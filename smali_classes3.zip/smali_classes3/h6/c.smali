.class public final Lh6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:J

.field public b:Ljava/util/HashMap;

.field public c:Ljava/util/HashMap;

.field public final synthetic d:Lcom/palmpay/lib/apm/network/OkHttpEventListener;


# direct methods
.method public constructor <init>(Lcom/palmpay/lib/apm/network/OkHttpEventListener;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lh6/c;->d:Lcom/palmpay/lib/apm/network/OkHttpEventListener;

    .line 5
    .line 6
    const-string p1, "url"

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2}, Lh6/c;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 4

    .line 1
    iget-object v0, p0, Lh6/c;->b:Ljava/util/HashMap;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    check-cast p2, Ljava/lang/Long;

    .line 11
    .line 12
    iget-object v0, p0, Lh6/c;->b:Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-virtual {v0, p3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p3

    .line 18
    check-cast p3, Ljava/lang/Long;

    .line 19
    .line 20
    if-eqz p2, :cond_1

    .line 21
    .line 22
    if-eqz p3, :cond_1

    .line 23
    .line 24
    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    .line 25
    .line 26
    .line 27
    move-result-wide v0

    .line 28
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 29
    .line 30
    .line 31
    move-result-wide v2

    .line 32
    cmp-long v0, v0, v2

    .line 33
    .line 34
    if-lez v0, :cond_1

    .line 35
    .line 36
    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    .line 37
    .line 38
    .line 39
    move-result-wide v0

    .line 40
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 41
    .line 42
    .line 43
    move-result-wide p2

    .line 44
    sub-long/2addr v0, p2

    .line 45
    invoke-virtual {p0, p1, v0, v1}, Lh6/c;->c(Ljava/lang/String;J)V

    .line 46
    .line 47
    .line 48
    const/4 p1, 0x1

    .line 49
    return p1

    .line 50
    :cond_1
    :goto_0
    const/4 p1, 0x0

    .line 51
    return p1
.end method

.method public final b(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    :try_start_0
    iget-object v0, p0, Lh6/c;->c:Ljava/util/HashMap;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Ljava/util/HashMap;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lh6/c;->c:Ljava/util/HashMap;

    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, Lh6/c;->c:Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    .line 16
    .line 17
    :catch_0
    return-void
.end method

.method public final c(Ljava/lang/String;J)V
    .locals 1

    .line 1
    :try_start_0
    iget-object v0, p0, Lh6/c;->c:Ljava/util/HashMap;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Ljava/util/HashMap;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lh6/c;->c:Ljava/util/HashMap;

    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, Lh6/c;->c:Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 15
    .line 16
    .line 17
    move-result-object p2

    .line 18
    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 19
    .line 20
    .line 21
    :catch_0
    return-void
.end method

.method public final d(ZZ)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 6
    .line 7
    .line 8
    move-result-wide v1

    .line 9
    iput-wide v1, v0, Lh6/c;->a:J

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    iget-object v1, v0, Lh6/c;->b:Ljava/util/HashMap;

    .line 13
    .line 14
    const-string v2, "requestHeadersStart"

    .line 15
    .line 16
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-eqz v1, :cond_13

    .line 21
    .line 22
    iget-object v1, v0, Lh6/c;->b:Ljava/util/HashMap;

    .line 23
    .line 24
    const-string v2, "requestHeadersEnd"

    .line 25
    .line 26
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    if-nez v1, :cond_1

    .line 31
    .line 32
    goto/16 :goto_5

    .line 33
    .line 34
    :cond_1
    sget-object v1, Lcom/palmpay/lib/apm/LibApm;->INSTANCE:Lcom/palmpay/lib/apm/LibApm;

    .line 35
    .line 36
    invoke-virtual {v1}, Lcom/palmpay/lib/apm/LibApm;->isFirebaseInitialized()Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-nez v1, :cond_2

    .line 41
    .line 42
    goto/16 :goto_6

    .line 43
    .line 44
    :cond_2
    invoke-static {}, Lcom/google/firebase/perf/FirebasePerformance;->getInstance()Lcom/google/firebase/perf/FirebasePerformance;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    iget-object v2, v0, Lh6/c;->d:Lcom/palmpay/lib/apm/network/OkHttpEventListener;

    .line 49
    .line 50
    invoke-static {v2}, Lcom/palmpay/lib/apm/network/OkHttpEventListener;->a(Lcom/palmpay/lib/apm/network/OkHttpEventListener;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    invoke-virtual {v1, v3}, Lcom/google/firebase/perf/FirebasePerformance;->newTrace(Ljava/lang/String;)Lcom/google/firebase/perf/metrics/Trace;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    invoke-virtual {v1}, Lcom/google/firebase/perf/metrics/Trace;->start()V

    .line 59
    .line 60
    .line 61
    iget-object v3, v0, Lh6/c;->c:Ljava/util/HashMap;

    .line 62
    .line 63
    const/4 v4, 0x0

    .line 64
    if-eqz v3, :cond_7

    .line 65
    .line 66
    invoke-virtual {v3}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 67
    .line 68
    .line 69
    move-result-object v3

    .line 70
    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    :cond_3
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 75
    .line 76
    .line 77
    move-result v5

    .line 78
    if-eqz v5, :cond_6

    .line 79
    .line 80
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v5

    .line 84
    check-cast v5, Ljava/util/Map$Entry;

    .line 85
    .line 86
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v6

    .line 90
    check-cast v6, Ljava/lang/String;

    .line 91
    .line 92
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v5

    .line 96
    instance-of v7, v5, Ljava/lang/Long;

    .line 97
    .line 98
    if-eqz v7, :cond_4

    .line 99
    .line 100
    check-cast v5, Ljava/lang/Long;

    .line 101
    .line 102
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 103
    .line 104
    .line 105
    move-result-wide v7

    .line 106
    invoke-virtual {v1, v6, v7, v8}, Lcom/google/firebase/perf/metrics/Trace;->putMetric(Ljava/lang/String;J)V

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_4
    instance-of v7, v5, Ljava/lang/String;

    .line 111
    .line 112
    if-eqz v7, :cond_3

    .line 113
    .line 114
    const-string v7, "encryption"

    .line 115
    .line 116
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v7

    .line 120
    if-eqz v7, :cond_5

    .line 121
    .line 122
    move-object v4, v5

    .line 123
    check-cast v4, Ljava/lang/String;

    .line 124
    .line 125
    goto :goto_0

    .line 126
    :cond_5
    check-cast v5, Ljava/lang/String;

    .line 127
    .line 128
    invoke-virtual {v1, v6, v5}, Lcom/google/firebase/perf/metrics/Trace;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    goto :goto_0

    .line 132
    :cond_6
    iget-object v3, v0, Lh6/c;->c:Ljava/util/HashMap;

    .line 133
    .line 134
    invoke-virtual {v3}, Ljava/util/HashMap;->clear()V

    .line 135
    .line 136
    .line 137
    :cond_7
    const-string v3, "dnsDuration"

    .line 138
    .line 139
    const-string v5, "dnsStart"

    .line 140
    .line 141
    const-string v6, "dnsEnd"

    .line 142
    .line 143
    invoke-virtual {v0, v3, v5, v6}, Lh6/c;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    .line 144
    .line 145
    .line 146
    move-result v5

    .line 147
    const-string v6, "connectDuration"

    .line 148
    .line 149
    const-string v7, "connectStart"

    .line 150
    .line 151
    const-string v8, "connectEnd"

    .line 152
    .line 153
    invoke-virtual {v0, v6, v7, v8}, Lh6/c;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    .line 154
    .line 155
    .line 156
    move-result v7

    .line 157
    const-string v8, "tlsDuration"

    .line 158
    .line 159
    const-string v9, "secureConnectStart"

    .line 160
    .line 161
    const-string v10, "secureConnectEnd"

    .line 162
    .line 163
    invoke-virtual {v0, v8, v9, v10}, Lh6/c;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    .line 164
    .line 165
    .line 166
    move-result v9

    .line 167
    iget-object v10, v0, Lh6/c;->b:Ljava/util/HashMap;

    .line 168
    .line 169
    if-nez v10, :cond_8

    .line 170
    .line 171
    goto :goto_1

    .line 172
    :cond_8
    const-string v11, "callStart"

    .line 173
    .line 174
    invoke-virtual {v10, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object v10

    .line 178
    check-cast v10, Ljava/lang/Long;

    .line 179
    .line 180
    iget-object v11, v0, Lh6/c;->b:Ljava/util/HashMap;

    .line 181
    .line 182
    const-string v12, "callEnd"

    .line 183
    .line 184
    invoke-virtual {v11, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v11

    .line 188
    check-cast v11, Ljava/lang/Long;

    .line 189
    .line 190
    iget-object v12, v0, Lh6/c;->b:Ljava/util/HashMap;

    .line 191
    .line 192
    const-string v13, "callFailed"

    .line 193
    .line 194
    invoke-virtual {v12, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v12

    .line 198
    check-cast v12, Ljava/lang/Long;

    .line 199
    .line 200
    if-eqz v12, :cond_9

    .line 201
    .line 202
    move-object v11, v12

    .line 203
    :cond_9
    if-eqz v10, :cond_a

    .line 204
    .line 205
    if-eqz v11, :cond_a

    .line 206
    .line 207
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    .line 208
    .line 209
    .line 210
    move-result-wide v12

    .line 211
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 212
    .line 213
    .line 214
    move-result-wide v14

    .line 215
    cmp-long v12, v12, v14

    .line 216
    .line 217
    if-lez v12, :cond_a

    .line 218
    .line 219
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    .line 220
    .line 221
    .line 222
    move-result-wide v11

    .line 223
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 224
    .line 225
    .line 226
    move-result-wide v13

    .line 227
    sub-long/2addr v11, v13

    .line 228
    const-string v10, "totalDuration"

    .line 229
    .line 230
    invoke-virtual {v0, v10, v11, v12}, Lh6/c;->c(Ljava/lang/String;J)V

    .line 231
    .line 232
    .line 233
    :cond_a
    :goto_1
    iget-object v10, v0, Lh6/c;->b:Ljava/util/HashMap;

    .line 234
    .line 235
    if-eqz v10, :cond_b

    .line 236
    .line 237
    invoke-virtual {v10}, Ljava/util/HashMap;->clear()V

    .line 238
    .line 239
    .line 240
    :cond_b
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 241
    .line 242
    .line 243
    move-result-wide v10

    .line 244
    iget-wide v12, v0, Lh6/c;->a:J

    .line 245
    .line 246
    sub-long/2addr v10, v12

    .line 247
    const-wide/16 v12, 0x3e8

    .line 248
    .line 249
    cmp-long v10, v10, v12

    .line 250
    .line 251
    if-gtz v10, :cond_c

    .line 252
    .line 253
    const-string v10, "true"

    .line 254
    .line 255
    goto :goto_2

    .line 256
    :cond_c
    const-string v10, "false"

    .line 257
    .line 258
    :goto_2
    const-string v11, "success_in_one_second"

    .line 259
    .line 260
    invoke-virtual {v1, v11, v10}, Lcom/google/firebase/perf/metrics/Trace;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    const-string v10, "newConnection"

    .line 264
    .line 265
    if-eqz p2, :cond_d

    .line 266
    .line 267
    const-string v4, "FAIL"

    .line 268
    .line 269
    invoke-virtual {v1, v10, v4}, Lcom/google/firebase/perf/metrics/Trace;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    goto :goto_3

    .line 273
    :cond_d
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 274
    .line 275
    .line 276
    move-result v11

    .line 277
    if-nez v11, :cond_e

    .line 278
    .line 279
    new-instance v11, Ljava/lang/StringBuilder;

    .line 280
    .line 281
    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 282
    .line 283
    .line 284
    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 285
    .line 286
    .line 287
    const-string v12, "/"

    .line 288
    .line 289
    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 290
    .line 291
    .line 292
    invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 293
    .line 294
    .line 295
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object v4

    .line 299
    invoke-virtual {v1, v10, v4}, Lcom/google/firebase/perf/metrics/Trace;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    goto :goto_3

    .line 303
    :cond_e
    invoke-static {v7}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v4

    .line 307
    invoke-virtual {v1, v10, v4}, Lcom/google/firebase/perf/metrics/Trace;->putAttribute(Ljava/lang/String;Ljava/lang/String;)V

    .line 308
    .line 309
    .line 310
    :goto_3
    invoke-virtual {v2}, Lcom/palmpay/lib/apm/network/NQEHttpEventListener;->isDebug()Z

    .line 311
    .line 312
    .line 313
    move-result v2

    .line 314
    if-nez v2, :cond_f

    .line 315
    .line 316
    goto :goto_4

    .line 317
    :cond_f
    const-string v2, "url"

    .line 318
    .line 319
    invoke-virtual {v1, v2}, Lcom/google/firebase/perf/metrics/Trace;->getAttribute(Ljava/lang/String;)Ljava/lang/String;

    .line 320
    .line 321
    .line 322
    if-eqz v5, :cond_10

    .line 323
    .line 324
    invoke-virtual {v1, v3}, Lcom/google/firebase/perf/metrics/Trace;->getLongMetric(Ljava/lang/String;)J

    .line 325
    .line 326
    .line 327
    :cond_10
    if-eqz v7, :cond_11

    .line 328
    .line 329
    invoke-virtual {v1, v6}, Lcom/google/firebase/perf/metrics/Trace;->getLongMetric(Ljava/lang/String;)J

    .line 330
    .line 331
    .line 332
    :cond_11
    if-eqz v9, :cond_12

    .line 333
    .line 334
    invoke-virtual {v1, v8}, Lcom/google/firebase/perf/metrics/Trace;->getLongMetric(Ljava/lang/String;)J

    .line 335
    .line 336
    .line 337
    :cond_12
    :goto_4
    invoke-virtual {v1}, Lcom/google/firebase/perf/metrics/Trace;->stop()V

    .line 338
    .line 339
    .line 340
    return-void

    .line 341
    :cond_13
    :goto_5
    iget-object v1, v0, Lh6/c;->b:Ljava/util/HashMap;

    .line 342
    .line 343
    if-eqz v1, :cond_14

    .line 344
    .line 345
    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    .line 346
    .line 347
    .line 348
    :cond_14
    :goto_6
    return-void
.end method

.method public final e(JLjava/lang/String;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lh6/c;->b:Ljava/util/HashMap;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Ljava/util/HashMap;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lh6/c;->b:Ljava/util/HashMap;

    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, Lh6/c;->b:Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    invoke-virtual {v0, p3, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    const-string p1, "callStart"

    .line 22
    .line 23
    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    const/4 p2, 0x1

    .line 28
    const/4 v0, 0x0

    .line 29
    if-eqz p1, :cond_1

    .line 30
    .line 31
    invoke-virtual {p0, p2, v0}, Lh6/c;->d(ZZ)V

    .line 32
    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    const-string p1, "callEnd"

    .line 36
    .line 37
    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    if-eqz p1, :cond_2

    .line 42
    .line 43
    invoke-virtual {p0, v0, v0}, Lh6/c;->d(ZZ)V

    .line 44
    .line 45
    .line 46
    return p2

    .line 47
    :cond_2
    const-string p1, "callFailed"

    .line 48
    .line 49
    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    if-eqz p1, :cond_3

    .line 54
    .line 55
    invoke-virtual {p0, v0, p2}, Lh6/c;->d(ZZ)V

    .line 56
    .line 57
    .line 58
    return p2

    .line 59
    :cond_3
    :goto_0
    return v0
.end method
