.class public final Lh6/a;
.super Lkotlin/jvm/internal/o;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# static fields
.field public static final a:Lh6/a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lh6/a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lkotlin/jvm/internal/o;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lh6/a;->a:Lh6/a;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Lcom/palmpay/lib/apm/network/NQEManager$networkCallback$2$1;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/palmpay/lib/apm/network/NQEManager$networkCallback$2$1;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method
