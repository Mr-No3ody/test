.class public final synthetic LT6/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/palmpay/lib/ui/form/PpFormVertical;


# direct methods
.method public synthetic constructor <init>(Lcom/palmpay/lib/ui/form/PpFormVertical;I)V
    .locals 0

    .line 1
    iput p2, p0, LT6/b;->a:I

    iput-object p1, p0, LT6/b;->b:Lcom/palmpay/lib/ui/form/PpFormVertical;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget v0, p0, LT6/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LT6/b;->b:Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/palmpay/lib/ui/form/PpFormVertical;->s0:Landroid/view/View$OnClickListener;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void

    .line 16
    :pswitch_0
    iget-object p1, p0, LT6/b;->b:Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 17
    .line 18
    iget-object v0, p1, Lcom/palmpay/lib/ui/form/PpFormVertical;->B:Landroidx/appcompat/widget/AppCompatEditText;

    .line 19
    .line 20
    invoke-virtual {v0}, Landroidx/appcompat/widget/AppCompatEditText;->getText()Landroid/text/Editable;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-interface {v0}, Landroid/text/Editable;->clear()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p1}, Lcom/palmpay/lib/ui/form/PpFormVertical;->d()V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
