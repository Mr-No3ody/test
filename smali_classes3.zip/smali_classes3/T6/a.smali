.class public final synthetic LT6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/palmpay/lib/ui/form/PpFormHorizontal;


# direct methods
.method public synthetic constructor <init>(Lcom/palmpay/lib/ui/form/PpFormHorizontal;I)V
    .locals 0

    .line 1
    iput p2, p0, LT6/a;->a:I

    iput-object p1, p0, LT6/a;->b:Lcom/palmpay/lib/ui/form/PpFormHorizontal;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget v0, p0, LT6/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LT6/a;->b:Lcom/palmpay/lib/ui/form/PpFormHorizontal;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/palmpay/lib/ui/form/PpFormHorizontal;->L:Landroid/view/View$OnClickListener;

    .line 9
    .line 10
    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object p1, p0, LT6/a;->b:Lcom/palmpay/lib/ui/form/PpFormHorizontal;

    .line 15
    .line 16
    invoke-static {p1}, Lcom/palmpay/lib/ui/form/PpFormHorizontal;->c(Lcom/palmpay/lib/ui/form/PpFormHorizontal;)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    nop

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
