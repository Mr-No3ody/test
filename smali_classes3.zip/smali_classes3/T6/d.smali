.class public final synthetic LT6/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/palmpay/lib/ui/form/PpPhoneEditText;


# direct methods
.method public synthetic constructor <init>(Lcom/palmpay/lib/ui/form/PpPhoneEditText;I)V
    .locals 0

    .line 1
    iput p2, p0, LT6/d;->a:I

    iput-object p1, p0, LT6/d;->b:Lcom/palmpay/lib/ui/form/PpPhoneEditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget v0, p0, LT6/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LT6/d;->b:Lcom/palmpay/lib/ui/form/PpPhoneEditText;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/palmpay/lib/ui/form/PpPhoneEditText;->r0:Landroid/view/View$OnClickListener;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void

    .line 16
    :pswitch_0
    iget-object p1, p0, LT6/d;->b:Lcom/palmpay/lib/ui/form/PpPhoneEditText;

    .line 17
    .line 18
    invoke-static {p1}, Lcom/palmpay/lib/ui/form/PpPhoneEditText;->d(Lcom/palmpay/lib/ui/form/PpPhoneEditText;)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
