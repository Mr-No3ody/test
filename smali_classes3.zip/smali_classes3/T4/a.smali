.class public final LT4/a;
.super Lr5/a;
.source "SourceFile"


# virtual methods
.method public final B(Ljava/lang/String;)V
    .locals 0

    .line 1
    return-void
.end method
