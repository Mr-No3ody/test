.class public final LT4/b;
.super Lr5/a;
.source "SourceFile"


# instance fields
.field public a:Ljava/util/logging/Logger;


# virtual methods
.method public final B(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, LT4/b;->a:Ljava/util/logging/Logger;

    .line 2
    .line 3
    sget-object v1, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
