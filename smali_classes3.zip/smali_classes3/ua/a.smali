.class public final synthetic Lua/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/manager/FileUploadManager;

.field public final synthetic b:Ljava/io/File;

.field public final synthetic c:Z

.field public final synthetic d:Lcom/transsnet/palmpay/core/manager/FileUploadManager$UploadListener;

.field public final synthetic e:Z


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/manager/FileUploadManager;Ljava/io/File;ZLcom/transsnet/palmpay/core/manager/FileUploadManager$UploadListener;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lua/a;->a:Lcom/transsnet/palmpay/core/manager/FileUploadManager;

    iput-object p2, p0, Lua/a;->b:Ljava/io/File;

    iput-boolean p3, p0, Lua/a;->c:Z

    iput-object p4, p0, Lua/a;->d:Lcom/transsnet/palmpay/core/manager/FileUploadManager$UploadListener;

    iput-boolean p5, p0, Lua/a;->e:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    iget-object v0, p0, Lua/a;->a:Lcom/transsnet/palmpay/core/manager/FileUploadManager;

    iget-object v1, p0, Lua/a;->b:Ljava/io/File;

    iget-boolean v2, p0, Lua/a;->c:Z

    iget-object v3, p0, Lua/a;->d:Lcom/transsnet/palmpay/core/manager/FileUploadManager$UploadListener;

    iget-boolean v4, p0, Lua/a;->e:Z

    invoke-static {v0, v1, v2, v3, v4}, Lcom/transsnet/palmpay/core/manager/FileUploadManager;->a(Lcom/transsnet/palmpay/core/manager/FileUploadManager;Ljava/io/File;ZLcom/transsnet/palmpay/core/manager/FileUploadManager$UploadListener;Z)V

    return-void
.end method
