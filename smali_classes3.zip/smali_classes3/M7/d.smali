.class public final LM7/d;
.super LJ3/a;
.source "SourceFile"


# static fields
.field public static final e:LM7/d;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, LM7/d;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LM7/d;->e:LM7/d;

    .line 7
    .line 8
    return-void
.end method
