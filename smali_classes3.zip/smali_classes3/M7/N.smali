.class public abstract enum LM7/N;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum a:LM7/M;

.field public static final enum b:LM7/L;

.field public static final enum c:LM7/K;

.field public static final enum d:LM7/J;

.field public static final synthetic e:[LM7/N;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, LM7/M;

    .line 2
    .line 3
    invoke-direct {v0}, LM7/M;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LM7/N;->a:LM7/M;

    .line 7
    .line 8
    new-instance v1, LM7/L;

    .line 9
    .line 10
    invoke-direct {v1}, LM7/L;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v1, LM7/N;->b:LM7/L;

    .line 14
    .line 15
    new-instance v2, LM7/K;

    .line 16
    .line 17
    invoke-direct {v2}, LM7/K;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v2, LM7/N;->c:LM7/K;

    .line 21
    .line 22
    new-instance v3, LM7/J;

    .line 23
    .line 24
    invoke-direct {v3}, LM7/J;-><init>()V

    .line 25
    .line 26
    .line 27
    sput-object v3, LM7/N;->d:LM7/J;

    .line 28
    .line 29
    const/4 v4, 0x4

    .line 30
    new-array v4, v4, [LM7/N;

    .line 31
    .line 32
    const/4 v5, 0x0

    .line 33
    aput-object v0, v4, v5

    .line 34
    .line 35
    const/4 v0, 0x1

    .line 36
    aput-object v1, v4, v0

    .line 37
    .line 38
    const/4 v0, 0x2

    .line 39
    aput-object v2, v4, v0

    .line 40
    .line 41
    const/4 v0, 0x3

    .line 42
    aput-object v3, v4, v0

    .line 43
    .line 44
    sput-object v4, LM7/N;->e:[LM7/N;

    .line 45
    .line 46
    invoke-static {v4}, Lcom/facebook/imagepipeline/nativecode/b;->n([Ljava/lang/Enum;)LGf/a;

    .line 47
    .line 48
    .line 49
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LM7/N;
    .locals 1

    .line 1
    const-class v0, LM7/N;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LM7/N;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[LM7/N;
    .locals 1

    .line 1
    sget-object v0, LM7/N;->e:[LM7/N;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LM7/N;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public abstract a(LM7/I;)I
.end method
