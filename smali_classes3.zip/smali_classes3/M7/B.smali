.class public final synthetic LM7/B;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# instance fields
.field public final synthetic a:Lcom/swmansion/rnscreens/ScreenContainer;

.field public final synthetic b:Lcom/swmansion/rnscreens/ScreenStackFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/swmansion/rnscreens/ScreenContainer;Lcom/swmansion/rnscreens/ScreenStackFragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LM7/B;->a:Lcom/swmansion/rnscreens/ScreenContainer;

    iput-object p2, p0, LM7/B;->b:Lcom/swmansion/rnscreens/ScreenStackFragment;

    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 1

    .line 1
    sget v0, Lcom/swmansion/rnscreens/ScreenStackFragment;->X:I

    .line 2
    .line 3
    const-string v0, "<unused var>"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string p1, "insets"

    .line 9
    .line 10
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, LM7/B;->a:Lcom/swmansion/rnscreens/ScreenContainer;

    .line 14
    .line 15
    invoke-static {p1, p2}, Landroidx/core/view/q0;->h(Landroid/view/View;Landroid/view/WindowInsets;)Landroidx/core/view/q0;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    const-string v0, "toWindowInsetsCompat(...)"

    .line 20
    .line 21
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, LM7/B;->b:Lcom/swmansion/rnscreens/ScreenStackFragment;

    .line 25
    .line 26
    invoke-virtual {v0, p1}, Lcom/swmansion/rnscreens/ScreenStackFragment;->h(Landroidx/core/view/q0;)V

    .line 27
    .line 28
    .line 29
    return-object p2
.end method
