.class public final synthetic LM7/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LM7/s;->a:I

    iput-object p1, p0, LM7/s;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 25

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    const/4 v2, 0x3

    .line 4
    const/4 v0, 0x2

    .line 5
    const/4 v3, 0x0

    .line 6
    const/4 v4, 0x0

    .line 7
    const/4 v5, 0x1

    .line 8
    iget v6, v1, LM7/s;->a:I

    .line 9
    .line 10
    packed-switch v6, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    new-array v0, v4, [Ljava/lang/Object;

    .line 14
    .line 15
    const-string v2, "HybridBridgePolicy"

    .line 16
    .line 17
    const-string v3, "getWebViewDomTree timeout"

    .line 18
    .line 19
    invoke-static {v2, v3, v0}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, LW4/f;

    .line 25
    .line 26
    invoke-virtual {v0}, LW4/f;->onFailed()V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/custom_view/model/ModelCopyableText;->p:I

    .line 31
    .line 32
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/ModelCopyableText;

    .line 35
    .line 36
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/model/ModelCopyableText;->d()V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :pswitch_1
    sget-boolean v0, Lcom/transsnet/palmpay/core/web/PWebActivity;->L:Z

    .line 41
    .line 42
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v0, Lcom/transsnet/palmpay/core/web/PWebActivity;

    .line 45
    .line 46
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/core/web/PWebActivity;->showLoadingDialog(Z)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, Lcom/palmpay/lib/webview/container/PPWebActivity;->isHideTitleBar()Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_1

    .line 54
    .line 55
    invoke-virtual {v0}, Lcom/palmpay/lib/webview/container/PPWebActivity;->getTitleBar()Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    if-eqz v2, :cond_0

    .line 60
    .line 61
    invoke-static {v2, v4}, Loa/h;->s(Landroid/view/View;Z)V

    .line 62
    .line 63
    .line 64
    :cond_0
    iget-object v0, v0, Lcom/transsnet/palmpay/core/web/PWebActivity;->v:Landroid/view/View;

    .line 65
    .line 66
    if-eqz v0, :cond_1

    .line 67
    .line 68
    invoke-static {v0, v4}, Loa/h;->s(Landroid/view/View;Z)V

    .line 69
    .line 70
    .line 71
    :cond_1
    return-void

    .line 72
    :pswitch_2
    sget v0, Lcom/transsnet/palmpay/account/ui/fragment/identify/IdentityVerificationUserProfileFragment;->L:I

    .line 73
    .line 74
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast v0, Lcom/transsnet/palmpay/account/ui/fragment/identify/IdentityVerificationUserProfileFragment;

    .line 77
    .line 78
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 79
    .line 80
    check-cast v0, LI8/t;

    .line 81
    .line 82
    if-eqz v0, :cond_2

    .line 83
    .line 84
    iget-object v0, v0, LI8/t;->v:Landroidx/core/widget/NestedScrollView;

    .line 85
    .line 86
    if-eqz v0, :cond_2

    .line 87
    .line 88
    const/high16 v2, 0x42f00000    # 120.0f

    .line 89
    .line 90
    invoke-static {v2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(F)I

    .line 91
    .line 92
    .line 93
    move-result v2

    .line 94
    invoke-virtual {v0, v4, v2}, Landroid/view/View;->scrollBy(II)V

    .line 95
    .line 96
    .line 97
    :cond_2
    return-void

    .line 98
    :pswitch_3
    sget v0, Lcom/transsnet/palmpay/account/ui/fragment/identify/IdentityVerificationAddressFragment;->Q:I

    .line 99
    .line 100
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v0, Lcom/transsnet/palmpay/account/ui/fragment/identify/IdentityVerificationAddressFragment;

    .line 103
    .line 104
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    invoke-static {v2}, LPa/i0;->W(Landroid/app/Activity;)Z

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    if-eqz v2, :cond_3

    .line 113
    .line 114
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 115
    .line 116
    check-cast v0, LI8/p;

    .line 117
    .line 118
    if-eqz v0, :cond_3

    .line 119
    .line 120
    iget-object v0, v0, LI8/p;->g:Landroidx/core/widget/NestedScrollView;

    .line 121
    .line 122
    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    .line 123
    .line 124
    .line 125
    move-result v2

    .line 126
    invoke-virtual {v0, v2}, Landroidx/core/widget/NestedScrollView;->p(I)V

    .line 127
    .line 128
    .line 129
    :cond_3
    return-void

    .line 130
    :pswitch_4
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast v0, LV7/g;

    .line 133
    .line 134
    iget-boolean v2, v0, LV7/g;->a:Z

    .line 135
    .line 136
    if-eqz v2, :cond_4

    .line 137
    .line 138
    invoke-virtual {v0}, LV7/g;->e()V

    .line 139
    .line 140
    .line 141
    :cond_4
    return-void

    .line 142
    :pswitch_5
    sget-object v0, Lcom/swmansion/rnscreens/gamma/tabs/TabsHost;->y0:[Lkotlin/reflect/KProperty;

    .line 143
    .line 144
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast v0, Lcom/swmansion/rnscreens/gamma/tabs/TabsHost;

    .line 147
    .line 148
    iget-boolean v2, v0, Lcom/swmansion/rnscreens/gamma/tabs/TabsHost;->p:Z

    .line 149
    .line 150
    if-nez v2, :cond_5

    .line 151
    .line 152
    iget-object v2, v0, Lcom/swmansion/rnscreens/gamma/tabs/TabsHost;->x0:LH0/f;

    .line 153
    .line 154
    if-eqz v2, :cond_5

    .line 155
    .line 156
    iput-boolean v5, v0, Lcom/swmansion/rnscreens/gamma/tabs/TabsHost;->p:Z

    .line 157
    .line 158
    sget-object v0, Lcom/facebook/react/modules/core/ReactChoreographer;->Companion:Lcom/facebook/react/modules/core/ReactChoreographer$Companion;

    .line 159
    .line 160
    invoke-virtual {v0}, Lcom/facebook/react/modules/core/ReactChoreographer$Companion;->getInstance()Lcom/facebook/react/modules/core/ReactChoreographer;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    sget-object v3, Lcom/facebook/react/modules/core/ReactChoreographer$CallbackType;->NATIVE_ANIMATED_MODULE:Lcom/facebook/react/modules/core/ReactChoreographer$CallbackType;

    .line 165
    .line 166
    invoke-virtual {v0, v3, v2}, Lcom/facebook/react/modules/core/ReactChoreographer;->postFrameCallback(Lcom/facebook/react/modules/core/ReactChoreographer$CallbackType;Landroid/view/Choreographer$FrameCallback;)V

    .line 167
    .line 168
    .line 169
    :cond_5
    const-string v0, "tag"

    .line 170
    .line 171
    const-string v2, "TabsHost"

    .line 172
    .line 173
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    const-string v0, "message"

    .line 177
    .line 178
    const-string v2, "BottomNavigationView request layout"

    .line 179
    .line 180
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    return-void

    .line 184
    :pswitch_6
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast v0, Lkotlinx/coroutines/Job;

    .line 187
    .line 188
    if-eqz v0, :cond_6

    .line 189
    .line 190
    invoke-interface {v0, v3}, Lkotlinx/coroutines/Job;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 191
    .line 192
    .line 193
    :cond_6
    return-void

    .line 194
    :pswitch_7
    sget v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->k0:I

    .line 195
    .line 196
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;

    .line 199
    .line 200
    invoke-virtual {v0}, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->n()LUc/o0;

    .line 201
    .line 202
    .line 203
    move-result-object v2

    .line 204
    invoke-virtual {v2}, LUc/o0;->b()V

    .line 205
    .line 206
    .line 207
    invoke-virtual {v0}, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->n()LUc/o0;

    .line 208
    .line 209
    .line 210
    move-result-object v0

    .line 211
    invoke-virtual {v0, v5}, LUc/o0;->d(I)V

    .line 212
    .line 213
    .line 214
    return-void

    .line 215
    :pswitch_8
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 216
    .line 217
    check-cast v0, LUc/e0;

    .line 218
    .line 219
    invoke-virtual {v0}, LUc/e0;->c()V

    .line 220
    .line 221
    .line 222
    return-void

    .line 223
    :pswitch_9
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v0, LUc/O;

    .line 226
    .line 227
    new-instance v2, Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/AboutDialog;

    .line 228
    .line 229
    iget-object v0, v0, LUc/O;->a:Lcom/transsnet/palmpay/p2pcash/ui/atm/CashierDeskPage;

    .line 230
    .line 231
    const-string v3, "<this>"

    .line 232
    .line 233
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    invoke-direct {v2, v0}, Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/AboutDialog;-><init>(Landroid/content/Context;)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {v2}, LO6/f;->show()V

    .line 240
    .line 241
    .line 242
    const-string v3, "Guidelines"

    .line 243
    .line 244
    const/4 v6, 0x6

    .line 245
    const-string v7, "For the Agent to reserve notes for you, you will pay a booking deposit. This deposit will be held by PalmPay and will be refunded to your Balance if you cancel the booking before the appointment time or if the Agent declines the booking.\n\nGuidelines\n1\u3001When you visit the Agent\'s location to withdraw cash, the booking deposit will be taken from the withdrawal amount.\n\n2\u3001If you cancel the booking before the appointment time, the booking deposit will be refunded to your Balance.\n\n3\u3001Your booking deposit will not be refunded when your appointment is overdue and cancelled.\n\n4\u3001If the Agent cancels the appointment, the booking deposit will be refunded to your Balance.\n\n5\u3001Your withdrawal amount is subject to your account KYC level. If your daily withdrawal limit has been reached at the time of withdrawal, you will not be able to withdraw and the N100 booking deposit will be forfeited."

    .line 246
    .line 247
    invoke-static {v7, v3, v4, v4, v6}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 248
    .line 249
    .line 250
    move-result v3

    .line 251
    add-int/lit8 v4, v3, 0xa

    .line 252
    .line 253
    if-ltz v3, :cond_7

    .line 254
    .line 255
    new-instance v6, Landroid/text/SpannableString;

    .line 256
    .line 257
    invoke-direct {v6, v7}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 258
    .line 259
    .line 260
    new-instance v7, Landroid/text/style/StyleSpan;

    .line 261
    .line 262
    invoke-direct {v7, v5}, Landroid/text/style/StyleSpan;-><init>(I)V

    .line 263
    .line 264
    .line 265
    const/16 v8, 0x21

    .line 266
    .line 267
    invoke-virtual {v6, v7, v3, v4, v8}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 268
    .line 269
    .line 270
    new-instance v7, Landroid/text/style/AbsoluteSizeSpan;

    .line 271
    .line 272
    const/16 v9, 0xe

    .line 273
    .line 274
    invoke-direct {v7, v9, v5}, Landroid/text/style/AbsoluteSizeSpan;-><init>(IZ)V

    .line 275
    .line 276
    .line 277
    invoke-virtual {v6, v7, v3, v4, v8}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 278
    .line 279
    .line 280
    invoke-virtual {v2, v6}, Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/AboutDialog;->setContent(Ljava/lang/CharSequence;)V

    .line 281
    .line 282
    .line 283
    goto :goto_0

    .line 284
    :cond_7
    invoke-virtual {v2, v7}, Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/AboutDialog;->setContent(Ljava/lang/CharSequence;)V

    .line 285
    .line 286
    .line 287
    :goto_0
    sget v3, Lba/k;->core_next:I

    .line 288
    .line 289
    invoke-virtual {v0, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v0

    .line 293
    invoke-virtual {v2, v0}, Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/AboutDialog;->setBtnText(Ljava/lang/String;)V

    .line 294
    .line 295
    .line 296
    return-void

    .line 297
    :pswitch_a
    sget v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingDetailPage;->H:I

    .line 298
    .line 299
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 300
    .line 301
    check-cast v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingDetailPage;

    .line 302
    .line 303
    invoke-virtual {v0}, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingDetailPage;->q()LUc/d;

    .line 304
    .line 305
    .line 306
    move-result-object v2

    .line 307
    invoke-virtual {v2}, LUc/d;->c()Lcom/transsnet/palmpay/p2pcash/bean/rsp/QueryAppointmentDetailResp$DataBean;

    .line 308
    .line 309
    .line 310
    move-result-object v2

    .line 311
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 312
    .line 313
    .line 314
    iget v2, v2, Lcom/transsnet/palmpay/p2pcash/bean/rsp/QueryAppointmentDetailResp$DataBean;->orderStatus:I

    .line 315
    .line 316
    const/16 v3, 0xd

    .line 317
    .line 318
    if-ne v2, v3, :cond_8

    .line 319
    .line 320
    goto :goto_1

    .line 321
    :cond_8
    move v5, v4

    .line 322
    :goto_1
    iget-object v2, v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingDetailPage;->C:Lxf/t;

    .line 323
    .line 324
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object v2

    .line 328
    check-cast v2, LUc/i;

    .line 329
    .line 330
    if-eqz v5, :cond_9

    .line 331
    .line 332
    invoke-virtual {v0}, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingDetailPage;->q()LUc/d;

    .line 333
    .line 334
    .line 335
    move-result-object v0

    .line 336
    invoke-virtual {v0}, LUc/d;->c()Lcom/transsnet/palmpay/p2pcash/bean/rsp/QueryAppointmentDetailResp$DataBean;

    .line 337
    .line 338
    .line 339
    move-result-object v0

    .line 340
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 341
    .line 342
    .line 343
    iget-object v0, v0, Lcom/transsnet/palmpay/p2pcash/bean/rsp/QueryAppointmentDetailResp$DataBean;->balanceOrderNo:Ljava/lang/String;

    .line 344
    .line 345
    goto :goto_2

    .line 346
    :cond_9
    iget-object v0, v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingDetailPage;->v:Ljava/lang/String;

    .line 347
    .line 348
    :goto_2
    if-eqz v5, :cond_a

    .line 349
    .line 350
    const-string v3, "t1"

    .line 351
    .line 352
    goto :goto_3

    .line 353
    :cond_a
    const-string v3, "s9"

    .line 354
    .line 355
    :goto_3
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 356
    .line 357
    .line 358
    const-string v2, "transType"

    .line 359
    .line 360
    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 364
    .line 365
    .line 366
    move-result-object v5

    .line 367
    const-string v6, "/p2p/exchange_cash_transaction_detail"

    .line 368
    .line 369
    invoke-virtual {v5, v6}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 370
    .line 371
    .line 372
    move-result-object v5

    .line 373
    const-string v6, "orderNo"

    .line 374
    .line 375
    invoke-virtual {v5, v6, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 376
    .line 377
    .line 378
    move-result-object v0

    .line 379
    invoke-virtual {v0, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 380
    .line 381
    .line 382
    move-result-object v0

    .line 383
    const-string v2, "from_page"

    .line 384
    .line 385
    invoke-virtual {v0, v2, v4}, Lcom/alibaba/android/arouter/facade/Postcard;->withBoolean(Ljava/lang/String;Z)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 386
    .line 387
    .line 388
    move-result-object v0

    .line 389
    invoke-virtual {v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 390
    .line 391
    .line 392
    return-void

    .line 393
    :pswitch_b
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 394
    .line 395
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeView;

    .line 396
    .line 397
    iget-object v0, v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeView;->p:Lcom/transsnet/palmpay/core/viewmodel/c;

    .line 398
    .line 399
    if-eqz v0, :cond_b

    .line 400
    .line 401
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/viewmodel/c;->g()V

    .line 402
    .line 403
    .line 404
    :cond_b
    return-void

    .line 405
    :pswitch_c
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 406
    .line 407
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 408
    .line 409
    iget-object v0, v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->w:Lcom/transsnet/palmpay/core/viewmodel/c;

    .line 410
    .line 411
    if-eqz v0, :cond_c

    .line 412
    .line 413
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/viewmodel/c;->g()V

    .line 414
    .line 415
    .line 416
    :cond_c
    return-void

    .line 417
    :pswitch_d
    const-string v0, "this$0"

    .line 418
    .line 419
    iget-object v2, v1, LM7/s;->b:Ljava/lang/Object;

    .line 420
    .line 421
    check-cast v2, LS1/c;

    .line 422
    .line 423
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 424
    .line 425
    .line 426
    iget-object v0, v2, LS1/c;->b:Lcom/chad/library/adapter/base/listener/OnLoadMoreListener;

    .line 427
    .line 428
    if-nez v0, :cond_d

    .line 429
    .line 430
    goto :goto_4

    .line 431
    :cond_d
    invoke-interface {v0}, Lcom/chad/library/adapter/base/listener/OnLoadMoreListener;->onLoadMore()V

    .line 432
    .line 433
    .line 434
    :goto_4
    return-void

    .line 435
    :pswitch_e
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 436
    .line 437
    check-cast v0, Landroidx/constraintlayout/helper/widget/Carousel;

    .line 438
    .line 439
    iget-object v2, v0, Landroidx/constraintlayout/helper/widget/Carousel;->C:Landroidx/constraintlayout/motion/widget/MotionLayout;

    .line 440
    .line 441
    iget v3, v0, Landroidx/constraintlayout/helper/widget/Carousel;->w0:I

    .line 442
    .line 443
    invoke-virtual {v2, v3}, Landroidx/constraintlayout/motion/widget/MotionLayout;->setTransitionDuration(I)V

    .line 444
    .line 445
    .line 446
    iget v2, v0, Landroidx/constraintlayout/helper/widget/Carousel;->v0:I

    .line 447
    .line 448
    iget v4, v0, Landroidx/constraintlayout/helper/widget/Carousel;->B:I

    .line 449
    .line 450
    if-ge v2, v4, :cond_e

    .line 451
    .line 452
    iget-object v2, v0, Landroidx/constraintlayout/helper/widget/Carousel;->C:Landroidx/constraintlayout/motion/widget/MotionLayout;

    .line 453
    .line 454
    iget v0, v0, Landroidx/constraintlayout/helper/widget/Carousel;->k0:I

    .line 455
    .line 456
    invoke-virtual {v2, v0, v3}, Landroidx/constraintlayout/motion/widget/MotionLayout;->A(II)V

    .line 457
    .line 458
    .line 459
    goto :goto_5

    .line 460
    :cond_e
    iget-object v2, v0, Landroidx/constraintlayout/helper/widget/Carousel;->C:Landroidx/constraintlayout/motion/widget/MotionLayout;

    .line 461
    .line 462
    iget v0, v0, Landroidx/constraintlayout/helper/widget/Carousel;->p0:I

    .line 463
    .line 464
    invoke-virtual {v2, v0, v3}, Landroidx/constraintlayout/motion/widget/MotionLayout;->A(II)V

    .line 465
    .line 466
    .line 467
    :goto_5
    return-void

    .line 468
    :pswitch_f
    sget v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;->C:I

    .line 469
    .line 470
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 471
    .line 472
    check-cast v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;

    .line 473
    .line 474
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->isResumed()Z

    .line 475
    .line 476
    .line 477
    move-result v2

    .line 478
    if-eqz v2, :cond_12

    .line 479
    .line 480
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->isDetached()Z

    .line 481
    .line 482
    .line 483
    move-result v2

    .line 484
    if-eqz v2, :cond_f

    .line 485
    .line 486
    goto :goto_6

    .line 487
    :cond_f
    iget-boolean v2, v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;->t:Z

    .line 488
    .line 489
    if-nez v2, :cond_11

    .line 490
    .line 491
    iput-boolean v5, v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;->t:Z

    .line 492
    .line 493
    iget-object v2, v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;->B:LBc/b;

    .line 494
    .line 495
    if-eqz v2, :cond_10

    .line 496
    .line 497
    iget-object v2, v2, LBc/b;->e:Ljava/lang/Object;

    .line 498
    .line 499
    check-cast v2, Lcom/palmpay/lib/ui/button/PpButton;

    .line 500
    .line 501
    if-eqz v2, :cond_10

    .line 502
    .line 503
    invoke-static {v2, v4}, Loa/h;->s(Landroid/view/View;Z)V

    .line 504
    .line 505
    .line 506
    :cond_10
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;->G(Z)V

    .line 507
    .line 508
    .line 509
    invoke-virtual {v0}, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;->C()V

    .line 510
    .line 511
    .line 512
    goto :goto_6

    .line 513
    :cond_11
    iget-boolean v2, v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;->v:Z

    .line 514
    .line 515
    if-eqz v2, :cond_12

    .line 516
    .line 517
    invoke-virtual {v0}, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;->F()V

    .line 518
    .line 519
    .line 520
    :cond_12
    :goto_6
    return-void

    .line 521
    :pswitch_10
    sget-object v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/AuthPswFragment;->w:Lcom/transsnet/palmpay/account/ui/fragment/auth/AuthPswFragment$a;

    .line 522
    .line 523
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 524
    .line 525
    check-cast v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/AuthPswFragment;

    .line 526
    .line 527
    invoke-virtual {v0}, Lcom/transsnet/palmpay/account/ui/fragment/auth/AuthPswFragment;->u()V

    .line 528
    .line 529
    .line 530
    return-void

    .line 531
    :pswitch_11
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 532
    .line 533
    check-cast v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/AuthPinFragment;

    .line 534
    .line 535
    invoke-virtual {v0}, Lcom/transsnet/palmpay/account/ui/fragment/auth/AuthPinFragment;->v()V

    .line 536
    .line 537
    .line 538
    return-void

    .line 539
    :pswitch_12
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 540
    .line 541
    check-cast v0, Lcom/transsnet/palmpay/account/ui/dialog/SignUpRewardOnBackDialog;

    .line 542
    .line 543
    invoke-static {v0}, Lcom/transsnet/palmpay/account/ui/dialog/SignUpRewardOnBackDialog;->a(Lcom/transsnet/palmpay/account/ui/dialog/SignUpRewardOnBackDialog;)V

    .line 544
    .line 545
    .line 546
    return-void

    .line 547
    :pswitch_13
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 548
    .line 549
    move-object v3, v0

    .line 550
    check-cast v3, LPa/n0;

    .line 551
    .line 552
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 553
    .line 554
    .line 555
    :try_start_0
    sget-object v6, LPa/n0;->i:LZ4/c;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    .line 556
    .line 557
    if-nez v6, :cond_14

    .line 558
    .line 559
    sget-object v0, LPa/n0;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 560
    .line 561
    invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 562
    .line 563
    .line 564
    sget-object v7, LPa/n0;->n:Ljava/lang/Object;

    .line 565
    .line 566
    monitor-enter v7

    .line 567
    :try_start_1
    sget-boolean v0, LPa/n0;->l:Z

    .line 568
    .line 569
    if-eqz v0, :cond_13

    .line 570
    .line 571
    sget-object v0, LPa/n0;->i:LZ4/c;

    .line 572
    .line 573
    if-eqz v0, :cond_13

    .line 574
    .line 575
    sget-object v0, LPa/n0;->m:Ljava/util/ArrayDeque;

    .line 576
    .line 577
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 578
    .line 579
    .line 580
    move-result v0

    .line 581
    if-nez v0, :cond_13

    .line 582
    .line 583
    move v4, v5

    .line 584
    goto :goto_7

    .line 585
    :catchall_0
    move-exception v0

    .line 586
    goto :goto_8

    .line 587
    :cond_13
    :goto_7
    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 588
    if-eqz v4, :cond_17

    .line 589
    .line 590
    invoke-virtual {v3}, LPa/n0;->e()V

    .line 591
    .line 592
    .line 593
    goto :goto_b

    .line 594
    :goto_8
    :try_start_2
    monitor-exit v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 595
    throw v0

    .line 596
    :cond_14
    move v7, v4

    .line 597
    :goto_9
    :try_start_3
    sget-object v8, LPa/n0;->n:Ljava/lang/Object;

    .line 598
    .line 599
    monitor-enter v8
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 600
    :try_start_4
    sget-object v0, LPa/n0;->m:Ljava/util/ArrayDeque;

    .line 601
    .line 602
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    .line 603
    .line 604
    .line 605
    move-result-object v9

    .line 606
    check-cast v9, LPa/m0;

    .line 607
    .line 608
    monitor-exit v8
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 609
    if-nez v9, :cond_18

    .line 610
    .line 611
    sget-object v6, LPa/n0;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 612
    .line 613
    invoke-virtual {v6, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 614
    .line 615
    .line 616
    monitor-enter v8

    .line 617
    :try_start_5
    sget-boolean v6, LPa/n0;->l:Z

    .line 618
    .line 619
    if-eqz v6, :cond_15

    .line 620
    .line 621
    sget-object v6, LPa/n0;->i:LZ4/c;

    .line 622
    .line 623
    if-eqz v6, :cond_15

    .line 624
    .line 625
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 626
    .line 627
    .line 628
    move-result v0

    .line 629
    if-nez v0, :cond_15

    .line 630
    .line 631
    move v4, v5

    .line 632
    goto :goto_a

    .line 633
    :catchall_1
    move-exception v0

    .line 634
    goto :goto_c

    .line 635
    :cond_15
    :goto_a
    monitor-exit v8
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 636
    if-eqz v4, :cond_16

    .line 637
    .line 638
    invoke-virtual {v3}, LPa/n0;->e()V

    .line 639
    .line 640
    .line 641
    :cond_16
    if-lez v7, :cond_17

    .line 642
    .line 643
    const-string v0, "StatisticsUtil"

    .line 644
    .line 645
    const-string v3, "flushPendingGioEventsAsync flushed="

    .line 646
    .line 647
    invoke-static {v7, v3}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 648
    .line 649
    .line 650
    move-result-object v3

    .line 651
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 652
    .line 653
    .line 654
    move-result-object v3

    .line 655
    invoke-static {v0, v2, v3}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 656
    .line 657
    .line 658
    :cond_17
    :goto_b
    return-void

    .line 659
    :goto_c
    :try_start_6
    monitor-exit v8
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 660
    throw v0

    .line 661
    :cond_18
    :try_start_7
    iget-object v0, v9, LPa/m0;->a:Ljava/lang/String;

    .line 662
    .line 663
    iget-object v8, v9, LPa/m0;->b:Ljava/util/HashMap;

    .line 664
    .line 665
    invoke-virtual {v6, v0, v8}, Lcom/growingio/android/sdk/c;->c(Ljava/lang/String;Ljava/util/HashMap;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 666
    .line 667
    .line 668
    add-int/2addr v7, v5

    .line 669
    goto :goto_9

    .line 670
    :catchall_2
    move-exception v0

    .line 671
    goto :goto_d

    .line 672
    :catch_0
    move-exception v0

    .line 673
    :try_start_8
    const-string v8, "StatisticsUtil"

    .line 674
    .line 675
    new-instance v10, Ljava/lang/StringBuilder;

    .line 676
    .line 677
    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    .line 678
    .line 679
    .line 680
    const-string v11, "flushPendingGioEvent failed: "

    .line 681
    .line 682
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 683
    .line 684
    .line 685
    iget-object v9, v9, LPa/m0;->a:Ljava/lang/String;

    .line 686
    .line 687
    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 688
    .line 689
    .line 690
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 691
    .line 692
    .line 693
    move-result-object v9

    .line 694
    filled-new-array {v9, v0}, [Ljava/lang/Object;

    .line 695
    .line 696
    .line 697
    move-result-object v0

    .line 698
    invoke-static {v8, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 699
    .line 700
    .line 701
    goto :goto_9

    .line 702
    :catchall_3
    move-exception v0

    .line 703
    :try_start_9
    monitor-exit v8
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .line 704
    :try_start_a
    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .line 705
    :catchall_4
    move-exception v0

    .line 706
    move v7, v4

    .line 707
    :goto_d
    sget-object v6, LPa/n0;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 708
    .line 709
    invoke-virtual {v6, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 710
    .line 711
    .line 712
    sget-object v6, LPa/n0;->n:Ljava/lang/Object;

    .line 713
    .line 714
    monitor-enter v6

    .line 715
    :try_start_b
    sget-boolean v8, LPa/n0;->l:Z

    .line 716
    .line 717
    if-eqz v8, :cond_19

    .line 718
    .line 719
    sget-object v8, LPa/n0;->i:LZ4/c;

    .line 720
    .line 721
    if-eqz v8, :cond_19

    .line 722
    .line 723
    sget-object v8, LPa/n0;->m:Ljava/util/ArrayDeque;

    .line 724
    .line 725
    invoke-virtual {v8}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 726
    .line 727
    .line 728
    move-result v8

    .line 729
    if-nez v8, :cond_19

    .line 730
    .line 731
    move v4, v5

    .line 732
    goto :goto_e

    .line 733
    :catchall_5
    move-exception v0

    .line 734
    goto :goto_f

    .line 735
    :cond_19
    :goto_e
    monitor-exit v6
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 736
    if-eqz v4, :cond_1a

    .line 737
    .line 738
    invoke-virtual {v3}, LPa/n0;->e()V

    .line 739
    .line 740
    .line 741
    :cond_1a
    if-lez v7, :cond_1b

    .line 742
    .line 743
    const-string v3, "StatisticsUtil"

    .line 744
    .line 745
    const-string v4, "flushPendingGioEventsAsync flushed="

    .line 746
    .line 747
    invoke-static {v7, v4}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 748
    .line 749
    .line 750
    move-result-object v4

    .line 751
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 752
    .line 753
    .line 754
    move-result-object v4

    .line 755
    invoke-static {v3, v2, v4}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 756
    .line 757
    .line 758
    :cond_1b
    throw v0

    .line 759
    :goto_f
    :try_start_c
    monitor-exit v6
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_5

    .line 760
    throw v0

    .line 761
    :pswitch_14
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 762
    .line 763
    check-cast v0, LPa/o;

    .line 764
    .line 765
    const-string v2, "crash_sp_history"

    .line 766
    .line 767
    invoke-static {v2}, Le1/a;->H(Ljava/lang/String;)Ljava/lang/String;

    .line 768
    .line 769
    .line 770
    move-result-object v2

    .line 771
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 772
    .line 773
    .line 774
    move-result v3

    .line 775
    if-eqz v3, :cond_1c

    .line 776
    .line 777
    new-instance v2, LPa/m;

    .line 778
    .line 779
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 780
    .line 781
    .line 782
    iput-object v2, v0, LPa/o;->c:LPa/m;

    .line 783
    .line 784
    goto :goto_10

    .line 785
    :cond_1c
    const-class v3, LPa/m;

    .line 786
    .line 787
    invoke-static {v3, v2}, Lcom/horcrux/svg/d0;->l(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    .line 788
    .line 789
    .line 790
    move-result-object v2

    .line 791
    check-cast v2, LPa/m;

    .line 792
    .line 793
    iput-object v2, v0, LPa/o;->c:LPa/m;

    .line 794
    .line 795
    :goto_10
    return-void

    .line 796
    :pswitch_15
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;->X:Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment$a;

    .line 797
    .line 798
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 799
    .line 800
    check-cast v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;

    .line 801
    .line 802
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->dismiss()V

    .line 803
    .line 804
    .line 805
    sget-object v2, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxTermsConditionsDialogFragment;->Q:Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxTermsConditionsDialogFragment$a;

    .line 806
    .line 807
    iget-object v3, v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;->M:Lxf/t;

    .line 808
    .line 809
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 810
    .line 811
    .line 812
    move-result-object v3

    .line 813
    check-cast v3, Ljava/util/ArrayList;

    .line 814
    .line 815
    iget-object v4, v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;->Q:Lcom/transsnet/palmpay/managemoney/bean/PayoutOption;

    .line 816
    .line 817
    invoke-virtual {v2, v3, v4}, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxTermsConditionsDialogFragment$a;->newInstance(Ljava/util/ArrayList;Lcom/transsnet/palmpay/managemoney/bean/PayoutOption;)Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxTermsConditionsDialogFragment;

    .line 818
    .line 819
    .line 820
    move-result-object v2

    .line 821
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireParentFragment()Landroidx/fragment/app/Fragment;

    .line 822
    .line 823
    .line 824
    move-result-object v0

    .line 825
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/Z;

    .line 826
    .line 827
    .line 828
    move-result-object v0

    .line 829
    const-string v3, "getChildFragmentManager(...)"

    .line 830
    .line 831
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 832
    .line 833
    .line 834
    const-string v3, "showCashBoxTermsConditionsDialog"

    .line 835
    .line 836
    invoke-virtual {v2, v0, v3}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 837
    .line 838
    .line 839
    return-void

    .line 840
    :pswitch_16
    iget-object v2, v1, LM7/s;->b:Ljava/lang/Object;

    .line 841
    .line 842
    check-cast v2, Lcom/transsnet/palmpay/account/ui/activity/SignUpSuccessActivity;

    .line 843
    .line 844
    iget-object v4, v2, Lcom/transsnet/palmpay/account/ui/activity/SignUpSuccessActivity;->e:LBc/B;

    .line 845
    .line 846
    if-eqz v4, :cond_1d

    .line 847
    .line 848
    iget-object v5, v4, LBc/B;->B:Landroid/view/View;

    .line 849
    .line 850
    check-cast v5, Lcom/palmpay/lib/ui/button/PpButton;

    .line 851
    .line 852
    goto :goto_11

    .line 853
    :cond_1d
    move-object v5, v3

    .line 854
    :goto_11
    if-eqz v5, :cond_20

    .line 855
    .line 856
    if-eqz v4, :cond_1e

    .line 857
    .line 858
    iget-object v4, v4, LBc/B;->B:Landroid/view/View;

    .line 859
    .line 860
    check-cast v4, Lcom/palmpay/lib/ui/button/PpButton;

    .line 861
    .line 862
    if-eqz v4, :cond_1e

    .line 863
    .line 864
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 865
    .line 866
    .line 867
    move-result-object v3

    .line 868
    :cond_1e
    invoke-static {v3}, LPa/i0;->X(Landroid/content/Context;)Z

    .line 869
    .line 870
    .line 871
    move-result v3

    .line 872
    if-nez v3, :cond_1f

    .line 873
    .line 874
    goto :goto_12

    .line 875
    :cond_1f
    sget v3, Lba/a;->core_anim_scale:I

    .line 876
    .line 877
    invoke-static {v2, v3}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    .line 878
    .line 879
    .line 880
    move-result-object v3

    .line 881
    const/4 v4, -0x1

    .line 882
    invoke-virtual {v3, v4}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    .line 883
    .line 884
    .line 885
    invoke-virtual {v3, v0}, Landroid/view/animation/Animation;->setRepeatMode(I)V

    .line 886
    .line 887
    .line 888
    const-wide/16 v4, 0xc8

    .line 889
    .line 890
    invoke-virtual {v3, v4, v5}, Landroid/view/animation/Animation;->setStartOffset(J)V

    .line 891
    .line 892
    .line 893
    iget-object v0, v2, Lcom/transsnet/palmpay/account/ui/activity/SignUpSuccessActivity;->e:LBc/B;

    .line 894
    .line 895
    if-eqz v0, :cond_20

    .line 896
    .line 897
    iget-object v0, v0, LBc/B;->B:Landroid/view/View;

    .line 898
    .line 899
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 900
    .line 901
    if-eqz v0, :cond_20

    .line 902
    .line 903
    invoke-virtual {v0, v3}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 904
    .line 905
    .line 906
    :cond_20
    :goto_12
    return-void

    .line 907
    :pswitch_17
    iget-object v2, v1, LM7/s;->b:Ljava/lang/Object;

    .line 908
    .line 909
    check-cast v2, Lcom/transsnet/palmpay/account/ui/activity/SignUpActivity;

    .line 910
    .line 911
    sget-object v4, Lcom/transsnet/palmpay/account/ui/activity/SignUpActivity;->C:Lcom/transsnet/palmpay/account/ui/activity/SignUpActivity$a;

    .line 912
    .line 913
    :try_start_d
    const-string v4, "firebase_sp_appsflyer_campaign"

    .line 914
    .line 915
    invoke-static {v4}, Le1/a;->H(Ljava/lang/String;)Ljava/lang/String;

    .line 916
    .line 917
    .line 918
    move-result-object v4

    .line 919
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 920
    .line 921
    .line 922
    move-result v5

    .line 923
    if-nez v5, :cond_21

    .line 924
    .line 925
    goto :goto_13

    .line 926
    :cond_21
    move-object v4, v3

    .line 927
    :goto_13
    if-eqz v4, :cond_22

    .line 928
    .line 929
    invoke-static {}, LG8/a;->t()Lcom/transsnet/palmpay/account/business/IApiAccountService;

    .line 930
    .line 931
    .line 932
    move-result-object v5

    .line 933
    invoke-interface {v5, v4}, Lcom/transsnet/palmpay/account/business/IApiAccountService;->getPopupDialogConfigV2(Ljava/lang/String;)Ldf/d;

    .line 934
    .line 935
    .line 936
    move-result-object v4

    .line 937
    invoke-virtual {v4}, Ldf/d;->b()Ljava/lang/Object;

    .line 938
    .line 939
    .line 940
    move-result-object v4

    .line 941
    check-cast v4, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 942
    .line 943
    invoke-virtual {v4}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 944
    .line 945
    .line 946
    move-result v5

    .line 947
    if-eqz v5, :cond_22

    .line 948
    .line 949
    invoke-static {v2}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 950
    .line 951
    .line 952
    move-result-object v5

    .line 953
    sget-object v6, LWf/I;->a:Lcg/f;

    .line 954
    .line 955
    sget-object v6, Lag/o;->a:LWf/p0;

    .line 956
    .line 957
    new-instance v7, LN8/e0;

    .line 958
    .line 959
    invoke-direct {v7, v2, v4, v3}, LN8/e0;-><init>(Lcom/transsnet/palmpay/account/ui/activity/SignUpActivity;Lcom/transsnet/palmpay/core/bean/CommonBeanResult;Lkotlin/coroutines/Continuation;)V

    .line 960
    .line 961
    .line 962
    invoke-static {v5, v6, v3, v7, v0}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_1

    .line 963
    .line 964
    .line 965
    :catch_1
    :cond_22
    return-void

    .line 966
    :pswitch_18
    sget v6, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdV2Activity;->g:I

    .line 967
    .line 968
    iget-object v6, v1, LM7/s;->b:Ljava/lang/Object;

    .line 969
    .line 970
    move-object v7, v6

    .line 971
    check-cast v7, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdV2Activity;

    .line 972
    .line 973
    invoke-static {v7}, Lcom/transsnet/palmpay/util/ActivityUtils;->isValidActivityContext(Landroid/app/Activity;)Z

    .line 974
    .line 975
    .line 976
    move-result v6

    .line 977
    if-nez v6, :cond_23

    .line 978
    .line 979
    goto/16 :goto_15

    .line 980
    .line 981
    :cond_23
    new-instance v6, Lid/a;

    .line 982
    .line 983
    invoke-direct {v6, v7}, Lid/a;-><init>(Landroid/content/Context;)V

    .line 984
    .line 985
    .line 986
    invoke-virtual {v6}, Lid/a;->W()Z

    .line 987
    .line 988
    .line 989
    move-result v6

    .line 990
    if-eqz v6, :cond_25

    .line 991
    .line 992
    iget-object v0, v7, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 993
    .line 994
    const-string v5, "startAuthentication: "

    .line 995
    .line 996
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 997
    .line 998
    .line 999
    move-result-object v5

    .line 1000
    invoke-static {v0, v2, v5}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1001
    .line 1002
    .line 1003
    iget-object v0, v7, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdV2Activity;->c:Landroidx/biometric/v;

    .line 1004
    .line 1005
    if-eqz v0, :cond_27

    .line 1006
    .line 1007
    :try_start_e
    iget-boolean v5, v7, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdV2Activity;->a:Z

    .line 1008
    .line 1009
    if-eqz v5, :cond_24

    .line 1010
    .line 1011
    iget-object v3, v7, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdV2Activity;->d:Landroidx/biometric/w;

    .line 1012
    .line 1013
    if-eqz v3, :cond_27

    .line 1014
    .line 1015
    new-instance v5, Landroidx/biometric/u;

    .line 1016
    .line 1017
    const-string v6, "login_keystore_alias"

    .line 1018
    .line 1019
    invoke-static {v6, v4}, Ljd/a;->d(Ljava/lang/String;Z)Ljavax/crypto/Cipher;

    .line 1020
    .line 1021
    .line 1022
    move-result-object v4

    .line 1023
    invoke-direct {v5, v4}, Landroidx/biometric/u;-><init>(Ljavax/crypto/Cipher;)V

    .line 1024
    .line 1025
    .line 1026
    invoke-virtual {v3, v0, v5}, Landroidx/biometric/w;->a(Landroidx/biometric/v;Landroidx/biometric/u;)V

    .line 1027
    .line 1028
    .line 1029
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1030
    .line 1031
    goto :goto_15

    .line 1032
    :catch_2
    move-exception v0

    .line 1033
    goto :goto_14

    .line 1034
    :cond_24
    iget-object v4, v7, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdV2Activity;->d:Landroidx/biometric/w;

    .line 1035
    .line 1036
    if-eqz v4, :cond_27

    .line 1037
    .line 1038
    invoke-virtual {v4, v0, v3}, Landroidx/biometric/w;->b(Landroidx/biometric/v;Landroidx/biometric/u;)V

    .line 1039
    .line 1040
    .line 1041
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_2

    .line 1042
    .line 1043
    goto :goto_15

    .line 1044
    :goto_14
    iget-object v3, v7, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 1045
    .line 1046
    new-instance v4, Ljava/lang/StringBuilder;

    .line 1047
    .line 1048
    const-string v5, "initData: "

    .line 1049
    .line 1050
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1051
    .line 1052
    .line 1053
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1054
    .line 1055
    .line 1056
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1057
    .line 1058
    .line 1059
    move-result-object v0

    .line 1060
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 1061
    .line 1062
    .line 1063
    move-result-object v0

    .line 1064
    invoke-static {v3, v2, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1065
    .line 1066
    .line 1067
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1068
    .line 1069
    goto :goto_15

    .line 1070
    :cond_25
    invoke-static {v7}, Lcom/transsnet/palmpay/util/ActivityUtils;->isValidActivityContext(Landroid/app/Activity;)Z

    .line 1071
    .line 1072
    .line 1073
    move-result v2

    .line 1074
    if-nez v2, :cond_26

    .line 1075
    .line 1076
    goto :goto_15

    .line 1077
    :cond_26
    sget v2, Lba/k;->core_title_attention:I

    .line 1078
    .line 1079
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1080
    .line 1081
    .line 1082
    move-result-object v9

    .line 1083
    sget v2, LF8/h;->ac_msg_enroll_finger_print:I

    .line 1084
    .line 1085
    invoke-virtual {v7, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1086
    .line 1087
    .line 1088
    move-result-object v14

    .line 1089
    sget v2, Lba/k;->core_confirm:I

    .line 1090
    .line 1091
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1092
    .line 1093
    .line 1094
    move-result-object v15

    .line 1095
    new-instance v2, LN8/X;

    .line 1096
    .line 1097
    invoke-direct {v2, v7, v5}, LN8/X;-><init>(Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdV2Activity;I)V

    .line 1098
    .line 1099
    .line 1100
    new-instance v3, LN8/X;

    .line 1101
    .line 1102
    invoke-direct {v3, v7, v0}, LN8/X;-><init>(Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdV2Activity;I)V

    .line 1103
    .line 1104
    .line 1105
    const/16 v23, 0x0

    .line 1106
    .line 1107
    const v24, 0x7f7a7d

    .line 1108
    .line 1109
    .line 1110
    const/4 v8, 0x0

    .line 1111
    const/4 v10, 0x0

    .line 1112
    const/4 v11, 0x0

    .line 1113
    const/4 v12, 0x0

    .line 1114
    const/4 v13, 0x0

    .line 1115
    const/16 v16, 0x0

    .line 1116
    .line 1117
    const/16 v18, 0x0

    .line 1118
    .line 1119
    const/16 v19, 0x0

    .line 1120
    .line 1121
    const/16 v20, 0x0

    .line 1122
    .line 1123
    const/16 v22, 0x0

    .line 1124
    .line 1125
    move-object/from16 v17, v2

    .line 1126
    .line 1127
    move-object/from16 v21, v3

    .line 1128
    .line 1129
    invoke-static/range {v7 .. v24}, Lio/fastkv/n;->O(Landroid/content/Context;ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;Lcom/mikepenz/iconics/IconicsDrawable;Landroid/graphics/drawable/Drawable;Ljava/lang/CharSequence;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;ZII)LO6/d;

    .line 1130
    .line 1131
    .line 1132
    :cond_27
    :goto_15
    return-void

    .line 1133
    :pswitch_19
    sget v0, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;->o:I

    .line 1134
    .line 1135
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 1136
    .line 1137
    check-cast v0, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;

    .line 1138
    .line 1139
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    .line 1140
    .line 1141
    .line 1142
    move-result v2

    .line 1143
    if-nez v2, :cond_2c

    .line 1144
    .line 1145
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->isDestroyed()Z

    .line 1146
    .line 1147
    .line 1148
    move-result v2

    .line 1149
    if-eqz v2, :cond_28

    .line 1150
    .line 1151
    goto :goto_16

    .line 1152
    :cond_28
    iget-object v2, v0, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;->a:Lid/a;

    .line 1153
    .line 1154
    invoke-virtual {v2}, Lid/a;->W()Z

    .line 1155
    .line 1156
    .line 1157
    move-result v2

    .line 1158
    if-eqz v2, :cond_29

    .line 1159
    .line 1160
    invoke-virtual {v0}, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;->l()V

    .line 1161
    .line 1162
    .line 1163
    iget-object v2, v0, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;->a:Lid/a;

    .line 1164
    .line 1165
    invoke-virtual {v2, v0}, Lid/a;->X(Lcom/transsnet/palmpay/security/utils/FingerPrintHelper$AuthenticationCallback;)V

    .line 1166
    .line 1167
    .line 1168
    goto :goto_16

    .line 1169
    :cond_29
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    .line 1170
    .line 1171
    .line 1172
    move-result v2

    .line 1173
    if-nez v2, :cond_2c

    .line 1174
    .line 1175
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->isDestroyed()Z

    .line 1176
    .line 1177
    .line 1178
    move-result v2

    .line 1179
    if-eqz v2, :cond_2a

    .line 1180
    .line 1181
    goto :goto_16

    .line 1182
    :cond_2a
    iget-object v2, v0, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;->g:LO6/d;

    .line 1183
    .line 1184
    if-eqz v2, :cond_2b

    .line 1185
    .line 1186
    invoke-virtual {v2}, Landroid/app/Dialog;->isShowing()Z

    .line 1187
    .line 1188
    .line 1189
    move-result v2

    .line 1190
    if-eqz v2, :cond_2b

    .line 1191
    .line 1192
    goto :goto_16

    .line 1193
    :cond_2b
    new-instance v2, LO6/c;

    .line 1194
    .line 1195
    invoke-direct {v2, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 1196
    .line 1197
    .line 1198
    sget v3, Lba/k;->core_title_attention:I

    .line 1199
    .line 1200
    invoke-virtual {v2, v3}, LO6/c;->e(I)V

    .line 1201
    .line 1202
    .line 1203
    sget v3, LF8/h;->ac_msg_enroll_finger_print:I

    .line 1204
    .line 1205
    invoke-virtual {v2, v3}, LO6/c;->b(I)V

    .line 1206
    .line 1207
    .line 1208
    sget v3, Lba/k;->core_confirm:I

    .line 1209
    .line 1210
    new-instance v6, LN8/V;

    .line 1211
    .line 1212
    invoke-direct {v6, v0, v5}, LN8/V;-><init>(Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;I)V

    .line 1213
    .line 1214
    .line 1215
    invoke-virtual {v2, v3, v6}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 1216
    .line 1217
    .line 1218
    new-instance v3, LN8/V;

    .line 1219
    .line 1220
    invoke-direct {v3, v0, v4}, LN8/V;-><init>(Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;I)V

    .line 1221
    .line 1222
    .line 1223
    iput-object v3, v2, LO6/c;->j:Landroid/view/View$OnClickListener;

    .line 1224
    .line 1225
    invoke-virtual {v2}, LO6/c;->a()LO6/d;

    .line 1226
    .line 1227
    .line 1228
    move-result-object v2

    .line 1229
    iput-object v2, v0, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;->g:LO6/d;

    .line 1230
    .line 1231
    new-instance v3, LN8/W;

    .line 1232
    .line 1233
    invoke-direct {v3, v0}, LN8/W;-><init>(Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;)V

    .line 1234
    .line 1235
    .line 1236
    invoke-virtual {v2, v3}, LO6/f;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V

    .line 1237
    .line 1238
    .line 1239
    iget-object v2, v0, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;->g:LO6/d;

    .line 1240
    .line 1241
    new-instance v3, LN8/U;

    .line 1242
    .line 1243
    invoke-direct {v3, v0, v5}, LN8/U;-><init>(Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;I)V

    .line 1244
    .line 1245
    .line 1246
    invoke-virtual {v2, v3}, LO6/f;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 1247
    .line 1248
    .line 1249
    iget-object v0, v0, Lcom/transsnet/palmpay/account/ui/activity/SetTouchIdActivity;->g:LO6/d;

    .line 1250
    .line 1251
    invoke-virtual {v0}, LO6/d;->show()V

    .line 1252
    .line 1253
    .line 1254
    :cond_2c
    :goto_16
    return-void

    .line 1255
    :pswitch_1a
    sget v0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->p0:I

    .line 1256
    .line 1257
    sget v0, LF8/h;->ac_secure_login_reminder:I

    .line 1258
    .line 1259
    iget-object v2, v1, LM7/s;->b:Ljava/lang/Object;

    .line 1260
    .line 1261
    move-object v6, v2

    .line 1262
    check-cast v6, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;

    .line 1263
    .line 1264
    invoke-virtual {v6, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1265
    .line 1266
    .line 1267
    move-result-object v9

    .line 1268
    sget v0, LF8/c;->ac_icon_secure_login:I

    .line 1269
    .line 1270
    iget-object v13, v6, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->w:Ljava/lang/String;

    .line 1271
    .line 1272
    new-instance v2, LN8/k;

    .line 1273
    .line 1274
    invoke-direct {v2, v6, v5}, LN8/k;-><init>(Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;I)V

    .line 1275
    .line 1276
    .line 1277
    sget v3, LF8/h;->ac_change_pin_2:I

    .line 1278
    .line 1279
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1280
    .line 1281
    .line 1282
    move-result-object v10

    .line 1283
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1284
    .line 1285
    .line 1286
    move-result-object v17

    .line 1287
    const/16 v21, 0x0

    .line 1288
    .line 1289
    const/16 v22, 0x0

    .line 1290
    .line 1291
    const/4 v7, 0x0

    .line 1292
    const/4 v8, 0x0

    .line 1293
    const/4 v11, 0x0

    .line 1294
    const/4 v12, 0x0

    .line 1295
    const/4 v14, 0x0

    .line 1296
    const-string v15, "Re-Login"

    .line 1297
    .line 1298
    const/16 v16, 0x0

    .line 1299
    .line 1300
    const/16 v18, 0x0

    .line 1301
    .line 1302
    const/16 v20, 0x0

    .line 1303
    .line 1304
    const v23, 0x7fd573

    .line 1305
    .line 1306
    .line 1307
    move-object/from16 v19, v2

    .line 1308
    .line 1309
    invoke-static/range {v6 .. v23}, Lio/fastkv/n;->O(Landroid/content/Context;ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;Lcom/mikepenz/iconics/IconicsDrawable;Landroid/graphics/drawable/Drawable;Ljava/lang/CharSequence;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;ZII)LO6/d;

    .line 1310
    .line 1311
    .line 1312
    return-void

    .line 1313
    :pswitch_1b
    sget-object v0, Lcom/swmansion/rnscreens/ScreenStack;->L:Lcom/swmansion/rnscreens/ScreenStack$a;

    .line 1314
    .line 1315
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 1316
    .line 1317
    check-cast v0, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;

    .line 1318
    .line 1319
    if-eqz v0, :cond_2d

    .line 1320
    .line 1321
    invoke-interface {v0}, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;->getScreen()Lcom/swmansion/rnscreens/Screen;

    .line 1322
    .line 1323
    .line 1324
    move-result-object v0

    .line 1325
    if-eqz v0, :cond_2d

    .line 1326
    .line 1327
    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    .line 1328
    .line 1329
    .line 1330
    :cond_2d
    return-void

    .line 1331
    :pswitch_1c
    sget v0, Lcom/swmansion/rnscreens/ScreenContainer;->i:I

    .line 1332
    .line 1333
    iget-object v0, v1, LM7/s;->b:Ljava/lang/Object;

    .line 1334
    .line 1335
    check-cast v0, Lcom/swmansion/rnscreens/ScreenContainer;

    .line 1336
    .line 1337
    invoke-virtual {v0}, Lcom/swmansion/rnscreens/ScreenContainer;->g()V

    .line 1338
    .line 1339
    .line 1340
    return-void

    .line 1341
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
