.class public final synthetic LM7/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lkotlin/jvm/internal/F;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/internal/F;I)V
    .locals 0

    .line 1
    iput p2, p0, LM7/x;->a:I

    iput-object p1, p0, LM7/x;->b:Lkotlin/jvm/internal/F;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    iget-object v2, p0, LM7/x;->b:Lkotlin/jvm/internal/F;

    .line 4
    .line 5
    const-string v3, "it"

    .line 6
    .line 7
    iget v4, p0, LM7/x;->a:I

    .line 8
    .line 9
    packed-switch v4, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast p1, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;

    .line 13
    .line 14
    sget-object v4, Lcom/swmansion/rnscreens/ScreenStack;->L:Lcom/swmansion/rnscreens/ScreenStack$a;

    .line 15
    .line 16
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object v2, v2, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 20
    .line 21
    if-eq p1, v2, :cond_0

    .line 22
    .line 23
    move v0, v1

    .line 24
    :cond_0
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    return-object p1

    .line 29
    :pswitch_0
    check-cast p1, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;

    .line 30
    .line 31
    sget-object v4, Lcom/swmansion/rnscreens/ScreenStack;->L:Lcom/swmansion/rnscreens/ScreenStack$a;

    .line 32
    .line 33
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    iget-object v2, v2, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 37
    .line 38
    if-eq p1, v2, :cond_1

    .line 39
    .line 40
    move v0, v1

    .line 41
    :cond_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    return-object p1

    .line 46
    :pswitch_1
    check-cast p1, Lcom/swmansion/rnscreens/ScreenStackFragmentWrapper;

    .line 47
    .line 48
    sget-object v4, Lcom/swmansion/rnscreens/ScreenStack;->L:Lcom/swmansion/rnscreens/ScreenStack$a;

    .line 49
    .line 50
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    iget-object v2, v2, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 54
    .line 55
    if-eq p1, v2, :cond_2

    .line 56
    .line 57
    invoke-interface {p1}, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;->isTranslucent()Z

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    if-eqz p1, :cond_2

    .line 62
    .line 63
    move v0, v1

    .line 64
    :cond_2
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    return-object p1

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
