.class public final LM7/t;
.super Lcom/google/android/material/bottomsheet/BottomSheetBehavior$BottomSheetCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/swmansion/rnscreens/ScreenFooter;


# direct methods
.method public constructor <init>(Lcom/swmansion/rnscreens/ScreenFooter;)V
    .locals 0

    .line 1
    iput-object p1, p0, LM7/t;->a:Lcom/swmansion/rnscreens/ScreenFooter;

    .line 2
    .line 3
    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$BottomSheetCallback;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSlide(Landroid/view/View;F)V
    .locals 3

    .line 1
    const-string v0, "bottomSheet"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    invoke-static {p2, p1}, Ljava/lang/Math;->max(FF)F

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    iget-object p2, p0, LM7/t;->a:Lcom/swmansion/rnscreens/ScreenFooter;

    .line 12
    .line 13
    iput p1, p2, Lcom/swmansion/rnscreens/ScreenFooter;->d:F

    .line 14
    .line 15
    iget-boolean p1, p2, Lcom/swmansion/rnscreens/ScreenFooter;->c:Z

    .line 16
    .line 17
    if-nez p1, :cond_0

    .line 18
    .line 19
    iget p1, p2, Lcom/swmansion/rnscreens/ScreenFooter;->b:I

    .line 20
    .line 21
    invoke-static {p2}, Lcom/swmansion/rnscreens/ScreenFooter;->b(Lcom/swmansion/rnscreens/ScreenFooter;)I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    iget v1, p2, Lcom/swmansion/rnscreens/ScreenFooter;->d:F

    .line 26
    .line 27
    invoke-static {p2, v1}, Lcom/swmansion/rnscreens/ScreenFooter;->c(Lcom/swmansion/rnscreens/ScreenFooter;F)I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    iget v2, p2, Lcom/swmansion/rnscreens/ScreenFooter;->e:I

    .line 32
    .line 33
    invoke-virtual {p2, p1, v0, v1, v2}, Lcom/swmansion/rnscreens/ScreenFooter;->d(IIII)V

    .line 34
    .line 35
    .line 36
    :cond_0
    return-void
.end method

.method public final onStateChanged(Landroid/view/View;I)V
    .locals 3

    .line 1
    const-string v0, "bottomSheet"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x6

    .line 7
    const/4 v0, 0x4

    .line 8
    const/4 v1, 0x3

    .line 9
    if-eq p2, v1, :cond_0

    .line 10
    .line 11
    if-eq p2, v0, :cond_0

    .line 12
    .line 13
    const/4 v2, 0x5

    .line 14
    if-eq p2, v2, :cond_0

    .line 15
    .line 16
    if-eq p2, p1, :cond_0

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v2, 0x1

    .line 21
    :goto_0
    if-nez v2, :cond_1

    .line 22
    .line 23
    return-void

    .line 24
    :cond_1
    iget-object v2, p0, LM7/t;->a:Lcom/swmansion/rnscreens/ScreenFooter;

    .line 25
    .line 26
    if-eq p2, v1, :cond_2

    .line 27
    .line 28
    if-eq p2, v0, :cond_2

    .line 29
    .line 30
    if-eq p2, p1, :cond_2

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_2
    iget p1, v2, Lcom/swmansion/rnscreens/ScreenFooter;->b:I

    .line 34
    .line 35
    invoke-static {v2}, Lcom/swmansion/rnscreens/ScreenFooter;->b(Lcom/swmansion/rnscreens/ScreenFooter;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-virtual {v2, p2}, Lcom/swmansion/rnscreens/ScreenFooter;->g(I)I

    .line 40
    .line 41
    .line 42
    move-result p2

    .line 43
    iget v1, v2, Lcom/swmansion/rnscreens/ScreenFooter;->e:I

    .line 44
    .line 45
    invoke-virtual {v2, p1, v0, p2, v1}, Lcom/swmansion/rnscreens/ScreenFooter;->d(IIII)V

    .line 46
    .line 47
    .line 48
    :goto_1
    sget p1, Lcom/swmansion/rnscreens/ScreenFooter;->i:I

    .line 49
    .line 50
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    return-void
.end method
