.class public final synthetic LM7/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/swmansion/rnscreens/ScreenStack;


# direct methods
.method public synthetic constructor <init>(Lcom/swmansion/rnscreens/ScreenStack;I)V
    .locals 0

    .line 1
    iput p2, p0, LM7/w;->a:I

    iput-object p1, p0, LM7/w;->b:Lcom/swmansion/rnscreens/ScreenStack;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    iget-object v2, p0, LM7/w;->b:Lcom/swmansion/rnscreens/ScreenStack;

    .line 4
    .line 5
    iget v3, p0, LM7/w;->a:I

    .line 6
    .line 7
    packed-switch v3, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast p1, Lcom/swmansion/rnscreens/ScreenStackFragmentWrapper;

    .line 11
    .line 12
    sget-object v3, Lcom/swmansion/rnscreens/ScreenStack;->L:Lcom/swmansion/rnscreens/ScreenStack$a;

    .line 13
    .line 14
    const-string v3, "wrapper"

    .line 15
    .line 16
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object v3, v2, Lcom/swmansion/rnscreens/ScreenContainer;->a:Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    if-eqz v3, :cond_1

    .line 26
    .line 27
    iget-object v2, v2, Lcom/swmansion/rnscreens/ScreenStack;->o:Ljava/util/HashSet;

    .line 28
    .line 29
    invoke-virtual {v2, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_0

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    move v0, v1

    .line 37
    :cond_1
    :goto_0
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    return-object p1

    .line 42
    :pswitch_0
    check-cast p1, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;

    .line 43
    .line 44
    sget-object v3, Lcom/swmansion/rnscreens/ScreenStack;->L:Lcom/swmansion/rnscreens/ScreenStack$a;

    .line 45
    .line 46
    const-string v3, "it"

    .line 47
    .line 48
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    iget-object v2, v2, Lcom/swmansion/rnscreens/ScreenStack;->o:Ljava/util/HashSet;

    .line 52
    .line 53
    invoke-static {v2, p1}, Lkotlin/collections/CollectionsKt;->A(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    if-nez v2, :cond_2

    .line 58
    .line 59
    invoke-interface {p1}, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;->getScreen()Lcom/swmansion/rnscreens/Screen;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-virtual {p1}, Lcom/swmansion/rnscreens/Screen;->getActivityState()LM7/n;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    sget-object v2, LM7/n;->a:LM7/n;

    .line 68
    .line 69
    if-eq p1, v2, :cond_2

    .line 70
    .line 71
    goto :goto_1

    .line 72
    :cond_2
    move v0, v1

    .line 73
    :goto_1
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    return-object p1

    .line 78
    nop

    .line 79
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
