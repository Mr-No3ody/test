.class public final LM7/u;
.super Landroidx/core/view/W;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/swmansion/rnscreens/ScreenFooter;


# direct methods
.method public constructor <init>(Lcom/swmansion/rnscreens/ScreenFooter;)V
    .locals 0

    .line 1
    iput-object p1, p0, LM7/u;->a:Lcom/swmansion/rnscreens/ScreenFooter;

    .line 2
    .line 3
    invoke-direct {p0}, Landroidx/core/view/W;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onEnd(Landroidx/core/view/d0;)V
    .locals 1

    .line 1
    const-string v0, "animation"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LM7/u;->a:Lcom/swmansion/rnscreens/ScreenFooter;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-boolean v0, p1, Lcom/swmansion/rnscreens/ScreenFooter;->c:Z

    .line 10
    .line 11
    return-void
.end method

.method public final onProgress(Landroidx/core/view/q0;Ljava/util/List;)Landroidx/core/view/q0;
    .locals 4

    .line 1
    const-string v0, "insets"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "runningAnimations"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p2, p1, Landroidx/core/view/q0;->a:Landroidx/core/view/o0;

    .line 12
    .line 13
    const/16 v0, 0x8

    .line 14
    .line 15
    invoke-virtual {p2, v0}, Landroidx/core/view/o0;->g(I)Landroidx/core/graphics/e;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    iget p2, p2, Landroidx/core/graphics/e;->d:I

    .line 20
    .line 21
    iget-object v0, p1, Landroidx/core/view/q0;->a:Landroidx/core/view/o0;

    .line 22
    .line 23
    const/4 v1, 0x2

    .line 24
    invoke-virtual {v0, v1}, Landroidx/core/view/o0;->g(I)Landroidx/core/graphics/e;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iget v0, v0, Landroidx/core/graphics/e;->d:I

    .line 29
    .line 30
    sub-int/2addr p2, v0

    .line 31
    iget-object v0, p0, LM7/u;->a:Lcom/swmansion/rnscreens/ScreenFooter;

    .line 32
    .line 33
    iput p2, v0, Lcom/swmansion/rnscreens/ScreenFooter;->e:I

    .line 34
    .line 35
    iget p2, v0, Lcom/swmansion/rnscreens/ScreenFooter;->b:I

    .line 36
    .line 37
    invoke-static {v0}, Lcom/swmansion/rnscreens/ScreenFooter;->b(Lcom/swmansion/rnscreens/ScreenFooter;)I

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    iget v2, v0, Lcom/swmansion/rnscreens/ScreenFooter;->d:F

    .line 42
    .line 43
    invoke-static {v0, v2}, Lcom/swmansion/rnscreens/ScreenFooter;->c(Lcom/swmansion/rnscreens/ScreenFooter;F)I

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    iget v3, v0, Lcom/swmansion/rnscreens/ScreenFooter;->e:I

    .line 48
    .line 49
    invoke-virtual {v0, p2, v1, v2, v3}, Lcom/swmansion/rnscreens/ScreenFooter;->d(IIII)V

    .line 50
    .line 51
    .line 52
    return-object p1
.end method

.method public final onStart(Landroidx/core/view/d0;Landroidx/core/view/V;)Landroidx/core/view/V;
    .locals 1

    .line 1
    const-string v0, "animation"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "bounds"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, LM7/u;->a:Lcom/swmansion/rnscreens/ScreenFooter;

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    iput-boolean v0, p1, Lcom/swmansion/rnscreens/ScreenFooter;->c:Z

    .line 15
    .line 16
    const-string p1, "onStart(...)"

    .line 17
    .line 18
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-object p2
.end method
