.class public final LM7/l;
.super Lcom/facebook/react/BaseReactPackage;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LM7/k;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LM7/k;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final createViewManagers(Lcom/facebook/react/bridge/ReactApplicationContext;)Ljava/util/List;
    .locals 16

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    const-string v1, "reactContext"

    .line 4
    .line 5
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    new-instance v2, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;

    .line 9
    .line 10
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    sget-object v1, Ld8/b;->c:Ld8/a;

    .line 17
    .line 18
    invoke-virtual {v1}, Ld8/a;->getEMPTY()Ld8/b;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    iput-object v1, v2, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;->f:Ld8/b;

    .line 23
    .line 24
    new-instance v1, Ljava/lang/ref/WeakReference;

    .line 25
    .line 26
    invoke-direct {v1, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iput-object v1, v2, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;->g:Ljava/lang/ref/WeakReference;

    .line 30
    .line 31
    :try_start_0
    const-string v1, "react_codegen_rnscreens"

    .line 32
    .line 33
    invoke-static {v1}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    .line 35
    .line 36
    :catch_0
    new-instance v1, Ljava/lang/ref/WeakReference;

    .line 37
    .line 38
    invoke-direct {v1, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    sput-object v1, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;->p:Ljava/lang/ref/WeakReference;

    .line 42
    .line 43
    invoke-virtual {v2, v0}, Lcom/swmansion/rnscreens/utils/ScreenDummyLayoutHelper;->b(Lcom/facebook/react/bridge/ReactApplicationContext;)Z

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0, v2}, Lcom/facebook/react/bridge/ReactContext;->addLifecycleEventListener(Lcom/facebook/react/bridge/LifecycleEventListener;)V

    .line 47
    .line 48
    .line 49
    sget-object v1, LM7/c;->a:LM7/c;

    .line 50
    .line 51
    const-string v2, "context"

    .line 52
    .line 53
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v0, v1}, Lcom/facebook/react/bridge/ReactContext;->addLifecycleEventListener(Lcom/facebook/react/bridge/LifecycleEventListener;)V

    .line 57
    .line 58
    .line 59
    new-instance v0, Lcom/swmansion/rnscreens/ScreenContainerViewManager;

    .line 60
    .line 61
    invoke-direct {v0}, Lcom/swmansion/rnscreens/ScreenContainerViewManager;-><init>()V

    .line 62
    .line 63
    .line 64
    new-instance v1, Lcom/swmansion/rnscreens/ScreenViewManager;

    .line 65
    .line 66
    invoke-direct {v1}, Lcom/swmansion/rnscreens/ScreenViewManager;-><init>()V

    .line 67
    .line 68
    .line 69
    new-instance v2, Lcom/swmansion/rnscreens/ModalScreenViewManager;

    .line 70
    .line 71
    invoke-direct {v2}, Lcom/swmansion/rnscreens/ModalScreenViewManager;-><init>()V

    .line 72
    .line 73
    .line 74
    new-instance v3, Lcom/swmansion/rnscreens/ScreenStackViewManager;

    .line 75
    .line 76
    invoke-direct {v3}, Lcom/swmansion/rnscreens/ScreenStackViewManager;-><init>()V

    .line 77
    .line 78
    .line 79
    new-instance v4, Lcom/swmansion/rnscreens/ScreenStackHeaderConfigViewManager;

    .line 80
    .line 81
    invoke-direct {v4}, Lcom/swmansion/rnscreens/ScreenStackHeaderConfigViewManager;-><init>()V

    .line 82
    .line 83
    .line 84
    new-instance v5, Lcom/swmansion/rnscreens/ScreenStackHeaderSubviewManager;

    .line 85
    .line 86
    invoke-direct {v5}, Lcom/swmansion/rnscreens/ScreenStackHeaderSubviewManager;-><init>()V

    .line 87
    .line 88
    .line 89
    new-instance v6, Lcom/swmansion/rnscreens/SearchBarManager;

    .line 90
    .line 91
    invoke-direct {v6}, Lcom/swmansion/rnscreens/SearchBarManager;-><init>()V

    .line 92
    .line 93
    .line 94
    new-instance v7, Lcom/swmansion/rnscreens/ScreenFooterManager;

    .line 95
    .line 96
    invoke-direct {v7}, Lcom/swmansion/rnscreens/ScreenFooterManager;-><init>()V

    .line 97
    .line 98
    .line 99
    new-instance v8, Lcom/swmansion/rnscreens/ScreenContentWrapperManager;

    .line 100
    .line 101
    invoke-direct {v8}, Lcom/swmansion/rnscreens/ScreenContentWrapperManager;-><init>()V

    .line 102
    .line 103
    .line 104
    new-instance v9, Lcom/swmansion/rnscreens/gamma/tabs/TabsHostViewManager;

    .line 105
    .line 106
    invoke-direct {v9}, Lcom/swmansion/rnscreens/gamma/tabs/TabsHostViewManager;-><init>()V

    .line 107
    .line 108
    .line 109
    new-instance v10, Lcom/swmansion/rnscreens/gamma/tabs/TabScreenViewManager;

    .line 110
    .line 111
    invoke-direct {v10}, Lcom/swmansion/rnscreens/gamma/tabs/TabScreenViewManager;-><init>()V

    .line 112
    .line 113
    .line 114
    new-instance v11, Lcom/swmansion/rnscreens/safearea/SafeAreaViewManager;

    .line 115
    .line 116
    invoke-direct {v11}, Lcom/swmansion/rnscreens/safearea/SafeAreaViewManager;-><init>()V

    .line 117
    .line 118
    .line 119
    new-instance v12, Lcom/swmansion/rnscreens/gamma/stack/host/StackHostViewManager;

    .line 120
    .line 121
    invoke-direct {v12}, Lcom/swmansion/rnscreens/gamma/stack/host/StackHostViewManager;-><init>()V

    .line 122
    .line 123
    .line 124
    new-instance v13, Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenViewManager;

    .line 125
    .line 126
    invoke-direct {v13}, Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenViewManager;-><init>()V

    .line 127
    .line 128
    .line 129
    const/16 v14, 0xe

    .line 130
    .line 131
    new-array v14, v14, [Lcom/facebook/react/uimanager/ViewManager;

    .line 132
    .line 133
    const/4 v15, 0x0

    .line 134
    aput-object v0, v14, v15

    .line 135
    .line 136
    const/4 v0, 0x1

    .line 137
    aput-object v1, v14, v0

    .line 138
    .line 139
    const/4 v0, 0x2

    .line 140
    aput-object v2, v14, v0

    .line 141
    .line 142
    const/4 v0, 0x3

    .line 143
    aput-object v3, v14, v0

    .line 144
    .line 145
    const/4 v0, 0x4

    .line 146
    aput-object v4, v14, v0

    .line 147
    .line 148
    const/4 v0, 0x5

    .line 149
    aput-object v5, v14, v0

    .line 150
    .line 151
    const/4 v0, 0x6

    .line 152
    aput-object v6, v14, v0

    .line 153
    .line 154
    const/4 v0, 0x7

    .line 155
    aput-object v7, v14, v0

    .line 156
    .line 157
    const/16 v0, 0x8

    .line 158
    .line 159
    aput-object v8, v14, v0

    .line 160
    .line 161
    const/16 v0, 0x9

    .line 162
    .line 163
    aput-object v9, v14, v0

    .line 164
    .line 165
    const/16 v0, 0xa

    .line 166
    .line 167
    aput-object v10, v14, v0

    .line 168
    .line 169
    const/16 v0, 0xb

    .line 170
    .line 171
    aput-object v11, v14, v0

    .line 172
    .line 173
    const/16 v0, 0xc

    .line 174
    .line 175
    aput-object v12, v14, v0

    .line 176
    .line 177
    const/16 v0, 0xd

    .line 178
    .line 179
    aput-object v13, v14, v0

    .line 180
    .line 181
    invoke-static {v14}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    return-object v0
.end method

.method public final getModule(Ljava/lang/String;Lcom/facebook/react/bridge/ReactApplicationContext;)Lcom/facebook/react/bridge/NativeModule;
    .locals 1

    .line 1
    const-string v0, "s"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "reactApplicationContext"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "RNSModule"

    .line 12
    .line 13
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    if-eqz p1, :cond_0

    .line 18
    .line 19
    new-instance p1, Lcom/swmansion/rnscreens/ScreensModule;

    .line 20
    .line 21
    invoke-direct {p1, p2}, Lcom/swmansion/rnscreens/ScreensModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 22
    .line 23
    .line 24
    return-object p1

    .line 25
    :cond_0
    const/4 p1, 0x0

    .line 26
    return-object p1
.end method

.method public final getReactModuleInfoProvider()Lcom/facebook/react/module/model/ReactModuleInfoProvider;
    .locals 2

    .line 1
    new-instance v0, LM7/j;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LM7/j;-><init>(I)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method
