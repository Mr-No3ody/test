.class public final synthetic LM7/C;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# instance fields
.field public final synthetic a:LN7/a;

.field public final synthetic b:Lcom/swmansion/rnscreens/ScreenStackFragment;


# direct methods
.method public synthetic constructor <init>(LN7/a;Lcom/swmansion/rnscreens/ScreenStackFragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LM7/C;->a:LN7/a;

    iput-object p2, p0, LM7/C;->b:Lcom/swmansion/rnscreens/ScreenStackFragment;

    return-void
.end method


# virtual methods
.method public final onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 0

    .line 1
    sget p1, Lcom/swmansion/rnscreens/ScreenStackFragment;->X:I

    .line 2
    .line 3
    iget-object p1, p0, LM7/C;->b:Lcom/swmansion/rnscreens/ScreenStackFragment;

    .line 4
    .line 5
    invoke-virtual {p1}, Lcom/swmansion/rnscreens/ScreenFragment;->getScreen()Lcom/swmansion/rnscreens/Screen;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iget-object p2, p0, LM7/C;->a:LN7/a;

    .line 10
    .line 11
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    const-string p3, "screen"

    .line 15
    .line 16
    invoke-static {p1, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const/4 p3, 0x1

    .line 20
    iput-boolean p3, p2, LN7/a;->a:Z

    .line 21
    .line 22
    invoke-virtual {p2, p1}, LN7/a;->a(Lcom/swmansion/rnscreens/Screen;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method
