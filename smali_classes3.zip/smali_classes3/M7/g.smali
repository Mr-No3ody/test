.class public final synthetic LM7/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/swmansion/rnscreens/Screen;


# direct methods
.method public synthetic constructor <init>(Lcom/swmansion/rnscreens/Screen;I)V
    .locals 0

    .line 1
    iput p2, p0, LM7/g;->a:I

    iput-object p1, p0, LM7/g;->b:Lcom/swmansion/rnscreens/Screen;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget-object v0, p0, LM7/g;->b:Lcom/swmansion/rnscreens/Screen;

    .line 2
    .line 3
    iget v1, p0, LM7/g;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/swmansion/rnscreens/Screen;->A0:I

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-interface {v1}, Landroid/view/ViewParent;->requestLayout()V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0}, Lcom/swmansion/rnscreens/Screen;->e()V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :pswitch_0
    sget-object v1, Lcom/swmansion/rnscreens/NativeProxy;->a:Lcom/swmansion/rnscreens/NativeProxy$a;

    .line 22
    .line 23
    iget-boolean v1, v0, Lcom/swmansion/rnscreens/Screen;->C:Z

    .line 24
    .line 25
    if-nez v1, :cond_0

    .line 26
    .line 27
    const/4 v1, 0x1

    .line 28
    iput-boolean v1, v0, Lcom/swmansion/rnscreens/Screen;->C:Z

    .line 29
    .line 30
    invoke-virtual {v0, v0}, Lcom/swmansion/rnscreens/Screen;->g(Landroid/view/ViewGroup;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    return-void

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
