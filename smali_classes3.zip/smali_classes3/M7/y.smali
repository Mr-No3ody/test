.class public final LM7/y;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroid/graphics/Canvas;

.field public b:Landroid/view/View;

.field public c:J

.field public final synthetic d:Lcom/swmansion/rnscreens/ScreenStack;


# direct methods
.method public constructor <init>(Lcom/swmansion/rnscreens/ScreenStack;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LM7/y;->d:Lcom/swmansion/rnscreens/ScreenStack;

    .line 5
    .line 6
    return-void
.end method
