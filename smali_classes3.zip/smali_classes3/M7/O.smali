.class public final LM7/O;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/widget/SearchView$OnQueryTextListener;


# instance fields
.field public final synthetic a:Lcom/swmansion/rnscreens/SearchBarView;


# direct methods
.method public constructor <init>(Lcom/swmansion/rnscreens/SearchBarView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LM7/O;->a:Lcom/swmansion/rnscreens/SearchBarView;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onQueryTextChange(Ljava/lang/String;)Z
    .locals 4

    .line 1
    sget v0, Lcom/swmansion/rnscreens/SearchBarView;->w:I

    .line 2
    .line 3
    iget-object v0, p0, LM7/O;->a:Lcom/swmansion/rnscreens/SearchBarView;

    .line 4
    .line 5
    new-instance v1, LO7/C;

    .line 6
    .line 7
    iget v2, v0, Lcom/swmansion/rnscreens/SearchBarView;->v:I

    .line 8
    .line 9
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    invoke-direct {v1, v2, v3, p1}, LO7/C;-><init>(IILjava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, v1}, Lcom/swmansion/rnscreens/SearchBarView;->j(Lcom/facebook/react/uimanager/events/Event;)V

    .line 17
    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    return p1
.end method

.method public final onQueryTextSubmit(Ljava/lang/String;)Z
    .locals 4

    .line 1
    sget v0, Lcom/swmansion/rnscreens/SearchBarView;->w:I

    .line 2
    .line 3
    iget-object v0, p0, LM7/O;->a:Lcom/swmansion/rnscreens/SearchBarView;

    .line 4
    .line 5
    new-instance v1, LO7/K;

    .line 6
    .line 7
    iget v2, v0, Lcom/swmansion/rnscreens/SearchBarView;->v:I

    .line 8
    .line 9
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    invoke-direct {v1, v2, v3, p1}, LO7/K;-><init>(IILjava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, v1}, Lcom/swmansion/rnscreens/SearchBarView;->j(Lcom/facebook/react/uimanager/events/Event;)V

    .line 17
    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    return p1
.end method
