.class public final synthetic LM7/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/core/view/OnApplyWindowInsetsListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LM7/A;->a:I

    iput-object p1, p0, LM7/A;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;Landroidx/core/view/q0;)Landroidx/core/view/q0;
    .locals 4

    .line 1
    const-string v0, "windowInsets"

    .line 2
    .line 3
    const-string v1, "<unused var>"

    .line 4
    .line 5
    iget-object v2, p0, LM7/A;->b:Ljava/lang/Object;

    .line 6
    .line 7
    iget v3, p0, LM7/A;->a:I

    .line 8
    .line 9
    packed-switch v3, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast v2, Lcom/facebook/react/views/safeareaview/ReactSafeAreaView;

    .line 13
    .line 14
    invoke-static {v2, p1, p2}, Lcom/facebook/react/views/safeareaview/ReactSafeAreaView;->a(Lcom/facebook/react/views/safeareaview/ReactSafeAreaView;Landroid/view/View;Landroidx/core/view/q0;)Landroidx/core/view/q0;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    return-object p1

    .line 19
    :pswitch_0
    sget v3, Lcom/swmansion/rnscreens/ScreenStackFragment;->X:I

    .line 20
    .line 21
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    check-cast v2, Lcom/swmansion/rnscreens/ScreenStackFragment;

    .line 28
    .line 29
    invoke-virtual {v2, p2}, Lcom/swmansion/rnscreens/ScreenStackFragment;->h(Landroidx/core/view/q0;)V

    .line 30
    .line 31
    .line 32
    return-object p2

    .line 33
    :pswitch_1
    sget v3, Lcom/swmansion/rnscreens/ScreenStackFragment;->X:I

    .line 34
    .line 35
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    check-cast v2, Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;

    .line 42
    .line 43
    const-string p1, "insets"

    .line 44
    .line 45
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget-object p1, p2, Landroidx/core/view/q0;->a:Landroidx/core/view/o0;

    .line 49
    .line 50
    const/16 v0, 0x8

    .line 51
    .line 52
    invoke-virtual {p1, v0}, Landroidx/core/view/o0;->g(I)Landroidx/core/graphics/e;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    iget p1, p1, Landroidx/core/graphics/e;->d:I

    .line 57
    .line 58
    iput p1, v2, Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;->f:I

    .line 59
    .line 60
    iget-boolean p1, v2, Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;->d:Z

    .line 61
    .line 62
    if-nez p1, :cond_0

    .line 63
    .line 64
    const/4 p1, 0x0

    .line 65
    invoke-virtual {v2, p1}, Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;->f(F)V

    .line 66
    .line 67
    .line 68
    :cond_0
    return-object p2

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
