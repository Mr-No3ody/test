.class public final LM7/D;
.super Landroidx/core/view/W;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;

.field public final synthetic b:Lcom/swmansion/rnscreens/ScreenStackFragment;


# direct methods
.method public constructor <init>(Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;Lcom/swmansion/rnscreens/ScreenStackFragment;)V
    .locals 0

    .line 1
    iput-object p1, p0, LM7/D;->a:Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;

    .line 2
    .line 3
    iput-object p2, p0, LM7/D;->b:Lcom/swmansion/rnscreens/ScreenStackFragment;

    .line 4
    .line 5
    invoke-direct {p0}, Landroidx/core/view/W;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onEnd(Landroidx/core/view/d0;)V
    .locals 1

    .line 1
    const-string v0, "animation"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LM7/D;->b:Lcom/swmansion/rnscreens/ScreenStackFragment;

    .line 7
    .line 8
    invoke-virtual {p1}, Lcom/swmansion/rnscreens/ScreenFragment;->getScreen()Lcom/swmansion/rnscreens/Screen;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-virtual {p1}, Lcom/swmansion/rnscreens/Screen;->e()V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final onProgress(Landroidx/core/view/q0;Ljava/util/List;)Landroidx/core/view/q0;
    .locals 2

    .line 1
    const-string v0, "insets"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v1, "runningAnimations"

    .line 7
    .line 8
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 12
    .line 13
    const/16 v1, 0x1e

    .line 14
    .line 15
    if-lt p2, v1, :cond_0

    .line 16
    .line 17
    iget-object p2, p0, LM7/D;->a:Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p1, Landroidx/core/view/q0;->a:Landroidx/core/view/o0;

    .line 23
    .line 24
    const/16 v1, 0x8

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Landroidx/core/view/o0;->g(I)Landroidx/core/graphics/e;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iget v0, v0, Landroidx/core/graphics/e;->d:I

    .line 31
    .line 32
    iput v0, p2, Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;->f:I

    .line 33
    .line 34
    iget-boolean v0, p2, Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;->d:Z

    .line 35
    .line 36
    if-nez v0, :cond_0

    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    invoke-virtual {p2, v0}, Lcom/swmansion/rnscreens/bottomsheet/SheetDelegate;->f(F)V

    .line 40
    .line 41
    .line 42
    :cond_0
    return-object p1
.end method
