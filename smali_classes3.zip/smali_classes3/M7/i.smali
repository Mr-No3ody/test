.class public final LM7/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static rns_default_enter_in:I = 0x7f01008d

.field public static rns_default_enter_out:I = 0x7f01008e

.field public static rns_default_exit_in:I = 0x7f01008f

.field public static rns_default_exit_out:I = 0x7f010090

.field public static rns_fade_from_bottom:I = 0x7f010091

.field public static rns_fade_in:I = 0x7f010092

.field public static rns_fade_out:I = 0x7f010093

.field public static rns_fade_to_bottom:I = 0x7f010094

.field public static rns_ios_from_left_background_close:I = 0x7f010095

.field public static rns_ios_from_left_background_open:I = 0x7f010096

.field public static rns_ios_from_left_foreground_close:I = 0x7f010097

.field public static rns_ios_from_left_foreground_open:I = 0x7f010098

.field public static rns_ios_from_right_background_close:I = 0x7f010099

.field public static rns_ios_from_right_background_open:I = 0x7f01009a

.field public static rns_ios_from_right_foreground_close:I = 0x7f01009b

.field public static rns_ios_from_right_foreground_open:I = 0x7f01009c

.field public static rns_no_animation_20:I = 0x7f01009d

.field public static rns_no_animation_250:I = 0x7f01009e

.field public static rns_no_animation_350:I = 0x7f01009f

.field public static rns_no_animation_medium:I = 0x7f0100a0

.field public static rns_slide_in_from_bottom:I = 0x7f0100a1

.field public static rns_slide_in_from_left:I = 0x7f0100a2

.field public static rns_slide_in_from_right:I = 0x7f0100a3

.field public static rns_slide_out_to_bottom:I = 0x7f0100a4

.field public static rns_slide_out_to_left:I = 0x7f0100a5

.field public static rns_slide_out_to_right:I = 0x7f0100a6

.field public static rns_standard_accelerate_interpolator:I = 0x7f0100a7


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
