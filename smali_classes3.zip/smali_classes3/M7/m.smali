.class public final synthetic LM7/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/swmansion/rnscreens/Screen;

.field public final synthetic b:I

.field public final synthetic c:F


# direct methods
.method public synthetic constructor <init>(Lcom/swmansion/rnscreens/Screen;IF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LM7/m;->a:Lcom/swmansion/rnscreens/Screen;

    iput p2, p0, LM7/m;->b:I

    iput p3, p0, LM7/m;->c:F

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    sget v0, Lcom/swmansion/rnscreens/Screen;->A0:I

    .line 2
    .line 3
    iget-object v0, p0, LM7/m;->a:Lcom/swmansion/rnscreens/Screen;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    iget v3, p0, LM7/m;->b:I

    .line 14
    .line 15
    sub-int/2addr v2, v3

    .line 16
    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    .line 21
    .line 22
    .line 23
    move-result v4

    .line 24
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/view/View;->layout(IIII)V

    .line 25
    .line 26
    .line 27
    iget v1, p0, LM7/m;->c:F

    .line 28
    .line 29
    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-interface {v1}, Landroid/view/ViewParent;->requestLayout()V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Lcom/swmansion/rnscreens/Screen;->e()V

    .line 40
    .line 41
    .line 42
    return-void
.end method
