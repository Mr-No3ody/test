.class public final LQ8/b;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:I

.field public final synthetic c:Lcom/transsnet/palmpay/account/ui/dialog/AutoLogoutOptionDialog;


# direct methods
.method public constructor <init>(ILcom/transsnet/palmpay/account/ui/dialog/AutoLogoutOptionDialog;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput p1, p0, LQ8/b;->b:I

    .line 2
    .line 3
    iput-object p2, p0, LQ8/b;->c:Lcom/transsnet/palmpay/account/ui/dialog/AutoLogoutOptionDialog;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LQ8/b;

    .line 2
    .line 3
    iget v0, p0, LQ8/b;->b:I

    .line 4
    .line 5
    iget-object v1, p0, LQ8/b;->c:Lcom/transsnet/palmpay/account/ui/dialog/AutoLogoutOptionDialog;

    .line 6
    .line 7
    invoke-direct {p1, v0, v1, p2}, LQ8/b;-><init>(ILcom/transsnet/palmpay/account/ui/dialog/AutoLogoutOptionDialog;Lkotlin/coroutines/Continuation;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LQ8/b;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LQ8/b;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LQ8/b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LQ8/b;->a:I

    .line 4
    .line 5
    iget-object v2, p0, LQ8/b;->c:Lcom/transsnet/palmpay/account/ui/dialog/AutoLogoutOptionDialog;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    const/4 v4, 0x0

    .line 9
    iget v5, p0, LQ8/b;->b:I

    .line 10
    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    if-ne v1, v3, :cond_0

    .line 14
    .line 15
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 16
    .line 17
    .line 18
    goto :goto_0

    .line 19
    :catchall_0
    move-exception p1

    .line 20
    goto/16 :goto_3

    .line 21
    .line 22
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 23
    .line 24
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 25
    .line 26
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    throw p1

    .line 30
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :try_start_1
    sget-object p1, LWf/I;->a:Lcg/f;

    .line 34
    .line 35
    sget-object p1, Lcg/e;->c:Lcg/e;

    .line 36
    .line 37
    new-instance v1, LQ8/a;

    .line 38
    .line 39
    const/4 v6, 0x0

    .line 40
    invoke-direct {v1, v5, v6}, LQ8/a;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 41
    .line 42
    .line 43
    iput v3, p0, LQ8/b;->a:I

    .line 44
    .line 45
    invoke-static {p1, v1, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    if-ne p1, v0, :cond_2

    .line 50
    .line 51
    return-object v0

    .line 52
    :cond_2
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 53
    .line 54
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_3

    .line 59
    .line 60
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    const-string v0, "AutoLogoutSetupGuide"

    .line 65
    .line 66
    const-string v1, "SettingType"

    .line 67
    .line 68
    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    invoke-virtual {p1, v0, v1, v3}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    new-instance v0, Ljava/lang/StringBuilder;

    .line 80
    .line 81
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 82
    .line 83
    .line 84
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/db/entity/User;->getPhoneNumber()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    const-string v1, "PATTERN_PIN_SETTING"

    .line 100
    .line 101
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    invoke-virtual {p1, v0, v5}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;I)V

    .line 109
    .line 110
    .line 111
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->h()Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    const-string v0, "getKeyLastPinTime(...)"

    .line 116
    .line 117
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    invoke-static {v4, p1}, Le1/a;->U(ILjava/lang/String;)V

    .line 121
    .line 122
    .line 123
    sget-object p1, Lha/b;->a:Lha/c;

    .line 124
    .line 125
    const-wide/16 v0, 0x0

    .line 126
    .line 127
    invoke-virtual {p1, v0, v1}, Lha/c;->a(J)V

    .line 128
    .line 129
    .line 130
    invoke-static {v2}, Lcom/transsnet/palmpay/account/ui/dialog/AutoLogoutOptionDialog;->access$getCheckStatus$p(Lcom/transsnet/palmpay/account/ui/dialog/AutoLogoutOptionDialog;)I

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    iput v0, p1, Lha/c;->e:I

    .line 135
    .line 136
    const/16 p1, 0x211

    .line 137
    .line 138
    invoke-static {p1}, LPa/r0;->P1(I)V

    .line 139
    .line 140
    .line 141
    goto :goto_1

    .line 142
    :cond_3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    new-array v0, v4, [Ljava/lang/Object;

    .line 147
    .line 148
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 149
    .line 150
    .line 151
    :goto_1
    invoke-virtual {v2}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 152
    .line 153
    .line 154
    goto :goto_2

    .line 155
    :catch_0
    :try_start_2
    sget p1, LF8/h;->ac_operation_fail:I

    .line 156
    .line 157
    invoke-virtual {v2}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->string(ILandroid/content/Context;)Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    new-array v0, v4, [Ljava/lang/Object;

    .line 166
    .line 167
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 168
    .line 169
    .line 170
    goto :goto_1

    .line 171
    :goto_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 172
    .line 173
    return-object p1

    .line 174
    :goto_3
    invoke-virtual {v2}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 175
    .line 176
    .line 177
    throw p1
.end method
