.class public final LQ8/d;
.super Landroid/app/Dialog;
.source "SourceFile"


# instance fields
.field public final a:Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;

.field public b:LBc/f;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;)V
    .locals 1

    .line 1
    const-string v0, "activity"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget v0, Lcom/transsnet/palmpay/custom_view/w;->CvFullscreenDialog:I

    .line 7
    .line 8
    invoke-direct {p0, p1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, LQ8/d;->a:Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final onCreate(Landroid/os/Bundle;)V
    .locals 11

    .line 1
    invoke-super {p0, p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    const/4 v0, 0x1

    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1, v0}, Landroid/view/Window;->requestFeature(I)Z

    .line 12
    .line 13
    .line 14
    :cond_0
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    if-eqz p1, :cond_1

    .line 19
    .line 20
    const v1, 0x106000d

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1, v1}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 24
    .line 25
    .line 26
    :cond_1
    sget p1, LF8/e;->ac_other_verify_methods_dialog:I

    .line 27
    .line 28
    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setContentView(I)V

    .line 29
    .line 30
    .line 31
    sget p1, LF8/d;->rootView:I

    .line 32
    .line 33
    invoke-virtual {p0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    move-object v2, p1

    .line 38
    check-cast v2, Landroid/widget/LinearLayout;

    .line 39
    .line 40
    sget v1, LF8/d;->tv1:I

    .line 41
    .line 42
    invoke-static {v1, p1}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    check-cast v3, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 47
    .line 48
    if-eqz v3, :cond_a

    .line 49
    .line 50
    sget v1, LF8/d;->tv2:I

    .line 51
    .line 52
    invoke-static {v1, p1}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    check-cast v4, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 57
    .line 58
    if-eqz v4, :cond_a

    .line 59
    .line 60
    sget v1, LF8/d;->tv3:I

    .line 61
    .line 62
    invoke-static {v1, p1}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 63
    .line 64
    .line 65
    move-result-object v5

    .line 66
    check-cast v5, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 67
    .line 68
    if-eqz v5, :cond_a

    .line 69
    .line 70
    sget v1, LF8/d;->tvCancel:I

    .line 71
    .line 72
    invoke-static {v1, p1}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 73
    .line 74
    .line 75
    move-result-object v6

    .line 76
    check-cast v6, Lcom/palmpay/lib/ui/button/PpButton;

    .line 77
    .line 78
    if-eqz v6, :cond_a

    .line 79
    .line 80
    sget v1, LF8/d;->tvTitle:I

    .line 81
    .line 82
    invoke-static {v1, p1}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 83
    .line 84
    .line 85
    move-result-object v7

    .line 86
    check-cast v7, Landroid/widget/TextView;

    .line 87
    .line 88
    if-eqz v7, :cond_a

    .line 89
    .line 90
    sget v1, LF8/d;->viewLine1:I

    .line 91
    .line 92
    invoke-static {v1, p1}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 93
    .line 94
    .line 95
    move-result-object v8

    .line 96
    if-eqz v8, :cond_a

    .line 97
    .line 98
    sget v1, LF8/d;->viewLine2:I

    .line 99
    .line 100
    invoke-static {v1, p1}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 101
    .line 102
    .line 103
    move-result-object v9

    .line 104
    if-eqz v9, :cond_a

    .line 105
    .line 106
    new-instance v1, LBc/f;

    .line 107
    .line 108
    const/16 v10, 0xb

    .line 109
    .line 110
    invoke-direct/range {v1 .. v10}, LBc/f;-><init>(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;I)V

    .line 111
    .line 112
    .line 113
    iput-object v1, p0, LQ8/d;->b:LBc/f;

    .line 114
    .line 115
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    const-string v1, "getContext(...)"

    .line 120
    .line 121
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    if-eqz p1, :cond_2

    .line 129
    .line 130
    const/16 v1, 0x50

    .line 131
    .line 132
    invoke-virtual {p1, v1}, Landroid/view/Window;->setGravity(I)V

    .line 133
    .line 134
    .line 135
    :cond_2
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    if-eqz p1, :cond_3

    .line 140
    .line 141
    sget v1, Lba/l;->dialog_bottom_in_out:I

    .line 142
    .line 143
    invoke-virtual {p1, v1}, Landroid/view/Window;->setWindowAnimations(I)V

    .line 144
    .line 145
    .line 146
    :cond_3
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    if-eqz p1, :cond_4

    .line 151
    .line 152
    invoke-virtual {p1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    if-eqz p1, :cond_4

    .line 157
    .line 158
    invoke-static {}, Lcom/transsnet/palmpay/util/ScreenUtils;->getScreenWidth()I

    .line 159
    .line 160
    .line 161
    move-result v1

    .line 162
    iput v1, p1, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 163
    .line 164
    :cond_4
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    if-eqz p1, :cond_5

    .line 169
    .line 170
    invoke-virtual {p1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 171
    .line 172
    .line 173
    move-result-object p1

    .line 174
    if-eqz p1, :cond_5

    .line 175
    .line 176
    const/4 v1, -0x2

    .line 177
    iput v1, p1, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 178
    .line 179
    :cond_5
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 183
    .line 184
    .line 185
    new-instance p1, LNc/x;

    .line 186
    .line 187
    const/16 v1, 0x11

    .line 188
    .line 189
    invoke-direct {p1, p0, v1}, LNc/x;-><init>(Ljava/lang/Object;I)V

    .line 190
    .line 191
    .line 192
    iget-object v1, p0, LQ8/d;->b:LBc/f;

    .line 193
    .line 194
    const/4 v2, 0x0

    .line 195
    if-eqz v1, :cond_6

    .line 196
    .line 197
    iget-object v3, v1, LBc/f;->g:Landroid/view/View;

    .line 198
    .line 199
    check-cast v3, Lcom/palmpay/lib/ui/button/PpButton;

    .line 200
    .line 201
    goto :goto_0

    .line 202
    :cond_6
    move-object v3, v2

    .line 203
    :goto_0
    if-eqz v1, :cond_7

    .line 204
    .line 205
    iget-object v4, v1, LBc/f;->d:Landroid/view/View;

    .line 206
    .line 207
    check-cast v4, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 208
    .line 209
    goto :goto_1

    .line 210
    :cond_7
    move-object v4, v2

    .line 211
    :goto_1
    if-eqz v1, :cond_8

    .line 212
    .line 213
    iget-object v5, v1, LBc/f;->e:Ljava/lang/Object;

    .line 214
    .line 215
    check-cast v5, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 216
    .line 217
    goto :goto_2

    .line 218
    :cond_8
    move-object v5, v2

    .line 219
    :goto_2
    if-eqz v1, :cond_9

    .line 220
    .line 221
    iget-object v1, v1, LBc/f;->f:Landroid/view/View;

    .line 222
    .line 223
    move-object v2, v1

    .line 224
    check-cast v2, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 225
    .line 226
    :cond_9
    const/4 v1, 0x4

    .line 227
    new-array v1, v1, [Landroid/view/View;

    .line 228
    .line 229
    const/4 v6, 0x0

    .line 230
    aput-object v3, v1, v6

    .line 231
    .line 232
    aput-object v4, v1, v0

    .line 233
    .line 234
    const/4 v0, 0x2

    .line 235
    aput-object v5, v1, v0

    .line 236
    .line 237
    const/4 v0, 0x3

    .line 238
    aput-object v2, v1, v0

    .line 239
    .line 240
    invoke-static {p1, v1}, Loa/h;->q(Landroid/view/View$OnClickListener;[Landroid/view/View;)V

    .line 241
    .line 242
    .line 243
    return-void

    .line 244
    :cond_a
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 245
    .line 246
    .line 247
    move-result-object p1

    .line 248
    invoke-virtual {p1, v1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object p1

    .line 252
    new-instance v0, Ljava/lang/NullPointerException;

    .line 253
    .line 254
    const-string v1, "Missing required view with ID: "

    .line 255
    .line 256
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 257
    .line 258
    .line 259
    move-result-object p1

    .line 260
    invoke-direct {v0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    throw v0
.end method
