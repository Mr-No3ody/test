.class public final La5/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/growingio/android/sdk/track/listener/IActivityLifecycle;
.implements Lcom/growingio/android/sdk/track/view/OnViewStateChangedListener;


# direct methods
.method public static a(Landroid/view/View;)V
    .locals 8

    .line 1
    const/4 v0, -0x1

    .line 2
    sget-object v1, Lcom/growingio/android/sdk/d;->b:Lcom/growingio/android/sdk/d;

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    move v1, v2

    .line 8
    goto :goto_0

    .line 9
    :cond_0
    sget-boolean v1, Lcom/growingio/android/sdk/d;->c:Z

    .line 10
    .line 11
    :goto_0
    const-string v3, "ViewChangeProvider"

    .line 12
    .line 13
    if-nez v1, :cond_1

    .line 14
    .line 15
    const-string v1, "Autotracker do not initialized successfully"

    .line 16
    .line 17
    new-array v4, v2, [Ljava/lang/Object;

    .line 18
    .line 19
    invoke-static {v3, v1, v4}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    :cond_1
    const/4 v1, 0x0

    .line 23
    if-nez p0, :cond_2

    .line 24
    .line 25
    goto/16 :goto_a

    .line 26
    .line 27
    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    instance-of v5, v4, Landroid/content/ContextWrapper;

    .line 32
    .line 33
    if-nez v5, :cond_3

    .line 34
    .line 35
    :goto_1
    move-object v4, v1

    .line 36
    goto :goto_3

    .line 37
    :cond_3
    check-cast v4, Landroid/content/ContextWrapper;

    .line 38
    .line 39
    :goto_2
    instance-of v5, v4, Landroid/app/Activity;

    .line 40
    .line 41
    if-eqz v5, :cond_4

    .line 42
    .line 43
    check-cast v4, Landroid/app/Activity;

    .line 44
    .line 45
    goto :goto_3

    .line 46
    :cond_4
    invoke-virtual {v4}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    instance-of v5, v4, Landroid/content/ContextWrapper;

    .line 51
    .line 52
    if-nez v5, :cond_15

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :goto_3
    if-eqz v4, :cond_12

    .line 56
    .line 57
    sget v4, LZ4/g;->growing_tracker_ignore_policy:I

    .line 58
    .line 59
    invoke-virtual {p0, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    instance-of v5, v4, LZ4/f;

    .line 64
    .line 65
    if-eqz v5, :cond_5

    .line 66
    .line 67
    check-cast v4, LZ4/f;

    .line 68
    .line 69
    goto :goto_4

    .line 70
    :cond_5
    move-object v4, v1

    .line 71
    :goto_4
    const/4 v5, 0x1

    .line 72
    if-eqz v4, :cond_8

    .line 73
    .line 74
    sget-object v6, LZ4/f;->a:LZ4/f;

    .line 75
    .line 76
    if-eq v4, v6, :cond_7

    .line 77
    .line 78
    sget-object v6, LZ4/f;->c:LZ4/f;

    .line 79
    .line 80
    if-ne v4, v6, :cond_6

    .line 81
    .line 82
    goto :goto_5

    .line 83
    :cond_6
    move v4, v2

    .line 84
    goto :goto_6

    .line 85
    :cond_7
    :goto_5
    move v4, v5

    .line 86
    goto :goto_6

    .line 87
    :cond_8
    invoke-static {p0}, Lio/fastkv/n;->r(Landroid/view/View;)Z

    .line 88
    .line 89
    .line 90
    move-result v4

    .line 91
    :goto_6
    if-nez v4, :cond_12

    .line 92
    .line 93
    instance-of v4, p0, Landroid/widget/EditText;

    .line 94
    .line 95
    if-eqz v4, :cond_c

    .line 96
    .line 97
    sget v4, LZ4/g;->growing_tracker_monitoring_focus_content:I

    .line 98
    .line 99
    invoke-virtual {p0, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v4

    .line 103
    instance-of v6, v4, Ljava/lang/String;

    .line 104
    .line 105
    if-eqz v6, :cond_9

    .line 106
    .line 107
    check-cast v4, Ljava/lang/String;

    .line 108
    .line 109
    goto :goto_7

    .line 110
    :cond_9
    move-object v4, v1

    .line 111
    :goto_7
    if-nez v4, :cond_a

    .line 112
    .line 113
    const-string v4, ""

    .line 114
    .line 115
    :cond_a
    move-object v6, p0

    .line 116
    check-cast v6, Landroid/widget/EditText;

    .line 117
    .line 118
    invoke-virtual {v6}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 119
    .line 120
    .line 121
    move-result-object v6

    .line 122
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v6

    .line 126
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 127
    .line 128
    .line 129
    move-result v7

    .line 130
    if-eqz v7, :cond_b

    .line 131
    .line 132
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 133
    .line 134
    .line 135
    move-result v7

    .line 136
    if-nez v7, :cond_c

    .line 137
    .line 138
    :cond_b
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v4

    .line 142
    if-eqz v4, :cond_d

    .line 143
    .line 144
    :cond_c
    move v5, v2

    .line 145
    goto :goto_8

    .line 146
    :cond_d
    sget v4, LZ4/g;->growing_tracker_monitoring_focus_content:I

    .line 147
    .line 148
    invoke-virtual {p0, v4, v6}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    :goto_8
    if-nez v5, :cond_e

    .line 152
    .line 153
    goto :goto_a

    .line 154
    :cond_e
    invoke-static {p0}, Lc5/a;->b(Landroid/view/View;)Z

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    if-eqz v1, :cond_f

    .line 159
    .line 160
    new-instance v1, Lc5/a;

    .line 161
    .line 162
    invoke-direct {v1, p0}, Lc5/a;-><init>(Landroid/view/View;)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v1}, Lc5/a;->a()Landroid/view/MenuItem;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    if-eqz v1, :cond_f

    .line 170
    .line 171
    sget-object p0, Ls5/a;->a:Ls5/b;

    .line 172
    .line 173
    invoke-virtual {p0}, Ls5/b;->x()Landroid/app/Activity;

    .line 174
    .line 175
    .line 176
    move-result-object p0

    .line 177
    sget-object v4, Lb5/d;->a:Ljava/util/WeakHashMap;

    .line 178
    .line 179
    sget-object v4, Lb5/c;->a:Lb5/d;

    .line 180
    .line 181
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 182
    .line 183
    .line 184
    sget-object v4, Lb5/d;->a:Ljava/util/WeakHashMap;

    .line 185
    .line 186
    invoke-virtual {v4, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object p0

    .line 190
    check-cast p0, Lb5/b;

    .line 191
    .line 192
    invoke-static {p0, v1}, Lio/fastkv/n;->k(Lb5/b;Landroid/view/MenuItem;)Ld5/b;

    .line 193
    .line 194
    .line 195
    move-result-object v1

    .line 196
    goto :goto_a

    .line 197
    :cond_f
    new-instance v1, Ljava/util/ArrayList;

    .line 198
    .line 199
    const/16 v4, 0x8

    .line 200
    .line 201
    invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 202
    .line 203
    .line 204
    invoke-static {p0, v1}, Lio/fastkv/n;->n(Landroid/view/View;Ljava/util/ArrayList;)Ld5/b;

    .line 205
    .line 206
    .line 207
    move-result-object p0

    .line 208
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 209
    .line 210
    .line 211
    move-result v4

    .line 212
    add-int/lit8 v4, v4, -0x2

    .line 213
    .line 214
    :goto_9
    if-ltz v4, :cond_11

    .line 215
    .line 216
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object v5

    .line 220
    check-cast v5, Landroid/view/View;

    .line 221
    .line 222
    iget-object v6, p0, Ld5/b;->a:Landroid/view/View;

    .line 223
    .line 224
    instance-of v7, v6, Landroid/view/ViewGroup;

    .line 225
    .line 226
    if-eqz v7, :cond_10

    .line 227
    .line 228
    check-cast v6, Landroid/view/ViewGroup;

    .line 229
    .line 230
    invoke-virtual {v6, v5}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 231
    .line 232
    .line 233
    move-result v6

    .line 234
    invoke-virtual {p0, v6, v5}, Ld5/b;->a(ILandroid/view/View;)Ld5/b;

    .line 235
    .line 236
    .line 237
    move-result-object p0

    .line 238
    :cond_10
    add-int/2addr v4, v0

    .line 239
    goto :goto_9

    .line 240
    :cond_11
    move-object v1, p0

    .line 241
    :cond_12
    :goto_a
    if-eqz v1, :cond_14

    .line 242
    .line 243
    sget-object p0, Lb5/d;->a:Ljava/util/WeakHashMap;

    .line 244
    .line 245
    sget-object p0, Lb5/c;->a:Lb5/d;

    .line 246
    .line 247
    iget-object v4, v1, Ld5/b;->a:Landroid/view/View;

    .line 248
    .line 249
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 250
    .line 251
    .line 252
    invoke-static {v4}, Lb5/d;->a(Landroid/view/View;)Lb5/b;

    .line 253
    .line 254
    .line 255
    move-result-object p0

    .line 256
    if-nez p0, :cond_13

    .line 257
    .line 258
    new-array p0, v2, [Ljava/lang/Object;

    .line 259
    .line 260
    const-string v0, "sendChangeEvent page Activity is NULL"

    .line 261
    .line 262
    invoke-static {v3, v0, p0}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 263
    .line 264
    .line 265
    return-void

    .line 266
    :cond_13
    sget-object v2, Le5/c;->a:Le5/d;

    .line 267
    .line 268
    new-instance v3, Lg5/k;

    .line 269
    .line 270
    invoke-direct {v3}, Lh5/c;-><init>()V

    .line 271
    .line 272
    .line 273
    iput v0, v3, Lg5/k;->D:I

    .line 274
    .line 275
    const-string v0, "VIEW_CHANGE"

    .line 276
    .line 277
    iput-object v0, v3, Lh5/c;->g:Ljava/lang/String;

    .line 278
    .line 279
    invoke-virtual {p0}, Lb5/b;->a()Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    iput-object v0, v3, Lg5/k;->z:Ljava/lang/String;

    .line 284
    .line 285
    iget-wide v4, p0, Lb5/b;->b:J

    .line 286
    .line 287
    iput-wide v4, v3, Lg5/k;->A:J

    .line 288
    .line 289
    iget-object p0, v1, Ld5/b;->b:Ljava/lang/String;

    .line 290
    .line 291
    iput-object p0, v3, Lg5/k;->C:Ljava/lang/String;

    .line 292
    .line 293
    iget p0, v1, Ld5/b;->h:I

    .line 294
    .line 295
    iput p0, v3, Lg5/k;->D:I

    .line 296
    .line 297
    iget-object p0, v1, Ld5/b;->e:Ljava/lang/String;

    .line 298
    .line 299
    iput-object p0, v3, Lg5/k;->B:Ljava/lang/String;

    .line 300
    .line 301
    invoke-virtual {v2, v3}, Le5/d;->y(Lh5/c;)V

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :cond_14
    const-string p0, "ViewNode is NULL"

    .line 306
    .line 307
    new-array v0, v2, [Ljava/lang/Object;

    .line 308
    .line 309
    invoke-static {v3, p0, v0}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 310
    .line 311
    .line 312
    return-void

    .line 313
    :cond_15
    check-cast v4, Landroid/content/ContextWrapper;

    .line 314
    .line 315
    goto/16 :goto_2
.end method


# virtual methods
.method public final onActivityLifecycle(Lm5/a;)V
    .locals 3

    .line 1
    iget v0, p1, Lm5/a;->a:I

    .line 2
    .line 3
    const/4 v1, 0x5

    .line 4
    if-ne v0, v1, :cond_1

    .line 5
    .line 6
    invoke-virtual {p1}, Lm5/a;->a()Landroid/app/Activity;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    if-nez p1, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-virtual {p1}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    instance-of v0, p1, Landroid/widget/EditText;

    .line 26
    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    new-array v0, v0, [Ljava/lang/Object;

    .line 31
    .line 32
    const-string v1, "ViewChangeProvider"

    .line 33
    .line 34
    const-string v2, "onActivityPaused, and focus view is EditText"

    .line 35
    .line 36
    invoke-static {v1, v2, v0}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    invoke-static {p1}, La5/a;->a(Landroid/view/View;)V

    .line 40
    .line 41
    .line 42
    :cond_1
    :goto_0
    return-void
.end method

.method public final onViewStateChanged(Lu5/b;)V
    .locals 3

    .line 1
    iget v0, p1, Lu5/b;->a:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    iget-object p1, p1, Lu5/b;->b:Landroid/view/View;

    .line 7
    .line 8
    instance-of v0, p1, Landroid/widget/EditText;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    new-array v0, v0, [Ljava/lang/Object;

    .line 14
    .line 15
    const-string v1, "ViewChangeProvider"

    .line 16
    .line 17
    const-string v2, "onViewStateChanged, and oldFocus view is EditText"

    .line 18
    .line 19
    invoke-static {v1, v2, v0}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    invoke-static {p1}, La5/a;->a(Landroid/view/View;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void
.end method
