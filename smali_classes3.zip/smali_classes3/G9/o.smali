.class public final synthetic LG9/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/o;->a:I

    iput-object p1, p0, LG9/o;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LG9/o;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;

    .line 3
    .line 4
    iget v2, p0, LG9/o;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;->w:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment$a;

    .line 10
    .line 11
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    sget v0, Ly9/b;->orhm_head:I

    .line 16
    .line 17
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 22
    .line 23
    :cond_0
    return-object v0

    .line 24
    :pswitch_0
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;->w:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment$a;

    .line 25
    .line 26
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 27
    .line 28
    if-eqz v1, :cond_1

    .line 29
    .line 30
    sget v0, Ly9/b;->ll_head_item:I

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroid/widget/LinearLayout;

    .line 37
    .line 38
    :cond_1
    return-object v0

    .line 39
    :pswitch_1
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;->w:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment$a;

    .line 40
    .line 41
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 42
    .line 43
    if-eqz v1, :cond_2

    .line 44
    .line 45
    sget v0, Ly9/b;->m_customer_service:I

    .line 46
    .line 47
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/OrderResultCustomerServiceModel;

    .line 52
    .line 53
    :cond_2
    return-object v0

    .line 54
    nop

    .line 55
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
