.class public final LG9/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/s;->a:I

    iput-object p1, p0, LG9/s;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;I)V
    .locals 0

    .line 2
    iput p3, p0, LG9/s;->a:I

    iput-object p2, p0, LG9/s;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, LG9/s;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 14
    .line 15
    if-nez v0, :cond_3

    .line 16
    .line 17
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 23
    .line 24
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;

    .line 27
    .line 28
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;->data:Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;

    .line 35
    .line 36
    if-eqz p1, :cond_3

    .line 37
    .line 38
    iget-object v0, p0, LG9/s;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 39
    .line 40
    iput-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->k0:Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;

    .line 41
    .line 42
    new-instance v1, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 43
    .line 44
    invoke-direct {v1}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMinAmount()J

    .line 48
    .line 49
    .line 50
    move-result-wide v2

    .line 51
    invoke-static {v2, v3}, LPa/r0;->A(J)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMaxAmount()J

    .line 56
    .line 57
    .line 58
    move-result-wide v3

    .line 59
    invoke-static {v3, v4}, LPa/r0;->A(J)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    new-instance v3, Ljava/lang/StringBuilder;

    .line 64
    .line 65
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    const-string v2, "-"

    .line 72
    .line 73
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 77
    .line 78
    .line 79
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    invoke-virtual {v1, p1}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    const/16 v1, 0x10

    .line 88
    .line 89
    const/4 v2, 0x1

    .line 90
    invoke-virtual {p1, v1, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(IZ)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {p1}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    const-string v1, "create(...)"

    .line 99
    .line 100
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    if-eqz v0, :cond_3

    .line 108
    .line 109
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 110
    .line 111
    .line 112
    goto :goto_0

    .line 113
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    new-array v0, v1, [Ljava/lang/Object;

    .line 118
    .line 119
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    goto :goto_0

    .line 123
    :cond_1
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 124
    .line 125
    if-nez v0, :cond_3

    .line 126
    .line 127
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 128
    .line 129
    if-eqz v0, :cond_2

    .line 130
    .line 131
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 132
    .line 133
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 134
    .line 135
    new-array v0, v1, [Ljava/lang/Object;

    .line 136
    .line 137
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    goto :goto_0

    .line 141
    :cond_2
    new-instance p1, Lxf/l;

    .line 142
    .line 143
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 144
    .line 145
    .line 146
    throw p1

    .line 147
    :cond_3
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 148
    .line 149
    return-object p1

    .line 150
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 151
    .line 152
    const-string v0, "it"

    .line 153
    .line 154
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 158
    .line 159
    if-nez v0, :cond_8

    .line 160
    .line 161
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 162
    .line 163
    const/4 v1, 0x0

    .line 164
    if-eqz v0, :cond_6

    .line 165
    .line 166
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 167
    .line 168
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 169
    .line 170
    check-cast p1, Lcom/transsnet/palmpay/core/bean/BalanceAccountInfo;

    .line 171
    .line 172
    if-eqz p1, :cond_8

    .line 173
    .line 174
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    if-eqz v0, :cond_5

    .line 179
    .line 180
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/BalanceAccountInfo;->getData()Lcom/transsnet/palmpay/core/bean/BalanceAccountInfo$DataBean;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    if-eqz v0, :cond_5

    .line 185
    .line 186
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/BalanceAccountInfo;->getData()Lcom/transsnet/palmpay/core/bean/BalanceAccountInfo$DataBean;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/BalanceAccountInfo$DataBean;->getAvailableBalance()J

    .line 191
    .line 192
    .line 193
    move-result-wide v2

    .line 194
    iget-object p1, p0, LG9/s;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 195
    .line 196
    iput-wide v2, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->p0:J

    .line 197
    .line 198
    iget-object v0, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->p:Lxf/t;

    .line 199
    .line 200
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v2

    .line 204
    check-cast v2, Landroid/widget/TextView;

    .line 205
    .line 206
    if-eqz v2, :cond_4

    .line 207
    .line 208
    const/4 v3, 0x1

    .line 209
    invoke-static {v2, v3}, Loa/h;->s(Landroid/view/View;Z)V

    .line 210
    .line 211
    .line 212
    :cond_4
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    check-cast v0, Landroid/widget/TextView;

    .line 217
    .line 218
    if-eqz v0, :cond_8

    .line 219
    .line 220
    sget v2, Ly9/d;->core_balance_x:I

    .line 221
    .line 222
    iget-wide v3, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->p0:J

    .line 223
    .line 224
    invoke-static {v3, v4, v1}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 225
    .line 226
    .line 227
    move-result-object v1

    .line 228
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    invoke-virtual {p1, v2, v1}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 233
    .line 234
    .line 235
    move-result-object p1

    .line 236
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 237
    .line 238
    .line 239
    goto :goto_1

    .line 240
    :cond_5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object p1

    .line 244
    new-array v0, v1, [Ljava/lang/Object;

    .line 245
    .line 246
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 247
    .line 248
    .line 249
    goto :goto_1

    .line 250
    :cond_6
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 251
    .line 252
    if-nez v0, :cond_8

    .line 253
    .line 254
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 255
    .line 256
    if-eqz v0, :cond_7

    .line 257
    .line 258
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 259
    .line 260
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 261
    .line 262
    new-array v0, v1, [Ljava/lang/Object;

    .line 263
    .line 264
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 265
    .line 266
    .line 267
    goto :goto_1

    .line 268
    :cond_7
    new-instance p1, Lxf/l;

    .line 269
    .line 270
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 271
    .line 272
    .line 273
    throw p1

    .line 274
    :cond_8
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 275
    .line 276
    return-object p1

    .line 277
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 278
    .line 279
    const-string v0, "it"

    .line 280
    .line 281
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 282
    .line 283
    .line 284
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 285
    .line 286
    if-eqz v0, :cond_9

    .line 287
    .line 288
    goto :goto_3

    .line 289
    :cond_9
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 290
    .line 291
    const/4 v1, 0x0

    .line 292
    if-eqz v0, :cond_c

    .line 293
    .line 294
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 295
    .line 296
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 297
    .line 298
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/CommonStringResult;

    .line 299
    .line 300
    if-eqz p1, :cond_a

    .line 301
    .line 302
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 303
    .line 304
    .line 305
    move-result v0

    .line 306
    const/4 v2, 0x1

    .line 307
    if-ne v0, v2, :cond_a

    .line 308
    .line 309
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/CommonStringResult;->data:Ljava/lang/String;

    .line 310
    .line 311
    if-eqz p1, :cond_e

    .line 312
    .line 313
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 314
    .line 315
    .line 316
    move-result v0

    .line 317
    if-nez v0, :cond_e

    .line 318
    .line 319
    iget-object v0, p0, LG9/s;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 320
    .line 321
    iput-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->M:Ljava/lang/String;

    .line 322
    .line 323
    goto :goto_3

    .line 324
    :cond_a
    if-eqz p1, :cond_b

    .line 325
    .line 326
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 327
    .line 328
    .line 329
    move-result-object p1

    .line 330
    goto :goto_2

    .line 331
    :cond_b
    const/4 p1, 0x0

    .line 332
    :goto_2
    new-array v0, v1, [Ljava/lang/Object;

    .line 333
    .line 334
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 335
    .line 336
    .line 337
    goto :goto_3

    .line 338
    :cond_c
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 339
    .line 340
    if-eqz v0, :cond_d

    .line 341
    .line 342
    goto :goto_3

    .line 343
    :cond_d
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 344
    .line 345
    if-eqz v0, :cond_f

    .line 346
    .line 347
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 348
    .line 349
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 350
    .line 351
    new-array v0, v1, [Ljava/lang/Object;

    .line 352
    .line 353
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 354
    .line 355
    .line 356
    :cond_e
    :goto_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 357
    .line 358
    return-object p1

    .line 359
    :cond_f
    new-instance p1, Lxf/l;

    .line 360
    .line 361
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 362
    .line 363
    .line 364
    throw p1

    .line 365
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 366
    .line 367
    const-string v0, "it"

    .line 368
    .line 369
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 370
    .line 371
    .line 372
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 373
    .line 374
    if-eqz v0, :cond_10

    .line 375
    .line 376
    goto/16 :goto_7

    .line 377
    .line 378
    :cond_10
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 379
    .line 380
    const/4 v1, 0x0

    .line 381
    if-eqz v0, :cond_21

    .line 382
    .line 383
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 384
    .line 385
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 386
    .line 387
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/WithdrawBankAccRsp;

    .line 388
    .line 389
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 390
    .line 391
    .line 392
    move-result v0

    .line 393
    if-eqz v0, :cond_20

    .line 394
    .line 395
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/WithdrawBankAccRsp;->data:Lcom/transsnet/palmpay/core/bean/BankCardListInfo;

    .line 396
    .line 397
    if-eqz p1, :cond_23

    .line 398
    .line 399
    iget v0, p1, Lcom/transsnet/palmpay/core/bean/BankCardListInfo;->curPage:I

    .line 400
    .line 401
    iget-object v2, p0, LG9/s;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 402
    .line 403
    const/4 v3, 0x0

    .line 404
    const-string v4, "mBankCardInfos"

    .line 405
    .line 406
    if-eqz v0, :cond_11

    .line 407
    .line 408
    const/4 v5, 0x1

    .line 409
    if-ne v0, v5, :cond_12

    .line 410
    .line 411
    :cond_11
    iget-object v0, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Y:Ljava/util/ArrayList;

    .line 412
    .line 413
    if-eqz v0, :cond_1f

    .line 414
    .line 415
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 416
    .line 417
    .line 418
    :cond_12
    iget-object v0, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Y:Ljava/util/ArrayList;

    .line 419
    .line 420
    if-eqz v0, :cond_1e

    .line 421
    .line 422
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/BankCardListInfo;->list:Ljava/util/List;

    .line 423
    .line 424
    check-cast p1, Ljava/util/Collection;

    .line 425
    .line 426
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 427
    .line 428
    .line 429
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Z:Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;

    .line 430
    .line 431
    if-eqz p1, :cond_14

    .line 432
    .line 433
    iget-object v0, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Y:Ljava/util/ArrayList;

    .line 434
    .line 435
    if-eqz v0, :cond_13

    .line 436
    .line 437
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;->setBankCardInfos(Ljava/util/List;)V

    .line 438
    .line 439
    .line 440
    goto :goto_4

    .line 441
    :cond_13
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 442
    .line 443
    .line 444
    throw v3

    .line 445
    :cond_14
    :goto_4
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Y:Ljava/util/ArrayList;

    .line 446
    .line 447
    if-eqz p1, :cond_1d

    .line 448
    .line 449
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 450
    .line 451
    .line 452
    move-result p1

    .line 453
    if-nez p1, :cond_16

    .line 454
    .line 455
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->X:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 456
    .line 457
    if-nez p1, :cond_16

    .line 458
    .line 459
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Y:Ljava/util/ArrayList;

    .line 460
    .line 461
    if-eqz p1, :cond_15

    .line 462
    .line 463
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 464
    .line 465
    .line 466
    move-result-object p1

    .line 467
    check-cast p1, Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 468
    .line 469
    iput-object p1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->X:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 470
    .line 471
    goto :goto_5

    .line 472
    :cond_15
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 473
    .line 474
    .line 475
    throw v3

    .line 476
    :cond_16
    :goto_5
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->X:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 477
    .line 478
    if-eqz p1, :cond_17

    .line 479
    .line 480
    invoke-static {v2, p1}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->t(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;Lcom/transsnet/palmpay/core/bean/BankCardInfo;)V

    .line 481
    .line 482
    .line 483
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Z:Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;

    .line 484
    .line 485
    if-eqz p1, :cond_17

    .line 486
    .line 487
    iget-object v0, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->X:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 488
    .line 489
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;->initNowSelectedBankCard(Lcom/transsnet/palmpay/core/bean/BankCardInfo;)V

    .line 490
    .line 491
    .line 492
    :cond_17
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Y:Ljava/util/ArrayList;

    .line 493
    .line 494
    if-eqz p1, :cond_1c

    .line 495
    .line 496
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 497
    .line 498
    .line 499
    move-result p1

    .line 500
    iget-object v0, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->C:Lxf/t;

    .line 501
    .line 502
    iget-object v4, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->B:Lxf/t;

    .line 503
    .line 504
    const/16 v5, 0x8

    .line 505
    .line 506
    if-eqz p1, :cond_19

    .line 507
    .line 508
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 509
    .line 510
    .line 511
    move-result-object p1

    .line 512
    check-cast p1, Landroid/widget/RelativeLayout;

    .line 513
    .line 514
    if-eqz p1, :cond_18

    .line 515
    .line 516
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 517
    .line 518
    .line 519
    :cond_18
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 520
    .line 521
    .line 522
    move-result-object p1

    .line 523
    check-cast p1, Lcom/transsnet/palmpay/core/viewmodel/ModelWithdrawBankaccountItem;

    .line 524
    .line 525
    if-eqz p1, :cond_1b

    .line 526
    .line 527
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 528
    .line 529
    .line 530
    goto :goto_6

    .line 531
    :cond_19
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 532
    .line 533
    .line 534
    move-result-object p1

    .line 535
    check-cast p1, Landroid/widget/RelativeLayout;

    .line 536
    .line 537
    if-eqz p1, :cond_1a

    .line 538
    .line 539
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 540
    .line 541
    .line 542
    :cond_1a
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 543
    .line 544
    .line 545
    move-result-object p1

    .line 546
    check-cast p1, Lcom/transsnet/palmpay/core/viewmodel/ModelWithdrawBankaccountItem;

    .line 547
    .line 548
    if-eqz p1, :cond_1b

    .line 549
    .line 550
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 551
    .line 552
    .line 553
    :cond_1b
    :goto_6
    iget-object p1, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 554
    .line 555
    check-cast p1, Lcom/transsnet/palmpay/cash_in/ui/viewmodel/WithdrawViewModel;

    .line 556
    .line 557
    if-eqz p1, :cond_23

    .line 558
    .line 559
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 560
    .line 561
    .line 562
    move-result-object v0

    .line 563
    invoke-virtual {v0}, Lya/a;->i()Ljava/lang/String;

    .line 564
    .line 565
    .line 566
    move-result-object v0

    .line 567
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 568
    .line 569
    .line 570
    move-result-object v1

    .line 571
    const-string v2, "Pref_"

    .line 572
    .line 573
    const-string v4, "_queryLastWithdrawBankAccNo_"

    .line 574
    .line 575
    invoke-static {v2, v0, v4, v1}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 576
    .line 577
    .line 578
    move-result-object v0

    .line 579
    invoke-static {p1}, Landroidx/lifecycle/V;->h(Landroidx/lifecycle/a0;)Lkotlinx/coroutines/CoroutineScope;

    .line 580
    .line 581
    .line 582
    move-result-object v1

    .line 583
    new-instance v2, LJ9/C;

    .line 584
    .line 585
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/ui/viewmodel/WithdrawViewModel;->i:Lcom/transsnet/palmpay/core/base/l;

    .line 586
    .line 587
    invoke-direct {v2, p1, v0, v3}, LJ9/C;-><init>(Lcom/transsnet/palmpay/core/base/l;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 588
    .line 589
    .line 590
    const/4 p1, 0x3

    .line 591
    invoke-static {v1, v3, v3, v2, p1}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 592
    .line 593
    .line 594
    goto :goto_7

    .line 595
    :cond_1c
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 596
    .line 597
    .line 598
    throw v3

    .line 599
    :cond_1d
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 600
    .line 601
    .line 602
    throw v3

    .line 603
    :cond_1e
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 604
    .line 605
    .line 606
    throw v3

    .line 607
    :cond_1f
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 608
    .line 609
    .line 610
    throw v3

    .line 611
    :cond_20
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 612
    .line 613
    .line 614
    move-result-object p1

    .line 615
    new-array v0, v1, [Ljava/lang/Object;

    .line 616
    .line 617
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 618
    .line 619
    .line 620
    goto :goto_7

    .line 621
    :cond_21
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 622
    .line 623
    if-eqz v0, :cond_22

    .line 624
    .line 625
    goto :goto_7

    .line 626
    :cond_22
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 627
    .line 628
    if-eqz v0, :cond_24

    .line 629
    .line 630
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 631
    .line 632
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 633
    .line 634
    new-array v0, v1, [Ljava/lang/Object;

    .line 635
    .line 636
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 637
    .line 638
    .line 639
    :cond_23
    :goto_7
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 640
    .line 641
    return-object p1

    .line 642
    :cond_24
    new-instance p1, Lxf/l;

    .line 643
    .line 644
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 645
    .line 646
    .line 647
    throw p1

    .line 648
    :pswitch_3
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 649
    .line 650
    const-string v0, "it"

    .line 651
    .line 652
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 653
    .line 654
    .line 655
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 656
    .line 657
    if-nez v0, :cond_2a

    .line 658
    .line 659
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 660
    .line 661
    if-eqz v0, :cond_27

    .line 662
    .line 663
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 664
    .line 665
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 666
    .line 667
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/GetMoneyConfigResp;

    .line 668
    .line 669
    iget-object v0, p0, LG9/s;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 670
    .line 671
    iget-object v1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->s0:Ljava/util/ArrayList;

    .line 672
    .line 673
    if-eqz v1, :cond_26

    .line 674
    .line 675
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/GetMoneyConfigResp;->data:Ljava/util/List;

    .line 676
    .line 677
    if-nez p1, :cond_25

    .line 678
    .line 679
    new-instance p1, Ljava/util/ArrayList;

    .line 680
    .line 681
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 682
    .line 683
    .line 684
    :cond_25
    check-cast p1, Ljava/util/Collection;

    .line 685
    .line 686
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 687
    .line 688
    .line 689
    :cond_26
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->o:Lxf/t;

    .line 690
    .line 691
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 692
    .line 693
    .line 694
    move-result-object p1

    .line 695
    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    .line 696
    .line 697
    if-eqz p1, :cond_2a

    .line 698
    .line 699
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$Adapter;

    .line 700
    .line 701
    .line 702
    move-result-object p1

    .line 703
    if-eqz p1, :cond_2a

    .line 704
    .line 705
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 706
    .line 707
    .line 708
    goto :goto_8

    .line 709
    :cond_27
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 710
    .line 711
    if-eqz v0, :cond_28

    .line 712
    .line 713
    goto :goto_8

    .line 714
    :cond_28
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 715
    .line 716
    if-eqz v0, :cond_29

    .line 717
    .line 718
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 719
    .line 720
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 721
    .line 722
    const/4 v0, 0x0

    .line 723
    new-array v0, v0, [Ljava/lang/Object;

    .line 724
    .line 725
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 726
    .line 727
    .line 728
    goto :goto_8

    .line 729
    :cond_29
    new-instance p1, Lxf/l;

    .line 730
    .line 731
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 732
    .line 733
    .line 734
    throw p1

    .line 735
    :cond_2a
    :goto_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 736
    .line 737
    return-object p1

    .line 738
    nop

    .line 739
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
