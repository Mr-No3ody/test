.class public final LG9/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/l;->a:I

    iput-object p1, p0, LG9/l;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, LG9/l;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "it"

    .line 5
    .line 6
    iget v3, p0, LG9/l;->a:I

    .line 7
    .line 8
    packed-switch v3, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 12
    .line 13
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 17
    .line 18
    if-nez v2, :cond_4

    .line 19
    .line 20
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 21
    .line 22
    if-eqz v2, :cond_2

    .line 23
    .line 24
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 25
    .line 26
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/WithdrawalMenuRsp;

    .line 29
    .line 30
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-eqz v2, :cond_4

    .line 35
    .line 36
    iget-object v2, p1, Lcom/transsnet/palmpay/core/bean/rsp/WithdrawalMenuRsp;->data:Ljava/util/List;

    .line 37
    .line 38
    if-eqz v2, :cond_4

    .line 39
    .line 40
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    if-eqz v2, :cond_0

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_0
    iget-object v2, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->H:Lxf/t;

    .line 48
    .line 49
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    check-cast v2, Landroid/view/View;

    .line 54
    .line 55
    if-eqz v2, :cond_1

    .line 56
    .line 57
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 58
    .line 59
    .line 60
    :cond_1
    iget-object v0, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->k0:Lxf/t;

    .line 61
    .line 62
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    check-cast v0, LE9/f;

    .line 67
    .line 68
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/WithdrawalMenuRsp;->data:Ljava/util/List;

    .line 69
    .line 70
    check-cast p1, Ljava/util/Collection;

    .line 71
    .line 72
    invoke-virtual {v0, p1}, LM1/j;->setList(Ljava/util/Collection;)V

    .line 73
    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_2
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 77
    .line 78
    if-nez v0, :cond_4

    .line 79
    .line 80
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 81
    .line 82
    if-eqz v0, :cond_3

    .line 83
    .line 84
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 85
    .line 86
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 87
    .line 88
    new-array v0, v1, [Ljava/lang/Object;

    .line 89
    .line 90
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_3
    new-instance p1, Lxf/l;

    .line 95
    .line 96
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 97
    .line 98
    .line 99
    throw p1

    .line 100
    :cond_4
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 101
    .line 102
    return-object p1

    .line 103
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 104
    .line 105
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 109
    .line 110
    if-nez v2, :cond_b

    .line 111
    .line 112
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 113
    .line 114
    if-eqz v2, :cond_9

    .line 115
    .line 116
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 117
    .line 118
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 121
    .line 122
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 123
    .line 124
    .line 125
    move-result v2

    .line 126
    if-eqz v2, :cond_8

    .line 127
    .line 128
    iget-object v2, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 129
    .line 130
    if-eqz v2, :cond_6

    .line 131
    .line 132
    check-cast v2, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp;

    .line 133
    .line 134
    iget-object v2, v2, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp;->nearbyShopList:Ljava/util/List;

    .line 135
    .line 136
    check-cast v2, Ljava/util/Collection;

    .line 137
    .line 138
    if-eqz v2, :cond_6

    .line 139
    .line 140
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 141
    .line 142
    .line 143
    move-result v2

    .line 144
    if-eqz v2, :cond_5

    .line 145
    .line 146
    goto :goto_1

    .line 147
    :cond_5
    iget-object v2, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->C:Lxf/t;

    .line 148
    .line 149
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v2

    .line 153
    check-cast v2, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 154
    .line 155
    if-eqz v2, :cond_6

    .line 156
    .line 157
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 158
    .line 159
    .line 160
    :cond_6
    :goto_1
    iget-object v2, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->H:Lxf/t;

    .line 161
    .line 162
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v2

    .line 166
    check-cast v2, Landroid/view/View;

    .line 167
    .line 168
    if-eqz v2, :cond_7

    .line 169
    .line 170
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 171
    .line 172
    .line 173
    :cond_7
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->v()LE9/g;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 178
    .line 179
    check-cast p1, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp;

    .line 180
    .line 181
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp;->nearbyShopList:Ljava/util/List;

    .line 182
    .line 183
    check-cast p1, Ljava/util/Collection;

    .line 184
    .line 185
    invoke-virtual {v0, p1}, LM1/j;->setList(Ljava/util/Collection;)V

    .line 186
    .line 187
    .line 188
    goto :goto_2

    .line 189
    :cond_8
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    new-array v0, v1, [Ljava/lang/Object;

    .line 194
    .line 195
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 196
    .line 197
    .line 198
    goto :goto_2

    .line 199
    :cond_9
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 200
    .line 201
    if-nez v0, :cond_b

    .line 202
    .line 203
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 204
    .line 205
    if-eqz v0, :cond_a

    .line 206
    .line 207
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 208
    .line 209
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 210
    .line 211
    new-array v0, v1, [Ljava/lang/Object;

    .line 212
    .line 213
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    goto :goto_2

    .line 217
    :cond_a
    new-instance p1, Lxf/l;

    .line 218
    .line 219
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 220
    .line 221
    .line 222
    throw p1

    .line 223
    :cond_b
    :goto_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 224
    .line 225
    return-object p1

    .line 226
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 227
    .line 228
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 232
    .line 233
    if-nez v2, :cond_12

    .line 234
    .line 235
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 236
    .line 237
    if-eqz v2, :cond_10

    .line 238
    .line 239
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 240
    .line 241
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 242
    .line 243
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp;

    .line 244
    .line 245
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 246
    .line 247
    .line 248
    move-result v2

    .line 249
    if-eqz v2, :cond_f

    .line 250
    .line 251
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp;->getData()Ljava/util/List;

    .line 252
    .line 253
    .line 254
    move-result-object v2

    .line 255
    iget-object v3, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->w:Lxf/t;

    .line 256
    .line 257
    if-eqz v2, :cond_e

    .line 258
    .line 259
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp;->getData()Ljava/util/List;

    .line 260
    .line 261
    .line 262
    move-result-object v2

    .line 263
    if-eqz v2, :cond_c

    .line 264
    .line 265
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 266
    .line 267
    .line 268
    move-result v2

    .line 269
    const/4 v4, 0x1

    .line 270
    if-ne v2, v4, :cond_c

    .line 271
    .line 272
    goto :goto_3

    .line 273
    :cond_c
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 274
    .line 275
    iget-object v2, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->Z:Lxf/t;

    .line 276
    .line 277
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 278
    .line 279
    .line 280
    move-result-object v2

    .line 281
    check-cast v2, LE9/i;

    .line 282
    .line 283
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp;->getData()Ljava/util/List;

    .line 284
    .line 285
    .line 286
    move-result-object p1

    .line 287
    check-cast p1, Ljava/util/Collection;

    .line 288
    .line 289
    invoke-virtual {v2, p1}, LM1/j;->setList(Ljava/util/Collection;)V

    .line 290
    .line 291
    .line 292
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->H:Lxf/t;

    .line 293
    .line 294
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 295
    .line 296
    .line 297
    move-result-object p1

    .line 298
    check-cast p1, Landroid/view/View;

    .line 299
    .line 300
    if-eqz p1, :cond_d

    .line 301
    .line 302
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 303
    .line 304
    .line 305
    :cond_d
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 306
    .line 307
    .line 308
    move-result-object p1

    .line 309
    check-cast p1, Landroid/widget/LinearLayout;

    .line 310
    .line 311
    if-eqz p1, :cond_12

    .line 312
    .line 313
    invoke-static {p1}, Loa/h;->C(Landroid/view/View;)V

    .line 314
    .line 315
    .line 316
    goto :goto_4

    .line 317
    :cond_e
    :goto_3
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    move-result-object p1

    .line 321
    check-cast p1, Landroid/widget/LinearLayout;

    .line 322
    .line 323
    if-eqz p1, :cond_12

    .line 324
    .line 325
    const/16 v0, 0x8

    .line 326
    .line 327
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 328
    .line 329
    .line 330
    goto :goto_4

    .line 331
    :cond_f
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object p1

    .line 335
    new-array v0, v1, [Ljava/lang/Object;

    .line 336
    .line 337
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    goto :goto_4

    .line 341
    :cond_10
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 342
    .line 343
    if-nez v0, :cond_12

    .line 344
    .line 345
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 346
    .line 347
    if-eqz v0, :cond_11

    .line 348
    .line 349
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 350
    .line 351
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 352
    .line 353
    new-array v0, v1, [Ljava/lang/Object;

    .line 354
    .line 355
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 356
    .line 357
    .line 358
    goto :goto_4

    .line 359
    :cond_11
    new-instance p1, Lxf/l;

    .line 360
    .line 361
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 362
    .line 363
    .line 364
    throw p1

    .line 365
    :cond_12
    :goto_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 366
    .line 367
    return-object p1

    .line 368
    nop

    .line 369
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
