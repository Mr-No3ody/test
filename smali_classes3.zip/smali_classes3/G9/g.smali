.class public final synthetic LG9/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/g;->a:I

    iput-object p1, p0, LG9/g;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 3

    .line 1
    iget-object v0, p0, LG9/g;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    .line 2
    .line 3
    const-string v1, "<unused var>"

    .line 4
    .line 5
    iget v2, p0, LG9/g;->a:I

    .line 6
    .line 7
    packed-switch v2, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 11
    .line 12
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->v()LE9/g;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    check-cast p1, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp$NearbyShopListBean;

    .line 27
    .line 28
    iget-object p2, p1, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp$NearbyShopListBean;->transType:Ljava/lang/String;

    .line 29
    .line 30
    iget-object p3, p1, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp$NearbyShopListBean;->memberId:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp$NearbyShopListBean;->networkMobile:Ljava/lang/String;

    .line 33
    .line 34
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/bean/response/NearbyAgentsResp$NearbyShopListBean;->accountNo:Ljava/lang/String;

    .line 35
    .line 36
    invoke-static {p2, p3, v0, p1}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :pswitch_0
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 41
    .line 42
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->k0:Lxf/t;

    .line 49
    .line 50
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    check-cast p1, LE9/f;

    .line 55
    .line 56
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/WithdrawalMenuRsp$WithdrawalMenuBean;

    .line 61
    .line 62
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/WithdrawalMenuRsp$WithdrawalMenuBean;->getLinkAddress()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p2

    .line 66
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 67
    .line 68
    .line 69
    move-result p2

    .line 70
    if-nez p2, :cond_0

    .line 71
    .line 72
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/WithdrawalMenuRsp$WithdrawalMenuBean;->getLinkAddress()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->F(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    :cond_0
    return-void

    .line 80
    :pswitch_1
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 81
    .line 82
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->Z:Lxf/t;

    .line 89
    .line 90
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    check-cast p1, LE9/i;

    .line 95
    .line 96
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp$Data;

    .line 101
    .line 102
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp$Data;->getTransType()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p2

    .line 106
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp$Data;->getMerchantMemberId()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object p3

    .line 110
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp$Data;->getPhone()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryRecentlyMerchantResp$Data;->getSnNo()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    invoke-static {p2, p3, v0, p1}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    return-void

    .line 122
    nop

    .line 123
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
