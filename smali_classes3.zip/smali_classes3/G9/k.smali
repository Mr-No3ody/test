.class public final LG9/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG9/k;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    .line 5
    .line 6
    return-void
.end method
