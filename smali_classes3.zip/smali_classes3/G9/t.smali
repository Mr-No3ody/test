.class public final LG9/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog$CallBack;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG9/t;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onAddBankcardClick()V
    .locals 3

    .line 1
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "/coreImpl/bind_new_bank_account"

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const-string v1, "extra_type"

    .line 12
    .line 13
    const/4 v2, 0x2

    .line 14
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, LG9/t;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 22
    .line 23
    iget-object v0, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Z:Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;

    .line 24
    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 28
    .line 29
    .line 30
    :cond_0
    return-void
.end method

.method public final onChooseBankClick(Lcom/transsnet/palmpay/core/bean/BankCardInfo;)V
    .locals 1

    .line 1
    iget-object v0, p0, LG9/t;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 2
    .line 3
    iput-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->X:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 4
    .line 5
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->t(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;Lcom/transsnet/palmpay/core/bean/BankCardInfo;)V

    .line 6
    .line 7
    .line 8
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Z:Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;

    .line 9
    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void
.end method
