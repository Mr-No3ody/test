.class public final LG9/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/model/OrderResultCustomerServiceModel$OnCustomerServiceModelListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG9/f;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onLeftClick(Landroid/view/View;)V
    .locals 8

    .line 1
    const-string v0, "v"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LG9/f;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;

    .line 7
    .line 8
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object v1, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    goto/16 :goto_a

    .line 18
    .line 19
    :cond_0
    new-instance v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;

    .line 20
    .line 21
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;-><init>()V

    .line 22
    .line 23
    .line 24
    sget v3, Lba/k;->core_fund:I

    .line 25
    .line 26
    invoke-virtual {p1, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->paymentType:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v3, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 33
    .line 34
    const-wide/16 v4, 0x0

    .line 35
    .line 36
    if-eqz v3, :cond_1

    .line 37
    .line 38
    iget-wide v6, v3, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->createTime:J

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    move-wide v6, v4

    .line 42
    :goto_0
    iput-wide v6, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->time:J

    .line 43
    .line 44
    if-eqz v3, :cond_2

    .line 45
    .line 46
    iget-wide v6, v3, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->businessAmount:J

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_2
    move-wide v6, v4

    .line 50
    :goto_1
    iput-wide v6, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->amount:J

    .line 51
    .line 52
    if-eqz v3, :cond_3

    .line 53
    .line 54
    iget-wide v6, v3, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->payFee:J

    .line 55
    .line 56
    goto :goto_2

    .line 57
    :cond_3
    move-wide v6, v4

    .line 58
    :goto_2
    iput-wide v6, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->fee:J

    .line 59
    .line 60
    if-eqz v3, :cond_4

    .line 61
    .line 62
    iget-object v3, v3, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderNo:Ljava/lang/String;

    .line 63
    .line 64
    goto :goto_3

    .line 65
    :cond_4
    move-object v3, v2

    .line 66
    :goto_3
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->orderNumber:Ljava/lang/String;

    .line 67
    .line 68
    invoke-virtual {p1}, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->u()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    if-eqz v3, :cond_5

    .line 73
    .line 74
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusTv()Landroid/widget/TextView;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    if-eqz v3, :cond_5

    .line 79
    .line 80
    invoke-virtual {v3}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    goto :goto_4

    .line 85
    :cond_5
    move-object v3, v2

    .line 86
    :goto_4
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->orderStatus:Ljava/lang/String;

    .line 91
    .line 92
    iget-object v3, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 93
    .line 94
    if-eqz v3, :cond_6

    .line 95
    .line 96
    iget-wide v6, v3, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->vat:J

    .line 97
    .line 98
    goto :goto_5

    .line 99
    :cond_6
    move-wide v6, v4

    .line 100
    :goto_5
    iput-wide v6, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->vat:J

    .line 101
    .line 102
    if-eqz v3, :cond_7

    .line 103
    .line 104
    iget-wide v6, v3, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->redeemPoint:J

    .line 105
    .line 106
    goto :goto_6

    .line 107
    :cond_7
    move-wide v6, v4

    .line 108
    :goto_6
    iput-wide v6, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->pointsUsed:J

    .line 109
    .line 110
    if-eqz v3, :cond_8

    .line 111
    .line 112
    iget-wide v4, v3, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->returnPoint:J

    .line 113
    .line 114
    :cond_8
    iput-wide v4, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->pointsEarned:J

    .line 115
    .line 116
    if-eqz v3, :cond_9

    .line 117
    .line 118
    iget-object v3, v3, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->transType:Ljava/lang/String;

    .line 119
    .line 120
    goto :goto_7

    .line 121
    :cond_9
    move-object v3, v2

    .line 122
    :goto_7
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->transType:Ljava/lang/String;

    .line 123
    .line 124
    iget-object v3, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->Q:Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 125
    .line 126
    if-eqz v3, :cond_a

    .line 127
    .line 128
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;->getItemValueTv()Landroid/widget/TextView;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    if-eqz v3, :cond_a

    .line 133
    .line 134
    invoke-virtual {v3}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 135
    .line 136
    .line 137
    move-result-object v3

    .line 138
    goto :goto_8

    .line 139
    :cond_a
    move-object v3, v2

    .line 140
    :goto_8
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v3

    .line 144
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->paymentMethod:Ljava/lang/String;

    .line 145
    .line 146
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 147
    .line 148
    if-eqz p1, :cond_b

    .line 149
    .line 150
    iget-object v3, p1, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 151
    .line 152
    goto :goto_9

    .line 153
    :cond_b
    move-object v3, v2

    .line 154
    :goto_9
    if-eqz v3, :cond_d

    .line 155
    .line 156
    if-eqz p1, :cond_c

    .line 157
    .line 158
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 159
    .line 160
    if-eqz p1, :cond_c

    .line 161
    .line 162
    iget-object v2, p1, Lcom/transsnet/palmpay/core/bean/BillProcessDetail;->faqLink:Ljava/lang/String;

    .line 163
    .line 164
    :cond_c
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->faqUrl:Ljava/lang/String;

    .line 165
    .line 166
    :cond_d
    move-object v2, v1

    .line 167
    :goto_a
    invoke-static {v0, v2}, LPa/i0;->M(Landroid/app/Activity;Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;)V

    .line 168
    .line 169
    .line 170
    return-void
.end method

.method public final onRightClick(Landroid/view/View;)V
    .locals 3

    .line 1
    const-string v0, "v"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LG9/f;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;

    .line 7
    .line 8
    iget-object v0, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 9
    .line 10
    if-eqz v0, :cond_2

    .line 11
    .line 12
    iget v0, v0, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->payeeAccountType:I

    .line 13
    .line 14
    iget-object v1, p1, Lcom/transsnet/palmpay/core/base/BaseFragment;->c:Landroidx/fragment/app/E;

    .line 15
    .line 16
    const/4 v2, 0x3

    .line 17
    if-ne v0, v2, :cond_0

    .line 18
    .line 19
    sget v0, Lba/k;->core_money_transfer_bank_account:I

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/16 v2, 0x9

    .line 27
    .line 28
    if-ne v0, v2, :cond_1

    .line 29
    .line 30
    sget v0, Lba/k;->core_money_transfer_mmo:I

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    goto :goto_0

    .line 37
    :cond_1
    sget v0, Lba/k;->core_money_transfer_palmpay:I

    .line 38
    .line 39
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    :goto_0
    const-string v1, "getPaymentType(...)"

    .line 44
    .line 45
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_2
    const-string v0, ""

    .line 50
    .line 51
    :goto_1
    iget-object v1, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 52
    .line 53
    const/4 v2, 0x0

    .line 54
    if-eqz v1, :cond_3

    .line 55
    .line 56
    iget-object v1, v1, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderNo:Ljava/lang/String;

    .line 57
    .line 58
    goto :goto_2

    .line 59
    :cond_3
    move-object v1, v2

    .line 60
    :goto_2
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->Q:Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 61
    .line 62
    if-eqz p1, :cond_4

    .line 63
    .line 64
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;->getItemValueTv()Landroid/widget/TextView;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    if-eqz p1, :cond_4

    .line 69
    .line 70
    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    :cond_4
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-static {p1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    invoke-static {v0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    const-string v2, "2"

    .line 87
    .line 88
    invoke-static {v2, v1, p1, v0}, LPa/i0;->J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    return-void
.end method
