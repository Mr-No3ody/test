.class public final synthetic LG9/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/q;->a:I

    iput-object p1, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LG9/q;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    sget v1, Ly9/b;->ci_bank_account_item:I

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/ModelWithdrawBankaccountItem;

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v0, 0x0

    .line 22
    :goto_0
    return-object v0

    .line 23
    :pswitch_0
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 24
    .line 25
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 26
    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    sget v1, Ly9/b;->ci_add_bank_account:I

    .line 30
    .line 31
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Landroid/widget/RelativeLayout;

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    const/4 v0, 0x0

    .line 39
    :goto_1
    return-object v0

    .line 40
    :pswitch_1
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 41
    .line 42
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 43
    .line 44
    if-eqz v0, :cond_2

    .line 45
    .line 46
    sget v1, Ly9/b;->tvAmountTitle:I

    .line 47
    .line 48
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    check-cast v0, Landroid/widget/TextView;

    .line 53
    .line 54
    goto :goto_2

    .line 55
    :cond_2
    const/4 v0, 0x0

    .line 56
    :goto_2
    return-object v0

    .line 57
    :pswitch_2
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 58
    .line 59
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 60
    .line 61
    if-eqz v0, :cond_3

    .line 62
    .line 63
    sget v1, Ly9/b;->tvAmountUnit:I

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Landroid/widget/TextView;

    .line 70
    .line 71
    goto :goto_3

    .line 72
    :cond_3
    const/4 v0, 0x0

    .line 73
    :goto_3
    return-object v0

    .line 74
    :pswitch_3
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 75
    .line 76
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 77
    .line 78
    if-eqz v0, :cond_4

    .line 79
    .line 80
    sget v1, Ly9/b;->tvTips:I

    .line 81
    .line 82
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    check-cast v0, Landroid/widget/TextView;

    .line 87
    .line 88
    goto :goto_4

    .line 89
    :cond_4
    const/4 v0, 0x0

    .line 90
    :goto_4
    return-object v0

    .line 91
    :pswitch_4
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 92
    .line 93
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 94
    .line 95
    if-eqz v0, :cond_5

    .line 96
    .line 97
    sget v1, Ly9/b;->etAmount:I

    .line 98
    .line 99
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    check-cast v0, Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 104
    .line 105
    goto :goto_5

    .line 106
    :cond_5
    const/4 v0, 0x0

    .line 107
    :goto_5
    return-object v0

    .line 108
    :pswitch_5
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 109
    .line 110
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 111
    .line 112
    if-eqz v0, :cond_6

    .line 113
    .line 114
    sget v1, Ly9/b;->balance_tv:I

    .line 115
    .line 116
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    check-cast v0, Landroid/widget/TextView;

    .line 121
    .line 122
    goto :goto_6

    .line 123
    :cond_6
    const/4 v0, 0x0

    .line 124
    :goto_6
    return-object v0

    .line 125
    :pswitch_6
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 126
    .line 127
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 128
    .line 129
    if-eqz v0, :cond_7

    .line 130
    .line 131
    sget v1, Ly9/b;->rvMoneyList:I

    .line 132
    .line 133
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 138
    .line 139
    goto :goto_7

    .line 140
    :cond_7
    const/4 v0, 0x0

    .line 141
    :goto_7
    return-object v0

    .line 142
    :pswitch_7
    new-instance v0, Landroidx/camera/video/internal/c;

    .line 143
    .line 144
    iget-object v1, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 145
    .line 146
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    const-string v2, "requireActivity(...)"

    .line 151
    .line 152
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    invoke-direct {v0, v1}, Landroidx/camera/video/internal/c;-><init>(Landroidx/lifecycle/ViewModelStoreOwner;)V

    .line 156
    .line 157
    .line 158
    const-class v1, Lcom/transsnet/palmpay/cash_in/ui/viewmodel/WithdrawHomeViewModel;

    .line 159
    .line 160
    invoke-virtual {v0, v1}, Landroidx/camera/video/internal/c;->h(Ljava/lang/Class;)Landroidx/lifecycle/a0;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    check-cast v0, Lcom/transsnet/palmpay/cash_in/ui/viewmodel/WithdrawHomeViewModel;

    .line 165
    .line 166
    return-object v0

    .line 167
    :pswitch_8
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 168
    .line 169
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 170
    .line 171
    if-eqz v0, :cond_8

    .line 172
    .line 173
    sget v1, Ly9/b;->viewNotice:I

    .line 174
    .line 175
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    check-cast v0, Lcom/transsnet/adsdk/widgets/MarqueeTextView/MarqueeView;

    .line 180
    .line 181
    goto :goto_8

    .line 182
    :cond_8
    const/4 v0, 0x0

    .line 183
    :goto_8
    return-object v0

    .line 184
    :pswitch_9
    iget-object v0, p0, LG9/q;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 185
    .line 186
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 187
    .line 188
    if-eqz v0, :cond_9

    .line 189
    .line 190
    sget v1, Ly9/b;->keyboard_view:I

    .line 191
    .line 192
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    check-cast v0, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 197
    .line 198
    goto :goto_9

    .line 199
    :cond_9
    const/4 v0, 0x0

    .line 200
    :goto_9
    return-object v0

    .line 201
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
