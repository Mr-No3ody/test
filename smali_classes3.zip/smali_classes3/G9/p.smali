.class public final LG9/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/model/OrderResultCustomerServiceModel$OnCustomerServiceModelListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG9/p;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onLeftClick(Landroid/view/View;)V
    .locals 5

    .line 1
    const-string v0, "v"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LG9/p;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;

    .line 7
    .line 8
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    new-instance v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;

    .line 16
    .line 17
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;-><init>()V

    .line 18
    .line 19
    .line 20
    iget-object v2, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;->v:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 21
    .line 22
    if-eqz v2, :cond_1

    .line 23
    .line 24
    sget v3, Lba/k;->core_withdraw:I

    .line 25
    .line 26
    invoke-virtual {p1, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->paymentType:Ljava/lang/String;

    .line 31
    .line 32
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->createTime:J

    .line 33
    .line 34
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->time:J

    .line 35
    .line 36
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->businessAmount:J

    .line 37
    .line 38
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->amount:J

    .line 39
    .line 40
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->payFee:J

    .line 41
    .line 42
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->fee:J

    .line 43
    .line 44
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderNo:Ljava/lang/String;

    .line 45
    .line 46
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->orderNumber:Ljava/lang/String;

    .line 47
    .line 48
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderStatusDesc:Ljava/lang/String;

    .line 49
    .line 50
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->orderStatus:Ljava/lang/String;

    .line 51
    .line 52
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->vat:J

    .line 53
    .line 54
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->vat:J

    .line 55
    .line 56
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->redeemPoint:J

    .line 57
    .line 58
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->pointsUsed:J

    .line 59
    .line 60
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->returnPoint:J

    .line 61
    .line 62
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->pointsEarned:J

    .line 63
    .line 64
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 65
    .line 66
    if-eqz p1, :cond_0

    .line 67
    .line 68
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/BillProcessDetail;->faqLink:Ljava/lang/String;

    .line 69
    .line 70
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->faqUrl:Ljava/lang/String;

    .line 71
    .line 72
    :cond_0
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->transType:Ljava/lang/String;

    .line 73
    .line 74
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->transType:Ljava/lang/String;

    .line 75
    .line 76
    :cond_1
    invoke-static {v0, v1}, LPa/i0;->M(Landroid/app/Activity;Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;)V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public final onRightClick(Landroid/view/View;)V
    .locals 3

    .line 1
    const-string v0, "v"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LG9/p;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;

    .line 7
    .line 8
    iget-object v0, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawRecordDetailFragment;->v:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, v0, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderNo:Ljava/lang/String;

    .line 13
    .line 14
    sget v1, Lba/k;->core_palmpay_payment_name:I

    .line 15
    .line 16
    invoke-virtual {p1, v1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    const-string v1, "Withdraw"

    .line 21
    .line 22
    const-string v2, "3"

    .line 23
    .line 24
    invoke-static {v2, v0, p1, v1}, LPa/i0;->J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    return-void
.end method
