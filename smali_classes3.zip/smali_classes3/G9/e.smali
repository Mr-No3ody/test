.class public final synthetic LG9/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/e;->a:I

    iput-object p1, p0, LG9/e;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    iget-object v0, p0, LG9/e;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;

    .line 2
    .line 3
    iget v1, p0, LG9/e;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget-object v1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->X:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment$a;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    sget v1, Ly9/b;->cffd_share_receipt:I

    .line 15
    .line 16
    if-ne p1, v1, :cond_a

    .line 17
    .line 18
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 19
    .line 20
    if-nez p1, :cond_0

    .line 21
    .line 22
    goto/16 :goto_8

    .line 23
    .line 24
    :cond_0
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    new-instance v1, LN9/f;

    .line 33
    .line 34
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 35
    .line 36
    .line 37
    iget-object v2, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 38
    .line 39
    const/4 v3, 0x0

    .line 40
    if-eqz v2, :cond_1

    .line 41
    .line 42
    iget-object v2, v2, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderNo:Ljava/lang/String;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    move-object v2, v3

    .line 46
    :goto_0
    iput-object v2, v1, LN9/f;->a:Ljava/lang/String;

    .line 47
    .line 48
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/db/entity/User;->getFirstName()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    iput-object v2, v1, LN9/f;->b:Ljava/lang/String;

    .line 53
    .line 54
    const-string v2, ""

    .line 55
    .line 56
    iput-object v2, v1, LN9/f;->c:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v4, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 59
    .line 60
    if-eqz v4, :cond_2

    .line 61
    .line 62
    iget-wide v4, v4, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->successTime:J

    .line 63
    .line 64
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    goto :goto_1

    .line 69
    :cond_2
    move-object v4, v3

    .line 70
    :goto_1
    iput-object v4, v1, LN9/f;->d:Ljava/lang/Long;

    .line 71
    .line 72
    iget-object v4, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 73
    .line 74
    if-eqz v4, :cond_3

    .line 75
    .line 76
    iget-wide v4, v4, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->totalAmount:J

    .line 77
    .line 78
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    goto :goto_2

    .line 83
    :cond_3
    move-object v4, v3

    .line 84
    :goto_2
    iput-object v4, v1, LN9/f;->e:Ljava/lang/Long;

    .line 85
    .line 86
    iget-object v4, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->M:Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 87
    .line 88
    if-eqz v4, :cond_4

    .line 89
    .line 90
    invoke-virtual {v4}, Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;->getItemValueTv()Landroid/widget/TextView;

    .line 91
    .line 92
    .line 93
    move-result-object v4

    .line 94
    if-eqz v4, :cond_4

    .line 95
    .line 96
    invoke-virtual {v4}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    goto :goto_3

    .line 101
    :cond_4
    move-object v4, v3

    .line 102
    :goto_3
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v4

    .line 106
    iput-object v4, v1, LN9/f;->f:Ljava/lang/String;

    .line 107
    .line 108
    iget-object v4, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->Q:Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 109
    .line 110
    if-eqz v4, :cond_5

    .line 111
    .line 112
    invoke-virtual {v4}, Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;->getItemValueTv()Landroid/widget/TextView;

    .line 113
    .line 114
    .line 115
    move-result-object v4

    .line 116
    if-eqz v4, :cond_5

    .line 117
    .line 118
    invoke-virtual {v4}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 119
    .line 120
    .line 121
    move-result-object v4

    .line 122
    goto :goto_4

    .line 123
    :cond_5
    move-object v4, v3

    .line 124
    :goto_4
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v4

    .line 128
    iput-object v4, v1, LN9/f;->g:Ljava/lang/String;

    .line 129
    .line 130
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/db/entity/User;->getFirstName()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    iput-object p1, v1, LN9/f;->h:Ljava/lang/String;

    .line 135
    .line 136
    iput-object v2, v1, LN9/f;->i:Ljava/lang/String;

    .line 137
    .line 138
    iput-object v2, v1, LN9/f;->j:Ljava/lang/String;

    .line 139
    .line 140
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 141
    .line 142
    if-eqz p1, :cond_6

    .line 143
    .line 144
    iget-wide v4, p1, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->loyaltyPoint:J

    .line 145
    .line 146
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    goto :goto_5

    .line 151
    :cond_6
    move-object p1, v3

    .line 152
    :goto_5
    iput-object p1, v1, LN9/f;->k:Ljava/lang/Long;

    .line 153
    .line 154
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 155
    .line 156
    if-eqz p1, :cond_7

    .line 157
    .line 158
    iget-wide v4, p1, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->payFee:J

    .line 159
    .line 160
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    goto :goto_6

    .line 165
    :cond_7
    move-object p1, v3

    .line 166
    :goto_6
    iput-object p1, v1, LN9/f;->l:Ljava/lang/Long;

    .line 167
    .line 168
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 169
    .line 170
    if-eqz p1, :cond_8

    .line 171
    .line 172
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->remark:Ljava/lang/String;

    .line 173
    .line 174
    goto :goto_7

    .line 175
    :cond_8
    move-object p1, v3

    .line 176
    :goto_7
    iput-object p1, v1, LN9/f;->m:Ljava/lang/String;

    .line 177
    .line 178
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->u()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    if-eqz p1, :cond_9

    .line 183
    .line 184
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusTv()Landroid/widget/TextView;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    if-eqz p1, :cond_9

    .line 189
    .line 190
    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 191
    .line 192
    .line 193
    move-result-object v3

    .line 194
    :cond_9
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    iput-object p1, v1, LN9/f;->n:Ljava/lang/String;

    .line 199
    .line 200
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 201
    .line 202
    .line 203
    move-result-object p1

    .line 204
    invoke-virtual {v1, p1}, LN9/f;->a(Landroid/content/Context;)V

    .line 205
    .line 206
    .line 207
    :cond_a
    :goto_8
    return-void

    .line 208
    :pswitch_0
    iget-object p1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->H:Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 209
    .line 210
    if-eqz p1, :cond_b

    .line 211
    .line 212
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    const-string v1, "/cash_in_out/trans_receipt"

    .line 217
    .line 218
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    const-string v1, "transType"

    .line 223
    .line 224
    iget-object v2, p1, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->transType:Ljava/lang/String;

    .line 225
    .line 226
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    const-string v1, "orderId"

    .line 231
    .line 232
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderNo:Ljava/lang/String;

    .line 233
    .line 234
    invoke-virtual {v0, v1, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 235
    .line 236
    .line 237
    move-result-object p1

    .line 238
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    :cond_b
    return-void

    .line 242
    nop

    .line 243
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
