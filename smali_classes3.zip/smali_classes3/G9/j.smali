.class public final synthetic LG9/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LG9/j;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    iget v2, p0, LG9/j;->a:I

    .line 4
    .line 5
    packed-switch v2, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 9
    .line 10
    iget-object v0, v0, Landroidx/camera/video/internal/c;->d:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 13
    .line 14
    invoke-interface {v0}, Lcom/transsnet/palmpay/core/network/api/AccountApiService;->queryPaymentMethod()Ldf/d;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 20
    .line 21
    return-object v0

    .line 22
    :pswitch_1
    new-instance v0, Ljava/util/ArrayList;

    .line 23
    .line 24
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 25
    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_2
    const/high16 v0, 0x41600000    # 14.0f

    .line 29
    .line 30
    invoke-static {v0}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0

    .line 39
    :pswitch_3
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 40
    .line 41
    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 42
    .line 43
    .line 44
    return-object v0

    .line 45
    :pswitch_4
    new-instance v0, Lcom/transsnet/palmpay/core/ui/fragment/verify/CheckSafetyAssessmentQADialogFragment;

    .line 46
    .line 47
    invoke-direct {v0}, Lcom/transsnet/palmpay/core/ui/fragment/verify/CheckSafetyAssessmentQADialogFragment;-><init>()V

    .line 48
    .line 49
    .line 50
    return-object v0

    .line 51
    :pswitch_5
    new-instance v0, Lze/k;

    .line 52
    .line 53
    sget v2, LAc/f;->main_item_saving_target:I

    .line 54
    .line 55
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 56
    .line 57
    .line 58
    return-object v0

    .line 59
    :pswitch_6
    new-instance v0, Lze/j;

    .line 60
    .line 61
    sget v2, LAc/f;->main_item_saving_target_h:I

    .line 62
    .line 63
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 64
    .line 65
    .line 66
    return-object v0

    .line 67
    :pswitch_7
    new-instance v0, Lze/i;

    .line 68
    .line 69
    sget v2, LAc/f;->main_item_saving_stock:I

    .line 70
    .line 71
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 72
    .line 73
    .line 74
    return-object v0

    .line 75
    :pswitch_8
    new-instance v0, Lze/c;

    .line 76
    .line 77
    sget v2, LAc/f;->main_item_saving_comment:I

    .line 78
    .line 79
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 80
    .line 81
    .line 82
    return-object v0

    .line 83
    :pswitch_9
    new-instance v0, Lze/f;

    .line 84
    .line 85
    sget v2, LAc/f;->main_item_saving_insurance:I

    .line 86
    .line 87
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 88
    .line 89
    .line 90
    return-object v0

    .line 91
    :pswitch_a
    new-instance v0, Lze/e;

    .line 92
    .line 93
    sget v2, LAc/f;->main_item_saving_fund:I

    .line 94
    .line 95
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 96
    .line 97
    .line 98
    return-object v0

    .line 99
    :pswitch_b
    new-instance v1, Lze/d;

    .line 100
    .line 101
    invoke-direct {v1, v0}, Lze/d;-><init>(I)V

    .line 102
    .line 103
    .line 104
    return-object v1

    .line 105
    :pswitch_c
    new-instance v0, Lze/d;

    .line 106
    .line 107
    const/4 v1, 0x0

    .line 108
    invoke-direct {v0, v1}, Lze/d;-><init>(I)V

    .line 109
    .line 110
    .line 111
    return-object v0

    .line 112
    :pswitch_d
    new-instance v0, Lxe/a;

    .line 113
    .line 114
    sget v2, LAc/f;->main_new_user_coupon_item_layout:I

    .line 115
    .line 116
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 117
    .line 118
    .line 119
    return-object v0

    .line 120
    :pswitch_e
    sget v0, Lcom/transsnet/palmpay/cash_in/ui/view/BindBankCardProgressModel;->d:I

    .line 121
    .line 122
    new-instance v0, LI9/b;

    .line 123
    .line 124
    sget v2, Ly9/c;->ci_item_bind_bank_card_progress:I

    .line 125
    .line 126
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 127
    .line 128
    .line 129
    return-object v0

    .line 130
    :pswitch_f
    sget v0, Lcom/transsnet/palmpay/ui/view/ModelPremiumBenefits;->i:I

    .line 131
    .line 132
    new-instance v0, Lye/f;

    .line 133
    .line 134
    sget v2, LAc/f;->main_item_premium_benefits_item:I

    .line 135
    .line 136
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 137
    .line 138
    .line 139
    return-object v0

    .line 140
    :pswitch_10
    sget v0, Lcom/transsnet/palmpay/ui/view/ModelPalmPrizeBanner;->e:I

    .line 141
    .line 142
    new-instance v0, Lye/i;

    .line 143
    .line 144
    sget v2, LAc/f;->main_item_reward_palmprize:I

    .line 145
    .line 146
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 147
    .line 148
    .line 149
    return-object v0

    .line 150
    :pswitch_11
    new-instance v0, Landroid/os/Handler;

    .line 151
    .line 152
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 153
    .line 154
    .line 155
    move-result-object v1

    .line 156
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 157
    .line 158
    .line 159
    return-object v0

    .line 160
    :pswitch_12
    new-instance v0, LHb/D;

    .line 161
    .line 162
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 163
    .line 164
    .line 165
    return-object v0

    .line 166
    :pswitch_13
    new-instance v0, Ljava/text/SimpleDateFormat;

    .line 167
    .line 168
    const-string v1, "hh : mm : ss"

    .line 169
    .line 170
    sget-object v2, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 171
    .line 172
    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 173
    .line 174
    .line 175
    return-object v0

    .line 176
    :pswitch_14
    new-instance v0, Landroid/os/Handler;

    .line 177
    .line 178
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 183
    .line 184
    .line 185
    return-object v0

    .line 186
    :pswitch_15
    new-instance v0, Landroid/os/Handler;

    .line 187
    .line 188
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 193
    .line 194
    .line 195
    return-object v0

    .line 196
    :pswitch_16
    sget v0, Lcom/transsnet/palmpay/send_money/ui/view/TransferToPalmPayProgressView;->f:I

    .line 197
    .line 198
    new-instance v0, LGd/B;

    .line 199
    .line 200
    sget v2, Lkd/f;->sm_item_transfer_to_palmpay_progress:I

    .line 201
    .line 202
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 203
    .line 204
    .line 205
    return-object v0

    .line 206
    :pswitch_17
    sget v0, Lcom/transsnet/palmpay/send_money/ui/view/TransferToFastTransferSafeguardProgressModel;->t:I

    .line 207
    .line 208
    new-instance v0, LGd/w;

    .line 209
    .line 210
    sget v2, Lkd/f;->sm_item_transfer_fast_refund_progress:I

    .line 211
    .line 212
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 213
    .line 214
    .line 215
    return-object v0

    .line 216
    :pswitch_18
    sget v2, Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankProgressModel;->i:I

    .line 217
    .line 218
    new-instance v2, LGd/t;

    .line 219
    .line 220
    sget v3, Lkd/f;->sm_item_transfer_header_progress:I

    .line 221
    .line 222
    invoke-direct {v2, v3, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 223
    .line 224
    .line 225
    iput-boolean v0, v2, LGd/t;->a:Z

    .line 226
    .line 227
    return-object v2

    .line 228
    :pswitch_19
    sget v0, Lcom/transsnet/palmpay/send_money/ui/view/TransferDetailQuestionView;->b:I

    .line 229
    .line 230
    new-instance v0, LGd/d;

    .line 231
    .line 232
    sget v2, Lkd/f;->sm_item_transfer_detail_question:I

    .line 233
    .line 234
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 235
    .line 236
    .line 237
    return-object v0

    .line 238
    :pswitch_1a
    sget v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 239
    .line 240
    new-instance v0, LE9/g;

    .line 241
    .line 242
    invoke-direct {v0}, LE9/g;-><init>()V

    .line 243
    .line 244
    .line 245
    return-object v0

    .line 246
    :pswitch_1b
    sget v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 247
    .line 248
    new-instance v0, LE9/f;

    .line 249
    .line 250
    sget v2, Ly9/c;->cash_in_item_withdraw_menu:I

    .line 251
    .line 252
    invoke-direct {v0, v2, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 253
    .line 254
    .line 255
    return-object v0

    .line 256
    :pswitch_1c
    sget v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 257
    .line 258
    new-instance v0, LE9/i;

    .line 259
    .line 260
    invoke-direct {v0}, LE9/i;-><init>()V

    .line 261
    .line 262
    .line 263
    return-object v0

    .line 264
    nop

    .line 265
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
