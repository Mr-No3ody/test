.class public final LG9/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/model/OrderResultCustomerServiceModel$OnCustomerServiceModelListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG9/c;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onLeftClick(Landroid/view/View;)V
    .locals 5

    .line 1
    const-string v0, "v"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LG9/c;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;

    .line 7
    .line 8
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    new-instance v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;

    .line 16
    .line 17
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;-><init>()V

    .line 18
    .line 19
    .line 20
    iget-object v2, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->B:Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;

    .line 21
    .line 22
    if-eqz v2, :cond_1

    .line 23
    .line 24
    sget v3, Lba/k;->core_fund:I

    .line 25
    .line 26
    invoke-virtual {p1, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->paymentType:Ljava/lang/String;

    .line 31
    .line 32
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->createTime:J

    .line 33
    .line 34
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->time:J

    .line 35
    .line 36
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->amount:J

    .line 37
    .line 38
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->amount:J

    .line 39
    .line 40
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->payFee:J

    .line 41
    .line 42
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->fee:J

    .line 43
    .line 44
    iget-object v3, v2, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->orderId:Ljava/lang/String;

    .line 45
    .line 46
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->orderNumber:Ljava/lang/String;

    .line 47
    .line 48
    invoke-virtual {p1}, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    if-eqz v3, :cond_0

    .line 53
    .line 54
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusTv()Landroid/widget/TextView;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    if-eqz v3, :cond_0

    .line 59
    .line 60
    invoke-virtual {v3}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 61
    .line 62
    .line 63
    move-result-object v3

    .line 64
    goto :goto_0

    .line 65
    :cond_0
    const/4 v3, 0x0

    .line 66
    :goto_0
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v3

    .line 70
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->orderStatus:Ljava/lang/String;

    .line 71
    .line 72
    iget-wide v3, v2, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->vat:J

    .line 73
    .line 74
    iput-wide v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->vat:J

    .line 75
    .line 76
    iget-object v3, v2, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->transType:Ljava/lang/String;

    .line 77
    .line 78
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->transType:Ljava/lang/String;

    .line 79
    .line 80
    sget v3, Lba/k;->core_palmpay_payment_balance:I

    .line 81
    .line 82
    invoke-virtual {p1, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->paymentMethod:Ljava/lang/String;

    .line 87
    .line 88
    iget-object p1, v2, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 89
    .line 90
    if-eqz p1, :cond_1

    .line 91
    .line 92
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/BillProcessDetail;->faqLink:Ljava/lang/String;

    .line 93
    .line 94
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->faqUrl:Ljava/lang/String;

    .line 95
    .line 96
    :cond_1
    invoke-static {v0, v1}, LPa/i0;->M(Landroid/app/Activity;Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;)V

    .line 97
    .line 98
    .line 99
    return-void
.end method

.method public final onRightClick(Landroid/view/View;)V
    .locals 4

    .line 1
    const-string v0, "v"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LG9/c;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;

    .line 7
    .line 8
    iget-object v0, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->B:Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;

    .line 9
    .line 10
    if-eqz v0, :cond_2

    .line 11
    .line 12
    iget-object v1, v0, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->orderId:Ljava/lang/String;

    .line 13
    .line 14
    sget v2, Lba/k;->core_palmpay_payment_balance:I

    .line 15
    .line 16
    invoke-virtual {p1, v2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-static {v2}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseFragment;->c:Landroidx/fragment/app/E;

    .line 25
    .line 26
    iget v0, v0, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->payeeAccountType:I

    .line 27
    .line 28
    const/4 v3, 0x3

    .line 29
    if-ne v0, v3, :cond_0

    .line 30
    .line 31
    sget v0, Lba/k;->core_money_transfer_bank_account:I

    .line 32
    .line 33
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    const/16 v3, 0x9

    .line 39
    .line 40
    if-ne v0, v3, :cond_1

    .line 41
    .line 42
    sget v0, Lba/k;->core_money_transfer_mmo:I

    .line 43
    .line 44
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    goto :goto_0

    .line 49
    :cond_1
    sget v0, Lba/k;->core_money_transfer_palmpay:I

    .line 50
    .line 51
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    :goto_0
    invoke-static {p1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    const-string v0, "7"

    .line 60
    .line 61
    invoke-static {v0, v1, v2, p1}, LPa/i0;->J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    :cond_2
    return-void
.end method
