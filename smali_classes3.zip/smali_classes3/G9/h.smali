.class public final synthetic LG9/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/h;->a:I

    iput-object p1, p0, LG9/h;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LG9/h;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    .line 3
    .line 4
    iget v2, p0, LG9/h;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 10
    .line 11
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    sget v0, Ly9/b;->viewNotice:I

    .line 16
    .line 17
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Lcom/transsnet/adsdk/widgets/MarqueeTextView/MarqueeView;

    .line 22
    .line 23
    :cond_0
    return-object v0

    .line 24
    :pswitch_0
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 25
    .line 26
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 27
    .line 28
    if-eqz v1, :cond_1

    .line 29
    .line 30
    sget v0, Ly9/b;->tv_account_no:I

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroid/widget/TextView;

    .line 37
    .line 38
    :cond_1
    return-object v0

    .line 39
    :pswitch_1
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 40
    .line 41
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 42
    .line 43
    if-eqz v1, :cond_2

    .line 44
    .line 45
    sget v0, Ly9/b;->ivScan:I

    .line 46
    .line 47
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 52
    .line 53
    :cond_2
    return-object v0

    .line 54
    :pswitch_2
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 55
    .line 56
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 57
    .line 58
    if-eqz v1, :cond_3

    .line 59
    .line 60
    sget v0, Ly9/b;->iv_close:I

    .line 61
    .line 62
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    check-cast v0, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 67
    .line 68
    :cond_3
    return-object v0

    .line 69
    :pswitch_3
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 70
    .line 71
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 72
    .line 73
    if-eqz v1, :cond_4

    .line 74
    .line 75
    sget v0, Ly9/b;->v_line:I

    .line 76
    .line 77
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    :cond_4
    return-object v0

    .line 82
    :pswitch_4
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 83
    .line 84
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 85
    .line 86
    if-eqz v1, :cond_5

    .line 87
    .line 88
    sget v0, Ly9/b;->ll_nearest:I

    .line 89
    .line 90
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 95
    .line 96
    :cond_5
    return-object v0

    .line 97
    :pswitch_5
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 98
    .line 99
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 100
    .line 101
    if-eqz v1, :cond_6

    .line 102
    .line 103
    sget v0, Ly9/b;->tvMore:I

    .line 104
    .line 105
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Landroid/widget/TextView;

    .line 110
    .line 111
    :cond_6
    return-object v0

    .line 112
    :pswitch_6
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 113
    .line 114
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 115
    .line 116
    if-eqz v1, :cond_7

    .line 117
    .line 118
    sget v0, Ly9/b;->rv_nearest:I

    .line 119
    .line 120
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 125
    .line 126
    :cond_7
    return-object v0

    .line 127
    :pswitch_7
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 128
    .line 129
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 130
    .line 131
    if-eqz v1, :cond_8

    .line 132
    .line 133
    sget v0, Ly9/b;->ll_recently:I

    .line 134
    .line 135
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    check-cast v0, Landroid/widget/LinearLayout;

    .line 140
    .line 141
    :cond_8
    return-object v0

    .line 142
    :pswitch_8
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 143
    .line 144
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 145
    .line 146
    if-eqz v1, :cond_9

    .line 147
    .line 148
    sget v0, Ly9/b;->rvRecentLyList:I

    .line 149
    .line 150
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 155
    .line 156
    :cond_9
    return-object v0

    .line 157
    :pswitch_9
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 158
    .line 159
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 160
    .line 161
    if-eqz v1, :cond_a

    .line 162
    .line 163
    sget v0, Ly9/b;->rvMenuList:I

    .line 164
    .line 165
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 170
    .line 171
    :cond_a
    return-object v0

    .line 172
    :pswitch_a
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 173
    .line 174
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 175
    .line 176
    if-eqz v1, :cond_b

    .line 177
    .line 178
    sget v0, Ly9/b;->ll_location_permission:I

    .line 179
    .line 180
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 185
    .line 186
    :cond_b
    return-object v0

    .line 187
    :pswitch_b
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 188
    .line 189
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 190
    .line 191
    if-eqz v1, :cond_c

    .line 192
    .line 193
    sget v0, Ly9/b;->iv_turn_on:I

    .line 194
    .line 195
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    check-cast v0, Landroid/widget/TextView;

    .line 200
    .line 201
    :cond_c
    return-object v0

    .line 202
    :pswitch_c
    sget v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 203
    .line 204
    new-instance v0, LV3/a;

    .line 205
    .line 206
    const/4 v2, 0x4

    .line 207
    invoke-direct {v0, v2}, LV3/a;-><init>(I)V

    .line 208
    .line 209
    .line 210
    new-instance v2, LG9/i;

    .line 211
    .line 212
    const/4 v3, 0x0

    .line 213
    invoke-direct {v2, v1, v3}, LG9/i;-><init>(Ljava/lang/Object;I)V

    .line 214
    .line 215
    .line 216
    invoke-virtual {v1, v0, v2}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Lm/b;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/a;

    .line 217
    .line 218
    .line 219
    move-result-object v0

    .line 220
    return-object v0

    .line 221
    :pswitch_d
    sget v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 222
    .line 223
    new-instance v0, LG9/k;

    .line 224
    .line 225
    invoke-direct {v0, v1}, LG9/k;-><init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;)V

    .line 226
    .line 227
    .line 228
    return-object v0

    .line 229
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
