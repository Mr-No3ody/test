.class public final LG9/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView$DigitalKeyboardClickListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LG9/v;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onActionClick()V
    .locals 14

    .line 1
    iget-object v0, p0, LG9/v;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const-wide/16 v2, 0x0

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/StateAmountEditText;->getDouble()D

    .line 12
    .line 13
    .line 14
    move-result-wide v4

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    move-wide v4, v2

    .line 17
    :goto_0
    invoke-static {v4, v5}, LPa/r0;->f(D)J

    .line 18
    .line 19
    .line 20
    move-result-wide v4

    .line 21
    iput-wide v4, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Q:J

    .line 22
    .line 23
    const-wide/16 v6, 0x0

    .line 24
    .line 25
    cmp-long v1, v4, v6

    .line 26
    .line 27
    const/4 v6, 0x1

    .line 28
    const/4 v7, 0x0

    .line 29
    if-lez v1, :cond_1

    .line 30
    .line 31
    move v1, v6

    .line 32
    goto :goto_1

    .line 33
    :cond_1
    move v1, v7

    .line 34
    :goto_1
    if-nez v1, :cond_2

    .line 35
    .line 36
    const-string v0, "Input error"

    .line 37
    .line 38
    new-array v1, v7, [Ljava/lang/Object;

    .line 39
    .line 40
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_2
    iget-object v1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->X:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 45
    .line 46
    if-nez v1, :cond_3

    .line 47
    .line 48
    const-string v0, "Please Add a withdrawal account"

    .line 49
    .line 50
    new-array v1, v7, [Ljava/lang/Object;

    .line 51
    .line 52
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_3
    iget-wide v8, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->p0:J

    .line 57
    .line 58
    cmp-long v1, v8, v4

    .line 59
    .line 60
    if-gez v1, :cond_4

    .line 61
    .line 62
    sget v1, Ly9/d;->ci_out_of_balance:I

    .line 63
    .line 64
    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    new-array v1, v7, [Ljava/lang/Object;

    .line 69
    .line 70
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :cond_4
    iget-object v1, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->k0:Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;

    .line 75
    .line 76
    if-eqz v1, :cond_6

    .line 77
    .line 78
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMaxAmount()J

    .line 79
    .line 80
    .line 81
    move-result-wide v4

    .line 82
    iget-wide v8, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Q:J

    .line 83
    .line 84
    cmp-long v4, v4, v8

    .line 85
    .line 86
    if-gez v4, :cond_5

    .line 87
    .line 88
    sget v2, Lba/k;->core_msg_amount_below_desc:I

    .line 89
    .line 90
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMaxAmount()J

    .line 91
    .line 92
    .line 93
    move-result-wide v3

    .line 94
    invoke-static {v3, v4, v6}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    invoke-virtual {v0, v2, v1}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    new-array v1, v7, [Ljava/lang/Object;

    .line 107
    .line 108
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    return-void

    .line 112
    :cond_5
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMinAmount()J

    .line 113
    .line 114
    .line 115
    move-result-wide v4

    .line 116
    iget-wide v8, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->Q:J

    .line 117
    .line 118
    cmp-long v4, v4, v8

    .line 119
    .line 120
    if-lez v4, :cond_6

    .line 121
    .line 122
    sget v2, Lba/k;->core_msg_amount_above_desc:I

    .line 123
    .line 124
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMinAmount()J

    .line 125
    .line 126
    .line 127
    move-result-wide v3

    .line 128
    invoke-static {v3, v4, v6}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    invoke-virtual {v0, v2, v1}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    new-array v1, v7, [Ljava/lang/Object;

    .line 141
    .line 142
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    return-void

    .line 146
    :cond_6
    invoke-static {}, LPa/r0;->U0()Z

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    if-nez v1, :cond_b

    .line 151
    .line 152
    new-instance v1, Lcom/transsnet/palmpay/cash_in/bean/request/CreateCashInOutOrderReqV2;

    .line 153
    .line 154
    invoke-direct {v1}, Lcom/transsnet/palmpay/cash_in/bean/request/CreateCashInOutOrderReqV2;-><init>()V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 158
    .line 159
    .line 160
    move-result-object v4

    .line 161
    if-eqz v4, :cond_7

    .line 162
    .line 163
    invoke-virtual {v4}, Lcom/transsnet/palmpay/custom_view/StateAmountEditText;->getDouble()D

    .line 164
    .line 165
    .line 166
    move-result-wide v2

    .line 167
    :cond_7
    invoke-static {v2, v3}, LPa/r0;->f(D)J

    .line 168
    .line 169
    .line 170
    move-result-wide v2

    .line 171
    iput-wide v2, v1, Lcom/transsnet/palmpay/cash_in/bean/request/CreateCashInOutOrderReqV2;->amount:J

    .line 172
    .line 173
    const-string v2, "02"

    .line 174
    .line 175
    iput-object v2, v1, Lcom/transsnet/palmpay/cash_in/bean/request/CreateCashInOutOrderReqV2;->transType:Ljava/lang/String;

    .line 176
    .line 177
    iget-object v2, v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->X:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 178
    .line 179
    new-instance v8, Lcom/transsnet/palmpay/cash_in/bean/request/ExtendField;

    .line 180
    .line 181
    const/4 v12, 0x7

    .line 182
    const/4 v13, 0x0

    .line 183
    const/4 v9, 0x0

    .line 184
    const/4 v10, 0x0

    .line 185
    const/4 v11, 0x0

    .line 186
    invoke-direct/range {v8 .. v13}, Lcom/transsnet/palmpay/cash_in/bean/request/ExtendField;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 187
    .line 188
    .line 189
    const/4 v3, 0x0

    .line 190
    if-eqz v2, :cond_8

    .line 191
    .line 192
    iget-object v4, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->bankCode:Ljava/lang/String;

    .line 193
    .line 194
    goto :goto_2

    .line 195
    :cond_8
    move-object v4, v3

    .line 196
    :goto_2
    iput-object v4, v8, Lcom/transsnet/palmpay/cash_in/bean/request/ExtendField;->payerBankCode:Ljava/lang/String;

    .line 197
    .line 198
    if-eqz v2, :cond_9

    .line 199
    .line 200
    iget-object v4, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->bankAccountNo:Ljava/lang/String;

    .line 201
    .line 202
    goto :goto_3

    .line 203
    :cond_9
    move-object v4, v3

    .line 204
    :goto_3
    iput-object v4, v8, Lcom/transsnet/palmpay/cash_in/bean/request/ExtendField;->payerBankAccNo:Ljava/lang/String;

    .line 205
    .line 206
    if-eqz v2, :cond_a

    .line 207
    .line 208
    iget-object v2, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->bankName:Ljava/lang/String;

    .line 209
    .line 210
    goto :goto_4

    .line 211
    :cond_a
    move-object v2, v3

    .line 212
    :goto_4
    iput-object v2, v8, Lcom/transsnet/palmpay/cash_in/bean/request/ExtendField;->payerBankName:Ljava/lang/String;

    .line 213
    .line 214
    iput-object v8, v1, Lcom/transsnet/palmpay/cash_in/bean/request/CreateCashInOutOrderReqV2;->extendField:Lcom/transsnet/palmpay/cash_in/bean/request/ExtendField;

    .line 215
    .line 216
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 217
    .line 218
    check-cast v0, Lcom/transsnet/palmpay/cash_in/ui/viewmodel/WithdrawViewModel;

    .line 219
    .line 220
    if-eqz v0, :cond_b

    .line 221
    .line 222
    const-string v2, "req"

    .line 223
    .line 224
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    new-instance v2, LJ9/v;

    .line 228
    .line 229
    invoke-direct {v2, v1, v3}, LJ9/v;-><init>(Lcom/transsnet/palmpay/cash_in/bean/request/CreateCashInOutOrderReqV2;Lkotlin/coroutines/Continuation;)V

    .line 230
    .line 231
    .line 232
    const/16 v1, 0x1c

    .line 233
    .line 234
    iget-object v3, v0, Lcom/transsnet/palmpay/cash_in/ui/viewmodel/WithdrawViewModel;->f:Lcom/transsnet/palmpay/core/base/l;

    .line 235
    .line 236
    invoke-static {v0, v2, v3, v7, v1}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 237
    .line 238
    .line 239
    :cond_b
    return-void
.end method

.method public final onDeleteClick()V
    .locals 3

    .line 1
    iget-object v0, p0, LG9/v;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v1}, Landroid/view/View;->isFocused()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-nez v1, :cond_0

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    if-eqz v1, :cond_0

    .line 20
    .line 21
    invoke-virtual {v1}, Landroid/view/View;->requestFocus()Z

    .line 22
    .line 23
    .line 24
    :cond_0
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    if-eqz v1, :cond_1

    .line 29
    .line 30
    invoke-virtual {v1}, Landroidx/appcompat/widget/AppCompatEditText;->getText()Landroid/text/Editable;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    goto :goto_0

    .line 35
    :cond_1
    const/4 v1, 0x0

    .line 36
    :goto_0
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-eqz v0, :cond_2

    .line 41
    .line 42
    invoke-virtual {v0}, Landroid/widget/TextView;->getSelectionStart()I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    goto :goto_1

    .line 47
    :cond_2
    const/4 v0, 0x0

    .line 48
    :goto_1
    if-eqz v1, :cond_3

    .line 49
    .line 50
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-lez v2, :cond_3

    .line 55
    .line 56
    if-lez v0, :cond_3

    .line 57
    .line 58
    add-int/lit8 v2, v0, -0x1

    .line 59
    .line 60
    invoke-interface {v1, v2, v0}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    .line 61
    .line 62
    .line 63
    :cond_3
    return-void
.end method

.method public final onDigitalClick(Ljava/lang/CharSequence;)V
    .locals 2

    .line 1
    const-string v0, "digital"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LG9/v;->a:Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    invoke-virtual {v1}, Landroid/view/View;->isFocused()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    invoke-virtual {v1}, Landroid/view/View;->requestFocus()Z

    .line 27
    .line 28
    .line 29
    :cond_0
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    invoke-virtual {v1}, Landroid/widget/TextView;->getSelectionStart()I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    const/4 v1, 0x0

    .line 41
    :goto_0
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->u()Lcom/transsnet/palmpay/custom_view/StateAmountEditText;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    invoke-virtual {v0}, Landroidx/appcompat/widget/AppCompatEditText;->getText()Landroid/text/Editable;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    invoke-interface {v0, v1, p1}, Landroid/text/Editable;->insert(ILjava/lang/CharSequence;)Landroid/text/Editable;

    .line 54
    .line 55
    .line 56
    :cond_2
    return-void
.end method
