.class public final synthetic LG9/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/r;->a:I

    iput-object p1, p0, LG9/r;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onGlobalLayout()V
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    iget-object v2, p0, LG9/r;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iget v3, p0, LG9/r;->a:I

    .line 6
    .line 7
    packed-switch v3, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    sget v3, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->Q:I

    .line 11
    .line 12
    new-instance v3, Landroid/graphics/Rect;

    .line 13
    .line 14
    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    .line 15
    .line 16
    .line 17
    check-cast v2, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;

    .line 18
    .line 19
    invoke-virtual {v2}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    invoke-virtual {v4}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    invoke-virtual {v4, v3}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    iget v4, v2, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->H:I

    .line 35
    .line 36
    if-nez v4, :cond_0

    .line 37
    .line 38
    iput v3, v2, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->H:I

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    invoke-virtual {v2}, Landroid/app/Activity;->isFinishing()Z

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    if-nez v4, :cond_2

    .line 46
    .line 47
    iget v4, v2, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->H:I

    .line 48
    .line 49
    if-eq v4, v3, :cond_1

    .line 50
    .line 51
    iget-boolean v3, v2, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->L:Z

    .line 52
    .line 53
    if-nez v3, :cond_2

    .line 54
    .line 55
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->q()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 56
    .line 57
    .line 58
    move-result-object v3

    .line 59
    if-eqz v3, :cond_2

    .line 60
    .line 61
    iput-boolean v1, v2, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->L:Z

    .line 62
    .line 63
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->q()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-static {v1, v0}, Loa/h;->s(Landroid/view/View;Z)V

    .line 68
    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_1
    iget-boolean v0, v2, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->L:Z

    .line 72
    .line 73
    if-eqz v0, :cond_2

    .line 74
    .line 75
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->q()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    if-eqz v0, :cond_2

    .line 80
    .line 81
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToBaseActivity;->q()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-static {v0, v1}, Loa/h;->s(Landroid/view/View;Z)V

    .line 86
    .line 87
    .line 88
    :cond_2
    :goto_0
    return-void

    .line 89
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/teller/ui/view/WrapContentViewPager2;->e:I

    .line 90
    .line 91
    check-cast v2, Lcom/transsnet/palmpay/teller/ui/view/WrapContentViewPager2;

    .line 92
    .line 93
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/ui/view/WrapContentViewPager2;->b()V

    .line 94
    .line 95
    .line 96
    return-void

    .line 97
    :pswitch_1
    new-instance v3, Landroid/graphics/Rect;

    .line 98
    .line 99
    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    .line 100
    .line 101
    .line 102
    check-cast v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;

    .line 103
    .line 104
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 105
    .line 106
    .line 107
    move-result-object v4

    .line 108
    if-eqz v4, :cond_3

    .line 109
    .line 110
    invoke-virtual {v4}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    if-eqz v4, :cond_3

    .line 115
    .line 116
    invoke-virtual {v4}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 117
    .line 118
    .line 119
    move-result-object v4

    .line 120
    if-eqz v4, :cond_3

    .line 121
    .line 122
    invoke-virtual {v4, v3}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    .line 123
    .line 124
    .line 125
    :cond_3
    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    .line 126
    .line 127
    .line 128
    move-result v3

    .line 129
    iget v4, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->q0:I

    .line 130
    .line 131
    if-nez v4, :cond_4

    .line 132
    .line 133
    iput v3, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->q0:I

    .line 134
    .line 135
    goto :goto_1

    .line 136
    :cond_4
    iget-object v5, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->j:Lxf/t;

    .line 137
    .line 138
    if-eq v4, v3, :cond_5

    .line 139
    .line 140
    iget-boolean v3, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->r0:Z

    .line 141
    .line 142
    if-nez v3, :cond_6

    .line 143
    .line 144
    iput-boolean v1, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->r0:Z

    .line 145
    .line 146
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    check-cast v1, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 151
    .line 152
    if-eqz v1, :cond_6

    .line 153
    .line 154
    invoke-static {v1, v0}, Loa/h;->s(Landroid/view/View;Z)V

    .line 155
    .line 156
    .line 157
    goto :goto_1

    .line 158
    :cond_5
    iget-boolean v0, v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawV2Fragment;->r0:Z

    .line 159
    .line 160
    if-eqz v0, :cond_6

    .line 161
    .line 162
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    check-cast v0, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 167
    .line 168
    if-eqz v0, :cond_6

    .line 169
    .line 170
    invoke-static {v0, v1}, Loa/h;->s(Landroid/view/View;Z)V

    .line 171
    .line 172
    .line 173
    :cond_6
    :goto_1
    return-void

    .line 174
    nop

    .line 175
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
