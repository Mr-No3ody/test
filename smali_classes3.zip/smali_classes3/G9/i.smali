.class public final synthetic LG9/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/activity/result/ActivityResultCallback;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/i;->a:I

    iput-object p1, p0, LG9/i;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onActivityResult(Ljava/lang/Object;)V
    .locals 31

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    const-string v3, "getValue(...)"

    .line 6
    .line 7
    const-string v4, "android.permission.READ_PHONE_STATE"

    .line 8
    .line 9
    const-string v6, "4"

    .line 10
    .line 11
    const-string v7, "oc_permission_router"

    .line 12
    .line 13
    const-string v8, "iterator(...)"

    .line 14
    .line 15
    const-string v9, "credit"

    .line 16
    .line 17
    const-string v10, "permissions"

    .line 18
    .line 19
    const-string v12, "result"

    .line 20
    .line 21
    const-string v14, "<unused var>"

    .line 22
    .line 23
    const-string v2, "Local Information"

    .line 24
    .line 25
    const-string v11, "android.permission.ACCESS_COARSE_LOCATION"

    .line 26
    .line 27
    const/4 v5, 0x0

    .line 28
    iget-object v13, v1, LG9/i;->b:Ljava/lang/Object;

    .line 29
    .line 30
    iget v15, v1, LG9/i;->a:I

    .line 31
    .line 32
    packed-switch v15, :pswitch_data_0

    .line 33
    .line 34
    .line 35
    check-cast v0, Ljava/util/Map;

    .line 36
    .line 37
    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    check-cast v13, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;

    .line 41
    .line 42
    invoke-virtual {v13, v5}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 43
    .line 44
    .line 45
    new-instance v0, Ljava/util/ArrayList;

    .line 46
    .line 47
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 48
    .line 49
    .line 50
    filled-new-array {v11}, [Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    if-nez v3, :cond_0

    .line 59
    .line 60
    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    :cond_0
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    filled-new-array {v3}, [Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v3

    .line 71
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 72
    .line 73
    .line 74
    move-result v3

    .line 75
    if-nez v3, :cond_1

    .line 76
    .line 77
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    :cond_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-nez v0, :cond_6

    .line 89
    .line 90
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-virtual {v0}, Lya/a;->f()Lcom/transsnet/palmpay/core/bean/LocationRecord;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    if-eqz v0, :cond_2

    .line 99
    .line 100
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLatitude()D

    .line 101
    .line 102
    .line 103
    move-result-wide v2

    .line 104
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLongitude()D

    .line 105
    .line 106
    .line 107
    move-result-wide v4

    .line 108
    goto :goto_0

    .line 109
    :cond_2
    const-wide v2, 0x40c3878000000000L    # 9999.0

    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    move-wide v4, v2

    .line 115
    :goto_0
    new-instance v22, Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;

    .line 116
    .line 117
    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 118
    .line 119
    .line 120
    move-result-object v23

    .line 121
    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 122
    .line 123
    .line 124
    move-result-object v24

    .line 125
    const-string v27, "flexi cash"

    .line 126
    .line 127
    const-string v28, "credit"

    .line 128
    .line 129
    const/16 v25, 0x0

    .line 130
    .line 131
    const/16 v26, 0x0

    .line 132
    .line 133
    const/16 v29, 0xc

    .line 134
    .line 135
    const/16 v30, 0x0

    .line 136
    .line 137
    invoke-direct/range {v22 .. v30}, Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;-><init>(Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 138
    .line 139
    .line 140
    move-object/from16 v0, v22

    .line 141
    .line 142
    sget-object v2, Lob/c;->a:Lob/a;

    .line 143
    .line 144
    invoke-virtual {v2}, Lob/a;->getInstance()Lob/c;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 149
    .line 150
    .line 151
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 152
    .line 153
    .line 154
    move-result-object v3

    .line 155
    invoke-interface {v3, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadLocationInfo(Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;)Ldf/d;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    sget-object v3, Ltf/f;->b:Ldf/i;

    .line 160
    .line 161
    invoke-virtual {v0, v3}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 166
    .line 167
    .line 168
    move-result-object v4

    .line 169
    invoke-virtual {v0, v4}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    new-instance v4, Lzb/m0;

    .line 174
    .line 175
    const/4 v5, 0x4

    .line 176
    invoke-direct {v4, v13, v5}, Lzb/m0;-><init>(Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;I)V

    .line 177
    .line 178
    .line 179
    invoke-virtual {v0, v4}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 180
    .line 181
    .line 182
    sget-object v0, LFb/d;->a:LFb/c;

    .line 183
    .line 184
    iget-object v4, v13, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->B:Ljava/lang/String;

    .line 185
    .line 186
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->y()Ljava/lang/String;

    .line 187
    .line 188
    .line 189
    move-result-object v5

    .line 190
    invoke-virtual {v0, v4, v5, v9}, LFb/c;->getOcDeviceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    invoke-virtual {v2}, Lob/a;->getInstance()Lob/c;

    .line 195
    .line 196
    .line 197
    move-result-object v4

    .line 198
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 199
    .line 200
    .line 201
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 202
    .line 203
    .line 204
    move-result-object v4

    .line 205
    invoke-interface {v4, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadDeviceInfoNew(Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;)Ldf/d;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    invoke-virtual {v0, v3}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 214
    .line 215
    .line 216
    move-result-object v4

    .line 217
    invoke-virtual {v0, v4}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    new-instance v4, Lzb/m0;

    .line 222
    .line 223
    const/4 v5, 0x3

    .line 224
    invoke-direct {v4, v13, v5}, Lzb/m0;-><init>(Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;I)V

    .line 225
    .line 226
    .line 227
    invoke-virtual {v0, v4}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 228
    .line 229
    .line 230
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    invoke-static {v0}, Lj8/f;->l(Landroid/app/Activity;)Lkotlin/Pair;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    new-instance v21, Lcom/transsnet/palmpay/credit/bean/req/MultiMediaReq;

    .line 239
    .line 240
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->y()Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object v22

    .line 244
    iget-object v4, v13, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->B:Ljava/lang/String;

    .line 245
    .line 246
    iget-object v5, v0, Lkotlin/Pair;->a:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast v5, Ljava/lang/Number;

    .line 249
    .line 250
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 251
    .line 252
    .line 253
    move-result v24

    .line 254
    iget-object v0, v0, Lkotlin/Pair;->b:Ljava/lang/Object;

    .line 255
    .line 256
    check-cast v0, Ljava/lang/Number;

    .line 257
    .line 258
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 259
    .line 260
    .line 261
    move-result v25

    .line 262
    const/16 v26, 0x0

    .line 263
    .line 264
    const-string v27, "credit"

    .line 265
    .line 266
    const/16 v28, 0x10

    .line 267
    .line 268
    const/16 v29, 0x0

    .line 269
    .line 270
    move-object/from16 v23, v4

    .line 271
    .line 272
    invoke-direct/range {v21 .. v29}, Lcom/transsnet/palmpay/credit/bean/req/MultiMediaReq;-><init>(Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 273
    .line 274
    .line 275
    move-object/from16 v0, v21

    .line 276
    .line 277
    invoke-virtual {v2}, Lob/a;->getInstance()Lob/c;

    .line 278
    .line 279
    .line 280
    move-result-object v2

    .line 281
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 282
    .line 283
    .line 284
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 285
    .line 286
    .line 287
    move-result-object v2

    .line 288
    invoke-interface {v2, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadMultiMediaInfo(Lcom/transsnet/palmpay/credit/bean/req/MultiMediaReq;)Ldf/d;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    invoke-virtual {v0, v3}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 297
    .line 298
    .line 299
    move-result-object v2

    .line 300
    invoke-virtual {v0, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 301
    .line 302
    .line 303
    move-result-object v0

    .line 304
    new-instance v2, Lzb/m0;

    .line 305
    .line 306
    const/4 v3, 0x5

    .line 307
    invoke-direct {v2, v13, v3}, Lzb/m0;-><init>(Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;I)V

    .line 308
    .line 309
    .line 310
    invoke-virtual {v0, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 311
    .line 312
    .line 313
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->B:Ljava/lang/String;

    .line 314
    .line 315
    if-eqz v0, :cond_5

    .line 316
    .line 317
    iget-object v2, v13, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->M:Ljava/util/ArrayList;

    .line 318
    .line 319
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 320
    .line 321
    .line 322
    move-result-object v2

    .line 323
    invoke-static {v2, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 324
    .line 325
    .line 326
    :cond_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 327
    .line 328
    .line 329
    move-result v3

    .line 330
    if-eqz v3, :cond_5

    .line 331
    .line 332
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 333
    .line 334
    .line 335
    move-result-object v3

    .line 336
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 337
    .line 338
    if-eqz v3, :cond_4

    .line 339
    .line 340
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 341
    .line 342
    .line 343
    move-result-object v3

    .line 344
    goto :goto_1

    .line 345
    :cond_4
    const/4 v3, 0x0

    .line 346
    :goto_1
    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 347
    .line 348
    .line 349
    move-result v3

    .line 350
    if-eqz v3, :cond_3

    .line 351
    .line 352
    sget-object v2, LGa/c;->a:LGa/b;

    .line 353
    .line 354
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->y()Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object v3

    .line 358
    invoke-virtual {v2, v0, v6, v3}, LGa/b;->upload(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 359
    .line 360
    .line 361
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 362
    .line 363
    .line 364
    move-result-object v15

    .line 365
    if-eqz v15, :cond_5

    .line 366
    .line 367
    sget-object v14, Lcom/transsnet/palmpay/core/service/CollectDeviceInfoService;->o:Lcom/transsnet/palmpay/core/service/CollectDeviceInfoService$a;

    .line 368
    .line 369
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->B:Ljava/lang/String;

    .line 370
    .line 371
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->y()Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v21

    .line 375
    const/16 v23, 0x14

    .line 376
    .line 377
    const/16 v24, 0x0

    .line 378
    .line 379
    const/16 v16, 0x1

    .line 380
    .line 381
    const/16 v17, 0x0

    .line 382
    .line 383
    const/16 v18, 0x1

    .line 384
    .line 385
    const/16 v19, 0x0

    .line 386
    .line 387
    const-string v22, "credit"

    .line 388
    .line 389
    move-object/from16 v20, v0

    .line 390
    .line 391
    invoke-static/range {v14 .. v24}, Lcom/transsnet/palmpay/core/service/CollectDeviceInfoService$a;->enqueueWork$default(Lcom/transsnet/palmpay/core/service/CollectDeviceInfoService$a;Landroid/content/Context;ZZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V

    .line 392
    .line 393
    .line 394
    :cond_5
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->A()V

    .line 395
    .line 396
    .line 397
    goto :goto_2

    .line 398
    :cond_6
    invoke-virtual {v13, v5}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 399
    .line 400
    .line 401
    new-instance v0, Ljava/util/ArrayList;

    .line 402
    .line 403
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 404
    .line 405
    .line 406
    filled-new-array {v11}, [Ljava/lang/String;

    .line 407
    .line 408
    .line 409
    move-result-object v3

    .line 410
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 411
    .line 412
    .line 413
    move-result v3

    .line 414
    const-string v4, "requireContext(...)"

    .line 415
    .line 416
    if-eqz v3, :cond_7

    .line 417
    .line 418
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 419
    .line 420
    .line 421
    move-result-object v3

    .line 422
    filled-new-array {v3}, [Ljava/lang/String;

    .line 423
    .line 424
    .line 425
    move-result-object v3

    .line 426
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 427
    .line 428
    .line 429
    move-result v3

    .line 430
    if-nez v3, :cond_8

    .line 431
    .line 432
    :cond_7
    new-instance v3, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;

    .line 433
    .line 434
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 435
    .line 436
    .line 437
    move-result-object v5

    .line 438
    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 439
    .line 440
    .line 441
    sget-object v6, LS6/a;->P0:LS6/a;

    .line 442
    .line 443
    sget v7, LL6/b;->ppColorTextPrimary:I

    .line 444
    .line 445
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 446
    .line 447
    .line 448
    move-result-object v8

    .line 449
    const/high16 v9, 0x41c00000    # 24.0f

    .line 450
    .line 451
    const/16 v10, 0x72

    .line 452
    .line 453
    const/4 v7, 0x0

    .line 454
    invoke-static/range {v5 .. v10}, LG8/a;->x(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;Ljava/lang/Integer;Ljava/lang/Integer;FI)Lcom/mikepenz/iconics/IconicsDrawable;

    .line 455
    .line 456
    .line 457
    move-result-object v5

    .line 458
    invoke-direct {v3, v5, v2}, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V

    .line 459
    .line 460
    .line 461
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 462
    .line 463
    .line 464
    :cond_8
    new-instance v2, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;

    .line 465
    .line 466
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 467
    .line 468
    .line 469
    move-result-object v3

    .line 470
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 471
    .line 472
    .line 473
    invoke-direct {v2, v3, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;-><init>(Landroid/content/Context;Ljava/util/ArrayList;)V

    .line 474
    .line 475
    .line 476
    new-instance v0, Lzb/n0;

    .line 477
    .line 478
    invoke-direct {v0, v13}, Lzb/n0;-><init>(Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;)V

    .line 479
    .line 480
    .line 481
    invoke-virtual {v2, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;->setListener(Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog$NoPermissionDialogInterface;)V

    .line 482
    .line 483
    .line 484
    invoke-virtual {v2}, LO6/f;->show()V

    .line 485
    .line 486
    .line 487
    :goto_2
    return-void

    .line 488
    :pswitch_0
    check-cast v0, Ljava/util/Map;

    .line 489
    .line 490
    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 491
    .line 492
    .line 493
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 494
    .line 495
    .line 496
    move-result-object v0

    .line 497
    filled-new-array {v0}, [Ljava/lang/String;

    .line 498
    .line 499
    .line 500
    move-result-object v0

    .line 501
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 502
    .line 503
    .line 504
    move-result v0

    .line 505
    check-cast v13, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeMobileInstalmentTabFragment;

    .line 506
    .line 507
    if-nez v0, :cond_a

    .line 508
    .line 509
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeMobileInstalmentTabFragment;->t()Z

    .line 510
    .line 511
    .line 512
    move-result v0

    .line 513
    if-eqz v0, :cond_9

    .line 514
    .line 515
    iput-boolean v5, v13, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeMobileInstalmentTabFragment;->B:Z

    .line 516
    .line 517
    goto :goto_3

    .line 518
    :cond_9
    const/4 v0, 0x1

    .line 519
    iput-boolean v0, v13, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeMobileInstalmentTabFragment;->B:Z

    .line 520
    .line 521
    goto :goto_3

    .line 522
    :cond_a
    iput-boolean v5, v13, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeMobileInstalmentTabFragment;->B:Z

    .line 523
    .line 524
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeMobileInstalmentTabFragment;->z()V

    .line 525
    .line 526
    .line 527
    :goto_3
    return-void

    .line 528
    :pswitch_1
    check-cast v0, Ljava/util/Map;

    .line 529
    .line 530
    sget v3, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeLoanTabFragment;->v:I

    .line 531
    .line 532
    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 533
    .line 534
    .line 535
    new-instance v0, Ljava/util/ArrayList;

    .line 536
    .line 537
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 538
    .line 539
    .line 540
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 541
    .line 542
    .line 543
    move-result-object v3

    .line 544
    filled-new-array {v3}, [Ljava/lang/String;

    .line 545
    .line 546
    .line 547
    move-result-object v3

    .line 548
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 549
    .line 550
    .line 551
    move-result v3

    .line 552
    if-nez v3, :cond_b

    .line 553
    .line 554
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 555
    .line 556
    .line 557
    move-result-object v3

    .line 558
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 559
    .line 560
    .line 561
    :cond_b
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 562
    .line 563
    .line 564
    move-result v0

    .line 565
    check-cast v13, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeLoanTabFragment;

    .line 566
    .line 567
    if-nez v0, :cond_c

    .line 568
    .line 569
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 570
    .line 571
    .line 572
    move-result-object v0

    .line 573
    new-instance v2, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;

    .line 574
    .line 575
    const/16 v3, 0x241

    .line 576
    .line 577
    invoke-direct {v2, v3}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;-><init>(I)V

    .line 578
    .line 579
    .line 580
    invoke-virtual {v0, v2}, Lorg/greenrobot/eventbus/c;->f(Ljava/lang/Object;)V

    .line 581
    .line 582
    .line 583
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeLoanTabFragment;->w()V

    .line 584
    .line 585
    .line 586
    goto :goto_5

    .line 587
    :cond_c
    new-instance v0, Ljava/util/ArrayList;

    .line 588
    .line 589
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 590
    .line 591
    .line 592
    filled-new-array {v11}, [Ljava/lang/String;

    .line 593
    .line 594
    .line 595
    move-result-object v3

    .line 596
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 597
    .line 598
    .line 599
    move-result v3

    .line 600
    if-eqz v3, :cond_d

    .line 601
    .line 602
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 603
    .line 604
    .line 605
    move-result-object v3

    .line 606
    filled-new-array {v3}, [Ljava/lang/String;

    .line 607
    .line 608
    .line 609
    move-result-object v3

    .line 610
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 611
    .line 612
    .line 613
    move-result v3

    .line 614
    if-nez v3, :cond_f

    .line 615
    .line 616
    :cond_d
    new-instance v3, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;

    .line 617
    .line 618
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 619
    .line 620
    .line 621
    move-result-object v4

    .line 622
    if-eqz v4, :cond_e

    .line 623
    .line 624
    sget-object v5, LS6/a;->P0:LS6/a;

    .line 625
    .line 626
    sget v6, LL6/b;->ppColorTextPrimary:I

    .line 627
    .line 628
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 629
    .line 630
    .line 631
    move-result-object v7

    .line 632
    const/high16 v8, 0x41c00000    # 24.0f

    .line 633
    .line 634
    const/16 v9, 0x72

    .line 635
    .line 636
    const/4 v6, 0x0

    .line 637
    invoke-static/range {v4 .. v9}, LG8/a;->x(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;Ljava/lang/Integer;Ljava/lang/Integer;FI)Lcom/mikepenz/iconics/IconicsDrawable;

    .line 638
    .line 639
    .line 640
    move-result-object v4

    .line 641
    goto :goto_4

    .line 642
    :cond_e
    const/4 v4, 0x0

    .line 643
    :goto_4
    invoke-direct {v3, v4, v2}, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V

    .line 644
    .line 645
    .line 646
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 647
    .line 648
    .line 649
    :cond_f
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 650
    .line 651
    .line 652
    move-result-object v2

    .line 653
    if-eqz v2, :cond_10

    .line 654
    .line 655
    new-instance v3, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;

    .line 656
    .line 657
    invoke-direct {v3, v2, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;-><init>(Landroid/content/Context;Ljava/util/ArrayList;)V

    .line 658
    .line 659
    .line 660
    new-instance v0, Lzb/P;

    .line 661
    .line 662
    invoke-direct {v0, v13}, Lzb/P;-><init>(Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeLoanTabFragment;)V

    .line 663
    .line 664
    .line 665
    invoke-virtual {v3, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;->setListener(Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog$NoPermissionDialogInterface;)V

    .line 666
    .line 667
    .line 668
    invoke-virtual {v3}, LO6/f;->show()V

    .line 669
    .line 670
    .line 671
    :cond_10
    :goto_5
    return-void

    .line 672
    :pswitch_2
    check-cast v0, Ljava/util/Map;

    .line 673
    .line 674
    sget-object v3, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;->Z:Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment$a;

    .line 675
    .line 676
    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 677
    .line 678
    .line 679
    new-instance v0, Ljava/util/ArrayList;

    .line 680
    .line 681
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 682
    .line 683
    .line 684
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 685
    .line 686
    .line 687
    move-result-object v3

    .line 688
    filled-new-array {v3}, [Ljava/lang/String;

    .line 689
    .line 690
    .line 691
    move-result-object v3

    .line 692
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 693
    .line 694
    .line 695
    move-result v3

    .line 696
    if-nez v3, :cond_11

    .line 697
    .line 698
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 699
    .line 700
    .line 701
    move-result-object v3

    .line 702
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 703
    .line 704
    .line 705
    :cond_11
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 706
    .line 707
    .line 708
    move-result v0

    .line 709
    check-cast v13, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;

    .line 710
    .line 711
    if-eqz v0, :cond_12

    .line 712
    .line 713
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 714
    .line 715
    .line 716
    move-result-object v0

    .line 717
    new-instance v2, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;

    .line 718
    .line 719
    const/16 v3, 0x241

    .line 720
    .line 721
    invoke-direct {v2, v3}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;-><init>(I)V

    .line 722
    .line 723
    .line 724
    invoke-virtual {v0, v2}, Lorg/greenrobot/eventbus/c;->f(Ljava/lang/Object;)V

    .line 725
    .line 726
    .line 727
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;->z()V

    .line 728
    .line 729
    .line 730
    goto :goto_7

    .line 731
    :cond_12
    new-instance v0, Ljava/util/ArrayList;

    .line 732
    .line 733
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 734
    .line 735
    .line 736
    filled-new-array {v11}, [Ljava/lang/String;

    .line 737
    .line 738
    .line 739
    move-result-object v3

    .line 740
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 741
    .line 742
    .line 743
    move-result v3

    .line 744
    if-eqz v3, :cond_13

    .line 745
    .line 746
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 747
    .line 748
    .line 749
    move-result-object v3

    .line 750
    filled-new-array {v3}, [Ljava/lang/String;

    .line 751
    .line 752
    .line 753
    move-result-object v3

    .line 754
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 755
    .line 756
    .line 757
    move-result v3

    .line 758
    if-nez v3, :cond_15

    .line 759
    .line 760
    :cond_13
    new-instance v3, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;

    .line 761
    .line 762
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 763
    .line 764
    .line 765
    move-result-object v4

    .line 766
    if-eqz v4, :cond_14

    .line 767
    .line 768
    sget-object v5, LS6/a;->P0:LS6/a;

    .line 769
    .line 770
    sget v6, LL6/b;->ppColorTextPrimary:I

    .line 771
    .line 772
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 773
    .line 774
    .line 775
    move-result-object v7

    .line 776
    const/high16 v8, 0x41c00000    # 24.0f

    .line 777
    .line 778
    const/16 v9, 0x72

    .line 779
    .line 780
    const/4 v6, 0x0

    .line 781
    invoke-static/range {v4 .. v9}, LG8/a;->x(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;Ljava/lang/Integer;Ljava/lang/Integer;FI)Lcom/mikepenz/iconics/IconicsDrawable;

    .line 782
    .line 783
    .line 784
    move-result-object v4

    .line 785
    goto :goto_6

    .line 786
    :cond_14
    const/4 v4, 0x0

    .line 787
    :goto_6
    invoke-direct {v3, v4, v2}, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V

    .line 788
    .line 789
    .line 790
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 791
    .line 792
    .line 793
    :cond_15
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 794
    .line 795
    .line 796
    move-result-object v2

    .line 797
    if-eqz v2, :cond_16

    .line 798
    .line 799
    new-instance v3, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;

    .line 800
    .line 801
    invoke-direct {v3, v2, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;-><init>(Landroid/content/Context;Ljava/util/ArrayList;)V

    .line 802
    .line 803
    .line 804
    new-instance v0, Lzb/w;

    .line 805
    .line 806
    invoke-direct {v0, v13}, Lzb/w;-><init>(Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;)V

    .line 807
    .line 808
    .line 809
    invoke-virtual {v3, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;->setListener(Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog$NoPermissionDialogInterface;)V

    .line 810
    .line 811
    .line 812
    invoke-virtual {v3}, LO6/f;->show()V

    .line 813
    .line 814
    .line 815
    :cond_16
    :goto_7
    return-void

    .line 816
    :pswitch_3
    check-cast v0, Ljava/util/Map;

    .line 817
    .line 818
    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 819
    .line 820
    .line 821
    check-cast v13, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 822
    .line 823
    invoke-virtual {v13, v5}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 824
    .line 825
    .line 826
    new-instance v0, Ljava/util/ArrayList;

    .line 827
    .line 828
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 829
    .line 830
    .line 831
    filled-new-array {v4}, [Ljava/lang/String;

    .line 832
    .line 833
    .line 834
    move-result-object v3

    .line 835
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 836
    .line 837
    .line 838
    move-result v3

    .line 839
    if-nez v3, :cond_17

    .line 840
    .line 841
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 842
    .line 843
    .line 844
    :cond_17
    filled-new-array {v11}, [Ljava/lang/String;

    .line 845
    .line 846
    .line 847
    move-result-object v3

    .line 848
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 849
    .line 850
    .line 851
    move-result v3

    .line 852
    if-nez v3, :cond_18

    .line 853
    .line 854
    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 855
    .line 856
    .line 857
    :cond_18
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 858
    .line 859
    .line 860
    move-result v0

    .line 861
    if-nez v0, :cond_27

    .line 862
    .line 863
    iget-boolean v0, v13, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;->o:Z

    .line 864
    .line 865
    const-string v2, "LOAN_WITHDRAW"

    .line 866
    .line 867
    const-string v3, "permissionGranted >>>"

    .line 868
    .line 869
    if-eqz v0, :cond_1c

    .line 870
    .line 871
    sget-object v0, Ljb/t;->n:Ljb/p;

    .line 872
    .line 873
    invoke-virtual {v0}, Ljb/p;->getInstance()Ljb/t;

    .line 874
    .line 875
    .line 876
    move-result-object v4

    .line 877
    invoke-virtual {v4}, Ljb/t;->i()V

    .line 878
    .line 879
    .line 880
    iget-object v5, v4, Ljb/t;->c:Ljava/lang/String;

    .line 881
    .line 882
    iget-object v7, v4, Ljb/t;->f:Ljava/lang/String;

    .line 883
    .line 884
    const-string v8, "OK_CARD"

    .line 885
    .line 886
    invoke-static {v7, v8}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 887
    .line 888
    .line 889
    move-result v7

    .line 890
    const-string v8, "flexi cash"

    .line 891
    .line 892
    if-eqz v7, :cond_19

    .line 893
    .line 894
    const-string v7, "flexi"

    .line 895
    .line 896
    goto :goto_8

    .line 897
    :cond_19
    move-object v7, v8

    .line 898
    :goto_8
    iget-object v10, v4, Ljb/t;->f:Ljava/lang/String;

    .line 899
    .line 900
    invoke-static {v10, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 901
    .line 902
    .line 903
    move-result v2

    .line 904
    if-eqz v2, :cond_1a

    .line 905
    .line 906
    const-string v9, "trade"

    .line 907
    .line 908
    :cond_1a
    sget-object v2, LFb/d;->a:LFb/c;

    .line 909
    .line 910
    invoke-virtual {v2, v5, v7, v9}, LFb/c;->getOcDeviceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;

    .line 911
    .line 912
    .line 913
    move-result-object v2

    .line 914
    sget-object v5, Lob/c;->a:Lob/a;

    .line 915
    .line 916
    invoke-virtual {v5}, Lob/a;->getInstance()Lob/c;

    .line 917
    .line 918
    .line 919
    move-result-object v5

    .line 920
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 921
    .line 922
    .line 923
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 924
    .line 925
    .line 926
    move-result-object v5

    .line 927
    invoke-interface {v5, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadDeviceInfoNew(Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;)Ldf/d;

    .line 928
    .line 929
    .line 930
    move-result-object v2

    .line 931
    sget-object v5, Ltf/f;->b:Ldf/i;

    .line 932
    .line 933
    invoke-virtual {v2, v5}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 934
    .line 935
    .line 936
    move-result-object v2

    .line 937
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 938
    .line 939
    .line 940
    move-result-object v5

    .line 941
    invoke-virtual {v2, v5}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 942
    .line 943
    .line 944
    move-result-object v2

    .line 945
    new-instance v5, LN8/t;

    .line 946
    .line 947
    const/4 v7, 0x3

    .line 948
    invoke-direct {v5, v7}, LN8/t;-><init>(I)V

    .line 949
    .line 950
    .line 951
    invoke-virtual {v2, v5}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 952
    .line 953
    .line 954
    iget-object v2, v4, Ljb/t;->c:Ljava/lang/String;

    .line 955
    .line 956
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 957
    .line 958
    .line 959
    move-result v2

    .line 960
    if-eqz v2, :cond_1b

    .line 961
    .line 962
    const-string v2, ""

    .line 963
    .line 964
    goto :goto_9

    .line 965
    :cond_1b
    iget-object v2, v4, Ljb/t;->c:Ljava/lang/String;

    .line 966
    .line 967
    :goto_9
    iput-object v2, v4, Ljb/t;->c:Ljava/lang/String;

    .line 968
    .line 969
    sget-object v4, LGa/c;->a:LGa/b;

    .line 970
    .line 971
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 972
    .line 973
    .line 974
    invoke-virtual {v4, v2, v6, v8}, LGa/b;->upload(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 975
    .line 976
    .line 977
    invoke-virtual {v0}, Ljb/p;->getInstance()Ljb/t;

    .line 978
    .line 979
    .line 980
    move-result-object v0

    .line 981
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 982
    .line 983
    .line 984
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 985
    .line 986
    .line 987
    move-result-object v0

    .line 988
    const-string v2, "CreditRouterManagerV2"

    .line 989
    .line 990
    const/4 v5, 0x3

    .line 991
    invoke-static {v2, v5, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 992
    .line 993
    .line 994
    const-string v0, "NoticeRNCreditAuth"

    .line 995
    .line 996
    const/4 v2, 0x0

    .line 997
    invoke-static {v0, v2, v2}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 998
    .line 999
    .line 1000
    goto/16 :goto_d

    .line 1001
    .line 1002
    :cond_1c
    sget-object v0, Ljb/o;->z:Ljb/j;

    .line 1003
    .line 1004
    invoke-virtual {v0}, Ljb/j;->getInstance()Ljb/o;

    .line 1005
    .line 1006
    .line 1007
    move-result-object v4

    .line 1008
    invoke-virtual {v4}, Ljb/o;->D()V

    .line 1009
    .line 1010
    .line 1011
    invoke-virtual {v0}, Ljb/j;->getInstance()Ljb/o;

    .line 1012
    .line 1013
    .line 1014
    move-result-object v0

    .line 1015
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1016
    .line 1017
    .line 1018
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 1019
    .line 1020
    .line 1021
    move-result-object v3

    .line 1022
    const-string v4, "CreditRouterManager"

    .line 1023
    .line 1024
    const/4 v6, 0x3

    .line 1025
    invoke-static {v4, v6, v3}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1026
    .line 1027
    .line 1028
    invoke-virtual {v0}, Ljb/o;->D()V

    .line 1029
    .line 1030
    .line 1031
    iget-object v3, v0, Ljb/o;->k:Ljava/lang/String;

    .line 1032
    .line 1033
    invoke-static {v3, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 1034
    .line 1035
    .line 1036
    move-result v2

    .line 1037
    if-eqz v2, :cond_1d

    .line 1038
    .line 1039
    invoke-virtual {v0}, Ljb/o;->x()V

    .line 1040
    .line 1041
    .line 1042
    goto/16 :goto_d

    .line 1043
    .line 1044
    :cond_1d
    iget-object v2, v0, Ljb/o;->d:Ljava/util/List;

    .line 1045
    .line 1046
    if-eqz v2, :cond_1e

    .line 1047
    .line 1048
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 1049
    .line 1050
    .line 1051
    move-result v5

    .line 1052
    :cond_1e
    invoke-virtual {v0}, Ljb/o;->n()Z

    .line 1053
    .line 1054
    .line 1055
    move-result v2

    .line 1056
    if-eqz v2, :cond_1f

    .line 1057
    .line 1058
    const/4 v2, 0x2

    .line 1059
    if-gt v5, v2, :cond_20

    .line 1060
    .line 1061
    :cond_1f
    invoke-virtual {v0}, Ljb/o;->n()Z

    .line 1062
    .line 1063
    .line 1064
    move-result v2

    .line 1065
    if-nez v2, :cond_26

    .line 1066
    .line 1067
    const/4 v2, 0x1

    .line 1068
    if-le v5, v2, :cond_26

    .line 1069
    .line 1070
    :cond_20
    iget-object v2, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 1071
    .line 1072
    if-eqz v2, :cond_25

    .line 1073
    .line 1074
    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1075
    .line 1076
    .line 1077
    move-result-object v2

    .line 1078
    check-cast v2, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 1079
    .line 1080
    if-eqz v2, :cond_2b

    .line 1081
    .line 1082
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/Z;

    .line 1083
    .line 1084
    .line 1085
    move-result-object v2

    .line 1086
    if-eqz v2, :cond_2b

    .line 1087
    .line 1088
    iget-object v3, v0, Ljb/o;->d:Ljava/util/List;

    .line 1089
    .line 1090
    if-eqz v3, :cond_24

    .line 1091
    .line 1092
    check-cast v3, Ljava/lang/Iterable;

    .line 1093
    .line 1094
    new-instance v4, Ljava/util/ArrayList;

    .line 1095
    .line 1096
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 1097
    .line 1098
    .line 1099
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1100
    .line 1101
    .line 1102
    move-result-object v3

    .line 1103
    :cond_21
    :goto_a
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1104
    .line 1105
    .line 1106
    move-result v5

    .line 1107
    if-eqz v5, :cond_23

    .line 1108
    .line 1109
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1110
    .line 1111
    .line 1112
    move-result-object v5

    .line 1113
    move-object v6, v5

    .line 1114
    check-cast v6, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 1115
    .line 1116
    if-eqz v6, :cond_22

    .line 1117
    .line 1118
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 1119
    .line 1120
    .line 1121
    move-result-object v6

    .line 1122
    goto :goto_b

    .line 1123
    :cond_22
    const/4 v6, 0x0

    .line 1124
    :goto_b
    invoke-static {v6, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 1125
    .line 1126
    .line 1127
    move-result v6

    .line 1128
    if-nez v6, :cond_21

    .line 1129
    .line 1130
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1131
    .line 1132
    .line 1133
    goto :goto_a

    .line 1134
    :cond_23
    move-object v13, v4

    .line 1135
    goto :goto_c

    .line 1136
    :cond_24
    const/4 v13, 0x0

    .line 1137
    :goto_c
    sget-object v3, Lcom/transsnet/palmpay/credit/ui/dialog/CreditApplicationDialogFragment;->L:Lcom/transsnet/palmpay/credit/ui/dialog/CreditApplicationDialogFragment$a;

    .line 1138
    .line 1139
    invoke-virtual {v3, v13}, Lcom/transsnet/palmpay/credit/ui/dialog/CreditApplicationDialogFragment$a;->newInstance(Ljava/util/List;)Lcom/transsnet/palmpay/credit/ui/dialog/CreditApplicationDialogFragment;

    .line 1140
    .line 1141
    .line 1142
    move-result-object v3

    .line 1143
    new-instance v4, Ljb/i;

    .line 1144
    .line 1145
    const/4 v5, 0x1

    .line 1146
    invoke-direct {v4, v0, v5}, Ljb/i;-><init>(Ljb/o;I)V

    .line 1147
    .line 1148
    .line 1149
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1150
    .line 1151
    .line 1152
    const-string v0, "countDownListener"

    .line 1153
    .line 1154
    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1155
    .line 1156
    .line 1157
    iput-object v4, v3, Lcom/transsnet/palmpay/credit/ui/dialog/CreditApplicationDialogFragment;->H:Lkotlin/jvm/functions/Function0;

    .line 1158
    .line 1159
    const-string v0, "CreditApplicationDialogFragment"

    .line 1160
    .line 1161
    invoke-virtual {v3, v2, v0}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 1162
    .line 1163
    .line 1164
    goto :goto_d

    .line 1165
    :cond_25
    const-string v0, "mLoanCreditFragmentRef"

    .line 1166
    .line 1167
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1168
    .line 1169
    .line 1170
    const/16 v20, 0x0

    .line 1171
    .line 1172
    throw v20

    .line 1173
    :cond_26
    invoke-virtual {v0}, Ljb/o;->x()V

    .line 1174
    .line 1175
    .line 1176
    goto :goto_d

    .line 1177
    :cond_27
    invoke-virtual {v13}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 1178
    .line 1179
    .line 1180
    move-result-object v3

    .line 1181
    if-eqz v3, :cond_2b

    .line 1182
    .line 1183
    invoke-virtual {v13, v5}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 1184
    .line 1185
    .line 1186
    new-instance v0, Ljava/util/ArrayList;

    .line 1187
    .line 1188
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1189
    .line 1190
    .line 1191
    filled-new-array {v4}, [Ljava/lang/String;

    .line 1192
    .line 1193
    .line 1194
    move-result-object v4

    .line 1195
    invoke-static {v4}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 1196
    .line 1197
    .line 1198
    move-result v4

    .line 1199
    if-nez v4, :cond_28

    .line 1200
    .line 1201
    new-instance v4, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;

    .line 1202
    .line 1203
    sget v5, LYa/d;->cs_device_info_icon:I

    .line 1204
    .line 1205
    invoke-virtual {v3, v5}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 1206
    .line 1207
    .line 1208
    move-result-object v5

    .line 1209
    const-string v6, "Device Information"

    .line 1210
    .line 1211
    invoke-direct {v4, v5, v6}, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V

    .line 1212
    .line 1213
    .line 1214
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1215
    .line 1216
    .line 1217
    :cond_28
    filled-new-array {v11}, [Ljava/lang/String;

    .line 1218
    .line 1219
    .line 1220
    move-result-object v4

    .line 1221
    invoke-static {v4}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 1222
    .line 1223
    .line 1224
    move-result v4

    .line 1225
    if-eqz v4, :cond_29

    .line 1226
    .line 1227
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 1228
    .line 1229
    .line 1230
    move-result-object v4

    .line 1231
    filled-new-array {v4}, [Ljava/lang/String;

    .line 1232
    .line 1233
    .line 1234
    move-result-object v4

    .line 1235
    invoke-static {v4}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 1236
    .line 1237
    .line 1238
    move-result v4

    .line 1239
    if-nez v4, :cond_2a

    .line 1240
    .line 1241
    :cond_29
    new-instance v9, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;

    .line 1242
    .line 1243
    sget-object v4, LS6/a;->P0:LS6/a;

    .line 1244
    .line 1245
    sget v5, LL6/b;->ppColorTextPrimary:I

    .line 1246
    .line 1247
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1248
    .line 1249
    .line 1250
    move-result-object v6

    .line 1251
    const/high16 v7, 0x41c00000    # 24.0f

    .line 1252
    .line 1253
    const/16 v8, 0x72

    .line 1254
    .line 1255
    const/4 v5, 0x0

    .line 1256
    invoke-static/range {v3 .. v8}, LG8/a;->x(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;Ljava/lang/Integer;Ljava/lang/Integer;FI)Lcom/mikepenz/iconics/IconicsDrawable;

    .line 1257
    .line 1258
    .line 1259
    move-result-object v4

    .line 1260
    invoke-direct {v9, v4, v2}, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V

    .line 1261
    .line 1262
    .line 1263
    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1264
    .line 1265
    .line 1266
    :cond_2a
    new-instance v2, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;

    .line 1267
    .line 1268
    invoke-direct {v2, v3, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;-><init>(Landroid/content/Context;Ljava/util/ArrayList;)V

    .line 1269
    .line 1270
    .line 1271
    new-instance v0, Lzb/s;

    .line 1272
    .line 1273
    invoke-direct {v0, v3}, Lzb/s;-><init>(Landroid/content/Context;)V

    .line 1274
    .line 1275
    .line 1276
    invoke-virtual {v2, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;->setListener(Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog$NoPermissionDialogInterface;)V

    .line 1277
    .line 1278
    .line 1279
    invoke-virtual {v2}, LO6/f;->show()V

    .line 1280
    .line 1281
    .line 1282
    :cond_2b
    :goto_d
    return-void

    .line 1283
    :pswitch_4
    check-cast v0, Ljava/util/Map;

    .line 1284
    .line 1285
    const-string v2, "perms"

    .line 1286
    .line 1287
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1288
    .line 1289
    .line 1290
    check-cast v13, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFaceRecFragment;

    .line 1291
    .line 1292
    invoke-virtual {v13, v5}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 1293
    .line 1294
    .line 1295
    new-instance v0, Ljava/util/ArrayList;

    .line 1296
    .line 1297
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1298
    .line 1299
    .line 1300
    const-string v2, "android.permission.CAMERA"

    .line 1301
    .line 1302
    filled-new-array {v2}, [Ljava/lang/String;

    .line 1303
    .line 1304
    .line 1305
    move-result-object v3

    .line 1306
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 1307
    .line 1308
    .line 1309
    move-result v3

    .line 1310
    if-nez v3, :cond_2c

    .line 1311
    .line 1312
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1313
    .line 1314
    .line 1315
    :cond_2c
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1316
    .line 1317
    .line 1318
    move-result v0

    .line 1319
    if-eqz v0, :cond_2d

    .line 1320
    .line 1321
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFaceRecFragment;->t()V

    .line 1322
    .line 1323
    .line 1324
    goto :goto_e

    .line 1325
    :cond_2d
    const-string v0, "showNoPermissionDialog >>>"

    .line 1326
    .line 1327
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 1328
    .line 1329
    .line 1330
    move-result-object v0

    .line 1331
    iget-object v2, v13, Lcom/transsnet/palmpay/core/base/BaseFragment;->a:Ljava/lang/String;

    .line 1332
    .line 1333
    const/4 v5, 0x3

    .line 1334
    invoke-static {v2, v5, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1335
    .line 1336
    .line 1337
    :goto_e
    return-void

    .line 1338
    :pswitch_5
    check-cast v0, Landroidx/activity/result/ActivityResult;

    .line 1339
    .line 1340
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 1341
    .line 1342
    invoke-static {v0, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1343
    .line 1344
    .line 1345
    check-cast v13, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 1346
    .line 1347
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->o()Landroid/widget/EditText;

    .line 1348
    .line 1349
    .line 1350
    move-result-object v2

    .line 1351
    invoke-virtual {v2, v5}, Landroid/view/View;->setFocusable(Z)V

    .line 1352
    .line 1353
    .line 1354
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->o()Landroid/widget/EditText;

    .line 1355
    .line 1356
    .line 1357
    move-result-object v2

    .line 1358
    const/4 v5, 0x1

    .line 1359
    invoke-virtual {v2, v5}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 1360
    .line 1361
    .line 1362
    invoke-virtual {v13}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->o()Landroid/widget/EditText;

    .line 1363
    .line 1364
    .line 1365
    move-result-object v2

    .line 1366
    invoke-virtual {v2, v5}, Landroid/view/View;->setFocusable(Z)V

    .line 1367
    .line 1368
    .line 1369
    iget v2, v0, Landroidx/activity/result/ActivityResult;->a:I

    .line 1370
    .line 1371
    const/4 v4, -0x1

    .line 1372
    if-ne v2, v4, :cond_34

    .line 1373
    .line 1374
    new-instance v2, Ljava/util/ArrayList;

    .line 1375
    .line 1376
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 1377
    .line 1378
    .line 1379
    iget-object v0, v0, Landroidx/activity/result/ActivityResult;->b:Landroid/content/Intent;

    .line 1380
    .line 1381
    invoke-static {v0}, Lcom/luck/picture/lib/basic/PictureSelector;->obtainSelectorList(Landroid/content/Intent;)Ljava/util/ArrayList;

    .line 1382
    .line 1383
    .line 1384
    move-result-object v0

    .line 1385
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 1386
    .line 1387
    .line 1388
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1389
    .line 1390
    .line 1391
    move-result-object v0

    .line 1392
    invoke-static {v0, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1393
    .line 1394
    .line 1395
    :cond_2e
    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1396
    .line 1397
    .line 1398
    move-result v4

    .line 1399
    if-eqz v4, :cond_30

    .line 1400
    .line 1401
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1402
    .line 1403
    .line 1404
    move-result-object v4

    .line 1405
    const-string v5, "next(...)"

    .line 1406
    .line 1407
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1408
    .line 1409
    .line 1410
    check-cast v4, Lcom/luck/picture/lib/entity/LocalMedia;

    .line 1411
    .line 1412
    invoke-virtual {v4}, Lcom/luck/picture/lib/entity/LocalMedia;->getWidth()I

    .line 1413
    .line 1414
    .line 1415
    move-result v5

    .line 1416
    if-eqz v5, :cond_2f

    .line 1417
    .line 1418
    invoke-virtual {v4}, Lcom/luck/picture/lib/entity/LocalMedia;->getHeight()I

    .line 1419
    .line 1420
    .line 1421
    move-result v5

    .line 1422
    if-nez v5, :cond_2e

    .line 1423
    .line 1424
    :cond_2f
    invoke-virtual {v4}, Lcom/luck/picture/lib/entity/LocalMedia;->getMimeType()Ljava/lang/String;

    .line 1425
    .line 1426
    .line 1427
    move-result-object v5

    .line 1428
    invoke-static {v5}, Lcom/luck/picture/lib/config/PictureMimeType;->isHasImage(Ljava/lang/String;)Z

    .line 1429
    .line 1430
    .line 1431
    move-result v5

    .line 1432
    if-eqz v5, :cond_2e

    .line 1433
    .line 1434
    invoke-virtual {v4}, Lcom/luck/picture/lib/entity/LocalMedia;->getPath()Ljava/lang/String;

    .line 1435
    .line 1436
    .line 1437
    move-result-object v5

    .line 1438
    invoke-static {v13, v5}, Lcom/luck/picture/lib/utils/MediaUtils;->getImageSize(Landroid/content/Context;Ljava/lang/String;)Lcom/luck/picture/lib/entity/MediaExtraInfo;

    .line 1439
    .line 1440
    .line 1441
    move-result-object v5

    .line 1442
    invoke-virtual {v5}, Lcom/luck/picture/lib/entity/MediaExtraInfo;->getWidth()I

    .line 1443
    .line 1444
    .line 1445
    move-result v6

    .line 1446
    invoke-virtual {v4, v6}, Lcom/luck/picture/lib/entity/LocalMedia;->setWidth(I)V

    .line 1447
    .line 1448
    .line 1449
    invoke-virtual {v5}, Lcom/luck/picture/lib/entity/MediaExtraInfo;->getHeight()I

    .line 1450
    .line 1451
    .line 1452
    move-result v5

    .line 1453
    invoke-virtual {v4, v5}, Lcom/luck/picture/lib/entity/LocalMedia;->setHeight(I)V

    .line 1454
    .line 1455
    .line 1456
    goto :goto_f

    .line 1457
    :cond_30
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->w:Lyb/z;

    .line 1458
    .line 1459
    const-string v4, "mSelectedImgAdapter"

    .line 1460
    .line 1461
    if-eqz v0, :cond_33

    .line 1462
    .line 1463
    const-string v5, "list"

    .line 1464
    .line 1465
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1466
    .line 1467
    .line 1468
    iget-object v0, v0, Lyb/z;->b:Ljava/util/ArrayList;

    .line 1469
    .line 1470
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 1471
    .line 1472
    .line 1473
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 1474
    .line 1475
    .line 1476
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->w:Lyb/z;

    .line 1477
    .line 1478
    if-eqz v0, :cond_32

    .line 1479
    .line 1480
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 1481
    .line 1482
    .line 1483
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->f:Lxf/t;

    .line 1484
    .line 1485
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1486
    .line 1487
    .line 1488
    move-result-object v0

    .line 1489
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1490
    .line 1491
    .line 1492
    check-cast v0, Landroid/widget/TextView;

    .line 1493
    .line 1494
    sget v2, LYa/g;->cs_max_screen:I

    .line 1495
    .line 1496
    iget-object v3, v13, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->w:Lyb/z;

    .line 1497
    .line 1498
    if-eqz v3, :cond_31

    .line 1499
    .line 1500
    iget-object v3, v3, Lyb/z;->b:Ljava/util/ArrayList;

    .line 1501
    .line 1502
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 1503
    .line 1504
    .line 1505
    move-result v3

    .line 1506
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1507
    .line 1508
    .line 1509
    move-result-object v3

    .line 1510
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 1511
    .line 1512
    .line 1513
    move-result-object v3

    .line 1514
    invoke-virtual {v13, v2, v3}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1515
    .line 1516
    .line 1517
    move-result-object v2

    .line 1518
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1519
    .line 1520
    .line 1521
    goto :goto_10

    .line 1522
    :cond_31
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1523
    .line 1524
    .line 1525
    const/16 v20, 0x0

    .line 1526
    .line 1527
    throw v20

    .line 1528
    :cond_32
    const/16 v20, 0x0

    .line 1529
    .line 1530
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1531
    .line 1532
    .line 1533
    throw v20

    .line 1534
    :cond_33
    const/16 v20, 0x0

    .line 1535
    .line 1536
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1537
    .line 1538
    .line 1539
    throw v20

    .line 1540
    :cond_34
    :goto_10
    return-void

    .line 1541
    :pswitch_6
    move-object v3, v0

    .line 1542
    check-cast v3, Landroid/net/Uri;

    .line 1543
    .line 1544
    if-eqz v3, :cond_3b

    .line 1545
    .line 1546
    check-cast v13, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;

    .line 1547
    .line 1548
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->j1:Ljava/lang/Integer;

    .line 1549
    .line 1550
    if-eqz v0, :cond_3c

    .line 1551
    .line 1552
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 1553
    .line 1554
    .line 1555
    move-result v8

    .line 1556
    const-string v0, "display_name"

    .line 1557
    .line 1558
    filled-new-array {v0}, [Ljava/lang/String;

    .line 1559
    .line 1560
    .line 1561
    move-result-object v4

    .line 1562
    :try_start_0
    invoke-virtual {v13}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 1563
    .line 1564
    .line 1565
    move-result-object v2

    .line 1566
    const/4 v6, 0x0

    .line 1567
    const/4 v7, 0x0

    .line 1568
    const/4 v5, 0x0

    .line 1569
    invoke-virtual/range {v2 .. v7}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    .line 1570
    .line 1571
    .line 1572
    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 1573
    if-eqz v2, :cond_36

    .line 1574
    .line 1575
    :try_start_1
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 1576
    .line 1577
    .line 1578
    move-result v4

    .line 1579
    if-eqz v4, :cond_37

    .line 1580
    .line 1581
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 1582
    .line 1583
    .line 1584
    move-result v0

    .line 1585
    const/4 v4, -0x1

    .line 1586
    if-eq v0, v4, :cond_35

    .line 1587
    .line 1588
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 1589
    .line 1590
    .line 1591
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 1592
    :try_start_2
    invoke-interface {v2}, Ljava/io/Closeable;->close()V

    .line 1593
    .line 1594
    .line 1595
    move-object v9, v0

    .line 1596
    goto :goto_13

    .line 1597
    :catchall_0
    move-exception v0

    .line 1598
    move-object v4, v0

    .line 1599
    goto :goto_12

    .line 1600
    :cond_35
    invoke-interface {v2}, Ljava/io/Closeable;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 1601
    .line 1602
    .line 1603
    :cond_36
    :goto_11
    const/4 v9, 0x0

    .line 1604
    goto :goto_13

    .line 1605
    :cond_37
    :try_start_3
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 1606
    .line 1607
    :try_start_4
    invoke-interface {v2}, Ljava/io/Closeable;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 1608
    .line 1609
    .line 1610
    goto :goto_11

    .line 1611
    :goto_12
    :try_start_5
    throw v4
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 1612
    :catchall_1
    move-exception v0

    .line 1613
    :try_start_6
    invoke-static {v2, v4}, Lorg/chromium/support_lib_boundary/util/b;->o(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1614
    .line 1615
    .line 1616
    throw v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    .line 1617
    :catch_0
    move-exception v0

    .line 1618
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 1619
    .line 1620
    .line 1621
    goto :goto_11

    .line 1622
    :goto_13
    const-string v0, "data1"

    .line 1623
    .line 1624
    filled-new-array {v0}, [Ljava/lang/String;

    .line 1625
    .line 1626
    .line 1627
    move-result-object v4

    .line 1628
    :try_start_7
    invoke-virtual {v13}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 1629
    .line 1630
    .line 1631
    move-result-object v2

    .line 1632
    const/4 v6, 0x0

    .line 1633
    const/4 v7, 0x0

    .line 1634
    const/4 v5, 0x0

    .line 1635
    invoke-virtual/range {v2 .. v7}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    .line 1636
    .line 1637
    .line 1638
    move-result-object v2
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_1

    .line 1639
    if-eqz v2, :cond_39

    .line 1640
    .line 1641
    :try_start_8
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 1642
    .line 1643
    .line 1644
    move-result v3

    .line 1645
    if-eqz v3, :cond_3a

    .line 1646
    .line 1647
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 1648
    .line 1649
    .line 1650
    move-result v0

    .line 1651
    const/4 v4, -0x1

    .line 1652
    if-eq v0, v4, :cond_38

    .line 1653
    .line 1654
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 1655
    .line 1656
    .line 1657
    move-result-object v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 1658
    :try_start_9
    invoke-interface {v2}, Ljava/io/Closeable;->close()V

    .line 1659
    .line 1660
    .line 1661
    goto :goto_16

    .line 1662
    :catchall_2
    move-exception v0

    .line 1663
    move-object v3, v0

    .line 1664
    goto :goto_15

    .line 1665
    :cond_38
    invoke-interface {v2}, Ljava/io/Closeable;->close()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_1

    .line 1666
    .line 1667
    .line 1668
    :cond_39
    :goto_14
    const/4 v0, 0x0

    .line 1669
    goto :goto_16

    .line 1670
    :cond_3a
    :try_start_a
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .line 1671
    .line 1672
    :try_start_b
    invoke-interface {v2}, Ljava/io/Closeable;->close()V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_1

    .line 1673
    .line 1674
    .line 1675
    goto :goto_14

    .line 1676
    :goto_15
    :try_start_c
    throw v3
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    .line 1677
    :catchall_3
    move-exception v0

    .line 1678
    :try_start_d
    invoke-static {v2, v3}, Lorg/chromium/support_lib_boundary/util/b;->o(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1679
    .line 1680
    .line 1681
    throw v0
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_1

    .line 1682
    :catch_1
    move-exception v0

    .line 1683
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 1684
    .line 1685
    .line 1686
    goto :goto_14

    .line 1687
    :goto_16
    invoke-virtual {v13, v8, v9, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Z(ILjava/lang/String;Ljava/lang/String;)V

    .line 1688
    .line 1689
    .line 1690
    goto :goto_17

    .line 1691
    :cond_3b
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 1692
    .line 1693
    :cond_3c
    :goto_17
    return-void

    .line 1694
    :pswitch_7
    check-cast v0, Ljava/util/Map;

    .line 1695
    .line 1696
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/LoanLocationRequestPermissionActivity;->b:I

    .line 1697
    .line 1698
    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1699
    .line 1700
    .line 1701
    new-instance v0, Ljava/util/ArrayList;

    .line 1702
    .line 1703
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1704
    .line 1705
    .line 1706
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 1707
    .line 1708
    .line 1709
    move-result-object v3

    .line 1710
    filled-new-array {v3}, [Ljava/lang/String;

    .line 1711
    .line 1712
    .line 1713
    move-result-object v3

    .line 1714
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 1715
    .line 1716
    .line 1717
    move-result v3

    .line 1718
    if-nez v3, :cond_3d

    .line 1719
    .line 1720
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 1721
    .line 1722
    .line 1723
    move-result-object v3

    .line 1724
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1725
    .line 1726
    .line 1727
    :cond_3d
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 1728
    .line 1729
    .line 1730
    move-result v0

    .line 1731
    move-object v3, v13

    .line 1732
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/activity/LoanLocationRequestPermissionActivity;

    .line 1733
    .line 1734
    const-string v4, "RequestPermission"

    .line 1735
    .line 1736
    if-nez v0, :cond_3e

    .line 1737
    .line 1738
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 1739
    .line 1740
    .line 1741
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 1742
    .line 1743
    .line 1744
    move-result-object v0

    .line 1745
    new-instance v2, Lorg/sufficientlysecure/htmltextview/m;

    .line 1746
    .line 1747
    const/16 v3, 0xa

    .line 1748
    .line 1749
    invoke-direct {v2, v3}, Lorg/sufficientlysecure/htmltextview/m;-><init>(I)V

    .line 1750
    .line 1751
    .line 1752
    sget-object v3, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1753
    .line 1754
    iget-object v0, v0, LPa/w;->b:Ljava/lang/Object;

    .line 1755
    .line 1756
    check-cast v0, Lcom/google/gson/Gson;

    .line 1757
    .line 1758
    invoke-virtual {v0, v2}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 1759
    .line 1760
    .line 1761
    move-result-object v0

    .line 1762
    const/4 v2, 0x0

    .line 1763
    invoke-static {v4, v0, v2}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1764
    .line 1765
    .line 1766
    goto :goto_18

    .line 1767
    :cond_3e
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 1768
    .line 1769
    .line 1770
    move-result-object v0

    .line 1771
    new-instance v5, Lorg/sufficientlysecure/htmltextview/m;

    .line 1772
    .line 1773
    const/16 v6, 0xa

    .line 1774
    .line 1775
    invoke-direct {v5, v6}, Lorg/sufficientlysecure/htmltextview/m;-><init>(I)V

    .line 1776
    .line 1777
    .line 1778
    sget-object v6, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1779
    .line 1780
    iget-object v0, v0, LPa/w;->b:Ljava/lang/Object;

    .line 1781
    .line 1782
    check-cast v0, Lcom/google/gson/Gson;

    .line 1783
    .line 1784
    invoke-virtual {v0, v5}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 1785
    .line 1786
    .line 1787
    move-result-object v0

    .line 1788
    const/4 v5, 0x0

    .line 1789
    invoke-static {v4, v0, v5}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1790
    .line 1791
    .line 1792
    new-instance v0, Ljava/util/ArrayList;

    .line 1793
    .line 1794
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1795
    .line 1796
    .line 1797
    filled-new-array {v11}, [Ljava/lang/String;

    .line 1798
    .line 1799
    .line 1800
    move-result-object v4

    .line 1801
    invoke-static {v4}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 1802
    .line 1803
    .line 1804
    move-result v4

    .line 1805
    if-eqz v4, :cond_3f

    .line 1806
    .line 1807
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 1808
    .line 1809
    .line 1810
    move-result-object v4

    .line 1811
    filled-new-array {v4}, [Ljava/lang/String;

    .line 1812
    .line 1813
    .line 1814
    move-result-object v4

    .line 1815
    invoke-static {v4}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 1816
    .line 1817
    .line 1818
    move-result v4

    .line 1819
    if-nez v4, :cond_40

    .line 1820
    .line 1821
    :cond_3f
    new-instance v9, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;

    .line 1822
    .line 1823
    sget-object v4, LS6/a;->P0:LS6/a;

    .line 1824
    .line 1825
    sget v5, LL6/b;->ppColorTextPrimary:I

    .line 1826
    .line 1827
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1828
    .line 1829
    .line 1830
    move-result-object v6

    .line 1831
    const/high16 v7, 0x41c00000    # 24.0f

    .line 1832
    .line 1833
    const/16 v8, 0x72

    .line 1834
    .line 1835
    const/4 v5, 0x0

    .line 1836
    invoke-static/range {v3 .. v8}, LG8/a;->x(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;Ljava/lang/Integer;Ljava/lang/Integer;FI)Lcom/mikepenz/iconics/IconicsDrawable;

    .line 1837
    .line 1838
    .line 1839
    move-result-object v4

    .line 1840
    invoke-direct {v9, v4, v2}, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V

    .line 1841
    .line 1842
    .line 1843
    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1844
    .line 1845
    .line 1846
    :cond_40
    new-instance v2, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;

    .line 1847
    .line 1848
    invoke-direct {v2, v3, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;-><init>(Landroid/content/Context;Ljava/util/ArrayList;)V

    .line 1849
    .line 1850
    .line 1851
    new-instance v0, Lsb/m;

    .line 1852
    .line 1853
    invoke-direct {v0, v3}, Lsb/m;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/LoanLocationRequestPermissionActivity;)V

    .line 1854
    .line 1855
    .line 1856
    invoke-virtual {v2, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog;->setListener(Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog$NoPermissionDialogInterface;)V

    .line 1857
    .line 1858
    .line 1859
    new-instance v0, LDd/b;

    .line 1860
    .line 1861
    const/16 v4, 0x1b

    .line 1862
    .line 1863
    invoke-direct {v0, v3, v4}, LDd/b;-><init>(Ljava/lang/Object;I)V

    .line 1864
    .line 1865
    .line 1866
    invoke-virtual {v2, v0}, LO6/f;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 1867
    .line 1868
    .line 1869
    invoke-virtual {v2}, LO6/f;->show()V

    .line 1870
    .line 1871
    .line 1872
    :goto_18
    return-void

    .line 1873
    :pswitch_8
    check-cast v0, Landroidx/activity/result/ActivityResult;

    .line 1874
    .line 1875
    sget-object v2, Lcom/transsnet/palmpay/betting/ui/activity/BettingHomeActivity;->w0:[Lkotlin/reflect/KProperty;

    .line 1876
    .line 1877
    invoke-static {v0, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1878
    .line 1879
    .line 1880
    iget v2, v0, Landroidx/activity/result/ActivityResult;->a:I

    .line 1881
    .line 1882
    const/4 v4, -0x1

    .line 1883
    if-ne v2, v4, :cond_41

    .line 1884
    .line 1885
    iget-object v0, v0, Landroidx/activity/result/ActivityResult;->b:Landroid/content/Intent;

    .line 1886
    .line 1887
    if-eqz v0, :cond_41

    .line 1888
    .line 1889
    const-string v2, "extra_data_1"

    .line 1890
    .line 1891
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 1892
    .line 1893
    .line 1894
    move-result-object v2

    .line 1895
    const-string v3, "customerId"

    .line 1896
    .line 1897
    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 1898
    .line 1899
    .line 1900
    move-result-object v0

    .line 1901
    check-cast v13, Lcom/transsnet/palmpay/betting/ui/activity/BettingHomeActivity;

    .line 1902
    .line 1903
    invoke-virtual {v13, v2, v0}, Lcom/transsnet/palmpay/betting/ui/activity/BettingHomeActivity;->v(Ljava/lang/String;Ljava/lang/String;)V

    .line 1904
    .line 1905
    .line 1906
    :cond_41
    return-void

    .line 1907
    :pswitch_9
    check-cast v0, Ljava/lang/String;

    .line 1908
    .line 1909
    check-cast v13, Lcom/transsnet/palmpay/airtime/ui/TopUpRecordActivity;

    .line 1910
    .line 1911
    iget-object v2, v13, Lcom/transsnet/palmpay/airtime/ui/TopUpRecordActivity;->e:Ljava/util/ArrayList;

    .line 1912
    .line 1913
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1914
    .line 1915
    .line 1916
    move-result-object v2

    .line 1917
    :cond_42
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1918
    .line 1919
    .line 1920
    move-result v3

    .line 1921
    if-eqz v3, :cond_43

    .line 1922
    .line 1923
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1924
    .line 1925
    .line 1926
    move-result-object v3

    .line 1927
    move-object v4, v3

    .line 1928
    check-cast v4, Lcom/transsnet/palmpay/airtime/bean/AirtimeOrderList$OrderData;

    .line 1929
    .line 1930
    iget-object v4, v4, Lcom/transsnet/palmpay/airtime/bean/AirtimeOrderList$OrderData;->orderNo:Ljava/lang/String;

    .line 1931
    .line 1932
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1933
    .line 1934
    .line 1935
    move-result v4

    .line 1936
    if-eqz v4, :cond_42

    .line 1937
    .line 1938
    goto :goto_19

    .line 1939
    :cond_43
    const/4 v3, 0x0

    .line 1940
    :goto_19
    check-cast v3, Lcom/transsnet/palmpay/airtime/bean/AirtimeOrderList$OrderData;

    .line 1941
    .line 1942
    if-eqz v3, :cond_44

    .line 1943
    .line 1944
    const/16 v0, 0x17

    .line 1945
    .line 1946
    iput v0, v3, Lcom/transsnet/palmpay/airtime/bean/AirtimeOrderList$OrderData;->orderStatus:I

    .line 1947
    .line 1948
    invoke-virtual {v13}, Lcom/transsnet/palmpay/airtime/ui/TopUpRecordActivity;->n()Lk9/q;

    .line 1949
    .line 1950
    .line 1951
    move-result-object v0

    .line 1952
    iget-object v2, v13, Lcom/transsnet/palmpay/airtime/ui/TopUpRecordActivity;->e:Ljava/util/ArrayList;

    .line 1953
    .line 1954
    iput-object v2, v0, LKb/c;->b:Ljava/util/List;

    .line 1955
    .line 1956
    invoke-virtual {v13}, Lcom/transsnet/palmpay/airtime/ui/TopUpRecordActivity;->n()Lk9/q;

    .line 1957
    .line 1958
    .line 1959
    move-result-object v0

    .line 1960
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 1961
    .line 1962
    .line 1963
    :cond_44
    return-void

    .line 1964
    :pswitch_a
    check-cast v0, Ljava/util/Map;

    .line 1965
    .line 1966
    sget v2, Lcom/transsnet/palmpay/core/ui/activity/FlexiPayOneClickOpenActivity;->e:I

    .line 1967
    .line 1968
    invoke-static {v0, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1969
    .line 1970
    .line 1971
    check-cast v13, Lcom/transsnet/palmpay/core/ui/activity/FlexiPayOneClickOpenActivity;

    .line 1972
    .line 1973
    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    .line 1974
    .line 1975
    .line 1976
    move-result v2

    .line 1977
    const/16 v3, 0xe

    .line 1978
    .line 1979
    if-eqz v2, :cond_45

    .line 1980
    .line 1981
    goto :goto_1a

    .line 1982
    :cond_45
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 1983
    .line 1984
    .line 1985
    move-result-object v0

    .line 1986
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 1987
    .line 1988
    .line 1989
    move-result-object v0

    .line 1990
    :cond_46
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1991
    .line 1992
    .line 1993
    move-result v2

    .line 1994
    if-eqz v2, :cond_47

    .line 1995
    .line 1996
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1997
    .line 1998
    .line 1999
    move-result-object v2

    .line 2000
    check-cast v2, Ljava/util/Map$Entry;

    .line 2001
    .line 2002
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 2003
    .line 2004
    .line 2005
    move-result-object v2

    .line 2006
    check-cast v2, Ljava/lang/Boolean;

    .line 2007
    .line 2008
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 2009
    .line 2010
    .line 2011
    move-result v2

    .line 2012
    if-nez v2, :cond_46

    .line 2013
    .line 2014
    const/4 v2, 0x0

    .line 2015
    invoke-static {v13, v5, v2, v2, v3}, Lcom/transsnet/palmpay/core/ui/activity/FlexiPayOneClickOpenActivity;->o(Lcom/transsnet/palmpay/core/ui/activity/FlexiPayOneClickOpenActivity;ILjava/lang/String;Ljava/lang/String;I)V

    .line 2016
    .line 2017
    .line 2018
    goto :goto_1d

    .line 2019
    :cond_47
    :goto_1a
    filled-new-array {v4}, [Ljava/lang/String;

    .line 2020
    .line 2021
    .line 2022
    move-result-object v0

    .line 2023
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 2024
    .line 2025
    .line 2026
    move-result v0

    .line 2027
    if-eqz v0, :cond_48

    .line 2028
    .line 2029
    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    .line 2030
    .line 2031
    filled-new-array {v0}, [Ljava/lang/String;

    .line 2032
    .line 2033
    .line 2034
    move-result-object v0

    .line 2035
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 2036
    .line 2037
    .line 2038
    move-result v0

    .line 2039
    if-nez v0, :cond_49

    .line 2040
    .line 2041
    filled-new-array {v11}, [Ljava/lang/String;

    .line 2042
    .line 2043
    .line 2044
    move-result-object v0

    .line 2045
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 2046
    .line 2047
    .line 2048
    move-result v0

    .line 2049
    if-eqz v0, :cond_48

    .line 2050
    .line 2051
    goto :goto_1b

    .line 2052
    :cond_48
    const/4 v2, 0x0

    .line 2053
    goto :goto_1c

    .line 2054
    :cond_49
    :goto_1b
    invoke-virtual {v13}, Lcom/transsnet/palmpay/core/ui/activity/FlexiPayOneClickOpenActivity;->r()V

    .line 2055
    .line 2056
    .line 2057
    goto :goto_1d

    .line 2058
    :goto_1c
    invoke-static {v13, v5, v2, v2, v3}, Lcom/transsnet/palmpay/core/ui/activity/FlexiPayOneClickOpenActivity;->o(Lcom/transsnet/palmpay/core/ui/activity/FlexiPayOneClickOpenActivity;ILjava/lang/String;Ljava/lang/String;I)V

    .line 2059
    .line 2060
    .line 2061
    :goto_1d
    return-void

    .line 2062
    :pswitch_b
    check-cast v13, Lcom/transsnet/palmpay/core/rnbridge/bridge/MfbBankSdkManagerBridge;

    .line 2063
    .line 2064
    check-cast v0, LJ3/e;

    .line 2065
    .line 2066
    invoke-static {v13, v0}, Lcom/transsnet/palmpay/core/rnbridge/bridge/MfbBankSdkManagerBridge;->c(Lcom/transsnet/palmpay/core/rnbridge/bridge/MfbBankSdkManagerBridge;LJ3/e;)V

    .line 2067
    .line 2068
    .line 2069
    return-void

    .line 2070
    :pswitch_c
    check-cast v0, Landroidx/activity/result/ActivityResult;

    .line 2071
    .line 2072
    iget v2, v0, Landroidx/activity/result/ActivityResult;->a:I

    .line 2073
    .line 2074
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2075
    .line 2076
    .line 2077
    move-result-object v2

    .line 2078
    iget-object v0, v0, Landroidx/activity/result/ActivityResult;->b:Landroid/content/Intent;

    .line 2079
    .line 2080
    check-cast v13, Lcom/transsnet/palmpay/core/callback/Argument2Callback;

    .line 2081
    .line 2082
    invoke-interface {v13, v2, v0}, Lcom/transsnet/palmpay/core/callback/Argument2Callback;->invoke(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2083
    .line 2084
    .line 2085
    return-void

    .line 2086
    :pswitch_d
    check-cast v0, Landroidx/activity/result/ActivityResult;

    .line 2087
    .line 2088
    invoke-static {v0, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2089
    .line 2090
    .line 2091
    iget v2, v0, Landroidx/activity/result/ActivityResult;->a:I

    .line 2092
    .line 2093
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2094
    .line 2095
    .line 2096
    move-result-object v2

    .line 2097
    check-cast v13, LN8/a;

    .line 2098
    .line 2099
    iget-object v0, v0, Landroidx/activity/result/ActivityResult;->b:Landroid/content/Intent;

    .line 2100
    .line 2101
    invoke-virtual {v13, v2, v0}, LN8/a;->invoke(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2102
    .line 2103
    .line 2104
    return-void

    .line 2105
    :pswitch_e
    check-cast v13, LV3/d;

    .line 2106
    .line 2107
    iget-object v2, v13, LV3/d;->c:Ljava/lang/Object;

    .line 2108
    .line 2109
    check-cast v2, Landroidx/activity/result/ActivityResultCallback;

    .line 2110
    .line 2111
    if-eqz v2, :cond_4a

    .line 2112
    .line 2113
    invoke-interface {v2, v0}, Landroidx/activity/result/ActivityResultCallback;->onActivityResult(Ljava/lang/Object;)V

    .line 2114
    .line 2115
    .line 2116
    const/4 v2, 0x0

    .line 2117
    iput-object v2, v13, LV3/d;->c:Ljava/lang/Object;

    .line 2118
    .line 2119
    goto :goto_1e

    .line 2120
    :cond_4a
    iget-object v2, v13, LV3/d;->d:Ljava/lang/Object;

    .line 2121
    .line 2122
    check-cast v2, Landroidx/lifecycle/F;

    .line 2123
    .line 2124
    if-nez v2, :cond_4b

    .line 2125
    .line 2126
    new-instance v2, Landroidx/lifecycle/F;

    .line 2127
    .line 2128
    invoke-direct {v2}, Landroidx/lifecycle/B;-><init>()V

    .line 2129
    .line 2130
    .line 2131
    iput-object v2, v13, LV3/d;->d:Ljava/lang/Object;

    .line 2132
    .line 2133
    :cond_4b
    iget-object v2, v13, LV3/d;->d:Ljava/lang/Object;

    .line 2134
    .line 2135
    check-cast v2, Landroidx/lifecycle/F;

    .line 2136
    .line 2137
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 2138
    .line 2139
    .line 2140
    invoke-virtual {v2, v0}, Landroidx/lifecycle/B;->k(Ljava/lang/Object;)V

    .line 2141
    .line 2142
    .line 2143
    :goto_1e
    return-void

    .line 2144
    :pswitch_f
    check-cast v0, Ljava/lang/Boolean;

    .line 2145
    .line 2146
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 2147
    .line 2148
    .line 2149
    move-result v0

    .line 2150
    sget v2, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->k0:I

    .line 2151
    .line 2152
    check-cast v13, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;

    .line 2153
    .line 2154
    if-eqz v0, :cond_4c

    .line 2155
    .line 2156
    invoke-virtual {v13}, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->p()LUc/w0;

    .line 2157
    .line 2158
    .line 2159
    move-result-object v0

    .line 2160
    iget-object v0, v0, LUc/w0;->b:Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;

    .line 2161
    .line 2162
    iget-object v0, v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->C:Lxf/t;

    .line 2163
    .line 2164
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 2165
    .line 2166
    .line 2167
    move-result-object v0

    .line 2168
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2169
    .line 2170
    .line 2171
    check-cast v0, Landroid/widget/FrameLayout;

    .line 2172
    .line 2173
    invoke-static {v0}, Loa/h;->c(Landroid/view/View;)V

    .line 2174
    .line 2175
    .line 2176
    invoke-virtual {v13}, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->n()LUc/o0;

    .line 2177
    .line 2178
    .line 2179
    move-result-object v0

    .line 2180
    invoke-virtual {v0}, LUc/o0;->b()V

    .line 2181
    .line 2182
    .line 2183
    invoke-virtual {v13}, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->p()LUc/w0;

    .line 2184
    .line 2185
    .line 2186
    move-result-object v0

    .line 2187
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2188
    .line 2189
    .line 2190
    invoke-virtual {v13}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 2191
    .line 2192
    .line 2193
    move-result-object v0

    .line 2194
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 2195
    .line 2196
    .line 2197
    move-result-object v0

    .line 2198
    new-instance v2, LM7/s;

    .line 2199
    .line 2200
    const/16 v3, 0x15

    .line 2201
    .line 2202
    invoke-direct {v2, v13, v3}, LM7/s;-><init>(Ljava/lang/Object;I)V

    .line 2203
    .line 2204
    .line 2205
    const-wide/16 v3, 0x7d0

    .line 2206
    .line 2207
    invoke-virtual {v0, v2, v3, v4}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 2208
    .line 2209
    .line 2210
    goto :goto_1f

    .line 2211
    :cond_4c
    invoke-virtual {v13}, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->p()LUc/w0;

    .line 2212
    .line 2213
    .line 2214
    move-result-object v0

    .line 2215
    iget-object v0, v0, LUc/w0;->b:Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;

    .line 2216
    .line 2217
    iget-object v0, v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/NearbyAgent2Page;->C:Lxf/t;

    .line 2218
    .line 2219
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 2220
    .line 2221
    .line 2222
    move-result-object v0

    .line 2223
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2224
    .line 2225
    .line 2226
    check-cast v0, Landroid/widget/FrameLayout;

    .line 2227
    .line 2228
    invoke-static {v0}, Loa/h;->C(Landroid/view/View;)V

    .line 2229
    .line 2230
    .line 2231
    :goto_1f
    return-void

    .line 2232
    :pswitch_10
    check-cast v0, Ljava/lang/Boolean;

    .line 2233
    .line 2234
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 2235
    .line 2236
    const-string v2, "isGranted"

    .line 2237
    .line 2238
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2239
    .line 2240
    .line 2241
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 2242
    .line 2243
    .line 2244
    move-result v0

    .line 2245
    check-cast v13, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    .line 2246
    .line 2247
    if-eqz v0, :cond_4e

    .line 2248
    .line 2249
    invoke-virtual {v13}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2250
    .line 2251
    .line 2252
    move-result-object v0

    .line 2253
    if-eqz v0, :cond_4d

    .line 2254
    .line 2255
    new-instance v2, LAe/n;

    .line 2256
    .line 2257
    const/16 v3, 0x10

    .line 2258
    .line 2259
    invoke-direct {v2, v13, v3}, LAe/n;-><init>(Ljava/lang/Object;I)V

    .line 2260
    .line 2261
    .line 2262
    const-wide/16 v3, 0x3e8

    .line 2263
    .line 2264
    invoke-virtual {v0, v2, v3, v4}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 2265
    .line 2266
    .line 2267
    :cond_4d
    invoke-virtual {v13}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2268
    .line 2269
    .line 2270
    move-result-object v0

    .line 2271
    if-eqz v0, :cond_4f

    .line 2272
    .line 2273
    invoke-static {v0}, Loa/h;->c(Landroid/view/View;)V

    .line 2274
    .line 2275
    .line 2276
    goto :goto_20

    .line 2277
    :cond_4e
    invoke-virtual {v13}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2278
    .line 2279
    .line 2280
    move-result-object v0

    .line 2281
    if-eqz v0, :cond_4f

    .line 2282
    .line 2283
    invoke-static {v0}, Loa/h;->C(Landroid/view/View;)V

    .line 2284
    .line 2285
    .line 2286
    :cond_4f
    :goto_20
    return-void

    .line 2287
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
