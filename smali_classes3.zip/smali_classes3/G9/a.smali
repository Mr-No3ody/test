.class public final synthetic LG9/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/a;->a:I

    iput-object p1, p0, LG9/a;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LG9/a;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;

    .line 3
    .line 4
    iget v2, p0, LG9/a;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->C:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment$a;

    .line 10
    .line 11
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    sget v0, Ly9/b;->title_bar:I

    .line 16
    .line 17
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 22
    .line 23
    :cond_0
    return-object v0

    .line 24
    :pswitch_0
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->C:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment$a;

    .line 25
    .line 26
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 27
    .line 28
    if-eqz v1, :cond_1

    .line 29
    .line 30
    sget v0, Ly9/b;->orlm_header:I

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 37
    .line 38
    :cond_1
    return-object v0

    .line 39
    :pswitch_1
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->C:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment$a;

    .line 40
    .line 41
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 42
    .line 43
    if-eqz v1, :cond_2

    .line 44
    .line 45
    sget v0, Ly9/b;->ll_fee_detail:I

    .line 46
    .line 47
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Landroid/widget/LinearLayout;

    .line 52
    .line 53
    :cond_2
    return-object v0

    .line 54
    :pswitch_2
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->C:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment$a;

    .line 55
    .line 56
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 57
    .line 58
    if-eqz v1, :cond_3

    .line 59
    .line 60
    sget v0, Ly9/b;->ll_container_middle:I

    .line 61
    .line 62
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    check-cast v0, Landroid/widget/LinearLayout;

    .line 67
    .line 68
    :cond_3
    return-object v0

    .line 69
    :pswitch_3
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->C:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment$a;

    .line 70
    .line 71
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 72
    .line 73
    if-eqz v1, :cond_4

    .line 74
    .line 75
    sget v0, Ly9/b;->model_order_result_customer_service:I

    .line 76
    .line 77
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/OrderResultCustomerServiceModel;

    .line 82
    .line 83
    :cond_4
    return-object v0

    .line 84
    :pswitch_4
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->C:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment$a;

    .line 85
    .line 86
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 87
    .line 88
    if-eqz v1, :cond_5

    .line 89
    .line 90
    sget v0, Ly9/b;->btn_view_receipt:I

    .line 91
    .line 92
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/OrderResultViewReceiptModel;

    .line 97
    .line 98
    :cond_5
    return-object v0

    .line 99
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
