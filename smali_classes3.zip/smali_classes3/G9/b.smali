.class public final synthetic LG9/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LG9/b;->a:I

    iput-object p1, p0, LG9/b;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget-object p1, p0, LG9/b;->b:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;

    .line 2
    .line 3
    iget v0, p0, LG9/b;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->B:Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;

    .line 9
    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    const-string v1, "/cash_in_out/trans_receipt"

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    const-string v1, "transType"

    .line 23
    .line 24
    iget-object v2, p1, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->transType:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const-string v1, "orderId"

    .line 31
    .line 32
    iget-object p1, p1, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->orderId:Ljava/lang/String;

    .line 33
    .line 34
    invoke-virtual {v0, v1, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    :cond_0
    return-void

    .line 42
    :pswitch_0
    sget-object v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment;->C:Lcom/transsnet/palmpay/cash_in/ui/fragment/BindBankCardDetailFragment$a;

    .line 43
    .line 44
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    nop

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
