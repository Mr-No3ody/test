.class public final LG6/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/growingio/android/sdk/track/middleware/IEventNetSender;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    iput p1, p0, LG6/b;->a:I

    packed-switch p1, :pswitch_data_0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void

    .line 1
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-static {}, Ls5/d;->b()Ls5/d;

    move-result-object p1

    .line 3
    iget-object p1, p1, Ls5/d;->b:Ljava/lang/Object;

    check-cast p1, Lcom/growingio/android/sdk/a;

    iget-object v0, p1, Lcom/growingio/android/sdk/a;->a:Ljava/lang/String;

    .line 4
    iput-object v0, p0, LG6/b;->b:Ljava/lang/String;

    .line 5
    iget-object p1, p1, Lcom/growingio/android/sdk/a;->j:Ljava/lang/String;

    .line 6
    iput-object p1, p0, LG6/b;->c:Ljava/lang/String;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LG6/b;->a:I

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput-object p1, p0, LG6/b;->b:Ljava/lang/String;

    .line 9
    iput-object p2, p0, LG6/b;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public send([BLjava/lang/String;)Lo5/e;
    .locals 10

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    if-eqz p1, :cond_9

    .line 5
    .line 6
    array-length v3, p1

    .line 7
    if-nez v3, :cond_0

    .line 8
    .line 9
    goto/16 :goto_4

    .line 10
    .line 11
    :cond_0
    invoke-static {}, Lcom/growingio/android/sdk/d;->a()Lcom/growingio/android/sdk/d;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    iget-object v3, v3, Lcom/growingio/android/sdk/d;->a:Lq5/c;

    .line 16
    .line 17
    const-class v4, Lj5/c;

    .line 18
    .line 19
    invoke-virtual {v3, v4}, Lq5/c;->a(Ljava/lang/Class;)Lcom/growingio/android/sdk/track/modelloader/ModelLoader;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    const-string v5, "EventHttpSender"

    .line 24
    .line 25
    if-nez v3, :cond_1

    .line 26
    .line 27
    const-string p1, "please register http request component first"

    .line 28
    .line 29
    new-array p2, v2, [Ljava/lang/Object;

    .line 30
    .line 31
    invoke-static {v5, p1, p2}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    new-instance p1, Lo5/e;

    .line 35
    .line 36
    invoke-direct {p1, v0, v1, v2}, Lo5/e;-><init>(JZ)V

    .line 37
    .line 38
    .line 39
    return-object p1

    .line 40
    :cond_1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 41
    .line 42
    .line 43
    move-result-wide v6

    .line 44
    new-instance v3, Lj5/c;

    .line 45
    .line 46
    iget-object v8, p0, LG6/b;->c:Ljava/lang/String;

    .line 47
    .line 48
    invoke-direct {v3, v8}, Lj5/c;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    iget-object v8, v3, Lj5/c;->c:Ljava/util/ArrayList;

    .line 52
    .line 53
    const-string v9, "v3"

    .line 54
    .line 55
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    const-string v9, "projects"

    .line 59
    .line 60
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    iget-object v9, p0, LG6/b;->b:Ljava/lang/String;

    .line 64
    .line 65
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    const-string v9, "collect"

    .line 69
    .line 70
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v6

    .line 77
    iget-object v7, v3, Lj5/c;->d:Ljava/util/HashMap;

    .line 78
    .line 79
    const-string v8, "stm"

    .line 80
    .line 81
    invoke-virtual {v7, v8, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    iput-object p1, v3, Lj5/c;->e:[B

    .line 85
    .line 86
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 87
    .line 88
    .line 89
    move-result p1

    .line 90
    if-nez p1, :cond_2

    .line 91
    .line 92
    iput-object p2, v3, Lj5/c;->f:Ljava/lang/String;

    .line 93
    .line 94
    :cond_2
    invoke-static {}, Lcom/growingio/android/sdk/d;->a()Lcom/growingio/android/sdk/d;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    new-instance p2, Lj5/a;

    .line 99
    .line 100
    invoke-direct {p2, v3}, Lj5/a;-><init>(Lj5/c;)V

    .line 101
    .line 102
    .line 103
    iget-object p1, p1, Lcom/growingio/android/sdk/d;->a:Lq5/c;

    .line 104
    .line 105
    const-class v6, Lj5/a;

    .line 106
    .line 107
    invoke-virtual {p1, v6}, Lq5/c;->a(Ljava/lang/Class;)Lcom/growingio/android/sdk/track/modelloader/ModelLoader;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    if-eqz p1, :cond_3

    .line 112
    .line 113
    invoke-interface {p1, p2}, Lcom/growingio/android/sdk/track/modelloader/ModelLoader;->buildLoadData(Ljava/lang/Object;)Lq5/a;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    iget-object p1, p1, Lq5/a;->a:Lcom/growingio/android/sdk/track/modelloader/DataFetcher;

    .line 118
    .line 119
    invoke-interface {p1}, Lcom/growingio/android/sdk/track/modelloader/DataFetcher;->executeData()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    goto :goto_0

    .line 124
    :cond_3
    const/4 p1, 0x0

    .line 125
    :goto_0
    check-cast p1, Lj5/a;

    .line 126
    .line 127
    if-eqz p1, :cond_4

    .line 128
    .line 129
    iget-object v3, p1, Lj5/a;->a:Lj5/c;

    .line 130
    .line 131
    :cond_4
    iget-object p1, v3, Lj5/c;->e:[B

    .line 132
    .line 133
    invoke-static {}, Lcom/growingio/android/sdk/d;->a()Lcom/growingio/android/sdk/d;

    .line 134
    .line 135
    .line 136
    move-result-object p2

    .line 137
    iget-object p2, p2, Lcom/growingio/android/sdk/d;->a:Lq5/c;

    .line 138
    .line 139
    invoke-virtual {p2, v4}, Lq5/c;->a(Ljava/lang/Class;)Lcom/growingio/android/sdk/track/modelloader/ModelLoader;

    .line 140
    .line 141
    .line 142
    move-result-object p2

    .line 143
    invoke-interface {p2, v3}, Lcom/growingio/android/sdk/track/modelloader/ModelLoader;->buildLoadData(Ljava/lang/Object;)Lq5/a;

    .line 144
    .line 145
    .line 146
    move-result-object p2

    .line 147
    iget-object v3, p2, Lq5/a;->a:Lcom/growingio/android/sdk/track/modelloader/DataFetcher;

    .line 148
    .line 149
    invoke-interface {v3}, Lcom/growingio/android/sdk/track/modelloader/DataFetcher;->getDataClass()Ljava/lang/Class;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    const-class v4, Lj5/b;

    .line 154
    .line 155
    invoke-virtual {v3, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 156
    .line 157
    .line 158
    move-result v3

    .line 159
    if-nez v3, :cond_5

    .line 160
    .line 161
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 162
    .line 163
    const-string p2, "illegal data class for http response."

    .line 164
    .line 165
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    invoke-static {v5, p1}, Ln5/h;->b(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 169
    .line 170
    .line 171
    new-instance p1, Lo5/e;

    .line 172
    .line 173
    invoke-direct {p1, v0, v1, v2}, Lo5/e;-><init>(JZ)V

    .line 174
    .line 175
    .line 176
    return-object p1

    .line 177
    :cond_5
    iget-object p2, p2, Lq5/a;->a:Lcom/growingio/android/sdk/track/modelloader/DataFetcher;

    .line 178
    .line 179
    invoke-interface {p2}, Lcom/growingio/android/sdk/track/modelloader/DataFetcher;->executeData()Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object p2

    .line 183
    check-cast p2, Lj5/b;

    .line 184
    .line 185
    if-eqz p2, :cond_6

    .line 186
    .line 187
    iget-boolean v3, p2, Lj5/b;->a:Z

    .line 188
    .line 189
    if-eqz v3, :cond_6

    .line 190
    .line 191
    const/4 v3, 0x1

    .line 192
    goto :goto_1

    .line 193
    :cond_6
    move v3, v2

    .line 194
    :goto_1
    if-eqz v3, :cond_7

    .line 195
    .line 196
    const-string p2, "Send events successfully"

    .line 197
    .line 198
    new-array v2, v2, [Ljava/lang/Object;

    .line 199
    .line 200
    invoke-static {v5, p2, v2}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    goto :goto_2

    .line 204
    :cond_7
    new-instance v4, Ljava/lang/StringBuilder;

    .line 205
    .line 206
    const-string v6, "Send events failed, response = "

    .line 207
    .line 208
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 212
    .line 213
    .line 214
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object p2

    .line 218
    new-array v2, v2, [Ljava/lang/Object;

    .line 219
    .line 220
    invoke-static {v5, p2, v2}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 221
    .line 222
    .line 223
    :goto_2
    if-nez p1, :cond_8

    .line 224
    .line 225
    goto :goto_3

    .line 226
    :cond_8
    array-length p1, p1

    .line 227
    int-to-long v0, p1

    .line 228
    :goto_3
    new-instance p1, Lo5/e;

    .line 229
    .line 230
    invoke-direct {p1, v0, v1, v3}, Lo5/e;-><init>(JZ)V

    .line 231
    .line 232
    .line 233
    return-object p1

    .line 234
    :cond_9
    :goto_4
    new-instance p1, Lo5/e;

    .line 235
    .line 236
    invoke-direct {p1, v0, v1, v2}, Lo5/e;-><init>(JZ)V

    .line 237
    .line 238
    .line 239
    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    iget v0, p0, LG6/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, LG6/b;->b:Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    const-string v1, "("

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, LG6/b;->c:Ljava/lang/String;

    .line 27
    .line 28
    const-string v2, ")"

    .line 29
    .line 30
    invoke-static {v0, v1, v2}, LC0/G;->r(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0

    .line 35
    :pswitch_1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    const-string v1, "RomInfo{name="

    .line 38
    .line 39
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    iget-object v1, p0, LG6/b;->b:Ljava/lang/String;

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string v1, ", version="

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, LG6/b;->c:Ljava/lang/String;

    .line 53
    .line 54
    const-string/jumbo v2, "}"

    .line 55
    .line 56
    .line 57
    invoke-static {v0, v1, v2}, LC0/G;->r(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    return-object v0

    .line 62
    nop

    .line 63
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
