.class public final LB9/b;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LB9/b;->f:Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, LB9/b;->f:Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, LB9/b;->f:Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 5
    .line 6
    .line 7
    invoke-static {v0, p1}, LB9/c;->l(Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 7

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;

    .line 2
    .line 3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    iget-object v2, p0, LB9/b;->f:Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;

    .line 9
    .line 10
    if-eqz v0, :cond_4

    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    const-string p1, "Server return null"

    .line 19
    .line 20
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iget-boolean v0, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;->flag:Z

    .line 29
    .line 30
    const/16 v3, 0x8

    .line 31
    .line 32
    if-eqz v0, :cond_3

    .line 33
    .line 34
    new-instance v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;

    .line 35
    .line 36
    invoke-direct {v0}, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;-><init>()V

    .line 37
    .line 38
    .line 39
    iget-object v4, v2, LB9/c;->e:Ljava/lang/String;

    .line 40
    .line 41
    iput-object v4, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->orderNo:Ljava/lang/String;

    .line 42
    .line 43
    const-string v4, "3"

    .line 44
    .line 45
    iput-object v4, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->orderType:Ljava/lang/String;

    .line 46
    .line 47
    const-string v4, "02"

    .line 48
    .line 49
    iput-object v4, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->transType:Ljava/lang/String;

    .line 50
    .line 51
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    iget-object v5, v5, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;->payId:Ljava/lang/String;

    .line 56
    .line 57
    iput-object v5, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->payId:Ljava/lang/String;

    .line 58
    .line 59
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 60
    .line 61
    .line 62
    move-result-object v5

    .line 63
    iget-object v5, v5, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;->subPayId:Ljava/lang/String;

    .line 64
    .line 65
    iput-object v5, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->subPayId:Ljava/lang/String;

    .line 66
    .line 67
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 68
    .line 69
    .line 70
    move-result-object v5

    .line 71
    iget-object v5, v5, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;->url:Ljava/lang/String;

    .line 72
    .line 73
    iput-object v5, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->url:Ljava/lang/String;

    .line 74
    .line 75
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 76
    .line 77
    .line 78
    move-result-object v5

    .line 79
    iget v5, v5, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;->verifyMethod:I

    .line 80
    .line 81
    iput v5, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->verifyMethod:I

    .line 82
    .line 83
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    iget-object v5, v5, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;->payRouteId:Ljava/lang/String;

    .line 88
    .line 89
    iput-object v5, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->payRouteId:Ljava/lang/String;

    .line 90
    .line 91
    iget-wide v5, v2, LB9/c;->d:J

    .line 92
    .line 93
    iput-wide v5, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->payAmount:J

    .line 94
    .line 95
    iput-object v4, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->transType:Ljava/lang/String;

    .line 96
    .line 97
    :try_start_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;->orderData:Ljava/lang/String;

    .line 102
    .line 103
    const-string v4, "payFee"

    .line 104
    .line 105
    invoke-static {p1, v4}, LPa/w;->i(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Long;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 110
    .line 111
    .line 112
    move-result-wide v4

    .line 113
    iput-wide v4, v0, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->feeAmount:J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 114
    .line 115
    goto :goto_0

    .line 116
    :catch_0
    move-exception p1

    .line 117
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 118
    .line 119
    .line 120
    :goto_0
    new-instance p1, Lcom/transsnet/palmpay/core/ui/activity/d0;

    .line 121
    .line 122
    invoke-direct {p1, v2}, Lcom/transsnet/palmpay/core/ui/activity/d0;-><init>(Landroid/content/Context;)V

    .line 123
    .line 124
    .line 125
    iput-object v0, p1, Lcom/transsnet/palmpay/core/ui/activity/d0;->b:Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;

    .line 126
    .line 127
    iput-boolean v1, p1, Lcom/transsnet/palmpay/core/ui/activity/d0;->k:Z

    .line 128
    .line 129
    iget-object v0, v2, LB9/c;->b:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 130
    .line 131
    if-nez v0, :cond_1

    .line 132
    .line 133
    move v3, v1

    .line 134
    goto :goto_1

    .line 135
    :cond_1
    const-string v4, "MobileWallet"

    .line 136
    .line 137
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->accountType:Ljava/lang/String;

    .line 138
    .line 139
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    if-eqz v0, :cond_2

    .line 144
    .line 145
    goto :goto_1

    .line 146
    :cond_2
    const/4 v3, 0x5

    .line 147
    :goto_1
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    iput-object v0, p1, Lcom/transsnet/palmpay/core/ui/activity/d0;->d:Ljava/lang/Integer;

    .line 152
    .line 153
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/ui/activity/d0;->a()V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v2}, Landroid/app/Activity;->finish()V

    .line 157
    .line 158
    .line 159
    goto :goto_2

    .line 160
    :cond_3
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 161
    .line 162
    .line 163
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    const-string v4, "/cashin_out/withdraw_result"

    .line 168
    .line 169
    invoke-virtual {v0, v4}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    const-string v4, "extra_data"

    .line 174
    .line 175
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    invoke-virtual {v0, v4, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withParcelable(Ljava/lang/String;Landroid/os/Parcelable;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    new-instance p1, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;

    .line 187
    .line 188
    const-string v0, ""

    .line 189
    .line 190
    invoke-direct {p1, v3, v0}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;-><init>(ILjava/lang/String;)V

    .line 191
    .line 192
    .line 193
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-virtual {v0, p1}, Lorg/greenrobot/eventbus/c;->f(Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    goto :goto_2

    .line 201
    :cond_4
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    invoke-static {v2, p1}, LB9/c;->l(Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;Ljava/lang/String;)V

    .line 206
    .line 207
    .line 208
    :goto_2
    invoke-virtual {v2, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 209
    .line 210
    .line 211
    return-void
.end method
