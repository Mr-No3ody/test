.class public final LB9/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog$CallBack;


# instance fields
.field public final synthetic a:LB9/c;


# direct methods
.method public constructor <init>(LB9/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LB9/a;->a:LB9/c;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onAddBankcardClick()V
    .locals 3

    .line 1
    iget-object v0, p0, LB9/a;->a:LB9/c;

    .line 2
    .line 3
    iget-object v1, v0, LB9/c;->a:Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;

    .line 4
    .line 5
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, "/coreImpl/bind_new_bank_account"

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const-string v1, "extra_type"

    .line 22
    .line 23
    const/4 v2, 0x2

    .line 24
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public final onChooseBankClick(Lcom/transsnet/palmpay/core/bean/BankCardInfo;)V
    .locals 1

    .line 1
    iget-object v0, p0, LB9/a;->a:LB9/c;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iput-object p1, v0, LB9/c;->b:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 7
    .line 8
    iget-object p1, v0, LB9/c;->a:Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0}, LB9/c;->n()V

    .line 14
    .line 15
    .line 16
    return-void
.end method
