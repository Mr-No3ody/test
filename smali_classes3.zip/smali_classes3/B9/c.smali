.class public abstract LB9/c;
.super Lcom/transsnet/palmpay/core/base/BaseActivity;
.source "SourceFile"


# instance fields
.field public a:Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;

.field public b:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

.field public c:Lcom/transsnet/palmpay/core/db/entity/User;

.field public d:J

.field public e:Ljava/lang/String;

.field public final f:LB9/a;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Lcom/transsnet/palmpay/core/base/BaseActivity;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, LB9/a;

    .line 5
    .line 6
    invoke-direct {v0, p0}, LB9/a;-><init>(LB9/c;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LB9/c;->f:LB9/a;

    .line 10
    .line 11
    return-void
.end method

.method public static l(Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v0, LO6/c;

    .line 5
    .line 6
    invoke-direct {v0, p0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 7
    .line 8
    .line 9
    sget v1, Lba/k;->core_title_error_info:I

    .line 10
    .line 11
    invoke-virtual {v0, v1}, LO6/c;->e(I)V

    .line 12
    .line 13
    .line 14
    iput-object p1, v0, LO6/c;->d:Ljava/lang/CharSequence;

    .line 15
    .line 16
    sget p1, Lba/k;->core_confirm:I

    .line 17
    .line 18
    new-instance v1, LA8/b;

    .line 19
    .line 20
    const/16 v2, 0x10

    .line 21
    .line 22
    invoke-direct {v1, p0, v2}, LA8/b;-><init>(Ljava/lang/Object;I)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, p1, v1}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, LO6/c;->g()LO6/d;

    .line 29
    .line 30
    .line 31
    return-void
.end method


# virtual methods
.method public initData()V
    .locals 2

    .line 1
    new-instance v0, Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;-><init>(Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    iput-object v0, p0, LB9/c;->a:Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;

    .line 7
    .line 8
    sget v1, Lba/k;->core_add_bank_card:I

    .line 9
    .line 10
    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;->setAddBankCardTitle(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, LB9/c;->a:Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;

    .line 18
    .line 19
    sget v1, Lba/k;->core_select_bank_account:I

    .line 20
    .line 21
    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;->setDialogTitle(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    iget-object v0, p0, LB9/c;->a:Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;

    .line 29
    .line 30
    iget-object v1, p0, LB9/c;->f:LB9/a;

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog;->setCallBack(Lcom/transsnet/palmpay/cash_in/ui/dialog/SelectPaymentBankCardDialog$CallBack;)V

    .line 33
    .line 34
    .line 35
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v0, p0}, Lorg/greenrobot/eventbus/c;->j(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    new-instance v0, Ljava/util/ArrayList;

    .line 43
    .line 44
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 45
    .line 46
    .line 47
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUserDataSource()Lka/a;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-virtual {v0}, Lka/a;->b()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    iput-object v0, p0, LB9/c;->c:Lcom/transsnet/palmpay/core/db/entity/User;

    .line 60
    .line 61
    return-void
.end method

.method public final m()V
    .locals 4

    .line 1
    iget-object v0, p0, LB9/c;->b:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const-string v0, "please select a bank account"

    .line 6
    .line 7
    invoke-static {v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_0
    new-instance v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;

    .line 12
    .line 13
    invoke-direct {v0}, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;-><init>()V

    .line 14
    .line 15
    .line 16
    iget-wide v1, p0, LB9/c;->d:J

    .line 17
    .line 18
    iput-wide v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->amount:J

    .line 19
    .line 20
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrency()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iput-object v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->currency:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v1, p0, LB9/c;->e:Ljava/lang/String;

    .line 27
    .line 28
    iput-object v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->orderNo:Ljava/lang/String;

    .line 29
    .line 30
    const-string v1, "3"

    .line 31
    .line 32
    iput-object v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->orderType:Ljava/lang/String;

    .line 33
    .line 34
    const/4 v1, 0x1

    .line 35
    iput v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->payType:I

    .line 36
    .line 37
    iget-object v2, p0, LB9/c;->c:Lcom/transsnet/palmpay/core/db/entity/User;

    .line 38
    .line 39
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/db/entity/User;->getBalanceAccountId()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    iput-object v2, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->payerAccountId:Ljava/lang/String;

    .line 44
    .line 45
    iget-object v2, p0, LB9/c;->b:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 46
    .line 47
    iget-object v3, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->cvv:Ljava/lang/String;

    .line 48
    .line 49
    iput-object v3, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->payerCardCvv:Ljava/lang/String;

    .line 50
    .line 51
    iget-object v3, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->expiryMonth:Ljava/lang/String;

    .line 52
    .line 53
    iput-object v3, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->payerCardExpiryMon:Ljava/lang/String;

    .line 54
    .line 55
    iget-object v3, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->expiryYear:Ljava/lang/String;

    .line 56
    .line 57
    iput-object v3, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->payerCardExpiryYear:Ljava/lang/String;

    .line 58
    .line 59
    iget-object v3, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->bankAccountNo:Ljava/lang/String;

    .line 60
    .line 61
    iput-object v3, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->payerBankAccountNo:Ljava/lang/String;

    .line 62
    .line 63
    iget-object v3, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->bankCode:Ljava/lang/String;

    .line 64
    .line 65
    iput-object v3, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->payerBankCode:Ljava/lang/String;

    .line 66
    .line 67
    const-string v3, "MobileWallet"

    .line 68
    .line 69
    iget-object v2, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->accountType:Ljava/lang/String;

    .line 70
    .line 71
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    if-eqz v2, :cond_1

    .line 76
    .line 77
    iget-object v2, p0, LB9/c;->b:Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 78
    .line 79
    iget-object v3, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->bankCode:Ljava/lang/String;

    .line 80
    .line 81
    iput-object v3, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->walletChannel:Ljava/lang/String;

    .line 82
    .line 83
    iget-object v2, v2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->phone:Ljava/lang/String;

    .line 84
    .line 85
    iput-object v2, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->walletPhone:Ljava/lang/String;

    .line 86
    .line 87
    :cond_1
    iput v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->reUseable:I

    .line 88
    .line 89
    iget-wide v1, p0, LB9/c;->d:J

    .line 90
    .line 91
    iput-wide v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->amount:J

    .line 92
    .line 93
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrency()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    iput-object v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->currency:Ljava/lang/String;

    .line 98
    .line 99
    iget-object v1, p0, LB9/c;->e:Ljava/lang/String;

    .line 100
    .line 101
    iput-object v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->orderNo:Ljava/lang/String;

    .line 102
    .line 103
    const/4 v1, 0x7

    .line 104
    iput v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->payType:I

    .line 105
    .line 106
    const-string v1, "02"

    .line 107
    .line 108
    iput-object v1, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->transType:Ljava/lang/String;

    .line 109
    .line 110
    move-object v1, p0

    .line 111
    check-cast v1, Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;

    .line 112
    .line 113
    iget-object v2, v1, Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;->M:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 114
    .line 115
    if-eqz v2, :cond_2

    .line 116
    .line 117
    iget-object v2, v2, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->cacheKey:Ljava/lang/String;

    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_2
    const/4 v2, 0x0

    .line 121
    :goto_0
    iput-object v2, v0, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->cacheKey:Ljava/lang/String;

    .line 122
    .line 123
    sget-object v2, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 124
    .line 125
    iget-object v2, v2, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast v2, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 128
    .line 129
    invoke-interface {v2, v0}, Lcom/transsnet/palmpay/core/network/PayApiService;->payByNewOrderNoV2(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)Ldf/d;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 134
    .line 135
    invoke-virtual {v0, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    invoke-virtual {v0, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    new-instance v2, LB9/b;

    .line 148
    .line 149
    invoke-direct {v2, v1}, LB9/b;-><init>(Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v0, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 153
    .line 154
    .line 155
    return-void
.end method

.method public abstract n()V
.end method

.method public final onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->onDestroy()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0, p0}, Lorg/greenrobot/eventbus/c;->l(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onMessageEvent(Lcom/transsnet/palmpay/core/bean/MessageBean;)V
    .locals 2
    .annotation runtime Lorg/greenrobot/eventbus/Subscribe;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    goto :goto_0

    .line 4
    :cond_0
    iget v0, p1, Lcom/transsnet/palmpay/core/bean/MessageBean;->key:I

    .line 5
    .line 6
    const/16 v1, 0x13

    .line 7
    .line 8
    if-eq v0, v1, :cond_1

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_1
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/MessageBean;->msg:Ljava/lang/Object;

    .line 12
    .line 13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 14
    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    check-cast p1, Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    .line 18
    .line 19
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/BankCardInfo;->bankAccountNo:Ljava/lang/String;

    .line 20
    .line 21
    :cond_2
    :goto_0
    return-void
.end method

.method public setupView()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-virtual {p0, v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->initStatusBar(Z)V

    .line 3
    .line 4
    .line 5
    sget v0, Lcom/transsnet/palmpay/custom_view/p;->cv_preview_window_bg:I

    .line 6
    .line 7
    invoke-virtual {p0, v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->setWindowBackground(I)V

    .line 8
    .line 9
    .line 10
    sget v0, Lcom/transsnet/palmpay/custom_view/s;->ivBack:I

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    new-instance v1, LA8/b;

    .line 19
    .line 20
    const/16 v2, 0xf

    .line 21
    .line 22
    invoke-direct {v1, p0, v2}, LA8/b;-><init>(Ljava/lang/Object;I)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 26
    .line 27
    .line 28
    :cond_0
    return-void
.end method
