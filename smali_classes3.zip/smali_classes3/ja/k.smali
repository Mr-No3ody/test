.class public final Lja/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final b:Lcom/palmpay/lib/ui/button/PpButton;

.field public final c:Lcom/palmpay/lib/ui/button/PpButton;

.field public final d:Landroid/widget/ImageView;

.field public final e:Landroidx/recyclerview/widget/RecyclerView;

.field public final f:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

.field public final g:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;Lcom/palmpay/lib/ui/button/PpButton;Lcom/palmpay/lib/ui/button/PpButton;Landroid/widget/ImageView;Landroidx/recyclerview/widget/RecyclerView;Lcom/palmpay/lib/ui/titlebar/PpTitleBar;Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lja/k;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lja/k;->b:Lcom/palmpay/lib/ui/button/PpButton;

    .line 7
    .line 8
    iput-object p3, p0, Lja/k;->c:Lcom/palmpay/lib/ui/button/PpButton;

    .line 9
    .line 10
    iput-object p4, p0, Lja/k;->d:Landroid/widget/ImageView;

    .line 11
    .line 12
    iput-object p5, p0, Lja/k;->e:Landroidx/recyclerview/widget/RecyclerView;

    .line 13
    .line 14
    iput-object p6, p0, Lja/k;->f:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 15
    .line 16
    iput-object p7, p0, Lja/k;->g:Landroid/widget/TextView;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lja/k;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2
    .line 3
    return-object v0
.end method
