.class public final Lja/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final a:Landroid/widget/RelativeLayout;

.field public final b:Lcom/mikepenz/iconics/view/IconicsImageView;

.field public final c:Landroid/widget/TextView;

.field public final d:Lcom/transsnet/palmpay/custom_view/SwipeRecyclerView;

.field public final e:Landroid/widget/TextView;

.field public final f:Lcom/wang/avi/AVLoadingIndicatorView;

.field public final g:Landroid/widget/RelativeLayout;


# direct methods
.method public constructor <init>(Landroid/widget/RelativeLayout;Lcom/mikepenz/iconics/view/IconicsImageView;Landroid/widget/TextView;Lcom/transsnet/palmpay/custom_view/SwipeRecyclerView;Landroid/widget/TextView;Lcom/wang/avi/AVLoadingIndicatorView;Landroid/widget/RelativeLayout;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lja/b;->a:Landroid/widget/RelativeLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lja/b;->b:Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 7
    .line 8
    iput-object p3, p0, Lja/b;->c:Landroid/widget/TextView;

    .line 9
    .line 10
    iput-object p4, p0, Lja/b;->d:Lcom/transsnet/palmpay/custom_view/SwipeRecyclerView;

    .line 11
    .line 12
    iput-object p5, p0, Lja/b;->e:Landroid/widget/TextView;

    .line 13
    .line 14
    iput-object p6, p0, Lja/b;->f:Lcom/wang/avi/AVLoadingIndicatorView;

    .line 15
    .line 16
    iput-object p7, p0, Lja/b;->g:Landroid/widget/RelativeLayout;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lja/b;->a:Landroid/widget/RelativeLayout;

    .line 2
    .line 3
    return-object v0
.end method
