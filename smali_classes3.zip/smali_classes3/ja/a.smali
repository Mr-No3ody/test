.class public final Lja/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final a:Landroid/widget/LinearLayout;

.field public final b:Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;

.field public final c:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

.field public final d:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/widget/LinearLayout;Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;Lcom/palmpay/lib/ui/titlebar/PpTitleBar;Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lja/a;->a:Landroid/widget/LinearLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lja/a;->b:Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;

    .line 7
    .line 8
    iput-object p3, p0, Lja/a;->c:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 9
    .line 10
    iput-object p4, p0, Lja/a;->d:Landroid/widget/TextView;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lja/a;->a:Landroid/widget/LinearLayout;

    .line 2
    .line 3
    return-object v0
.end method
