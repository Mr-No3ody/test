.class public final Lja/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final b:Landroid/widget/LinearLayout;

.field public final c:Lcom/palmpay/lib/ui/button/PpButton;

.field public final d:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

.field public final e:Landroid/widget/TextView;

.field public final f:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/widget/LinearLayout;Lcom/palmpay/lib/ui/button/PpButton;Lcom/palmpay/lib/ui/titlebar/PpTitleBar;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lja/j;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lja/j;->b:Landroid/widget/LinearLayout;

    .line 7
    .line 8
    iput-object p3, p0, Lja/j;->c:Lcom/palmpay/lib/ui/button/PpButton;

    .line 9
    .line 10
    iput-object p4, p0, Lja/j;->d:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 11
    .line 12
    iput-object p5, p0, Lja/j;->e:Landroid/widget/TextView;

    .line 13
    .line 14
    iput-object p6, p0, Lja/j;->f:Landroid/widget/TextView;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lja/j;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2
    .line 3
    return-object v0
.end method
