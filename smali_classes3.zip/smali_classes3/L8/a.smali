.class public final LL8/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method public static a(Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;LC0/w;LC0/U;Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 6

    .line 1
    if-eqz p1, :cond_b

    .line 2
    .line 3
    if-nez p0, :cond_0

    .line 4
    .line 5
    goto/16 :goto_3

    .line 6
    .line 7
    :cond_0
    const-string v0, "context"

    .line 8
    .line 9
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    new-instance v0, Lid/a;

    .line 13
    .line 14
    invoke-direct {v0, p0}, Lid/a;-><init>(Landroid/content/Context;)V

    .line 15
    .line 16
    .line 17
    const-string v1, "android.permission.USE_FINGERPRINT"

    .line 18
    .line 19
    invoke-static {p0, v1}, Landroidx/core/content/d;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    const/4 v2, 0x0

    .line 24
    if-eqz v1, :cond_1

    .line 25
    .line 26
    move v1, v2

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    iget-object v1, v0, Lid/a;->e:La0/b;

    .line 29
    .line 30
    invoke-virtual {v1}, La0/b;->c()Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    :goto_0
    invoke-virtual {v0}, Lid/a;->W()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    if-nez v3, :cond_2

    .line 43
    .line 44
    invoke-static {p3}, Lio/fastkv/n;->w(Ljava/lang/String;)Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    if-eqz v3, :cond_2

    .line 49
    .line 50
    const/4 v2, 0x1

    .line 51
    :cond_2
    if-eqz v1, :cond_3

    .line 52
    .line 53
    if-eqz v0, :cond_3

    .line 54
    .line 55
    if-eqz v2, :cond_3

    .line 56
    .line 57
    const-string v3, "supported"

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_3
    const-string v3, "unsupported"

    .line 61
    .line 62
    :goto_1
    const/4 v4, 0x0

    .line 63
    if-nez v1, :cond_4

    .line 64
    .line 65
    const-string v0, "no_hardware"

    .line 66
    .line 67
    goto :goto_2

    .line 68
    :cond_4
    if-eqz v1, :cond_5

    .line 69
    .line 70
    if-nez v0, :cond_5

    .line 71
    .line 72
    const-string v0, "not_enrolled"

    .line 73
    .line 74
    goto :goto_2

    .line 75
    :cond_5
    if-eqz v0, :cond_6

    .line 76
    .line 77
    if-nez v2, :cond_6

    .line 78
    .line 79
    const-string v0, "app_not_enabled"

    .line 80
    .line 81
    goto :goto_2

    .line 82
    :cond_6
    move-object v0, v4

    .line 83
    :goto_2
    const-string v1, "login"

    .line 84
    .line 85
    const-string v2, "fingerprint"

    .line 86
    .line 87
    const-string v5, "login_page"

    .line 88
    .line 89
    invoke-static {v1, v2, v3, v0, v5}, LD3/a;->J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-nez v0, :cond_8

    .line 97
    .line 98
    invoke-static {p3}, Lio/fastkv/n;->w(Ljava/lang/String;)Z

    .line 99
    .line 100
    .line 101
    move-result p3

    .line 102
    if-eqz p3, :cond_8

    .line 103
    .line 104
    new-instance p3, Lid/a;

    .line 105
    .line 106
    invoke-direct {p3, p0}, Lid/a;-><init>(Landroid/content/Context;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {p3}, Lid/a;->W()Z

    .line 110
    .line 111
    .line 112
    move-result p3

    .line 113
    if-eqz p3, :cond_8

    .line 114
    .line 115
    if-nez p2, :cond_7

    .line 116
    .line 117
    sget p0, LF8/d;->fragment_login_verify_touch_id:I

    .line 118
    .line 119
    invoke-virtual {p1, p0, p4, v4}, LC0/w;->h(ILandroid/os/Bundle;LC0/U;)V

    .line 120
    .line 121
    .line 122
    return-void

    .line 123
    :cond_7
    sget p0, LF8/d;->fragment_login_verify_touch_id:I

    .line 124
    .line 125
    invoke-virtual {p1, p0, p4, p2}, LC0/w;->h(ILandroid/os/Bundle;LC0/U;)V

    .line 126
    .line 127
    .line 128
    return-void

    .line 129
    :cond_8
    sget p3, LF8/d;->fragment_login_verify_pin:I

    .line 130
    .line 131
    iget-object p0, p0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->t:Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;

    .line 132
    .line 133
    if-eqz p0, :cond_9

    .line 134
    .line 135
    invoke-virtual {p0}, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->checkVerifyWithPsw()Z

    .line 136
    .line 137
    .line 138
    move-result p0

    .line 139
    if-eqz p0, :cond_9

    .line 140
    .line 141
    sget p3, LF8/d;->fragment_login_verify_psw:I

    .line 142
    .line 143
    :cond_9
    if-nez p2, :cond_a

    .line 144
    .line 145
    invoke-virtual {p1, p3, p4, v4}, LC0/w;->h(ILandroid/os/Bundle;LC0/U;)V

    .line 146
    .line 147
    .line 148
    return-void

    .line 149
    :cond_a
    invoke-virtual {p1, p3, p4, p2}, LC0/w;->h(ILandroid/os/Bundle;LC0/U;)V

    .line 150
    .line 151
    .line 152
    :cond_b
    :goto_3
    return-void
.end method

.method public static b(Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;LC0/w;Landroid/os/Bundle;)Ljava/lang/Integer;
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_f

    .line 3
    .line 4
    if-eqz p0, :cond_f

    .line 5
    .line 6
    iget-object p1, p0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->t:Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;

    .line 7
    .line 8
    if-nez p1, :cond_0

    .line 9
    .line 10
    goto/16 :goto_4

    .line 11
    .line 12
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->isNeedNameVerify()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/4 v2, 0x0

    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    move v1, v2

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    iget-boolean v1, p1, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->supplement:Z

    .line 22
    .line 23
    :goto_0
    iget-boolean v3, p1, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->needOtp:Z

    .line 24
    .line 25
    const/4 v4, 0x1

    .line 26
    if-eqz v3, :cond_2

    .line 27
    .line 28
    invoke-virtual {p0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->u()Z

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    if-nez v3, :cond_2

    .line 33
    .line 34
    move v3, v4

    .line 35
    goto :goto_1

    .line 36
    :cond_2
    move v3, v2

    .line 37
    :goto_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->isNeedNameVerify()Z

    .line 38
    .line 39
    .line 40
    move-result v5

    .line 41
    if-eqz v5, :cond_3

    .line 42
    .line 43
    iget-object v5, p0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->b:Lcom/transsnet/palmpay/account/bean/LogInReq;

    .line 44
    .line 45
    if-eqz v5, :cond_3

    .line 46
    .line 47
    invoke-virtual {v5, v2}, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->isVerifyTokenValid(Z)Z

    .line 48
    .line 49
    .line 50
    move-result v5

    .line 51
    if-nez v5, :cond_3

    .line 52
    .line 53
    move v5, v4

    .line 54
    goto :goto_2

    .line 55
    :cond_3
    move v5, v2

    .line 56
    :goto_2
    const v6, 0x7fffffff

    .line 57
    .line 58
    .line 59
    if-eqz v1, :cond_7

    .line 60
    .line 61
    if-eqz v3, :cond_4

    .line 62
    .line 63
    sget p0, LF8/d;->fragment_login_input_sms:I

    .line 64
    .line 65
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object p0

    .line 69
    return-object p0

    .line 70
    :cond_4
    if-nez v5, :cond_5

    .line 71
    .line 72
    invoke-virtual {p1}, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->isNeedExtraInfo()Z

    .line 73
    .line 74
    .line 75
    move-result p1

    .line 76
    if-eqz p1, :cond_f

    .line 77
    .line 78
    :cond_5
    iget-object p0, p0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->b:Lcom/transsnet/palmpay/account/bean/LogInReq;

    .line 79
    .line 80
    if-eqz p0, :cond_6

    .line 81
    .line 82
    invoke-virtual {p0, v2}, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->isVerifyTokenValid(Z)Z

    .line 83
    .line 84
    .line 85
    move-result p0

    .line 86
    if-ne p0, v4, :cond_6

    .line 87
    .line 88
    return-object v0

    .line 89
    :cond_6
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    return-object p0

    .line 94
    :cond_7
    iget-object v1, p0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->b:Lcom/transsnet/palmpay/account/bean/LogInReq;

    .line 95
    .line 96
    if-eqz v1, :cond_8

    .line 97
    .line 98
    iget-object v1, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->faceToken:Ljava/lang/String;

    .line 99
    .line 100
    goto :goto_3

    .line 101
    :cond_8
    move-object v1, v0

    .line 102
    :goto_3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->isSupportMultiVerifyMethods()Z

    .line 103
    .line 104
    .line 105
    move-result v7

    .line 106
    if-eqz v7, :cond_9

    .line 107
    .line 108
    if-eqz v3, :cond_9

    .line 109
    .line 110
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 111
    .line 112
    .line 113
    move-result v7

    .line 114
    if-eqz v7, :cond_9

    .line 115
    .line 116
    sget p0, LF8/d;->fragment_login_select_verify_method:I

    .line 117
    .line 118
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 119
    .line 120
    .line 121
    move-result-object p0

    .line 122
    return-object p0

    .line 123
    :cond_9
    iget-boolean v7, p1, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->needFaceAuthen:Z

    .line 124
    .line 125
    if-eqz v7, :cond_b

    .line 126
    .line 127
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    if-eqz v1, :cond_b

    .line 132
    .line 133
    iget-object p0, p1, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->faceScene:Ljava/lang/Integer;

    .line 134
    .line 135
    if-eqz p0, :cond_a

    .line 136
    .line 137
    if-eqz p2, :cond_a

    .line 138
    .line 139
    const-string p1, "faceScene"

    .line 140
    .line 141
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    .line 145
    .line 146
    .line 147
    move-result p0

    .line 148
    const-string p1, "extra_type"

    .line 149
    .line 150
    invoke-virtual {p2, p1, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 151
    .line 152
    .line 153
    :cond_a
    sget p0, LF8/d;->fragment_login_with_face:I

    .line 154
    .line 155
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 156
    .line 157
    .line 158
    move-result-object p0

    .line 159
    return-object p0

    .line 160
    :cond_b
    if-eqz v3, :cond_c

    .line 161
    .line 162
    sget p0, LF8/d;->fragment_login_input_sms:I

    .line 163
    .line 164
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 165
    .line 166
    .line 167
    move-result-object p0

    .line 168
    return-object p0

    .line 169
    :cond_c
    if-nez v5, :cond_d

    .line 170
    .line 171
    invoke-virtual {p1}, Lcom/transsnet/palmpay/account/bean/rsp/PreCheckPhoneRsp;->isNeedExtraInfo()Z

    .line 172
    .line 173
    .line 174
    move-result p1

    .line 175
    if-eqz p1, :cond_f

    .line 176
    .line 177
    :cond_d
    iget-object p0, p0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->b:Lcom/transsnet/palmpay/account/bean/LogInReq;

    .line 178
    .line 179
    if-eqz p0, :cond_e

    .line 180
    .line 181
    invoke-virtual {p0, v2}, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->isVerifyTokenValid(Z)Z

    .line 182
    .line 183
    .line 184
    move-result p0

    .line 185
    if-ne p0, v4, :cond_e

    .line 186
    .line 187
    return-object v0

    .line 188
    :cond_e
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 189
    .line 190
    .line 191
    move-result-object p0

    .line 192
    return-object p0

    .line 193
    :cond_f
    :goto_4
    return-object v0
.end method

.method public static final c(Landroid/view/View;)V
    .locals 4

    .line 1
    if-nez p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance v0, Landroid/view/animation/TranslateAnimation;

    .line 5
    .line 6
    const/high16 v1, -0x3e600000    # -20.0f

    .line 7
    .line 8
    const/high16 v2, 0x41a00000    # 20.0f

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    invoke-direct {v0, v1, v2, v3, v3}, Landroid/view/animation/TranslateAnimation;-><init>(FFFF)V

    .line 12
    .line 13
    .line 14
    const-wide/16 v1, 0x64

    .line 15
    .line 16
    invoke-virtual {v0, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 17
    .line 18
    .line 19
    const/4 v1, 0x4

    .line 20
    invoke-virtual {v0, v1}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    .line 21
    .line 22
    .line 23
    const/4 v1, 0x2

    .line 24
    invoke-virtual {v0, v1}, Landroid/view/animation/Animation;->setRepeatMode(I)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0, v0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Integer;Landroid/graphics/drawable/Drawable;Ljava/lang/CharSequence;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Ljava/lang/Integer;Landroid/view/View$OnClickListener;LV8/l;I)LO6/d;
    .locals 22

    .line 1
    move/from16 v0, p11

    .line 2
    .line 3
    and-int/lit8 v1, v0, 0x4

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    move-object v1, v2

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object/from16 v1, p2

    .line 11
    .line 12
    :goto_0
    and-int/lit8 v3, v0, 0x8

    .line 13
    .line 14
    if-eqz v3, :cond_1

    .line 15
    .line 16
    move-object v10, v2

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    move-object/from16 v10, p3

    .line 19
    .line 20
    :goto_1
    and-int/lit8 v3, v0, 0x20

    .line 21
    .line 22
    if-eqz v3, :cond_2

    .line 23
    .line 24
    move-object v12, v2

    .line 25
    goto :goto_2

    .line 26
    :cond_2
    move-object/from16 v12, p5

    .line 27
    .line 28
    :goto_2
    and-int/lit8 v3, v0, 0x40

    .line 29
    .line 30
    if-eqz v3, :cond_3

    .line 31
    .line 32
    move-object v13, v2

    .line 33
    goto :goto_3

    .line 34
    :cond_3
    move-object/from16 v13, p6

    .line 35
    .line 36
    :goto_3
    and-int/lit16 v3, v0, 0x80

    .line 37
    .line 38
    if-eqz v3, :cond_4

    .line 39
    .line 40
    move-object v14, v2

    .line 41
    goto :goto_4

    .line 42
    :cond_4
    move-object/from16 v14, p7

    .line 43
    .line 44
    :goto_4
    and-int/lit16 v3, v0, 0x100

    .line 45
    .line 46
    if-eqz v3, :cond_5

    .line 47
    .line 48
    move-object v15, v2

    .line 49
    goto :goto_5

    .line 50
    :cond_5
    move-object/from16 v15, p8

    .line 51
    .line 52
    :goto_5
    and-int/lit16 v3, v0, 0x400

    .line 53
    .line 54
    if-eqz v3, :cond_6

    .line 55
    .line 56
    move-object/from16 v17, v2

    .line 57
    .line 58
    goto :goto_6

    .line 59
    :cond_6
    move-object/from16 v17, p9

    .line 60
    .line 61
    :goto_6
    and-int/lit16 v3, v0, 0x800

    .line 62
    .line 63
    if-eqz v3, :cond_7

    .line 64
    .line 65
    move-object/from16 v18, v2

    .line 66
    .line 67
    goto :goto_7

    .line 68
    :cond_7
    move-object/from16 v18, p10

    .line 69
    .line 70
    :goto_7
    and-int/lit16 v0, v0, 0x1000

    .line 71
    .line 72
    if-eqz v0, :cond_8

    .line 73
    .line 74
    const/4 v0, 0x1

    .line 75
    :goto_8
    move v5, v0

    .line 76
    goto :goto_9

    .line 77
    :cond_8
    const/4 v0, 0x2

    .line 78
    goto :goto_8

    .line 79
    :goto_9
    if-eqz p0, :cond_c

    .line 80
    .line 81
    if-nez v10, :cond_9

    .line 82
    .line 83
    move-object/from16 v7, p1

    .line 84
    .line 85
    goto :goto_a

    .line 86
    :cond_9
    move-object v7, v2

    .line 87
    :goto_a
    if-nez v10, :cond_a

    .line 88
    .line 89
    move-object v8, v1

    .line 90
    goto :goto_b

    .line 91
    :cond_a
    move-object v8, v2

    .line 92
    :goto_b
    if-nez v10, :cond_b

    .line 93
    .line 94
    move-object/from16 v11, p4

    .line 95
    .line 96
    goto :goto_c

    .line 97
    :cond_b
    move-object v11, v2

    .line 98
    :goto_c
    const/16 v20, 0x0

    .line 99
    .line 100
    const v21, 0x7e4032

    .line 101
    .line 102
    .line 103
    const/4 v6, 0x0

    .line 104
    const/4 v9, 0x0

    .line 105
    const/16 v16, 0x0

    .line 106
    .line 107
    const/16 v19, 0x0

    .line 108
    .line 109
    move-object/from16 v4, p0

    .line 110
    .line 111
    invoke-static/range {v4 .. v21}, Lio/fastkv/n;->O(Landroid/content/Context;ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;Lcom/mikepenz/iconics/IconicsDrawable;Landroid/graphics/drawable/Drawable;Ljava/lang/CharSequence;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;ZII)LO6/d;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    return-object v0

    .line 116
    :cond_c
    return-object v2
.end method

.method public static e(Landroid/widget/TextView;Ljava/lang/String;)V
    .locals 4

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz p0, :cond_0

    .line 6
    .line 7
    new-instance v1, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 8
    .line 9
    invoke-direct {v1}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 10
    .line 11
    .line 12
    sget v2, LF8/h;->ac_msg_sms_sent_to:I

    .line 13
    .line 14
    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    sget v2, LL6/b;->ppColorTextNormal:I

    .line 23
    .line 24
    invoke-virtual {v0, v2}, Landroid/content/Context;->getColor(I)I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    const/4 v2, 0x0

    .line 33
    invoke-static {p1, v2}, LPa/i0;->n(Ljava/lang/String;Z)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    new-instance v2, Ljava/lang/StringBuilder;

    .line 38
    .line 39
    const-string v3, " "

    .line 40
    .line 41
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string p1, "."

    .line 48
    .line 49
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    invoke-virtual {v1, p1}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-virtual {p1}, Lcom/transsnet/palmpay/util/SpanUtils;->setBold()Lcom/transsnet/palmpay/util/SpanUtils;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    sget v1, LL6/b;->ppColorTextNormal:I

    .line 65
    .line 66
    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    sget v1, LF8/h;->ac_wrong_number:I

    .line 75
    .line 76
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    sget v1, LL6/b;->ppColorPrimary:I

    .line 85
    .line 86
    invoke-static {v0, v1, p1, p0}, LC0/G;->w(Landroid/content/Context;ILcom/transsnet/palmpay/util/SpanUtils;Landroid/widget/TextView;)V

    .line 87
    .line 88
    .line 89
    :cond_0
    return-void
.end method

.method public static f(Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;)V
    .locals 4

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    :try_start_0
    invoke-virtual {p0}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->getEventName()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    :goto_0
    if-eqz v0, :cond_5

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-nez v1, :cond_1

    .line 16
    .line 17
    goto :goto_2

    .line 18
    :cond_1
    new-instance v1, Lcom/adjust/sdk/AdjustEvent;

    .line 19
    .line 20
    invoke-direct {v1, v0}, Lcom/adjust/sdk/AdjustEvent;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    if-eqz p0, :cond_4

    .line 24
    .line 25
    invoke-virtual {p0}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->getEventMap()Ljava/util/Map;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    if-eqz p0, :cond_4

    .line 30
    .line 31
    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    :cond_2
    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_4

    .line 44
    .line 45
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Ljava/util/Map$Entry;

    .line 50
    .line 51
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    check-cast v2, Ljava/lang/String;

    .line 56
    .line 57
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-eqz v2, :cond_2

    .line 62
    .line 63
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    if-nez v3, :cond_3

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_3
    if-eqz v0, :cond_2

    .line 71
    .line 72
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-virtual {v1, v2, v0}, Lcom/adjust/sdk/AdjustEvent;->addCallbackParameter(Ljava/lang/String;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    goto :goto_1

    .line 80
    :cond_4
    invoke-static {v1}, Lcom/adjust/sdk/Adjust;->trackEvent(Lcom/adjust/sdk/AdjustEvent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :catch_0
    move-exception p0

    .line 85
    const-string v0, "Adjust"

    .line 86
    .line 87
    const-string v1, "trackAdjustEvent: "

    .line 88
    .line 89
    invoke-static {v0, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 90
    .line 91
    .line 92
    :cond_5
    :goto_2
    return-void
.end method
