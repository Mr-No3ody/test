.class public final enum LL8/c;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final a:I

.field public static final b:I

.field public static final synthetic c:[LL8/c;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, LL8/c;

    .line 2
    .line 3
    const-string v1, "#FFF44E4E"

    .line 4
    .line 5
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 6
    .line 7
    .line 8
    const-string v1, "WEAK"

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 12
    .line 13
    .line 14
    new-instance v1, LL8/c;

    .line 15
    .line 16
    const-string v2, "#FFF5A623"

    .line 17
    .line 18
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 19
    .line 20
    .line 21
    const-string v2, "MEDIUM"

    .line 22
    .line 23
    const/4 v3, 0x1

    .line 24
    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 25
    .line 26
    .line 27
    new-instance v2, LL8/c;

    .line 28
    .line 29
    const-string v3, "#FF23D184"

    .line 30
    .line 31
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 32
    .line 33
    .line 34
    const-string v4, "STRONG"

    .line 35
    .line 36
    const/4 v5, 0x2

    .line 37
    invoke-direct {v2, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 38
    .line 39
    .line 40
    new-instance v4, LL8/c;

    .line 41
    .line 42
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    const-string v3, "VERY_STRONG"

    .line 46
    .line 47
    const/4 v5, 0x3

    .line 48
    invoke-direct {v4, v3, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 49
    .line 50
    .line 51
    filled-new-array {v0, v1, v2, v4}, [LL8/c;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    sput-object v0, LL8/c;->c:[LL8/c;

    .line 56
    .line 57
    const/4 v0, 0x4

    .line 58
    sput v0, LL8/c;->a:I

    .line 59
    .line 60
    const/4 v0, 0x6

    .line 61
    sput v0, LL8/c;->b:I

    .line 62
    .line 63
    return-void
.end method

.method public static a(ILjava/lang/String;Z)I
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    move v2, v0

    .line 4
    move v5, v2

    .line 5
    move v3, v1

    .line 6
    move v4, v3

    .line 7
    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 8
    .line 9
    .line 10
    move-result v6

    .line 11
    if-ge v2, v6, :cond_4

    .line 12
    .line 13
    add-int/lit8 v6, v2, 0x1

    .line 14
    .line 15
    invoke-virtual {p1, v2, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v7

    .line 19
    invoke-virtual {v7, v0}, Ljava/lang/String;->charAt(I)C

    .line 20
    .line 21
    .line 22
    move-result v7

    .line 23
    if-nez v2, :cond_0

    .line 24
    .line 25
    move v5, v7

    .line 26
    :cond_0
    if-eqz p2, :cond_1

    .line 27
    .line 28
    add-int v2, v7, p0

    .line 29
    .line 30
    if-ne v2, v5, :cond_2

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_1
    sub-int v2, v7, p0

    .line 34
    .line 35
    if-ne v2, v5, :cond_2

    .line 36
    .line 37
    :goto_1
    add-int/lit8 v3, v3, 0x1

    .line 38
    .line 39
    goto :goto_3

    .line 40
    :cond_2
    if-le v3, v4, :cond_3

    .line 41
    .line 42
    goto :goto_2

    .line 43
    :cond_3
    move v3, v4

    .line 44
    :goto_2
    move v4, v3

    .line 45
    move v3, v1

    .line 46
    :goto_3
    move v2, v6

    .line 47
    move v5, v7

    .line 48
    goto :goto_0

    .line 49
    :cond_4
    if-le v3, v4, :cond_5

    .line 50
    .line 51
    return v3

    .line 52
    :cond_5
    return v4
.end method

.method public static b(Ljava/lang/String;)I
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    move v2, v1

    .line 4
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 5
    .line 6
    .line 7
    move-result v3

    .line 8
    if-ge v1, v3, :cond_3

    .line 9
    .line 10
    add-int/lit8 v3, v1, 0x1

    .line 11
    .line 12
    invoke-virtual {p0, v1, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    move v4, v0

    .line 17
    move v5, v4

    .line 18
    :goto_1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    if-ge v4, v6, :cond_1

    .line 23
    .line 24
    add-int/lit8 v6, v4, 0x1

    .line 25
    .line 26
    invoke-virtual {p0, v4, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-eqz v4, :cond_0

    .line 35
    .line 36
    add-int/lit8 v5, v5, 0x1

    .line 37
    .line 38
    :cond_0
    move v4, v6

    .line 39
    goto :goto_1

    .line 40
    :cond_1
    if-le v5, v2, :cond_2

    .line 41
    .line 42
    move v2, v5

    .line 43
    :cond_2
    move v1, v3

    .line 44
    goto :goto_0

    .line 45
    :cond_3
    return v2
.end method

.method public static c(Ljava/lang/String;)I
    .locals 10

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    sget v2, LL8/c;->a:I

    .line 14
    .line 15
    if-ge v0, v2, :cond_1

    .line 16
    .line 17
    :goto_0
    return v1

    .line 18
    :cond_1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    const/4 v3, 0x1

    .line 23
    if-eqz v2, :cond_2

    .line 24
    .line 25
    move v6, v1

    .line 26
    goto :goto_4

    .line 27
    :cond_2
    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    array-length v4, v2

    .line 32
    new-array v4, v4, [C

    .line 33
    .line 34
    aget-char v5, v2, v1

    .line 35
    .line 36
    aput-char v5, v4, v1

    .line 37
    .line 38
    move v5, v3

    .line 39
    move v6, v5

    .line 40
    :goto_1
    array-length v7, v2

    .line 41
    if-ge v5, v7, :cond_5

    .line 42
    .line 43
    aget-char v7, v2, v5

    .line 44
    .line 45
    move v8, v1

    .line 46
    :goto_2
    if-ge v8, v6, :cond_4

    .line 47
    .line 48
    aget-char v9, v4, v8

    .line 49
    .line 50
    if-ne v7, v9, :cond_3

    .line 51
    .line 52
    goto :goto_3

    .line 53
    :cond_3
    add-int/lit8 v8, v8, 0x1

    .line 54
    .line 55
    goto :goto_2

    .line 56
    :cond_4
    aput-char v7, v4, v6

    .line 57
    .line 58
    add-int/lit8 v6, v6, 0x1

    .line 59
    .line 60
    :goto_3
    add-int/lit8 v5, v5, 0x1

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_5
    :goto_4
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    const/4 v4, 0x2

    .line 68
    div-int/2addr v2, v4

    .line 69
    if-gt v6, v2, :cond_6

    .line 70
    .line 71
    return v1

    .line 72
    :cond_6
    invoke-static {p0}, LL8/c;->b(Ljava/lang/String;)I

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    invoke-static {v3, p0, v1}, LL8/c;->a(ILjava/lang/String;Z)I

    .line 77
    .line 78
    .line 79
    move-result v5

    .line 80
    invoke-static {v3, p0, v3}, LL8/c;->a(ILjava/lang/String;Z)I

    .line 81
    .line 82
    .line 83
    move-result v6

    .line 84
    invoke-static {v4, p0, v1}, LL8/c;->a(ILjava/lang/String;Z)I

    .line 85
    .line 86
    .line 87
    move-result v7

    .line 88
    invoke-static {v4, p0, v3}, LL8/c;->a(ILjava/lang/String;Z)I

    .line 89
    .line 90
    .line 91
    move-result p0

    .line 92
    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    .line 93
    .line 94
    .line 95
    move-result v5

    .line 96
    invoke-static {v7, p0}, Ljava/lang/Math;->max(II)I

    .line 97
    .line 98
    .line 99
    move-result p0

    .line 100
    invoke-static {v5, p0}, Ljava/lang/Math;->max(II)I

    .line 101
    .line 102
    .line 103
    move-result p0

    .line 104
    if-lt p0, v0, :cond_7

    .line 105
    .line 106
    return v1

    .line 107
    :cond_7
    add-int/lit8 v5, v0, -0x1

    .line 108
    .line 109
    if-lt p0, v5, :cond_8

    .line 110
    .line 111
    return v3

    .line 112
    :cond_8
    if-lt v2, v0, :cond_9

    .line 113
    .line 114
    goto :goto_5

    .line 115
    :cond_9
    if-lt v2, v5, :cond_b

    .line 116
    .line 117
    :cond_a
    move v1, v3

    .line 118
    goto :goto_5

    .line 119
    :cond_b
    if-ne v2, v3, :cond_a

    .line 120
    .line 121
    move v1, v4

    .line 122
    :goto_5
    if-ne v2, v3, :cond_c

    .line 123
    .line 124
    if-ne p0, v3, :cond_c

    .line 125
    .line 126
    const/4 p0, 0x3

    .line 127
    return p0

    .line 128
    :cond_c
    return v1
.end method

.method public static d(Ljava/lang/String;)Z
    .locals 4

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    return v1

    .line 9
    :cond_0
    const/4 v0, 0x1

    .line 10
    invoke-static {v0, p0, v1}, LL8/c;->a(ILjava/lang/String;Z)I

    .line 11
    .line 12
    .line 13
    move-result v2

    .line 14
    invoke-static {v0, p0, v0}, LL8/c;->a(ILjava/lang/String;Z)I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    if-ne v2, p0, :cond_1

    .line 27
    .line 28
    return v0

    .line 29
    :cond_1
    return v1
.end method

.method public static e(Ljava/lang/String;)Z
    .locals 2

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    return v1

    .line 9
    :cond_0
    invoke-static {p0}, LL8/c;->b(Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-ne v0, p0, :cond_1

    .line 18
    .line 19
    const/4 p0, 0x1

    .line 20
    return p0

    .line 21
    :cond_1
    return v1
.end method

.method public static valueOf(Ljava/lang/String;)LL8/c;
    .locals 1

    .line 1
    const-class v0, LL8/c;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LL8/c;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[LL8/c;
    .locals 1

    .line 1
    sget-object v0, LL8/c;->c:[LL8/c;

    .line 2
    .line 3
    invoke-virtual {v0}, [LL8/c;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LL8/c;

    .line 8
    .line 9
    return-object v0
.end method
