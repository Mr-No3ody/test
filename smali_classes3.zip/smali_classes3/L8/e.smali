.class public final LL8/e;
.super Landroidx/fragment/app/J;
.source "SourceFile"


# static fields
.field public static final b:LL8/d;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LL8/d;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LL8/d;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LL8/e;->b:LL8/d;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    .locals 4

    .line 1
    const-string v0, "classLoader"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "className"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object v0, LL8/e;->b:LL8/d;

    .line 12
    .line 13
    invoke-virtual {v0, p2}, LL8/d;->isBiometricInternalFragment(Ljava/lang/String;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    const-string p1, "skip restore biometric fragment: "

    .line 20
    .line 21
    invoke-static {p1, p2}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    const/4 p2, 0x5

    .line 30
    const-string v0, "SafeFragmentFactory"

    .line 31
    .line 32
    invoke-static {v0, p2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    new-instance p1, Landroidx/fragment/app/Fragment;

    .line 36
    .line 37
    invoke-direct {p1}, Landroidx/fragment/app/Fragment;-><init>()V

    .line 38
    .line 39
    .line 40
    return-object p1

    .line 41
    :cond_0
    const-string v0, ": make sure class name exists, is public, and has an empty constructor that is public"

    .line 42
    .line 43
    const-string v1, "Unable to instantiate fragment "

    .line 44
    .line 45
    :try_start_0
    invoke-static {p1, p2}, Landroidx/fragment/app/J;->c(Ljava/lang/ClassLoader;Ljava/lang/String;)Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    const/4 v2, 0x0

    .line 50
    new-array v3, v2, [Ljava/lang/Class;

    .line 51
    .line 52
    invoke-virtual {p1, v3}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    new-array v2, v2, [Ljava/lang/Object;

    .line 57
    .line 58
    invoke-virtual {p1, v2}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    check-cast p1, Landroidx/fragment/app/Fragment;
    :try_end_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    .line 63
    .line 64
    const-string p2, "instantiate(...)"

    .line 65
    .line 66
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    return-object p1

    .line 70
    :catch_0
    move-exception p1

    .line 71
    goto :goto_0

    .line 72
    :catch_1
    move-exception p1

    .line 73
    goto :goto_1

    .line 74
    :catch_2
    move-exception p1

    .line 75
    goto :goto_2

    .line 76
    :catch_3
    move-exception p1

    .line 77
    goto :goto_3

    .line 78
    :goto_0
    new-instance v0, LP0/c;

    .line 79
    .line 80
    const-string v2, ": calling Fragment constructor caused an exception"

    .line 81
    .line 82
    invoke-static {v1, p2, v2}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object p2

    .line 86
    const/4 v1, 0x5

    .line 87
    invoke-direct {v0, v1, p2, p1}, LP0/c;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 88
    .line 89
    .line 90
    throw v0

    .line 91
    :goto_1
    new-instance v0, LP0/c;

    .line 92
    .line 93
    const-string v2, ": could not find Fragment constructor"

    .line 94
    .line 95
    invoke-static {v1, p2, v2}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object p2

    .line 99
    const/4 v1, 0x5

    .line 100
    invoke-direct {v0, v1, p2, p1}, LP0/c;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 101
    .line 102
    .line 103
    throw v0

    .line 104
    :goto_2
    new-instance v2, LP0/c;

    .line 105
    .line 106
    invoke-static {v1, p2, v0}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object p2

    .line 110
    const/4 v0, 0x5

    .line 111
    invoke-direct {v2, v0, p2, p1}, LP0/c;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 112
    .line 113
    .line 114
    throw v2

    .line 115
    :goto_3
    new-instance v2, LP0/c;

    .line 116
    .line 117
    invoke-static {v1, p2, v0}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object p2

    .line 121
    const/4 v0, 0x5

    .line 122
    invoke-direct {v2, v0, p2, p1}, LP0/c;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 123
    .line 124
    .line 125
    throw v2
.end method
