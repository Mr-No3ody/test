.class public final synthetic Lo7/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/activity/result/ActivityResultCallback;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/permissionx/guolindev/request/InvisibleFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, Lo7/c;->a:I

    iput-object p1, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onActivityResult(Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget v0, p0, Lo7/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 7
    .line 8
    iget-object p1, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 9
    .line 10
    const-string v0, "this$0"

    .line 11
    .line 12
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->f()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    iget-object v0, p1, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    new-instance v2, Ljava/util/ArrayList;

    .line 27
    .line 28
    iget-object p1, p1, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 29
    .line 30
    if-eqz p1, :cond_0

    .line 31
    .line 32
    iget-object p1, p1, Lo7/h;->i:Ljava/util/LinkedHashSet;

    .line 33
    .line 34
    invoke-direct {v2, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 35
    .line 36
    .line 37
    invoke-interface {v0, v2}, Lcom/permissionx/guolindev/request/ChainTask;->requestAgain(Ljava/util/List;)V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    const-string p1, "pb"

    .line 42
    .line 43
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw v1

    .line 47
    :cond_1
    const-string p1, "task"

    .line 48
    .line 49
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw v1

    .line 53
    :cond_2
    :goto_0
    return-void

    .line 54
    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    .line 55
    .line 56
    iget-object v0, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 57
    .line 58
    const-string v1, "this$0"

    .line 59
    .line 60
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    new-instance v1, Lo7/f;

    .line 64
    .line 65
    const/4 v2, 0x1

    .line 66
    invoke-direct {v1, v0, p1, v2}, Lo7/f;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;Ljava/lang/Boolean;I)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v0, v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 70
    .line 71
    .line 72
    return-void

    .line 73
    :pswitch_1
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 74
    .line 75
    iget-object p1, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 76
    .line 77
    const-string v0, "this$0"

    .line 78
    .line 79
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    new-instance v0, Lo7/e;

    .line 83
    .line 84
    const/4 v1, 0x6

    .line 85
    invoke-direct {v0, p1, v1}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p1, v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 89
    .line 90
    .line 91
    return-void

    .line 92
    :pswitch_2
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 93
    .line 94
    iget-object p1, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 95
    .line 96
    const-string v0, "this$0"

    .line 97
    .line 98
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    new-instance v0, Lo7/e;

    .line 102
    .line 103
    const/4 v1, 0x4

    .line 104
    invoke-direct {v0, p1, v1}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {p1, v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :pswitch_3
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 112
    .line 113
    iget-object p1, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 114
    .line 115
    const-string v0, "this$0"

    .line 116
    .line 117
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    new-instance v0, Lo7/e;

    .line 121
    .line 122
    const/4 v1, 0x5

    .line 123
    invoke-direct {v0, p1, v1}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {p1, v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 127
    .line 128
    .line 129
    return-void

    .line 130
    :pswitch_4
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 131
    .line 132
    iget-object p1, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 133
    .line 134
    const-string v0, "this$0"

    .line 135
    .line 136
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    new-instance v0, Lo7/e;

    .line 140
    .line 141
    const/16 v1, 0x8

    .line 142
    .line 143
    invoke-direct {v0, p1, v1}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {p1, v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 147
    .line 148
    .line 149
    return-void

    .line 150
    :pswitch_5
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 151
    .line 152
    iget-object p1, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 153
    .line 154
    const-string v0, "this$0"

    .line 155
    .line 156
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    new-instance v0, Lo7/e;

    .line 160
    .line 161
    const/4 v1, 0x7

    .line 162
    invoke-direct {v0, p1, v1}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {p1, v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 166
    .line 167
    .line 168
    return-void

    .line 169
    :pswitch_6
    check-cast p1, Ljava/lang/Boolean;

    .line 170
    .line 171
    iget-object v0, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 172
    .line 173
    const-string v1, "this$0"

    .line 174
    .line 175
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 176
    .line 177
    .line 178
    new-instance v1, Lo7/f;

    .line 179
    .line 180
    const/4 v2, 0x0

    .line 181
    invoke-direct {v1, v0, p1, v2}, Lo7/f;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;Ljava/lang/Boolean;I)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v0, v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 185
    .line 186
    .line 187
    return-void

    .line 188
    :pswitch_7
    check-cast p1, Ljava/util/Map;

    .line 189
    .line 190
    iget-object v0, p0, Lo7/c;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 191
    .line 192
    const-string v1, "this$0"

    .line 193
    .line 194
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    new-instance v1, LE0/h;

    .line 198
    .line 199
    const/4 v2, 0x7

    .line 200
    invoke-direct {v1, v2, v0, p1}, LE0/h;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v0, v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 204
    .line 205
    .line 206
    return-void

    .line 207
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
