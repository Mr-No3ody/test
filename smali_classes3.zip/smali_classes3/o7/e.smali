.class public final Lo7/e;
.super Lkotlin/jvm/internal/o;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/permissionx/guolindev/request/InvisibleFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, Lo7/e;->a:I

    iput-object p1, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/o;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, Lo7/e;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->f()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    new-instance v1, Lo7/e;

    .line 15
    .line 16
    const/4 v2, 0x3

    .line 17
    invoke-direct {v1, v0, v2}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0, v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 24
    .line 25
    return-object v0

    .line 26
    :pswitch_0
    iget-object v0, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->g()V

    .line 29
    .line 30
    .line 31
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 32
    .line 33
    return-object v0

    .line 34
    :pswitch_1
    iget-object v0, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 35
    .line 36
    invoke-virtual {v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->f()Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-eqz v1, :cond_1

    .line 41
    .line 42
    new-instance v1, Lo7/e;

    .line 43
    .line 44
    const/4 v2, 0x2

    .line 45
    invoke-direct {v1, v0, v2}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v0, v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 49
    .line 50
    .line 51
    :cond_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 52
    .line 53
    return-object v0

    .line 54
    :pswitch_2
    iget-object v0, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 55
    .line 56
    invoke-virtual {v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->f()Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-eqz v1, :cond_2

    .line 61
    .line 62
    new-instance v1, Lo7/e;

    .line 63
    .line 64
    const/4 v2, 0x1

    .line 65
    invoke-direct {v1, v0, v2}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0, v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 69
    .line 70
    .line 71
    :cond_2
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 72
    .line 73
    return-object v0

    .line 74
    :pswitch_3
    iget-object v0, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 75
    .line 76
    invoke-virtual {v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;->f()Z

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    if-eqz v1, :cond_3

    .line 81
    .line 82
    new-instance v1, Lo7/e;

    .line 83
    .line 84
    const/4 v2, 0x0

    .line 85
    invoke-direct {v1, v0, v2}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v0, v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 89
    .line 90
    .line 91
    :cond_3
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 92
    .line 93
    return-object v0

    .line 94
    :pswitch_4
    iget-object v0, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 95
    .line 96
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    invoke-static {v1}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    const/4 v2, 0x0

    .line 105
    if-eqz v1, :cond_5

    .line 106
    .line 107
    iget-object v0, v0, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 108
    .line 109
    if-eqz v0, :cond_4

    .line 110
    .line 111
    invoke-interface {v0}, Lcom/permissionx/guolindev/request/ChainTask;->finish()V

    .line 112
    .line 113
    .line 114
    goto :goto_0

    .line 115
    :cond_4
    const-string v0, "task"

    .line 116
    .line 117
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    throw v2

    .line 121
    :cond_5
    iget-object v0, v0, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 122
    .line 123
    const-string v1, "pb"

    .line 124
    .line 125
    if-eqz v0, :cond_7

    .line 126
    .line 127
    if-eqz v0, :cond_6

    .line 128
    .line 129
    :goto_0
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 130
    .line 131
    return-object v0

    .line 132
    :cond_6
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    throw v2

    .line 136
    :cond_7
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    throw v2

    .line 140
    :pswitch_5
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 141
    .line 142
    iget-object v1, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 143
    .line 144
    const/4 v2, 0x0

    .line 145
    const/16 v3, 0x1a

    .line 146
    .line 147
    const-string v4, "task"

    .line 148
    .line 149
    if-lt v0, v3, :cond_b

    .line 150
    .line 151
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    new-instance v3, Landroidx/core/app/M;

    .line 156
    .line 157
    invoke-direct {v3, v0}, Landroidx/core/app/M;-><init>(Landroid/content/Context;)V

    .line 158
    .line 159
    .line 160
    iget-object v0, v3, Landroidx/core/app/M;->b:Landroid/app/NotificationManager;

    .line 161
    .line 162
    invoke-virtual {v0}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    if-eqz v0, :cond_9

    .line 167
    .line 168
    iget-object v0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 169
    .line 170
    if-eqz v0, :cond_8

    .line 171
    .line 172
    invoke-interface {v0}, Lcom/permissionx/guolindev/request/ChainTask;->finish()V

    .line 173
    .line 174
    .line 175
    goto :goto_1

    .line 176
    :cond_8
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    throw v2

    .line 180
    :cond_9
    iget-object v0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 181
    .line 182
    if-eqz v0, :cond_a

    .line 183
    .line 184
    goto :goto_1

    .line 185
    :cond_a
    const-string v0, "pb"

    .line 186
    .line 187
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    throw v2

    .line 191
    :cond_b
    iget-object v0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 192
    .line 193
    if-eqz v0, :cond_c

    .line 194
    .line 195
    invoke-interface {v0}, Lcom/permissionx/guolindev/request/ChainTask;->finish()V

    .line 196
    .line 197
    .line 198
    :goto_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 199
    .line 200
    return-object v0

    .line 201
    :cond_c
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 202
    .line 203
    .line 204
    throw v2

    .line 205
    :pswitch_6
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 206
    .line 207
    const/4 v1, 0x0

    .line 208
    const/16 v2, 0x1e

    .line 209
    .line 210
    const-string v3, "task"

    .line 211
    .line 212
    iget-object v4, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 213
    .line 214
    if-lt v0, v2, :cond_10

    .line 215
    .line 216
    invoke-static {}, Lcom/google/android/material/color/a;->o()Z

    .line 217
    .line 218
    .line 219
    move-result v0

    .line 220
    if-eqz v0, :cond_e

    .line 221
    .line 222
    iget-object v0, v4, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 223
    .line 224
    if-eqz v0, :cond_d

    .line 225
    .line 226
    invoke-interface {v0}, Lcom/permissionx/guolindev/request/ChainTask;->finish()V

    .line 227
    .line 228
    .line 229
    goto :goto_2

    .line 230
    :cond_d
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 231
    .line 232
    .line 233
    throw v1

    .line 234
    :cond_e
    iget-object v0, v4, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 235
    .line 236
    if-eqz v0, :cond_f

    .line 237
    .line 238
    goto :goto_2

    .line 239
    :cond_f
    const-string v0, "pb"

    .line 240
    .line 241
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 242
    .line 243
    .line 244
    throw v1

    .line 245
    :cond_10
    iget-object v0, v4, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 246
    .line 247
    if-eqz v0, :cond_11

    .line 248
    .line 249
    invoke-interface {v0}, Lcom/permissionx/guolindev/request/ChainTask;->finish()V

    .line 250
    .line 251
    .line 252
    :goto_2
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 253
    .line 254
    return-object v0

    .line 255
    :cond_11
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    throw v1

    .line 259
    :pswitch_7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 260
    .line 261
    const/4 v1, 0x0

    .line 262
    const/16 v2, 0x1a

    .line 263
    .line 264
    const-string v3, "task"

    .line 265
    .line 266
    iget-object v4, p0, Lo7/e;->b:Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 267
    .line 268
    if-lt v0, v2, :cond_15

    .line 269
    .line 270
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 275
    .line 276
    .line 277
    move-result-object v0

    .line 278
    invoke-static {v0}, Lcom/horcrux/svg/Z;->z(Landroid/content/pm/PackageManager;)Z

    .line 279
    .line 280
    .line 281
    move-result v0

    .line 282
    if-eqz v0, :cond_13

    .line 283
    .line 284
    iget-object v0, v4, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 285
    .line 286
    if-eqz v0, :cond_12

    .line 287
    .line 288
    invoke-interface {v0}, Lcom/permissionx/guolindev/request/ChainTask;->finish()V

    .line 289
    .line 290
    .line 291
    goto :goto_3

    .line 292
    :cond_12
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 293
    .line 294
    .line 295
    throw v1

    .line 296
    :cond_13
    iget-object v0, v4, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 297
    .line 298
    if-eqz v0, :cond_14

    .line 299
    .line 300
    goto :goto_3

    .line 301
    :cond_14
    const-string v0, "pb"

    .line 302
    .line 303
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    throw v1

    .line 307
    :cond_15
    iget-object v0, v4, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 308
    .line 309
    if-eqz v0, :cond_16

    .line 310
    .line 311
    invoke-interface {v0}, Lcom/permissionx/guolindev/request/ChainTask;->finish()V

    .line 312
    .line 313
    .line 314
    :goto_3
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 315
    .line 316
    return-object v0

    .line 317
    :cond_16
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 318
    .line 319
    .line 320
    throw v1

    .line 321
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
