.class public final Lo7/q;
.super LV3/d;
.source "SourceFile"


# instance fields
.field public final synthetic f:I


# direct methods
.method public synthetic constructor <init>(Lo7/h;I)V
    .locals 0

    .line 1
    iput p2, p0, Lo7/q;->f:I

    invoke-direct {p0, p1}, LV3/d;-><init>(Lo7/h;)V

    return-void
.end method


# virtual methods
.method public final request()V
    .locals 5

    .line 1
    iget v0, p0, Lo7/q;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LV3/d;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lo7/h;

    .line 9
    .line 10
    iget-object v1, v0, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 11
    .line 12
    const-string v2, "android.permission.WRITE_SETTINGS"

    .line 13
    .line 14
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_2

    .line 19
    .line 20
    invoke-virtual {v0}, Lo7/h;->d()I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    const/16 v3, 0x17

    .line 25
    .line 26
    if-lt v1, v3, :cond_1

    .line 27
    .line 28
    invoke-virtual {v0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-static {v0}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    iget-object v1, v0, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 47
    .line 48
    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    iget-object v0, v0, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 52
    .line 53
    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 57
    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_2
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 61
    .line 62
    .line 63
    :goto_0
    return-void

    .line 64
    :pswitch_0
    iget-object v0, p0, LV3/d;->e:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v0, Lo7/h;

    .line 67
    .line 68
    iget-object v1, v0, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 69
    .line 70
    const-string v2, "android.permission.SYSTEM_ALERT_WINDOW"

    .line 71
    .line 72
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    if-eqz v1, :cond_5

    .line 77
    .line 78
    invoke-virtual {v0}, Lo7/h;->d()I

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    const/16 v3, 0x17

    .line 83
    .line 84
    if-lt v1, v3, :cond_4

    .line 85
    .line 86
    invoke-virtual {v0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-static {v0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    if-eqz v0, :cond_3

    .line 95
    .line 96
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_3
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 101
    .line 102
    .line 103
    goto :goto_1

    .line 104
    :cond_4
    iget-object v1, v0, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 105
    .line 106
    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    iget-object v0, v0, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 110
    .line 111
    invoke-interface {v0, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 115
    .line 116
    .line 117
    goto :goto_1

    .line 118
    :cond_5
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 119
    .line 120
    .line 121
    :goto_1
    return-void

    .line 122
    :pswitch_1
    iget-object v0, p0, LV3/d;->e:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast v0, Lo7/h;

    .line 125
    .line 126
    iget-object v1, v0, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 127
    .line 128
    const-string v2, "android.permission.POST_NOTIFICATIONS"

    .line 129
    .line 130
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v1

    .line 134
    if-eqz v1, :cond_6

    .line 135
    .line 136
    invoke-virtual {v0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    new-instance v1, Landroidx/core/app/M;

    .line 141
    .line 142
    invoke-direct {v1, v0}, Landroidx/core/app/M;-><init>(Landroid/content/Context;)V

    .line 143
    .line 144
    .line 145
    iget-object v0, v1, Landroidx/core/app/M;->b:Landroid/app/NotificationManager;

    .line 146
    .line 147
    invoke-virtual {v0}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    if-eqz v0, :cond_6

    .line 152
    .line 153
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 154
    .line 155
    .line 156
    goto :goto_2

    .line 157
    :cond_6
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 158
    .line 159
    .line 160
    :goto_2
    return-void

    .line 161
    :pswitch_2
    new-instance v0, Ljava/util/ArrayList;

    .line 162
    .line 163
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 164
    .line 165
    .line 166
    iget-object v1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 167
    .line 168
    check-cast v1, Lo7/h;

    .line 169
    .line 170
    iget-object v2, v1, Lo7/h;->c:Ljava/util/LinkedHashSet;

    .line 171
    .line 172
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 177
    .line 178
    .line 179
    move-result v3

    .line 180
    if-eqz v3, :cond_8

    .line 181
    .line 182
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    move-result-object v3

    .line 186
    check-cast v3, Ljava/lang/String;

    .line 187
    .line 188
    invoke-virtual {v1}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 189
    .line 190
    .line 191
    move-result-object v4

    .line 192
    invoke-static {v4, v3}, Landroidx/core/content/d;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 193
    .line 194
    .line 195
    move-result v4

    .line 196
    if-nez v4, :cond_7

    .line 197
    .line 198
    iget-object v4, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 199
    .line 200
    invoke-interface {v4, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 201
    .line 202
    .line 203
    goto :goto_3

    .line 204
    :cond_7
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 205
    .line 206
    .line 207
    goto :goto_3

    .line 208
    :cond_8
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 209
    .line 210
    .line 211
    move-result v0

    .line 212
    if-eqz v0, :cond_9

    .line 213
    .line 214
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 215
    .line 216
    .line 217
    goto :goto_4

    .line 218
    :cond_9
    iget-object v0, v1, Lo7/h;->c:Ljava/util/LinkedHashSet;

    .line 219
    .line 220
    invoke-virtual {v1, v0, p0}, Lo7/h;->f(Ljava/util/HashSet;Lo7/q;)V

    .line 221
    .line 222
    .line 223
    :goto_4
    return-void

    .line 224
    nop

    .line 225
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final requestAgain(Ljava/util/List;)V
    .locals 3

    .line 1
    iget v0, p0, Lo7/q;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "permissions"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Lo7/h;

    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    const-string v0, "chainTask"

    .line 19
    .line 20
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Lo7/h;->c()Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const-string v2, "permissionBuilder"

    .line 28
    .line 29
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    iput-object p1, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 36
    .line 37
    iput-object p0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 38
    .line 39
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    invoke-static {p1}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    .line 44
    .line 45
    .line 46
    move-result p1

    .line 47
    if-nez p1, :cond_0

    .line 48
    .line 49
    new-instance p1, Landroid/content/Intent;

    .line 50
    .line 51
    const-string v0, "android.settings.action.MANAGE_WRITE_SETTINGS"

    .line 52
    .line 53
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    new-instance v0, Ljava/lang/StringBuilder;

    .line 57
    .line 58
    const-string v2, "package:"

    .line 59
    .line 60
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-virtual {p1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 83
    .line 84
    .line 85
    iget-object v0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->g:Landroidx/activity/result/a;

    .line 86
    .line 87
    invoke-virtual {v0, p1}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    goto :goto_0

    .line 91
    :cond_0
    invoke-virtual {v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->f()Z

    .line 92
    .line 93
    .line 94
    move-result p1

    .line 95
    if-eqz p1, :cond_1

    .line 96
    .line 97
    new-instance p1, Lo7/e;

    .line 98
    .line 99
    const/4 v0, 0x3

    .line 100
    invoke-direct {p1, v1, v0}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v1, p1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 104
    .line 105
    .line 106
    :cond_1
    :goto_0
    return-void

    .line 107
    :pswitch_0
    const-string v0, "permissions"

    .line 108
    .line 109
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    iget-object p1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast p1, Lo7/h;

    .line 115
    .line 116
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    .line 118
    .line 119
    const-string v0, "chainTask"

    .line 120
    .line 121
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {p1}, Lo7/h;->c()Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    const-string v2, "permissionBuilder"

    .line 129
    .line 130
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    iput-object p1, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 137
    .line 138
    iput-object p0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 139
    .line 140
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    invoke-static {p1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    .line 145
    .line 146
    .line 147
    move-result p1

    .line 148
    if-nez p1, :cond_2

    .line 149
    .line 150
    new-instance p1, Landroid/content/Intent;

    .line 151
    .line 152
    const-string v0, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    .line 153
    .line 154
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    new-instance v0, Ljava/lang/StringBuilder;

    .line 158
    .line 159
    const-string v2, "package:"

    .line 160
    .line 161
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    invoke-virtual {p1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 184
    .line 185
    .line 186
    iget-object v0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->f:Landroidx/activity/result/a;

    .line 187
    .line 188
    invoke-virtual {v0, p1}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V

    .line 189
    .line 190
    .line 191
    goto :goto_1

    .line 192
    :cond_2
    invoke-virtual {v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->g()V

    .line 193
    .line 194
    .line 195
    :goto_1
    return-void

    .line 196
    :pswitch_1
    const-string v0, "permissions"

    .line 197
    .line 198
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    iget-object p1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 202
    .line 203
    check-cast p1, Lo7/h;

    .line 204
    .line 205
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 206
    .line 207
    .line 208
    const-string v0, "chainTask"

    .line 209
    .line 210
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {p1}, Lo7/h;->c()Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 214
    .line 215
    .line 216
    move-result-object v1

    .line 217
    const-string v2, "permissionBuilder"

    .line 218
    .line 219
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 223
    .line 224
    .line 225
    iput-object p1, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 226
    .line 227
    iput-object p0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 228
    .line 229
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 230
    .line 231
    const/16 v0, 0x1a

    .line 232
    .line 233
    if-lt p1, v0, :cond_3

    .line 234
    .line 235
    new-instance p1, Landroid/content/Intent;

    .line 236
    .line 237
    const-string v0, "android.settings.APP_NOTIFICATION_SETTINGS"

    .line 238
    .line 239
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    const-string v2, "android.provider.extra.APP_PACKAGE"

    .line 251
    .line 252
    invoke-virtual {p1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 253
    .line 254
    .line 255
    iget-object v0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->o:Landroidx/activity/result/a;

    .line 256
    .line 257
    invoke-virtual {v0, p1}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    goto :goto_2

    .line 261
    :cond_3
    invoke-virtual {v1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->f()Z

    .line 262
    .line 263
    .line 264
    move-result p1

    .line 265
    if-eqz p1, :cond_4

    .line 266
    .line 267
    new-instance p1, Lo7/e;

    .line 268
    .line 269
    const/4 v0, 0x0

    .line 270
    invoke-direct {p1, v1, v0}, Lo7/e;-><init>(Lcom/permissionx/guolindev/request/InvisibleFragment;I)V

    .line 271
    .line 272
    .line 273
    invoke-virtual {v1, p1}, Lcom/permissionx/guolindev/request/InvisibleFragment;->h(Lkotlin/jvm/functions/Function0;)V

    .line 274
    .line 275
    .line 276
    :cond_4
    :goto_2
    return-void

    .line 277
    :pswitch_2
    const-string v0, "permissions"

    .line 278
    .line 279
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 280
    .line 281
    .line 282
    new-instance v0, Ljava/util/HashSet;

    .line 283
    .line 284
    iget-object v1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 285
    .line 286
    check-cast v1, Lo7/h;

    .line 287
    .line 288
    iget-object v2, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 289
    .line 290
    invoke-direct {v0, v2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 291
    .line 292
    .line 293
    check-cast p1, Ljava/util/Collection;

    .line 294
    .line 295
    invoke-interface {v0, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 296
    .line 297
    .line 298
    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    .line 299
    .line 300
    .line 301
    move-result p1

    .line 302
    if-nez p1, :cond_5

    .line 303
    .line 304
    invoke-virtual {v1, v0, p0}, Lo7/h;->f(Ljava/util/HashSet;Lo7/q;)V

    .line 305
    .line 306
    .line 307
    goto :goto_3

    .line 308
    :cond_5
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 309
    .line 310
    .line 311
    :goto_3
    return-void

    .line 312
    nop

    .line 313
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
