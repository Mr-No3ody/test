.class public final Lo7/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroidx/fragment/app/E;

.field public b:I

.field public c:Ljava/util/LinkedHashSet;

.field public d:Ljava/util/LinkedHashSet;

.field public e:Ljava/util/LinkedHashSet;

.field public f:Ljava/util/LinkedHashSet;

.field public g:Ljava/util/LinkedHashSet;

.field public h:Ljava/util/LinkedHashSet;

.field public i:Ljava/util/LinkedHashSet;

.field public j:Lcom/permissionx/guolindev/callback/RequestCallback;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lo7/g;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lo7/g;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final a()Landroidx/fragment/app/E;
    .locals 1

    .line 1
    iget-object v0, p0, Lo7/h;->a:Landroidx/fragment/app/E;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    const-string v0, "activity"

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    throw v0
.end method

.method public final b()Landroidx/fragment/app/Z;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroidx/fragment/app/E;->getSupportFragmentManager()Landroidx/fragment/app/Z;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const-string v1, "activity.supportFragmentManager"

    .line 10
    .line 11
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final c()Lcom/permissionx/guolindev/request/InvisibleFragment;
    .locals 5

    .line 1
    invoke-virtual {p0}, Lo7/h;->b()Landroidx/fragment/app/Z;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "InvisibleFragment"

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroidx/fragment/app/Z;->E(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    check-cast v0, Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_0
    new-instance v0, Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 17
    .line 18
    invoke-direct {v0}, Lcom/permissionx/guolindev/request/InvisibleFragment;-><init>()V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0}, Lo7/h;->b()Landroidx/fragment/app/Z;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    invoke-static {v2, v2}, LN8/q0;->e(Landroidx/fragment/app/Z;Landroidx/fragment/app/Z;)Landroidx/fragment/app/a;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    const/4 v3, 0x0

    .line 30
    const/4 v4, 0x1

    .line 31
    invoke-virtual {v2, v3, v0, v1, v4}, Landroidx/fragment/app/a;->d(ILandroidx/fragment/app/Fragment;Ljava/lang/String;I)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v2}, Landroidx/fragment/app/a;->j()V

    .line 35
    .line 36
    .line 37
    return-object v0
.end method

.method public final d()I
    .locals 1

    .line 1
    invoke-virtual {p0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget v0, v0, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    .line 10
    .line 11
    return v0
.end method

.method public final e(Lcom/permissionx/guolindev/callback/RequestCallback;)V
    .locals 3

    .line 1
    iput-object p1, p0, Lo7/h;->j:Lcom/permissionx/guolindev/callback/RequestCallback;

    .line 2
    .line 3
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 4
    .line 5
    const/16 v0, 0x1a

    .line 6
    .line 7
    if-eq p1, v0, :cond_2

    .line 8
    .line 9
    invoke-virtual {p0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p1}, Landroid/app/Activity;->getRequestedOrientation()I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    iput p1, p0, Lo7/h;->b:I

    .line 18
    .line 19
    invoke-virtual {p0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    iget p1, p1, Landroid/content/res/Configuration;->orientation:I

    .line 32
    .line 33
    const/4 v0, 0x1

    .line 34
    if-eq p1, v0, :cond_1

    .line 35
    .line 36
    const/4 v0, 0x2

    .line 37
    if-eq p1, v0, :cond_0

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-virtual {p0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    const/4 v0, 0x6

    .line 45
    invoke-virtual {p1, v0}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 46
    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_1
    invoke-virtual {p0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    const/4 v0, 0x7

    .line 54
    invoke-virtual {p1, v0}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 55
    .line 56
    .line 57
    :cond_2
    :goto_0
    new-instance p1, Landroidx/work/impl/model/b;

    .line 58
    .line 59
    const/16 v0, 0x10

    .line 60
    .line 61
    const/4 v1, 0x0

    .line 62
    invoke-direct {p1, v0, v1}, Landroidx/work/impl/model/b;-><init>(IZ)V

    .line 63
    .line 64
    .line 65
    new-instance v0, Lo7/q;

    .line 66
    .line 67
    const-string v1, "permissionBuilder"

    .line 68
    .line 69
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    const/4 v2, 0x0

    .line 73
    invoke-direct {v0, p0, v2}, Lo7/q;-><init>(Lo7/h;I)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p1, v0}, Landroidx/work/impl/model/b;->c(LV3/d;)V

    .line 77
    .line 78
    .line 79
    new-instance v0, Lo7/j;

    .line 80
    .line 81
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-direct {v0, p0}, LV3/d;-><init>(Lo7/h;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {p1, v0}, Landroidx/work/impl/model/b;->c(LV3/d;)V

    .line 88
    .line 89
    .line 90
    new-instance v0, Lo7/q;

    .line 91
    .line 92
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    const/4 v2, 0x2

    .line 96
    invoke-direct {v0, p0, v2}, Lo7/q;-><init>(Lo7/h;I)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p1, v0}, Landroidx/work/impl/model/b;->c(LV3/d;)V

    .line 100
    .line 101
    .line 102
    new-instance v0, Lo7/q;

    .line 103
    .line 104
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    const/4 v2, 0x3

    .line 108
    invoke-direct {v0, p0, v2}, Lo7/q;-><init>(Lo7/h;I)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {p1, v0}, Landroidx/work/impl/model/b;->c(LV3/d;)V

    .line 112
    .line 113
    .line 114
    new-instance v0, Lo7/p;

    .line 115
    .line 116
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    invoke-direct {v0, p0}, LV3/d;-><init>(Lo7/h;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {p1, v0}, Landroidx/work/impl/model/b;->c(LV3/d;)V

    .line 123
    .line 124
    .line 125
    new-instance v0, Lo7/n;

    .line 126
    .line 127
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    invoke-direct {v0, p0}, LV3/d;-><init>(Lo7/h;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1, v0}, Landroidx/work/impl/model/b;->c(LV3/d;)V

    .line 134
    .line 135
    .line 136
    new-instance v0, Lo7/q;

    .line 137
    .line 138
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    const/4 v2, 0x1

    .line 142
    invoke-direct {v0, p0, v2}, Lo7/q;-><init>(Lo7/h;I)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {p1, v0}, Landroidx/work/impl/model/b;->c(LV3/d;)V

    .line 146
    .line 147
    .line 148
    new-instance v0, Lo7/l;

    .line 149
    .line 150
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    invoke-direct {v0, p0}, LV3/d;-><init>(Lo7/h;)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {p1, v0}, Landroidx/work/impl/model/b;->c(LV3/d;)V

    .line 157
    .line 158
    .line 159
    iget-object p1, p1, Landroidx/work/impl/model/b;->b:Ljava/lang/Object;

    .line 160
    .line 161
    check-cast p1, LV3/d;

    .line 162
    .line 163
    if-eqz p1, :cond_3

    .line 164
    .line 165
    invoke-interface {p1}, Lcom/permissionx/guolindev/request/ChainTask;->request()V

    .line 166
    .line 167
    .line 168
    :cond_3
    return-void
.end method

.method public final f(Ljava/util/HashSet;Lo7/q;)V
    .locals 4

    .line 1
    const-string v0, "permissions"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v1, "chainTask"

    .line 7
    .line 8
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Lo7/h;->c()Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const-string v3, "permissionBuilder"

    .line 16
    .line 17
    invoke-static {p0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iput-object p0, v2, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 27
    .line 28
    iput-object p2, v2, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 29
    .line 30
    const/4 p2, 0x0

    .line 31
    new-array p2, p2, [Ljava/lang/String;

    .line 32
    .line 33
    invoke-interface {p1, p2}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    const-string p2, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    .line 38
    .line 39
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    iget-object p2, v2, Lcom/permissionx/guolindev/request/InvisibleFragment;->d:Landroidx/activity/result/a;

    .line 43
    .line 44
    invoke-virtual {p2, p1}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method
