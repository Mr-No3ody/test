.class public final Lo7/l;
.super LV3/d;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lo7/k;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lo7/k;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final request()V
    .locals 4

    .line 1
    iget-object v0, p0, LV3/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo7/h;

    .line 4
    .line 5
    iget-object v1, v0, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 6
    .line 7
    const-string v2, "android.permission.BODY_SENSORS_BACKGROUND"

    .line 8
    .line 9
    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_2

    .line 14
    .line 15
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 16
    .line 17
    const/16 v3, 0x21

    .line 18
    .line 19
    if-ge v1, v3, :cond_0

    .line 20
    .line 21
    iget-object v1, v0, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 22
    .line 23
    invoke-interface {v1, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    iget-object v0, v0, Lo7/h;->e:Ljava/util/LinkedHashSet;

    .line 27
    .line 28
    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_0
    invoke-virtual {v0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-static {v1, v2}, Landroidx/core/content/d;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-nez v1, :cond_1

    .line 44
    .line 45
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :cond_1
    invoke-virtual {v0}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    const-string v1, "android.permission.BODY_SENSORS"

    .line 54
    .line 55
    invoke-static {v0, v1}, Landroidx/core/content/d;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-nez v0, :cond_2

    .line 60
    .line 61
    sget-object v0, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 62
    .line 63
    invoke-virtual {p0, v0}, Lo7/l;->requestAgain(Ljava/util/List;)V

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :cond_2
    invoke-virtual {p0}, LV3/d;->finish()V

    .line 68
    .line 69
    .line 70
    return-void
.end method

.method public final requestAgain(Ljava/util/List;)V
    .locals 3

    .line 1
    const-string v0, "permissions"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Lo7/h;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    const-string v0, "chainTask"

    .line 14
    .line 15
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p1}, Lo7/h;->c()Lcom/permissionx/guolindev/request/InvisibleFragment;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    const-string v2, "permissionBuilder"

    .line 23
    .line 24
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    iput-object p1, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->b:Lo7/h;

    .line 31
    .line 32
    iput-object p0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->c:Lcom/permissionx/guolindev/request/ChainTask;

    .line 33
    .line 34
    const-string p1, "android.permission.BODY_SENSORS_BACKGROUND"

    .line 35
    .line 36
    iget-object v0, v1, Lcom/permissionx/guolindev/request/InvisibleFragment;->p:Landroidx/activity/result/a;

    .line 37
    .line 38
    invoke-virtual {v0, p1}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method
