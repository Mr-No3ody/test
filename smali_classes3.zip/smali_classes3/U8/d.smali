.class public final LU8/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;

.field public final synthetic c:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;I)V
    .locals 0

    .line 1
    iput p3, p0, LU8/d;->a:I

    iput-object p1, p0, LU8/d;->b:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;

    iput-object p2, p0, LU8/d;->c:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    const-string v0, "securityQuestion"

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, LU8/d;->c:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;

    .line 5
    .line 6
    const/4 v3, 0x1

    .line 7
    iget-object v4, p0, LU8/d;->b:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;

    .line 8
    .line 9
    const-string v5, "it"

    .line 10
    .line 11
    iget v6, p0, LU8/d;->a:I

    .line 12
    .line 13
    packed-switch v6, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 17
    .line 18
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    instance-of v5, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 22
    .line 23
    if-eqz v5, :cond_0

    .line 24
    .line 25
    invoke-virtual {v4, v3, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(ZZ)V

    .line 26
    .line 27
    .line 28
    goto/16 :goto_3

    .line 29
    .line 30
    :cond_0
    instance-of v5, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 31
    .line 32
    if-eqz v5, :cond_a

    .line 33
    .line 34
    invoke-virtual {v4, v1, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(ZZ)V

    .line 35
    .line 36
    .line 37
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 38
    .line 39
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 42
    .line 43
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    const/4 v5, 0x0

    .line 48
    if-eqz v4, :cond_6

    .line 49
    .line 50
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast p1, Lcom/transsnet/palmpay/account/bean/rsp/VerifyAccountHistoryRsp;

    .line 53
    .line 54
    iget-boolean v3, p1, Lcom/transsnet/palmpay/account/bean/rsp/VerifyAccountHistoryRsp;->result:Z

    .line 55
    .line 56
    if-eqz v3, :cond_5

    .line 57
    .line 58
    iget-boolean v3, p1, Lcom/transsnet/palmpay/account/bean/rsp/VerifyAccountHistoryRsp;->endFlag:Z

    .line 59
    .line 60
    if-nez v3, :cond_3

    .line 61
    .line 62
    sget-object p1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->v:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment$a;

    .line 63
    .line 64
    iget-object p1, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 65
    .line 66
    check-cast p1, Lcom/transsnet/palmpay/account/ui/viewmodel/VerifyAccountHistoryViewModel;

    .line 67
    .line 68
    if-eqz p1, :cond_9

    .line 69
    .line 70
    iget-object v0, v2, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->p:Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;

    .line 71
    .line 72
    if-eqz v0, :cond_1

    .line 73
    .line 74
    iget-object v3, v0, Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;->flowId:Ljava/lang/String;

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_1
    move-object v3, v5

    .line 78
    :goto_0
    if-eqz v0, :cond_2

    .line 79
    .line 80
    iget-object v5, v0, Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;->mobile:Ljava/lang/String;

    .line 81
    .line 82
    :cond_2
    invoke-virtual {p1, v3, v5}, Lcom/transsnet/palmpay/account/ui/viewmodel/VerifyAccountHistoryViewModel;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    goto/16 :goto_2

    .line 86
    .line 87
    :cond_3
    iget-object v3, v2, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->p:Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;

    .line 88
    .line 89
    if-eqz v3, :cond_4

    .line 90
    .line 91
    iget-object p1, p1, Lcom/transsnet/palmpay/account/bean/rsp/VerifyAccountHistoryRsp;->securityVerifyToken:Ljava/lang/String;

    .line 92
    .line 93
    iput-object p1, v3, Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;->securityVerifyToken:Ljava/lang/String;

    .line 94
    .line 95
    :cond_4
    if-eqz v3, :cond_9

    .line 96
    .line 97
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    invoke-virtual {v3, p1, v0}, Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;->nextStep(Landroid/app/Activity;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    goto/16 :goto_2

    .line 105
    .line 106
    :cond_5
    new-instance p1, Lcom/transsnet/palmpay/custom_view/dialog/t;

    .line 107
    .line 108
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    invoke-direct {p1, v0}, Lcom/transsnet/palmpay/custom_view/dialog/t;-><init>(Landroid/content/Context;)V

    .line 113
    .line 114
    .line 115
    const/16 v0, 0x66

    .line 116
    .line 117
    iput v0, p1, Lcom/transsnet/palmpay/custom_view/dialog/t;->h:I

    .line 118
    .line 119
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/t;->a()V

    .line 120
    .line 121
    .line 122
    sget v0, LF8/h;->ac_wrong_answer:I

    .line 123
    .line 124
    iget-object v3, p1, Lcom/transsnet/palmpay/custom_view/dialog/t;->a:Landroid/content/Context;

    .line 125
    .line 126
    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    iput-object v0, p1, Lcom/transsnet/palmpay/custom_view/dialog/t;->b:Ljava/lang/String;

    .line 131
    .line 132
    const/16 v0, 0x5dc

    .line 133
    .line 134
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/custom_view/dialog/t;->d(I)Lcom/transsnet/palmpay/custom_view/dialog/SuccessFailDialog;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    new-instance v0, LCe/T;

    .line 139
    .line 140
    const/4 v3, 0x5

    .line 141
    invoke-direct {v0, v2, v3}, LCe/T;-><init>(Ljava/lang/Object;I)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {p1, v0}, LO6/f;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 145
    .line 146
    .line 147
    goto :goto_2

    .line 148
    :cond_6
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    const-string v4, "SA0001"

    .line 153
    .line 154
    invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    if-nez v0, :cond_8

    .line 159
    .line 160
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    const-string v4, "CFRONT_800115"

    .line 165
    .line 166
    invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result v0

    .line 170
    if-eqz v0, :cond_7

    .line 171
    .line 172
    goto :goto_1

    .line 173
    :cond_7
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    new-instance v3, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;

    .line 182
    .line 183
    sget v4, Lcom/transsnet/palmpay/custom_view/t;->cv_toast_dialog:I

    .line 184
    .line 185
    invoke-direct {v3, v0, v4}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;-><init>(Landroid/content/Context;I)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v3, p1}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->setMessage(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v3, v5}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->setTitle(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    invoke-static {v3, v1}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->d(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;I)V

    .line 195
    .line 196
    .line 197
    invoke-static {v3, v5}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->e(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;Lcom/mikepenz/iconics/IconicsDrawable;)V

    .line 198
    .line 199
    .line 200
    invoke-static {v3}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->c(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;)V

    .line 201
    .line 202
    .line 203
    const-wide/16 v4, 0x7d0

    .line 204
    .line 205
    invoke-virtual {v3, v4, v5}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->show(J)V

    .line 206
    .line 207
    .line 208
    goto :goto_2

    .line 209
    :cond_8
    :goto_1
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 210
    .line 211
    .line 212
    move-result-object v0

    .line 213
    const-string v4, "requireContext(...)"

    .line 214
    .line 215
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 216
    .line 217
    .line 218
    sget v4, LF8/h;->ac_wrong_answer:I

    .line 219
    .line 220
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object p1

    .line 224
    const-string v5, "getRespMsg(...)"

    .line 225
    .line 226
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    sget v5, LF8/h;->ac_contact_customer_care:I

    .line 230
    .line 231
    new-instance v6, LC9/m;

    .line 232
    .line 233
    const/16 v7, 0x8

    .line 234
    .line 235
    invoke-direct {v6, v2, v7}, LC9/m;-><init>(Ljava/lang/Object;I)V

    .line 236
    .line 237
    .line 238
    new-instance v7, LO6/c;

    .line 239
    .line 240
    invoke-direct {v7, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 241
    .line 242
    .line 243
    iput v3, v7, LO6/c;->u:I

    .line 244
    .line 245
    invoke-virtual {v7, v4}, LO6/c;->e(I)V

    .line 246
    .line 247
    .line 248
    iput-object p1, v7, LO6/c;->d:Ljava/lang/CharSequence;

    .line 249
    .line 250
    invoke-virtual {v7, v5, v6}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 251
    .line 252
    .line 253
    iput-boolean v3, v7, LO6/c;->k:Z

    .line 254
    .line 255
    iput v3, v7, LO6/c;->l:I

    .line 256
    .line 257
    invoke-static {v7, v1, v1}, LC0/G;->v(LO6/c;ZZ)V

    .line 258
    .line 259
    .line 260
    :cond_9
    :goto_2
    invoke-virtual {v2, v1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 261
    .line 262
    .line 263
    goto :goto_3

    .line 264
    :cond_a
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 265
    .line 266
    if-eqz v0, :cond_b

    .line 267
    .line 268
    invoke-virtual {v4, v1, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(ZZ)V

    .line 269
    .line 270
    .line 271
    goto :goto_2

    .line 272
    :cond_b
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 273
    .line 274
    if-eqz v0, :cond_c

    .line 275
    .line 276
    invoke-virtual {v4, v1, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(ZZ)V

    .line 277
    .line 278
    .line 279
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 280
    .line 281
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 282
    .line 283
    new-array v0, v1, [Ljava/lang/Object;

    .line 284
    .line 285
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 286
    .line 287
    .line 288
    goto :goto_2

    .line 289
    :goto_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 290
    .line 291
    return-object p1

    .line 292
    :cond_c
    new-instance p1, Lxf/l;

    .line 293
    .line 294
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 295
    .line 296
    .line 297
    throw p1

    .line 298
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 299
    .line 300
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 301
    .line 302
    .line 303
    instance-of v5, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 304
    .line 305
    if-eqz v5, :cond_d

    .line 306
    .line 307
    invoke-virtual {v4, v3, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(ZZ)V

    .line 308
    .line 309
    .line 310
    goto/16 :goto_5

    .line 311
    .line 312
    :cond_d
    instance-of v5, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 313
    .line 314
    if-eqz v5, :cond_12

    .line 315
    .line 316
    invoke-virtual {v4, v1, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(ZZ)V

    .line 317
    .line 318
    .line 319
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 320
    .line 321
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 322
    .line 323
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 324
    .line 325
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 326
    .line 327
    .line 328
    move-result v1

    .line 329
    if-eqz v1, :cond_11

    .line 330
    .line 331
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 332
    .line 333
    if-nez p1, :cond_f

    .line 334
    .line 335
    iget-object p1, v2, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->p:Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;

    .line 336
    .line 337
    if-eqz p1, :cond_e

    .line 338
    .line 339
    iget-object v1, v2, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->o:Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;

    .line 340
    .line 341
    if-eqz v1, :cond_e

    .line 342
    .line 343
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 344
    .line 345
    .line 346
    move-result-object v1

    .line 347
    invoke-virtual {p1, v1, v0}, Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;->nextStep(Landroid/app/Activity;Ljava/lang/String;)V

    .line 348
    .line 349
    .line 350
    goto :goto_4

    .line 351
    :cond_e
    const-string p1, "/h5/help/service"

    .line 352
    .line 353
    invoke-static {p1}, LPa/i0;->b0(Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    :goto_4
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 357
    .line 358
    .line 359
    move-result-object p1

    .line 360
    if-eqz p1, :cond_14

    .line 361
    .line 362
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 363
    .line 364
    .line 365
    goto :goto_5

    .line 366
    :cond_f
    iget-object v0, v2, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->o:Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;

    .line 367
    .line 368
    if-eqz v0, :cond_10

    .line 369
    .line 370
    check-cast p1, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;

    .line 371
    .line 372
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 373
    .line 374
    .line 375
    move-result-object v0

    .line 376
    instance-of v0, v0, Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountHistoryActivity;

    .line 377
    .line 378
    if-eqz v0, :cond_14

    .line 379
    .line 380
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 381
    .line 382
    .line 383
    move-result-object v0

    .line 384
    const-string v1, "null cannot be cast to non-null type com.transsnet.palmpay.account.ui.activity.VerifyAccountHistoryActivity"

    .line 385
    .line 386
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 387
    .line 388
    .line 389
    check-cast v0, Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountHistoryActivity;

    .line 390
    .line 391
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountHistoryActivity;->m(Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;)V

    .line 392
    .line 393
    .line 394
    goto :goto_5

    .line 395
    :cond_10
    move-object v0, p1

    .line 396
    check-cast v0, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;

    .line 397
    .line 398
    iput-object v0, v2, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->o:Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;

    .line 399
    .line 400
    const-string v1, "data"

    .line 401
    .line 402
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 403
    .line 404
    .line 405
    invoke-virtual {v2, v0}, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->t(Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;)V

    .line 406
    .line 407
    .line 408
    goto :goto_5

    .line 409
    :cond_11
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 410
    .line 411
    .line 412
    move-result-object p1

    .line 413
    invoke-static {v2, p1}, Loa/h;->y(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 414
    .line 415
    .line 416
    goto :goto_5

    .line 417
    :cond_12
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 418
    .line 419
    if-eqz v0, :cond_13

    .line 420
    .line 421
    invoke-virtual {v4, v1, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(ZZ)V

    .line 422
    .line 423
    .line 424
    goto :goto_5

    .line 425
    :cond_13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 426
    .line 427
    if-eqz v0, :cond_15

    .line 428
    .line 429
    invoke-virtual {v4, v1, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(ZZ)V

    .line 430
    .line 431
    .line 432
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 433
    .line 434
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 435
    .line 436
    new-array v0, v1, [Ljava/lang/Object;

    .line 437
    .line 438
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 439
    .line 440
    .line 441
    :cond_14
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 442
    .line 443
    return-object p1

    .line 444
    :cond_15
    new-instance p1, Lxf/l;

    .line 445
    .line 446
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 447
    .line 448
    .line 449
    throw p1

    .line 450
    nop

    .line 451
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
