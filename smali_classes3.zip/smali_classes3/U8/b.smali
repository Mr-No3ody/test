.class public final synthetic LU8/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LU8/b;->a:I

    iput-object p1, p0, LU8/b;->b:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 7

    .line 1
    iget-object p1, p0, LU8/b;->b:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;

    .line 2
    .line 3
    iget v0, p0, LU8/b;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget-object v0, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->v:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment$a;

    .line 9
    .line 10
    new-instance v0, Lcom/transsnet/palmpay/account/bean/req/VerifyAccountHistoryReq;

    .line 11
    .line 12
    invoke-direct {v0}, Lcom/transsnet/palmpay/account/bean/req/VerifyAccountHistoryReq;-><init>()V

    .line 13
    .line 14
    .line 15
    iget-object v1, p1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->p:Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    iget-object v3, v1, Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;->flowId:Ljava/lang/String;

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    move-object v3, v2

    .line 24
    :goto_0
    iput-object v3, v0, Lcom/transsnet/palmpay/account/bean/req/VerifyAccountHistoryReq;->flowId:Ljava/lang/String;

    .line 25
    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    iget-object v1, v1, Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;->mobile:Ljava/lang/String;

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_1
    move-object v1, v2

    .line 32
    :goto_1
    iput-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/VerifyAccountHistoryReq;->mobileNo:Ljava/lang/String;

    .line 33
    .line 34
    iget-object v1, p1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->o:Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;

    .line 35
    .line 36
    if-eqz v1, :cond_2

    .line 37
    .line 38
    iget-object v1, v1, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;->questionId:Ljava/lang/String;

    .line 39
    .line 40
    goto :goto_2

    .line 41
    :cond_2
    move-object v1, v2

    .line 42
    :goto_2
    iput-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/VerifyAccountHistoryReq;->questionId:Ljava/lang/String;

    .line 43
    .line 44
    new-instance v1, Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 47
    .line 48
    .line 49
    iput-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/VerifyAccountHistoryReq;->answerIds:Ljava/util/List;

    .line 50
    .line 51
    iget-object v1, p1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->j:LU8/c;

    .line 52
    .line 53
    if-eqz v1, :cond_4

    .line 54
    .line 55
    invoke-virtual {v1}, LM1/j;->getData()Ljava/util/List;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    if-eqz v1, :cond_4

    .line 60
    .line 61
    check-cast v1, Ljava/lang/Iterable;

    .line 62
    .line 63
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    :cond_3
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    if-eqz v3, :cond_4

    .line 72
    .line 73
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    check-cast v3, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;

    .line 78
    .line 79
    iget-boolean v4, v3, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;->check:Z

    .line 80
    .line 81
    if-eqz v4, :cond_3

    .line 82
    .line 83
    iget-object v4, v0, Lcom/transsnet/palmpay/account/bean/req/VerifyAccountHistoryReq;->answerIds:Ljava/util/List;

    .line 84
    .line 85
    iget-wide v5, v3, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;->itemId:J

    .line 86
    .line 87
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    invoke-interface {v4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    goto :goto_3

    .line 95
    :cond_4
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 96
    .line 97
    check-cast p1, Lcom/transsnet/palmpay/account/ui/viewmodel/VerifyAccountHistoryViewModel;

    .line 98
    .line 99
    if-eqz p1, :cond_5

    .line 100
    .line 101
    const-string v1, "req"

    .line 102
    .line 103
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    new-instance v1, Lg9/Z;

    .line 107
    .line 108
    invoke-direct {v1, v0, v2}, Lg9/Z;-><init>(Lcom/transsnet/palmpay/account/bean/req/VerifyAccountHistoryReq;Lkotlin/coroutines/Continuation;)V

    .line 109
    .line 110
    .line 111
    iget-object v0, p1, Lcom/transsnet/palmpay/account/ui/viewmodel/VerifyAccountHistoryViewModel;->f:Lcom/transsnet/palmpay/core/base/l;

    .line 112
    .line 113
    const/16 v2, 0x1c

    .line 114
    .line 115
    const/4 v3, 0x0

    .line 116
    invoke-static {p1, v1, v0, v3, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 117
    .line 118
    .line 119
    :cond_5
    return-void

    .line 120
    :pswitch_0
    sget-object v0, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->v:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment$a;

    .line 121
    .line 122
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    if-eqz p1, :cond_6

    .line 127
    .line 128
    invoke-virtual {p1}, Landroidx/activity/m;->onBackPressed()V

    .line 129
    .line 130
    .line 131
    :cond_6
    return-void

    .line 132
    nop

    .line 133
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
