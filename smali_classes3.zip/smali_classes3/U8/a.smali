.class public final synthetic LU8/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;
.implements Lcom/chad/library/adapter/base/listener/OnItemChildClickListener;
.implements Lcom/google/android/gms/maps/GoogleMap$OnCameraMoveListener;
.implements Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;
.implements Lio/reactivex/ObservableOnSubscribe;
.implements Lcom/transsnet/palmpay/core/callback/Argument2Callback;
.implements Lcom/transsnet/palmpay/p2pcash/ui/atm/view/P2PButton$OnP2PButtonClickListener;
.implements Landroidx/camera/core/impl/ImageReaderProxy$OnImageAvailableListener;
.implements Landroidx/camera/core/SurfaceRequest$TransformationInfoListener;
.implements Landroidx/camera/core/impl/utils/futures/AsyncFunction;
.implements Landroidx/core/os/CancellationSignal$OnCancelListener;
.implements Lcom/transsnet/palmpay/core/callback/ResultCallback;
.implements Lcom/facebook/react/devsupport/interfaces/PackagerStatusCallback;
.implements Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout$OnRefreshListener;
.implements Lcom/google/android/datatransport/runtime/synchronization/SynchronizationGuard$CriticalSection;
.implements Lcom/google/android/gms/tasks/Continuation;
.implements Lcom/permissionx/guolindev/callback/RequestCallback;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LU8/a;->a:I

    iput-object p2, p0, LU8/a;->b:Ljava/lang/Object;

    iput-object p3, p0, LU8/a;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Landroidx/camera/core/CameraInfo;Landroidx/camera/view/i;Ljava/util/ArrayList;)V
    .locals 0

    .line 2
    const/16 p2, 0xf

    iput p2, p0, LU8/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LU8/a;->b:Ljava/lang/Object;

    iput-object p3, p0, LU8/a;->c:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/concurrent/Executor;Lkotlin/jvm/functions/Function0;)V
    .locals 1

    .line 3
    const/4 v0, 0x5

    iput v0, p0, LU8/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast p2, Lkotlin/jvm/internal/o;

    iput-object p2, p0, LU8/a;->c:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;)V
    .locals 1

    .line 4
    const/4 v0, 0x4

    iput v0, p0, LU8/a;->a:I

    sget-object v0, LWf/w;->a:LWf/w;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast p2, LFf/h;

    iput-object p2, p0, LU8/a;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Lcom/google/common/util/concurrent/ListenableFuture;
    .locals 5

    .line 1
    check-cast p1, Ljava/lang/Void;

    .line 2
    .line 3
    iget-object p1, p0, LU8/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p1, Landroidx/camera/core/streamsharing/k;

    .line 6
    .line 7
    iget-object v0, p0, LU8/a;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Ljava/util/List;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    check-cast v2, Landroidx/camera/core/impl/T;

    .line 17
    .line 18
    iget-object v2, v2, Landroidx/camera/core/impl/T;->b:Landroidx/camera/core/impl/q0;

    .line 19
    .line 20
    sget-object v3, Landroidx/camera/core/impl/T;->j:Landroidx/camera/core/impl/c;

    .line 21
    .line 22
    const/16 v4, 0x64

    .line 23
    .line 24
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    :try_start_0
    invoke-virtual {v2, v3}, Landroidx/camera/core/impl/q0;->retrieveOption(Landroidx/camera/core/impl/V;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v4
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    :catch_0
    check-cast v4, Ljava/lang/Integer;

    .line 33
    .line 34
    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    check-cast v0, Landroidx/camera/core/impl/T;

    .line 46
    .line 47
    iget-object v0, v0, Landroidx/camera/core/impl/T;->b:Landroidx/camera/core/impl/q0;

    .line 48
    .line 49
    sget-object v3, Landroidx/camera/core/impl/T;->i:Landroidx/camera/core/impl/c;

    .line 50
    .line 51
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    :try_start_1
    invoke-virtual {v0, v3}, Landroidx/camera/core/impl/q0;->retrieveOption(Landroidx/camera/core/impl/V;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v1
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    .line 59
    :catch_1
    check-cast v1, Ljava/lang/Integer;

    .line 60
    .line 61
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    iget-object p1, p1, Landroidx/camera/core/streamsharing/k;->c:Landroidx/camera/core/streamsharing/j;

    .line 69
    .line 70
    invoke-virtual {p1, v2, v0}, Landroidx/camera/core/streamsharing/j;->jpegSnapshot(II)Lcom/google/common/util/concurrent/ListenableFuture;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    return-object p1
.end method

.method public attachCompleter(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .locals 7

    .line 1
    const/16 v0, 0x16

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    iget v3, p0, LU8/a;->a:I

    .line 6
    .line 7
    sparse-switch v3, :sswitch_data_0

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Landroidx/camera/view/H;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    const-string v1, "TextureViewImpl"

    .line 18
    .line 19
    invoke-static {v1}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    iget-object v1, v0, Landroidx/camera/view/H;->h:LE/m0;

    .line 23
    .line 24
    invoke-static {}, Lorg/chromium/support_lib_boundary/util/b;->u()Landroidx/camera/core/impl/utils/executor/a;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    new-instance v4, Landroidx/camera/view/D;

    .line 32
    .line 33
    invoke-direct {v4, p1, v2}, Landroidx/camera/view/D;-><init>(Ljava/lang/Object;I)V

    .line 34
    .line 35
    .line 36
    iget-object p1, p0, LU8/a;->c:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, Landroid/view/Surface;

    .line 39
    .line 40
    invoke-virtual {v1, p1, v3, v4}, LE/m0;->b(Landroid/view/Surface;Ljava/util/concurrent/Executor;Landroidx/core/util/Consumer;)V

    .line 41
    .line 42
    .line 43
    new-instance v1, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    const-string v2, "provideSurface[request="

    .line 46
    .line 47
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    iget-object v0, v0, Landroidx/camera/view/H;->h:LE/m0;

    .line 51
    .line 52
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    const-string v0, " surface="

    .line 56
    .line 57
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string p1, "]"

    .line 64
    .line 65
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    return-object p1

    .line 73
    :sswitch_0
    new-instance v0, Landroidx/camera/camera2/internal/m;

    .line 74
    .line 75
    iget-object v1, p0, LU8/a;->b:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v1, Landroidx/camera/core/CameraInfo;

    .line 78
    .line 79
    invoke-direct {v0, p1, v1}, Landroidx/camera/camera2/internal/m;-><init>(Landroidx/concurrent/futures/k;Landroidx/camera/core/CameraInfo;)V

    .line 80
    .line 81
    .line 82
    iget-object p1, p0, LU8/a;->c:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast p1, Ljava/util/ArrayList;

    .line 85
    .line 86
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    check-cast v1, Landroidx/camera/core/impl/CameraInfoInternal;

    .line 90
    .line 91
    invoke-static {}, Lorg/chromium/support_lib_boundary/util/b;->u()Landroidx/camera/core/impl/utils/executor/a;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    invoke-interface {v1, p1, v0}, Landroidx/camera/core/impl/CameraInfoInternal;->addSessionCaptureCallback(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/q;)V

    .line 96
    .line 97
    .line 98
    const-string p1, "waitForCaptureResult"

    .line 99
    .line 100
    return-object p1

    .line 101
    :sswitch_1
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v0, Landroidx/camera/view/d;

    .line 104
    .line 105
    iget-object v1, v0, Landroidx/camera/view/d;->a:Ljava/lang/Object;

    .line 106
    .line 107
    check-cast v1, Le0/a;

    .line 108
    .line 109
    if-eqz v1, :cond_0

    .line 110
    .line 111
    iget-object v1, v1, Le0/a;->a:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v1, Landroidx/concurrent/futures/k;

    .line 114
    .line 115
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    invoke-virtual {v1}, Landroidx/concurrent/futures/k;->c()V

    .line 119
    .line 120
    .line 121
    :cond_0
    new-instance v1, Le0/a;

    .line 122
    .line 123
    iget-object v2, p0, LU8/a;->c:Ljava/lang/Object;

    .line 124
    .line 125
    invoke-direct {v1, p1, v2}, Le0/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    iput-object v1, v0, Landroidx/camera/view/d;->a:Ljava/lang/Object;

    .line 129
    .line 130
    new-instance p1, Ljava/lang/StringBuilder;

    .line 131
    .line 132
    const-string v0, "PendingValue "

    .line 133
    .line 134
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 138
    .line 139
    .line 140
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    return-object p1

    .line 145
    :sswitch_2
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    .line 146
    .line 147
    check-cast v0, Landroidx/camera/video/C;

    .line 148
    .line 149
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 150
    .line 151
    .line 152
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    iget-object v2, p0, LU8/a;->c:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast v2, Landroidx/camera/core/impl/C0;

    .line 163
    .line 164
    iget-object v3, v2, Landroidx/camera/core/impl/B0;->b:Landroidx/camera/core/impl/S;

    .line 165
    .line 166
    iget-object v3, v3, Landroidx/camera/core/impl/S;->g:Landroidx/camera/core/impl/o0;

    .line 167
    .line 168
    iget-object v3, v3, Landroidx/camera/core/impl/O0;->a:Landroid/util/ArrayMap;

    .line 169
    .line 170
    const-string v4, "androidx.camera.video.VideoCapture.streamUpdate"

    .line 171
    .line 172
    invoke-virtual {v3, v4, v0}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 176
    .line 177
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 178
    .line 179
    .line 180
    new-instance v1, Landroidx/camera/video/x;

    .line 181
    .line 182
    invoke-direct {v1, v0, p1, v2}, Landroidx/camera/video/x;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Landroidx/concurrent/futures/k;Landroidx/camera/core/impl/C0;)V

    .line 183
    .line 184
    .line 185
    new-instance v3, LDa/h;

    .line 186
    .line 187
    const/16 v5, 0x19

    .line 188
    .line 189
    invoke-direct {v3, v0, v5, v2, v1}, LDa/h;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    invoke-static {}, Lorg/chromium/support_lib_boundary/util/b;->u()Landroidx/camera/core/impl/utils/executor/a;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    invoke-virtual {p1, v3, v0}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 197
    .line 198
    .line 199
    iget-object v0, v2, Landroidx/camera/core/impl/B0;->b:Landroidx/camera/core/impl/S;

    .line 200
    .line 201
    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/S;->b(Landroidx/camera/core/impl/q;)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 205
    .line 206
    .line 207
    move-result p1

    .line 208
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 209
    .line 210
    .line 211
    move-result-object p1

    .line 212
    filled-new-array {v4, p1}, [Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object p1

    .line 216
    const-string v0, "%s[0x%x]"

    .line 217
    .line 218
    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object p1

    .line 222
    return-object p1

    .line 223
    :sswitch_3
    iget-object v2, p0, LU8/a;->b:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v2, Landroidx/camera/lifecycle/h;

    .line 226
    .line 227
    iget-object v3, p0, LU8/a;->c:Ljava/lang/Object;

    .line 228
    .line 229
    check-cast v3, Landroidx/camera/core/c;

    .line 230
    .line 231
    const-string v4, "this$0"

    .line 232
    .line 233
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    const-string v4, "$cameraX"

    .line 237
    .line 238
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 239
    .line 240
    .line 241
    const-string v4, "completer"

    .line 242
    .line 243
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    iget-object v4, v2, Landroidx/camera/lifecycle/h;->a:Ljava/lang/Object;

    .line 247
    .line 248
    monitor-enter v4

    .line 249
    :try_start_0
    iget-object v2, v2, Landroidx/camera/lifecycle/h;->d:Lcom/google/common/util/concurrent/ListenableFuture;

    .line 250
    .line 251
    invoke-static {v2}, Landroidx/camera/core/impl/utils/futures/b;->a(Lcom/google/common/util/concurrent/ListenableFuture;)Landroidx/camera/core/impl/utils/futures/b;

    .line 252
    .line 253
    .line 254
    move-result-object v2

    .line 255
    new-instance v5, LC0/J;

    .line 256
    .line 257
    const/4 v6, 0x4

    .line 258
    invoke-direct {v5, v3, v6}, LC0/J;-><init>(Ljava/lang/Object;I)V

    .line 259
    .line 260
    .line 261
    new-instance v6, Landroidx/camera/lifecycle/c;

    .line 262
    .line 263
    invoke-direct {v6, v5}, Landroidx/camera/lifecycle/c;-><init>(LC0/J;)V

    .line 264
    .line 265
    .line 266
    invoke-static {}, Lorg/chromium/support_lib_boundary/util/b;->u()Landroidx/camera/core/impl/utils/executor/a;

    .line 267
    .line 268
    .line 269
    move-result-object v5

    .line 270
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 271
    .line 272
    .line 273
    invoke-static {v2, v6, v5}, Landroidx/camera/core/impl/utils/futures/j;->i(Lcom/google/common/util/concurrent/ListenableFuture;Landroidx/camera/core/impl/utils/futures/AsyncFunction;Ljava/util/concurrent/Executor;)Landroidx/camera/core/impl/utils/futures/a;

    .line 274
    .line 275
    .line 276
    move-result-object v2

    .line 277
    const-string v5, "cameraX = CameraX(contex\u2026                        )"

    .line 278
    .line 279
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 280
    .line 281
    .line 282
    new-instance v5, Ls5/d;

    .line 283
    .line 284
    invoke-direct {v5, v0, p1, v3}, Ls5/d;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 285
    .line 286
    .line 287
    invoke-static {}, Lorg/chromium/support_lib_boundary/util/b;->u()Landroidx/camera/core/impl/utils/executor/a;

    .line 288
    .line 289
    .line 290
    move-result-object p1

    .line 291
    new-instance v0, Landroidx/camera/core/impl/utils/futures/i;

    .line 292
    .line 293
    invoke-direct {v0, v1, v2, v5}, Landroidx/camera/core/impl/utils/futures/i;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 294
    .line 295
    .line 296
    invoke-virtual {v2, v0, p1}, Landroidx/camera/core/impl/utils/futures/b;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 297
    .line 298
    .line 299
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 300
    .line 301
    monitor-exit v4

    .line 302
    const-string p1, "ProcessCameraProvider-initializeCameraX"

    .line 303
    .line 304
    return-object p1

    .line 305
    :catchall_0
    move-exception p1

    .line 306
    monitor-exit v4

    .line 307
    throw p1

    .line 308
    :sswitch_4
    const-string v0, "it"

    .line 309
    .line 310
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 314
    .line 315
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 316
    .line 317
    .line 318
    new-instance v1, LV0/u;

    .line 319
    .line 320
    invoke-direct {v1, v0, v2}, LV0/u;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;I)V

    .line 321
    .line 322
    .line 323
    sget-object v2, LV0/q;->a:LV0/q;

    .line 324
    .line 325
    invoke-virtual {p1, v1, v2}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 326
    .line 327
    .line 328
    new-instance v1, LDa/h;

    .line 329
    .line 330
    iget-object v2, p0, LU8/a;->c:Ljava/lang/Object;

    .line 331
    .line 332
    check-cast v2, Lkotlin/jvm/internal/o;

    .line 333
    .line 334
    invoke-direct {v1, v0, p1, v2}, LDa/h;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Landroidx/concurrent/futures/k;Lkotlin/jvm/functions/Function0;)V

    .line 335
    .line 336
    .line 337
    iget-object p1, p0, LU8/a;->b:Ljava/lang/Object;

    .line 338
    .line 339
    check-cast p1, Ljava/util/concurrent/Executor;

    .line 340
    .line 341
    invoke-interface {p1, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 342
    .line 343
    .line 344
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 345
    .line 346
    return-object p1

    .line 347
    :sswitch_5
    const-string v1, "completer"

    .line 348
    .line 349
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 350
    .line 351
    .line 352
    sget-object v1, LWf/a0;->a:LWf/a0;

    .line 353
    .line 354
    iget-object v3, p0, LU8/a;->b:Ljava/lang/Object;

    .line 355
    .line 356
    check-cast v3, Lkotlin/coroutines/CoroutineContext;

    .line 357
    .line 358
    invoke-interface {v3, v1}, Lkotlin/coroutines/CoroutineContext;->get(Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext$Element;

    .line 359
    .line 360
    .line 361
    move-result-object v1

    .line 362
    check-cast v1, Lkotlinx/coroutines/Job;

    .line 363
    .line 364
    new-instance v4, LM7/s;

    .line 365
    .line 366
    invoke-direct {v4, v1, v0}, LM7/s;-><init>(Ljava/lang/Object;I)V

    .line 367
    .line 368
    .line 369
    sget-object v0, LV0/q;->a:LV0/q;

    .line 370
    .line 371
    invoke-virtual {p1, v4, v0}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 372
    .line 373
    .line 374
    invoke-static {v3}, LWf/v;->a(Lkotlin/coroutines/CoroutineContext;)Lag/c;

    .line 375
    .line 376
    .line 377
    move-result-object v0

    .line 378
    new-instance v1, LV0/v;

    .line 379
    .line 380
    iget-object v3, p0, LU8/a;->c:Ljava/lang/Object;

    .line 381
    .line 382
    check-cast v3, LFf/h;

    .line 383
    .line 384
    const/4 v4, 0x0

    .line 385
    invoke-direct {v1, v3, p1, v4}, LV0/v;-><init>(Lkotlin/jvm/functions/Function2;Landroidx/concurrent/futures/k;Lkotlin/coroutines/Continuation;)V

    .line 386
    .line 387
    .line 388
    sget-object p1, LWf/w;->a:LWf/w;

    .line 389
    .line 390
    invoke-static {v0, v4, p1, v1, v2}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 391
    .line 392
    .line 393
    move-result-object p1

    .line 394
    return-object p1

    .line 395
    :sswitch_data_0
    .sparse-switch
        0x4 -> :sswitch_5
        0x5 -> :sswitch_4
        0xc -> :sswitch_3
        0xd -> :sswitch_2
        0xe -> :sswitch_1
        0xf -> :sswitch_0
    .end sparse-switch
.end method

.method public execute()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LU8/a;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/Uploader;

    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-static {v0, v1}, Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/Uploader;->h(Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/Uploader;Ljava/util/HashMap;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/Uploader;

    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v0, v1}, Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/Uploader;->e(Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/Uploader;Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x18
        :pswitch_0
    .end packed-switch
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Ljava/lang/String;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Boolean;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    sget v0, Lcom/transsnet/palmpay/account/ui/fragment/login/LogInWithSmsFragment;->C:I

    .line 10
    .line 11
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lcom/transsnet/palmpay/account/ui/fragment/login/LogInWithSmsFragment;

    .line 18
    .line 19
    if-eqz p1, :cond_2

    .line 20
    .line 21
    if-eqz p2, :cond_0

    .line 22
    .line 23
    iget-boolean p1, v0, Lcom/transsnet/palmpay/account/ui/fragment/login/LogInWithSmsFragment;->o:Z

    .line 24
    .line 25
    if-nez p1, :cond_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    iget-object p1, v0, Lcom/transsnet/palmpay/account/ui/fragment/login/LogInWithSmsFragment;->t:LC0/w;

    .line 29
    .line 30
    if-eqz p1, :cond_1

    .line 31
    .line 32
    sget p2, LF8/d;->fragment_login_input_mobile:I

    .line 33
    .line 34
    const/4 v0, 0x0

    .line 35
    invoke-virtual {p1, p2, v0}, LC0/w;->k(IZ)Z

    .line 36
    .line 37
    .line 38
    :cond_1
    return-void

    .line 39
    :cond_2
    :goto_0
    iget-object p1, p0, LU8/a;->c:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast p1, LC0/U;

    .line 42
    .line 43
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/account/ui/fragment/login/LogInWithSmsFragment;->x(LC0/U;)V

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public onCameraMove()V
    .locals 7

    .line 1
    sget v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/MapPage;->u0:I

    .line 2
    .line 3
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/google/android/gms/maps/GoogleMap;

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getCameraPosition()Lcom/google/android/gms/maps/model/CameraPosition;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget-object v0, v0, Lcom/google/android/gms/maps/model/CameraPosition;->target:Lcom/google/android/gms/maps/model/LatLng;

    .line 12
    .line 13
    const-string v1, "target"

    .line 14
    .line 15
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-wide v1, v0, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 19
    .line 20
    iget-wide v3, v0, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 21
    .line 22
    new-instance v5, Ljava/lang/StringBuilder;

    .line 23
    .line 24
    const-string v6, "position:"

    .line 25
    .line 26
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v5, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    const-string v1, ","

    .line 33
    .line 34
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v5, v3, v4}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const/4 v2, 0x0

    .line 45
    new-array v2, v2, [Ljava/lang/Object;

    .line 46
    .line 47
    const/4 v3, 0x4

    .line 48
    invoke-static {v1, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v1, Lcom/transsnet/palmpay/p2pcash/ui/atm/MapPage;

    .line 54
    .line 55
    invoke-virtual {v1}, Lcom/transsnet/palmpay/p2pcash/ui/atm/MapPage;->s()LUc/Y;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    iget v3, v2, LUc/Y;->b:I

    .line 60
    .line 61
    add-int/lit8 v3, v3, 0x1

    .line 62
    .line 63
    iput v3, v2, LUc/Y;->b:I

    .line 64
    .line 65
    invoke-virtual {v1}, Lcom/transsnet/palmpay/p2pcash/ui/atm/MapPage;->s()LUc/Y;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    iget v2, v2, LUc/Y;->b:I

    .line 70
    .line 71
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    new-instance v4, LH0/a;

    .line 80
    .line 81
    const/4 v5, 0x2

    .line 82
    invoke-direct {v4, v2, v1, v0, v5}, LH0/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;I)V

    .line 83
    .line 84
    .line 85
    const-wide/16 v0, 0x12c

    .line 86
    .line 87
    invoke-virtual {v3, v4, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 88
    .line 89
    .line 90
    return-void
.end method

.method public onCancel()V
    .locals 1

    .line 1
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/transition/Transition;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/transition/Transition;->cancel()V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LU8/a;->c:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Landroidx/fragment/app/v0;

    .line 11
    .line 12
    invoke-virtual {v0}, Landroidx/fragment/app/v0;->run()V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public onClick()V
    .locals 2

    .line 1
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/PayByNoticeDialog;

    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v1, Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/PayByNoticeDialog$Listener;

    invoke-static {v0, v1}, Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/PayByNoticeDialog;->a(Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/PayByNoticeDialog;Lcom/transsnet/palmpay/p2pcash/ui/atm/dialog/PayByNoticeDialog$Listener;)V

    return-void
.end method

.method public onComplete(Ljava/lang/Object;)V
    .locals 12

    .line 1
    iget-object v0, p0, LU8/a;->c:Ljava/lang/Object;

    .line 2
    .line 3
    const-string v1, "couponCode"

    .line 4
    .line 5
    const-string v2, ""

    .line 6
    .line 7
    const-string v3, "Use"

    .line 8
    .line 9
    const-string v4, "element_details"

    .line 10
    .line 11
    const-string v5, "transType"

    .line 12
    .line 13
    const-string v6, "Dialog_ModelActivityBannerWithCouponUse"

    .line 14
    .line 15
    iget-object v7, p0, LU8/a;->b:Ljava/lang/Object;

    .line 16
    .line 17
    const/4 v8, 0x0

    .line 18
    iget v9, p0, LU8/a;->a:I

    .line 19
    .line 20
    check-cast p1, Ljava/util/List;

    .line 21
    .line 22
    packed-switch v9, :pswitch_data_0

    .line 23
    .line 24
    .line 25
    sget v9, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;->i:I

    .line 26
    .line 27
    if-eqz p1, :cond_0

    .line 28
    .line 29
    invoke-interface {p1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    const/4 p1, 0x0

    .line 37
    :goto_0
    check-cast v7, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;

    .line 38
    .line 39
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 43
    .line 44
    .line 45
    move-result-object v8

    .line 46
    new-instance v9, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 47
    .line 48
    invoke-direct {v9, v6}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    iget-object v6, v7, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;->e:Ljava/lang/String;

    .line 52
    .line 53
    invoke-virtual {v9, v5, v6}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 54
    .line 55
    .line 56
    move-result-object v5

    .line 57
    check-cast v5, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 58
    .line 59
    invoke-virtual {v5, v4, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    check-cast v3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 64
    .line 65
    if-eqz p1, :cond_2

    .line 66
    .line 67
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getCouponCode()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-nez p1, :cond_1

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_1
    move-object v2, p1

    .line 75
    :cond_2
    :goto_1
    invoke-virtual {v3, v1, v2}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    check-cast p1, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 80
    .line 81
    invoke-virtual {v8, p1}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 82
    .line 83
    .line 84
    check-cast v0, Lcom/transsnet/palmpay/teller/ui/dialog/CouponClaimResultDialog;

    .line 85
    .line 86
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 87
    .line 88
    .line 89
    iget-object p1, v7, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;->d:Lcom/transsnet/palmpay/teller/ui/dialog/BillerCouponListDialog;

    .line 90
    .line 91
    if-eqz p1, :cond_3

    .line 92
    .line 93
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 94
    .line 95
    .line 96
    :cond_3
    return-void

    .line 97
    :pswitch_0
    invoke-interface {p1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;

    .line 102
    .line 103
    check-cast v7, Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;

    .line 104
    .line 105
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;->getMListener()Lcom/transsnet/palmpay/teller/ui/view/BillerCouponClickListener;

    .line 106
    .line 107
    .line 108
    move-result-object v8

    .line 109
    if-eqz v8, :cond_5

    .line 110
    .line 111
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getInstitutionIdList()Ljava/util/List;

    .line 112
    .line 113
    .line 114
    move-result-object v9

    .line 115
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;->getLimitAmt()Ljava/lang/Long;

    .line 116
    .line 117
    .line 118
    move-result-object v10

    .line 119
    if-eqz v10, :cond_4

    .line 120
    .line 121
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 122
    .line 123
    .line 124
    move-result-wide v10

    .line 125
    goto :goto_2

    .line 126
    :cond_4
    const-wide/16 v10, 0x0

    .line 127
    .line 128
    :goto_2
    invoke-interface {v8, v9, v10, v11}, Lcom/transsnet/palmpay/teller/ui/view/BillerCouponClickListener;->onCouponUseClick(Ljava/util/List;J)V

    .line 129
    .line 130
    .line 131
    :cond_5
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 132
    .line 133
    .line 134
    move-result-object v8

    .line 135
    new-instance v9, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 136
    .line 137
    invoke-direct {v9, v6}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    iget-object v6, v7, Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;->g:Ljava/lang/String;

    .line 141
    .line 142
    invoke-virtual {v9, v5, v6}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 143
    .line 144
    .line 145
    move-result-object v5

    .line 146
    check-cast v5, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 147
    .line 148
    invoke-virtual {v5, v4, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    check-cast v3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 153
    .line 154
    if-eqz p1, :cond_7

    .line 155
    .line 156
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getCouponCode()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    if-nez p1, :cond_6

    .line 161
    .line 162
    goto :goto_3

    .line 163
    :cond_6
    move-object v2, p1

    .line 164
    :cond_7
    :goto_3
    invoke-virtual {v3, v1, v2}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    check-cast p1, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 169
    .line 170
    invoke-virtual {v8, p1}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 171
    .line 172
    .line 173
    check-cast v0, Lcom/transsnet/palmpay/teller/ui/dialog/CouponClaimResultDialog;

    .line 174
    .line 175
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 176
    .line 177
    .line 178
    return-void

    .line 179
    :pswitch_data_0
    .packed-switch 0x13
        :pswitch_0
    .end packed-switch
.end method

.method public onImageAvailable(Landroidx/camera/core/impl/ImageReaderProxy;)V
    .locals 1

    .line 1
    iget-object p1, p0, LU8/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, Landroidx/camera/core/imagecapture/o;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LU8/a;->c:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Landroidx/camera/core/impl/ImageReaderProxy$OnImageAvailableListener;

    .line 11
    .line 12
    invoke-interface {v0, p1}, Landroidx/camera/core/impl/ImageReaderProxy$OnImageAvailableListener;->onImageAvailable(Landroidx/camera/core/impl/ImageReaderProxy;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public onItemChildClick(LM1/j;Landroid/view/View;I)V
    .locals 11

    .line 1
    sget v0, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->t:I

    .line 2
    .line 3
    const-string v0, "<unused var>"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, LU8/a;->b:Ljava/lang/Object;

    .line 12
    .line 13
    move-object v4, p1

    .line 14
    check-cast v4, LUa/A0;

    .line 15
    .line 16
    invoke-virtual {v4, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    move-object v2, p1

    .line 21
    check-cast v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 22
    .line 23
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    iget-object p2, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardType:Ljava/lang/Integer;

    .line 28
    .line 29
    new-instance v5, Lkotlin/Pair;

    .line 30
    .line 31
    const-string p3, "rewardType"

    .line 32
    .line 33
    invoke-direct {v5, p3, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    iget-object p2, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->activityNodeNo:Ljava/lang/String;

    .line 37
    .line 38
    new-instance v6, Lkotlin/Pair;

    .line 39
    .line 40
    const-string p3, "activityNodeNo"

    .line 41
    .line 42
    invoke-direct {v6, p3, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object p2, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->recordNo:Ljava/lang/String;

    .line 46
    .line 47
    new-instance v7, Lkotlin/Pair;

    .line 48
    .line 49
    const-string p3, "rewardid"

    .line 50
    .line 51
    invoke-direct {v7, p3, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    iget-object p2, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->transType:Ljava/lang/String;

    .line 55
    .line 56
    new-instance v8, Lkotlin/Pair;

    .line 57
    .line 58
    const-string p3, "transtype"

    .line 59
    .line 60
    invoke-direct {v8, p3, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    invoke-static {}, LC0/G;->k()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p2

    .line 67
    new-instance v9, Lkotlin/Pair;

    .line 68
    .line 69
    const-string p3, "memberid"

    .line 70
    .line 71
    invoke-direct {v9, p3, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    iget-object p2, p0, LU8/a;->c:Ljava/lang/Object;

    .line 75
    .line 76
    move-object v3, p2

    .line 77
    check-cast v3, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 78
    .line 79
    iget-object p2, v3, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->j:Ljava/lang/String;

    .line 80
    .line 81
    new-instance v10, Lkotlin/Pair;

    .line 82
    .line 83
    const-string p3, "orderid"

    .line 84
    .line 85
    invoke-direct {v10, p3, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    filled-new-array/range {v5 .. v10}, [Lkotlin/Pair;

    .line 89
    .line 90
    .line 91
    move-result-object p2

    .line 92
    invoke-static {p2}, Lkotlin/collections/G;->g([Lkotlin/Pair;)Ljava/util/Map;

    .line 93
    .line 94
    .line 95
    move-result-object p2

    .line 96
    const-string p3, "ResultPage_Reward_Click"

    .line 97
    .line 98
    invoke-virtual {p1, p3, p2}, LPa/n0;->n(Ljava/lang/String;Ljava/util/Map;)V

    .line 99
    .line 100
    .line 101
    iget-object p1, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardType:Ljava/lang/Integer;

    .line 102
    .line 103
    const/4 p2, 0x1

    .line 104
    if-nez p1, :cond_0

    .line 105
    .line 106
    goto :goto_0

    .line 107
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 108
    .line 109
    .line 110
    move-result p1

    .line 111
    if-eq p1, p2, :cond_3

    .line 112
    .line 113
    :goto_0
    iget-object p1, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardType:Ljava/lang/Integer;

    .line 114
    .line 115
    if-nez p1, :cond_1

    .line 116
    .line 117
    goto :goto_1

    .line 118
    :cond_1
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 119
    .line 120
    .line 121
    move-result p1

    .line 122
    const/4 p3, 0x3

    .line 123
    if-ne p1, p3, :cond_2

    .line 124
    .line 125
    goto :goto_2

    .line 126
    :cond_2
    :goto_1
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    iget-object p2, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->jumpPath:Ljava/lang/String;

    .line 131
    .line 132
    invoke-static {p1, p2}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 137
    .line 138
    .line 139
    return-void

    .line 140
    :cond_3
    :goto_2
    iget-object p1, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardStatus:Ljava/lang/Integer;

    .line 141
    .line 142
    if-nez p1, :cond_4

    .line 143
    .line 144
    goto :goto_3

    .line 145
    :cond_4
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 146
    .line 147
    .line 148
    move-result p1

    .line 149
    if-ne p1, p2, :cond_5

    .line 150
    .line 151
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    iget-object p2, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->jumpPath:Ljava/lang/String;

    .line 156
    .line 157
    invoke-static {p1, p2}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 162
    .line 163
    .line 164
    return-void

    .line 165
    :cond_5
    :goto_3
    iget-object p1, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->recordNo:Ljava/lang/String;

    .line 166
    .line 167
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 168
    .line 169
    .line 170
    move-result p1

    .line 171
    if-nez p1, :cond_7

    .line 172
    .line 173
    iget-object p1, v3, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->p:Lcom/transsnet/palmpay/core/viewmodel/OnClaimRewardListener;

    .line 174
    .line 175
    if-eqz p1, :cond_6

    .line 176
    .line 177
    invoke-interface {p1, p2}, Lcom/transsnet/palmpay/core/viewmodel/OnClaimRewardListener;->onShowLoading(Z)V

    .line 178
    .line 179
    .line 180
    :cond_6
    invoke-static {v3}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    sget-object p2, LWf/I;->a:Lcg/f;

    .line 185
    .line 186
    sget-object p2, Lcg/e;->c:Lcg/e;

    .line 187
    .line 188
    new-instance v0, LUa/u0;

    .line 189
    .line 190
    const/4 v1, 0x0

    .line 191
    move-object v5, v2

    .line 192
    invoke-direct/range {v0 .. v5}, LUa/u0;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;LUa/A0;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;)V

    .line 193
    .line 194
    .line 195
    const/4 p3, 0x2

    .line 196
    invoke-static {p1, p2, v1, v0, p3}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 197
    .line 198
    .line 199
    move-result-object p1

    .line 200
    invoke-virtual {v3, p1}, Lcom/transsnet/palmpay/custom_view/model/BaseLinearLayout;->addJob(Lkotlinx/coroutines/Job;)V

    .line 201
    .line 202
    .line 203
    :cond_7
    return-void
.end method

.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    .line 3
    .line 4
    iget-object v2, p0, LU8/a;->b:Ljava/lang/Object;

    .line 5
    .line 6
    iget v3, p0, LU8/a;->a:I

    .line 7
    .line 8
    sparse-switch v3, :sswitch_data_0

    .line 9
    .line 10
    .line 11
    check-cast v2, Lcom/transsnet/palmpay/teller/ui/view/ModelBillerMoreService;

    .line 12
    .line 13
    check-cast v1, Landroid/content/Context;

    .line 14
    .line 15
    invoke-static {v2, v1, p1, p2, p3}, Lcom/transsnet/palmpay/teller/ui/view/ModelBillerMoreService;->a(Lcom/transsnet/palmpay/teller/ui/view/ModelBillerMoreService;Landroid/content/Context;LM1/j;Landroid/view/View;I)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :sswitch_0
    check-cast v2, Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;

    .line 20
    .line 21
    check-cast v1, Landroid/content/Context;

    .line 22
    .line 23
    invoke-static {v2, v1, p1, p2, p3}, Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;->c(Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;Landroid/content/Context;LM1/j;Landroid/view/View;I)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :sswitch_1
    check-cast v2, Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;

    .line 28
    .line 29
    check-cast v1, Landroid/content/Context;

    .line 30
    .line 31
    invoke-static {v2, v1, p1, p2, p3}, Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;->a(Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;Landroid/content/Context;LM1/j;Landroid/view/View;I)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :sswitch_2
    sget-object v3, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->v:Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment$a;

    .line 36
    .line 37
    const-string v3, "<unused var>"

    .line 38
    .line 39
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-static {p2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    check-cast v2, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;

    .line 46
    .line 47
    iget-boolean p1, v2, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp;->multiSelect:Z

    .line 48
    .line 49
    check-cast v1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;

    .line 50
    .line 51
    const/4 p2, 0x0

    .line 52
    if-eqz p1, :cond_1

    .line 53
    .line 54
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    :try_start_0
    iget-object p1, v1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->j:LU8/c;

    .line 58
    .line 59
    if-eqz p1, :cond_0

    .line 60
    .line 61
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    if-eqz p1, :cond_0

    .line 66
    .line 67
    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    check-cast p1, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;

    .line 72
    .line 73
    if-eqz p1, :cond_0

    .line 74
    .line 75
    iget-boolean p2, p1, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;->check:Z

    .line 76
    .line 77
    :cond_0
    iget-object p1, v1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->j:LU8/c;

    .line 78
    .line 79
    if-eqz p1, :cond_3

    .line 80
    .line 81
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    if-eqz p1, :cond_3

    .line 86
    .line 87
    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    check-cast p1, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;

    .line 92
    .line 93
    if-eqz p1, :cond_3

    .line 94
    .line 95
    xor-int/2addr p2, v0

    .line 96
    iput-boolean p2, p1, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;->check:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 97
    .line 98
    goto :goto_2

    .line 99
    :cond_1
    iget-object p1, v1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->j:LU8/c;

    .line 100
    .line 101
    if-eqz p1, :cond_3

    .line 102
    .line 103
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    if-eqz p1, :cond_3

    .line 108
    .line 109
    check-cast p1, Ljava/lang/Iterable;

    .line 110
    .line 111
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    move v2, p2

    .line 116
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 117
    .line 118
    .line 119
    move-result v3

    .line 120
    if-eqz v3, :cond_3

    .line 121
    .line 122
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    check-cast v3, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;

    .line 127
    .line 128
    if-ne v2, p3, :cond_2

    .line 129
    .line 130
    move v4, v0

    .line 131
    goto :goto_1

    .line 132
    :cond_2
    move v4, p2

    .line 133
    :goto_1
    iput-boolean v4, v3, Lcom/transsnet/palmpay/account/bean/AccountHistoryListRsp$ItemListBean;->check:Z

    .line 134
    .line 135
    add-int/2addr v2, v0

    .line 136
    goto :goto_0

    .line 137
    :catch_0
    :cond_3
    :goto_2
    iget-object p1, v1, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->j:LU8/c;

    .line 138
    .line 139
    if-eqz p1, :cond_4

    .line 140
    .line 141
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 142
    .line 143
    .line 144
    :cond_4
    invoke-virtual {v1}, Lcom/transsnet/palmpay/account/ui/fragment/history/VerifyAccountHistoryFragment;->u()V

    .line 145
    .line 146
    .line 147
    return-void

    .line 148
    nop

    .line 149
    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_2
        0x1 -> :sswitch_1
        0x12 -> :sswitch_0
    .end sparse-switch
.end method

.method public onPackagerStatusFetched(Z)V
    .locals 2

    .line 1
    iget-object v0, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/runtime/internal/bolts/TaskCompletionSource;

    iget-object v1, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/runtime/ReactHostImpl;

    invoke-static {v1, v0, p1}, Lcom/facebook/react/runtime/ReactHostImpl;->Q(Lcom/facebook/react/runtime/ReactHostImpl;Lcom/facebook/react/runtime/internal/bolts/TaskCompletionSource;Z)V

    return-void
.end method

.method public onRefresh()V
    .locals 2

    .line 1
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/uimanager/ThemedReactContext;

    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/views/swiperefresh/ReactSwipeRefreshLayout;

    invoke-static {v0, v1}, Lcom/facebook/react/views/swiperefresh/SwipeRefreshLayoutManager;->a(Lcom/facebook/react/uimanager/ThemedReactContext;Lcom/facebook/react/views/swiperefresh/ReactSwipeRefreshLayout;)V

    return-void
.end method

.method public onResult(ZLjava/util/List;Ljava/util/List;)V
    .locals 2

    .line 1
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/palmpay/lib/bridgewrapper/location/LocationBridge;

    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v1, Landroidx/appcompat/app/o;

    invoke-static {v0, v1, p1, p2, p3}, Lcom/palmpay/lib/bridgewrapper/location/LocationBridge;->c(Lcom/palmpay/lib/bridgewrapper/location/LocationBridge;Landroidx/appcompat/app/o;ZLjava/util/List;Ljava/util/List;)V

    return-void
.end method

.method public onTransformationInfoUpdate(LE/l0;)V
    .locals 3

    .line 1
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/camera/core/processing/f;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    sget-object v1, LH/g;->b:LH/g;

    .line 9
    .line 10
    iget-object v2, p0, LU8/a;->c:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v2, LE/m0;

    .line 13
    .line 14
    iget-object v2, v2, LE/m0;->c:LE/v;

    .line 15
    .line 16
    invoke-virtual {v2}, LE/v;->a()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_0

    .line 21
    .line 22
    check-cast p1, LE/j;

    .line 23
    .line 24
    iget-boolean p1, p1, LE/j;->d:Z

    .line 25
    .line 26
    if-eqz p1, :cond_0

    .line 27
    .line 28
    sget-object v1, LH/g;->c:LH/g;

    .line 29
    .line 30
    :cond_0
    iget-object p1, v0, Landroidx/camera/core/processing/f;->a:Landroidx/camera/core/processing/h;

    .line 31
    .line 32
    iget-object v0, p1, Landroidx/camera/core/processing/h;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 33
    .line 34
    const/4 v2, 0x1

    .line 35
    invoke-static {v0, v2}, LH/j;->d(Ljava/util/concurrent/atomic/AtomicBoolean;Z)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p1, Landroidx/camera/core/processing/h;->c:Ljava/lang/Thread;

    .line 39
    .line 40
    invoke-static {v0}, LH/j;->c(Ljava/lang/Thread;)V

    .line 41
    .line 42
    .line 43
    iget-object v0, p1, Landroidx/camera/core/processing/h;->l:LH/g;

    .line 44
    .line 45
    if-eq v0, v1, :cond_1

    .line 46
    .line 47
    iput-object v1, p1, Landroidx/camera/core/processing/h;->l:LH/g;

    .line 48
    .line 49
    iget v0, p1, Landroidx/camera/core/processing/h;->m:I

    .line 50
    .line 51
    invoke-virtual {p1, v0}, Landroidx/camera/core/processing/h;->k(I)V

    .line 52
    .line 53
    .line 54
    :cond_1
    return-void
.end method

.method public subscribe(Lio/reactivex/ObservableEmitter;)V
    .locals 10

    .line 1
    sget v0, Lcom/transsnet/palmpay/contacts/ui/activity/FindInviteFriendsActivity;->i:I

    .line 2
    .line 3
    const-string v0, "emitter"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    new-instance v0, Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, LU8/a;->b:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Lcom/transsnet/palmpay/contacts/ui/activity/FindInviteFriendsActivity;

    .line 16
    .line 17
    iget-object v1, v1, Lcom/transsnet/palmpay/contacts/ui/activity/FindInviteFriendsActivity;->e:Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v2, "iterator(...)"

    .line 24
    .line 25
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_6

    .line 33
    .line 34
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    const-string v3, "next(...)"

    .line 39
    .line 40
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    check-cast v2, Lcom/transsnet/palmpay/contacts/bean/resp/QueryPhonesData;

    .line 44
    .line 45
    invoke-virtual {v2}, Lcom/transsnet/palmpay/contacts/bean/resp/QueryPhonesData;->getPhone()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    const-string v4, ""

    .line 50
    .line 51
    const-string v5, "toUpperCase(...)"

    .line 52
    .line 53
    const-string v6, "getDefault(...)"

    .line 54
    .line 55
    if-eqz v3, :cond_1

    .line 56
    .line 57
    invoke-static {v6, v3, v5}, Lcom/airbnb/lottie/model/layer/d;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    if-nez v3, :cond_2

    .line 62
    .line 63
    :cond_1
    move-object v3, v4

    .line 64
    :cond_2
    invoke-virtual {v2}, Lcom/transsnet/palmpay/contacts/bean/resp/QueryPhonesData;->getPhone()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v7

    .line 68
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 69
    .line 70
    .line 71
    move-result v7

    .line 72
    iget-object v8, p0, LU8/a;->c:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v8, Ljava/lang/String;

    .line 75
    .line 76
    const/4 v9, 0x0

    .line 77
    if-nez v7, :cond_3

    .line 78
    .line 79
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 80
    .line 81
    .line 82
    move-result-object v7

    .line 83
    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v8, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v7

    .line 90
    invoke-static {v7, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    invoke-static {v3, v7, v9}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    if-eqz v3, :cond_3

    .line 98
    .line 99
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    goto :goto_0

    .line 103
    :cond_3
    invoke-virtual {v2}, Lcom/transsnet/palmpay/contacts/bean/resp/QueryPhonesData;->getFullName()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v3

    .line 107
    if-eqz v3, :cond_5

    .line 108
    .line 109
    invoke-static {v6, v3, v5}, Lcom/airbnb/lottie/model/layer/d;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v3

    .line 113
    if-nez v3, :cond_4

    .line 114
    .line 115
    goto :goto_1

    .line 116
    :cond_4
    move-object v4, v3

    .line 117
    :cond_5
    :goto_1
    invoke-virtual {v2}, Lcom/transsnet/palmpay/contacts/bean/resp/QueryPhonesData;->getFullName()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v3

    .line 121
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 122
    .line 123
    .line 124
    move-result v3

    .line 125
    if-nez v3, :cond_0

    .line 126
    .line 127
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v8, v3}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v3

    .line 138
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    invoke-static {v4, v3, v9}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 142
    .line 143
    .line 144
    move-result v3

    .line 145
    if-eqz v3, :cond_0

    .line 146
    .line 147
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    goto :goto_0

    .line 151
    :cond_6
    invoke-interface {p1, v0}, Lio/reactivex/Emitter;->onNext(Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    invoke-interface {p1}, Lio/reactivex/Emitter;->onComplete()V

    .line 155
    .line 156
    .line 157
    return-void
.end method

.method public then(Lcom/google/android/gms/tasks/Task;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LU8/a;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/internal/ConfigRealtimeHttpClient;

    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/tasks/Task;

    invoke-static {v0, v1, p1}, Lcom/google/firebase/remoteconfig/internal/ConfigRealtimeHttpClient;->a(Lcom/google/firebase/remoteconfig/internal/ConfigRealtimeHttpClient;Lcom/google/android/gms/tasks/Task;Lcom/google/android/gms/tasks/Task;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    return-object p1

    :pswitch_0
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;

    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-static {v0, v1, p1}, Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;->d(Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;Ljava/util/HashMap;Lcom/google/android/gms/tasks/Task;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    return-object p1

    :pswitch_1
    iget-object v0, p0, LU8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;

    iget-object v1, p0, LU8/a;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Date;

    invoke-static {v0, v1, p1}, Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;->c(Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;Ljava/util/Date;Lcom/google/android/gms/tasks/Task;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    return-object p1

    :pswitch_data_0
    .packed-switch 0x1a
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
