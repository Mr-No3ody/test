.class public final Lia/a;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 1

    .line 1
    new-instance p1, Lia/a;

    .line 2
    .line 3
    const/4 v0, 0x2

    .line 4
    invoke-direct {p1, v0, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lia/a;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lia/a;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lia/a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    const-string/jumbo v0, "\u91c7\u96c6\u5230 "

    .line 2
    .line 3
    .line 4
    const-string/jumbo v1, "\u83b7\u53d6\u914d\u7f6e\u6210\u529f: needCollect="

    .line 5
    .line 6
    .line 7
    sget-object v2, LEf/a;->a:LEf/a;

    .line 8
    .line 9
    iget v3, p0, Lia/a;->a:I

    .line 10
    .line 11
    const/4 v4, 0x2

    .line 12
    const/4 v5, 0x1

    .line 13
    const/4 v6, 0x5

    .line 14
    const/4 v7, 0x3

    .line 15
    const/4 v8, 0x0

    .line 16
    const-string v9, "InstalledAppsCollect"

    .line 17
    .line 18
    if-eqz v3, :cond_2

    .line 19
    .line 20
    if-eq v3, v5, :cond_1

    .line 21
    .line 22
    if-ne v3, v4, :cond_0

    .line 23
    .line 24
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    .line 26
    .line 27
    goto/16 :goto_3

    .line 28
    .line 29
    :catchall_0
    move-exception p1

    .line 30
    goto/16 :goto_7

    .line 31
    .line 32
    :catch_0
    move-exception p1

    .line 33
    goto/16 :goto_8

    .line 34
    .line 35
    :catch_1
    move-exception p1

    .line 36
    goto/16 :goto_9

    .line 37
    .line 38
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_1
    :try_start_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    :try_start_2
    const-string/jumbo p1, "\u5f00\u59cb\u68c0\u67e5\u5e94\u7528\u5217\u8868\u91c7\u96c6\u914d\u7f6e"

    .line 54
    .line 55
    .line 56
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-static {v9, v7, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    sget-object p1, Lia/e;->a:Lia/e;

    .line 64
    .line 65
    iput v5, p0, Lia/a;->a:I

    .line 66
    .line 67
    invoke-static {p0}, Lia/e;->a(LFf/c;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-ne p1, v2, :cond_3

    .line 72
    .line 73
    goto/16 :goto_2

    .line 74
    .line 75
    :cond_3
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;

    .line 76
    .line 77
    if-nez p1, :cond_4

    .line 78
    .line 79
    const-string/jumbo p1, "\u83b7\u53d6\u914d\u7f6e\u5931\u8d25\uff0c\u8df3\u8fc7\u91c7\u96c6"

    .line 80
    .line 81
    .line 82
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    invoke-static {v9, v6, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 90
    .line 91
    sget-object v0, Lia/e;->a:Lia/e;

    .line 92
    .line 93
    sput-object v8, Lia/e;->c:LWf/t0;

    .line 94
    .line 95
    return-object p1

    .line 96
    :cond_4
    :try_start_3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;->getUploadAble()Ljava/lang/Boolean;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;->getApplyId()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    new-instance v10, Ljava/lang/StringBuilder;

    .line 105
    .line 106
    invoke-direct {v10, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    const-string v1, ", applyId="

    .line 113
    .line 114
    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-static {v9, v7, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;->getUploadAble()Ljava/lang/Boolean;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 136
    .line 137
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    if-nez v1, :cond_5

    .line 142
    .line 143
    const-string/jumbo p1, "\u914d\u7f6e\u8868\u660e\u65e0\u9700\u91c7\u96c6\u5e94\u7528\u5217\u8868"

    .line 144
    .line 145
    .line 146
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    invoke-static {v9, v7, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_3
    .catch Ljava/lang/OutOfMemoryError; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 154
    .line 155
    sget-object v0, Lia/e;->a:Lia/e;

    .line 156
    .line 157
    sput-object v8, Lia/e;->c:LWf/t0;

    .line 158
    .line 159
    return-object p1

    .line 160
    :cond_5
    :try_start_4
    const-string/jumbo v1, "\u5f00\u59cb\u91c7\u96c6\u5e94\u7528\u5217\u8868..."

    .line 161
    .line 162
    .line 163
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v1

    .line 167
    invoke-static {v9, v7, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;->getIncludeSystemApp()Ljava/lang/Boolean;

    .line 171
    .line 172
    .line 173
    move-result-object v1

    .line 174
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 175
    .line 176
    .line 177
    move-result v1

    .line 178
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;->getMaxCount()Ljava/lang/Integer;

    .line 179
    .line 180
    .line 181
    move-result-object v3

    .line 182
    if-eqz v3, :cond_6

    .line 183
    .line 184
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 185
    .line 186
    .line 187
    move-result v3

    .line 188
    goto :goto_1

    .line 189
    :cond_6
    const/16 v3, 0x190

    .line 190
    .line 191
    :goto_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;->getAppWhiteList()Ljava/util/List;

    .line 192
    .line 193
    .line 194
    move-result-object v5

    .line 195
    invoke-static {v3, v5, v1}, LPa/r0;->c0(ILjava/util/List;Z)Ljava/util/List;

    .line 196
    .line 197
    .line 198
    move-result-object v1

    .line 199
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 200
    .line 201
    .line 202
    move-result v3

    .line 203
    new-instance v5, Ljava/lang/StringBuilder;

    .line 204
    .line 205
    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 206
    .line 207
    .line 208
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 209
    .line 210
    .line 211
    const-string v0, " \u4e2a\u5e94\u7528"

    .line 212
    .line 213
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 214
    .line 215
    .line 216
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object v0

    .line 220
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    invoke-static {v9, v7, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 225
    .line 226
    .line 227
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 228
    .line 229
    .line 230
    move-result v0

    .line 231
    if-eqz v0, :cond_7

    .line 232
    .line 233
    const-string/jumbo p1, "\u91c7\u96c6\u5230\u7684\u5e94\u7528\u5217\u8868\u4e3a\u7a7a\uff0c\u8df3\u8fc7\u4e0a\u4f20"

    .line 234
    .line 235
    .line 236
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object p1

    .line 240
    invoke-static {v9, v6, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 241
    .line 242
    .line 243
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 244
    .line 245
    sget-object v0, Lia/e;->a:Lia/e;

    .line 246
    .line 247
    sput-object v8, Lia/e;->c:LWf/t0;

    .line 248
    .line 249
    return-object p1

    .line 250
    :cond_7
    :try_start_5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;->getApplyId()Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    if-eqz v0, :cond_b

    .line 255
    .line 256
    invoke-static {v0}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 257
    .line 258
    .line 259
    move-result v0

    .line 260
    if-eqz v0, :cond_8

    .line 261
    .line 262
    goto :goto_4

    .line 263
    :cond_8
    sget-object v0, Lia/e;->a:Lia/e;

    .line 264
    .line 265
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;->getApplyId()Ljava/lang/String;

    .line 266
    .line 267
    .line 268
    move-result-object p1

    .line 269
    if-nez p1, :cond_9

    .line 270
    .line 271
    const-string p1, ""

    .line 272
    .line 273
    :cond_9
    iput v4, p0, Lia/a;->a:I

    .line 274
    .line 275
    invoke-static {p1, v1, p0}, Lia/e;->b(Ljava/lang/String;Ljava/util/List;LFf/c;)Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    move-result-object p1

    .line 279
    if-ne p1, v2, :cond_a

    .line 280
    .line 281
    :goto_2
    return-object v2

    .line 282
    :cond_a
    :goto_3
    check-cast p1, Ljava/lang/Boolean;

    .line 283
    .line 284
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 285
    .line 286
    .line 287
    move-result p1

    .line 288
    goto :goto_5

    .line 289
    :cond_b
    :goto_4
    const-string p1, "applyId \u4e3a\u7a7a\uff0c\u8df3\u8fc7\u4e0a\u4f20"

    .line 290
    .line 291
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 292
    .line 293
    .line 294
    move-result-object p1

    .line 295
    invoke-static {v9, v6, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 296
    .line 297
    .line 298
    const/4 p1, 0x0

    .line 299
    :goto_5
    if-eqz p1, :cond_c

    .line 300
    .line 301
    const-string/jumbo p1, "\u5e94\u7528\u5217\u8868\u4e0a\u4f20\u6210\u529f"

    .line 302
    .line 303
    .line 304
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    move-result-object p1

    .line 308
    invoke-static {v9, v7, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 309
    .line 310
    .line 311
    goto :goto_6

    .line 312
    :cond_c
    const-string/jumbo p1, "\u5e94\u7528\u5217\u8868\u4e0a\u4f20\u5931\u8d25"

    .line 313
    .line 314
    .line 315
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object p1

    .line 319
    invoke-static {v9, v6, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V
    :try_end_5
    .catch Ljava/lang/OutOfMemoryError; {:try_start_5 .. :try_end_5} :catch_1
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 320
    .line 321
    .line 322
    :goto_6
    sget-object p1, Lia/e;->a:Lia/e;

    .line 323
    .line 324
    sput-object v8, Lia/e;->c:LWf/t0;

    .line 325
    .line 326
    goto :goto_a

    .line 327
    :goto_7
    :try_start_6
    const-string/jumbo v0, "\u5e94\u7528\u5217\u8868\u91c7\u96c6\u8fc7\u7a0b\u53d1\u751f\u672a\u77e5\u9519\u8bef"

    .line 328
    .line 329
    .line 330
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object p1

    .line 334
    invoke-static {v9, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 335
    .line 336
    .line 337
    goto :goto_6

    .line 338
    :catchall_1
    move-exception p1

    .line 339
    goto :goto_b

    .line 340
    :goto_8
    const-string/jumbo v0, "\u5e94\u7528\u5217\u8868\u91c7\u96c6\u8fc7\u7a0b\u53d1\u751f\u5f02\u5e38"

    .line 341
    .line 342
    .line 343
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object p1

    .line 347
    invoke-static {v9, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    goto :goto_6

    .line 351
    :goto_9
    const-string/jumbo v0, "\u5e94\u7528\u5217\u8868\u91c7\u96c6\u8fc7\u7a0b\u53d1\u751f OOM"

    .line 352
    .line 353
    .line 354
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    move-result-object p1

    .line 358
    invoke-static {v9, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 359
    .line 360
    .line 361
    goto :goto_6

    .line 362
    :goto_a
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 363
    .line 364
    return-object p1

    .line 365
    :goto_b
    sget-object v0, Lia/e;->a:Lia/e;

    .line 366
    .line 367
    sput-object v8, Lia/e;->c:LWf/t0;

    .line 368
    .line 369
    throw p1
.end method
