.class public final Lia/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lia/e;

.field public static final b:Lag/c;

.field public static volatile c:LWf/t0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lia/e;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lia/e;->a:Lia/e;

    .line 7
    .line 8
    sget-object v0, LWf/I;->a:Lcg/f;

    .line 9
    .line 10
    sget-object v0, Lcg/e;->c:Lcg/e;

    .line 11
    .line 12
    invoke-static {}, LWf/y;->c()LWf/v0;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-static {v0, v1}, Lkotlin/coroutines/e;->c(Lkotlin/coroutines/CoroutineContext$Element;Lkotlin/coroutines/CoroutineContext;)Lkotlin/coroutines/CoroutineContext;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {v0}, LWf/v;->a(Lkotlin/coroutines/CoroutineContext;)Lag/c;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sput-object v0, Lia/e;->b:Lag/c;

    .line 28
    .line 29
    return-void
.end method

.method public static final a(LFf/c;)Ljava/lang/Object;
    .locals 9

    .line 1
    const-string/jumbo v0, "\u67e5\u8be2\u914d\u7f6e\u5931\u8d25: "

    .line 2
    .line 3
    .line 4
    instance-of v1, p0, Lia/b;

    .line 5
    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    move-object v1, p0

    .line 9
    check-cast v1, Lia/b;

    .line 10
    .line 11
    iget v2, v1, Lia/b;->b:I

    .line 12
    .line 13
    const/high16 v3, -0x80000000

    .line 14
    .line 15
    and-int v4, v2, v3

    .line 16
    .line 17
    if-eqz v4, :cond_0

    .line 18
    .line 19
    sub-int/2addr v2, v3

    .line 20
    iput v2, v1, Lia/b;->b:I

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    new-instance v1, Lia/b;

    .line 24
    .line 25
    invoke-direct {v1, p0}, LFf/c;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 26
    .line 27
    .line 28
    :goto_0
    iget-object p0, v1, Lia/b;->a:Ljava/lang/Object;

    .line 29
    .line 30
    sget-object v2, LEf/a;->a:LEf/a;

    .line 31
    .line 32
    iget v3, v1, Lia/b;->b:I

    .line 33
    .line 34
    const-string v4, "InstalledAppsCollect"

    .line 35
    .line 36
    const/4 v5, 0x0

    .line 37
    const/4 v6, 0x1

    .line 38
    if-eqz v3, :cond_2

    .line 39
    .line 40
    if-ne v3, v6, :cond_1

    .line 41
    .line 42
    :try_start_0
    invoke-static {p0}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 43
    .line 44
    .line 45
    goto :goto_1

    .line 46
    :catch_0
    move-exception p0

    .line 47
    goto :goto_3

    .line 48
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 51
    .line 52
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    throw p0

    .line 56
    :cond_2
    invoke-static {p0}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :try_start_1
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getManufacturer()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getModel()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    sget-object v7, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 68
    .line 69
    iget-object v7, v7, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v7, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 72
    .line 73
    new-instance v8, Lcom/transsnet/palmpay/core/bean/req/AppListCollectUpload;

    .line 74
    .line 75
    invoke-direct {v8, p0, v3}, Lcom/transsnet/palmpay/core/bean/req/AppListCollectUpload;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    iput v6, v1, Lia/b;->b:I

    .line 79
    .line 80
    invoke-interface {v7, v8, v1}, Lcom/transsnet/palmpay/core/network/PayApiService;->checkAppListCollectConfig(Lcom/transsnet/palmpay/core/bean/req/AppListCollectUpload;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    if-ne p0, v2, :cond_3

    .line 85
    .line 86
    return-object v2

    .line 87
    :cond_3
    :goto_1
    check-cast p0, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 88
    .line 89
    if-eqz p0, :cond_4

    .line 90
    .line 91
    invoke-virtual {p0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 92
    .line 93
    .line 94
    move-result v1

    .line 95
    if-ne v1, v6, :cond_4

    .line 96
    .line 97
    iget-object v1, p0, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 98
    .line 99
    if-eqz v1, :cond_4

    .line 100
    .line 101
    check-cast v1, Lcom/transsnet/palmpay/core/bean/rsp/AppListCollectConfigBean;

    .line 102
    .line 103
    return-object v1

    .line 104
    :cond_4
    if-eqz p0, :cond_5

    .line 105
    .line 106
    invoke-virtual {p0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    goto :goto_2

    .line 111
    :cond_5
    move-object p0, v5

    .line 112
    :goto_2
    new-instance v1, Ljava/lang/StringBuilder;

    .line 113
    .line 114
    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object p0

    .line 124
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object p0

    .line 128
    const/4 v0, 0x5

    .line 129
    invoke-static {v4, v0, p0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 130
    .line 131
    .line 132
    return-object v5

    .line 133
    :goto_3
    const-string/jumbo v0, "\u67e5\u8be2\u91c7\u96c6\u914d\u7f6e\u5931\u8d25"

    .line 134
    .line 135
    .line 136
    filled-new-array {v0, p0}, [Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object p0

    .line 140
    invoke-static {v4, p0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    return-object v5
.end method

.method public static final b(Ljava/lang/String;Ljava/util/List;LFf/c;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    sget-object v2, Lia/e;->a:Lia/e;

    .line 6
    .line 7
    const-string v3, ", \u6bcf\u6279=50, \u8d77\u59cb\u6279\u6b21="

    .line 8
    .line 9
    const-string/jumbo v4, "\u5f00\u59cb\u5206\u6279\u4e0a\u4f20\u5e94\u7528\u5217\u8868: \u603b\u6570="

    .line 10
    .line 11
    .line 12
    const-string/jumbo v5, "\u5f00\u59cb\u5168\u65b0\u4e0a\u4f20: applyId="

    .line 13
    .line 14
    .line 15
    const-string/jumbo v6, "\u68c0\u6d4b\u5230\u65ad\u70b9\u7eed\u4f20: applyId="

    .line 16
    .line 17
    .line 18
    const-string/jumbo v7, "\u5e94\u7528\u6570\u91cf\u53d8\u5316: \u4e0a\u6b21="

    .line 19
    .line 20
    .line 21
    instance-of v8, v1, Lia/c;

    .line 22
    .line 23
    if-eqz v8, :cond_0

    .line 24
    .line 25
    move-object v8, v1

    .line 26
    check-cast v8, Lia/c;

    .line 27
    .line 28
    iget v9, v8, Lia/c;->p:I

    .line 29
    .line 30
    const/high16 v10, -0x80000000

    .line 31
    .line 32
    and-int v11, v9, v10

    .line 33
    .line 34
    if-eqz v11, :cond_0

    .line 35
    .line 36
    sub-int/2addr v9, v10

    .line 37
    iput v9, v8, Lia/c;->p:I

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    new-instance v8, Lia/c;

    .line 41
    .line 42
    invoke-direct {v8, v1}, LFf/c;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 43
    .line 44
    .line 45
    :goto_0
    iget-object v1, v8, Lia/c;->o:Ljava/lang/Object;

    .line 46
    .line 47
    sget-object v9, LEf/a;->a:LEf/a;

    .line 48
    .line 49
    iget v10, v8, Lia/c;->p:I

    .line 50
    .line 51
    const/4 v11, 0x1

    .line 52
    const-string/jumbo v12, "\u7b2c "

    .line 53
    .line 54
    .line 55
    const-string v14, "/"

    .line 56
    .line 57
    const/16 v16, 0x0

    .line 58
    .line 59
    const-string v15, "InstalledAppsCollect"

    .line 60
    .line 61
    if-eqz v10, :cond_2

    .line 62
    .line 63
    if-ne v10, v11, :cond_1

    .line 64
    .line 65
    iget v0, v8, Lia/c;->j:I

    .line 66
    .line 67
    iget v3, v8, Lia/c;->i:I

    .line 68
    .line 69
    iget v4, v8, Lia/c;->g:I

    .line 70
    .line 71
    iget v5, v8, Lia/c;->f:I

    .line 72
    .line 73
    iget v6, v8, Lia/c;->e:I

    .line 74
    .line 75
    iget v7, v8, Lia/c;->d:I

    .line 76
    .line 77
    iget-object v10, v8, Lia/c;->c:Ljava/util/List;

    .line 78
    .line 79
    check-cast v10, Ljava/util/List;

    .line 80
    .line 81
    move/from16 v17, v11

    .line 82
    .line 83
    iget-object v11, v8, Lia/c;->b:Ljava/util/List;

    .line 84
    .line 85
    check-cast v11, Ljava/util/List;

    .line 86
    .line 87
    iget-object v13, v8, Lia/c;->a:Ljava/lang/String;

    .line 88
    .line 89
    :try_start_0
    invoke-static {v1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 90
    .line 91
    .line 92
    move-object/from16 v18, v12

    .line 93
    .line 94
    move-object v12, v10

    .line 95
    move-object v10, v8

    .line 96
    move v8, v7

    .line 97
    move v7, v6

    .line 98
    move v6, v5

    .line 99
    move v5, v4

    .line 100
    move v4, v0

    .line 101
    move-object v0, v13

    .line 102
    goto/16 :goto_5

    .line 103
    .line 104
    :catch_0
    move-exception v0

    .line 105
    move-object v1, v12

    .line 106
    goto/16 :goto_a

    .line 107
    .line 108
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 109
    .line 110
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 111
    .line 112
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    throw v0

    .line 116
    :cond_2
    move/from16 v17, v11

    .line 117
    .line 118
    invoke-static {v1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    :try_start_1
    invoke-static {v0}, Lia/e;->d(Ljava/lang/String;)Lkotlin/Pair;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    iget-object v10, v1, Lkotlin/Pair;->a:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast v10, Ljava/lang/Number;

    .line 128
    .line 129
    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    .line 130
    .line 131
    .line 132
    move-result v10

    .line 133
    iget-object v1, v1, Lkotlin/Pair;->b:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v1, Ljava/lang/Number;

    .line 136
    .line 137
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    if-ltz v10, :cond_3

    .line 142
    .line 143
    if-lez v1, :cond_3

    .line 144
    .line 145
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    .line 146
    .line 147
    .line 148
    move-result v11

    .line 149
    if-eq v1, v11, :cond_3

    .line 150
    .line 151
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    .line 152
    .line 153
    .line 154
    move-result v11

    .line 155
    new-instance v13, Ljava/lang/StringBuilder;

    .line 156
    .line 157
    invoke-direct {v13, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 161
    .line 162
    .line 163
    const-string v7, ", \u672c\u6b21="

    .line 164
    .line 165
    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    const-string/jumbo v7, "\uff0c\u91cd\u65b0\u5f00\u59cb\u4e0a\u4f20"

    .line 172
    .line 173
    .line 174
    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v7

    .line 181
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v7

    .line 185
    const/4 v11, 0x5

    .line 186
    invoke-static {v15, v11, v7}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    invoke-static {}, Lia/e;->c()V

    .line 190
    .line 191
    .line 192
    goto :goto_1

    .line 193
    :catch_1
    move-exception v0

    .line 194
    goto/16 :goto_d

    .line 195
    .line 196
    :cond_3
    :goto_1
    if-ltz v10, :cond_4

    .line 197
    .line 198
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    .line 199
    .line 200
    .line 201
    move-result v7

    .line 202
    if-ne v1, v7, :cond_4

    .line 203
    .line 204
    add-int/lit8 v10, v10, 0x1

    .line 205
    .line 206
    new-instance v1, Ljava/lang/StringBuilder;

    .line 207
    .line 208
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 212
    .line 213
    .line 214
    const-string v5, ", \u4ece\u7b2c "

    .line 215
    .line 216
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 217
    .line 218
    .line 219
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 220
    .line 221
    .line 222
    const-string v5, " \u6279\u7ee7\u7eed\u4e0a\u4f20"

    .line 223
    .line 224
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 225
    .line 226
    .line 227
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v1

    .line 231
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v1

    .line 235
    const/4 v5, 0x3

    .line 236
    invoke-static {v15, v5, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 237
    .line 238
    .line 239
    goto :goto_2

    .line 240
    :cond_4
    new-instance v1, Ljava/lang/StringBuilder;

    .line 241
    .line 242
    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 246
    .line 247
    .line 248
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v1

    .line 252
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v1

    .line 256
    const/4 v5, 0x3

    .line 257
    invoke-static {v15, v5, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    move/from16 v10, v16

    .line 261
    .line 262
    :goto_2
    move-object/from16 v1, p1

    .line 263
    .line 264
    check-cast v1, Ljava/lang/Iterable;

    .line 265
    .line 266
    const/16 v5, 0x32

    .line 267
    .line 268
    invoke-static {v1, v5}, Lkotlin/collections/CollectionsKt;->z(Ljava/lang/Iterable;I)Ljava/util/ArrayList;

    .line 269
    .line 270
    .line 271
    move-result-object v1

    .line 272
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 273
    .line 274
    .line 275
    move-result v5

    .line 276
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    .line 277
    .line 278
    .line 279
    move-result v6

    .line 280
    new-instance v7, Ljava/lang/StringBuilder;

    .line 281
    .line 282
    invoke-direct {v7, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 286
    .line 287
    .line 288
    const-string v4, ", \u5206\u6279\u6570="

    .line 289
    .line 290
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 291
    .line 292
    .line 293
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 294
    .line 295
    .line 296
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 297
    .line 298
    .line 299
    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 300
    .line 301
    .line 302
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    move-result-object v3

    .line 306
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object v3

    .line 310
    const/4 v4, 0x3

    .line 311
    invoke-static {v15, v4, v3}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 312
    .line 313
    .line 314
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 315
    .line 316
    .line 317
    move-result v3

    .line 318
    move-object v11, v1

    .line 319
    move v6, v5

    .line 320
    move v7, v10

    .line 321
    move/from16 v4, v16

    .line 322
    .line 323
    move v5, v4

    .line 324
    move-object/from16 v1, p1

    .line 325
    .line 326
    :goto_3
    if-ge v10, v3, :cond_a

    .line 327
    .line 328
    sget-object v13, Lia/e;->c:LWf/t0;

    .line 329
    .line 330
    if-eqz v13, :cond_9

    .line 331
    .line 332
    invoke-virtual {v13}, LWf/n0;->isActive()Z

    .line 333
    .line 334
    .line 335
    move-result v13

    .line 336
    move-object/from16 p0, v1

    .line 337
    .line 338
    move/from16 v1, v17

    .line 339
    .line 340
    if-ne v13, v1, :cond_8

    .line 341
    .line 342
    invoke-interface {v11, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    move-result-object v13

    .line 346
    check-cast v13, Ljava/util/List;

    .line 347
    .line 348
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 349
    .line 350
    .line 351
    move-result v17
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 352
    move/from16 p1, v1

    .line 353
    .line 354
    add-int/lit8 v1, v17, -0x1

    .line 355
    .line 356
    if-ne v10, v1, :cond_5

    .line 357
    .line 358
    const/4 v1, 0x1

    .line 359
    goto :goto_4

    .line 360
    :cond_5
    move/from16 v1, v16

    .line 361
    .line 362
    :goto_4
    move-object/from16 p1, v11

    .line 363
    .line 364
    add-int/lit8 v11, v10, 0x1

    .line 365
    .line 366
    move-object/from16 v18, v12

    .line 367
    .line 368
    :try_start_2
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 369
    .line 370
    .line 371
    move-result v12

    .line 372
    move-object/from16 v19, v9

    .line 373
    .line 374
    new-instance v9, Ljava/lang/StringBuilder;

    .line 375
    .line 376
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 377
    .line 378
    .line 379
    move-object/from16 v20, v2

    .line 380
    .line 381
    const-string/jumbo v2, "\u6b63\u5728\u4e0a\u4f20\u7b2c "

    .line 382
    .line 383
    .line 384
    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 385
    .line 386
    .line 387
    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 388
    .line 389
    .line 390
    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 391
    .line 392
    .line 393
    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 394
    .line 395
    .line 396
    const-string v2, " \u6279, \u6570\u91cf="

    .line 397
    .line 398
    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 402
    .line 403
    .line 404
    const-string v2, ", \u6700\u540e\u4e00\u6279="

    .line 405
    .line 406
    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 407
    .line 408
    .line 409
    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 410
    .line 411
    .line 412
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 413
    .line 414
    .line 415
    move-result-object v2

    .line 416
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 417
    .line 418
    .line 419
    move-result-object v2

    .line 420
    const/4 v9, 0x3

    .line 421
    invoke-static {v15, v9, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 422
    .line 423
    .line 424
    iput-object v0, v8, Lia/c;->a:Ljava/lang/String;

    .line 425
    .line 426
    move-object/from16 v2, p0

    .line 427
    .line 428
    check-cast v2, Ljava/util/List;

    .line 429
    .line 430
    iput-object v2, v8, Lia/c;->b:Ljava/util/List;

    .line 431
    .line 432
    move-object/from16 v11, p1

    .line 433
    .line 434
    check-cast v11, Ljava/util/List;

    .line 435
    .line 436
    iput-object v11, v8, Lia/c;->c:Ljava/util/List;

    .line 437
    .line 438
    iput v7, v8, Lia/c;->d:I

    .line 439
    .line 440
    iput v6, v8, Lia/c;->e:I

    .line 441
    .line 442
    iput v5, v8, Lia/c;->f:I

    .line 443
    .line 444
    iput v4, v8, Lia/c;->g:I

    .line 445
    .line 446
    iput v10, v8, Lia/c;->i:I

    .line 447
    .line 448
    iput v3, v8, Lia/c;->j:I

    .line 449
    .line 450
    const/4 v2, 0x1

    .line 451
    iput v2, v8, Lia/c;->p:I

    .line 452
    .line 453
    move-object/from16 v2, v20

    .line 454
    .line 455
    invoke-virtual {v2, v0, v13, v1, v8}, Lia/e;->f(Ljava/lang/String;Ljava/util/List;ZLFf/c;)Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_6

    .line 459
    move-object/from16 v9, v19

    .line 460
    .line 461
    if-ne v1, v9, :cond_6

    .line 462
    .line 463
    return-object v9

    .line 464
    :cond_6
    move v11, v4

    .line 465
    move v4, v3

    .line 466
    move v3, v10

    .line 467
    move-object v10, v8

    .line 468
    move v8, v7

    .line 469
    move v7, v6

    .line 470
    move v6, v5

    .line 471
    move v5, v11

    .line 472
    move-object/from16 v11, p0

    .line 473
    .line 474
    move-object/from16 v12, p1

    .line 475
    .line 476
    :goto_5
    :try_start_3
    check-cast v1, Ljava/lang/Boolean;

    .line 477
    .line 478
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 479
    .line 480
    .line 481
    move-result v1
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_5

    .line 482
    if-eqz v1, :cond_7

    .line 483
    .line 484
    add-int/lit8 v1, v6, 0x1

    .line 485
    .line 486
    :try_start_4
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 487
    .line 488
    .line 489
    move-result v6

    .line 490
    invoke-static {v3, v6, v0}, Lia/e;->e(IILjava/lang/String;)V

    .line 491
    .line 492
    .line 493
    add-int/lit8 v6, v3, 0x1

    .line 494
    .line 495
    new-instance v13, Ljava/lang/StringBuilder;

    .line 496
    .line 497
    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    .line 498
    .line 499
    .line 500
    move/from16 p0, v1

    .line 501
    .line 502
    move-object/from16 v1, v18

    .line 503
    .line 504
    :try_start_5
    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 505
    .line 506
    .line 507
    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 508
    .line 509
    .line 510
    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 511
    .line 512
    .line 513
    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 514
    .line 515
    .line 516
    move-object/from16 v18, v0

    .line 517
    .line 518
    const-string v0, " \u6279\u4e0a\u4f20\u6210\u529f\uff0c\u5df2\u4fdd\u5b58\u8fdb\u5ea6"

    .line 519
    .line 520
    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 521
    .line 522
    .line 523
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 524
    .line 525
    .line 526
    move-result-object v0

    .line 527
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 528
    .line 529
    .line 530
    move-result-object v0

    .line 531
    const/4 v13, 0x3

    .line 532
    invoke-static {v15, v13, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    .line 533
    .line 534
    .line 535
    move-object v0, v12

    .line 536
    move-object v12, v1

    .line 537
    move-object v1, v11

    .line 538
    move-object v11, v0

    .line 539
    move-object v0, v10

    .line 540
    move v10, v6

    .line 541
    move v6, v7

    .line 542
    move v7, v8

    .line 543
    move-object v8, v0

    .line 544
    move v3, v4

    .line 545
    move v4, v5

    .line 546
    move-object/from16 v0, v18

    .line 547
    .line 548
    const/16 v17, 0x1

    .line 549
    .line 550
    move/from16 v5, p0

    .line 551
    .line 552
    goto/16 :goto_3

    .line 553
    .line 554
    :goto_6
    move v4, v5

    .line 555
    move v6, v7

    .line 556
    move v7, v8

    .line 557
    const/16 v17, 0x1

    .line 558
    .line 559
    move/from16 v5, p0

    .line 560
    .line 561
    goto :goto_a

    .line 562
    :catch_2
    move-exception v0

    .line 563
    goto :goto_6

    .line 564
    :catch_3
    move-exception v0

    .line 565
    move/from16 p0, v1

    .line 566
    .line 567
    move-object/from16 v1, v18

    .line 568
    .line 569
    goto :goto_6

    .line 570
    :cond_7
    move-object/from16 v1, v18

    .line 571
    .line 572
    add-int/lit8 v4, v5, 0x1

    .line 573
    .line 574
    add-int/lit8 v0, v3, 0x1

    .line 575
    .line 576
    :try_start_6
    new-instance v2, Ljava/lang/StringBuilder;

    .line 577
    .line 578
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 579
    .line 580
    .line 581
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 582
    .line 583
    .line 584
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 585
    .line 586
    .line 587
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 588
    .line 589
    .line 590
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 591
    .line 592
    .line 593
    const-string v0, " \u6279\u4e0a\u4f20\u5931\u8d25"

    .line 594
    .line 595
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 596
    .line 597
    .line 598
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 599
    .line 600
    .line 601
    move-result-object v0

    .line 602
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 603
    .line 604
    .line 605
    move-result-object v0

    .line 606
    const/4 v11, 0x5

    .line 607
    invoke-static {v15, v11, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    .line 608
    .line 609
    .line 610
    move v5, v6

    .line 611
    move v6, v7

    .line 612
    move v7, v8

    .line 613
    const/16 v17, 0x1

    .line 614
    .line 615
    goto :goto_b

    .line 616
    :goto_7
    move v5, v6

    .line 617
    move v6, v7

    .line 618
    move v7, v8

    .line 619
    :goto_8
    const/16 v17, 0x1

    .line 620
    .line 621
    goto :goto_a

    .line 622
    :catch_4
    move-exception v0

    .line 623
    goto :goto_7

    .line 624
    :catch_5
    move-exception v0

    .line 625
    move-object/from16 v1, v18

    .line 626
    .line 627
    move v4, v5

    .line 628
    goto :goto_7

    .line 629
    :goto_9
    move v3, v10

    .line 630
    goto :goto_8

    .line 631
    :catch_6
    move-exception v0

    .line 632
    move-object/from16 v1, v18

    .line 633
    .line 634
    goto :goto_9

    .line 635
    :goto_a
    add-int/lit8 v4, v4, 0x1

    .line 636
    .line 637
    add-int/lit8 v3, v3, 0x1

    .line 638
    .line 639
    :try_start_7
    new-instance v2, Ljava/lang/StringBuilder;

    .line 640
    .line 641
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 642
    .line 643
    .line 644
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 645
    .line 646
    .line 647
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 648
    .line 649
    .line 650
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 651
    .line 652
    .line 653
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 654
    .line 655
    .line 656
    const-string v1, " \u6279\u4e0a\u4f20\u5f02\u5e38"

    .line 657
    .line 658
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 659
    .line 660
    .line 661
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 662
    .line 663
    .line 664
    move-result-object v1

    .line 665
    filled-new-array {v1, v0}, [Ljava/lang/Object;

    .line 666
    .line 667
    .line 668
    move-result-object v0

    .line 669
    invoke-static {v15, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 670
    .line 671
    .line 672
    goto :goto_b

    .line 673
    :cond_8
    move/from16 v17, v1

    .line 674
    .line 675
    :cond_9
    const-string/jumbo v0, "\u68c0\u6d4b\u5230\u534f\u7a0b\u5df2\u53d6\u6d88\uff0c\u505c\u6b62\u4e0a\u4f20"

    .line 676
    .line 677
    .line 678
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 679
    .line 680
    .line 681
    move-result-object v0

    .line 682
    const/4 v11, 0x5

    .line 683
    invoke-static {v15, v11, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 684
    .line 685
    .line 686
    :cond_a
    :goto_b
    add-int/2addr v7, v5

    .line 687
    if-ne v7, v6, :cond_b

    .line 688
    .line 689
    invoke-static {}, Lia/e;->c()V

    .line 690
    .line 691
    .line 692
    const-string/jumbo v0, "\u6240\u6709\u6279\u6b21\u4e0a\u4f20\u5b8c\u6210\uff0c\u5df2\u6e05\u9664\u4e0a\u4f20\u8fdb\u5ea6"

    .line 693
    .line 694
    .line 695
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 696
    .line 697
    .line 698
    move-result-object v0

    .line 699
    const/4 v13, 0x3

    .line 700
    invoke-static {v15, v13, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 701
    .line 702
    .line 703
    :cond_b
    if-lez v5, :cond_c

    .line 704
    .line 705
    move/from16 v11, v17

    .line 706
    .line 707
    goto :goto_c

    .line 708
    :cond_c
    move/from16 v11, v16

    .line 709
    .line 710
    :goto_c
    new-instance v0, Ljava/lang/StringBuilder;

    .line 711
    .line 712
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 713
    .line 714
    .line 715
    const-string/jumbo v1, "\u5e94\u7528\u5217\u8868\u5206\u6279\u4e0a\u4f20\u5b8c\u6210: \u6210\u529f="

    .line 716
    .line 717
    .line 718
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 719
    .line 720
    .line 721
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 722
    .line 723
    .line 724
    const-string v1, ", \u5931\u8d25="

    .line 725
    .line 726
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 727
    .line 728
    .line 729
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 730
    .line 731
    .line 732
    const-string v1, ", \u603b\u6279\u6b21="

    .line 733
    .line 734
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 735
    .line 736
    .line 737
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 738
    .line 739
    .line 740
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 741
    .line 742
    .line 743
    move-result-object v0

    .line 744
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 745
    .line 746
    .line 747
    move-result-object v0

    .line 748
    const/4 v13, 0x3

    .line 749
    invoke-static {v15, v13, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_1

    .line 750
    .line 751
    .line 752
    move/from16 v16, v11

    .line 753
    .line 754
    goto :goto_e

    .line 755
    :goto_d
    const-string/jumbo v1, "\u4e0a\u4f20\u5e94\u7528\u5217\u8868\u5931\u8d25"

    .line 756
    .line 757
    .line 758
    filled-new-array {v1, v0}, [Ljava/lang/Object;

    .line 759
    .line 760
    .line 761
    move-result-object v0

    .line 762
    invoke-static {v15, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 763
    .line 764
    .line 765
    :goto_e
    invoke-static/range {v16 .. v16}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 766
    .line 767
    .line 768
    move-result-object v0

    .line 769
    return-object v0
.end method

.method public static c()V
    .locals 3

    .line 1
    const-string v0, "InstalledAppsCollect"

    .line 2
    .line 3
    :try_start_0
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const-string v2, "installed_apps_collect_last_apply_id"

    .line 8
    .line 9
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/util/SPUtils;->remove(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    const-string v2, "installed_apps_collect_last_uploaded_batch_index"

    .line 17
    .line 18
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/util/SPUtils;->remove(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const-string v2, "installed_apps_collect_last_app_count"

    .line 26
    .line 27
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/util/SPUtils;->remove(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const-string/jumbo v1, "\u6e05\u9664\u4e0a\u4f20\u8fdb\u5ea6"

    .line 31
    .line 32
    .line 33
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const/4 v2, 0x3

    .line 38
    invoke-static {v0, v2, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :catch_0
    move-exception v1

    .line 43
    const-string/jumbo v2, "\u6e05\u9664\u4e0a\u4f20\u8fdb\u5ea6\u5931\u8d25"

    .line 44
    .line 45
    .line 46
    filled-new-array {v2, v1}, [Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    invoke-static {v0, v1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public static d(Ljava/lang/String;)Lkotlin/Pair;
    .locals 8

    .line 1
    const-string v0, "InstalledAppsCollect"

    .line 2
    .line 3
    const-string v1, "applyId \u4e0d\u540c\uff0c\u4ece\u5934\u5f00\u59cb\u4e0a\u4f20: last="

    .line 4
    .line 5
    const-string/jumbo v2, "\u8bfb\u53d6\u4e0a\u4f20\u8fdb\u5ea6: applyId="

    .line 6
    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    const/4 v4, -0x1

    .line 10
    :try_start_0
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 11
    .line 12
    .line 13
    move-result-object v5

    .line 14
    const-string v6, "installed_apps_collect_last_apply_id"

    .line 15
    .line 16
    const-string v7, ""

    .line 17
    .line 18
    invoke-virtual {v5, v6, v7}, Lcom/transsnet/palmpay/util/SPUtils;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    invoke-static {v5, p0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    const/4 v7, 0x3

    .line 27
    if-eqz v6, :cond_0

    .line 28
    .line 29
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    const-string v5, "installed_apps_collect_last_uploaded_batch_index"

    .line 34
    .line 35
    invoke-virtual {v1, v5, v4}, Lcom/transsnet/palmpay/util/SPUtils;->getInt(Ljava/lang/String;I)I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    const-string v6, "installed_apps_collect_last_app_count"

    .line 44
    .line 45
    invoke-virtual {v5, v6, v3}, Lcom/transsnet/palmpay/util/SPUtils;->getInt(Ljava/lang/String;I)I

    .line 46
    .line 47
    .line 48
    move-result v5

    .line 49
    new-instance v6, Ljava/lang/StringBuilder;

    .line 50
    .line 51
    invoke-direct {v6, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string p0, ", lastBatchIndex="

    .line 58
    .line 59
    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    const-string p0, ", lastAppCount="

    .line 66
    .line 67
    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object p0

    .line 81
    invoke-static {v0, v7, p0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    new-instance p0, Lkotlin/Pair;

    .line 85
    .line 86
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    invoke-direct {p0, v1, v2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    return-object p0

    .line 98
    :catch_0
    move-exception p0

    .line 99
    goto :goto_0

    .line 100
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 101
    .line 102
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    const-string v1, ", current="

    .line 109
    .line 110
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object p0

    .line 120
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object p0

    .line 124
    invoke-static {v0, v7, p0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    new-instance p0, Lkotlin/Pair;

    .line 128
    .line 129
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    invoke-direct {p0, v1, v2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 138
    .line 139
    .line 140
    return-object p0

    .line 141
    :goto_0
    const-string/jumbo v1, "\u83b7\u53d6\u4e0a\u4f20\u8fdb\u5ea6\u5931\u8d25"

    .line 142
    .line 143
    .line 144
    filled-new-array {v1, p0}, [Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object p0

    .line 148
    invoke-static {v0, p0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    new-instance p0, Lkotlin/Pair;

    .line 152
    .line 153
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-direct {p0, v0, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    return-object p0
.end method

.method public static e(IILjava/lang/String;)V
    .locals 4

    .line 1
    const-string v0, "InstalledAppsCollect"

    .line 2
    .line 3
    const-string/jumbo v1, "\u4fdd\u5b58\u4e0a\u4f20\u8fdb\u5ea6: applyId="

    .line 4
    .line 5
    .line 6
    :try_start_0
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    const-string v3, "installed_apps_collect_last_apply_id"

    .line 11
    .line 12
    invoke-virtual {v2, v3, p2}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const-string v3, "installed_apps_collect_last_uploaded_batch_index"

    .line 20
    .line 21
    invoke-virtual {v2, v3, p0}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;I)V

    .line 22
    .line 23
    .line 24
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    const-string v3, "installed_apps_collect_last_app_count"

    .line 29
    .line 30
    invoke-virtual {v2, v3, p1}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;I)V

    .line 31
    .line 32
    .line 33
    new-instance v2, Ljava/lang/StringBuilder;

    .line 34
    .line 35
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    const-string p2, ", batchIndex="

    .line 42
    .line 43
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    const-string p0, ", appCount="

    .line 50
    .line 51
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    const/4 p1, 0x3

    .line 66
    invoke-static {v0, p1, p0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :catch_0
    move-exception p0

    .line 71
    const-string/jumbo p1, "\u4fdd\u5b58\u4e0a\u4f20\u8fdb\u5ea6\u5931\u8d25"

    .line 72
    .line 73
    .line 74
    filled-new-array {p1, p0}, [Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    invoke-static {v0, p0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/String;Ljava/util/List;ZLFf/c;)Ljava/lang/Object;
    .locals 8

    .line 1
    const-string/jumbo v0, "\u6279\u6b21\u4e0a\u4f20\u5931\u8d25: "

    .line 2
    .line 3
    .line 4
    const-string/jumbo v1, "\u4e0a\u4f20\u6279\u6b21: isLastBatch="

    .line 5
    .line 6
    .line 7
    instance-of v2, p4, Lia/d;

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    move-object v2, p4

    .line 12
    check-cast v2, Lia/d;

    .line 13
    .line 14
    iget v3, v2, Lia/d;->c:I

    .line 15
    .line 16
    const/high16 v4, -0x80000000

    .line 17
    .line 18
    and-int v5, v3, v4

    .line 19
    .line 20
    if-eqz v5, :cond_0

    .line 21
    .line 22
    sub-int/2addr v3, v4

    .line 23
    iput v3, v2, Lia/d;->c:I

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    new-instance v2, Lia/d;

    .line 27
    .line 28
    invoke-direct {v2, p0, p4}, Lia/d;-><init>(Lia/e;LFf/c;)V

    .line 29
    .line 30
    .line 31
    :goto_0
    iget-object p4, v2, Lia/d;->a:Ljava/lang/Object;

    .line 32
    .line 33
    sget-object v3, LEf/a;->a:LEf/a;

    .line 34
    .line 35
    iget v4, v2, Lia/d;->c:I

    .line 36
    .line 37
    const-string v5, "InstalledAppsCollect"

    .line 38
    .line 39
    const/4 v6, 0x0

    .line 40
    const/4 v7, 0x1

    .line 41
    if-eqz v4, :cond_2

    .line 42
    .line 43
    if-ne v4, v7, :cond_1

    .line 44
    .line 45
    :try_start_0
    invoke-static {p4}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 46
    .line 47
    .line 48
    goto :goto_1

    .line 49
    :catch_0
    move-exception p1

    .line 50
    goto/16 :goto_3

    .line 51
    .line 52
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 53
    .line 54
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 55
    .line 56
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    throw p1

    .line 60
    :cond_2
    invoke-static {p4}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    :try_start_1
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 64
    .line 65
    .line 66
    move-result-object p4

    .line 67
    iget-object p4, p4, LPa/w;->b:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast p4, Lcom/google/gson/Gson;

    .line 70
    .line 71
    invoke-virtual {p4, p2}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object p2

    .line 75
    new-instance p4, Lcom/transsnet/palmpay/core/bean/req/AppListCollectUploadBean;

    .line 76
    .line 77
    invoke-direct {p4}, Lcom/transsnet/palmpay/core/bean/req/AppListCollectUploadBean;-><init>()V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p4, p1}, Lcom/transsnet/palmpay/core/bean/req/AppListCollectUploadBean;->setApplyId(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {p4, p2}, Lcom/transsnet/palmpay/core/bean/req/AppListCollectUploadBean;->setInfo(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/db/entity/User;->getMemberId()Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    invoke-virtual {p4, p1}, Lcom/transsnet/palmpay/core/bean/req/AppListCollectUploadBean;->setMemberId(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    invoke-virtual {p4, p1}, Lcom/transsnet/palmpay/core/bean/req/AppListCollectUploadBean;->setLastPageFlag(Ljava/lang/Boolean;)V

    .line 106
    .line 107
    .line 108
    new-instance p1, Ljava/lang/StringBuilder;

    .line 109
    .line 110
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    const/4 p2, 0x3

    .line 125
    invoke-static {v5, p2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 129
    .line 130
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 131
    .line 132
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 133
    .line 134
    iput v7, v2, Lia/d;->c:I

    .line 135
    .line 136
    invoke-interface {p1, p4, v2}, Lcom/transsnet/palmpay/core/network/PayApiService;->uploadAppListCollect(Lcom/transsnet/palmpay/core/bean/req/AppListCollectUploadBean;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object p4

    .line 140
    if-ne p4, v3, :cond_3

    .line 141
    .line 142
    return-object v3

    .line 143
    :cond_3
    :goto_1
    check-cast p4, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 144
    .line 145
    if-eqz p4, :cond_4

    .line 146
    .line 147
    invoke-virtual {p4}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 148
    .line 149
    .line 150
    move-result p1

    .line 151
    if-ne p1, v7, :cond_4

    .line 152
    .line 153
    move v6, v7

    .line 154
    goto :goto_4

    .line 155
    :cond_4
    if-eqz p4, :cond_5

    .line 156
    .line 157
    invoke-virtual {p4}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    goto :goto_2

    .line 162
    :cond_5
    const/4 p1, 0x0

    .line 163
    :goto_2
    new-instance p2, Ljava/lang/StringBuilder;

    .line 164
    .line 165
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    const/4 p2, 0x5

    .line 180
    invoke-static {v5, p2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 181
    .line 182
    .line 183
    goto :goto_4

    .line 184
    :goto_3
    const-string/jumbo p2, "\u6279\u6b21\u4e0a\u4f20\u5f02\u5e38"

    .line 185
    .line 186
    .line 187
    filled-new-array {p2, p1}, [Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    invoke-static {v5, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 192
    .line 193
    .line 194
    :goto_4
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    return-object p1
.end method
