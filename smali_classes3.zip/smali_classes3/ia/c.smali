.class public final Lia/c;
.super LFf/c;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/util/List;

.field public c:Ljava/util/List;

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public i:I

.field public j:I

.field public synthetic o:Ljava/lang/Object;

.field public p:I


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lia/c;->o:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lia/c;->p:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lia/c;->p:I

    .line 9
    .line 10
    sget-object p1, Lia/e;->a:Lia/e;

    .line 11
    .line 12
    const/4 p1, 0x0

    .line 13
    invoke-static {p1, p1, p0}, Lia/e;->b(Ljava/lang/String;Ljava/util/List;LFf/c;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method
