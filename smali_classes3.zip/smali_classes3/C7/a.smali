.class public final LC7/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/scwang/smartrefresh/layout/footer/BallPulseFooter;

.field public final synthetic c:Lcom/scwang/smartrefresh/layout/footer/BallPulseFooter;


# direct methods
.method public constructor <init>(Lcom/scwang/smartrefresh/layout/footer/BallPulseFooter;ILcom/scwang/smartrefresh/layout/footer/BallPulseFooter;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LC7/a;->c:Lcom/scwang/smartrefresh/layout/footer/BallPulseFooter;

    .line 5
    .line 6
    iput p2, p0, LC7/a;->a:I

    .line 7
    .line 8
    iput-object p3, p0, LC7/a;->b:Lcom/scwang/smartrefresh/layout/footer/BallPulseFooter;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 2

    .line 1
    iget-object v0, p0, LC7/a;->c:Lcom/scwang/smartrefresh/layout/footer/BallPulseFooter;

    .line 2
    .line 3
    iget-object v0, v0, Lcom/scwang/smartrefresh/layout/footer/BallPulseFooter;->j:[F

    .line 4
    .line 5
    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ljava/lang/Float;

    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    iget v1, p0, LC7/a;->a:I

    .line 16
    .line 17
    aput p1, v0, v1

    .line 18
    .line 19
    iget-object p1, p0, LC7/a;->b:Lcom/scwang/smartrefresh/layout/footer/BallPulseFooter;

    .line 20
    .line 21
    invoke-virtual {p1}, Landroid/view/View;->postInvalidate()V

    .line 22
    .line 23
    .line 24
    return-void
.end method
