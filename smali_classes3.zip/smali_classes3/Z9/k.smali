.class public final LZ9/k;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/base/l;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/base/l;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LZ9/k;->b:Lcom/transsnet/palmpay/core/base/l;

    .line 2
    .line 3
    iput-object p2, p0, LZ9/k;->c:Ljava/lang/String;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LZ9/k;

    .line 2
    .line 3
    iget-object v0, p0, LZ9/k;->c:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v1, p0, LZ9/k;->b:Lcom/transsnet/palmpay/core/base/l;

    .line 6
    .line 7
    invoke-direct {p1, v1, v0, p2}, LZ9/k;-><init>(Lcom/transsnet/palmpay/core/base/l;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LZ9/k;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LZ9/k;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LZ9/k;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LZ9/k;->a:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    sget-object p1, Lcom/palmpay/lib/apm/network/NQEManager;->INSTANCE:Lcom/palmpay/lib/apm/network/NQEManager;

    .line 26
    .line 27
    invoke-virtual {p1}, Lcom/palmpay/lib/apm/network/NQEManager;->isNetworkOffline()Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_2

    .line 32
    .line 33
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 34
    .line 35
    return-object p1

    .line 36
    :cond_2
    new-instance p1, Lkotlin/jvm/internal/F;

    .line 37
    .line 38
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 39
    .line 40
    .line 41
    const-string v1, ""

    .line 42
    .line 43
    iput-object v1, p1, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 44
    .line 45
    sget-object v1, Lcom/transsnet/palmpay/core/base/o;->a:Lcom/transsnet/palmpay/core/base/o;

    .line 46
    .line 47
    iget-object v3, p0, LZ9/k;->b:Lcom/transsnet/palmpay/core/base/l;

    .line 48
    .line 49
    invoke-virtual {v3, v1}, Lcom/transsnet/palmpay/core/base/l;->k(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    new-instance v1, LZ9/i;

    .line 53
    .line 54
    iget-object v4, p0, LZ9/k;->c:Ljava/lang/String;

    .line 55
    .line 56
    const/4 v5, 0x0

    .line 57
    invoke-direct {v1, v4, p1, v5}, LZ9/i;-><init>(Ljava/lang/String;Lkotlin/jvm/internal/F;Lkotlin/coroutines/Continuation;)V

    .line 58
    .line 59
    .line 60
    new-instance p1, Lkotlinx/coroutines/flow/T;

    .line 61
    .line 62
    invoke-direct {p1, v1}, Lkotlinx/coroutines/flow/T;-><init>(Lkotlin/jvm/functions/Function2;)V

    .line 63
    .line 64
    .line 65
    sget-object v1, LPa/I;->a:LWf/s;

    .line 66
    .line 67
    invoke-static {p1, v1}, Lkotlinx/coroutines/flow/X;->n(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/CoroutineContext;)Lkotlinx/coroutines/flow/Flow;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    new-instance v1, LJ9/A;

    .line 72
    .line 73
    const/16 v4, 0x1b

    .line 74
    .line 75
    invoke-direct {v1, v3, v5, v4}, LJ9/A;-><init>(Lcom/transsnet/palmpay/core/base/l;Lkotlin/coroutines/Continuation;I)V

    .line 76
    .line 77
    .line 78
    new-instance v4, Lkotlinx/coroutines/flow/u;

    .line 79
    .line 80
    invoke-direct {v4, p1, v1}, Lkotlinx/coroutines/flow/u;-><init>(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;)V

    .line 81
    .line 82
    .line 83
    new-instance p1, LZ9/j;

    .line 84
    .line 85
    invoke-direct {p1, v3, v5}, LZ9/j;-><init>(Lcom/transsnet/palmpay/core/base/l;Lkotlin/coroutines/Continuation;)V

    .line 86
    .line 87
    .line 88
    iput v2, p0, LZ9/k;->a:I

    .line 89
    .line 90
    invoke-static {v4, p1, p0}, Lkotlinx/coroutines/flow/X;->g(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    if-ne p1, v0, :cond_3

    .line 95
    .line 96
    return-object v0

    .line 97
    :cond_3
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 98
    .line 99
    return-object p1
.end method
