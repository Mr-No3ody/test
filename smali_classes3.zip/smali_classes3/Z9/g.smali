.class public final LZ9/g;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/transsnet/palmpay/contacts/bean/req/QueryLastRelationShipReq;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/contacts/bean/req/QueryLastRelationShipReq;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LZ9/g;->b:Lcom/transsnet/palmpay/contacts/bean/req/QueryLastRelationShipReq;

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance v0, LZ9/g;

    .line 2
    .line 3
    iget-object v1, p0, LZ9/g;->b:Lcom/transsnet/palmpay/contacts/bean/req/QueryLastRelationShipReq;

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, LZ9/g;-><init>(Lcom/transsnet/palmpay/contacts/bean/req/QueryLastRelationShipReq;Lkotlin/coroutines/Continuation;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Lkotlin/coroutines/Continuation;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, LZ9/g;->create(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, LZ9/g;

    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 10
    .line 11
    invoke-virtual {p1, v0}, LZ9/g;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LZ9/g;->a:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-object p1

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    sget-object p1, LS9/a;->a:Lorg/greenrobot/eventbus/f;

    .line 26
    .line 27
    iget-object p1, p1, Lorg/greenrobot/eventbus/f;->b:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast p1, Lcom/transsnet/palmpay/contacts/api/ContactsApiService;

    .line 30
    .line 31
    iput v2, p0, LZ9/g;->a:I

    .line 32
    .line 33
    iget-object v1, p0, LZ9/g;->b:Lcom/transsnet/palmpay/contacts/bean/req/QueryLastRelationShipReq;

    .line 34
    .line 35
    invoke-interface {p1, v1, p0}, Lcom/transsnet/palmpay/contacts/api/ContactsApiService;->queryRelationShip(Lcom/transsnet/palmpay/contacts/bean/req/QueryLastRelationShipReq;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    if-ne p1, v0, :cond_2

    .line 40
    .line 41
    return-object v0

    .line 42
    :cond_2
    return-object p1
.end method
