.class public final LU6/a;
.super Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;


# direct methods
.method public constructor <init>(Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;)V
    .locals 0

    .line 1
    iput-object p1, p0, LU6/a;->a:Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;

    .line 2
    .line 3
    invoke-direct {p0}, Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onPageScrollStateChanged(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onPageScrolled(IFI)V
    .locals 1

    .line 1
    iget-object p3, p0, LU6/a;->a:Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;

    .line 2
    .line 3
    iget-boolean v0, p3, Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;->C:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p3}, Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;->getCount()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    add-int/lit8 v0, v0, -0x1

    .line 12
    .line 13
    if-eq p1, v0, :cond_0

    .line 14
    .line 15
    iput p1, p3, Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;->g:I

    .line 16
    .line 17
    iput p2, p3, Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;->i:F

    .line 18
    .line 19
    invoke-virtual {p3}, Landroid/view/View;->invalidate()V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method

.method public final onPageSelected(I)V
    .locals 2

    .line 1
    iget-object v0, p0, LU6/a;->a:Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;

    .line 2
    .line 3
    iget-boolean v1, v0, Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;->C:Z

    .line 4
    .line 5
    if-nez v1, :cond_1

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;->getCount()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    add-int/lit8 v1, v1, -0x1

    .line 12
    .line 13
    if-ne p1, v1, :cond_0

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    return-void

    .line 17
    :cond_1
    :goto_0
    iput p1, v0, Lcom/palmpay/lib/ui/indicator/RoundCornerIndicator;->g:I

    .line 18
    .line 19
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 20
    .line 21
    .line 22
    return-void
.end method
