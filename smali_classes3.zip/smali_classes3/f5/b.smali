.class public final Lf5/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;
.implements Lcom/growingio/android/sdk/track/async/Disposable;
.implements Lorg/greenrobot/eventbus/Poster;


# instance fields
.field public final synthetic a:I

.field public volatile b:Z

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/os/Handler;LM7/s;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lf5/b;->a:I

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-object p1, p0, Lf5/b;->c:Ljava/lang/Object;

    .line 8
    iput-object p2, p0, Lf5/b;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lorg/greenrobot/eventbus/c;)V
    .locals 2

    const/4 v0, 0x1

    iput v0, p0, Lf5/b;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lf5/b;->d:Ljava/lang/Object;

    .line 3
    new-instance p1, Lcb/c;

    const/16 v0, 0xe

    const/4 v1, 0x0

    .line 4
    invoke-direct {p1, v0, v1}, Lcb/c;-><init>(IZ)V

    .line 5
    iput-object p1, p0, Lf5/b;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public dispose()V
    .locals 1

    .line 1
    iget-object v0, p0, Lf5/b;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/os/Handler;

    .line 4
    .line 5
    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    iput-boolean v0, p0, Lf5/b;->b:Z

    .line 10
    .line 11
    return-void
.end method

.method public enqueue(Lorg/greenrobot/eventbus/l;Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-static {p1, p2}, Lorg/greenrobot/eventbus/g;->a(Lorg/greenrobot/eventbus/l;Ljava/lang/Object;)Lorg/greenrobot/eventbus/g;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    monitor-enter p0

    .line 6
    :try_start_0
    iget-object p2, p0, Lf5/b;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p2, Lcb/c;

    .line 9
    .line 10
    invoke-virtual {p2, p1}, Lcb/c;->a(Lorg/greenrobot/eventbus/g;)V

    .line 11
    .line 12
    .line 13
    iget-boolean p1, p0, Lf5/b;->b:Z

    .line 14
    .line 15
    if-nez p1, :cond_0

    .line 16
    .line 17
    const/4 p1, 0x1

    .line 18
    iput-boolean p1, p0, Lf5/b;->b:Z

    .line 19
    .line 20
    iget-object p1, p0, Lf5/b;->d:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast p1, Lorg/greenrobot/eventbus/c;

    .line 23
    .line 24
    iget-object p1, p1, Lorg/greenrobot/eventbus/c;->j:Ljava/util/concurrent/ExecutorService;

    .line 25
    .line 26
    invoke-interface {p1, p0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :catchall_0
    move-exception p1

    .line 31
    goto :goto_1

    .line 32
    :cond_0
    :goto_0
    monitor-exit p0

    .line 33
    return-void

    .line 34
    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 35
    throw p1
.end method

.method public isDisposed()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lf5/b;->b:Z

    .line 2
    .line 3
    return v0
.end method

.method public final run()V
    .locals 6

    .line 1
    iget v0, p0, Lf5/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    :goto_0
    const/4 v0, 0x0

    .line 7
    :try_start_0
    iget-object v1, p0, Lf5/b;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Lcb/c;

    .line 10
    .line 11
    monitor-enter v1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 12
    :try_start_1
    iget-object v2, v1, Lcb/c;->b:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, Lorg/greenrobot/eventbus/g;

    .line 15
    .line 16
    if-nez v2, :cond_0

    .line 17
    .line 18
    const/16 v2, 0x3e8

    .line 19
    .line 20
    int-to-long v2, v2

    .line 21
    invoke-virtual {v1, v2, v3}, Ljava/lang/Object;->wait(J)V

    .line 22
    .line 23
    .line 24
    goto :goto_1

    .line 25
    :catchall_0
    move-exception v2

    .line 26
    goto :goto_5

    .line 27
    :cond_0
    :goto_1
    invoke-virtual {v1}, Lcb/c;->e()Lorg/greenrobot/eventbus/g;

    .line 28
    .line 29
    .line 30
    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 31
    :try_start_2
    monitor-exit v1

    .line 32
    if-nez v2, :cond_2

    .line 33
    .line 34
    monitor-enter p0
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 35
    :try_start_3
    iget-object v1, p0, Lf5/b;->c:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v1, Lcb/c;

    .line 38
    .line 39
    invoke-virtual {v1}, Lcb/c;->e()Lorg/greenrobot/eventbus/g;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    if-nez v2, :cond_1

    .line 44
    .line 45
    iput-boolean v0, p0, Lf5/b;->b:Z

    .line 46
    .line 47
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 48
    :goto_2
    iput-boolean v0, p0, Lf5/b;->b:Z

    .line 49
    .line 50
    goto :goto_7

    .line 51
    :catchall_1
    move-exception v1

    .line 52
    goto :goto_3

    .line 53
    :cond_1
    :try_start_4
    monitor-exit p0

    .line 54
    goto :goto_4

    .line 55
    :goto_3
    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 56
    :try_start_5
    throw v1

    .line 57
    :catchall_2
    move-exception v1

    .line 58
    goto :goto_8

    .line 59
    :catch_0
    move-exception v1

    .line 60
    goto :goto_6

    .line 61
    :cond_2
    :goto_4
    iget-object v1, p0, Lf5/b;->d:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v1, Lorg/greenrobot/eventbus/c;

    .line 64
    .line 65
    invoke-virtual {v1, v2}, Lorg/greenrobot/eventbus/c;->c(Lorg/greenrobot/eventbus/g;)V
    :try_end_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 66
    .line 67
    .line 68
    goto :goto_0

    .line 69
    :goto_5
    :try_start_6
    monitor-exit v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 70
    :try_start_7
    throw v2
    :try_end_7
    .catch Ljava/lang/InterruptedException; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 71
    :goto_6
    :try_start_8
    iget-object v2, p0, Lf5/b;->d:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v2, Lorg/greenrobot/eventbus/c;

    .line 74
    .line 75
    iget-object v2, v2, Lorg/greenrobot/eventbus/c;->p:Lorg/greenrobot/eventbus/Logger;

    .line 76
    .line 77
    sget-object v3, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    .line 78
    .line 79
    new-instance v4, Ljava/lang/StringBuilder;

    .line 80
    .line 81
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 82
    .line 83
    .line 84
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    invoke-virtual {v5}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v5

    .line 92
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string v5, " was interruppted"

    .line 96
    .line 97
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    invoke-interface {v2, v3, v4, v1}, Lorg/greenrobot/eventbus/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 105
    .line 106
    .line 107
    goto :goto_2

    .line 108
    :goto_7
    return-void

    .line 109
    :goto_8
    iput-boolean v0, p0, Lf5/b;->b:Z

    .line 110
    .line 111
    throw v1

    .line 112
    :pswitch_0
    const/4 v0, 0x1

    .line 113
    iput-boolean v0, p0, Lf5/b;->b:Z

    .line 114
    .line 115
    iget-object v0, p0, Lf5/b;->d:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast v0, LM7/s;

    .line 118
    .line 119
    invoke-virtual {v0}, LM7/s;->run()V

    .line 120
    .line 121
    .line 122
    return-void

    .line 123
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
