.class public final synthetic LC6/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/camera/core/ImageAnalysis$Analyzer;
.implements Lcom/google/android/gms/tasks/OnFailureListener;


# instance fields
.field public final synthetic a:LC6/v;


# direct methods
.method public synthetic constructor <init>(LC6/v;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC6/c;->a:LC6/v;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public analyze(Landroidx/camera/core/ImageProxy;)V
    .locals 8

    .line 1
    iget-object v1, p0, LC6/c;->a:LC6/v;

    .line 2
    .line 3
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const-string v0, "imageProxy"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getImage()Landroid/media/Image;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iget-boolean v2, v1, LC6/v;->C:Z

    .line 16
    .line 17
    if-eqz v2, :cond_0

    .line 18
    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    :cond_0
    move-object v4, p1

    .line 22
    goto :goto_0

    .line 23
    :cond_1
    iget-wide v2, v1, LC6/v;->B:J

    .line 24
    .line 25
    const-wide/16 v4, 0x1

    .line 26
    .line 27
    cmp-long v2, v2, v4

    .line 28
    .line 29
    if-gez v2, :cond_2

    .line 30
    .line 31
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 32
    .line 33
    .line 34
    move-result-wide v2

    .line 35
    iput-wide v2, v1, LC6/v;->B:J

    .line 36
    .line 37
    :cond_2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 38
    .line 39
    .line 40
    move-result-wide v2

    .line 41
    iget-wide v4, v1, LC6/v;->B:J

    .line 42
    .line 43
    sub-long/2addr v2, v4

    .line 44
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getImageInfo()Landroidx/camera/core/ImageInfo;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    invoke-interface {v4}, Landroidx/camera/core/ImageInfo;->getRotationDegrees()I

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    invoke-static {v0, v4}, Lcom/google/mlkit/vision/common/InputImage;->fromMediaImage(Landroid/media/Image;I)Lcom/google/mlkit/vision/common/InputImage;

    .line 53
    .line 54
    .line 55
    move-result-object v5

    .line 56
    const-string v0, "fromMediaImage(...)"

    .line 57
    .line 58
    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    iget-object v0, v1, LC6/v;->Q:Lxf/t;

    .line 62
    .line 63
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v0, Lcom/google/mlkit/vision/face/FaceDetector;

    .line 68
    .line 69
    invoke-interface {v0, v5}, Lcom/google/mlkit/vision/face/FaceDetector;->process(Lcom/google/mlkit/vision/common/InputImage;)Lcom/google/android/gms/tasks/Task;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    new-instance v0, LC6/q;

    .line 74
    .line 75
    const/4 v6, 0x0

    .line 76
    move-object v4, p1

    .line 77
    invoke-direct/range {v0 .. v6}, LC6/q;-><init>(Landroidx/lifecycle/a0;JLandroidx/camera/core/ImageProxy;Lcom/google/mlkit/vision/common/InputImage;I)V

    .line 78
    .line 79
    .line 80
    new-instance p1, LA8/a;

    .line 81
    .line 82
    const/16 v2, 0x11

    .line 83
    .line 84
    invoke-direct {p1, v0, v2}, LA8/a;-><init>(Ljava/lang/Object;I)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v7, p1}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    new-instance v0, LC6/c;

    .line 92
    .line 93
    invoke-direct {v0, v1}, LC6/c;-><init>(LC6/v;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {p1, v0}, Lcom/google/android/gms/tasks/Task;->addOnFailureListener(Lcom/google/android/gms/tasks/OnFailureListener;)Lcom/google/android/gms/tasks/Task;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    new-instance v0, LC6/r;

    .line 101
    .line 102
    const/4 v1, 0x0

    .line 103
    invoke-direct {v0, v4, v1}, LC6/r;-><init>(Landroidx/camera/core/ImageProxy;I)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {p1, v0}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    .line 107
    .line 108
    .line 109
    return-void

    .line 110
    :goto_0
    invoke-interface {v4}, Landroidx/camera/core/ImageProxy;->close()V

    .line 111
    .line 112
    .line 113
    return-void
.end method

.method public onFailure(Ljava/lang/Exception;)V
    .locals 11

    .line 1
    const-string v0, "exception"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "Error detecting faces"

    .line 7
    .line 8
    invoke-static {p1}, Lt6/a;->b(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget-object p1, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 12
    .line 13
    invoke-virtual {p1}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->detectError()V

    .line 14
    .line 15
    .line 16
    new-instance p1, Lcom/palmpay/lib/liveness/result/LiveIDResult$Error;

    .line 17
    .line 18
    new-instance v0, Lcom/palmpay/lib/liveness/model/LiveIDException;

    .line 19
    .line 20
    sget-object v1, LD6/f;->p:LD6/f;

    .line 21
    .line 22
    move-object v2, v1

    .line 23
    iget-object v1, v2, LD6/f;->a:Ljava/lang/String;

    .line 24
    .line 25
    const/4 v3, 0x0

    .line 26
    const/4 v4, 0x0

    .line 27
    iget-object v2, v2, LD6/f;->b:Ljava/lang/String;

    .line 28
    .line 29
    const/16 v5, 0xc

    .line 30
    .line 31
    const/4 v6, 0x0

    .line 32
    invoke-direct/range {v0 .. v6}, Lcom/palmpay/lib/liveness/model/LiveIDException;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 33
    .line 34
    .line 35
    invoke-direct {p1, v0}, Lcom/palmpay/lib/liveness/result/LiveIDResult$Error;-><init>(Ljava/lang/Throwable;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, LC6/c;->a:LC6/v;

    .line 39
    .line 40
    iput-object p1, v0, LC6/v;->t:Lcom/palmpay/lib/liveness/result/LiveIDResult;

    .line 41
    .line 42
    :cond_0
    iget-object p1, v0, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 43
    .line 44
    invoke-virtual {p1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    move-object v2, v1

    .line 49
    check-cast v2, LD6/i;

    .line 50
    .line 51
    sget-object v7, LD6/g;->c:LD6/g;

    .line 52
    .line 53
    const/4 v8, 0x0

    .line 54
    const/4 v9, 0x0

    .line 55
    const/4 v3, 0x0

    .line 56
    const/4 v4, 0x0

    .line 57
    const/4 v5, 0x0

    .line 58
    const/4 v6, 0x0

    .line 59
    const/16 v10, 0x4f

    .line 60
    .line 61
    invoke-static/range {v2 .. v10}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-virtual {p1, v1, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    if-eqz p1, :cond_0

    .line 70
    .line 71
    return-void
.end method
