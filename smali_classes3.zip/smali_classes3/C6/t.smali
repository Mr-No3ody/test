.class public final LC6/t;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:J

.field public b:I

.field public synthetic c:Ljava/lang/Object;

.field public final synthetic d:I

.field public final synthetic e:Ljava/util/ArrayList;

.field public final synthetic f:Ljava/io/File;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic i:LC6/v;

.field public final synthetic j:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/util/ArrayList;Ljava/io/File;Ljava/lang/String;LC6/v;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput p1, p0, LC6/t;->d:I

    .line 2
    .line 3
    iput-object p2, p0, LC6/t;->e:Ljava/util/ArrayList;

    .line 4
    .line 5
    iput-object p3, p0, LC6/t;->f:Ljava/io/File;

    .line 6
    .line 7
    iput-object p4, p0, LC6/t;->g:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p5, p0, LC6/t;->i:LC6/v;

    .line 10
    .line 11
    iput-object p6, p0, LC6/t;->j:Ljava/lang/String;

    .line 12
    .line 13
    const/4 p1, 0x2

    .line 14
    invoke-direct {p0, p1, p7}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 8

    .line 1
    new-instance v0, LC6/t;

    .line 2
    .line 3
    iget-object v6, p0, LC6/t;->j:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v2, p0, LC6/t;->e:Ljava/util/ArrayList;

    .line 6
    .line 7
    iget-object v4, p0, LC6/t;->g:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v5, p0, LC6/t;->i:LC6/v;

    .line 10
    .line 11
    iget v1, p0, LC6/t;->d:I

    .line 12
    .line 13
    iget-object v3, p0, LC6/t;->f:Ljava/io/File;

    .line 14
    .line 15
    move-object v7, p2

    .line 16
    invoke-direct/range {v0 .. v7}, LC6/t;-><init>(ILjava/util/ArrayList;Ljava/io/File;Ljava/lang/String;LC6/v;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 17
    .line 18
    .line 19
    iput-object p1, v0, LC6/t;->c:Ljava/lang/Object;

    .line 20
    .line 21
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LC6/t;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LC6/t;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LC6/t;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    sget-object v2, LEf/a;->a:LEf/a;

    .line 5
    .line 6
    iget v3, v0, LC6/t;->b:I

    .line 7
    .line 8
    const/4 v4, 0x4

    .line 9
    const/4 v5, 0x3

    .line 10
    const-string v6, ""

    .line 11
    .line 12
    const-string v7, "ms"

    .line 13
    .line 14
    const/4 v8, 0x0

    .line 15
    const/4 v9, 0x1

    .line 16
    iget-object v10, v0, LC6/t;->i:LC6/v;

    .line 17
    .line 18
    if-eqz v3, :cond_4

    .line 19
    .line 20
    if-eq v3, v9, :cond_3

    .line 21
    .line 22
    if-eq v3, v1, :cond_2

    .line 23
    .line 24
    if-eq v3, v5, :cond_1

    .line 25
    .line 26
    if-ne v3, v4, :cond_0

    .line 27
    .line 28
    iget-wide v2, v0, LC6/t;->a:J

    .line 29
    .line 30
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    move-wide v11, v2

    .line 34
    move-object/from16 v3, p1

    .line 35
    .line 36
    goto/16 :goto_7

    .line 37
    .line 38
    :cond_0
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw v1

    .line 46
    :cond_1
    iget-object v3, v0, LC6/t;->c:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v3, Lcom/palmpay/lib/liveness/model/CheckRequest;

    .line 49
    .line 50
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    move-object v4, v3

    .line 54
    move-object/from16 v3, p1

    .line 55
    .line 56
    goto/16 :goto_5

    .line 57
    .line 58
    :cond_2
    iget-wide v11, v0, LC6/t;->a:J

    .line 59
    .line 60
    iget-object v3, v0, LC6/t;->c:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v3, Lkotlinx/coroutines/CoroutineScope;

    .line 63
    .line 64
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    goto/16 :goto_2

    .line 68
    .line 69
    :cond_3
    iget-wide v11, v0, LC6/t;->a:J

    .line 70
    .line 71
    iget-object v3, v0, LC6/t;->c:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v3, Lkotlinx/coroutines/CoroutineScope;

    .line 74
    .line 75
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_4
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    iget-object v3, v0, LC6/t;->c:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast v3, Lkotlinx/coroutines/CoroutineScope;

    .line 85
    .line 86
    iget v11, v0, LC6/t;->d:I

    .line 87
    .line 88
    iget-object v12, v0, LC6/t;->g:Ljava/lang/String;

    .line 89
    .line 90
    iget-object v13, v0, LC6/t;->f:Ljava/io/File;

    .line 91
    .line 92
    if-ne v9, v11, :cond_7

    .line 93
    .line 94
    iget-object v11, v0, LC6/t;->e:Ljava/util/ArrayList;

    .line 95
    .line 96
    new-instance v14, Ljava/util/ArrayList;

    .line 97
    .line 98
    const/16 v15, 0xa

    .line 99
    .line 100
    invoke-static {v11, v15}, Lkotlin/collections/r;->l(Ljava/lang/Iterable;I)I

    .line 101
    .line 102
    .line 103
    move-result v15

    .line 104
    invoke-direct {v14, v15}, Ljava/util/ArrayList;-><init>(I)V

    .line 105
    .line 106
    .line 107
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 108
    .line 109
    .line 110
    move-result-object v11

    .line 111
    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 112
    .line 113
    .line 114
    move-result v15

    .line 115
    const-string v4, "<this>"

    .line 116
    .line 117
    if-eqz v15, :cond_5

    .line 118
    .line 119
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v15

    .line 123
    check-cast v15, Ljava/io/File;

    .line 124
    .line 125
    invoke-static {v15, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    new-instance v4, Lcom/palmpay/lib/liveness/model/UploadImageInfo;

    .line 129
    .line 130
    sget-object v5, Lcom/palmpay/lib/liveness/model/ImageType;->LivenessJpgFile:Lcom/palmpay/lib/liveness/model/ImageType;

    .line 131
    .line 132
    invoke-direct {v4, v5, v15}, Lcom/palmpay/lib/liveness/model/UploadImageInfo;-><init>(Lcom/palmpay/lib/liveness/model/ImageType;Ljava/io/File;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v14, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    const/4 v4, 0x4

    .line 139
    const/4 v5, 0x3

    .line 140
    goto :goto_0

    .line 141
    :cond_5
    invoke-static {v13, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    new-instance v4, Lcom/palmpay/lib/liveness/model/UploadImageInfo;

    .line 145
    .line 146
    sget-object v5, Lcom/palmpay/lib/liveness/model/ImageType;->SelfieJpgFile:Lcom/palmpay/lib/liveness/model/ImageType;

    .line 147
    .line 148
    invoke-direct {v4, v5, v13}, Lcom/palmpay/lib/liveness/model/UploadImageInfo;-><init>(Lcom/palmpay/lib/liveness/model/ImageType;Ljava/io/File;)V

    .line 149
    .line 150
    .line 151
    new-instance v5, Lcom/palmpay/lib/liveness/model/UploadRequest;

    .line 152
    .line 153
    invoke-static {v14, v4}, Lkotlin/collections/CollectionsKt;->Q(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    invoke-direct {v5, v4}, Lcom/palmpay/lib/liveness/model/UploadRequest;-><init>(Ljava/util/List;)V

    .line 158
    .line 159
    .line 160
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 161
    .line 162
    .line 163
    move-result-wide v13

    .line 164
    sget-object v4, Lp6/p;->a:Lp6/p;

    .line 165
    .line 166
    invoke-static {}, Lp6/p;->h()Lcom/palmpay/lib/liveness/net/UploadApi;

    .line 167
    .line 168
    .line 169
    move-result-object v4

    .line 170
    iput-object v3, v0, LC6/t;->c:Ljava/lang/Object;

    .line 171
    .line 172
    iput-wide v13, v0, LC6/t;->a:J

    .line 173
    .line 174
    iput v9, v0, LC6/t;->b:I

    .line 175
    .line 176
    invoke-interface {v4, v12, v5, v0}, Lcom/palmpay/lib/liveness/net/UploadApi;->upload(Ljava/lang/String;Lcom/palmpay/lib/liveness/model/UploadRequest;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v4

    .line 180
    if-ne v4, v2, :cond_6

    .line 181
    .line 182
    goto/16 :goto_6

    .line 183
    .line 184
    :cond_6
    move-wide v11, v13

    .line 185
    :goto_1
    sget v4, Lt6/a;->a:I

    .line 186
    .line 187
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 188
    .line 189
    .line 190
    move-result-wide v4

    .line 191
    sub-long/2addr v4, v11

    .line 192
    new-instance v11, Ljava/lang/StringBuilder;

    .line 193
    .line 194
    const-string v12, "upload cost : "

    .line 195
    .line 196
    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v11, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 200
    .line 201
    .line 202
    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    invoke-static {v4}, Lt6/a;->a(Ljava/lang/String;)V

    .line 210
    .line 211
    .line 212
    goto :goto_3

    .line 213
    :cond_7
    new-instance v4, Lcom/palmpay/lib/liveness/model/UploadRequestV2;

    .line 214
    .line 215
    invoke-direct {v4, v13}, Lcom/palmpay/lib/liveness/model/UploadRequestV2;-><init>(Ljava/io/File;)V

    .line 216
    .line 217
    .line 218
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 219
    .line 220
    .line 221
    move-result-wide v13

    .line 222
    sget-object v5, Lp6/p;->a:Lp6/p;

    .line 223
    .line 224
    invoke-static {}, Lp6/p;->h()Lcom/palmpay/lib/liveness/net/UploadApi;

    .line 225
    .line 226
    .line 227
    move-result-object v5

    .line 228
    iput-object v3, v0, LC6/t;->c:Ljava/lang/Object;

    .line 229
    .line 230
    iput-wide v13, v0, LC6/t;->a:J

    .line 231
    .line 232
    iput v1, v0, LC6/t;->b:I

    .line 233
    .line 234
    invoke-interface {v5, v12, v4, v0}, Lcom/palmpay/lib/liveness/net/UploadApi;->uploadV2(Ljava/lang/String;Lcom/palmpay/lib/liveness/model/UploadRequestV2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v4

    .line 238
    if-ne v4, v2, :cond_8

    .line 239
    .line 240
    goto/16 :goto_6

    .line 241
    .line 242
    :cond_8
    move-wide v11, v13

    .line 243
    :goto_2
    sget v4, Lt6/a;->a:I

    .line 244
    .line 245
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 246
    .line 247
    .line 248
    move-result-wide v4

    .line 249
    sub-long/2addr v4, v11

    .line 250
    new-instance v11, Ljava/lang/StringBuilder;

    .line 251
    .line 252
    const-string v12, "uploadV2 cost : "

    .line 253
    .line 254
    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 255
    .line 256
    .line 257
    invoke-virtual {v11, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 258
    .line 259
    .line 260
    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 261
    .line 262
    .line 263
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 264
    .line 265
    .line 266
    move-result-object v4

    .line 267
    invoke-static {v4}, Lt6/a;->a(Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    :goto_3
    sget-object v4, Lp6/p;->d:Lr6/a;

    .line 271
    .line 272
    if-eqz v4, :cond_c

    .line 273
    .line 274
    iget-object v4, v4, Lr6/a;->e:Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;

    .line 275
    .line 276
    if-eqz v4, :cond_c

    .line 277
    .line 278
    sget-object v5, Lv6/e;->f:Lv6/d;

    .line 279
    .line 280
    iget-object v11, v5, Lv6/d;->a:Ljava/lang/String;

    .line 281
    .line 282
    iget-object v5, v5, Lv6/d;->b:Ljava/lang/String;

    .line 283
    .line 284
    new-instance v12, Lkotlin/Pair;

    .line 285
    .line 286
    const-string v13, "event_desc"

    .line 287
    .line 288
    invoke-direct {v12, v13, v5}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 289
    .line 290
    .line 291
    sget-object v5, Lp6/p;->j:Ljava/lang/Integer;

    .line 292
    .line 293
    if-eqz v5, :cond_9

    .line 294
    .line 295
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 296
    .line 297
    .line 298
    move-result v5

    .line 299
    goto :goto_4

    .line 300
    :cond_9
    const/4 v5, -0x1

    .line 301
    :goto_4
    new-instance v13, Ljava/lang/Integer;

    .line 302
    .line 303
    invoke-direct {v13, v5}, Ljava/lang/Integer;-><init>(I)V

    .line 304
    .line 305
    .line 306
    new-instance v5, Lkotlin/Pair;

    .line 307
    .line 308
    const-string v14, "scene"

    .line 309
    .line 310
    invoke-direct {v5, v14, v13}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 311
    .line 312
    .line 313
    iget-object v13, v10, LC6/v;->A:Ljava/lang/String;

    .line 314
    .line 315
    if-nez v13, :cond_a

    .line 316
    .line 317
    move-object v13, v6

    .line 318
    :cond_a
    new-instance v14, Lkotlin/Pair;

    .line 319
    .line 320
    const-string v15, "transactionId"

    .line 321
    .line 322
    invoke-direct {v14, v15, v13}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 323
    .line 324
    .line 325
    sget-object v13, Lp6/p;->i:Ljava/lang/String;

    .line 326
    .line 327
    if-nez v13, :cond_b

    .line 328
    .line 329
    move-object v13, v6

    .line 330
    :cond_b
    new-instance v15, Lkotlin/Pair;

    .line 331
    .line 332
    const-string v9, "uuid"

    .line 333
    .line 334
    invoke-direct {v15, v9, v13}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 335
    .line 336
    .line 337
    filled-new-array {v12, v5, v14, v15}, [Lkotlin/Pair;

    .line 338
    .line 339
    .line 340
    move-result-object v5

    .line 341
    invoke-static {v5}, Lkotlin/collections/G;->h([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 342
    .line 343
    .line 344
    move-result-object v5

    .line 345
    invoke-interface {v4, v11, v5}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;->report(Ljava/lang/String;Ljava/util/Map;)V

    .line 346
    .line 347
    .line 348
    :cond_c
    new-instance v19, Lcom/palmpay/lib/liveness/model/CheckRequest;

    .line 349
    .line 350
    iget-object v4, v0, LC6/t;->j:Ljava/lang/String;

    .line 351
    .line 352
    const/16 v22, 0x0

    .line 353
    .line 354
    const/16 v23, 0x0

    .line 355
    .line 356
    const/16 v21, 0x0

    .line 357
    .line 358
    const/16 v24, 0xc

    .line 359
    .line 360
    const/16 v25, 0x0

    .line 361
    .line 362
    move-object/from16 v20, v4

    .line 363
    .line 364
    invoke-direct/range {v19 .. v25}, Lcom/palmpay/lib/liveness/model/CheckRequest;-><init>(Ljava/lang/String;IILjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 365
    .line 366
    .line 367
    move-object/from16 v4, v19

    .line 368
    .line 369
    sget-object v5, LWf/I;->a:Lcg/f;

    .line 370
    .line 371
    sget-object v5, Lcg/e;->c:Lcg/e;

    .line 372
    .line 373
    new-instance v9, LC6/s;

    .line 374
    .line 375
    invoke-direct {v9, v1, v8}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 376
    .line 377
    .line 378
    invoke-static {v3, v5, v9, v1}, LWf/y;->d(Lkotlinx/coroutines/CoroutineScope;Lcg/e;Lkotlin/jvm/functions/Function2;I)LWf/B;

    .line 379
    .line 380
    .line 381
    move-result-object v3

    .line 382
    iput-object v4, v0, LC6/t;->c:Ljava/lang/Object;

    .line 383
    .line 384
    const/4 v5, 0x3

    .line 385
    iput v5, v0, LC6/t;->b:I

    .line 386
    .line 387
    invoke-virtual {v3, v0}, LWf/n0;->c(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    move-result-object v3

    .line 391
    sget-object v5, LEf/a;->a:LEf/a;

    .line 392
    .line 393
    if-ne v3, v2, :cond_d

    .line 394
    .line 395
    goto :goto_6

    .line 396
    :cond_d
    :goto_5
    check-cast v3, Ljava/lang/Boolean;

    .line 397
    .line 398
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 399
    .line 400
    .line 401
    move-result v3

    .line 402
    if-eqz v3, :cond_e

    .line 403
    .line 404
    const/4 v3, 0x1

    .line 405
    invoke-virtual {v4, v3}, Lcom/palmpay/lib/liveness/model/CheckRequest;->setSystemType(I)V

    .line 406
    .line 407
    .line 408
    :cond_e
    sget-object v3, Lp6/p;->a:Lp6/p;

    .line 409
    .line 410
    invoke-static {}, Lp6/p;->d()Ljava/lang/String;

    .line 411
    .line 412
    .line 413
    move-result-object v3

    .line 414
    invoke-virtual {v4, v3}, Lcom/palmpay/lib/liveness/model/CheckRequest;->setDeviceFingerprint(Ljava/lang/String;)V

    .line 415
    .line 416
    .line 417
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 418
    .line 419
    .line 420
    move-result-wide v11

    .line 421
    sget-object v3, Lp6/p;->a:Lp6/p;

    .line 422
    .line 423
    invoke-static {}, Lp6/p;->e()Lcom/palmpay/lib/liveness/net/LiveApi;

    .line 424
    .line 425
    .line 426
    move-result-object v3

    .line 427
    iput-object v8, v0, LC6/t;->c:Ljava/lang/Object;

    .line 428
    .line 429
    iput-wide v11, v0, LC6/t;->a:J

    .line 430
    .line 431
    const/4 v5, 0x4

    .line 432
    iput v5, v0, LC6/t;->b:I

    .line 433
    .line 434
    const-string v5, "/api/validator/liveness/checkV2"

    .line 435
    .line 436
    invoke-interface {v3, v5, v4, v0}, Lcom/palmpay/lib/liveness/net/LiveApi;->check(Ljava/lang/String;Lcom/palmpay/lib/liveness/model/CheckRequest;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 437
    .line 438
    .line 439
    move-result-object v3

    .line 440
    if-ne v3, v2, :cond_f

    .line 441
    .line 442
    :goto_6
    return-object v2

    .line 443
    :cond_f
    :goto_7
    check-cast v3, Lcom/palmpay/lib/liveness/model/CheckResponse;

    .line 444
    .line 445
    sget v2, Lt6/a;->a:I

    .line 446
    .line 447
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 448
    .line 449
    .line 450
    move-result-wide v4

    .line 451
    sub-long/2addr v4, v11

    .line 452
    new-instance v2, Ljava/lang/StringBuilder;

    .line 453
    .line 454
    const-string v9, "check cost : "

    .line 455
    .line 456
    invoke-direct {v2, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 457
    .line 458
    .line 459
    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 460
    .line 461
    .line 462
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 463
    .line 464
    .line 465
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 466
    .line 467
    .line 468
    move-result-object v2

    .line 469
    invoke-static {v2}, Lt6/a;->a(Ljava/lang/String;)V

    .line 470
    .line 471
    .line 472
    invoke-static {v3}, Landroidx/camera/core/impl/utils/executor/g;->A(Lcom/palmpay/lib/liveness/model/LiveBaseResponse;)Z

    .line 473
    .line 474
    .line 475
    move-result v2

    .line 476
    if-eqz v2, :cond_11

    .line 477
    .line 478
    new-instance v1, Lcom/palmpay/lib/liveness/result/LiveIDResult$Success;

    .line 479
    .line 480
    new-instance v2, Lcom/palmpay/lib/liveness/result/LiveSelfieResult;

    .line 481
    .line 482
    invoke-direct {v2, v3}, Lcom/palmpay/lib/liveness/result/LiveSelfieResult;-><init>(Lcom/palmpay/lib/liveness/model/CheckResponse;)V

    .line 483
    .line 484
    .line 485
    invoke-direct {v1, v2}, Lcom/palmpay/lib/liveness/result/LiveIDResult$Success;-><init>(Landroid/os/Parcelable;)V

    .line 486
    .line 487
    .line 488
    iput-object v1, v10, LC6/v;->t:Lcom/palmpay/lib/liveness/result/LiveIDResult;

    .line 489
    .line 490
    :cond_10
    iget-object v1, v10, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 491
    .line 492
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 493
    .line 494
    .line 495
    move-result-object v2

    .line 496
    move-object v11, v2

    .line 497
    check-cast v11, LD6/i;

    .line 498
    .line 499
    sget-object v16, LD6/g;->b:LD6/g;

    .line 500
    .line 501
    const/16 v17, 0x0

    .line 502
    .line 503
    const/16 v18, 0x0

    .line 504
    .line 505
    const/4 v12, 0x0

    .line 506
    const/4 v13, 0x0

    .line 507
    const/4 v14, 0x0

    .line 508
    const/4 v15, 0x0

    .line 509
    const/16 v19, 0x6f

    .line 510
    .line 511
    invoke-static/range {v11 .. v19}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 512
    .line 513
    .line 514
    move-result-object v3

    .line 515
    invoke-virtual {v1, v2, v3}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 516
    .line 517
    .line 518
    move-result v1

    .line 519
    if-eqz v1, :cond_10

    .line 520
    .line 521
    goto :goto_9

    .line 522
    :cond_11
    invoke-virtual {v3}, Lcom/palmpay/lib/liveness/model/LiveBaseResponse;->getRespCode()Ljava/lang/String;

    .line 523
    .line 524
    .line 525
    move-result-object v2

    .line 526
    if-nez v2, :cond_12

    .line 527
    .line 528
    move-object v12, v6

    .line 529
    goto :goto_8

    .line 530
    :cond_12
    move-object v12, v2

    .line 531
    :goto_8
    invoke-virtual {v3}, Lcom/palmpay/lib/liveness/model/LiveBaseResponse;->getRespMsg()Ljava/lang/String;

    .line 532
    .line 533
    .line 534
    move-result-object v2

    .line 535
    if-nez v2, :cond_13

    .line 536
    .line 537
    const-string v2, "Unknown Error"

    .line 538
    .line 539
    :cond_13
    new-instance v4, Lcom/palmpay/lib/liveness/result/LiveIDResult$Error;

    .line 540
    .line 541
    new-instance v11, Lcom/palmpay/lib/liveness/model/LiveIDException;

    .line 542
    .line 543
    const-string v5, "["

    .line 544
    .line 545
    const-string v6, "]"

    .line 546
    .line 547
    invoke-static {v2, v5, v12, v6}, LN8/q0;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 548
    .line 549
    .line 550
    move-result-object v13

    .line 551
    invoke-virtual {v3}, Lcom/palmpay/lib/liveness/model/LiveBaseResponse;->getAddition()Ljava/lang/String;

    .line 552
    .line 553
    .line 554
    move-result-object v15

    .line 555
    const/16 v17, 0x0

    .line 556
    .line 557
    const/4 v14, 0x0

    .line 558
    const/16 v16, 0x4

    .line 559
    .line 560
    invoke-direct/range {v11 .. v17}, Lcom/palmpay/lib/liveness/model/LiveIDException;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 561
    .line 562
    .line 563
    invoke-direct {v4, v11}, Lcom/palmpay/lib/liveness/result/LiveIDResult$Error;-><init>(Ljava/lang/Throwable;)V

    .line 564
    .line 565
    .line 566
    iput-object v4, v10, LC6/v;->t:Lcom/palmpay/lib/liveness/result/LiveIDResult;

    .line 567
    .line 568
    iget-object v2, v10, LC6/v;->v:Ljava/util/ArrayList;

    .line 569
    .line 570
    new-instance v4, LAb/B;

    .line 571
    .line 572
    invoke-direct {v4, v1}, LAb/B;-><init>(I)V

    .line 573
    .line 574
    .line 575
    invoke-static {v2, v4}, Lkotlin/collections/v;->r(Ljava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 576
    .line 577
    .line 578
    iget-object v1, v10, LC6/v;->w:Ljava/io/File;

    .line 579
    .line 580
    if-eqz v1, :cond_14

    .line 581
    .line 582
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    .line 583
    .line 584
    .line 585
    :cond_14
    iput-object v8, v10, LC6/v;->w:Ljava/io/File;

    .line 586
    .line 587
    :cond_15
    iget-object v1, v10, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 588
    .line 589
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 590
    .line 591
    .line 592
    move-result-object v2

    .line 593
    move-object v11, v2

    .line 594
    check-cast v11, LD6/i;

    .line 595
    .line 596
    sget-object v16, LD6/g;->c:LD6/g;

    .line 597
    .line 598
    invoke-virtual {v3}, Lcom/palmpay/lib/liveness/model/LiveBaseResponse;->getRespMsg()Ljava/lang/String;

    .line 599
    .line 600
    .line 601
    move-result-object v17

    .line 602
    const/4 v15, 0x0

    .line 603
    const/16 v18, 0x0

    .line 604
    .line 605
    const/4 v12, 0x0

    .line 606
    const/4 v13, 0x0

    .line 607
    const/4 v14, 0x0

    .line 608
    const/16 v19, 0x47

    .line 609
    .line 610
    invoke-static/range {v11 .. v19}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 611
    .line 612
    .line 613
    move-result-object v4

    .line 614
    invoke-virtual {v1, v2, v4}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 615
    .line 616
    .line 617
    move-result v1

    .line 618
    if-eqz v1, :cond_15

    .line 619
    .line 620
    :goto_9
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 621
    .line 622
    return-object v1
.end method
