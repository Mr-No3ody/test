.class public final LC6/v;
.super Landroidx/lifecycle/a0;
.source "SourceFile"


# instance fields
.field public A:Ljava/lang/String;

.field public B:J

.field public C:Z

.field public H:Z

.field public L:I

.field public final M:Lcom/google/mlkit/vision/face/FaceDetectorOptions;

.field public final Q:Lxf/t;

.field public X:LC6/o;

.field public Y:Ljava/lang/Boolean;

.field public final d:I

.field public final e:I

.field public final f:Landroid/util/Size;

.field public final g:J

.field public final i:F

.field public final j:I

.field public final o:Lkotlinx/coroutines/flow/g0;

.field public final p:Lkotlinx/coroutines/flow/S;

.field public t:Lcom/palmpay/lib/liveness/result/LiveIDResult;

.field public final v:Ljava/util/ArrayList;

.field public w:Ljava/io/File;


# direct methods
.method public constructor <init>()V
    .locals 10

    .line 1
    invoke-direct {p0}, Landroidx/lifecycle/a0;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, v0, Lr6/a;->n:Ljava/lang/Integer;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move v0, v1

    .line 19
    :goto_0
    iput v0, p0, LC6/v;->d:I

    .line 20
    .line 21
    add-int/2addr v0, v1

    .line 22
    iput v0, p0, LC6/v;->e:I

    .line 23
    .line 24
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 25
    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    iget-object v2, v0, Lr6/a;->m:Landroid/util/Size;

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_1
    const/4 v2, 0x0

    .line 32
    :goto_1
    iput-object v2, p0, LC6/v;->f:Landroid/util/Size;

    .line 33
    .line 34
    if-eqz v0, :cond_2

    .line 35
    .line 36
    iget-object v0, v0, Lr6/a;->o:Ljava/lang/Long;

    .line 37
    .line 38
    if-eqz v0, :cond_2

    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 41
    .line 42
    .line 43
    move-result-wide v2

    .line 44
    goto :goto_2

    .line 45
    :cond_2
    const-wide/16 v2, 0xbb8

    .line 46
    .line 47
    :goto_2
    iput-wide v2, p0, LC6/v;->g:J

    .line 48
    .line 49
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 50
    .line 51
    if-eqz v0, :cond_3

    .line 52
    .line 53
    iget-object v2, v0, Lr6/a;->k:Ljava/lang/Float;

    .line 54
    .line 55
    :cond_3
    if-eqz v0, :cond_4

    .line 56
    .line 57
    iget-object v0, v0, Lr6/a;->l:Ljava/lang/Float;

    .line 58
    .line 59
    if-eqz v0, :cond_4

    .line 60
    .line 61
    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    goto :goto_3

    .line 66
    :cond_4
    const/high16 v0, 0x3f000000    # 0.5f

    .line 67
    .line 68
    :goto_3
    iput v0, p0, LC6/v;->i:F

    .line 69
    .line 70
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 71
    .line 72
    if-eqz v0, :cond_5

    .line 73
    .line 74
    iget-object v0, v0, Lr6/a;->q:Ljava/lang/Integer;

    .line 75
    .line 76
    if-eqz v0, :cond_5

    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    goto :goto_4

    .line 83
    :cond_5
    const/16 v0, 0x9

    .line 84
    .line 85
    :goto_4
    sub-int/2addr v0, v1

    .line 86
    iput v0, p0, LC6/v;->j:I

    .line 87
    .line 88
    new-instance v0, LD6/i;

    .line 89
    .line 90
    invoke-direct {v0}, LD6/i;-><init>()V

    .line 91
    .line 92
    .line 93
    invoke-static {v0}, Lkotlinx/coroutines/flow/X;->a(Ljava/lang/Object;)Lkotlinx/coroutines/flow/g0;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    iput-object v0, p0, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 98
    .line 99
    invoke-static {v0}, Lkotlinx/coroutines/flow/X;->d(Lkotlinx/coroutines/flow/g0;)Lkotlinx/coroutines/flow/S;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    sget-wide v2, LD6/o;->a:J

    .line 104
    .line 105
    invoke-static {v0, v2, v3}, Lkotlinx/coroutines/flow/X;->h(Lkotlinx/coroutines/flow/S;J)Lkotlinx/coroutines/flow/Flow;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-static {p0}, Landroidx/lifecycle/V;->h(Landroidx/lifecycle/a0;)Lkotlinx/coroutines/CoroutineScope;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    sget-object v3, Lkotlinx/coroutines/flow/SharingStarted;->n0:Lkotlinx/coroutines/flow/SharingStarted$a;

    .line 114
    .line 115
    const-wide/16 v4, 0x0

    .line 116
    .line 117
    const-wide/16 v6, 0x0

    .line 118
    .line 119
    const/4 v8, 0x3

    .line 120
    const/4 v9, 0x0

    .line 121
    invoke-static/range {v3 .. v9}, Lkotlinx/coroutines/flow/SharingStarted$a;->WhileSubscribed$default(Lkotlinx/coroutines/flow/SharingStarted$a;JJILjava/lang/Object;)Lkotlinx/coroutines/flow/SharingStarted;

    .line 122
    .line 123
    .line 124
    move-result-object v3

    .line 125
    new-instance v4, LD6/i;

    .line 126
    .line 127
    invoke-direct {v4}, LD6/i;-><init>()V

    .line 128
    .line 129
    .line 130
    invoke-static {v0, v2, v3, v4}, Lkotlinx/coroutines/flow/X;->p(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/CoroutineScope;Lkotlinx/coroutines/flow/SharingStarted;Ljava/lang/Object;)Lkotlinx/coroutines/flow/S;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    iput-object v0, p0, LC6/v;->p:Lkotlinx/coroutines/flow/S;

    .line 135
    .line 136
    new-instance v0, Ljava/util/ArrayList;

    .line 137
    .line 138
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 139
    .line 140
    .line 141
    iput-object v0, p0, LC6/v;->v:Ljava/util/ArrayList;

    .line 142
    .line 143
    iput-boolean v1, p0, LC6/v;->C:Z

    .line 144
    .line 145
    new-instance v0, Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;

    .line 146
    .line 147
    invoke-direct {v0}, Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;-><init>()V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v0, v1}, Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;->setPerformanceMode(I)Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;

    .line 151
    .line 152
    .line 153
    invoke-virtual {v0, v1}, Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;->setLandmarkMode(I)Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;

    .line 154
    .line 155
    .line 156
    const/4 v1, 0x2

    .line 157
    invoke-virtual {v0, v1}, Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;->setClassificationMode(I)Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;

    .line 158
    .line 159
    .line 160
    invoke-virtual {v0}, Lcom/google/mlkit/vision/face/FaceDetectorOptions$Builder;->build()Lcom/google/mlkit/vision/face/FaceDetectorOptions;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    const-string v1, "build(...)"

    .line 165
    .line 166
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    iput-object v0, p0, LC6/v;->M:Lcom/google/mlkit/vision/face/FaceDetectorOptions;

    .line 170
    .line 171
    new-instance v0, LAe/j;

    .line 172
    .line 173
    const/4 v1, 0x3

    .line 174
    invoke-direct {v0, p0, v1}, LAe/j;-><init>(Ljava/lang/Object;I)V

    .line 175
    .line 176
    .line 177
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    iput-object v0, p0, LC6/v;->Q:Lxf/t;

    .line 182
    .line 183
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 184
    .line 185
    iput-object v0, p0, LC6/v;->Y:Ljava/lang/Boolean;

    .line 186
    .line 187
    return-void
.end method


# virtual methods
.method public final d()V
    .locals 11

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    iput-wide v0, p0, LC6/v;->B:J

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, LC6/v;->C:Z

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-boolean v0, p0, LC6/v;->H:Z

    .line 10
    .line 11
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 12
    .line 13
    iput-object v0, p0, LC6/v;->Y:Ljava/lang/Boolean;

    .line 14
    .line 15
    :cond_0
    iget-object v0, p0, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 16
    .line 17
    invoke-virtual {v0}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    move-object v2, v1

    .line 22
    check-cast v2, LD6/i;

    .line 23
    .line 24
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 25
    .line 26
    const/4 v8, 0x0

    .line 27
    const/4 v9, 0x0

    .line 28
    const/4 v3, 0x0

    .line 29
    const/4 v4, 0x0

    .line 30
    const/4 v6, 0x0

    .line 31
    const/4 v7, 0x0

    .line 32
    const/16 v10, 0x6b

    .line 33
    .line 34
    invoke-static/range {v2 .. v10}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-virtual {v0, v1, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_0

    .line 43
    .line 44
    iget-object v0, p0, LC6/v;->X:LC6/o;

    .line 45
    .line 46
    if-eqz v0, :cond_1

    .line 47
    .line 48
    iget-object v1, v0, LC6/o;->h:Landroid/os/Handler;

    .line 49
    .line 50
    if-eqz v1, :cond_1

    .line 51
    .line 52
    new-instance v2, LC6/l;

    .line 53
    .line 54
    const/4 v3, 0x0

    .line 55
    invoke-direct {v2, v0, v3}, LC6/l;-><init>(LC6/o;I)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 59
    .line 60
    .line 61
    :cond_1
    return-void
.end method
