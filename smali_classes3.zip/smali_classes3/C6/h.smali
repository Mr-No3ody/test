.class public final LC6/h;
.super Lkotlin/jvm/internal/o;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/palmpay/lib/liveness/video/VideoActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/palmpay/lib/liveness/video/VideoActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, LC6/h;->a:I

    iput-object p1, p0, LC6/h;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/o;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LC6/h;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LC6/h;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 7
    .line 8
    invoke-virtual {v0}, Landroidx/activity/m;->getDefaultViewModelCreationExtras()Lz0/b;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const-string v1, "this.defaultViewModelCreationExtras"

    .line 13
    .line 14
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_0
    iget-object v0, p0, LC6/h;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 19
    .line 20
    invoke-virtual {v0}, Landroidx/activity/m;->getViewModelStore()Landroidx/lifecycle/i0;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const-string v1, "viewModelStore"

    .line 25
    .line 26
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    iget-object v0, p0, LC6/h;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 31
    .line 32
    invoke-virtual {v0}, Landroidx/activity/m;->getDefaultViewModelProviderFactory()Landroidx/lifecycle/ViewModelProvider$Factory;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    const-string v1, "defaultViewModelProviderFactory"

    .line 37
    .line 38
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    return-object v0

    .line 42
    nop

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
