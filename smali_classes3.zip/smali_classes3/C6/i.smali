.class public final LC6/i;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/palmpay/lib/liveness/video/VideoActivity;


# direct methods
.method public constructor <init>(Lcom/palmpay/lib/liveness/video/VideoActivity;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC6/i;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 1

    .line 1
    new-instance p1, LC6/i;

    .line 2
    .line 3
    iget-object v0, p0, LC6/i;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 4
    .line 5
    invoke-direct {p1, v0, p2}, LC6/i;-><init>(Lcom/palmpay/lib/liveness/video/VideoActivity;Lkotlin/coroutines/Continuation;)V

    .line 6
    .line 7
    .line 8
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LC6/i;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LC6/i;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LC6/i;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LC6/i;->a:I

    .line 4
    .line 5
    iget-object v2, p0, LC6/i;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    if-ne v1, v3, :cond_0

    .line 11
    .line 12
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 19
    .line 20
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    throw p1

    .line 24
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    sget-object p1, Landroidx/camera/lifecycle/h;->i:Landroidx/camera/lifecycle/f;

    .line 28
    .line 29
    invoke-virtual {p1, v2}, Landroidx/camera/lifecycle/f;->getInstance(Landroid/content/Context;)Lcom/google/common/util/concurrent/ListenableFuture;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iput v3, p0, LC6/i;->a:I

    .line 34
    .line 35
    invoke-static {p1, p0}, LG8/a;->h(Lcom/google/common/util/concurrent/ListenableFuture;LFf/c;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    if-ne p1, v0, :cond_2

    .line 40
    .line 41
    return-object v0

    .line 42
    :cond_2
    :goto_0
    check-cast p1, Landroidx/camera/lifecycle/h;

    .line 43
    .line 44
    invoke-virtual {p1}, Landroidx/camera/lifecycle/h;->unbindAll()V

    .line 45
    .line 46
    .line 47
    sget-object v0, LE/p;->b:LE/p;

    .line 48
    .line 49
    filled-new-array {v0}, [LE/p;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    const/4 v1, 0x0

    .line 54
    aget-object v0, v0, v1

    .line 55
    .line 56
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :try_start_0
    invoke-virtual {p1, v0}, Landroidx/camera/lifecycle/h;->hasCamera(LE/p;)Z

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    if-eqz v3, :cond_3

    .line 64
    .line 65
    new-array v1, v1, [LE/n0;

    .line 66
    .line 67
    invoke-virtual {p1, v2, v0, v1}, Landroidx/camera/lifecycle/h;->d(Landroidx/lifecycle/LifecycleOwner;LE/p;[LE/n0;)Landroidx/camera/lifecycle/LifecycleCamera;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    iget-object p1, p1, Landroidx/camera/lifecycle/LifecycleCamera;->c:Landroidx/camera/core/internal/f;

    .line 72
    .line 73
    iget-object p1, p1, Landroidx/camera/core/internal/f;->H:Landroidx/camera/core/impl/A0;

    .line 74
    .line 75
    sget-object v1, Landroidx/camera/video/s;->E:Ljava/util/Set;

    .line 76
    .line 77
    new-instance v1, Landroidx/camera/video/t;

    .line 78
    .line 79
    invoke-direct {v1, p1}, Landroidx/camera/video/t;-><init>(Landroidx/camera/core/impl/CameraInfoInternal;)V

    .line 80
    .line 81
    .line 82
    sget-object p1, LE/v;->d:LE/v;

    .line 83
    .line 84
    invoke-virtual {v1, p1}, Landroidx/camera/video/t;->getSupportedQualities(LE/v;)Ljava/util/List;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    iget-object v1, v2, Lcom/palmpay/lib/liveness/video/VideoActivity;->o:Ljava/util/ArrayList;

    .line 89
    .line 90
    new-instance v2, LC6/d;

    .line 91
    .line 92
    check-cast p1, Ljava/util/ArrayList;

    .line 93
    .line 94
    invoke-direct {v2, v0, p1}, LC6/d;-><init>(LE/p;Ljava/util/ArrayList;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 98
    .line 99
    .line 100
    goto :goto_1

    .line 101
    :catch_0
    sget p1, Lt6/a;->a:I

    .line 102
    .line 103
    new-instance p1, Ljava/lang/StringBuilder;

    .line 104
    .line 105
    const-string v1, "Camera Face "

    .line 106
    .line 107
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    const-string v0, " is not supported"

    .line 114
    .line 115
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    invoke-static {p1}, Lt6/a;->b(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    :cond_3
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 126
    .line 127
    return-object p1
.end method
