.class public final synthetic LC6/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:Landroidx/camera/core/ImageProxy;

.field public final synthetic d:Lcom/google/mlkit/vision/common/InputImage;

.field public final synthetic e:Landroidx/lifecycle/a0;


# direct methods
.method public synthetic constructor <init>(Landroidx/lifecycle/a0;JLandroidx/camera/core/ImageProxy;Lcom/google/mlkit/vision/common/InputImage;I)V
    .locals 0

    .line 1
    iput p6, p0, LC6/q;->a:I

    iput-object p1, p0, LC6/q;->e:Landroidx/lifecycle/a0;

    iput-wide p2, p0, LC6/q;->b:J

    iput-object p4, p0, LC6/q;->c:Landroidx/camera/core/ImageProxy;

    iput-object p5, p0, LC6/q;->d:Lcom/google/mlkit/vision/common/InputImage;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 34

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-string v1, ""

    .line 4
    .line 5
    const-string v2, "event_desc"

    .line 6
    .line 7
    const-string v3, "scene"

    .line 8
    .line 9
    const-string v5, "current"

    .line 10
    .line 11
    const-string v6, "total"

    .line 12
    .line 13
    const-string v7, "transactionId"

    .line 14
    .line 15
    const-string v8, "uuid"

    .line 16
    .line 17
    const-string v9, "liveness"

    .line 18
    .line 19
    const-string v10, "selfie"

    .line 20
    .line 21
    iget-object v13, v0, LC6/q;->d:Lcom/google/mlkit/vision/common/InputImage;

    .line 22
    .line 23
    const-string v14, "getBoundingBox(...)"

    .line 24
    .line 25
    iget-object v15, v0, LC6/q;->c:Landroidx/camera/core/ImageProxy;

    .line 26
    .line 27
    const v16, 0x3ecccccd    # 0.4f

    .line 28
    .line 29
    .line 30
    const v17, 0x3dcccccd    # 0.1f

    .line 31
    .line 32
    .line 33
    iget-wide v11, v0, LC6/q;->b:J

    .line 34
    .line 35
    iget-object v4, v0, LC6/q;->e:Landroidx/lifecycle/a0;

    .line 36
    .line 37
    move-object/from16 v19, v1

    .line 38
    .line 39
    iget v1, v0, LC6/q;->a:I

    .line 40
    .line 41
    packed-switch v1, :pswitch_data_0

    .line 42
    .line 43
    .line 44
    move-object/from16 v1, p1

    .line 45
    .line 46
    check-cast v1, Ljava/util/List;

    .line 47
    .line 48
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 49
    .line 50
    .line 51
    move-result v23

    .line 52
    check-cast v4, LD6/m;

    .line 53
    .line 54
    if-eqz v23, :cond_3

    .line 55
    .line 56
    sget-object v1, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 57
    .line 58
    invoke-virtual {v1}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->ensureFaceInFrame()V

    .line 59
    .line 60
    .line 61
    iget-object v1, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 62
    .line 63
    :cond_0
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    move-object/from16 v22, v2

    .line 68
    .line 69
    check-cast v22, LD6/i;

    .line 70
    .line 71
    sget-object v23, LD6/h;->d:LD6/h;

    .line 72
    .line 73
    const/16 v28, 0x0

    .line 74
    .line 75
    const/16 v29, 0x0

    .line 76
    .line 77
    const/16 v24, 0x0

    .line 78
    .line 79
    const/16 v25, 0x0

    .line 80
    .line 81
    const/16 v26, 0x0

    .line 82
    .line 83
    const/16 v27, 0x0

    .line 84
    .line 85
    const/16 v30, 0x7e

    .line 86
    .line 87
    invoke-static/range {v22 .. v30}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    invoke-virtual {v1, v2, v3}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    if-eqz v2, :cond_0

    .line 96
    .line 97
    iget-wide v1, v4, LD6/m;->i:J

    .line 98
    .line 99
    cmp-long v1, v11, v1

    .line 100
    .line 101
    if-lez v1, :cond_2

    .line 102
    .line 103
    sget-object v1, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 104
    .line 105
    invoke-virtual {v1}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->timeOut()V

    .line 106
    .line 107
    .line 108
    const/4 v1, 0x0

    .line 109
    iput-boolean v1, v4, LD6/m;->H:Z

    .line 110
    .line 111
    :cond_1
    iget-object v1, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 112
    .line 113
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v2

    .line 117
    move-object v5, v2

    .line 118
    check-cast v5, LD6/i;

    .line 119
    .line 120
    sget-object v10, LD6/g;->d:LD6/g;

    .line 121
    .line 122
    const/4 v11, 0x0

    .line 123
    const/4 v12, 0x0

    .line 124
    const/4 v6, 0x0

    .line 125
    const/4 v7, 0x0

    .line 126
    const/4 v8, 0x0

    .line 127
    const/4 v9, 0x0

    .line 128
    const/16 v13, 0x47

    .line 129
    .line 130
    invoke-static/range {v5 .. v13}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 131
    .line 132
    .line 133
    move-result-object v3

    .line 134
    invoke-virtual {v1, v2, v3}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v1

    .line 138
    if-eqz v1, :cond_1

    .line 139
    .line 140
    :cond_2
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 141
    .line 142
    goto/16 :goto_e

    .line 143
    .line 144
    :cond_3
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->F(Ljava/util/List;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    check-cast v1, Lcom/google/mlkit/vision/face/Face;

    .line 149
    .line 150
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    invoke-interface {v15}, Landroidx/camera/core/ImageProxy;->getWidth()I

    .line 154
    .line 155
    .line 156
    move-result v11

    .line 157
    invoke-interface {v15}, Landroidx/camera/core/ImageProxy;->getHeight()I

    .line 158
    .line 159
    .line 160
    move-result v12

    .line 161
    invoke-static {v11, v12}, Ljava/lang/Math;->max(II)I

    .line 162
    .line 163
    .line 164
    move-result v11

    .line 165
    invoke-static {v1, v11}, LD3/a;->m(Lcom/google/mlkit/vision/face/Face;I)Z

    .line 166
    .line 167
    .line 168
    move-result v11

    .line 169
    if-nez v11, :cond_5

    .line 170
    .line 171
    sget-object v1, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 172
    .line 173
    invoke-virtual {v1}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->ensureFaceInFrame()V

    .line 174
    .line 175
    .line 176
    iget-object v11, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 177
    .line 178
    :cond_4
    invoke-virtual {v11}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    move-object v2, v1

    .line 183
    check-cast v2, LD6/i;

    .line 184
    .line 185
    sget-object v3, LD6/h;->d:LD6/h;

    .line 186
    .line 187
    const/4 v8, 0x0

    .line 188
    const/4 v9, 0x0

    .line 189
    const/4 v4, 0x0

    .line 190
    const/4 v5, 0x0

    .line 191
    const/4 v6, 0x0

    .line 192
    const/4 v7, 0x0

    .line 193
    const/16 v10, 0x7e

    .line 194
    .line 195
    invoke-static/range {v2 .. v10}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 196
    .line 197
    .line 198
    move-result-object v2

    .line 199
    invoke-virtual {v11, v1, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 200
    .line 201
    .line 202
    move-result v1

    .line 203
    if-eqz v1, :cond_4

    .line 204
    .line 205
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 206
    .line 207
    goto/16 :goto_e

    .line 208
    .line 209
    :cond_5
    invoke-virtual {v1}, Lcom/google/mlkit/vision/face/Face;->getBoundingBox()Landroid/graphics/Rect;

    .line 210
    .line 211
    .line 212
    move-result-object v11

    .line 213
    invoke-static {v11, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 214
    .line 215
    .line 216
    invoke-static {v11}, LE/c;->t(Landroid/graphics/Rect;)I

    .line 217
    .line 218
    .line 219
    move-result v11

    .line 220
    int-to-float v11, v11

    .line 221
    invoke-static {v13}, LE/c;->u(Lcom/google/mlkit/vision/common/InputImage;)I

    .line 222
    .line 223
    .line 224
    move-result v12

    .line 225
    int-to-float v12, v12

    .line 226
    div-float/2addr v11, v12

    .line 227
    cmpg-float v12, v11, v17

    .line 228
    .line 229
    if-gez v12, :cond_7

    .line 230
    .line 231
    sget-object v1, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 232
    .line 233
    invoke-virtual {v1}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->moveCloser()V

    .line 234
    .line 235
    .line 236
    iget-object v12, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 237
    .line 238
    :cond_6
    invoke-virtual {v12}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    move-result-object v1

    .line 242
    move-object v2, v1

    .line 243
    check-cast v2, LD6/i;

    .line 244
    .line 245
    sget-object v3, LD6/h;->f:LD6/h;

    .line 246
    .line 247
    const/4 v8, 0x0

    .line 248
    const/4 v9, 0x0

    .line 249
    const/4 v4, 0x0

    .line 250
    const/4 v5, 0x0

    .line 251
    const/4 v6, 0x0

    .line 252
    const/4 v7, 0x0

    .line 253
    const/16 v10, 0x7e

    .line 254
    .line 255
    invoke-static/range {v2 .. v10}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 256
    .line 257
    .line 258
    move-result-object v2

    .line 259
    invoke-virtual {v12, v1, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 260
    .line 261
    .line 262
    move-result v1

    .line 263
    if-eqz v1, :cond_6

    .line 264
    .line 265
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 266
    .line 267
    goto/16 :goto_e

    .line 268
    .line 269
    :cond_7
    cmpl-float v11, v11, v16

    .line 270
    .line 271
    if-lez v11, :cond_9

    .line 272
    .line 273
    sget-object v1, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 274
    .line 275
    invoke-virtual {v1}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->moveAway()V

    .line 276
    .line 277
    .line 278
    iget-object v11, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 279
    .line 280
    :cond_8
    invoke-virtual {v11}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v1

    .line 284
    move-object v2, v1

    .line 285
    check-cast v2, LD6/i;

    .line 286
    .line 287
    sget-object v3, LD6/h;->g:LD6/h;

    .line 288
    .line 289
    const/4 v8, 0x0

    .line 290
    const/4 v9, 0x0

    .line 291
    const/4 v4, 0x0

    .line 292
    const/4 v5, 0x0

    .line 293
    const/4 v6, 0x0

    .line 294
    const/4 v7, 0x0

    .line 295
    const/16 v10, 0x7e

    .line 296
    .line 297
    invoke-static/range {v2 .. v10}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 298
    .line 299
    .line 300
    move-result-object v2

    .line 301
    invoke-virtual {v11, v1, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    move-result v1

    .line 305
    if-eqz v1, :cond_8

    .line 306
    .line 307
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 308
    .line 309
    goto/16 :goto_e

    .line 310
    .line 311
    :cond_9
    sget-object v11, Lp6/p;->d:Lr6/a;

    .line 312
    .line 313
    if-eqz v11, :cond_1e

    .line 314
    .line 315
    iget-object v11, v11, Lr6/a;->p:Ljava/lang/Integer;

    .line 316
    .line 317
    if-nez v11, :cond_a

    .line 318
    .line 319
    goto/16 :goto_6

    .line 320
    .line 321
    :cond_a
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 322
    .line 323
    .line 324
    move-result v11

    .line 325
    const/4 v12, 0x1

    .line 326
    if-ne v12, v11, :cond_1e

    .line 327
    .line 328
    invoke-virtual {v1}, Lcom/google/mlkit/vision/face/Face;->getSmilingProbability()Ljava/lang/Float;

    .line 329
    .line 330
    .line 331
    move-result-object v1

    .line 332
    if-eqz v1, :cond_b

    .line 333
    .line 334
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 335
    .line 336
    .line 337
    move-result v1

    .line 338
    goto :goto_0

    .line 339
    :cond_b
    const/4 v1, 0x0

    .line 340
    :goto_0
    iget v11, v4, LD6/m;->j:F

    .line 341
    .line 342
    cmpl-float v1, v1, v11

    .line 343
    .line 344
    if-lez v1, :cond_c

    .line 345
    .line 346
    const/4 v11, 0x1

    .line 347
    goto :goto_1

    .line 348
    :cond_c
    const/4 v11, 0x0

    .line 349
    :goto_1
    iget-object v12, v4, LD6/m;->w:Ljava/util/ArrayList;

    .line 350
    .line 351
    iget-object v13, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 352
    .line 353
    iget v14, v4, LD6/m;->e:I

    .line 354
    .line 355
    const/4 v1, 0x2

    .line 356
    if-le v14, v1, :cond_e

    .line 357
    .line 358
    move/from16 v22, v1

    .line 359
    .line 360
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 361
    .line 362
    .line 363
    move-result v1

    .line 364
    div-int/lit8 v0, v14, 0x2

    .line 365
    .line 366
    if-le v1, v0, :cond_12

    .line 367
    .line 368
    if-nez v11, :cond_12

    .line 369
    .line 370
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 371
    .line 372
    .line 373
    move-result v0

    .line 374
    if-eq v0, v14, :cond_12

    .line 375
    .line 376
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 377
    .line 378
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->smile()V

    .line 379
    .line 380
    .line 381
    :cond_d
    invoke-virtual {v13}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 382
    .line 383
    .line 384
    move-result-object v0

    .line 385
    move-object v1, v0

    .line 386
    check-cast v1, LD6/i;

    .line 387
    .line 388
    sget-object v2, LD6/h;->i:LD6/h;

    .line 389
    .line 390
    const/4 v7, 0x0

    .line 391
    const/4 v8, 0x0

    .line 392
    const/4 v3, 0x0

    .line 393
    const/4 v4, 0x0

    .line 394
    const/4 v5, 0x0

    .line 395
    const/4 v6, 0x0

    .line 396
    const/16 v9, 0x7e

    .line 397
    .line 398
    invoke-static/range {v1 .. v9}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 399
    .line 400
    .line 401
    move-result-object v1

    .line 402
    invoke-virtual {v13, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 403
    .line 404
    .line 405
    move-result v0

    .line 406
    if-eqz v0, :cond_d

    .line 407
    .line 408
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 409
    .line 410
    goto/16 :goto_e

    .line 411
    .line 412
    :cond_e
    const/4 v0, 0x1

    .line 413
    if-le v14, v0, :cond_10

    .line 414
    .line 415
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 416
    .line 417
    .line 418
    move-result v1

    .line 419
    if-lt v1, v0, :cond_12

    .line 420
    .line 421
    if-nez v11, :cond_12

    .line 422
    .line 423
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 424
    .line 425
    .line 426
    move-result v0

    .line 427
    if-eq v0, v14, :cond_12

    .line 428
    .line 429
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 430
    .line 431
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->smile()V

    .line 432
    .line 433
    .line 434
    :cond_f
    invoke-virtual {v13}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 435
    .line 436
    .line 437
    move-result-object v0

    .line 438
    move-object v1, v0

    .line 439
    check-cast v1, LD6/i;

    .line 440
    .line 441
    sget-object v2, LD6/h;->i:LD6/h;

    .line 442
    .line 443
    const/4 v7, 0x0

    .line 444
    const/4 v8, 0x0

    .line 445
    const/4 v3, 0x0

    .line 446
    const/4 v4, 0x0

    .line 447
    const/4 v5, 0x0

    .line 448
    const/4 v6, 0x0

    .line 449
    const/16 v9, 0x7e

    .line 450
    .line 451
    invoke-static/range {v1 .. v9}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 452
    .line 453
    .line 454
    move-result-object v1

    .line 455
    invoke-virtual {v13, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 456
    .line 457
    .line 458
    move-result v0

    .line 459
    if-eqz v0, :cond_f

    .line 460
    .line 461
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 462
    .line 463
    goto/16 :goto_e

    .line 464
    .line 465
    :cond_10
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 466
    .line 467
    .line 468
    move-result v0

    .line 469
    if-nez v0, :cond_12

    .line 470
    .line 471
    if-nez v11, :cond_12

    .line 472
    .line 473
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 474
    .line 475
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->smile()V

    .line 476
    .line 477
    .line 478
    :cond_11
    invoke-virtual {v13}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 479
    .line 480
    .line 481
    move-result-object v0

    .line 482
    move-object v1, v0

    .line 483
    check-cast v1, LD6/i;

    .line 484
    .line 485
    sget-object v2, LD6/h;->i:LD6/h;

    .line 486
    .line 487
    const/4 v7, 0x0

    .line 488
    const/4 v8, 0x0

    .line 489
    const/4 v3, 0x0

    .line 490
    const/4 v4, 0x0

    .line 491
    const/4 v5, 0x0

    .line 492
    const/4 v6, 0x0

    .line 493
    const/16 v9, 0x7e

    .line 494
    .line 495
    invoke-static/range {v1 .. v9}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 496
    .line 497
    .line 498
    move-result-object v1

    .line 499
    invoke-virtual {v13, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 500
    .line 501
    .line 502
    move-result v0

    .line 503
    if-eqz v0, :cond_11

    .line 504
    .line 505
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 506
    .line 507
    goto/16 :goto_e

    .line 508
    .line 509
    :cond_12
    invoke-virtual {v13}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 510
    .line 511
    .line 512
    move-result-object v0

    .line 513
    move-object/from16 v23, v0

    .line 514
    .line 515
    check-cast v23, LD6/i;

    .line 516
    .line 517
    sget-object v24, LD6/h;->c:LD6/h;

    .line 518
    .line 519
    const/16 v29, 0x0

    .line 520
    .line 521
    const/16 v30, 0x0

    .line 522
    .line 523
    const/16 v25, 0x0

    .line 524
    .line 525
    const/16 v26, 0x0

    .line 526
    .line 527
    const/16 v27, 0x0

    .line 528
    .line 529
    const/16 v28, 0x0

    .line 530
    .line 531
    const/16 v31, 0x7e

    .line 532
    .line 533
    invoke-static/range {v23 .. v31}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 534
    .line 535
    .line 536
    move-result-object v1

    .line 537
    invoke-virtual {v13, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 538
    .line 539
    .line 540
    move-result v0

    .line 541
    if-eqz v0, :cond_12

    .line 542
    .line 543
    invoke-static {v15}, Lhf/a;->u(Landroidx/camera/core/ImageProxy;)Landroid/graphics/Bitmap;

    .line 544
    .line 545
    .line 546
    move-result-object v0

    .line 547
    if-nez v0, :cond_13

    .line 548
    .line 549
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 550
    .line 551
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->bitmapEmpty()V

    .line 552
    .line 553
    .line 554
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 555
    .line 556
    goto/16 :goto_e

    .line 557
    .line 558
    :cond_13
    move-object/from16 v23, v9

    .line 559
    .line 560
    move-object/from16 v24, v10

    .line 561
    .line 562
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 563
    .line 564
    .line 565
    move-result-wide v9

    .line 566
    iput-wide v9, v4, LD6/m;->C:J

    .line 567
    .line 568
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 569
    .line 570
    .line 571
    move-result v1

    .line 572
    iget v9, v4, LD6/m;->f:I

    .line 573
    .line 574
    if-ge v1, v14, :cond_18

    .line 575
    .line 576
    invoke-static/range {v23 .. v23}, LE/c;->j(Ljava/lang/String;)Ljava/io/File;

    .line 577
    .line 578
    .line 579
    move-result-object v0

    .line 580
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 581
    .line 582
    .line 583
    :cond_14
    invoke-virtual {v13}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 584
    .line 585
    .line 586
    move-result-object v0

    .line 587
    move-object/from16 v20, v0

    .line 588
    .line 589
    check-cast v20, LD6/i;

    .line 590
    .line 591
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 592
    .line 593
    .line 594
    move-result v1

    .line 595
    int-to-float v1, v1

    .line 596
    int-to-float v10, v9

    .line 597
    div-float v22, v1, v10

    .line 598
    .line 599
    const/16 v26, 0x0

    .line 600
    .line 601
    const/16 v27, 0x0

    .line 602
    .line 603
    const/16 v21, 0x0

    .line 604
    .line 605
    const/16 v23, 0x0

    .line 606
    .line 607
    const/16 v24, 0x0

    .line 608
    .line 609
    const/16 v25, 0x0

    .line 610
    .line 611
    const/16 v28, 0x7d

    .line 612
    .line 613
    invoke-static/range {v20 .. v28}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 614
    .line 615
    .line 616
    move-result-object v1

    .line 617
    invoke-virtual {v13, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 618
    .line 619
    .line 620
    move-result v0

    .line 621
    if-eqz v0, :cond_14

    .line 622
    .line 623
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 624
    .line 625
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->collectLiveness()V

    .line 626
    .line 627
    .line 628
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 629
    .line 630
    if-eqz v0, :cond_35

    .line 631
    .line 632
    iget-object v0, v0, Lr6/a;->e:Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;

    .line 633
    .line 634
    if-eqz v0, :cond_35

    .line 635
    .line 636
    sget-object v1, Lv6/e;->e:Lv6/d;

    .line 637
    .line 638
    iget-object v10, v1, Lv6/d;->a:Ljava/lang/String;

    .line 639
    .line 640
    new-instance v11, Lkotlin/Pair;

    .line 641
    .line 642
    iget-object v1, v1, Lv6/d;->b:Ljava/lang/String;

    .line 643
    .line 644
    invoke-direct {v11, v2, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 645
    .line 646
    .line 647
    sget-object v1, Lp6/p;->j:Ljava/lang/Integer;

    .line 648
    .line 649
    if-eqz v1, :cond_15

    .line 650
    .line 651
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 652
    .line 653
    .line 654
    move-result v1

    .line 655
    goto :goto_2

    .line 656
    :cond_15
    const/4 v1, -0x1

    .line 657
    :goto_2
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 658
    .line 659
    .line 660
    move-result-object v1

    .line 661
    new-instance v2, Lkotlin/Pair;

    .line 662
    .line 663
    invoke-direct {v2, v3, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 664
    .line 665
    .line 666
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 667
    .line 668
    .line 669
    move-result v1

    .line 670
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 671
    .line 672
    .line 673
    move-result-object v1

    .line 674
    new-instance v3, Lkotlin/Pair;

    .line 675
    .line 676
    invoke-direct {v3, v5, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 677
    .line 678
    .line 679
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 680
    .line 681
    .line 682
    move-result-object v1

    .line 683
    new-instance v5, Lkotlin/Pair;

    .line 684
    .line 685
    invoke-direct {v5, v6, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 686
    .line 687
    .line 688
    iget-object v1, v4, LD6/m;->B:Ljava/lang/String;

    .line 689
    .line 690
    if-nez v1, :cond_16

    .line 691
    .line 692
    move-object/from16 v1, v19

    .line 693
    .line 694
    :cond_16
    new-instance v4, Lkotlin/Pair;

    .line 695
    .line 696
    invoke-direct {v4, v7, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 697
    .line 698
    .line 699
    sget-object v1, Lp6/p;->i:Ljava/lang/String;

    .line 700
    .line 701
    if-nez v1, :cond_17

    .line 702
    .line 703
    move-object/from16 v1, v19

    .line 704
    .line 705
    :cond_17
    new-instance v6, Lkotlin/Pair;

    .line 706
    .line 707
    invoke-direct {v6, v8, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 708
    .line 709
    .line 710
    move-object/from16 v21, v2

    .line 711
    .line 712
    move-object/from16 v22, v3

    .line 713
    .line 714
    move-object/from16 v24, v4

    .line 715
    .line 716
    move-object/from16 v23, v5

    .line 717
    .line 718
    move-object/from16 v25, v6

    .line 719
    .line 720
    move-object/from16 v20, v11

    .line 721
    .line 722
    filled-new-array/range {v20 .. v25}, [Lkotlin/Pair;

    .line 723
    .line 724
    .line 725
    move-result-object v1

    .line 726
    invoke-static {v1}, Lkotlin/collections/G;->h([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 727
    .line 728
    .line 729
    move-result-object v1

    .line 730
    invoke-interface {v0, v10, v1}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;->report(Ljava/lang/String;Ljava/util/Map;)V

    .line 731
    .line 732
    .line 733
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 734
    .line 735
    goto/16 :goto_d

    .line 736
    .line 737
    :cond_18
    if-nez v11, :cond_35

    .line 738
    .line 739
    iget-object v1, v4, LD6/m;->A:Ljava/io/File;

    .line 740
    .line 741
    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 742
    .line 743
    .line 744
    iget v1, v4, LD6/m;->d:I

    .line 745
    .line 746
    iget-object v10, v4, LD6/m;->g:Landroid/util/Size;

    .line 747
    .line 748
    const/4 v11, 0x2

    .line 749
    if-ne v1, v11, :cond_19

    .line 750
    .line 751
    invoke-static {}, LE/c;->k()Ljava/io/File;

    .line 752
    .line 753
    .line 754
    move-result-object v1

    .line 755
    iput-object v1, v4, LD6/m;->A:Ljava/io/File;

    .line 756
    .line 757
    invoke-static {v0, v1, v10}, LE/c;->U(Landroid/graphics/Bitmap;Ljava/io/File;Landroid/util/Size;)V

    .line 758
    .line 759
    .line 760
    :goto_3
    const/4 v1, 0x0

    .line 761
    goto :goto_4

    .line 762
    :cond_19
    invoke-static/range {v24 .. v24}, LE/c;->j(Ljava/lang/String;)Ljava/io/File;

    .line 763
    .line 764
    .line 765
    move-result-object v1

    .line 766
    iput-object v1, v4, LD6/m;->A:Ljava/io/File;

    .line 767
    .line 768
    invoke-static {v0, v1, v10}, LE/c;->T(Landroid/graphics/Bitmap;Ljava/io/File;Landroid/util/Size;)V

    .line 769
    .line 770
    .line 771
    goto :goto_3

    .line 772
    :goto_4
    iput-boolean v1, v4, LD6/m;->H:Z

    .line 773
    .line 774
    :cond_1a
    invoke-virtual {v13}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 775
    .line 776
    .line 777
    move-result-object v0

    .line 778
    move-object/from16 v21, v0

    .line 779
    .line 780
    check-cast v21, LD6/i;

    .line 781
    .line 782
    iget-object v1, v4, LD6/m;->A:Ljava/io/File;

    .line 783
    .line 784
    const/16 v27, 0x0

    .line 785
    .line 786
    const/16 v28, 0x0

    .line 787
    .line 788
    const/16 v22, 0x0

    .line 789
    .line 790
    const/high16 v23, 0x3f800000    # 1.0f

    .line 791
    .line 792
    const/16 v24, 0x0

    .line 793
    .line 794
    const/16 v26, 0x0

    .line 795
    .line 796
    const/16 v29, 0x75

    .line 797
    .line 798
    move-object/from16 v25, v1

    .line 799
    .line 800
    invoke-static/range {v21 .. v29}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 801
    .line 802
    .line 803
    move-result-object v1

    .line 804
    invoke-virtual {v13, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 805
    .line 806
    .line 807
    move-result v0

    .line 808
    if-eqz v0, :cond_1a

    .line 809
    .line 810
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 811
    .line 812
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->collectLiveness()V

    .line 813
    .line 814
    .line 815
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 816
    .line 817
    if-eqz v0, :cond_35

    .line 818
    .line 819
    iget-object v0, v0, Lr6/a;->e:Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;

    .line 820
    .line 821
    if-eqz v0, :cond_35

    .line 822
    .line 823
    sget-object v1, Lv6/e;->e:Lv6/d;

    .line 824
    .line 825
    iget-object v10, v1, Lv6/d;->a:Ljava/lang/String;

    .line 826
    .line 827
    new-instance v11, Lkotlin/Pair;

    .line 828
    .line 829
    iget-object v1, v1, Lv6/d;->b:Ljava/lang/String;

    .line 830
    .line 831
    invoke-direct {v11, v2, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 832
    .line 833
    .line 834
    sget-object v1, Lp6/p;->j:Ljava/lang/Integer;

    .line 835
    .line 836
    if-eqz v1, :cond_1b

    .line 837
    .line 838
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 839
    .line 840
    .line 841
    move-result v1

    .line 842
    goto :goto_5

    .line 843
    :cond_1b
    const/4 v1, -0x1

    .line 844
    :goto_5
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 845
    .line 846
    .line 847
    move-result-object v1

    .line 848
    new-instance v2, Lkotlin/Pair;

    .line 849
    .line 850
    invoke-direct {v2, v3, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 851
    .line 852
    .line 853
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 854
    .line 855
    .line 856
    move-result v1

    .line 857
    const/16 v20, 0x1

    .line 858
    .line 859
    add-int/lit8 v1, v1, 0x1

    .line 860
    .line 861
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 862
    .line 863
    .line 864
    move-result-object v1

    .line 865
    new-instance v3, Lkotlin/Pair;

    .line 866
    .line 867
    invoke-direct {v3, v5, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 868
    .line 869
    .line 870
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 871
    .line 872
    .line 873
    move-result-object v1

    .line 874
    new-instance v5, Lkotlin/Pair;

    .line 875
    .line 876
    invoke-direct {v5, v6, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 877
    .line 878
    .line 879
    iget-object v1, v4, LD6/m;->B:Ljava/lang/String;

    .line 880
    .line 881
    if-nez v1, :cond_1c

    .line 882
    .line 883
    move-object/from16 v1, v19

    .line 884
    .line 885
    :cond_1c
    new-instance v4, Lkotlin/Pair;

    .line 886
    .line 887
    invoke-direct {v4, v7, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 888
    .line 889
    .line 890
    sget-object v1, Lp6/p;->i:Ljava/lang/String;

    .line 891
    .line 892
    if-nez v1, :cond_1d

    .line 893
    .line 894
    move-object/from16 v1, v19

    .line 895
    .line 896
    :cond_1d
    new-instance v6, Lkotlin/Pair;

    .line 897
    .line 898
    invoke-direct {v6, v8, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 899
    .line 900
    .line 901
    move-object/from16 v22, v2

    .line 902
    .line 903
    move-object/from16 v23, v3

    .line 904
    .line 905
    move-object/from16 v25, v4

    .line 906
    .line 907
    move-object/from16 v24, v5

    .line 908
    .line 909
    move-object/from16 v26, v6

    .line 910
    .line 911
    move-object/from16 v21, v11

    .line 912
    .line 913
    filled-new-array/range {v21 .. v26}, [Lkotlin/Pair;

    .line 914
    .line 915
    .line 916
    move-result-object v1

    .line 917
    invoke-static {v1}, Lkotlin/collections/G;->h([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 918
    .line 919
    .line 920
    move-result-object v1

    .line 921
    invoke-interface {v0, v10, v1}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;->report(Ljava/lang/String;Ljava/util/Map;)V

    .line 922
    .line 923
    .line 924
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 925
    .line 926
    goto/16 :goto_d

    .line 927
    .line 928
    :cond_1e
    :goto_6
    move-object/from16 v23, v9

    .line 929
    .line 930
    move-object/from16 v24, v10

    .line 931
    .line 932
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 933
    .line 934
    if-eqz v0, :cond_35

    .line 935
    .line 936
    iget-object v0, v0, Lr6/a;->p:Ljava/lang/Integer;

    .line 937
    .line 938
    if-nez v0, :cond_1f

    .line 939
    .line 940
    goto/16 :goto_d

    .line 941
    .line 942
    :cond_1f
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 943
    .line 944
    .line 945
    move-result v0

    .line 946
    const/4 v11, 0x2

    .line 947
    if-ne v11, v0, :cond_35

    .line 948
    .line 949
    invoke-virtual {v1}, Lcom/google/mlkit/vision/face/Face;->getLeftEyeOpenProbability()Ljava/lang/Float;

    .line 950
    .line 951
    .line 952
    move-result-object v0

    .line 953
    invoke-virtual {v1}, Lcom/google/mlkit/vision/face/Face;->getRightEyeOpenProbability()Ljava/lang/Float;

    .line 954
    .line 955
    .line 956
    move-result-object v1

    .line 957
    if-eqz v0, :cond_27

    .line 958
    .line 959
    if-eqz v1, :cond_27

    .line 960
    .line 961
    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    .line 962
    .line 963
    .line 964
    move-result v0

    .line 965
    iget v9, v4, LD6/m;->o:F

    .line 966
    .line 967
    cmpg-float v0, v0, v9

    .line 968
    .line 969
    if-ltz v0, :cond_21

    .line 970
    .line 971
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 972
    .line 973
    .line 974
    move-result v0

    .line 975
    iget v1, v4, LD6/m;->o:F

    .line 976
    .line 977
    cmpg-float v0, v0, v1

    .line 978
    .line 979
    if-gez v0, :cond_20

    .line 980
    .line 981
    goto :goto_7

    .line 982
    :cond_20
    const/4 v0, 0x0

    .line 983
    goto :goto_8

    .line 984
    :cond_21
    :goto_7
    const/4 v0, 0x1

    .line 985
    :goto_8
    iget-object v1, v4, LD6/m;->w:Ljava/util/ArrayList;

    .line 986
    .line 987
    iget-object v9, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 988
    .line 989
    iget v10, v4, LD6/m;->e:I

    .line 990
    .line 991
    const/4 v11, 0x2

    .line 992
    if-le v10, v11, :cond_23

    .line 993
    .line 994
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 995
    .line 996
    .line 997
    move-result v12

    .line 998
    div-int/lit8 v13, v10, 0x2

    .line 999
    .line 1000
    if-le v12, v13, :cond_28

    .line 1001
    .line 1002
    if-nez v0, :cond_28

    .line 1003
    .line 1004
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 1005
    .line 1006
    .line 1007
    move-result v1

    .line 1008
    if-eq v1, v10, :cond_28

    .line 1009
    .line 1010
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1011
    .line 1012
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->blink()V

    .line 1013
    .line 1014
    .line 1015
    :cond_22
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1016
    .line 1017
    .line 1018
    move-result-object v0

    .line 1019
    move-object v10, v0

    .line 1020
    check-cast v10, LD6/i;

    .line 1021
    .line 1022
    sget-object v11, LD6/h;->j:LD6/h;

    .line 1023
    .line 1024
    const/16 v16, 0x0

    .line 1025
    .line 1026
    const/16 v17, 0x0

    .line 1027
    .line 1028
    const/4 v12, 0x0

    .line 1029
    const/4 v13, 0x0

    .line 1030
    const/4 v14, 0x0

    .line 1031
    const/4 v15, 0x0

    .line 1032
    const/16 v18, 0x7e

    .line 1033
    .line 1034
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1035
    .line 1036
    .line 1037
    move-result-object v1

    .line 1038
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1039
    .line 1040
    .line 1041
    move-result v0

    .line 1042
    if-eqz v0, :cond_22

    .line 1043
    .line 1044
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1045
    .line 1046
    goto/16 :goto_e

    .line 1047
    .line 1048
    :cond_23
    const/4 v12, 0x1

    .line 1049
    if-le v10, v12, :cond_25

    .line 1050
    .line 1051
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 1052
    .line 1053
    .line 1054
    move-result v11

    .line 1055
    if-lt v11, v12, :cond_28

    .line 1056
    .line 1057
    if-nez v0, :cond_28

    .line 1058
    .line 1059
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 1060
    .line 1061
    .line 1062
    move-result v1

    .line 1063
    if-eq v1, v10, :cond_28

    .line 1064
    .line 1065
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1066
    .line 1067
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->blink()V

    .line 1068
    .line 1069
    .line 1070
    :cond_24
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1071
    .line 1072
    .line 1073
    move-result-object v0

    .line 1074
    move-object v10, v0

    .line 1075
    check-cast v10, LD6/i;

    .line 1076
    .line 1077
    sget-object v11, LD6/h;->j:LD6/h;

    .line 1078
    .line 1079
    const/16 v16, 0x0

    .line 1080
    .line 1081
    const/16 v17, 0x0

    .line 1082
    .line 1083
    const/4 v12, 0x0

    .line 1084
    const/4 v13, 0x0

    .line 1085
    const/4 v14, 0x0

    .line 1086
    const/4 v15, 0x0

    .line 1087
    const/16 v18, 0x7e

    .line 1088
    .line 1089
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1090
    .line 1091
    .line 1092
    move-result-object v1

    .line 1093
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1094
    .line 1095
    .line 1096
    move-result v0

    .line 1097
    if-eqz v0, :cond_24

    .line 1098
    .line 1099
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1100
    .line 1101
    goto/16 :goto_e

    .line 1102
    .line 1103
    :cond_25
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 1104
    .line 1105
    .line 1106
    move-result v1

    .line 1107
    if-nez v1, :cond_28

    .line 1108
    .line 1109
    if-nez v0, :cond_28

    .line 1110
    .line 1111
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1112
    .line 1113
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->blink()V

    .line 1114
    .line 1115
    .line 1116
    :cond_26
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1117
    .line 1118
    .line 1119
    move-result-object v0

    .line 1120
    move-object v10, v0

    .line 1121
    check-cast v10, LD6/i;

    .line 1122
    .line 1123
    sget-object v11, LD6/h;->j:LD6/h;

    .line 1124
    .line 1125
    const/16 v16, 0x0

    .line 1126
    .line 1127
    const/16 v17, 0x0

    .line 1128
    .line 1129
    const/4 v12, 0x0

    .line 1130
    const/4 v13, 0x0

    .line 1131
    const/4 v14, 0x0

    .line 1132
    const/4 v15, 0x0

    .line 1133
    const/16 v18, 0x7e

    .line 1134
    .line 1135
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1136
    .line 1137
    .line 1138
    move-result-object v1

    .line 1139
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1140
    .line 1141
    .line 1142
    move-result v0

    .line 1143
    if-eqz v0, :cond_26

    .line 1144
    .line 1145
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1146
    .line 1147
    goto/16 :goto_e

    .line 1148
    .line 1149
    :cond_27
    const/4 v0, 0x0

    .line 1150
    :cond_28
    iget-object v1, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 1151
    .line 1152
    :cond_29
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1153
    .line 1154
    .line 1155
    move-result-object v9

    .line 1156
    move-object/from16 v25, v9

    .line 1157
    .line 1158
    check-cast v25, LD6/i;

    .line 1159
    .line 1160
    sget-object v26, LD6/h;->c:LD6/h;

    .line 1161
    .line 1162
    const/16 v31, 0x0

    .line 1163
    .line 1164
    const/16 v32, 0x0

    .line 1165
    .line 1166
    const/16 v27, 0x0

    .line 1167
    .line 1168
    const/16 v28, 0x0

    .line 1169
    .line 1170
    const/16 v29, 0x0

    .line 1171
    .line 1172
    const/16 v30, 0x0

    .line 1173
    .line 1174
    const/16 v33, 0x7e

    .line 1175
    .line 1176
    invoke-static/range {v25 .. v33}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1177
    .line 1178
    .line 1179
    move-result-object v10

    .line 1180
    invoke-virtual {v1, v9, v10}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1181
    .line 1182
    .line 1183
    move-result v9

    .line 1184
    if-eqz v9, :cond_29

    .line 1185
    .line 1186
    invoke-static {v15}, Lhf/a;->u(Landroidx/camera/core/ImageProxy;)Landroid/graphics/Bitmap;

    .line 1187
    .line 1188
    .line 1189
    move-result-object v1

    .line 1190
    if-nez v1, :cond_2a

    .line 1191
    .line 1192
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1193
    .line 1194
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->bitmapEmpty()V

    .line 1195
    .line 1196
    .line 1197
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1198
    .line 1199
    goto/16 :goto_e

    .line 1200
    .line 1201
    :cond_2a
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 1202
    .line 1203
    .line 1204
    move-result-wide v9

    .line 1205
    iput-wide v9, v4, LD6/m;->C:J

    .line 1206
    .line 1207
    iget-object v9, v4, LD6/m;->w:Ljava/util/ArrayList;

    .line 1208
    .line 1209
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 1210
    .line 1211
    .line 1212
    move-result v10

    .line 1213
    iget-object v11, v4, LD6/m;->p:Lkotlinx/coroutines/flow/g0;

    .line 1214
    .line 1215
    iget v12, v4, LD6/m;->e:I

    .line 1216
    .line 1217
    iget v13, v4, LD6/m;->f:I

    .line 1218
    .line 1219
    if-ge v10, v12, :cond_2f

    .line 1220
    .line 1221
    invoke-static/range {v23 .. v23}, LE/c;->j(Ljava/lang/String;)Ljava/io/File;

    .line 1222
    .line 1223
    .line 1224
    move-result-object v0

    .line 1225
    invoke-virtual {v9, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1226
    .line 1227
    .line 1228
    :cond_2b
    invoke-virtual {v11}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1229
    .line 1230
    .line 1231
    move-result-object v0

    .line 1232
    move-object/from16 v20, v0

    .line 1233
    .line 1234
    check-cast v20, LD6/i;

    .line 1235
    .line 1236
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 1237
    .line 1238
    .line 1239
    move-result v1

    .line 1240
    int-to-float v1, v1

    .line 1241
    int-to-float v10, v13

    .line 1242
    div-float v22, v1, v10

    .line 1243
    .line 1244
    const/16 v26, 0x0

    .line 1245
    .line 1246
    const/16 v27, 0x0

    .line 1247
    .line 1248
    const/16 v21, 0x0

    .line 1249
    .line 1250
    const/16 v23, 0x0

    .line 1251
    .line 1252
    const/16 v24, 0x0

    .line 1253
    .line 1254
    const/16 v25, 0x0

    .line 1255
    .line 1256
    const/16 v28, 0x7d

    .line 1257
    .line 1258
    invoke-static/range {v20 .. v28}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1259
    .line 1260
    .line 1261
    move-result-object v1

    .line 1262
    invoke-virtual {v11, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1263
    .line 1264
    .line 1265
    move-result v0

    .line 1266
    if-eqz v0, :cond_2b

    .line 1267
    .line 1268
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1269
    .line 1270
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->collectLiveness()V

    .line 1271
    .line 1272
    .line 1273
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 1274
    .line 1275
    if-eqz v0, :cond_35

    .line 1276
    .line 1277
    iget-object v0, v0, Lr6/a;->e:Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;

    .line 1278
    .line 1279
    if-eqz v0, :cond_35

    .line 1280
    .line 1281
    sget-object v1, Lv6/e;->e:Lv6/d;

    .line 1282
    .line 1283
    iget-object v10, v1, Lv6/d;->a:Ljava/lang/String;

    .line 1284
    .line 1285
    new-instance v11, Lkotlin/Pair;

    .line 1286
    .line 1287
    iget-object v1, v1, Lv6/d;->b:Ljava/lang/String;

    .line 1288
    .line 1289
    invoke-direct {v11, v2, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1290
    .line 1291
    .line 1292
    sget-object v1, Lp6/p;->j:Ljava/lang/Integer;

    .line 1293
    .line 1294
    if-eqz v1, :cond_2c

    .line 1295
    .line 1296
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1297
    .line 1298
    .line 1299
    move-result v1

    .line 1300
    goto :goto_9

    .line 1301
    :cond_2c
    const/4 v1, -0x1

    .line 1302
    :goto_9
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1303
    .line 1304
    .line 1305
    move-result-object v1

    .line 1306
    new-instance v2, Lkotlin/Pair;

    .line 1307
    .line 1308
    invoke-direct {v2, v3, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1309
    .line 1310
    .line 1311
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 1312
    .line 1313
    .line 1314
    move-result v1

    .line 1315
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1316
    .line 1317
    .line 1318
    move-result-object v1

    .line 1319
    new-instance v3, Lkotlin/Pair;

    .line 1320
    .line 1321
    invoke-direct {v3, v5, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1322
    .line 1323
    .line 1324
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1325
    .line 1326
    .line 1327
    move-result-object v1

    .line 1328
    new-instance v5, Lkotlin/Pair;

    .line 1329
    .line 1330
    invoke-direct {v5, v6, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1331
    .line 1332
    .line 1333
    iget-object v1, v4, LD6/m;->B:Ljava/lang/String;

    .line 1334
    .line 1335
    if-nez v1, :cond_2d

    .line 1336
    .line 1337
    move-object/from16 v1, v19

    .line 1338
    .line 1339
    :cond_2d
    new-instance v4, Lkotlin/Pair;

    .line 1340
    .line 1341
    invoke-direct {v4, v7, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1342
    .line 1343
    .line 1344
    sget-object v1, Lp6/p;->i:Ljava/lang/String;

    .line 1345
    .line 1346
    if-nez v1, :cond_2e

    .line 1347
    .line 1348
    move-object/from16 v1, v19

    .line 1349
    .line 1350
    :cond_2e
    new-instance v6, Lkotlin/Pair;

    .line 1351
    .line 1352
    invoke-direct {v6, v8, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1353
    .line 1354
    .line 1355
    move-object/from16 v21, v2

    .line 1356
    .line 1357
    move-object/from16 v22, v3

    .line 1358
    .line 1359
    move-object/from16 v24, v4

    .line 1360
    .line 1361
    move-object/from16 v23, v5

    .line 1362
    .line 1363
    move-object/from16 v25, v6

    .line 1364
    .line 1365
    move-object/from16 v20, v11

    .line 1366
    .line 1367
    filled-new-array/range {v20 .. v25}, [Lkotlin/Pair;

    .line 1368
    .line 1369
    .line 1370
    move-result-object v1

    .line 1371
    invoke-static {v1}, Lkotlin/collections/G;->h([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 1372
    .line 1373
    .line 1374
    move-result-object v1

    .line 1375
    invoke-interface {v0, v10, v1}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;->report(Ljava/lang/String;Ljava/util/Map;)V

    .line 1376
    .line 1377
    .line 1378
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1379
    .line 1380
    goto/16 :goto_d

    .line 1381
    .line 1382
    :cond_2f
    if-nez v0, :cond_35

    .line 1383
    .line 1384
    iget-object v0, v4, LD6/m;->A:Ljava/io/File;

    .line 1385
    .line 1386
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 1387
    .line 1388
    .line 1389
    iget v0, v4, LD6/m;->d:I

    .line 1390
    .line 1391
    iget-object v10, v4, LD6/m;->g:Landroid/util/Size;

    .line 1392
    .line 1393
    const/4 v12, 0x2

    .line 1394
    if-ne v0, v12, :cond_30

    .line 1395
    .line 1396
    invoke-static {}, LE/c;->k()Ljava/io/File;

    .line 1397
    .line 1398
    .line 1399
    move-result-object v0

    .line 1400
    iput-object v0, v4, LD6/m;->A:Ljava/io/File;

    .line 1401
    .line 1402
    invoke-static {v1, v0, v10}, LE/c;->U(Landroid/graphics/Bitmap;Ljava/io/File;Landroid/util/Size;)V

    .line 1403
    .line 1404
    .line 1405
    :goto_a
    const/4 v1, 0x0

    .line 1406
    goto :goto_b

    .line 1407
    :cond_30
    invoke-static/range {v24 .. v24}, LE/c;->j(Ljava/lang/String;)Ljava/io/File;

    .line 1408
    .line 1409
    .line 1410
    move-result-object v0

    .line 1411
    iput-object v0, v4, LD6/m;->A:Ljava/io/File;

    .line 1412
    .line 1413
    invoke-static {v1, v0, v10}, LE/c;->T(Landroid/graphics/Bitmap;Ljava/io/File;Landroid/util/Size;)V

    .line 1414
    .line 1415
    .line 1416
    goto :goto_a

    .line 1417
    :goto_b
    iput-boolean v1, v4, LD6/m;->H:Z

    .line 1418
    .line 1419
    :cond_31
    invoke-virtual {v11}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1420
    .line 1421
    .line 1422
    move-result-object v0

    .line 1423
    move-object/from16 v21, v0

    .line 1424
    .line 1425
    check-cast v21, LD6/i;

    .line 1426
    .line 1427
    iget-object v1, v4, LD6/m;->A:Ljava/io/File;

    .line 1428
    .line 1429
    const/16 v27, 0x0

    .line 1430
    .line 1431
    const/16 v28, 0x0

    .line 1432
    .line 1433
    const/16 v22, 0x0

    .line 1434
    .line 1435
    const/high16 v23, 0x3f800000    # 1.0f

    .line 1436
    .line 1437
    const/16 v24, 0x0

    .line 1438
    .line 1439
    const/16 v26, 0x0

    .line 1440
    .line 1441
    const/16 v29, 0x75

    .line 1442
    .line 1443
    move-object/from16 v25, v1

    .line 1444
    .line 1445
    invoke-static/range {v21 .. v29}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1446
    .line 1447
    .line 1448
    move-result-object v1

    .line 1449
    invoke-virtual {v11, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1450
    .line 1451
    .line 1452
    move-result v0

    .line 1453
    if-eqz v0, :cond_31

    .line 1454
    .line 1455
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1456
    .line 1457
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->collectLiveness()V

    .line 1458
    .line 1459
    .line 1460
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 1461
    .line 1462
    if-eqz v0, :cond_35

    .line 1463
    .line 1464
    iget-object v0, v0, Lr6/a;->e:Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;

    .line 1465
    .line 1466
    if-eqz v0, :cond_35

    .line 1467
    .line 1468
    sget-object v1, Lv6/e;->e:Lv6/d;

    .line 1469
    .line 1470
    iget-object v10, v1, Lv6/d;->a:Ljava/lang/String;

    .line 1471
    .line 1472
    new-instance v11, Lkotlin/Pair;

    .line 1473
    .line 1474
    iget-object v1, v1, Lv6/d;->b:Ljava/lang/String;

    .line 1475
    .line 1476
    invoke-direct {v11, v2, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1477
    .line 1478
    .line 1479
    sget-object v1, Lp6/p;->j:Ljava/lang/Integer;

    .line 1480
    .line 1481
    if-eqz v1, :cond_32

    .line 1482
    .line 1483
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1484
    .line 1485
    .line 1486
    move-result v1

    .line 1487
    goto :goto_c

    .line 1488
    :cond_32
    const/4 v1, -0x1

    .line 1489
    :goto_c
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1490
    .line 1491
    .line 1492
    move-result-object v1

    .line 1493
    new-instance v2, Lkotlin/Pair;

    .line 1494
    .line 1495
    invoke-direct {v2, v3, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1496
    .line 1497
    .line 1498
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 1499
    .line 1500
    .line 1501
    move-result v1

    .line 1502
    const/16 v20, 0x1

    .line 1503
    .line 1504
    add-int/lit8 v1, v1, 0x1

    .line 1505
    .line 1506
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1507
    .line 1508
    .line 1509
    move-result-object v1

    .line 1510
    new-instance v3, Lkotlin/Pair;

    .line 1511
    .line 1512
    invoke-direct {v3, v5, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1513
    .line 1514
    .line 1515
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1516
    .line 1517
    .line 1518
    move-result-object v1

    .line 1519
    new-instance v5, Lkotlin/Pair;

    .line 1520
    .line 1521
    invoke-direct {v5, v6, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1522
    .line 1523
    .line 1524
    iget-object v1, v4, LD6/m;->B:Ljava/lang/String;

    .line 1525
    .line 1526
    if-nez v1, :cond_33

    .line 1527
    .line 1528
    move-object/from16 v1, v19

    .line 1529
    .line 1530
    :cond_33
    new-instance v4, Lkotlin/Pair;

    .line 1531
    .line 1532
    invoke-direct {v4, v7, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1533
    .line 1534
    .line 1535
    sget-object v1, Lp6/p;->i:Ljava/lang/String;

    .line 1536
    .line 1537
    if-nez v1, :cond_34

    .line 1538
    .line 1539
    move-object/from16 v1, v19

    .line 1540
    .line 1541
    :cond_34
    new-instance v6, Lkotlin/Pair;

    .line 1542
    .line 1543
    invoke-direct {v6, v8, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1544
    .line 1545
    .line 1546
    move-object/from16 v22, v2

    .line 1547
    .line 1548
    move-object/from16 v23, v3

    .line 1549
    .line 1550
    move-object/from16 v25, v4

    .line 1551
    .line 1552
    move-object/from16 v24, v5

    .line 1553
    .line 1554
    move-object/from16 v26, v6

    .line 1555
    .line 1556
    move-object/from16 v21, v11

    .line 1557
    .line 1558
    filled-new-array/range {v21 .. v26}, [Lkotlin/Pair;

    .line 1559
    .line 1560
    .line 1561
    move-result-object v1

    .line 1562
    invoke-static {v1}, Lkotlin/collections/G;->h([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 1563
    .line 1564
    .line 1565
    move-result-object v1

    .line 1566
    invoke-interface {v0, v10, v1}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;->report(Ljava/lang/String;Ljava/util/Map;)V

    .line 1567
    .line 1568
    .line 1569
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1570
    .line 1571
    :cond_35
    :goto_d
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1572
    .line 1573
    :goto_e
    return-object v1

    .line 1574
    :pswitch_0
    move-object/from16 v23, v9

    .line 1575
    .line 1576
    move-object/from16 v24, v10

    .line 1577
    .line 1578
    move-object/from16 v0, p1

    .line 1579
    .line 1580
    check-cast v0, Ljava/util/List;

    .line 1581
    .line 1582
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 1583
    .line 1584
    .line 1585
    move-result v1

    .line 1586
    check-cast v4, LC6/v;

    .line 1587
    .line 1588
    if-eqz v1, :cond_39

    .line 1589
    .line 1590
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1591
    .line 1592
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->ensureFaceInFrame()V

    .line 1593
    .line 1594
    .line 1595
    iget-object v1, v4, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 1596
    .line 1597
    :cond_36
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1598
    .line 1599
    .line 1600
    move-result-object v0

    .line 1601
    move-object/from16 v22, v0

    .line 1602
    .line 1603
    check-cast v22, LD6/i;

    .line 1604
    .line 1605
    sget-object v23, LD6/h;->d:LD6/h;

    .line 1606
    .line 1607
    sget-object v25, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1608
    .line 1609
    const/16 v28, 0x0

    .line 1610
    .line 1611
    const/16 v29, 0x0

    .line 1612
    .line 1613
    const/16 v24, 0x0

    .line 1614
    .line 1615
    const/16 v26, 0x0

    .line 1616
    .line 1617
    const/16 v27, 0x0

    .line 1618
    .line 1619
    const/16 v30, 0x7a

    .line 1620
    .line 1621
    invoke-static/range {v22 .. v30}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1622
    .line 1623
    .line 1624
    move-result-object v2

    .line 1625
    invoke-virtual {v1, v0, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1626
    .line 1627
    .line 1628
    move-result v0

    .line 1629
    if-eqz v0, :cond_36

    .line 1630
    .line 1631
    iget-wide v0, v4, LC6/v;->g:J

    .line 1632
    .line 1633
    cmp-long v0, v11, v0

    .line 1634
    .line 1635
    if-lez v0, :cond_38

    .line 1636
    .line 1637
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1638
    .line 1639
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->timeOut()V

    .line 1640
    .line 1641
    .line 1642
    const/4 v1, 0x0

    .line 1643
    iput-boolean v1, v4, LC6/v;->C:Z

    .line 1644
    .line 1645
    :cond_37
    iget-object v0, v4, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 1646
    .line 1647
    invoke-virtual {v0}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1648
    .line 1649
    .line 1650
    move-result-object v1

    .line 1651
    move-object v5, v1

    .line 1652
    check-cast v5, LD6/i;

    .line 1653
    .line 1654
    sget-object v10, LD6/g;->d:LD6/g;

    .line 1655
    .line 1656
    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1657
    .line 1658
    const/4 v11, 0x0

    .line 1659
    const/4 v12, 0x0

    .line 1660
    const/4 v6, 0x0

    .line 1661
    const/4 v7, 0x0

    .line 1662
    const/4 v9, 0x0

    .line 1663
    const/16 v13, 0x43

    .line 1664
    .line 1665
    invoke-static/range {v5 .. v13}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1666
    .line 1667
    .line 1668
    move-result-object v2

    .line 1669
    invoke-virtual {v0, v1, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1670
    .line 1671
    .line 1672
    move-result v0

    .line 1673
    if-eqz v0, :cond_37

    .line 1674
    .line 1675
    :cond_38
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1676
    .line 1677
    goto/16 :goto_1a

    .line 1678
    .line 1679
    :cond_39
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->F(Ljava/util/List;)Ljava/lang/Object;

    .line 1680
    .line 1681
    .line 1682
    move-result-object v0

    .line 1683
    check-cast v0, Lcom/google/mlkit/vision/face/Face;

    .line 1684
    .line 1685
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 1686
    .line 1687
    .line 1688
    invoke-interface {v15}, Landroidx/camera/core/ImageProxy;->getWidth()I

    .line 1689
    .line 1690
    .line 1691
    move-result v1

    .line 1692
    invoke-interface {v15}, Landroidx/camera/core/ImageProxy;->getHeight()I

    .line 1693
    .line 1694
    .line 1695
    move-result v9

    .line 1696
    invoke-static {v1, v9}, Ljava/lang/Math;->max(II)I

    .line 1697
    .line 1698
    .line 1699
    move-result v1

    .line 1700
    invoke-static {v0, v1}, LD3/a;->m(Lcom/google/mlkit/vision/face/Face;I)Z

    .line 1701
    .line 1702
    .line 1703
    move-result v1

    .line 1704
    if-nez v1, :cond_3b

    .line 1705
    .line 1706
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1707
    .line 1708
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->ensureFaceInFrame()V

    .line 1709
    .line 1710
    .line 1711
    iget-object v1, v4, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 1712
    .line 1713
    :cond_3a
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1714
    .line 1715
    .line 1716
    move-result-object v0

    .line 1717
    move-object v2, v0

    .line 1718
    check-cast v2, LD6/i;

    .line 1719
    .line 1720
    sget-object v3, LD6/h;->d:LD6/h;

    .line 1721
    .line 1722
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1723
    .line 1724
    const/4 v8, 0x0

    .line 1725
    const/4 v9, 0x0

    .line 1726
    const/4 v4, 0x0

    .line 1727
    const/4 v6, 0x0

    .line 1728
    const/4 v7, 0x0

    .line 1729
    const/16 v10, 0x7a

    .line 1730
    .line 1731
    invoke-static/range {v2 .. v10}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1732
    .line 1733
    .line 1734
    move-result-object v2

    .line 1735
    invoke-virtual {v1, v0, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1736
    .line 1737
    .line 1738
    move-result v0

    .line 1739
    if-eqz v0, :cond_3a

    .line 1740
    .line 1741
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1742
    .line 1743
    goto/16 :goto_1a

    .line 1744
    .line 1745
    :cond_3b
    invoke-virtual {v0}, Lcom/google/mlkit/vision/face/Face;->getBoundingBox()Landroid/graphics/Rect;

    .line 1746
    .line 1747
    .line 1748
    move-result-object v1

    .line 1749
    invoke-static {v1, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1750
    .line 1751
    .line 1752
    invoke-static {v1}, LE/c;->t(Landroid/graphics/Rect;)I

    .line 1753
    .line 1754
    .line 1755
    move-result v1

    .line 1756
    int-to-float v1, v1

    .line 1757
    invoke-static {v13}, LE/c;->u(Lcom/google/mlkit/vision/common/InputImage;)I

    .line 1758
    .line 1759
    .line 1760
    move-result v9

    .line 1761
    int-to-float v9, v9

    .line 1762
    div-float/2addr v1, v9

    .line 1763
    cmpg-float v9, v1, v17

    .line 1764
    .line 1765
    if-gez v9, :cond_3d

    .line 1766
    .line 1767
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1768
    .line 1769
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->moveCloser()V

    .line 1770
    .line 1771
    .line 1772
    iget-object v9, v4, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 1773
    .line 1774
    :cond_3c
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1775
    .line 1776
    .line 1777
    move-result-object v0

    .line 1778
    move-object v10, v0

    .line 1779
    check-cast v10, LD6/i;

    .line 1780
    .line 1781
    sget-object v11, LD6/h;->f:LD6/h;

    .line 1782
    .line 1783
    sget-object v13, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1784
    .line 1785
    const/16 v16, 0x0

    .line 1786
    .line 1787
    const/16 v17, 0x0

    .line 1788
    .line 1789
    const/4 v12, 0x0

    .line 1790
    const/4 v14, 0x0

    .line 1791
    const/4 v15, 0x0

    .line 1792
    const/16 v18, 0x7a

    .line 1793
    .line 1794
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1795
    .line 1796
    .line 1797
    move-result-object v1

    .line 1798
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1799
    .line 1800
    .line 1801
    move-result v0

    .line 1802
    if-eqz v0, :cond_3c

    .line 1803
    .line 1804
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1805
    .line 1806
    goto/16 :goto_1a

    .line 1807
    .line 1808
    :cond_3d
    cmpl-float v1, v1, v16

    .line 1809
    .line 1810
    if-lez v1, :cond_3f

    .line 1811
    .line 1812
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1813
    .line 1814
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->moveAway()V

    .line 1815
    .line 1816
    .line 1817
    iget-object v1, v4, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 1818
    .line 1819
    :cond_3e
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1820
    .line 1821
    .line 1822
    move-result-object v0

    .line 1823
    move-object v2, v0

    .line 1824
    check-cast v2, LD6/i;

    .line 1825
    .line 1826
    sget-object v3, LD6/h;->g:LD6/h;

    .line 1827
    .line 1828
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1829
    .line 1830
    const/4 v8, 0x0

    .line 1831
    const/4 v9, 0x0

    .line 1832
    const/4 v4, 0x0

    .line 1833
    const/4 v6, 0x0

    .line 1834
    const/4 v7, 0x0

    .line 1835
    const/16 v10, 0x7a

    .line 1836
    .line 1837
    invoke-static/range {v2 .. v10}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1838
    .line 1839
    .line 1840
    move-result-object v2

    .line 1841
    invoke-virtual {v1, v0, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1842
    .line 1843
    .line 1844
    move-result v0

    .line 1845
    if-eqz v0, :cond_3e

    .line 1846
    .line 1847
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1848
    .line 1849
    goto/16 :goto_1a

    .line 1850
    .line 1851
    :cond_3f
    iget-boolean v1, v4, LC6/v;->H:Z

    .line 1852
    .line 1853
    iget-object v9, v4, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 1854
    .line 1855
    if-eqz v1, :cond_45

    .line 1856
    .line 1857
    invoke-static {v15}, Lhf/a;->u(Landroidx/camera/core/ImageProxy;)Landroid/graphics/Bitmap;

    .line 1858
    .line 1859
    .line 1860
    move-result-object v0

    .line 1861
    if-nez v0, :cond_40

    .line 1862
    .line 1863
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 1864
    .line 1865
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->bitmapEmpty()V

    .line 1866
    .line 1867
    .line 1868
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1869
    .line 1870
    goto/16 :goto_1a

    .line 1871
    .line 1872
    :cond_40
    const-string v1, "analyze record------------"

    .line 1873
    .line 1874
    invoke-static {v1}, Lt6/a;->a(Ljava/lang/String;)V

    .line 1875
    .line 1876
    .line 1877
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 1878
    .line 1879
    .line 1880
    move-result-wide v1

    .line 1881
    iput-wide v1, v4, LC6/v;->B:J

    .line 1882
    .line 1883
    iget v1, v4, LC6/v;->L:I

    .line 1884
    .line 1885
    iget v2, v4, LC6/v;->j:I

    .line 1886
    .line 1887
    if-gt v1, v2, :cond_41

    .line 1888
    .line 1889
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1890
    .line 1891
    iget-object v2, v4, LC6/v;->Y:Ljava/lang/Boolean;

    .line 1892
    .line 1893
    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1894
    .line 1895
    .line 1896
    move-result v1

    .line 1897
    if-eqz v1, :cond_42

    .line 1898
    .line 1899
    :cond_41
    const/4 v1, 0x0

    .line 1900
    goto :goto_10

    .line 1901
    :cond_42
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1902
    .line 1903
    .line 1904
    move-result-object v1

    .line 1905
    move-object v10, v1

    .line 1906
    check-cast v10, LD6/i;

    .line 1907
    .line 1908
    sget-object v11, LD6/h;->e:LD6/h;

    .line 1909
    .line 1910
    sget-object v13, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1911
    .line 1912
    const/16 v16, 0x0

    .line 1913
    .line 1914
    const/16 v17, 0x0

    .line 1915
    .line 1916
    const/4 v12, 0x0

    .line 1917
    const/4 v14, 0x0

    .line 1918
    const/4 v15, 0x0

    .line 1919
    const/16 v18, 0x7a

    .line 1920
    .line 1921
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 1922
    .line 1923
    .line 1924
    move-result-object v2

    .line 1925
    invoke-virtual {v9, v1, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1926
    .line 1927
    .line 1928
    move-result v1

    .line 1929
    if-eqz v1, :cond_42

    .line 1930
    .line 1931
    iget-object v1, v4, LC6/v;->X:LC6/o;

    .line 1932
    .line 1933
    if-eqz v1, :cond_43

    .line 1934
    .line 1935
    const-string v2, "bitmap"

    .line 1936
    .line 1937
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1938
    .line 1939
    .line 1940
    iget-object v2, v1, LC6/o;->h:Landroid/os/Handler;

    .line 1941
    .line 1942
    if-eqz v2, :cond_43

    .line 1943
    .line 1944
    new-instance v3, LB6/g;

    .line 1945
    .line 1946
    const/4 v12, 0x1

    .line 1947
    invoke-direct {v3, v12, v1, v0}, LB6/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 1948
    .line 1949
    .line 1950
    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1951
    .line 1952
    .line 1953
    goto :goto_f

    .line 1954
    :cond_43
    const/4 v12, 0x1

    .line 1955
    :goto_f
    iget v0, v4, LC6/v;->L:I

    .line 1956
    .line 1957
    add-int/2addr v0, v12

    .line 1958
    iput v0, v4, LC6/v;->L:I

    .line 1959
    .line 1960
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1961
    .line 1962
    goto/16 :goto_1a

    .line 1963
    .line 1964
    :goto_10
    iput-boolean v1, v4, LC6/v;->C:Z

    .line 1965
    .line 1966
    iput-boolean v1, v4, LC6/v;->H:Z

    .line 1967
    .line 1968
    iget-object v0, v4, LC6/v;->X:LC6/o;

    .line 1969
    .line 1970
    if-eqz v0, :cond_44

    .line 1971
    .line 1972
    const/4 v1, 0x0

    .line 1973
    iput-object v1, v0, LC6/o;->a:LC6/p;

    .line 1974
    .line 1975
    iget-object v1, v0, LC6/o;->h:Landroid/os/Handler;

    .line 1976
    .line 1977
    if-eqz v1, :cond_44

    .line 1978
    .line 1979
    new-instance v2, LC6/l;

    .line 1980
    .line 1981
    const/4 v11, 0x2

    .line 1982
    invoke-direct {v2, v0, v11}, LC6/l;-><init>(LC6/o;I)V

    .line 1983
    .line 1984
    .line 1985
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1986
    .line 1987
    .line 1988
    :cond_44
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 1989
    .line 1990
    .line 1991
    move-result-object v0

    .line 1992
    move-object v10, v0

    .line 1993
    check-cast v10, LD6/i;

    .line 1994
    .line 1995
    iget-object v14, v4, LC6/v;->w:Ljava/io/File;

    .line 1996
    .line 1997
    const/16 v16, 0x0

    .line 1998
    .line 1999
    const/16 v17, 0x0

    .line 2000
    .line 2001
    const/4 v11, 0x0

    .line 2002
    const/high16 v12, 0x3f800000    # 1.0f

    .line 2003
    .line 2004
    const/4 v13, 0x0

    .line 2005
    const/4 v15, 0x0

    .line 2006
    const/16 v18, 0x75

    .line 2007
    .line 2008
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 2009
    .line 2010
    .line 2011
    move-result-object v1

    .line 2012
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2013
    .line 2014
    .line 2015
    move-result v0

    .line 2016
    if-eqz v0, :cond_44

    .line 2017
    .line 2018
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 2019
    .line 2020
    goto/16 :goto_1a

    .line 2021
    .line 2022
    :cond_45
    sget-object v1, Lp6/p;->d:Lr6/a;

    .line 2023
    .line 2024
    if-eqz v1, :cond_5e

    .line 2025
    .line 2026
    iget-object v1, v1, Lr6/a;->p:Ljava/lang/Integer;

    .line 2027
    .line 2028
    if-nez v1, :cond_46

    .line 2029
    .line 2030
    goto/16 :goto_19

    .line 2031
    .line 2032
    :cond_46
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2033
    .line 2034
    .line 2035
    move-result v1

    .line 2036
    const/4 v11, 0x2

    .line 2037
    if-ne v11, v1, :cond_5e

    .line 2038
    .line 2039
    invoke-virtual {v0}, Lcom/google/mlkit/vision/face/Face;->getLeftEyeOpenProbability()Ljava/lang/Float;

    .line 2040
    .line 2041
    .line 2042
    move-result-object v1

    .line 2043
    invoke-virtual {v0}, Lcom/google/mlkit/vision/face/Face;->getRightEyeOpenProbability()Ljava/lang/Float;

    .line 2044
    .line 2045
    .line 2046
    move-result-object v0

    .line 2047
    iget-object v10, v4, LC6/v;->v:Ljava/util/ArrayList;

    .line 2048
    .line 2049
    iget v11, v4, LC6/v;->d:I

    .line 2050
    .line 2051
    if-eqz v1, :cond_4f

    .line 2052
    .line 2053
    if-eqz v0, :cond_4f

    .line 2054
    .line 2055
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 2056
    .line 2057
    .line 2058
    move-result v1

    .line 2059
    iget v12, v4, LC6/v;->i:F

    .line 2060
    .line 2061
    cmpg-float v1, v1, v12

    .line 2062
    .line 2063
    if-ltz v1, :cond_48

    .line 2064
    .line 2065
    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    .line 2066
    .line 2067
    .line 2068
    move-result v0

    .line 2069
    cmpg-float v0, v0, v12

    .line 2070
    .line 2071
    if-gez v0, :cond_47

    .line 2072
    .line 2073
    goto :goto_12

    .line 2074
    :cond_47
    const/4 v0, 0x0

    .line 2075
    :goto_11
    const/4 v1, 0x2

    .line 2076
    goto :goto_13

    .line 2077
    :cond_48
    :goto_12
    const/4 v0, 0x1

    .line 2078
    goto :goto_11

    .line 2079
    :goto_13
    if-le v11, v1, :cond_4a

    .line 2080
    .line 2081
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2082
    .line 2083
    .line 2084
    move-result v12

    .line 2085
    div-int/lit8 v1, v11, 0x2

    .line 2086
    .line 2087
    if-le v12, v1, :cond_4e

    .line 2088
    .line 2089
    if-nez v0, :cond_4e

    .line 2090
    .line 2091
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2092
    .line 2093
    .line 2094
    move-result v1

    .line 2095
    if-eq v1, v11, :cond_4e

    .line 2096
    .line 2097
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 2098
    .line 2099
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->blink()V

    .line 2100
    .line 2101
    .line 2102
    :cond_49
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 2103
    .line 2104
    .line 2105
    move-result-object v0

    .line 2106
    move-object v10, v0

    .line 2107
    check-cast v10, LD6/i;

    .line 2108
    .line 2109
    sget-object v11, LD6/h;->j:LD6/h;

    .line 2110
    .line 2111
    const/16 v16, 0x0

    .line 2112
    .line 2113
    const/16 v17, 0x0

    .line 2114
    .line 2115
    const/4 v12, 0x0

    .line 2116
    const/4 v13, 0x0

    .line 2117
    const/4 v14, 0x0

    .line 2118
    const/4 v15, 0x0

    .line 2119
    const/16 v18, 0x7e

    .line 2120
    .line 2121
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 2122
    .line 2123
    .line 2124
    move-result-object v1

    .line 2125
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2126
    .line 2127
    .line 2128
    move-result v0

    .line 2129
    if-eqz v0, :cond_49

    .line 2130
    .line 2131
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 2132
    .line 2133
    goto/16 :goto_1a

    .line 2134
    .line 2135
    :cond_4a
    const/4 v12, 0x1

    .line 2136
    if-le v11, v12, :cond_4c

    .line 2137
    .line 2138
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2139
    .line 2140
    .line 2141
    move-result v1

    .line 2142
    if-lt v1, v12, :cond_4e

    .line 2143
    .line 2144
    if-nez v0, :cond_4e

    .line 2145
    .line 2146
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2147
    .line 2148
    .line 2149
    move-result v1

    .line 2150
    if-eq v1, v11, :cond_4e

    .line 2151
    .line 2152
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 2153
    .line 2154
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->blink()V

    .line 2155
    .line 2156
    .line 2157
    :cond_4b
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 2158
    .line 2159
    .line 2160
    move-result-object v0

    .line 2161
    move-object v10, v0

    .line 2162
    check-cast v10, LD6/i;

    .line 2163
    .line 2164
    sget-object v11, LD6/h;->j:LD6/h;

    .line 2165
    .line 2166
    const/16 v16, 0x0

    .line 2167
    .line 2168
    const/16 v17, 0x0

    .line 2169
    .line 2170
    const/4 v12, 0x0

    .line 2171
    const/4 v13, 0x0

    .line 2172
    const/4 v14, 0x0

    .line 2173
    const/4 v15, 0x0

    .line 2174
    const/16 v18, 0x7e

    .line 2175
    .line 2176
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 2177
    .line 2178
    .line 2179
    move-result-object v1

    .line 2180
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2181
    .line 2182
    .line 2183
    move-result v0

    .line 2184
    if-eqz v0, :cond_4b

    .line 2185
    .line 2186
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 2187
    .line 2188
    goto/16 :goto_1a

    .line 2189
    .line 2190
    :cond_4c
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2191
    .line 2192
    .line 2193
    move-result v1

    .line 2194
    if-nez v1, :cond_4e

    .line 2195
    .line 2196
    if-nez v0, :cond_4e

    .line 2197
    .line 2198
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 2199
    .line 2200
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->blink()V

    .line 2201
    .line 2202
    .line 2203
    :cond_4d
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 2204
    .line 2205
    .line 2206
    move-result-object v0

    .line 2207
    move-object v10, v0

    .line 2208
    check-cast v10, LD6/i;

    .line 2209
    .line 2210
    sget-object v11, LD6/h;->j:LD6/h;

    .line 2211
    .line 2212
    const/16 v16, 0x0

    .line 2213
    .line 2214
    const/16 v17, 0x0

    .line 2215
    .line 2216
    const/4 v12, 0x0

    .line 2217
    const/4 v13, 0x0

    .line 2218
    const/4 v14, 0x0

    .line 2219
    const/4 v15, 0x0

    .line 2220
    const/16 v18, 0x7e

    .line 2221
    .line 2222
    invoke-static/range {v10 .. v18}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 2223
    .line 2224
    .line 2225
    move-result-object v1

    .line 2226
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2227
    .line 2228
    .line 2229
    move-result v0

    .line 2230
    if-eqz v0, :cond_4d

    .line 2231
    .line 2232
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 2233
    .line 2234
    goto/16 :goto_1a

    .line 2235
    .line 2236
    :cond_4e
    move v1, v0

    .line 2237
    goto :goto_14

    .line 2238
    :cond_4f
    const/4 v1, 0x0

    .line 2239
    :goto_14
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 2240
    .line 2241
    .line 2242
    move-result-object v0

    .line 2243
    move-object/from16 v25, v0

    .line 2244
    .line 2245
    check-cast v25, LD6/i;

    .line 2246
    .line 2247
    sget-object v26, LD6/h;->c:LD6/h;

    .line 2248
    .line 2249
    const/16 v31, 0x0

    .line 2250
    .line 2251
    const/16 v32, 0x0

    .line 2252
    .line 2253
    const/16 v27, 0x0

    .line 2254
    .line 2255
    const/16 v28, 0x0

    .line 2256
    .line 2257
    const/16 v29, 0x0

    .line 2258
    .line 2259
    const/16 v30, 0x0

    .line 2260
    .line 2261
    const/16 v33, 0x7e

    .line 2262
    .line 2263
    invoke-static/range {v25 .. v33}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 2264
    .line 2265
    .line 2266
    move-result-object v12

    .line 2267
    invoke-virtual {v9, v0, v12}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2268
    .line 2269
    .line 2270
    move-result v0

    .line 2271
    if-eqz v0, :cond_5d

    .line 2272
    .line 2273
    invoke-static {v15}, Lhf/a;->u(Landroidx/camera/core/ImageProxy;)Landroid/graphics/Bitmap;

    .line 2274
    .line 2275
    .line 2276
    move-result-object v0

    .line 2277
    if-nez v0, :cond_50

    .line 2278
    .line 2279
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 2280
    .line 2281
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->bitmapEmpty()V

    .line 2282
    .line 2283
    .line 2284
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 2285
    .line 2286
    goto/16 :goto_1a

    .line 2287
    .line 2288
    :cond_50
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 2289
    .line 2290
    .line 2291
    move-result-wide v12

    .line 2292
    iput-wide v12, v4, LC6/v;->B:J

    .line 2293
    .line 2294
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2295
    .line 2296
    .line 2297
    move-result v12

    .line 2298
    iget v13, v4, LC6/v;->e:I

    .line 2299
    .line 2300
    if-ge v12, v11, :cond_55

    .line 2301
    .line 2302
    invoke-static/range {v23 .. v23}, LE/c;->j(Ljava/lang/String;)Ljava/io/File;

    .line 2303
    .line 2304
    .line 2305
    move-result-object v0

    .line 2306
    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2307
    .line 2308
    .line 2309
    :cond_51
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 2310
    .line 2311
    .line 2312
    move-result-object v0

    .line 2313
    move-object/from16 v20, v0

    .line 2314
    .line 2315
    check-cast v20, LD6/i;

    .line 2316
    .line 2317
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2318
    .line 2319
    .line 2320
    move-result v1

    .line 2321
    int-to-float v1, v1

    .line 2322
    int-to-float v11, v13

    .line 2323
    div-float v22, v1, v11

    .line 2324
    .line 2325
    const/16 v26, 0x0

    .line 2326
    .line 2327
    const/16 v27, 0x0

    .line 2328
    .line 2329
    const/16 v21, 0x0

    .line 2330
    .line 2331
    const/16 v23, 0x0

    .line 2332
    .line 2333
    const/16 v24, 0x0

    .line 2334
    .line 2335
    const/16 v25, 0x0

    .line 2336
    .line 2337
    const/16 v28, 0x7d

    .line 2338
    .line 2339
    invoke-static/range {v20 .. v28}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 2340
    .line 2341
    .line 2342
    move-result-object v1

    .line 2343
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2344
    .line 2345
    .line 2346
    move-result v0

    .line 2347
    if-eqz v0, :cond_51

    .line 2348
    .line 2349
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 2350
    .line 2351
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->collectLiveness()V

    .line 2352
    .line 2353
    .line 2354
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 2355
    .line 2356
    if-eqz v0, :cond_5e

    .line 2357
    .line 2358
    iget-object v0, v0, Lr6/a;->e:Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;

    .line 2359
    .line 2360
    if-eqz v0, :cond_5e

    .line 2361
    .line 2362
    sget-object v1, Lv6/e;->e:Lv6/d;

    .line 2363
    .line 2364
    iget-object v9, v1, Lv6/d;->a:Ljava/lang/String;

    .line 2365
    .line 2366
    new-instance v11, Lkotlin/Pair;

    .line 2367
    .line 2368
    iget-object v1, v1, Lv6/d;->b:Ljava/lang/String;

    .line 2369
    .line 2370
    invoke-direct {v11, v2, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2371
    .line 2372
    .line 2373
    sget-object v1, Lp6/p;->j:Ljava/lang/Integer;

    .line 2374
    .line 2375
    if-eqz v1, :cond_52

    .line 2376
    .line 2377
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2378
    .line 2379
    .line 2380
    move-result v1

    .line 2381
    goto :goto_15

    .line 2382
    :cond_52
    const/4 v1, -0x1

    .line 2383
    :goto_15
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2384
    .line 2385
    .line 2386
    move-result-object v1

    .line 2387
    new-instance v2, Lkotlin/Pair;

    .line 2388
    .line 2389
    invoke-direct {v2, v3, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2390
    .line 2391
    .line 2392
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2393
    .line 2394
    .line 2395
    move-result v1

    .line 2396
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2397
    .line 2398
    .line 2399
    move-result-object v1

    .line 2400
    new-instance v3, Lkotlin/Pair;

    .line 2401
    .line 2402
    invoke-direct {v3, v5, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2403
    .line 2404
    .line 2405
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2406
    .line 2407
    .line 2408
    move-result-object v1

    .line 2409
    new-instance v5, Lkotlin/Pair;

    .line 2410
    .line 2411
    invoke-direct {v5, v6, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2412
    .line 2413
    .line 2414
    iget-object v1, v4, LC6/v;->A:Ljava/lang/String;

    .line 2415
    .line 2416
    if-nez v1, :cond_53

    .line 2417
    .line 2418
    move-object/from16 v1, v19

    .line 2419
    .line 2420
    :cond_53
    new-instance v4, Lkotlin/Pair;

    .line 2421
    .line 2422
    invoke-direct {v4, v7, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2423
    .line 2424
    .line 2425
    sget-object v1, Lp6/p;->i:Ljava/lang/String;

    .line 2426
    .line 2427
    if-nez v1, :cond_54

    .line 2428
    .line 2429
    move-object/from16 v1, v19

    .line 2430
    .line 2431
    :cond_54
    new-instance v6, Lkotlin/Pair;

    .line 2432
    .line 2433
    invoke-direct {v6, v8, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2434
    .line 2435
    .line 2436
    move-object/from16 v21, v2

    .line 2437
    .line 2438
    move-object/from16 v22, v3

    .line 2439
    .line 2440
    move-object/from16 v24, v4

    .line 2441
    .line 2442
    move-object/from16 v23, v5

    .line 2443
    .line 2444
    move-object/from16 v25, v6

    .line 2445
    .line 2446
    move-object/from16 v20, v11

    .line 2447
    .line 2448
    filled-new-array/range {v20 .. v25}, [Lkotlin/Pair;

    .line 2449
    .line 2450
    .line 2451
    move-result-object v1

    .line 2452
    invoke-static {v1}, Lkotlin/collections/G;->h([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 2453
    .line 2454
    .line 2455
    move-result-object v1

    .line 2456
    invoke-interface {v0, v9, v1}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;->report(Ljava/lang/String;Ljava/util/Map;)V

    .line 2457
    .line 2458
    .line 2459
    goto/16 :goto_19

    .line 2460
    .line 2461
    :cond_55
    if-nez v1, :cond_5e

    .line 2462
    .line 2463
    invoke-static/range {v24 .. v24}, LE/c;->j(Ljava/lang/String;)Ljava/io/File;

    .line 2464
    .line 2465
    .line 2466
    move-result-object v1

    .line 2467
    iput-object v1, v4, LC6/v;->w:Ljava/io/File;

    .line 2468
    .line 2469
    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 2470
    .line 2471
    .line 2472
    iget-object v1, v4, LC6/v;->w:Ljava/io/File;

    .line 2473
    .line 2474
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 2475
    .line 2476
    .line 2477
    iget-object v11, v4, LC6/v;->f:Landroid/util/Size;

    .line 2478
    .line 2479
    invoke-static {v0, v1, v11}, LE/c;->T(Landroid/graphics/Bitmap;Ljava/io/File;Landroid/util/Size;)V

    .line 2480
    .line 2481
    .line 2482
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 2483
    .line 2484
    iget-object v1, v4, LC6/v;->Y:Ljava/lang/Boolean;

    .line 2485
    .line 2486
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 2487
    .line 2488
    .line 2489
    move-result v0

    .line 2490
    if-eqz v0, :cond_57

    .line 2491
    .line 2492
    const/4 v1, 0x0

    .line 2493
    iput-boolean v1, v4, LC6/v;->C:Z

    .line 2494
    .line 2495
    :cond_56
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 2496
    .line 2497
    .line 2498
    move-result-object v0

    .line 2499
    move-object/from16 v21, v0

    .line 2500
    .line 2501
    check-cast v21, LD6/i;

    .line 2502
    .line 2503
    iget-object v1, v4, LC6/v;->w:Ljava/io/File;

    .line 2504
    .line 2505
    const/16 v27, 0x0

    .line 2506
    .line 2507
    const/16 v28, 0x0

    .line 2508
    .line 2509
    const/16 v22, 0x0

    .line 2510
    .line 2511
    const/high16 v23, 0x3f800000    # 1.0f

    .line 2512
    .line 2513
    const/16 v24, 0x0

    .line 2514
    .line 2515
    const/16 v26, 0x0

    .line 2516
    .line 2517
    const/16 v29, 0x75

    .line 2518
    .line 2519
    move-object/from16 v25, v1

    .line 2520
    .line 2521
    invoke-static/range {v21 .. v29}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 2522
    .line 2523
    .line 2524
    move-result-object v1

    .line 2525
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2526
    .line 2527
    .line 2528
    move-result v0

    .line 2529
    if-eqz v0, :cond_56

    .line 2530
    .line 2531
    goto :goto_17

    .line 2532
    :cond_57
    const/4 v12, 0x1

    .line 2533
    iput-boolean v12, v4, LC6/v;->H:Z

    .line 2534
    .line 2535
    :goto_16
    invoke-virtual {v9}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 2536
    .line 2537
    .line 2538
    move-result-object v0

    .line 2539
    move-object/from16 v22, v0

    .line 2540
    .line 2541
    check-cast v22, LD6/i;

    .line 2542
    .line 2543
    sget-object v23, LD6/h;->e:LD6/h;

    .line 2544
    .line 2545
    sget-object v25, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 2546
    .line 2547
    const/16 v28, 0x0

    .line 2548
    .line 2549
    const/16 v29, 0x0

    .line 2550
    .line 2551
    const/high16 v24, 0x3f800000    # 1.0f

    .line 2552
    .line 2553
    const/16 v26, 0x0

    .line 2554
    .line 2555
    const/16 v27, 0x0

    .line 2556
    .line 2557
    const/16 v30, 0x78

    .line 2558
    .line 2559
    invoke-static/range {v22 .. v30}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 2560
    .line 2561
    .line 2562
    move-result-object v1

    .line 2563
    invoke-virtual {v9, v0, v1}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2564
    .line 2565
    .line 2566
    move-result v0

    .line 2567
    if-eqz v0, :cond_5c

    .line 2568
    .line 2569
    iget-object v0, v4, LC6/v;->X:LC6/o;

    .line 2570
    .line 2571
    if-eqz v0, :cond_58

    .line 2572
    .line 2573
    iget-object v1, v0, LC6/o;->h:Landroid/os/Handler;

    .line 2574
    .line 2575
    if-eqz v1, :cond_58

    .line 2576
    .line 2577
    new-instance v9, LC6/l;

    .line 2578
    .line 2579
    const/4 v12, 0x0

    .line 2580
    invoke-direct {v9, v0, v12}, LC6/l;-><init>(LC6/o;I)V

    .line 2581
    .line 2582
    .line 2583
    invoke-virtual {v1, v9}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 2584
    .line 2585
    .line 2586
    :cond_58
    :goto_17
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 2587
    .line 2588
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->collectLiveness()V

    .line 2589
    .line 2590
    .line 2591
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 2592
    .line 2593
    if-eqz v0, :cond_5e

    .line 2594
    .line 2595
    iget-object v0, v0, Lr6/a;->e:Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;

    .line 2596
    .line 2597
    if-eqz v0, :cond_5e

    .line 2598
    .line 2599
    sget-object v1, Lv6/e;->e:Lv6/d;

    .line 2600
    .line 2601
    iget-object v9, v1, Lv6/d;->a:Ljava/lang/String;

    .line 2602
    .line 2603
    new-instance v11, Lkotlin/Pair;

    .line 2604
    .line 2605
    iget-object v1, v1, Lv6/d;->b:Ljava/lang/String;

    .line 2606
    .line 2607
    invoke-direct {v11, v2, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2608
    .line 2609
    .line 2610
    sget-object v1, Lp6/p;->j:Ljava/lang/Integer;

    .line 2611
    .line 2612
    if-eqz v1, :cond_59

    .line 2613
    .line 2614
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 2615
    .line 2616
    .line 2617
    move-result v1

    .line 2618
    goto :goto_18

    .line 2619
    :cond_59
    const/4 v1, -0x1

    .line 2620
    :goto_18
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2621
    .line 2622
    .line 2623
    move-result-object v1

    .line 2624
    new-instance v2, Lkotlin/Pair;

    .line 2625
    .line 2626
    invoke-direct {v2, v3, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2627
    .line 2628
    .line 2629
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2630
    .line 2631
    .line 2632
    move-result v1

    .line 2633
    const/16 v20, 0x1

    .line 2634
    .line 2635
    add-int/lit8 v1, v1, 0x1

    .line 2636
    .line 2637
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2638
    .line 2639
    .line 2640
    move-result-object v1

    .line 2641
    new-instance v3, Lkotlin/Pair;

    .line 2642
    .line 2643
    invoke-direct {v3, v5, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2644
    .line 2645
    .line 2646
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2647
    .line 2648
    .line 2649
    move-result-object v1

    .line 2650
    new-instance v5, Lkotlin/Pair;

    .line 2651
    .line 2652
    invoke-direct {v5, v6, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2653
    .line 2654
    .line 2655
    iget-object v1, v4, LC6/v;->A:Ljava/lang/String;

    .line 2656
    .line 2657
    if-nez v1, :cond_5a

    .line 2658
    .line 2659
    move-object/from16 v1, v19

    .line 2660
    .line 2661
    :cond_5a
    new-instance v4, Lkotlin/Pair;

    .line 2662
    .line 2663
    invoke-direct {v4, v7, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2664
    .line 2665
    .line 2666
    sget-object v1, Lp6/p;->i:Ljava/lang/String;

    .line 2667
    .line 2668
    if-nez v1, :cond_5b

    .line 2669
    .line 2670
    move-object/from16 v1, v19

    .line 2671
    .line 2672
    :cond_5b
    new-instance v6, Lkotlin/Pair;

    .line 2673
    .line 2674
    invoke-direct {v6, v8, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2675
    .line 2676
    .line 2677
    move-object/from16 v22, v2

    .line 2678
    .line 2679
    move-object/from16 v23, v3

    .line 2680
    .line 2681
    move-object/from16 v25, v4

    .line 2682
    .line 2683
    move-object/from16 v24, v5

    .line 2684
    .line 2685
    move-object/from16 v26, v6

    .line 2686
    .line 2687
    move-object/from16 v21, v11

    .line 2688
    .line 2689
    filled-new-array/range {v21 .. v26}, [Lkotlin/Pair;

    .line 2690
    .line 2691
    .line 2692
    move-result-object v1

    .line 2693
    invoke-static {v1}, Lkotlin/collections/G;->h([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 2694
    .line 2695
    .line 2696
    move-result-object v1

    .line 2697
    invoke-interface {v0, v9, v1}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;->report(Ljava/lang/String;Ljava/util/Map;)V

    .line 2698
    .line 2699
    .line 2700
    goto :goto_19

    .line 2701
    :cond_5c
    const/16 v20, 0x1

    .line 2702
    .line 2703
    goto/16 :goto_16

    .line 2704
    .line 2705
    :cond_5d
    const/16 v20, 0x1

    .line 2706
    .line 2707
    goto/16 :goto_14

    .line 2708
    .line 2709
    :cond_5e
    :goto_19
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 2710
    .line 2711
    :goto_1a
    return-object v0

    .line 2712
    nop

    .line 2713
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
