.class public final LC6/e;
.super LFf/c;
.source "SourceFile"


# instance fields
.field public a:Lcom/palmpay/lib/liveness/video/VideoActivity;

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Lcom/palmpay/lib/liveness/video/VideoActivity;

.field public d:I


# direct methods
.method public constructor <init>(Lcom/palmpay/lib/liveness/video/VideoActivity;LFf/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC6/e;->c:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 2
    .line 3
    invoke-direct {p0, p2}, LFf/c;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, LC6/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, LC6/e;->d:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, LC6/e;->d:I

    .line 9
    .line 10
    iget-object p1, p0, LC6/e;->c:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 11
    .line 12
    invoke-static {p1, p0}, Lcom/palmpay/lib/liveness/video/VideoActivity;->e(Lcom/palmpay/lib/liveness/video/VideoActivity;LFf/c;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    return-object p1
.end method
