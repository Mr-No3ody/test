.class public final synthetic LC6/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LC6/v;


# direct methods
.method public synthetic constructor <init>(LC6/v;I)V
    .locals 0

    .line 1
    iput p2, p0, LC6/p;->a:I

    iput-object p1, p0, LC6/p;->b:LC6/v;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget v0, p0, LC6/p;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/lang/Throwable;

    .line 7
    .line 8
    const-string v0, "e"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    new-instance v0, Lcom/palmpay/lib/liveness/result/LiveIDResult$Error;

    .line 14
    .line 15
    invoke-direct {v0, p1}, Lcom/palmpay/lib/liveness/result/LiveIDResult$Error;-><init>(Ljava/lang/Throwable;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, LC6/p;->b:LC6/v;

    .line 19
    .line 20
    iput-object v0, v1, LC6/v;->t:Lcom/palmpay/lib/liveness/result/LiveIDResult;

    .line 21
    .line 22
    :cond_0
    iget-object p1, v1, LC6/v;->o:Lkotlinx/coroutines/flow/g0;

    .line 23
    .line 24
    invoke-virtual {p1}, Lkotlinx/coroutines/flow/g0;->getValue()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    move-object v2, v0

    .line 29
    check-cast v2, LD6/i;

    .line 30
    .line 31
    sget-object v7, LD6/g;->c:LD6/g;

    .line 32
    .line 33
    const/4 v8, 0x0

    .line 34
    const/4 v9, 0x0

    .line 35
    const/4 v3, 0x0

    .line 36
    const/4 v4, 0x0

    .line 37
    const/4 v5, 0x0

    .line 38
    const/4 v6, 0x0

    .line 39
    const/16 v10, 0x4f

    .line 40
    .line 41
    invoke-static/range {v2 .. v10}, LD6/i;->a(LD6/i;LD6/h;FLjava/lang/Boolean;Ljava/io/File;LD6/g;Ljava/lang/String;Landroid/graphics/Bitmap;I)LD6/i;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    invoke-virtual {p1, v0, v2}, Lkotlinx/coroutines/flow/g0;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    if-eqz p1, :cond_0

    .line 50
    .line 51
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 52
    .line 53
    return-object p1

    .line 54
    :pswitch_0
    check-cast p1, Ljava/lang/Exception;

    .line 55
    .line 56
    const-string v0, "exception"

    .line 57
    .line 58
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    const-string p1, "Error record faces video"

    .line 62
    .line 63
    invoke-static {p1}, Lt6/a;->b(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 67
    .line 68
    iget-object v0, p0, LC6/p;->b:LC6/v;

    .line 69
    .line 70
    iput-object p1, v0, LC6/v;->Y:Ljava/lang/Boolean;

    .line 71
    .line 72
    iget-object p1, v0, LC6/v;->X:LC6/o;

    .line 73
    .line 74
    if-eqz p1, :cond_1

    .line 75
    .line 76
    const/4 v0, 0x0

    .line 77
    iput-object v0, p1, LC6/o;->a:LC6/p;

    .line 78
    .line 79
    iget-object v0, p1, LC6/o;->h:Landroid/os/Handler;

    .line 80
    .line 81
    if-eqz v0, :cond_1

    .line 82
    .line 83
    new-instance v1, LC6/l;

    .line 84
    .line 85
    const/4 v2, 0x2

    .line 86
    invoke-direct {v1, p1, v2}, LC6/l;-><init>(LC6/o;I)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 90
    .line 91
    .line 92
    :cond_1
    sget-object p1, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 93
    .line 94
    invoke-virtual {p1}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->recordVideoError()V

    .line 95
    .line 96
    .line 97
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 98
    .line 99
    return-object p1

    .line 100
    nop

    .line 101
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
