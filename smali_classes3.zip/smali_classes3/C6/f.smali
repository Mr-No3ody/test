.class public final LC6/f;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/palmpay/lib/liveness/video/VideoActivity;

.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;


# direct methods
.method public constructor <init>(Lcom/palmpay/lib/liveness/video/VideoActivity;Landroid/widget/TextView;Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC6/f;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 2
    .line 3
    iput-object p2, p0, LC6/f;->c:Landroid/widget/TextView;

    .line 4
    .line 5
    iput-object p3, p0, LC6/f;->d:Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance p1, LC6/f;

    .line 2
    .line 3
    iget-object v0, p0, LC6/f;->c:Landroid/widget/TextView;

    .line 4
    .line 5
    iget-object v1, p0, LC6/f;->d:Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;

    .line 6
    .line 7
    iget-object v2, p0, LC6/f;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 8
    .line 9
    invoke-direct {p1, v2, v0, v1, p2}, LC6/f;-><init>(Lcom/palmpay/lib/liveness/video/VideoActivity;Landroid/widget/TextView;Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;Lkotlin/coroutines/Continuation;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LC6/f;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LC6/f;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LC6/f;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    sget-object p1, LEf/a;->a:LEf/a;

    .line 17
    .line 18
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    const/4 v0, 0x1

    .line 2
    sget-object v1, LEf/a;->a:LEf/a;

    .line 3
    .line 4
    iget v2, p0, LC6/f;->a:I

    .line 5
    .line 6
    if-eqz v2, :cond_1

    .line 7
    .line 8
    if-eq v2, v0, :cond_0

    .line 9
    .line 10
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 11
    .line 12
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 13
    .line 14
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    throw p1

    .line 18
    :cond_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    sget-object p1, Lcom/palmpay/lib/liveness/video/VideoActivity;->B:Landroid/util/Size;

    .line 26
    .line 27
    iget-object p1, p0, LC6/f;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 28
    .line 29
    invoke-virtual {p1}, Lcom/palmpay/lib/liveness/video/VideoActivity;->f()LC6/v;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    iget-object v2, v2, LC6/v;->p:Lkotlinx/coroutines/flow/S;

    .line 34
    .line 35
    new-instance v3, LB6/p;

    .line 36
    .line 37
    iget-object v4, p0, LC6/f;->c:Landroid/widget/TextView;

    .line 38
    .line 39
    iget-object v5, p0, LC6/f;->d:Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;

    .line 40
    .line 41
    invoke-direct {v3, p1, v4, v5, v0}, LB6/p;-><init>(Landroidx/appcompat/app/o;Landroid/widget/TextView;Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;I)V

    .line 42
    .line 43
    .line 44
    iput v0, p0, LC6/f;->a:I

    .line 45
    .line 46
    iget-object p1, v2, Lkotlinx/coroutines/flow/S;->a:Lkotlinx/coroutines/flow/MutableStateFlow;

    .line 47
    .line 48
    invoke-interface {p1, v3, p0}, Lkotlinx/coroutines/flow/SharedFlow;->collect(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    if-ne p1, v1, :cond_2

    .line 53
    .line 54
    return-object v1

    .line 55
    :cond_2
    :goto_0
    new-instance p1, Lxf/f;

    .line 56
    .line 57
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 58
    .line 59
    .line 60
    throw p1
.end method
