.class public final LC6/g;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/palmpay/lib/liveness/video/VideoActivity;

.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;


# direct methods
.method public constructor <init>(Lcom/palmpay/lib/liveness/video/VideoActivity;Landroid/widget/TextView;Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC6/g;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 2
    .line 3
    iput-object p2, p0, LC6/g;->c:Landroid/widget/TextView;

    .line 4
    .line 5
    iput-object p3, p0, LC6/g;->d:Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance p1, LC6/g;

    .line 2
    .line 3
    iget-object v0, p0, LC6/g;->c:Landroid/widget/TextView;

    .line 4
    .line 5
    iget-object v1, p0, LC6/g;->d:Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;

    .line 6
    .line 7
    iget-object v2, p0, LC6/g;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 8
    .line 9
    invoke-direct {p1, v2, v0, v1, p2}, LC6/g;-><init>(Lcom/palmpay/lib/liveness/video/VideoActivity;Landroid/widget/TextView;Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;Lkotlin/coroutines/Continuation;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LC6/g;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LC6/g;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LC6/g;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LC6/g;->a:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    sget-object p1, Landroidx/lifecycle/n;->d:Landroidx/lifecycle/n;

    .line 26
    .line 27
    new-instance v1, LC6/f;

    .line 28
    .line 29
    iget-object v3, p0, LC6/g;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 30
    .line 31
    iget-object v4, p0, LC6/g;->c:Landroid/widget/TextView;

    .line 32
    .line 33
    iget-object v5, p0, LC6/g;->d:Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;

    .line 34
    .line 35
    const/4 v6, 0x0

    .line 36
    invoke-direct {v1, v3, v4, v5, v6}, LC6/f;-><init>(Lcom/palmpay/lib/liveness/video/VideoActivity;Landroid/widget/TextView;Lcom/palmpay/lib/liveness/ui/widget/AlgorithmScheduleProgressBar;Lkotlin/coroutines/Continuation;)V

    .line 37
    .line 38
    .line 39
    iput v2, p0, LC6/g;->a:I

    .line 40
    .line 41
    invoke-static {v3, p1, v1, p0}, Landroidx/lifecycle/V;->j(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/n;Lkotlin/jvm/functions/Function2;LFf/h;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    if-ne p1, v0, :cond_2

    .line 46
    .line 47
    return-object v0

    .line 48
    :cond_2
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 49
    .line 50
    return-object p1
.end method
