.class public final synthetic LC6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/palmpay/lib/liveness/video/VideoActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/palmpay/lib/liveness/video/VideoActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, LC6/a;->a:I

    iput-object p1, p0, LC6/a;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget-object p1, p0, LC6/a;->b:Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 2
    .line 3
    iget v0, p0, LC6/a;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget-object v0, Lcom/palmpay/lib/liveness/video/VideoActivity;->B:Landroid/util/Size;

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/palmpay/lib/liveness/video/VideoActivity;->f()LC6/v;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    invoke-virtual {p1}, LC6/v;->d()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    sget-object v0, Lcom/palmpay/lib/liveness/video/VideoActivity;->B:Landroid/util/Size;

    .line 19
    .line 20
    invoke-virtual {p1}, Lcom/palmpay/lib/liveness/video/VideoActivity;->i()V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_1
    sget-object v0, Lcom/palmpay/lib/liveness/video/VideoActivity;->B:Landroid/util/Size;

    .line 25
    .line 26
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_2
    sget-object v0, Lcom/palmpay/lib/liveness/video/VideoActivity;->B:Landroid/util/Size;

    .line 31
    .line 32
    invoke-virtual {p1}, Lcom/palmpay/lib/liveness/video/VideoActivity;->f()LC6/v;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-virtual {p1}, LC6/v;->d()V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    nop

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
