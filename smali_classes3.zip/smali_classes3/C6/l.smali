.class public final synthetic LC6/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LC6/o;


# direct methods
.method public synthetic constructor <init>(LC6/o;I)V
    .locals 0

    .line 1
    iput p2, p0, LC6/l;->a:I

    iput-object p1, p0, LC6/l;->b:LC6/o;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 12

    .line 1
    const/4 v0, 0x1

    .line 2
    const-string v1, "encoder"

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x0

    .line 6
    iget-object v4, p0, LC6/l;->b:LC6/o;

    .line 7
    .line 8
    iget v5, p0, LC6/l;->a:I

    .line 9
    .line 10
    packed-switch v5, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    const-string v0, "encoding finished"

    .line 14
    .line 15
    invoke-static {v0}, Lt6/a;->a(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iput-boolean v3, v4, LC6/o;->i:Z

    .line 19
    .line 20
    :try_start_0
    iget-object v0, v4, LC6/o;->c:Landroid/media/MediaMuxer;

    .line 21
    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    invoke-virtual {v0}, Landroid/media/MediaMuxer;->stop()V

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :catch_0
    move-exception v0

    .line 29
    goto :goto_1

    .line 30
    :cond_0
    :goto_0
    iget-object v0, v4, LC6/o;->f:Landroid/media/MediaCodec;

    .line 31
    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    invoke-virtual {v0}, Landroid/media/MediaCodec;->stop()V

    .line 35
    .line 36
    .line 37
    iget-object v0, v4, LC6/o;->f:Landroid/media/MediaCodec;

    .line 38
    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    invoke-virtual {v0}, Landroid/media/MediaCodec;->release()V

    .line 42
    .line 43
    .line 44
    goto :goto_2

    .line 45
    :cond_1
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    throw v2

    .line 49
    :cond_2
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 53
    :goto_1
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 54
    .line 55
    .line 56
    :goto_2
    return-void

    .line 57
    :pswitch_0
    const-string v5, "format: "

    .line 58
    .line 59
    const-string v6, "find encodeCodecName: "

    .line 60
    .line 61
    const-string v7, "find format: "

    .line 62
    .line 63
    :try_start_1
    const-string v8, "video/avc"

    .line 64
    .line 65
    const/16 v9, 0x1e0

    .line 66
    .line 67
    const/16 v10, 0x280

    .line 68
    .line 69
    invoke-static {v8, v9, v10}, Landroid/media/MediaFormat;->createVideoFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    .line 70
    .line 71
    .line 72
    move-result-object v9

    .line 73
    const-string v10, "createVideoFormat(...)"

    .line 74
    .line 75
    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    new-instance v10, Landroid/media/MediaCodecList;

    .line 79
    .line 80
    invoke-direct {v10, v3}, Landroid/media/MediaCodecList;-><init>(I)V

    .line 81
    .line 82
    .line 83
    sget v11, Lt6/a;->a:I

    .line 84
    .line 85
    new-instance v11, Ljava/lang/StringBuilder;

    .line 86
    .line 87
    invoke-direct {v11, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v7

    .line 97
    invoke-static {v7}, Lt6/a;->a(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v10, v9}, Landroid/media/MediaCodecList;->findEncoderForFormat(Landroid/media/MediaFormat;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v7

    .line 104
    new-instance v10, Ljava/lang/StringBuilder;

    .line 105
    .line 106
    invoke-direct {v10, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v6

    .line 116
    invoke-static {v6}, Lt6/a;->a(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    invoke-static {v7}, Landroid/media/MediaCodec;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    .line 120
    .line 121
    .line 122
    move-result-object v6

    .line 123
    iput-object v6, v4, LC6/o;->f:Landroid/media/MediaCodec;

    .line 124
    .line 125
    if-eqz v6, :cond_9

    .line 126
    .line 127
    new-instance v7, LC6/n;

    .line 128
    .line 129
    invoke-direct {v7, v4}, LC6/n;-><init>(LC6/o;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v6, v7}, Landroid/media/MediaCodec;->setCallback(Landroid/media/MediaCodec$Callback;)V

    .line 133
    .line 134
    .line 135
    iget-object v6, v4, LC6/o;->f:Landroid/media/MediaCodec;

    .line 136
    .line 137
    if-eqz v6, :cond_8

    .line 138
    .line 139
    invoke-virtual {v6}, Landroid/media/MediaCodec;->getCodecInfo()Landroid/media/MediaCodecInfo;

    .line 140
    .line 141
    .line 142
    move-result-object v6

    .line 143
    invoke-virtual {v6, v8}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    .line 144
    .line 145
    .line 146
    move-result-object v6

    .line 147
    iget-object v7, v6, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    .line 148
    .line 149
    const-string v8, "colorFormats"

    .line 150
    .line 151
    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    const v8, 0x7f000789

    .line 155
    .line 156
    .line 157
    invoke-static {v7, v8}, Lkotlin/collections/n;->n([II)Z

    .line 158
    .line 159
    .line 160
    move-result v7
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 161
    const-string v10, "color-format"

    .line 162
    .line 163
    if-eqz v7, :cond_3

    .line 164
    .line 165
    :try_start_2
    invoke-virtual {v9, v10, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 166
    .line 167
    .line 168
    goto :goto_3

    .line 169
    :catch_1
    move-exception v0

    .line 170
    goto/16 :goto_4

    .line 171
    .line 172
    :cond_3
    iget-object v7, v6, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    .line 173
    .line 174
    aget v7, v7, v3

    .line 175
    .line 176
    invoke-virtual {v9, v10, v7}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 177
    .line 178
    .line 179
    :goto_3
    invoke-virtual {v6}, Landroid/media/MediaCodecInfo$CodecCapabilities;->getVideoCapabilities()Landroid/media/MediaCodecInfo$VideoCapabilities;

    .line 180
    .line 181
    .line 182
    move-result-object v6

    .line 183
    invoke-virtual {v6}, Landroid/media/MediaCodecInfo$VideoCapabilities;->getBitrateRange()Landroid/util/Range;

    .line 184
    .line 185
    .line 186
    move-result-object v6

    .line 187
    invoke-virtual {v6}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    .line 188
    .line 189
    .line 190
    move-result-object v6

    .line 191
    check-cast v6, Ljava/lang/Integer;

    .line 192
    .line 193
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 194
    .line 195
    .line 196
    move-result v7

    .line 197
    const v8, 0x1e8480

    .line 198
    .line 199
    .line 200
    if-lt v7, v8, :cond_4

    .line 201
    .line 202
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 203
    .line 204
    .line 205
    move-result-object v6

    .line 206
    :cond_4
    const-string v7, "bitrate"

    .line 207
    .line 208
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 209
    .line 210
    .line 211
    move-result v8

    .line 212
    invoke-virtual {v9, v7, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 213
    .line 214
    .line 215
    const-string v7, "frame-rate"

    .line 216
    .line 217
    const/16 v8, 0x18

    .line 218
    .line 219
    invoke-virtual {v9, v7, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 220
    .line 221
    .line 222
    const-string v7, "i-frame-interval"

    .line 223
    .line 224
    invoke-virtual {v9, v7, v0}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    .line 225
    .line 226
    .line 227
    new-instance v7, Ljava/lang/StringBuilder;

    .line 228
    .line 229
    invoke-direct {v7, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 233
    .line 234
    .line 235
    const-string v5, ", rateFrame: "

    .line 236
    .line 237
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 238
    .line 239
    .line 240
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 241
    .line 242
    .line 243
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object v5

    .line 247
    invoke-static {v5}, Lt6/a;->a(Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    iget-object v5, v4, LC6/o;->f:Landroid/media/MediaCodec;

    .line 251
    .line 252
    if-eqz v5, :cond_7

    .line 253
    .line 254
    invoke-virtual {v5, v9, v2, v2, v0}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    .line 255
    .line 256
    .line 257
    iget-object v0, v4, LC6/o;->f:Landroid/media/MediaCodec;

    .line 258
    .line 259
    if-eqz v0, :cond_6

    .line 260
    .line 261
    invoke-virtual {v0}, Landroid/media/MediaCodec;->createInputSurface()Landroid/view/Surface;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    iput-object v0, v4, LC6/o;->g:Landroid/view/Surface;

    .line 266
    .line 267
    invoke-static {}, LC6/o;->a()Ljava/io/File;

    .line 268
    .line 269
    .line 270
    move-result-object v0

    .line 271
    iput-object v0, v4, LC6/o;->j:Ljava/io/File;

    .line 272
    .line 273
    new-instance v5, Landroid/media/MediaMuxer;

    .line 274
    .line 275
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 276
    .line 277
    .line 278
    move-result-object v0

    .line 279
    invoke-direct {v5, v0, v3}, Landroid/media/MediaMuxer;-><init>(Ljava/lang/String;I)V

    .line 280
    .line 281
    .line 282
    iput-object v5, v4, LC6/o;->c:Landroid/media/MediaMuxer;

    .line 283
    .line 284
    iget-object v0, v4, LC6/o;->f:Landroid/media/MediaCodec;

    .line 285
    .line 286
    if-eqz v0, :cond_5

    .line 287
    .line 288
    invoke-virtual {v0}, Landroid/media/MediaCodec;->start()V

    .line 289
    .line 290
    .line 291
    goto :goto_5

    .line 292
    :cond_5
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 293
    .line 294
    .line 295
    throw v2

    .line 296
    :cond_6
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 297
    .line 298
    .line 299
    throw v2

    .line 300
    :cond_7
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 301
    .line 302
    .line 303
    throw v2

    .line 304
    :cond_8
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 305
    .line 306
    .line 307
    throw v2

    .line 308
    :cond_9
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 309
    .line 310
    .line 311
    throw v2
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 312
    :goto_4
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 313
    .line 314
    .line 315
    iget-object v1, v4, LC6/o;->a:LC6/p;

    .line 316
    .line 317
    if-eqz v1, :cond_a

    .line 318
    .line 319
    invoke-virtual {v1, v0}, LC6/p;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 320
    .line 321
    .line 322
    :cond_a
    :goto_5
    return-void

    .line 323
    :pswitch_1
    iget-boolean v1, v4, LC6/o;->i:Z

    .line 324
    .line 325
    if-nez v1, :cond_b

    .line 326
    .line 327
    const-string v1, "Starting to encode"

    .line 328
    .line 329
    invoke-static {v1}, Lt6/a;->a(Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    iput-boolean v0, v4, LC6/o;->i:Z

    .line 333
    .line 334
    goto :goto_6

    .line 335
    :cond_b
    const-string v0, "Encoding already started"

    .line 336
    .line 337
    invoke-static {v0}, Lt6/a;->b(Ljava/lang/String;)V

    .line 338
    .line 339
    .line 340
    :goto_6
    return-void

    .line 341
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
