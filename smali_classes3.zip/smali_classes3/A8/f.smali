.class public final synthetic LA8/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LA8/h;


# direct methods
.method public synthetic constructor <init>(LA8/h;I)V
    .locals 0

    .line 1
    iput p2, p0, LA8/f;->a:I

    iput-object p1, p0, LA8/f;->b:LA8/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget p1, p0, LA8/f;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LA8/f;->b:LA8/h;

    .line 7
    .line 8
    iget-object p1, p1, LA8/h;->a:Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object p1, p0, LA8/f;->b:LA8/h;

    .line 15
    .line 16
    iget-object p1, p1, LA8/h;->a:Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 17
    .line 18
    iget-object p1, p1, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;->c:Landroid/widget/CheckBox;

    .line 19
    .line 20
    invoke-virtual {p1}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    xor-int/lit8 v0, v0, 0x1

    .line 25
    .line 26
    invoke-virtual {p1, v0}, Landroid/widget/CompoundButton;->setChecked(Z)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
