.class public final synthetic LA8/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA8/c;->a:I

    iput-object p2, p0, LA8/c;->b:Ljava/lang/Object;

    iput-object p3, p0, LA8/c;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const/16 v3, 0x1c

    .line 6
    .line 7
    sget-object v4, LJ1/g;->a:Landroidx/camera/core/impl/utils/executor/a;

    .line 8
    .line 9
    const-string v5, "mActivity"

    .line 10
    .line 11
    const-string v6, "LoanOutstandingBill"

    .line 12
    .line 13
    const-string v7, "loanProduct"

    .line 14
    .line 15
    const-string v8, "cardNo"

    .line 16
    .line 17
    const-string v9, "accountType"

    .line 18
    .line 19
    const-string v10, "billId"

    .line 20
    .line 21
    const/4 v13, 0x0

    .line 22
    const/4 v14, 0x1

    .line 23
    const/4 v15, 0x0

    .line 24
    const-wide/16 v16, 0x0

    .line 25
    .line 26
    iget-object v11, v0, LA8/c;->c:Ljava/lang/Object;

    .line 27
    .line 28
    iget-object v12, v0, LA8/c;->b:Ljava/lang/Object;

    .line 29
    .line 30
    iget v2, v0, LA8/c;->a:I

    .line 31
    .line 32
    packed-switch v2, :pswitch_data_0

    .line 33
    .line 34
    .line 35
    sget v1, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->w:I

    .line 36
    .line 37
    check-cast v12, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 38
    .line 39
    if-eqz v12, :cond_0

    .line 40
    .line 41
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;->getCurrentRepaymentDetail()Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    goto :goto_0

    .line 46
    :cond_0
    move-object v1, v15

    .line 47
    :goto_0
    if-eqz v1, :cond_7

    .line 48
    .line 49
    if-eqz v12, :cond_2

    .line 50
    .line 51
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;->getCurrentRepaymentDetail()Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    if-eqz v1, :cond_2

    .line 56
    .line 57
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;->getCashRepaymentInfo()Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    if-eqz v1, :cond_2

    .line 62
    .line 63
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;->getOutstandingAmount()Ljava/lang/Long;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    if-nez v1, :cond_1

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_1
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 71
    .line 72
    .line 73
    move-result-wide v1

    .line 74
    cmp-long v1, v1, v16

    .line 75
    .line 76
    if-nez v1, :cond_2

    .line 77
    .line 78
    goto/16 :goto_5

    .line 79
    .line 80
    :cond_2
    :goto_1
    new-instance v1, Landroid/os/Bundle;

    .line 81
    .line 82
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 83
    .line 84
    .line 85
    check-cast v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 86
    .line 87
    iget-object v2, v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->v:Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 88
    .line 89
    if-eqz v2, :cond_3

    .line 90
    .line 91
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;->getCurrentRepaymentDetail()Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;

    .line 92
    .line 93
    .line 94
    move-result-object v2

    .line 95
    if-eqz v2, :cond_3

    .line 96
    .line 97
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;->getCashRepaymentInfo()Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    if-eqz v2, :cond_3

    .line 102
    .line 103
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;->getBillId()Ljava/lang/Long;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    goto :goto_2

    .line 108
    :cond_3
    move-object v2, v15

    .line 109
    :goto_2
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    invoke-virtual {v1, v10, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    iget-object v2, v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->v:Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 117
    .line 118
    if-eqz v2, :cond_4

    .line 119
    .line 120
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;->getCurrentRepaymentDetail()Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    if-eqz v2, :cond_4

    .line 125
    .line 126
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;->getCashRepaymentInfo()Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    if-eqz v2, :cond_4

    .line 131
    .line 132
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;->getAccountType()Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v2

    .line 136
    goto :goto_3

    .line 137
    :cond_4
    move-object v2, v15

    .line 138
    :goto_3
    invoke-virtual {v1, v9, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    iget-object v2, v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->v:Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 142
    .line 143
    if-eqz v2, :cond_5

    .line 144
    .line 145
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;->getCurrentRepaymentDetail()Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    if-eqz v2, :cond_5

    .line 150
    .line 151
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;->getCashRepaymentInfo()Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    if-eqz v2, :cond_5

    .line 156
    .line 157
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;->getCardNo()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v2

    .line 161
    goto :goto_4

    .line 162
    :cond_5
    move-object v2, v15

    .line 163
    :goto_4
    invoke-virtual {v1, v8, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    iget-object v2, v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->v:Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 167
    .line 168
    if-eqz v2, :cond_6

    .line 169
    .line 170
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;->getCurrentRepaymentDetail()Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;

    .line 171
    .line 172
    .line 173
    move-result-object v2

    .line 174
    if-eqz v2, :cond_6

    .line 175
    .line 176
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CurrentRepaymentDetail;->getCashRepaymentInfo()Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;

    .line 177
    .line 178
    .line 179
    move-result-object v2

    .line 180
    if-eqz v2, :cond_6

    .line 181
    .line 182
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CashRepaymentInfo;->getLoanProduct()Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v15

    .line 186
    :cond_6
    invoke-virtual {v1, v7, v15}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    invoke-static {v1, v6}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    :cond_7
    :goto_5
    return-void

    .line 193
    :pswitch_0
    check-cast v12, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 194
    .line 195
    iget-object v1, v12, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->p:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 196
    .line 197
    check-cast v11, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 198
    .line 199
    const-string v2, "oc_card_no"

    .line 200
    .line 201
    if-eqz v1, :cond_b

    .line 202
    .line 203
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getAccountStatus()Ljava/lang/Integer;

    .line 204
    .line 205
    .line 206
    move-result-object v1

    .line 207
    if-nez v1, :cond_8

    .line 208
    .line 209
    goto :goto_7

    .line 210
    :cond_8
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 211
    .line 212
    .line 213
    move-result v1

    .line 214
    if-ne v1, v14, :cond_b

    .line 215
    .line 216
    if-eqz v11, :cond_9

    .line 217
    .line 218
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getNextCycleInstallmentAmount()Ljava/lang/Long;

    .line 219
    .line 220
    .line 221
    move-result-object v1

    .line 222
    if-eqz v1, :cond_9

    .line 223
    .line 224
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 225
    .line 226
    .line 227
    move-result-wide v3

    .line 228
    goto :goto_6

    .line 229
    :cond_9
    move-wide/from16 v3, v16

    .line 230
    .line 231
    :goto_6
    cmp-long v1, v3, v16

    .line 232
    .line 233
    if-lez v1, :cond_b

    .line 234
    .line 235
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    const-string v3, "/credit_score/oc_all_bill_activity"

    .line 240
    .line 241
    invoke-virtual {v1, v3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 242
    .line 243
    .line 244
    move-result-object v1

    .line 245
    iget-object v3, v12, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->p:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 246
    .line 247
    if-eqz v3, :cond_a

    .line 248
    .line 249
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getCardNo()Ljava/lang/String;

    .line 250
    .line 251
    .line 252
    move-result-object v15

    .line 253
    :cond_a
    invoke-virtual {v1, v2, v15}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    const-string v2, "oc_bill_list_type"

    .line 258
    .line 259
    const-string v3, "oc_all_bill"

    .line 260
    .line 261
    invoke-virtual {v1, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 262
    .line 263
    .line 264
    move-result-object v1

    .line 265
    invoke-virtual {v1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    goto/16 :goto_c

    .line 269
    .line 270
    :cond_b
    :goto_7
    if-eqz v11, :cond_13

    .line 271
    .line 272
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getBillOutstandingAmount()J

    .line 273
    .line 274
    .line 275
    move-result-wide v3

    .line 276
    cmp-long v1, v3, v16

    .line 277
    .line 278
    if-nez v1, :cond_c

    .line 279
    .line 280
    goto :goto_c

    .line 281
    :cond_c
    iget-object v1, v12, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->p:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 282
    .line 283
    if-eqz v1, :cond_f

    .line 284
    .line 285
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getOutstandingBillCount()Ljava/lang/Integer;

    .line 286
    .line 287
    .line 288
    move-result-object v1

    .line 289
    if-nez v1, :cond_d

    .line 290
    .line 291
    goto :goto_8

    .line 292
    :cond_d
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 293
    .line 294
    .line 295
    move-result v1

    .line 296
    if-ne v1, v14, :cond_f

    .line 297
    .line 298
    iget-object v1, v12, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->p:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 299
    .line 300
    if-eqz v1, :cond_e

    .line 301
    .line 302
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getOutstandingBillId()Ljava/lang/Long;

    .line 303
    .line 304
    .line 305
    move-result-object v1

    .line 306
    goto :goto_9

    .line 307
    :cond_e
    move-object v1, v15

    .line 308
    goto :goto_9

    .line 309
    :cond_f
    :goto_8
    iget-object v1, v12, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->p:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 310
    .line 311
    if-eqz v1, :cond_e

    .line 312
    .line 313
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getBillId()Ljava/lang/Long;

    .line 314
    .line 315
    .line 316
    move-result-object v1

    .line 317
    :goto_9
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 318
    .line 319
    .line 320
    move-result-object v3

    .line 321
    const-string v4, "/credit_score/oc_bill_activity"

    .line 322
    .line 323
    invoke-virtual {v3, v4}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 324
    .line 325
    .line 326
    move-result-object v3

    .line 327
    iget-object v4, v12, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->p:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 328
    .line 329
    if-eqz v4, :cond_10

    .line 330
    .line 331
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getCardNo()Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object v15

    .line 335
    :cond_10
    invoke-virtual {v3, v2, v15}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 336
    .line 337
    .line 338
    move-result-object v2

    .line 339
    if-eqz v1, :cond_11

    .line 340
    .line 341
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 342
    .line 343
    .line 344
    move-result-wide v3

    .line 345
    goto :goto_a

    .line 346
    :cond_11
    move-wide/from16 v3, v16

    .line 347
    .line 348
    :goto_a
    const-string v1, "oc_bill_id"

    .line 349
    .line 350
    invoke-virtual {v2, v1, v3, v4}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 351
    .line 352
    .line 353
    move-result-object v1

    .line 354
    iget-object v2, v12, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->p:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 355
    .line 356
    if-eqz v2, :cond_12

    .line 357
    .line 358
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getRepaymentDateStamp()J

    .line 359
    .line 360
    .line 361
    move-result-wide v11

    .line 362
    goto :goto_b

    .line 363
    :cond_12
    move-wide/from16 v11, v16

    .line 364
    .line 365
    :goto_b
    const-string v2, "oc_future_repayment_date"

    .line 366
    .line 367
    invoke-virtual {v1, v2, v11, v12}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 368
    .line 369
    .line 370
    move-result-object v1

    .line 371
    invoke-virtual {v1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 372
    .line 373
    .line 374
    :cond_13
    :goto_c
    return-void

    .line 375
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->w:I

    .line 376
    .line 377
    check-cast v12, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 378
    .line 379
    if-eqz v12, :cond_14

    .line 380
    .line 381
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCurrentCashLoanBill()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;

    .line 382
    .line 383
    .line 384
    move-result-object v1

    .line 385
    goto :goto_d

    .line 386
    :cond_14
    move-object v1, v15

    .line 387
    :goto_d
    if-eqz v1, :cond_1a

    .line 388
    .line 389
    if-eqz v12, :cond_15

    .line 390
    .line 391
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCurrentCashLoanBill()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;

    .line 392
    .line 393
    .line 394
    move-result-object v1

    .line 395
    if-eqz v1, :cond_15

    .line 396
    .line 397
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;->getOutstandingAmount()J

    .line 398
    .line 399
    .line 400
    move-result-wide v1

    .line 401
    cmp-long v1, v1, v16

    .line 402
    .line 403
    if-nez v1, :cond_15

    .line 404
    .line 405
    goto :goto_11

    .line 406
    :cond_15
    new-instance v1, Landroid/os/Bundle;

    .line 407
    .line 408
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 409
    .line 410
    .line 411
    check-cast v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 412
    .line 413
    iget-object v2, v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->t:Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 414
    .line 415
    if-eqz v2, :cond_16

    .line 416
    .line 417
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCurrentCashLoanBill()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;

    .line 418
    .line 419
    .line 420
    move-result-object v2

    .line 421
    if-eqz v2, :cond_16

    .line 422
    .line 423
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;->getBillId()Ljava/lang/Long;

    .line 424
    .line 425
    .line 426
    move-result-object v2

    .line 427
    goto :goto_e

    .line 428
    :cond_16
    move-object v2, v15

    .line 429
    :goto_e
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 430
    .line 431
    .line 432
    move-result-object v2

    .line 433
    invoke-virtual {v1, v10, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 434
    .line 435
    .line 436
    iget-object v2, v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->t:Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 437
    .line 438
    if-eqz v2, :cond_17

    .line 439
    .line 440
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCurrentCashLoanBill()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;

    .line 441
    .line 442
    .line 443
    move-result-object v2

    .line 444
    if-eqz v2, :cond_17

    .line 445
    .line 446
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;->getAccountType()Ljava/lang/String;

    .line 447
    .line 448
    .line 449
    move-result-object v2

    .line 450
    goto :goto_f

    .line 451
    :cond_17
    move-object v2, v15

    .line 452
    :goto_f
    invoke-virtual {v1, v9, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 453
    .line 454
    .line 455
    iget-object v2, v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->t:Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 456
    .line 457
    if-eqz v2, :cond_18

    .line 458
    .line 459
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCurrentCashLoanBill()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;

    .line 460
    .line 461
    .line 462
    move-result-object v2

    .line 463
    if-eqz v2, :cond_18

    .line 464
    .line 465
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;->getCardNo()Ljava/lang/String;

    .line 466
    .line 467
    .line 468
    move-result-object v2

    .line 469
    goto :goto_10

    .line 470
    :cond_18
    move-object v2, v15

    .line 471
    :goto_10
    invoke-virtual {v1, v8, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 472
    .line 473
    .line 474
    iget-object v2, v11, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->t:Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 475
    .line 476
    if-eqz v2, :cond_19

    .line 477
    .line 478
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCurrentCashLoanBill()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;

    .line 479
    .line 480
    .line 481
    move-result-object v2

    .line 482
    if-eqz v2, :cond_19

    .line 483
    .line 484
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;->getLoanProduct()Ljava/lang/String;

    .line 485
    .line 486
    .line 487
    move-result-object v15

    .line 488
    :cond_19
    invoke-virtual {v1, v7, v15}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 489
    .line 490
    .line 491
    invoke-static {v1, v6}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 492
    .line 493
    .line 494
    :cond_1a
    :goto_11
    return-void

    .line 495
    :pswitch_2
    sget-object v1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->X:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment$a;

    .line 496
    .line 497
    new-instance v1, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;

    .line 498
    .line 499
    check-cast v12, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;

    .line 500
    .line 501
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/BaseFragment;->c:Landroidx/fragment/app/E;

    .line 502
    .line 503
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 504
    .line 505
    .line 506
    invoke-direct {v1, v2}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;-><init>(Landroid/content/Context;)V

    .line 507
    .line 508
    .line 509
    invoke-virtual {v1}, LO6/f;->show()V

    .line 510
    .line 511
    .line 512
    check-cast v11, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;

    .line 513
    .line 514
    iget-object v2, v11, Lcom/transsnet/palmpay/cash_in/bean/BillDetail;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 515
    .line 516
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;->fillData(Lcom/transsnet/palmpay/core/bean/BillProcessDetail;)V

    .line 517
    .line 518
    .line 519
    return-void

    .line 520
    :pswitch_3
    sget-object v1, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;->X:Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment$a;

    .line 521
    .line 522
    check-cast v12, Lcom/transsnet/palmpay/cash_in/ui/fragment/FundDetailFragment;

    .line 523
    .line 524
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 525
    .line 526
    .line 527
    new-instance v1, Lcom/transsnet/palmpay/cash_in/ui/dialog/CashInTaxDetailDialog;

    .line 528
    .line 529
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/BaseFragment;->c:Landroidx/fragment/app/E;

    .line 530
    .line 531
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 532
    .line 533
    .line 534
    invoke-direct {v1, v2}, Lcom/transsnet/palmpay/cash_in/ui/dialog/CashInTaxDetailDialog;-><init>(Landroid/content/Context;)V

    .line 535
    .line 536
    .line 537
    invoke-virtual {v1}, LO6/f;->show()V

    .line 538
    .line 539
    .line 540
    check-cast v11, Lcom/transsnet/palmpay/cash_in/bean/TaxItem;

    .line 541
    .line 542
    invoke-virtual {v1, v11}, Lcom/transsnet/palmpay/cash_in/ui/dialog/CashInTaxDetailDialog;->update(Lcom/transsnet/palmpay/cash_in/bean/TaxItem;)V

    .line 543
    .line 544
    .line 545
    return-void

    .line 546
    :pswitch_4
    check-cast v11, Lcom/skydoves/balloon/Balloon;

    .line 547
    .line 548
    const-string v2, "this$0"

    .line 549
    .line 550
    invoke-static {v11, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 551
    .line 552
    .line 553
    check-cast v12, LG7/u;

    .line 554
    .line 555
    if-nez v12, :cond_1b

    .line 556
    .line 557
    goto :goto_12

    .line 558
    :cond_1b
    const-string v2, "it"

    .line 559
    .line 560
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 561
    .line 562
    .line 563
    invoke-virtual {v12, v1}, LG7/u;->onBalloonClick(Landroid/view/View;)V

    .line 564
    .line 565
    .line 566
    :goto_12
    iget-object v1, v11, Lcom/skydoves/balloon/Balloon;->b:LG7/g;

    .line 567
    .line 568
    iget-boolean v1, v1, LG7/g;->K:Z

    .line 569
    .line 570
    if-eqz v1, :cond_1c

    .line 571
    .line 572
    invoke-virtual {v11}, Lcom/skydoves/balloon/Balloon;->f()V

    .line 573
    .line 574
    .line 575
    :cond_1c
    return-void

    .line 576
    :pswitch_5
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeFragment;

    .line 577
    .line 578
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 579
    .line 580
    .line 581
    move-result-object v1

    .line 582
    check-cast v11, Ljava/lang/String;

    .line 583
    .line 584
    invoke-static {v1, v11}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 585
    .line 586
    .line 587
    move-result-object v1

    .line 588
    invoke-static {v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 589
    .line 590
    .line 591
    return-void

    .line 592
    :pswitch_6
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayContactFavoriteFragment;

    .line 593
    .line 594
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 595
    .line 596
    check-cast v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;

    .line 597
    .line 598
    if-eqz v1, :cond_1d

    .line 599
    .line 600
    check-cast v11, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 601
    .line 602
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 603
    .line 604
    .line 605
    move-result-object v2

    .line 606
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;->g(Ljava/lang/String;)V

    .line 607
    .line 608
    .line 609
    :cond_1d
    return-void

    .line 610
    :pswitch_7
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayContactAllFragment;

    .line 611
    .line 612
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 613
    .line 614
    check-cast v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;

    .line 615
    .line 616
    if-eqz v1, :cond_1e

    .line 617
    .line 618
    check-cast v11, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 619
    .line 620
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 621
    .line 622
    .line 623
    move-result-object v2

    .line 624
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;->g(Ljava/lang/String;)V

    .line 625
    .line 626
    .line 627
    :cond_1e
    return-void

    .line 628
    :pswitch_8
    sget-object v1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment;->L:Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment$a;

    .line 629
    .line 630
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment;

    .line 631
    .line 632
    check-cast v11, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;

    .line 633
    .line 634
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 635
    .line 636
    .line 637
    move-result-object v1

    .line 638
    iget-object v2, v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment;->o:Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;

    .line 639
    .line 640
    if-eqz v2, :cond_1f

    .line 641
    .line 642
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 643
    .line 644
    .line 645
    move-result-object v2

    .line 646
    goto :goto_13

    .line 647
    :cond_1f
    move-object v2, v15

    .line 648
    :goto_13
    invoke-static {v1, v2, v13}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 649
    .line 650
    .line 651
    move-result v1

    .line 652
    if-eqz v1, :cond_20

    .line 653
    .line 654
    goto/16 :goto_1d

    .line 655
    .line 656
    :cond_20
    iput-object v11, v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment;->o:Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;

    .line 657
    .line 658
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 659
    .line 660
    check-cast v1, Lod/m;

    .line 661
    .line 662
    if-eqz v1, :cond_21

    .line 663
    .line 664
    iget-object v1, v1, Lod/m;->b:Lcom/google/android/flexbox/FlexboxLayout;

    .line 665
    .line 666
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 667
    .line 668
    .line 669
    move-result v1

    .line 670
    goto :goto_14

    .line 671
    :cond_21
    move v1, v13

    .line 672
    :goto_14
    move v2, v13

    .line 673
    :goto_15
    if-ge v2, v1, :cond_2d

    .line 674
    .line 675
    iget-object v3, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 676
    .line 677
    check-cast v3, Lod/m;

    .line 678
    .line 679
    if-eqz v3, :cond_22

    .line 680
    .line 681
    iget-object v3, v3, Lod/m;->b:Lcom/google/android/flexbox/FlexboxLayout;

    .line 682
    .line 683
    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 684
    .line 685
    .line 686
    move-result-object v3

    .line 687
    goto :goto_16

    .line 688
    :cond_22
    move-object v3, v15

    .line 689
    :goto_16
    instance-of v5, v3, Landroid/widget/ImageView;

    .line 690
    .line 691
    if-eqz v5, :cond_23

    .line 692
    .line 693
    check-cast v3, Landroid/widget/ImageView;

    .line 694
    .line 695
    goto :goto_17

    .line 696
    :cond_23
    move-object v3, v15

    .line 697
    :goto_17
    iget-object v5, v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment;->w:Ljava/util/List;

    .line 698
    .line 699
    if-eqz v5, :cond_24

    .line 700
    .line 701
    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 702
    .line 703
    .line 704
    move-result-object v5

    .line 705
    check-cast v5, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;

    .line 706
    .line 707
    goto :goto_18

    .line 708
    :cond_24
    move-object v5, v15

    .line 709
    :goto_18
    if-eqz v3, :cond_2c

    .line 710
    .line 711
    invoke-virtual {v12}, Lcom/transsnet/palmpay/core/base/BaseFragment;->m()Z

    .line 712
    .line 713
    .line 714
    move-result v6

    .line 715
    if-eqz v6, :cond_28

    .line 716
    .line 717
    if-eqz v5, :cond_25

    .line 718
    .line 719
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 720
    .line 721
    .line 722
    move-result-object v6

    .line 723
    goto :goto_19

    .line 724
    :cond_25
    move-object v6, v15

    .line 725
    :goto_19
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 726
    .line 727
    .line 728
    move-result-object v7

    .line 729
    invoke-static {v6, v7, v13}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 730
    .line 731
    .line 732
    move-result v6

    .line 733
    if-eqz v6, :cond_27

    .line 734
    .line 735
    if-eqz v5, :cond_26

    .line 736
    .line 737
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getSelectedDarkUrl()Ljava/lang/String;

    .line 738
    .line 739
    .line 740
    move-result-object v5

    .line 741
    goto :goto_1b

    .line 742
    :cond_26
    move-object v5, v15

    .line 743
    goto :goto_1b

    .line 744
    :cond_27
    if-eqz v5, :cond_26

    .line 745
    .line 746
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getUnselectedDarkUrl()Ljava/lang/String;

    .line 747
    .line 748
    .line 749
    move-result-object v5

    .line 750
    goto :goto_1b

    .line 751
    :cond_28
    if-eqz v5, :cond_29

    .line 752
    .line 753
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 754
    .line 755
    .line 756
    move-result-object v6

    .line 757
    goto :goto_1a

    .line 758
    :cond_29
    move-object v6, v15

    .line 759
    :goto_1a
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 760
    .line 761
    .line 762
    move-result-object v7

    .line 763
    invoke-static {v6, v7, v13}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 764
    .line 765
    .line 766
    move-result v6

    .line 767
    if-eqz v6, :cond_2a

    .line 768
    .line 769
    if-eqz v5, :cond_26

    .line 770
    .line 771
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getSelectedUrl()Ljava/lang/String;

    .line 772
    .line 773
    .line 774
    move-result-object v5

    .line 775
    goto :goto_1b

    .line 776
    :cond_2a
    if-eqz v5, :cond_26

    .line 777
    .line 778
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getUnselectedUrl()Ljava/lang/String;

    .line 779
    .line 780
    .line 781
    move-result-object v5

    .line 782
    :goto_1b
    new-instance v6, LEd/D;

    .line 783
    .line 784
    invoke-direct {v6, v3, v14}, LEd/D;-><init>(Landroid/widget/ImageView;I)V

    .line 785
    .line 786
    .line 787
    invoke-static {v3}, LPa/r0;->n(Landroid/view/View;)Z

    .line 788
    .line 789
    .line 790
    move-result v7

    .line 791
    if-nez v7, :cond_2b

    .line 792
    .line 793
    goto :goto_1c

    .line 794
    :cond_2b
    invoke-static {v3}, Lcom/bumptech/glide/b;->f(Landroid/view/View;)Lcom/bumptech/glide/p;

    .line 795
    .line 796
    .line 797
    move-result-object v3

    .line 798
    invoke-virtual {v3}, Lcom/bumptech/glide/p;->b()Lcom/bumptech/glide/m;

    .line 799
    .line 800
    .line 801
    move-result-object v3

    .line 802
    new-instance v7, LRb/a;

    .line 803
    .line 804
    invoke-direct {v7, v5}, LRb/a;-><init>(Ljava/lang/String;)V

    .line 805
    .line 806
    .line 807
    invoke-virtual {v3, v7}, Lcom/bumptech/glide/m;->a0(Ljava/lang/Object;)Lcom/bumptech/glide/m;

    .line 808
    .line 809
    .line 810
    move-result-object v3

    .line 811
    invoke-virtual {v3, v6, v15, v3, v4}, Lcom/bumptech/glide/m;->T(Lcom/bumptech/glide/request/target/Target;LG1/c;LG1/a;Ljava/util/concurrent/Executor;)V

    .line 812
    .line 813
    .line 814
    :cond_2c
    :goto_1c
    add-int/2addr v2, v14

    .line 815
    goto/16 :goto_15

    .line 816
    .line 817
    :cond_2d
    invoke-virtual {v12}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment;->w()V

    .line 818
    .line 819
    .line 820
    :goto_1d
    return-void

    .line 821
    :pswitch_9
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomeFragment;

    .line 822
    .line 823
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 824
    .line 825
    .line 826
    move-result-object v1

    .line 827
    check-cast v11, Ljava/lang/String;

    .line 828
    .line 829
    invoke-static {v1, v11}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 830
    .line 831
    .line 832
    move-result-object v1

    .line 833
    invoke-static {v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 834
    .line 835
    .line 836
    return-void

    .line 837
    :pswitch_a
    sget-object v1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment;->M:Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment$a;

    .line 838
    .line 839
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment;

    .line 840
    .line 841
    check-cast v11, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;

    .line 842
    .line 843
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 844
    .line 845
    .line 846
    move-result-object v1

    .line 847
    iget-object v2, v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment;->o:Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;

    .line 848
    .line 849
    if-eqz v2, :cond_2e

    .line 850
    .line 851
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 852
    .line 853
    .line 854
    move-result-object v2

    .line 855
    goto :goto_1e

    .line 856
    :cond_2e
    move-object v2, v15

    .line 857
    :goto_1e
    invoke-static {v1, v2, v13}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 858
    .line 859
    .line 860
    move-result v1

    .line 861
    if-eqz v1, :cond_2f

    .line 862
    .line 863
    goto/16 :goto_28

    .line 864
    .line 865
    :cond_2f
    iput-object v11, v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment;->o:Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;

    .line 866
    .line 867
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 868
    .line 869
    check-cast v1, Lod/k;

    .line 870
    .line 871
    if-eqz v1, :cond_30

    .line 872
    .line 873
    iget-object v1, v1, Lod/k;->b:Lcom/google/android/flexbox/FlexboxLayout;

    .line 874
    .line 875
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 876
    .line 877
    .line 878
    move-result v1

    .line 879
    goto :goto_1f

    .line 880
    :cond_30
    move v1, v13

    .line 881
    :goto_1f
    move v2, v13

    .line 882
    :goto_20
    if-ge v2, v1, :cond_3c

    .line 883
    .line 884
    iget-object v3, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 885
    .line 886
    check-cast v3, Lod/k;

    .line 887
    .line 888
    if-eqz v3, :cond_31

    .line 889
    .line 890
    iget-object v3, v3, Lod/k;->b:Lcom/google/android/flexbox/FlexboxLayout;

    .line 891
    .line 892
    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 893
    .line 894
    .line 895
    move-result-object v3

    .line 896
    goto :goto_21

    .line 897
    :cond_31
    move-object v3, v15

    .line 898
    :goto_21
    instance-of v5, v3, Landroid/widget/ImageView;

    .line 899
    .line 900
    if-eqz v5, :cond_32

    .line 901
    .line 902
    check-cast v3, Landroid/widget/ImageView;

    .line 903
    .line 904
    goto :goto_22

    .line 905
    :cond_32
    move-object v3, v15

    .line 906
    :goto_22
    iget-object v5, v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment;->w:Ljava/util/List;

    .line 907
    .line 908
    if-eqz v5, :cond_33

    .line 909
    .line 910
    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 911
    .line 912
    .line 913
    move-result-object v5

    .line 914
    check-cast v5, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;

    .line 915
    .line 916
    goto :goto_23

    .line 917
    :cond_33
    move-object v5, v15

    .line 918
    :goto_23
    if-eqz v3, :cond_3b

    .line 919
    .line 920
    invoke-virtual {v12}, Lcom/transsnet/palmpay/core/base/BaseFragment;->m()Z

    .line 921
    .line 922
    .line 923
    move-result v6

    .line 924
    if-eqz v6, :cond_37

    .line 925
    .line 926
    if-eqz v5, :cond_34

    .line 927
    .line 928
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 929
    .line 930
    .line 931
    move-result-object v6

    .line 932
    goto :goto_24

    .line 933
    :cond_34
    move-object v6, v15

    .line 934
    :goto_24
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 935
    .line 936
    .line 937
    move-result-object v7

    .line 938
    invoke-static {v6, v7, v13}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 939
    .line 940
    .line 941
    move-result v6

    .line 942
    if-eqz v6, :cond_36

    .line 943
    .line 944
    if-eqz v5, :cond_35

    .line 945
    .line 946
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getSelectedDarkUrl()Ljava/lang/String;

    .line 947
    .line 948
    .line 949
    move-result-object v5

    .line 950
    goto :goto_26

    .line 951
    :cond_35
    move-object v5, v15

    .line 952
    goto :goto_26

    .line 953
    :cond_36
    if-eqz v5, :cond_35

    .line 954
    .line 955
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getUnselectedDarkUrl()Ljava/lang/String;

    .line 956
    .line 957
    .line 958
    move-result-object v5

    .line 959
    goto :goto_26

    .line 960
    :cond_37
    if-eqz v5, :cond_38

    .line 961
    .line 962
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 963
    .line 964
    .line 965
    move-result-object v6

    .line 966
    goto :goto_25

    .line 967
    :cond_38
    move-object v6, v15

    .line 968
    :goto_25
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getLabel()Ljava/lang/String;

    .line 969
    .line 970
    .line 971
    move-result-object v7

    .line 972
    invoke-static {v6, v7, v13}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 973
    .line 974
    .line 975
    move-result v6

    .line 976
    if-eqz v6, :cond_39

    .line 977
    .line 978
    if-eqz v5, :cond_35

    .line 979
    .line 980
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getSelectedUrl()Ljava/lang/String;

    .line 981
    .line 982
    .line 983
    move-result-object v5

    .line 984
    goto :goto_26

    .line 985
    :cond_39
    if-eqz v5, :cond_35

    .line 986
    .line 987
    invoke-virtual {v5}, Lcom/transsnet/palmpay/send_money/bean/resp/LabelBean;->getUnselectedUrl()Ljava/lang/String;

    .line 988
    .line 989
    .line 990
    move-result-object v5

    .line 991
    :goto_26
    new-instance v6, LEd/D;

    .line 992
    .line 993
    invoke-direct {v6, v3, v13}, LEd/D;-><init>(Landroid/widget/ImageView;I)V

    .line 994
    .line 995
    .line 996
    invoke-static {v3}, LPa/r0;->n(Landroid/view/View;)Z

    .line 997
    .line 998
    .line 999
    move-result v7

    .line 1000
    if-nez v7, :cond_3a

    .line 1001
    .line 1002
    goto :goto_27

    .line 1003
    :cond_3a
    invoke-static {v3}, Lcom/bumptech/glide/b;->f(Landroid/view/View;)Lcom/bumptech/glide/p;

    .line 1004
    .line 1005
    .line 1006
    move-result-object v3

    .line 1007
    invoke-virtual {v3}, Lcom/bumptech/glide/p;->b()Lcom/bumptech/glide/m;

    .line 1008
    .line 1009
    .line 1010
    move-result-object v3

    .line 1011
    new-instance v7, LRb/a;

    .line 1012
    .line 1013
    invoke-direct {v7, v5}, LRb/a;-><init>(Ljava/lang/String;)V

    .line 1014
    .line 1015
    .line 1016
    invoke-virtual {v3, v7}, Lcom/bumptech/glide/m;->a0(Ljava/lang/Object;)Lcom/bumptech/glide/m;

    .line 1017
    .line 1018
    .line 1019
    move-result-object v3

    .line 1020
    invoke-virtual {v3, v6, v15, v3, v4}, Lcom/bumptech/glide/m;->T(Lcom/bumptech/glide/request/target/Target;LG1/c;LG1/a;Ljava/util/concurrent/Executor;)V

    .line 1021
    .line 1022
    .line 1023
    :cond_3b
    :goto_27
    add-int/2addr v2, v14

    .line 1024
    goto/16 :goto_20

    .line 1025
    .line 1026
    :cond_3c
    invoke-virtual {v12}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment;->x()V

    .line 1027
    .line 1028
    .line 1029
    :goto_28
    return-void

    .line 1030
    :pswitch_b
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountPalmPayContactFragment;

    .line 1031
    .line 1032
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 1033
    .line 1034
    check-cast v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;

    .line 1035
    .line 1036
    if-eqz v1, :cond_3d

    .line 1037
    .line 1038
    check-cast v11, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 1039
    .line 1040
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 1041
    .line 1042
    .line 1043
    move-result-object v2

    .line 1044
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;->g(Ljava/lang/String;)V

    .line 1045
    .line 1046
    .line 1047
    :cond_3d
    return-void

    .line 1048
    :pswitch_c
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;

    .line 1049
    .line 1050
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 1051
    .line 1052
    check-cast v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 1053
    .line 1054
    if-eqz v1, :cond_3e

    .line 1055
    .line 1056
    check-cast v11, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 1057
    .line 1058
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 1059
    .line 1060
    .line 1061
    move-result-object v2

    .line 1062
    new-instance v4, LKd/U0;

    .line 1063
    .line 1064
    invoke-direct {v4, v2, v15}, LKd/U0;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 1065
    .line 1066
    .line 1067
    iget-object v2, v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->i:Lcom/transsnet/palmpay/core/base/l;

    .line 1068
    .line 1069
    invoke-static {v1, v4, v2, v13, v3}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 1070
    .line 1071
    .line 1072
    :cond_3e
    return-void

    .line 1073
    :pswitch_d
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;

    .line 1074
    .line 1075
    invoke-virtual {v12, v14}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 1076
    .line 1077
    .line 1078
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 1079
    .line 1080
    check-cast v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 1081
    .line 1082
    if-eqz v1, :cond_3f

    .line 1083
    .line 1084
    check-cast v11, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 1085
    .line 1086
    invoke-virtual {v11}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 1087
    .line 1088
    .line 1089
    move-result-object v2

    .line 1090
    new-instance v4, LKd/U0;

    .line 1091
    .line 1092
    invoke-direct {v4, v2, v15}, LKd/U0;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 1093
    .line 1094
    .line 1095
    iget-object v2, v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->i:Lcom/transsnet/palmpay/core/base/l;

    .line 1096
    .line 1097
    invoke-static {v1, v4, v2, v13, v3}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 1098
    .line 1099
    .line 1100
    :cond_3f
    return-void

    .line 1101
    :pswitch_e
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 1102
    .line 1103
    .line 1104
    move-result-object v1

    .line 1105
    const-string v2, "AddMoney_Share_Click"

    .line 1106
    .line 1107
    invoke-virtual {v1, v2}, LPa/n0;->v(Ljava/lang/String;)V

    .line 1108
    .line 1109
    .line 1110
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 1111
    .line 1112
    .line 1113
    move-result-object v1

    .line 1114
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 1115
    .line 1116
    .line 1117
    move-result-object v1

    .line 1118
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/db/entity/User;->getFullName()Ljava/lang/String;

    .line 1119
    .line 1120
    .line 1121
    move-result-object v1

    .line 1122
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1123
    .line 1124
    .line 1125
    move-result v1

    .line 1126
    if-nez v1, :cond_40

    .line 1127
    .line 1128
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 1129
    .line 1130
    .line 1131
    move-result-object v1

    .line 1132
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 1133
    .line 1134
    .line 1135
    move-result-object v1

    .line 1136
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/db/entity/User;->getFullName()Ljava/lang/String;

    .line 1137
    .line 1138
    .line 1139
    move-result-object v1

    .line 1140
    goto :goto_29

    .line 1141
    :cond_40
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 1142
    .line 1143
    .line 1144
    move-result-object v1

    .line 1145
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 1146
    .line 1147
    .line 1148
    move-result-object v1

    .line 1149
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/db/entity/User;->getNickName()Ljava/lang/String;

    .line 1150
    .line 1151
    .line 1152
    move-result-object v1

    .line 1153
    :goto_29
    sget v2, Ly9/d;->ci_bank_transfer_content:I

    .line 1154
    .line 1155
    check-cast v11, LD9/c;

    .line 1156
    .line 1157
    iget-object v3, v11, LD9/c;->g:Landroid/widget/TextView;

    .line 1158
    .line 1159
    invoke-virtual {v3}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 1160
    .line 1161
    .line 1162
    move-result-object v3

    .line 1163
    filled-new-array {v3, v1}, [Ljava/lang/Object;

    .line 1164
    .line 1165
    .line 1166
    move-result-object v1

    .line 1167
    check-cast v12, Lcom/transsnet/palmpay/cash_in/ui/activity/instruction/AddMoneyHomeActivity;

    .line 1168
    .line 1169
    invoke-virtual {v12, v2, v1}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1170
    .line 1171
    .line 1172
    move-result-object v1

    .line 1173
    invoke-static {v12, v1}, Lcom/facebook/imagepipeline/nativecode/b;->D(Landroid/content/Context;Ljava/lang/String;)V

    .line 1174
    .line 1175
    .line 1176
    return-void

    .line 1177
    :pswitch_f
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 1178
    .line 1179
    .line 1180
    move-result-object v1

    .line 1181
    const-string v2, "AddMoney_KYC_Click"

    .line 1182
    .line 1183
    invoke-virtual {v1, v2}, LPa/n0;->v(Ljava/lang/String;)V

    .line 1184
    .line 1185
    .line 1186
    check-cast v12, Lcom/transsnet/palmpay/main/export/bean/rsp/MeTabTotalAssetInfo;

    .line 1187
    .line 1188
    iget-object v1, v12, Lcom/transsnet/palmpay/main/export/bean/rsp/MeTabTotalAssetInfo;->authAndroidLinkUrl:Ljava/lang/String;

    .line 1189
    .line 1190
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1191
    .line 1192
    .line 1193
    move-result v1

    .line 1194
    if-eqz v1, :cond_41

    .line 1195
    .line 1196
    const-string v1, "/account/palmpayLevel"

    .line 1197
    .line 1198
    invoke-static {v1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->F(Ljava/lang/String;)V

    .line 1199
    .line 1200
    .line 1201
    goto :goto_2a

    .line 1202
    :cond_41
    iget-object v1, v12, Lcom/transsnet/palmpay/main/export/bean/rsp/MeTabTotalAssetInfo;->authAndroidLinkUrl:Ljava/lang/String;

    .line 1203
    .line 1204
    check-cast v11, Lcom/transsnet/palmpay/cash_in/ui/activity/instruction/AddMoneyHomeActivity;

    .line 1205
    .line 1206
    invoke-static {v11, v1}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 1207
    .line 1208
    .line 1209
    move-result-object v1

    .line 1210
    invoke-static {v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 1211
    .line 1212
    .line 1213
    :goto_2a
    return-void

    .line 1214
    :pswitch_10
    check-cast v11, Lcom/transsnet/palmpay/cash_in/bean/response/FundViewBean;

    .line 1215
    .line 1216
    iget-object v2, v11, Lcom/transsnet/palmpay/cash_in/bean/response/FundViewBean;->name:Ljava/lang/String;

    .line 1217
    .line 1218
    check-cast v12, LD9/b;

    .line 1219
    .line 1220
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1221
    .line 1222
    .line 1223
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 1224
    .line 1225
    .line 1226
    move-result-object v3

    .line 1227
    const-string v4, "AddMoney_Method_Click"

    .line 1228
    .line 1229
    const-string v5, ""

    .line 1230
    .line 1231
    invoke-virtual {v3, v4, v2, v5}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 1232
    .line 1233
    .line 1234
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1235
    .line 1236
    .line 1237
    move-result-object v1

    .line 1238
    iget-object v2, v11, Lcom/transsnet/palmpay/cash_in/bean/response/FundViewBean;->jumpPath:Ljava/lang/String;

    .line 1239
    .line 1240
    invoke-static {v1, v2}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 1241
    .line 1242
    .line 1243
    move-result-object v1

    .line 1244
    invoke-static {v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 1245
    .line 1246
    .line 1247
    return-void

    .line 1248
    :pswitch_11
    check-cast v12, Lcom/transsnet/palmpay/ui/fragment/BankCardAndAccountFragment;

    .line 1249
    .line 1250
    check-cast v11, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;

    .line 1251
    .line 1252
    iput-object v11, v12, Lcom/transsnet/palmpay/ui/fragment/BankCardAndAccountFragment;->A:Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;

    .line 1253
    .line 1254
    if-eqz v11, :cond_42

    .line 1255
    .line 1256
    invoke-virtual {v12, v14}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 1257
    .line 1258
    .line 1259
    iget-object v1, v12, Lcom/transsnet/palmpay/ui/fragment/BankCardAndAccountFragment;->A:Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;

    .line 1260
    .line 1261
    invoke-virtual {v12, v1}, Lcom/transsnet/palmpay/ui/fragment/BankCardAndAccountFragment;->C(Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;)V

    .line 1262
    .line 1263
    .line 1264
    :cond_42
    return-void

    .line 1265
    :pswitch_12
    check-cast v12, Lcom/transsnet/palmpay/ui/fragment/BankCardAndAccountFragment;

    .line 1266
    .line 1267
    iput-object v11, v12, Lcom/transsnet/palmpay/ui/fragment/BankCardAndAccountFragment;->w:Ljava/lang/Object;

    .line 1268
    .line 1269
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 1270
    .line 1271
    .line 1272
    move-result-object v1

    .line 1273
    const-string v2, "/account/authentication"

    .line 1274
    .line 1275
    invoke-virtual {v1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 1276
    .line 1277
    .line 1278
    move-result-object v1

    .line 1279
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/BaseFragment;->c:Landroidx/fragment/app/E;

    .line 1280
    .line 1281
    const/16 v3, 0x64

    .line 1282
    .line 1283
    invoke-virtual {v1, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/app/Activity;I)V

    .line 1284
    .line 1285
    .line 1286
    return-void

    .line 1287
    :pswitch_13
    sget-object v1, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToPalmPayFragment;->H:Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToPalmPayFragment$a;

    .line 1288
    .line 1289
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToPalmPayFragment;

    .line 1290
    .line 1291
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 1292
    .line 1293
    check-cast v1, Lod/p;

    .line 1294
    .line 1295
    if-eqz v1, :cond_43

    .line 1296
    .line 1297
    iget-object v1, v1, Lod/p;->c:Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 1298
    .line 1299
    if-eqz v1, :cond_43

    .line 1300
    .line 1301
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/form/PpFormVertical;->getEditText()Landroidx/appcompat/widget/AppCompatEditText;

    .line 1302
    .line 1303
    .line 1304
    move-result-object v1

    .line 1305
    if-eqz v1, :cond_43

    .line 1306
    .line 1307
    check-cast v11, Ljava/lang/String;

    .line 1308
    .line 1309
    invoke-virtual {v1, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1310
    .line 1311
    .line 1312
    :cond_43
    return-void

    .line 1313
    :pswitch_14
    sget-object v1, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToBankFragment;->H:Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToBankFragment$a;

    .line 1314
    .line 1315
    check-cast v12, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToBankFragment;

    .line 1316
    .line 1317
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 1318
    .line 1319
    check-cast v1, Lod/o;

    .line 1320
    .line 1321
    if-eqz v1, :cond_44

    .line 1322
    .line 1323
    iget-object v1, v1, Lod/o;->c:Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 1324
    .line 1325
    if-eqz v1, :cond_44

    .line 1326
    .line 1327
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/form/PpFormVertical;->getEditText()Landroidx/appcompat/widget/AppCompatEditText;

    .line 1328
    .line 1329
    .line 1330
    move-result-object v1

    .line 1331
    if-eqz v1, :cond_44

    .line 1332
    .line 1333
    check-cast v11, Ljava/lang/String;

    .line 1334
    .line 1335
    invoke-virtual {v1, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1336
    .line 1337
    .line 1338
    :cond_44
    return-void

    .line 1339
    :pswitch_15
    sget v1, Lcom/transsnet/palmpay/credit/ui/view/BorrowCLInfoView2;->A:I

    .line 1340
    .line 1341
    new-instance v1, Lkotlin/jvm/internal/F;

    .line 1342
    .line 1343
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 1344
    .line 1345
    .line 1346
    new-instance v2, LO6/c;

    .line 1347
    .line 1348
    check-cast v12, Lcom/transsnet/palmpay/credit/ui/view/BorrowCLInfoView2;

    .line 1349
    .line 1350
    invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1351
    .line 1352
    .line 1353
    move-result-object v3

    .line 1354
    invoke-direct {v2, v3}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 1355
    .line 1356
    .line 1357
    sget v3, LL6/i;->ppFlexiCashDialogTheme:I

    .line 1358
    .line 1359
    iput v3, v2, LO6/c;->v:I

    .line 1360
    .line 1361
    invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1362
    .line 1363
    .line 1364
    move-result-object v3

    .line 1365
    sget v4, Lhb/f;->cs_cl_stamp_duty_dialog_title:I

    .line 1366
    .line 1367
    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1368
    .line 1369
    .line 1370
    move-result-object v3

    .line 1371
    invoke-static {v3}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 1372
    .line 1373
    .line 1374
    move-result-object v3

    .line 1375
    iput-object v3, v2, LO6/c;->b:Ljava/lang/CharSequence;

    .line 1376
    .line 1377
    check-cast v11, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1378
    .line 1379
    if-eqz v11, :cond_45

    .line 1380
    .line 1381
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getStampDutyText()Ljava/lang/String;

    .line 1382
    .line 1383
    .line 1384
    move-result-object v15

    .line 1385
    :cond_45
    iput-object v15, v2, LO6/c;->d:Ljava/lang/CharSequence;

    .line 1386
    .line 1387
    invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1388
    .line 1389
    .line 1390
    move-result-object v3

    .line 1391
    sget v4, Lba/k;->core_got_it:I

    .line 1392
    .line 1393
    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1394
    .line 1395
    .line 1396
    move-result-object v3

    .line 1397
    new-instance v4, LAb/l;

    .line 1398
    .line 1399
    const/4 v5, 0x2

    .line 1400
    invoke-direct {v4, v1, v5}, LAb/l;-><init>(Lkotlin/jvm/internal/F;I)V

    .line 1401
    .line 1402
    .line 1403
    iput-object v3, v2, LO6/c;->f:Ljava/lang/String;

    .line 1404
    .line 1405
    iput-object v4, v2, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 1406
    .line 1407
    invoke-virtual {v2}, LO6/c;->a()LO6/d;

    .line 1408
    .line 1409
    .line 1410
    move-result-object v2

    .line 1411
    iput-object v2, v1, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 1412
    .line 1413
    invoke-virtual {v2}, LO6/d;->show()V

    .line 1414
    .line 1415
    .line 1416
    return-void

    .line 1417
    :pswitch_16
    sget v1, Lcom/transsnet/palmpay/credit/ui/view/BorrowCLInfoView;->w:I

    .line 1418
    .line 1419
    new-instance v1, Lkotlin/jvm/internal/F;

    .line 1420
    .line 1421
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 1422
    .line 1423
    .line 1424
    new-instance v2, LO6/c;

    .line 1425
    .line 1426
    check-cast v12, Lcom/transsnet/palmpay/credit/ui/view/BorrowCLInfoView;

    .line 1427
    .line 1428
    invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1429
    .line 1430
    .line 1431
    move-result-object v3

    .line 1432
    invoke-direct {v2, v3}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 1433
    .line 1434
    .line 1435
    sget v3, LL6/i;->ppFlexiCashDialogTheme:I

    .line 1436
    .line 1437
    iput v3, v2, LO6/c;->v:I

    .line 1438
    .line 1439
    invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1440
    .line 1441
    .line 1442
    move-result-object v3

    .line 1443
    sget v4, Lhb/f;->cs_cl_stamp_duty_dialog_title:I

    .line 1444
    .line 1445
    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1446
    .line 1447
    .line 1448
    move-result-object v3

    .line 1449
    invoke-static {v3}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 1450
    .line 1451
    .line 1452
    move-result-object v3

    .line 1453
    iput-object v3, v2, LO6/c;->b:Ljava/lang/CharSequence;

    .line 1454
    .line 1455
    check-cast v11, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1456
    .line 1457
    if-eqz v11, :cond_46

    .line 1458
    .line 1459
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getStampDutyText()Ljava/lang/String;

    .line 1460
    .line 1461
    .line 1462
    move-result-object v15

    .line 1463
    :cond_46
    iput-object v15, v2, LO6/c;->d:Ljava/lang/CharSequence;

    .line 1464
    .line 1465
    invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 1466
    .line 1467
    .line 1468
    move-result-object v3

    .line 1469
    sget v4, Lba/k;->core_got_it:I

    .line 1470
    .line 1471
    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1472
    .line 1473
    .line 1474
    move-result-object v3

    .line 1475
    new-instance v4, LAb/l;

    .line 1476
    .line 1477
    invoke-direct {v4, v1, v14}, LAb/l;-><init>(Lkotlin/jvm/internal/F;I)V

    .line 1478
    .line 1479
    .line 1480
    iput-object v3, v2, LO6/c;->f:Ljava/lang/String;

    .line 1481
    .line 1482
    iput-object v4, v2, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 1483
    .line 1484
    invoke-virtual {v2}, LO6/c;->a()LO6/d;

    .line 1485
    .line 1486
    .line 1487
    move-result-object v2

    .line 1488
    iput-object v2, v1, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 1489
    .line 1490
    invoke-virtual {v2}, LO6/d;->show()V

    .line 1491
    .line 1492
    .line 1493
    return-void

    .line 1494
    :pswitch_17
    const-string v1, "TransferPaymentResultsClick"

    .line 1495
    .line 1496
    const-string v2, "ViewDetail"

    .line 1497
    .line 1498
    check-cast v12, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawAgentPaymentResultActivity;

    .line 1499
    .line 1500
    invoke-static {v12, v1, v2}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawAgentPaymentResultActivity;->m(Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawAgentPaymentResultActivity;Ljava/lang/String;Ljava/lang/String;)V

    .line 1501
    .line 1502
    .line 1503
    check-cast v11, Lcom/transsnet/palmpay/core/bean/rsp/QueryOrderDetailRsp;

    .line 1504
    .line 1505
    iget-object v1, v11, Lcom/transsnet/palmpay/core/bean/rsp/QueryOrderDetailRsp;->orderNo:Ljava/lang/String;

    .line 1506
    .line 1507
    new-instance v2, Lkotlin/Pair;

    .line 1508
    .line 1509
    const-string v3, "orderNo"

    .line 1510
    .line 1511
    invoke-direct {v2, v3, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1512
    .line 1513
    .line 1514
    iget-object v1, v11, Lcom/transsnet/palmpay/core/bean/rsp/QueryOrderDetailRsp;->transType:Ljava/lang/String;

    .line 1515
    .line 1516
    new-instance v3, Lkotlin/Pair;

    .line 1517
    .line 1518
    const-string v4, "transType"

    .line 1519
    .line 1520
    invoke-direct {v3, v4, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1521
    .line 1522
    .line 1523
    filled-new-array {v2, v3}, [Lkotlin/Pair;

    .line 1524
    .line 1525
    .line 1526
    move-result-object v1

    .line 1527
    invoke-static {v1}, La/a;->e([Lkotlin/Pair;)Landroid/os/Bundle;

    .line 1528
    .line 1529
    .line 1530
    move-result-object v1

    .line 1531
    const-string v2, "CommonDetail"

    .line 1532
    .line 1533
    invoke-static {v1, v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 1534
    .line 1535
    .line 1536
    return-void

    .line 1537
    :pswitch_18
    check-cast v11, Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;

    .line 1538
    .line 1539
    check-cast v12, Ljava/lang/String;

    .line 1540
    .line 1541
    invoke-static {v12, v11, v1}, Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;->f(Ljava/lang/String;Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;Landroid/view/View;)V

    .line 1542
    .line 1543
    .line 1544
    return-void

    .line 1545
    :pswitch_19
    sget v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->M1:I

    .line 1546
    .line 1547
    check-cast v11, Lcom/transsnet/palmpay/credit/ui/dialog/CLCouponDialog;

    .line 1548
    .line 1549
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/ui/dialog/CLCouponDialog;->getSelectedIndex()I

    .line 1550
    .line 1551
    .line 1552
    move-result v1

    .line 1553
    check-cast v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;

    .line 1554
    .line 1555
    iput v1, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->K1:I

    .line 1556
    .line 1557
    const/4 v2, -0x1

    .line 1558
    if-ne v1, v2, :cond_49

    .line 1559
    .line 1560
    iget-object v1, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->q1:Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1561
    .line 1562
    if-eqz v1, :cond_47

    .line 1563
    .line 1564
    invoke-virtual {v1, v15}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCouponId(Ljava/lang/Long;)V

    .line 1565
    .line 1566
    .line 1567
    :cond_47
    iget-object v1, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->q1:Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1568
    .line 1569
    if-eqz v1, :cond_48

    .line 1570
    .line 1571
    invoke-virtual {v1, v15}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCoupon(Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;)V

    .line 1572
    .line 1573
    .line 1574
    :cond_48
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->t0()V

    .line 1575
    .line 1576
    .line 1577
    goto :goto_2b

    .line 1578
    :cond_49
    iget-object v2, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->q1:Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1579
    .line 1580
    iget-object v3, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->L1:Ljava/util/ArrayList;

    .line 1581
    .line 1582
    if-eqz v2, :cond_4a

    .line 1583
    .line 1584
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1585
    .line 1586
    .line 1587
    move-result-object v1

    .line 1588
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;

    .line 1589
    .line 1590
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;->getCouponId()Ljava/lang/Long;

    .line 1591
    .line 1592
    .line 1593
    move-result-object v1

    .line 1594
    invoke-virtual {v2, v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCouponId(Ljava/lang/Long;)V

    .line 1595
    .line 1596
    .line 1597
    :cond_4a
    iget-object v1, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->q1:Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1598
    .line 1599
    if-eqz v1, :cond_4b

    .line 1600
    .line 1601
    iget v2, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->K1:I

    .line 1602
    .line 1603
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1604
    .line 1605
    .line 1606
    move-result-object v2

    .line 1607
    check-cast v2, Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;

    .line 1608
    .line 1609
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCoupon(Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;)V

    .line 1610
    .line 1611
    .line 1612
    :cond_4b
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->t0()V

    .line 1613
    .line 1614
    .line 1615
    :goto_2b
    return-void

    .line 1616
    :pswitch_1a
    sget v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->H1:I

    .line 1617
    .line 1618
    check-cast v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;

    .line 1619
    .line 1620
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->X()Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1621
    .line 1622
    .line 1623
    move-result-object v1

    .line 1624
    if-eqz v1, :cond_4c

    .line 1625
    .line 1626
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getUpperLimit()Ljava/lang/Boolean;

    .line 1627
    .line 1628
    .line 1629
    move-result-object v1

    .line 1630
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1631
    .line 1632
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1633
    .line 1634
    .line 1635
    move-result v13

    .line 1636
    :cond_4c
    if-eqz v13, :cond_4e

    .line 1637
    .line 1638
    new-instance v1, LO6/c;

    .line 1639
    .line 1640
    check-cast v11, Landroid/content/Context;

    .line 1641
    .line 1642
    invoke-direct {v1, v11}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 1643
    .line 1644
    .line 1645
    sget v2, LL6/i;->ppFlexiCashDialogTheme:I

    .line 1646
    .line 1647
    iput v2, v1, LO6/c;->v:I

    .line 1648
    .line 1649
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->X()Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1650
    .line 1651
    .line 1652
    move-result-object v2

    .line 1653
    if-eqz v2, :cond_4d

    .line 1654
    .line 1655
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getCoupon()Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;

    .line 1656
    .line 1657
    .line 1658
    move-result-object v2

    .line 1659
    if-eqz v2, :cond_4d

    .line 1660
    .line 1661
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;->getNominaValue()Ljava/lang/Long;

    .line 1662
    .line 1663
    .line 1664
    move-result-object v2

    .line 1665
    if-eqz v2, :cond_4d

    .line 1666
    .line 1667
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 1668
    .line 1669
    .line 1670
    move-result-wide v11

    .line 1671
    goto :goto_2c

    .line 1672
    :cond_4d
    move-wide/from16 v11, v16

    .line 1673
    .line 1674
    :goto_2c
    invoke-static {v11, v12, v14}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 1675
    .line 1676
    .line 1677
    move-result-object v2

    .line 1678
    const-string v3, "The deduction amount cannot exceed the upper limit "

    .line 1679
    .line 1680
    invoke-static {v3, v2}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1681
    .line 1682
    .line 1683
    move-result-object v2

    .line 1684
    iput-object v2, v1, LO6/c;->d:Ljava/lang/CharSequence;

    .line 1685
    .line 1686
    sget v2, Lba/k;->core_got_it:I

    .line 1687
    .line 1688
    invoke-virtual {v1, v2, v15}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 1689
    .line 1690
    .line 1691
    invoke-virtual {v1}, LO6/c;->a()LO6/d;

    .line 1692
    .line 1693
    .line 1694
    move-result-object v1

    .line 1695
    invoke-virtual {v1}, LO6/d;->show()V

    .line 1696
    .line 1697
    .line 1698
    :cond_4e
    return-void

    .line 1699
    :pswitch_1b
    sget v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->H1:I

    .line 1700
    .line 1701
    check-cast v11, Lcom/transsnet/palmpay/credit/ui/dialog/CLCouponDialog;

    .line 1702
    .line 1703
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/ui/dialog/CLCouponDialog;->getSelectedIndex()I

    .line 1704
    .line 1705
    .line 1706
    move-result v1

    .line 1707
    check-cast v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;

    .line 1708
    .line 1709
    iput v1, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->m1:I

    .line 1710
    .line 1711
    const/4 v2, -0x1

    .line 1712
    if-ne v1, v2, :cond_51

    .line 1713
    .line 1714
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->X()Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1715
    .line 1716
    .line 1717
    move-result-object v1

    .line 1718
    if-eqz v1, :cond_4f

    .line 1719
    .line 1720
    invoke-virtual {v1, v15}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCouponId(Ljava/lang/Long;)V

    .line 1721
    .line 1722
    .line 1723
    :cond_4f
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->X()Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1724
    .line 1725
    .line 1726
    move-result-object v1

    .line 1727
    if-eqz v1, :cond_50

    .line 1728
    .line 1729
    invoke-virtual {v1, v15}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCoupon(Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;)V

    .line 1730
    .line 1731
    .line 1732
    :cond_50
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->f0()V

    .line 1733
    .line 1734
    .line 1735
    goto :goto_2d

    .line 1736
    :cond_51
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->X()Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1737
    .line 1738
    .line 1739
    move-result-object v1

    .line 1740
    iget-object v2, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->n1:Ljava/util/ArrayList;

    .line 1741
    .line 1742
    if-eqz v1, :cond_52

    .line 1743
    .line 1744
    iget v3, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->m1:I

    .line 1745
    .line 1746
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1747
    .line 1748
    .line 1749
    move-result-object v3

    .line 1750
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;

    .line 1751
    .line 1752
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;->getCouponId()Ljava/lang/Long;

    .line 1753
    .line 1754
    .line 1755
    move-result-object v3

    .line 1756
    invoke-virtual {v1, v3}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCouponId(Ljava/lang/Long;)V

    .line 1757
    .line 1758
    .line 1759
    :cond_52
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->X()Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 1760
    .line 1761
    .line 1762
    move-result-object v1

    .line 1763
    if-eqz v1, :cond_53

    .line 1764
    .line 1765
    iget v3, v12, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->m1:I

    .line 1766
    .line 1767
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1768
    .line 1769
    .line 1770
    move-result-object v2

    .line 1771
    check-cast v2, Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;

    .line 1772
    .line 1773
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCoupon(Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;)V

    .line 1774
    .line 1775
    .line 1776
    :cond_53
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->f0()V

    .line 1777
    .line 1778
    .line 1779
    :goto_2d
    return-void

    .line 1780
    :pswitch_1c
    check-cast v12, LA8/d;

    .line 1781
    .line 1782
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1783
    .line 1784
    .line 1785
    invoke-static {}, Lf/c;->a()Lf/c;

    .line 1786
    .line 1787
    .line 1788
    move-result-object v1

    .line 1789
    check-cast v11, Lf/a;

    .line 1790
    .line 1791
    iget-object v2, v11, Lf/a;->c:Ljava/lang/String;

    .line 1792
    .line 1793
    iput-object v2, v1, Lf/c;->d:Ljava/lang/String;

    .line 1794
    .line 1795
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1796
    .line 1797
    const-string v2, "com.transsnet.mtn.sdk.ui.bank."

    .line 1798
    .line 1799
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1800
    .line 1801
    .line 1802
    iget-object v2, v11, Lf/a;->d:Ljava/lang/String;

    .line 1803
    .line 1804
    const-string v3, ".LoginActivity"

    .line 1805
    .line 1806
    invoke-static {v1, v2, v3}, LC0/G;->r(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1807
    .line 1808
    .line 1809
    move-result-object v1

    .line 1810
    new-instance v2, Landroid/content/Intent;

    .line 1811
    .line 1812
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 1813
    .line 1814
    .line 1815
    new-instance v3, Landroid/content/ComponentName;

    .line 1816
    .line 1817
    iget-object v4, v12, LA8/d;->c:LA8/e;

    .line 1818
    .line 1819
    iget-object v5, v4, LA8/e;->a:Lcom/transsnet/mtn/sdk/ui/bank/_common/SelectBankActivity;

    .line 1820
    .line 1821
    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 1822
    .line 1823
    .line 1824
    move-result-object v5

    .line 1825
    invoke-direct {v3, v5, v1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 1826
    .line 1827
    .line 1828
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 1829
    .line 1830
    .line 1831
    iget-object v1, v4, LA8/e;->a:Lcom/transsnet/mtn/sdk/ui/bank/_common/SelectBankActivity;

    .line 1832
    .line 1833
    invoke-virtual {v1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 1834
    .line 1835
    .line 1836
    return-void

    .line 1837
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
