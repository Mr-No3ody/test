.class public final synthetic LA8/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LA8/g;->a:I

    iput-object p1, p0, LA8/g;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkc/c;Lkc/d;)V
    .locals 0

    .line 2
    const/16 p1, 0xc

    iput p1, p0, LA8/g;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA8/g;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 9

    .line 1
    const/4 v0, 0x2

    .line 2
    const/4 v1, 0x0

    .line 3
    const-string v2, "getValue(...)"

    .line 4
    .line 5
    const-string v3, "buttonView"

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    const/4 v5, 0x1

    .line 9
    const-string v6, "<unused var>"

    .line 10
    .line 11
    iget-object v7, p0, LA8/g;->b:Ljava/lang/Object;

    .line 12
    .line 13
    iget v8, p0, LA8/g;->a:I

    .line 14
    .line 15
    packed-switch v8, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    check-cast v7, Lcom/transsnet/palmpay/credit/ui/fragment/OcProtocolLockFragment;

    .line 22
    .line 23
    if-eqz p2, :cond_0

    .line 24
    .line 25
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    if-eqz p1, :cond_0

    .line 30
    .line 31
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/ui/fragment/OcProtocolLockFragment;->u()Landroid/widget/TextView;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    if-eqz p2, :cond_0

    .line 36
    .line 37
    sget v0, LYa/b;->cs_agree_txt_color:I

    .line 38
    .line 39
    invoke-virtual {p1, v0}, Landroid/content/Context;->getColor(I)I

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 44
    .line 45
    .line 46
    :cond_0
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    invoke-virtual {p2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p2

    .line 58
    const-string v0, "_element_click"

    .line 59
    .line 60
    invoke-virtual {p2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p2

    .line 64
    const-string v0, "oc_proto_cb"

    .line 65
    .line 66
    const-string v1, ""

    .line 67
    .line 68
    invoke-virtual {p1, p2, v0, v1}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideDoubleOpenFragment;->r0:I

    .line 73
    .line 74
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    check-cast v7, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideDoubleOpenFragment;

    .line 78
    .line 79
    if-eqz p2, :cond_3

    .line 80
    .line 81
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideDoubleOpenFragment;->Z:Lgb/b;

    .line 82
    .line 83
    if-eqz p1, :cond_1

    .line 84
    .line 85
    iget-object p1, p1, Lgb/b;->openFlexiTv:Landroid/widget/TextView;

    .line 86
    .line 87
    if-eqz p1, :cond_1

    .line 88
    .line 89
    invoke-virtual {p1, v5}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 90
    .line 91
    .line 92
    :cond_1
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideDoubleOpenFragment;->Z:Lgb/b;

    .line 93
    .line 94
    if-eqz p1, :cond_2

    .line 95
    .line 96
    iget-object p1, p1, Lgb/b;->openFlexiTv:Landroid/widget/TextView;

    .line 97
    .line 98
    if-eqz p1, :cond_2

    .line 99
    .line 100
    sget p2, LL6/b;->ppColorTextPrimary:I

    .line 101
    .line 102
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 107
    .line 108
    .line 109
    move-result p2

    .line 110
    invoke-static {p2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 111
    .line 112
    .line 113
    move-result-object p2

    .line 114
    invoke-virtual {p1, p2}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 115
    .line 116
    .line 117
    :cond_2
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideDoubleOpenFragment;->Z:Lgb/b;

    .line 118
    .line 119
    if-eqz p1, :cond_5

    .line 120
    .line 121
    iget-object p1, p1, Lgb/b;->openFlexiTv:Landroid/widget/TextView;

    .line 122
    .line 123
    if-eqz p1, :cond_5

    .line 124
    .line 125
    sget p2, LL6/b;->ppColorTextBase:I

    .line 126
    .line 127
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 132
    .line 133
    .line 134
    move-result p2

    .line 135
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 136
    .line 137
    .line 138
    goto :goto_0

    .line 139
    :cond_3
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideDoubleOpenFragment;->Z:Lgb/b;

    .line 140
    .line 141
    if-eqz p1, :cond_4

    .line 142
    .line 143
    iget-object p1, p1, Lgb/b;->openFlexiTv:Landroid/widget/TextView;

    .line 144
    .line 145
    if-eqz p1, :cond_4

    .line 146
    .line 147
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 148
    .line 149
    .line 150
    :cond_4
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideDoubleOpenFragment;->Z:Lgb/b;

    .line 151
    .line 152
    if-eqz p1, :cond_5

    .line 153
    .line 154
    iget-object p1, p1, Lgb/b;->openFlexiTv:Landroid/widget/TextView;

    .line 155
    .line 156
    if-eqz p1, :cond_5

    .line 157
    .line 158
    sget p2, LL6/b;->ppColorTextAssist:I

    .line 159
    .line 160
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 165
    .line 166
    .line 167
    move-result p2

    .line 168
    invoke-static {p2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 169
    .line 170
    .line 171
    move-result-object p2

    .line 172
    invoke-virtual {p1, p2}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 173
    .line 174
    .line 175
    :cond_5
    :goto_0
    return-void

    .line 176
    :pswitch_1
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 177
    .line 178
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    check-cast v7, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 182
    .line 183
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->Z:Lxf/t;

    .line 184
    .line 185
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    check-cast p1, Landroid/widget/CheckedTextView;

    .line 193
    .line 194
    invoke-virtual {p1}, Landroid/widget/CheckedTextView;->isChecked()Z

    .line 195
    .line 196
    .line 197
    move-result p1

    .line 198
    if-eqz p1, :cond_7

    .line 199
    .line 200
    if-eqz p2, :cond_6

    .line 201
    .line 202
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->p()V

    .line 203
    .line 204
    .line 205
    goto :goto_1

    .line 206
    :cond_6
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->o()V

    .line 207
    .line 208
    .line 209
    :cond_7
    :goto_1
    return-void

    .line 210
    :pswitch_2
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 211
    .line 212
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 213
    .line 214
    .line 215
    check-cast v7, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;

    .line 216
    .line 217
    if-eqz p2, :cond_8

    .line 218
    .line 219
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->o()Landroid/widget/Button;

    .line 220
    .line 221
    .line 222
    move-result-object p1

    .line 223
    invoke-virtual {p1, v5}, Landroid/view/View;->setEnabled(Z)V

    .line 224
    .line 225
    .line 226
    goto :goto_2

    .line 227
    :cond_8
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->o()Landroid/widget/Button;

    .line 228
    .line 229
    .line 230
    move-result-object p1

    .line 231
    invoke-virtual {p1, v4}, Landroid/view/View;->setEnabled(Z)V

    .line 232
    .line 233
    .line 234
    :goto_2
    return-void

    .line 235
    :pswitch_3
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;->v0:I

    .line 236
    .line 237
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 238
    .line 239
    .line 240
    check-cast v7, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;

    .line 241
    .line 242
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;->Y:Lxf/t;

    .line 243
    .line 244
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    move-result-object p1

    .line 248
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 249
    .line 250
    .line 251
    check-cast p1, Landroid/widget/TextView;

    .line 252
    .line 253
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 254
    .line 255
    .line 256
    return-void

    .line 257
    :pswitch_4
    sget p2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->C:I

    .line 258
    .line 259
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    check-cast v7, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;

    .line 263
    .line 264
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->e:Lxf/t;

    .line 265
    .line 266
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object p1

    .line 270
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 271
    .line 272
    .line 273
    check-cast p1, Landroid/widget/TextView;

    .line 274
    .line 275
    iget-object p2, v7, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->g:Lxf/t;

    .line 276
    .line 277
    invoke-virtual {p2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 278
    .line 279
    .line 280
    move-result-object p2

    .line 281
    invoke-static {p2, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 282
    .line 283
    .line 284
    check-cast p2, Landroidx/appcompat/widget/AppCompatCheckBox;

    .line 285
    .line 286
    invoke-virtual {p2}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 287
    .line 288
    .line 289
    move-result p2

    .line 290
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 291
    .line 292
    .line 293
    return-void

    .line 294
    :pswitch_5
    sget p1, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantPreviewActivity;->w0:I

    .line 295
    .line 296
    check-cast v7, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantPreviewActivity;

    .line 297
    .line 298
    invoke-virtual {v7, v5}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v7}, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantPreviewActivity;->Q()V

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :pswitch_6
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    check-cast v7, Lkc/d;

    .line 309
    .line 310
    if-eqz p2, :cond_9

    .line 311
    .line 312
    iget-object p2, v7, Lkc/d;->g:LOe/a;

    .line 313
    .line 314
    if-eqz p2, :cond_a

    .line 315
    .line 316
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 317
    .line 318
    .line 319
    move-result-object p1

    .line 320
    invoke-virtual {p2, p1}, LOe/a;->onActive(Ljava/lang/Object;)V

    .line 321
    .line 322
    .line 323
    goto :goto_3

    .line 324
    :cond_9
    iget-object p2, v7, Lkc/d;->g:LOe/a;

    .line 325
    .line 326
    if-eqz p2, :cond_a

    .line 327
    .line 328
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 329
    .line 330
    .line 331
    move-result-object p1

    .line 332
    invoke-virtual {p2, p1}, LOe/a;->onDeActive(Ljava/lang/Object;)V

    .line 333
    .line 334
    .line 335
    :cond_a
    :goto_3
    return-void

    .line 336
    :pswitch_7
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/fragment/OrderPreFragment;->Q:Lcom/transsnet/palmpay/managemoney/ui/fragment/OrderPreFragment$a;

    .line 337
    .line 338
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    check-cast v7, Lcom/transsnet/palmpay/managemoney/ui/fragment/OrderPreFragment;

    .line 342
    .line 343
    iget-object p1, v7, Lcom/transsnet/palmpay/managemoney/ui/fragment/OrderPreFragment;->j:Lxf/t;

    .line 344
    .line 345
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 346
    .line 347
    .line 348
    move-result-object p1

    .line 349
    check-cast p1, Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 350
    .line 351
    if-eqz p1, :cond_b

    .line 352
    .line 353
    invoke-virtual {p1, p2}, Landroid/view/View;->setEnabled(Z)V

    .line 354
    .line 355
    .line 356
    :cond_b
    return-void

    .line 357
    :pswitch_8
    sget-object p2, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxIntroductionFragment;->H:Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxIntroductionFragment$a;

    .line 358
    .line 359
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 360
    .line 361
    .line 362
    check-cast v7, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxIntroductionFragment;

    .line 363
    .line 364
    iget-object p1, v7, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxIntroductionFragment;->B:Lxf/t;

    .line 365
    .line 366
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 367
    .line 368
    .line 369
    move-result-object p1

    .line 370
    check-cast p1, Landroid/widget/CheckBox;

    .line 371
    .line 372
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 373
    .line 374
    .line 375
    invoke-virtual {p1}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 376
    .line 377
    .line 378
    move-result p1

    .line 379
    if-eqz p1, :cond_c

    .line 380
    .line 381
    iget-object p1, v7, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxIntroductionFragment;->C:Lxf/t;

    .line 382
    .line 383
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 384
    .line 385
    .line 386
    move-result-object p1

    .line 387
    check-cast p1, Landroidx/appcompat/widget/AppCompatImageView;

    .line 388
    .line 389
    if-eqz p1, :cond_c

    .line 390
    .line 391
    const/16 p2, 0x8

    .line 392
    .line 393
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 394
    .line 395
    .line 396
    :cond_c
    return-void

    .line 397
    :pswitch_9
    sget-object p2, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxDepositFragment;->p0:Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxDepositFragment$a;

    .line 398
    .line 399
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 400
    .line 401
    .line 402
    check-cast v7, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxDepositFragment;

    .line 403
    .line 404
    iget-object p1, v7, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxDepositFragment;->o:Lxf/t;

    .line 405
    .line 406
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 407
    .line 408
    .line 409
    move-result-object p1

    .line 410
    check-cast p1, Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 411
    .line 412
    if-eqz p1, :cond_f

    .line 413
    .line 414
    iget-object p2, v7, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxDepositFragment;->t:Lxf/t;

    .line 415
    .line 416
    invoke-virtual {p2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 417
    .line 418
    .line 419
    move-result-object p2

    .line 420
    check-cast p2, Landroid/widget/CheckBox;

    .line 421
    .line 422
    invoke-static {p2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 423
    .line 424
    .line 425
    invoke-virtual {p2}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 426
    .line 427
    .line 428
    move-result p2

    .line 429
    if-eqz p2, :cond_e

    .line 430
    .line 431
    invoke-virtual {v7}, Lcom/transsnet/palmpay/managemoney/ui/fragment/CashBoxDepositFragment;->t()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 432
    .line 433
    .line 434
    move-result-object p2

    .line 435
    if-eqz p2, :cond_d

    .line 436
    .line 437
    invoke-virtual {p2}, Landroidx/appcompat/widget/AppCompatEditText;->getText()Landroid/text/Editable;

    .line 438
    .line 439
    .line 440
    move-result-object v1

    .line 441
    :cond_d
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 442
    .line 443
    .line 444
    move-result-object p2

    .line 445
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 446
    .line 447
    .line 448
    move-result p2

    .line 449
    if-nez p2, :cond_e

    .line 450
    .line 451
    move v4, v5

    .line 452
    :cond_e
    invoke-virtual {p1, v4}, Landroid/view/View;->setEnabled(Z)V

    .line 453
    .line 454
    .line 455
    :cond_f
    return-void

    .line 456
    :pswitch_a
    sget v2, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->q0:I

    .line 457
    .line 458
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 459
    .line 460
    .line 461
    check-cast v7, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;

    .line 462
    .line 463
    iget-boolean p1, v7, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->p0:Z

    .line 464
    .line 465
    if-eqz p1, :cond_10

    .line 466
    .line 467
    goto/16 :goto_8

    .line 468
    .line 469
    :cond_10
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->z()Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;

    .line 470
    .line 471
    .line 472
    move-result-object p1

    .line 473
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;->f:Landroidx/lifecycle/F;

    .line 474
    .line 475
    invoke-virtual {p1}, Landroidx/lifecycle/B;->d()Ljava/lang/Object;

    .line 476
    .line 477
    .line 478
    move-result-object v2

    .line 479
    instance-of v3, v2, LJb/G;

    .line 480
    .line 481
    if-eqz v3, :cond_11

    .line 482
    .line 483
    check-cast v2, LJb/G;

    .line 484
    .line 485
    goto :goto_4

    .line 486
    :cond_11
    move-object v2, v1

    .line 487
    :goto_4
    if-nez v2, :cond_12

    .line 488
    .line 489
    goto :goto_5

    .line 490
    :cond_12
    iget-boolean v3, v2, LJb/G;->e:Z

    .line 491
    .line 492
    if-ne v3, p2, :cond_13

    .line 493
    .line 494
    goto :goto_5

    .line 495
    :cond_13
    const/16 v3, 0xf

    .line 496
    .line 497
    invoke-static {v2, v4, p2, v3}, LJb/G;->a(LJb/G;IZI)LJb/G;

    .line 498
    .line 499
    .line 500
    move-result-object v2

    .line 501
    invoke-virtual {p1, v2}, Landroidx/lifecycle/B;->k(Ljava/lang/Object;)V

    .line 502
    .line 503
    .line 504
    :goto_5
    iget-object p1, v7, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->j:Lcom/transsnet/palmpay/core/bean/TransferByLoanOpenParams;

    .line 505
    .line 506
    if-eqz p1, :cond_18

    .line 507
    .line 508
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/TransferByLoanOpenParams;->getLoanAmount()J

    .line 509
    .line 510
    .line 511
    move-result-wide v1

    .line 512
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 513
    .line 514
    .line 515
    move-result-object p1

    .line 516
    if-eqz p2, :cond_14

    .line 517
    .line 518
    const-string p2, "1"

    .line 519
    .line 520
    goto :goto_6

    .line 521
    :cond_14
    const-string p2, "0"

    .line 522
    .line 523
    :goto_6
    new-instance v3, Lkotlin/Pair;

    .line 524
    .line 525
    const-string v6, "status"

    .line 526
    .line 527
    invoke-direct {v3, v6, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 528
    .line 529
    .line 530
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 531
    .line 532
    .line 533
    move-result-object p2

    .line 534
    new-instance v1, Lkotlin/Pair;

    .line 535
    .line 536
    const-string v2, "transfer_amount"

    .line 537
    .line 538
    invoke-direct {v1, v2, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 539
    .line 540
    .line 541
    filled-new-array {v3, v1}, [Lkotlin/Pair;

    .line 542
    .line 543
    .line 544
    move-result-object p2

    .line 545
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 546
    .line 547
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 548
    .line 549
    .line 550
    sget-object v2, LJ3/a;->b:Ljava/lang/String;

    .line 551
    .line 552
    if-eqz v2, :cond_15

    .line 553
    .line 554
    const-string v3, "trace_id"

    .line 555
    .line 556
    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 557
    .line 558
    .line 559
    :cond_15
    sget-object v2, LJ3/a;->c:Ljava/lang/String;

    .line 560
    .line 561
    if-eqz v2, :cond_16

    .line 562
    .line 563
    const-string v3, "order_id"

    .line 564
    .line 565
    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 566
    .line 567
    .line 568
    :cond_16
    :goto_7
    if-ge v4, v0, :cond_17

    .line 569
    .line 570
    aget-object v2, p2, v4

    .line 571
    .line 572
    iget-object v3, v2, Lkotlin/Pair;->a:Ljava/lang/Object;

    .line 573
    .line 574
    check-cast v3, Ljava/lang/String;

    .line 575
    .line 576
    iget-object v2, v2, Lkotlin/Pair;->b:Ljava/lang/Object;

    .line 577
    .line 578
    check-cast v2, Ljava/lang/String;

    .line 579
    .line 580
    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 581
    .line 582
    .line 583
    add-int/2addr v4, v5

    .line 584
    goto :goto_7

    .line 585
    :cond_17
    const-string p2, "loan_transfer_agreement_toggle"

    .line 586
    .line 587
    invoke-virtual {p1, p2, v1}, LPa/n0;->n(Ljava/lang/String;Ljava/util/Map;)V

    .line 588
    .line 589
    .line 590
    :goto_8
    return-void

    .line 591
    :cond_18
    const-string p1, "params"

    .line 592
    .line 593
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 594
    .line 595
    .line 596
    throw v1

    .line 597
    :pswitch_b
    sget-object v0, Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog;->L:Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog$a;

    .line 598
    .line 599
    const-string v0, "compoundButton"

    .line 600
    .line 601
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 602
    .line 603
    .line 604
    check-cast v7, Lcom/palmpay/lib/ui/button/PpButton;

    .line 605
    .line 606
    if-eqz v7, :cond_19

    .line 607
    .line 608
    invoke-virtual {v7, p2}, Landroid/view/View;->setEnabled(Z)V

    .line 609
    .line 610
    .line 611
    :cond_19
    return-void

    .line 612
    :pswitch_c
    check-cast v7, Lcom/google/android/material/chip/Chip;

    .line 613
    .line 614
    invoke-static {v7, p1, p2}, Lcom/google/android/material/chip/Chip;->a(Lcom/google/android/material/chip/Chip;Landroid/widget/CompoundButton;Z)V

    .line 615
    .line 616
    .line 617
    return-void

    .line 618
    :pswitch_d
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 619
    .line 620
    .line 621
    check-cast v7, Lcom/transsnet/palmpay/account/ui/fragment/identify/IdentityVerificationStep2Fragment;

    .line 622
    .line 623
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 624
    .line 625
    .line 626
    move-result-object p1

    .line 627
    invoke-static {p1}, Lcom/transsnet/palmpay/util/KeyboardUtils;->hideSoftInput(Landroid/app/Activity;)V

    .line 628
    .line 629
    .line 630
    iget-object p1, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 631
    .line 632
    check-cast p1, LI8/o;

    .line 633
    .line 634
    if-eqz p1, :cond_1a

    .line 635
    .line 636
    iget-object p1, p1, LI8/o;->i:Landroid/widget/TextView;

    .line 637
    .line 638
    if-eqz p1, :cond_1a

    .line 639
    .line 640
    invoke-static {p1, v4}, Loa/h;->s(Landroid/view/View;Z)V

    .line 641
    .line 642
    .line 643
    :cond_1a
    return-void

    .line 644
    :pswitch_e
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 645
    .line 646
    .line 647
    sget p1, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingNotesPage;->A:I

    .line 648
    .line 649
    check-cast v7, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingNotesPage;

    .line 650
    .line 651
    invoke-virtual {v7}, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingNotesPage;->n()LUc/z;

    .line 652
    .line 653
    .line 654
    move-result-object p1

    .line 655
    iput-boolean p2, p1, LUc/z;->d:Z

    .line 656
    .line 657
    iget-object p1, v7, Lcom/transsnet/palmpay/p2pcash/ui/atm/BookingNotesPage;->c:Lxf/t;

    .line 658
    .line 659
    if-eqz p2, :cond_1b

    .line 660
    .line 661
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 662
    .line 663
    .line 664
    move-result-object p1

    .line 665
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 666
    .line 667
    .line 668
    check-cast p1, Landroid/widget/TextView;

    .line 669
    .line 670
    invoke-static {p1}, Loa/h;->C(Landroid/view/View;)V

    .line 671
    .line 672
    .line 673
    goto :goto_9

    .line 674
    :cond_1b
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 675
    .line 676
    .line 677
    move-result-object p1

    .line 678
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 679
    .line 680
    .line 681
    check-cast p1, Landroid/widget/TextView;

    .line 682
    .line 683
    invoke-static {p1}, Loa/h;->c(Landroid/view/View;)V

    .line 684
    .line 685
    .line 686
    :goto_9
    return-void

    .line 687
    :pswitch_f
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 688
    .line 689
    .line 690
    check-cast v7, Lcom/transsnet/palmpay/account/ui/fragment/guardian/GuardianApproveAuthorizationConfirmFragment;

    .line 691
    .line 692
    iget-object p1, v7, Lcom/transsnet/palmpay/account/ui/fragment/guardian/GuardianApproveAuthorizationConfirmFragment;->p:LBc/e;

    .line 693
    .line 694
    if-eqz p1, :cond_1d

    .line 695
    .line 696
    iget-object p2, p1, LBc/e;->f:Landroid/view/View;

    .line 697
    .line 698
    check-cast p2, Lcom/palmpay/lib/ui/button/PpButton;

    .line 699
    .line 700
    iget-object p1, p1, LBc/e;->g:Ljava/lang/Object;

    .line 701
    .line 702
    check-cast p1, Lcom/mikepenz/iconics/view/IconicsCheckBox;

    .line 703
    .line 704
    invoke-virtual {p1}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 705
    .line 706
    .line 707
    move-result p1

    .line 708
    if-ne p1, v5, :cond_1c

    .line 709
    .line 710
    move v4, v5

    .line 711
    :cond_1c
    invoke-virtual {p2, v4}, Landroid/view/View;->setEnabled(Z)V

    .line 712
    .line 713
    .line 714
    :cond_1d
    return-void

    .line 715
    :pswitch_10
    check-cast v7, LD4/f;

    .line 716
    .line 717
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 718
    .line 719
    .line 720
    sget p1, Lcom/transsnet/palmpay/credit/view/FeeCalculateView;->p:I

    .line 721
    .line 722
    iget-object p1, v7, LD4/f;->b:Ljava/lang/Object;

    .line 723
    .line 724
    check-cast p1, Lcom/transsnet/palmpay/credit/view/FeeCalculateView;

    .line 725
    .line 726
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 727
    .line 728
    .line 729
    return-void

    .line 730
    :pswitch_11
    sget v1, Lcom/transsnet/palmpay/ui/fragment/settings/PaymentSettingsFragment;->C:I

    .line 731
    .line 732
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 733
    .line 734
    .line 735
    check-cast v7, Lcom/transsnet/palmpay/ui/fragment/settings/PaymentSettingsFragment;

    .line 736
    .line 737
    if-eqz p2, :cond_1e

    .line 738
    .line 739
    new-instance p1, Lid/a;

    .line 740
    .line 741
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 742
    .line 743
    .line 744
    move-result-object v1

    .line 745
    invoke-direct {p1, v1}, Lid/a;-><init>(Landroid/content/Context;)V

    .line 746
    .line 747
    .line 748
    invoke-virtual {p1}, Lid/a;->W()Z

    .line 749
    .line 750
    .line 751
    move-result p1

    .line 752
    if-nez p1, :cond_1e

    .line 753
    .line 754
    sget-object p1, LPa/s;->a:LPa/s;

    .line 755
    .line 756
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 757
    .line 758
    .line 759
    move-result-object p1

    .line 760
    invoke-static {p1}, LPa/s;->i(Landroid/content/Context;)V

    .line 761
    .line 762
    .line 763
    goto :goto_a

    .line 764
    :cond_1e
    if-eqz p2, :cond_20

    .line 765
    .line 766
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 767
    .line 768
    .line 769
    move-result-object p1

    .line 770
    invoke-static {p1}, LPa/i0;->q(Landroid/content/Context;)Landroid/content/Intent;

    .line 771
    .line 772
    .line 773
    move-result-object p1

    .line 774
    const-string v1, "_encrypt"

    .line 775
    .line 776
    invoke-virtual {p1, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 777
    .line 778
    .line 779
    const-string v1, "extra_use_night_mode"

    .line 780
    .line 781
    invoke-virtual {p1, v1, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 782
    .line 783
    .line 784
    const-string v1, "extra_mode"

    .line 785
    .line 786
    invoke-virtual {p1, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 787
    .line 788
    .line 789
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 790
    .line 791
    .line 792
    move-result-object v1

    .line 793
    const-string v2, "null cannot be cast to non-null type com.transsnet.palmpay.core.base.BaseActivity"

    .line 794
    .line 795
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 796
    .line 797
    .line 798
    check-cast v1, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 799
    .line 800
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->getStartActivityLauncher()Lca/e;

    .line 801
    .line 802
    .line 803
    move-result-object v1

    .line 804
    if-eqz v1, :cond_21

    .line 805
    .line 806
    if-eqz p2, :cond_1f

    .line 807
    .line 808
    new-instance p2, LDe/e;

    .line 809
    .line 810
    invoke-direct {p2, v7, v5}, LDe/e;-><init>(Lcom/transsnet/palmpay/ui/fragment/settings/PaymentSettingsFragment;I)V

    .line 811
    .line 812
    .line 813
    invoke-virtual {v1, p1, p2}, Lca/e;->f(Landroid/content/Intent;Lcom/transsnet/palmpay/core/callback/Argument2Callback;)V

    .line 814
    .line 815
    .line 816
    goto :goto_a

    .line 817
    :cond_1f
    new-instance p2, LDe/e;

    .line 818
    .line 819
    invoke-direct {p2, v7, v0}, LDe/e;-><init>(Lcom/transsnet/palmpay/ui/fragment/settings/PaymentSettingsFragment;I)V

    .line 820
    .line 821
    .line 822
    invoke-virtual {v1, p1, p2}, Lca/e;->f(Landroid/content/Intent;Lcom/transsnet/palmpay/core/callback/Argument2Callback;)V

    .line 823
    .line 824
    .line 825
    goto :goto_a

    .line 826
    :cond_20
    new-instance p1, LO6/c;

    .line 827
    .line 828
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 829
    .line 830
    .line 831
    move-result-object p2

    .line 832
    invoke-direct {p1, p2}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 833
    .line 834
    .line 835
    const-string p2, "Disable Touch ID for pay?"

    .line 836
    .line 837
    invoke-static {p2}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 838
    .line 839
    .line 840
    move-result-object p2

    .line 841
    iput-object p2, p1, LO6/c;->b:Ljava/lang/CharSequence;

    .line 842
    .line 843
    iput-boolean v5, p1, LO6/c;->k:Z

    .line 844
    .line 845
    const-string p2, "Are you sure you want to disable fingerprint payment?"

    .line 846
    .line 847
    iput-object p2, p1, LO6/c;->d:Ljava/lang/CharSequence;

    .line 848
    .line 849
    new-instance p2, LDe/c;

    .line 850
    .line 851
    const/4 v0, 0x4

    .line 852
    invoke-direct {p2, v7, v0}, LDe/c;-><init>(Lcom/transsnet/palmpay/ui/fragment/settings/PaymentSettingsFragment;I)V

    .line 853
    .line 854
    .line 855
    const-string v0, "Disable"

    .line 856
    .line 857
    iput-object v0, p1, LO6/c;->g:Ljava/lang/String;

    .line 858
    .line 859
    iput-object p2, p1, LO6/c;->i:Landroid/view/View$OnClickListener;

    .line 860
    .line 861
    sget p2, Lba/k;->core_later:I

    .line 862
    .line 863
    new-instance v0, LDe/c;

    .line 864
    .line 865
    invoke-direct {v0, v7, v4}, LDe/c;-><init>(Lcom/transsnet/palmpay/ui/fragment/settings/PaymentSettingsFragment;I)V

    .line 866
    .line 867
    .line 868
    invoke-virtual {p1, p2, v0}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 869
    .line 870
    .line 871
    invoke-virtual {p1}, LO6/c;->g()LO6/d;

    .line 872
    .line 873
    .line 874
    move-result-object p1

    .line 875
    invoke-virtual {p1, v4}, LO6/d;->setCancelable(Z)V

    .line 876
    .line 877
    .line 878
    invoke-virtual {p1, v4}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 879
    .line 880
    .line 881
    :cond_21
    :goto_a
    return-void

    .line 882
    :pswitch_12
    check-cast v7, LA8/h;

    .line 883
    .line 884
    iget-object p1, v7, LA8/h;->a:Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 885
    .line 886
    iget-object p1, p1, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;->g:LPa/w;

    .line 887
    .line 888
    iget-object v0, p1, LPa/w;->b:Ljava/lang/Object;

    .line 889
    .line 890
    check-cast v0, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 891
    .line 892
    iget-object v0, v0, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;->e:Lcom/transsnet/mtn/sdk/ui/view/MTNButton;

    .line 893
    .line 894
    invoke-virtual {v0}, Lcom/transsnet/mtn/sdk/ui/view/MTNButton;->d()Z

    .line 895
    .line 896
    .line 897
    move-result v0

    .line 898
    if-eqz v0, :cond_22

    .line 899
    .line 900
    goto :goto_b

    .line 901
    :cond_22
    iget-object p1, p1, LPa/w;->b:Ljava/lang/Object;

    .line 902
    .line 903
    check-cast p1, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 904
    .line 905
    if-eqz p2, :cond_23

    .line 906
    .line 907
    iget-object p1, p1, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;->e:Lcom/transsnet/mtn/sdk/ui/view/MTNButton;

    .line 908
    .line 909
    invoke-virtual {p1}, Lcom/transsnet/mtn/sdk/ui/view/MTNButton;->f()V

    .line 910
    .line 911
    .line 912
    goto :goto_b

    .line 913
    :cond_23
    iget-object p1, p1, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;->e:Lcom/transsnet/mtn/sdk/ui/view/MTNButton;

    .line 914
    .line 915
    invoke-virtual {p1}, Lcom/transsnet/mtn/sdk/ui/view/MTNButton;->c()V

    .line 916
    .line 917
    .line 918
    :goto_b
    return-void

    .line 919
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
