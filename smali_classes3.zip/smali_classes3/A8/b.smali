.class public final synthetic LA8/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LA8/b;->a:I

    iput-object p1, p0, LA8/b;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    iget-object v3, p0, LA8/b;->b:Ljava/lang/Object;

    .line 5
    .line 6
    iget v4, p0, LA8/b;->a:I

    .line 7
    .line 8
    packed-switch v4, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    sget-object p1, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToPalmPayFragment;->H:Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToPalmPayFragment$a;

    .line 12
    .line 13
    check-cast v3, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToPalmPayFragment;

    .line 14
    .line 15
    invoke-virtual {v3}, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToPalmPayFragment;->v()V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_0
    sget-object p1, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToBankFragment;->H:Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToBankFragment$a;

    .line 20
    .line 21
    check-cast v3, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToBankFragment;

    .line 22
    .line 23
    invoke-virtual {v3}, Lcom/transsnet/palmpay/send_money/ui/fragment/ScheduleTransferPaymentToBankFragment;->x()V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :pswitch_1
    check-cast v3, Lca/a;

    .line 28
    .line 29
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    invoke-static {v3}, Lca/a;->f(Lca/a;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :pswitch_2
    sget p1, Lcom/transsnet/palmpay/send_money/ui/fragment/MoneyTransferHistoryFragment;->X:I

    .line 37
    .line 38
    check-cast v3, Lcom/transsnet/palmpay/send_money/ui/fragment/MoneyTransferHistoryFragment;

    .line 39
    .line 40
    invoke-virtual {v3}, Lcom/transsnet/palmpay/send_money/ui/fragment/MoneyTransferHistoryFragment;->B()V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :pswitch_3
    sget-object v0, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawResultActivity;->A:[Ljava/lang/String;

    .line 45
    .line 46
    check-cast v3, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawResultActivity;

    .line 47
    .line 48
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 52
    .line 53
    .line 54
    move-result p1

    .line 55
    sget v0, Ly9/b;->ciar_complete_btn:I

    .line 56
    .line 57
    if-ne p1, v0, :cond_1

    .line 58
    .line 59
    invoke-static {}, LPa/i0;->b()Z

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    if-eqz p1, :cond_0

    .line 64
    .line 65
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 66
    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_0
    invoke-static {v2}, LPa/i0;->H(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_1
    sget v0, Ly9/b;->ciar_withdraw_again_btn:I

    .line 74
    .line 75
    if-ne p1, v0, :cond_2

    .line 76
    .line 77
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 78
    .line 79
    .line 80
    :cond_2
    :goto_0
    return-void

    .line 81
    :pswitch_4
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->C:I

    .line 82
    .line 83
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    sget v2, Ly9/b;->ivScan:I

    .line 88
    .line 89
    if-ne p1, v2, :cond_3

    .line 90
    .line 91
    const-string p1, "/qrcode/scan"

    .line 92
    .line 93
    invoke-static {p1}, LN8/q0;->u(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    goto/16 :goto_2

    .line 97
    .line 98
    :cond_3
    sget v2, Ly9/b;->ivClear:I

    .line 99
    .line 100
    if-ne p1, v2, :cond_9

    .line 101
    .line 102
    check-cast v3, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;

    .line 103
    .line 104
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->m()Landroid/widget/EditText;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 109
    .line 110
    .line 111
    move-result-object p1

    .line 112
    invoke-interface {p1}, Landroid/text/Editable;->clear()V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->p()LE9/i;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    check-cast p1, Ljava/util/Collection;

    .line 124
    .line 125
    const/16 v2, 0x8

    .line 126
    .line 127
    if-eqz p1, :cond_4

    .line 128
    .line 129
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 130
    .line 131
    .line 132
    move-result p1

    .line 133
    if-eqz p1, :cond_5

    .line 134
    .line 135
    :cond_4
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->q()LE9/g;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    check-cast p1, Ljava/util/Collection;

    .line 144
    .line 145
    if-eqz p1, :cond_8

    .line 146
    .line 147
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 148
    .line 149
    .line 150
    move-result p1

    .line 151
    if-eqz p1, :cond_5

    .line 152
    .line 153
    goto :goto_1

    .line 154
    :cond_5
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->o()Landroid/widget/LinearLayout;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 159
    .line 160
    .line 161
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->u()Landroid/widget/TextView;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->p()LE9/i;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 173
    .line 174
    .line 175
    move-result-object p1

    .line 176
    check-cast p1, Ljava/util/Collection;

    .line 177
    .line 178
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 179
    .line 180
    .line 181
    move-result p1

    .line 182
    if-nez p1, :cond_6

    .line 183
    .line 184
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->u()Landroid/widget/TextView;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->u()Landroid/widget/TextView;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    sget v2, Ly9/d;->ci_recently:I

    .line 196
    .line 197
    invoke-virtual {v3, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object v2

    .line 201
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->t()Landroidx/recyclerview/widget/RecyclerView;

    .line 205
    .line 206
    .line 207
    move-result-object p1

    .line 208
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 209
    .line 210
    .line 211
    :cond_6
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->q()LE9/g;

    .line 212
    .line 213
    .line 214
    move-result-object p1

    .line 215
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 216
    .line 217
    .line 218
    move-result-object p1

    .line 219
    check-cast p1, Ljava/util/Collection;

    .line 220
    .line 221
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 222
    .line 223
    .line 224
    move-result p1

    .line 225
    if-nez p1, :cond_7

    .line 226
    .line 227
    iget-object p1, v3, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->g:Lxf/t;

    .line 228
    .line 229
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object p1

    .line 233
    const-string v1, "getValue(...)"

    .line 234
    .line 235
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    check-cast p1, Landroid/widget/LinearLayout;

    .line 239
    .line 240
    invoke-static {p1, v0}, Loa/h;->s(Landroid/view/View;Z)V

    .line 241
    .line 242
    .line 243
    :cond_7
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->r()LE9/h;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    new-instance v0, Ljava/util/ArrayList;

    .line 248
    .line 249
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 250
    .line 251
    .line 252
    invoke-virtual {p1, v0}, LM1/j;->setList(Ljava/util/Collection;)V

    .line 253
    .line 254
    .line 255
    goto :goto_2

    .line 256
    :cond_8
    :goto_1
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawQueryAccountListActivity;->o()Landroid/widget/LinearLayout;

    .line 257
    .line 258
    .line 259
    move-result-object p1

    .line 260
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 261
    .line 262
    .line 263
    :cond_9
    :goto_2
    return-void

    .line 264
    :pswitch_5
    sget p1, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawHomeActivity;->v:I

    .line 265
    .line 266
    check-cast v3, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawHomeActivity;

    .line 267
    .line 268
    invoke-static {v3}, Lcom/transsnet/palmpay/util/KeyboardUtils;->hideSoftInput(Landroid/app/Activity;)V

    .line 269
    .line 270
    .line 271
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 272
    .line 273
    .line 274
    return-void

    .line 275
    :pswitch_6
    sget p1, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeUSSDResultActivity;->p:I

    .line 276
    .line 277
    check-cast v3, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeUSSDResultActivity;

    .line 278
    .line 279
    invoke-virtual {v3}, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeUSSDResultActivity;->m()V

    .line 280
    .line 281
    .line 282
    return-void

    .line 283
    :pswitch_7
    sget-object v0, Lcom/transsnet/palmpay/cash_in/ui/activity/FundResultActivity;->v:[Ljava/lang/String;

    .line 284
    .line 285
    check-cast v3, Lcom/transsnet/palmpay/cash_in/ui/activity/FundResultActivity;

    .line 286
    .line 287
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 288
    .line 289
    .line 290
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 291
    .line 292
    .line 293
    move-result p1

    .line 294
    sget v0, Ly9/b;->ciar_complete_btn:I

    .line 295
    .line 296
    if-ne p1, v0, :cond_b

    .line 297
    .line 298
    invoke-static {}, LPa/r0;->B1()V

    .line 299
    .line 300
    .line 301
    invoke-static {}, LPa/i0;->b()Z

    .line 302
    .line 303
    .line 304
    move-result p1

    .line 305
    if-eqz p1, :cond_a

    .line 306
    .line 307
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 308
    .line 309
    .line 310
    goto :goto_4

    .line 311
    :cond_a
    invoke-static {v2}, LPa/i0;->H(Ljava/lang/String;)V

    .line 312
    .line 313
    .line 314
    goto :goto_4

    .line 315
    :cond_b
    sget v0, Ly9/b;->ciar_fund_again_btn:I

    .line 316
    .line 317
    if-ne p1, v0, :cond_d

    .line 318
    .line 319
    const-class p1, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;

    .line 320
    .line 321
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->isActivityExistsInStack(Ljava/lang/Class;)Z

    .line 322
    .line 323
    .line 324
    move-result v0

    .line 325
    if-eqz v0, :cond_c

    .line 326
    .line 327
    invoke-static {p1, v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->finishToActivity(Ljava/lang/Class;Z)Z

    .line 328
    .line 329
    .line 330
    goto :goto_3

    .line 331
    :cond_c
    const-string p1, "/cashin/recharge"

    .line 332
    .line 333
    invoke-static {p1}, LN8/q0;->u(Ljava/lang/String;)V

    .line 334
    .line 335
    .line 336
    :goto_3
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 337
    .line 338
    .line 339
    :cond_d
    :goto_4
    return-void

    .line 340
    :pswitch_8
    sget p1, Lcom/transsnet/palmpay/cash_in/ui/activity/BindBankCardResultActivity;->t:I

    .line 341
    .line 342
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 343
    .line 344
    .line 345
    move-result-object p1

    .line 346
    const-string v0, "/cash_in_out/billdetail"

    .line 347
    .line 348
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 349
    .line 350
    .line 351
    move-result-object p1

    .line 352
    const-string v0, "orderNo"

    .line 353
    .line 354
    check-cast v3, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;

    .line 355
    .line 356
    iget-object v1, v3, Lcom/transsnet/palmpay/cash_in/bean/response/BindBankCardDetail;->orderId:Ljava/lang/String;

    .line 357
    .line 358
    invoke-virtual {p1, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 359
    .line 360
    .line 361
    move-result-object p1

    .line 362
    const-string v0, "extra_type"

    .line 363
    .line 364
    const-string v1, "28"

    .line 365
    .line 366
    invoke-virtual {p1, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 367
    .line 368
    .line 369
    move-result-object p1

    .line 370
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 371
    .line 372
    .line 373
    return-void

    .line 374
    :pswitch_9
    check-cast v3, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneRewardsDialog;

    .line 375
    .line 376
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneRewardsDialog;->a(Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneRewardsDialog;Landroid/view/View;)V

    .line 377
    .line 378
    .line 379
    return-void

    .line 380
    :pswitch_a
    check-cast v3, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;

    .line 381
    .line 382
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;->a(Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;Landroid/view/View;)V

    .line 383
    .line 384
    .line 385
    return-void

    .line 386
    :pswitch_b
    check-cast v3, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneChainProgressDialog;

    .line 387
    .line 388
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneChainProgressDialog;->a(Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneChainProgressDialog;Landroid/view/View;)V

    .line 389
    .line 390
    .line 391
    return-void

    .line 392
    :pswitch_c
    check-cast v3, Lcom/transsnet/palmpay/cash_in/ui/activity/ConfirmAndPayWithdrawOrderActivity;

    .line 393
    .line 394
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 395
    .line 396
    .line 397
    return-void

    .line 398
    :pswitch_d
    check-cast v3, LB9/c;

    .line 399
    .line 400
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/base/BaseActivity;->onBackPressed()V

    .line 401
    .line 402
    .line 403
    return-void

    .line 404
    :pswitch_e
    check-cast v3, Lcom/transsnet/mtn/sdk/ui/view/MTNButton;

    .line 405
    .line 406
    iget-object p1, v3, Lcom/transsnet/mtn/sdk/ui/view/MTNButton;->d:Lcom/transsnet/mtn/sdk/ui/view/MTNButton$a;

    .line 407
    .line 408
    if-eqz p1, :cond_e

    .line 409
    .line 410
    iget-boolean v0, v3, Lcom/transsnet/mtn/sdk/ui/view/MTNButton;->e:Z

    .line 411
    .line 412
    if-eqz v0, :cond_e

    .line 413
    .line 414
    invoke-interface {p1}, Lcom/transsnet/mtn/sdk/ui/view/MTNButton$a;->a()V

    .line 415
    .line 416
    .line 417
    :cond_e
    return-void

    .line 418
    :pswitch_f
    check-cast v3, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 419
    .line 420
    iget-object p1, v3, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 421
    .line 422
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/ShareAccountDetailBean;

    .line 423
    .line 424
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/ShareAccountDetailBean;->getTransType()Ljava/lang/String;

    .line 425
    .line 426
    .line 427
    move-result-object p1

    .line 428
    iget-object v0, v3, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 429
    .line 430
    check-cast v0, Lcom/transsnet/palmpay/core/bean/rsp/ShareAccountDetailBean;

    .line 431
    .line 432
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/rsp/ShareAccountDetailBean;->getBusinessType()I

    .line 433
    .line 434
    .line 435
    move-result v0

    .line 436
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 437
    .line 438
    .line 439
    move-result-object v0

    .line 440
    iget-object v1, v3, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 441
    .line 442
    check-cast v1, Lcom/transsnet/palmpay/core/bean/rsp/ShareAccountDetailBean;

    .line 443
    .line 444
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/rsp/ShareAccountDetailBean;->getAccountNo()Ljava/lang/String;

    .line 445
    .line 446
    .line 447
    move-result-object v1

    .line 448
    new-instance v2, Lkotlin/Pair;

    .line 449
    .line 450
    const-string v4, "core_order_source_type"

    .line 451
    .line 452
    const-string v5, "DEEPLINK"

    .line 453
    .line 454
    invoke-direct {v2, v4, v5}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 455
    .line 456
    .line 457
    iget-object v3, v3, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 458
    .line 459
    check-cast v3, Lcom/transsnet/palmpay/core/bean/rsp/ShareAccountDetailBean;

    .line 460
    .line 461
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/bean/rsp/ShareAccountDetailBean;->getMemberId()Ljava/lang/String;

    .line 462
    .line 463
    .line 464
    move-result-object v3

    .line 465
    new-instance v4, Lkotlin/Pair;

    .line 466
    .line 467
    const-string v5, "MEMBER_ID"

    .line 468
    .line 469
    invoke-direct {v4, v5, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 470
    .line 471
    .line 472
    filled-new-array {v2, v4}, [Lkotlin/Pair;

    .line 473
    .line 474
    .line 475
    move-result-object v2

    .line 476
    invoke-static {v2}, La/a;->e([Lkotlin/Pair;)Landroid/os/Bundle;

    .line 477
    .line 478
    .line 479
    move-result-object v2

    .line 480
    invoke-static {p1, v0, v1, v2}, LPa/r0;->O0(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 481
    .line 482
    .line 483
    return-void

    .line 484
    :pswitch_10
    check-cast v3, Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;

    .line 485
    .line 486
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;->e(Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;Landroid/view/View;)V

    .line 487
    .line 488
    .line 489
    return-void

    .line 490
    :pswitch_11
    check-cast v3, LAe/p;

    .line 491
    .line 492
    invoke-static {v3, p1}, LAe/p;->b(LAe/p;Landroid/view/View;)V

    .line 493
    .line 494
    .line 495
    return-void

    .line 496
    :pswitch_12
    check-cast v3, Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;

    .line 497
    .line 498
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;->a(Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;Landroid/view/View;)V

    .line 499
    .line 500
    .line 501
    return-void

    .line 502
    :pswitch_13
    check-cast v3, Lcom/transsnet/palmpay/ui/dialog/MonthlyLimitDialog;

    .line 503
    .line 504
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/ui/dialog/MonthlyLimitDialog;->a(Lcom/transsnet/palmpay/ui/dialog/MonthlyLimitDialog;Landroid/view/View;)V

    .line 505
    .line 506
    .line 507
    return-void

    .line 508
    :pswitch_14
    check-cast v3, Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;

    .line 509
    .line 510
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;Landroid/view/View;)V

    .line 511
    .line 512
    .line 513
    return-void

    .line 514
    :pswitch_15
    check-cast v3, Lcom/transsnet/palmpay/send_money/ui/dialog/TransferErrorDialog;

    .line 515
    .line 516
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/send_money/ui/dialog/TransferErrorDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/TransferErrorDialog;Landroid/view/View;)V

    .line 517
    .line 518
    .line 519
    return-void

    .line 520
    :pswitch_16
    check-cast v3, Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;

    .line 521
    .line 522
    invoke-static {v3, p1}, Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;Landroid/view/View;)V

    .line 523
    .line 524
    .line 525
    return-void

    .line 526
    :pswitch_17
    check-cast v3, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail;

    .line 527
    .line 528
    invoke-virtual {v3}, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail;->getCustomerServicePhone()Ljava/lang/String;

    .line 529
    .line 530
    .line 531
    move-result-object p1

    .line 532
    invoke-static {p1}, Lcom/transsnet/palmpay/util/PhoneUtils;->dial(Ljava/lang/String;)V

    .line 533
    .line 534
    .line 535
    return-void

    .line 536
    :pswitch_18
    check-cast v3, LAd/m;

    .line 537
    .line 538
    invoke-virtual {v3}, Landroidx/appcompat/app/K;->dismiss()V

    .line 539
    .line 540
    .line 541
    return-void

    .line 542
    :pswitch_19
    sget-object p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment;->q0:Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment$a;

    .line 543
    .line 544
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/resp/CLInstallmentLoanMainPageResp;

    .line 545
    .line 546
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/CLInstallmentLoanMainPageResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 547
    .line 548
    .line 549
    move-result-object p1

    .line 550
    if-eqz p1, :cond_f

    .line 551
    .line 552
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;->getLoanConfig()Lcom/transsnet/palmpay/credit/bean/resp/LoanConfig;

    .line 553
    .line 554
    .line 555
    move-result-object p1

    .line 556
    if-eqz p1, :cond_f

    .line 557
    .line 558
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/LoanConfig;->getRiskLevelResp()Lcom/transsnet/palmpay/credit/bean/resp/CardRiskLevelResp;

    .line 559
    .line 560
    .line 561
    move-result-object v2

    .line 562
    :cond_f
    new-instance p1, Landroid/os/Bundle;

    .line 563
    .line 564
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 565
    .line 566
    .line 567
    const-string v0, "amount"

    .line 568
    .line 569
    const-wide/32 v3, 0x7a120

    .line 570
    .line 571
    .line 572
    invoke-virtual {p1, v0, v3, v4}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 573
    .line 574
    .line 575
    if-eqz v2, :cond_10

    .line 576
    .line 577
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CardRiskLevelResp;->getTerm()Ljava/lang/Integer;

    .line 578
    .line 579
    .line 580
    move-result-object v0

    .line 581
    if-eqz v0, :cond_10

    .line 582
    .line 583
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 584
    .line 585
    .line 586
    move-result v0

    .line 587
    goto :goto_5

    .line 588
    :cond_10
    move v0, v1

    .line 589
    :goto_5
    const-string v3, "term"

    .line 590
    .line 591
    invoke-virtual {p1, v3, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 592
    .line 593
    .line 594
    if-eqz v2, :cond_11

    .line 595
    .line 596
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CardRiskLevelResp;->getTermSpan()Ljava/lang/Integer;

    .line 597
    .line 598
    .line 599
    move-result-object v0

    .line 600
    if-eqz v0, :cond_11

    .line 601
    .line 602
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 603
    .line 604
    .line 605
    move-result v1

    .line 606
    :cond_11
    const-string v0, "termSpan"

    .line 607
    .line 608
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 609
    .line 610
    .line 611
    if-eqz v2, :cond_12

    .line 612
    .line 613
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CardRiskLevelResp;->getTermSpanUnit()Ljava/lang/String;

    .line 614
    .line 615
    .line 616
    move-result-object v0

    .line 617
    if-nez v0, :cond_13

    .line 618
    .line 619
    :cond_12
    const-string v0, ""

    .line 620
    .line 621
    :cond_13
    const-string v1, "termSpanUnit"

    .line 622
    .line 623
    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 624
    .line 625
    .line 626
    const-string v0, "AboutInstallmentLoan"

    .line 627
    .line 628
    invoke-static {p1, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 629
    .line 630
    .line 631
    return-void

    .line 632
    :pswitch_1a
    sget-object v0, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeFailFragment;->p:Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeFailFragment$a;

    .line 633
    .line 634
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 635
    .line 636
    .line 637
    move-result p1

    .line 638
    sget v0, LYa/e;->tvOk:I

    .line 639
    .line 640
    if-ne p1, v0, :cond_15

    .line 641
    .line 642
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeFailFragment;

    .line 643
    .line 644
    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 645
    .line 646
    .line 647
    move-result-object p1

    .line 648
    if-eqz p1, :cond_14

    .line 649
    .line 650
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 651
    .line 652
    .line 653
    :cond_14
    const-string p1, "/main/home"

    .line 654
    .line 655
    const-string v0, "tab"

    .line 656
    .line 657
    const-string v1, "finance"

    .line 658
    .line 659
    invoke-static {p1, v0, v1}, LN8/q0;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 660
    .line 661
    .line 662
    :cond_15
    return-void

    .line 663
    :pswitch_1b
    check-cast v3, LPa/w;

    .line 664
    .line 665
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 666
    .line 667
    .line 668
    new-instance p1, Lmh/i;

    .line 669
    .line 670
    iget-object v1, v3, LPa/w;->b:Ljava/lang/Object;

    .line 671
    .line 672
    check-cast v1, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 673
    .line 674
    invoke-direct {p1, v1, v0}, LV6/a;-><init>(Landroid/content/Context;I)V

    .line 675
    .line 676
    .line 677
    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    .line 678
    .line 679
    .line 680
    return-void

    .line 681
    :pswitch_1c
    check-cast v3, Lcom/transsnet/mtn/sdk/ui/bank/_common/LoginSuccessActivity;

    .line 682
    .line 683
    invoke-virtual {v3, p1}, Lcom/transsnet/mtn/sdk/ui/bank/_common/LoginSuccessActivity;->close(Landroid/view/View;)V

    .line 684
    .line 685
    .line 686
    return-void

    .line 687
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
