.class public final LA8/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LA8/h;->a:Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 5
    .line 6
    return-void
.end method
