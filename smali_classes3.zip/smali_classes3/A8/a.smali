.class public final synthetic LA8/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/mtn/sdk/ui/view/MTNButton$a;
.implements Lcom/transsnet/palmpay/custom_view/AmountEditText$OnTextInputListener;
.implements Lio/reactivex/functions/BiFunction;
.implements Lio/reactivex/functions/Function;
.implements Lio/reactivex/functions/Consumer;
.implements Lio/reactivex/functions/Action;
.implements Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView$OnWheelItemSelectedListener;
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;
.implements Lcom/google/android/gms/tasks/OnSuccessListener;
.implements Lcom/google/android/gms/tasks/OnFailureListener;
.implements Landroidx/camera/core/ImageAnalysis$Analyzer;
.implements Lr/b$c;
.implements Lcom/chad/library/adapter/base/listener/OnItemChildClickListener;
.implements Lcom/palmpay/lib/ui/edit/PpAmountEditText$OnTextInputListener;
.implements Lcom/facebook/react/modules/network/OkHttpClientFactory;
.implements Lcom/transsnet/palmpay/core/callback/ResultCallback;
.implements Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout$OnRefreshListener;
.implements Lcom/transsnet/palmpay/custom_view/adapter/BaseRecyclerViewAdapter$ItemViewOnClickListener;
.implements Lcom/transsnet/palmpay/core/callback/Argument2Callback;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LA8/a;->a:I

    iput-object p1, p0, LA8/a;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public OnItemViewOnClick(Landroid/view/View;Ljava/lang/Object;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V
    .locals 9

    .line 1
    const-string p1, "extra_data"

    .line 2
    .line 3
    iget-object p3, p0, LA8/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iget v0, p0, LA8/a;->a:I

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast p2, Lcom/transsnet/palmpay/cash_in/bean/response/BankCashInInstructionBean;

    .line 11
    .line 12
    sget-object v0, Lcom/transsnet/palmpay/cash_in/ui/activity/instruction/InterBankCashInInstructionActivity;->p:Lcom/transsnet/palmpay/cash_in/ui/activity/instruction/InterBankCashInInstructionActivity$a;

    .line 13
    .line 14
    new-instance v0, Landroid/content/Intent;

    .line 15
    .line 16
    const-class v1, Lcom/transsnet/palmpay/cash_in/ui/activity/instruction/InterBankCashInInstructionDetailActivity;

    .line 17
    .line 18
    check-cast p3, Lcom/transsnet/palmpay/cash_in/ui/activity/instruction/InterBankCashInInstructionActivity;

    .line 19
    .line 20
    invoke-direct {v0, p3, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 21
    .line 22
    .line 23
    const/high16 v1, 0x10000000

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 29
    .line 30
    .line 31
    invoke-virtual {p3, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :pswitch_0
    check-cast p2, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;

    .line 36
    .line 37
    sget-object v0, Lcom/transsnet/palmpay/ui/fragment/MeBalanceStatementFragment;->Z:Lcom/transsnet/palmpay/ui/fragment/MeBalanceStatementFragment$a;

    .line 38
    .line 39
    const-string v0, "data"

    .line 40
    .line 41
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p2, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->redirect:Ljava/lang/String;

    .line 45
    .line 46
    check-cast p3, Lcom/transsnet/palmpay/ui/fragment/MeBalanceStatementFragment;

    .line 47
    .line 48
    iput-object v0, p3, Lcom/transsnet/palmpay/ui/fragment/MeBalanceStatementFragment;->Y:Ljava/lang/String;

    .line 49
    .line 50
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getPayId()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    const/4 v1, 0x0

    .line 59
    const-string v2, "getPayId(...)"

    .line 60
    .line 61
    if-eqz v0, :cond_0

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_0
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getPayId()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    const-string v3, "R_"

    .line 72
    .line 73
    invoke-static {v0, v3, v1}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    :goto_0
    if-eqz v1, :cond_1

    .line 78
    .line 79
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getTransType()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    const-string v1, "03"

    .line 84
    .line 85
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-nez v0, :cond_1

    .line 90
    .line 91
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 92
    .line 93
    .line 94
    move-result-object p3

    .line 95
    const-string v0, "/main/refund_billdetail"

    .line 96
    .line 97
    invoke-virtual {p3, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 98
    .line 99
    .line 100
    move-result-object p3

    .line 101
    const-string v0, "orderNo"

    .line 102
    .line 103
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getRemark()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-virtual {p3, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 108
    .line 109
    .line 110
    move-result-object p3

    .line 111
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getTransType()Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object p2

    .line 115
    invoke-virtual {p3, p1, p2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    goto :goto_1

    .line 123
    :cond_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getPayId()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object p1

    .line 127
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 128
    .line 129
    .line 130
    move-result p1

    .line 131
    if-nez p1, :cond_2

    .line 132
    .line 133
    iget-object p1, p3, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 134
    .line 135
    move-object v3, p1

    .line 136
    check-cast v3, Lcom/transsnet/palmpay/viewmodule/BalanceViewModel;

    .line 137
    .line 138
    if-eqz v3, :cond_2

    .line 139
    .line 140
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getPayId()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v4

    .line 144
    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getAmount()J

    .line 148
    .line 149
    .line 150
    move-result-wide v5

    .line 151
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/AccountFlowBean$DataBean$ListBean;->getCreateTime()J

    .line 152
    .line 153
    .line 154
    move-result-wide v7

    .line 155
    invoke-virtual/range {v3 .. v8}, Lcom/transsnet/palmpay/viewmodule/BalanceViewModel;->e(Ljava/lang/String;JJ)V

    .line 156
    .line 157
    .line 158
    :cond_2
    :goto_1
    return-void

    .line 159
    :pswitch_data_0
    .packed-switch 0x19
        :pswitch_0
    .end packed-switch
.end method

.method public OnTextInput(Ljava/lang/String;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LA8/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iget v2, v0, LA8/a;->a:I

    .line 6
    .line 7
    packed-switch v2, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    sget-object v2, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;->r0:Ljava/lang/String;

    .line 11
    .line 12
    check-cast v1, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;

    .line 13
    .line 14
    invoke-virtual {v1}, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;->p()Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->getLongAmount()J

    .line 19
    .line 20
    .line 21
    move-result-wide v2

    .line 22
    iput-wide v2, v1, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;->Q:J

    .line 23
    .line 24
    invoke-virtual {v1}, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;->p()Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    const-string v2, ""

    .line 29
    .line 30
    invoke-virtual {v1, v2}, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->setError(Ljava/lang/CharSequence;)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :pswitch_0
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;

    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    iput-boolean v2, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->G1:Z

    .line 38
    .line 39
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->E()Landroid/widget/LinearLayout;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    const/16 v4, 0x8

    .line 44
    .line 45
    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    .line 46
    .line 47
    .line 48
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->c1:Lxf/t;

    .line 49
    .line 50
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    const-string v5, "getValue(...)"

    .line 55
    .line 56
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    check-cast v3, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 60
    .line 61
    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    .line 62
    .line 63
    .line 64
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->l1:Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;

    .line 65
    .line 66
    const/4 v6, 0x1

    .line 67
    if-eqz v3, :cond_1

    .line 68
    .line 69
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    invoke-virtual {v7}, Lcom/transsnet/palmpay/custom_view/AmountEditText;->getLong()J

    .line 74
    .line 75
    .line 76
    move-result-wide v7

    .line 77
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;->getMaxLoanAmt()Ljava/lang/Long;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    if-nez v3, :cond_0

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_0
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 85
    .line 86
    .line 87
    move-result-wide v9

    .line 88
    cmp-long v3, v7, v9

    .line 89
    .line 90
    if-nez v3, :cond_1

    .line 91
    .line 92
    move v3, v6

    .line 93
    goto :goto_1

    .line 94
    :cond_1
    :goto_0
    move v3, v2

    .line 95
    :goto_1
    iput-boolean v3, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->D1:Z

    .line 96
    .line 97
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->f1:Lxf/t;

    .line 98
    .line 99
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    check-cast v3, Landroid/widget/TextView;

    .line 107
    .line 108
    iget-boolean v7, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->D1:Z

    .line 109
    .line 110
    if-eqz v7, :cond_2

    .line 111
    .line 112
    move v7, v4

    .line 113
    goto :goto_2

    .line 114
    :cond_2
    move v7, v2

    .line 115
    :goto_2
    invoke-virtual {v3, v7}, Landroid/view/View;->setVisibility(I)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->U()Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 119
    .line 120
    .line 121
    move-result-object v3

    .line 122
    iget-boolean v7, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->D1:Z

    .line 123
    .line 124
    if-eqz v7, :cond_3

    .line 125
    .line 126
    move v7, v4

    .line 127
    goto :goto_3

    .line 128
    :cond_3
    move v7, v2

    .line 129
    :goto_3
    invoke-virtual {v3, v7}, Landroid/view/View;->setVisibility(I)V

    .line 130
    .line 131
    .line 132
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->i1:Lxf/t;

    .line 133
    .line 134
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v3

    .line 138
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    check-cast v3, Landroid/widget/ImageView;

    .line 142
    .line 143
    iget-boolean v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->D1:Z

    .line 144
    .line 145
    if-eqz v5, :cond_4

    .line 146
    .line 147
    move v5, v4

    .line 148
    goto :goto_4

    .line 149
    :cond_4
    move v5, v2

    .line 150
    :goto_4
    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->X()Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 154
    .line 155
    .line 156
    move-result-object v3

    .line 157
    const/4 v5, 0x0

    .line 158
    if-eqz v3, :cond_5

    .line 159
    .line 160
    invoke-virtual {v3, v5}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->setCoupon(Lcom/transsnet/palmpay/credit/bean/resp/CLBorrowCouponData;)V

    .line 161
    .line 162
    .line 163
    :cond_5
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->X()Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    if-eqz v3, :cond_7

    .line 168
    .line 169
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getProductSubId()Ljava/lang/Integer;

    .line 170
    .line 171
    .line 172
    move-result-object v3

    .line 173
    if-nez v3, :cond_6

    .line 174
    .line 175
    goto :goto_5

    .line 176
    :cond_6
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 177
    .line 178
    .line 179
    move-result v3

    .line 180
    const/4 v7, 0x2

    .line 181
    if-ne v3, v7, :cond_7

    .line 182
    .line 183
    iput-object v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->x1:Lcom/transsnet/palmpay/credit/bean/BorrowAllDiscountConfig;

    .line 184
    .line 185
    iput-boolean v2, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->E1:Z

    .line 186
    .line 187
    :cond_7
    :goto_5
    iput-object v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->p1:Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 188
    .line 189
    iput-object v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->q1:Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 190
    .line 191
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 192
    .line 193
    .line 194
    move-result-object v3

    .line 195
    if-eqz v3, :cond_1a

    .line 196
    .line 197
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 198
    .line 199
    .line 200
    move-result-object v7

    .line 201
    invoke-virtual {v7}, Lcom/transsnet/palmpay/custom_view/AmountEditText;->getLong()J

    .line 202
    .line 203
    .line 204
    move-result-wide v7

    .line 205
    iget-object v9, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->l1:Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;

    .line 206
    .line 207
    if-eqz v9, :cond_8

    .line 208
    .line 209
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;->getMaxLoanAmt()Ljava/lang/Long;

    .line 210
    .line 211
    .line 212
    move-result-object v9

    .line 213
    if-eqz v9, :cond_8

    .line 214
    .line 215
    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    .line 216
    .line 217
    .line 218
    move-result-wide v12

    .line 219
    goto :goto_6

    .line 220
    :cond_8
    const-wide/16 v12, 0x0

    .line 221
    .line 222
    :goto_6
    iget-object v9, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->l1:Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;

    .line 223
    .line 224
    if-eqz v9, :cond_9

    .line 225
    .line 226
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;->getMinLoanAmt()Ljava/lang/Long;

    .line 227
    .line 228
    .line 229
    move-result-object v9

    .line 230
    if-eqz v9, :cond_9

    .line 231
    .line 232
    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    .line 233
    .line 234
    .line 235
    move-result-wide v14

    .line 236
    goto :goto_7

    .line 237
    :cond_9
    const-wide/16 v14, 0x0

    .line 238
    .line 239
    :goto_7
    iput-boolean v6, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->F1:Z

    .line 240
    .line 241
    cmp-long v9, v7, v14

    .line 242
    .line 243
    if-gez v9, :cond_a

    .line 244
    .line 245
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 246
    .line 247
    .line 248
    move-result-object v6

    .line 249
    sget v7, LYa/b;->cs_cl_max_txt_color:I

    .line 250
    .line 251
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 252
    .line 253
    .line 254
    move-result v7

    .line 255
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 256
    .line 257
    .line 258
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 259
    .line 260
    .line 261
    move-result-object v6

    .line 262
    sget v7, LYa/g;->cs_cl_min_tips:I

    .line 263
    .line 264
    invoke-static {v14, v15, v2}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v8

    .line 268
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object v8

    .line 272
    invoke-virtual {v1, v7, v8}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object v7

    .line 276
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 277
    .line 278
    .line 279
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 280
    .line 281
    .line 282
    move-result-object v6

    .line 283
    invoke-virtual {v6, v2}, Landroid/view/View;->setVisibility(I)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 287
    .line 288
    .line 289
    move-result-object v6

    .line 290
    invoke-virtual {v6, v2, v2, v2, v2}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    .line 291
    .line 292
    .line 293
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 294
    .line 295
    .line 296
    move-result-object v6

    .line 297
    sget v7, LYa/b;->cs_cl_repayment_amount_tips_txt_color:I

    .line 298
    .line 299
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 300
    .line 301
    .line 302
    move-result v7

    .line 303
    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 307
    .line 308
    .line 309
    move-result-object v6

    .line 310
    invoke-virtual {v6, v2}, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;->setActionButtonEnable(Z)V

    .line 311
    .line 312
    .line 313
    goto/16 :goto_a

    .line 314
    .line 315
    :cond_a
    cmp-long v9, v7, v12

    .line 316
    .line 317
    if-lez v9, :cond_b

    .line 318
    .line 319
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 320
    .line 321
    .line 322
    move-result-object v6

    .line 323
    sget v7, LYa/b;->cs_cl_max_txt_color:I

    .line 324
    .line 325
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 326
    .line 327
    .line 328
    move-result v7

    .line 329
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 330
    .line 331
    .line 332
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 333
    .line 334
    .line 335
    move-result-object v6

    .line 336
    sget v7, LYa/g;->cs_cl_max_tips:I

    .line 337
    .line 338
    invoke-static {v12, v13, v2}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v8

    .line 342
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    move-result-object v8

    .line 346
    invoke-virtual {v1, v7, v8}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object v7

    .line 350
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 351
    .line 352
    .line 353
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 354
    .line 355
    .line 356
    move-result-object v6

    .line 357
    invoke-virtual {v6, v2}, Landroid/view/View;->setVisibility(I)V

    .line 358
    .line 359
    .line 360
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 361
    .line 362
    .line 363
    move-result-object v6

    .line 364
    invoke-virtual {v6, v2, v2, v2, v2}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    .line 365
    .line 366
    .line 367
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 368
    .line 369
    .line 370
    move-result-object v6

    .line 371
    sget v7, LYa/b;->cs_cl_repayment_amount_tips_txt_color:I

    .line 372
    .line 373
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 374
    .line 375
    .line 376
    move-result v7

    .line 377
    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 378
    .line 379
    .line 380
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 381
    .line 382
    .line 383
    move-result-object v6

    .line 384
    invoke-virtual {v6, v2}, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;->setActionButtonEnable(Z)V

    .line 385
    .line 386
    .line 387
    goto/16 :goto_a

    .line 388
    .line 389
    :cond_b
    const/16 v5, 0x2710

    .line 390
    .line 391
    const-wide/16 v16, 0x0

    .line 392
    .line 393
    int-to-long v10, v5

    .line 394
    rem-long v10, v7, v10

    .line 395
    .line 396
    cmp-long v5, v10, v16

    .line 397
    .line 398
    if-eqz v5, :cond_c

    .line 399
    .line 400
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 401
    .line 402
    .line 403
    move-result-object v5

    .line 404
    sget v6, LYa/b;->cs_cl_max_txt_color:I

    .line 405
    .line 406
    invoke-virtual {v3, v6}, Landroid/content/Context;->getColor(I)I

    .line 407
    .line 408
    .line 409
    move-result v6

    .line 410
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 411
    .line 412
    .line 413
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 414
    .line 415
    .line 416
    move-result-object v5

    .line 417
    sget v6, LYa/g;->cs_cl_round_number:I

    .line 418
    .line 419
    const-wide/16 v7, 0x2710

    .line 420
    .line 421
    invoke-static {v7, v8}, LPa/r0;->F(J)Ljava/lang/String;

    .line 422
    .line 423
    .line 424
    move-result-object v7

    .line 425
    const-wide/32 v8, 0x186a0

    .line 426
    .line 427
    .line 428
    invoke-static {v8, v9}, LPa/r0;->F(J)Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object v8

    .line 432
    filled-new-array {v7, v8}, [Ljava/lang/Object;

    .line 433
    .line 434
    .line 435
    move-result-object v7

    .line 436
    invoke-virtual {v1, v6, v7}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 437
    .line 438
    .line 439
    move-result-object v6

    .line 440
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 441
    .line 442
    .line 443
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 444
    .line 445
    .line 446
    move-result-object v5

    .line 447
    invoke-virtual {v5, v2}, Landroid/view/View;->setVisibility(I)V

    .line 448
    .line 449
    .line 450
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 451
    .line 452
    .line 453
    move-result-object v5

    .line 454
    sget v6, LYa/b;->cs_cl_repayment_amount_tips_txt_color:I

    .line 455
    .line 456
    invoke-virtual {v3, v6}, Landroid/content/Context;->getColor(I)I

    .line 457
    .line 458
    .line 459
    move-result v6

    .line 460
    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 461
    .line 462
    .line 463
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 464
    .line 465
    .line 466
    move-result-object v5

    .line 467
    invoke-virtual {v5, v2}, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;->setActionButtonEnable(Z)V

    .line 468
    .line 469
    .line 470
    goto/16 :goto_a

    .line 471
    .line 472
    :cond_c
    cmp-long v5, v7, v16

    .line 473
    .line 474
    if-nez v5, :cond_d

    .line 475
    .line 476
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 477
    .line 478
    .line 479
    move-result-object v5

    .line 480
    sget v6, LYa/b;->cs_cl_input_divider_focus_color:I

    .line 481
    .line 482
    invoke-virtual {v3, v6}, Landroid/content/Context;->getColor(I)I

    .line 483
    .line 484
    .line 485
    move-result v6

    .line 486
    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 487
    .line 488
    .line 489
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 490
    .line 491
    .line 492
    move-result-object v5

    .line 493
    invoke-virtual {v5, v2}, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;->setActionButtonEnable(Z)V

    .line 494
    .line 495
    .line 496
    goto/16 :goto_a

    .line 497
    .line 498
    :cond_d
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 499
    .line 500
    .line 501
    move-result-object v5

    .line 502
    invoke-virtual {v5}, Lcom/transsnet/palmpay/custom_view/AmountEditText;->getLong()J

    .line 503
    .line 504
    .line 505
    move-result-wide v7

    .line 506
    iget-object v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->l1:Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;

    .line 507
    .line 508
    if-eqz v5, :cond_e

    .line 509
    .line 510
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;->getMinLoanAmt()Ljava/lang/Long;

    .line 511
    .line 512
    .line 513
    move-result-object v5

    .line 514
    if-eqz v5, :cond_e

    .line 515
    .line 516
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 517
    .line 518
    .line 519
    move-result-wide v10

    .line 520
    goto :goto_8

    .line 521
    :cond_e
    move-wide/from16 v10, v16

    .line 522
    .line 523
    :goto_8
    cmp-long v5, v7, v10

    .line 524
    .line 525
    if-gez v5, :cond_f

    .line 526
    .line 527
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 528
    .line 529
    .line 530
    move-result-object v5

    .line 531
    sget v7, LYa/b;->cs_cl_repayment_amount_tips_txt_color:I

    .line 532
    .line 533
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 534
    .line 535
    .line 536
    move-result v7

    .line 537
    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 538
    .line 539
    .line 540
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 541
    .line 542
    .line 543
    move-result-object v5

    .line 544
    sget v7, LYa/g;->cs_cl_min_installment_amount_tips:I

    .line 545
    .line 546
    invoke-static {v14, v15, v6}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 547
    .line 548
    .line 549
    move-result-object v6

    .line 550
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 551
    .line 552
    .line 553
    move-result-object v6

    .line 554
    invoke-virtual {v1, v7, v6}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 555
    .line 556
    .line 557
    move-result-object v6

    .line 558
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 559
    .line 560
    .line 561
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 562
    .line 563
    .line 564
    move-result-object v5

    .line 565
    invoke-virtual {v5, v2}, Landroid/view/View;->setVisibility(I)V

    .line 566
    .line 567
    .line 568
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 569
    .line 570
    .line 571
    move-result-object v5

    .line 572
    sget v6, LYa/b;->cs_cl_repayment_amount_tips_txt_color:I

    .line 573
    .line 574
    invoke-virtual {v3, v6}, Landroid/content/Context;->getColor(I)I

    .line 575
    .line 576
    .line 577
    move-result v6

    .line 578
    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 579
    .line 580
    .line 581
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 582
    .line 583
    .line 584
    move-result-object v5

    .line 585
    invoke-virtual {v5, v2}, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;->setActionButtonEnable(Z)V

    .line 586
    .line 587
    .line 588
    goto/16 :goto_a

    .line 589
    .line 590
    :cond_f
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 591
    .line 592
    .line 593
    move-result-object v5

    .line 594
    invoke-virtual {v5}, Lcom/transsnet/palmpay/custom_view/AmountEditText;->getLong()J

    .line 595
    .line 596
    .line 597
    move-result-wide v7

    .line 598
    iget-object v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->l1:Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;

    .line 599
    .line 600
    if-eqz v5, :cond_10

    .line 601
    .line 602
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;->getMaxLoanAmt()Ljava/lang/Long;

    .line 603
    .line 604
    .line 605
    move-result-object v5

    .line 606
    if-eqz v5, :cond_10

    .line 607
    .line 608
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 609
    .line 610
    .line 611
    move-result-wide v10

    .line 612
    goto :goto_9

    .line 613
    :cond_10
    move-wide/from16 v10, v16

    .line 614
    .line 615
    :goto_9
    cmp-long v5, v7, v10

    .line 616
    .line 617
    if-lez v5, :cond_11

    .line 618
    .line 619
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 620
    .line 621
    .line 622
    move-result-object v5

    .line 623
    sget v7, LYa/b;->cs_cl_max_amount_tips_txt_color:I

    .line 624
    .line 625
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 626
    .line 627
    .line 628
    move-result v7

    .line 629
    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 630
    .line 631
    .line 632
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 633
    .line 634
    .line 635
    move-result-object v5

    .line 636
    sget v7, LYa/g;->cs_cl_max_one_off_limit_tips:I

    .line 637
    .line 638
    invoke-static {v12, v13, v6}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 639
    .line 640
    .line 641
    move-result-object v6

    .line 642
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 643
    .line 644
    .line 645
    move-result-object v6

    .line 646
    invoke-virtual {v1, v7, v6}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 647
    .line 648
    .line 649
    move-result-object v6

    .line 650
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 651
    .line 652
    .line 653
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 654
    .line 655
    .line 656
    move-result-object v5

    .line 657
    invoke-virtual {v5, v2}, Landroid/view/View;->setVisibility(I)V

    .line 658
    .line 659
    .line 660
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 661
    .line 662
    .line 663
    move-result-object v5

    .line 664
    sget v6, LYa/b;->cs_cl_repayment_amount_tips_txt_color:I

    .line 665
    .line 666
    invoke-virtual {v3, v6}, Landroid/content/Context;->getColor(I)I

    .line 667
    .line 668
    .line 669
    move-result v6

    .line 670
    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 671
    .line 672
    .line 673
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 674
    .line 675
    .line 676
    move-result-object v5

    .line 677
    invoke-virtual {v5, v2}, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;->setActionButtonEnable(Z)V

    .line 678
    .line 679
    .line 680
    goto :goto_a

    .line 681
    :cond_11
    if-gez v9, :cond_12

    .line 682
    .line 683
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 684
    .line 685
    .line 686
    move-result-object v5

    .line 687
    invoke-virtual {v5, v4}, Landroid/view/View;->setVisibility(I)V

    .line 688
    .line 689
    .line 690
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 691
    .line 692
    .line 693
    move-result-object v5

    .line 694
    sget v7, LL6/b;->ppColorTextPrimary:I

    .line 695
    .line 696
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 697
    .line 698
    .line 699
    move-result v7

    .line 700
    invoke-virtual {v5, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 701
    .line 702
    .line 703
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 704
    .line 705
    .line 706
    move-result-object v5

    .line 707
    invoke-virtual {v5, v6}, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;->setActionButtonEnable(Z)V

    .line 708
    .line 709
    .line 710
    iput-boolean v2, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->F1:Z

    .line 711
    .line 712
    goto :goto_a

    .line 713
    :cond_12
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 714
    .line 715
    .line 716
    move-result-object v5

    .line 717
    sget v7, LYa/b;->cs_cl_max_amount_tips_txt_color:I

    .line 718
    .line 719
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 720
    .line 721
    .line 722
    move-result v7

    .line 723
    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 724
    .line 725
    .line 726
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 727
    .line 728
    .line 729
    move-result-object v5

    .line 730
    sget v7, LYa/g;->cs_cl_only_one_loan_is_support:I

    .line 731
    .line 732
    invoke-virtual {v1, v7}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 733
    .line 734
    .line 735
    move-result-object v7

    .line 736
    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 737
    .line 738
    .line 739
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 740
    .line 741
    .line 742
    move-result-object v5

    .line 743
    invoke-virtual {v5, v4}, Landroid/view/View;->setVisibility(I)V

    .line 744
    .line 745
    .line 746
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 747
    .line 748
    .line 749
    move-result-object v5

    .line 750
    sget v7, LYa/b;->cs_cl_input_divider_normal_color:I

    .line 751
    .line 752
    invoke-virtual {v3, v7}, Landroid/content/Context;->getColor(I)I

    .line 753
    .line 754
    .line 755
    move-result v7

    .line 756
    invoke-virtual {v5, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 757
    .line 758
    .line 759
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 760
    .line 761
    .line 762
    move-result-object v5

    .line 763
    invoke-virtual {v5, v6}, Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;->setActionButtonEnable(Z)V

    .line 764
    .line 765
    .line 766
    iput-boolean v2, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->F1:Z

    .line 767
    .line 768
    :goto_a
    iget-object v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->l1:Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;

    .line 769
    .line 770
    if-eqz v5, :cond_13

    .line 771
    .line 772
    iget-object v5, v5, Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;->can:Ljava/lang/Boolean;

    .line 773
    .line 774
    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 775
    .line 776
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 777
    .line 778
    .line 779
    move-result v5

    .line 780
    goto :goto_b

    .line 781
    :cond_13
    move v5, v2

    .line 782
    :goto_b
    if-eqz v5, :cond_15

    .line 783
    .line 784
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 785
    .line 786
    .line 787
    move-result-object v5

    .line 788
    sget v6, LYa/b;->cs_cl_max_txt_color:I

    .line 789
    .line 790
    invoke-virtual {v3, v6}, Landroid/content/Context;->getColor(I)I

    .line 791
    .line 792
    .line 793
    move-result v6

    .line 794
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 795
    .line 796
    .line 797
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 798
    .line 799
    .line 800
    move-result-object v5

    .line 801
    iget-object v6, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->l1:Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;

    .line 802
    .line 803
    if-eqz v6, :cond_14

    .line 804
    .line 805
    iget-object v6, v6, Lcom/transsnet/palmpay/credit/bean/rsp/CLCanBorrowData;->msg:Ljava/lang/String;

    .line 806
    .line 807
    goto :goto_c

    .line 808
    :cond_14
    const/4 v6, 0x0

    .line 809
    :goto_c
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 810
    .line 811
    .line 812
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 813
    .line 814
    .line 815
    move-result-object v5

    .line 816
    invoke-virtual {v5, v2}, Landroid/view/View;->setVisibility(I)V

    .line 817
    .line 818
    .line 819
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->v()Landroid/widget/TextView;

    .line 820
    .line 821
    .line 822
    move-result-object v5

    .line 823
    invoke-virtual {v5, v2, v2, v2, v2}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    .line 824
    .line 825
    .line 826
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y()Landroid/view/View;

    .line 827
    .line 828
    .line 829
    move-result-object v5

    .line 830
    sget v6, LYa/b;->cs_cl_repayment_amount_tips_txt_color:I

    .line 831
    .line 832
    invoke-virtual {v3, v6}, Landroid/content/Context;->getColor(I)I

    .line 833
    .line 834
    .line 835
    move-result v3

    .line 836
    invoke-virtual {v5, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 837
    .line 838
    .line 839
    :cond_15
    const/4 v3, -0x1

    .line 840
    iput v3, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->o1:I

    .line 841
    .line 842
    iget-object v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->s1:Lxb/y;

    .line 843
    .line 844
    if-eqz v5, :cond_16

    .line 845
    .line 846
    iput v3, v5, Lxb/y;->d:I

    .line 847
    .line 848
    :cond_16
    if-eqz v5, :cond_17

    .line 849
    .line 850
    invoke-virtual {v5}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 851
    .line 852
    .line 853
    :cond_17
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->I1:Lxb/y;

    .line 854
    .line 855
    if-eqz v3, :cond_18

    .line 856
    .line 857
    iget v5, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y1:I

    .line 858
    .line 859
    iput v5, v3, Lxb/y;->d:I

    .line 860
    .line 861
    :cond_18
    if-eqz v3, :cond_19

    .line 862
    .line 863
    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 864
    .line 865
    .line 866
    :cond_19
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->W()Landroid/widget/LinearLayout;

    .line 867
    .line 868
    .line 869
    move-result-object v3

    .line 870
    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    .line 871
    .line 872
    .line 873
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->N()Landroid/widget/LinearLayout;

    .line 874
    .line 875
    .line 876
    move-result-object v3

    .line 877
    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    .line 878
    .line 879
    .line 880
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->E()Landroid/widget/LinearLayout;

    .line 881
    .line 882
    .line 883
    move-result-object v3

    .line 884
    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    .line 885
    .line 886
    .line 887
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->R()Landroid/widget/LinearLayout;

    .line 888
    .line 889
    .line 890
    move-result-object v3

    .line 891
    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    .line 892
    .line 893
    .line 894
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->B()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 895
    .line 896
    .line 897
    move-result-object v3

    .line 898
    invoke-virtual {v3, v2}, Landroid/view/View;->setVisibility(I)V

    .line 899
    .line 900
    .line 901
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->K()Landroid/widget/TextView;

    .line 902
    .line 903
    .line 904
    move-result-object v3

    .line 905
    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    .line 906
    .line 907
    .line 908
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->z()Landroid/widget/Button;

    .line 909
    .line 910
    .line 911
    move-result-object v3

    .line 912
    invoke-virtual {v3, v2}, Landroid/view/View;->setEnabled(Z)V

    .line 913
    .line 914
    .line 915
    :cond_1a
    iget-boolean v2, v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->D1:Z

    .line 916
    .line 917
    if-nez v2, :cond_1b

    .line 918
    .line 919
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->A()Lcom/transsnet/palmpay/core/ui/widget/DigitalKeyboardView;

    .line 920
    .line 921
    .line 922
    move-result-object v2

    .line 923
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    .line 924
    .line 925
    .line 926
    move-result v2

    .line 927
    if-nez v2, :cond_1b

    .line 928
    .line 929
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->u()V

    .line 930
    .line 931
    .line 932
    :cond_1b
    return-void

    .line 933
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method public a()V
    .locals 4

    iget v0, p0, LA8/a;->a:I

    packed-switch v0, :pswitch_data_0

    .line 5
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, LSd/b;

    iget-object v0, v0, LSd/b;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 6
    iget-object v0, v0, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;->g:LPa/w;

    .line 7
    iget-object v1, v0, LPa/w;->b:Ljava/lang/Object;

    check-cast v1, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    .line 8
    new-instance v2, Landroid/content/Intent;

    iget-object v0, v0, LPa/w;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/mtn/sdk/ui/bank/_common/TermsAndPrivacyActivity;

    const-class v3, Lcom/transsnet/mtn/sdk/ui/bank/_common/SelectBankActivity;

    invoke-direct {v2, v0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void

    .line 9
    :pswitch_0
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/mtn/sdk/ui/bank/_common/LoginSuccessActivity;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-static {}, Lf/c;->a()Lf/c;

    move-result-object v0

    invoke-static {}, Lf/c;->a()Lf/c;

    move-result-object v1

    iget-object v1, v1, Lf/c;->b:Ljava/lang/String;

    const/16 v2, 0x65

    invoke-virtual {v0, v2, v1}, Lf/c;->b(ILjava/lang/String;)V

    .line 11
    sget-object v0, LOe/a;->d:LOe/a;

    if-nez v0, :cond_0

    new-instance v0, LOe/a;

    const/16 v1, 0x17

    invoke-direct {v0, v1}, LOe/a;-><init>(I)V

    sput-object v0, LOe/a;->d:LOe/a;

    :cond_0
    sget-object v0, LOe/a;->d:LOe/a;

    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    new-instance v1, Ljava/util/ArrayList;

    iget-object v0, v0, LOe/a;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v1}, Ljava/util/Collections;->reverse(Ljava/util/List;)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Leh/a;

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    invoke-virtual {v1}, Landroid/app/Activity;->finish()V

    goto :goto_0

    :cond_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public a(Ljava/util/Calendar;)V
    .locals 5

    .line 1
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/mtn/sdk/ui/view/InputView;

    iget-object v1, v0, Lcom/transsnet/mtn/sdk/ui/view/InputView;->a:Landroidx/appcompat/widget/AppCompatEditText;

    invoke-virtual {v1, p1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    iget-object v1, v0, Lcom/transsnet/mtn/sdk/ui/view/InputView;->a:Landroidx/appcompat/widget/AppCompatEditText;

    new-instance v2, Ljava/text/SimpleDateFormat;

    iget-object v0, v0, Lcom/transsnet/mtn/sdk/ui/view/InputView;->d:Lmh/e;

    .line 2
    iget v0, v0, Lmh/e;->p:I

    const/4 v3, 0x2

    if-eq v0, v3, :cond_0

    .line 3
    const-string v0, "dd/MMM/yyyy"

    goto :goto_0

    :cond_0
    const-string v0, "MM/yy"

    .line 4
    :goto_0
    invoke-direct {v2, v0}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/Date;->getTime()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public accept(Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    iget v1, p0, LA8/a;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget-object v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment;->q0:Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment$a;

    .line 9
    .line 10
    check-cast v0, LAb/B;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, LAb/B;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_0
    sget-object v1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment;->q0:Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment$a;

    .line 17
    .line 18
    check-cast v0, LAb/C;

    .line 19
    .line 20
    invoke-virtual {v0, p1}, LAb/C;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    nop

    .line 25
    :pswitch_data_0
    .packed-switch 0x5
        :pswitch_0
    .end packed-switch
.end method

.method public analyze(Landroidx/camera/core/ImageProxy;)V
    .locals 4

    .line 1
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LB6/b0;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const-string v1, "imageProxy"

    .line 9
    .line 10
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->getImage()Landroid/media/Image;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    iget-object v1, v0, LB6/b0;->w:LWf/t0;

    .line 20
    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    invoke-virtual {v1}, LWf/n0;->isActive()Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    const/4 v2, 0x1

    .line 28
    if-ne v1, v2, :cond_0

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    invoke-static {v0}, Landroidx/lifecycle/V;->h(Landroidx/lifecycle/a0;)Lkotlinx/coroutines/CoroutineScope;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    new-instance v2, LB6/X;

    .line 36
    .line 37
    const/4 v3, 0x0

    .line 38
    invoke-direct {v2, v0, p1, v3}, LB6/X;-><init>(LB6/b0;Landroidx/camera/core/ImageProxy;Lkotlin/coroutines/Continuation;)V

    .line 39
    .line 40
    .line 41
    const/4 p1, 0x3

    .line 42
    invoke-static {v1, v3, v3, v2, p1}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :cond_1
    :goto_0
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->close()V

    .line 47
    .line 48
    .line 49
    return-void
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    sget-object v0, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment;->q0:Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment$a;

    .line 1
    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, LAb/B;

    invoke-virtual {v0, p1}, LAb/B;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    return-object p1
.end method

.method public apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    sget-object v0, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment;->q0:Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment$a;

    .line 3
    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "p1"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, LAb/y;

    invoke-virtual {v0, p1, p2}, LAb/y;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lkotlin/Pair;

    return-object p1
.end method

.method public createNewNetworkModuleClient()Lokhttp3/U;
    .locals 1

    .line 1
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;->a(Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;)Lokhttp3/U;

    move-result-object v0

    return-object v0
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 7

    .line 1
    check-cast p1, Ljava/lang/Integer;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    check-cast p2, Landroid/content/Intent;

    .line 8
    .line 9
    sget-object v0, Lcom/transsnet/palmpay/ui/fragment/settings/LoginSettingsFragment;->B:Lcom/transsnet/palmpay/ui/fragment/settings/LoginSettingsFragment$a;

    .line 10
    .line 11
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/ui/fragment/settings/LoginSettingsFragment;

    .line 14
    .line 15
    const-string v1, "enable"

    .line 16
    .line 17
    const/4 v2, -0x1

    .line 18
    const/4 v3, 0x0

    .line 19
    const-string v4, "fail"

    .line 20
    .line 21
    if-ne p1, v2, :cond_2

    .line 22
    .line 23
    if-eqz p2, :cond_0

    .line 24
    .line 25
    :try_start_0
    const-string p1, "_cipher_vector"

    .line 26
    .line 27
    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    const-string v2, "_encrypt_text"

    .line 32
    .line 33
    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    invoke-static {p1, p2}, Lio/fastkv/n;->I(Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    :cond_0
    invoke-static {}, Lio/fastkv/n;->G()V

    .line 41
    .line 42
    .line 43
    const/4 p1, 0x1

    .line 44
    invoke-static {p1}, Lio/fastkv/n;->M(Z)V

    .line 45
    .line 46
    .line 47
    const-string p2, "success"

    .line 48
    .line 49
    const/4 v2, 0x0

    .line 50
    invoke-static {v1, p2, v2}, LD3/a;->N(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 54
    .line 55
    .line 56
    move-result-object p2

    .line 57
    if-eqz p2, :cond_1

    .line 58
    .line 59
    const-string v5, "Enabled Successfully"

    .line 60
    .line 61
    const/16 v6, 0x3d

    .line 62
    .line 63
    invoke-static {p2, v5, v2, v2, v6}, Loa/h;->z(Landroid/content/Context;Ljava/lang/String;LS6/a;Landroid/content/DialogInterface$OnDismissListener;I)V

    .line 64
    .line 65
    .line 66
    :cond_1
    iget-object p2, v0, Lcom/transsnet/palmpay/ui/fragment/settings/LoginSettingsFragment;->w:Lcom/transsnet/palmpay/ui/view/SettingItem;

    .line 67
    .line 68
    if-eqz p2, :cond_3

    .line 69
    .line 70
    invoke-virtual {p2, p1}, Lcom/transsnet/palmpay/ui/view/SettingItem;->setChecked(Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :catch_0
    sget-object p1, LPa/n0;->i:LZ4/c;

    .line 75
    .line 76
    const-string p1, "sdk_error"

    .line 77
    .line 78
    invoke-static {v1, v4, p1}, LD3/a;->N(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    iget-object p1, v0, Lcom/transsnet/palmpay/ui/fragment/settings/LoginSettingsFragment;->w:Lcom/transsnet/palmpay/ui/view/SettingItem;

    .line 82
    .line 83
    if-eqz p1, :cond_3

    .line 84
    .line 85
    invoke-virtual {p1, v3}, Lcom/transsnet/palmpay/ui/view/SettingItem;->setChecked(Z)V

    .line 86
    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_2
    const-string p1, "user_cancelled"

    .line 90
    .line 91
    invoke-static {v1, v4, p1}, LD3/a;->N(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    iget-object p1, v0, Lcom/transsnet/palmpay/ui/fragment/settings/LoginSettingsFragment;->w:Lcom/transsnet/palmpay/ui/view/SettingItem;

    .line 95
    .line 96
    if-eqz p1, :cond_3

    .line 97
    .line 98
    invoke-virtual {p1, v3}, Lcom/transsnet/palmpay/ui/view/SettingItem;->setChecked(Z)V

    .line 99
    .line 100
    .line 101
    :cond_3
    :goto_0
    return-void
.end method

.method public onComplete(Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p1, Ljava/lang/Boolean;

    .line 2
    .line 3
    sget v0, Lcom/transsnet/palmpay/send_money/ui/fragment/AddBankAccountFragment;->M:I

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-eqz p1, :cond_2

    .line 10
    .line 11
    iget-object p1, p0, LA8/a;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Lcom/transsnet/palmpay/send_money/ui/fragment/AddBankAccountFragment;

    .line 14
    .line 15
    iget-object v0, p1, Lcom/transsnet/palmpay/send_money/ui/fragment/AddBankAccountFragment;->C:Lcom/transsnet/palmpay/core/bean/BankInfo;

    .line 16
    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    new-instance v1, Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;

    .line 20
    .line 21
    invoke-direct {v1}, Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;-><init>()V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p1}, Lcom/transsnet/palmpay/send_money/ui/fragment/AddBankAccountFragment;->u()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;->setRecipientBankAccount(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    iget-object v2, v0, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankCode:Ljava/lang/String;

    .line 32
    .line 33
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;->setRecipientBankCode(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    iget-object v2, v0, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankName:Ljava/lang/String;

    .line 37
    .line 38
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;->setRecipientBankName(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    iget-object v2, v0, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankUrl:Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;->setRecipientImageUrl(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    iget v0, v0, Lcom/transsnet/palmpay/core/bean/BankInfo;->mmo:I

    .line 47
    .line 48
    const/4 v2, 0x1

    .line 49
    if-ne v0, v2, :cond_0

    .line 50
    .line 51
    const/4 v0, 0x7

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    const/4 v0, 0x2

    .line 54
    :goto_0
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;->setRecipientType(I)V

    .line 55
    .line 56
    .line 57
    iget-object v0, p1, Lcom/transsnet/palmpay/send_money/ui/fragment/AddBankAccountFragment;->o:Lxf/t;

    .line 58
    .line 59
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    check-cast v0, Lcom/transsnet/palmpay/custom_view/MobileNumberEditText;

    .line 64
    .line 65
    const/4 v2, 0x0

    .line 66
    if-eqz v0, :cond_1

    .line 67
    .line 68
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/MobileNumberEditText;->getString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    goto :goto_1

    .line 73
    :cond_1
    move-object v0, v2

    .line 74
    :goto_1
    invoke-static {v0}, LPa/r0;->L0(Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-static {v0}, LPa/r0;->v0(Ljava/lang/String;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;->setRecipientMobileNo(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 86
    .line 87
    check-cast p1, Lcom/transsnet/palmpay/send_money/viewmodel/AddBankAccountViewModel;

    .line 88
    .line 89
    if-eqz p1, :cond_2

    .line 90
    .line 91
    const-string v0, "req"

    .line 92
    .line 93
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    new-instance v0, LKd/b;

    .line 97
    .line 98
    invoke-direct {v0, v1, v2}, LKd/b;-><init>(Lcom/transsnet/palmpay/send_money/bean/AddRecipientReq;Lkotlin/coroutines/Continuation;)V

    .line 99
    .line 100
    .line 101
    iget-object v1, p1, Lcom/transsnet/palmpay/send_money/viewmodel/AddBankAccountViewModel;->f:Lcom/transsnet/palmpay/core/base/l;

    .line 102
    .line 103
    const/4 v2, 0x0

    .line 104
    const/16 v3, 0x1c

    .line 105
    .line 106
    invoke-static {p1, v0, v1, v2, v3}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 107
    .line 108
    .line 109
    :cond_2
    return-void
.end method

.method public onFailure(Ljava/lang/Exception;)V
    .locals 1

    .line 1
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lkotlinx/coroutines/channels/ProducerScope;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/SendChannel;->close(Ljava/lang/Throwable;)Z

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public onItemChildClick(LM1/j;Landroid/view/View;I)V
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LA8/a;->b:Ljava/lang/Object;

    .line 3
    .line 4
    iget v2, p0, LA8/a;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget v2, Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;->B:I

    .line 10
    .line 11
    const-string v2, "<unused var>"

    .line 12
    .line 13
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string p1, "view"

    .line 17
    .line 18
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    check-cast v1, Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;

    .line 22
    .line 23
    invoke-virtual {v1}, Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;->u()Lve/d;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    check-cast p1, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;

    .line 32
    .line 33
    invoke-virtual {p2}, Landroid/view/View;->getId()I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    sget v3, LAc/e;->v_status_bg:I

    .line 38
    .line 39
    const/4 v4, 0x3

    .line 40
    if-ne v2, v3, :cond_1

    .line 41
    .line 42
    iget p2, p1, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->bankCardStatus:I

    .line 43
    .line 44
    if-eq p2, v4, :cond_0

    .line 45
    .line 46
    const/4 p3, 0x2

    .line 47
    if-ne p2, p3, :cond_8

    .line 48
    .line 49
    :cond_0
    new-instance p2, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 50
    .line 51
    const-string p3, "banksandcardsPagereaddClick"

    .line 52
    .line 53
    invoke-direct {p2, p3}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 57
    .line 58
    .line 59
    move-result-object p3

    .line 60
    invoke-virtual {p3, p2}, LPa/n0;->q(Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;)V

    .line 61
    .line 62
    .line 63
    new-instance p2, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;

    .line 64
    .line 65
    invoke-direct {p2}, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;-><init>()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getCardNo()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p3

    .line 72
    iput-object p3, p2, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;->cardNo:Ljava/lang/String;

    .line 73
    .line 74
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getBankCode()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p3

    .line 78
    iput-object p3, p2, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;->bankCode:Ljava/lang/String;

    .line 79
    .line 80
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getBankName()Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object p3

    .line 84
    iput-object p3, p2, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;->bankName:Ljava/lang/String;

    .line 85
    .line 86
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getExpiryYear()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object p3

    .line 90
    iput-object p3, p2, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;->cardExpiryYear:Ljava/lang/String;

    .line 91
    .line 92
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getExpiryMonth()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object p3

    .line 96
    iput-object p3, p2, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;->cardExpiryMon:Ljava/lang/String;

    .line 97
    .line 98
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getBankUrl()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object p3

    .line 102
    iput-object p3, p2, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;->bankUrl:Ljava/lang/String;

    .line 103
    .line 104
    iget p1, p1, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->bankCardStatus:I

    .line 105
    .line 106
    iput p1, p2, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;->bankCardStatus:I

    .line 107
    .line 108
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 109
    .line 110
    .line 111
    move-result-object p1

    .line 112
    const-string p3, "/coreImpl/add_new_card"

    .line 113
    .line 114
    invoke-virtual {p1, p3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    const-string p3, "extra_data"

    .line 119
    .line 120
    invoke-virtual {p1, p3, p2}, Lcom/alibaba/android/arouter/facade/Postcard;->withParcelable(Ljava/lang/String;Landroid/os/Parcelable;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    goto/16 :goto_1

    .line 128
    .line 129
    :cond_1
    sget v3, LAc/e;->ivDelete:I

    .line 130
    .line 131
    if-ne v2, v3, :cond_2

    .line 132
    .line 133
    invoke-virtual {v1}, Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;->u()Lve/d;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    check-cast p1, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;

    .line 142
    .line 143
    invoke-virtual {v1, p1}, Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;->w(Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;)V

    .line 144
    .line 145
    .line 146
    goto/16 :goto_1

    .line 147
    .line 148
    :cond_2
    sget v3, LAc/e;->iv_setting:I

    .line 149
    .line 150
    const/4 v5, 0x0

    .line 151
    if-ne v2, v3, :cond_4

    .line 152
    .line 153
    invoke-virtual {v1}, Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;->u()Lve/d;

    .line 154
    .line 155
    .line 156
    move-result-object p1

    .line 157
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    check-cast p1, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;

    .line 162
    .line 163
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 164
    .line 165
    .line 166
    move-result-object p3

    .line 167
    sget v2, LAc/f;->main_popup_bank_card_setting:I

    .line 168
    .line 169
    invoke-virtual {p3, v2, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 170
    .line 171
    .line 172
    move-result-object p3

    .line 173
    new-instance v2, LG7/g;

    .line 174
    .line 175
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 176
    .line 177
    .line 178
    move-result-object v3

    .line 179
    const-string v4, "requireContext(...)"

    .line 180
    .line 181
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    invoke-direct {v2, v3}, LG7/g;-><init>(Landroid/content/Context;)V

    .line 185
    .line 186
    .line 187
    invoke-static {p3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    const-string v3, "layout"

    .line 191
    .line 192
    invoke-static {p3, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    iput-object p3, v2, LG7/g;->G:Landroid/view/View;

    .line 196
    .line 197
    const/16 v3, 0xa

    .line 198
    .line 199
    invoke-virtual {v2, v3}, LG7/g;->d(I)V

    .line 200
    .line 201
    .line 202
    const/16 v3, 0x15

    .line 203
    .line 204
    invoke-virtual {v2, v3}, LG7/g;->i(I)V

    .line 205
    .line 206
    .line 207
    sget-object v3, LG7/b;->c:LG7/b;

    .line 208
    .line 209
    invoke-virtual {v2, v3}, LG7/g;->b(LG7/b;)V

    .line 210
    .line 211
    .line 212
    sget-object v3, LG7/c;->b:LG7/c;

    .line 213
    .line 214
    invoke-virtual {v2, v3}, LG7/g;->c(LG7/c;)V

    .line 215
    .line 216
    .line 217
    const/4 v3, 0x4

    .line 218
    invoke-virtual {v2, v3}, LG7/g;->e(I)V

    .line 219
    .line 220
    .line 221
    const/high16 v3, 0x41000000    # 8.0f

    .line 222
    .line 223
    invoke-virtual {v2, v3}, LG7/g;->g(F)V

    .line 224
    .line 225
    .line 226
    sget v3, LL6/b;->ppColorBackgroundLight:I

    .line 227
    .line 228
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 229
    .line 230
    .line 231
    move-result-object v4

    .line 232
    invoke-static {v3, v4}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 233
    .line 234
    .line 235
    move-result v3

    .line 236
    iput v3, v2, LG7/g;->t:I

    .line 237
    .line 238
    sget-object v3, LG7/q;->a:LG7/q;

    .line 239
    .line 240
    invoke-virtual {v2, v3}, LG7/g;->f(LG7/q;)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    .line 244
    .line 245
    .line 246
    move-result-object v3

    .line 247
    iput-object v3, v2, LG7/g;->O:Landroidx/lifecycle/LifecycleOwner;

    .line 248
    .line 249
    invoke-virtual {v2}, LG7/g;->a()Lcom/skydoves/balloon/Balloon;

    .line 250
    .line 251
    .line 252
    move-result-object v2

    .line 253
    invoke-static {p2, v2}, La/a;->B(Landroid/view/View;Lcom/skydoves/balloon/Balloon;)V

    .line 254
    .line 255
    .line 256
    sget p2, LAc/e;->itv_setting_default:I

    .line 257
    .line 258
    invoke-virtual {p3, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 259
    .line 260
    .line 261
    move-result-object p2

    .line 262
    check-cast p2, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 263
    .line 264
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->isDefaultPaymentCard()Z

    .line 265
    .line 266
    .line 267
    move-result v3

    .line 268
    if-eqz v3, :cond_3

    .line 269
    .line 270
    invoke-static {p2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 271
    .line 272
    .line 273
    invoke-static {p2}, Loa/h;->c(Landroid/view/View;)V

    .line 274
    .line 275
    .line 276
    goto :goto_0

    .line 277
    :cond_3
    new-instance v3, LCe/d;

    .line 278
    .line 279
    invoke-direct {v3, v2, v1, p1, v0}, LCe/d;-><init>(Lcom/skydoves/balloon/Balloon;Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;I)V

    .line 280
    .line 281
    .line 282
    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 283
    .line 284
    .line 285
    :goto_0
    sget p2, LAc/e;->itv_delete:I

    .line 286
    .line 287
    invoke-virtual {p3, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 288
    .line 289
    .line 290
    move-result-object p2

    .line 291
    check-cast p2, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 292
    .line 293
    new-instance p3, LCe/d;

    .line 294
    .line 295
    const/4 v0, 0x1

    .line 296
    invoke-direct {p3, v2, v1, p1, v0}, LCe/d;-><init>(Lcom/skydoves/balloon/Balloon;Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;I)V

    .line 297
    .line 298
    .line 299
    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 300
    .line 301
    .line 302
    goto :goto_1

    .line 303
    :cond_4
    sget p2, LAc/e;->iv_copy:I

    .line 304
    .line 305
    if-ne v2, p2, :cond_6

    .line 306
    .line 307
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getCardNo()Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    move-result-object p1

    .line 311
    if-eqz p1, :cond_8

    .line 312
    .line 313
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 314
    .line 315
    .line 316
    move-result p2

    .line 317
    if-nez p2, :cond_5

    .line 318
    .line 319
    move-object v5, p1

    .line 320
    :cond_5
    if-eqz v5, :cond_8

    .line 321
    .line 322
    sget p1, Lcom/transsnet/palmpay/custom_view/v;->cv_copy_successful:I

    .line 323
    .line 324
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(I)V

    .line 325
    .line 326
    .line 327
    invoke-static {v5}, Lcom/transsnet/palmpay/util/ClipboardUtils;->copyText(Ljava/lang/CharSequence;)V

    .line 328
    .line 329
    .line 330
    goto :goto_1

    .line 331
    :cond_6
    sget p2, LAc/e;->iiv_show:I

    .line 332
    .line 333
    if-ne v2, p2, :cond_8

    .line 334
    .line 335
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->isShow()Z

    .line 336
    .line 337
    .line 338
    move-result p2

    .line 339
    if-eqz p2, :cond_7

    .line 340
    .line 341
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->setShow(Z)V

    .line 342
    .line 343
    .line 344
    invoke-virtual {v1}, Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;->u()Lve/d;

    .line 345
    .line 346
    .line 347
    move-result-object p1

    .line 348
    invoke-virtual {p1, p3}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemChanged(I)V

    .line 349
    .line 350
    .line 351
    goto :goto_1

    .line 352
    :cond_7
    iput p3, v1, Lcom/transsnet/palmpay/ui/fragment/BankCardFragment;->v:I

    .line 353
    .line 354
    iget-object p2, v1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 355
    .line 356
    check-cast p2, Lcom/transsnet/palmpay/viewmodule/BankCardAndAccountViewModel;

    .line 357
    .line 358
    if-eqz p2, :cond_8

    .line 359
    .line 360
    new-instance p3, Lcom/transsnet/palmpay/core/bean/req/ViewBankCardReq;

    .line 361
    .line 362
    invoke-direct {p3, v5, v5, v4, v5}, Lcom/transsnet/palmpay/core/bean/req/ViewBankCardReq;-><init>(Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 363
    .line 364
    .line 365
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getAccountId()Ljava/lang/String;

    .line 366
    .line 367
    .line 368
    move-result-object v0

    .line 369
    iput-object v0, p3, Lcom/transsnet/palmpay/core/bean/req/ViewBankCardReq;->accountId:Ljava/lang/String;

    .line 370
    .line 371
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LinkBankCardResp$LinkBankCard;->getOrderId()Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object p1

    .line 375
    iput-object p1, p3, Lcom/transsnet/palmpay/core/bean/req/ViewBankCardReq;->orderId:Ljava/lang/String;

    .line 376
    .line 377
    new-instance p1, LPe/j;

    .line 378
    .line 379
    invoke-direct {p1, p3, v5}, LPe/j;-><init>(Lcom/transsnet/palmpay/core/bean/req/ViewBankCardReq;Lkotlin/coroutines/Continuation;)V

    .line 380
    .line 381
    .line 382
    const-wide/16 v0, 0x0

    .line 383
    .line 384
    iget-object p3, p2, Lcom/transsnet/palmpay/viewmodule/BankCardAndAccountViewModel;->i:Lcom/transsnet/palmpay/core/base/l;

    .line 385
    .line 386
    invoke-static {p2, p1, p3, v0, v1}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 387
    .line 388
    .line 389
    :cond_8
    :goto_1
    return-void

    .line 390
    :pswitch_0
    check-cast v1, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneRewardsDialog;

    .line 391
    .line 392
    invoke-static {v1, p1, p2, p3}, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneRewardsDialog;->b(Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneRewardsDialog;LM1/j;Landroid/view/View;I)V

    .line 393
    .line 394
    .line 395
    return-void

    .line 396
    :pswitch_1
    check-cast v1, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;

    .line 397
    .line 398
    invoke-static {v1, p1, p2, p3}, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;->c(Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;LM1/j;Landroid/view/View;I)V

    .line 399
    .line 400
    .line 401
    return-void

    .line 402
    nop

    .line 403
    :pswitch_data_0
    .packed-switch 0xf
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 1

    .line 1
    iget v0, p0, LA8/a;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;

    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;->c(Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;LM1/j;Landroid/view/View;I)V

    return-void

    :pswitch_0
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/dialog/MonthDayPickerDialog;

    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/send_money/ui/dialog/MonthDayPickerDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/MonthDayPickerDialog;LM1/j;Landroid/view/View;I)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x9
        :pswitch_0
    .end packed-switch
.end method

.method public onItemSelected(ILjava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;

    check-cast p2, LJd/a;

    invoke-static {v0, p1, p2}, Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;->d(Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;ILJd/a;)V

    return-void
.end method

.method public onRefresh()V
    .locals 13

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    const/4 v3, 0x0

    .line 5
    const/4 v4, 0x1

    .line 6
    iget-object v5, p0, LA8/a;->b:Ljava/lang/Object;

    .line 7
    .line 8
    iget v6, p0, LA8/a;->a:I

    .line 9
    .line 10
    packed-switch v6, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    sget-object v0, Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment;->t0:Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment$a;

    .line 14
    .line 15
    check-cast v5, Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment;

    .line 16
    .line 17
    iget-object v0, v5, Lcom/transsnet/palmpay/core/base/BaseLazyMvvmFragment;->p:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 18
    .line 19
    check-cast v0, Lcom/transsnet/palmpay/viewmodule/HomeSavingsViewModel;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    new-instance v1, LPe/z;

    .line 25
    .line 26
    invoke-direct {v1, v4, v3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 27
    .line 28
    .line 29
    const/16 v3, 0x1c

    .line 30
    .line 31
    iget-object v4, v0, Lcom/transsnet/palmpay/viewmodule/HomeSavingsViewModel;->t:Lcom/transsnet/palmpay/core/base/l;

    .line 32
    .line 33
    invoke-static {v0, v1, v4, v2, v3}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :pswitch_0
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    const-string v3, "me_page_pull_down_to_refresh"

    .line 42
    .line 43
    invoke-virtual {v2, v3}, LPa/n0;->l(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    sput-wide v0, LPa/D;->b:J

    .line 47
    .line 48
    check-cast v5, Lcom/transsnet/palmpay/ui/fragment/HomeMeFragment;

    .line 49
    .line 50
    iget-object v0, v5, Lcom/transsnet/palmpay/core/base/BaseMVPFragment;->i:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 51
    .line 52
    check-cast v0, LFe/I;

    .line 53
    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    invoke-virtual {v0}, LFe/I;->queryMenuList()V

    .line 57
    .line 58
    .line 59
    :cond_0
    iget-object v0, v5, Lcom/transsnet/palmpay/ui/fragment/HomeMeFragment;->t:LKe/i;

    .line 60
    .line 61
    if-eqz v0, :cond_1

    .line 62
    .line 63
    invoke-virtual {v0, v4}, LKe/i;->a(Z)V

    .line 64
    .line 65
    .line 66
    :cond_1
    invoke-virtual {v5}, Landroidx/fragment/app/Fragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    check-cast v0, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;

    .line 71
    .line 72
    if-eqz v0, :cond_2

    .line 73
    .line 74
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;->G(Z)Ljava/lang/Boolean;

    .line 75
    .line 76
    .line 77
    :cond_2
    invoke-virtual {v5}, Landroidx/fragment/app/Fragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    check-cast v0, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;

    .line 82
    .line 83
    if-eqz v0, :cond_3

    .line 84
    .line 85
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseMVPFragment;->i:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 86
    .line 87
    check-cast v0, LFe/I;

    .line 88
    .line 89
    if-eqz v0, :cond_3

    .line 90
    .line 91
    invoke-virtual {v0}, LFe/I;->queryLastTransactionHistory()V

    .line 92
    .line 93
    .line 94
    :cond_3
    iget-object v0, v5, Lcom/transsnet/palmpay/core/base/BaseMVPFragment;->i:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 95
    .line 96
    check-cast v0, LFe/I;

    .line 97
    .line 98
    if-eqz v0, :cond_4

    .line 99
    .line 100
    invoke-virtual {v0}, LFe/I;->queryMeTabTotalAssetInfo()V

    .line 101
    .line 102
    .line 103
    :cond_4
    iget-object v0, v5, Lcom/transsnet/palmpay/ui/fragment/HomeMeFragment;->X:Lcom/transsnet/adsdk/widgets/MarqueeTextView/MarqueeViewV2;

    .line 104
    .line 105
    if-eqz v0, :cond_5

    .line 106
    .line 107
    invoke-virtual {v0}, Lcom/transsnet/adsdk/widgets/MarqueeTextView/MarqueeViewV2;->loadAdData()V

    .line 108
    .line 109
    .line 110
    :cond_5
    return-void

    .line 111
    :pswitch_1
    check-cast v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;

    .line 112
    .line 113
    iget-wide v6, v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->j:J

    .line 114
    .line 115
    cmp-long v6, v6, v0

    .line 116
    .line 117
    const-wide/16 v7, 0x7d0

    .line 118
    .line 119
    if-lez v6, :cond_6

    .line 120
    .line 121
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 122
    .line 123
    .line 124
    move-result-wide v9

    .line 125
    iget-wide v11, v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->j:J

    .line 126
    .line 127
    sub-long/2addr v9, v11

    .line 128
    goto :goto_0

    .line 129
    :cond_6
    move-wide v9, v7

    .line 130
    :goto_0
    cmp-long v6, v9, v7

    .line 131
    .line 132
    if-gez v6, :cond_7

    .line 133
    .line 134
    move v6, v4

    .line 135
    goto :goto_1

    .line 136
    :cond_7
    move v6, v2

    .line 137
    :goto_1
    iget-object v7, v5, Lcom/transsnet/palmpay/core/base/BaseMVPFragment;->i:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 138
    .line 139
    check-cast v7, LFe/I;

    .line 140
    .line 141
    if-eqz v7, :cond_8

    .line 142
    .line 143
    invoke-virtual {v7, v4, v6}, LFe/I;->c(ZZ)V

    .line 144
    .line 145
    .line 146
    :cond_8
    iget-object v6, v5, Lcom/transsnet/palmpay/core/base/BaseMVPFragment;->i:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 147
    .line 148
    check-cast v6, LFe/I;

    .line 149
    .line 150
    if-eqz v6, :cond_9

    .line 151
    .line 152
    invoke-virtual {v6}, LFe/I;->queryHomeBusinessInfo()V

    .line 153
    .line 154
    .line 155
    :cond_9
    sput-wide v0, LPa/D;->b:J

    .line 156
    .line 157
    invoke-virtual {v5}, Landroidx/fragment/app/Fragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    check-cast v0, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;

    .line 162
    .line 163
    if-eqz v0, :cond_a

    .line 164
    .line 165
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;->G(Z)Ljava/lang/Boolean;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    goto :goto_2

    .line 170
    :cond_a
    move-object v0, v3

    .line 171
    :goto_2
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 172
    .line 173
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v0

    .line 177
    if-eqz v0, :cond_b

    .line 178
    .line 179
    iget-object v0, v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->v0:LIe/h;

    .line 180
    .line 181
    if-eqz v0, :cond_b

    .line 182
    .line 183
    invoke-virtual {v0, v4}, LIe/h;->c(Z)V

    .line 184
    .line 185
    .line 186
    :cond_b
    iget-object v0, v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->Q:Lcom/transsnet/adsdk/widgets/MarqueeTextView/MarqueeViewV2;

    .line 187
    .line 188
    if-eqz v0, :cond_c

    .line 189
    .line 190
    invoke-virtual {v0}, Lcom/transsnet/adsdk/widgets/MarqueeTextView/MarqueeViewV2;->loadAdData()V

    .line 191
    .line 192
    .line 193
    :cond_c
    iget-object v0, v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->L:Lcom/transsnet/adsdk/widgets/banner/BannerAdView;

    .line 194
    .line 195
    if-eqz v0, :cond_d

    .line 196
    .line 197
    invoke-static {v0, v2, v4, v3}, Lcom/transsnet/adsdk/widgets/banner/BannerAdView;->refreshData$default(Lcom/transsnet/adsdk/widgets/banner/BannerAdView;ZILjava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    :cond_d
    iget-object v0, v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->B:Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 201
    .line 202
    if-eqz v0, :cond_e

    .line 203
    .line 204
    invoke-virtual {v0}, Lcom/transsnet/adsdk/widgets/SingleAdView;->refreshData()V

    .line 205
    .line 206
    .line 207
    :cond_e
    iget-object v0, v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->M:Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 208
    .line 209
    if-eqz v0, :cond_f

    .line 210
    .line 211
    invoke-virtual {v0}, Lcom/transsnet/adsdk/widgets/SingleAdView;->refreshData()V

    .line 212
    .line 213
    .line 214
    :cond_f
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 215
    .line 216
    .line 217
    move-result-wide v0

    .line 218
    iput-wide v0, v5, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->j:J

    .line 219
    .line 220
    return-void

    .line 221
    :pswitch_data_0
    .packed-switch 0x16
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LA8/a;->a:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LC6/q;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, LC6/q;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :sswitch_0
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, LD6/a;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, LD6/a;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :sswitch_1
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, LC6/q;

    .line 25
    .line 26
    invoke-virtual {v0, p1}, LC6/q;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :sswitch_2
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v0, LAd/e;

    .line 33
    .line 34
    invoke-virtual {v0, p1}, LAd/e;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    nop

    .line 39
    :sswitch_data_0
    .sparse-switch
        0xb -> :sswitch_2
        0x11 -> :sswitch_1
        0x1a -> :sswitch_0
    .end sparse-switch
.end method

.method public run()V
    .locals 1

    .line 1
    sget-object v0, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment;->q0:Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment$a;

    .line 2
    .line 3
    iget-object v0, p0, LA8/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment;

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentUpGradeSuccFragment;->t()V

    .line 8
    .line 9
    .line 10
    return-void
.end method
