.class public final LLa/l;
.super LLa/r;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IPresenter;


# virtual methods
.method public final bindBankCard(Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;)V
    .locals 9

    .line 1
    const-string v0, "req"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 7
    .line 8
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 14
    .line 15
    .line 16
    :cond_0
    iget-object v3, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 17
    .line 18
    new-instance v4, LAe/j;

    .line 19
    .line 20
    const/16 v0, 0x19

    .line 21
    .line 22
    invoke-direct {v4, p1, v0}, LAe/j;-><init>(Ljava/lang/Object;I)V

    .line 23
    .line 24
    .line 25
    new-instance v5, LLa/j;

    .line 26
    .line 27
    const/4 p1, 0x4

    .line 28
    invoke-direct {v5, p0, p1}, LLa/j;-><init>(LLa/l;I)V

    .line 29
    .line 30
    .line 31
    new-instance v6, LLa/j;

    .line 32
    .line 33
    const/4 p1, 0x5

    .line 34
    invoke-direct {v6, p0, p1}, LLa/j;-><init>(LLa/l;I)V

    .line 35
    .line 36
    .line 37
    const/4 v7, 0x0

    .line 38
    const/4 v8, 0x0

    .line 39
    move-object v2, p0

    .line 40
    invoke-static/range {v2 .. v8}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public final checkCardBindNum(Lcom/transsnet/palmpay/core/bean/req/CheckCardBindNumReq;)V
    .locals 8

    .line 1
    const-string v0, "req"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v2, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 7
    .line 8
    new-instance v3, LAe/j;

    .line 9
    .line 10
    const/16 v0, 0x18

    .line 11
    .line 12
    invoke-direct {v3, p1, v0}, LAe/j;-><init>(Ljava/lang/Object;I)V

    .line 13
    .line 14
    .line 15
    new-instance v4, LLa/j;

    .line 16
    .line 17
    const/4 p1, 0x2

    .line 18
    invoke-direct {v4, p0, p1}, LLa/j;-><init>(LLa/l;I)V

    .line 19
    .line 20
    .line 21
    new-instance v5, LFe/h0;

    .line 22
    .line 23
    const/4 p1, 0x5

    .line 24
    invoke-direct {v5, p1}, LFe/h0;-><init>(I)V

    .line 25
    .line 26
    .line 27
    const/4 v6, 0x0

    .line 28
    const/4 v7, 0x1

    .line 29
    move-object v1, p0

    .line 30
    invoke-static/range {v1 .. v7}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final checkInputBankCardInfo(Lcom/transsnet/palmpay/core/bean/req/CheckBankCardInfoReq;)V
    .locals 8

    .line 1
    const-string v0, "req"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v2, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 7
    .line 8
    new-instance v3, LAe/j;

    .line 9
    .line 10
    const/16 v0, 0x1a

    .line 11
    .line 12
    invoke-direct {v3, p1, v0}, LAe/j;-><init>(Ljava/lang/Object;I)V

    .line 13
    .line 14
    .line 15
    new-instance v4, LAd/e;

    .line 16
    .line 17
    const/16 v0, 0xa

    .line 18
    .line 19
    invoke-direct {v4, v0, p0, p1}, LAd/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    new-instance v5, LFe/h0;

    .line 23
    .line 24
    const/4 p1, 0x2

    .line 25
    invoke-direct {v5, p1}, LFe/h0;-><init>(I)V

    .line 26
    .line 27
    .line 28
    const/4 v6, 0x0

    .line 29
    const/4 v7, 0x1

    .line 30
    move-object v1, p0

    .line 31
    invoke-static/range {v1 .. v7}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final getBankInfoByCardNo(Ljava/lang/String;)V
    .locals 7

    .line 1
    iget-object v1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    new-instance v2, LFe/g;

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    invoke-direct {v2, p1, v0}, LFe/g;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    new-instance v3, LLa/j;

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    invoke-direct {v3, p0, p1}, LLa/j;-><init>(LLa/l;I)V

    .line 13
    .line 14
    .line 15
    new-instance v4, LFe/h0;

    .line 16
    .line 17
    const/4 p1, 0x4

    .line 18
    invoke-direct {v4, p1}, LFe/h0;-><init>(I)V

    .line 19
    .line 20
    .line 21
    const/4 v5, 0x1

    .line 22
    const/4 v6, 0x0

    .line 23
    move-object v0, p0

    .line 24
    invoke-static/range {v0 .. v6}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final getBindBankCardTips()V
    .locals 7

    .line 1
    iget-object v1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    new-instance v2, LLa/i;

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    invoke-direct {v2, v0}, LLa/i;-><init>(I)V

    .line 7
    .line 8
    .line 9
    new-instance v3, LLa/j;

    .line 10
    .line 11
    const/4 v0, 0x6

    .line 12
    invoke-direct {v3, p0, v0}, LLa/j;-><init>(LLa/l;I)V

    .line 13
    .line 14
    .line 15
    new-instance v4, LFe/h0;

    .line 16
    .line 17
    const/4 v0, 0x7

    .line 18
    invoke-direct {v4, v0}, LFe/h0;-><init>(I)V

    .line 19
    .line 20
    .line 21
    const/4 v5, 0x0

    .line 22
    const/4 v6, 0x0

    .line 23
    move-object v0, p0

    .line 24
    invoke-static/range {v0 .. v6}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final getFundActivityConfig()V
    .locals 7

    .line 1
    iget-object v1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    new-instance v2, LLa/i;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-direct {v2, v0}, LLa/i;-><init>(I)V

    .line 7
    .line 8
    .line 9
    new-instance v3, LLa/j;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-direct {v3, p0, v0}, LLa/j;-><init>(LLa/l;I)V

    .line 13
    .line 14
    .line 15
    new-instance v4, LFe/h0;

    .line 16
    .line 17
    const/4 v0, 0x3

    .line 18
    invoke-direct {v4, v0}, LFe/h0;-><init>(I)V

    .line 19
    .line 20
    .line 21
    const/4 v5, 0x0

    .line 22
    const/4 v6, 0x0

    .line 23
    move-object v0, p0

    .line 24
    invoke-static/range {v0 .. v6}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final queryPaymentMethod()V
    .locals 7

    .line 1
    iget-object v1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    new-instance v2, LG9/j;

    .line 4
    .line 5
    const/16 v0, 0x1d

    .line 6
    .line 7
    invoke-direct {v2, v0}, LG9/j;-><init>(I)V

    .line 8
    .line 9
    .line 10
    new-instance v3, LLa/j;

    .line 11
    .line 12
    const/4 v0, 0x3

    .line 13
    invoke-direct {v3, p0, v0}, LLa/j;-><init>(LLa/l;I)V

    .line 14
    .line 15
    .line 16
    new-instance v4, LFe/h0;

    .line 17
    .line 18
    const/4 v0, 0x6

    .line 19
    invoke-direct {v4, v0}, LFe/h0;-><init>(I)V

    .line 20
    .line 21
    .line 22
    const/4 v5, 0x1

    .line 23
    const/4 v6, 0x0

    .line 24
    move-object v0, p0

    .line 25
    invoke-static/range {v0 .. v6}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 26
    .line 27
    .line 28
    return-void
.end method
