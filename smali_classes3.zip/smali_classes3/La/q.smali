.class public final LLa/q;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic i:J

.field public final synthetic j:LLa/r;


# direct methods
.method public constructor <init>(LLa/r;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLa/q;->j:LLa/r;

    .line 5
    .line 6
    iput-object p2, p0, LLa/q;->f:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, LLa/q;->g:Ljava/lang/String;

    .line 9
    .line 10
    iput-wide p4, p0, LLa/q;->i:J

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, LLa/q;->j:LLa/r;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 7

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/USSDFundResp;

    .line 2
    .line 3
    if-eqz p1, :cond_2

    .line 4
    .line 5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/rsp/USSDFundResp;->data:Lcom/transsnet/palmpay/core/bean/rsp/USSDFundResp$USSDDataBean;

    .line 12
    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    const-string v0, "01"

    .line 16
    .line 17
    iget-object v1, p0, LLa/q;->f:Ljava/lang/String;

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    iget-object v2, p0, LLa/q;->g:Ljava/lang/String;

    .line 24
    .line 25
    const-string v3, "orderId"

    .line 26
    .line 27
    const-string v4, "extra_type"

    .line 28
    .line 29
    const-string v5, "extra_data"

    .line 30
    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    const-string v6, "/cashin/ussd_result"

    .line 38
    .line 39
    invoke-virtual {v0, v6}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/USSDFundResp;->data:Lcom/transsnet/palmpay/core/bean/rsp/USSDFundResp$USSDDataBean;

    .line 48
    .line 49
    iget-object v6, v6, LPa/w;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v6, Lcom/google/gson/Gson;

    .line 52
    .line 53
    invoke-virtual {v6, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-virtual {v0, v5, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    invoke-virtual {p1, v4, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-virtual {p1, v3, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    const-string v0, "extra_amount"

    .line 70
    .line 71
    iget-wide v2, p0, LLa/q;->i:J

    .line 72
    .line 73
    invoke-virtual {p1, v0, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_0
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    const-string v6, "/core/ussd_pay_result"

    .line 86
    .line 87
    invoke-virtual {v0, v6}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 92
    .line 93
    .line 94
    move-result-object v6

    .line 95
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/USSDFundResp;->data:Lcom/transsnet/palmpay/core/bean/rsp/USSDFundResp$USSDDataBean;

    .line 96
    .line 97
    iget-object v6, v6, LPa/w;->b:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v6, Lcom/google/gson/Gson;

    .line 100
    .line 101
    invoke-virtual {v6, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    invoke-virtual {v0, v5, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    invoke-virtual {p1, v4, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-virtual {p1, v3, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    :goto_0
    const-string p1, "04"

    .line 121
    .line 122
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result p1

    .line 126
    if-eqz p1, :cond_1

    .line 127
    .line 128
    invoke-static {}, LPa/r0;->A1()V

    .line 129
    .line 130
    .line 131
    :cond_1
    iget-object p1, p0, LLa/q;->j:LLa/r;

    .line 132
    .line 133
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 134
    .line 135
    instance-of v0, p1, Landroid/app/Activity;

    .line 136
    .line 137
    if-eqz v0, :cond_2

    .line 138
    .line 139
    check-cast p1, Landroid/app/Activity;

    .line 140
    .line 141
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 142
    .line 143
    .line 144
    :cond_2
    return-void
.end method
