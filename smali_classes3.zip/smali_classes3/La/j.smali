.class public final synthetic LLa/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LLa/l;


# direct methods
.method public synthetic constructor <init>(LLa/l;I)V
    .locals 0

    .line 1
    iput p2, p0, LLa/j;->a:I

    iput-object p1, p0, LLa/j;->b:LLa/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LLa/j;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, LLa/j;->b:LLa/l;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 16
    .line 17
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->getBindBankCardTips(Lcom/transsnet/palmpay/core/bean/CommonBeanResult;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 25
    .line 26
    return-object p1

    .line 27
    :pswitch_0
    check-cast p1, Ljava/lang/String;

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    new-array v1, v0, [Ljava/lang/Object;

    .line 31
    .line 32
    invoke-static {p1, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iget-object p1, p0, LLa/j;->b:LLa/l;

    .line 36
    .line 37
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 38
    .line 39
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 40
    .line 41
    if-eqz p1, :cond_1

    .line 42
    .line 43
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 44
    .line 45
    .line 46
    :cond_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 47
    .line 48
    return-object p1

    .line 49
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;

    .line 50
    .line 51
    const-string v0, "it"

    .line 52
    .line 53
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    iget-object v0, p0, LLa/j;->b:LLa/l;

    .line 57
    .line 58
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 59
    .line 60
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 61
    .line 62
    if-eqz v1, :cond_2

    .line 63
    .line 64
    invoke-interface {v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handleCheckCardBindNum(Lcom/transsnet/palmpay/core/bean/CommonResult;)V

    .line 65
    .line 66
    .line 67
    :cond_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    if-eqz v1, :cond_3

    .line 72
    .line 73
    iget-object v1, p1, Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;->token:Ljava/lang/String;

    .line 74
    .line 75
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    if-eqz v1, :cond_3

    .line 80
    .line 81
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUserDataSource()Lka/a;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    invoke-virtual {v1}, Lka/a;->a()Lio/reactivex/internal/operators/observable/K;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 94
    .line 95
    invoke-virtual {v1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    invoke-virtual {v1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    new-instance v2, LLa/k;

    .line 108
    .line 109
    invoke-direct {v2, v0, p1}, LLa/k;-><init>(LLa/l;Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v1, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 113
    .line 114
    .line 115
    goto :goto_0

    .line 116
    :cond_3
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 117
    .line 118
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 119
    .line 120
    if-eqz v1, :cond_4

    .line 121
    .line 122
    const/4 v2, 0x0

    .line 123
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 124
    .line 125
    .line 126
    :cond_4
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 127
    .line 128
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 129
    .line 130
    if-eqz v0, :cond_5

    .line 131
    .line 132
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handleBindResult(Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;)V

    .line 133
    .line 134
    .line 135
    :cond_5
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 136
    .line 137
    return-object p1

    .line 138
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;

    .line 139
    .line 140
    const-string v0, "it"

    .line 141
    .line 142
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    iget-object v0, p0, LLa/j;->b:LLa/l;

    .line 146
    .line 147
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 148
    .line 149
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 150
    .line 151
    if-eqz v0, :cond_6

    .line 152
    .line 153
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;->data:Ljava/util/List;

    .line 154
    .line 155
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handlePaymentMethods(Ljava/util/List;)V

    .line 156
    .line 157
    .line 158
    :cond_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 159
    .line 160
    return-object p1

    .line 161
    :pswitch_3
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 162
    .line 163
    const-string v0, "it"

    .line 164
    .line 165
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    iget-object v0, p0, LLa/j;->b:LLa/l;

    .line 169
    .line 170
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 171
    .line 172
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 173
    .line 174
    if-eqz v0, :cond_7

    .line 175
    .line 176
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handleCheckCardBindNum(Lcom/transsnet/palmpay/core/bean/CommonResult;)V

    .line 177
    .line 178
    .line 179
    :cond_7
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 180
    .line 181
    return-object p1

    .line 182
    :pswitch_4
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/CardNoBankInfoRsp;

    .line 183
    .line 184
    const-string v0, "it"

    .line 185
    .line 186
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    iget-object v0, p0, LLa/j;->b:LLa/l;

    .line 190
    .line 191
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 192
    .line 193
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 194
    .line 195
    if-eqz v0, :cond_8

    .line 196
    .line 197
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handleGetBankInfoByCardNoRsp(Lcom/transsnet/palmpay/core/bean/rsp/CardNoBankInfoRsp;)V

    .line 198
    .line 199
    .line 200
    :cond_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 201
    .line 202
    return-object p1

    .line 203
    :pswitch_5
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 204
    .line 205
    const-string v0, "it"

    .line 206
    .line 207
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    iget-object v0, p0, LLa/j;->b:LLa/l;

    .line 211
    .line 212
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 213
    .line 214
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 215
    .line 216
    if-eqz v0, :cond_9

    .line 217
    .line 218
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handleFundActivityConfig(Lcom/transsnet/palmpay/core/bean/CommonBeanResult;)V

    .line 219
    .line 220
    .line 221
    :cond_9
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 222
    .line 223
    return-object p1

    .line 224
    nop

    .line 225
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
