.class public final synthetic LLa/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LLa/i;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LLa/i;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/util/HashMap;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 9
    .line 10
    .line 11
    return-object v0

    .line 12
    :pswitch_0
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/WithdrawSureDialogFragment;->X:Lcom/transsnet/palmpay/managemoney/ui/dialog/WithdrawSureDialogFragment$a;

    .line 13
    .line 14
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 15
    .line 16
    return-object v0

    .line 17
    :pswitch_1
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/WithdrawSureDialogFragment;->X:Lcom/transsnet/palmpay/managemoney/ui/dialog/WithdrawSureDialogFragment$a;

    .line 18
    .line 19
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 20
    .line 21
    return-object v0

    .line 22
    :pswitch_2
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/WhyTurnOffSaveDialogFragment;->Z:Lcom/transsnet/palmpay/managemoney/ui/dialog/WhyTurnOffSaveDialogFragment$a;

    .line 23
    .line 24
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 25
    .line 26
    return-object v0

    .line 27
    :pswitch_3
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/TurnOnAutoSaveDialogFragment;->L:Lcom/transsnet/palmpay/managemoney/ui/dialog/TurnOnAutoSaveDialogFragment$a;

    .line 28
    .line 29
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 30
    .line 31
    return-object v0

    .line 32
    :pswitch_4
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/TurnOnAutoSaveDialogFragment;->L:Lcom/transsnet/palmpay/managemoney/ui/dialog/TurnOnAutoSaveDialogFragment$a;

    .line 33
    .line 34
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 35
    .line 36
    return-object v0

    .line 37
    :pswitch_5
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/CongratulationsDialogFragment;->L:Lcom/transsnet/palmpay/managemoney/ui/dialog/CongratulationsDialogFragment$a;

    .line 38
    .line 39
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 40
    .line 41
    return-object v0

    .line 42
    :pswitch_6
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/CongratulationsDialogFragment;->L:Lcom/transsnet/palmpay/managemoney/ui/dialog/CongratulationsDialogFragment$a;

    .line 43
    .line 44
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 45
    .line 46
    return-object v0

    .line 47
    :pswitch_7
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxTermsConditionsWithEventDialogFragment;->H:Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxTermsConditionsWithEventDialogFragment$a;

    .line 48
    .line 49
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_8
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 53
    .line 54
    return-object v0

    .line 55
    :pswitch_9
    sget v0, Lcom/transsnet/palmpay/core/ui/widget/ModelPaymentManualGetLayout;->g:I

    .line 56
    .line 57
    new-instance v0, LOa/k;

    .line 58
    .line 59
    sget v1, Lba/g;->core_layout_payment_manual_get_reward_item:I

    .line 60
    .line 61
    const/4 v2, 0x0

    .line 62
    invoke-direct {v0, v1, v2}, LM1/j;-><init>(ILjava/util/List;)V

    .line 63
    .line 64
    .line 65
    return-object v0

    .line 66
    :pswitch_a
    sget v0, Lcom/transsnet/palmpay/core/ui/widget/ModelPaymentManualGetLayout;->g:I

    .line 67
    .line 68
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 69
    .line 70
    return-object v0

    .line 71
    :pswitch_b
    sget v0, Lcom/transsnet/palmpay/account/ui/activity/quota/Tier3QuotaManageActivity;->f:I

    .line 72
    .line 73
    new-instance v0, Lcom/transsnet/palmpay/account/ui/fragment/quota/Tier3QuotaManageFragment;

    .line 74
    .line 75
    invoke-direct {v0}, Lcom/transsnet/palmpay/account/ui/fragment/quota/Tier3QuotaManageFragment;-><init>()V

    .line 76
    .line 77
    .line 78
    return-object v0

    .line 79
    :pswitch_c
    sget-object v0, Lcom/transsnet/palmpay/account/ui/activity/SignUpActivity;->C:Lcom/transsnet/palmpay/account/ui/activity/SignUpActivity$a;

    .line 80
    .line 81
    new-instance v0, Landroid/os/Handler;

    .line 82
    .line 83
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 88
    .line 89
    .line 90
    return-object v0

    .line 91
    :pswitch_d
    sget v0, Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;->g:I

    .line 92
    .line 93
    new-instance v0, Landroid/os/Handler;

    .line 94
    .line 95
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 100
    .line 101
    .line 102
    return-object v0

    .line 103
    :pswitch_e
    sget v0, Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;->g:I

    .line 104
    .line 105
    new-instance v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;

    .line 106
    .line 107
    invoke-direct {v0}, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyFingerPrintFragment;-><init>()V

    .line 108
    .line 109
    .line 110
    return-object v0

    .line 111
    :pswitch_f
    sget v0, Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;->g:I

    .line 112
    .line 113
    new-instance v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyPatternFragment;

    .line 114
    .line 115
    invoke-direct {v0}, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifyPatternFragment;-><init>()V

    .line 116
    .line 117
    .line 118
    return-object v0

    .line 119
    :pswitch_10
    sget v0, Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;->g:I

    .line 120
    .line 121
    new-instance v0, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifySafePinFragment;

    .line 122
    .line 123
    invoke-direct {v0}, Lcom/transsnet/palmpay/account/ui/fragment/auth/VerifySafePinFragment;-><init>()V

    .line 124
    .line 125
    .line 126
    return-object v0

    .line 127
    :pswitch_11
    sget-object v0, Lcom/transsnet/palmpay/account/ui/activity/PalmPayLevelV2Activity;->p:Lcom/transsnet/palmpay/account/ui/activity/PalmPayLevelV2Activity$a;

    .line 128
    .line 129
    new-instance v0, Landroid/os/Handler;

    .line 130
    .line 131
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 136
    .line 137
    .line 138
    return-object v0

    .line 139
    :pswitch_12
    sget v0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->p0:I

    .line 140
    .line 141
    new-instance v0, Landroid/os/Handler;

    .line 142
    .line 143
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 148
    .line 149
    .line 150
    return-object v0

    .line 151
    :pswitch_13
    new-instance v0, Ljava/util/ArrayList;

    .line 152
    .line 153
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 154
    .line 155
    .line 156
    return-object v0

    .line 157
    :pswitch_14
    new-instance v0, Landroid/os/Handler;

    .line 158
    .line 159
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 160
    .line 161
    .line 162
    move-result-object v1

    .line 163
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 164
    .line 165
    .line 166
    return-object v0

    .line 167
    :pswitch_15
    new-instance v0, Ljava/util/ArrayList;

    .line 168
    .line 169
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 170
    .line 171
    .line 172
    return-object v0

    .line 173
    :pswitch_16
    const/16 v0, 0x10

    .line 174
    .line 175
    invoke-static {v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    return-object v0

    .line 184
    :pswitch_17
    sget v0, LM3/g;->g:I

    .line 185
    .line 186
    const-wide/16 v0, 0x0

    .line 187
    .line 188
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    return-object v0

    .line 193
    :pswitch_18
    new-instance v0, LLb/c;

    .line 194
    .line 195
    const/4 v1, 0x0

    .line 196
    invoke-direct {v0, v1}, LLb/c;-><init>(I)V

    .line 197
    .line 198
    .line 199
    const-string/jumbo v1, "\u200bcom.transsnet.palmpay.custom_view.async.PpAsyncInflateQueue"

    .line 200
    .line 201
    .line 202
    invoke-static {v0, v1}, Lcom/didiglobal/booster/instrument/ShadowExecutors;->newOptimizedSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;Ljava/lang/String;)Ljava/util/concurrent/ExecutorService;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    return-object v0

    .line 207
    :pswitch_19
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 208
    .line 209
    iget-object v0, v0, Landroidx/camera/video/internal/c;->d:Ljava/lang/Object;

    .line 210
    .line 211
    check-cast v0, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 212
    .line 213
    invoke-interface {v0}, Lcom/transsnet/palmpay/core/network/api/AccountApiService;->queryPaymentMethod()Ldf/d;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    return-object v0

    .line 218
    :pswitch_1a
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 219
    .line 220
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 221
    .line 222
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 223
    .line 224
    invoke-interface {v0}, Lcom/transsnet/palmpay/core/network/PayApiService;->getOkCardPreCreditInfo()Ldf/d;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    return-object v0

    .line 229
    :pswitch_1b
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 230
    .line 231
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 232
    .line 233
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 234
    .line 235
    invoke-interface {v0}, Lcom/transsnet/palmpay/core/network/PayApiService;->getBindBankCardTips()Ldf/d;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    return-object v0

    .line 240
    :pswitch_1c
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 241
    .line 242
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 243
    .line 244
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 245
    .line 246
    invoke-interface {v0}, Lcom/transsnet/palmpay/core/network/PayApiService;->getFundActivityConfig()Ldf/d;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    return-object v0

    .line 251
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
