.class public final LLa/a;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:LLa/h;


# direct methods
.method public constructor <init>(LLa/h;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLa/a;->f:LLa/h;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, LLa/a;->f:LLa/h;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, LLa/a;->f:LLa/h;

    .line 2
    .line 3
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 11
    .line 12
    .line 13
    :cond_0
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    iget-object v0, p0, LLa/a;->f:LLa/h;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 13
    .line 14
    .line 15
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 16
    .line 17
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;

    .line 18
    .line 19
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;->handleCheckCardBindNum(Lcom/transsnet/palmpay/core/bean/CommonResult;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method
