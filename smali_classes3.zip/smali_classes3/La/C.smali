.class public final synthetic LLa/C;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LLa/F;


# direct methods
.method public synthetic constructor <init>(LLa/F;I)V
    .locals 0

    .line 1
    iput p2, p0, LLa/C;->a:I

    iput-object p1, p0, LLa/C;->b:LLa/F;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LLa/C;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/lang/String;

    .line 7
    .line 8
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 9
    .line 10
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 11
    .line 12
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 18
    .line 19
    .line 20
    :cond_0
    new-array v0, v1, [Ljava/lang/Object;

    .line 21
    .line 22
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 26
    .line 27
    return-object p1

    .line 28
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV3Resp;

    .line 29
    .line 30
    const-string v0, "it"

    .line 31
    .line 32
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 36
    .line 37
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 38
    .line 39
    if-eqz v1, :cond_6

    .line 40
    .line 41
    new-instance v1, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;

    .line 42
    .line 43
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;-><init>()V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->setRespCode(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->setRespMsg(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    const/4 v3, 0x0

    .line 65
    if-eqz v2, :cond_2

    .line 66
    .line 67
    iget-object v2, p1, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV3Resp;->data:Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV3Resp$DataBean;

    .line 68
    .line 69
    if-eqz v2, :cond_1

    .line 70
    .line 71
    iget-object v2, v2, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV3Resp$DataBean;->payAble:Ljava/util/List;

    .line 72
    .line 73
    goto :goto_0

    .line 74
    :cond_1
    move-object v2, v3

    .line 75
    :goto_0
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;->data:Ljava/util/List;

    .line 76
    .line 77
    goto :goto_1

    .line 78
    :cond_2
    iget-object v2, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 79
    .line 80
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 81
    .line 82
    if-eqz v2, :cond_3

    .line 83
    .line 84
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v5

    .line 92
    invoke-interface {v2, v4, v5}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->payProcessUnexpectedStop(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    :cond_3
    :goto_1
    iget-object v2, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 96
    .line 97
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 98
    .line 99
    if-eqz v2, :cond_4

    .line 100
    .line 101
    invoke-interface {v2, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->showPaymentMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;)V

    .line 102
    .line 103
    .line 104
    :cond_4
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 105
    .line 106
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 107
    .line 108
    if-eqz v0, :cond_6

    .line 109
    .line 110
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV3Resp;->data:Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV3Resp$DataBean;

    .line 111
    .line 112
    if-eqz p1, :cond_5

    .line 113
    .line 114
    iget-object v3, p1, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV3Resp$DataBean;->payUnable:Ljava/util/List;

    .line 115
    .line 116
    :cond_5
    invoke-interface {v0, v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->handlePaymentMethodActivityText(Ljava/util/List;)V

    .line 117
    .line 118
    .line 119
    :cond_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 120
    .line 121
    return-object p1

    .line 122
    :pswitch_1
    check-cast p1, Ljava/lang/String;

    .line 123
    .line 124
    iget-object p1, p0, LLa/C;->b:LLa/F;

    .line 125
    .line 126
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 127
    .line 128
    if-eqz p1, :cond_7

    .line 129
    .line 130
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 131
    .line 132
    const/4 v0, 0x0

    .line 133
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 134
    .line 135
    .line 136
    :cond_7
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 137
    .line 138
    return-object p1

    .line 139
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 140
    .line 141
    const-string v0, "it"

    .line 142
    .line 143
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    iget-object v1, p0, LLa/C;->b:LLa/F;

    .line 151
    .line 152
    const/4 v2, 0x0

    .line 153
    if-eqz v0, :cond_13

    .line 154
    .line 155
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 156
    .line 157
    if-eqz v0, :cond_13

    .line 158
    .line 159
    iget-object v3, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 160
    .line 161
    if-eqz v3, :cond_14

    .line 162
    .line 163
    check-cast v0, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;

    .line 164
    .line 165
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->paymentMethod:Lcom/transsnet/palmpay/core/bean/PaymentMethod;

    .line 166
    .line 167
    const/4 v4, 0x0

    .line 168
    if-nez v0, :cond_a

    .line 169
    .line 170
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 171
    .line 172
    invoke-interface {v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->checkShowOkCardPreCreditInfo()Z

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    const/4 v3, 0x1

    .line 177
    if-ne v0, v3, :cond_9

    .line 178
    .line 179
    iget-object v0, v1, LLa/F;->d:Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;

    .line 180
    .line 181
    if-nez v0, :cond_8

    .line 182
    .line 183
    invoke-virtual {v1, v3}, LLa/F;->queryOkCardPreCreditInfo(Z)V

    .line 184
    .line 185
    .line 186
    goto :goto_2

    .line 187
    :cond_8
    iget-boolean v0, v0, Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;->okCardPreCreditFlag:Z

    .line 188
    .line 189
    if-nez v0, :cond_b

    .line 190
    .line 191
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 192
    .line 193
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 194
    .line 195
    if-eqz v0, :cond_b

    .line 196
    .line 197
    invoke-interface {v0, v4}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setDefaultMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 198
    .line 199
    .line 200
    goto :goto_2

    .line 201
    :cond_9
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 202
    .line 203
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 204
    .line 205
    if-eqz v0, :cond_b

    .line 206
    .line 207
    invoke-interface {v0, v4}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setDefaultMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 208
    .line 209
    .line 210
    goto :goto_2

    .line 211
    :cond_a
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 212
    .line 213
    invoke-interface {v3, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setDefaultMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 214
    .line 215
    .line 216
    :cond_b
    :goto_2
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 217
    .line 218
    check-cast v0, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;

    .line 219
    .line 220
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->paymentMethod:Lcom/transsnet/palmpay/core/bean/PaymentMethod;

    .line 221
    .line 222
    invoke-virtual {v1, v0}, LLa/F;->e(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 223
    .line 224
    .line 225
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v0, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;

    .line 228
    .line 229
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->calculationDto:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 230
    .line 231
    if-eqz v0, :cond_e

    .line 232
    .line 233
    iget-object v3, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 234
    .line 235
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 236
    .line 237
    if-eqz v3, :cond_c

    .line 238
    .line 239
    iget-wide v5, v0, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->fee:J

    .line 240
    .line 241
    invoke-interface {v3, v5, v6}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setFeeAmount(J)V

    .line 242
    .line 243
    .line 244
    :cond_c
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 245
    .line 246
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 247
    .line 248
    if-eqz v0, :cond_d

    .line 249
    .line 250
    iget-object v3, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 251
    .line 252
    check-cast v3, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;

    .line 253
    .line 254
    iget-object v3, v3, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->calculationDto:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 255
    .line 256
    invoke-interface {v0, v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->handleCommonPreviewInfo(Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;)V

    .line 257
    .line 258
    .line 259
    :cond_d
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 260
    .line 261
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 262
    .line 263
    if-eqz v0, :cond_f

    .line 264
    .line 265
    iget-object v3, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 266
    .line 267
    check-cast v3, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;

    .line 268
    .line 269
    iget-object v5, v3, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->paymentMethod:Lcom/transsnet/palmpay/core/bean/PaymentMethod;

    .line 270
    .line 271
    iget-object v3, v3, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->calculationDto:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 272
    .line 273
    invoke-interface {v0, v5, v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->showPreviewPayInfo(Lcom/transsnet/palmpay/core/bean/PaymentMethod;Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;)V

    .line 274
    .line 275
    .line 276
    goto :goto_3

    .line 277
    :cond_e
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 278
    .line 279
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 280
    .line 281
    if-eqz v0, :cond_f

    .line 282
    .line 283
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object v3

    .line 287
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 288
    .line 289
    .line 290
    move-result-object v5

    .line 291
    invoke-interface {v0, v3, v5}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->payProcessUnexpectedStop(Ljava/lang/String;Ljava/lang/String;)V

    .line 292
    .line 293
    .line 294
    :cond_f
    :goto_3
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 295
    .line 296
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 297
    .line 298
    if-eqz v0, :cond_10

    .line 299
    .line 300
    invoke-interface {v0, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 301
    .line 302
    .line 303
    :cond_10
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 304
    .line 305
    check-cast v0, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;

    .line 306
    .line 307
    if-eqz v0, :cond_11

    .line 308
    .line 309
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->calculationDto:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 310
    .line 311
    if-eqz v0, :cond_11

    .line 312
    .line 313
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->riskMsg:Ljava/lang/String;

    .line 314
    .line 315
    goto :goto_4

    .line 316
    :cond_11
    move-object v0, v4

    .line 317
    :goto_4
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 318
    .line 319
    .line 320
    move-result v0

    .line 321
    if-nez v0, :cond_14

    .line 322
    .line 323
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 324
    .line 325
    check-cast p1, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;

    .line 326
    .line 327
    if-eqz p1, :cond_12

    .line 328
    .line 329
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->calculationDto:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 330
    .line 331
    if-eqz p1, :cond_12

    .line 332
    .line 333
    iget-object v4, p1, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->riskMsg:Ljava/lang/String;

    .line 334
    .line 335
    :cond_12
    new-array p1, v2, [Ljava/lang/Object;

    .line 336
    .line 337
    invoke-static {v4, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    goto :goto_5

    .line 341
    :cond_13
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 342
    .line 343
    if-eqz v0, :cond_14

    .line 344
    .line 345
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 346
    .line 347
    invoke-interface {v0, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 348
    .line 349
    .line 350
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 351
    .line 352
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 353
    .line 354
    if-eqz v0, :cond_14

    .line 355
    .line 356
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v1

    .line 360
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object p1

    .line 364
    invoke-interface {v0, v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->payProcessUnexpectedStop(Ljava/lang/String;Ljava/lang/String;)V

    .line 365
    .line 366
    .line 367
    :cond_14
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 368
    .line 369
    return-object p1

    .line 370
    :pswitch_3
    check-cast p1, Ljava/lang/String;

    .line 371
    .line 372
    iget-object p1, p0, LLa/C;->b:LLa/F;

    .line 373
    .line 374
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 375
    .line 376
    if-eqz p1, :cond_15

    .line 377
    .line 378
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 379
    .line 380
    const/4 v0, 0x0

    .line 381
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 382
    .line 383
    .line 384
    :cond_15
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 385
    .line 386
    return-object p1

    .line 387
    :pswitch_4
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;

    .line 388
    .line 389
    const-string v0, "it"

    .line 390
    .line 391
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 392
    .line 393
    .line 394
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 395
    .line 396
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 397
    .line 398
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 399
    .line 400
    if-eqz v0, :cond_16

    .line 401
    .line 402
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->queryLimitAmountOK(Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;)V

    .line 403
    .line 404
    .line 405
    :cond_16
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 406
    .line 407
    return-object p1

    .line 408
    :pswitch_5
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp;

    .line 409
    .line 410
    const-string v0, "resp"

    .line 411
    .line 412
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 413
    .line 414
    .line 415
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 416
    .line 417
    .line 418
    move-result v0

    .line 419
    iget-object v1, p0, LLa/C;->b:LLa/F;

    .line 420
    .line 421
    const/4 v2, 0x0

    .line 422
    if-eqz v0, :cond_25

    .line 423
    .line 424
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 425
    .line 426
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 427
    .line 428
    if-eqz v0, :cond_17

    .line 429
    .line 430
    invoke-interface {v0, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 431
    .line 432
    .line 433
    :cond_17
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp;->data:Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp$DataBean;

    .line 434
    .line 435
    if-eqz v0, :cond_27

    .line 436
    .line 437
    new-instance v3, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;

    .line 438
    .line 439
    invoke-direct {v3}, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;-><init>()V

    .line 440
    .line 441
    .line 442
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 443
    .line 444
    .line 445
    move-result-object v4

    .line 446
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/core/bean/CommonResult;->setRespCode(Ljava/lang/String;)V

    .line 447
    .line 448
    .line 449
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 450
    .line 451
    .line 452
    move-result-object v4

    .line 453
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/core/bean/CommonResult;->setRespMsg(Ljava/lang/String;)V

    .line 454
    .line 455
    .line 456
    iget-object v4, v0, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp$DataBean;->paymentMethodList:Ljava/util/List;

    .line 457
    .line 458
    iput-object v4, v3, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;->data:Ljava/util/List;

    .line 459
    .line 460
    iget-object v4, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 461
    .line 462
    check-cast v4, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 463
    .line 464
    if-eqz v4, :cond_18

    .line 465
    .line 466
    invoke-interface {v4, v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->showPaymentMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;)V

    .line 467
    .line 468
    .line 469
    :cond_18
    iget-object v3, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 470
    .line 471
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 472
    .line 473
    if-eqz v3, :cond_19

    .line 474
    .line 475
    iget-object v4, v0, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp$DataBean;->payUnable:Ljava/util/List;

    .line 476
    .line 477
    invoke-interface {v3, v4}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->handlePaymentMethodActivityText(Ljava/util/List;)V

    .line 478
    .line 479
    .line 480
    :cond_19
    iget-object v3, v0, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp$DataBean;->paymentMethodList:Ljava/util/List;

    .line 481
    .line 482
    const/4 v4, 0x0

    .line 483
    if-eqz v3, :cond_1b

    .line 484
    .line 485
    check-cast v3, Ljava/lang/Iterable;

    .line 486
    .line 487
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 488
    .line 489
    .line 490
    move-result-object v3

    .line 491
    :cond_1a
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 492
    .line 493
    .line 494
    move-result v5

    .line 495
    if-eqz v5, :cond_1b

    .line 496
    .line 497
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 498
    .line 499
    .line 500
    move-result-object v5

    .line 501
    check-cast v5, Lcom/transsnet/palmpay/core/bean/PaymentMethod;

    .line 502
    .line 503
    iget-boolean v6, v5, Lcom/transsnet/palmpay/core/bean/cashier/CashierPaymentMethodBean;->defaultMethodFlag:Z

    .line 504
    .line 505
    if-eqz v6, :cond_1a

    .line 506
    .line 507
    goto :goto_6

    .line 508
    :cond_1b
    move-object v5, v4

    .line 509
    :goto_6
    if-nez v5, :cond_1e

    .line 510
    .line 511
    iget-object v3, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 512
    .line 513
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 514
    .line 515
    if-eqz v3, :cond_1d

    .line 516
    .line 517
    invoke-interface {v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->checkShowOkCardPreCreditInfo()Z

    .line 518
    .line 519
    .line 520
    move-result v3

    .line 521
    const/4 v6, 0x1

    .line 522
    if-ne v3, v6, :cond_1d

    .line 523
    .line 524
    iget-object v3, v1, LLa/F;->d:Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;

    .line 525
    .line 526
    if-nez v3, :cond_1c

    .line 527
    .line 528
    invoke-virtual {v1, v6}, LLa/F;->queryOkCardPreCreditInfo(Z)V

    .line 529
    .line 530
    .line 531
    goto :goto_7

    .line 532
    :cond_1c
    iget-boolean v3, v3, Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;->okCardPreCreditFlag:Z

    .line 533
    .line 534
    if-nez v3, :cond_1f

    .line 535
    .line 536
    iget-object v3, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 537
    .line 538
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 539
    .line 540
    if-eqz v3, :cond_1f

    .line 541
    .line 542
    invoke-interface {v3, v4}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setDefaultMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 543
    .line 544
    .line 545
    goto :goto_7

    .line 546
    :cond_1d
    iget-object v3, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 547
    .line 548
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 549
    .line 550
    if-eqz v3, :cond_1f

    .line 551
    .line 552
    invoke-interface {v3, v4}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setDefaultMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 553
    .line 554
    .line 555
    goto :goto_7

    .line 556
    :cond_1e
    iget-object v3, v0, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp$DataBean;->calculationDto:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 557
    .line 558
    iget-wide v3, v3, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->payMentMethodsDiscount:J

    .line 559
    .line 560
    iput-wide v3, v5, Lcom/transsnet/palmpay/core/bean/PaymentMethod;->payMentMethodsDiscount:J

    .line 561
    .line 562
    iget-object v3, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 563
    .line 564
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 565
    .line 566
    if-eqz v3, :cond_1f

    .line 567
    .line 568
    invoke-interface {v3, v5}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setDefaultMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 569
    .line 570
    .line 571
    :cond_1f
    :goto_7
    invoke-virtual {v1, v5}, LLa/F;->e(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 572
    .line 573
    .line 574
    iget-object v3, v0, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp$DataBean;->limitAmountResp:Lcom/transsnet/palmpay/core/bean/rsp/LimitAmountResp;

    .line 575
    .line 576
    if-eqz v3, :cond_20

    .line 577
    .line 578
    iget-object v4, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 579
    .line 580
    check-cast v4, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 581
    .line 582
    if-eqz v4, :cond_20

    .line 583
    .line 584
    invoke-interface {v4, v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setLimitAmount(Lcom/transsnet/palmpay/core/bean/rsp/LimitAmountResp;)V

    .line 585
    .line 586
    .line 587
    :cond_20
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/rsp/PaymentMethodV4Resp$DataBean;->calculationDto:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 588
    .line 589
    if-eqz v0, :cond_24

    .line 590
    .line 591
    iget-object p1, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 592
    .line 593
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 594
    .line 595
    if-eqz p1, :cond_21

    .line 596
    .line 597
    iget-wide v3, v0, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->fee:J

    .line 598
    .line 599
    invoke-interface {p1, v3, v4}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setFeeAmount(J)V

    .line 600
    .line 601
    .line 602
    :cond_21
    iget-object p1, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 603
    .line 604
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 605
    .line 606
    if-eqz p1, :cond_22

    .line 607
    .line 608
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->handleCommonPreviewInfo(Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;)V

    .line 609
    .line 610
    .line 611
    :cond_22
    iget-object p1, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 612
    .line 613
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 614
    .line 615
    if-eqz p1, :cond_23

    .line 616
    .line 617
    invoke-interface {p1, v5, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->showPreviewPayInfo(Lcom/transsnet/palmpay/core/bean/PaymentMethod;Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;)V

    .line 618
    .line 619
    .line 620
    :cond_23
    iget-object p1, v0, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->riskMsg:Ljava/lang/String;

    .line 621
    .line 622
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 623
    .line 624
    .line 625
    move-result p1

    .line 626
    if-nez p1, :cond_27

    .line 627
    .line 628
    iget-object p1, v0, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->riskMsg:Ljava/lang/String;

    .line 629
    .line 630
    new-array v0, v2, [Ljava/lang/Object;

    .line 631
    .line 632
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 633
    .line 634
    .line 635
    goto :goto_8

    .line 636
    :cond_24
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 637
    .line 638
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 639
    .line 640
    if-eqz v0, :cond_27

    .line 641
    .line 642
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 643
    .line 644
    .line 645
    move-result-object v1

    .line 646
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 647
    .line 648
    .line 649
    move-result-object p1

    .line 650
    invoke-interface {v0, v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->payProcessUnexpectedStop(Ljava/lang/String;Ljava/lang/String;)V

    .line 651
    .line 652
    .line 653
    goto :goto_8

    .line 654
    :cond_25
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 655
    .line 656
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 657
    .line 658
    if-eqz v0, :cond_26

    .line 659
    .line 660
    invoke-interface {v0, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 661
    .line 662
    .line 663
    :cond_26
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 664
    .line 665
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 666
    .line 667
    if-eqz v0, :cond_27

    .line 668
    .line 669
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 670
    .line 671
    .line 672
    move-result-object v1

    .line 673
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 674
    .line 675
    .line 676
    move-result-object p1

    .line 677
    invoke-interface {v0, v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->payProcessUnexpectedStop(Ljava/lang/String;Ljava/lang/String;)V

    .line 678
    .line 679
    .line 680
    :cond_27
    :goto_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 681
    .line 682
    return-object p1

    .line 683
    :pswitch_6
    check-cast p1, Lcom/transsnet/palmpay/core/bean/QueryBankListRsp;

    .line 684
    .line 685
    const-string v0, "it"

    .line 686
    .line 687
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 688
    .line 689
    .line 690
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 691
    .line 692
    .line 693
    move-result v0

    .line 694
    const/4 v1, 0x1

    .line 695
    if-ne v0, v1, :cond_28

    .line 696
    .line 697
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 698
    .line 699
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 700
    .line 701
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 702
    .line 703
    if-eqz v0, :cond_28

    .line 704
    .line 705
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/QueryBankListRsp;->data:Ljava/util/List;

    .line 706
    .line 707
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setUSSDData(Ljava/util/List;)V

    .line 708
    .line 709
    .line 710
    :cond_28
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 711
    .line 712
    return-object p1

    .line 713
    :pswitch_7
    check-cast p1, Ljava/lang/String;

    .line 714
    .line 715
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 716
    .line 717
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 718
    .line 719
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 720
    .line 721
    const/4 v1, 0x0

    .line 722
    if-eqz v0, :cond_29

    .line 723
    .line 724
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 725
    .line 726
    .line 727
    :cond_29
    new-array v0, v1, [Ljava/lang/Object;

    .line 728
    .line 729
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 730
    .line 731
    .line 732
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 733
    .line 734
    return-object p1

    .line 735
    :pswitch_8
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryUserCouponsRsp;

    .line 736
    .line 737
    const-string v0, "it"

    .line 738
    .line 739
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 740
    .line 741
    .line 742
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 743
    .line 744
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 745
    .line 746
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 747
    .line 748
    if-eqz v0, :cond_2a

    .line 749
    .line 750
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->handleQueryCouponRsp(Lcom/transsnet/palmpay/core/bean/rsp/QueryUserCouponsRsp;)V

    .line 751
    .line 752
    .line 753
    :cond_2a
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 754
    .line 755
    return-object p1

    .line 756
    :pswitch_9
    check-cast p1, Ljava/lang/String;

    .line 757
    .line 758
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 759
    .line 760
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 761
    .line 762
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 763
    .line 764
    const/4 v1, 0x0

    .line 765
    if-eqz v0, :cond_2b

    .line 766
    .line 767
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 768
    .line 769
    .line 770
    :cond_2b
    new-array v0, v1, [Ljava/lang/Object;

    .line 771
    .line 772
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 773
    .line 774
    .line 775
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 776
    .line 777
    return-object p1

    .line 778
    :pswitch_a
    check-cast p1, Ljava/lang/String;

    .line 779
    .line 780
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 781
    .line 782
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 783
    .line 784
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 785
    .line 786
    const/4 v1, 0x0

    .line 787
    if-eqz v0, :cond_2c

    .line 788
    .line 789
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 790
    .line 791
    .line 792
    :cond_2c
    new-array v0, v1, [Ljava/lang/Object;

    .line 793
    .line 794
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 795
    .line 796
    .line 797
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 798
    .line 799
    return-object p1

    .line 800
    :pswitch_b
    check-cast p1, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;

    .line 801
    .line 802
    const-string v0, "it"

    .line 803
    .line 804
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 805
    .line 806
    .line 807
    iget-object v0, p0, LLa/C;->b:LLa/F;

    .line 808
    .line 809
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 810
    .line 811
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 812
    .line 813
    if-eqz v0, :cond_2d

    .line 814
    .line 815
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->showPaymentMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;)V

    .line 816
    .line 817
    .line 818
    :cond_2d
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 819
    .line 820
    return-object p1

    .line 821
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
