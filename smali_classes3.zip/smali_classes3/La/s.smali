.class public final LLa/s;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;

.field public final synthetic i:LLa/v;


# direct methods
.method public synthetic constructor <init>(LLa/v;Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;I)V
    .locals 0

    .line 1
    iput p3, p0, LLa/s;->f:I

    iput-object p1, p0, LLa/s;->i:LLa/v;

    iput-object p2, p0, LLa/s;->g:Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, LLa/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 13
    .line 14
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_1
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 19
    .line 20
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_2
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 25
    .line 26
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget v0, p0, LLa/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 7
    .line 8
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 13
    .line 14
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->checkPayFail(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void

    .line 18
    :pswitch_0
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 19
    .line 20
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 21
    .line 22
    if-eqz v0, :cond_1

    .line 23
    .line 24
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 25
    .line 26
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->checkPayFail(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    :cond_1
    return-void

    .line 30
    :pswitch_1
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 31
    .line 32
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 33
    .line 34
    if-eqz v0, :cond_2

    .line 35
    .line 36
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 37
    .line 38
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->checkPayFail(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    :cond_2
    return-void

    .line 42
    :pswitch_2
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 43
    .line 44
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 45
    .line 46
    if-eqz v0, :cond_3

    .line 47
    .line 48
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 49
    .line 50
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->checkPayFail(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    :cond_3
    return-void

    .line 54
    nop

    .line 55
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget v0, p0, LLa/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayResp;

    .line 7
    .line 8
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 9
    .line 10
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 15
    .line 16
    iget-object v1, p0, LLa/s;->g:Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;

    .line 17
    .line 18
    iget v1, v1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->verifyMethod:I

    .line 19
    .line 20
    invoke-interface {v0, v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->showCheckPayResult(ILcom/transsnet/palmpay/core/bean/payment/CheckPayResp;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void

    .line 24
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayResp;

    .line 25
    .line 26
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 27
    .line 28
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 33
    .line 34
    iget-object v1, p0, LLa/s;->g:Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;

    .line 35
    .line 36
    iget v1, v1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->verifyMethod:I

    .line 37
    .line 38
    invoke-interface {v0, v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->showCheckPayResult(ILcom/transsnet/palmpay/core/bean/payment/CheckPayResp;)V

    .line 39
    .line 40
    .line 41
    :cond_1
    return-void

    .line 42
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayResp;

    .line 43
    .line 44
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 45
    .line 46
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 47
    .line 48
    if-eqz v0, :cond_2

    .line 49
    .line 50
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 51
    .line 52
    iget-object v1, p0, LLa/s;->g:Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;

    .line 53
    .line 54
    iget v1, v1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->verifyMethod:I

    .line 55
    .line 56
    invoke-interface {v0, v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->showCheckPayResult(ILcom/transsnet/palmpay/core/bean/payment/CheckPayResp;)V

    .line 57
    .line 58
    .line 59
    :cond_2
    return-void

    .line 60
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayResp;

    .line 61
    .line 62
    iget-object v0, p0, LLa/s;->i:LLa/v;

    .line 63
    .line 64
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 65
    .line 66
    if-eqz v0, :cond_3

    .line 67
    .line 68
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 69
    .line 70
    iget-object v1, p0, LLa/s;->g:Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;

    .line 71
    .line 72
    iget v1, v1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;->verifyMethod:I

    .line 73
    .line 74
    invoke-interface {v0, v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->showCheckPayResult(ILcom/transsnet/palmpay/core/bean/payment/CheckPayResp;)V

    .line 75
    .line 76
    .line 77
    :cond_3
    return-void

    .line 78
    nop

    .line 79
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
