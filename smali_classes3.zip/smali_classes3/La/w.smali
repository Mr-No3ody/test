.class public final synthetic LLa/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;I)V
    .locals 0

    .line 1
    iput p2, p0, LLa/w;->a:I

    iput-object p1, p0, LLa/w;->b:Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LLa/w;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 7
    .line 8
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 11
    .line 12
    iget-object v1, p0, LLa/w;->b:Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;

    .line 13
    .line 14
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryPreviewPayInfoV2(Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;)Ldf/d;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 20
    .line 21
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 24
    .line 25
    iget-object v1, p0, LLa/w;->b:Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;

    .line 26
    .line 27
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryPreviewPayInfoV2(Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;)Ldf/d;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0

    .line 32
    nop

    .line 33
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
