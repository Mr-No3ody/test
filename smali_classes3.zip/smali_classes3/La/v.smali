.class public final LLa/v;
.super Lcom/transsnet/palmpay/core/base/j;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IPresenter;


# virtual methods
.method public final checkNewPay(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)V
    .locals 3

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->checkSavingPay(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, LLa/s;

    .line 26
    .line 27
    const/4 v2, 0x1

    .line 28
    invoke-direct {v1, p0, p1, v2}, LLa/s;-><init>(LLa/v;Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final checkPay(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)V
    .locals 3

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->checkPay(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, LLa/s;

    .line 26
    .line 27
    const/4 v2, 0x0

    .line 28
    invoke-direct {v1, p0, p1, v2}, LLa/s;-><init>(LLa/v;Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final checkWithdrawalPay(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)V
    .locals 3

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->checkWithdrawalPay(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, LLa/s;

    .line 26
    .line 27
    const/4 v2, 0x2

    .line 28
    invoke-direct {v1, p0, p1, v2}, LLa/s;-><init>(LLa/v;Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final partnerCheckPay(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)V
    .locals 3

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->partnerCheckPay(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, LLa/s;

    .line 26
    .line 27
    const/4 v2, 0x3

    .line 28
    invoke-direct {v1, p0, p1, v2}, LLa/s;-><init>(LLa/v;Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final queryPayResult(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)V
    .locals 2

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryPayResult(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    new-instance v0, LLa/t;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-direct {v0, p0, v1}, LLa/t;-><init>(LLa/v;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final queryPaymentReward(ILjava/lang/String;)V
    .locals 1

    .line 1
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const-string p1, "queryPaymentReward transType is empty"

    .line 8
    .line 9
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    const-string p2, "CheckPayPresenter"

    .line 14
    .line 15
    invoke-static {p2, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 20
    .line 21
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 24
    .line 25
    invoke-interface {v0, p1, p2}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryPaymentReward(ILjava/lang/String;)Ldf/d;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    sget-object p2, Ltf/f;->b:Ldf/i;

    .line 30
    .line 31
    invoke-virtual {p1, p2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    invoke-virtual {p1, p2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    new-instance p2, LLa/t;

    .line 44
    .line 45
    const/4 v0, 0x2

    .line 46
    invoke-direct {p2, p0, v0}, LLa/t;-><init>(LLa/v;I)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p1, p2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 50
    .line 51
    .line 52
    return-void
.end method

.method public final querySavingPayResult(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)V
    .locals 2

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryNewPayResult(Lcom/transsnet/palmpay/core/bean/payment/CheckPayReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    new-instance v0, LLa/t;

    .line 26
    .line 27
    const/4 v1, 0x1

    .line 28
    invoke-direct {v0, p0, v1}, LLa/t;-><init>(LLa/v;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method
