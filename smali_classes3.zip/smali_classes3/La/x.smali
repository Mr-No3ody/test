.class public final LLa/x;
.super LLa/F;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/ui/mvp/contract/CorePaymentPreviewContract$Presenter;


# virtual methods
.method public final queryPreviewInfo(Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;)V
    .locals 9

    .line 1
    iget-object v0, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    move-object v2, v0

    .line 4
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/CorePaymentPreviewContract$View;

    .line 5
    .line 6
    new-instance v3, LLa/w;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {v3, p1, v0}, LLa/w;-><init>(Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;I)V

    .line 10
    .line 11
    .line 12
    new-instance v4, LAd/e;

    .line 13
    .line 14
    const/16 v0, 0xb

    .line 15
    .line 16
    invoke-direct {v4, v0, p0, p1}, LAd/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    const/4 v6, 0x1

    .line 20
    const/4 v7, 0x1

    .line 21
    const/4 v5, 0x0

    .line 22
    const/16 v8, 0x8

    .line 23
    .line 24
    move-object v1, p0

    .line 25
    invoke-static/range {v1 .. v8}, LJ3/a;->C(Lcom/transsnet/palmpay/core/base/j;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Ld9/v;ZZI)V

    .line 26
    .line 27
    .line 28
    return-void
.end method
