.class public final LLa/t;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:LLa/v;


# direct methods
.method public synthetic constructor <init>(LLa/v;I)V
    .locals 0

    .line 1
    iput p2, p0, LLa/t;->f:I

    iput-object p1, p0, LLa/t;->g:LLa/v;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final R(Ljava/lang/String;)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, LLa/t;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LLa/t;->g:LLa/v;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    iget-object v0, p0, LLa/t;->g:LLa/v;

    .line 13
    .line 14
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_1
    iget-object v0, p0, LLa/t;->g:LLa/v;

    .line 19
    .line 20
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    nop

    .line 25
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget v0, p0, LLa/t;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    iget-object v0, p0, LLa/t;->g:LLa/v;

    .line 8
    .line 9
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 14
    .line 15
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->checkPayFail(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void

    .line 19
    :pswitch_1
    iget-object v0, p0, LLa/t;->g:LLa/v;

    .line 20
    .line 21
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 26
    .line 27
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->checkPayFail(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :cond_1
    return-void

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LLa/t;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryPaymentRewardRsp;

    .line 7
    .line 8
    iget-object v0, p0, LLa/t;->g:LLa/v;

    .line 9
    .line 10
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    if-eqz p1, :cond_0

    .line 15
    .line 16
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 17
    .line 18
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->queryPaymentRewardOk(Lcom/transsnet/palmpay/core/bean/rsp/QueryPaymentRewardRsp;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    return-void

    .line 22
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayResp;

    .line 23
    .line 24
    iget-object v0, p0, LLa/t;->g:LLa/v;

    .line 25
    .line 26
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 27
    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 31
    .line 32
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->showQueryPayResult(Lcom/transsnet/palmpay/core/bean/payment/CheckPayResp;)V

    .line 33
    .line 34
    .line 35
    :cond_1
    return-void

    .line 36
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/payment/CheckPayResp;

    .line 37
    .line 38
    iget-object v0, p0, LLa/t;->g:LLa/v;

    .line 39
    .line 40
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 41
    .line 42
    if-eqz v0, :cond_2

    .line 43
    .line 44
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;

    .line 45
    .line 46
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CheckPayContract$IView;->showQueryPayResult(Lcom/transsnet/palmpay/core/bean/payment/CheckPayResp;)V

    .line 47
    .line 48
    .line 49
    :cond_2
    return-void

    .line 50
    nop

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
