.class public final synthetic LLa/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Z

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ZI)V
    .locals 0

    .line 1
    iput p3, p0, LLa/D;->a:I

    iput-object p1, p0, LLa/D;->c:Ljava/lang/Object;

    iput-boolean p2, p0, LLa/D;->b:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-boolean v1, p0, LLa/D;->b:Z

    .line 3
    .line 4
    iget-object v2, p0, LLa/D;->c:Ljava/lang/Object;

    .line 5
    .line 6
    iget v3, p0, LLa/D;->a:I

    .line 7
    .line 8
    packed-switch v3, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;

    .line 12
    .line 13
    const-string v0, "response"

    .line 14
    .line 15
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    check-cast v2, Ld9/z;

    .line 23
    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    iget-object v0, v2, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 27
    .line 28
    check-cast v0, Lcom/transsnet/palmpay/account/ui/mvp/contract/PalmPayLevelUpTier3Contract$View;

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    invoke-interface {v0, p1, v1}, Lcom/transsnet/palmpay/account/ui/mvp/contract/PalmPayLevelUpTier3Contract$View;->handleIdIdentityListRsp(Lcom/transsnet/palmpay/core/bean/CommonListResultV2;Z)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    if-eqz v1, :cond_1

    .line 37
    .line 38
    iget-object v0, v2, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 39
    .line 40
    check-cast v0, Lcom/transsnet/palmpay/account/ui/mvp/contract/PalmPayLevelUpTier3Contract$View;

    .line 41
    .line 42
    if-eqz v0, :cond_1

    .line 43
    .line 44
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/account/ui/mvp/contract/PalmPayLevelUpTier3Contract$View;->showRetryIdentityListDialog(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    :cond_1
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 52
    .line 53
    return-object p1

    .line 54
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/WAECOperatorResp;

    .line 55
    .line 56
    sget v3, Lcom/transsnet/palmpay/teller/ui/activity/WaecHomeActivity;->Q:I

    .line 57
    .line 58
    const-string v3, "rsp"

    .line 59
    .line 60
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/WAECOperatorResp;->getData()Ljava/util/List;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    check-cast v2, Lcom/transsnet/palmpay/teller/ui/activity/WaecHomeActivity;

    .line 68
    .line 69
    iput-object p1, v2, Lcom/transsnet/palmpay/teller/ui/activity/WaecHomeActivity;->v:Ljava/util/List;

    .line 70
    .line 71
    if-eqz v1, :cond_4

    .line 72
    .line 73
    iget-object v1, v2, Lcom/transsnet/palmpay/teller/ui/activity/WaecHomeActivity;->L:Lcom/transsnet/palmpay/teller/ui/dialog/PickMobileNetWorkDialog;

    .line 74
    .line 75
    const-string v3, "selectNetWorkDialog"

    .line 76
    .line 77
    if-eqz v1, :cond_3

    .line 78
    .line 79
    invoke-virtual {v1, p1}, Lcom/transsnet/palmpay/teller/ui/dialog/PickMobileNetWorkDialog;->setDatas(Ljava/util/List;)V

    .line 80
    .line 81
    .line 82
    iget-object p1, v2, Lcom/transsnet/palmpay/teller/ui/activity/WaecHomeActivity;->L:Lcom/transsnet/palmpay/teller/ui/dialog/PickMobileNetWorkDialog;

    .line 83
    .line 84
    if-eqz p1, :cond_2

    .line 85
    .line 86
    invoke-virtual {p1}, LO6/f;->show()V

    .line 87
    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_2
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    throw v0

    .line 94
    :cond_3
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    throw v0

    .line 98
    :cond_4
    iget-object p1, v2, Lcom/transsnet/palmpay/teller/ui/activity/WaecHomeActivity;->B:Ljava/lang/String;

    .line 99
    .line 100
    invoke-virtual {v2, p1}, Lcom/transsnet/palmpay/teller/ui/activity/WaecHomeActivity;->t(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 104
    .line 105
    return-object p1

    .line 106
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 107
    .line 108
    const-string v3, "it"

    .line 109
    .line 110
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    iget-object v3, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v3, Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;

    .line 116
    .line 117
    if-eqz v3, :cond_6

    .line 118
    .line 119
    check-cast v2, LLa/F;

    .line 120
    .line 121
    iput-object v3, v2, LLa/F;->d:Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;

    .line 122
    .line 123
    iget-object v4, v2, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 124
    .line 125
    check-cast v4, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 126
    .line 127
    if-eqz v4, :cond_5

    .line 128
    .line 129
    invoke-interface {v4, v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->handleOkCardPreCreditInfo(Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;)V

    .line 130
    .line 131
    .line 132
    :cond_5
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;

    .line 135
    .line 136
    iget-boolean p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;->okCardPreCreditFlag:Z

    .line 137
    .line 138
    if-nez p1, :cond_6

    .line 139
    .line 140
    if-eqz v1, :cond_6

    .line 141
    .line 142
    iget-object p1, v2, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 143
    .line 144
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 145
    .line 146
    if-eqz p1, :cond_6

    .line 147
    .line 148
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setDefaultMethod(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 149
    .line 150
    .line 151
    :cond_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 152
    .line 153
    return-object p1

    .line 154
    nop

    .line 155
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
