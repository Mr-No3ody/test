.class public final LLa/e;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:LLa/h;


# direct methods
.method public constructor <init>(LLa/h;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLa/e;->f:LLa/h;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, LLa/e;->f:LLa/h;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;

    .line 2
    .line 3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, LLa/e;->f:LLa/h;

    .line 10
    .line 11
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;

    .line 14
    .line 15
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/PaymentMethodResp;->data:Ljava/util/List;

    .line 16
    .line 17
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;->handlePaymentMethods(Ljava/util/List;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method
