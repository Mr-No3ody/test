.class public final LLa/c;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:LLa/h;


# direct methods
.method public constructor <init>(LLa/h;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLa/c;->f:LLa/h;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, LLa/c;->f:LLa/h;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, LLa/c;->f:LLa/h;

    .line 5
    .line 6
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 7
    .line 8
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/AddPayBankAccRsp;

    .line 2
    .line 3
    iget-object v0, p0, LLa/c;->f:LLa/h;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 6
    .line 7
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 11
    .line 12
    .line 13
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 14
    .line 15
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;

    .line 16
    .line 17
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddBankAccountContract$IView;->handleAddBankAccountResult(Lcom/transsnet/palmpay/core/bean/rsp/AddPayBankAccRsp;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method
