.class public abstract LLa/r;
.super Lcom/transsnet/palmpay/core/base/j;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IPresenter;


# direct methods
.method public static b(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    if-eqz p0, :cond_0

    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    const-string v0, "Cashier_Order_Creation"

    .line 14
    .line 15
    const/4 v1, 0x1

    .line 16
    invoke-static {v0, v1}, LC0/G;->g(Ljava/lang/String;Z)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;

    .line 21
    .line 22
    const-string v1, "TransType"

    .line 23
    .line 24
    iget-object v2, p1, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->transType:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {v0, v1, v2}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    check-cast v0, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;

    .line 31
    .line 32
    const-string v1, "OrderNo"

    .line 33
    .line 34
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;->orderNo:Ljava/lang/String;

    .line 35
    .line 36
    invoke-virtual {v0, v1, p1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;

    .line 41
    .line 42
    invoke-virtual {p0, p1}, LPa/n0;->u(Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;)V

    .line 43
    .line 44
    .line 45
    :cond_0
    return-void
.end method


# virtual methods
.method public final partnerPayByOrderNo(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V
    .locals 2

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->partnerPayByOrderNo(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, LLa/o;

    .line 26
    .line 27
    invoke-direct {v1, p0, p1}, LLa/o;-><init>(LLa/r;Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final payByNewOrderNo(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V
    .locals 2

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->payByNewOrderNoV2(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, LLa/n;

    .line 26
    .line 27
    invoke-direct {v1, p0, p1}, LLa/n;-><init>(LLa/r;Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final payByOrderNo(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V
    .locals 2

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->payByOrderNoV2(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v1, LLa/m;

    .line 26
    .line 27
    invoke-direct {v1, p0, p1}, LLa/m;-><init>(LLa/r;Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final queryBankList(Lcom/transsnet/palmpay/core/bean/req/QueryBankListReq;)V
    .locals 3

    .line 1
    const-string v0, "queryBankList"

    .line 2
    .line 3
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, LPa/H;->b([Ljava/lang/Object;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sget-object v1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 12
    .line 13
    iget-object v1, v1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 16
    .line 17
    invoke-interface {v1, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryBankList(Lcom/transsnet/palmpay/core/bean/req/QueryBankListReq;)Ldf/d;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    new-instance v1, LPa/a0;

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    invoke-direct {v1, v0, v2}, LPa/a0;-><init>(Ljava/lang/String;I)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p1, v1}, Ldf/d;->c(Lio/reactivex/ObservableTransformer;)Ldf/d;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    const-class v1, Lcom/transsnet/palmpay/core/bean/QueryBankListRsp;

    .line 32
    .line 33
    invoke-static {v1, v0}, LPa/r0;->H1(Ljava/lang/Class;Ljava/lang/String;)Lio/reactivex/internal/operators/observable/K;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {v0, p1}, Ldf/d;->d(Lio/reactivex/internal/operators/observable/K;Ldf/d;)Lio/reactivex/internal/operators/observable/d;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 42
    .line 43
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    new-instance v0, LLa/p;

    .line 56
    .line 57
    invoke-direct {v0, p0}, LLa/p;-><init>(LLa/r;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 61
    .line 62
    .line 63
    return-void
.end method
