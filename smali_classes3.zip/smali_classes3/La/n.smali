.class public final LLa/n;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;

.field public final synthetic g:LLa/r;


# direct methods
.method public constructor <init>(LLa/r;Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLa/n;->g:LLa/r;

    .line 5
    .line 6
    iput-object p2, p0, LLa/n;->f:Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, LLa/n;->g:LLa/r;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, LLa/n;->g:LLa/r;

    .line 2
    .line 3
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 11
    .line 12
    .line 13
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 14
    .line 15
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;

    .line 16
    .line 17
    const-string v1, "-1"

    .line 18
    .line 19
    invoke-interface {v0, v1, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->payProcessUnexpectedStop(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    const-string v0, "The request is being processed. Please wait for a while and try it again."

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    sget p1, Lba/k;->core_msg_pay_order_time_out:I

    .line 31
    .line 32
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :cond_1
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;

    .line 2
    .line 3
    iget-object v0, p0, LLa/n;->g:LLa/r;

    .line 4
    .line 5
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;

    .line 10
    .line 11
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showPayResult(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, LLa/n;->f:Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;

    .line 15
    .line 16
    invoke-static {p1, v0}, LLa/r;->b(Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp;Lcom/transsnet/palmpay/core/bean/payment/PayByOrderReq;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void
.end method
