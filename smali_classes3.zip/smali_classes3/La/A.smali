.class public final LLa/A;
.super Lcom/transsnet/palmpay/core/base/j;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$Presenter;


# virtual methods
.method public final checkSms(Lcom/transsnet/palmpay/core/bean/req/VerifyRiskControlSmsReq;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;->showLoadingView(Z)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 10
    .line 11
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 14
    .line 15
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->verifyRiskControlSms(Lcom/transsnet/palmpay/core/bean/req/VerifyRiskControlSmsReq;)Ldf/d;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 20
    .line 21
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    new-instance v0, LLa/z;

    .line 34
    .line 35
    invoke-direct {v0, p0}, LLa/z;-><init>(LLa/A;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final sendSms(II)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;->showLoadingView(Z)V

    .line 7
    .line 8
    .line 9
    new-instance v0, Lcom/transsnet/palmpay/core/bean/req/RiskControlOtcReq;

    .line 10
    .line 11
    invoke-direct {v0}, Lcom/transsnet/palmpay/core/bean/req/RiskControlOtcReq;-><init>()V

    .line 12
    .line 13
    .line 14
    iput p1, v0, Lcom/transsnet/palmpay/core/bean/req/RiskControlOtcReq;->scene:I

    .line 15
    .line 16
    iput p2, v0, Lcom/transsnet/palmpay/core/bean/req/RiskControlOtcReq;->voiceSms:I

    .line 17
    .line 18
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 19
    .line 20
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 23
    .line 24
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/network/PayApiService;->sendPayVerifySms(Lcom/transsnet/palmpay/core/bean/req/RiskControlOtcReq;)Ldf/d;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    sget-object p2, Ltf/f;->b:Ldf/i;

    .line 29
    .line 30
    invoke-virtual {p1, p2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 35
    .line 36
    .line 37
    move-result-object p2

    .line 38
    invoke-virtual {p1, p2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    new-instance p2, LLa/y;

    .line 43
    .line 44
    invoke-direct {p2, p0}, LLa/y;-><init>(LLa/A;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p1, p2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 48
    .line 49
    .line 50
    return-void
.end method
