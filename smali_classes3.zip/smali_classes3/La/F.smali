.class public LLa/F;
.super LLa/r;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IPresenter;


# instance fields
.field public d:Lcom/transsnet/palmpay/core/bean/rsp/OkCardPreCreditInfoRsp;

.field public e:Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;


# direct methods
.method public static synthetic d(LLa/F;Ljava/lang/String;I)V
    .locals 1

    .line 1
    const/4 p2, 0x0

    .line 2
    const-string v0, ""

    .line 3
    .line 4
    invoke-virtual {p0, p2, p1, v0, v0}, LLa/F;->c(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final c(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    .line 1
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v2

    .line 5
    if-nez v2, :cond_3

    .line 6
    .line 7
    new-instance v2, Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;

    .line 8
    .line 9
    invoke-direct {v2}, Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;-><init>()V

    .line 10
    .line 11
    .line 12
    iget-object v3, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 13
    .line 14
    check-cast v3, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 15
    .line 16
    if-eqz v3, :cond_0

    .line 17
    .line 18
    invoke-interface {v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->getOrderAmount()J

    .line 19
    .line 20
    .line 21
    move-result-wide v3

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const-wide/16 v3, 0x0

    .line 24
    .line 25
    :goto_0
    iput-wide v3, v2, Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;->orderAmount:J

    .line 26
    .line 27
    iput-object p2, v2, Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;->transType:Ljava/lang/String;

    .line 28
    .line 29
    iput p1, v2, Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;->senderAccountType:I

    .line 30
    .line 31
    iput-object p3, v2, Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;->payeeAccountType:Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-nez v3, :cond_2

    .line 38
    .line 39
    if-nez p2, :cond_1

    .line 40
    .line 41
    const-string v1, ""

    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    move-object v1, p2

    .line 45
    :goto_1
    const-string v3, "j6"

    .line 46
    .line 47
    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_2

    .line 52
    .line 53
    iput-object p4, v2, Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;->orderNo:Ljava/lang/String;

    .line 54
    .line 55
    :cond_2
    iget-object v1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 56
    .line 57
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 58
    .line 59
    new-instance v3, LAe/j;

    .line 60
    .line 61
    const/16 v4, 0x1d

    .line 62
    .line 63
    invoke-direct {v3, v2, v4}, LAe/j;-><init>(Ljava/lang/Object;I)V

    .line 64
    .line 65
    .line 66
    move-object v2, v3

    .line 67
    new-instance v3, LLa/C;

    .line 68
    .line 69
    const/16 v4, 0xb

    .line 70
    .line 71
    invoke-direct {v3, p0, v4}, LLa/C;-><init>(LLa/F;I)V

    .line 72
    .line 73
    .line 74
    new-instance v4, LLa/C;

    .line 75
    .line 76
    const/16 v5, 0xc

    .line 77
    .line 78
    invoke-direct {v4, p0, v5}, LLa/C;-><init>(LLa/F;I)V

    .line 79
    .line 80
    .line 81
    const/4 v5, 0x0

    .line 82
    const/4 v6, 0x0

    .line 83
    move-object v0, p0

    .line 84
    invoke-static/range {v0 .. v6}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 85
    .line 86
    .line 87
    return-void

    .line 88
    :cond_3
    iget-object v1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 89
    .line 90
    new-instance v2, LLa/i;

    .line 91
    .line 92
    const/4 v3, 0x3

    .line 93
    invoke-direct {v2, v3}, LLa/i;-><init>(I)V

    .line 94
    .line 95
    .line 96
    new-instance v3, LLa/C;

    .line 97
    .line 98
    const/4 v4, 0x0

    .line 99
    invoke-direct {v3, p0, v4}, LLa/C;-><init>(LLa/F;I)V

    .line 100
    .line 101
    .line 102
    new-instance v4, LLa/C;

    .line 103
    .line 104
    const/4 v5, 0x1

    .line 105
    invoke-direct {v4, p0, v5}, LLa/C;-><init>(LLa/F;I)V

    .line 106
    .line 107
    .line 108
    const/4 v5, 0x0

    .line 109
    const/4 v6, 0x0

    .line 110
    move-object v0, p0

    .line 111
    invoke-static/range {v0 .. v6}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 112
    .line 113
    .line 114
    return-void
.end method

.method public final e(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V
    .locals 2

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    new-instance v0, Ljava/util/HashMap;

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 6
    .line 7
    .line 8
    iget p1, p1, Lcom/transsnet/palmpay/core/bean/cashier/CashierPaymentMethodBean;->senderAccountType:I

    .line 9
    .line 10
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const-string v1, "element_pay_method"

    .line 15
    .line 16
    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    iget-object p1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 20
    .line 21
    const-string v1, "null cannot be cast to non-null type android.app.Activity"

    .line 22
    .line 23
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    check-cast p1, Landroid/app/Activity;

    .line 27
    .line 28
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/core/util/statistic/core/AutoTrackUtil;->trackActivityProperties(Landroid/app/Activity;Ljava/util/Map;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    return-void
.end method

.method public final getPreviewPayInfoReq()Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;
    .locals 1

    .line 1
    iget-object v0, p0, LLa/F;->e:Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;

    .line 2
    .line 3
    return-object v0
.end method

.method public final queryCoupons(Lcom/transsnet/palmpay/core/bean/req/QueryCouponByConditionReq;)V
    .locals 8

    .line 1
    const-string v0, "req"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 7
    .line 8
    move-object v2, v0

    .line 9
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 10
    .line 11
    new-instance v3, LAe/j;

    .line 12
    .line 13
    const/16 v0, 0x1b

    .line 14
    .line 15
    invoke-direct {v3, p1, v0}, LAe/j;-><init>(Ljava/lang/Object;I)V

    .line 16
    .line 17
    .line 18
    new-instance v4, LLa/C;

    .line 19
    .line 20
    const/4 p1, 0x3

    .line 21
    invoke-direct {v4, p0, p1}, LLa/C;-><init>(LLa/F;I)V

    .line 22
    .line 23
    .line 24
    new-instance v5, LLa/C;

    .line 25
    .line 26
    const/4 p1, 0x4

    .line 27
    invoke-direct {v5, p0, p1}, LLa/C;-><init>(LLa/F;I)V

    .line 28
    .line 29
    .line 30
    const/4 v6, 0x0

    .line 31
    const/4 v7, 0x0

    .line 32
    move-object v1, p0

    .line 33
    invoke-static/range {v1 .. v7}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final queryLimitAmount(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 8

    .line 1
    const-string v0, "transType"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "payeeAccountType"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "payerAccountType"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    new-instance v0, Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;

    .line 17
    .line 18
    invoke-direct {v0}, Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;-><init>()V

    .line 19
    .line 20
    .line 21
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    iput-object v1, v0, Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;->countryCode:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrency()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    iput-object v1, v0, Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;->currency:Ljava/lang/String;

    .line 32
    .line 33
    iput-object p1, v0, Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;->transType:Ljava/lang/String;

    .line 34
    .line 35
    iput-object p2, v0, Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;->payeeAccountType:Ljava/lang/String;

    .line 36
    .line 37
    iput-object p3, v0, Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;->payerAccountType:Ljava/lang/String;

    .line 38
    .line 39
    iget-object p1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 40
    .line 41
    move-object v2, p1

    .line 42
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 43
    .line 44
    new-instance v3, LAe/j;

    .line 45
    .line 46
    const/16 p1, 0x1c

    .line 47
    .line 48
    invoke-direct {v3, v0, p1}, LAe/j;-><init>(Ljava/lang/Object;I)V

    .line 49
    .line 50
    .line 51
    new-instance v4, LLa/C;

    .line 52
    .line 53
    const/4 p1, 0x7

    .line 54
    invoke-direct {v4, p0, p1}, LLa/C;-><init>(LLa/F;I)V

    .line 55
    .line 56
    .line 57
    new-instance v5, LFe/h0;

    .line 58
    .line 59
    const/16 p1, 0x9

    .line 60
    .line 61
    invoke-direct {v5, p1}, LFe/h0;-><init>(I)V

    .line 62
    .line 63
    .line 64
    const/4 v6, 0x0

    .line 65
    const/4 v7, 0x1

    .line 66
    move-object v1, p0

    .line 67
    invoke-static/range {v1 .. v7}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 68
    .line 69
    .line 70
    return-void
.end method

.method public final queryOkCardPreCreditInfo(Z)V
    .locals 8

    .line 1
    iget-object v1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    new-instance v2, LLa/i;

    .line 4
    .line 5
    const/4 v0, 0x2

    .line 6
    invoke-direct {v2, v0}, LLa/i;-><init>(I)V

    .line 7
    .line 8
    .line 9
    new-instance v3, LLa/D;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-direct {v3, p0, p1, v0}, LLa/D;-><init>(Ljava/lang/Object;ZI)V

    .line 13
    .line 14
    .line 15
    const/4 v5, 0x0

    .line 16
    const/4 v6, 0x0

    .line 17
    const/4 v4, 0x0

    .line 18
    const/16 v7, 0x8

    .line 19
    .line 20
    move-object v0, p0

    .line 21
    invoke-static/range {v0 .. v7}, LJ3/a;->C(Lcom/transsnet/palmpay/core/base/j;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Ld9/v;ZZI)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final queryPaymentMethod(Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;)V
    .locals 8

    .line 1
    const-string v0, "req"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 14
    .line 15
    .line 16
    :cond_0
    const/4 v0, 0x0

    .line 17
    if-eqz p1, :cond_3

    .line 18
    .line 19
    iget-object v1, p1, Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;->transType:Ljava/lang/String;

    .line 20
    .line 21
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    iget-object v1, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 28
    .line 29
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 30
    .line 31
    if-eqz v1, :cond_1

    .line 32
    .line 33
    invoke-interface {v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->getTransType()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    :cond_1
    iput-object v0, p1, Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;->transType:Ljava/lang/String;

    .line 38
    .line 39
    :cond_2
    iget-object v2, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 40
    .line 41
    new-instance v3, LLa/w;

    .line 42
    .line 43
    const/4 v0, 0x1

    .line 44
    invoke-direct {v3, p1, v0}, LLa/w;-><init>(Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;I)V

    .line 45
    .line 46
    .line 47
    new-instance v4, LAd/e;

    .line 48
    .line 49
    const/16 v0, 0xc

    .line 50
    .line 51
    invoke-direct {v4, v0, p0, p1}, LAd/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    new-instance v5, LLa/C;

    .line 55
    .line 56
    const/4 p1, 0x2

    .line 57
    invoke-direct {v5, p0, p1}, LLa/C;-><init>(LLa/F;I)V

    .line 58
    .line 59
    .line 60
    const/4 v6, 0x0

    .line 61
    const/4 v7, 0x0

    .line 62
    move-object v1, p0

    .line 63
    invoke-static/range {v1 .. v7}, LJ3/a;->B(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :cond_3
    move-object v1, p0

    .line 68
    const/16 p1, 0xe

    .line 69
    .line 70
    invoke-static {p0, v0, p1}, LLa/F;->d(LLa/F;Ljava/lang/String;I)V

    .line 71
    .line 72
    .line 73
    return-void
.end method

.method public final savePreviewPayInfoReq(Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;)V
    .locals 0

    .line 1
    iput-object p1, p0, LLa/F;->e:Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;

    .line 2
    .line 3
    return-void
.end method
