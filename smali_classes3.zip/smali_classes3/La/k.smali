.class public final LLa/k;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:LLa/l;

.field public final synthetic g:Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;


# direct methods
.method public constructor <init>(LLa/l;Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLa/k;->f:LLa/l;

    .line 5
    .line 6
    iput-object p2, p0, LLa/k;->g:Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LLa/k;->f:LLa/l;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 3

    .line 1
    const-string v0, "message"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LLa/k;->f:LLa/l;

    .line 7
    .line 8
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 9
    .line 10
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 16
    .line 17
    .line 18
    :cond_0
    new-array v1, v2, [Ljava/lang/Object;

    .line 19
    .line 20
    invoke-static {p1, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 24
    .line 25
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 26
    .line 27
    if-eqz p1, :cond_1

    .line 28
    .line 29
    iget-object v0, p0, LLa/k;->g:Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;

    .line 30
    .line 31
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handleBindResult(Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;)V

    .line 32
    .line 33
    .line 34
    :cond_1
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/db/entity/User;

    .line 2
    .line 3
    const-string v0, "response"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, LLa/k;->f:LLa/l;

    .line 9
    .line 10
    iget-object v0, p1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 11
    .line 12
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 18
    .line 19
    .line 20
    :cond_0
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 21
    .line 22
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 23
    .line 24
    if-eqz p1, :cond_1

    .line 25
    .line 26
    iget-object v0, p0, LLa/k;->g:Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;

    .line 27
    .line 28
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handleBindResult(Lcom/transsnet/palmpay/core/bean/rsp/BindActionRsp;)V

    .line 29
    .line 30
    .line 31
    :cond_1
    return-void
.end method
