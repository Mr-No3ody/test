.class public final LLa/y;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:LLa/A;


# direct methods
.method public constructor <init>(LLa/A;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLa/y;->f:LLa/A;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, LLa/y;->f:LLa/A;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, LLa/y;->f:LLa/A;

    .line 5
    .line 6
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 7
    .line 8
    check-cast p1, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;->showLoadingView(Z)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    iget-object v0, p0, LLa/y;->f:LLa/A;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 6
    .line 7
    check-cast v1, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;->showLoadingView(Z)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p1}, Lya/a;->g()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    const/4 v0, 0x0

    .line 28
    invoke-static {v2, p1, v0}, LPa/i0;->C(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :cond_0
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 37
    .line 38
    check-cast v0, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;

    .line 39
    .line 40
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/RiskControlCheckOtcContact$View;->showErrorMessage(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method
