.class public final Lj5/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lj5/c;


# direct methods
.method public constructor <init>(Lj5/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lj5/a;->a:Lj5/c;

    .line 5
    .line 6
    return-void
.end method
