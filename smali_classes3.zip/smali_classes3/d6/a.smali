.class public final Ld6/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static texture_fragment:I = 0x7f130029

.field public static texture_vertex:I = 0x7f13002a


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
