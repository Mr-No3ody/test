.class public final synthetic Lc9/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, Lc9/a;->a:I

    iput-object p1, p0, Lc9/a;->b:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 8

    .line 1
    const/4 p1, 0x0

    .line 2
    iget v0, p0, Lc9/a;->a:I

    .line 3
    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    sget v0, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;->w:I

    .line 8
    .line 9
    iget-object v2, p0, Lc9/a;->b:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;

    .line 10
    .line 11
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    invoke-static {}, LC0/G;->A()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    :cond_0
    :goto_0
    move-object v6, p1

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    invoke-virtual {v2}, Lcom/transsnet/palmpay/account/ui/fragment/verify/BaseVerifyAccountFragment;->w()Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountActivity;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-virtual {v0}, Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountActivity;->q()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    goto :goto_0

    .line 34
    :goto_1
    sget-object p1, LPa/g0;->h:LPa/e0;

    .line 35
    .line 36
    invoke-virtual {p1}, LPa/e0;->getInstance()LPa/g0;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    iget v3, v2, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;->t:I

    .line 41
    .line 42
    iget-object v5, v2, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;->o:Lca/d;

    .line 43
    .line 44
    const/4 v7, 0x1

    .line 45
    move-object v4, v2

    .line 46
    invoke-static/range {v1 .. v7}, LPa/g0;->f(LPa/g0;Lcom/transsnet/palmpay/core/base/BaseFragment;ILcom/transsnet/palmpay/core/util/ScanFaceLogicUtil$IScanFaceResultCallBack;Lca/d;Ljava/lang/String;Z)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :pswitch_0
    iget-object v0, p0, Lc9/a;->b:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;

    .line 51
    .line 52
    iget-boolean v1, v0, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountFaceFragment;->v:Z

    .line 53
    .line 54
    if-eqz v1, :cond_2

    .line 55
    .line 56
    new-instance v1, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;

    .line 57
    .line 58
    invoke-direct {v1}, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;-><init>()V

    .line 59
    .line 60
    .line 61
    iget-object v2, v0, Lcom/transsnet/palmpay/account/ui/fragment/verify/BaseVerifyAccountFragment;->j:Ljava/lang/String;

    .line 62
    .line 63
    iput-object v2, v1, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;->flowId:Ljava/lang/String;

    .line 64
    .line 65
    const/4 v2, 0x5

    .line 66
    iput v2, v1, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;->verifyMethod:I

    .line 67
    .line 68
    new-instance v2, Ljava/util/HashMap;

    .line 69
    .line 70
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 71
    .line 72
    .line 73
    iput-object v2, v1, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;->verifyParams:Ljava/util/HashMap;

    .line 74
    .line 75
    const-string v3, "verifyParams"

    .line 76
    .line 77
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    const-string v4, "faceToken"

    .line 81
    .line 82
    invoke-virtual {v2, v4, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    iget-object p1, v1, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;->verifyParams:Ljava/util/HashMap;

    .line 86
    .line 87
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 91
    .line 92
    const-string v3, "other"

    .line 93
    .line 94
    invoke-interface {p1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    invoke-virtual {v0}, Lcom/transsnet/palmpay/account/ui/fragment/verify/BaseVerifyAccountFragment;->w()Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountActivity;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    if-eqz p1, :cond_2

    .line 102
    .line 103
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountActivity;->p(Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;)V

    .line 104
    .line 105
    .line 106
    :cond_2
    return-void

    .line 107
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
