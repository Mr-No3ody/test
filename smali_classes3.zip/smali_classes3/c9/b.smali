.class public final synthetic Lc9/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, Lc9/b;->a:I

    iput-object p1, p0, Lc9/b;->b:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 7

    .line 1
    iget p1, p0, Lc9/b;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lc9/b;->b:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;

    .line 7
    .line 8
    iget-object v0, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;->o:LBc/b;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object v0, v0, LBc/b;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v0}, Lcom/palmpay/lib/ui/form/PpFormVertical;->getEditContent()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    move-object v0, v1

    .line 25
    :goto_0
    if-eqz v0, :cond_1

    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    goto :goto_1

    .line 32
    :cond_1
    const/4 v0, 0x0

    .line 33
    :goto_1
    const/16 v2, 0xb

    .line 34
    .line 35
    const/4 v3, 0x7

    .line 36
    if-ge v0, v2, :cond_3

    .line 37
    .line 38
    iget v0, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;->p:I

    .line 39
    .line 40
    if-ne v0, v3, :cond_2

    .line 41
    .line 42
    iget-object v0, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;->o:LBc/b;

    .line 43
    .line 44
    if-eqz v0, :cond_8

    .line 45
    .line 46
    iget-object v0, v0, LBc/b;->e:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v0, Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 49
    .line 50
    if-eqz v0, :cond_8

    .line 51
    .line 52
    sget v1, LF8/h;->ac_msg_nin_code_hint:I

    .line 53
    .line 54
    invoke-virtual {p1, v1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-virtual {v0, p1}, Lcom/palmpay/lib/ui/form/PpFormVertical;->setBottomText(Ljava/lang/CharSequence;)V

    .line 59
    .line 60
    .line 61
    goto :goto_3

    .line 62
    :cond_2
    iget-object v0, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;->o:LBc/b;

    .line 63
    .line 64
    if-eqz v0, :cond_8

    .line 65
    .line 66
    iget-object v0, v0, LBc/b;->e:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v0, Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 69
    .line 70
    if-eqz v0, :cond_8

    .line 71
    .line 72
    sget v1, LF8/h;->ac_msg_bvn_code_hint:I

    .line 73
    .line 74
    invoke-virtual {p1, v1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-virtual {v0, p1}, Lcom/palmpay/lib/ui/form/PpFormVertical;->setBottomText(Ljava/lang/CharSequence;)V

    .line 79
    .line 80
    .line 81
    goto :goto_3

    .line 82
    :cond_3
    new-instance v0, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;

    .line 83
    .line 84
    invoke-direct {v0}, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;-><init>()V

    .line 85
    .line 86
    .line 87
    iget-object v2, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/BaseVerifyAccountFragment;->j:Ljava/lang/String;

    .line 88
    .line 89
    iput-object v2, v0, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;->flowId:Ljava/lang/String;

    .line 90
    .line 91
    iget v2, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;->p:I

    .line 92
    .line 93
    iput v2, v0, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;->verifyMethod:I

    .line 94
    .line 95
    new-instance v2, Ljava/util/HashMap;

    .line 96
    .line 97
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 98
    .line 99
    .line 100
    iput-object v2, v0, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;->verifyParams:Ljava/util/HashMap;

    .line 101
    .line 102
    iget v4, v0, Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;->verifyMethod:I

    .line 103
    .line 104
    const/4 v5, 0x3

    .line 105
    const-string v6, "verifyParams"

    .line 106
    .line 107
    if-ne v4, v5, :cond_5

    .line 108
    .line 109
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    iget-object v3, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;->o:LBc/b;

    .line 113
    .line 114
    if-eqz v3, :cond_4

    .line 115
    .line 116
    iget-object v3, v3, LBc/b;->e:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast v3, Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 119
    .line 120
    if-eqz v3, :cond_4

    .line 121
    .line 122
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/form/PpFormVertical;->getEditContent()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    :cond_4
    const-string v3, "bvn"

    .line 127
    .line 128
    invoke-virtual {v2, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    goto :goto_2

    .line 132
    :cond_5
    if-ne v4, v3, :cond_7

    .line 133
    .line 134
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    iget-object v3, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;->o:LBc/b;

    .line 138
    .line 139
    if-eqz v3, :cond_6

    .line 140
    .line 141
    iget-object v3, v3, LBc/b;->e:Ljava/lang/Object;

    .line 142
    .line 143
    check-cast v3, Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 144
    .line 145
    if-eqz v3, :cond_6

    .line 146
    .line 147
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/form/PpFormVertical;->getEditContent()Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v1

    .line 151
    :cond_6
    const-string v3, "nin"

    .line 152
    .line 153
    invoke-virtual {v2, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    :cond_7
    :goto_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/account/ui/fragment/verify/BaseVerifyAccountFragment;->w()Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountActivity;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    if-eqz p1, :cond_8

    .line 161
    .line 162
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/account/ui/activity/VerifyAccountActivity;->p(Lcom/transsnet/palmpay/account/bean/req/CheckSecurityVerifyMethodReq;)V

    .line 163
    .line 164
    .line 165
    :cond_8
    :goto_3
    return-void

    .line 166
    :pswitch_0
    iget-object p1, p0, Lc9/b;->b:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;

    .line 167
    .line 168
    iget p1, p1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountIdFragment;->p:I

    .line 169
    .line 170
    const/4 v0, 0x3

    .line 171
    const-string v1, "#"

    .line 172
    .line 173
    if-ne p1, v0, :cond_9

    .line 174
    .line 175
    invoke-static {v1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    new-instance v0, Ljava/lang/StringBuilder;

    .line 180
    .line 181
    const-string v1, "*565*0"

    .line 182
    .line 183
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 187
    .line 188
    .line 189
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    invoke-static {p1}, Lcom/transsnet/palmpay/util/PhoneUtils;->dial(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    goto :goto_4

    .line 197
    :cond_9
    const/4 v0, 0x7

    .line 198
    if-ne p1, v0, :cond_a

    .line 199
    .line 200
    invoke-static {v1}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object p1

    .line 204
    new-instance v0, Ljava/lang/StringBuilder;

    .line 205
    .line 206
    const-string v1, "*346"

    .line 207
    .line 208
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 212
    .line 213
    .line 214
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object p1

    .line 218
    invoke-static {p1}, Lcom/transsnet/palmpay/util/PhoneUtils;->dial(Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    :cond_a
    :goto_4
    return-void

    .line 222
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
