.class public final synthetic Lc9/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;
.implements Lcom/transsnet/palmpay/custom_view/PinEntryView$OnPinEnteredListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lc9/c;->a:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onPinEntered(Ljava/lang/String;)V
    .locals 4

    .line 1
    sget v0, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->H:I

    .line 2
    .line 3
    const-string v0, "code"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    iget-object v1, p0, Lc9/c;->a:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;

    .line 13
    .line 14
    if-nez v0, :cond_1

    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    const/4 v2, 0x4

    .line 21
    if-ge v0, v2, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v0, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;

    .line 25
    .line 26
    invoke-direct {v0}, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;-><init>()V

    .line 27
    .line 28
    .line 29
    iget v3, v1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->B:I

    .line 30
    .line 31
    iput v3, v0, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->businessType:I

    .line 32
    .line 33
    iget-object v3, v1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->w:Ljava/lang/String;

    .line 34
    .line 35
    iput-object v3, v0, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->phoneNo:Ljava/lang/String;

    .line 36
    .line 37
    iput-object p1, v0, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->smsCode:Ljava/lang/String;

    .line 38
    .line 39
    iput v2, v0, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->codeCount:I

    .line 40
    .line 41
    iget-object p1, v1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->v:Ljava/lang/String;

    .line 42
    .line 43
    iput-object p1, v0, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->email:Ljava/lang/String;

    .line 44
    .line 45
    iget-object p1, v1, Lcom/transsnet/palmpay/core/base/BaseMVPFragment;->i:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 46
    .line 47
    check-cast p1, Ld9/n0;

    .line 48
    .line 49
    if-eqz p1, :cond_2

    .line 50
    .line 51
    invoke-virtual {p1, v0}, Ld9/n0;->getSmsToken(Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :cond_1
    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    if-lez p1, :cond_2

    .line 60
    .line 61
    iget-object p1, v1, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->o:LBc/d;

    .line 62
    .line 63
    if-eqz p1, :cond_2

    .line 64
    .line 65
    iget-object p1, p1, LBc/d;->d:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast p1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;

    .line 68
    .line 69
    iget-object p1, p1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->f:Landroid/widget/TextView;

    .line 70
    .line 71
    if-eqz p1, :cond_2

    .line 72
    .line 73
    const/16 v0, 0x8

    .line 74
    .line 75
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 76
    .line 77
    .line 78
    :cond_2
    return-void
.end method

.method public onSend(IILjava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lc9/c;->a:Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;

    .line 2
    .line 3
    iput p2, v0, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->t:I

    .line 4
    .line 5
    const/4 p2, 0x4

    .line 6
    if-ne p1, p2, :cond_1

    .line 7
    .line 8
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    if-nez p2, :cond_1

    .line 13
    .line 14
    invoke-static {p3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    iput-object p3, v0, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->p:Ljava/lang/String;

    .line 18
    .line 19
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    iget p2, v0, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->t:I

    .line 24
    .line 25
    iget-object p3, v0, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->p:Ljava/lang/String;

    .line 26
    .line 27
    const/16 v1, 0x2e4

    .line 28
    .line 29
    invoke-static {p1, p2, p3, v1, v0}, LPa/r0;->j(Landroidx/fragment/app/E;ILjava/lang/String;ILcom/transsnet/palmpay/core/util/UssdUtils$UssdResponseCallback;)Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_0

    .line 34
    .line 35
    const/4 p1, 0x1

    .line 36
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 37
    .line 38
    .line 39
    :cond_0
    return-void

    .line 40
    :cond_1
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/account/ui/fragment/verify/VerifyAccountOtpFragment;->B(I)V

    .line 41
    .line 42
    .line 43
    return-void
.end method
