.class public abstract Lk5/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lk5/f;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lk5/f;

    .line 2
    .line 3
    invoke-direct {v0}, Lk5/f;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lk5/e;->a:Lk5/f;

    .line 7
    .line 8
    return-void
.end method
