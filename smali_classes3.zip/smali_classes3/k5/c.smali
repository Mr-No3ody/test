.class public final Lk5/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;

.field public final d:I

.field public final e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LN2/a;Lcom/facebook/fresco/animation/backend/AnimationBackend;Lcom/facebook/fresco/animation/bitmap/BitmapFrameCache;II)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lk5/c;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 3
    iput-object p2, p0, Lk5/c;->c:Ljava/lang/Object;

    .line 4
    iput-object p3, p0, Lk5/c;->b:Ljava/lang/Object;

    .line 5
    iput p4, p0, Lk5/c;->d:I

    .line 6
    iput p5, p0, Lk5/c;->e:I

    return-void
.end method

.method public synthetic constructor <init>(Lk5/d;Lk5/g;[IIII)V
    .locals 0

    .line 1
    iput p6, p0, Lk5/c;->a:I

    iput-object p1, p0, Lk5/c;->f:Ljava/lang/Object;

    iput-object p2, p0, Lk5/c;->b:Ljava/lang/Object;

    iput-object p3, p0, Lk5/c;->c:Ljava/lang/Object;

    iput p4, p0, Lk5/c;->d:I

    iput p5, p0, Lk5/c;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(II)Z
    .locals 7

    .line 1
    iget-object v0, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LN2/a;

    .line 4
    .line 5
    iget-object v1, p0, Lk5/c;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lcom/facebook/fresco/animation/backend/AnimationBackend;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x1

    .line 11
    const/4 v4, -0x1

    .line 12
    const/4 v5, 0x2

    .line 13
    const/4 v6, 0x0

    .line 14
    if-eq p2, v3, :cond_1

    .line 15
    .line 16
    if-eq p2, v5, :cond_0

    .line 17
    .line 18
    goto :goto_1

    .line 19
    :cond_0
    :try_start_0
    iget-object p2, v0, LN2/a;->a:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p2, Lc3/b;

    .line 22
    .line 23
    invoke-interface {v1}, Lcom/facebook/fresco/animation/backend/AnimationBackend;->getIntrinsicWidth()I

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    invoke-interface {v1}, Lcom/facebook/fresco/animation/backend/AnimationBackend;->getIntrinsicHeight()I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    iget-object v5, v0, LN2/a;->c:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v5, Landroid/graphics/Bitmap$Config;

    .line 34
    .line 35
    invoke-virtual {p2, v3, v1, v5}, Lc3/b;->a(IILandroid/graphics/Bitmap$Config;)Lcom/facebook/common/references/CloseableReference;

    .line 36
    .line 37
    .line 38
    move-result-object p2
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    move v5, v4

    .line 40
    :goto_0
    move-object v6, p2

    .line 41
    goto :goto_2

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    goto :goto_4

    .line 44
    :catch_0
    move-exception p1

    .line 45
    :try_start_1
    const-class p2, LN2/a;

    .line 46
    .line 47
    const-string v0, "Failed to create frame bitmap"

    .line 48
    .line 49
    invoke-static {p2, v0, p1}, Lp2/a;->t(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Exception;)V

    .line 50
    .line 51
    .line 52
    :goto_1
    return v2

    .line 53
    :cond_1
    iget-object p2, p0, Lk5/c;->b:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast p2, Lcom/facebook/fresco/animation/bitmap/BitmapFrameCache;

    .line 56
    .line 57
    invoke-interface {v1}, Lcom/facebook/fresco/animation/backend/AnimationBackend;->getIntrinsicWidth()I

    .line 58
    .line 59
    .line 60
    move-result v3

    .line 61
    invoke-interface {v1}, Lcom/facebook/fresco/animation/backend/AnimationBackend;->getIntrinsicHeight()I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    invoke-interface {p2, p1, v3, v1}, Lcom/facebook/fresco/animation/bitmap/BitmapFrameCache;->getBitmapToReuseForFrame(III)Lcom/facebook/common/references/CloseableReference;

    .line 66
    .line 67
    .line 68
    move-result-object p2

    .line 69
    goto :goto_0

    .line 70
    :goto_2
    invoke-static {v6}, Lcom/facebook/common/references/CloseableReference;->h(Lcom/facebook/common/references/CloseableReference;)Z

    .line 71
    .line 72
    .line 73
    move-result p2

    .line 74
    if-nez p2, :cond_2

    .line 75
    .line 76
    goto :goto_3

    .line 77
    :cond_2
    iget-object p2, v0, LN2/a;->b:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast p2, LO2/a;

    .line 80
    .line 81
    invoke-virtual {v6}, Lcom/facebook/common/references/CloseableReference;->f()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    check-cast v0, Landroid/graphics/Bitmap;

    .line 86
    .line 87
    invoke-virtual {p2, p1, v0}, LO2/a;->renderFrame(ILandroid/graphics/Bitmap;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 88
    .line 89
    .line 90
    :goto_3
    invoke-static {v6}, Lcom/facebook/common/references/CloseableReference;->d(Lcom/facebook/common/references/CloseableReference;)V

    .line 91
    .line 92
    .line 93
    if-ne v5, v4, :cond_3

    .line 94
    .line 95
    return v2

    .line 96
    :cond_3
    invoke-virtual {p0, p1, v5}, Lk5/c;->a(II)Z

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    return p1

    .line 101
    :goto_4
    invoke-static {v6}, Lcom/facebook/common/references/CloseableReference;->d(Lcom/facebook/common/references/CloseableReference;)V

    .line 102
    .line 103
    .line 104
    throw p1
.end method

.method public final run()V
    .locals 5

    .line 1
    iget v0, p0, Lk5/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    :try_start_0
    iget-object v0, p0, Lk5/c;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lcom/facebook/fresco/animation/bitmap/BitmapFrameCache;

    .line 9
    .line 10
    iget v1, p0, Lk5/c;->d:I

    .line 11
    .line 12
    invoke-interface {v0, v1}, Lcom/facebook/fresco/animation/bitmap/BitmapFrameCache;->contains(I)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    const-class v0, LN2/a;

    .line 19
    .line 20
    const-string v1, "Frame %d is cached already."

    .line 21
    .line 22
    iget v2, p0, Lk5/c;->d:I

    .line 23
    .line 24
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-static {v0, v1, v2}, Lp2/a;->o(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v0, LN2/a;

    .line 34
    .line 35
    iget-object v0, v0, LN2/a;->e:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v0, Landroid/util/SparseArray;

    .line 38
    .line 39
    monitor-enter v0

    .line 40
    :try_start_1
    iget-object v1, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v1, LN2/a;

    .line 43
    .line 44
    iget-object v1, v1, LN2/a;->e:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v1, Landroid/util/SparseArray;

    .line 47
    .line 48
    iget v2, p0, Lk5/c;->e:I

    .line 49
    .line 50
    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->remove(I)V

    .line 51
    .line 52
    .line 53
    monitor-exit v0

    .line 54
    goto :goto_1

    .line 55
    :catchall_0
    move-exception v1

    .line 56
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 57
    throw v1

    .line 58
    :catchall_1
    move-exception v0

    .line 59
    goto :goto_2

    .line 60
    :cond_0
    :try_start_2
    iget v0, p0, Lk5/c;->d:I

    .line 61
    .line 62
    const/4 v1, 0x1

    .line 63
    invoke-virtual {p0, v0, v1}, Lk5/c;->a(II)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_1

    .line 68
    .line 69
    const-class v0, LN2/a;

    .line 70
    .line 71
    const-string v1, "Prepared frame frame %d."

    .line 72
    .line 73
    iget v2, p0, Lk5/c;->d:I

    .line 74
    .line 75
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    invoke-static {v0, v1, v2}, Lp2/a;->o(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_1
    const-class v0, LN2/a;

    .line 84
    .line 85
    const-string v1, "Could not prepare frame %d."

    .line 86
    .line 87
    iget v2, p0, Lk5/c;->d:I

    .line 88
    .line 89
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    invoke-static {v0, v1, v2}, Lp2/a;->g(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 98
    .line 99
    .line 100
    :goto_0
    iget-object v0, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v0, LN2/a;

    .line 103
    .line 104
    iget-object v0, v0, LN2/a;->e:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v0, Landroid/util/SparseArray;

    .line 107
    .line 108
    monitor-enter v0

    .line 109
    :try_start_3
    iget-object v1, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 110
    .line 111
    check-cast v1, LN2/a;

    .line 112
    .line 113
    iget-object v1, v1, LN2/a;->e:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v1, Landroid/util/SparseArray;

    .line 116
    .line 117
    iget v2, p0, Lk5/c;->e:I

    .line 118
    .line 119
    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->remove(I)V

    .line 120
    .line 121
    .line 122
    monitor-exit v0

    .line 123
    :goto_1
    return-void

    .line 124
    :catchall_2
    move-exception v1

    .line 125
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 126
    throw v1

    .line 127
    :goto_2
    iget-object v1, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 128
    .line 129
    check-cast v1, LN2/a;

    .line 130
    .line 131
    iget-object v1, v1, LN2/a;->e:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast v1, Landroid/util/SparseArray;

    .line 134
    .line 135
    monitor-enter v1

    .line 136
    :try_start_4
    iget-object v2, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v2, LN2/a;

    .line 139
    .line 140
    iget-object v2, v2, LN2/a;->e:Ljava/lang/Object;

    .line 141
    .line 142
    check-cast v2, Landroid/util/SparseArray;

    .line 143
    .line 144
    iget v3, p0, Lk5/c;->e:I

    .line 145
    .line 146
    invoke-virtual {v2, v3}, Landroid/util/SparseArray;->remove(I)V

    .line 147
    .line 148
    .line 149
    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 150
    throw v0

    .line 151
    :catchall_3
    move-exception v0

    .line 152
    :try_start_5
    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 153
    throw v0

    .line 154
    :pswitch_0
    iget-object v0, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 155
    .line 156
    check-cast v0, Lk5/d;

    .line 157
    .line 158
    iget-object v1, v0, Lk5/d;->e:Ljava/nio/MappedByteBuffer;

    .line 159
    .line 160
    iget-object v2, p0, Lk5/c;->b:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast v2, Lk5/g;

    .line 163
    .line 164
    invoke-virtual {v2, v1}, Lk5/g;->a(Ljava/nio/ByteBuffer;)Ljava/io/Serializable;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    check-cast v1, Ljava/lang/Integer;

    .line 169
    .line 170
    if-eqz v1, :cond_2

    .line 171
    .line 172
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 173
    .line 174
    .line 175
    move-result v1

    .line 176
    goto :goto_3

    .line 177
    :cond_2
    iget v1, p0, Lk5/c;->d:I

    .line 178
    .line 179
    :goto_3
    iget v3, p0, Lk5/c;->e:I

    .line 180
    .line 181
    sub-int/2addr v1, v3

    .line 182
    iget-object v3, p0, Lk5/c;->c:Ljava/lang/Object;

    .line 183
    .line 184
    check-cast v3, [I

    .line 185
    .line 186
    const/4 v4, 0x0

    .line 187
    aput v1, v3, v4

    .line 188
    .line 189
    iget-object v0, v0, Lk5/d;->e:Ljava/nio/MappedByteBuffer;

    .line 190
    .line 191
    invoke-virtual {v2, v1, v0}, Lk5/g;->b(ILjava/nio/ByteBuffer;)V

    .line 192
    .line 193
    .line 194
    return-void

    .line 195
    :pswitch_1
    iget-object v0, p0, Lk5/c;->f:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast v0, Lk5/d;

    .line 198
    .line 199
    iget-object v1, v0, Lk5/d;->e:Ljava/nio/MappedByteBuffer;

    .line 200
    .line 201
    iget-object v2, p0, Lk5/c;->b:Ljava/lang/Object;

    .line 202
    .line 203
    check-cast v2, Lk5/g;

    .line 204
    .line 205
    invoke-virtual {v2, v1}, Lk5/g;->a(Ljava/nio/ByteBuffer;)Ljava/io/Serializable;

    .line 206
    .line 207
    .line 208
    move-result-object v1

    .line 209
    check-cast v1, Ljava/lang/Integer;

    .line 210
    .line 211
    if-eqz v1, :cond_3

    .line 212
    .line 213
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 214
    .line 215
    .line 216
    move-result v1

    .line 217
    goto :goto_4

    .line 218
    :cond_3
    iget v1, p0, Lk5/c;->d:I

    .line 219
    .line 220
    :goto_4
    iget v3, p0, Lk5/c;->e:I

    .line 221
    .line 222
    add-int/2addr v1, v3

    .line 223
    iget-object v3, p0, Lk5/c;->c:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v3, [I

    .line 226
    .line 227
    const/4 v4, 0x0

    .line 228
    aput v1, v3, v4

    .line 229
    .line 230
    iget-object v0, v0, Lk5/d;->e:Ljava/nio/MappedByteBuffer;

    .line 231
    .line 232
    invoke-virtual {v2, v1, v0}, Lk5/g;->b(ILjava/nio/ByteBuffer;)V

    .line 233
    .line 234
    .line 235
    return-void

    .line 236
    nop

    .line 237
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
