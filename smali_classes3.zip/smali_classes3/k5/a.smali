.class public final Lk5/a;
.super Ljava/lang/Thread;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lk5/d;


# direct methods
.method public constructor <init>(Lk5/d;)V
    .locals 1

    .line 1
    iput-object p1, p0, Lk5/a;->a:Lk5/d;

    .line 2
    .line 3
    const-string/jumbo p1, "\u200bcom.growingio.android.sdk.track.ipc.MultiProcessDataSharer$1"

    .line 4
    .line 5
    .line 6
    const-string v0, "MultiProcessDataSharer-load"

    .line 7
    .line 8
    invoke-static {v0, p1}, Lcom/didiglobal/booster/instrument/ShadowThread;->makeThreadName(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-direct {p0, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 11

    .line 1
    iget-object v1, p0, Lk5/a;->a:Lk5/d;

    .line 2
    .line 3
    const-string v0, "loadFromDisk mLoaded is "

    .line 4
    .line 5
    monitor-enter v1

    .line 6
    :try_start_0
    const-string v2, "MultiProcessDataSharer"

    .line 7
    .line 8
    new-instance v3, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-boolean v0, v1, Lk5/d;->d:Z

    .line 14
    .line 15
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    const/4 v3, 0x0

    .line 23
    new-array v4, v3, [Ljava/lang/Object;

    .line 24
    .line 25
    invoke-static {v2, v0, v4}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iget-boolean v0, v1, Lk5/d;->d:Z

    .line 29
    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    monitor-exit v1

    .line 33
    return-void

    .line 34
    :catchall_0
    move-exception v0

    .line 35
    goto :goto_1

    .line 36
    :cond_0
    iget-object v0, v1, Lk5/d;->a:Landroid/content/Context;

    .line 37
    .line 38
    iget-object v2, v1, Lk5/d;->b:Ljava/lang/String;

    .line 39
    .line 40
    invoke-virtual {v0, v2}, Landroid/content/Context;->getFileStreamPath(Ljava/lang/String;)Ljava/io/File;

    .line 41
    .line 42
    .line 43
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    :try_start_1
    new-instance v2, Ljava/io/RandomAccessFile;

    .line 45
    .line 46
    const-string v4, "rw"

    .line 47
    .line 48
    invoke-direct {v2, v0, v4}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v2}, Ljava/io/RandomAccessFile;->getChannel()Ljava/nio/channels/FileChannel;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    iput-object v5, v1, Lk5/d;->f:Ljava/nio/channels/FileChannel;

    .line 56
    .line 57
    sget-object v6, Ljava/nio/channels/FileChannel$MapMode;->READ_WRITE:Ljava/nio/channels/FileChannel$MapMode;

    .line 58
    .line 59
    iget v0, v1, Lk5/d;->c:I

    .line 60
    .line 61
    int-to-long v7, v0

    .line 62
    const-wide/16 v9, 0x400

    .line 63
    .line 64
    mul-long/2addr v9, v7

    .line 65
    const-wide/16 v7, 0x0

    .line 66
    .line 67
    invoke-virtual/range {v5 .. v10}, Ljava/nio/channels/FileChannel;->map(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    iput-object v0, v1, Lk5/d;->e:Ljava/nio/MappedByteBuffer;

    .line 72
    .line 73
    invoke-virtual {v1}, Lk5/d;->c()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 74
    .line 75
    .line 76
    goto :goto_0

    .line 77
    :catch_0
    move-exception v0

    .line 78
    :try_start_2
    const-string v2, "MultiProcessDataSharer"

    .line 79
    .line 80
    invoke-static {v2, v0}, Ln5/h;->b(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 81
    .line 82
    .line 83
    :goto_0
    const-string v0, "MultiProcessDataSharer"

    .line 84
    .line 85
    const-string v2, "loadFromDisk successfully "

    .line 86
    .line 87
    new-array v3, v3, [Ljava/lang/Object;

    .line 88
    .line 89
    invoke-static {v0, v2, v3}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    const/4 v0, 0x1

    .line 93
    iput-boolean v0, v1, Lk5/d;->d:Z

    .line 94
    .line 95
    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    .line 96
    .line 97
    .line 98
    monitor-exit v1

    .line 99
    return-void

    .line 100
    :goto_1
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 101
    throw v0
.end method
