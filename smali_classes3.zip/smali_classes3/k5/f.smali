.class public final Lk5/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lk5/d;

.field public final b:LE2/a;

.field public final c:Landroid/content/Context;

.field public d:I

.field public e:J


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lk5/f;->d:I

    .line 6
    .line 7
    const-wide/16 v0, 0x0

    .line 8
    .line 9
    iput-wide v0, p0, Lk5/f;->e:J

    .line 10
    .line 11
    invoke-static {}, Lcom/growingio/android/sdk/d;->a()Lcom/growingio/android/sdk/d;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, Lk5/f;->c:Landroid/content/Context;

    .line 20
    .line 21
    new-instance v1, Lk5/d;

    .line 22
    .line 23
    invoke-direct {v1, v0}, Lk5/d;-><init>(Landroid/content/Context;)V

    .line 24
    .line 25
    .line 26
    iput-object v1, p0, Lk5/f;->a:Lk5/d;

    .line 27
    .line 28
    new-instance v1, LE2/a;

    .line 29
    .line 30
    const-class v2, Lk5/f;

    .line 31
    .line 32
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    invoke-direct {v1, v0, v2}, LE2/a;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    iput-object v1, p0, Lk5/f;->b:LE2/a;

    .line 40
    .line 41
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 2

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "LOGIN_USER_ID"

    .line 7
    .line 8
    invoke-virtual {v0, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    const-string p1, "LOGIN_USER_KEY"

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    invoke-virtual {v0, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    iget-object p1, p0, Lk5/f;->a:Lk5/d;

    .line 18
    .line 19
    invoke-virtual {p1, v0}, Lk5/d;->putMultiString(Ljava/util/Map;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
