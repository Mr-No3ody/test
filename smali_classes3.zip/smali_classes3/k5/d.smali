.class public final Lk5/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/growingio/android/sdk/track/ipc/IDataSharer;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ljava/lang/String;

.field public final c:I

.field public volatile d:Z

.field public e:Ljava/nio/MappedByteBuffer;

.field public f:Ljava/nio/channels/FileChannel;

.field public final g:Ljava/util/HashMap;

.field public h:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/HashMap;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lk5/d;->g:Ljava/util/HashMap;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput v0, p0, Lk5/d;->h:I

    .line 13
    .line 14
    iput-object p1, p0, Lk5/d;->a:Landroid/content/Context;

    .line 15
    .line 16
    const-string p1, "PersistentSharerDataProvider.shared"

    .line 17
    .line 18
    iput-object p1, p0, Lk5/d;->b:Ljava/lang/String;

    .line 19
    .line 20
    const/16 p1, 0x32

    .line 21
    .line 22
    iput p1, p0, Lk5/d;->c:I

    .line 23
    .line 24
    iput-boolean v0, p0, Lk5/d;->d:Z

    .line 25
    .line 26
    monitor-enter p0

    .line 27
    :try_start_0
    iput-boolean v0, p0, Lk5/d;->d:Z

    .line 28
    .line 29
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    new-instance p1, Lk5/a;

    .line 31
    .line 32
    invoke-direct {p1, p0}, Lk5/a;-><init>(Lk5/d;)V

    .line 33
    .line 34
    .line 35
    const-string/jumbo v0, "\u200bcom.growingio.android.sdk.track.ipc.MultiProcessDataSharer"

    .line 36
    .line 37
    .line 38
    invoke-static {p1, v0}, Lcom/didiglobal/booster/instrument/ShadowThread;->setThreadName(Ljava/lang/Thread;Ljava/lang/String;)Ljava/lang/Thread;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :catchall_0
    move-exception p1

    .line 47
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 48
    throw p1
.end method


# virtual methods
.method public final declared-synchronized a()V
    .locals 4

    .line 1
    monitor-enter p0

    .line 2
    :goto_0
    :try_start_0
    iget-boolean v0, p0, Lk5/d;->d:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 3
    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    :try_start_1
    const-string v1, "MultiProcessDataSharer"

    .line 8
    .line 9
    const-string v2, "awaitLoadedLocked"

    .line 10
    .line 11
    new-array v3, v0, [Ljava/lang/Object;

    .line 12
    .line 13
    invoke-static {v1, v2, v3}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Ljava/lang/Object;->wait()V

    .line 17
    .line 18
    .line 19
    const-string v1, "MultiProcessDataSharer"

    .line 20
    .line 21
    const-string v2, "awaitLoadedLocked end"

    .line 22
    .line 23
    new-array v3, v0, [Ljava/lang/Object;

    .line 24
    .line 25
    invoke-static {v1, v2, v3}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 26
    .line 27
    .line 28
    goto :goto_0

    .line 29
    :catchall_0
    move-exception v0

    .line 30
    goto :goto_1

    .line 31
    :catch_0
    move-exception v1

    .line 32
    :try_start_2
    const-string v2, "MultiProcessDataSharer"

    .line 33
    .line 34
    const-string v3, "awaitLoadedLocked interrupted"

    .line 35
    .line 36
    new-array v0, v0, [Ljava/lang/Object;

    .line 37
    .line 38
    invoke-static {v2, v1, v3, v0}, Ln5/h;->d(Ljava/lang/String;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 46
    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_0
    monitor-exit p0

    .line 50
    return-void

    .line 51
    :goto_1
    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 52
    throw v0
.end method

.method public final b(Ljava/lang/String;)Ljava/lang/Object;
    .locals 13

    .line 1
    iget-object v0, p0, Lk5/d;->g:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    move-object v5, v0

    .line 8
    check-cast v5, Lk5/g;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    if-eqz v5, :cond_0

    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    new-array v4, p1, [Ljava/lang/Object;

    .line 15
    .line 16
    new-instance v1, LCe/H;

    .line 17
    .line 18
    const/16 v2, 0x15

    .line 19
    .line 20
    const/4 v6, 0x0

    .line 21
    move-object v3, p0

    .line 22
    invoke-direct/range {v1 .. v6}, LCe/H;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 23
    .line 24
    .line 25
    iget p1, v5, Lk5/g;->a:I

    .line 26
    .line 27
    int-to-long v8, p1

    .line 28
    const-wide/16 v10, 0x400

    .line 29
    .line 30
    move-object v6, p0

    .line 31
    move-object v7, v1

    .line 32
    invoke-virtual/range {v6 .. v11}, Lk5/d;->d(Ljava/lang/Runnable;JJ)V

    .line 33
    .line 34
    .line 35
    aget-object p1, v4, v0

    .line 36
    .line 37
    return-object p1

    .line 38
    :cond_0
    const/4 v1, 0x0

    .line 39
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v11

    .line 43
    new-instance v7, LCe/H;

    .line 44
    .line 45
    const/16 v8, 0x14

    .line 46
    .line 47
    const/4 v12, 0x0

    .line 48
    move-object v9, p0

    .line 49
    move-object v10, p1

    .line 50
    invoke-direct/range {v7 .. v12}, LCe/H;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 51
    .line 52
    .line 53
    move-object p1, v11

    .line 54
    const-wide/16 v9, 0x0

    .line 55
    .line 56
    const-wide v11, 0x7fffffffffffffffL

    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    move-object v8, v7

    .line 62
    move-object v7, p0

    .line 63
    invoke-virtual/range {v7 .. v12}, Lk5/d;->d(Ljava/lang/Runnable;JJ)V

    .line 64
    .line 65
    .line 66
    aget-object p1, p1, v0

    .line 67
    .line 68
    return-object p1
.end method

.method public final c()V
    .locals 6

    .line 1
    iget-object v0, p0, Lk5/d;->g:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/HashMap;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    iget v2, p0, Lk5/d;->c:I

    .line 8
    .line 9
    sub-int/2addr v2, v1

    .line 10
    const/4 v1, 0x0

    .line 11
    :goto_0
    if-ge v1, v2, :cond_0

    .line 12
    .line 13
    :try_start_0
    new-instance v3, Lk5/g;

    .line 14
    .line 15
    iget-object v4, p0, Lk5/d;->e:Ljava/nio/MappedByteBuffer;

    .line 16
    .line 17
    iget v5, p0, Lk5/d;->h:I

    .line 18
    .line 19
    invoke-direct {v3, v4, v5}, Lk5/g;-><init>(Ljava/nio/ByteBuffer;I)V

    .line 20
    .line 21
    .line 22
    iget-object v4, v3, Lk5/g;->b:Ljava/lang/String;

    .line 23
    .line 24
    invoke-virtual {v0, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    iget v3, p0, Lk5/d;->h:I

    .line 28
    .line 29
    add-int/lit16 v3, v3, 0x400

    .line 30
    .line 31
    iput v3, p0, Lk5/d;->h:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    .line 33
    add-int/lit8 v1, v1, 0x1

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :catch_0
    :cond_0
    return-void
.end method

.method public final d(Ljava/lang/Runnable;JJ)V
    .locals 9

    .line 1
    const-string v1, "MultiProcessDataSharer"

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    :try_start_0
    iget-object v3, p0, Lk5/d;->f:Ljava/nio/channels/FileChannel;

    .line 5
    .line 6
    const/4 v8, 0x0

    .line 7
    move-wide v4, p2

    .line 8
    move-wide v6, p4

    .line 9
    invoke-virtual/range {v3 .. v8}, Ljava/nio/channels/FileChannel;->lock(JJZ)Ljava/nio/channels/FileLock;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    invoke-interface {p1}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    .line 15
    .line 16
    if-eqz v2, :cond_0

    .line 17
    .line 18
    :try_start_1
    invoke-virtual {v2}, Ljava/nio/channels/FileLock;->release()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :catch_0
    move-exception v0

    .line 23
    move-object p1, v0

    .line 24
    invoke-static {v1, p1}, Ln5/h;->b(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :catchall_0
    move-exception v0

    .line 29
    move-object p1, v0

    .line 30
    goto :goto_1

    .line 31
    :catch_1
    move-exception v0

    .line 32
    move-object p1, v0

    .line 33
    :try_start_2
    invoke-static {v1, p1}, Ln5/h;->b(Ljava/lang/String;Ljava/lang/Exception;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 34
    .line 35
    .line 36
    if-eqz v2, :cond_0

    .line 37
    .line 38
    :try_start_3
    invoke-virtual {v2}, Ljava/nio/channels/FileLock;->release()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 39
    .line 40
    .line 41
    :cond_0
    :goto_0
    return-void

    .line 42
    :goto_1
    if-eqz v2, :cond_1

    .line 43
    .line 44
    :try_start_4
    invoke-virtual {v2}, Ljava/nio/channels/FileLock;->release()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    .line 45
    .line 46
    .line 47
    goto :goto_2

    .line 48
    :catch_2
    move-exception v0

    .line 49
    move-object p2, v0

    .line 50
    invoke-static {v1, p2}, Ln5/h;->b(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    :goto_2
    throw p1
.end method

.method public final e(ILjava/lang/Object;Ljava/lang/String;)V
    .locals 6

    .line 1
    iget-object v1, p0, Lk5/d;->g:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {v1, p3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Lk5/g;

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    new-instance v0, Lcom/gyf/immersionbar/h;

    .line 12
    .line 13
    const/4 v5, 0x2

    .line 14
    move v3, p1

    .line 15
    move-object v4, p2

    .line 16
    move-object v2, v1

    .line 17
    move-object v1, p0

    .line 18
    invoke-direct/range {v0 .. v5}, Lcom/gyf/immersionbar/h;-><init>(Lk5/d;Ljava/lang/Object;ILjava/lang/Object;I)V

    .line 19
    .line 20
    .line 21
    iget v1, v2, Lk5/g;->a:I

    .line 22
    .line 23
    int-to-long v2, v1

    .line 24
    const-wide/16 v4, 0x400

    .line 25
    .line 26
    move-object v1, v0

    .line 27
    move-object v0, p0

    .line 28
    invoke-virtual/range {v0 .. v5}, Lk5/d;->d(Ljava/lang/Runnable;JJ)V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :cond_0
    new-instance v0, Lcom/gyf/immersionbar/h;

    .line 33
    .line 34
    const/4 v5, 0x1

    .line 35
    move-object v1, p0

    .line 36
    move v3, p1

    .line 37
    move-object v4, p2

    .line 38
    move-object v2, p3

    .line 39
    invoke-direct/range {v0 .. v5}, Lcom/gyf/immersionbar/h;-><init>(Lk5/d;Ljava/lang/Object;ILjava/lang/Object;I)V

    .line 40
    .line 41
    .line 42
    const-wide/16 v2, 0x0

    .line 43
    .line 44
    const-wide v4, 0x7fffffffffffffffL

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    move-object v1, v0

    .line 50
    move-object v0, p0

    .line 51
    invoke-virtual/range {v0 .. v5}, Lk5/d;->d(Ljava/lang/Runnable;JJ)V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public final getAndAddInt(Ljava/lang/String;II)I
    .locals 9

    .line 1
    const-string v7, "getAndAddInt: result = "

    .line 2
    .line 3
    const-string v2, "getAndAddInt: key = "

    .line 4
    .line 5
    monitor-enter p0

    .line 6
    :try_start_0
    const-string v3, "MultiProcessDataSharer"

    .line 7
    .line 8
    new-instance v5, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    invoke-direct {v5, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    const-string v2, ", delta = "

    .line 17
    .line 18
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const-string v6, ", startValue = "

    .line 25
    .line 26
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v5, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    const/4 v8, 0x0

    .line 37
    new-array v6, v8, [Ljava/lang/Object;

    .line 38
    .line 39
    invoke-static {v3, v5, v6}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 43
    .line 44
    .line 45
    const/4 v3, 0x1

    .line 46
    move v5, v3

    .line 47
    new-array v3, v5, [I

    .line 48
    .line 49
    iget-object v6, p0, Lk5/d;->g:Ljava/util/HashMap;

    .line 50
    .line 51
    invoke-virtual {v6, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v6

    .line 55
    check-cast v6, Lk5/g;

    .line 56
    .line 57
    if-eqz v6, :cond_0

    .line 58
    .line 59
    new-instance v0, Lk5/c;

    .line 60
    .line 61
    move-object v2, v6

    .line 62
    const/4 v6, 0x0

    .line 63
    move-object v1, p0

    .line 64
    move v5, p2

    .line 65
    move v4, p3

    .line 66
    invoke-direct/range {v0 .. v6}, Lk5/c;-><init>(Lk5/d;Lk5/g;[IIII)V

    .line 67
    .line 68
    .line 69
    move-object v1, v0

    .line 70
    move-object v0, v3

    .line 71
    iget v2, v2, Lk5/g;->a:I

    .line 72
    .line 73
    int-to-long v3, v2

    .line 74
    const-wide/16 v5, 0x400

    .line 75
    .line 76
    move-object v2, v1

    .line 77
    move-object v1, p0

    .line 78
    invoke-virtual/range {v1 .. v6}, Lk5/d;->d(Ljava/lang/Runnable;JJ)V

    .line 79
    .line 80
    .line 81
    const-string v2, "MultiProcessDataSharer"

    .line 82
    .line 83
    new-instance v3, Ljava/lang/StringBuilder;

    .line 84
    .line 85
    invoke-direct {v3, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    aget v4, v0, v8

    .line 89
    .line 90
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v3

    .line 97
    new-array v4, v8, [Ljava/lang/Object;

    .line 98
    .line 99
    invoke-static {v2, v3, v4}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    aget v0, v0, v8

    .line 103
    .line 104
    monitor-exit p0

    .line 105
    return v0

    .line 106
    :catchall_0
    move-exception v0

    .line 107
    goto :goto_0

    .line 108
    :cond_0
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    invoke-virtual {p0, v5, v2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    const-string v0, "MultiProcessDataSharer"

    .line 116
    .line 117
    const-string v2, "getAndAddInt: return startValue"

    .line 118
    .line 119
    new-array v3, v8, [Ljava/lang/Object;

    .line 120
    .line 121
    invoke-static {v0, v2, v3}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    monitor-exit p0

    .line 125
    return p3

    .line 126
    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 127
    throw v0
.end method

.method public final getAndAddLong(Ljava/lang/String;JJ)J
    .locals 10

    .line 1
    move-wide v4, p4

    .line 2
    const-string v8, "getAndAddLong: result = "

    .line 3
    .line 4
    const-string v2, "getAndAddLong: key = "

    .line 5
    .line 6
    monitor-enter p0

    .line 7
    :try_start_0
    const-string v3, "MultiProcessDataSharer"

    .line 8
    .line 9
    new-instance v6, Ljava/lang/StringBuilder;

    .line 10
    .line 11
    invoke-direct {v6, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    const-string v2, ", delta = "

    .line 18
    .line 19
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v6, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v2, ", startValue = "

    .line 26
    .line 27
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v6, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    const/4 v9, 0x0

    .line 38
    new-array v6, v9, [Ljava/lang/Object;

    .line 39
    .line 40
    invoke-static {v3, v2, v6}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 44
    .line 45
    .line 46
    const/4 v2, 0x1

    .line 47
    new-array v3, v2, [J

    .line 48
    .line 49
    iget-object v2, p0, Lk5/d;->g:Ljava/util/HashMap;

    .line 50
    .line 51
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    check-cast v2, Lk5/g;

    .line 56
    .line 57
    if-eqz v2, :cond_0

    .line 58
    .line 59
    new-instance v0, Lk5/b;

    .line 60
    .line 61
    move-object v1, p0

    .line 62
    move-wide v6, p2

    .line 63
    invoke-direct/range {v0 .. v7}, Lk5/b;-><init>(Lk5/d;Lk5/g;[JJJ)V

    .line 64
    .line 65
    .line 66
    move-object v1, v0

    .line 67
    move-object v0, v3

    .line 68
    iget v2, v2, Lk5/g;->a:I

    .line 69
    .line 70
    int-to-long v3, v2

    .line 71
    const-wide/16 v5, 0x400

    .line 72
    .line 73
    move-object v2, v1

    .line 74
    move-object v1, p0

    .line 75
    invoke-virtual/range {v1 .. v6}, Lk5/d;->d(Ljava/lang/Runnable;JJ)V

    .line 76
    .line 77
    .line 78
    const-string v2, "MultiProcessDataSharer"

    .line 79
    .line 80
    new-instance v3, Ljava/lang/StringBuilder;

    .line 81
    .line 82
    invoke-direct {v3, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    aget-wide v4, v0, v9

    .line 86
    .line 87
    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v3

    .line 94
    new-array v4, v9, [Ljava/lang/Object;

    .line 95
    .line 96
    invoke-static {v2, v3, v4}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    aget-wide v2, v0, v9

    .line 100
    .line 101
    monitor-exit p0

    .line 102
    return-wide v2

    .line 103
    :catchall_0
    move-exception v0

    .line 104
    goto :goto_0

    .line 105
    :cond_0
    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 106
    .line 107
    .line 108
    move-result-object v2

    .line 109
    const/4 v3, 0x2

    .line 110
    invoke-virtual {p0, v3, v2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    const-string v0, "MultiProcessDataSharer"

    .line 114
    .line 115
    const-string v2, "getAndAddLong: return startValue"

    .line 116
    .line 117
    new-array v3, v9, [Ljava/lang/Object;

    .line 118
    .line 119
    invoke-static {v0, v2, v3}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    monitor-exit p0

    .line 123
    return-wide p4

    .line 124
    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 125
    throw v0
.end method

.method public final getAndDecrementInt(Ljava/lang/String;I)I
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-virtual {p0, p1, v0, p2}, Lk5/d;->getAndDelInt(Ljava/lang/String;II)I

    .line 3
    .line 4
    .line 5
    move-result p1

    .line 6
    return p1
.end method

.method public final getAndDelInt(Ljava/lang/String;II)I
    .locals 9

    .line 1
    const-string v7, "getAndDelInt: result = "

    .line 2
    .line 3
    const-string v2, "getAndDelInt: key = "

    .line 4
    .line 5
    monitor-enter p0

    .line 6
    :try_start_0
    const-string v3, "MultiProcessDataSharer"

    .line 7
    .line 8
    new-instance v5, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    invoke-direct {v5, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    const-string v2, ", delta = "

    .line 17
    .line 18
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const-string v6, ", startValue = "

    .line 25
    .line 26
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v5, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    const/4 v8, 0x0

    .line 37
    new-array v6, v8, [Ljava/lang/Object;

    .line 38
    .line 39
    invoke-static {v3, v5, v6}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 43
    .line 44
    .line 45
    const/4 v3, 0x1

    .line 46
    move v5, v3

    .line 47
    new-array v3, v5, [I

    .line 48
    .line 49
    iget-object v6, p0, Lk5/d;->g:Ljava/util/HashMap;

    .line 50
    .line 51
    invoke-virtual {v6, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v6

    .line 55
    check-cast v6, Lk5/g;

    .line 56
    .line 57
    if-eqz v6, :cond_0

    .line 58
    .line 59
    new-instance v0, Lk5/c;

    .line 60
    .line 61
    move-object v2, v6

    .line 62
    const/4 v6, 0x1

    .line 63
    move-object v1, p0

    .line 64
    move v5, p2

    .line 65
    move v4, p3

    .line 66
    invoke-direct/range {v0 .. v6}, Lk5/c;-><init>(Lk5/d;Lk5/g;[IIII)V

    .line 67
    .line 68
    .line 69
    move-object v1, v0

    .line 70
    move-object v0, v3

    .line 71
    iget v2, v2, Lk5/g;->a:I

    .line 72
    .line 73
    int-to-long v3, v2

    .line 74
    const-wide/16 v5, 0x400

    .line 75
    .line 76
    move-object v2, v1

    .line 77
    move-object v1, p0

    .line 78
    invoke-virtual/range {v1 .. v6}, Lk5/d;->d(Ljava/lang/Runnable;JJ)V

    .line 79
    .line 80
    .line 81
    const-string v2, "MultiProcessDataSharer"

    .line 82
    .line 83
    new-instance v3, Ljava/lang/StringBuilder;

    .line 84
    .line 85
    invoke-direct {v3, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    aget v4, v0, v8

    .line 89
    .line 90
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v3

    .line 97
    new-array v4, v8, [Ljava/lang/Object;

    .line 98
    .line 99
    invoke-static {v2, v3, v4}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    aget v0, v0, v8

    .line 103
    .line 104
    monitor-exit p0

    .line 105
    return v0

    .line 106
    :catchall_0
    move-exception v0

    .line 107
    goto :goto_0

    .line 108
    :cond_0
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    invoke-virtual {p0, v5, v2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    const-string v0, "MultiProcessDataSharer"

    .line 116
    .line 117
    const-string v2, "getAndDelInt: return startValue"

    .line 118
    .line 119
    new-array v3, v8, [Ljava/lang/Object;

    .line 120
    .line 121
    invoke-static {v0, v2, v3}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    monitor-exit p0

    .line 125
    return p3

    .line 126
    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 127
    throw v0
.end method

.method public final getAndIncrementInt(Ljava/lang/String;I)I
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-virtual {p0, p1, v0, p2}, Lk5/d;->getAndAddInt(Ljava/lang/String;II)I

    .line 3
    .line 4
    .line 5
    move-result p1

    .line 6
    return p1
.end method

.method public final getAndIncrementLong(Ljava/lang/String;J)J
    .locals 6

    .line 1
    const-wide/16 v2, 0x1

    .line 2
    .line 3
    move-object v0, p0

    .line 4
    move-object v1, p1

    .line 5
    move-wide v4, p2

    .line 6
    invoke-virtual/range {v0 .. v5}, Lk5/d;->getAndAddLong(Ljava/lang/String;JJ)J

    .line 7
    .line 8
    .line 9
    move-result-wide p1

    .line 10
    return-wide p1
.end method

.method public final getBoolean(Ljava/lang/String;Z)Z
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lk5/d;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ljava/lang/Boolean;

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 14
    .line 15
    .line 16
    move-result p2

    .line 17
    goto :goto_0

    .line 18
    :catchall_0
    move-exception p1

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    :goto_0
    monitor-exit p0

    .line 21
    return p2

    .line 22
    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    throw p1
.end method

.method public final getFloat(Ljava/lang/String;F)F
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lk5/d;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ljava/lang/Float;

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 14
    .line 15
    .line 16
    move-result p2

    .line 17
    goto :goto_0

    .line 18
    :catchall_0
    move-exception p1

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    :goto_0
    monitor-exit p0

    .line 21
    return p2

    .line 22
    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    throw p1
.end method

.method public final getInt(Ljava/lang/String;I)I
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lk5/d;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ljava/lang/Integer;

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 14
    .line 15
    .line 16
    move-result p2

    .line 17
    goto :goto_0

    .line 18
    :catchall_0
    move-exception p1

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    :goto_0
    monitor-exit p0

    .line 21
    return p2

    .line 22
    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    throw p1
.end method

.method public final getIntArray(Ljava/lang/String;Ljava/util/List;)Ljava/util/List;
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lk5/d;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ljava/util/List;

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    move-object p2, p1

    .line 14
    :cond_0
    monitor-exit p0

    .line 15
    return-object p2

    .line 16
    :catchall_0
    move-exception p1

    .line 17
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    throw p1
.end method

.method public final getLong(Ljava/lang/String;J)J
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lk5/d;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ljava/lang/Long;

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 14
    .line 15
    .line 16
    move-result-wide p2

    .line 17
    goto :goto_0

    .line 18
    :catchall_0
    move-exception p1

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    :goto_0
    monitor-exit p0

    .line 21
    return-wide p2

    .line 22
    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    throw p1
.end method

.method public final getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lk5/d;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ljava/lang/String;

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    move-object p2, p1

    .line 14
    :cond_0
    monitor-exit p0

    .line 15
    return-object p2

    .line 16
    :catchall_0
    move-exception p1

    .line 17
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    throw p1
.end method

.method public final putBoolean(Ljava/lang/String;Z)V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    const/4 v0, 0x4

    .line 10
    invoke-virtual {p0, v0, p2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    monitor-exit p0

    .line 14
    return-void

    .line 15
    :catchall_0
    move-exception p1

    .line 16
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    throw p1
.end method

.method public final putFloat(Ljava/lang/String;F)V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    const/4 v0, 0x3

    .line 10
    invoke-virtual {p0, v0, p2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    monitor-exit p0

    .line 14
    return-void

    .line 15
    :catchall_0
    move-exception p1

    .line 16
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    throw p1
.end method

.method public final putInt(Ljava/lang/String;I)V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    const/4 v0, 0x1

    .line 10
    invoke-virtual {p0, v0, p2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    monitor-exit p0

    .line 14
    return-void

    .line 15
    :catchall_0
    move-exception p1

    .line 16
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    throw p1
.end method

.method public final putIntArray(Ljava/lang/String;Ljava/util/List;)V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    const/4 v0, 0x6

    .line 6
    invoke-virtual {p0, v0, p2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    monitor-exit p0

    .line 10
    return-void

    .line 11
    :catchall_0
    move-exception p1

    .line 12
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    throw p1
.end method

.method public final putLong(Ljava/lang/String;J)V
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    const/4 p3, 0x2

    .line 10
    invoke-virtual {p0, p3, p2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    monitor-exit p0

    .line 14
    return-void

    .line 15
    :catchall_0
    move-exception p1

    .line 16
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    throw p1
.end method

.method public final putMultiString(Ljava/util/Map;)V
    .locals 7

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    new-instance v2, Landroidx/core/provider/m;

    .line 6
    .line 7
    const/16 v0, 0x18

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-direct {v2, p0, v0, p1, v1}, Landroidx/core/provider/m;-><init>(Ljava/lang/Object;ILjava/lang/Object;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 11
    .line 12
    .line 13
    const-wide/16 v3, 0x0

    .line 14
    .line 15
    const-wide v5, 0x7fffffffffffffffL

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    move-object v1, p0

    .line 21
    :try_start_1
    invoke-virtual/range {v1 .. v6}, Lk5/d;->d(Ljava/lang/Runnable;JJ)V

    .line 22
    .line 23
    .line 24
    monitor-exit p0

    .line 25
    return-void

    .line 26
    :catchall_0
    move-exception v0

    .line 27
    :goto_0
    move-object p1, v0

    .line 28
    goto :goto_1

    .line 29
    :catchall_1
    move-exception v0

    .line 30
    move-object v1, p0

    .line 31
    goto :goto_0

    .line 32
    :goto_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 33
    throw p1
.end method

.method public final putString(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-virtual {p0}, Lk5/d;->a()V

    .line 3
    .line 4
    .line 5
    const/4 v0, 0x5

    .line 6
    invoke-virtual {p0, v0, p2, p1}, Lk5/d;->e(ILjava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    monitor-exit p0

    .line 10
    return-void

    .line 11
    :catchall_0
    move-exception p1

    .line 12
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    throw p1
.end method
