.class public final Lk5/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lk5/g;

.field public final synthetic b:[J

.field public final synthetic c:J

.field public final synthetic d:J

.field public final synthetic e:Lk5/d;


# direct methods
.method public constructor <init>(Lk5/d;Lk5/g;[JJJ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lk5/b;->e:Lk5/d;

    .line 5
    .line 6
    iput-object p2, p0, Lk5/b;->a:Lk5/g;

    .line 7
    .line 8
    iput-object p3, p0, Lk5/b;->b:[J

    .line 9
    .line 10
    iput-wide p4, p0, Lk5/b;->c:J

    .line 11
    .line 12
    iput-wide p6, p0, Lk5/b;->d:J

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget-object v0, p0, Lk5/b;->e:Lk5/d;

    .line 2
    .line 3
    iget-object v1, v0, Lk5/d;->e:Ljava/nio/MappedByteBuffer;

    .line 4
    .line 5
    iget-object v2, p0, Lk5/b;->a:Lk5/g;

    .line 6
    .line 7
    invoke-virtual {v2, v1}, Lk5/g;->a(Ljava/nio/ByteBuffer;)Ljava/io/Serializable;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    check-cast v1, Ljava/lang/Long;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 16
    .line 17
    .line 18
    move-result-wide v3

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    iget-wide v3, p0, Lk5/b;->c:J

    .line 21
    .line 22
    :goto_0
    iget-wide v5, p0, Lk5/b;->d:J

    .line 23
    .line 24
    add-long/2addr v3, v5

    .line 25
    iget-object v1, p0, Lk5/b;->b:[J

    .line 26
    .line 27
    const/4 v5, 0x0

    .line 28
    aput-wide v3, v1, v5

    .line 29
    .line 30
    iget-object v0, v0, Lk5/d;->e:Ljava/nio/MappedByteBuffer;

    .line 31
    .line 32
    iget v1, v2, Lk5/g;->c:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 35
    .line 36
    .line 37
    const/4 v1, 0x2

    .line 38
    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    .line 39
    .line 40
    .line 41
    const/16 v1, 0x8

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0, v3, v4}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 47
    .line 48
    .line 49
    return-void
.end method
