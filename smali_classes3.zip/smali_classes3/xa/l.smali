.class public final Lxa/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# direct methods
.method public static a(Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-static {}, LPa/A;->a()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, LPa/i0;->y()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    const/4 p0, 0x0

    .line 15
    const-string v0, "HttpClient"

    .line 16
    .line 17
    invoke-static {v0, p0}, LPa/i0;->K(Ljava/lang/String;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    const-string v1, "com.transsnet.palmpay.account.ui.activity.LogInActivity"

    .line 26
    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    invoke-static {v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->isActivityExistsInStack(Ljava/lang/String;)Landroid/app/Activity;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    if-eqz v0, :cond_2

    .line 49
    .line 50
    invoke-static {}, LPa/A;->a()V

    .line 51
    .line 52
    .line 53
    const/4 v1, 0x0

    .line 54
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->finishToActivity(Landroid/app/Activity;Z)Z

    .line 55
    .line 56
    .line 57
    instance-of v1, v0, Lcom/transsnet/palmpay/core/callback/CustomActionCallback;

    .line 58
    .line 59
    if-eqz v1, :cond_3

    .line 60
    .line 61
    new-instance v1, LDa/i;

    .line 62
    .line 63
    const/4 v2, 0x3

    .line 64
    invoke-direct {v1, v0, p0, v2}, LDa/i;-><init>(Landroid/app/Activity;Ljava/lang/String;I)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :cond_2
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    const/16 v1, 0x196

    .line 76
    .line 77
    invoke-static {v1, v0}, LC0/G;->u(ILorg/greenrobot/eventbus/c;)V

    .line 78
    .line 79
    .line 80
    :try_start_0
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    const-string v1, "/account/login"

    .line 85
    .line 86
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    const-string v1, "android.intent.extra.TEXT"

    .line 91
    .line 92
    invoke-virtual {v0, v1, p0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 93
    .line 94
    .line 95
    move-result-object p0

    .line 96
    const-string v0, "extra_data"

    .line 97
    .line 98
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    invoke-virtual {p0, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    invoke-virtual {p0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :catch_0
    move-exception p0

    .line 111
    const-string v0, "gotoLoginPage: "

    .line 112
    .line 113
    filled-new-array {v0, p0}, [Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object p0

    .line 117
    const-string v0, "TokenInterceptor"

    .line 118
    .line 119
    invoke-static {v0, p0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    :goto_0
    const-string p0, "com.transsnet.palmpay.account.ui.activity.PinSafeWithPatternActivity"

    .line 123
    .line 124
    invoke-static {p0}, Lcom/transsnet/palmpay/util/ActivityUtils;->isActivityExistsInStack(Ljava/lang/String;)Landroid/app/Activity;

    .line 125
    .line 126
    .line 127
    move-result-object p0

    .line 128
    if-eqz p0, :cond_3

    .line 129
    .line 130
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 131
    .line 132
    .line 133
    :cond_3
    :goto_1
    return-void
.end method


# virtual methods
.method public final intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;
    .locals 12

    .line 1
    invoke-interface {p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Y;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, v0, Lokhttp3/Y;->a:Lokhttp3/J;

    .line 6
    .line 7
    iget-object v2, v1, Lokhttp3/J;->i:Ljava/lang/String;

    .line 8
    .line 9
    const-string v3, "UTF-8"

    .line 10
    .line 11
    invoke-static {v2, v3}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const-string v4, "PP_TOKEN"

    .line 16
    .line 17
    invoke-virtual {v0, v4}, Lokhttp3/Y;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    const-string v5, "Ignore-Common-Dialog"

    .line 22
    .line 23
    invoke-virtual {v0, v5}, Lokhttp3/Y;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v6

    .line 27
    const-string/jumbo v7, "yes"

    .line 28
    .line 29
    .line 30
    invoke-virtual {v7, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 31
    .line 32
    .line 33
    move-result v6

    .line 34
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    const-string v7, ""

    .line 39
    .line 40
    const-string v8, "No-Token"

    .line 41
    .line 42
    const-string v9, "TokenInterceptor"

    .line 43
    .line 44
    if-eqz v4, :cond_2

    .line 45
    .line 46
    :try_start_0
    iget-object v4, v1, Lokhttp3/J;->i:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {v4, v3}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    const-string v10, "Yes"

    .line 53
    .line 54
    invoke-virtual {v0, v8}, Lokhttp3/Y;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v11

    .line 58
    invoke-virtual {v10, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 59
    .line 60
    .line 61
    move-result v10

    .line 62
    if-eqz v10, :cond_0

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_0
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 66
    .line 67
    .line 68
    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 69
    if-eqz v4, :cond_1

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :catch_0
    move-exception p1

    .line 73
    const-string v0, "isTokenRequired: "

    .line 74
    .line 75
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    invoke-static {v9, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_1
    new-instance p1, Ljava/lang/StringBuilder;

    .line 83
    .line 84
    const-string/jumbo v0, "\u6709\u9700\u8981token\u7684\u63a5\u53e3\u88ab\u62e6\u622a\uff1a url: "

    .line 85
    .line 86
    .line 87
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    iget-object v0, v1, Lokhttp3/J;->i:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v0, v3}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    const/4 v0, 0x3

    .line 108
    invoke-static {v9, v0, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    invoke-static {v7}, Lxa/l;->a(Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    new-instance p1, Lna/c;

    .line 115
    .line 116
    const-string v0, "CFRONT_000002"

    .line 117
    .line 118
    const-string v1, "Token required"

    .line 119
    .line 120
    invoke-direct {p1, v0, v1}, Lna/c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    throw p1

    .line 124
    :cond_2
    :goto_0
    invoke-virtual {v0}, Lokhttp3/Y;->b()Lokhttp3/X;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-virtual {v0, v8}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v0, v5}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v0}, Lokhttp3/X;->b()Lokhttp3/Y;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    const/4 v0, 0x0

    .line 143
    if-eqz p1, :cond_4

    .line 144
    .line 145
    invoke-virtual {p1}, Lokhttp3/e0;->isSuccessful()Z

    .line 146
    .line 147
    .line 148
    move-result v1

    .line 149
    if-nez v1, :cond_3

    .line 150
    .line 151
    goto :goto_1

    .line 152
    :cond_3
    :try_start_1
    invoke-virtual {p1}, Lokhttp3/e0;->d()Lokhttp3/h0;

    .line 153
    .line 154
    .line 155
    move-result-object v1

    .line 156
    invoke-virtual {v1}, Lokhttp3/h0;->string()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 160
    goto :goto_2

    .line 161
    :catch_1
    move-exception v1

    .line 162
    const-string v3, "peekBody: "

    .line 163
    .line 164
    filled-new-array {v3, v1}, [Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    invoke-static {v9, v1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    :cond_4
    :goto_1
    move-object v1, v0

    .line 172
    :goto_2
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 173
    .line 174
    .line 175
    move-result v3

    .line 176
    if-eqz v3, :cond_5

    .line 177
    .line 178
    goto :goto_3

    .line 179
    :cond_5
    :try_start_2
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 180
    .line 181
    .line 182
    move-result-object v3

    .line 183
    const-class v4, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 184
    .line 185
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 186
    .line 187
    .line 188
    invoke-static {v1, v4}, LPa/w;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v3

    .line 192
    check-cast v3, Lcom/transsnet/palmpay/core/bean/CommonResult;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 193
    .line 194
    move-object v0, v3

    .line 195
    goto :goto_3

    .line 196
    :catch_2
    move-exception v3

    .line 197
    const-string v4, "parseCommonResult: "

    .line 198
    .line 199
    filled-new-array {v4, v3}, [Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v3

    .line 203
    invoke-static {v9, v3}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    :goto_3
    if-eqz v0, :cond_f

    .line 207
    .line 208
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isTokenExpired()Z

    .line 209
    .line 210
    .line 211
    move-result v3

    .line 212
    const/4 v4, 0x5

    .line 213
    if-eqz v3, :cond_6

    .line 214
    .line 215
    const-string v0, "gotoLoginPage_02"

    .line 216
    .line 217
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    invoke-static {v9, v4, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 222
    .line 223
    .line 224
    invoke-static {v7}, Lxa/l;->a(Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    goto/16 :goto_6

    .line 228
    .line 229
    :cond_6
    const-string v3, "CFRONT_000009"

    .line 230
    .line 231
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object v5

    .line 235
    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 236
    .line 237
    .line 238
    move-result v3

    .line 239
    if-eqz v3, :cond_7

    .line 240
    .line 241
    const-string v1, "gotoLoginPage_05"

    .line 242
    .line 243
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v1

    .line 247
    invoke-static {v9, v4, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    invoke-static {v0}, Lxa/l;->a(Ljava/lang/String;)V

    .line 255
    .line 256
    .line 257
    goto/16 :goto_6

    .line 258
    .line 259
    :cond_7
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isPreSignUpOutOfDate()Z

    .line 260
    .line 261
    .line 262
    move-result v3

    .line 263
    if-eqz v3, :cond_8

    .line 264
    .line 265
    invoke-static {}, LPa/A;->a()V

    .line 266
    .line 267
    .line 268
    const-string v0, "/main/splash"

    .line 269
    .line 270
    invoke-static {v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->F(Ljava/lang/String;)V

    .line 271
    .line 272
    .line 273
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->finishAllActivities()V

    .line 274
    .line 275
    .line 276
    goto/16 :goto_6

    .line 277
    .line 278
    :cond_8
    const-string v3, "CFRONT_300058"

    .line 279
    .line 280
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v4

    .line 284
    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 285
    .line 286
    .line 287
    move-result v3

    .line 288
    if-nez v3, :cond_e

    .line 289
    .line 290
    const-string v3, "CFRONT_300063"

    .line 291
    .line 292
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object v4

    .line 296
    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 297
    .line 298
    .line 299
    move-result v3

    .line 300
    if-eqz v3, :cond_9

    .line 301
    .line 302
    goto :goto_5

    .line 303
    :cond_9
    const-string v3, "CFRONT_000019"

    .line 304
    .line 305
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v4

    .line 309
    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 310
    .line 311
    .line 312
    move-result v3

    .line 313
    const-string v4, "validationCheckResp"

    .line 314
    .line 315
    if-nez v3, :cond_c

    .line 316
    .line 317
    const-string v3, "CFRONT_000020"

    .line 318
    .line 319
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 320
    .line 321
    .line 322
    move-result-object v5

    .line 323
    invoke-virtual {v3, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 324
    .line 325
    .line 326
    move-result v3

    .line 327
    if-eqz v3, :cond_a

    .line 328
    .line 329
    goto :goto_4

    .line 330
    :cond_a
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 331
    .line 332
    .line 333
    move-result v0

    .line 334
    if-eqz v0, :cond_f

    .line 335
    .line 336
    if-eqz v1, :cond_f

    .line 337
    .line 338
    invoke-virtual {v1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 339
    .line 340
    .line 341
    move-result v0

    .line 342
    if-eqz v0, :cond_f

    .line 343
    .line 344
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 345
    .line 346
    .line 347
    move-result-object v0

    .line 348
    instance-of v3, v0, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 349
    .line 350
    if-eqz v3, :cond_f

    .line 351
    .line 352
    invoke-static {v1, v4}, LPa/w;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 353
    .line 354
    .line 355
    move-result-object v3

    .line 356
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 357
    .line 358
    .line 359
    move-result v5

    .line 360
    if-eqz v5, :cond_b

    .line 361
    .line 362
    if-nez v6, :cond_b

    .line 363
    .line 364
    const-string v3, "data"

    .line 365
    .line 366
    invoke-static {v1, v3}, LPa/w;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 367
    .line 368
    .line 369
    move-result-object v1

    .line 370
    invoke-static {v1, v4}, LPa/w;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 371
    .line 372
    .line 373
    move-result-object v3

    .line 374
    :cond_b
    check-cast v0, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 375
    .line 376
    invoke-virtual {v0, v2, v3}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showCommonDialog(Ljava/lang/String;Ljava/lang/String;)V

    .line 377
    .line 378
    .line 379
    goto :goto_6

    .line 380
    :cond_c
    :goto_4
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 381
    .line 382
    .line 383
    move-result-object p1

    .line 384
    instance-of v3, p1, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 385
    .line 386
    if-eqz v3, :cond_d

    .line 387
    .line 388
    check-cast p1, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 389
    .line 390
    invoke-static {v1, v4}, LPa/w;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 391
    .line 392
    .line 393
    move-result-object v1

    .line 394
    invoke-virtual {p1, v2, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showCommonDialog(Ljava/lang/String;Ljava/lang/String;)V

    .line 395
    .line 396
    .line 397
    :cond_d
    new-instance p1, Lna/c;

    .line 398
    .line 399
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 400
    .line 401
    .line 402
    move-result-object v0

    .line 403
    const-string v1, "Action required"

    .line 404
    .line 405
    invoke-direct {p1, v0, v1}, Lna/c;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 406
    .line 407
    .line 408
    throw p1

    .line 409
    :cond_e
    :goto_5
    invoke-static {}, Lcom/facebook/imagepipeline/nativecode/b;->d()V

    .line 410
    .line 411
    .line 412
    :cond_f
    :goto_6
    return-object p1
.end method
