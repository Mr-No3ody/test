.class public final Lxa/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# virtual methods
.method public final intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;
    .locals 12

    .line 1
    invoke-interface {p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Y;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lokhttp3/Y;->b()Lokhttp3/X;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const-string v2, "Accept-Encoding"

    .line 10
    .line 11
    invoke-virtual {v0, v2}, Lokhttp3/Y;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    const-string v4, "gzip"

    .line 16
    .line 17
    if-nez v3, :cond_1

    .line 18
    .line 19
    const-string v3, "Range"

    .line 20
    .line 21
    invoke-virtual {v0, v3}, Lokhttp3/Y;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    if-nez v3, :cond_1

    .line 26
    .line 27
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/base/BaseApplication;->isOldAndroidDevice()Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-eqz v3, :cond_0

    .line 38
    .line 39
    invoke-virtual {v1, v2, v4}, Lokhttp3/X;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_0
    const-string v3, "br,gzip"

    .line 44
    .line 45
    invoke-virtual {v1, v2, v3}, Lokhttp3/X;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    :cond_1
    :goto_0
    invoke-virtual {v1}, Lokhttp3/X;->b()Lokhttp3/Y;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-interface {p1, v1}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    invoke-virtual {p1}, Lokhttp3/e0;->c()Lokhttp3/d0;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    const-string v2, "request"

    .line 61
    .line 62
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    iput-object v0, v1, Lokhttp3/d0;->a:Lokhttp3/Y;

    .line 66
    .line 67
    sget v0, LHg/e;->a:I

    .line 68
    .line 69
    const-string v0, "response"

    .line 70
    .line 71
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    invoke-static {p1}, LHg/e;->a(Lokhttp3/e0;)Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_3

    .line 79
    .line 80
    const-string v0, "Content-Encoding"

    .line 81
    .line 82
    const-string v2, "name"

    .line 83
    .line 84
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    const/4 v3, 0x0

    .line 88
    invoke-virtual {p1, v0, v3}, Lokhttp3/e0;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v5

    .line 92
    const-string v6, "br"

    .line 93
    .line 94
    invoke-virtual {v6, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 95
    .line 96
    .line 97
    move-result v5

    .line 98
    iget-object v6, p1, Lokhttp3/e0;->f:Lokhttp3/F;

    .line 99
    .line 100
    const-wide/16 v7, -0x1

    .line 101
    .line 102
    const-string v9, "Content-Type"

    .line 103
    .line 104
    const-string v10, "Content-Length"

    .line 105
    .line 106
    iget-object v11, p1, Lokhttp3/e0;->g:Lokhttp3/h0;

    .line 107
    .line 108
    if-eqz v5, :cond_2

    .line 109
    .line 110
    invoke-virtual {v11}, Lokhttp3/h0;->source()Lokio/BufferedSource;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    new-instance v5, LUg/b;

    .line 115
    .line 116
    invoke-interface {v4}, Lokio/BufferedSource;->inputStream()Ljava/io/InputStream;

    .line 117
    .line 118
    .line 119
    move-result-object v4

    .line 120
    invoke-direct {v5, v4}, LUg/b;-><init>(Ljava/io/InputStream;)V

    .line 121
    .line 122
    .line 123
    invoke-static {v5}, LPg/b;->l(Ljava/io/InputStream;)LPg/e;

    .line 124
    .line 125
    .line 126
    move-result-object v4

    .line 127
    invoke-virtual {v6}, Lokhttp3/F;->d()LF1/b;

    .line 128
    .line 129
    .line 130
    move-result-object v5

    .line 131
    invoke-virtual {v5, v0}, LF1/b;->j(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v5, v10}, LF1/b;->j(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v5}, LF1/b;->h()Lokhttp3/F;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    invoke-virtual {v1, v0}, Lokhttp3/d0;->c(Lokhttp3/F;)V

    .line 142
    .line 143
    .line 144
    invoke-static {v9, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p1, v9, v3}, Lokhttp3/e0;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    new-instance v0, LHg/g;

    .line 152
    .line 153
    invoke-static {v4}, LPg/b;->c(Lokio/Source;)LPg/x;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-direct {v0, p1, v7, v8, v2}, LHg/g;-><init>(Ljava/lang/String;JLPg/x;)V

    .line 158
    .line 159
    .line 160
    iput-object v0, v1, Lokhttp3/d0;->g:Lokhttp3/h0;

    .line 161
    .line 162
    goto :goto_1

    .line 163
    :cond_2
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {p1, v0, v3}, Lokhttp3/e0;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v5

    .line 170
    invoke-virtual {v4, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 171
    .line 172
    .line 173
    move-result v4

    .line 174
    if-eqz v4, :cond_3

    .line 175
    .line 176
    new-instance v4, LPg/q;

    .line 177
    .line 178
    invoke-virtual {v11}, Lokhttp3/h0;->source()Lokio/BufferedSource;

    .line 179
    .line 180
    .line 181
    move-result-object v5

    .line 182
    invoke-direct {v4, v5}, LPg/q;-><init>(Lokio/Source;)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {v6}, Lokhttp3/F;->d()LF1/b;

    .line 186
    .line 187
    .line 188
    move-result-object v5

    .line 189
    invoke-virtual {v5, v0}, LF1/b;->j(Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v5, v10}, LF1/b;->j(Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    const-string v0, "access-control-allow-origin"

    .line 196
    .line 197
    invoke-virtual {v5, v0}, LF1/b;->j(Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    const-string v0, "access-control-allow-methods"

    .line 201
    .line 202
    invoke-virtual {v5, v0}, LF1/b;->j(Ljava/lang/String;)V

    .line 203
    .line 204
    .line 205
    const-string v0, "access-control-allow-headers"

    .line 206
    .line 207
    invoke-virtual {v5, v0}, LF1/b;->j(Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    const-string v0, "server"

    .line 211
    .line 212
    invoke-virtual {v5, v0}, LF1/b;->j(Ljava/lang/String;)V

    .line 213
    .line 214
    .line 215
    const-string v0, "x-application-context"

    .line 216
    .line 217
    invoke-virtual {v5, v0}, LF1/b;->j(Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    invoke-virtual {v5}, LF1/b;->h()Lokhttp3/F;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    invoke-virtual {v1, v0}, Lokhttp3/d0;->c(Lokhttp3/F;)V

    .line 225
    .line 226
    .line 227
    invoke-static {v9, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    invoke-virtual {p1, v9, v3}, Lokhttp3/e0;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object p1

    .line 234
    new-instance v0, LHg/g;

    .line 235
    .line 236
    invoke-static {v4}, LPg/b;->c(Lokio/Source;)LPg/x;

    .line 237
    .line 238
    .line 239
    move-result-object v2

    .line 240
    invoke-direct {v0, p1, v7, v8, v2}, LHg/g;-><init>(Ljava/lang/String;JLPg/x;)V

    .line 241
    .line 242
    .line 243
    iput-object v0, v1, Lokhttp3/d0;->g:Lokhttp3/h0;

    .line 244
    .line 245
    :cond_3
    :goto_1
    invoke-virtual {v1}, Lokhttp3/d0;->a()Lokhttp3/e0;

    .line 246
    .line 247
    .line 248
    move-result-object p1

    .line 249
    return-object p1
.end method
