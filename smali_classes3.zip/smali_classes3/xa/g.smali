.class public final Lxa/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# static fields
.field public static final a:Lokhttp3/L;

.field public static b:Ljava/lang/String;

.field public static c:Ljava/lang/Boolean;

.field public static final d:Ljava/util/concurrent/atomic/AtomicInteger;

.field public static volatile e:Ljava/security/PublicKey;

.field public static final f:Ljavax/crypto/spec/OAEPParameterSpec;

.field public static final g:LHg/c;

.field public static final i:LHg/c;

.field public static final j:LHg/c;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    sget-object v0, Lokhttp3/L;->e:Lokhttp3/K;

    .line 2
    .line 3
    const-string v1, "application/json; charset=utf-8"

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Lokhttp3/K;->parse(Ljava/lang/String;)Lokhttp3/L;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, Lxa/g;->a:Lokhttp3/L;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    sput-object v0, Lxa/g;->b:Ljava/lang/String;

    .line 13
    .line 14
    sput-object v0, Lxa/g;->c:Ljava/lang/Boolean;

    .line 15
    .line 16
    new-instance v1, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 20
    .line 21
    .line 22
    sput-object v1, Lxa/g;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 23
    .line 24
    sput-object v0, Lxa/g;->e:Ljava/security/PublicKey;

    .line 25
    .line 26
    new-instance v0, Ljavax/crypto/spec/OAEPParameterSpec;

    .line 27
    .line 28
    sget-object v1, Ljava/security/spec/MGF1ParameterSpec;->SHA256:Ljava/security/spec/MGF1ParameterSpec;

    .line 29
    .line 30
    sget-object v2, Ljavax/crypto/spec/PSource$PSpecified;->DEFAULT:Ljavax/crypto/spec/PSource$PSpecified;

    .line 31
    .line 32
    const-string v3, "SHA-256"

    .line 33
    .line 34
    const-string v4, "MGF1"

    .line 35
    .line 36
    invoke-direct {v0, v3, v4, v1, v2}, Ljavax/crypto/spec/OAEPParameterSpec;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/security/spec/AlgorithmParameterSpec;Ljavax/crypto/spec/PSource;)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Lxa/g;->f:Ljavax/crypto/spec/OAEPParameterSpec;

    .line 40
    .line 41
    new-instance v0, LHg/c;

    .line 42
    .line 43
    const/16 v1, 0xb

    .line 44
    .line 45
    invoke-direct {v0, v1}, LHg/c;-><init>(I)V

    .line 46
    .line 47
    .line 48
    sput-object v0, Lxa/g;->g:LHg/c;

    .line 49
    .line 50
    new-instance v0, LHg/c;

    .line 51
    .line 52
    const/16 v1, 0xc

    .line 53
    .line 54
    invoke-direct {v0, v1}, LHg/c;-><init>(I)V

    .line 55
    .line 56
    .line 57
    sput-object v0, Lxa/g;->i:LHg/c;

    .line 58
    .line 59
    new-instance v0, LHg/c;

    .line 60
    .line 61
    const/16 v1, 0xd

    .line 62
    .line 63
    invoke-direct {v0, v1}, LHg/c;-><init>(I)V

    .line 64
    .line 65
    .line 66
    sput-object v0, Lxa/g;->j:LHg/c;

    .line 67
    .line 68
    return-void
.end method

.method public static a(Lokhttp3/Y;Ljava/lang/String;)Lokhttp3/Y;
    .locals 3

    .line 1
    invoke-virtual {p0}, Lokhttp3/Y;->b()Lokhttp3/X;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "X-Response-Encryption-Required"

    .line 6
    .line 7
    const-string v2, "false"

    .line 8
    .line 9
    invoke-virtual {v0, v1, v2}, Lokhttp3/X;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const-string v1, "X-Body-Encrypted"

    .line 13
    .line 14
    invoke-virtual {v0, v1, v2}, Lokhttp3/X;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v1, p0, Lokhttp3/Y;->d:Lokhttp3/c0;

    .line 18
    .line 19
    if-eqz v1, :cond_1

    .line 20
    .line 21
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    if-nez v2, :cond_1

    .line 26
    .line 27
    invoke-virtual {v1}, Lokhttp3/c0;->contentType()Lokhttp3/L;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    if-nez v1, :cond_0

    .line 32
    .line 33
    sget-object v1, Lxa/g;->a:Lokhttp3/L;

    .line 34
    .line 35
    :cond_0
    invoke-static {v1, p1}, Lokhttp3/c0;->create(Lokhttp3/L;Ljava/lang/String;)Lokhttp3/c0;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    iget-object p0, p0, Lokhttp3/Y;->b:Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {v0, p0, p1}, Lokhttp3/X;->g(Ljava/lang/String;Lokhttp3/c0;)V

    .line 42
    .line 43
    .line 44
    :cond_1
    invoke-virtual {v0}, Lokhttp3/X;->b()Lokhttp3/Y;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    return-object p0
.end method

.method public static b(Ljava/lang/String;[B)Ljava/lang/String;
    .locals 4

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    const/16 v0, 0x2e

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, -0x1

    .line 11
    :goto_0
    if-lez v0, :cond_2

    .line 12
    .line 13
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    add-int/lit8 v1, v1, -0x1

    .line 18
    .line 19
    if-ge v0, v1, :cond_2

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    const/4 v2, 0x2

    .line 27
    invoke-static {v1, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    add-int/lit8 v0, v0, 0x1

    .line 32
    .line 33
    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    invoke-static {p0, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    new-instance v0, Ljavax/crypto/spec/SecretKeySpec;

    .line 42
    .line 43
    const-string v3, "AES"

    .line 44
    .line 45
    invoke-direct {v0, p1, v3}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    .line 46
    .line 47
    .line 48
    new-instance p1, Ljavax/crypto/spec/GCMParameterSpec;

    .line 49
    .line 50
    const/16 v3, 0x80

    .line 51
    .line 52
    invoke-direct {p1, v3, v1}, Ljavax/crypto/spec/GCMParameterSpec;-><init>(I[B)V

    .line 53
    .line 54
    .line 55
    sget-object v1, Lxa/g;->i:LHg/c;

    .line 56
    .line 57
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    check-cast v1, Ljavax/crypto/Cipher;

    .line 62
    .line 63
    if-eqz v1, :cond_1

    .line 64
    .line 65
    invoke-virtual {v1, v2, v0, p1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    .line 69
    .line 70
    .line 71
    move-result-object p0

    .line 72
    new-instance p1, Ljava/lang/String;

    .line 73
    .line 74
    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 75
    .line 76
    invoke-direct {p1, p0, v0}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 77
    .line 78
    .line 79
    return-object p1

    .line 80
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 81
    .line 82
    const-string p1, "AES_GCM_CIPHER is null"

    .line 83
    .line 84
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    throw p0

    .line 88
    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 89
    .line 90
    const-string p1, "Invalid encrypted data format"

    .line 91
    .line 92
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    throw p0
.end method

.method public static c(Ljava/lang/String;[B)Ljava/lang/String;
    .locals 4

    .line 1
    const/16 v0, 0xc

    .line 2
    .line 3
    new-array v0, v0, [B

    .line 4
    .line 5
    sget-object v1, Lxa/g;->j:LHg/c;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    check-cast v1, Ljava/security/SecureRandom;

    .line 12
    .line 13
    invoke-virtual {v1, v0}, Ljava/security/SecureRandom;->nextBytes([B)V

    .line 14
    .line 15
    .line 16
    new-instance v1, Ljavax/crypto/spec/SecretKeySpec;

    .line 17
    .line 18
    const-string v2, "AES"

    .line 19
    .line 20
    invoke-direct {v1, p1, v2}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    .line 21
    .line 22
    .line 23
    new-instance p1, Ljavax/crypto/spec/GCMParameterSpec;

    .line 24
    .line 25
    const/16 v2, 0x80

    .line 26
    .line 27
    invoke-direct {p1, v2, v0}, Ljavax/crypto/spec/GCMParameterSpec;-><init>(I[B)V

    .line 28
    .line 29
    .line 30
    sget-object v2, Lxa/g;->i:LHg/c;

    .line 31
    .line 32
    invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    check-cast v2, Ljavax/crypto/Cipher;

    .line 37
    .line 38
    if-eqz v2, :cond_0

    .line 39
    .line 40
    const/4 v3, 0x1

    .line 41
    invoke-virtual {v2, v3, v1, p1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    .line 42
    .line 43
    .line 44
    sget-object p1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 45
    .line 46
    invoke-virtual {p0, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    invoke-virtual {v2, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    const/4 p1, 0x2

    .line 55
    invoke-static {v0, p1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-static {p0, p1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p0

    .line 71
    const-string p1, "."

    .line 72
    .line 73
    invoke-static {v0, p1, p0}, LN8/q0;->y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    return-object p0

    .line 78
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 79
    .line 80
    const-string p1, "AES_GCM_CIPHER is null"

    .line 81
    .line 82
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    throw p0
.end method

.method public static d([B)Ljava/lang/String;
    .locals 5

    .line 1
    array-length v0, p0

    .line 2
    if-eqz v0, :cond_3

    .line 3
    .line 4
    :try_start_0
    sget-object v0, Lxa/g;->e:Ljava/security/PublicKey;

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    invoke-static {}, Lcom/transsnet/palmpay/security/utils/SecurityUtils;->c()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const/4 v1, 0x0

    .line 13
    invoke-static {v0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    new-instance v1, Ljava/security/spec/X509EncodedKeySpec;

    .line 18
    .line 19
    invoke-direct {v1, v0}, Ljava/security/spec/X509EncodedKeySpec;-><init>([B)V

    .line 20
    .line 21
    .line 22
    const-string v0, "RSA"

    .line 23
    .line 24
    invoke-static {v0}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {v0, v1}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    sput-object v0, Lxa/g;->e:Ljava/security/PublicKey;

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :catch_0
    move-exception v0

    .line 36
    goto :goto_1

    .line 37
    :cond_0
    :goto_0
    sget-object v0, Lxa/g;->e:Ljava/security/PublicKey;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 38
    .line 39
    goto :goto_2

    .line 40
    :goto_1
    const-string v1, "EncryptionInterceptor"

    .line 41
    .line 42
    const-string v2, "getOrCreateRsaPublicKey: "

    .line 43
    .line 44
    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 45
    .line 46
    .line 47
    const/4 v0, 0x0

    .line 48
    :goto_2
    if-eqz v0, :cond_2

    .line 49
    .line 50
    :try_start_1
    sget-object v1, Lxa/g;->g:LHg/c;

    .line 51
    .line 52
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    check-cast v1, Ljavax/crypto/Cipher;

    .line 57
    .line 58
    if-eqz v1, :cond_1

    .line 59
    .line 60
    sget-object v2, Lxa/g;->f:Ljavax/crypto/spec/OAEPParameterSpec;

    .line 61
    .line 62
    sget-object v3, Lxa/g;->j:LHg/c;

    .line 63
    .line 64
    invoke-virtual {v3}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    check-cast v3, Ljava/security/SecureRandom;

    .line 69
    .line 70
    const/4 v4, 0x1

    .line 71
    invoke-virtual {v1, v4, v0, v2, v3}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;Ljava/security/SecureRandom;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v1, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    const/4 v0, 0x2

    .line 79
    invoke-static {p0, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    return-object p0

    .line 88
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 89
    .line 90
    const-string v0, "RSA_OAEP_CIPHER is null"

    .line 91
    .line 92
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    throw p0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 96
    :catch_1
    move-exception p0

    .line 97
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 98
    .line 99
    const-string v1, "Unsupported RSA-OAEP configuration: RSA/ECB/OAEPPadding (OAEP SHA-256, MGF1 SHA-256). Please ensure the device JCA provider supports OAEPParameterSpec."

    .line 100
    .line 101
    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 102
    .line 103
    .line 104
    throw v0

    .line 105
    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 106
    .line 107
    const-string v0, "Create Rsp Public Key fail"

    .line 108
    .line 109
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    throw p0

    .line 113
    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 114
    .line 115
    const-string v0, "AES key is empty"

    .line 116
    .line 117
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    throw p0
.end method

.method public static e()Ljava/lang/String;
    .locals 3

    .line 1
    const-string v0, ""

    .line 2
    .line 3
    sget-object v1, Lxa/g;->b:Ljava/lang/String;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 8
    .line 9
    .line 10
    sget-object v0, Lxa/g;->b:Ljava/lang/String;

    .line 11
    .line 12
    return-object v0

    .line 13
    :cond_0
    :try_start_0
    sget-object v1, Lm6/n;->a:Lm6/m;

    .line 14
    .line 15
    invoke-virtual {v1}, Lm6/m;->instance()Lm6/n;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    const-string v2, "E2EE_base_host"

    .line 20
    .line 21
    invoke-virtual {v1, v2, v0}, Lm6/n;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-static {v1}, Lcom/transsnet/palmpay/util/RegexUtils;->isURL(Ljava/lang/CharSequence;)Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_1

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    move-object v1, v0

    .line 33
    :goto_0
    sput-object v1, Lxa/g;->b:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :catchall_0
    move-exception v1

    .line 40
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    const-string v2, "RemoteConfig not ready, fallback disabled. err="

    .line 49
    .line 50
    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    const-string v2, "EncryptionInterceptor"

    .line 55
    .line 56
    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 57
    .line 58
    .line 59
    sput-object v0, Lxa/g;->b:Ljava/lang/String;

    .line 60
    .line 61
    :goto_1
    sget-object v0, Lxa/g;->b:Ljava/lang/String;

    .line 62
    .line 63
    return-object v0
.end method

.method public static f(Ljava/lang/String;)V
    .locals 6

    .line 1
    sget-object v0, Lxa/g;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const-string v1, "encrypt error count="

    .line 8
    .line 9
    const-string v2, ", reason="

    .line 10
    .line 11
    invoke-static {v1, v0, v2, p0}, Lcom/airbnb/lottie/model/layer/d;->j(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    const-string v2, "EncryptionInterceptor"

    .line 20
    .line 21
    invoke-static {v2, v1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    new-instance v3, Lcom/transsnet/palmpay/core/util/statistic/TrackEvent;

    .line 32
    .line 33
    const-string v4, "E2EE_ERROR"

    .line 34
    .line 35
    invoke-direct {v3, v4}, Lcom/transsnet/palmpay/core/util/statistic/TrackEvent;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    new-instance v4, Ljava/util/HashMap;

    .line 39
    .line 40
    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 41
    .line 42
    .line 43
    const-string v5, "msg"

    .line 44
    .line 45
    invoke-virtual {v4, v5, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->putAll(Ljava/util/Map;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    invoke-virtual {v1, p0}, LPa/n0;->q(Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;)V

    .line 53
    .line 54
    .line 55
    const/16 p0, 0xa

    .line 56
    .line 57
    if-le v0, p0, :cond_0

    .line 58
    .line 59
    sget-object p0, Lxa/g;->c:Ljava/lang/Boolean;

    .line 60
    .line 61
    if-eqz p0, :cond_0

    .line 62
    .line 63
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    if-eqz p0, :cond_0

    .line 68
    .line 69
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 70
    .line 71
    sput-object p0, Lxa/g;->c:Ljava/lang/Boolean;

    .line 72
    .line 73
    const-string p0, "encrypt error count exceeded threshold, force disable encryption"

    .line 74
    .line 75
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    invoke-static {v2, p0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_0
    return-void
.end method


# virtual methods
.method public final intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;
    .locals 10

    .line 1
    invoke-interface {p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Y;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lxa/g;->c:Ljava/lang/Boolean;

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    invoke-static {}, Lxa/g;->e()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    xor-int/lit8 v1, v1, 0x1

    .line 18
    .line 19
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    sput-object v1, Lxa/g;->c:Ljava/lang/Boolean;

    .line 24
    .line 25
    :cond_0
    sget-object v1, Lxa/g;->c:Ljava/lang/Boolean;

    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-nez v1, :cond_1

    .line 32
    .line 33
    goto/16 :goto_9

    .line 34
    .line 35
    :cond_1
    const-string v1, "X-Body-Encrypted"

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Lokhttp3/Y;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    if-eqz v2, :cond_2

    .line 42
    .line 43
    const-string v3, "false"

    .line 44
    .line 45
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_2

    .line 54
    .line 55
    goto/16 :goto_9

    .line 56
    .line 57
    :cond_2
    invoke-static {}, Lxa/g;->e()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    const-string v4, ""

    .line 66
    .line 67
    const-string v5, "EncryptionInterceptor"

    .line 68
    .line 69
    if-eqz v3, :cond_3

    .line 70
    .line 71
    :goto_0
    move-object v2, v4

    .line 72
    goto :goto_1

    .line 73
    :cond_3
    :try_start_0
    sget-object v3, Lokhttp3/J;->k:Lokhttp3/I;

    .line 74
    .line 75
    invoke-virtual {v3, v2}, Lokhttp3/I;->parse(Ljava/lang/String;)Lokhttp3/J;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    if-nez v2, :cond_4

    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_4
    iget-object v2, v2, Lokhttp3/J;->d:Ljava/lang/String;

    .line 83
    .line 84
    const-string v3, "ng-"

    .line 85
    .line 86
    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 87
    .line 88
    .line 89
    move-result v3

    .line 90
    if-eqz v3, :cond_5

    .line 91
    .line 92
    goto :goto_1

    .line 93
    :cond_5
    new-instance v3, Ljava/lang/StringBuilder;

    .line 94
    .line 95
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 96
    .line 97
    .line 98
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v6

    .line 102
    invoke-virtual {v6}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v6

    .line 106
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    const-string v6, "-"

    .line 110
    .line 111
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 121
    goto :goto_1

    .line 122
    :catchall_0
    move-exception v2

    .line 123
    const-string v3, "getEffectiveE2EEHost failed"

    .line 124
    .line 125
    filled-new-array {v3, v2}, [Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    invoke-static {v5, v2}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    goto :goto_0

    .line 133
    :goto_1
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 134
    .line 135
    .line 136
    move-result v3

    .line 137
    if-nez v3, :cond_15

    .line 138
    .line 139
    iget-object v3, v0, Lokhttp3/Y;->a:Lokhttp3/J;

    .line 140
    .line 141
    iget-object v3, v3, Lokhttp3/J;->d:Ljava/lang/String;

    .line 142
    .line 143
    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 144
    .line 145
    .line 146
    move-result v2

    .line 147
    if-nez v2, :cond_6

    .line 148
    .line 149
    goto/16 :goto_9

    .line 150
    .line 151
    :cond_6
    iget-object v2, v0, Lokhttp3/Y;->d:Lokhttp3/c0;

    .line 152
    .line 153
    if-eqz v2, :cond_15

    .line 154
    .line 155
    :try_start_1
    invoke-virtual {v2}, Lokhttp3/c0;->contentLength()J

    .line 156
    .line 157
    .line 158
    move-result-wide v6
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3

    .line 159
    const-wide/16 v8, 0x0

    .line 160
    .line 161
    cmp-long v3, v6, v8

    .line 162
    .line 163
    if-nez v3, :cond_7

    .line 164
    .line 165
    goto/16 :goto_9

    .line 166
    .line 167
    :cond_7
    invoke-virtual {v2}, Lokhttp3/c0;->contentType()Lokhttp3/L;

    .line 168
    .line 169
    .line 170
    move-result-object v3

    .line 171
    if-eqz v3, :cond_15

    .line 172
    .line 173
    const-string v6, "json"

    .line 174
    .line 175
    iget-object v3, v3, Lokhttp3/L;->c:Ljava/lang/String;

    .line 176
    .line 177
    invoke-virtual {v3, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 178
    .line 179
    .line 180
    move-result v3

    .line 181
    if-eqz v3, :cond_15

    .line 182
    .line 183
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 184
    .line 185
    .line 186
    invoke-static {}, Landroid/os/SystemClock;->currentThreadTimeMillis()J

    .line 187
    .line 188
    .line 189
    :try_start_2
    new-instance v3, LPg/k;

    .line 190
    .line 191
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 192
    .line 193
    .line 194
    if-eqz v2, :cond_8

    .line 195
    .line 196
    invoke-virtual {v2, v3}, Lokhttp3/c0;->writeTo(Lokio/BufferedSink;)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v3}, LPg/k;->readUtf8()Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object v2
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    .line 203
    goto :goto_2

    .line 204
    :catch_0
    :cond_8
    move-object v2, v4

    .line 205
    :goto_2
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 206
    .line 207
    .line 208
    move-result v3

    .line 209
    if-nez v3, :cond_14

    .line 210
    .line 211
    const-string/jumbo v3, "{}"

    .line 212
    .line 213
    .line 214
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    move-result v3

    .line 218
    if-eqz v3, :cond_9

    .line 219
    .line 220
    goto/16 :goto_8

    .line 221
    .line 222
    :cond_9
    const/16 v3, 0x20

    .line 223
    .line 224
    new-array v3, v3, [B

    .line 225
    .line 226
    sget-object v6, Lxa/g;->j:LHg/c;

    .line 227
    .line 228
    invoke-virtual {v6}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v6

    .line 232
    check-cast v6, Ljava/security/SecureRandom;

    .line 233
    .line 234
    invoke-virtual {v6, v3}, Ljava/security/SecureRandom;->nextBytes([B)V

    .line 235
    .line 236
    .line 237
    :try_start_3
    invoke-static {v2, v3}, Lxa/g;->c(Ljava/lang/String;[B)Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object v6

    .line 241
    invoke-static {v3}, Lxa/g;->d([B)Ljava/lang/String;

    .line 242
    .line 243
    .line 244
    move-result-object v7

    .line 245
    new-instance v8, Lorg/json/JSONObject;

    .line 246
    .line 247
    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V

    .line 248
    .line 249
    .line 250
    const-string v9, "encryptedBody"

    .line 251
    .line 252
    invoke-virtual {v8, v9, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 253
    .line 254
    .line 255
    move-result-object v6

    .line 256
    const-string v8, "encryptedKey"

    .line 257
    .line 258
    invoke-virtual {v6, v8, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 259
    .line 260
    .line 261
    move-result-object v6

    .line 262
    invoke-virtual {v6}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object v2
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 266
    sget-object v6, Lxa/g;->a:Lokhttp3/L;

    .line 267
    .line 268
    invoke-static {v6, v2}, Lokhttp3/c0;->create(Lokhttp3/L;Ljava/lang/String;)Lokhttp3/c0;

    .line 269
    .line 270
    .line 271
    move-result-object v2

    .line 272
    invoke-virtual {v0}, Lokhttp3/Y;->b()Lokhttp3/X;

    .line 273
    .line 274
    .line 275
    move-result-object v7

    .line 276
    const-string v8, "true"

    .line 277
    .line 278
    invoke-virtual {v7, v1, v8}, Lokhttp3/X;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 279
    .line 280
    .line 281
    const-string v1, "X-Encryption-Key-Version"

    .line 282
    .line 283
    const-string v9, "v1"

    .line 284
    .line 285
    invoke-virtual {v7, v1, v9}, Lokhttp3/X;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 286
    .line 287
    .line 288
    iget-object v0, v0, Lokhttp3/Y;->b:Ljava/lang/String;

    .line 289
    .line 290
    invoke-virtual {v7, v0, v2}, Lokhttp3/X;->g(Ljava/lang/String;Lokhttp3/c0;)V

    .line 291
    .line 292
    .line 293
    const-string v0, "X-Response-Encryption-Required"

    .line 294
    .line 295
    invoke-virtual {v7, v0, v8}, Lokhttp3/X;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 296
    .line 297
    .line 298
    invoke-virtual {v7}, Lokhttp3/X;->b()Lokhttp3/Y;

    .line 299
    .line 300
    .line 301
    move-result-object v0

    .line 302
    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 303
    .line 304
    .line 305
    move-result-object p1

    .line 306
    invoke-virtual {p1}, Lokhttp3/e0;->isSuccessful()Z

    .line 307
    .line 308
    .line 309
    move-result v0

    .line 310
    iget v1, p1, Lokhttp3/e0;->d:I

    .line 311
    .line 312
    iget-object v2, p1, Lokhttp3/e0;->g:Lokhttp3/h0;

    .line 313
    .line 314
    if-eqz v0, :cond_10

    .line 315
    .line 316
    const-string v0, "encryptedData"

    .line 317
    .line 318
    if-nez v2, :cond_a

    .line 319
    .line 320
    goto :goto_4

    .line 321
    :cond_a
    invoke-virtual {v2}, Lokhttp3/h0;->string()Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object v7

    .line 325
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 326
    .line 327
    .line 328
    move-result v8

    .line 329
    if-eqz v8, :cond_b

    .line 330
    .line 331
    const-string v0, "decryptResponse: empty response body"

    .line 332
    .line 333
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 334
    .line 335
    .line 336
    move-result-object v0

    .line 337
    invoke-static {v5, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    invoke-virtual {v2}, Lokhttp3/h0;->contentType()Lokhttp3/L;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    invoke-virtual {p1}, Lokhttp3/e0;->c()Lokhttp3/d0;

    .line 345
    .line 346
    .line 347
    move-result-object p1

    .line 348
    invoke-static {v0, v4}, Lokhttp3/h0;->create(Lokhttp3/L;Ljava/lang/String;)Lokhttp3/h0;

    .line 349
    .line 350
    .line 351
    move-result-object v0

    .line 352
    iput-object v0, p1, Lokhttp3/d0;->g:Lokhttp3/h0;

    .line 353
    .line 354
    invoke-virtual {p1}, Lokhttp3/d0;->a()Lokhttp3/e0;

    .line 355
    .line 356
    .line 357
    move-result-object p1

    .line 358
    goto :goto_4

    .line 359
    :cond_b
    :try_start_4
    new-instance v4, Lorg/json/JSONObject;

    .line 360
    .line 361
    invoke-direct {v4, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 362
    .line 363
    .line 364
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 365
    .line 366
    .line 367
    move-result v8

    .line 368
    if-eqz v8, :cond_e

    .line 369
    .line 370
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 371
    .line 372
    .line 373
    move-result-object v0

    .line 374
    invoke-static {v0, v3}, Lxa/g;->b(Ljava/lang/String;[B)Ljava/lang/String;

    .line 375
    .line 376
    .line 377
    move-result-object v0

    .line 378
    :cond_c
    sget-object v2, Lxa/g;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 379
    .line 380
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 381
    .line 382
    .line 383
    move-result v3

    .line 384
    if-gtz v3, :cond_d

    .line 385
    .line 386
    goto :goto_3

    .line 387
    :cond_d
    add-int/lit8 v4, v3, -0x1

    .line 388
    .line 389
    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 390
    .line 391
    .line 392
    move-result v2

    .line 393
    if-eqz v2, :cond_c

    .line 394
    .line 395
    :goto_3
    invoke-virtual {p1}, Lokhttp3/e0;->c()Lokhttp3/d0;

    .line 396
    .line 397
    .line 398
    move-result-object v2

    .line 399
    invoke-static {v6, v0}, Lokhttp3/h0;->create(Lokhttp3/L;Ljava/lang/String;)Lokhttp3/h0;

    .line 400
    .line 401
    .line 402
    move-result-object v0

    .line 403
    iput-object v0, v2, Lokhttp3/d0;->g:Lokhttp3/h0;

    .line 404
    .line 405
    invoke-virtual {v2}, Lokhttp3/d0;->a()Lokhttp3/e0;

    .line 406
    .line 407
    .line 408
    move-result-object p1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    .line 409
    goto :goto_4

    .line 410
    :catch_1
    move-exception v0

    .line 411
    goto :goto_5

    .line 412
    :cond_e
    invoke-virtual {v2}, Lokhttp3/h0;->contentType()Lokhttp3/L;

    .line 413
    .line 414
    .line 415
    move-result-object v0

    .line 416
    invoke-virtual {p1}, Lokhttp3/e0;->c()Lokhttp3/d0;

    .line 417
    .line 418
    .line 419
    move-result-object p1

    .line 420
    invoke-static {v0, v7}, Lokhttp3/h0;->create(Lokhttp3/L;Ljava/lang/String;)Lokhttp3/h0;

    .line 421
    .line 422
    .line 423
    move-result-object v0

    .line 424
    iput-object v0, p1, Lokhttp3/d0;->g:Lokhttp3/h0;

    .line 425
    .line 426
    invoke-virtual {p1}, Lokhttp3/d0;->a()Lokhttp3/e0;

    .line 427
    .line 428
    .line 429
    move-result-object p1

    .line 430
    :goto_4
    return-object p1

    .line 431
    :goto_5
    new-instance v2, Ljava/lang/StringBuilder;

    .line 432
    .line 433
    const-string v3, "decryptResponse failed. path="

    .line 434
    .line 435
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 436
    .line 437
    .line 438
    iget-object p1, p1, Lokhttp3/e0;->a:Lokhttp3/Y;

    .line 439
    .line 440
    if-eqz p1, :cond_f

    .line 441
    .line 442
    iget-object p1, p1, Lokhttp3/Y;->a:Lokhttp3/J;

    .line 443
    .line 444
    invoke-virtual {p1}, Lokhttp3/J;->b()Ljava/lang/String;

    .line 445
    .line 446
    .line 447
    move-result-object p1

    .line 448
    goto :goto_6

    .line 449
    :cond_f
    const-string p1, "null"

    .line 450
    .line 451
    :goto_6
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 452
    .line 453
    .line 454
    const-string p1, ", httpCode="

    .line 455
    .line 456
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 457
    .line 458
    .line 459
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 460
    .line 461
    .line 462
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 463
    .line 464
    .line 465
    move-result-object p1

    .line 466
    filled-new-array {p1, v0}, [Ljava/lang/Object;

    .line 467
    .line 468
    .line 469
    move-result-object p1

    .line 470
    invoke-static {v5, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 471
    .line 472
    .line 473
    const-string p1, "decrypt response failed"

    .line 474
    .line 475
    invoke-static {p1}, Lxa/g;->f(Ljava/lang/String;)V

    .line 476
    .line 477
    .line 478
    new-instance p1, Ljava/io/IOException;

    .line 479
    .line 480
    const-string v1, "E2EE_D_1:"

    .line 481
    .line 482
    invoke-direct {p1, v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 483
    .line 484
    .line 485
    throw p1

    .line 486
    :cond_10
    const/16 v0, 0x190

    .line 487
    .line 488
    if-ne v1, v0, :cond_13

    .line 489
    .line 490
    if-eqz v2, :cond_13

    .line 491
    .line 492
    invoke-virtual {v2}, Lokhttp3/h0;->string()Ljava/lang/String;

    .line 493
    .line 494
    .line 495
    move-result-object v0

    .line 496
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 497
    .line 498
    .line 499
    move-result v1

    .line 500
    if-nez v1, :cond_12

    .line 501
    .line 502
    const-string v1, "E2EE"

    .line 503
    .line 504
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 505
    .line 506
    .line 507
    move-result v1

    .line 508
    if-nez v1, :cond_11

    .line 509
    .line 510
    goto :goto_7

    .line 511
    :cond_11
    const-string p1, "Bad Request: "

    .line 512
    .line 513
    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 514
    .line 515
    .line 516
    move-result-object p1

    .line 517
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 518
    .line 519
    .line 520
    move-result-object p1

    .line 521
    invoke-static {v5, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 522
    .line 523
    .line 524
    const-string p1, "response 400 contains E2EE"

    .line 525
    .line 526
    invoke-static {p1}, Lxa/g;->f(Ljava/lang/String;)V

    .line 527
    .line 528
    .line 529
    new-instance p1, Ljava/io/IOException;

    .line 530
    .line 531
    new-instance v1, Ljava/lang/StringBuilder;

    .line 532
    .line 533
    const-string v2, "E2EE:"

    .line 534
    .line 535
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 536
    .line 537
    .line 538
    const-string v2, "message"

    .line 539
    .line 540
    invoke-static {v0, v2}, LPa/w;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 541
    .line 542
    .line 543
    move-result-object v0

    .line 544
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 545
    .line 546
    .line 547
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 548
    .line 549
    .line 550
    move-result-object v0

    .line 551
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 552
    .line 553
    .line 554
    throw p1

    .line 555
    :cond_12
    :goto_7
    invoke-virtual {v2}, Lokhttp3/h0;->contentType()Lokhttp3/L;

    .line 556
    .line 557
    .line 558
    move-result-object v1

    .line 559
    invoke-virtual {p1}, Lokhttp3/e0;->c()Lokhttp3/d0;

    .line 560
    .line 561
    .line 562
    move-result-object p1

    .line 563
    invoke-static {v1, v0}, Lokhttp3/h0;->create(Lokhttp3/L;Ljava/lang/String;)Lokhttp3/h0;

    .line 564
    .line 565
    .line 566
    move-result-object v0

    .line 567
    iput-object v0, p1, Lokhttp3/d0;->g:Lokhttp3/h0;

    .line 568
    .line 569
    invoke-virtual {p1}, Lokhttp3/d0;->a()Lokhttp3/e0;

    .line 570
    .line 571
    .line 572
    move-result-object p1

    .line 573
    :cond_13
    return-object p1

    .line 574
    :catch_2
    move-exception v1

    .line 575
    const-string v3, "RSA Encryption error"

    .line 576
    .line 577
    filled-new-array {v3, v1}, [Ljava/lang/Object;

    .line 578
    .line 579
    .line 580
    move-result-object v1

    .line 581
    invoke-static {v5, v1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 582
    .line 583
    .line 584
    const-string v1, "encrypt request failed"

    .line 585
    .line 586
    invoke-static {v1}, Lxa/g;->f(Ljava/lang/String;)V

    .line 587
    .line 588
    .line 589
    invoke-static {v0, v2}, Lxa/g;->a(Lokhttp3/Y;Ljava/lang/String;)Lokhttp3/Y;

    .line 590
    .line 591
    .line 592
    move-result-object v0

    .line 593
    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 594
    .line 595
    .line 596
    move-result-object p1

    .line 597
    return-object p1

    .line 598
    :cond_14
    :goto_8
    const-string v1, "Request body is empty, no need to encrypt"

    .line 599
    .line 600
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 601
    .line 602
    .line 603
    move-result-object v1

    .line 604
    invoke-static {v5, v1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 605
    .line 606
    .line 607
    invoke-static {v0, v2}, Lxa/g;->a(Lokhttp3/Y;Ljava/lang/String;)Lokhttp3/Y;

    .line 608
    .line 609
    .line 610
    move-result-object v0

    .line 611
    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 612
    .line 613
    .line 614
    move-result-object p1

    .line 615
    return-object p1

    .line 616
    :catch_3
    :cond_15
    :goto_9
    const/4 v1, 0x0

    .line 617
    invoke-static {v0, v1}, Lxa/g;->a(Lokhttp3/Y;Ljava/lang/String;)Lokhttp3/Y;

    .line 618
    .line 619
    .line 620
    move-result-object v0

    .line 621
    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 622
    .line 623
    .line 624
    move-result-object p1

    .line 625
    return-object p1
.end method
