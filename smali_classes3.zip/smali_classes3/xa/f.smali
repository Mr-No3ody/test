.class public final Lxa/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# static fields
.field public static final i:Lxa/c;

.field public static final j:Ljava/lang/Object;


# instance fields
.field public a:Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

.field public final b:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final c:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final d:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final e:Lxf/t;

.field public f:I

.field public g:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lxa/c;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lxa/c;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lxa/f;->i:Lxa/c;

    .line 8
    .line 9
    sget-object v0, Lxf/k;->a:Lxf/k;

    .line 10
    .line 11
    new-instance v1, Lx9/u;

    .line 12
    .line 13
    const/4 v2, 0x1

    .line 14
    invoke-direct {v1, v2}, Lx9/u;-><init>(I)V

    .line 15
    .line 16
    .line 17
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sput-object v0, Lxa/f;->j:Ljava/lang/Object;

    .line 22
    .line 23
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lxa/f;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 11
    .line 12
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 13
    .line 14
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lxa/f;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 18
    .line 19
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lxa/f;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 25
    .line 26
    new-instance v0, Lx9/u;

    .line 27
    .line 28
    const/4 v1, 0x2

    .line 29
    invoke-direct {v0, v1}, Lx9/u;-><init>(I)V

    .line 30
    .line 31
    .line 32
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    iput-object v0, p0, Lxa/f;->e:Lxf/t;

    .line 37
    .line 38
    const/16 v0, 0x9

    .line 39
    .line 40
    iput v0, p0, Lxa/f;->f:I

    .line 41
    .line 42
    return-void
.end method


# virtual methods
.method public final a(Lorg/chromium/net/CronetEngine;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lxa/f;->a:Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    :try_start_0
    invoke-static {p1}, Lcom/google/net/cronet/okhttptransport/CronetInterceptor;->newBuilder(Lorg/chromium/net/CronetEngine;)Lcom/google/net/cronet/okhttptransport/CronetInterceptor$Builder;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    const-string v0, "NetworkTraceV6"

    .line 10
    .line 11
    invoke-virtual {p1, v0}, Lcom/google/net/cronet/okhttptransport/CronetInterceptor$Builder;->setTraceName(Ljava/lang/String;)Lcom/google/net/cronet/okhttptransport/CronetInterceptor$Builder;

    .line 12
    .line 13
    .line 14
    new-instance v0, Lxa/d;

    .line 15
    .line 16
    invoke-direct {v0, p0}, Lxa/d;-><init>(Lxa/f;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1, v0}, Lcom/google/net/cronet/okhttptransport/CronetInterceptor$Builder;->setMetricCallBack(Lcom/google/net/cronet/okhttptransport/CronetLogHelper$OnMetricCallback;)Lcom/google/net/cronet/okhttptransport/CronetInterceptor$Builder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1}, Lcom/google/net/cronet/okhttptransport/CronetInterceptor$Builder;->build()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    check-cast p1, Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

    .line 27
    .line 28
    iput-object p1, p0, Lxa/f;->a:Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

    .line 29
    .line 30
    iget-object p1, p0, Lxa/f;->e:Lxf/t;

    .line 31
    .line 32
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    check-cast p1, Ljava/lang/Boolean;

    .line 37
    .line 38
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    if-nez p1, :cond_0

    .line 43
    .line 44
    sget-object p1, Lva/d;->a:Landroidx/work/impl/model/b;

    .line 45
    .line 46
    iget-object p1, p1, Landroidx/work/impl/model/b;->c:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast p1, Lcom/palmpay/lib/apm/network/OkHttpEventListener;

    .line 49
    .line 50
    if-eqz p1, :cond_0

    .line 51
    .line 52
    const/4 v0, 0x0

    .line 53
    invoke-virtual {p1, v0}, Lcom/palmpay/lib/apm/network/OkHttpEventListener;->setEnableNetworkTrace(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :catchall_0
    move-exception p1

    .line 58
    const/4 v0, 0x0

    .line 59
    iput-object v0, p0, Lxa/f;->a:Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

    .line 60
    .line 61
    const-string v0, "initCronetInterceptor"

    .line 62
    .line 63
    filled-new-array {v0, p1}, [Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    const-string v0, "CronetWrapInterceptor"

    .line 68
    .line 69
    invoke-static {v0, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    :cond_0
    return-void
.end method

.method public final intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;
    .locals 31

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    const-string v2, "intercept use okhttp "

    .line 6
    .line 7
    const-string v3, "intercept use Cronet "

    .line 8
    .line 9
    const-string v4, "chain"

    .line 10
    .line 11
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v4, v1, Lxa/f;->e:Lxf/t;

    .line 15
    .line 16
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    check-cast v4, Ljava/lang/Boolean;

    .line 21
    .line 22
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 23
    .line 24
    .line 25
    move-result v4

    .line 26
    if-eqz v4, :cond_1d

    .line 27
    .line 28
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 29
    .line 30
    const/16 v5, 0x1d

    .line 31
    .line 32
    if-lt v4, v5, :cond_1d

    .line 33
    .line 34
    iget-wide v4, v1, Lxa/f;->g:J

    .line 35
    .line 36
    const-wide/16 v6, 0x0

    .line 37
    .line 38
    cmp-long v4, v4, v6

    .line 39
    .line 40
    const-string v5, "CronetWrapInterceptor"

    .line 41
    .line 42
    if-eqz v4, :cond_0

    .line 43
    .line 44
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 45
    .line 46
    .line 47
    move-result-wide v9

    .line 48
    iget-wide v11, v1, Lxa/f;->g:J

    .line 49
    .line 50
    sub-long/2addr v9, v11

    .line 51
    const-wide/16 v11, 0x4e20

    .line 52
    .line 53
    cmp-long v4, v9, v11

    .line 54
    .line 55
    if-lez v4, :cond_16

    .line 56
    .line 57
    :cond_0
    sget-object v4, Lcom/palmpay/lib/apm/network/NQEManager;->INSTANCE:Lcom/palmpay/lib/apm/network/NQEManager;

    .line 58
    .line 59
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/NQEManager;->getLastNetworkQualityRecord()Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    if-nez v4, :cond_1

    .line 64
    .line 65
    goto/16 :goto_a

    .line 66
    .line 67
    :cond_1
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getCronet()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 68
    .line 69
    .line 70
    move-result-object v9

    .line 71
    const-wide/16 v10, 0x0

    .line 72
    .line 73
    if-eqz v9, :cond_2

    .line 74
    .line 75
    invoke-virtual {v9}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedSuccessRate()D

    .line 76
    .line 77
    .line 78
    move-result-wide v12

    .line 79
    goto :goto_0

    .line 80
    :cond_2
    move-wide v12, v10

    .line 81
    :goto_0
    cmpl-double v9, v12, v10

    .line 82
    .line 83
    if-lez v9, :cond_6

    .line 84
    .line 85
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getOkhttp()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 86
    .line 87
    .line 88
    move-result-object v9

    .line 89
    if-eqz v9, :cond_3

    .line 90
    .line 91
    invoke-virtual {v9}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedSuccessRate()D

    .line 92
    .line 93
    .line 94
    move-result-wide v12

    .line 95
    goto :goto_1

    .line 96
    :cond_3
    move-wide v12, v10

    .line 97
    :goto_1
    cmpl-double v9, v12, v10

    .line 98
    .line 99
    if-lez v9, :cond_6

    .line 100
    .line 101
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getCronet()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 102
    .line 103
    .line 104
    move-result-object v9

    .line 105
    if-eqz v9, :cond_4

    .line 106
    .line 107
    invoke-virtual {v9}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedSuccessRate()D

    .line 108
    .line 109
    .line 110
    move-result-wide v12

    .line 111
    goto :goto_2

    .line 112
    :cond_4
    move-wide v12, v10

    .line 113
    :goto_2
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getOkhttp()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 114
    .line 115
    .line 116
    move-result-object v9

    .line 117
    if-eqz v9, :cond_5

    .line 118
    .line 119
    invoke-virtual {v9}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedSuccessRate()D

    .line 120
    .line 121
    .line 122
    move-result-wide v14

    .line 123
    goto :goto_3

    .line 124
    :cond_5
    move-wide v14, v10

    .line 125
    :goto_3
    sub-double/2addr v12, v14

    .line 126
    goto :goto_4

    .line 127
    :cond_6
    move-wide v12, v10

    .line 128
    :goto_4
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getCronet()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 129
    .line 130
    .line 131
    move-result-object v9

    .line 132
    if-eqz v9, :cond_7

    .line 133
    .line 134
    invoke-virtual {v9}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedHttpRTT()J

    .line 135
    .line 136
    .line 137
    move-result-wide v14

    .line 138
    goto :goto_5

    .line 139
    :cond_7
    move-wide v14, v6

    .line 140
    :goto_5
    cmp-long v9, v14, v6

    .line 141
    .line 142
    if-lez v9, :cond_b

    .line 143
    .line 144
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getOkhttp()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 145
    .line 146
    .line 147
    move-result-object v9

    .line 148
    if-eqz v9, :cond_8

    .line 149
    .line 150
    invoke-virtual {v9}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedHttpRTT()J

    .line 151
    .line 152
    .line 153
    move-result-wide v14

    .line 154
    goto :goto_6

    .line 155
    :cond_8
    move-wide v14, v6

    .line 156
    :goto_6
    cmp-long v9, v14, v6

    .line 157
    .line 158
    if-lez v9, :cond_b

    .line 159
    .line 160
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getCronet()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 161
    .line 162
    .line 163
    move-result-object v9

    .line 164
    if-eqz v9, :cond_9

    .line 165
    .line 166
    invoke-virtual {v9}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedHttpRTT()J

    .line 167
    .line 168
    .line 169
    move-result-wide v14

    .line 170
    goto :goto_7

    .line 171
    :cond_9
    move-wide v14, v6

    .line 172
    :goto_7
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getOkhttp()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 173
    .line 174
    .line 175
    move-result-object v9

    .line 176
    if-eqz v9, :cond_a

    .line 177
    .line 178
    invoke-virtual {v9}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedHttpRTT()J

    .line 179
    .line 180
    .line 181
    move-result-wide v16

    .line 182
    goto :goto_8

    .line 183
    :cond_a
    move-wide/from16 v16, v6

    .line 184
    .line 185
    :goto_8
    sub-long v14, v14, v16

    .line 186
    .line 187
    goto :goto_9

    .line 188
    :cond_b
    move-wide v14, v6

    .line 189
    :goto_9
    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    .line 190
    .line 191
    .line 192
    move-result-wide v16

    .line 193
    const-wide v18, 0x3fc3333340000000L    # 0.15000000596046448

    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    cmpl-double v9, v16, v18

    .line 199
    .line 200
    const-wide/16 v16, 0x64

    .line 201
    .line 202
    if-gtz v9, :cond_d

    .line 203
    .line 204
    invoke-static {v14, v15}, Ljava/lang/Math;->abs(J)J

    .line 205
    .line 206
    .line 207
    move-result-wide v20

    .line 208
    cmp-long v9, v20, v16

    .line 209
    .line 210
    if-lez v9, :cond_c

    .line 211
    .line 212
    goto :goto_b

    .line 213
    :cond_c
    :goto_a
    move-wide/from16 v18, v6

    .line 214
    .line 215
    goto/16 :goto_11

    .line 216
    .line 217
    :cond_d
    :goto_b
    iget v9, v1, Lxa/f;->f:I

    .line 218
    .line 219
    cmpl-double v10, v12, v10

    .line 220
    .line 221
    if-gtz v10, :cond_f

    .line 222
    .line 223
    cmp-long v10, v14, v6

    .line 224
    .line 225
    if-gez v10, :cond_e

    .line 226
    .line 227
    goto :goto_c

    .line 228
    :cond_e
    add-int/lit8 v10, v9, -0x1

    .line 229
    .line 230
    const/4 v11, 0x1

    .line 231
    invoke-static {v11, v10}, Ljava/lang/Math;->max(II)I

    .line 232
    .line 233
    .line 234
    move-result v10

    .line 235
    goto :goto_d

    .line 236
    :cond_f
    :goto_c
    add-int/lit8 v10, v9, 0x1

    .line 237
    .line 238
    const/16 v11, 0x9

    .line 239
    .line 240
    invoke-static {v11, v10}, Ljava/lang/Math;->min(II)I

    .line 241
    .line 242
    .line 243
    move-result v10

    .line 244
    :goto_d
    iput v10, v1, Lxa/f;->f:I

    .line 245
    .line 246
    invoke-static {v12, v13}, Ljava/lang/Math;->abs(D)D

    .line 247
    .line 248
    .line 249
    move-result-wide v10

    .line 250
    cmpl-double v10, v10, v18

    .line 251
    .line 252
    const-string v11, ")="

    .line 253
    .line 254
    move-wide/from16 v18, v6

    .line 255
    .line 256
    const-string v6, " - "

    .line 257
    .line 258
    const-string v7, " -> "

    .line 259
    .line 260
    const-string v8, "checkIfUpdatePercent "

    .line 261
    .line 262
    const/16 v21, 0x0

    .line 263
    .line 264
    if-lez v10, :cond_12

    .line 265
    .line 266
    iget v10, v1, Lxa/f;->f:I

    .line 267
    .line 268
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getCronet()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 269
    .line 270
    .line 271
    move-result-object v14

    .line 272
    if-eqz v14, :cond_10

    .line 273
    .line 274
    invoke-virtual {v14}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedSuccessRate()D

    .line 275
    .line 276
    .line 277
    move-result-wide v14

    .line 278
    invoke-static {v14, v15}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 279
    .line 280
    .line 281
    move-result-object v14

    .line 282
    goto :goto_e

    .line 283
    :cond_10
    move-object/from16 v14, v21

    .line 284
    .line 285
    :goto_e
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getOkhttp()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 286
    .line 287
    .line 288
    move-result-object v4

    .line 289
    if-eqz v4, :cond_11

    .line 290
    .line 291
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedSuccessRate()D

    .line 292
    .line 293
    .line 294
    move-result-wide v15

    .line 295
    invoke-static/range {v15 .. v16}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 296
    .line 297
    .line 298
    move-result-object v21

    .line 299
    :cond_11
    move-object/from16 v4, v21

    .line 300
    .line 301
    const-string v15, " success rate ("

    .line 302
    .line 303
    invoke-static {v9, v8, v10, v7, v15}, LN8/q0;->p(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 304
    .line 305
    .line 306
    move-result-object v7

    .line 307
    invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 308
    .line 309
    .line 310
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 311
    .line 312
    .line 313
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 314
    .line 315
    .line 316
    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 317
    .line 318
    .line 319
    invoke-virtual {v7, v12, v13}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 320
    .line 321
    .line 322
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 323
    .line 324
    .line 325
    move-result-object v4

    .line 326
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 327
    .line 328
    .line 329
    move-result-object v4

    .line 330
    const/4 v6, 0x3

    .line 331
    invoke-static {v5, v6, v4}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 332
    .line 333
    .line 334
    goto :goto_10

    .line 335
    :cond_12
    invoke-static {v14, v15}, Ljava/lang/Math;->abs(J)J

    .line 336
    .line 337
    .line 338
    move-result-wide v12

    .line 339
    cmp-long v10, v12, v16

    .line 340
    .line 341
    if-lez v10, :cond_15

    .line 342
    .line 343
    iget v10, v1, Lxa/f;->f:I

    .line 344
    .line 345
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getCronet()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 346
    .line 347
    .line 348
    move-result-object v12

    .line 349
    if-eqz v12, :cond_13

    .line 350
    .line 351
    invoke-virtual {v12}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedHttpRTT()J

    .line 352
    .line 353
    .line 354
    move-result-wide v12

    .line 355
    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 356
    .line 357
    .line 358
    move-result-object v12

    .line 359
    goto :goto_f

    .line 360
    :cond_13
    move-object/from16 v12, v21

    .line 361
    .line 362
    :goto_f
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/NQEQualityBean;->getOkhttp()Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;

    .line 363
    .line 364
    .line 365
    move-result-object v4

    .line 366
    if-eqz v4, :cond_14

    .line 367
    .line 368
    invoke-virtual {v4}, Lcom/palmpay/lib/apm/network/bean/BaseNQEQualityBean;->getWeightedHttpRTT()J

    .line 369
    .line 370
    .line 371
    move-result-wide v16

    .line 372
    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 373
    .line 374
    .line 375
    move-result-object v21

    .line 376
    :cond_14
    move-object/from16 v4, v21

    .line 377
    .line 378
    const-string v13, " rtt ("

    .line 379
    .line 380
    invoke-static {v9, v8, v10, v7, v13}, LN8/q0;->p(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 381
    .line 382
    .line 383
    move-result-object v7

    .line 384
    invoke-static {v7, v12, v6, v4, v11}, LN8/q0;->w(Ljava/lang/StringBuilder;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/String;)V

    .line 385
    .line 386
    .line 387
    invoke-virtual {v7, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 388
    .line 389
    .line 390
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 391
    .line 392
    .line 393
    move-result-object v4

    .line 394
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    move-result-object v4

    .line 398
    const/4 v6, 0x3

    .line 399
    invoke-static {v5, v6, v4}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 400
    .line 401
    .line 402
    :cond_15
    :goto_10
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 403
    .line 404
    .line 405
    move-result-wide v6

    .line 406
    iput-wide v6, v1, Lxa/f;->g:J

    .line 407
    .line 408
    :goto_11
    iget-wide v6, v1, Lxa/f;->g:J

    .line 409
    .line 410
    cmp-long v4, v6, v18

    .line 411
    .line 412
    if-nez v4, :cond_16

    .line 413
    .line 414
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 415
    .line 416
    .line 417
    move-result-wide v6

    .line 418
    iput-wide v6, v1, Lxa/f;->g:J

    .line 419
    .line 420
    :cond_16
    iget-object v4, v1, Lxa/f;->a:Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

    .line 421
    .line 422
    iget-object v6, v1, Lxa/f;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 423
    .line 424
    iget-object v7, v1, Lxa/f;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 425
    .line 426
    const/4 v8, 0x0

    .line 427
    if-eqz v4, :cond_19

    .line 428
    .line 429
    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 430
    .line 431
    .line 432
    move-result v4

    .line 433
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 434
    .line 435
    .line 436
    move-result v9

    .line 437
    const/16 v10, 0xa

    .line 438
    .line 439
    if-le v4, v10, :cond_17

    .line 440
    .line 441
    add-int/lit8 v9, v9, 0x5

    .line 442
    .line 443
    if-le v4, v9, :cond_17

    .line 444
    .line 445
    goto/16 :goto_13

    .line 446
    .line 447
    :cond_17
    iget-object v4, v1, Lxa/f;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 448
    .line 449
    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 450
    .line 451
    .line 452
    move-result v9

    .line 453
    const v11, 0x7ffffff5

    .line 454
    .line 455
    .line 456
    if-le v9, v11, :cond_18

    .line 457
    .line 458
    invoke-virtual {v4, v8}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 459
    .line 460
    .line 461
    :cond_18
    iget v4, v1, Lxa/f;->f:I

    .line 462
    .line 463
    packed-switch v4, :pswitch_data_0

    .line 464
    .line 465
    .line 466
    sget-object v21, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 467
    .line 468
    move-object/from16 v22, v21

    .line 469
    .line 470
    move-object/from16 v23, v21

    .line 471
    .line 472
    move-object/from16 v24, v21

    .line 473
    .line 474
    move-object/from16 v25, v21

    .line 475
    .line 476
    move-object/from16 v26, v21

    .line 477
    .line 478
    move-object/from16 v27, v21

    .line 479
    .line 480
    move-object/from16 v28, v21

    .line 481
    .line 482
    move-object/from16 v29, v21

    .line 483
    .line 484
    move-object/from16 v30, v21

    .line 485
    .line 486
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 487
    .line 488
    .line 489
    move-result-object v4

    .line 490
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 491
    .line 492
    .line 493
    move-result-object v4

    .line 494
    goto/16 :goto_12

    .line 495
    .line 496
    :pswitch_0
    sget-object v21, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 497
    .line 498
    sget-object v26, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 499
    .line 500
    move-object/from16 v22, v21

    .line 501
    .line 502
    move-object/from16 v23, v21

    .line 503
    .line 504
    move-object/from16 v24, v21

    .line 505
    .line 506
    move-object/from16 v25, v21

    .line 507
    .line 508
    move-object/from16 v27, v21

    .line 509
    .line 510
    move-object/from16 v28, v21

    .line 511
    .line 512
    move-object/from16 v29, v21

    .line 513
    .line 514
    move-object/from16 v30, v21

    .line 515
    .line 516
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 517
    .line 518
    .line 519
    move-result-object v4

    .line 520
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 521
    .line 522
    .line 523
    move-result-object v4

    .line 524
    goto/16 :goto_12

    .line 525
    .line 526
    :pswitch_1
    sget-object v21, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 527
    .line 528
    sget-object v24, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 529
    .line 530
    move-object/from16 v22, v21

    .line 531
    .line 532
    move-object/from16 v23, v21

    .line 533
    .line 534
    move-object/from16 v25, v21

    .line 535
    .line 536
    move-object/from16 v26, v21

    .line 537
    .line 538
    move-object/from16 v27, v21

    .line 539
    .line 540
    move-object/from16 v28, v24

    .line 541
    .line 542
    move-object/from16 v29, v21

    .line 543
    .line 544
    move-object/from16 v30, v21

    .line 545
    .line 546
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 547
    .line 548
    .line 549
    move-result-object v4

    .line 550
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 551
    .line 552
    .line 553
    move-result-object v4

    .line 554
    goto/16 :goto_12

    .line 555
    .line 556
    :pswitch_2
    sget-object v21, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 557
    .line 558
    sget-object v23, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 559
    .line 560
    move-object/from16 v22, v21

    .line 561
    .line 562
    move-object/from16 v24, v21

    .line 563
    .line 564
    move-object/from16 v25, v21

    .line 565
    .line 566
    move-object/from16 v26, v23

    .line 567
    .line 568
    move-object/from16 v27, v21

    .line 569
    .line 570
    move-object/from16 v28, v21

    .line 571
    .line 572
    move-object/from16 v29, v23

    .line 573
    .line 574
    move-object/from16 v30, v21

    .line 575
    .line 576
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 577
    .line 578
    .line 579
    move-result-object v4

    .line 580
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 581
    .line 582
    .line 583
    move-result-object v4

    .line 584
    goto/16 :goto_12

    .line 585
    .line 586
    :pswitch_3
    sget-object v21, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 587
    .line 588
    sget-object v23, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 589
    .line 590
    move-object/from16 v22, v21

    .line 591
    .line 592
    move-object/from16 v24, v21

    .line 593
    .line 594
    move-object/from16 v25, v23

    .line 595
    .line 596
    move-object/from16 v26, v21

    .line 597
    .line 598
    move-object/from16 v27, v23

    .line 599
    .line 600
    move-object/from16 v28, v21

    .line 601
    .line 602
    move-object/from16 v29, v21

    .line 603
    .line 604
    move-object/from16 v30, v23

    .line 605
    .line 606
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 607
    .line 608
    .line 609
    move-result-object v4

    .line 610
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 611
    .line 612
    .line 613
    move-result-object v4

    .line 614
    goto/16 :goto_12

    .line 615
    .line 616
    :pswitch_4
    sget-object v21, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 617
    .line 618
    sget-object v22, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 619
    .line 620
    move-object/from16 v23, v21

    .line 621
    .line 622
    move-object/from16 v24, v22

    .line 623
    .line 624
    move-object/from16 v25, v21

    .line 625
    .line 626
    move-object/from16 v26, v22

    .line 627
    .line 628
    move-object/from16 v27, v21

    .line 629
    .line 630
    move-object/from16 v28, v22

    .line 631
    .line 632
    move-object/from16 v29, v21

    .line 633
    .line 634
    move-object/from16 v30, v22

    .line 635
    .line 636
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 637
    .line 638
    .line 639
    move-result-object v4

    .line 640
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 641
    .line 642
    .line 643
    move-result-object v4

    .line 644
    goto/16 :goto_12

    .line 645
    .line 646
    :pswitch_5
    sget-object v21, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 647
    .line 648
    sget-object v22, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 649
    .line 650
    move-object/from16 v23, v22

    .line 651
    .line 652
    move-object/from16 v24, v21

    .line 653
    .line 654
    move-object/from16 v25, v22

    .line 655
    .line 656
    move-object/from16 v26, v22

    .line 657
    .line 658
    move-object/from16 v27, v21

    .line 659
    .line 660
    move-object/from16 v28, v22

    .line 661
    .line 662
    move-object/from16 v29, v21

    .line 663
    .line 664
    move-object/from16 v30, v22

    .line 665
    .line 666
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 667
    .line 668
    .line 669
    move-result-object v4

    .line 670
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 671
    .line 672
    .line 673
    move-result-object v4

    .line 674
    goto :goto_12

    .line 675
    :pswitch_6
    sget-object v21, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 676
    .line 677
    sget-object v22, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 678
    .line 679
    move-object/from16 v23, v22

    .line 680
    .line 681
    move-object/from16 v24, v21

    .line 682
    .line 683
    move-object/from16 v25, v22

    .line 684
    .line 685
    move-object/from16 v26, v22

    .line 686
    .line 687
    move-object/from16 v27, v21

    .line 688
    .line 689
    move-object/from16 v28, v22

    .line 690
    .line 691
    move-object/from16 v29, v22

    .line 692
    .line 693
    move-object/from16 v30, v22

    .line 694
    .line 695
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 696
    .line 697
    .line 698
    move-result-object v4

    .line 699
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 700
    .line 701
    .line 702
    move-result-object v4

    .line 703
    goto :goto_12

    .line 704
    :pswitch_7
    sget-object v21, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 705
    .line 706
    sget-object v24, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 707
    .line 708
    move-object/from16 v22, v21

    .line 709
    .line 710
    move-object/from16 v23, v21

    .line 711
    .line 712
    move-object/from16 v25, v21

    .line 713
    .line 714
    move-object/from16 v26, v21

    .line 715
    .line 716
    move-object/from16 v27, v21

    .line 717
    .line 718
    move-object/from16 v28, v24

    .line 719
    .line 720
    move-object/from16 v29, v21

    .line 721
    .line 722
    move-object/from16 v30, v21

    .line 723
    .line 724
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 725
    .line 726
    .line 727
    move-result-object v4

    .line 728
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 729
    .line 730
    .line 731
    move-result-object v4

    .line 732
    goto :goto_12

    .line 733
    :pswitch_8
    sget-object v21, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 734
    .line 735
    sget-object v25, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 736
    .line 737
    move-object/from16 v22, v21

    .line 738
    .line 739
    move-object/from16 v23, v21

    .line 740
    .line 741
    move-object/from16 v24, v21

    .line 742
    .line 743
    move-object/from16 v26, v21

    .line 744
    .line 745
    move-object/from16 v27, v21

    .line 746
    .line 747
    move-object/from16 v28, v21

    .line 748
    .line 749
    move-object/from16 v29, v21

    .line 750
    .line 751
    move-object/from16 v30, v21

    .line 752
    .line 753
    filled-new-array/range {v21 .. v30}, [Ljava/lang/Boolean;

    .line 754
    .line 755
    .line 756
    move-result-object v4

    .line 757
    invoke-static {v4}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 758
    .line 759
    .line 760
    move-result-object v4

    .line 761
    :goto_12
    rem-int/2addr v9, v10

    .line 762
    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 763
    .line 764
    .line 765
    move-result-object v4

    .line 766
    check-cast v4, Ljava/lang/Boolean;

    .line 767
    .line 768
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 769
    .line 770
    .line 771
    move-result v8

    .line 772
    :cond_19
    :goto_13
    const-string v4, "Activate okhttp request count:"

    .line 773
    .line 774
    const-string v9, "Activate Cronet request count:"

    .line 775
    .line 776
    if-eqz v8, :cond_1a

    .line 777
    .line 778
    :try_start_0
    iget v2, v1, Lxa/f;->f:I

    .line 779
    .line 780
    new-instance v10, Ljava/lang/StringBuilder;

    .line 781
    .line 782
    invoke-direct {v10, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 783
    .line 784
    .line 785
    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 786
    .line 787
    .line 788
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 789
    .line 790
    .line 791
    move-result-object v2

    .line 792
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 793
    .line 794
    .line 795
    move-result-object v2

    .line 796
    const/4 v3, 0x3

    .line 797
    invoke-static {v5, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 798
    .line 799
    .line 800
    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 801
    .line 802
    .line 803
    iget-object v2, v1, Lxa/f;->a:Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

    .line 804
    .line 805
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 806
    .line 807
    .line 808
    invoke-virtual {v2, v0}, Lcom/google/net/cronet/okhttptransport/CronetInterceptor;->intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;

    .line 809
    .line 810
    .line 811
    move-result-object v0

    .line 812
    goto :goto_14

    .line 813
    :catchall_0
    move-exception v0

    .line 814
    goto :goto_15

    .line 815
    :cond_1a
    iget v3, v1, Lxa/f;->f:I

    .line 816
    .line 817
    new-instance v10, Ljava/lang/StringBuilder;

    .line 818
    .line 819
    invoke-direct {v10, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 820
    .line 821
    .line 822
    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 823
    .line 824
    .line 825
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 826
    .line 827
    .line 828
    move-result-object v2

    .line 829
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 830
    .line 831
    .line 832
    move-result-object v2

    .line 833
    const/4 v3, 0x3

    .line 834
    invoke-static {v5, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 835
    .line 836
    .line 837
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 838
    .line 839
    .line 840
    invoke-interface {v0}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Y;

    .line 841
    .line 842
    .line 843
    move-result-object v2

    .line 844
    invoke-interface {v0, v2}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 845
    .line 846
    .line 847
    move-result-object v0

    .line 848
    :goto_14
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 849
    .line 850
    .line 851
    if-eqz v8, :cond_1b

    .line 852
    .line 853
    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 854
    .line 855
    .line 856
    move-result v2

    .line 857
    invoke-static {v2, v9}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 858
    .line 859
    .line 860
    move-result-object v2

    .line 861
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 862
    .line 863
    .line 864
    move-result-object v2

    .line 865
    const/4 v3, 0x3

    .line 866
    invoke-static {v5, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 867
    .line 868
    .line 869
    return-object v0

    .line 870
    :cond_1b
    const/4 v3, 0x3

    .line 871
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 872
    .line 873
    .line 874
    move-result v2

    .line 875
    invoke-static {v2, v4}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 876
    .line 877
    .line 878
    move-result-object v2

    .line 879
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 880
    .line 881
    .line 882
    move-result-object v2

    .line 883
    invoke-static {v5, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 884
    .line 885
    .line 886
    return-object v0

    .line 887
    :goto_15
    if-eqz v8, :cond_1c

    .line 888
    .line 889
    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 890
    .line 891
    .line 892
    move-result v2

    .line 893
    invoke-static {v2, v9}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 894
    .line 895
    .line 896
    move-result-object v2

    .line 897
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 898
    .line 899
    .line 900
    move-result-object v2

    .line 901
    const/4 v3, 0x3

    .line 902
    invoke-static {v5, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 903
    .line 904
    .line 905
    goto :goto_16

    .line 906
    :cond_1c
    const/4 v3, 0x3

    .line 907
    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 908
    .line 909
    .line 910
    move-result v2

    .line 911
    invoke-static {v2, v4}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 912
    .line 913
    .line 914
    move-result-object v2

    .line 915
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 916
    .line 917
    .line 918
    move-result-object v2

    .line 919
    invoke-static {v5, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 920
    .line 921
    .line 922
    :goto_16
    throw v0

    .line 923
    :cond_1d
    iget-object v2, v1, Lxa/f;->a:Lcom/google/net/cronet/okhttptransport/CronetInterceptor;

    .line 924
    .line 925
    if-eqz v2, :cond_1e

    .line 926
    .line 927
    invoke-virtual {v2, v0}, Lcom/google/net/cronet/okhttptransport/CronetInterceptor;->intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;

    .line 928
    .line 929
    .line 930
    move-result-object v0

    .line 931
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 932
    .line 933
    .line 934
    return-object v0

    .line 935
    :cond_1e
    invoke-interface {v0}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Y;

    .line 936
    .line 937
    .line 938
    move-result-object v2

    .line 939
    invoke-interface {v0, v2}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 940
    .line 941
    .line 942
    move-result-object v0

    .line 943
    return-object v0

    .line 944
    nop

    .line 945
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
