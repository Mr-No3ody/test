.class public final Lxa/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# static fields
.field public static a:Ljava/lang/String;

.field public static b:Ljava/lang/String;


# virtual methods
.method public final intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;
    .locals 24

    .line 1
    invoke-interface/range {p1 .. p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Y;

    .line 2
    .line 3
    .line 4
    move-result-object v1

    .line 5
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getToken()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v6

    .line 13
    const-string v2, "Use_Sign_V2"

    .line 14
    .line 15
    const-string v8, "applyCommonHeaders: "

    .line 16
    .line 17
    const-string v9, "HeaderInterceptor"

    .line 18
    .line 19
    const-string v0, "No-PalmPay-Header"

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Lokhttp3/Y;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    const-string/jumbo v3, "yes"

    .line 26
    .line 27
    .line 28
    invoke-virtual {v3, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    :goto_0
    move-object/from16 v2, p1

    .line 35
    .line 36
    goto/16 :goto_6

    .line 37
    .line 38
    :cond_0
    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/nio/charset/Charset;->name()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v10

    .line 44
    invoke-static {}, Landroidx/work/impl/model/b;->f()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    invoke-static {}, Landroidx/work/impl/model/b;->e()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    invoke-virtual {v1}, Lokhttp3/Y;->b()Lokhttp3/X;

    .line 53
    .line 54
    .line 55
    move-result-object v11

    .line 56
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 57
    .line 58
    .line 59
    move-result-wide v12

    .line 60
    invoke-static {v12, v13}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v5

    .line 64
    const-string v0, "PP_DEVICE_ID"

    .line 65
    .line 66
    invoke-virtual {v11, v0}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    const-string v7, "PP_DEVICE_TYPE"

    .line 70
    .line 71
    invoke-virtual {v11, v7}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    const-string v12, "PP_CLIENT_VER"

    .line 75
    .line 76
    invoke-virtual {v11, v12}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    const-string v13, "PP_TIMESTAMP"

    .line 80
    .line 81
    invoke-virtual {v11, v13}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    const-string v14, "PP_TOKEN"

    .line 85
    .line 86
    invoke-virtual {v11, v14}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    const-string v15, "PP_REQ_SIGN"

    .line 90
    .line 91
    invoke-virtual {v11, v15}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    move-object/from16 v16, v6

    .line 95
    .line 96
    const-string v6, "PP_REQ_SIGN_2"

    .line 97
    .line 98
    invoke-virtual {v11, v6}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    move-object/from16 v17, v15

    .line 102
    .line 103
    const-string v15, "PP_REQ_SIGN_V2"

    .line 104
    .line 105
    invoke-virtual {v11, v15}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    move-object/from16 v18, v6

    .line 109
    .line 110
    const-string v6, "PP_LNG"

    .line 111
    .line 112
    invoke-virtual {v11, v6}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    move-object/from16 v19, v15

    .line 116
    .line 117
    const-string v15, "PP_LAT"

    .line 118
    .line 119
    invoke-virtual {v11, v15}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    move-object/from16 v20, v2

    .line 123
    .line 124
    const-string v2, "PP_CHANNEL"

    .line 125
    .line 126
    invoke-virtual {v11, v2}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    move-object/from16 v21, v14

    .line 130
    .line 131
    const-string v14, "INSTALLER_PACKAGE"

    .line 132
    .line 133
    invoke-virtual {v11, v14}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    move-object/from16 v22, v6

    .line 137
    .line 138
    const-string v6, "validationCheck"

    .line 139
    .line 140
    invoke-virtual {v11, v6}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v11, v0, v3}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    move-object/from16 v23, v3

    .line 147
    .line 148
    const-string v3, "ANDROID"

    .line 149
    .line 150
    invoke-virtual {v11, v7, v3}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v11, v12, v4}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v11, v13, v5}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    const-string v0, "Content-Type"

    .line 160
    .line 161
    const-string v7, "application/json"

    .line 162
    .line 163
    invoke-virtual {v11, v0, v7}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    sget-object v0, Lxa/h;->a:Ljava/lang/String;

    .line 167
    .line 168
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 169
    .line 170
    .line 171
    move-result v0

    .line 172
    if-eqz v0, :cond_1

    .line 173
    .line 174
    new-instance v0, Ljava/lang/StringBuilder;

    .line 175
    .line 176
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 177
    .line 178
    .line 179
    invoke-static {}, Lcom/transsnet/palmpay/util/AppUtils;->getAppName()Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v7

    .line 183
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    const-string v7, "/"

    .line 187
    .line 188
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 189
    .line 190
    .line 191
    invoke-static {}, Landroidx/work/impl/model/b;->f()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v7

    .line 195
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 196
    .line 197
    .line 198
    const-string v7, " (Android "

    .line 199
    .line 200
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 201
    .line 202
    .line 203
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getSDKVersionName()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v7

    .line 207
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 208
    .line 209
    .line 210
    const-string v7, ")"

    .line 211
    .line 212
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 213
    .line 214
    .line 215
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    sput-object v0, Lxa/h;->a:Ljava/lang/String;

    .line 220
    .line 221
    :cond_1
    sget-object v0, Lxa/h;->a:Ljava/lang/String;

    .line 222
    .line 223
    const-string v7, "User-Agent"

    .line 224
    .line 225
    invoke-virtual {v11, v7, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 226
    .line 227
    .line 228
    const-string v0, "appSource"

    .line 229
    .line 230
    const-string v7, "0"

    .line 231
    .line 232
    invoke-virtual {v11, v0, v7}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 233
    .line 234
    .line 235
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getChannel()Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    invoke-virtual {v11, v2, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    :try_start_0
    iget-object v0, v1, Lokhttp3/Y;->a:Lokhttp3/J;

    .line 243
    .line 244
    iget-object v0, v0, Lokhttp3/J;->i:Ljava/lang/String;

    .line 245
    .line 246
    invoke-static {v0, v10}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    const-string v2, "/api/cfront/cashLoan/initApplyLog"

    .line 251
    .line 252
    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 253
    .line 254
    .line 255
    move-result v2

    .line 256
    if-eqz v2, :cond_2

    .line 257
    .line 258
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 259
    .line 260
    .line 261
    move-result-object v2

    .line 262
    invoke-static {v2}, LPa/i0;->x(Lcom/transsnet/palmpay/core/base/BaseApplication;)Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object v2

    .line 266
    invoke-virtual {v11, v14, v2}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 267
    .line 268
    .line 269
    goto :goto_1

    .line 270
    :catch_0
    move-exception v0

    .line 271
    goto :goto_2

    .line 272
    :cond_2
    :goto_1
    sget-object v2, LPa/s;->a:LPa/s;

    .line 273
    .line 274
    invoke-static {v0}, LPa/s;->a(Ljava/lang/String;)Z

    .line 275
    .line 276
    .line 277
    move-result v0

    .line 278
    if-nez v0, :cond_3

    .line 279
    .line 280
    const-string v0, "disable"

    .line 281
    .line 282
    invoke-virtual {v11, v6, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 283
    .line 284
    .line 285
    goto :goto_3

    .line 286
    :goto_2
    filled-new-array {v8, v0}, [Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    invoke-static {v9, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 291
    .line 292
    .line 293
    :cond_3
    :goto_3
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 294
    .line 295
    .line 296
    move-result-object v0

    .line 297
    invoke-virtual {v0}, Lya/a;->f()Lcom/transsnet/palmpay/core/bean/LocationRecord;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    if-eqz v0, :cond_4

    .line 302
    .line 303
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->isExpired()Z

    .line 304
    .line 305
    .line 306
    move-result v2

    .line 307
    if-nez v2, :cond_4

    .line 308
    .line 309
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLatitude()D

    .line 310
    .line 311
    .line 312
    move-result-wide v6

    .line 313
    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object v2

    .line 317
    invoke-virtual {v11, v15, v2}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLongitude()D

    .line 321
    .line 322
    .line 323
    move-result-wide v6

    .line 324
    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    move-object/from16 v2, v22

    .line 329
    .line 330
    invoke-virtual {v11, v2, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 331
    .line 332
    .line 333
    :cond_4
    sget-object v0, Lxa/h;->b:Ljava/lang/String;

    .line 334
    .line 335
    if-nez v0, :cond_5

    .line 336
    .line 337
    const-string v0, "key_env_tag"

    .line 338
    .line 339
    const-string v2, ""

    .line 340
    .line 341
    invoke-static {v0, v2}, Le1/a;->I(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object v0

    .line 345
    sput-object v0, Lxa/h;->b:Ljava/lang/String;

    .line 346
    .line 347
    :cond_5
    sget-object v0, Lxa/h;->b:Ljava/lang/String;

    .line 348
    .line 349
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 350
    .line 351
    .line 352
    move-result v2

    .line 353
    if-nez v2, :cond_6

    .line 354
    .line 355
    const-string v2, "x-mse-tag"

    .line 356
    .line 357
    invoke-virtual {v11, v2, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 358
    .line 359
    .line 360
    :cond_6
    invoke-static/range {v16 .. v16}, Lcom/transsnet/palmpay/util/StringUtils;->null2Length0(Ljava/lang/String;)Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v0

    .line 364
    move-object/from16 v2, v21

    .line 365
    .line 366
    invoke-virtual {v11, v2, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 367
    .line 368
    .line 369
    iget-object v0, v1, Lokhttp3/Y;->d:Lokhttp3/c0;

    .line 370
    .line 371
    invoke-static {v0}, Lxa/a;->b(Lokhttp3/c0;)Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v7

    .line 375
    :try_start_1
    const-string v0, "Yes"

    .line 376
    .line 377
    move-object/from16 v2, v20

    .line 378
    .line 379
    invoke-virtual {v1, v2}, Lokhttp3/Y;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 380
    .line 381
    .line 382
    move-result-object v1

    .line 383
    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 384
    .line 385
    .line 386
    move-result v0

    .line 387
    if-eqz v0, :cond_7

    .line 388
    .line 389
    invoke-virtual {v11, v2}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 390
    .line 391
    .line 392
    move-object/from16 v6, v16

    .line 393
    .line 394
    move-object/from16 v2, v23

    .line 395
    .line 396
    filled-new-array/range {v2 .. v7}, [Ljava/lang/String;

    .line 397
    .line 398
    .line 399
    move-result-object v0

    .line 400
    invoke-static {v0}, Lcom/transsnet/palmpay/security/utils/SecurityUtils;->f([Ljava/lang/String;)Ljava/lang/String;

    .line 401
    .line 402
    .line 403
    move-result-object v0

    .line 404
    invoke-static {v0, v10}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 405
    .line 406
    .line 407
    move-result-object v0

    .line 408
    move-object/from16 v1, v19

    .line 409
    .line 410
    invoke-virtual {v11, v1, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 411
    .line 412
    .line 413
    goto :goto_5

    .line 414
    :catch_1
    move-exception v0

    .line 415
    goto :goto_4

    .line 416
    :cond_7
    move-object/from16 v6, v16

    .line 417
    .line 418
    move-object/from16 v2, v23

    .line 419
    .line 420
    invoke-static {v2, v4, v5, v6}, Lcom/transsnet/palmpay/security/utils/SecurityUtils;->g(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 421
    .line 422
    .line 423
    move-result-object v0

    .line 424
    invoke-static {v0, v10}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 425
    .line 426
    .line 427
    move-result-object v0

    .line 428
    move-object/from16 v1, v17

    .line 429
    .line 430
    invoke-virtual {v11, v1, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 431
    .line 432
    .line 433
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 434
    .line 435
    .line 436
    move-result v0

    .line 437
    if-nez v0, :cond_8

    .line 438
    .line 439
    invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B

    .line 440
    .line 441
    .line 442
    move-result-object v0

    .line 443
    invoke-static {v0}, Lcom/transsnet/palmpay/security/utils/SecurityUtils;->e([B)Ljava/lang/String;

    .line 444
    .line 445
    .line 446
    move-result-object v0

    .line 447
    invoke-static {v0, v10}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v0

    .line 451
    move-object/from16 v1, v18

    .line 452
    .line 453
    invoke-virtual {v11, v1, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 454
    .line 455
    .line 456
    goto :goto_5

    .line 457
    :goto_4
    filled-new-array {v8, v0}, [Ljava/lang/Object;

    .line 458
    .line 459
    .line 460
    move-result-object v0

    .line 461
    invoke-static {v9, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 462
    .line 463
    .line 464
    :cond_8
    :goto_5
    invoke-virtual {v11}, Lokhttp3/X;->b()Lokhttp3/Y;

    .line 465
    .line 466
    .line 467
    move-result-object v1

    .line 468
    goto/16 :goto_0

    .line 469
    .line 470
    :goto_6
    invoke-interface {v2, v1}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 471
    .line 472
    .line 473
    move-result-object v0

    .line 474
    return-object v0
.end method
