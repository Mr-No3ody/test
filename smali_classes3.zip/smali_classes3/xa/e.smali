.class public final Lxa/e;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Ljava/util/Map;


# direct methods
.method public constructor <init>(Ljava/util/Map;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lxa/e;->a:Ljava/util/Map;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 1

    .line 1
    new-instance p1, Lxa/e;

    .line 2
    .line 3
    iget-object v0, p0, Lxa/e;->a:Ljava/util/Map;

    .line 4
    .line 5
    invoke-direct {p1, v0, p2}, Lxa/e;-><init>(Ljava/util/Map;Lkotlin/coroutines/Continuation;)V

    .line 6
    .line 7
    .line 8
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lxa/e;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lxa/e;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lxa/e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    const-string v0, "CronetWrapInterceptor"

    .line 2
    .line 3
    const-string v1, "setCronetMetricToNQE "

    .line 4
    .line 5
    sget-object v2, LEf/a;->a:LEf/a;

    .line 6
    .line 7
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    iget-object p1, p0, Lxa/e;->a:Ljava/util/Map;

    .line 11
    .line 12
    if-eqz p1, :cond_9

    .line 13
    .line 14
    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    if-eqz v2, :cond_0

    .line 19
    .line 20
    goto/16 :goto_6

    .line 21
    .line 22
    :cond_0
    const/4 v2, 0x5

    .line 23
    :try_start_0
    new-instance v3, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;

    .line 24
    .line 25
    invoke-direct {v3}, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;-><init>()V

    .line 26
    .line 27
    .line 28
    const-string v4, "httpRTT"

    .line 29
    .line 30
    invoke-interface {p1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    check-cast v4, Ljava/lang/String;

    .line 35
    .line 36
    const/4 v5, 0x0

    .line 37
    if-eqz v4, :cond_2

    .line 38
    .line 39
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    .line 40
    .line 41
    .line 42
    move-result v6

    .line 43
    if-lez v6, :cond_1

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    move-object v4, v5

    .line 47
    :goto_0
    if-eqz v4, :cond_2

    .line 48
    .line 49
    invoke-static {v4}, Lkotlin/text/StringsKt;->U(Ljava/lang/String;)Ljava/lang/Long;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    if-eqz v4, :cond_2

    .line 54
    .line 55
    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    .line 56
    .line 57
    .line 58
    move-result-wide v6

    .line 59
    new-instance v4, Ljava/lang/Long;

    .line 60
    .line 61
    invoke-direct {v4, v6, v7}, Ljava/lang/Long;-><init>(J)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v3, v4}, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;->setHttpRTT(Ljava/lang/Long;)V

    .line 65
    .line 66
    .line 67
    goto :goto_1

    .line 68
    :catch_0
    move-exception p1

    .line 69
    goto/16 :goto_4

    .line 70
    .line 71
    :cond_2
    :goto_1
    const-string v4, "transportRTT"

    .line 72
    .line 73
    invoke-interface {p1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    check-cast v4, Ljava/lang/String;

    .line 78
    .line 79
    if-eqz v4, :cond_4

    .line 80
    .line 81
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    .line 82
    .line 83
    .line 84
    move-result v6

    .line 85
    if-lez v6, :cond_3

    .line 86
    .line 87
    goto :goto_2

    .line 88
    :cond_3
    move-object v4, v5

    .line 89
    :goto_2
    if-eqz v4, :cond_4

    .line 90
    .line 91
    invoke-static {v4}, Lkotlin/text/StringsKt;->U(Ljava/lang/String;)Ljava/lang/Long;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    if-eqz v4, :cond_4

    .line 96
    .line 97
    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    .line 98
    .line 99
    .line 100
    move-result-wide v6

    .line 101
    new-instance v4, Ljava/lang/Long;

    .line 102
    .line 103
    invoke-direct {v4, v6, v7}, Ljava/lang/Long;-><init>(J)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v3, v4}, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;->setTransportRTT(Ljava/lang/Long;)V

    .line 107
    .line 108
    .line 109
    :cond_4
    const-string v4, "success"

    .line 110
    .line 111
    invoke-interface {p1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v4

    .line 115
    check-cast v4, Ljava/lang/String;

    .line 116
    .line 117
    if-eqz v4, :cond_6

    .line 118
    .line 119
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    .line 120
    .line 121
    .line 122
    move-result v6

    .line 123
    if-lez v6, :cond_5

    .line 124
    .line 125
    goto :goto_3

    .line 126
    :cond_5
    move-object v4, v5

    .line 127
    :goto_3
    if-eqz v4, :cond_6

    .line 128
    .line 129
    const-string v6, "1"

    .line 130
    .line 131
    invoke-virtual {v4, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v4

    .line 135
    invoke-virtual {v3, v4}, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;->setSuccessed(Z)V

    .line 136
    .line 137
    .line 138
    :cond_6
    const-string v4, "protocol"

    .line 139
    .line 140
    invoke-interface {p1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    check-cast p1, Ljava/lang/String;

    .line 145
    .line 146
    if-eqz p1, :cond_8

    .line 147
    .line 148
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 149
    .line 150
    .line 151
    move-result v4

    .line 152
    if-lez v4, :cond_7

    .line 153
    .line 154
    move-object v5, p1

    .line 155
    :cond_7
    if-eqz v5, :cond_8

    .line 156
    .line 157
    invoke-virtual {v3, v5}, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;->setProtocol(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    :cond_8
    const/4 p1, 0x1

    .line 161
    invoke-virtual {v3, p1}, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;->setType(I)V

    .line 162
    .line 163
    .line 164
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 165
    .line 166
    .line 167
    move-result-wide v4

    .line 168
    invoke-virtual {v3, v4, v5}, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;->setElapsedTime(J)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v3}, Lcom/palmpay/lib/apm/network/bean/NQEMetrics;->isSuccessed()Z

    .line 172
    .line 173
    .line 174
    move-result p1

    .line 175
    new-instance v4, Ljava/lang/StringBuilder;

    .line 176
    .line 177
    invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    invoke-static {v0, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 192
    .line 193
    .line 194
    sget-object p1, Lcom/palmpay/lib/apm/network/NQEManager;->INSTANCE:Lcom/palmpay/lib/apm/network/NQEManager;

    .line 195
    .line 196
    invoke-virtual {p1, v3}, Lcom/palmpay/lib/apm/network/NQEManager;->addMetrics(Lcom/palmpay/lib/apm/network/bean/NQEMetrics;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 197
    .line 198
    .line 199
    goto :goto_5

    .line 200
    :goto_4
    const-string v1, "Error setting Cronet metrics"

    .line 201
    .line 202
    filled-new-array {v1, p1}, [Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object p1

    .line 206
    invoke-static {v0, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 207
    .line 208
    .line 209
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 210
    .line 211
    return-object p1

    .line 212
    :cond_9
    :goto_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 213
    .line 214
    return-object p1
.end method
