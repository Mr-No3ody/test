.class public final Lxa/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/net/cronet/okhttptransport/CronetLogHelper$OnMetricCallback;


# instance fields
.field public final synthetic a:Lxa/f;


# direct methods
.method public constructor <init>(Lxa/f;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lxa/d;->a:Lxa/f;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onMetric(Ljava/util/Map;)V
    .locals 4

    .line 1
    const-string v0, "metricsMap"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lxa/d;->a:Lxa/f;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    sget-object v0, LWf/V;->a:LWf/V;

    .line 12
    .line 13
    sget-object v1, LWf/I;->a:Lcg/f;

    .line 14
    .line 15
    sget-object v1, Lcg/e;->c:Lcg/e;

    .line 16
    .line 17
    new-instance v2, Lxa/e;

    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    invoke-direct {v2, p1, v3}, Lxa/e;-><init>(Ljava/util/Map;Lkotlin/coroutines/Continuation;)V

    .line 21
    .line 22
    .line 23
    const/4 p1, 0x2

    .line 24
    invoke-static {v0, v1, v3, v2, p1}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 25
    .line 26
    .line 27
    return-void
.end method
