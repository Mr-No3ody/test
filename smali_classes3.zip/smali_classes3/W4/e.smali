.class public final synthetic LW4/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/growingio/android/hybrid/OnDomChangedListener;


# instance fields
.field public final synthetic a:LV4/a;


# direct methods
.method public synthetic constructor <init>(LV4/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LW4/e;->a:LV4/a;

    return-void
.end method


# virtual methods
.method public final onDomChanged()V
    .locals 1

    .line 1
    iget-object v0, p0, LW4/e;->a:LV4/a;

    .line 2
    .line 3
    iget-object v0, v0, LV4/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/growingio/android/sdk/track/modelloader/data/HybridDom$OnDomChangedListener;

    .line 6
    .line 7
    invoke-interface {v0}, Lcom/growingio/android/sdk/track/modelloader/data/HybridDom$OnDomChangedListener;->onDomChanged()V

    .line 8
    .line 9
    .line 10
    return-void
.end method
