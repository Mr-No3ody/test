.class public final LW4/d;
.super LD4/f;
.source "SourceFile"


# instance fields
.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LW4/d;->c:I

    const/4 p1, 0x7

    invoke-direct {p0, p1}, LD4/f;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final u(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LW4/d;->c:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/growingio/android/sdk/track/listener/OnUserIdChangedListener;

    .line 7
    .line 8
    check-cast p2, Ljava/lang/String;

    .line 9
    .line 10
    invoke-interface {p1, p2}, Lcom/growingio/android/sdk/track/listener/OnUserIdChangedListener;->onUserIdChanged(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    check-cast p1, Lcom/growingio/android/hybrid/OnDomChangedListener;

    .line 15
    .line 16
    check-cast p2, Ljava/lang/Void;

    .line 17
    .line 18
    invoke-interface {p1}, Lcom/growingio/android/hybrid/OnDomChangedListener;->onDomChanged()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public w(Ljava/lang/String;)V
    .locals 7

    .line 1
    invoke-static {}, Ls5/d;->b()Ls5/d;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Ls5/d;->b:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Lcom/growingio/android/sdk/a;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    const-string v1, "UserInfoPolicy"

    .line 14
    .line 15
    if-eqz p1, :cond_0

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    const/16 v3, 0x3e8

    .line 22
    .line 23
    if-le v2, v3, :cond_0

    .line 24
    .line 25
    const-string p1, "GrowingIO.setUserId(KEY, VALUE):VALUE\u957f\u5ea6\u5927\u4e8e1000\uff0c\u4e0d\u53d1\u9001"

    .line 26
    .line 27
    new-array v0, v0, [Ljava/lang/Object;

    .line 28
    .line 29
    invoke-static {v1, p1, v0}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    const/4 v3, 0x0

    .line 38
    if-eqz v2, :cond_1

    .line 39
    .line 40
    sget-object p1, Lk5/e;->a:Lk5/f;

    .line 41
    .line 42
    invoke-virtual {p1, v3}, Lk5/f;->a(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    const-string p1, "clean the userId (and will also clean the userKey"

    .line 46
    .line 47
    new-array v0, v0, [Ljava/lang/Object;

    .line 48
    .line 49
    invoke-static {v1, p1, v0}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0, v3}, LD4/f;->l(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_1
    sget-object v2, Lk5/e;->a:Lk5/f;

    .line 57
    .line 58
    iget-object v4, v2, Lk5/f;->a:Lk5/d;

    .line 59
    .line 60
    const-string v5, "LOGIN_USER_ID"

    .line 61
    .line 62
    const-string v6, ""

    .line 63
    .line 64
    invoke-virtual {v4, v5, v6}, Lk5/d;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    if-eq p1, v4, :cond_6

    .line 69
    .line 70
    if-eqz p1, :cond_2

    .line 71
    .line 72
    invoke-virtual {p1, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v4

    .line 76
    if-eqz v4, :cond_2

    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_2
    invoke-virtual {p0, p1}, LD4/f;->l(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 83
    .line 84
    .line 85
    invoke-virtual {v2, p1}, Lk5/f;->a(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    iget-object v2, v2, Lk5/f;->a:Lk5/d;

    .line 89
    .line 90
    const-string v3, "LATEST_NON_NULL_USER_ID"

    .line 91
    .line 92
    invoke-virtual {v2, v3, v6}, Lk5/d;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v4

    .line 96
    const-string v5, "onUserIdChanged: newUserId = "

    .line 97
    .line 98
    const-string v6, ", mLatestNonNullUserId = "

    .line 99
    .line 100
    invoke-static {v5, p1, v6, v4}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    new-array v0, v0, [Ljava/lang/Object;

    .line 105
    .line 106
    invoke-static {v1, v5, v0}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    if-eqz p1, :cond_5

    .line 110
    .line 111
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    if-eqz v0, :cond_5

    .line 116
    .line 117
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 118
    .line 119
    .line 120
    move-result v0

    .line 121
    if-eqz v0, :cond_3

    .line 122
    .line 123
    sget-object v0, Ls5/l;->a:Ls5/m;

    .line 124
    .line 125
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 126
    .line 127
    .line 128
    invoke-static {}, Ls5/m;->a()V

    .line 129
    .line 130
    .line 131
    goto :goto_0

    .line 132
    :cond_3
    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-nez v0, :cond_4

    .line 137
    .line 138
    sget-object v0, Ls5/l;->a:Ls5/m;

    .line 139
    .line 140
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 141
    .line 142
    .line 143
    invoke-static {}, Ls5/m;->b()V

    .line 144
    .line 145
    .line 146
    invoke-static {}, Ls5/m;->a()V

    .line 147
    .line 148
    .line 149
    :cond_4
    :goto_0
    invoke-virtual {v2, v3, p1}, Lk5/d;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    :cond_5
    return-void

    .line 153
    :cond_6
    :goto_1
    iget-object v4, v2, Lk5/f;->a:Lk5/d;

    .line 154
    .line 155
    const-string v5, "LOGIN_USER_KEY"

    .line 156
    .line 157
    invoke-virtual {v4, v5, v6}, Lk5/d;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v4

    .line 161
    if-eqz v4, :cond_8

    .line 162
    .line 163
    if-eqz v4, :cond_7

    .line 164
    .line 165
    invoke-virtual {v4, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 166
    .line 167
    .line 168
    move-result v3

    .line 169
    if-eqz v3, :cond_7

    .line 170
    .line 171
    goto :goto_2

    .line 172
    :cond_7
    invoke-virtual {v2, p1}, Lk5/f;->a(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    :cond_8
    :goto_2
    const-string p1, "setUserId, but the userId is same as the old userId, just return"

    .line 176
    .line 177
    new-array v0, v0, [Ljava/lang/Object;

    .line 178
    .line 179
    invoke-static {v1, p1, v0}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    return-void
.end method
