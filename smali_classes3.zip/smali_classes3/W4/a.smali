.class public final LW4/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/growingio/android/sdk/track/modelloader/ModelLoader;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LW4/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final buildLoadData(Ljava/lang/Object;)Lq5/a;
    .locals 3

    .line 1
    iget v0, p0, LW4/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lp5/b;

    .line 7
    .line 8
    new-instance v0, Lq5/a;

    .line 9
    .line 10
    new-instance v1, Ld3/k;

    .line 11
    .line 12
    const/16 v2, 0xb

    .line 13
    .line 14
    invoke-direct {v1, p1, v2}, Ld3/k;-><init>(Ljava/lang/Object;I)V

    .line 15
    .line 16
    .line 17
    invoke-direct {v0, v1}, Lq5/a;-><init>(Lcom/growingio/android/sdk/track/modelloader/DataFetcher;)V

    .line 18
    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_0
    if-nez p1, :cond_0

    .line 22
    .line 23
    new-instance p1, Lq5/a;

    .line 24
    .line 25
    new-instance v0, Lorg/sufficientlysecure/htmltextview/n;

    .line 26
    .line 27
    const/4 v1, 0x2

    .line 28
    invoke-direct {v0, v1}, Lorg/sufficientlysecure/htmltextview/n;-><init>(I)V

    .line 29
    .line 30
    .line 31
    invoke-direct {p1, v0}, Lq5/a;-><init>(Lcom/growingio/android/sdk/track/modelloader/DataFetcher;)V

    .line 32
    .line 33
    .line 34
    return-object p1

    .line 35
    :cond_0
    new-instance p1, Ljava/lang/ClassCastException;

    .line 36
    .line 37
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 38
    .line 39
    .line 40
    throw p1

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
