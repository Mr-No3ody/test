.class public final LW4/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/growingio/android/sdk/track/async/Callback;


# instance fields
.field public final synthetic a:Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;


# direct methods
.method public constructor <init>(Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LW4/f;->a:Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onFailed()V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/RuntimeException;

    .line 2
    .line 3
    const-string v1, "getWebViewDomTree error"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LW4/f;->a:Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;

    .line 9
    .line 10
    invoke-interface {v1, v0}, Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;->onLoadFailed(Ljava/lang/Exception;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onSuccess(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lorg/json/JSONObject;

    .line 2
    .line 3
    new-instance v0, Lr5/c;

    .line 4
    .line 5
    invoke-direct {v0, p1}, Lr5/c;-><init>(Lorg/json/JSONObject;)V

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, LW4/f;->a:Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;

    .line 9
    .line 10
    invoke-interface {p1, v0}, Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;->onDataReady(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
