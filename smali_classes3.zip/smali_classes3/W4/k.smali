.class public final LW4/k;
.super LD4/f;
.source "SourceFile"


# virtual methods
.method public final m(Ljava/lang/String;LW4/b;)V
    .locals 1

    .line 1
    iget-object p2, p0, LD4/f;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p2, Landroid/view/View;

    .line 4
    .line 5
    check-cast p2, Lcom/tencent/smtt/sdk/WebView;

    .line 6
    .line 7
    new-instance v0, LW4/j;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p2, p1, v0}, Lcom/tencent/smtt/sdk/WebView;->evaluateJavascript(Ljava/lang/String;Lcom/tencent/smtt/sdk/ValueCallback;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
