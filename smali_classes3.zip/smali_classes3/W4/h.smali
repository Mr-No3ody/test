.class public final LW4/h;
.super LD4/f;
.source "SourceFile"


# virtual methods
.method public final m(Ljava/lang/String;LW4/b;)V
    .locals 1

    .line 1
    iget-object v0, p0, LD4/f;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/View;

    .line 4
    .line 5
    check-cast v0, Landroid/webkit/WebView;

    .line 6
    .line 7
    invoke-virtual {v0, p1, p2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
