.class public final LW4/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher;


# instance fields
.field public final a:Lr5/b;


# direct methods
.method public constructor <init>(Lr5/b;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LW4/g;->a:Lr5/b;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()LD4/f;
    .locals 3

    .line 1
    iget-object v0, p0, LW4/g;->a:Lr5/b;

    .line 2
    .line 3
    iget-object v1, v0, Lr5/b;->a:Landroid/view/View;

    .line 4
    .line 5
    instance-of v2, v1, Landroid/webkit/WebView;

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    check-cast v1, Landroid/webkit/WebView;

    .line 10
    .line 11
    new-instance v0, LW4/h;

    .line 12
    .line 13
    const/4 v2, 0x2

    .line 14
    invoke-direct {v0, v1, v2}, LD4/f;-><init>(Ljava/lang/Object;I)V

    .line 15
    .line 16
    .line 17
    return-object v0

    .line 18
    :cond_0
    invoke-static {v1}, Lt5/a;->c(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-eqz v1, :cond_1

    .line 23
    .line 24
    iget-object v0, v0, Lr5/b;->a:Landroid/view/View;

    .line 25
    .line 26
    check-cast v0, Lcom/tencent/smtt/sdk/WebView;

    .line 27
    .line 28
    new-instance v1, LW4/k;

    .line 29
    .line 30
    const/4 v2, 0x2

    .line 31
    invoke-direct {v1, v0, v2}, LD4/f;-><init>(Ljava/lang/Object;I)V

    .line 32
    .line 33
    .line 34
    return-object v1

    .line 35
    :cond_1
    iget-object v1, v0, Lr5/b;->a:Landroid/view/View;

    .line 36
    .line 37
    invoke-static {v1}, Lt5/a;->b(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    iget-object v0, v0, Lr5/b;->a:Landroid/view/View;

    .line 44
    .line 45
    check-cast v0, Lcom/uc/webview/export/WebView;

    .line 46
    .line 47
    new-instance v1, LW4/i;

    .line 48
    .line 49
    const/4 v2, 0x2

    .line 50
    invoke-direct {v1, v0, v2}, LD4/f;-><init>(Ljava/lang/Object;I)V

    .line 51
    .line 52
    .line 53
    return-object v1

    .line 54
    :cond_2
    const/4 v0, 0x0

    .line 55
    return-object v0
.end method

.method public final executeData()Ljava/lang/Object;
    .locals 2

    .line 1
    new-instance v0, Lr5/c;

    .line 2
    .line 3
    new-instance v1, Lorg/json/JSONObject;

    .line 4
    .line 5
    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1}, Lr5/c;-><init>(Lorg/json/JSONObject;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final getDataClass()Ljava/lang/Class;
    .locals 1

    .line 1
    const-class v0, Lr5/c;

    .line 2
    .line 3
    return-object v0
.end method

.method public final loadData(Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;)V
    .locals 7

    .line 1
    iget-object v0, p0, LW4/g;->a:Lr5/b;

    .line 2
    .line 3
    iget-object v0, v0, Lr5/b;->a:Landroid/view/View;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Ljava/lang/NullPointerException;

    .line 8
    .line 9
    const-string v1, "webview is null"

    .line 10
    .line 11
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-interface {p1, v0}, Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;->onLoadFailed(Ljava/lang/Exception;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_0
    invoke-virtual {p0}, LW4/g;->a()LD4/f;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 25
    .line 26
    iget-object v1, p0, LW4/g;->a:Lr5/b;

    .line 27
    .line 28
    iget-object v1, v1, Lr5/b;->a:Landroid/view/View;

    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    const-string v2, "is not webView"

    .line 39
    .line 40
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-interface {p1, v0}, Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;->onLoadFailed(Ljava/lang/Exception;)V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :cond_1
    sget-object v1, LW4/c;->a:LW4/d;

    .line 52
    .line 53
    new-instance v2, LW4/f;

    .line 54
    .line 55
    invoke-direct {v2, p1}, LW4/f;-><init>(Lcom/growingio/android/sdk/track/modelloader/LoadDataFetcher$DataCallback;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    const/4 p1, 0x0

    .line 62
    new-array v1, p1, [Ljava/lang/Object;

    .line 63
    .line 64
    const-string v3, "HybridBridgePolicy"

    .line 65
    .line 66
    const-string v4, "getWebViewDomTree"

    .line 67
    .line 68
    invoke-static {v3, v4, v1}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    sget-object v1, Lf5/a;->a:Lf5/a;

    .line 72
    .line 73
    new-instance v3, Lf5/c;

    .line 74
    .line 75
    invoke-direct {v3}, Lf5/c;-><init>()V

    .line 76
    .line 77
    .line 78
    new-instance v4, LM7/s;

    .line 79
    .line 80
    const/16 v5, 0x1d

    .line 81
    .line 82
    invoke-direct {v4, v2, v5}, LM7/s;-><init>(Ljava/lang/Object;I)V

    .line 83
    .line 84
    .line 85
    iget-boolean v5, v3, Lf5/c;->b:Z

    .line 86
    .line 87
    if-eqz v5, :cond_2

    .line 88
    .line 89
    goto :goto_0

    .line 90
    :cond_2
    new-instance v1, Lf5/b;

    .line 91
    .line 92
    iget-object v5, v3, Lf5/c;->a:Landroid/os/Handler;

    .line 93
    .line 94
    invoke-direct {v1, v5, v4}, Lf5/b;-><init>(Landroid/os/Handler;LM7/s;)V

    .line 95
    .line 96
    .line 97
    invoke-static {v5, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;Ljava/lang/Runnable;)Landroid/os/Message;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    iput-object v3, v4, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 102
    .line 103
    iget-object v3, v3, Lf5/c;->a:Landroid/os/Handler;

    .line 104
    .line 105
    const-wide/16 v5, 0x1388

    .line 106
    .line 107
    invoke-virtual {v3, v4, v5, v6}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    .line 108
    .line 109
    .line 110
    :goto_0
    const/4 v3, 0x2

    .line 111
    new-array v3, v3, [I

    .line 112
    .line 113
    iget-object v4, v0, LD4/f;->b:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v4, Landroid/view/View;

    .line 116
    .line 117
    invoke-virtual {v4, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 118
    .line 119
    .line 120
    new-instance v4, Ljava/lang/StringBuilder;

    .line 121
    .line 122
    const-string v5, "javascript:window.GrowingWebViewJavascriptBridge.getDomTree("

    .line 123
    .line 124
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    aget p1, v3, p1

    .line 128
    .line 129
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 130
    .line 131
    .line 132
    const-string p1, ", "

    .line 133
    .line 134
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 135
    .line 136
    .line 137
    const/4 v5, 0x1

    .line 138
    aget v3, v3, v5

    .line 139
    .line 140
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 141
    .line 142
    .line 143
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 144
    .line 145
    .line 146
    iget-object v3, v0, LD4/f;->b:Ljava/lang/Object;

    .line 147
    .line 148
    check-cast v3, Landroid/view/View;

    .line 149
    .line 150
    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    .line 151
    .line 152
    .line 153
    move-result v3

    .line 154
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    iget-object p1, v0, LD4/f;->b:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast p1, Landroid/view/View;

    .line 163
    .line 164
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 165
    .line 166
    .line 167
    move-result p1

    .line 168
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    const-string p1, ", 100)"

    .line 172
    .line 173
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 174
    .line 175
    .line 176
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object p1

    .line 180
    new-instance v3, LW4/b;

    .line 181
    .line 182
    invoke-direct {v3, v1, v2}, LW4/b;-><init>(Lcom/growingio/android/sdk/track/async/Disposable;LW4/f;)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {v0, p1, v3}, LD4/f;->m(Ljava/lang/String;LW4/b;)V

    .line 186
    .line 187
    .line 188
    return-void
.end method
