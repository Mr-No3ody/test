.class public final synthetic Lma/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lma/i;


# direct methods
.method public synthetic constructor <init>(Lma/i;I)V
    .locals 0

    .line 1
    iput p2, p0, Lma/g;->a:I

    iput-object p1, p0, Lma/g;->b:Lma/i;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, Lma/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget v0, Lba/e;->iv_close:I

    .line 7
    .line 8
    iget-object v1, p0, Lma/g;->b:Lma/i;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Landroidx/appcompat/app/K;->findViewById(I)Landroid/view/View;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Landroid/widget/ImageView;

    .line 15
    .line 16
    return-object v0

    .line 17
    :pswitch_0
    sget v0, Lba/e;->wv_protocol:I

    .line 18
    .line 19
    iget-object v1, p0, Lma/g;->b:Lma/i;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Landroidx/appcompat/app/K;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/AndroidXWebView;

    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_1
    sget v0, Lba/e;->tv_confirm:I

    .line 29
    .line 30
    iget-object v1, p0, Lma/g;->b:Lma/i;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroidx/appcompat/app/K;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroid/widget/TextView;

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
