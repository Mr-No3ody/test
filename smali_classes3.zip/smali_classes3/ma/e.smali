.class public final Lma/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, Lma/e;->a:I

    iput-object p1, p0, Lma/e;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    const-string v0, "/main/home"

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, Lma/e;->b:Ljava/lang/Object;

    .line 6
    .line 7
    iget v4, p0, Lma/e;->a:I

    .line 8
    .line 9
    packed-switch v4, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    if-eqz p1, :cond_9

    .line 13
    .line 14
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    instance-of v0, v0, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsClaimClickEvent;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    move-object v0, p1

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    move-object v0, v2

    .line 25
    :goto_0
    if-eqz v0, :cond_9

    .line 26
    .line 27
    invoke-virtual {v0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    const-string v4, "null cannot be cast to non-null type com.transsnet.palmpay.main.export.bean.rsp.HomeRewardsClaimClickEvent"

    .line 32
    .line 33
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    check-cast v0, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsClaimClickEvent;

    .line 37
    .line 38
    invoke-interface {v0}, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsClaimClickEvent;->takeContentType()Ljava/lang/Integer;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    sget-object v5, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsCenterContentType;->INSTANCE:Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsCenterContentType;

    .line 43
    .line 44
    invoke-virtual {v5}, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsCenterContentType;->getCONTENT_TYPE_REWARD_TASK()I

    .line 45
    .line 46
    .line 47
    move-result v5

    .line 48
    check-cast v3, Lye/j;

    .line 49
    .line 50
    if-nez v4, :cond_1

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_1
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    if-ne v4, v5, :cond_6

    .line 58
    .line 59
    instance-of p1, v0, Lcom/transsnet/palmpay/main/export/bean/rsp/RewardsInfo;

    .line 60
    .line 61
    if-eqz p1, :cond_2

    .line 62
    .line 63
    move-object v2, v0

    .line 64
    check-cast v2, Lcom/transsnet/palmpay/main/export/bean/rsp/RewardsInfo;

    .line 65
    .line 66
    :cond_2
    if-nez v2, :cond_3

    .line 67
    .line 68
    goto/16 :goto_3

    .line 69
    .line 70
    :cond_3
    iget-object p1, v2, Lcom/transsnet/palmpay/main/export/bean/rsp/RewardsInfo;->memberTaskNo:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v1, v2, Lcom/transsnet/palmpay/main/export/bean/rsp/RewardsInfo;->rewardSpecialMemberCycleId:Ljava/lang/Long;

    .line 73
    .line 74
    if-eqz p1, :cond_8

    .line 75
    .line 76
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    if-nez v2, :cond_4

    .line 81
    .line 82
    goto/16 :goto_2

    .line 83
    .line 84
    :cond_4
    if-eqz v1, :cond_8

    .line 85
    .line 86
    iget-object v2, v3, Lye/j;->a:Ljava/lang/ref/WeakReference;

    .line 87
    .line 88
    if-eqz v2, :cond_8

    .line 89
    .line 90
    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    check-cast v2, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;

    .line 95
    .line 96
    if-eqz v2, :cond_8

    .line 97
    .line 98
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    check-cast v2, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;

    .line 103
    .line 104
    if-eqz v2, :cond_8

    .line 105
    .line 106
    invoke-virtual {v2}, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;->E()I

    .line 107
    .line 108
    .line 109
    move-result v3

    .line 110
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;->H(I)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 114
    .line 115
    .line 116
    move-result v3

    .line 117
    if-nez v3, :cond_5

    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_5
    invoke-virtual {v2}, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;->B()Lcom/transsnet/palmpay/ui/fragment/HomePalmZoneTabV2;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    if-eqz v2, :cond_8

    .line 125
    .line 126
    iget-object v2, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 127
    .line 128
    check-cast v2, Lcom/transsnet/palmpay/viewmodule/PalmZoneViewModel;

    .line 129
    .line 130
    if-eqz v2, :cond_8

    .line 131
    .line 132
    invoke-virtual {v2, v1, p1}, Lcom/transsnet/palmpay/viewmodule/PalmZoneViewModel;->e(Ljava/lang/Long;Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_6
    :goto_1
    instance-of v2, p1, Lcom/palmpay/lib/ui/button/PpButton;

    .line 137
    .line 138
    if-eqz v2, :cond_7

    .line 139
    .line 140
    check-cast p1, Lcom/palmpay/lib/ui/button/PpButton;

    .line 141
    .line 142
    invoke-virtual {p1, v1}, Lcom/palmpay/lib/ui/button/PpButton;->b(Z)V

    .line 143
    .line 144
    .line 145
    :cond_7
    iget-object p1, v3, Lye/j;->a:Ljava/lang/ref/WeakReference;

    .line 146
    .line 147
    if-eqz p1, :cond_8

    .line 148
    .line 149
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object p1

    .line 153
    check-cast p1, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;

    .line 154
    .line 155
    if-eqz p1, :cond_8

    .line 156
    .line 157
    new-instance v1, Lcom/transsnet/palmpay/main/export/bean/req/ClaimRewardReq;

    .line 158
    .line 159
    invoke-direct {v1}, Lcom/transsnet/palmpay/main/export/bean/req/ClaimRewardReq;-><init>()V

    .line 160
    .line 161
    .line 162
    invoke-interface {v0}, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsClaimClickEvent;->takeActivityId()Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v2

    .line 166
    iput-object v2, v1, Lcom/transsnet/palmpay/main/export/bean/req/ClaimRewardReq;->activityId:Ljava/lang/String;

    .line 167
    .line 168
    invoke-interface {v0}, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsClaimClickEvent;->takeCouponCode()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    iput-object v2, v1, Lcom/transsnet/palmpay/main/export/bean/req/ClaimRewardReq;->couponCode:Ljava/lang/String;

    .line 173
    .line 174
    invoke-interface {v0}, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsClaimClickEvent;->takeContentType()Ljava/lang/Integer;

    .line 175
    .line 176
    .line 177
    move-result-object v2

    .line 178
    iput-object v2, v1, Lcom/transsnet/palmpay/main/export/bean/req/ClaimRewardReq;->contentType:Ljava/lang/Integer;

    .line 179
    .line 180
    invoke-interface {v0}, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsClaimClickEvent;->takeBizIdList()Ljava/util/List;

    .line 181
    .line 182
    .line 183
    move-result-object v2

    .line 184
    iput-object v2, v1, Lcom/transsnet/palmpay/main/export/bean/req/ClaimRewardReq;->bizIdList:Ljava/util/List;

    .line 185
    .line 186
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMVPFragment;->i:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 187
    .line 188
    check-cast p1, LFe/I;

    .line 189
    .line 190
    if-eqz p1, :cond_8

    .line 191
    .line 192
    invoke-virtual {p1, v1}, LFe/I;->claimRewardsCenterReward(Lcom/transsnet/palmpay/main/export/bean/req/ClaimRewardReq;)V

    .line 193
    .line 194
    .line 195
    :cond_8
    :goto_2
    invoke-static {v0}, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsStatisticsExtKt;->sendStatisticsEvent(Lcom/transsnet/palmpay/main/export/bean/rsp/HomeRewardsClaimClickEvent;)V

    .line 196
    .line 197
    .line 198
    :cond_9
    :goto_3
    return-void

    .line 199
    :pswitch_0
    if-eqz p1, :cond_a

    .line 200
    .line 201
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 202
    .line 203
    .line 204
    move-result p1

    .line 205
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 206
    .line 207
    .line 208
    move-result-object v2

    .line 209
    :cond_a
    sget p1, LAc/e;->tvLogin:I

    .line 210
    .line 211
    check-cast v3, Lcom/transsnet/palmpay/ui/activity/welcome/WelcomeNewUserActivity;

    .line 212
    .line 213
    const-string v0, "business_path"

    .line 214
    .line 215
    if-nez v2, :cond_b

    .line 216
    .line 217
    goto :goto_5

    .line 218
    :cond_b
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 219
    .line 220
    .line 221
    move-result v1

    .line 222
    if-ne v1, p1, :cond_e

    .line 223
    .line 224
    iget-object p1, v3, Lcom/transsnet/palmpay/ui/activity/welcome/WelcomeNewUserActivity;->b:Ljava/lang/String;

    .line 225
    .line 226
    const-string v1, "/account/login"

    .line 227
    .line 228
    if-eqz p1, :cond_d

    .line 229
    .line 230
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 231
    .line 232
    .line 233
    move-result v2

    .line 234
    if-nez v2, :cond_c

    .line 235
    .line 236
    goto :goto_4

    .line 237
    :cond_c
    invoke-static {v1, v0, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->H(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 238
    .line 239
    .line 240
    goto :goto_7

    .line 241
    :cond_d
    :goto_4
    invoke-static {v1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->F(Ljava/lang/String;)V

    .line 242
    .line 243
    .line 244
    goto :goto_7

    .line 245
    :cond_e
    :goto_5
    sget p1, LAc/e;->btnSignUp:I

    .line 246
    .line 247
    if-nez v2, :cond_f

    .line 248
    .line 249
    goto :goto_7

    .line 250
    :cond_f
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 251
    .line 252
    .line 253
    move-result v1

    .line 254
    if-ne v1, p1, :cond_12

    .line 255
    .line 256
    iget-object p1, v3, Lcom/transsnet/palmpay/ui/activity/welcome/WelcomeNewUserActivity;->b:Ljava/lang/String;

    .line 257
    .line 258
    const-string v1, "/account/signup"

    .line 259
    .line 260
    if-eqz p1, :cond_11

    .line 261
    .line 262
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 263
    .line 264
    .line 265
    move-result v2

    .line 266
    if-nez v2, :cond_10

    .line 267
    .line 268
    goto :goto_6

    .line 269
    :cond_10
    invoke-static {v1, v0, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->H(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    goto :goto_7

    .line 273
    :cond_11
    :goto_6
    invoke-static {v1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->F(Ljava/lang/String;)V

    .line 274
    .line 275
    .line 276
    :cond_12
    :goto_7
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 277
    .line 278
    .line 279
    return-void

    .line 280
    :pswitch_1
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 281
    .line 282
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 283
    .line 284
    .line 285
    return-void

    .line 286
    :pswitch_2
    check-cast v3, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantOrderDetailActivity;

    .line 287
    .line 288
    iget-object p1, v3, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantOrderDetailActivity;->a:Ljava/lang/String;

    .line 289
    .line 290
    invoke-virtual {v3, p1}, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantOrderDetailActivity;->n(Ljava/lang/String;)V

    .line 291
    .line 292
    .line 293
    return-void

    .line 294
    :pswitch_3
    check-cast v3, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantActivity;

    .line 295
    .line 296
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 297
    .line 298
    .line 299
    return-void

    .line 300
    :pswitch_4
    check-cast v3, Lcom/transsnet/palmpay/send_money/bean/resp/Data;

    .line 301
    .line 302
    invoke-virtual {v3}, Lcom/transsnet/palmpay/send_money/bean/resp/Data;->getMerchantServiceUrl()Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    move-result-object p1

    .line 306
    invoke-static {p1}, LPa/i0;->b0(Ljava/lang/String;)V

    .line 307
    .line 308
    .line 309
    return-void

    .line 310
    :pswitch_5
    sget p1, Lcom/transsnet/palmpay/ui/activity/settings/SettingsActivity;->d:I

    .line 311
    .line 312
    check-cast v3, Lcom/transsnet/palmpay/ui/activity/settings/SettingsActivity;

    .line 313
    .line 314
    new-instance p1, LO6/c;

    .line 315
    .line 316
    invoke-direct {p1, v3}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 317
    .line 318
    .line 319
    sget v0, LAc/h;->main_log_out:I

    .line 320
    .line 321
    invoke-virtual {p1, v0}, LO6/c;->e(I)V

    .line 322
    .line 323
    .line 324
    sget v0, LAc/h;->main_msg_log_out:I

    .line 325
    .line 326
    invoke-virtual {p1, v0}, LO6/c;->b(I)V

    .line 327
    .line 328
    .line 329
    sget v0, LAc/h;->main_ok:I

    .line 330
    .line 331
    new-instance v2, Lse/f;

    .line 332
    .line 333
    const/4 v4, 0x0

    .line 334
    invoke-direct {v2, v3, v4}, Lse/f;-><init>(Lcom/transsnet/palmpay/ui/activity/settings/SettingsActivity;I)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {p1, v0, v2}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 338
    .line 339
    .line 340
    sget v0, LAc/h;->main_cancel:I

    .line 341
    .line 342
    new-instance v2, Lse/f;

    .line 343
    .line 344
    invoke-direct {v2, v3, v1}, Lse/f;-><init>(Lcom/transsnet/palmpay/ui/activity/settings/SettingsActivity;I)V

    .line 345
    .line 346
    .line 347
    invoke-virtual {p1, v0, v2}, LO6/c;->c(ILandroid/view/View$OnClickListener;)V

    .line 348
    .line 349
    .line 350
    new-instance v0, Lse/f;

    .line 351
    .line 352
    const/4 v1, 0x2

    .line 353
    invoke-direct {v0, v3, v1}, Lse/f;-><init>(Lcom/transsnet/palmpay/ui/activity/settings/SettingsActivity;I)V

    .line 354
    .line 355
    .line 356
    iput-object v0, p1, LO6/c;->j:Landroid/view/View$OnClickListener;

    .line 357
    .line 358
    invoke-virtual {p1}, LO6/c;->g()LO6/d;

    .line 359
    .line 360
    .line 361
    return-void

    .line 362
    :pswitch_6
    check-cast v3, Lcom/transsnet/palmpay/jara_packet/ui/activity/JaraCommissionDetailActivity;

    .line 363
    .line 364
    iget-object p1, v3, Lcom/transsnet/palmpay/jara_packet/ui/activity/JaraCommissionDetailActivity;->a:Ljava/lang/String;

    .line 365
    .line 366
    invoke-virtual {v3, p1}, Lcom/transsnet/palmpay/jara_packet/ui/activity/JaraCommissionDetailActivity;->n(Ljava/lang/String;)V

    .line 367
    .line 368
    .line 369
    return-void

    .line 370
    :pswitch_7
    check-cast v3, Ljava/lang/String;

    .line 371
    .line 372
    invoke-static {v3}, LPa/i0;->b0(Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    return-void

    .line 376
    :pswitch_8
    sget p1, Lcom/transsnet/palmpay/ui/activity/qr/QrcodePayMoneySuccessActivity;->C:I

    .line 377
    .line 378
    check-cast v3, Lcom/transsnet/palmpay/ui/activity/qr/QrcodePayMoneySuccessActivity;

    .line 379
    .line 380
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 381
    .line 382
    .line 383
    move-result-object p1

    .line 384
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 385
    .line 386
    .line 387
    move-result-object p1

    .line 388
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 389
    .line 390
    .line 391
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 392
    .line 393
    .line 394
    return-void

    .line 395
    :pswitch_9
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 396
    .line 397
    .line 398
    move-result p1

    .line 399
    sget v4, LAc/e;->actur_complete_btn:I

    .line 400
    .line 401
    if-ne p1, v4, :cond_13

    .line 402
    .line 403
    invoke-static {v0}, LN8/q0;->u(Ljava/lang/String;)V

    .line 404
    .line 405
    .line 406
    goto :goto_8

    .line 407
    :cond_13
    sget v4, LAc/e;->actur_done_tv:I

    .line 408
    .line 409
    if-ne p1, v4, :cond_14

    .line 410
    .line 411
    invoke-static {v0}, LN8/q0;->u(Ljava/lang/String;)V

    .line 412
    .line 413
    .line 414
    goto :goto_8

    .line 415
    :cond_14
    sget v0, LAc/e;->imageViewShare:I

    .line 416
    .line 417
    if-ne p1, v0, :cond_15

    .line 418
    .line 419
    check-cast v3, Lcom/transsnet/palmpay/ui/activity/qr/PayMoneyToPalmPayBusinessResultActivity;

    .line 420
    .line 421
    sget p1, LAc/e;->rootView:I

    .line 422
    .line 423
    invoke-virtual {v3, p1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 424
    .line 425
    .line 426
    move-result-object p1

    .line 427
    filled-new-array {p1}, [Landroid/view/View;

    .line 428
    .line 429
    .line 430
    move-result-object p1

    .line 431
    new-instance v0, LCe/l;

    .line 432
    .line 433
    invoke-direct {v0, v1}, LCe/l;-><init>(I)V

    .line 434
    .line 435
    .line 436
    invoke-static {v2, v0, p1}, LPa/r0;->L1(Ljava/lang/String;Lcom/transsnet/palmpay/core/callback/CompleteCallback;[Landroid/view/View;)V

    .line 437
    .line 438
    .line 439
    :cond_15
    :goto_8
    return-void

    .line 440
    :pswitch_a
    const-string v0, "view"

    .line 441
    .line 442
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 443
    .line 444
    .line 445
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 446
    .line 447
    .line 448
    move-result p1

    .line 449
    sget v0, Lcom/flexibank/sdk/p;->fb_cmpta_back_iv:I

    .line 450
    .line 451
    if-ne p1, v0, :cond_16

    .line 452
    .line 453
    check-cast v3, Lcom/flexibank/sdk/customview/model/FlexiBankModelPageTitleArea;

    .line 454
    .line 455
    invoke-virtual {v3}, Lcom/flexibank/sdk/customview/model/FlexiBankModelPageTitleArea;->getMContext()Landroid/content/Context;

    .line 456
    .line 457
    .line 458
    move-result-object p1

    .line 459
    instance-of p1, p1, Landroid/app/Activity;

    .line 460
    .line 461
    if-eqz p1, :cond_16

    .line 462
    .line 463
    invoke-virtual {v3}, Lcom/flexibank/sdk/customview/model/FlexiBankModelPageTitleArea;->getMContext()Landroid/content/Context;

    .line 464
    .line 465
    .line 466
    move-result-object p1

    .line 467
    const-string v0, "null cannot be cast to non-null type android.app.Activity"

    .line 468
    .line 469
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 470
    .line 471
    .line 472
    check-cast p1, Landroid/app/Activity;

    .line 473
    .line 474
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 475
    .line 476
    .line 477
    :cond_16
    return-void

    .line 478
    :pswitch_b
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 479
    .line 480
    .line 481
    move-result p1

    .line 482
    sget v0, LAc/e;->imageViewShare:I

    .line 483
    .line 484
    if-ne p1, v0, :cond_17

    .line 485
    .line 486
    goto :goto_9

    .line 487
    :cond_17
    sget v0, LAc/e;->viewReceipt:I

    .line 488
    .line 489
    if-ne p1, v0, :cond_18

    .line 490
    .line 491
    check-cast v3, Lcom/transsnet/palmpay/ui/activity/points/PointStatementDetailActivity;

    .line 492
    .line 493
    iget-object p1, v3, Lcom/transsnet/palmpay/ui/activity/points/PointStatementDetailActivity;->p:Lcom/transsnet/palmpay/main/export/bean/rsp/GetPointFlowRsp$DataBean$ListBean;

    .line 494
    .line 495
    if-eqz p1, :cond_18

    .line 496
    .line 497
    iget-object v0, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/GetPointFlowRsp$DataBean$ListBean;->transOrderType:Ljava/lang/String;

    .line 498
    .line 499
    if-eqz v0, :cond_18

    .line 500
    .line 501
    iget-object p1, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/GetPointFlowRsp$DataBean$ListBean;->outOrderNo:Ljava/lang/String;

    .line 502
    .line 503
    const-string v1, ""

    .line 504
    .line 505
    invoke-static {v0, p1, v1}, LEa/a;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    .line 506
    .line 507
    .line 508
    :cond_18
    :goto_9
    return-void

    .line 509
    :pswitch_c
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 510
    .line 511
    .line 512
    move-result p1

    .line 513
    sget v0, Lba/e;->ivClose:I

    .line 514
    .line 515
    check-cast v3, Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    .line 516
    .line 517
    if-ne p1, v0, :cond_19

    .line 518
    .line 519
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->dismiss()V

    .line 520
    .line 521
    .line 522
    goto/16 :goto_a

    .line 523
    .line 524
    :cond_19
    sget v0, Lba/e;->cds_qr_code_container:I

    .line 525
    .line 526
    if-ne p1, v0, :cond_1a

    .line 527
    .line 528
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->access$000(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Landroid/content/Context;

    .line 529
    .line 530
    .line 531
    move-result-object p1

    .line 532
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 533
    .line 534
    .line 535
    move-result-object p1

    .line 536
    sget v0, Lcom/transsnet/palmpay/custom_view/q;->dp90:I

    .line 537
    .line 538
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 539
    .line 540
    .line 541
    move-result p1

    .line 542
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->d(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Ljava/lang/String;

    .line 543
    .line 544
    .line 545
    move-result-object v0

    .line 546
    invoke-static {v0, p1, p1, v2}, LJ3/a;->i(Ljava/lang/String;IILandroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    .line 547
    .line 548
    .line 549
    move-result-object p1

    .line 550
    new-instance v0, Lcom/transsnet/palmpay/core/dialog/CommonQRCodeDialog;

    .line 551
    .line 552
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->access$100(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Landroid/content/Context;

    .line 553
    .line 554
    .line 555
    move-result-object v1

    .line 556
    invoke-direct {v0, v1, p1}, Lcom/transsnet/palmpay/core/dialog/CommonQRCodeDialog;-><init>(Landroid/content/Context;Landroid/graphics/Bitmap;)V

    .line 557
    .line 558
    .line 559
    invoke-virtual {v0}, LO6/f;->show()V

    .line 560
    .line 561
    .line 562
    goto :goto_a

    .line 563
    :cond_1a
    sget v0, Lba/e;->cds_copy_link_container:I

    .line 564
    .line 565
    if-ne p1, v0, :cond_1b

    .line 566
    .line 567
    new-instance p1, Lcom/transsnet/palmpay/custom_view/dialog/y;

    .line 568
    .line 569
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->access$300(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Landroid/content/Context;

    .line 570
    .line 571
    .line 572
    move-result-object v0

    .line 573
    invoke-direct {p1, v0}, Lcom/transsnet/palmpay/custom_view/dialog/y;-><init>(Landroid/content/Context;)V

    .line 574
    .line 575
    .line 576
    sget v0, Lcom/transsnet/palmpay/custom_view/r;->cv_common_toast_succ:I

    .line 577
    .line 578
    iput v0, p1, Lcom/transsnet/palmpay/custom_view/dialog/y;->c:I

    .line 579
    .line 580
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->access$200(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Landroid/content/Context;

    .line 581
    .line 582
    .line 583
    move-result-object v0

    .line 584
    sget v1, Lba/k;->core_core_copy_successfully:I

    .line 585
    .line 586
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 587
    .line 588
    .line 589
    move-result-object v0

    .line 590
    iput-object v0, p1, Lcom/transsnet/palmpay/custom_view/dialog/y;->b:Ljava/io/Serializable;

    .line 591
    .line 592
    sget v0, Lba/k;->core_copy_toast_desc:I

    .line 593
    .line 594
    iget-object v1, p1, Lcom/transsnet/palmpay/custom_view/dialog/y;->e:Ljava/lang/Object;

    .line 595
    .line 596
    check-cast v1, Landroid/content/Context;

    .line 597
    .line 598
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 599
    .line 600
    .line 601
    move-result-object v0

    .line 602
    iput-object v0, p1, Lcom/transsnet/palmpay/custom_view/dialog/y;->a:Ljava/io/Serializable;

    .line 603
    .line 604
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/y;->h()V

    .line 605
    .line 606
    .line 607
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->d(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Ljava/lang/String;

    .line 608
    .line 609
    .line 610
    move-result-object p1

    .line 611
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ClipboardUtils;->copyText(Ljava/lang/CharSequence;)V

    .line 612
    .line 613
    .line 614
    new-instance p1, Ljava/util/HashMap;

    .line 615
    .line 616
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 617
    .line 618
    .line 619
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->c(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)I

    .line 620
    .line 621
    .line 622
    move-result v0

    .line 623
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 624
    .line 625
    .line 626
    move-result-object v0

    .line 627
    const-string v1, "ShareBusinessType"

    .line 628
    .line 629
    invoke-virtual {p1, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 630
    .line 631
    .line 632
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 633
    .line 634
    .line 635
    move-result-object v0

    .line 636
    const-string v1, "ShareDialogItemCopyClick"

    .line 637
    .line 638
    invoke-virtual {v0, v1, p1}, LPa/n0;->n(Ljava/lang/String;Ljava/util/Map;)V

    .line 639
    .line 640
    .line 641
    goto :goto_a

    .line 642
    :cond_1b
    sget v0, Lba/e;->cds_more_container:I

    .line 643
    .line 644
    if-ne p1, v0, :cond_1c

    .line 645
    .line 646
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->dismiss()V

    .line 647
    .line 648
    .line 649
    goto :goto_a

    .line 650
    :cond_1c
    sget v0, Lba/e;->ivCopyText:I

    .line 651
    .line 652
    if-ne p1, v0, :cond_1d

    .line 653
    .line 654
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->d(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Ljava/lang/String;

    .line 655
    .line 656
    .line 657
    move-result-object p1

    .line 658
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 659
    .line 660
    .line 661
    move-result p1

    .line 662
    if-nez p1, :cond_1d

    .line 663
    .line 664
    invoke-static {v3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->d(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Ljava/lang/String;

    .line 665
    .line 666
    .line 667
    move-result-object p1

    .line 668
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ClipboardUtils;->copyText(Ljava/lang/CharSequence;)V

    .line 669
    .line 670
    .line 671
    sget p1, Lba/k;->core_copy_success:I

    .line 672
    .line 673
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 674
    .line 675
    .line 676
    :cond_1d
    :goto_a
    return-void

    .line 677
    :pswitch_d
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 678
    .line 679
    .line 680
    move-result p1

    .line 681
    sget v0, Lba/e;->cdspm_close_iv:I

    .line 682
    .line 683
    if-ne p1, v0, :cond_1e

    .line 684
    .line 685
    check-cast v3, Lcom/transsnet/palmpay/core/dialog/SelectBankDialogV2;

    .line 686
    .line 687
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 688
    .line 689
    .line 690
    :cond_1e
    return-void

    .line 691
    :pswitch_e
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 692
    .line 693
    .line 694
    move-result p1

    .line 695
    sget v0, Lba/e;->cdspm_close_iv:I

    .line 696
    .line 697
    if-ne p1, v0, :cond_1f

    .line 698
    .line 699
    check-cast v3, Lcom/transsnet/palmpay/core/dialog/SelectBankDialog;

    .line 700
    .line 701
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 702
    .line 703
    .line 704
    :cond_1f
    return-void

    .line 705
    :pswitch_f
    check-cast v3, Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;

    .line 706
    .line 707
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 708
    .line 709
    .line 710
    return-void

    .line 711
    :pswitch_10
    check-cast v3, Lcom/transsnet/palmpay/core/dialog/MobileWalletGuideDialog;

    .line 712
    .line 713
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 714
    .line 715
    .line 716
    return-void

    .line 717
    :pswitch_11
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 718
    .line 719
    .line 720
    move-result p1

    .line 721
    sget v0, Lba/e;->mdp_close_iv:I

    .line 722
    .line 723
    if-eq p1, v0, :cond_20

    .line 724
    .line 725
    sget v0, Lba/e;->mdp_confirm_btn:I

    .line 726
    .line 727
    if-ne p1, v0, :cond_21

    .line 728
    .line 729
    :cond_20
    check-cast v3, Lcom/transsnet/palmpay/core/dialog/DayPickDialog;

    .line 730
    .line 731
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 732
    .line 733
    .line 734
    :cond_21
    return-void

    .line 735
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
