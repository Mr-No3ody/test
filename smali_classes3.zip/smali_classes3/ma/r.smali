.class public final Lma/r;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

.field public final synthetic i:Lcom/transsnet/palmpay/core/dialog/ShareDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/dialog/ShareDialog;Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;I)V
    .locals 0

    .line 1
    iput p3, p0, Lma/r;->f:I

    iput-object p1, p0, Lma/r;->i:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    iput-object p2, p0, Lma/r;->g:Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Lma/r;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lma/r;->i:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    .line 7
    .line 8
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->h(Lcom/transsnet/palmpay/core/dialog/ShareDialog;Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    iget-object v0, p0, Lma/r;->i:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    .line 13
    .line 14
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->h(Lcom/transsnet/palmpay/core/dialog/ShareDialog;Lio/reactivex/disposables/Disposable;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    nop

    .line 19
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget v0, p0, Lma/r;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_0
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    nop

    .line 15
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 4

    .line 1
    iget v0, p0, Lma/r;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 7
    .line 8
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_2

    .line 13
    .line 14
    sget v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->TYPE_RETURN_WEB_PAGE_PATH_AND_SHARE_TEXT:I

    .line 15
    .line 16
    iget-object v1, p0, Lma/r;->g:Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

    .line 17
    .line 18
    iget v2, v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->type:I

    .line 19
    .line 20
    if-ne v0, v2, :cond_1

    .line 21
    .line 22
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 23
    .line 24
    iget-object v2, p0, Lma/r;->i:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    .line 25
    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    check-cast v0, Lcom/transsnet/palmpay/core/bean/rsp/CommonShareNewRsp;

    .line 29
    .line 30
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/rsp/CommonShareNewRsp;->url:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v2, v0}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->g(Lcom/transsnet/palmpay/core/dialog/ShareDialog;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    :cond_0
    invoke-static {v2}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->j(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Landroid/os/Handler;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    new-instance v2, Lcom/flexibank/sdk/g;

    .line 40
    .line 41
    const/16 v3, 0x18

    .line 42
    .line 43
    invoke-direct {v2, v3, p0, p1}, Lcom/flexibank/sdk/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 47
    .line 48
    .line 49
    :cond_1
    sget v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->TYPE_SEND_NOTIFICATION:I

    .line 50
    .line 51
    iget v2, v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->type:I

    .line 52
    .line 53
    if-ne v0, v2, :cond_3

    .line 54
    .line 55
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 60
    .line 61
    .line 62
    iget-object p1, v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->memberId:Ljava/lang/String;

    .line 63
    .line 64
    iget v0, v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->businessType:I

    .line 65
    .line 66
    invoke-static {v0, p1}, LPa/i0;->f0(ILjava/lang/String;)V

    .line 67
    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 75
    .line 76
    .line 77
    :cond_3
    :goto_0
    return-void

    .line 78
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/CommonStringResult;

    .line 79
    .line 80
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_5

    .line 85
    .line 86
    sget v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->TYPE_RETURN_WEB_PAGE_PATH_AND_SHARE_TEXT:I

    .line 87
    .line 88
    iget-object v1, p0, Lma/r;->g:Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

    .line 89
    .line 90
    iget v2, v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->type:I

    .line 91
    .line 92
    if-ne v0, v2, :cond_4

    .line 93
    .line 94
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/rsp/CommonStringResult;->data:Ljava/lang/String;

    .line 95
    .line 96
    iget-object v2, p0, Lma/r;->i:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    .line 97
    .line 98
    invoke-static {v2, v0}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->g(Lcom/transsnet/palmpay/core/dialog/ShareDialog;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    invoke-static {v2}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->d(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-nez v0, :cond_4

    .line 110
    .line 111
    invoke-static {v2}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->j(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)Landroid/os/Handler;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    new-instance v2, Lcom/transsnet/adsdk/widgets/banner/bannerview/b;

    .line 116
    .line 117
    const/16 v3, 0xf

    .line 118
    .line 119
    invoke-direct {v2, p0, v3}, Lcom/transsnet/adsdk/widgets/banner/bannerview/b;-><init>(Ljava/lang/Object;I)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 123
    .line 124
    .line 125
    :cond_4
    sget v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->TYPE_SEND_NOTIFICATION:I

    .line 126
    .line 127
    iget v2, v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->type:I

    .line 128
    .line 129
    if-ne v0, v2, :cond_6

    .line 130
    .line 131
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 136
    .line 137
    .line 138
    iget-object p1, v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->memberId:Ljava/lang/String;

    .line 139
    .line 140
    iget v0, v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->businessType:I

    .line 141
    .line 142
    invoke-static {v0, p1}, LPa/i0;->f0(ILjava/lang/String;)V

    .line 143
    .line 144
    .line 145
    goto :goto_1

    .line 146
    :cond_5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 151
    .line 152
    .line 153
    :cond_6
    :goto_1
    return-void

    .line 154
    nop

    .line 155
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
