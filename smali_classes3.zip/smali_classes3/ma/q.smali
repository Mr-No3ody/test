.class public final Lma/q;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/transsnet/palmpay/core/dialog/ShareDialog;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/dialog/ShareDialog;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lma/q;->f:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lma/q;->f:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->h(Lcom/transsnet/palmpay/core/dialog/ShareDialog;Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/PalmPayContactListResp;

    .line 2
    .line 3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/PalmPayContactListResp;->getData()Lcom/transsnet/palmpay/core/bean/rsp/PalmPayContactListResp$DataBean;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    if-nez v0, :cond_1

    .line 22
    .line 23
    return-void

    .line 24
    :cond_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/PalmPayContactListResp;->getData()Lcom/transsnet/palmpay/core/bean/rsp/PalmPayContactListResp$DataBean;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/PalmPayContactListResp$DataBean;->getMemberContactsList()Ljava/util/List;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    iget-object v0, p0, Lma/q;->f:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    .line 33
    .line 34
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->setContactsList(Ljava/util/List;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method
