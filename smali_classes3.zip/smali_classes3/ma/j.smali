.class public final synthetic Lma/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/adapter/BaseRecyclerViewAdapter$ItemViewOnClickListener;
.implements Lcom/transsnet/palmpay/custom_view/adapter/BaseRecyclerViewAdapter$ItemFooterViewOnClickListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lma/j;->a:Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public OnItemFooterViewOnClick(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lma/j;->a:Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;

    invoke-static {v0, p1, p2}, Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;->b(Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V

    return-void
.end method

.method public OnItemViewOnClick(Landroid/view/View;Ljava/lang/Object;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lma/j;->a:Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;

    check-cast p2, Lcom/transsnet/palmpay/core/bean/BankCardInfo;

    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;->a(Lcom/transsnet/palmpay/core/dialog/NgSelectBankCardDialog;Landroid/view/View;Lcom/transsnet/palmpay/core/bean/BankCardInfo;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V

    return-void
.end method
