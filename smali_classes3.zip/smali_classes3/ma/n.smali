.class public final Lma/n;
.super Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/dialog/SelectBillTypeDialog;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/dialog/SelectBillTypeDialog;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lma/n;->a:Lcom/transsnet/palmpay/core/dialog/SelectBillTypeDialog;

    .line 2
    .line 3
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V
    .locals 3

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;->getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V

    .line 2
    .line 3
    .line 4
    iget-object p4, p0, Lma/n;->a:Lcom/transsnet/palmpay/core/dialog/SelectBillTypeDialog;

    .line 5
    .line 6
    invoke-static {p4}, Lcom/transsnet/palmpay/core/dialog/SelectBillTypeDialog;->a(Lcom/transsnet/palmpay/core/dialog/SelectBillTypeDialog;)Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    rem-int/lit8 v0, v0, 0x3

    .line 15
    .line 16
    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->getChildLayoutPosition(Landroid/view/View;)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    invoke-static {p4}, Lcom/transsnet/palmpay/core/dialog/SelectBillTypeDialog;->a(Lcom/transsnet/palmpay/core/dialog/SelectBillTypeDialog;)Ljava/util/List;

    .line 21
    .line 22
    .line 23
    move-result-object p4

    .line 24
    invoke-interface {p4}, Ljava/util/List;->size()I

    .line 25
    .line 26
    .line 27
    move-result p4

    .line 28
    sub-int/2addr p4, v0

    .line 29
    const/4 v0, 0x0

    .line 30
    const/high16 v2, 0x40e00000    # 7.0f

    .line 31
    .line 32
    if-ge v1, p4, :cond_0

    .line 33
    .line 34
    invoke-static {v2}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 35
    .line 36
    .line 37
    move-result p4

    .line 38
    iput p4, p1, Landroid/graphics/Rect;->bottom:I

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    iput v0, p1, Landroid/graphics/Rect;->bottom:I

    .line 42
    .line 43
    :goto_0
    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->getChildLayoutPosition(Landroid/view/View;)I

    .line 44
    .line 45
    .line 46
    move-result p2

    .line 47
    rem-int/lit8 p2, p2, 0x3

    .line 48
    .line 49
    const/4 p3, 0x2

    .line 50
    if-eq p2, p3, :cond_1

    .line 51
    .line 52
    invoke-static {v2}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 53
    .line 54
    .line 55
    move-result p2

    .line 56
    iput p2, p1, Landroid/graphics/Rect;->right:I

    .line 57
    .line 58
    return-void

    .line 59
    :cond_1
    iput v0, p1, Landroid/graphics/Rect;->right:I

    .line 60
    .line 61
    return-void
.end method
