.class public final synthetic Lma/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/adapter/BaseRecyclerViewAdapter$ItemViewOnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/dialog/ShareDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/dialog/ShareDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, Lma/p;->a:I

    iput-object p1, p0, Lma/p;->b:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final OnItemViewOnClick(Landroid/view/View;Ljava/lang/Object;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V
    .locals 1

    .line 1
    iget v0, p0, Lma/p;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lma/p;->b:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    check-cast p2, Lcom/transsnet/palmpay/core/bean/ShareAppInfo;

    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->a(Lcom/transsnet/palmpay/core/dialog/ShareDialog;Landroid/view/View;Lcom/transsnet/palmpay/core/bean/ShareAppInfo;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lma/p;->b:Lcom/transsnet/palmpay/core/dialog/ShareDialog;

    check-cast p2, Lcom/transsnet/palmpay/core/bean/PalmPayContact;

    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/core/dialog/ShareDialog;->b(Lcom/transsnet/palmpay/core/dialog/ShareDialog;Landroid/view/View;Lcom/transsnet/palmpay/core/bean/PalmPayContact;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
