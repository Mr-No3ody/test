.class public final synthetic Lma/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, Lma/k;->a:I

    iput-object p1, p0, Lma/k;->b:Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lma/k;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lma/k;->b:Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;->d(Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, Lma/k;->b:Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;->c(Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, Lma/k;->b:Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;->f(Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, Lma/k;->b:Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;->a(Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, p0, Lma/k;->b:Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;->g(Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_4
    iget-object v0, p0, Lma/k;->b:Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;->b(Lcom/transsnet/palmpay/core/dialog/PaymentRewardsDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
