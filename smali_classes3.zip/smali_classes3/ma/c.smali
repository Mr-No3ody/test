.class public final synthetic Lma/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, Lma/c;->a:I

    iput-object p1, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lma/c;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->c(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Landroidx/constraintlayout/widget/ConstraintLayout;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->a(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->h(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Lcom/transsnet/palmpay/core/ui/widget/AmountUnitLayout;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->i(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Lcom/transsnet/palmpay/core/ui/widget/AmountUnitLayout;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->d(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Landroid/widget/LinearLayout;

    move-result-object v0

    return-object v0

    :pswitch_4
    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->e(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_5
    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->g(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_6
    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->f(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_7
    iget-object v0, p0, Lma/c;->b:Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;->b(Lcom/transsnet/palmpay/core/dialog/ConfirmLargeAndRecipientInfoDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
