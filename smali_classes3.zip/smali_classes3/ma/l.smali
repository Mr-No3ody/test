.class public final synthetic Lma/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, Lma/l;->a:I

    iput-object p1, p0, Lma/l;->b:Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lma/l;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lma/l;->b:Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;->a(Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, Lma/l;->b:Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;->b(Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, Lma/l;->b:Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;->d(Lcom/transsnet/palmpay/core/dialog/RemindTimeSelectDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
