.class public final Lma/s;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

.field public final synthetic i:Lma/t;


# direct methods
.method public synthetic constructor <init>(Lma/t;Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;I)V
    .locals 0

    .line 1
    iput p3, p0, Lma/s;->f:I

    iput-object p1, p0, Lma/s;->i:Lma/t;

    iput-object p2, p0, Lma/s;->g:Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 2

    .line 1
    iget v0, p0, Lma/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lma/s;->i:Lma/t;

    .line 7
    .line 8
    iget-object v1, v0, Lma/t;->e:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lgf/a;

    .line 11
    .line 12
    if-nez v1, :cond_0

    .line 13
    .line 14
    new-instance v1, Lgf/a;

    .line 15
    .line 16
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object v1, v0, Lma/t;->e:Ljava/lang/Object;

    .line 20
    .line 21
    :cond_0
    iget-object v0, v0, Lma/t;->e:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lgf/a;

    .line 24
    .line 25
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_0
    iget-object v0, p0, Lma/s;->i:Lma/t;

    .line 30
    .line 31
    iget-object v1, v0, Lma/t;->e:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v1, Lgf/a;

    .line 34
    .line 35
    if-nez v1, :cond_1

    .line 36
    .line 37
    new-instance v1, Lgf/a;

    .line 38
    .line 39
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 40
    .line 41
    .line 42
    iput-object v1, v0, Lma/t;->e:Ljava/lang/Object;

    .line 43
    .line 44
    :cond_1
    iget-object v0, v0, Lma/t;->e:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v0, Lgf/a;

    .line 47
    .line 48
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    nop

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget v0, p0, Lma/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 7
    .line 8
    .line 9
    iget-object p1, p0, Lma/s;->i:Lma/t;

    .line 10
    .line 11
    iget-object v0, p1, Lma/t;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lgf/a;

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {v0}, Lgf/a;->dispose()V

    .line 18
    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    iput-object v0, p1, Lma/t;->e:Ljava/lang/Object;

    .line 22
    .line 23
    :cond_0
    return-void

    .line 24
    :pswitch_0
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 25
    .line 26
    .line 27
    iget-object p1, p0, Lma/s;->i:Lma/t;

    .line 28
    .line 29
    iget-object v0, p1, Lma/t;->e:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lgf/a;

    .line 32
    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    invoke-virtual {v0}, Lgf/a;->dispose()V

    .line 36
    .line 37
    .line 38
    const/4 v0, 0x0

    .line 39
    iput-object v0, p1, Lma/t;->e:Ljava/lang/Object;

    .line 40
    .line 41
    :cond_1
    return-void

    .line 42
    nop

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 5

    .line 1
    iget v0, p0, Lma/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 7
    .line 8
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    iget-object v1, p0, Lma/s;->i:Lma/t;

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    sget v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->TYPE_RETURN_WEB_PAGE_PATH_AND_SHARE_TEXT:I

    .line 17
    .line 18
    iget-object v2, p0, Lma/s;->g:Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

    .line 19
    .line 20
    iget v3, v2, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->type:I

    .line 21
    .line 22
    if-ne v0, v3, :cond_0

    .line 23
    .line 24
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v0, Lcom/transsnet/palmpay/core/bean/rsp/CommonShareNewRsp;

    .line 27
    .line 28
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/rsp/CommonShareNewRsp;->url:Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    iget-object v3, v1, Lma/t;->c:Ljava/io/Serializable;

    .line 34
    .line 35
    check-cast v3, Ljava/lang/String;

    .line 36
    .line 37
    iget-object v4, v1, Lma/t;->f:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v4, Landroid/content/Context;

    .line 40
    .line 41
    invoke-static {v4, v3, v0}, Lcom/facebook/imagepipeline/nativecode/b;->E(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    :cond_0
    sget v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->TYPE_SEND_NOTIFICATION:I

    .line 45
    .line 46
    iget v3, v2, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->type:I

    .line 47
    .line 48
    if-ne v0, v3, :cond_2

    .line 49
    .line 50
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, v2, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->memberId:Ljava/lang/String;

    .line 58
    .line 59
    iget v0, v2, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->businessType:I

    .line 60
    .line 61
    invoke-static {v0, p1}, LPa/i0;->f0(ILjava/lang/String;)V

    .line 62
    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 70
    .line 71
    .line 72
    :cond_2
    :goto_0
    iget-object p1, v1, Lma/t;->e:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast p1, Lgf/a;

    .line 75
    .line 76
    if-eqz p1, :cond_3

    .line 77
    .line 78
    invoke-virtual {p1}, Lgf/a;->dispose()V

    .line 79
    .line 80
    .line 81
    const/4 p1, 0x0

    .line 82
    iput-object p1, v1, Lma/t;->e:Ljava/lang/Object;

    .line 83
    .line 84
    :cond_3
    return-void

    .line 85
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/CommonStringResult;

    .line 86
    .line 87
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    iget-object v1, p0, Lma/s;->i:Lma/t;

    .line 92
    .line 93
    if-eqz v0, :cond_5

    .line 94
    .line 95
    sget v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->TYPE_RETURN_WEB_PAGE_PATH_AND_SHARE_TEXT:I

    .line 96
    .line 97
    iget-object v2, p0, Lma/s;->g:Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

    .line 98
    .line 99
    iget v3, v2, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->type:I

    .line 100
    .line 101
    if-ne v0, v3, :cond_4

    .line 102
    .line 103
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/rsp/CommonStringResult;->data:Ljava/lang/String;

    .line 104
    .line 105
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 106
    .line 107
    .line 108
    iget-object v3, v1, Lma/t;->c:Ljava/io/Serializable;

    .line 109
    .line 110
    check-cast v3, Ljava/lang/String;

    .line 111
    .line 112
    iget-object v4, v1, Lma/t;->f:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast v4, Landroid/content/Context;

    .line 115
    .line 116
    invoke-static {v4, v3, v0}, Lcom/facebook/imagepipeline/nativecode/b;->E(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    :cond_4
    sget v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->TYPE_SEND_NOTIFICATION:I

    .line 120
    .line 121
    iget v3, v2, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->type:I

    .line 122
    .line 123
    if-ne v0, v3, :cond_6

    .line 124
    .line 125
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 130
    .line 131
    .line 132
    iget-object p1, v2, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->memberId:Ljava/lang/String;

    .line 133
    .line 134
    iget v0, v2, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;->businessType:I

    .line 135
    .line 136
    invoke-static {v0, p1}, LPa/i0;->f0(ILjava/lang/String;)V

    .line 137
    .line 138
    .line 139
    goto :goto_1

    .line 140
    :cond_5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    .line 145
    .line 146
    .line 147
    :cond_6
    :goto_1
    iget-object p1, v1, Lma/t;->e:Ljava/lang/Object;

    .line 148
    .line 149
    check-cast p1, Lgf/a;

    .line 150
    .line 151
    if-eqz p1, :cond_7

    .line 152
    .line 153
    invoke-virtual {p1}, Lgf/a;->dispose()V

    .line 154
    .line 155
    .line 156
    const/4 p1, 0x0

    .line 157
    iput-object p1, v1, Lma/t;->e:Ljava/lang/Object;

    .line 158
    .line 159
    :cond_7
    return-void

    .line 160
    nop

    .line 161
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
