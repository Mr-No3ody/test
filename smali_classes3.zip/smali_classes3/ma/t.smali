.class public Lma/t;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public b:I

.field public c:Ljava/io/Serializable;

.field public d:Ljava/io/Serializable;

.field public e:Ljava/lang/Object;

.field public final f:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lma/t;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 2
    iput v0, p0, Lma/t;->b:I

    .line 3
    iput-object p1, p0, Lma/t;->f:Ljava/lang/Object;

    .line 4
    new-instance p1, Lgf/a;

    .line 5
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Lma/t;->e:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/gridlayout/widget/a;[Lv0/e;)V
    .locals 8

    const/4 v0, 0x2

    iput v0, p0, Lma/t;->a:I

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lma/t;->f:Ljava/lang/Object;

    .line 17
    array-length v0, p2

    new-array v1, v0, [Lv0/e;

    iput-object v1, p0, Lma/t;->e:Ljava/lang/Object;

    add-int/lit8 v0, v0, -0x1

    .line 18
    iput v0, p0, Lma/t;->b:I

    .line 19
    invoke-virtual {p1}, Landroidx/gridlayout/widget/a;->f()I

    move-result p1

    add-int/lit8 p1, p1, 0x1

    .line 20
    new-array v0, p1, [[Lv0/e;

    .line 21
    new-array v1, p1, [I

    .line 22
    array-length v2, p2

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_0

    aget-object v5, p2, v4

    .line 23
    iget-object v5, v5, Lv0/e;->a:Lv0/h;

    iget v5, v5, Lv0/h;->a:I

    aget v6, v1, v5

    add-int/lit8 v6, v6, 0x1

    aput v6, v1, v5

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    move v2, v3

    :goto_1
    if-ge v2, p1, :cond_1

    .line 24
    aget v4, v1, v2

    new-array v4, v4, [Lv0/e;

    aput-object v4, v0, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 25
    :cond_1
    invoke-static {v1, v3}, Ljava/util/Arrays;->fill([II)V

    .line 26
    array-length p1, p2

    :goto_2
    if-ge v3, p1, :cond_2

    aget-object v2, p2, v3

    .line 27
    iget-object v4, v2, Lv0/e;->a:Lv0/h;

    iget v4, v4, Lv0/h;->a:I

    .line 28
    aget-object v5, v0, v4

    aget v6, v1, v4

    add-int/lit8 v7, v6, 0x1

    aput v7, v1, v4

    aput-object v2, v5, v6

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 29
    :cond_2
    iput-object v0, p0, Lma/t;->c:Ljava/io/Serializable;

    .line 30
    iget-object p1, p0, Lma/t;->f:Ljava/lang/Object;

    check-cast p1, Landroidx/gridlayout/widget/a;

    invoke-virtual {p1}, Landroidx/gridlayout/widget/a;->f()I

    move-result p1

    add-int/lit8 p1, p1, 0x1

    new-array p1, p1, [I

    iput-object p1, p0, Lma/t;->d:Ljava/io/Serializable;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 5

    const/4 v0, 0x1

    iput v0, p0, Lma/t;->a:I

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    new-instance v0, LPa/b;

    const/16 v1, 0x8

    const/4 v2, 0x0

    .line 9
    invoke-direct {v0, v2, v1}, LPa/b;-><init>(BI)V

    .line 10
    new-array v2, v1, [Ljava/lang/Object;

    iput-object v2, v0, LPa/b;->c:Ljava/lang/Object;

    .line 11
    new-array v2, v1, [I

    const/4 v3, 0x0

    :goto_0
    const/4 v4, -0x1

    if-ge v3, v1, :cond_0

    aput v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    iput-object v2, v0, LPa/b;->d:Ljava/lang/Object;

    .line 12
    iput v4, v0, LPa/b;->b:I

    .line 13
    iput-object v0, p0, Lma/t;->e:Ljava/lang/Object;

    .line 14
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v0, p0, Lma/t;->f:Ljava/lang/Object;

    .line 15
    iput-object p1, p0, Lma/t;->d:Ljava/io/Serializable;

    return-void
.end method

.method public static synthetic n(Lma/t;Ljava/lang/String;II)V
    .locals 1

    .line 1
    and-int/lit8 v0, p3, 0x2

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget p2, p0, Lma/t;->b:I

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p3, p3, 0x4

    .line 8
    .line 9
    if-eqz p3, :cond_1

    .line 10
    .line 11
    const-string p3, ""

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_1
    const-string p3, "It is possible to deserialize them using \'JsonBuilder.allowSpecialFloatingPointValues = true\'"

    .line 15
    .line 16
    :goto_0
    invoke-virtual {p0, p2, p1, p3}, Lma/t;->m(ILjava/lang/String;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const/4 p0, 0x0

    .line 20
    throw p0
.end method


# virtual methods
.method public a(ILjava/lang/CharSequence;)I
    .locals 3

    .line 1
    add-int/lit8 v0, p1, 0x4

    .line 2
    .line 3
    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-lt v0, v1, :cond_1

    .line 8
    .line 9
    iput p1, p0, Lma/t;->b:I

    .line 10
    .line 11
    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    if-ge v0, p1, :cond_0

    .line 16
    .line 17
    iget p1, p0, Lma/t;->b:I

    .line 18
    .line 19
    invoke-virtual {p0, p1, p2}, Lma/t;->a(ILjava/lang/CharSequence;)I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    return p1

    .line 24
    :cond_0
    const-string p1, "Unexpected EOF during unicode escape"

    .line 25
    .line 26
    const/4 p2, 0x0

    .line 27
    const/4 v0, 0x6

    .line 28
    invoke-static {p0, p1, p2, v0}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 29
    .line 30
    .line 31
    const/4 p1, 0x0

    .line 32
    throw p1

    .line 33
    :cond_1
    invoke-virtual {p0, p1, p2}, Lma/t;->p(ILjava/lang/CharSequence;)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    shl-int/lit8 v1, v1, 0xc

    .line 38
    .line 39
    add-int/lit8 v2, p1, 0x1

    .line 40
    .line 41
    invoke-virtual {p0, v2, p2}, Lma/t;->p(ILjava/lang/CharSequence;)I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    shl-int/lit8 v2, v2, 0x8

    .line 46
    .line 47
    add-int/2addr v1, v2

    .line 48
    add-int/lit8 v2, p1, 0x2

    .line 49
    .line 50
    invoke-virtual {p0, v2, p2}, Lma/t;->p(ILjava/lang/CharSequence;)I

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    shl-int/lit8 v2, v2, 0x4

    .line 55
    .line 56
    add-int/2addr v1, v2

    .line 57
    add-int/lit8 p1, p1, 0x3

    .line 58
    .line 59
    invoke-virtual {p0, p1, p2}, Lma/t;->p(ILjava/lang/CharSequence;)I

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    add-int/2addr p1, v1

    .line 64
    int-to-char p1, p1

    .line 65
    iget-object p2, p0, Lma/t;->f:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast p2, Ljava/lang/StringBuilder;

    .line 68
    .line 69
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    return v0
.end method

.method public b()Z
    .locals 4

    .line 1
    iget v0, p0, Lma/t;->b:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-ne v0, v1, :cond_0

    .line 6
    .line 7
    return v2

    .line 8
    :cond_0
    :goto_0
    iget-object v1, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 9
    .line 10
    check-cast v1, Ljava/lang/String;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    if-ge v0, v3, :cond_4

    .line 17
    .line 18
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    const/16 v3, 0x20

    .line 23
    .line 24
    if-eq v1, v3, :cond_3

    .line 25
    .line 26
    const/16 v3, 0xa

    .line 27
    .line 28
    if-eq v1, v3, :cond_3

    .line 29
    .line 30
    const/16 v3, 0xd

    .line 31
    .line 32
    if-eq v1, v3, :cond_3

    .line 33
    .line 34
    const/16 v3, 0x9

    .line 35
    .line 36
    if-ne v1, v3, :cond_1

    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    iput v0, p0, Lma/t;->b:I

    .line 40
    .line 41
    const/16 v0, 0x2c

    .line 42
    .line 43
    if-eq v1, v0, :cond_2

    .line 44
    .line 45
    const/16 v0, 0x3a

    .line 46
    .line 47
    if-eq v1, v0, :cond_2

    .line 48
    .line 49
    const/16 v0, 0x5d

    .line 50
    .line 51
    if-eq v1, v0, :cond_2

    .line 52
    .line 53
    const/16 v0, 0x7d

    .line 54
    .line 55
    if-eq v1, v0, :cond_2

    .line 56
    .line 57
    const/4 v0, 0x1

    .line 58
    return v0

    .line 59
    :cond_2
    return v2

    .line 60
    :cond_3
    :goto_1
    add-int/lit8 v0, v0, 0x1

    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_4
    iput v0, p0, Lma/t;->b:I

    .line 64
    .line 65
    return v2
.end method

.method public c(Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;)V
    .locals 3

    .line 1
    iget v0, p0, Lma/t;->b:I

    .line 2
    .line 3
    if-ltz v0, :cond_0

    .line 4
    .line 5
    const/16 v1, 0x1f

    .line 6
    .line 7
    if-ge v0, v1, :cond_0

    .line 8
    .line 9
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 10
    .line 11
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 14
    .line 15
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->commonShare(Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;)Ldf/d;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 28
    .line 29
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    new-instance v1, Lma/s;

    .line 34
    .line 35
    const/4 v2, 0x0

    .line 36
    invoke-direct {v1, p0, p1, v2}, Lma/s;-><init>(Lma/t;Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :cond_0
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 44
    .line 45
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 48
    .line 49
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/PayApiService;->commonShareNew(Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;)Ldf/d;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 62
    .line 63
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    new-instance v1, Lma/s;

    .line 68
    .line 69
    const/4 v2, 0x1

    .line 70
    invoke-direct {v1, p0, p1, v2}, Lma/s;-><init>(Lma/t;Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;I)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 74
    .line 75
    .line 76
    return-void
.end method

.method public d(ILjava/lang/String;)V
    .locals 8

    .line 1
    iget-object v0, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    sub-int/2addr v1, p1

    .line 10
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 11
    .line 12
    .line 13
    move-result v2

    .line 14
    const/4 v3, 0x0

    .line 15
    const/4 v4, 0x6

    .line 16
    const/4 v5, 0x0

    .line 17
    if-lt v1, v2, :cond_2

    .line 18
    .line 19
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    move v2, v5

    .line 24
    :goto_0
    if-ge v2, v1, :cond_1

    .line 25
    .line 26
    invoke-virtual {p2, v2}, Ljava/lang/String;->charAt(I)C

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    add-int v7, p1, v2

    .line 31
    .line 32
    invoke-virtual {v0, v7}, Ljava/lang/String;->charAt(I)C

    .line 33
    .line 34
    .line 35
    move-result v7

    .line 36
    or-int/lit8 v7, v7, 0x20

    .line 37
    .line 38
    if-ne v6, v7, :cond_0

    .line 39
    .line 40
    add-int/lit8 v2, v2, 0x1

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_0
    new-instance p1, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    const-string p2, "Expected valid boolean literal prefix, but had \'"

    .line 46
    .line 47
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p0}, Lma/t;->k()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const/16 p2, 0x27

    .line 58
    .line 59
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-static {p0, p1, v5, v4}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 67
    .line 68
    .line 69
    throw v3

    .line 70
    :cond_1
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 71
    .line 72
    .line 73
    move-result p2

    .line 74
    add-int/2addr p2, p1

    .line 75
    iput p2, p0, Lma/t;->b:I

    .line 76
    .line 77
    return-void

    .line 78
    :cond_2
    const-string p1, "Unexpected end of boolean literal"

    .line 79
    .line 80
    invoke-static {p0, p1, v5, v4}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 81
    .line 82
    .line 83
    throw v3
.end method

.method public e()Ljava/lang/String;
    .locals 13

    .line 1
    const/16 v0, 0x22

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Lma/t;->h(C)V

    .line 4
    .line 5
    .line 6
    iget v1, p0, Lma/t;->b:I

    .line 7
    .line 8
    iget-object v2, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 9
    .line 10
    check-cast v2, Ljava/lang/String;

    .line 11
    .line 12
    const/4 v3, 0x4

    .line 13
    invoke-static {v2, v0, v1, v3}, Lkotlin/text/StringsKt;->D(Ljava/lang/CharSequence;CII)I

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    const/4 v5, 0x0

    .line 18
    const/4 v6, 0x0

    .line 19
    const/4 v7, 0x1

    .line 20
    const/4 v8, -0x1

    .line 21
    if-eq v4, v8, :cond_c

    .line 22
    .line 23
    move v9, v1

    .line 24
    :goto_0
    if-ge v9, v4, :cond_b

    .line 25
    .line 26
    invoke-virtual {v2, v9}, Ljava/lang/String;->charAt(I)C

    .line 27
    .line 28
    .line 29
    move-result v10

    .line 30
    const/16 v11, 0x5c

    .line 31
    .line 32
    if-ne v10, v11, :cond_a

    .line 33
    .line 34
    iget v1, p0, Lma/t;->b:I

    .line 35
    .line 36
    const-string v4, "source"

    .line 37
    .line 38
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v2, v9}, Ljava/lang/String;->charAt(I)C

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    move v10, v5

    .line 46
    :goto_1
    if-eq v4, v0, :cond_8

    .line 47
    .line 48
    const-string v12, "Unexpected EOF"

    .line 49
    .line 50
    if-ne v4, v11, :cond_5

    .line 51
    .line 52
    iget-object v4, p0, Lma/t;->f:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v4, Ljava/lang/StringBuilder;

    .line 55
    .line 56
    invoke-virtual {v4, v2, v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    add-int/lit8 v9, v9, 0x1

    .line 60
    .line 61
    invoke-virtual {p0, v9}, Lma/t;->r(I)I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    const/4 v4, 0x6

    .line 66
    if-eq v1, v8, :cond_4

    .line 67
    .line 68
    add-int/lit8 v9, v1, 0x1

    .line 69
    .line 70
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    const/16 v10, 0x75

    .line 75
    .line 76
    if-ne v1, v10, :cond_0

    .line 77
    .line 78
    invoke-virtual {p0, v9, v2}, Lma/t;->a(ILjava/lang/CharSequence;)I

    .line 79
    .line 80
    .line 81
    move-result v9

    .line 82
    goto :goto_3

    .line 83
    :cond_0
    if-ge v1, v10, :cond_1

    .line 84
    .line 85
    sget-object v10, Lmg/d;->a:[C

    .line 86
    .line 87
    aget-char v10, v10, v1

    .line 88
    .line 89
    goto :goto_2

    .line 90
    :cond_1
    move v10, v5

    .line 91
    :goto_2
    if-eqz v10, :cond_3

    .line 92
    .line 93
    iget-object v1, p0, Lma/t;->f:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast v1, Ljava/lang/StringBuilder;

    .line 96
    .line 97
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    :goto_3
    invoke-virtual {p0, v9}, Lma/t;->r(I)I

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    if-eq v1, v8, :cond_2

    .line 105
    .line 106
    :goto_4
    move v9, v1

    .line 107
    move v10, v7

    .line 108
    goto :goto_5

    .line 109
    :cond_2
    invoke-static {p0, v12, v1, v3}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 110
    .line 111
    .line 112
    throw v6

    .line 113
    :cond_3
    new-instance v0, Ljava/lang/StringBuilder;

    .line 114
    .line 115
    const-string v2, "Invalid escaped char \'"

    .line 116
    .line 117
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    const/16 v1, 0x27

    .line 124
    .line 125
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-static {p0, v0, v5, v4}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 133
    .line 134
    .line 135
    throw v6

    .line 136
    :cond_4
    const-string v0, "Expected escape sequence to continue, got EOF"

    .line 137
    .line 138
    invoke-static {p0, v0, v5, v4}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 139
    .line 140
    .line 141
    throw v6

    .line 142
    :cond_5
    add-int/lit8 v9, v9, 0x1

    .line 143
    .line 144
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 145
    .line 146
    .line 147
    move-result v4

    .line 148
    if-lt v9, v4, :cond_7

    .line 149
    .line 150
    iget-object v4, p0, Lma/t;->f:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v4, Ljava/lang/StringBuilder;

    .line 153
    .line 154
    invoke-virtual {v4, v2, v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-virtual {p0, v9}, Lma/t;->r(I)I

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    if-eq v1, v8, :cond_6

    .line 162
    .line 163
    goto :goto_4

    .line 164
    :cond_6
    invoke-static {p0, v12, v1, v3}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 165
    .line 166
    .line 167
    throw v6

    .line 168
    :cond_7
    :goto_5
    invoke-virtual {v2, v9}, Ljava/lang/String;->charAt(I)C

    .line 169
    .line 170
    .line 171
    move-result v4

    .line 172
    goto :goto_1

    .line 173
    :cond_8
    if-nez v10, :cond_9

    .line 174
    .line 175
    invoke-virtual {v2, v1, v9}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    goto :goto_6

    .line 184
    :cond_9
    invoke-virtual {p0, v1, v9}, Lma/t;->l(II)Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    :goto_6
    add-int/2addr v9, v7

    .line 189
    iput v9, p0, Lma/t;->b:I

    .line 190
    .line 191
    return-object v0

    .line 192
    :cond_a
    add-int/lit8 v9, v9, 0x1

    .line 193
    .line 194
    goto/16 :goto_0

    .line 195
    .line 196
    :cond_b
    add-int/lit8 v0, v4, 0x1

    .line 197
    .line 198
    iput v0, p0, Lma/t;->b:I

    .line 199
    .line 200
    invoke-virtual {v2, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    const-string v1, "substring(...)"

    .line 205
    .line 206
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    return-object v0

    .line 210
    :cond_c
    invoke-virtual {p0}, Lma/t;->k()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    invoke-virtual {p0, v7, v5}, Lma/t;->o(BZ)V

    .line 214
    .line 215
    .line 216
    throw v6
.end method

.method public f()B
    .locals 4

    .line 1
    iget v0, p0, Lma/t;->b:I

    .line 2
    .line 3
    :goto_0
    const/4 v1, -0x1

    .line 4
    const/16 v2, 0xa

    .line 5
    .line 6
    iget-object v3, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 7
    .line 8
    check-cast v3, Ljava/lang/String;

    .line 9
    .line 10
    if-eq v0, v1, :cond_2

    .line 11
    .line 12
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-ge v0, v1, :cond_2

    .line 17
    .line 18
    add-int/lit8 v1, v0, 0x1

    .line 19
    .line 20
    invoke-virtual {v3, v0}, Ljava/lang/String;->charAt(I)C

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    const/16 v3, 0x20

    .line 25
    .line 26
    if-eq v0, v3, :cond_1

    .line 27
    .line 28
    if-eq v0, v2, :cond_1

    .line 29
    .line 30
    const/16 v2, 0xd

    .line 31
    .line 32
    if-eq v0, v2, :cond_1

    .line 33
    .line 34
    const/16 v2, 0x9

    .line 35
    .line 36
    if-ne v0, v2, :cond_0

    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_0
    iput v1, p0, Lma/t;->b:I

    .line 40
    .line 41
    invoke-static {v0}, Lmg/k;->d(C)B

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    return v0

    .line 46
    :cond_1
    :goto_1
    move v0, v1

    .line 47
    goto :goto_0

    .line 48
    :cond_2
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    iput v0, p0, Lma/t;->b:I

    .line 53
    .line 54
    return v2
.end method

.method public g(B)B
    .locals 1

    .line 1
    invoke-virtual {p0}, Lma/t;->f()B

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-ne v0, p1, :cond_0

    .line 6
    .line 7
    return v0

    .line 8
    :cond_0
    const/4 v0, 0x1

    .line 9
    invoke-virtual {p0, p1, v0}, Lma/t;->o(BZ)V

    .line 10
    .line 11
    .line 12
    const/4 p1, 0x0

    .line 13
    throw p1
.end method

.method public h(C)V
    .locals 5

    .line 1
    iget v0, p0, Lma/t;->b:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, -0x1

    .line 5
    if-eq v0, v2, :cond_4

    .line 6
    .line 7
    :goto_0
    iget-object v3, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 8
    .line 9
    check-cast v3, Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v4

    .line 15
    if-ge v0, v4, :cond_3

    .line 16
    .line 17
    add-int/lit8 v4, v0, 0x1

    .line 18
    .line 19
    invoke-virtual {v3, v0}, Ljava/lang/String;->charAt(I)C

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    const/16 v3, 0x20

    .line 24
    .line 25
    if-eq v0, v3, :cond_2

    .line 26
    .line 27
    const/16 v3, 0xa

    .line 28
    .line 29
    if-eq v0, v3, :cond_2

    .line 30
    .line 31
    const/16 v3, 0xd

    .line 32
    .line 33
    if-eq v0, v3, :cond_2

    .line 34
    .line 35
    const/16 v3, 0x9

    .line 36
    .line 37
    if-ne v0, v3, :cond_0

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    iput v4, p0, Lma/t;->b:I

    .line 41
    .line 42
    if-ne v0, p1, :cond_1

    .line 43
    .line 44
    return-void

    .line 45
    :cond_1
    invoke-virtual {p0, p1}, Lma/t;->v(C)V

    .line 46
    .line 47
    .line 48
    throw v1

    .line 49
    :cond_2
    :goto_1
    move v0, v4

    .line 50
    goto :goto_0

    .line 51
    :cond_3
    iput v2, p0, Lma/t;->b:I

    .line 52
    .line 53
    invoke-virtual {p0, p1}, Lma/t;->v(C)V

    .line 54
    .line 55
    .line 56
    throw v1

    .line 57
    :cond_4
    invoke-virtual {p0, p1}, Lma/t;->v(C)V

    .line 58
    .line 59
    .line 60
    throw v1
.end method

.method public i()J
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual {v0}, Lma/t;->t()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-virtual {v0, v1}, Lma/t;->r(I)I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    iget-object v2, v0, Lma/t;->d:Ljava/io/Serializable;

    .line 12
    .line 13
    check-cast v2, Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    const-string v4, "EOF"

    .line 20
    .line 21
    const/4 v5, 0x0

    .line 22
    const/4 v6, 0x6

    .line 23
    const/4 v7, 0x0

    .line 24
    if-ge v1, v3, :cond_1d

    .line 25
    .line 26
    const/4 v3, -0x1

    .line 27
    if-eq v1, v3, :cond_1d

    .line 28
    .line 29
    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    const/16 v9, 0x22

    .line 34
    .line 35
    if-ne v3, v9, :cond_1

    .line 36
    .line 37
    add-int/lit8 v1, v1, 0x1

    .line 38
    .line 39
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    if-eq v1, v3, :cond_0

    .line 44
    .line 45
    const/4 v3, 0x1

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    invoke-static {v0, v4, v7, v6}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 48
    .line 49
    .line 50
    throw v5

    .line 51
    :cond_1
    move v3, v7

    .line 52
    :goto_0
    move v12, v1

    .line 53
    move-object/from16 v16, v5

    .line 54
    .line 55
    move v5, v7

    .line 56
    move v13, v5

    .line 57
    move v14, v13

    .line 58
    const-wide/16 v8, 0x0

    .line 59
    .line 60
    const-wide/16 v10, 0x0

    .line 61
    .line 62
    const-wide/16 v17, 0x0

    .line 63
    .line 64
    :goto_1
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 65
    .line 66
    .line 67
    move-result v15

    .line 68
    const-string v6, "Numeric value overflow"

    .line 69
    .line 70
    if-eq v12, v15, :cond_e

    .line 71
    .line 72
    invoke-virtual {v2, v12}, Ljava/lang/String;->charAt(I)C

    .line 73
    .line 74
    .line 75
    move-result v15

    .line 76
    const/16 v7, 0x65

    .line 77
    .line 78
    if-eq v15, v7, :cond_3

    .line 79
    .line 80
    const/16 v7, 0x45

    .line 81
    .line 82
    if-ne v15, v7, :cond_2

    .line 83
    .line 84
    goto :goto_2

    .line 85
    :cond_2
    move/from16 v19, v3

    .line 86
    .line 87
    const/4 v7, 0x0

    .line 88
    goto :goto_3

    .line 89
    :cond_3
    :goto_2
    if-nez v13, :cond_2

    .line 90
    .line 91
    if-eq v12, v1, :cond_4

    .line 92
    .line 93
    add-int/lit8 v12, v12, 0x1

    .line 94
    .line 95
    const/4 v5, 0x1

    .line 96
    const/4 v6, 0x6

    .line 97
    const/4 v7, 0x0

    .line 98
    const/4 v13, 0x1

    .line 99
    goto :goto_1

    .line 100
    :cond_4
    new-instance v1, Ljava/lang/StringBuilder;

    .line 101
    .line 102
    const-string v2, "Unexpected symbol "

    .line 103
    .line 104
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 108
    .line 109
    .line 110
    const-string v2, " in numeric literal"

    .line 111
    .line 112
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 113
    .line 114
    .line 115
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    const/4 v2, 0x6

    .line 120
    const/4 v7, 0x0

    .line 121
    invoke-static {v0, v1, v7, v2}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 122
    .line 123
    .line 124
    throw v16

    .line 125
    :goto_3
    const-string v3, "Unexpected symbol \'-\' in numeric literal"

    .line 126
    .line 127
    const/16 v7, 0x2d

    .line 128
    .line 129
    if-ne v15, v7, :cond_6

    .line 130
    .line 131
    if-eqz v13, :cond_6

    .line 132
    .line 133
    if-eq v12, v1, :cond_5

    .line 134
    .line 135
    add-int/lit8 v12, v12, 0x1

    .line 136
    .line 137
    move/from16 v3, v19

    .line 138
    .line 139
    const/4 v5, 0x0

    .line 140
    :goto_4
    const/4 v6, 0x6

    .line 141
    const/4 v7, 0x0

    .line 142
    goto :goto_1

    .line 143
    :cond_5
    const/4 v5, 0x6

    .line 144
    const/4 v7, 0x0

    .line 145
    invoke-static {v0, v3, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 146
    .line 147
    .line 148
    throw v16

    .line 149
    :cond_6
    const/16 v7, 0x2b

    .line 150
    .line 151
    if-ne v15, v7, :cond_8

    .line 152
    .line 153
    if-eqz v13, :cond_8

    .line 154
    .line 155
    if-eq v12, v1, :cond_7

    .line 156
    .line 157
    add-int/lit8 v12, v12, 0x1

    .line 158
    .line 159
    move/from16 v3, v19

    .line 160
    .line 161
    const/4 v5, 0x1

    .line 162
    goto :goto_4

    .line 163
    :cond_7
    const-string v1, "Unexpected symbol \'+\' in numeric literal"

    .line 164
    .line 165
    const/4 v2, 0x0

    .line 166
    const/4 v7, 0x6

    .line 167
    invoke-static {v0, v1, v2, v7}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 168
    .line 169
    .line 170
    throw v16

    .line 171
    :cond_8
    move/from16 v21, v13

    .line 172
    .line 173
    const/4 v13, 0x0

    .line 174
    const/16 v7, 0x2d

    .line 175
    .line 176
    if-ne v15, v7, :cond_a

    .line 177
    .line 178
    if-ne v12, v1, :cond_9

    .line 179
    .line 180
    add-int/lit8 v12, v12, 0x1

    .line 181
    .line 182
    move v7, v13

    .line 183
    move/from16 v3, v19

    .line 184
    .line 185
    move/from16 v13, v21

    .line 186
    .line 187
    const/4 v6, 0x6

    .line 188
    const/4 v14, 0x1

    .line 189
    goto :goto_1

    .line 190
    :cond_9
    const/4 v5, 0x6

    .line 191
    invoke-static {v0, v3, v13, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 192
    .line 193
    .line 194
    throw v16

    .line 195
    :cond_a
    invoke-static {v15}, Lmg/k;->d(C)B

    .line 196
    .line 197
    .line 198
    move-result v3

    .line 199
    if-nez v3, :cond_f

    .line 200
    .line 201
    add-int/lit8 v12, v12, 0x1

    .line 202
    .line 203
    add-int/lit8 v3, v15, -0x30

    .line 204
    .line 205
    if-ltz v3, :cond_d

    .line 206
    .line 207
    const/16 v7, 0xa

    .line 208
    .line 209
    if-ge v3, v7, :cond_d

    .line 210
    .line 211
    if-eqz v21, :cond_b

    .line 212
    .line 213
    int-to-long v6, v7

    .line 214
    mul-long/2addr v8, v6

    .line 215
    int-to-long v6, v3

    .line 216
    add-long/2addr v8, v6

    .line 217
    move/from16 v3, v19

    .line 218
    .line 219
    :goto_5
    move/from16 v13, v21

    .line 220
    .line 221
    goto :goto_4

    .line 222
    :cond_b
    move/from16 v20, v12

    .line 223
    .line 224
    int-to-long v12, v7

    .line 225
    mul-long/2addr v10, v12

    .line 226
    int-to-long v12, v3

    .line 227
    sub-long/2addr v10, v12

    .line 228
    cmp-long v3, v10, v17

    .line 229
    .line 230
    if-gtz v3, :cond_c

    .line 231
    .line 232
    move/from16 v3, v19

    .line 233
    .line 234
    move/from16 v12, v20

    .line 235
    .line 236
    goto :goto_5

    .line 237
    :cond_c
    const/4 v5, 0x6

    .line 238
    const/4 v7, 0x0

    .line 239
    invoke-static {v0, v6, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 240
    .line 241
    .line 242
    throw v16

    .line 243
    :cond_d
    const/4 v5, 0x6

    .line 244
    const/4 v7, 0x0

    .line 245
    new-instance v1, Ljava/lang/StringBuilder;

    .line 246
    .line 247
    const-string v2, "Unexpected symbol \'"

    .line 248
    .line 249
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 253
    .line 254
    .line 255
    const-string v2, "\' in numeric literal"

    .line 256
    .line 257
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 258
    .line 259
    .line 260
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object v1

    .line 264
    invoke-static {v0, v1, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 265
    .line 266
    .line 267
    throw v16

    .line 268
    :cond_e
    move/from16 v19, v3

    .line 269
    .line 270
    move/from16 v21, v13

    .line 271
    .line 272
    :cond_f
    if-eq v12, v1, :cond_10

    .line 273
    .line 274
    const/4 v3, 0x1

    .line 275
    goto :goto_6

    .line 276
    :cond_10
    const/4 v3, 0x0

    .line 277
    :goto_6
    if-eq v1, v12, :cond_11

    .line 278
    .line 279
    if-eqz v14, :cond_12

    .line 280
    .line 281
    add-int/lit8 v7, v12, -0x1

    .line 282
    .line 283
    if-eq v1, v7, :cond_11

    .line 284
    .line 285
    goto :goto_7

    .line 286
    :cond_11
    const/4 v5, 0x6

    .line 287
    const/4 v7, 0x0

    .line 288
    goto/16 :goto_b

    .line 289
    .line 290
    :cond_12
    :goto_7
    if-eqz v19, :cond_15

    .line 291
    .line 292
    if-eqz v3, :cond_14

    .line 293
    .line 294
    invoke-virtual {v2, v12}, Ljava/lang/String;->charAt(I)C

    .line 295
    .line 296
    .line 297
    move-result v1

    .line 298
    const/16 v2, 0x22

    .line 299
    .line 300
    if-ne v1, v2, :cond_13

    .line 301
    .line 302
    add-int/lit8 v12, v12, 0x1

    .line 303
    .line 304
    goto :goto_8

    .line 305
    :cond_13
    const-string v1, "Expected closing quotation mark"

    .line 306
    .line 307
    const/4 v5, 0x6

    .line 308
    const/4 v7, 0x0

    .line 309
    invoke-static {v0, v1, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 310
    .line 311
    .line 312
    throw v16

    .line 313
    :cond_14
    const/4 v5, 0x6

    .line 314
    const/4 v7, 0x0

    .line 315
    invoke-static {v0, v4, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 316
    .line 317
    .line 318
    throw v16

    .line 319
    :cond_15
    :goto_8
    iput v12, v0, Lma/t;->b:I

    .line 320
    .line 321
    if-eqz v21, :cond_1a

    .line 322
    .line 323
    long-to-double v1, v10

    .line 324
    const-wide/high16 v3, 0x4024000000000000L    # 10.0

    .line 325
    .line 326
    if-nez v5, :cond_16

    .line 327
    .line 328
    long-to-double v7, v8

    .line 329
    neg-double v7, v7

    .line 330
    invoke-static {v3, v4, v7, v8}, Ljava/lang/Math;->pow(DD)D

    .line 331
    .line 332
    .line 333
    move-result-wide v3

    .line 334
    goto :goto_9

    .line 335
    :cond_16
    const/4 v7, 0x1

    .line 336
    if-ne v5, v7, :cond_19

    .line 337
    .line 338
    long-to-double v7, v8

    .line 339
    invoke-static {v3, v4, v7, v8}, Ljava/lang/Math;->pow(DD)D

    .line 340
    .line 341
    .line 342
    move-result-wide v3

    .line 343
    :goto_9
    mul-double/2addr v1, v3

    .line 344
    const-wide/high16 v3, 0x43e0000000000000L    # 9.223372036854776E18

    .line 345
    .line 346
    cmpl-double v3, v1, v3

    .line 347
    .line 348
    if-gtz v3, :cond_18

    .line 349
    .line 350
    const-wide/high16 v3, -0x3c20000000000000L    # -9.223372036854776E18

    .line 351
    .line 352
    cmpg-double v3, v1, v3

    .line 353
    .line 354
    if-ltz v3, :cond_18

    .line 355
    .line 356
    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    .line 357
    .line 358
    .line 359
    move-result-wide v3

    .line 360
    cmpg-double v3, v3, v1

    .line 361
    .line 362
    if-nez v3, :cond_17

    .line 363
    .line 364
    double-to-long v10, v1

    .line 365
    goto :goto_a

    .line 366
    :cond_17
    new-instance v3, Ljava/lang/StringBuilder;

    .line 367
    .line 368
    const-string v4, "Can\'t convert "

    .line 369
    .line 370
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 371
    .line 372
    .line 373
    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 374
    .line 375
    .line 376
    const-string v1, " to Long"

    .line 377
    .line 378
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 379
    .line 380
    .line 381
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 382
    .line 383
    .line 384
    move-result-object v1

    .line 385
    const/4 v5, 0x6

    .line 386
    const/4 v7, 0x0

    .line 387
    invoke-static {v0, v1, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 388
    .line 389
    .line 390
    throw v16

    .line 391
    :cond_18
    const/4 v5, 0x6

    .line 392
    const/4 v7, 0x0

    .line 393
    invoke-static {v0, v6, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 394
    .line 395
    .line 396
    throw v16

    .line 397
    :cond_19
    new-instance v1, Lxf/l;

    .line 398
    .line 399
    invoke-direct {v1}, Ljava/lang/RuntimeException;-><init>()V

    .line 400
    .line 401
    .line 402
    throw v1

    .line 403
    :cond_1a
    :goto_a
    if-eqz v14, :cond_1b

    .line 404
    .line 405
    return-wide v10

    .line 406
    :cond_1b
    const-wide/high16 v1, -0x8000000000000000L

    .line 407
    .line 408
    cmp-long v1, v10, v1

    .line 409
    .line 410
    if-eqz v1, :cond_1c

    .line 411
    .line 412
    neg-long v1, v10

    .line 413
    return-wide v1

    .line 414
    :cond_1c
    const/4 v5, 0x6

    .line 415
    const/4 v7, 0x0

    .line 416
    invoke-static {v0, v6, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 417
    .line 418
    .line 419
    throw v16

    .line 420
    :goto_b
    const-string v1, "Expected numeric literal"

    .line 421
    .line 422
    invoke-static {v0, v1, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 423
    .line 424
    .line 425
    throw v16

    .line 426
    :cond_1d
    move-object/from16 v16, v5

    .line 427
    .line 428
    move v5, v6

    .line 429
    invoke-static {v0, v4, v7, v5}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 430
    .line 431
    .line 432
    throw v16
.end method

.method public j()Ljava/lang/String;
    .locals 2

    .line 1
    iget-object v0, p0, Lma/t;->c:Ljava/io/Serializable;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    iput-object v1, p0, Lma/t;->c:Ljava/io/Serializable;

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_0
    invoke-virtual {p0}, Lma/t;->e()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    return-object v0
.end method

.method public k()Ljava/lang/String;
    .locals 7

    .line 1
    iget-object v0, p0, Lma/t;->c:Ljava/io/Serializable;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iput-object v1, p0, Lma/t;->c:Ljava/io/Serializable;

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_0
    invoke-virtual {p0}, Lma/t;->t()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    iget-object v2, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 19
    .line 20
    check-cast v2, Ljava/lang/String;

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    if-ge v0, v3, :cond_7

    .line 27
    .line 28
    const/4 v3, -0x1

    .line 29
    if-eq v0, v3, :cond_7

    .line 30
    .line 31
    invoke-virtual {v2, v0}, Ljava/lang/String;->charAt(I)C

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    invoke-static {v4}, Lmg/k;->d(C)B

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    const/4 v5, 0x1

    .line 40
    if-ne v4, v5, :cond_1

    .line 41
    .line 42
    invoke-virtual {p0}, Lma/t;->j()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0

    .line 47
    :cond_1
    const/4 v6, 0x0

    .line 48
    if-nez v4, :cond_6

    .line 49
    .line 50
    move v1, v6

    .line 51
    :cond_2
    :goto_0
    invoke-virtual {v2, v0}, Ljava/lang/String;->charAt(I)C

    .line 52
    .line 53
    .line 54
    move-result v4

    .line 55
    invoke-static {v4}, Lmg/k;->d(C)B

    .line 56
    .line 57
    .line 58
    move-result v4

    .line 59
    if-nez v4, :cond_4

    .line 60
    .line 61
    add-int/lit8 v0, v0, 0x1

    .line 62
    .line 63
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 64
    .line 65
    .line 66
    move-result v4

    .line 67
    if-lt v0, v4, :cond_2

    .line 68
    .line 69
    iget v1, p0, Lma/t;->b:I

    .line 70
    .line 71
    iget-object v4, p0, Lma/t;->f:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v4, Ljava/lang/StringBuilder;

    .line 74
    .line 75
    invoke-virtual {v4, v2, v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-virtual {p0, v0}, Lma/t;->r(I)I

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    if-ne v1, v3, :cond_3

    .line 83
    .line 84
    iput v0, p0, Lma/t;->b:I

    .line 85
    .line 86
    invoke-virtual {p0, v6, v6}, Lma/t;->l(II)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    return-object v0

    .line 91
    :cond_3
    move v0, v1

    .line 92
    move v1, v5

    .line 93
    goto :goto_0

    .line 94
    :cond_4
    if-nez v1, :cond_5

    .line 95
    .line 96
    iget v1, p0, Lma/t;->b:I

    .line 97
    .line 98
    invoke-virtual {v2, v1, v0}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    goto :goto_1

    .line 107
    :cond_5
    iget v1, p0, Lma/t;->b:I

    .line 108
    .line 109
    invoke-virtual {p0, v1, v0}, Lma/t;->l(II)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    :goto_1
    iput v0, p0, Lma/t;->b:I

    .line 114
    .line 115
    return-object v1

    .line 116
    :cond_6
    new-instance v3, Ljava/lang/StringBuilder;

    .line 117
    .line 118
    const-string v4, "Expected beginning of the string, but got "

    .line 119
    .line 120
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v2, v0}, Ljava/lang/String;->charAt(I)C

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 128
    .line 129
    .line 130
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    const/4 v2, 0x6

    .line 135
    invoke-static {p0, v0, v6, v2}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 136
    .line 137
    .line 138
    throw v1

    .line 139
    :cond_7
    const/4 v2, 0x4

    .line 140
    const-string v3, "EOF"

    .line 141
    .line 142
    invoke-static {p0, v3, v0, v2}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 143
    .line 144
    .line 145
    throw v1
.end method

.method public l(II)Ljava/lang/String;
    .locals 2

    .line 1
    iget-object v0, p0, Lma/t;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    iget-object v1, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v0, v1, p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, Lma/t;->f:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p1, Ljava/lang/StringBuilder;

    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    const-string v0, "toString(...)"

    .line 21
    .line 22
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const/4 v0, 0x0

    .line 26
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 27
    .line 28
    .line 29
    return-object p2
.end method

.method public m(ILjava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "message"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "hint"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p3}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    const-string p3, ""

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const-string v0, "\n"

    .line 21
    .line 22
    invoke-virtual {v0, p3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p3

    .line 26
    :goto_0
    const-string v0, " at path: "

    .line 27
    .line 28
    invoke-static {p2, v0}, LC0/G;->t(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    move-result-object p2

    .line 32
    iget-object v0, p0, Lma/t;->e:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, LPa/b;

    .line 35
    .line 36
    invoke-virtual {v0}, LPa/b;->i()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    iget-object p3, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 51
    .line 52
    check-cast p3, Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {p3, p1, p2}, Lmg/k;->b(Ljava/lang/CharSequence;ILjava/lang/String;)Lmg/h;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    throw p1
.end method

.method public o(BZ)V
    .locals 4

    .line 1
    invoke-static {p1}, Lmg/k;->l(B)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    if-eqz p2, :cond_0

    .line 6
    .line 7
    iget p2, p0, Lma/t;->b:I

    .line 8
    .line 9
    add-int/lit8 p2, p2, -0x1

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget p2, p0, Lma/t;->b:I

    .line 13
    .line 14
    :goto_0
    iget v0, p0, Lma/t;->b:I

    .line 15
    .line 16
    iget-object v1, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 17
    .line 18
    check-cast v1, Ljava/lang/String;

    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    if-eq v0, v2, :cond_2

    .line 25
    .line 26
    if-gez p2, :cond_1

    .line 27
    .line 28
    goto :goto_1

    .line 29
    :cond_1
    invoke-virtual {v1, p2}, Ljava/lang/String;->charAt(I)C

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    invoke-static {v0}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    goto :goto_2

    .line 38
    :cond_2
    :goto_1
    const-string v0, "EOF"

    .line 39
    .line 40
    :goto_2
    const-string v1, "Expected "

    .line 41
    .line 42
    const-string v2, ", but had \'"

    .line 43
    .line 44
    const-string v3, "\' instead"

    .line 45
    .line 46
    invoke-static {v1, p1, v2, v0, v3}, LC0/G;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    const/4 v0, 0x4

    .line 51
    invoke-static {p0, p1, p2, v0}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 52
    .line 53
    .line 54
    const/4 p1, 0x0

    .line 55
    throw p1
.end method

.method public p(ILjava/lang/CharSequence;)I
    .locals 1

    .line 1
    invoke-interface {p2, p1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/16 p2, 0x30

    .line 6
    .line 7
    if-gt p2, p1, :cond_0

    .line 8
    .line 9
    const/16 v0, 0x3a

    .line 10
    .line 11
    if-ge p1, v0, :cond_0

    .line 12
    .line 13
    sub-int/2addr p1, p2

    .line 14
    return p1

    .line 15
    :cond_0
    const/16 p2, 0x61

    .line 16
    .line 17
    if-gt p2, p1, :cond_1

    .line 18
    .line 19
    const/16 p2, 0x67

    .line 20
    .line 21
    if-ge p1, p2, :cond_1

    .line 22
    .line 23
    add-int/lit8 p1, p1, -0x57

    .line 24
    .line 25
    return p1

    .line 26
    :cond_1
    const/16 p2, 0x41

    .line 27
    .line 28
    if-gt p2, p1, :cond_2

    .line 29
    .line 30
    const/16 p2, 0x47

    .line 31
    .line 32
    if-ge p1, p2, :cond_2

    .line 33
    .line 34
    add-int/lit8 p1, p1, -0x37

    .line 35
    .line 36
    return p1

    .line 37
    :cond_2
    new-instance p2, Ljava/lang/StringBuilder;

    .line 38
    .line 39
    const-string v0, "Invalid toHexChar char \'"

    .line 40
    .line 41
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string p1, "\' in unicode escape"

    .line 48
    .line 49
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    const/4 p2, 0x6

    .line 57
    const/4 v0, 0x0

    .line 58
    invoke-static {p0, p1, v0, p2}, Lma/t;->n(Lma/t;Ljava/lang/String;II)V

    .line 59
    .line 60
    .line 61
    const/4 p1, 0x0

    .line 62
    throw p1
.end method

.method public q()B
    .locals 4

    .line 1
    iget v0, p0, Lma/t;->b:I

    .line 2
    .line 3
    :goto_0
    invoke-virtual {p0, v0}, Lma/t;->r(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, -0x1

    .line 8
    const/16 v2, 0xa

    .line 9
    .line 10
    if-eq v0, v1, :cond_1

    .line 11
    .line 12
    iget-object v1, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 13
    .line 14
    check-cast v1, Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    const/16 v3, 0x9

    .line 21
    .line 22
    if-eq v1, v3, :cond_0

    .line 23
    .line 24
    if-eq v1, v2, :cond_0

    .line 25
    .line 26
    const/16 v2, 0xd

    .line 27
    .line 28
    if-eq v1, v2, :cond_0

    .line 29
    .line 30
    const/16 v2, 0x20

    .line 31
    .line 32
    if-eq v1, v2, :cond_0

    .line 33
    .line 34
    iput v0, p0, Lma/t;->b:I

    .line 35
    .line 36
    invoke-static {v1}, Lmg/k;->d(C)B

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    return v0

    .line 41
    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    iput v0, p0, Lma/t;->b:I

    .line 45
    .line 46
    return v2
.end method

.method public r(I)I
    .locals 1

    .line 1
    iget-object v0, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-ge p1, v0, :cond_0

    .line 10
    .line 11
    return p1

    .line 12
    :cond_0
    const/4 p1, -0x1

    .line 13
    return p1
.end method

.method public s(I)V
    .locals 2

    .line 1
    iput p1, p0, Lma/t;->b:I

    .line 2
    .line 3
    const/16 v0, 0x10

    .line 4
    .line 5
    if-eq p1, v0, :cond_1

    .line 6
    .line 7
    const/16 v0, 0x1a

    .line 8
    .line 9
    if-eq p1, v0, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v0, 0x0

    .line 13
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-nez v1, :cond_2

    .line 18
    .line 19
    new-instance v1, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

    .line 20
    .line 21
    invoke-direct {v1, p1, v0}, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;-><init>(ILjava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, v1}, Lma/t;->c(Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_1
    iget-object v0, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 29
    .line 30
    check-cast v0, Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-nez v0, :cond_2

    .line 37
    .line 38
    new-instance v0, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;

    .line 39
    .line 40
    iget-object v1, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 41
    .line 42
    check-cast v1, Ljava/lang/String;

    .line 43
    .line 44
    invoke-direct {v0, p1, v1}, Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;-><init>(ILjava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0, v0}, Lma/t;->c(Lcom/transsnet/palmpay/core/bean/req/CommonShareReq;)V

    .line 48
    .line 49
    .line 50
    :cond_2
    :goto_0
    return-void
.end method

.method public t()I
    .locals 3

    .line 1
    iget v0, p0, Lma/t;->b:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v0

    .line 7
    :cond_0
    :goto_0
    iget-object v1, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 8
    .line 9
    check-cast v1, Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-ge v0, v2, :cond_2

    .line 16
    .line 17
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    const/16 v2, 0x20

    .line 22
    .line 23
    if-eq v1, v2, :cond_1

    .line 24
    .line 25
    const/16 v2, 0xa

    .line 26
    .line 27
    if-eq v1, v2, :cond_1

    .line 28
    .line 29
    const/16 v2, 0xd

    .line 30
    .line 31
    if-eq v1, v2, :cond_1

    .line 32
    .line 33
    const/16 v2, 0x9

    .line 34
    .line 35
    if-ne v1, v2, :cond_2

    .line 36
    .line 37
    :cond_1
    add-int/lit8 v0, v0, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_2
    iput v0, p0, Lma/t;->b:I

    .line 41
    .line 42
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    iget v0, p0, Lma/t;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "JsonReader(source=\'"

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 19
    .line 20
    check-cast v1, Ljava/lang/String;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v1, "\', currentPosition="

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    iget v1, p0, Lma/t;->b:I

    .line 31
    .line 32
    const/16 v2, 0x29

    .line 33
    .line 34
    invoke-static {v0, v1, v2}, LN8/q0;->m(Ljava/lang/StringBuilder;IC)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0

    .line 39
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public u()Z
    .locals 4

    .line 1
    invoke-virtual {p0}, Lma/t;->t()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x0

    .line 14
    if-ge v0, v2, :cond_1

    .line 15
    .line 16
    const/4 v2, -0x1

    .line 17
    if-ne v0, v2, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    const/16 v1, 0x2c

    .line 25
    .line 26
    if-ne v0, v1, :cond_1

    .line 27
    .line 28
    iget v0, p0, Lma/t;->b:I

    .line 29
    .line 30
    const/4 v1, 0x1

    .line 31
    add-int/2addr v0, v1

    .line 32
    iput v0, p0, Lma/t;->b:I

    .line 33
    .line 34
    return v1

    .line 35
    :cond_1
    :goto_0
    return v3
.end method

.method public v(C)V
    .locals 4

    .line 1
    iget v0, p0, Lma/t;->b:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-lez v0, :cond_0

    .line 6
    .line 7
    const/16 v3, 0x22

    .line 8
    .line 9
    if-ne p1, v3, :cond_0

    .line 10
    .line 11
    add-int/lit8 v3, v0, -0x1

    .line 12
    .line 13
    :try_start_0
    iput v3, p0, Lma/t;->b:I

    .line 14
    .line 15
    invoke-virtual {p0}, Lma/t;->k()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    iput v0, p0, Lma/t;->b:I

    .line 20
    .line 21
    const-string v0, "null"

    .line 22
    .line 23
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    iget p1, p0, Lma/t;->b:I

    .line 30
    .line 31
    sub-int/2addr p1, v2

    .line 32
    const-string v0, "Use \'coerceInputValues = true\' in \'Json {}\' builder to coerce nulls if property has a default value."

    .line 33
    .line 34
    const-string v2, "Expected string literal but \'null\' literal was found"

    .line 35
    .line 36
    invoke-virtual {p0, p1, v2, v0}, Lma/t;->m(ILjava/lang/String;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    throw v1

    .line 40
    :catchall_0
    move-exception p1

    .line 41
    iput v0, p0, Lma/t;->b:I

    .line 42
    .line 43
    throw p1

    .line 44
    :cond_0
    invoke-static {p1}, Lmg/k;->d(C)B

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    invoke-virtual {p0, p1, v2}, Lma/t;->o(BZ)V

    .line 49
    .line 50
    .line 51
    throw v1
.end method

.method public w(I)V
    .locals 7

    .line 1
    iget-object v0, p0, Lma/t;->d:Ljava/io/Serializable;

    .line 2
    .line 3
    check-cast v0, [I

    .line 4
    .line 5
    aget v1, v0, p1

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    const/4 v1, 0x1

    .line 11
    aput v1, v0, p1

    .line 12
    .line 13
    iget-object v1, p0, Lma/t;->c:Ljava/io/Serializable;

    .line 14
    .line 15
    check-cast v1, [[Lv0/e;

    .line 16
    .line 17
    aget-object v1, v1, p1

    .line 18
    .line 19
    array-length v2, v1

    .line 20
    const/4 v3, 0x0

    .line 21
    :goto_0
    if-ge v3, v2, :cond_1

    .line 22
    .line 23
    aget-object v4, v1, v3

    .line 24
    .line 25
    iget-object v5, v4, Lv0/e;->a:Lv0/h;

    .line 26
    .line 27
    iget v5, v5, Lv0/h;->b:I

    .line 28
    .line 29
    invoke-virtual {p0, v5}, Lma/t;->w(I)V

    .line 30
    .line 31
    .line 32
    iget v5, p0, Lma/t;->b:I

    .line 33
    .line 34
    add-int/lit8 v6, v5, -0x1

    .line 35
    .line 36
    iput v6, p0, Lma/t;->b:I

    .line 37
    .line 38
    iget-object v6, p0, Lma/t;->e:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v6, [Lv0/e;

    .line 41
    .line 42
    aput-object v4, v6, v5

    .line 43
    .line 44
    add-int/lit8 v3, v3, 0x1

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_1
    const/4 v1, 0x2

    .line 48
    aput v1, v0, p1

    .line 49
    .line 50
    return-void
.end method
