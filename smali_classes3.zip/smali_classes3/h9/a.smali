.class public final Lh9/a;
.super Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I


# direct methods
.method public constructor <init>(II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lh9/a;->a:I

    .line 5
    .line 6
    iput p2, p0, Lh9/a;->b:I

    .line 7
    .line 8
    const/16 p1, 0xa

    .line 9
    .line 10
    invoke-static {p1}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    iput p1, p0, Lh9/a;->c:I

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V
    .locals 1

    .line 1
    const-string v0, "outRect"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "view"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "parent"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "state"

    .line 17
    .line 18
    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-super {p0, p1, p2, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;->getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->getChildLayoutPosition(Landroid/view/View;)I

    .line 25
    .line 26
    .line 27
    move-result p2

    .line 28
    if-eqz p2, :cond_0

    .line 29
    .line 30
    const/16 p2, 0xa

    .line 31
    .line 32
    invoke-static {p2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    iput p2, p1, Landroid/graphics/Rect;->left:I

    .line 37
    .line 38
    :cond_0
    iget p2, p0, Lh9/a;->c:I

    .line 39
    .line 40
    iput p2, p1, Landroid/graphics/Rect;->bottom:I

    .line 41
    .line 42
    return-void
.end method

.method public final onDrawOver(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V
    .locals 11

    .line 1
    const-string v0, "c"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "parent"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "state"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;->onDrawOver(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V

    .line 17
    .line 18
    .line 19
    const/4 p3, 0x3

    .line 20
    invoke-static {p3}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 21
    .line 22
    .line 23
    move-result p3

    .line 24
    const/16 v0, 0x1c

    .line 25
    .line 26
    invoke-static {v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    const/16 v1, 0xa

    .line 31
    .line 32
    invoke-static {v1}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    div-int/lit8 v2, v2, 0x2

    .line 41
    .line 42
    div-int/lit8 v3, v0, 0x2

    .line 43
    .line 44
    sub-int/2addr v2, v3

    .line 45
    int-to-float v4, v2

    .line 46
    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    sub-int/2addr v2, p3

    .line 51
    int-to-float v5, v2

    .line 52
    new-instance v8, Landroid/graphics/Paint;

    .line 53
    .line 54
    invoke-direct {v8}, Landroid/graphics/Paint;-><init>()V

    .line 55
    .line 56
    .line 57
    const/4 v2, 0x1

    .line 58
    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 59
    .line 60
    .line 61
    iget v2, p0, Lh9/a;->a:I

    .line 62
    .line 63
    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 64
    .line 65
    .line 66
    sget-object v2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    .line 67
    .line 68
    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 69
    .line 70
    .line 71
    int-to-float p3, p3

    .line 72
    invoke-virtual {v8, p3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollExtent()I

    .line 76
    .line 77
    .line 78
    move-result p3

    .line 79
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollRange()I

    .line 80
    .line 81
    .line 82
    move-result v2

    .line 83
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollOffset()I

    .line 84
    .line 85
    .line 86
    move-result p2

    .line 87
    sub-int/2addr v2, p3

    .line 88
    int-to-float p3, v2

    .line 89
    const/4 v2, 0x0

    .line 90
    cmpl-float v2, p3, v2

    .line 91
    .line 92
    if-lez v2, :cond_0

    .line 93
    .line 94
    int-to-float v2, v0

    .line 95
    add-float v6, v4, v2

    .line 96
    .line 97
    move v7, v5

    .line 98
    move-object v3, p1

    .line 99
    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 100
    .line 101
    .line 102
    int-to-float p1, p2

    .line 103
    div-float/2addr p1, p3

    .line 104
    sub-int/2addr v0, v1

    .line 105
    int-to-float p2, v0

    .line 106
    mul-float/2addr p2, p1

    .line 107
    iget p1, p0, Lh9/a;->b:I

    .line 108
    .line 109
    invoke-virtual {v8, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 110
    .line 111
    .line 112
    add-float v6, v4, p2

    .line 113
    .line 114
    int-to-float p1, v1

    .line 115
    add-float/2addr v4, p1

    .line 116
    add-float/2addr v4, p2

    .line 117
    move v9, v5

    .line 118
    move-object v10, v8

    .line 119
    move-object v5, v3

    .line 120
    move v8, v4

    .line 121
    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 122
    .line 123
    .line 124
    :cond_0
    return-void
.end method
