.class public final Lr9/d;
.super Lcom/facebook/react/defaults/DefaultReactNativeHost;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:Z


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/base/ShellApplication;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lcom/facebook/react/defaults/DefaultReactNativeHost;-><init>(Landroid/app/Application;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x1

    .line 5
    iput-boolean p1, p0, Lr9/d;->a:Z

    .line 6
    .line 7
    iput-boolean p1, p0, Lr9/d;->b:Z

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final getBundleAssetName()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "index.android.bundle"

    .line 2
    .line 3
    return-object v0
.end method

.method public final getJSBundleFile()Ljava/lang/String;
    .locals 4

    .line 1
    invoke-static {}, Lcom/microsoft/codepush/react/CodePush;->getJSBundleFile()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "getBizJSBundle "

    .line 6
    .line 7
    invoke-static {v1, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/4 v2, 0x3

    .line 16
    const-string v3, "ReactNative"

    .line 17
    .line 18
    invoke-static {v3, v2, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_0

    .line 26
    .line 27
    const-string v0, "assets://index.android.bundle"

    .line 28
    .line 29
    :cond_0
    return-object v0
.end method

.method public final getJSMainModuleName()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "index"

    .line 2
    .line 3
    return-object v0
.end method

.method public final getJavaScriptExecutorFactory()Lcom/facebook/react/bridge/JavaScriptExecutorFactory;
    .locals 2

    .line 1
    :try_start_0
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "get(...)"

    .line 6
    .line 7
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-static {v0}, LCa/f;->a(Landroid/content/Context;)V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lcom/facebook/hermes/reactexecutor/HermesExecutor;->a:Lcom/facebook/hermes/reactexecutor/HermesExecutor$a;

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/facebook/hermes/reactexecutor/HermesExecutor$a;->loadLibrary()V

    .line 16
    .line 17
    .line 18
    new-instance v0, Lorg/sufficientlysecure/htmltextview/k;

    .line 19
    .line 20
    const/4 v1, 0x2

    .line 21
    invoke-direct {v0, v1}, Lorg/sufficientlysecure/htmltextview/k;-><init>(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    .line 23
    .line 24
    return-object v0

    .line 25
    :catchall_0
    const/4 v0, 0x0

    .line 26
    return-object v0
.end method

.method public final getPackages()Ljava/util/List;
    .locals 3

    .line 1
    new-instance v0, Lcom/facebook/react/PackageList;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lcom/facebook/react/PackageList;-><init>(Lcom/facebook/react/ReactNativeHost;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0}, Lcom/facebook/react/PackageList;->getPackages()Ljava/util/ArrayList;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const-string v1, "getPackages(...)"

    .line 11
    .line 12
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->Z(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    new-instance v1, LCa/a;

    .line 20
    .line 21
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    sget-boolean v1, LPa/q;->g:Z

    .line 28
    .line 29
    if-eqz v1, :cond_0

    .line 30
    .line 31
    const-string v1, "23106RN0DA"

    .line 32
    .line 33
    sget-object v2, LPa/q;->b:Ljava/lang/String;

    .line 34
    .line 35
    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_0

    .line 40
    .line 41
    new-instance v1, LD5/a;

    .line 42
    .line 43
    const/16 v2, 0x9

    .line 44
    .line 45
    invoke-direct {v1, v2}, LD5/a;-><init>(I)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    :cond_0
    return-object v0
.end method

.method public final getUseDeveloperSupport()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final isHermesEnabled()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lr9/d;->b:Z

    .line 2
    .line 3
    return v0
.end method

.method public final isNewArchEnabled()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lr9/d;->a:Z

    .line 2
    .line 3
    return v0
.end method
