.class public final Lr9/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e:Lr9/b;


# instance fields
.field public final a:Landroid/app/Application;

.field public final b:Lkotlin/jvm/functions/Function2;

.field public final c:Ljava/util/LinkedHashMap;

.field public final d:Ljava/lang/ThreadLocal;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lr9/b;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lr9/b;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lr9/c;->e:Lr9/b;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Landroid/app/Application;Lkotlin/jvm/functions/Function2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lr9/c;->a:Landroid/app/Application;

    .line 5
    .line 6
    iput-object p2, p0, Lr9/c;->b:Lkotlin/jvm/functions/Function2;

    .line 7
    .line 8
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Lr9/c;->c:Ljava/util/LinkedHashMap;

    .line 14
    .line 15
    new-instance p1, Ljava/lang/ThreadLocal;

    .line 16
    .line 17
    invoke-direct {p1}, Ljava/lang/ThreadLocal;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Lr9/c;->d:Ljava/lang/ThreadLocal;

    .line 21
    .line 22
    return-void
.end method
