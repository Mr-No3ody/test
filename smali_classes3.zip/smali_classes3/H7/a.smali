.class public final synthetic LH7/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:Landroid/view/KeyEvent$Callback;


# direct methods
.method public synthetic constructor <init>(IJLandroid/view/KeyEvent$Callback;)V
    .locals 0

    .line 1
    iput p1, p0, LH7/a;->a:I

    iput-object p4, p0, LH7/a;->c:Landroid/view/KeyEvent$Callback;

    iput-wide p2, p0, LH7/a;->b:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget-wide v0, p0, LH7/a;->b:J

    .line 2
    .line 3
    iget-object v2, p0, LH7/a;->c:Landroid/view/KeyEvent$Callback;

    .line 4
    .line 5
    iget v3, p0, LH7/a;->a:I

    .line 6
    .line 7
    packed-switch v3, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    sget-object v3, Lcom/transsnet/palmpay/ui/activity/HomeActivity;->H:Lcom/transsnet/palmpay/ui/activity/HomeActivity$a;

    .line 11
    .line 12
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    const-class v4, Lcom/transsnet/palmpay/core/provider/IAccountModule;

    .line 17
    .line 18
    invoke-virtual {v3, v4}, Lcom/alibaba/android/arouter/launcher/ARouter;->navigation(Ljava/lang/Class;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    check-cast v3, Lcom/transsnet/palmpay/core/provider/IAccountModule;

    .line 23
    .line 24
    check-cast v2, Lcom/transsnet/palmpay/ui/activity/HomeActivity;

    .line 25
    .line 26
    if-eqz v3, :cond_0

    .line 27
    .line 28
    invoke-interface {v3, v2}, Lcom/transsnet/palmpay/core/provider/IAccountModule;->buildAutoLogoutOptionsDialog(Landroid/app/Activity;)Landroid/app/Dialog;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    const/4 v3, 0x0

    .line 34
    :goto_0
    if-eqz v3, :cond_1

    .line 35
    .line 36
    invoke-virtual {v2}, Lcom/transsnet/palmpay/ui/activity/HomeActivity;->p()Lcom/transsnet/palmpay/bean/HomeDialogState;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    const/16 v4, 0x63

    .line 41
    .line 42
    invoke-virtual {v2, v3, v4}, Lcom/transsnet/palmpay/bean/HomeDialogState;->showDialog(Landroid/app/Dialog;I)Z

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    if-eqz v2, :cond_1

    .line 47
    .line 48
    const-string v2, "main_sp_check_auto_logout"

    .line 49
    .line 50
    invoke-static {v0, v1, v2}, Le1/a;->Y(JLjava/lang/String;)V

    .line 51
    .line 52
    .line 53
    :cond_1
    return-void

    .line 54
    :pswitch_0
    const-string v3, "$this_circularRevealed"

    .line 55
    .line 56
    check-cast v2, Landroid/view/View;

    .line 57
    .line 58
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {v2}, Landroid/view/View;->isAttachedToWindow()Z

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    if-eqz v3, :cond_2

    .line 66
    .line 67
    const/4 v3, 0x0

    .line 68
    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {v2}, Landroid/view/View;->getLeft()I

    .line 72
    .line 73
    .line 74
    move-result v3

    .line 75
    invoke-virtual {v2}, Landroid/view/View;->getRight()I

    .line 76
    .line 77
    .line 78
    move-result v4

    .line 79
    add-int/2addr v4, v3

    .line 80
    div-int/lit8 v4, v4, 0x2

    .line 81
    .line 82
    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    invoke-virtual {v2}, Landroid/view/View;->getBottom()I

    .line 87
    .line 88
    .line 89
    move-result v5

    .line 90
    add-int/2addr v5, v3

    .line 91
    div-int/lit8 v5, v5, 0x2

    .line 92
    .line 93
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 94
    .line 95
    .line 96
    move-result v3

    .line 97
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 98
    .line 99
    .line 100
    move-result v6

    .line 101
    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    .line 102
    .line 103
    .line 104
    move-result v3

    .line 105
    int-to-float v3, v3

    .line 106
    const/4 v6, 0x0

    .line 107
    invoke-static {v2, v4, v5, v6, v3}, Landroid/view/ViewAnimationUtils;->createCircularReveal(Landroid/view/View;IIFF)Landroid/animation/Animator;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    invoke-virtual {v2, v0, v1}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    .line 112
    .line 113
    .line 114
    invoke-virtual {v2}, Landroid/animation/Animator;->start()V

    .line 115
    .line 116
    .line 117
    :cond_2
    return-void

    .line 118
    nop

    .line 119
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
