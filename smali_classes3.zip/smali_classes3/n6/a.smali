.class public final Ln6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# instance fields
.field public final synthetic a:LO2/a;

.field public final synthetic b:Lm6/s;


# direct methods
.method public constructor <init>(LO2/a;Lm6/s;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ln6/a;->a:LO2/a;

    .line 5
    .line 6
    iput-object p2, p0, Ln6/a;->b:Lm6/s;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    const-string v2, "chain"

    .line 6
    .line 7
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {v0}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Y;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {v2}, Lokhttp3/Y;->b()Lokhttp3/X;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 19
    .line 20
    .line 21
    move-result-wide v4

    .line 22
    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    new-instance v5, Ljava/lang/StringBuilder;

    .line 27
    .line 28
    const-string v6, "ANDROID"

    .line 29
    .line 30
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    sget-object v7, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    .line 34
    .line 35
    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v5

    .line 42
    const-string v8, "pp_device_id"

    .line 43
    .line 44
    invoke-virtual {v3, v8}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    const-string v9, "pp_device_type"

    .line 48
    .line 49
    invoke-virtual {v3, v9}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    const-string v10, "pp_client_ver"

    .line 53
    .line 54
    invoke-virtual {v3, v10}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    const-string v11, "PP_TIMESTAMP"

    .line 58
    .line 59
    invoke-virtual {v3, v11}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    const-string v12, "pp_channel"

    .line 63
    .line 64
    invoke-virtual {v3, v12}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    const-string v13, "countryCode"

    .line 68
    .line 69
    invoke-virtual {v3, v13}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    const-string v14, "appId"

    .line 73
    .line 74
    invoke-virtual {v3, v14}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    const-string v15, "pp_req_sign"

    .line 78
    .line 79
    invoke-virtual {v3, v15}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    const-string v0, "tntCode"

    .line 83
    .line 84
    invoke-virtual {v3, v0}, Lokhttp3/X;->i(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    iget-object v0, v1, Ln6/a;->a:LO2/a;

    .line 88
    .line 89
    move-object/from16 v16, v2

    .line 90
    .line 91
    iget-object v2, v0, LO2/a;->a:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v2, Ljava/lang/String;

    .line 94
    .line 95
    if-eqz v2, :cond_0

    .line 96
    .line 97
    invoke-virtual {v3, v8, v2}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 101
    .line 102
    invoke-direct {v2, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    const-string v6, "getDeviceType(...)"

    .line 113
    .line 114
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v3, v9, v2}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    iget-object v2, v0, LO2/a;->b:Ljava/lang/Object;

    .line 121
    .line 122
    check-cast v2, Ljava/lang/String;

    .line 123
    .line 124
    if-eqz v2, :cond_1

    .line 125
    .line 126
    invoke-virtual {v3, v10, v2}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    :cond_1
    invoke-virtual {v3, v11, v4}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    iget-object v2, v1, Ln6/a;->b:Lm6/s;

    .line 133
    .line 134
    iget-object v6, v2, Lm6/s;->d:Ljava/lang/String;

    .line 135
    .line 136
    if-eqz v6, :cond_2

    .line 137
    .line 138
    invoke-virtual {v3, v12, v6}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    :cond_2
    iget-object v7, v2, Lm6/s;->e:Ljava/lang/String;

    .line 142
    .line 143
    if-nez v7, :cond_3

    .line 144
    .line 145
    const-string v7, "NG"

    .line 146
    .line 147
    :cond_3
    invoke-virtual {v3, v13, v7}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    iget-object v2, v2, Lm6/s;->b:Ljava/lang/String;

    .line 151
    .line 152
    invoke-virtual {v3, v14, v2}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    iget-object v2, v0, LO2/a;->a:Ljava/lang/Object;

    .line 156
    .line 157
    check-cast v2, Ljava/lang/String;

    .line 158
    .line 159
    iget-object v0, v0, LO2/a;->b:Ljava/lang/Object;

    .line 160
    .line 161
    check-cast v0, Ljava/lang/String;

    .line 162
    .line 163
    new-instance v7, Ljava/lang/StringBuilder;

    .line 164
    .line 165
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    const-string v2, "palmpay"

    .line 175
    .line 176
    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 177
    .line 178
    .line 179
    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 180
    .line 181
    .line 182
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    invoke-static {v0}, Lm6/k;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    const-string v5, "getMD5(...)"

    .line 194
    .line 195
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v3, v15, v0}, Lokhttp3/X;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    move-object/from16 v0, v16

    .line 202
    .line 203
    iget-object v0, v0, Lokhttp3/Y;->d:Lokhttp3/c0;

    .line 204
    .line 205
    new-instance v5, LPg/k;

    .line 206
    .line 207
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 208
    .line 209
    .line 210
    :try_start_0
    invoke-virtual {v0, v5}, Lokhttp3/c0;->writeTo(Lokio/BufferedSink;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v5}, LPg/k;->readUtf8()Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 217
    goto :goto_0

    .line 218
    :catchall_0
    move-exception v0

    .line 219
    throw v0

    .line 220
    :catch_0
    const/4 v0, 0x0

    .line 221
    :goto_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 222
    .line 223
    .line 224
    move-result v5

    .line 225
    if-eqz v5, :cond_4

    .line 226
    .line 227
    const-string v0, ""

    .line 228
    .line 229
    goto :goto_1

    .line 230
    :cond_4
    invoke-static {}, Lm6/j;->c()Lm6/j;

    .line 231
    .line 232
    .line 233
    move-result-object v5

    .line 234
    const-class v7, Lcom/palmpay/lib/config/api/bean/ConfigReq;

    .line 235
    .line 236
    invoke-virtual {v5, v0, v7}, Lm6/j;->b(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v5

    .line 240
    check-cast v5, Lcom/palmpay/lib/config/api/bean/ConfigReq;

    .line 241
    .line 242
    if-eqz v5, :cond_6

    .line 243
    .line 244
    iget-object v7, v5, Lcom/palmpay/lib/config/api/bean/ConfigReq;->nebulaClientParam:Lcom/palmpay/lib/config/api/bean/ConfigReq$Extra;

    .line 245
    .line 246
    if-nez v7, :cond_5

    .line 247
    .line 248
    goto :goto_1

    .line 249
    :cond_5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 250
    .line 251
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 252
    .line 253
    .line 254
    iget-object v7, v5, Lcom/palmpay/lib/config/api/bean/ConfigReq;->appId:Ljava/lang/String;

    .line 255
    .line 256
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 257
    .line 258
    .line 259
    iget-object v7, v5, Lcom/palmpay/lib/config/api/bean/ConfigReq;->nebulaClientParam:Lcom/palmpay/lib/config/api/bean/ConfigReq$Extra;

    .line 260
    .line 261
    iget-object v7, v7, Lcom/palmpay/lib/config/api/bean/ConfigReq$Extra;->pp_device_type:Ljava/lang/String;

    .line 262
    .line 263
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 264
    .line 265
    .line 266
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 267
    .line 268
    .line 269
    iget-object v2, v5, Lcom/palmpay/lib/config/api/bean/ConfigReq;->nebulaClientParam:Lcom/palmpay/lib/config/api/bean/ConfigReq$Extra;

    .line 270
    .line 271
    iget-object v2, v2, Lcom/palmpay/lib/config/api/bean/ConfigReq$Extra;->pp_client_ver:Ljava/lang/String;

    .line 272
    .line 273
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 274
    .line 275
    .line 276
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 277
    .line 278
    .line 279
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    invoke-static {v0}, Lm6/k;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    iput-object v0, v5, Lcom/palmpay/lib/config/api/bean/ConfigReq;->sign:Ljava/lang/String;

    .line 288
    .line 289
    invoke-virtual {v5, v6}, Lcom/palmpay/lib/config/api/bean/ConfigReq;->setChannel(Ljava/lang/String;)V

    .line 290
    .line 291
    .line 292
    invoke-static {}, Lm6/j;->c()Lm6/j;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    iget-object v0, v0, Lm6/j;->b:Ljava/lang/Object;

    .line 297
    .line 298
    check-cast v0, Lcom/google/gson/Gson;

    .line 299
    .line 300
    invoke-virtual {v0, v5}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 301
    .line 302
    .line 303
    move-result-object v0

    .line 304
    :cond_6
    :goto_1
    sget-object v2, Lokhttp3/c0;->Companion:Lokhttp3/b0;

    .line 305
    .line 306
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 307
    .line 308
    .line 309
    sget-object v4, Lokhttp3/L;->e:Lokhttp3/K;

    .line 310
    .line 311
    const-string v5, "application/json"

    .line 312
    .line 313
    invoke-virtual {v4, v5}, Lokhttp3/K;->parse(Ljava/lang/String;)Lokhttp3/L;

    .line 314
    .line 315
    .line 316
    move-result-object v4

    .line 317
    invoke-virtual {v2, v0, v4}, Lokhttp3/b0;->create(Ljava/lang/String;Lokhttp3/L;)Lokhttp3/c0;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    invoke-virtual {v3, v0}, Lokhttp3/X;->h(Lokhttp3/c0;)V

    .line 322
    .line 323
    .line 324
    invoke-virtual {v3}, Lokhttp3/X;->b()Lokhttp3/Y;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    move-object/from16 v2, p1

    .line 329
    .line 330
    invoke-interface {v2, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 331
    .line 332
    .line 333
    move-result-object v0

    .line 334
    return-object v0
.end method
