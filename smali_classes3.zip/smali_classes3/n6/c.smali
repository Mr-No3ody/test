.class public final Ln6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LO2/a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ln6/b;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Ln6/b;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(LO2/a;Landroid/content/Context;)V
    .locals 1

    .line 1
    const-string v0, "client"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "context"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Ln6/c;->a:LO2/a;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final a(Lcom/palmpay/lib/config/api/bean/ConfigReq;)Lcom/palmpay/lib/config/api/bean/ConfigRsp;
    .locals 9

    .line 1
    const-string v0, "req"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Ln6/c;->a:LO2/a;

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, v1, LO2/a;->d:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lokhttp3/J;

    .line 14
    .line 15
    invoke-virtual {v0}, Lokhttp3/J;->f()Lokhttp3/H;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const-string v0, "pathSegments"

    .line 20
    .line 21
    const-string v3, "api/nebula-product/param/pull/map"

    .line 22
    .line 23
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    move v4, v0

    .line 28
    :cond_0
    const-string v5, "/\\"

    .line 29
    .line 30
    const/16 v8, 0x21

    .line 31
    .line 32
    invoke-static {v4, v3, v8, v5}, LDg/c;->e(ILjava/lang/String;ILjava/lang/String;)I

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    if-ge v5, v8, :cond_1

    .line 37
    .line 38
    const/4 v6, 0x1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    move v6, v0

    .line 41
    :goto_0
    const/4 v7, 0x0

    .line 42
    invoke-virtual/range {v2 .. v7}, Lokhttp3/H;->g(Ljava/lang/String;IIZZ)V

    .line 43
    .line 44
    .line 45
    add-int/lit8 v4, v5, 0x1

    .line 46
    .line 47
    if-le v4, v8, :cond_0

    .line 48
    .line 49
    sget-object v0, Lokhttp3/c0;->Companion:Lokhttp3/b0;

    .line 50
    .line 51
    invoke-static {}, Lm6/j;->c()Lm6/j;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    iget-object v3, v3, Lm6/j;->b:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v3, Lcom/google/gson/Gson;

    .line 58
    .line 59
    invoke-virtual {v3, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    const-string v3, "toJson(...)"

    .line 64
    .line 65
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    sget-object v3, Lokhttp3/L;->e:Lokhttp3/K;

    .line 69
    .line 70
    const-string v4, "application/json; charset=UTF-8"

    .line 71
    .line 72
    invoke-virtual {v3, v4}, Lokhttp3/K;->parse(Ljava/lang/String;)Lokhttp3/L;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    invoke-virtual {v0, p1, v3}, Lokhttp3/b0;->create(Ljava/lang/String;Lokhttp3/L;)Lokhttp3/c0;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    new-instance v0, Lokhttp3/X;

    .line 81
    .line 82
    invoke-direct {v0}, Lokhttp3/X;-><init>()V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v2}, Lokhttp3/H;->b()Lokhttp3/J;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    const-string v3, "url"

    .line 90
    .line 91
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    iput-object v2, v0, Lokhttp3/X;->a:Lokhttp3/J;

    .line 95
    .line 96
    invoke-virtual {v0, p1}, Lokhttp3/X;->h(Lokhttp3/c0;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v0}, Lokhttp3/X;->b()Lokhttp3/Y;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    iget-object v0, v1, LO2/a;->c:Ljava/lang/Object;

    .line 104
    .line 105
    check-cast v0, Lokhttp3/U;

    .line 106
    .line 107
    invoke-virtual {v0, p1}, Lokhttp3/U;->newCall(Lokhttp3/Y;)Lokhttp3/Call;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    invoke-static {p1}, Lcom/google/firebase/perf/network/FirebasePerfOkHttpClient;->execute(Lokhttp3/Call;)Lokhttp3/e0;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    invoke-virtual {p1}, Lokhttp3/e0;->isSuccessful()Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    if-eqz v0, :cond_3

    .line 120
    .line 121
    iget-object p1, p1, Lokhttp3/e0;->g:Lokhttp3/h0;

    .line 122
    .line 123
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {p1}, Lokhttp3/h0;->string()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    invoke-static {p1}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    invoke-static {}, Lm6/j;->c()Lm6/j;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    const-class v1, Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 143
    .line 144
    invoke-virtual {v0, p1, v1}, Lm6/j;->b(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    check-cast p1, Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 149
    .line 150
    if-eqz p1, :cond_2

    .line 151
    .line 152
    return-object p1

    .line 153
    :cond_2
    new-instance p1, Ljava/io/IOException;

    .line 154
    .line 155
    const-string v0, "Failed to parse remote config response body."

    .line 156
    .line 157
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    throw p1

    .line 161
    :cond_3
    new-instance v0, Ljava/io/IOException;

    .line 162
    .line 163
    new-instance v1, Ljava/lang/StringBuilder;

    .line 164
    .line 165
    const-string v2, "Unexpected response when fetching remote config: "

    .line 166
    .line 167
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 171
    .line 172
    .line 173
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object p1

    .line 177
    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    throw v0
.end method
