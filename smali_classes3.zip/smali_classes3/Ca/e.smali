.class public final LCa/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/Interceptor;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LCa/e;->a:Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final intercept(Lokhttp3/Interceptor$Chain;)Lokhttp3/e0;
    .locals 3

    .line 1
    const-string v0, "chain"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, Lokhttp3/Interceptor$Chain;->request()Lokhttp3/Y;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-interface {p1, v0}, Lokhttp3/Interceptor$Chain;->proceed(Lokhttp3/Y;)Lokhttp3/e0;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iget v1, p1, Lokhttp3/e0;->d:I

    .line 15
    .line 16
    const/16 v2, 0x190

    .line 17
    .line 18
    if-lt v1, v2, :cond_0

    .line 19
    .line 20
    iget-object v1, p0, LCa/e;->a:Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;

    .line 21
    .line 22
    invoke-static {v1, v0, p1}, Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;->access$monitorNetworkError(Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;Lokhttp3/Y;Lokhttp3/e0;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-object p1
.end method
