.class public final LCa/c;
.super Lcom/alibaba/android/alpha/Task;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;)V
    .locals 1

    .line 1
    iput-object p1, p0, LCa/c;->a:Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;

    .line 2
    .line 3
    const-string p1, "task_react_native_init"

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-direct {p0, p1, v0}, Lcom/alibaba/android/alpha/Task;-><init>(Ljava/lang/String;Z)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget-object v0, p0, LCa/c;->a:Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-static {v0, v1, v2, v1}, Lcom/transsnet/palmpay/core/init/BaseInitTask;->beginSection$default(Lcom/transsnet/palmpay/core/init/BaseInitTask;Ljava/lang/String;ILjava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    sget-object v3, Lr9/a;->a:LJ1/h;

    .line 9
    .line 10
    invoke-virtual {v3}, LJ1/h;->a()Z

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    invoke-static {v0}, Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;->access$initOkHttpClientFactory(Lcom/transsnet/palmpay/core/rnbridge/ReactNativeInitTask;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    invoke-static {v0, v1, v2, v1}, Lcom/transsnet/palmpay/core/init/BaseInitTask;->endSection$default(Lcom/transsnet/palmpay/core/init/BaseInitTask;Ljava/lang/String;ILjava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
