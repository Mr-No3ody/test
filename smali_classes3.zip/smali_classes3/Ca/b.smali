.class public final LCa/b;
.super Lcom/alibaba/android/alpha/Task;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/rnbridge/PreloadReactNativeInitTask;

.field public final synthetic b:Landroid/app/Application;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/rnbridge/PreloadReactNativeInitTask;Landroid/app/Application;Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, LCa/b;->a:Lcom/transsnet/palmpay/core/rnbridge/PreloadReactNativeInitTask;

    .line 2
    .line 3
    iput-object p2, p0, LCa/b;->b:Landroid/app/Application;

    .line 4
    .line 5
    invoke-direct {p0, p3}, Lcom/alibaba/android/alpha/Task;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    .line 1
    iget-object v0, p0, LCa/b;->b:Landroid/app/Application;

    .line 2
    .line 3
    iget-object v1, p0, LCa/b;->a:Lcom/transsnet/palmpay/core/rnbridge/PreloadReactNativeInitTask;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    invoke-static {v1, v2, v3, v2}, Lcom/transsnet/palmpay/core/init/BaseInitTask;->beginSection$default(Lcom/transsnet/palmpay/core/init/BaseInitTask;Ljava/lang/String;ILjava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    :try_start_0
    invoke-static {v0}, LCa/f;->a(Landroid/content/Context;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0}, Lcom/transsnet/palmpay/util/DeviceUtils;->getDeviceLevel(Landroid/content/Context;)Lcom/transsnet/palmpay/util/DeviceUtils$LEVEL;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 22
    .line 23
    const/16 v5, 0x22

    .line 24
    .line 25
    if-eq v4, v5, :cond_1

    .line 26
    .line 27
    sget-object v4, Lcom/transsnet/palmpay/util/DeviceUtils$LEVEL;->BEST:Lcom/transsnet/palmpay/util/DeviceUtils$LEVEL;

    .line 28
    .line 29
    if-eq v0, v4, :cond_0

    .line 30
    .line 31
    sget-object v4, Lcom/transsnet/palmpay/util/DeviceUtils$LEVEL;->HIGH:Lcom/transsnet/palmpay/util/DeviceUtils$LEVEL;

    .line 32
    .line 33
    if-ne v0, v4, :cond_1

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :catch_0
    move-exception v0

    .line 37
    goto :goto_1

    .line 38
    :cond_0
    :goto_0
    invoke-static {v1}, Lcom/transsnet/palmpay/core/rnbridge/PreloadReactNativeInitTask;->access$preload(Lcom/transsnet/palmpay/core/rnbridge/PreloadReactNativeInitTask;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 39
    .line 40
    .line 41
    goto :goto_2

    .line 42
    :goto_1
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 43
    .line 44
    .line 45
    :cond_1
    :goto_2
    invoke-static {v1, v2, v3, v2}, Lcom/transsnet/palmpay/core/init/BaseInitTask;->endSection$default(Lcom/transsnet/palmpay/core/init/BaseInitTask;Ljava/lang/String;ILjava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    return-void
.end method
