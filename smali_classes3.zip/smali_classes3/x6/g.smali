.class public final Lx6/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/palmpay/lib/liveness/task/IDetectionTask;


# instance fields
.field public final a:F

.field public b:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lx6/f;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lx6/f;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lp6/p;->a:Lp6/p;

    .line 5
    .line 6
    sget-object v0, Lp6/p;->d:Lr6/a;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, v0, Lr6/a;->l:Ljava/lang/Float;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/high16 v0, 0x3f000000    # 0.5f

    .line 20
    .line 21
    :goto_0
    iput v0, p0, Lx6/g;->a:F

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final process(Lcom/google/mlkit/vision/face/Face;)Z
    .locals 7

    .line 1
    const-string v0, "face"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->holdOn()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1}, Lcom/google/mlkit/vision/face/Face;->getLeftEyeOpenProbability()Ljava/lang/Float;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {p1}, Lcom/google/mlkit/vision/face/Face;->getRightEyeOpenProbability()Ljava/lang/Float;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    if-eqz v1, :cond_0

    .line 20
    .line 21
    if-eqz v2, :cond_0

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    iget v3, p0, Lx6/g;->a:F

    .line 28
    .line 29
    cmpg-float v1, v1, v3

    .line 30
    .line 31
    if-ltz v1, :cond_7

    .line 32
    .line 33
    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    cmpg-float v1, v1, v3

    .line 38
    .line 39
    if-gez v1, :cond_0

    .line 40
    .line 41
    goto :goto_3

    .line 42
    :cond_0
    sget-object v1, Lp6/p;->d:Lr6/a;

    .line 43
    .line 44
    if-eqz v1, :cond_1

    .line 45
    .line 46
    iget-object v1, v1, Lr6/a;->s:Lcom/palmpay/lib/liveness/model/ExtendFeature;

    .line 47
    .line 48
    if-eqz v1, :cond_1

    .line 49
    .line 50
    invoke-virtual {v1}, Lcom/palmpay/lib/liveness/model/ExtendFeature;->getHoldOnFacingDetect()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    goto :goto_0

    .line 55
    :cond_1
    const/4 v1, 0x0

    .line 56
    :goto_0
    const/4 v2, 0x1

    .line 57
    if-eqz v1, :cond_4

    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    packed-switch v3, :pswitch_data_0

    .line 64
    .line 65
    .line 66
    goto :goto_1

    .line 67
    :pswitch_0
    const-string v3, "3"

    .line 68
    .line 69
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-nez v1, :cond_2

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 77
    .line 78
    .line 79
    move-result-wide v3

    .line 80
    iget-wide v5, p0, Lx6/g;->b:J

    .line 81
    .line 82
    sub-long/2addr v3, v5

    .line 83
    const-wide/16 v5, 0x7d0

    .line 84
    .line 85
    cmp-long v1, v3, v5

    .line 86
    .line 87
    if-gez v1, :cond_3

    .line 88
    .line 89
    invoke-static {p1}, LD3/a;->o(Lcom/google/mlkit/vision/face/Face;)Z

    .line 90
    .line 91
    .line 92
    move-result p1

    .line 93
    goto :goto_2

    .line 94
    :cond_3
    invoke-virtual {v0, v2}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->holdOnTimeOut(I)V

    .line 95
    .line 96
    .line 97
    :cond_4
    :goto_1
    move p1, v2

    .line 98
    goto :goto_2

    .line 99
    :pswitch_1
    const-string v0, "2"

    .line 100
    .line 101
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    if-nez v0, :cond_5

    .line 106
    .line 107
    goto :goto_1

    .line 108
    :cond_5
    invoke-static {p1}, LD3/a;->o(Lcom/google/mlkit/vision/face/Face;)Z

    .line 109
    .line 110
    .line 111
    move-result p1

    .line 112
    goto :goto_2

    .line 113
    :pswitch_2
    const-string p1, "1"

    .line 114
    .line 115
    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    goto :goto_1

    .line 119
    :goto_2
    if-nez p1, :cond_6

    .line 120
    .line 121
    goto :goto_3

    .line 122
    :cond_6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 123
    .line 124
    .line 125
    move-result-wide v0

    .line 126
    iget-wide v3, p0, Lx6/g;->b:J

    .line 127
    .line 128
    sub-long/2addr v0, v3

    .line 129
    const-wide/16 v3, 0x5dc

    .line 130
    .line 131
    cmp-long p1, v0, v3

    .line 132
    .line 133
    if-ltz p1, :cond_7

    .line 134
    .line 135
    return v2

    .line 136
    :cond_7
    :goto_3
    const/4 p1, 0x0

    .line 137
    return p1

    .line 138
    nop

    .line 139
    :pswitch_data_0
    .packed-switch 0x31
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final start()V
    .locals 2

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    iput-wide v0, p0, Lx6/g;->b:J

    .line 6
    .line 7
    return-void
.end method
