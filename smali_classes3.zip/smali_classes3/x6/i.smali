.class public final Lx6/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/palmpay/lib/liveness/task/IDetectionTask;


# instance fields
.field public final a:F


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lx6/h;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lx6/h;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "threshold"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    :try_start_0
    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 10
    .line 11
    .line 12
    move-result p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    goto :goto_0

    .line 14
    :catch_0
    const p1, 0x3e99999a    # 0.3f

    .line 15
    .line 16
    .line 17
    :goto_0
    iput p1, p0, Lx6/i;->a:F

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final process(Lcom/google/mlkit/vision/face/Face;)Z
    .locals 12

    .line 1
    const-string v0, "face"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lp6/p;->l:Lcom/palmpay/lib/liveness/net/ReasonTrack;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/palmpay/lib/liveness/net/ReasonTrack;->mouthOpen()V

    .line 9
    .line 10
    .line 11
    invoke-static {p1}, LD3/a;->o(Lcom/google/mlkit/vision/face/Face;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/4 v1, 0x0

    .line 16
    if-eqz v0, :cond_6

    .line 17
    .line 18
    const/4 v0, 0x5

    .line 19
    invoke-virtual {p1, v0}, Lcom/google/mlkit/vision/face/Face;->getLandmark(I)Lcom/google/mlkit/vision/face/FaceLandmark;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_6

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/google/mlkit/vision/face/FaceLandmark;->getPosition()Landroid/graphics/PointF;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    goto/16 :goto_1

    .line 32
    .line 33
    :cond_0
    const/16 v2, 0xb

    .line 34
    .line 35
    invoke-virtual {p1, v2}, Lcom/google/mlkit/vision/face/Face;->getLandmark(I)Lcom/google/mlkit/vision/face/FaceLandmark;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    if-eqz v2, :cond_6

    .line 40
    .line 41
    invoke-virtual {v2}, Lcom/google/mlkit/vision/face/FaceLandmark;->getPosition()Landroid/graphics/PointF;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    if-nez v2, :cond_1

    .line 46
    .line 47
    goto/16 :goto_1

    .line 48
    .line 49
    :cond_1
    invoke-virtual {p1, v1}, Lcom/google/mlkit/vision/face/Face;->getLandmark(I)Lcom/google/mlkit/vision/face/FaceLandmark;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    if-eqz p1, :cond_6

    .line 54
    .line 55
    invoke-virtual {p1}, Lcom/google/mlkit/vision/face/FaceLandmark;->getPosition()Landroid/graphics/PointF;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    if-nez p1, :cond_2

    .line 60
    .line 61
    goto/16 :goto_1

    .line 62
    .line 63
    :cond_2
    iget v3, v0, Landroid/graphics/PointF;->x:F

    .line 64
    .line 65
    iget v4, v2, Landroid/graphics/PointF;->x:F

    .line 66
    .line 67
    sub-float/2addr v3, v4

    .line 68
    iget v4, v0, Landroid/graphics/PointF;->y:F

    .line 69
    .line 70
    iget v5, v2, Landroid/graphics/PointF;->y:F

    .line 71
    .line 72
    sub-float/2addr v4, v5

    .line 73
    mul-float/2addr v3, v3

    .line 74
    mul-float/2addr v4, v4

    .line 75
    add-float/2addr v4, v3

    .line 76
    float-to-double v3, v4

    .line 77
    invoke-static {v3, v4}, Ljava/lang/Math;->sqrt(D)D

    .line 78
    .line 79
    .line 80
    move-result-wide v3

    .line 81
    double-to-float v3, v3

    .line 82
    iget v4, p1, Landroid/graphics/PointF;->x:F

    .line 83
    .line 84
    iget v5, v0, Landroid/graphics/PointF;->x:F

    .line 85
    .line 86
    sub-float v6, v4, v5

    .line 87
    .line 88
    iget p1, p1, Landroid/graphics/PointF;->y:F

    .line 89
    .line 90
    iget v0, v0, Landroid/graphics/PointF;->y:F

    .line 91
    .line 92
    sub-float v7, p1, v0

    .line 93
    .line 94
    iget v8, v2, Landroid/graphics/PointF;->x:F

    .line 95
    .line 96
    sub-float v9, v8, v5

    .line 97
    .line 98
    iget v2, v2, Landroid/graphics/PointF;->y:F

    .line 99
    .line 100
    sub-float v10, v2, v0

    .line 101
    .line 102
    mul-float/2addr v6, v9

    .line 103
    mul-float/2addr v7, v10

    .line 104
    add-float/2addr v7, v6

    .line 105
    mul-float v6, v9, v9

    .line 106
    .line 107
    mul-float v11, v10, v10

    .line 108
    .line 109
    add-float/2addr v11, v6

    .line 110
    div-float/2addr v7, v11

    .line 111
    const/4 v6, 0x0

    .line 112
    cmpg-float v6, v7, v6

    .line 113
    .line 114
    if-ltz v6, :cond_5

    .line 115
    .line 116
    cmpg-float v6, v5, v8

    .line 117
    .line 118
    if-nez v6, :cond_3

    .line 119
    .line 120
    cmpg-float v6, v0, v2

    .line 121
    .line 122
    if-nez v6, :cond_3

    .line 123
    .line 124
    goto :goto_0

    .line 125
    :cond_3
    const/high16 v6, 0x3f800000    # 1.0f

    .line 126
    .line 127
    cmpl-float v6, v7, v6

    .line 128
    .line 129
    if-lez v6, :cond_4

    .line 130
    .line 131
    move v0, v2

    .line 132
    move v5, v8

    .line 133
    goto :goto_0

    .line 134
    :cond_4
    mul-float/2addr v9, v7

    .line 135
    add-float/2addr v5, v9

    .line 136
    mul-float/2addr v7, v10

    .line 137
    add-float/2addr v0, v7

    .line 138
    :cond_5
    :goto_0
    sub-float/2addr v4, v5

    .line 139
    sub-float/2addr p1, v0

    .line 140
    mul-float/2addr v4, v4

    .line 141
    mul-float/2addr p1, p1

    .line 142
    add-float/2addr p1, v4

    .line 143
    float-to-double v4, p1

    .line 144
    invoke-static {v4, v5}, Ljava/lang/Math;->sqrt(D)D

    .line 145
    .line 146
    .line 147
    move-result-wide v4

    .line 148
    double-to-float p1, v4

    .line 149
    div-float/2addr p1, v3

    .line 150
    sget v0, Lt6/a;->a:I

    .line 151
    .line 152
    new-instance v0, Ljava/lang/StringBuilder;

    .line 153
    .line 154
    const-string v2, "mouth ratio: "

    .line 155
    .line 156
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 160
    .line 161
    .line 162
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    invoke-static {v0}, Lt6/a;->a(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    iget v0, p0, Lx6/i;->a:F

    .line 170
    .line 171
    cmpl-float p1, p1, v0

    .line 172
    .line 173
    if-lez p1, :cond_6

    .line 174
    .line 175
    const/4 p1, 0x1

    .line 176
    return p1

    .line 177
    :cond_6
    :goto_1
    return v1
.end method

.method public final start()V
    .locals 0

    .line 1
    return-void
.end method
