.class public final synthetic LUa/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;I)V
    .locals 0

    .line 1
    iput p2, p0, LUa/n;->a:I

    iput-object p1, p0, LUa/n;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, LUa/n;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 2
    .line 3
    iget v1, p0, LUa/n;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    invoke-static {v0}, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->a(Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;)Lkotlin/Unit;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0

    .line 13
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->o:I

    .line 14
    .line 15
    sget v1, Lba/e;->vs_coupon_available_list:I

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Landroid/view/ViewStub;

    .line 22
    .line 23
    invoke-virtual {v1}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const-string v2, "null cannot be cast to non-null type com.transsnet.palmpay.core.viewmodel.ModelCouponListItemView"

    .line 28
    .line 29
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    check-cast v1, Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;

    .line 33
    .line 34
    new-instance v2, LR8/d;

    .line 35
    .line 36
    const/16 v3, 0xf

    .line 37
    .line 38
    invoke-direct {v2, v0, v3}, LR8/d;-><init>(Ljava/lang/Object;I)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 42
    .line 43
    .line 44
    return-object v1

    .line 45
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->o:I

    .line 46
    .line 47
    sget v1, Lba/e;->vs_coupon_claimable_list:I

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    check-cast v0, Landroid/view/ViewStub;

    .line 54
    .line 55
    invoke-virtual {v0}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    const-string v1, "null cannot be cast to non-null type com.transsnet.palmpay.core.viewmodel.ModelClaimCouponListItemView"

    .line 60
    .line 61
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponListItemView;

    .line 65
    .line 66
    return-object v0

    .line 67
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
