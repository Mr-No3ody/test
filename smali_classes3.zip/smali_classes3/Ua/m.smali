.class public final synthetic LUa/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;I)V
    .locals 0

    .line 1
    iput p2, p0, LUa/m;->a:I

    iput-object p1, p0, LUa/m;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LUa/m;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;

    .line 2
    .line 3
    iget v1, p0, LUa/m;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;->i:I

    .line 9
    .line 10
    sget v1, Lba/e;->tvTitle:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/TextView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;->i:I

    .line 20
    .line 21
    sget v1, Lba/e;->tvAmount:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/TextView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;->i:I

    .line 31
    .line 32
    sget v1, Lba/e;->viewContainer:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Lcom/transsnet/palmpay/custom_view/viewholder/LabelLayout;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;->i:I

    .line 42
    .line 43
    sget v1, Lba/e;->tvApply:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Landroid/widget/TextView;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelApplyOkCard;->i:I

    .line 53
    .line 54
    sget v1, Lba/e;->tvMessage:I

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Landroid/widget/TextView;

    .line 61
    .line 62
    return-object v0

    .line 63
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
