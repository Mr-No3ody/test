.class public final LUa/r0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:J

.field public final synthetic d:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;


# direct methods
.method public constructor <init>(JLcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-wide p1, p0, LUa/r0;->c:J

    .line 2
    .line 3
    iput-object p3, p0, LUa/r0;->d:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p4}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 4

    .line 1
    new-instance v0, LUa/r0;

    .line 2
    .line 3
    iget-wide v1, p0, LUa/r0;->c:J

    .line 4
    .line 5
    iget-object v3, p0, LUa/r0;->d:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2, v3, p2}, LUa/r0;-><init>(JLcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;Lkotlin/coroutines/Continuation;)V

    .line 8
    .line 9
    .line 10
    iput-object p1, v0, LUa/r0;->b:Ljava/lang/Object;

    .line 11
    .line 12
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/r0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/r0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/r0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LUa/r0;->a:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    iget-object v1, p0, LUa/r0;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    .line 13
    .line 14
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 19
    .line 20
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 21
    .line 22
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    throw p1

    .line 26
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object p1, p0, LUa/r0;->b:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 32
    .line 33
    move-object v1, p1

    .line 34
    :cond_2
    :goto_0
    invoke-static {v1}, LWf/v;->e(Lkotlinx/coroutines/CoroutineScope;)Z

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    if-eqz p1, :cond_9

    .line 39
    .line 40
    sget p1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->A:I

    .line 41
    .line 42
    int-to-long v3, p1

    .line 43
    iget-wide v5, p0, LUa/r0;->c:J

    .line 44
    .line 45
    add-long/2addr v3, v5

    .line 46
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 47
    .line 48
    .line 49
    move-result-wide v5

    .line 50
    sub-long/2addr v3, v5

    .line 51
    const-wide/16 v5, 0x0

    .line 52
    .line 53
    cmp-long p1, v3, v5

    .line 54
    .line 55
    iget-object v5, p0, LUa/r0;->d:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 56
    .line 57
    if-gtz p1, :cond_5

    .line 58
    .line 59
    iget-object p1, v5, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->c:Lja/f;

    .line 60
    .line 61
    if-eqz p1, :cond_3

    .line 62
    .line 63
    iget-object p1, p1, Lja/f;->tvTime:Landroid/widget/TextView;

    .line 64
    .line 65
    if-eqz p1, :cond_3

    .line 66
    .line 67
    const-string v0, ""

    .line 68
    .line 69
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 70
    .line 71
    .line 72
    :cond_3
    iget-object p1, v5, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->c:Lja/f;

    .line 73
    .line 74
    if-eqz p1, :cond_4

    .line 75
    .line 76
    iget-object p1, p1, Lja/f;->tvTime:Landroid/widget/TextView;

    .line 77
    .line 78
    if-eqz p1, :cond_4

    .line 79
    .line 80
    const/16 v0, 0x8

    .line 81
    .line 82
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 83
    .line 84
    .line 85
    :cond_4
    invoke-virtual {v5, v2}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->setSendOtcButtonState(Z)V

    .line 86
    .line 87
    .line 88
    iget-object p1, v5, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->c:Lja/f;

    .line 89
    .line 90
    if-eqz p1, :cond_9

    .line 91
    .line 92
    iget-object p1, p1, Lja/f;->textViewSendSms:Landroid/widget/TextView;

    .line 93
    .line 94
    if-eqz p1, :cond_9

    .line 95
    .line 96
    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    sget v1, Lba/k;->core_resend:I

    .line 101
    .line 102
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 107
    .line 108
    .line 109
    goto :goto_1

    .line 110
    :cond_5
    iget-boolean p1, v5, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->f:Z

    .line 111
    .line 112
    const/4 v6, 0x0

    .line 113
    if-eqz p1, :cond_6

    .line 114
    .line 115
    const-wide/32 v7, 0xc350

    .line 116
    .line 117
    .line 118
    cmp-long p1, v3, v7

    .line 119
    .line 120
    if-gtz p1, :cond_6

    .line 121
    .line 122
    invoke-virtual {v5}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->o()V

    .line 123
    .line 124
    .line 125
    iput-boolean v6, v5, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->f:Z

    .line 126
    .line 127
    :cond_6
    iget-object p1, v5, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->c:Lja/f;

    .line 128
    .line 129
    if-eqz p1, :cond_7

    .line 130
    .line 131
    iget-object p1, p1, Lja/f;->tvTime:Landroid/widget/TextView;

    .line 132
    .line 133
    if-eqz p1, :cond_7

    .line 134
    .line 135
    invoke-virtual {p1, v6}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 136
    .line 137
    .line 138
    :cond_7
    iget-object p1, v5, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->c:Lja/f;

    .line 139
    .line 140
    if-eqz p1, :cond_8

    .line 141
    .line 142
    iget-object p1, p1, Lja/f;->tvTime:Landroid/widget/TextView;

    .line 143
    .line 144
    if-eqz p1, :cond_8

    .line 145
    .line 146
    const/16 v5, 0x3e8

    .line 147
    .line 148
    int-to-long v5, v5

    .line 149
    div-long/2addr v3, v5

    .line 150
    new-instance v5, Ljava/lang/StringBuilder;

    .line 151
    .line 152
    const-string v6, "Resend ("

    .line 153
    .line 154
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v5, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    const-string v3, "s)"

    .line 161
    .line 162
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 163
    .line 164
    .line 165
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 170
    .line 171
    .line 172
    :cond_8
    iput-object v1, p0, LUa/r0;->b:Ljava/lang/Object;

    .line 173
    .line 174
    iput v2, p0, LUa/r0;->a:I

    .line 175
    .line 176
    const-wide/16 v3, 0x3e8

    .line 177
    .line 178
    invoke-static {v3, v4, p0}, LWf/D;->b(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    if-ne p1, v0, :cond_2

    .line 183
    .line 184
    return-object v0

    .line 185
    :cond_9
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 186
    .line 187
    return-object p1
.end method
