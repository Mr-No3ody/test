.class public final synthetic LUa/i0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# instance fields
.field public final synthetic a:Landroid/view/View$OnFocusChangeListener;

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/c;

.field public final synthetic c:Landroid/widget/EditText;

.field public final synthetic d:Ljava/util/ArrayList;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View$OnFocusChangeListener;Lcom/transsnet/palmpay/core/viewmodel/c;Landroid/widget/EditText;Ljava/util/ArrayList;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LUa/i0;->a:Landroid/view/View$OnFocusChangeListener;

    iput-object p2, p0, LUa/i0;->b:Lcom/transsnet/palmpay/core/viewmodel/c;

    iput-object p3, p0, LUa/i0;->c:Landroid/widget/EditText;

    iput-object p4, p0, LUa/i0;->d:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    .locals 3

    .line 1
    iget-object v0, p0, LUa/i0;->a:Landroid/view/View$OnFocusChangeListener;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-interface {v0, p1, p2}, Landroid/view/View$OnFocusChangeListener;->onFocusChange(Landroid/view/View;Z)V

    .line 6
    .line 7
    .line 8
    :cond_0
    iget-object p1, p0, LUa/i0;->c:Landroid/widget/EditText;

    .line 9
    .line 10
    iget-object v0, p0, LUa/i0;->b:Lcom/transsnet/palmpay/core/viewmodel/c;

    .line 11
    .line 12
    if-eqz p2, :cond_1

    .line 13
    .line 14
    iput-object p1, v0, Lcom/transsnet/palmpay/core/viewmodel/c;->d:Landroid/widget/EditText;

    .line 15
    .line 16
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/viewmodel/c;->g()V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :cond_1
    new-instance p2, LB6/g;

    .line 21
    .line 22
    iget-object v1, p0, LUa/i0;->d:Ljava/util/ArrayList;

    .line 23
    .line 24
    const/16 v2, 0x15

    .line 25
    .line 26
    invoke-direct {p2, v2, v1, v0}, LB6/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p1, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 30
    .line 31
    .line 32
    return-void
.end method
