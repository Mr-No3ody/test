.class public final LUa/b;
.super Landroidx/lifecycle/a0;
.source "SourceFile"


# instance fields
.field public final d:Landroidx/lifecycle/F;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroidx/lifecycle/a0;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroidx/lifecycle/F;

    .line 5
    .line 6
    invoke-direct {v0}, Landroidx/lifecycle/B;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LUa/b;->d:Landroidx/lifecycle/F;

    .line 10
    .line 11
    return-void
.end method
