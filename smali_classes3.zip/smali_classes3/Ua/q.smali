.class public final LUa/q;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public b:I

.field public c:J

.field public d:I

.field public synthetic e:Ljava/lang/Object;

.field public final synthetic f:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;)V
    .locals 0

    .line 1
    iput-object p2, p0, LUa/q;->f:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 2
    .line 3
    const/4 p2, 0x2

    .line 4
    invoke-direct {p0, p2, p1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance v0, LUa/q;

    .line 2
    .line 3
    iget-object v1, p0, LUa/q;->f:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 4
    .line 5
    invoke-direct {v0, p2, v1}, LUa/q;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;)V

    .line 6
    .line 7
    .line 8
    iput-object p1, v0, LUa/q;->e:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/q;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/q;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/q;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LUa/q;->d:I

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x5

    .line 7
    const/4 v4, 0x4

    .line 8
    iget-object v5, p0, LUa/q;->f:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 9
    .line 10
    const/4 v6, 0x0

    .line 11
    const/4 v7, 0x1

    .line 12
    if-eqz v1, :cond_5

    .line 13
    .line 14
    if-eq v1, v7, :cond_4

    .line 15
    .line 16
    if-eq v1, v2, :cond_3

    .line 17
    .line 18
    const/4 v2, 0x3

    .line 19
    if-eq v1, v2, :cond_2

    .line 20
    .line 21
    if-eq v1, v4, :cond_1

    .line 22
    .line 23
    if-ne v1, v3, :cond_0

    .line 24
    .line 25
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    goto/16 :goto_9

    .line 29
    .line 30
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 31
    .line 32
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 33
    .line 34
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    throw p1

    .line 38
    :cond_1
    iget-object v1, p0, LUa/q;->e:Ljava/lang/Object;

    .line 39
    .line 40
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto/16 :goto_7

    .line 44
    .line 45
    :cond_2
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    .line 50
    goto/16 :goto_3

    .line 51
    .line 52
    :catchall_0
    move-exception p1

    .line 53
    goto/16 :goto_5

    .line 54
    .line 55
    :cond_3
    iget v1, p0, LUa/q;->b:I

    .line 56
    .line 57
    iget-wide v8, p0, LUa/q;->c:J

    .line 58
    .line 59
    iget v10, p0, LUa/q;->a:I

    .line 60
    .line 61
    :try_start_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 62
    .line 63
    .line 64
    goto :goto_2

    .line 65
    :cond_4
    iget v1, p0, LUa/q;->b:I

    .line 66
    .line 67
    iget-wide v8, p0, LUa/q;->c:J

    .line 68
    .line 69
    iget v10, p0, LUa/q;->a:I

    .line 70
    .line 71
    :try_start_2
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 72
    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_5
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    iget-object p1, p0, LUa/q;->e:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 81
    .line 82
    :try_start_3
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 83
    .line 84
    const-wide/16 v8, 0x3e8

    .line 85
    .line 86
    const/4 p1, 0x0

    .line 87
    move v1, v2

    .line 88
    :goto_0
    if-ge p1, v1, :cond_9

    .line 89
    .line 90
    sget-object v10, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 91
    .line 92
    iget-object v10, v10, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast v10, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 95
    .line 96
    iget-object v11, v5, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->d:Ljava/lang/String;

    .line 97
    .line 98
    iput v1, p0, LUa/q;->a:I

    .line 99
    .line 100
    iput-wide v8, p0, LUa/q;->c:J

    .line 101
    .line 102
    iput p1, p0, LUa/q;->b:I

    .line 103
    .line 104
    iput v7, p0, LUa/q;->d:I

    .line 105
    .line 106
    invoke-interface {v10, v11, p0}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryCouponList(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v10

    .line 110
    if-ne v10, v0, :cond_6

    .line 111
    .line 112
    goto/16 :goto_8

    .line 113
    .line 114
    :cond_6
    move v13, v1

    .line 115
    move v1, p1

    .line 116
    move-object p1, v10

    .line 117
    move v10, v13

    .line 118
    :goto_1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 119
    .line 120
    move-object v11, p1

    .line 121
    check-cast v11, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 122
    .line 123
    if-eqz v11, :cond_7

    .line 124
    .line 125
    invoke-virtual {v11}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 126
    .line 127
    .line 128
    move-result v12

    .line 129
    if-ne v12, v7, :cond_7

    .line 130
    .line 131
    iget-object v11, v11, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast v11, Lcom/transsnet/palmpay/core/bean/rsp/QueryCouponClaimBodyData;

    .line 134
    .line 135
    if-eqz v11, :cond_7

    .line 136
    .line 137
    goto :goto_3

    .line 138
    :cond_7
    iput v10, p0, LUa/q;->a:I

    .line 139
    .line 140
    iput-wide v8, p0, LUa/q;->c:J

    .line 141
    .line 142
    iput v1, p0, LUa/q;->b:I

    .line 143
    .line 144
    iput v2, p0, LUa/q;->d:I

    .line 145
    .line 146
    invoke-static {v8, v9, p0}, LWf/D;->b(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    if-ne p1, v0, :cond_8

    .line 151
    .line 152
    goto :goto_8

    .line 153
    :cond_8
    :goto_2
    add-int/lit8 p1, v1, 0x1

    .line 154
    .line 155
    move v1, v10

    .line 156
    goto :goto_0

    .line 157
    :cond_9
    move-object p1, v6

    .line 158
    :goto_3
    sget-object v1, Lxf/q;->a:Lxf/o;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 159
    .line 160
    :goto_4
    move-object v1, p1

    .line 161
    goto :goto_6

    .line 162
    :goto_5
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 163
    .line 164
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    goto :goto_4

    .line 169
    :goto_6
    instance-of p1, v1, Lxf/p;

    .line 170
    .line 171
    if-nez p1, :cond_a

    .line 172
    .line 173
    move-object p1, v1

    .line 174
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 175
    .line 176
    sget-object v2, LWf/I;->a:Lcg/f;

    .line 177
    .line 178
    sget-object v2, Lag/o;->a:LWf/p0;

    .line 179
    .line 180
    new-instance v7, LUa/o;

    .line 181
    .line 182
    invoke-direct {v7, p1, v6, v5}, LUa/o;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;)V

    .line 183
    .line 184
    .line 185
    iput-object v1, p0, LUa/q;->e:Ljava/lang/Object;

    .line 186
    .line 187
    iput v4, p0, LUa/q;->d:I

    .line 188
    .line 189
    invoke-static {v2, v7, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    if-ne p1, v0, :cond_a

    .line 194
    .line 195
    goto :goto_8

    .line 196
    :cond_a
    :goto_7
    invoke-static {v1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 197
    .line 198
    .line 199
    move-result-object p1

    .line 200
    if-eqz p1, :cond_b

    .line 201
    .line 202
    sget-object v2, LWf/I;->a:Lcg/f;

    .line 203
    .line 204
    sget-object v2, Lag/o;->a:LWf/p0;

    .line 205
    .line 206
    new-instance v4, LUa/p;

    .line 207
    .line 208
    invoke-direct {v4, v6, p1}, LUa/p;-><init>(Lkotlin/coroutines/Continuation;Ljava/lang/Throwable;)V

    .line 209
    .line 210
    .line 211
    iput-object v1, p0, LUa/q;->e:Ljava/lang/Object;

    .line 212
    .line 213
    iput v3, p0, LUa/q;->d:I

    .line 214
    .line 215
    invoke-static {v2, v4, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object p1

    .line 219
    if-ne p1, v0, :cond_b

    .line 220
    .line 221
    :goto_8
    return-object v0

    .line 222
    :cond_b
    :goto_9
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 223
    .line 224
    return-object p1
.end method
