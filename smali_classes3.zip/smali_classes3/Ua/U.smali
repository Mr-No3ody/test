.class public final LUa/U;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;Ljava/lang/String;Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)V
    .locals 0

    .line 1
    iput-object p2, p0, LUa/U;->c:Ljava/lang/String;

    .line 2
    .line 3
    iput-object p3, p0, LUa/U;->d:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;

    .line 4
    .line 5
    const/4 p2, 0x2

    .line 6
    invoke-direct {p0, p2, p1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance v0, LUa/U;

    .line 2
    .line 3
    iget-object v1, p0, LUa/U;->c:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v2, p0, LUa/U;->d:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;

    .line 6
    .line 7
    invoke-direct {v0, p2, v1, v2}, LUa/U;-><init>(Lkotlin/coroutines/Continuation;Ljava/lang/String;Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)V

    .line 8
    .line 9
    .line 10
    iput-object p1, v0, LUa/U;->b:Ljava/lang/Object;

    .line 11
    .line 12
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/U;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/U;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/U;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LUa/U;->a:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x3

    .line 7
    const/4 v4, 0x2

    .line 8
    const/4 v5, 0x1

    .line 9
    if-eqz v1, :cond_3

    .line 10
    .line 11
    if-eq v1, v5, :cond_2

    .line 12
    .line 13
    if-eq v1, v4, :cond_1

    .line 14
    .line 15
    if-ne v1, v3, :cond_0

    .line 16
    .line 17
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    goto/16 :goto_7

    .line 21
    .line 22
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 23
    .line 24
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 25
    .line 26
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    throw p1

    .line 30
    :cond_1
    iget-object v1, p0, LUa/U;->b:Ljava/lang/Object;

    .line 31
    .line 32
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    goto :goto_5

    .line 36
    :cond_2
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :catchall_0
    move-exception p1

    .line 41
    goto :goto_3

    .line 42
    :cond_3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object p1, p0, LUa/U;->b:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 48
    .line 49
    :try_start_1
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 50
    .line 51
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 52
    .line 53
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 56
    .line 57
    iget-object v1, p0, LUa/U;->c:Ljava/lang/String;

    .line 58
    .line 59
    if-eqz v1, :cond_4

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_4
    const-string v1, ""

    .line 63
    .line 64
    :goto_0
    iput v5, p0, LUa/U;->a:I

    .line 65
    .line 66
    invoke-interface {p1, v1, p0}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryDataBundleFlashSaleList(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    if-ne p1, v0, :cond_5

    .line 71
    .line 72
    goto :goto_6

    .line 73
    :cond_5
    :goto_1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 74
    .line 75
    sget-object v1, Lxf/q;->a:Lxf/o;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 76
    .line 77
    :goto_2
    move-object v1, p1

    .line 78
    goto :goto_4

    .line 79
    :goto_3
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 80
    .line 81
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    goto :goto_2

    .line 86
    :goto_4
    instance-of p1, v1, Lxf/p;

    .line 87
    .line 88
    if-nez p1, :cond_6

    .line 89
    .line 90
    move-object p1, v1

    .line 91
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 92
    .line 93
    sget-object v5, LWf/I;->a:Lcg/f;

    .line 94
    .line 95
    sget-object v5, Lag/o;->a:LWf/p0;

    .line 96
    .line 97
    new-instance v6, LUa/S;

    .line 98
    .line 99
    iget-object v7, p0, LUa/U;->d:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;

    .line 100
    .line 101
    invoke-direct {v6, p1, v2, v7}, LUa/S;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)V

    .line 102
    .line 103
    .line 104
    iput-object v1, p0, LUa/U;->b:Ljava/lang/Object;

    .line 105
    .line 106
    iput v4, p0, LUa/U;->a:I

    .line 107
    .line 108
    invoke-static {v5, v6, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object p1

    .line 112
    if-ne p1, v0, :cond_6

    .line 113
    .line 114
    goto :goto_6

    .line 115
    :cond_6
    :goto_5
    invoke-static {v1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    if-eqz p1, :cond_7

    .line 120
    .line 121
    sget-object v4, LWf/I;->a:Lcg/f;

    .line 122
    .line 123
    sget-object v4, Lag/o;->a:LWf/p0;

    .line 124
    .line 125
    new-instance v5, LUa/T;

    .line 126
    .line 127
    invoke-direct {v5, v2, p1}, LUa/T;-><init>(Lkotlin/coroutines/Continuation;Ljava/lang/Throwable;)V

    .line 128
    .line 129
    .line 130
    iput-object v1, p0, LUa/U;->b:Ljava/lang/Object;

    .line 131
    .line 132
    iput v3, p0, LUa/U;->a:I

    .line 133
    .line 134
    invoke-static {v4, v5, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    if-ne p1, v0, :cond_7

    .line 139
    .line 140
    :goto_6
    return-object v0

    .line 141
    :cond_7
    :goto_7
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 142
    .line 143
    return-object p1
.end method
