.class public final LUa/b0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView$OnWheelItemSelectedListener;


# instance fields
.field public a:I

.field public final synthetic b:Ljava/util/ArrayList;

.field public final synthetic c:Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;Ljava/util/ArrayList;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LUa/b0;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;

    .line 5
    .line 6
    iput-object p2, p0, LUa/b0;->b:Ljava/util/ArrayList;

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    iput p1, p0, LUa/b0;->a:I

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final onItemSelected(ILjava/lang/Object;)V
    .locals 4

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    iget-object v0, p0, LUa/b0;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;

    .line 6
    .line 7
    iput-object p2, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->p:Ljava/lang/String;

    .line 8
    .line 9
    iget-object p2, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->t:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->e()V

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, LUa/b0;->b:Ljava/util/ArrayList;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    if-nez p1, :cond_0

    .line 18
    .line 19
    iget-object v3, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->i:Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    iget v3, p0, LUa/b0;->a:I

    .line 26
    .line 27
    if-lez v3, :cond_1

    .line 28
    .line 29
    return-void

    .line 30
    :cond_1
    iget-object v3, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->i:Ljava/util/ArrayList;

    .line 31
    .line 32
    invoke-virtual {v3, v2, v1}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z

    .line 33
    .line 34
    .line 35
    :goto_0
    move v1, v2

    .line 36
    :goto_1
    iget-object v3, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->i:Ljava/util/ArrayList;

    .line 37
    .line 38
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    if-ge v1, v3, :cond_3

    .line 43
    .line 44
    iget-object v3, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->i:Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    invoke-virtual {p2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    if-eqz v3, :cond_2

    .line 55
    .line 56
    move v2, v1

    .line 57
    goto :goto_2

    .line 58
    :cond_2
    add-int/lit8 v1, v1, 0x1

    .line 59
    .line 60
    goto :goto_1

    .line 61
    :cond_3
    :goto_2
    iget-object p2, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->d:Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView;

    .line 62
    .line 63
    invoke-virtual {p2, v2}, Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView;->setSelection(I)V

    .line 64
    .line 65
    .line 66
    iget-object p2, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->d:Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView;

    .line 67
    .line 68
    invoke-virtual {p2}, Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView;->f()V

    .line 69
    .line 70
    .line 71
    iget-object p2, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->d:Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView;

    .line 72
    .line 73
    invoke-virtual {p2}, Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView;->getSelectionItem()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p2

    .line 77
    check-cast p2, Ljava/lang/String;

    .line 78
    .line 79
    iput-object p2, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->t:Ljava/lang/String;

    .line 80
    .line 81
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->e()V

    .line 82
    .line 83
    .line 84
    iput p1, p0, LUa/b0;->a:I

    .line 85
    .line 86
    return-void
.end method
