.class public final LUa/s0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/bean/CommonResult;

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

.field public final synthetic c:LUa/A0;

.field public final synthetic d:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;LUa/A0;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/s0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    iput-object p3, p0, LUa/s0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 4
    .line 5
    iput-object p4, p0, LUa/s0;->c:LUa/A0;

    .line 6
    .line 7
    iput-object p5, p0, LUa/s0;->d:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 6

    .line 1
    new-instance v0, LUa/s0;

    .line 2
    .line 3
    iget-object v4, p0, LUa/s0;->c:LUa/A0;

    .line 4
    .line 5
    iget-object v5, p0, LUa/s0;->d:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 6
    .line 7
    iget-object v1, p0, LUa/s0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 8
    .line 9
    iget-object v3, p0, LUa/s0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 10
    .line 11
    move-object v2, p2

    .line 12
    invoke-direct/range {v0 .. v5}, LUa/s0;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;LUa/A0;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/s0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/s0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/s0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    sget-object v1, LEf/a;->a:LEf/a;

    .line 3
    .line 4
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    iget-object p1, p0, LUa/s0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 8
    .line 9
    iget-object p1, p1, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->p:Lcom/transsnet/palmpay/core/viewmodel/OnClaimRewardListener;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    invoke-interface {p1, v1}, Lcom/transsnet/palmpay/core/viewmodel/OnClaimRewardListener;->onShowLoading(Z)V

    .line 15
    .line 16
    .line 17
    :cond_0
    iget-object p1, p0, LUa/s0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 18
    .line 19
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_3

    .line 24
    .line 25
    const-string p1, "Claim Successfully"

    .line 26
    .line 27
    new-array v2, v1, [Ljava/lang/Object;

    .line 28
    .line 29
    invoke-static {p1, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iget-object p1, p0, LUa/s0;->c:LUa/A0;

    .line 33
    .line 34
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    check-cast v2, Ljava/lang/Iterable;

    .line 39
    .line 40
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    if-eqz v3, :cond_4

    .line 49
    .line 50
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    add-int/lit8 v4, v1, 0x1

    .line 55
    .line 56
    if-ltz v1, :cond_2

    .line 57
    .line 58
    check-cast v3, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 59
    .line 60
    iget-object v5, v3, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->recordNo:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v6, p0, LUa/s0;->d:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 63
    .line 64
    iget-object v6, v6, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->recordNo:Ljava/lang/String;

    .line 65
    .line 66
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v5

    .line 70
    if-eqz v5, :cond_1

    .line 71
    .line 72
    new-instance v2, Ljava/lang/Integer;

    .line 73
    .line 74
    invoke-direct {v2, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 75
    .line 76
    .line 77
    iput-object v2, v3, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardStatus:Ljava/lang/Integer;

    .line 78
    .line 79
    invoke-virtual {p1, v1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemChanged(I)V

    .line 80
    .line 81
    .line 82
    goto :goto_1

    .line 83
    :cond_1
    move v1, v4

    .line 84
    goto :goto_0

    .line 85
    :cond_2
    invoke-static {}, Lkotlin/collections/q;->k()V

    .line 86
    .line 87
    .line 88
    const/4 p1, 0x0

    .line 89
    throw p1

    .line 90
    :cond_3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    new-array v0, v1, [Ljava/lang/Object;

    .line 95
    .line 96
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    :cond_4
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 100
    .line 101
    return-object p1
.end method
