.class public final synthetic LUa/N;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;I)V
    .locals 0

    .line 1
    iput p2, p0, LUa/N;->a:I

    iput-object p1, p0, LUa/N;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LUa/N;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;

    .line 2
    .line 3
    iget v1, p0, LUa/N;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;->f:I

    .line 9
    .line 10
    new-instance v1, Lda/J;

    .line 11
    .line 12
    iget v0, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;->d:I

    .line 13
    .line 14
    invoke-direct {v1, v0}, Lda/J;-><init>(I)V

    .line 15
    .line 16
    .line 17
    return-object v1

    .line 18
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;->f:I

    .line 19
    .line 20
    sget v1, Lba/e;->rv_coupons:I

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 27
    .line 28
    return-object v0

    .line 29
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;->f:I

    .line 30
    .line 31
    sget v1, Lba/e;->view_loading_indicator:I

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Lcom/wang/avi/AVLoadingIndicatorView;

    .line 38
    .line 39
    return-object v0

    .line 40
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;->f:I

    .line 41
    .line 42
    sget v1, Lba/e;->tv_arrow_right:I

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    check-cast v0, Landroid/widget/TextView;

    .line 49
    .line 50
    return-object v0

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
