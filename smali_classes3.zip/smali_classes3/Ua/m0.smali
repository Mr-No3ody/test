.class public final synthetic LUa/m0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/util/ArrayList;

.field public final synthetic c:Landroid/view/KeyEvent$Callback;


# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;Ljava/util/ArrayList;I)V
    .locals 0

    .line 1
    iput p3, p0, LUa/m0;->a:I

    iput-object p1, p0, LUa/m0;->c:Landroid/view/KeyEvent$Callback;

    iput-object p2, p0, LUa/m0;->b:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x3

    .line 3
    const/4 v2, 0x4

    .line 4
    const/16 v3, 0x7d0

    .line 5
    .line 6
    const/4 v4, 0x0

    .line 7
    iget-object v5, p0, LUa/m0;->b:Ljava/util/ArrayList;

    .line 8
    .line 9
    iget-object v6, p0, LUa/m0;->c:Landroid/view/KeyEvent$Callback;

    .line 10
    .line 11
    iget v7, p0, LUa/m0;->a:I

    .line 12
    .line 13
    packed-switch v7, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    if-eqz p1, :cond_0

    .line 17
    .line 18
    sget v0, Lcom/transsnet/palmpay/core/ui/activity/CoreUssdListActivity;->d:I

    .line 19
    .line 20
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 21
    .line 22
    .line 23
    :cond_0
    check-cast v6, Lcom/transsnet/palmpay/core/ui/activity/CoreUssdListActivity;

    .line 24
    .line 25
    iget-object p1, v6, Lcom/transsnet/palmpay/core/ui/activity/CoreUssdListActivity;->b:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v5, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p2

    .line 31
    check-cast p2, Ljava/lang/Number;

    .line 32
    .line 33
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    if-eqz p1, :cond_1

    .line 38
    .line 39
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 40
    .line 41
    .line 42
    :cond_1
    const/4 p1, 0x1

    .line 43
    invoke-virtual {v6, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 44
    .line 45
    .line 46
    iget-object p1, v6, Lcom/transsnet/palmpay/core/ui/activity/CoreUssdListActivity;->b:Ljava/lang/String;

    .line 47
    .line 48
    const/16 v0, 0x2e4

    .line 49
    .line 50
    invoke-static {v6, p2, p1, v0, v6}, LPa/r0;->j(Landroidx/fragment/app/E;ILjava/lang/String;ILcom/transsnet/palmpay/core/util/UssdUtils$UssdResponseCallback;)Z

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :pswitch_0
    check-cast v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;

    .line 55
    .line 56
    if-eqz p1, :cond_2

    .line 57
    .line 58
    sget v7, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->B:I

    .line 59
    .line 60
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 64
    .line 65
    .line 66
    :cond_2
    iget-object p1, v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->i:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 67
    .line 68
    if-eqz p1, :cond_7

    .line 69
    .line 70
    invoke-virtual {v5, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    check-cast p1, Ljava/lang/Integer;

    .line 75
    .line 76
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 77
    .line 78
    .line 79
    move-result p1

    .line 80
    if-lt p1, v3, :cond_4

    .line 81
    .line 82
    invoke-virtual {v6, v2}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->e(I)Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;

    .line 83
    .line 84
    .line 85
    move-result-object p2

    .line 86
    iget-object v0, v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->i:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 87
    .line 88
    sub-int/2addr p1, v3

    .line 89
    if-eqz p2, :cond_3

    .line 90
    .line 91
    iget-object v4, p2, Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;->sender:Ljava/lang/String;

    .line 92
    .line 93
    :cond_3
    invoke-interface {v0, v2, p1, v4}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 94
    .line 95
    .line 96
    goto :goto_0

    .line 97
    :cond_4
    if-ne p1, v1, :cond_6

    .line 98
    .line 99
    invoke-virtual {v6, v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->e(I)Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;

    .line 100
    .line 101
    .line 102
    move-result-object p2

    .line 103
    iget-object v0, v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->i:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 104
    .line 105
    sub-int/2addr p1, v3

    .line 106
    if-eqz p2, :cond_5

    .line 107
    .line 108
    iget-object v4, p2, Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;->sender:Ljava/lang/String;

    .line 109
    .line 110
    :cond_5
    invoke-interface {v0, v1, p1, v4}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 111
    .line 112
    .line 113
    goto :goto_0

    .line 114
    :cond_6
    invoke-virtual {v6}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->h()V

    .line 115
    .line 116
    .line 117
    iget-object p2, v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->i:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 118
    .line 119
    invoke-interface {p2, p1, v0, v4}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 120
    .line 121
    .line 122
    :cond_7
    :goto_0
    return-void

    .line 123
    :pswitch_1
    check-cast v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;

    .line 124
    .line 125
    if-eqz p1, :cond_8

    .line 126
    .line 127
    sget v7, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->B:I

    .line 128
    .line 129
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 130
    .line 131
    .line 132
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 133
    .line 134
    .line 135
    :cond_8
    iget-object p1, v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->j:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 136
    .line 137
    if-eqz p1, :cond_d

    .line 138
    .line 139
    invoke-virtual {v5, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    check-cast p1, Ljava/lang/Integer;

    .line 144
    .line 145
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 146
    .line 147
    .line 148
    move-result p1

    .line 149
    if-lt p1, v3, :cond_a

    .line 150
    .line 151
    invoke-virtual {v6, v2}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->b(I)Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;

    .line 152
    .line 153
    .line 154
    move-result-object p2

    .line 155
    iget-object v0, v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->j:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 156
    .line 157
    sub-int/2addr p1, v3

    .line 158
    if-eqz p2, :cond_9

    .line 159
    .line 160
    iget-object v4, p2, Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;->sender:Ljava/lang/String;

    .line 161
    .line 162
    :cond_9
    invoke-interface {v0, v2, p1, v4}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 163
    .line 164
    .line 165
    goto :goto_1

    .line 166
    :cond_a
    if-ne p1, v1, :cond_c

    .line 167
    .line 168
    invoke-virtual {v6, v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->b(I)Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;

    .line 169
    .line 170
    .line 171
    move-result-object p2

    .line 172
    iget-object v0, v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->j:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 173
    .line 174
    sub-int/2addr p1, v3

    .line 175
    if-eqz p2, :cond_b

    .line 176
    .line 177
    iget-object v4, p2, Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;->sender:Ljava/lang/String;

    .line 178
    .line 179
    :cond_b
    invoke-interface {v0, v1, p1, v4}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 180
    .line 181
    .line 182
    goto :goto_1

    .line 183
    :cond_c
    invoke-virtual {v6}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->e()V

    .line 184
    .line 185
    .line 186
    iget-object p2, v6, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->j:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 187
    .line 188
    invoke-interface {p2, p1, v0, v4}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 189
    .line 190
    .line 191
    :cond_d
    :goto_1
    return-void

    .line 192
    nop

    .line 193
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
