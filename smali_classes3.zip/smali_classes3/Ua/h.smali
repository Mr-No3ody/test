.class public final synthetic LUa/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;I)V
    .locals 0

    .line 1
    iput p2, p0, LUa/h;->a:I

    iput-object p1, p0, LUa/h;->b:Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LUa/h;->b:Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;

    .line 2
    .line 3
    iget v1, p0, LUa/h;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 9
    .line 10
    sget v1, Lba/e;->modelPaymentDivider:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0

    .line 17
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 18
    .line 19
    sget v1, Lba/e;->tv_cashier_item_top_up:I

    .line 20
    .line 21
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/widget/TextView;

    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 29
    .line 30
    sget v1, Lba/e;->iv_cashier_item_selected:I

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroid/widget/ImageView;

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 40
    .line 41
    sget v1, Lba/e;->mbci_root:I

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    return-object v0

    .line 48
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 49
    .line 50
    sget v1, Lba/e;->tv_item_payment_method_activity_tips:I

    .line 51
    .line 52
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    check-cast v0, Landroid/widget/TextView;

    .line 57
    .line 58
    return-object v0

    .line 59
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 60
    .line 61
    sget v1, Lba/e;->tv_item_payment_method_normal_tips:I

    .line 62
    .line 63
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v0, Landroid/widget/TextView;

    .line 68
    .line 69
    return-object v0

    .line 70
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 71
    .line 72
    sget v1, Lba/e;->tv_cashier_item_payment_balance:I

    .line 73
    .line 74
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    check-cast v0, Landroid/widget/TextView;

    .line 79
    .line 80
    return-object v0

    .line 81
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 82
    .line 83
    sget v1, Lba/e;->tv_cashier_item_payment_method_name:I

    .line 84
    .line 85
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    check-cast v0, Landroid/widget/TextView;

    .line 90
    .line 91
    return-object v0

    .line 92
    :pswitch_7
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/CashierPayMethodItem;->t:I

    .line 93
    .line 94
    sget v1, Lba/e;->iv_cashier_item_payment_method_icon:I

    .line 95
    .line 96
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    check-cast v0, Landroid/widget/ImageView;

    .line 101
    .line 102
    return-object v0

    .line 103
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
