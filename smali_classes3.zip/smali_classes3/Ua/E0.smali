.class public final LUa/E0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lxf/t;

.field public final b:Lxf/t;

.field public final c:Lxf/t;

.field public final d:Lxf/t;

.field public final e:Lxf/t;

.field public final f:Lxf/t;

.field public final g:Lxf/t;

.field public final h:Lxf/t;

.field public final i:Lxf/t;

.field public final j:Lxf/t;

.field public final k:Ljava/lang/String;

.field public final l:Ljava/lang/String;

.field public final m:Ljava/lang/String;

.field public n:Ljava/lang/String;

.field public o:Ljava/lang/String;

.field public p:Ljava/lang/String;

.field public q:LX6/r;

.field public final r:Ljava/util/List;

.field public final s:Landroid/content/Context;

.field public final t:Landroid/view/View;

.field public u:Lcom/transsnet/palmpay/core/viewmodel/TimeRemindViewHandler$CallBack1;

.field public v:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LUa/D0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LUa/D0;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/view/View;Z)V
    .locals 9

    .line 1
    const-string v0, "view"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    new-instance v0, LUa/C0;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-direct {v0, p0, v1}, LUa/C0;-><init>(LUa/E0;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, LUa/E0;->a:Lxf/t;

    .line 20
    .line 21
    new-instance v0, LUa/C0;

    .line 22
    .line 23
    const/4 v1, 0x2

    .line 24
    invoke-direct {v0, p0, v1}, LUa/C0;-><init>(LUa/E0;I)V

    .line 25
    .line 26
    .line 27
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iput-object v0, p0, LUa/E0;->b:Lxf/t;

    .line 32
    .line 33
    new-instance v0, LUa/C0;

    .line 34
    .line 35
    const/4 v1, 0x3

    .line 36
    invoke-direct {v0, p0, v1}, LUa/C0;-><init>(LUa/E0;I)V

    .line 37
    .line 38
    .line 39
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    iput-object v0, p0, LUa/E0;->c:Lxf/t;

    .line 44
    .line 45
    new-instance v1, LUa/C0;

    .line 46
    .line 47
    const/4 v2, 0x4

    .line 48
    invoke-direct {v1, p0, v2}, LUa/C0;-><init>(LUa/E0;I)V

    .line 49
    .line 50
    .line 51
    invoke-static {v1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    iput-object v1, p0, LUa/E0;->d:Lxf/t;

    .line 56
    .line 57
    new-instance v2, LUa/C0;

    .line 58
    .line 59
    const/4 v3, 0x5

    .line 60
    invoke-direct {v2, p0, v3}, LUa/C0;-><init>(LUa/E0;I)V

    .line 61
    .line 62
    .line 63
    invoke-static {v2}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    iput-object v2, p0, LUa/E0;->e:Lxf/t;

    .line 68
    .line 69
    new-instance v2, LUa/C0;

    .line 70
    .line 71
    const/4 v3, 0x6

    .line 72
    invoke-direct {v2, p0, v3}, LUa/C0;-><init>(LUa/E0;I)V

    .line 73
    .line 74
    .line 75
    invoke-static {v2}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    iput-object v2, p0, LUa/E0;->f:Lxf/t;

    .line 80
    .line 81
    new-instance v3, LUa/C0;

    .line 82
    .line 83
    const/4 v4, 0x7

    .line 84
    invoke-direct {v3, p0, v4}, LUa/C0;-><init>(LUa/E0;I)V

    .line 85
    .line 86
    .line 87
    invoke-static {v3}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    iput-object v3, p0, LUa/E0;->g:Lxf/t;

    .line 92
    .line 93
    new-instance v3, LUa/C0;

    .line 94
    .line 95
    const/16 v4, 0x8

    .line 96
    .line 97
    invoke-direct {v3, p0, v4}, LUa/C0;-><init>(LUa/E0;I)V

    .line 98
    .line 99
    .line 100
    invoke-static {v3}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 101
    .line 102
    .line 103
    move-result-object v3

    .line 104
    iput-object v3, p0, LUa/E0;->h:Lxf/t;

    .line 105
    .line 106
    new-instance v4, LUa/C0;

    .line 107
    .line 108
    const/16 v5, 0x9

    .line 109
    .line 110
    invoke-direct {v4, p0, v5}, LUa/C0;-><init>(LUa/E0;I)V

    .line 111
    .line 112
    .line 113
    invoke-static {v4}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 114
    .line 115
    .line 116
    move-result-object v4

    .line 117
    iput-object v4, p0, LUa/E0;->i:Lxf/t;

    .line 118
    .line 119
    new-instance v4, LUa/C0;

    .line 120
    .line 121
    const/4 v5, 0x1

    .line 122
    invoke-direct {v4, p0, v5}, LUa/C0;-><init>(LUa/E0;I)V

    .line 123
    .line 124
    .line 125
    invoke-static {v4}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 126
    .line 127
    .line 128
    move-result-object v4

    .line 129
    iput-object v4, p0, LUa/E0;->j:Lxf/t;

    .line 130
    .line 131
    const-string v5, "week"

    .line 132
    .line 133
    iput-object v5, p0, LUa/E0;->k:Ljava/lang/String;

    .line 134
    .line 135
    const-string v6, "day"

    .line 136
    .line 137
    iput-object v6, p0, LUa/E0;->l:Ljava/lang/String;

    .line 138
    .line 139
    const-string v7, "month"

    .line 140
    .line 141
    iput-object v7, p0, LUa/E0;->m:Ljava/lang/String;

    .line 142
    .line 143
    const-string v8, ""

    .line 144
    .line 145
    iput-object v8, p0, LUa/E0;->n:Ljava/lang/String;

    .line 146
    .line 147
    iput-object v5, p0, LUa/E0;->o:Ljava/lang/String;

    .line 148
    .line 149
    iput-object v8, p0, LUa/E0;->p:Ljava/lang/String;

    .line 150
    .line 151
    if-eqz p2, :cond_0

    .line 152
    .line 153
    filled-new-array {v6, v5, v7}, [Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object p2

    .line 157
    invoke-static {p2}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 158
    .line 159
    .line 160
    move-result-object p2

    .line 161
    goto :goto_0

    .line 162
    :cond_0
    filled-new-array {v5, v7}, [Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object p2

    .line 166
    invoke-static {p2}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 167
    .line 168
    .line 169
    move-result-object p2

    .line 170
    :goto_0
    iput-object p2, p0, LUa/E0;->r:Ljava/util/List;

    .line 171
    .line 172
    iput-object p1, p0, LUa/E0;->t:Landroid/view/View;

    .line 173
    .line 174
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 175
    .line 176
    .line 177
    move-result-object p1

    .line 178
    iput-object p1, p0, LUa/E0;->s:Landroid/content/Context;

    .line 179
    .line 180
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    check-cast p1, Landroidx/appcompat/widget/SwitchCompat;

    .line 185
    .line 186
    if-eqz p1, :cond_1

    .line 187
    .line 188
    new-instance v5, LC9/l;

    .line 189
    .line 190
    const/4 v6, 0x1

    .line 191
    invoke-direct {v5, p0, v6}, LC9/l;-><init>(Ljava/lang/Object;I)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {p1, v5}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 195
    .line 196
    .line 197
    :cond_1
    new-instance p1, LR8/d;

    .line 198
    .line 199
    const/16 v5, 0x18

    .line 200
    .line 201
    invoke-direct {p1, p0, v5}, LR8/d;-><init>(Ljava/lang/Object;I)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v5

    .line 208
    check-cast v5, Landroid/widget/TextView;

    .line 209
    .line 210
    if-eqz v5, :cond_2

    .line 211
    .line 212
    invoke-virtual {v5, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 213
    .line 214
    .line 215
    :cond_2
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v5

    .line 219
    check-cast v5, Landroid/widget/TextView;

    .line 220
    .line 221
    if-eqz v5, :cond_3

    .line 222
    .line 223
    invoke-virtual {v5, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 224
    .line 225
    .line 226
    :cond_3
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v3

    .line 230
    check-cast v3, Landroid/widget/ImageView;

    .line 231
    .line 232
    if-eqz v3, :cond_4

    .line 233
    .line 234
    invoke-virtual {v3, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 235
    .line 236
    .line 237
    :cond_4
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    move-result-object v2

    .line 241
    check-cast v2, Landroid/widget/ImageView;

    .line 242
    .line 243
    if-eqz v2, :cond_5

    .line 244
    .line 245
    invoke-virtual {v2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 246
    .line 247
    .line 248
    :cond_5
    new-instance p1, LR3/e;

    .line 249
    .line 250
    const/4 v2, 0x6

    .line 251
    invoke-direct {p1, p0, v2}, LR3/e;-><init>(Ljava/lang/Object;I)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    check-cast v1, Landroid/widget/TextView;

    .line 259
    .line 260
    if-eqz v1, :cond_6

    .line 261
    .line 262
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 263
    .line 264
    .line 265
    :cond_6
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object v0

    .line 269
    check-cast v0, Landroid/widget/TextView;

    .line 270
    .line 271
    if-eqz v0, :cond_7

    .line 272
    .line 273
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 274
    .line 275
    .line 276
    :cond_7
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 277
    .line 278
    .line 279
    move-result-object p1

    .line 280
    check-cast p1, Landroidx/appcompat/widget/SwitchCompat;

    .line 281
    .line 282
    if-eqz p1, :cond_8

    .line 283
    .line 284
    const/4 v0, 0x1

    .line 285
    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/SwitchCompat;->setChecked(Z)V

    .line 286
    .line 287
    .line 288
    :cond_8
    invoke-static {p2}, Lkotlin/collections/CollectionsKt;->F(Ljava/util/List;)Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object p1

    .line 292
    check-cast p1, Ljava/lang/String;

    .line 293
    .line 294
    invoke-virtual {p0, p1}, LUa/E0;->f(Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    iget-object p1, p0, LUa/E0;->o:Ljava/lang/String;

    .line 298
    .line 299
    invoke-virtual {p0, p1}, LUa/E0;->i(Ljava/lang/String;)Ljava/util/List;

    .line 300
    .line 301
    .line 302
    move-result-object p1

    .line 303
    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->F(Ljava/util/List;)Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object p1

    .line 307
    check-cast p1, Ljava/lang/String;

    .line 308
    .line 309
    invoke-virtual {p0, p1}, LUa/E0;->g(Ljava/lang/String;)V

    .line 310
    .line 311
    .line 312
    return-void
.end method


# virtual methods
.method public final a(Z)V
    .locals 3

    .line 1
    iget-object v0, p0, LUa/E0;->s:Landroid/content/Context;

    .line 2
    .line 3
    iget-object v1, p0, LUa/E0;->g:Lxf/t;

    .line 4
    .line 5
    iget-object v2, p0, LUa/E0;->h:Lxf/t;

    .line 6
    .line 7
    if-eqz p1, :cond_1

    .line 8
    .line 9
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    check-cast p1, Landroid/widget/ImageView;

    .line 14
    .line 15
    if-eqz p1, :cond_0

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    invoke-virtual {p1, v2}, Landroid/view/View;->setEnabled(Z)V

    .line 19
    .line 20
    .line 21
    :cond_0
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, Landroid/widget/TextView;

    .line 26
    .line 27
    if-eqz p1, :cond_3

    .line 28
    .line 29
    sget v1, LL6/b;->ppColorTextPrimary:I

    .line 30
    .line 31
    invoke-static {v1, v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_1
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    check-cast p1, Landroid/widget/ImageView;

    .line 44
    .line 45
    if-eqz p1, :cond_2

    .line 46
    .line 47
    const/4 v2, 0x0

    .line 48
    invoke-virtual {p1, v2}, Landroid/view/View;->setEnabled(Z)V

    .line 49
    .line 50
    .line 51
    :cond_2
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    check-cast p1, Landroid/widget/TextView;

    .line 56
    .line 57
    if-eqz p1, :cond_3

    .line 58
    .line 59
    sget v1, LL6/b;->ppColorTextDisable:I

    .line 60
    .line 61
    invoke-static {v1, v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 66
    .line 67
    .line 68
    :cond_3
    return-void
.end method

.method public final b(Z)V
    .locals 3

    .line 1
    iget-object v0, p0, LUa/E0;->s:Landroid/content/Context;

    .line 2
    .line 3
    iget-object v1, p0, LUa/E0;->e:Lxf/t;

    .line 4
    .line 5
    iget-object v2, p0, LUa/E0;->f:Lxf/t;

    .line 6
    .line 7
    if-eqz p1, :cond_1

    .line 8
    .line 9
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    check-cast p1, Landroid/widget/ImageView;

    .line 14
    .line 15
    if-eqz p1, :cond_0

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    invoke-virtual {p1, v2}, Landroid/view/View;->setEnabled(Z)V

    .line 19
    .line 20
    .line 21
    :cond_0
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, Landroid/widget/TextView;

    .line 26
    .line 27
    if-eqz p1, :cond_3

    .line 28
    .line 29
    sget v1, LL6/b;->ppColorTextPrimary:I

    .line 30
    .line 31
    invoke-static {v1, v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_1
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    check-cast p1, Landroid/widget/ImageView;

    .line 44
    .line 45
    if-eqz p1, :cond_2

    .line 46
    .line 47
    const/4 v2, 0x0

    .line 48
    invoke-virtual {p1, v2}, Landroid/view/View;->setEnabled(Z)V

    .line 49
    .line 50
    .line 51
    :cond_2
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    check-cast p1, Landroid/widget/TextView;

    .line 56
    .line 57
    if-eqz p1, :cond_3

    .line 58
    .line 59
    sget v1, LL6/b;->ppColorTextDisable:I

    .line 60
    .line 61
    invoke-static {v1, v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 66
    .line 67
    .line 68
    :cond_3
    return-void
.end method

.method public final c()Z
    .locals 3

    .line 1
    iget-object v0, p0, LUa/E0;->j:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroidx/appcompat/widget/SwitchCompat;

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    if-eqz v0, :cond_4

    .line 11
    .line 12
    invoke-virtual {v0}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-ne v0, v1, :cond_4

    .line 17
    .line 18
    iget-object v0, p0, LUa/E0;->d:Lxf/t;

    .line 19
    .line 20
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Landroid/widget/TextView;

    .line 25
    .line 26
    const/4 v2, 0x0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    move-object v0, v2

    .line 35
    :goto_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-nez v0, :cond_2

    .line 40
    .line 41
    iget-object v0, p0, LUa/E0;->c:Lxf/t;

    .line 42
    .line 43
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Landroid/widget/TextView;

    .line 48
    .line 49
    if-eqz v0, :cond_1

    .line 50
    .line 51
    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    :cond_1
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-nez v0, :cond_2

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    const/4 v1, 0x0

    .line 63
    :goto_1
    iget-object v0, p0, LUa/E0;->u:Lcom/transsnet/palmpay/core/viewmodel/TimeRemindViewHandler$CallBack1;

    .line 64
    .line 65
    if-eqz v0, :cond_3

    .line 66
    .line 67
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/viewmodel/TimeRemindViewHandler$CallBack1;->onInputChanged(Z)V

    .line 68
    .line 69
    .line 70
    :cond_3
    return v1

    .line 71
    :cond_4
    iget-object v0, p0, LUa/E0;->u:Lcom/transsnet/palmpay/core/viewmodel/TimeRemindViewHandler$CallBack1;

    .line 72
    .line 73
    if-eqz v0, :cond_5

    .line 74
    .line 75
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/viewmodel/TimeRemindViewHandler$CallBack1;->onInputChanged(Z)V

    .line 76
    .line 77
    .line 78
    :cond_5
    return v1
.end method

.method public final d()Z
    .locals 1

    .line 1
    iget-object v0, p0, LUa/E0;->j:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroidx/appcompat/widget/SwitchCompat;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    return v0

    .line 16
    :cond_0
    const/4 v0, 0x0

    .line 17
    return v0
.end method

.method public final e(I)V
    .locals 2

    .line 1
    iget-object v0, p0, LUa/E0;->f:Lxf/t;

    .line 2
    .line 3
    iget-object v1, p0, LUa/E0;->h:Lxf/t;

    .line 4
    .line 5
    if-nez p1, :cond_1

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    iput p1, p0, LUa/E0;->v:I

    .line 9
    .line 10
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Landroid/widget/ImageView;

    .line 15
    .line 16
    if-eqz p1, :cond_0

    .line 17
    .line 18
    sget v1, Lcom/transsnet/palmpay/custom_view/r;->cv_purple_checked:I

    .line 19
    .line 20
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 21
    .line 22
    .line 23
    :cond_0
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Landroid/widget/ImageView;

    .line 28
    .line 29
    if-eqz p1, :cond_3

    .line 30
    .line 31
    sget v0, Lcom/transsnet/palmpay/custom_view/r;->cv_gray_unchecked:I

    .line 32
    .line 33
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    const/4 p1, 0x1

    .line 38
    iput p1, p0, LUa/E0;->v:I

    .line 39
    .line 40
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    check-cast p1, Landroid/widget/ImageView;

    .line 45
    .line 46
    if-eqz p1, :cond_2

    .line 47
    .line 48
    sget v1, Lcom/transsnet/palmpay/custom_view/r;->cv_gray_unchecked:I

    .line 49
    .line 50
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 51
    .line 52
    .line 53
    :cond_2
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    check-cast p1, Landroid/widget/ImageView;

    .line 58
    .line 59
    if-eqz p1, :cond_3

    .line 60
    .line 61
    sget v0, Lcom/transsnet/palmpay/custom_view/r;->cv_purple_checked:I

    .line 62
    .line 63
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 64
    .line 65
    .line 66
    :cond_3
    return-void
.end method

.method public final f(Ljava/lang/String;)V
    .locals 3

    .line 1
    const-string v0, "text"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LUa/E0;->k:Ljava/lang/String;

    .line 7
    .line 8
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    iget-object v2, p0, LUa/E0;->l:Ljava/lang/String;

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    const-string p1, "Every Week"

    .line 17
    .line 18
    iput-object p1, p0, LUa/E0;->n:Ljava/lang/String;

    .line 19
    .line 20
    iput-object v0, p0, LUa/E0;->o:Ljava/lang/String;

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-static {v2, p1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    if-eqz p1, :cond_1

    .line 28
    .line 29
    const-string p1, "Every Day"

    .line 30
    .line 31
    iput-object p1, p0, LUa/E0;->n:Ljava/lang/String;

    .line 32
    .line 33
    iput-object v2, p0, LUa/E0;->o:Ljava/lang/String;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    const-string p1, "Every Month"

    .line 37
    .line 38
    iput-object p1, p0, LUa/E0;->n:Ljava/lang/String;

    .line 39
    .line 40
    iget-object p1, p0, LUa/E0;->m:Ljava/lang/String;

    .line 41
    .line 42
    iput-object p1, p0, LUa/E0;->o:Ljava/lang/String;

    .line 43
    .line 44
    :goto_0
    iget-object p1, p0, LUa/E0;->a:Lxf/t;

    .line 45
    .line 46
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, Landroid/widget/TextView;

    .line 51
    .line 52
    if-eqz p1, :cond_3

    .line 53
    .line 54
    iget-object v0, p0, LUa/E0;->o:Ljava/lang/String;

    .line 55
    .line 56
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    if-eqz v0, :cond_2

    .line 61
    .line 62
    sget v0, Lba/k;->core_time:I

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_2
    sget v0, Lba/k;->core_day:I

    .line 66
    .line 67
    :goto_1
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(I)V

    .line 68
    .line 69
    .line 70
    :cond_3
    iget-object p1, p0, LUa/E0;->d:Lxf/t;

    .line 71
    .line 72
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    check-cast p1, Landroid/widget/TextView;

    .line 77
    .line 78
    if-eqz p1, :cond_4

    .line 79
    .line 80
    iget-object v0, p0, LUa/E0;->n:Ljava/lang/String;

    .line 81
    .line 82
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 83
    .line 84
    .line 85
    :cond_4
    return-void
.end method

.method public final g(Ljava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "text"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, LUa/E0;->p:Ljava/lang/String;

    .line 7
    .line 8
    iget-object p1, p0, LUa/E0;->c:Lxf/t;

    .line 9
    .line 10
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Landroid/widget/TextView;

    .line 15
    .line 16
    if-eqz p1, :cond_0

    .line 17
    .line 18
    iget-object v0, p0, LUa/E0;->p:Ljava/lang/String;

    .line 19
    .line 20
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final h(ILjava/util/List;ILkotlin/jvm/functions/Function1;)V
    .locals 4

    .line 1
    iget-object v0, p0, LUa/E0;->q:LX6/r;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x1

    .line 10
    if-ne v0, v1, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    iget-object v0, p0, LUa/E0;->s:Landroid/content/Context;

    .line 14
    .line 15
    if-nez v0, :cond_1

    .line 16
    .line 17
    :goto_0
    return-void

    .line 18
    :cond_1
    new-instance v1, LX6/r;

    .line 19
    .line 20
    new-instance v2, LAd/e;

    .line 21
    .line 22
    const/16 v3, 0x10

    .line 23
    .line 24
    invoke-direct {v2, v3, p2, p4}, LAd/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    const-string p4, "context"

    .line 28
    .line 29
    invoke-static {v0, p4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-static {v0, p4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    const/4 p4, 0x0

    .line 36
    invoke-direct {v1, v0, p4}, LV6/a;-><init>(Landroid/content/Context;I)V

    .line 37
    .line 38
    .line 39
    iput-object v2, v1, LX6/r;->d:LAd/e;

    .line 40
    .line 41
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    iput-object p1, v1, LX6/b;->c:Ljava/lang/String;

    .line 46
    .line 47
    invoke-static {p2}, Lkotlin/collections/q;->g(Ljava/util/List;)I

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    const/4 p4, 0x0

    .line 52
    invoke-static {p3, p4, p1}, Lkotlin/ranges/b;->c(III)I

    .line 53
    .line 54
    .line 55
    move-result p1

    .line 56
    iput p1, v1, LX6/r;->f:I

    .line 57
    .line 58
    check-cast p2, Ljava/lang/Iterable;

    .line 59
    .line 60
    new-instance p1, Ljava/util/ArrayList;

    .line 61
    .line 62
    const/16 p3, 0xa

    .line 63
    .line 64
    invoke-static {p2, p3}, Lkotlin/collections/r;->l(Ljava/lang/Iterable;I)I

    .line 65
    .line 66
    .line 67
    move-result p3

    .line 68
    invoke-direct {p1, p3}, Ljava/util/ArrayList;-><init>(I)V

    .line 69
    .line 70
    .line 71
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 72
    .line 73
    .line 74
    move-result-object p2

    .line 75
    :goto_1
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 76
    .line 77
    .line 78
    move-result p3

    .line 79
    if-eqz p3, :cond_3

    .line 80
    .line 81
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object p3

    .line 85
    add-int/lit8 v0, p4, 0x1

    .line 86
    .line 87
    if-ltz p4, :cond_2

    .line 88
    .line 89
    check-cast p3, Ljava/lang/String;

    .line 90
    .line 91
    new-instance v2, LY6/a;

    .line 92
    .line 93
    invoke-static {p4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object p4

    .line 97
    invoke-direct {v2, p3, p4}, LY6/a;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move p4, v0

    .line 104
    goto :goto_1

    .line 105
    :cond_2
    invoke-static {}, Lkotlin/collections/q;->k()V

    .line 106
    .line 107
    .line 108
    const/4 p1, 0x0

    .line 109
    throw p1

    .line 110
    :cond_3
    iput-object p1, v1, LX6/r;->g:Ljava/util/ArrayList;

    .line 111
    .line 112
    new-instance p1, LCe/p0;

    .line 113
    .line 114
    const/4 p2, 0x5

    .line 115
    invoke-direct {p1, p2, p0, v1}, LCe/p0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v1, p1}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 119
    .line 120
    .line 121
    iput-object v1, p0, LUa/E0;->q:LX6/r;

    .line 122
    .line 123
    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    .line 124
    .line 125
    .line 126
    return-void
.end method

.method public final i(Ljava/lang/String;)Ljava/util/List;
    .locals 2

    .line 1
    iget-object v0, p0, LUa/E0;->k:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    sget-object p1, Lma/m;->a:[Ljava/lang/String;

    .line 10
    .line 11
    sget-object p1, Lma/m;->a:[Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {p1}, Lkotlin/collections/n;->y([Ljava/lang/Object;)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1

    .line 18
    :cond_0
    iget-object v0, p0, LUa/E0;->l:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    if-eqz p1, :cond_1

    .line 25
    .line 26
    sget-object p1, Lma/m;->a:[Ljava/lang/String;

    .line 27
    .line 28
    sget-object p1, Lma/m;->b:[Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {p1}, Lkotlin/collections/n;->y([Ljava/lang/Object;)Ljava/util/List;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    return-object p1

    .line 35
    :cond_1
    new-instance p1, Lkotlin/ranges/IntRange;

    .line 36
    .line 37
    const/4 v0, 0x1

    .line 38
    const/16 v1, 0x1f

    .line 39
    .line 40
    invoke-direct {p1, v0, v1, v0}, Lkotlin/ranges/a;-><init>(III)V

    .line 41
    .line 42
    .line 43
    new-instance v0, Ljava/util/ArrayList;

    .line 44
    .line 45
    const/16 v1, 0xa

    .line 46
    .line 47
    invoke-static {p1, v1}, Lkotlin/collections/r;->l(Ljava/lang/Iterable;I)I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 52
    .line 53
    .line 54
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-eqz v1, :cond_2

    .line 63
    .line 64
    move-object v1, p1

    .line 65
    check-cast v1, Lkotlin/collections/C;

    .line 66
    .line 67
    invoke-virtual {v1}, Lkotlin/collections/C;->a()I

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_2
    return-object v0
.end method
