.class public final synthetic LUa/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;I)V
    .locals 0

    .line 1
    iput p2, p0, LUa/P;->a:I

    iput-object p1, p0, LUa/P;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LUa/P;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;

    .line 2
    .line 3
    iget v1, p0, LUa/P;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->j:I

    .line 9
    .line 10
    sget v1, Lba/e;->tv_sale_time_title:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/TextView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->j:I

    .line 20
    .line 21
    sget v1, Lba/e;->ivInfo:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->j:I

    .line 31
    .line 32
    sget v1, Lba/e;->rv_data_bundles:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
