.class public final LUa/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView$OnWheelItemSelectedListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LUa/a0;->a:Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onItemSelected(ILjava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Ljava/lang/String;

    .line 2
    .line 3
    iget-object p1, p0, LUa/a0;->a:Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;

    .line 4
    .line 5
    iput-object p2, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->p:Ljava/lang/String;

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/viewmodel/ModelMonthPick;->e()V

    .line 8
    .line 9
    .line 10
    return-void
.end method
