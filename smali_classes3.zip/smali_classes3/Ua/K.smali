.class public final LUa/K;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponListItemView;

.field public final synthetic g:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;Ljava/lang/String;Ljava/lang/String;Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponListItemView;Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p2, p0, LUa/K;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;

    .line 2
    .line 3
    iput-object p3, p0, LUa/K;->d:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, LUa/K;->e:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p5, p0, LUa/K;->f:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponListItemView;

    .line 8
    .line 9
    iput-object p6, p0, LUa/K;->g:Ljava/lang/String;

    .line 10
    .line 11
    const/4 p2, 0x2

    .line 12
    invoke-direct {p0, p2, p1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 7

    .line 1
    new-instance v0, LUa/K;

    .line 2
    .line 3
    iget-object v5, p0, LUa/K;->f:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponListItemView;

    .line 4
    .line 5
    iget-object v6, p0, LUa/K;->g:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v3, p0, LUa/K;->d:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v4, p0, LUa/K;->e:Ljava/lang/String;

    .line 10
    .line 11
    iget-object v2, p0, LUa/K;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;

    .line 12
    .line 13
    move-object v1, p2

    .line 14
    invoke-direct/range {v0 .. v6}, LUa/K;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;Ljava/lang/String;Ljava/lang/String;Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponListItemView;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iput-object p1, v0, LUa/K;->b:Ljava/lang/Object;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/K;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/K;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/K;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    sget-object v1, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v0, p0, LUa/K;->a:I

    .line 4
    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v4, 0x1

    .line 8
    if-eqz v0, :cond_3

    .line 9
    .line 10
    if-eq v0, v4, :cond_2

    .line 11
    .line 12
    if-eq v0, v3, :cond_1

    .line 13
    .line 14
    if-ne v0, v2, :cond_0

    .line 15
    .line 16
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    goto/16 :goto_6

    .line 20
    .line 21
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 22
    .line 23
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 24
    .line 25
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw p1

    .line 29
    :cond_1
    iget-object v0, p0, LUa/K;->b:Ljava/lang/Object;

    .line 30
    .line 31
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    goto :goto_4

    .line 35
    :cond_2
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :catchall_0
    move-exception v0

    .line 40
    move-object p1, v0

    .line 41
    goto :goto_2

    .line 42
    :cond_3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object p1, p0, LUa/K;->b:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 48
    .line 49
    :try_start_1
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 50
    .line 51
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 52
    .line 53
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 56
    .line 57
    new-instance v0, Lcom/transsnet/palmpay/core/bean/req/ClaimCouponReq;

    .line 58
    .line 59
    iget-object v5, p0, LUa/K;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;

    .line 60
    .line 61
    invoke-virtual {v5}, Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;->getTransType()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    const-string v6, ""

    .line 66
    .line 67
    iget-object v7, p0, LUa/K;->d:Ljava/lang/String;

    .line 68
    .line 69
    iget-object v8, p0, LUa/K;->e:Ljava/lang/String;

    .line 70
    .line 71
    invoke-direct {v0, v5, v6, v7, v8}, Lcom/transsnet/palmpay/core/bean/req/ClaimCouponReq;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    iput v4, p0, LUa/K;->a:I

    .line 75
    .line 76
    invoke-interface {p1, v0, p0}, Lcom/transsnet/palmpay/core/network/PayApiService;->claimCoupon(Lcom/transsnet/palmpay/core/bean/req/ClaimCouponReq;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    if-ne p1, v1, :cond_4

    .line 81
    .line 82
    goto :goto_5

    .line 83
    :cond_4
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 84
    .line 85
    sget-object v0, Lxf/q;->a:Lxf/o;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 86
    .line 87
    :goto_1
    move-object v0, p1

    .line 88
    goto :goto_3

    .line 89
    :goto_2
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 90
    .line 91
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    goto :goto_1

    .line 96
    :goto_3
    instance-of p1, v0, Lxf/p;

    .line 97
    .line 98
    if-nez p1, :cond_5

    .line 99
    .line 100
    move-object v5, v0

    .line 101
    check-cast v5, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 102
    .line 103
    sget-object p1, LWf/I;->a:Lcg/f;

    .line 104
    .line 105
    sget-object p1, Lag/o;->a:LWf/p0;

    .line 106
    .line 107
    new-instance v4, LUa/I;

    .line 108
    .line 109
    iget-object v8, p0, LUa/K;->g:Ljava/lang/String;

    .line 110
    .line 111
    iget-object v7, p0, LUa/K;->f:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponListItemView;

    .line 112
    .line 113
    const/4 v6, 0x0

    .line 114
    iget-object v9, p0, LUa/K;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;

    .line 115
    .line 116
    invoke-direct/range {v4 .. v9}, LUa/I;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponListItemView;Ljava/lang/String;Lcom/transsnet/palmpay/core/viewmodel/ModelClaimCouponItemView;)V

    .line 117
    .line 118
    .line 119
    iput-object v0, p0, LUa/K;->b:Ljava/lang/Object;

    .line 120
    .line 121
    iput v3, p0, LUa/K;->a:I

    .line 122
    .line 123
    invoke-static {p1, v4, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object p1

    .line 127
    if-ne p1, v1, :cond_5

    .line 128
    .line 129
    goto :goto_5

    .line 130
    :cond_5
    :goto_4
    invoke-static {v0}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    if-eqz p1, :cond_6

    .line 135
    .line 136
    sget-object v3, LWf/I;->a:Lcg/f;

    .line 137
    .line 138
    sget-object v3, Lag/o;->a:LWf/p0;

    .line 139
    .line 140
    new-instance v4, LUa/J;

    .line 141
    .line 142
    const/4 v5, 0x0

    .line 143
    invoke-direct {v4, v5, p1}, LUa/J;-><init>(Lkotlin/coroutines/Continuation;Ljava/lang/Throwable;)V

    .line 144
    .line 145
    .line 146
    iput-object v0, p0, LUa/K;->b:Ljava/lang/Object;

    .line 147
    .line 148
    iput v2, p0, LUa/K;->a:I

    .line 149
    .line 150
    invoke-static {v3, v4, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object p1

    .line 154
    if-ne p1, v1, :cond_6

    .line 155
    .line 156
    :goto_5
    return-object v1

    .line 157
    :cond_6
    :goto_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 158
    .line 159
    return-object p1
.end method
