.class public final synthetic LUa/B0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;I)V
    .locals 0

    .line 1
    iput p2, p0, LUa/B0;->a:I

    iput-object p1, p0, LUa/B0;->b:Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LUa/B0;->b:Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;

    .line 2
    .line 3
    iget v1, p0, LUa/B0;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;->g:I

    .line 9
    .line 10
    sget v1, Lba/e;->report_left_img:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/ImageView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;->g:I

    .line 20
    .line 21
    sget v1, Lba/e;->report_content_tv:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/TextView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;->g:I

    .line 31
    .line 32
    sget v1, Lba/e;->report_right_img:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/widget/ImageView;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
