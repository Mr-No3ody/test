.class public final LUa/o0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/bean/CommonResult;

.field public final synthetic b:Z

.field public final synthetic c:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;ZLcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/o0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    iput-boolean p3, p0, LUa/o0;->b:Z

    .line 4
    .line 5
    iput-object p4, p0, LUa/o0;->c:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance p1, LUa/o0;

    .line 2
    .line 3
    iget-object v0, p0, LUa/o0;->c:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 4
    .line 5
    iget-object v1, p0, LUa/o0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 6
    .line 7
    iget-boolean v2, p0, LUa/o0;->b:Z

    .line 8
    .line 9
    invoke-direct {p1, v1, p2, v2, v0}, LUa/o0;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;ZLcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/o0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/o0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/o0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LUa/o0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 7
    .line 8
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;

    .line 9
    .line 10
    iget-boolean v0, p0, LUa/o0;->b:Z

    .line 11
    .line 12
    iget-object v1, p0, LUa/o0;->c:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    sget v2, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->A:I

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->m(Z)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->o()V

    .line 23
    .line 24
    .line 25
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_1

    .line 30
    .line 31
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;->data:Ljava/util/List;

    .line 32
    .line 33
    iput-object p1, v1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->o:Ljava/util/List;

    .line 34
    .line 35
    :cond_1
    if-eqz v0, :cond_2

    .line 36
    .line 37
    sget p1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->A:I

    .line 38
    .line 39
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->n()V

    .line 40
    .line 41
    .line 42
    :cond_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 43
    .line 44
    return-object p1
.end method
