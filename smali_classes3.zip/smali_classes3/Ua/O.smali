.class public final LUa/O;
.super LM1/j;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Landroidx/lifecycle/LifecycleOwner;

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/lifecycle/LifecycleOwner;)V
    .locals 2

    .line 1
    const-string v0, "viewContext"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "life"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sget v0, Lba/g;->core_layout_flash_sale_data_bundle_item:I

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    invoke-direct {p0, v0, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, LUa/O;->a:Landroid/content/Context;

    .line 18
    .line 19
    iput-object p2, p0, LUa/O;->b:Landroidx/lifecycle/LifecycleOwner;

    .line 20
    .line 21
    sget p2, LL6/b;->ppColorPrimary:I

    .line 22
    .line 23
    invoke-virtual {p1, p2}, Landroid/content/Context;->getColor(I)I

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    iput p2, p0, LUa/O;->c:I

    .line 28
    .line 29
    sget p2, LL6/b;->ppColorTextPrimary:I

    .line 30
    .line 31
    invoke-virtual {p1, p2}, Landroid/content/Context;->getColor(I)I

    .line 32
    .line 33
    .line 34
    move-result p2

    .line 35
    iput p2, p0, LUa/O;->d:I

    .line 36
    .line 37
    sget p2, LL6/b;->ppColorTextNormal:I

    .line 38
    .line 39
    invoke-virtual {p1, p2}, Landroid/content/Context;->getColor(I)I

    .line 40
    .line 41
    .line 42
    move-result p2

    .line 43
    iput p2, p0, LUa/O;->e:I

    .line 44
    .line 45
    sget p2, LL6/b;->ppColorTextAssist:I

    .line 46
    .line 47
    invoke-virtual {p1, p2}, Landroid/content/Context;->getColor(I)I

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    iput p1, p0, LUa/O;->f:I

    .line 52
    .line 53
    return-void
.end method


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    check-cast v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;

    .line 8
    .line 9
    const-string v3, "holder"

    .line 10
    .line 11
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v3, "item"

    .line 15
    .line 16
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    sget v3, Lba/e;->tv_name:I

    .line 20
    .line 21
    invoke-virtual {v1, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getViewOrNull(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Landroid/widget/TextView;

    .line 26
    .line 27
    sget v4, Lba/e;->tv_content:I

    .line 28
    .line 29
    invoke-virtual {v1, v4}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getViewOrNull(I)Landroid/view/View;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    check-cast v4, Landroid/widget/TextView;

    .line 34
    .line 35
    sget v5, Lba/e;->tv_status:I

    .line 36
    .line 37
    invoke-virtual {v1, v5}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getViewOrNull(I)Landroid/view/View;

    .line 38
    .line 39
    .line 40
    move-result-object v5

    .line 41
    check-cast v5, Landroid/widget/TextView;

    .line 42
    .line 43
    sget v6, Lba/e;->divider:I

    .line 44
    .line 45
    invoke-virtual {v1, v6}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getViewOrNull(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v6

    .line 49
    sget v7, Lba/e;->tv_cashback:I

    .line 50
    .line 51
    invoke-virtual {v1, v7}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getViewOrNull(I)Landroid/view/View;

    .line 52
    .line 53
    .line 54
    move-result-object v7

    .line 55
    check-cast v7, Landroid/widget/TextView;

    .line 56
    .line 57
    sget v8, Lba/e;->lpi_progress_bar:I

    .line 58
    .line 59
    invoke-virtual {v1, v8}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getViewOrNull(I)Landroid/view/View;

    .line 60
    .line 61
    .line 62
    move-result-object v8

    .line 63
    check-cast v8, Landroidx/appcompat/widget/AppCompatSeekBar;

    .line 64
    .line 65
    sget v9, Lba/e;->iv_info:I

    .line 66
    .line 67
    invoke-virtual {v1, v9}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getViewOrNull(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v9

    .line 71
    check-cast v9, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 72
    .line 73
    const/4 v10, 0x0

    .line 74
    if-eqz v8, :cond_0

    .line 75
    .line 76
    invoke-virtual {v8, v10}, Landroid/view/View;->setEnabled(Z)V

    .line 77
    .line 78
    .line 79
    :cond_0
    iget-object v11, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->remainingStock:Ljava/lang/Integer;

    .line 80
    .line 81
    if-eqz v11, :cond_1

    .line 82
    .line 83
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 84
    .line 85
    .line 86
    move-result v11

    .line 87
    goto :goto_0

    .line 88
    :cond_1
    move v11, v10

    .line 89
    :goto_0
    iget-object v12, v1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 90
    .line 91
    invoke-virtual {v12, v10}, Landroid/view/View;->setEnabled(Z)V

    .line 92
    .line 93
    .line 94
    new-instance v12, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 95
    .line 96
    invoke-direct {v12}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 97
    .line 98
    .line 99
    iget-object v13, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->volume:Ljava/lang/String;

    .line 100
    .line 101
    const-string v14, ""

    .line 102
    .line 103
    if-nez v13, :cond_2

    .line 104
    .line 105
    move-object v13, v14

    .line 106
    :cond_2
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 107
    .line 108
    .line 109
    move-result-object v12

    .line 110
    const/16 v13, 0x10

    .line 111
    .line 112
    invoke-static {v13}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 113
    .line 114
    .line 115
    move-result v13

    .line 116
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 117
    .line 118
    .line 119
    move-result-object v12

    .line 120
    invoke-virtual {v12}, Lcom/transsnet/palmpay/util/SpanUtils;->setBold()Lcom/transsnet/palmpay/util/SpanUtils;

    .line 121
    .line 122
    .line 123
    move-result-object v12

    .line 124
    iget v13, v0, LUa/O;->d:I

    .line 125
    .line 126
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 127
    .line 128
    .line 129
    move-result-object v12

    .line 130
    iget-object v15, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->validity:Ljava/lang/String;

    .line 131
    .line 132
    if-nez v15, :cond_3

    .line 133
    .line 134
    goto :goto_1

    .line 135
    :cond_3
    move-object v14, v15

    .line 136
    :goto_1
    const-string v15, "/"

    .line 137
    .line 138
    invoke-virtual {v15, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v14

    .line 142
    invoke-virtual {v12, v14}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 143
    .line 144
    .line 145
    move-result-object v12

    .line 146
    const/16 v14, 0xc

    .line 147
    .line 148
    invoke-static {v14}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 149
    .line 150
    .line 151
    move-result v14

    .line 152
    invoke-virtual {v12, v14}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 153
    .line 154
    .line 155
    move-result-object v12

    .line 156
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 157
    .line 158
    .line 159
    move-result-object v12

    .line 160
    invoke-virtual {v12}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 161
    .line 162
    .line 163
    move-result-object v12

    .line 164
    if-eqz v3, :cond_4

    .line 165
    .line 166
    invoke-virtual {v3, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 167
    .line 168
    .line 169
    :cond_4
    new-instance v12, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 170
    .line 171
    invoke-direct {v12}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 172
    .line 173
    .line 174
    iget-object v13, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->discountPackageAmount:Ljava/lang/Long;

    .line 175
    .line 176
    if-eqz v13, :cond_5

    .line 177
    .line 178
    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    .line 179
    .line 180
    .line 181
    move-result-wide v16

    .line 182
    goto :goto_2

    .line 183
    :cond_5
    const-wide/16 v16, 0x0

    .line 184
    .line 185
    :goto_2
    invoke-static/range {v16 .. v17}, LPa/r0;->F(J)Ljava/lang/String;

    .line 186
    .line 187
    .line 188
    move-result-object v13

    .line 189
    const-wide/16 v16, 0x0

    .line 190
    .line 191
    new-instance v14, Ljava/lang/StringBuilder;

    .line 192
    .line 193
    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v14, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    const-string v13, " "

    .line 200
    .line 201
    invoke-virtual {v14, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object v13

    .line 208
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 209
    .line 210
    .line 211
    move-result-object v12

    .line 212
    iget v13, v0, LUa/O;->c:I

    .line 213
    .line 214
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 215
    .line 216
    .line 217
    move-result-object v12

    .line 218
    iget-object v13, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->price:Ljava/lang/Long;

    .line 219
    .line 220
    if-eqz v13, :cond_6

    .line 221
    .line 222
    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    .line 223
    .line 224
    .line 225
    move-result-wide v13

    .line 226
    goto :goto_3

    .line 227
    :cond_6
    move-wide/from16 v13, v16

    .line 228
    .line 229
    :goto_3
    invoke-static {v13, v14}, LPa/r0;->F(J)Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v13

    .line 233
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 234
    .line 235
    .line 236
    move-result-object v12

    .line 237
    iget v13, v0, LUa/O;->f:I

    .line 238
    .line 239
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 240
    .line 241
    .line 242
    move-result-object v12

    .line 243
    invoke-virtual {v12}, Lcom/transsnet/palmpay/util/SpanUtils;->setStrikethrough()Lcom/transsnet/palmpay/util/SpanUtils;

    .line 244
    .line 245
    .line 246
    move-result-object v12

    .line 247
    iget v13, v0, LUa/O;->e:I

    .line 248
    .line 249
    invoke-virtual {v12, v13}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 250
    .line 251
    .line 252
    move-result-object v12

    .line 253
    invoke-virtual {v12}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 254
    .line 255
    .line 256
    move-result-object v12

    .line 257
    if-eqz v4, :cond_7

    .line 258
    .line 259
    invoke-virtual {v4, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 260
    .line 261
    .line 262
    :cond_7
    iget-object v12, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->initialStock:Ljava/lang/Integer;

    .line 263
    .line 264
    const/4 v13, 0x1

    .line 265
    const/16 v14, 0x64

    .line 266
    .line 267
    if-nez v12, :cond_9

    .line 268
    .line 269
    if-eqz v8, :cond_8

    .line 270
    .line 271
    invoke-virtual {v8, v14}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 272
    .line 273
    .line 274
    :cond_8
    if-eqz v8, :cond_c

    .line 275
    .line 276
    invoke-static {v8, v10}, Loa/h;->s(Landroid/view/View;Z)V

    .line 277
    .line 278
    .line 279
    goto :goto_4

    .line 280
    :cond_9
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    .line 281
    .line 282
    .line 283
    move-result v12

    .line 284
    if-eqz v8, :cond_a

    .line 285
    .line 286
    invoke-virtual {v8, v14}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 287
    .line 288
    .line 289
    :cond_a
    sub-int v11, v12, v11

    .line 290
    .line 291
    int-to-float v11, v11

    .line 292
    int-to-float v12, v12

    .line 293
    div-float/2addr v11, v12

    .line 294
    int-to-float v12, v14

    .line 295
    mul-float/2addr v11, v12

    .line 296
    float-to-int v11, v11

    .line 297
    if-eqz v8, :cond_b

    .line 298
    .line 299
    invoke-virtual {v8, v11}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 300
    .line 301
    .line 302
    :cond_b
    if-eqz v8, :cond_c

    .line 303
    .line 304
    invoke-static {v8, v13}, Loa/h;->s(Landroid/view/View;Z)V

    .line 305
    .line 306
    .line 307
    :cond_c
    :goto_4
    iget-object v11, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->discountInfo:Ljava/lang/String;

    .line 308
    .line 309
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 310
    .line 311
    .line 312
    move-result v11

    .line 313
    if-nez v11, :cond_f

    .line 314
    .line 315
    if-eqz v7, :cond_d

    .line 316
    .line 317
    invoke-static {v7, v13}, Loa/h;->s(Landroid/view/View;Z)V

    .line 318
    .line 319
    .line 320
    :cond_d
    if-eqz v6, :cond_e

    .line 321
    .line 322
    invoke-static {v6, v13}, Loa/h;->s(Landroid/view/View;Z)V

    .line 323
    .line 324
    .line 325
    :cond_e
    if-eqz v7, :cond_11

    .line 326
    .line 327
    iget-object v6, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->discountInfo:Ljava/lang/String;

    .line 328
    .line 329
    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 330
    .line 331
    .line 332
    goto :goto_5

    .line 333
    :cond_f
    if-eqz v7, :cond_10

    .line 334
    .line 335
    invoke-static {v7, v10}, Loa/h;->s(Landroid/view/View;Z)V

    .line 336
    .line 337
    .line 338
    :cond_10
    if-eqz v6, :cond_11

    .line 339
    .line 340
    invoke-static {v6, v10}, Loa/h;->s(Landroid/view/View;Z)V

    .line 341
    .line 342
    .line 343
    :cond_11
    :goto_5
    sget v6, Lba/e;->iv_info:I

    .line 344
    .line 345
    iget-object v7, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->description:Ljava/lang/String;

    .line 346
    .line 347
    if-eqz v7, :cond_13

    .line 348
    .line 349
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 350
    .line 351
    .line 352
    move-result v7

    .line 353
    if-nez v7, :cond_12

    .line 354
    .line 355
    goto :goto_6

    .line 356
    :cond_12
    move v7, v10

    .line 357
    goto :goto_7

    .line 358
    :cond_13
    :goto_6
    move v7, v13

    .line 359
    :goto_7
    invoke-virtual {v1, v6, v7}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 360
    .line 361
    .line 362
    if-eqz v9, :cond_14

    .line 363
    .line 364
    new-instance v6, LOc/j;

    .line 365
    .line 366
    const/16 v7, 0xb

    .line 367
    .line 368
    invoke-direct {v6, v7, v2, v0}, LOc/j;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 369
    .line 370
    .line 371
    invoke-virtual {v9, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 372
    .line 373
    .line 374
    :cond_14
    iget-object v1, v1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 375
    .line 376
    const-string v6, "itemView"

    .line 377
    .line 378
    invoke-static {v1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 379
    .line 380
    .line 381
    iget-object v6, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->remainingStock:Ljava/lang/Integer;

    .line 382
    .line 383
    if-eqz v6, :cond_15

    .line 384
    .line 385
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 386
    .line 387
    .line 388
    move-result v6

    .line 389
    goto :goto_8

    .line 390
    :cond_15
    move v6, v10

    .line 391
    :goto_8
    iget-object v7, v2, Lcom/transsnet/palmpay/core/bean/FlashSaleItemBean;->endDownTime:Ljava/lang/Long;

    .line 392
    .line 393
    if-eqz v7, :cond_16

    .line 394
    .line 395
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    .line 396
    .line 397
    .line 398
    move-result-wide v11

    .line 399
    goto :goto_9

    .line 400
    :cond_16
    move-wide/from16 v11, v16

    .line 401
    .line 402
    :goto_9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 403
    .line 404
    .line 405
    move-result-wide v14

    .line 406
    sub-long/2addr v11, v14

    .line 407
    const/16 v7, 0x3e8

    .line 408
    .line 409
    int-to-long v14, v7

    .line 410
    div-long/2addr v11, v14

    .line 411
    iget-object v7, v2, Lcom/transsnet/palmpay/core/bean/FlashSaleItemBean;->startDownTime:Ljava/lang/Long;

    .line 412
    .line 413
    if-eqz v7, :cond_17

    .line 414
    .line 415
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    .line 416
    .line 417
    .line 418
    move-result-wide v18

    .line 419
    goto :goto_a

    .line 420
    :cond_17
    move-wide/from16 v18, v16

    .line 421
    .line 422
    :goto_a
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 423
    .line 424
    .line 425
    move-result-wide v20

    .line 426
    sub-long v18, v18, v20

    .line 427
    .line 428
    div-long v18, v18, v14

    .line 429
    .line 430
    const/4 v7, 0x3

    .line 431
    const/4 v14, 0x2

    .line 432
    if-gtz v6, :cond_18

    .line 433
    .line 434
    iget-object v6, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->initialStock:Ljava/lang/Integer;

    .line 435
    .line 436
    if-eqz v6, :cond_18

    .line 437
    .line 438
    move v10, v14

    .line 439
    goto :goto_b

    .line 440
    :cond_18
    cmp-long v6, v11, v16

    .line 441
    .line 442
    if-lez v6, :cond_19

    .line 443
    .line 444
    cmp-long v11, v18, v16

    .line 445
    .line 446
    if-lez v11, :cond_19

    .line 447
    .line 448
    goto :goto_b

    .line 449
    :cond_19
    if-lez v6, :cond_1a

    .line 450
    .line 451
    cmp-long v6, v18, v16

    .line 452
    .line 453
    if-gtz v6, :cond_1a

    .line 454
    .line 455
    move v10, v7

    .line 456
    goto :goto_b

    .line 457
    :cond_1a
    move v10, v13

    .line 458
    :goto_b
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 459
    .line 460
    .line 461
    move-result-object v6

    .line 462
    iput-object v6, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->status:Ljava/lang/Integer;

    .line 463
    .line 464
    iget-object v6, v0, LUa/O;->a:Landroid/content/Context;

    .line 465
    .line 466
    if-ne v10, v14, :cond_1d

    .line 467
    .line 468
    if-eqz v5, :cond_1b

    .line 469
    .line 470
    sget v7, Lba/k;->core_sold_out:I

    .line 471
    .line 472
    invoke-virtual {v6, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 473
    .line 474
    .line 475
    move-result-object v6

    .line 476
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 477
    .line 478
    .line 479
    :cond_1b
    if-eqz v5, :cond_1c

    .line 480
    .line 481
    sget v6, LL6/b;->lib_ui_button_white_text_color:I

    .line 482
    .line 483
    invoke-virtual {v0}, LM1/j;->getContext()Landroid/content/Context;

    .line 484
    .line 485
    .line 486
    move-result-object v7

    .line 487
    invoke-static {v6, v7}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 488
    .line 489
    .line 490
    move-result v6

    .line 491
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 492
    .line 493
    .line 494
    :cond_1c
    if-eqz v5, :cond_25

    .line 495
    .line 496
    sget v6, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_rect_corner_12_bg_color_disable:I

    .line 497
    .line 498
    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundResource(I)V

    .line 499
    .line 500
    .line 501
    goto :goto_e

    .line 502
    :cond_1d
    if-eqz v10, :cond_21

    .line 503
    .line 504
    if-ne v10, v7, :cond_1e

    .line 505
    .line 506
    goto :goto_c

    .line 507
    :cond_1e
    if-eqz v5, :cond_1f

    .line 508
    .line 509
    sget v7, Lba/k;->core_databundle_grab:I

    .line 510
    .line 511
    invoke-virtual {v6, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 512
    .line 513
    .line 514
    move-result-object v6

    .line 515
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 516
    .line 517
    .line 518
    :cond_1f
    if-eqz v5, :cond_20

    .line 519
    .line 520
    sget v6, LL6/b;->lib_ui_button_white_text_color:I

    .line 521
    .line 522
    invoke-virtual {v0}, LM1/j;->getContext()Landroid/content/Context;

    .line 523
    .line 524
    .line 525
    move-result-object v7

    .line 526
    invoke-static {v6, v7}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 527
    .line 528
    .line 529
    move-result v6

    .line 530
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 531
    .line 532
    .line 533
    :cond_20
    if-eqz v5, :cond_25

    .line 534
    .line 535
    sget v6, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_rect_corner_16_bg_primary:I

    .line 536
    .line 537
    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundResource(I)V

    .line 538
    .line 539
    .line 540
    goto :goto_e

    .line 541
    :cond_21
    :goto_c
    if-eqz v5, :cond_23

    .line 542
    .line 543
    iget-object v6, v2, Lcom/transsnet/palmpay/core/bean/FlashSaleItemBean;->startTime:Ljava/lang/Long;

    .line 544
    .line 545
    if-eqz v6, :cond_22

    .line 546
    .line 547
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 548
    .line 549
    .line 550
    move-result-wide v6

    .line 551
    goto :goto_d

    .line 552
    :cond_22
    move-wide/from16 v6, v16

    .line 553
    .line 554
    :goto_d
    new-instance v10, Ljava/text/SimpleDateFormat;

    .line 555
    .line 556
    const-string v11, "HH:mm"

    .line 557
    .line 558
    sget-object v12, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 559
    .line 560
    invoke-direct {v10, v11, v12}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 561
    .line 562
    .line 563
    invoke-static {v6, v7, v10}, Lcom/transsnet/palmpay/util/TimeUtils;->millis2String(JLjava/text/DateFormat;)Ljava/lang/String;

    .line 564
    .line 565
    .line 566
    move-result-object v6

    .line 567
    const-string v7, "Start at "

    .line 568
    .line 569
    invoke-static {v7, v6, v5}, LC0/G;->x(Ljava/lang/String;Ljava/lang/String;Landroid/widget/TextView;)V

    .line 570
    .line 571
    .line 572
    :cond_23
    if-eqz v5, :cond_24

    .line 573
    .line 574
    sget v6, LL6/b;->ppColorPrimary:I

    .line 575
    .line 576
    invoke-virtual {v0}, LM1/j;->getContext()Landroid/content/Context;

    .line 577
    .line 578
    .line 579
    move-result-object v7

    .line 580
    invoke-static {v6, v7}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 581
    .line 582
    .line 583
    move-result v6

    .line 584
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 585
    .line 586
    .line 587
    :cond_24
    if-eqz v5, :cond_25

    .line 588
    .line 589
    sget v6, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_rect_corner_12_bg_color_disable:I

    .line 590
    .line 591
    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundResource(I)V

    .line 592
    .line 593
    .line 594
    :cond_25
    :goto_e
    iget-object v2, v2, Lcom/transsnet/palmpay/core/bean/RecommendedItem;->status:Ljava/lang/Integer;

    .line 595
    .line 596
    if-nez v2, :cond_26

    .line 597
    .line 598
    goto :goto_f

    .line 599
    :cond_26
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 600
    .line 601
    .line 602
    move-result v2

    .line 603
    if-ne v2, v14, :cond_2b

    .line 604
    .line 605
    const/high16 v1, 0x3f000000    # 0.5f

    .line 606
    .line 607
    if-eqz v3, :cond_27

    .line 608
    .line 609
    invoke-virtual {v3, v1}, Landroid/view/View;->setAlpha(F)V

    .line 610
    .line 611
    .line 612
    :cond_27
    if-eqz v4, :cond_28

    .line 613
    .line 614
    invoke-virtual {v4, v1}, Landroid/view/View;->setAlpha(F)V

    .line 615
    .line 616
    .line 617
    :cond_28
    if-eqz v8, :cond_29

    .line 618
    .line 619
    invoke-virtual {v8, v1}, Landroid/view/View;->setAlpha(F)V

    .line 620
    .line 621
    .line 622
    :cond_29
    if-eqz v9, :cond_2a

    .line 623
    .line 624
    invoke-virtual {v9, v1}, Landroid/view/View;->setAlpha(F)V

    .line 625
    .line 626
    .line 627
    :cond_2a
    return-void

    .line 628
    :cond_2b
    :goto_f
    const/high16 v2, 0x3f800000    # 1.0f

    .line 629
    .line 630
    if-eqz v3, :cond_2c

    .line 631
    .line 632
    invoke-virtual {v3, v2}, Landroid/view/View;->setAlpha(F)V

    .line 633
    .line 634
    .line 635
    :cond_2c
    if-eqz v4, :cond_2d

    .line 636
    .line 637
    invoke-virtual {v4, v2}, Landroid/view/View;->setAlpha(F)V

    .line 638
    .line 639
    .line 640
    :cond_2d
    if-eqz v8, :cond_2e

    .line 641
    .line 642
    invoke-virtual {v8, v2}, Landroid/view/View;->setAlpha(F)V

    .line 643
    .line 644
    .line 645
    :cond_2e
    if-eqz v9, :cond_2f

    .line 646
    .line 647
    invoke-virtual {v9, v2}, Landroid/view/View;->setAlpha(F)V

    .line 648
    .line 649
    .line 650
    :cond_2f
    invoke-virtual {v1, v13}, Landroid/view/View;->setEnabled(Z)V

    .line 651
    .line 652
    .line 653
    return-void
.end method
