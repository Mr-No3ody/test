.class public final LUa/W;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView$OnWheelItemSelectedListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/viewmodel/ModelDayPick;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelDayPick;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LUa/W;->a:Lcom/transsnet/palmpay/core/viewmodel/ModelDayPick;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onItemSelected(ILjava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Ljava/lang/String;

    .line 2
    .line 3
    iget-object p1, p0, LUa/W;->a:Lcom/transsnet/palmpay/core/viewmodel/ModelDayPick;

    .line 4
    .line 5
    iput-object p2, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelDayPick;->w:Ljava/lang/String;

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/viewmodel/ModelDayPick;->g()V

    .line 8
    .line 9
    .line 10
    invoke-static {p1}, Lcom/transsnet/palmpay/core/viewmodel/ModelDayPick;->d(Lcom/transsnet/palmpay/core/viewmodel/ModelDayPick;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
