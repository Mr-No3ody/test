.class public final LUa/G;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;)V
    .locals 0

    .line 1
    iput-object p2, p0, LUa/G;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;

    .line 2
    .line 3
    const/4 p2, 0x2

    .line 4
    invoke-direct {p0, p2, p1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance v0, LUa/G;

    .line 2
    .line 3
    iget-object v1, p0, LUa/G;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;

    .line 4
    .line 5
    invoke-direct {v0, p2, v1}, LUa/G;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;)V

    .line 6
    .line 7
    .line 8
    iput-object p1, v0, LUa/G;->b:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/G;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/G;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/G;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LUa/G;->a:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object v3, p0, LUa/G;->c:Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;

    .line 7
    .line 8
    const/4 v4, 0x3

    .line 9
    const/4 v5, 0x2

    .line 10
    const/4 v6, 0x1

    .line 11
    if-eqz v1, :cond_3

    .line 12
    .line 13
    if-eq v1, v6, :cond_2

    .line 14
    .line 15
    if-eq v1, v5, :cond_1

    .line 16
    .line 17
    if-ne v1, v4, :cond_0

    .line 18
    .line 19
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    goto/16 :goto_6

    .line 23
    .line 24
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 25
    .line 26
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 27
    .line 28
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1

    .line 32
    :cond_1
    iget-object v1, p0, LUa/G;->b:Ljava/lang/Object;

    .line 33
    .line 34
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_4

    .line 38
    :cond_2
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    goto :goto_2

    .line 44
    :cond_3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    iget-object p1, p0, LUa/G;->b:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 50
    .line 51
    :try_start_1
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 52
    .line 53
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 54
    .line 55
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 58
    .line 59
    iget-object v1, v3, Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;->d:Ljava/lang/String;

    .line 60
    .line 61
    if-nez v1, :cond_4

    .line 62
    .line 63
    const-string v1, ""

    .line 64
    .line 65
    :cond_4
    iput v6, p0, LUa/G;->a:I

    .line 66
    .line 67
    invoke-interface {p1, v1, p0}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryBillQuickAccess(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-ne p1, v0, :cond_5

    .line 72
    .line 73
    goto :goto_5

    .line 74
    :cond_5
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 75
    .line 76
    sget-object v1, Lxf/q;->a:Lxf/o;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 77
    .line 78
    :goto_1
    move-object v1, p1

    .line 79
    goto :goto_3

    .line 80
    :goto_2
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 81
    .line 82
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    goto :goto_1

    .line 87
    :goto_3
    instance-of p1, v1, Lxf/p;

    .line 88
    .line 89
    if-nez p1, :cond_6

    .line 90
    .line 91
    move-object p1, v1

    .line 92
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 93
    .line 94
    sget-object v6, LWf/I;->a:Lcg/f;

    .line 95
    .line 96
    sget-object v6, Lag/o;->a:LWf/p0;

    .line 97
    .line 98
    new-instance v7, LUa/E;

    .line 99
    .line 100
    invoke-direct {v7, p1, v2, v3}, LUa/E;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelBillQuickAccessItem;)V

    .line 101
    .line 102
    .line 103
    iput-object v1, p0, LUa/G;->b:Ljava/lang/Object;

    .line 104
    .line 105
    iput v5, p0, LUa/G;->a:I

    .line 106
    .line 107
    invoke-static {v6, v7, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    if-ne p1, v0, :cond_6

    .line 112
    .line 113
    goto :goto_5

    .line 114
    :cond_6
    :goto_4
    invoke-static {v1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    if-eqz p1, :cond_7

    .line 119
    .line 120
    sget-object v3, LWf/I;->a:Lcg/f;

    .line 121
    .line 122
    sget-object v3, Lag/o;->a:LWf/p0;

    .line 123
    .line 124
    new-instance v5, LUa/F;

    .line 125
    .line 126
    invoke-direct {v5, v2, p1}, LUa/F;-><init>(Lkotlin/coroutines/Continuation;Ljava/lang/Throwable;)V

    .line 127
    .line 128
    .line 129
    iput-object v1, p0, LUa/G;->b:Ljava/lang/Object;

    .line 130
    .line 131
    iput v4, p0, LUa/G;->a:I

    .line 132
    .line 133
    invoke-static {v3, v5, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    if-ne p1, v0, :cond_7

    .line 138
    .line 139
    :goto_5
    return-object v0

    .line 140
    :cond_7
    :goto_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 141
    .line 142
    return-object p1
.end method
