.class public final LUa/f0;
.super LI9/c;
.source "SourceFile"


# instance fields
.field public final e:Landroid/widget/TextView;

.field public final f:Landroid/widget/TextView;

.field public final g:Landroid/widget/TextView;

.field public final synthetic h:Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;Landroid/view/View;)V
    .locals 1

    .line 1
    iput-object p1, p0, LUa/f0;->h:Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    invoke-direct {p0, p2, p1}, LI9/c;-><init>(Landroid/view/View;I)V

    .line 5
    .line 6
    .line 7
    iget-object p1, p0, LI9/c;->b:Landroid/view/View;

    .line 8
    .line 9
    sget p2, Lba/e;->tvCountDown:I

    .line 10
    .line 11
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Landroid/widget/TextView;

    .line 16
    .line 17
    iput-object p1, p0, LUa/f0;->e:Landroid/widget/TextView;

    .line 18
    .line 19
    iget-object p1, p0, LI9/c;->b:Landroid/view/View;

    .line 20
    .line 21
    sget p2, Lba/e;->tvPendingMsg:I

    .line 22
    .line 23
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Landroid/widget/TextView;

    .line 28
    .line 29
    iput-object p1, p0, LUa/f0;->f:Landroid/widget/TextView;

    .line 30
    .line 31
    iget-object p1, p0, LI9/c;->b:Landroid/view/View;

    .line 32
    .line 33
    sget p2, Lba/e;->ivIcon:I

    .line 34
    .line 35
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    check-cast p1, Landroid/widget/ImageView;

    .line 40
    .line 41
    iget-object p2, p0, LI9/c;->b:Landroid/view/View;

    .line 42
    .line 43
    sget v0, Lba/e;->tvClaimCoupon:I

    .line 44
    .line 45
    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    check-cast p2, Landroid/widget/TextView;

    .line 50
    .line 51
    iput-object p2, p0, LUa/f0;->g:Landroid/widget/TextView;

    .line 52
    .line 53
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->isNG()Z

    .line 54
    .line 55
    .line 56
    move-result p2

    .line 57
    if-nez p2, :cond_0

    .line 58
    .line 59
    sget p2, Lcom/transsnet/palmpay/custom_view/r;->cv_result_pending:I

    .line 60
    .line 61
    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 62
    .line 63
    .line 64
    :cond_0
    return-void
.end method


# virtual methods
.method public final a(I)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, LI9/c;->a(I)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    iget-object p1, p0, LUa/f0;->h:Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;

    .line 7
    .line 8
    iget-object p1, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;->f:LI9/d;

    .line 9
    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, LUa/f0;->e:Landroid/widget/TextView;

    .line 13
    .line 14
    invoke-virtual {v0, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final b(J)V
    .locals 5

    .line 1
    iget-object v0, p0, LUa/f0;->h:Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;

    .line 2
    .line 3
    iget-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;->f:LI9/d;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    iget-object v2, p0, LUa/f0;->e:Landroid/widget/TextView;

    .line 8
    .line 9
    invoke-virtual {v2, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 10
    .line 11
    .line 12
    :cond_0
    const-wide/16 v1, 0x0

    .line 13
    .line 14
    cmp-long v1, p1, v1

    .line 15
    .line 16
    iget-object v2, p0, LUa/f0;->e:Landroid/widget/TextView;

    .line 17
    .line 18
    if-lez v1, :cond_1

    .line 19
    .line 20
    new-instance v1, LI9/d;

    .line 21
    .line 22
    const/4 v3, 0x1

    .line 23
    invoke-direct {v1, v3}, LI9/d;-><init>(I)V

    .line 24
    .line 25
    .line 26
    new-instance v3, Ljava/lang/ref/WeakReference;

    .line 27
    .line 28
    invoke-direct {v3, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iput-object v3, v1, LI9/d;->b:Ljava/lang/ref/WeakReference;

    .line 32
    .line 33
    new-instance v3, Ljava/lang/ref/WeakReference;

    .line 34
    .line 35
    iget-object v4, p0, LUa/f0;->f:Landroid/widget/TextView;

    .line 36
    .line 37
    invoke-direct {v3, v4}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iput-object v3, v1, LI9/d;->c:Ljava/lang/ref/WeakReference;

    .line 41
    .line 42
    iput-wide p1, v1, LI9/d;->d:J

    .line 43
    .line 44
    iput-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;->f:LI9/d;

    .line 45
    .line 46
    const-wide/16 p1, 0x1f4

    .line 47
    .line 48
    invoke-virtual {v2, v1, p1, p2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    :cond_1
    sget p1, Lba/k;->core_pending:I

    .line 53
    .line 54
    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(I)V

    .line 55
    .line 56
    .line 57
    return-void
.end method
