.class public final LUa/v0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/v0;->a:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 2
    .line 3
    iput-object p2, p0, LUa/v0;->b:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p3, p0, LUa/v0;->c:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p4, p0, LUa/v0;->d:Ljava/lang/String;

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p5}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 6

    .line 1
    new-instance v0, LUa/v0;

    .line 2
    .line 3
    iget-object v3, p0, LUa/v0;->c:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v4, p0, LUa/v0;->d:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v1, p0, LUa/v0;->a:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 8
    .line 9
    iget-object v2, p0, LUa/v0;->b:Ljava/lang/String;

    .line 10
    .line 11
    move-object v5, p2

    .line 12
    invoke-direct/range {v0 .. v5}, LUa/v0;-><init>(Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Boolean;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 4
    .line 5
    .line 6
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 7
    .line 8
    invoke-virtual {p0, p1, p2}, LUa/v0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, LUa/v0;

    .line 13
    .line 14
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 15
    .line 16
    invoke-virtual {p1, p2}, LUa/v0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object v2, p0, LUa/v0;->a:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 7
    .line 8
    iget-boolean p1, v2, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->f:Z

    .line 9
    .line 10
    if-nez p1, :cond_0

    .line 11
    .line 12
    invoke-static {v2}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    sget-object v0, LWf/I;->a:Lcg/f;

    .line 17
    .line 18
    sget-object v0, Lcg/e;->c:Lcg/e;

    .line 19
    .line 20
    new-instance v1, LUa/y0;

    .line 21
    .line 22
    iget-object v4, p0, LUa/v0;->c:Ljava/lang/String;

    .line 23
    .line 24
    iget-object v5, p0, LUa/v0;->d:Ljava/lang/String;

    .line 25
    .line 26
    const/4 v6, 0x0

    .line 27
    iget-object v3, p0, LUa/v0;->b:Ljava/lang/String;

    .line 28
    .line 29
    invoke-direct/range {v1 .. v6}, LUa/y0;-><init>(Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 30
    .line 31
    .line 32
    const/4 v3, 0x0

    .line 33
    const/4 v4, 0x2

    .line 34
    invoke-static {p1, v0, v3, v1, v4}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-virtual {v2, p1}, Lcom/transsnet/palmpay/custom_view/model/BaseLinearLayout;->addJob(Lkotlinx/coroutines/Job;)V

    .line 39
    .line 40
    .line 41
    :cond_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 42
    .line 43
    return-object p1
.end method
