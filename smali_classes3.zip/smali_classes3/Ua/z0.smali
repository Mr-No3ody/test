.class public final LUa/z0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewpager/widget/ViewPager$OnPageChangeListener;


# instance fields
.field public final synthetic a:Ljava/util/ArrayList;

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LUa/z0;->a:Ljava/util/ArrayList;

    .line 5
    .line 6
    iput-object p2, p0, LUa/z0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onPageScrollStateChanged(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onPageScrolled(IFI)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onPageSelected(I)V
    .locals 11

    .line 1
    iget-object v0, p0, LUa/z0;->a:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/view/View;

    .line 8
    .line 9
    sget v1, Lba/e;->core_order_reward_report:I

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 16
    .line 17
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    iget-object v2, p0, LUa/z0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 22
    .line 23
    if-eqz v1, :cond_1

    .line 24
    .line 25
    iget-object v1, v2, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->d:Ljava/util/List;

    .line 26
    .line 27
    if-eqz v1, :cond_0

    .line 28
    .line 29
    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, Ljava/util/List;

    .line 34
    .line 35
    if-eqz v1, :cond_0

    .line 36
    .line 37
    check-cast v1, Ljava/lang/Iterable;

    .line 38
    .line 39
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 44
    .line 45
    .line 46
    move-result v3

    .line 47
    if-eqz v3, :cond_0

    .line 48
    .line 49
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v3

    .line 53
    check-cast v3, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 54
    .line 55
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 56
    .line 57
    .line 58
    move-result-object v4

    .line 59
    iget-object v5, v3, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardType:Ljava/lang/Integer;

    .line 60
    .line 61
    new-instance v6, Lkotlin/Pair;

    .line 62
    .line 63
    const-string v7, "rewardType"

    .line 64
    .line 65
    invoke-direct {v6, v7, v5}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    iget-object v5, v3, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->recordNo:Ljava/lang/String;

    .line 69
    .line 70
    new-instance v7, Lkotlin/Pair;

    .line 71
    .line 72
    const-string v8, "rewardid"

    .line 73
    .line 74
    invoke-direct {v7, v8, v5}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    iget-object v3, v3, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->transType:Ljava/lang/String;

    .line 78
    .line 79
    new-instance v5, Lkotlin/Pair;

    .line 80
    .line 81
    const-string v8, "transtype"

    .line 82
    .line 83
    invoke-direct {v5, v8, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    invoke-static {}, LC0/G;->k()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    new-instance v8, Lkotlin/Pair;

    .line 91
    .line 92
    const-string v9, "memberid"

    .line 93
    .line 94
    invoke-direct {v8, v9, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    iget-object v3, v2, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->j:Ljava/lang/String;

    .line 98
    .line 99
    new-instance v9, Lkotlin/Pair;

    .line 100
    .line 101
    const-string v10, "orderid"

    .line 102
    .line 103
    invoke-direct {v9, v10, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    filled-new-array {v6, v7, v5, v8, v9}, [Lkotlin/Pair;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    invoke-static {v3}, Lkotlin/collections/G;->g([Lkotlin/Pair;)Ljava/util/Map;

    .line 111
    .line 112
    .line 113
    move-result-object v3

    .line 114
    const-string v5, "ResultPage_Reward_View"

    .line 115
    .line 116
    invoke-virtual {v4, v5, v3}, LPa/n0;->w(Ljava/lang/String;Ljava/util/Map;)V

    .line 117
    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_0
    sget v1, Lba/e;->core_order_reward_report:I

    .line 121
    .line 122
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 123
    .line 124
    invoke-virtual {v0, v1, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    :cond_1
    iget-object v0, v2, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->c:LBc/b;

    .line 128
    .line 129
    const/4 v1, 0x0

    .line 130
    if-eqz v0, :cond_2

    .line 131
    .line 132
    iget-object v2, v0, LBc/b;->b:Landroid/view/ViewGroup;

    .line 133
    .line 134
    check-cast v2, Landroid/widget/LinearLayout;

    .line 135
    .line 136
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 137
    .line 138
    .line 139
    move-result v2

    .line 140
    goto :goto_1

    .line 141
    :cond_2
    move v2, v1

    .line 142
    :goto_1
    if-nez v2, :cond_3

    .line 143
    .line 144
    goto :goto_5

    .line 145
    :cond_3
    if-eqz v0, :cond_4

    .line 146
    .line 147
    iget-object v2, v0, LBc/b;->b:Landroid/view/ViewGroup;

    .line 148
    .line 149
    check-cast v2, Landroid/widget/LinearLayout;

    .line 150
    .line 151
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 152
    .line 153
    .line 154
    move-result v2

    .line 155
    goto :goto_2

    .line 156
    :cond_4
    const/4 v2, 0x1

    .line 157
    :goto_2
    if-ge v1, v2, :cond_8

    .line 158
    .line 159
    if-eqz v0, :cond_5

    .line 160
    .line 161
    iget-object v3, v0, LBc/b;->b:Landroid/view/ViewGroup;

    .line 162
    .line 163
    check-cast v3, Landroid/widget/LinearLayout;

    .line 164
    .line 165
    invoke-virtual {v3, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    goto :goto_3

    .line 170
    :cond_5
    const/4 v3, 0x0

    .line 171
    :goto_3
    if-eqz v3, :cond_7

    .line 172
    .line 173
    if-ne v1, p1, :cond_6

    .line 174
    .line 175
    sget v4, Lcom/transsnet/palmpay/custom_view/r;->cv_button_bg_purple_corner_1:I

    .line 176
    .line 177
    goto :goto_4

    .line 178
    :cond_6
    sget v4, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_rect_corner_12_bg_color_disable:I

    .line 179
    .line 180
    :goto_4
    invoke-virtual {v3, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 181
    .line 182
    .line 183
    :cond_7
    add-int/lit8 v1, v1, 0x1

    .line 184
    .line 185
    goto :goto_2

    .line 186
    :cond_8
    :goto_5
    return-void
.end method
