.class public final LUa/r;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Lkotlin/jvm/internal/F;

.field public final synthetic e:Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lkotlin/jvm/internal/F;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/r;->c:Ljava/lang/String;

    .line 2
    .line 3
    iput-object p2, p0, LUa/r;->d:Lkotlin/jvm/internal/F;

    .line 4
    .line 5
    iput-object p4, p0, LUa/r;->e:Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 4

    .line 1
    new-instance v0, LUa/r;

    .line 2
    .line 3
    iget-object v1, p0, LUa/r;->e:Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;

    .line 4
    .line 5
    iget-object v2, p0, LUa/r;->d:Lkotlin/jvm/internal/F;

    .line 6
    .line 7
    iget-object v3, p0, LUa/r;->c:Ljava/lang/String;

    .line 8
    .line 9
    invoke-direct {v0, v3, v2, p2, v1}, LUa/r;-><init>(Ljava/lang/String;Lkotlin/jvm/internal/F;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, v0, LUa/r;->b:Ljava/lang/Object;

    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/flow/FlowCollector;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/r;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/r;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/r;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LUa/r;->a:I

    .line 4
    .line 5
    iget-object v2, p0, LUa/r;->d:Lkotlin/jvm/internal/F;

    .line 6
    .line 7
    iget-object v3, p0, LUa/r;->c:Ljava/lang/String;

    .line 8
    .line 9
    const/4 v4, 0x4

    .line 10
    const/4 v5, 0x3

    .line 11
    const/4 v6, 0x2

    .line 12
    const/4 v7, 0x1

    .line 13
    if-eqz v1, :cond_4

    .line 14
    .line 15
    if-eq v1, v7, :cond_3

    .line 16
    .line 17
    if-eq v1, v6, :cond_2

    .line 18
    .line 19
    if-eq v1, v5, :cond_1

    .line 20
    .line 21
    if-ne v1, v4, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 25
    .line 26
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 27
    .line 28
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1

    .line 32
    :cond_1
    :goto_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    goto/16 :goto_4

    .line 36
    .line 37
    :cond_2
    iget-object v1, p0, LUa/r;->b:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v1, Lkotlinx/coroutines/flow/FlowCollector;

    .line 40
    .line 41
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_2

    .line 45
    :cond_3
    iget-object v1, p0, LUa/r;->b:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v1, Lkotlinx/coroutines/flow/FlowCollector;

    .line 48
    .line 49
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_4
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    iget-object p1, p0, LUa/r;->b:Ljava/lang/Object;

    .line 57
    .line 58
    move-object v1, p1

    .line 59
    check-cast v1, Lkotlinx/coroutines/flow/FlowCollector;

    .line 60
    .line 61
    invoke-static {v3}, Lcom/horcrux/svg/d0;->p(Ljava/lang/String;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 66
    .line 67
    .line 68
    move-result v8

    .line 69
    if-nez v8, :cond_5

    .line 70
    .line 71
    new-instance v8, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem$queryCoupons$$inlined$launchRequestFromCacheFirstOnView$1$1$1;

    .line 72
    .line 73
    invoke-direct {v8}, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem$queryCoupons$$inlined$launchRequestFromCacheFirstOnView$1$1$1;-><init>()V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v8}, Lcom/google/gson/reflect/TypeToken;->getType()Ljava/lang/reflect/Type;

    .line 77
    .line 78
    .line 79
    move-result-object v8

    .line 80
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 81
    .line 82
    .line 83
    move-result-object v9

    .line 84
    invoke-virtual {v9, p1, v8}, LPa/w;->e(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v8

    .line 88
    check-cast v8, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 89
    .line 90
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    iput-object p1, v2, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 94
    .line 95
    iput-object v1, p0, LUa/r;->b:Ljava/lang/Object;

    .line 96
    .line 97
    iput v7, p0, LUa/r;->a:I

    .line 98
    .line 99
    invoke-interface {v1, v8, p0}, Lkotlinx/coroutines/flow/FlowCollector;->emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    if-ne p1, v0, :cond_5

    .line 104
    .line 105
    goto :goto_3

    .line 106
    :cond_5
    :goto_1
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 107
    .line 108
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 111
    .line 112
    iput-object v1, p0, LUa/r;->b:Ljava/lang/Object;

    .line 113
    .line 114
    iput v6, p0, LUa/r;->a:I

    .line 115
    .line 116
    iget-object v6, p0, LUa/r;->e:Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;

    .line 117
    .line 118
    invoke-interface {p1, v6, p0}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryCouponStatisticsByNew(Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    if-ne p1, v0, :cond_6

    .line 123
    .line 124
    goto :goto_3

    .line 125
    :cond_6
    :goto_2
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 126
    .line 127
    const/4 v6, 0x0

    .line 128
    if-eqz p1, :cond_7

    .line 129
    .line 130
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 131
    .line 132
    .line 133
    move-result v8

    .line 134
    if-ne v8, v7, :cond_7

    .line 135
    .line 136
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 137
    .line 138
    .line 139
    move-result-object v4

    .line 140
    invoke-static {v4}, LPa/H;->c(Landroid/content/Context;)LPa/H;

    .line 141
    .line 142
    .line 143
    move-result-object v4

    .line 144
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 145
    .line 146
    .line 147
    move-result-object v7

    .line 148
    iget-object v7, v7, LPa/w;->b:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v7, Lcom/google/gson/Gson;

    .line 151
    .line 152
    const-class v8, Lcom/transsnet/palmpay/core/bean/rsp/QueryUserCouponsRsp;

    .line 153
    .line 154
    invoke-virtual {v7, p1, v8}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;Ljava/lang/reflect/Type;)Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v7

    .line 158
    const/16 v8, 0x3c

    .line 159
    .line 160
    invoke-virtual {v4, v8, v3, v7}, LPa/H;->f(ILjava/lang/String;Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    iget-object v3, v3, LPa/w;->b:Ljava/lang/Object;

    .line 168
    .line 169
    check-cast v3, Lcom/google/gson/Gson;

    .line 170
    .line 171
    invoke-virtual {v3, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object v3

    .line 175
    iget-object v2, v2, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 176
    .line 177
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 178
    .line 179
    .line 180
    move-result v2

    .line 181
    if-nez v2, :cond_8

    .line 182
    .line 183
    iput-object v6, p0, LUa/r;->b:Ljava/lang/Object;

    .line 184
    .line 185
    iput v5, p0, LUa/r;->a:I

    .line 186
    .line 187
    invoke-interface {v1, p1, p0}, Lkotlinx/coroutines/flow/FlowCollector;->emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    if-ne p1, v0, :cond_8

    .line 192
    .line 193
    goto :goto_3

    .line 194
    :cond_7
    iput-object v6, p0, LUa/r;->b:Ljava/lang/Object;

    .line 195
    .line 196
    iput v4, p0, LUa/r;->a:I

    .line 197
    .line 198
    invoke-interface {v1, p1, p0}, Lkotlinx/coroutines/flow/FlowCollector;->emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object p1

    .line 202
    if-ne p1, v0, :cond_8

    .line 203
    .line 204
    :goto_3
    return-object v0

    .line 205
    :cond_8
    :goto_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 206
    .line 207
    return-object p1
.end method
