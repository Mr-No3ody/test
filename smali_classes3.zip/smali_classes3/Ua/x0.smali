.class public final LUa/x0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Ljava/lang/Throwable;

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;


# direct methods
.method public constructor <init>(Ljava/lang/Throwable;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/x0;->a:Ljava/lang/Throwable;

    .line 2
    .line 3
    iput-object p3, p0, LUa/x0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LUa/x0;

    .line 2
    .line 3
    iget-object v0, p0, LUa/x0;->a:Ljava/lang/Throwable;

    .line 4
    .line 5
    iget-object v1, p0, LUa/x0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 6
    .line 7
    invoke-direct {p1, v0, p2, v1}, LUa/x0;-><init>(Ljava/lang/Throwable;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/x0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/x0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/x0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LUa/x0;->a:Ljava/lang/Throwable;

    .line 7
    .line 8
    invoke-static {p1}, Lorg/chromium/support_lib_boundary/util/b;->W(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/4 v0, 0x0

    .line 13
    new-array v0, v0, [Ljava/lang/Object;

    .line 14
    .line 15
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object p1, p0, LUa/x0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 19
    .line 20
    invoke-static {p1}, Loa/h;->c(Landroid/view/View;)V

    .line 21
    .line 22
    .line 23
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 24
    .line 25
    return-object p1
.end method
