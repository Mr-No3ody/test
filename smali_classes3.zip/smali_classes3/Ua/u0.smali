.class public final LUa/u0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

.field public final synthetic d:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

.field public final synthetic e:LUa/A0;

.field public final synthetic f:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;LUa/A0;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;)V
    .locals 0

    .line 1
    iput-object p2, p0, LUa/u0;->c:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 2
    .line 3
    iput-object p3, p0, LUa/u0;->d:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 4
    .line 5
    iput-object p4, p0, LUa/u0;->e:LUa/A0;

    .line 6
    .line 7
    iput-object p5, p0, LUa/u0;->f:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 8
    .line 9
    const/4 p2, 0x2

    .line 10
    invoke-direct {p0, p2, p1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 6

    .line 1
    new-instance v0, LUa/u0;

    .line 2
    .line 3
    iget-object v4, p0, LUa/u0;->e:LUa/A0;

    .line 4
    .line 5
    iget-object v5, p0, LUa/u0;->f:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 6
    .line 7
    iget-object v2, p0, LUa/u0;->c:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 8
    .line 9
    iget-object v3, p0, LUa/u0;->d:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 10
    .line 11
    move-object v1, p2

    .line 12
    invoke-direct/range {v0 .. v5}, LUa/u0;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;LUa/A0;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;)V

    .line 13
    .line 14
    .line 15
    iput-object p1, v0, LUa/u0;->b:Ljava/lang/Object;

    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/u0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/u0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/u0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    sget-object v1, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v0, p0, LUa/u0;->a:I

    .line 4
    .line 5
    iget-object v2, p0, LUa/u0;->d:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 6
    .line 7
    const/4 v3, 0x3

    .line 8
    const/4 v4, 0x2

    .line 9
    const/4 v5, 0x1

    .line 10
    if-eqz v0, :cond_3

    .line 11
    .line 12
    if-eq v0, v5, :cond_2

    .line 13
    .line 14
    if-eq v0, v4, :cond_1

    .line 15
    .line 16
    if-ne v0, v3, :cond_0

    .line 17
    .line 18
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    move-object v12, p0

    .line 22
    goto/16 :goto_7

    .line 23
    .line 24
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 25
    .line 26
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 27
    .line 28
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1

    .line 32
    :cond_1
    iget-object v0, p0, LUa/u0;->b:Ljava/lang/Object;

    .line 33
    .line 34
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    move-object v12, p0

    .line 38
    goto/16 :goto_5

    .line 39
    .line 40
    :cond_2
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    .line 42
    .line 43
    move-object v12, p0

    .line 44
    goto :goto_0

    .line 45
    :catchall_0
    move-exception v0

    .line 46
    move-object p1, v0

    .line 47
    move-object v12, p0

    .line 48
    goto :goto_3

    .line 49
    :cond_3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iget-object p1, p0, LUa/u0;->b:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 55
    .line 56
    :try_start_1
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 57
    .line 58
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 59
    .line 60
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 61
    .line 62
    move-object v6, p1

    .line 63
    check-cast v6, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 64
    .line 65
    iget-object p1, p0, LUa/u0;->c:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 66
    .line 67
    iget-object v7, p1, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->recordNo:Ljava/lang/String;

    .line 68
    .line 69
    iget-object v8, v2, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->o:Ljava/lang/String;

    .line 70
    .line 71
    iget-object v9, p1, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->payId:Ljava/lang/String;

    .line 72
    .line 73
    iget-object v10, p1, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->orderNo:Ljava/lang/String;

    .line 74
    .line 75
    iget-object v11, p1, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardType:Ljava/lang/Integer;

    .line 76
    .line 77
    iput v5, p0, LUa/u0;->a:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 78
    .line 79
    move-object v12, p0

    .line 80
    :try_start_2
    invoke-interface/range {v6 .. v12}, Lcom/transsnet/palmpay/core/network/PayApiService;->claimReward(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    if-ne p1, v1, :cond_4

    .line 85
    .line 86
    goto :goto_6

    .line 87
    :cond_4
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 88
    .line 89
    sget-object v0, Lxf/q;->a:Lxf/o;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 90
    .line 91
    :goto_1
    move-object v0, p1

    .line 92
    goto :goto_4

    .line 93
    :catchall_1
    move-exception v0

    .line 94
    :goto_2
    move-object p1, v0

    .line 95
    goto :goto_3

    .line 96
    :catchall_2
    move-exception v0

    .line 97
    move-object v12, p0

    .line 98
    goto :goto_2

    .line 99
    :goto_3
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 100
    .line 101
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    goto :goto_1

    .line 106
    :goto_4
    instance-of p1, v0, Lxf/p;

    .line 107
    .line 108
    if-nez p1, :cond_5

    .line 109
    .line 110
    move-object v6, v0

    .line 111
    check-cast v6, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 112
    .line 113
    sget-object p1, LWf/I;->a:Lcg/f;

    .line 114
    .line 115
    sget-object p1, Lag/o;->a:LWf/p0;

    .line 116
    .line 117
    new-instance v5, LUa/s0;

    .line 118
    .line 119
    iget-object v9, v12, LUa/u0;->e:LUa/A0;

    .line 120
    .line 121
    iget-object v10, v12, LUa/u0;->f:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 122
    .line 123
    const/4 v7, 0x0

    .line 124
    iget-object v8, v12, LUa/u0;->d:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 125
    .line 126
    invoke-direct/range {v5 .. v10}, LUa/s0;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;LUa/A0;Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;)V

    .line 127
    .line 128
    .line 129
    iput-object v0, v12, LUa/u0;->b:Ljava/lang/Object;

    .line 130
    .line 131
    iput v4, v12, LUa/u0;->a:I

    .line 132
    .line 133
    invoke-static {p1, v5, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    if-ne p1, v1, :cond_5

    .line 138
    .line 139
    goto :goto_6

    .line 140
    :cond_5
    :goto_5
    invoke-static {v0}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    if-eqz p1, :cond_6

    .line 145
    .line 146
    sget-object v4, LWf/I;->a:Lcg/f;

    .line 147
    .line 148
    sget-object v4, Lag/o;->a:LWf/p0;

    .line 149
    .line 150
    new-instance v5, LUa/t0;

    .line 151
    .line 152
    const/4 v6, 0x0

    .line 153
    invoke-direct {v5, p1, v6, v2}, LUa/t0;-><init>(Ljava/lang/Throwable;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V

    .line 154
    .line 155
    .line 156
    iput-object v0, v12, LUa/u0;->b:Ljava/lang/Object;

    .line 157
    .line 158
    iput v3, v12, LUa/u0;->a:I

    .line 159
    .line 160
    invoke-static {v4, v5, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    if-ne p1, v1, :cond_6

    .line 165
    .line 166
    :goto_6
    return-object v1

    .line 167
    :cond_6
    :goto_7
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 168
    .line 169
    return-object p1
.end method
