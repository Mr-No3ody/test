.class public final LUa/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/adsdk/widgets/interfaces/AdShowCallback;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LUa/a;->a:I

    iput-object p1, p0, LUa/a;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final showAppAd(Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V
    .locals 1

    .line 1
    iget v0, p0, LUa/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "adEntity"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p1, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->relativeUrl:Ljava/lang/String;

    .line 12
    .line 13
    const-string v0, "RATE_DIALOG"

    .line 14
    .line 15
    invoke-virtual {v0, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    if-eqz p1, :cond_0

    .line 20
    .line 21
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {p1}, Lya/a;->j()V

    .line 26
    .line 27
    .line 28
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    const-string v0, "/app/rate_app_activity"

    .line 33
    .line 34
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    const/high16 v0, 0x10000000

    .line 39
    .line 40
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withFlags(I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    iget-object v0, p0, LUa/a;->b:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment;

    .line 47
    .line 48
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    :cond_0
    return-void

    .line 56
    :pswitch_0
    const-string v0, "adEntity"

    .line 57
    .line 58
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    iget-object p1, p1, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->relativeUrl:Ljava/lang/String;

    .line 62
    .line 63
    const-string v0, "RATE_DIALOG"

    .line 64
    .line 65
    invoke-virtual {v0, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    if-eqz p1, :cond_1

    .line 70
    .line 71
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    invoke-virtual {p1}, Lya/a;->j()V

    .line 76
    .line 77
    .line 78
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    const-string v0, "/app/rate_app_activity"

    .line 83
    .line 84
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    const/high16 v0, 0x10000000

    .line 89
    .line 90
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withFlags(I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    iget-object v0, p0, LUa/a;->b:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnResolveActivity;

    .line 97
    .line 98
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    :cond_1
    return-void

    .line 102
    :pswitch_1
    const-string v0, "adEntity"

    .line 103
    .line 104
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    iget-object p1, p1, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->relativeUrl:Ljava/lang/String;

    .line 108
    .line 109
    const-string v0, "RATE_DIALOG"

    .line 110
    .line 111
    invoke-virtual {v0, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 112
    .line 113
    .line 114
    move-result p1

    .line 115
    if-eqz p1, :cond_2

    .line 116
    .line 117
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    invoke-virtual {p1}, Lya/a;->j()V

    .line 122
    .line 123
    .line 124
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    const-string v0, "/app/rate_app_activity"

    .line 129
    .line 130
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    const/high16 v0, 0x10000000

    .line 135
    .line 136
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withFlags(I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    iget-object v0, p0, LUa/a;->b:Ljava/lang/Object;

    .line 141
    .line 142
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnHomePageActivity;

    .line 143
    .line 144
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    :cond_2
    return-void

    .line 148
    :pswitch_2
    const-string v0, "RATE_DIALOG"

    .line 149
    .line 150
    iget-object p1, p1, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->relativeUrl:Ljava/lang/String;

    .line 151
    .line 152
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result p1

    .line 156
    if-eqz p1, :cond_3

    .line 157
    .line 158
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    invoke-virtual {p1}, Lya/a;->j()V

    .line 163
    .line 164
    .line 165
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    const-string v0, "/app/rate_app_activity"

    .line 170
    .line 171
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    const/high16 v0, 0x10000000

    .line 176
    .line 177
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withFlags(I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    iget-object v0, p0, LUa/a;->b:Ljava/lang/Object;

    .line 182
    .line 183
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/a;

    .line 184
    .line 185
    iget-object v0, v0, Lcom/transsnet/palmpay/core/viewmodel/a;->a:Lcom/transsnet/palmpay/core/viewmodel/ActivityWebView;

    .line 186
    .line 187
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    :cond_3
    return-void

    .line 195
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
