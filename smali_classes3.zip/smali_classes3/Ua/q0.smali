.class public final LUa/q0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:I

.field public final synthetic e:Z

.field public final synthetic f:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

.field public final synthetic g:Z


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;Ljava/lang/String;IZLcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;Z)V
    .locals 0

    .line 1
    iput-object p2, p0, LUa/q0;->c:Ljava/lang/String;

    .line 2
    .line 3
    iput p3, p0, LUa/q0;->d:I

    .line 4
    .line 5
    iput-boolean p4, p0, LUa/q0;->e:Z

    .line 6
    .line 7
    iput-object p5, p0, LUa/q0;->f:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 8
    .line 9
    iput-boolean p6, p0, LUa/q0;->g:Z

    .line 10
    .line 11
    const/4 p2, 0x2

    .line 12
    invoke-direct {p0, p2, p1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 7

    .line 1
    new-instance v0, LUa/q0;

    .line 2
    .line 3
    iget v3, p0, LUa/q0;->d:I

    .line 4
    .line 5
    iget-boolean v4, p0, LUa/q0;->e:Z

    .line 6
    .line 7
    iget-object v2, p0, LUa/q0;->c:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v5, p0, LUa/q0;->f:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 10
    .line 11
    iget-boolean v6, p0, LUa/q0;->g:Z

    .line 12
    .line 13
    move-object v1, p2

    .line 14
    invoke-direct/range {v0 .. v6}, LUa/q0;-><init>(Lkotlin/coroutines/Continuation;Ljava/lang/String;IZLcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;Z)V

    .line 15
    .line 16
    .line 17
    iput-object p1, v0, LUa/q0;->b:Ljava/lang/Object;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/q0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/q0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/q0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LUa/q0;->a:I

    .line 4
    .line 5
    iget-object v2, p0, LUa/q0;->f:Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x3

    .line 9
    const/4 v5, 0x2

    .line 10
    const/4 v6, 0x1

    .line 11
    if-eqz v1, :cond_3

    .line 12
    .line 13
    if-eq v1, v6, :cond_2

    .line 14
    .line 15
    if-eq v1, v5, :cond_1

    .line 16
    .line 17
    if-ne v1, v4, :cond_0

    .line 18
    .line 19
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    goto/16 :goto_6

    .line 23
    .line 24
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 25
    .line 26
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 27
    .line 28
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1

    .line 32
    :cond_1
    iget-object v1, p0, LUa/q0;->b:Ljava/lang/Object;

    .line 33
    .line 34
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_4

    .line 38
    :cond_2
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    goto :goto_2

    .line 44
    :cond_3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    iget-object p1, p0, LUa/q0;->b:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 50
    .line 51
    :try_start_1
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 52
    .line 53
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 54
    .line 55
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 58
    .line 59
    iget-object v1, p0, LUa/q0;->c:Ljava/lang/String;

    .line 60
    .line 61
    iget v7, p0, LUa/q0;->d:I

    .line 62
    .line 63
    iput v6, p0, LUa/q0;->a:I

    .line 64
    .line 65
    invoke-interface {p1, v1, v7, p0}, Lcom/transsnet/palmpay/core/network/PayApiService;->getSmsChannelVM(Ljava/lang/String;ILkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    if-ne p1, v0, :cond_4

    .line 70
    .line 71
    goto :goto_5

    .line 72
    :cond_4
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 73
    .line 74
    sget-object v1, Lxf/q;->a:Lxf/o;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 75
    .line 76
    :goto_1
    move-object v1, p1

    .line 77
    goto :goto_3

    .line 78
    :goto_2
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 79
    .line 80
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    goto :goto_1

    .line 85
    :goto_3
    instance-of p1, v1, Lxf/p;

    .line 86
    .line 87
    if-nez p1, :cond_5

    .line 88
    .line 89
    move-object p1, v1

    .line 90
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 91
    .line 92
    sget-object v6, LWf/I;->a:Lcg/f;

    .line 93
    .line 94
    sget-object v6, Lag/o;->a:LWf/p0;

    .line 95
    .line 96
    new-instance v7, LUa/o0;

    .line 97
    .line 98
    iget-boolean v8, p0, LUa/q0;->e:Z

    .line 99
    .line 100
    invoke-direct {v7, p1, v3, v8, v2}, LUa/o0;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;ZLcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;)V

    .line 101
    .line 102
    .line 103
    iput-object v1, p0, LUa/q0;->b:Ljava/lang/Object;

    .line 104
    .line 105
    iput v5, p0, LUa/q0;->a:I

    .line 106
    .line 107
    invoke-static {v6, v7, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    if-ne p1, v0, :cond_5

    .line 112
    .line 113
    goto :goto_5

    .line 114
    :cond_5
    :goto_4
    invoke-static {v1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    if-eqz p1, :cond_6

    .line 119
    .line 120
    sget-object v5, LWf/I;->a:Lcg/f;

    .line 121
    .line 122
    sget-object v5, Lag/o;->a:LWf/p0;

    .line 123
    .line 124
    new-instance v6, LUa/p0;

    .line 125
    .line 126
    iget-boolean v7, p0, LUa/q0;->g:Z

    .line 127
    .line 128
    invoke-direct {v6, p1, v3, v7, v2}, LUa/p0;-><init>(Ljava/lang/Throwable;Lkotlin/coroutines/Continuation;ZLcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;)V

    .line 129
    .line 130
    .line 131
    iput-object v1, p0, LUa/q0;->b:Ljava/lang/Object;

    .line 132
    .line 133
    iput v4, p0, LUa/q0;->a:I

    .line 134
    .line 135
    invoke-static {v5, v6, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    if-ne p1, v0, :cond_6

    .line 140
    .line 141
    :goto_5
    return-object v0

    .line 142
    :cond_6
    :goto_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 143
    .line 144
    return-object p1
.end method
