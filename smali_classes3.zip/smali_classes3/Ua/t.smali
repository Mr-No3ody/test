.class public final LUa/t;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;

.field public final synthetic d:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

.field public final synthetic e:Lkotlin/jvm/functions/Function0;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/t;->b:Ljava/lang/String;

    .line 2
    .line 3
    iput-object p3, p0, LUa/t;->c:Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;

    .line 4
    .line 5
    iput-object p4, p0, LUa/t;->d:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 6
    .line 7
    iput-object p5, p0, LUa/t;->e:Lkotlin/jvm/functions/Function0;

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 6

    .line 1
    new-instance v0, LUa/t;

    .line 2
    .line 3
    iget-object v5, p0, LUa/t;->e:Lkotlin/jvm/functions/Function0;

    .line 4
    .line 5
    iget-object v3, p0, LUa/t;->c:Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;

    .line 6
    .line 7
    iget-object v1, p0, LUa/t;->b:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v4, p0, LUa/t;->d:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 10
    .line 11
    move-object v2, p2

    .line 12
    invoke-direct/range {v0 .. v5}, LUa/t;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;Lkotlin/jvm/functions/Function0;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/t;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/t;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/t;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LUa/t;->a:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->isConnected()Z

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    if-nez p1, :cond_2

    .line 30
    .line 31
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 32
    .line 33
    return-object p1

    .line 34
    :cond_2
    new-instance p1, Lkotlin/jvm/internal/F;

    .line 35
    .line 36
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 37
    .line 38
    .line 39
    const-string v1, ""

    .line 40
    .line 41
    iput-object v1, p1, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 42
    .line 43
    new-instance v1, LUa/r;

    .line 44
    .line 45
    iget-object v3, p0, LUa/t;->c:Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;

    .line 46
    .line 47
    iget-object v4, p0, LUa/t;->b:Ljava/lang/String;

    .line 48
    .line 49
    const/4 v5, 0x0

    .line 50
    invoke-direct {v1, v4, p1, v5, v3}, LUa/r;-><init>(Ljava/lang/String;Lkotlin/jvm/internal/F;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/bean/req/QueryCouponStatisticsReq;)V

    .line 51
    .line 52
    .line 53
    new-instance p1, Lkotlinx/coroutines/flow/T;

    .line 54
    .line 55
    invoke-direct {p1, v1}, Lkotlinx/coroutines/flow/T;-><init>(Lkotlin/jvm/functions/Function2;)V

    .line 56
    .line 57
    .line 58
    sget-object v1, LWf/I;->a:Lcg/f;

    .line 59
    .line 60
    sget-object v1, Lcg/e;->c:Lcg/e;

    .line 61
    .line 62
    invoke-static {p1, v1}, Lkotlinx/coroutines/flow/X;->n(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/CoroutineContext;)Lkotlinx/coroutines/flow/Flow;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    new-instance v1, LMa/l;

    .line 67
    .line 68
    iget-object v3, p0, LUa/t;->d:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 69
    .line 70
    invoke-direct {v1, v5, v3}, LMa/l;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;)V

    .line 71
    .line 72
    .line 73
    new-instance v4, Lkotlinx/coroutines/flow/u;

    .line 74
    .line 75
    invoke-direct {v4, p1, v1}, Lkotlinx/coroutines/flow/u;-><init>(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function3;)V

    .line 76
    .line 77
    .line 78
    new-instance p1, LUa/s;

    .line 79
    .line 80
    iget-object v1, p0, LUa/t;->e:Lkotlin/jvm/functions/Function0;

    .line 81
    .line 82
    invoke-direct {p1, v5, v3, v1}, LUa/s;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;Lkotlin/jvm/functions/Function0;)V

    .line 83
    .line 84
    .line 85
    iput v2, p0, LUa/t;->a:I

    .line 86
    .line 87
    invoke-static {v4, p1, p0}, Lkotlinx/coroutines/flow/X;->g(Lkotlinx/coroutines/flow/Flow;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    if-ne p1, v0, :cond_3

    .line 92
    .line 93
    return-object v0

    .line 94
    :cond_3
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 95
    .line 96
    return-object p1
.end method
