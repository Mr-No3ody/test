.class public final LUa/y0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p2, p0, LUa/y0;->c:Ljava/lang/String;

    .line 2
    .line 3
    iput-object p3, p0, LUa/y0;->d:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p4, p0, LUa/y0;->e:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p1, p0, LUa/y0;->f:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p5}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 6

    .line 1
    new-instance v0, LUa/y0;

    .line 2
    .line 3
    iget-object v2, p0, LUa/y0;->c:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v3, p0, LUa/y0;->d:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v4, p0, LUa/y0;->e:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v1, p0, LUa/y0;->f:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 10
    .line 11
    move-object v5, p2

    .line 12
    invoke-direct/range {v0 .. v5}, LUa/y0;-><init>(Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    iput-object p1, v0, LUa/y0;->b:Ljava/lang/Object;

    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/y0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/y0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/y0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LUa/y0;->a:I

    .line 4
    .line 5
    iget-object v2, p0, LUa/y0;->f:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x3

    .line 9
    const/4 v5, 0x2

    .line 10
    const/4 v6, 0x1

    .line 11
    if-eqz v1, :cond_3

    .line 12
    .line 13
    if-eq v1, v6, :cond_2

    .line 14
    .line 15
    if-eq v1, v5, :cond_1

    .line 16
    .line 17
    if-ne v1, v4, :cond_0

    .line 18
    .line 19
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    goto/16 :goto_6

    .line 23
    .line 24
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 25
    .line 26
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 27
    .line 28
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1

    .line 32
    :cond_1
    iget-object v1, p0, LUa/y0;->b:Ljava/lang/Object;

    .line 33
    .line 34
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_4

    .line 38
    :cond_2
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    goto :goto_2

    .line 44
    :cond_3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    iget-object p1, p0, LUa/y0;->b:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 50
    .line 51
    :try_start_1
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 52
    .line 53
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 54
    .line 55
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 58
    .line 59
    new-instance v1, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardsReq;

    .line 60
    .line 61
    iget-object v7, p0, LUa/y0;->c:Ljava/lang/String;

    .line 62
    .line 63
    iget-object v8, p0, LUa/y0;->d:Ljava/lang/String;

    .line 64
    .line 65
    iget-object v9, p0, LUa/y0;->e:Ljava/lang/String;

    .line 66
    .line 67
    invoke-direct {v1, v7, v8, v9}, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardsReq;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    iput v6, p0, LUa/y0;->a:I

    .line 71
    .line 72
    invoke-interface {p1, v1, p0}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryOrderResultRewards(Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardsReq;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    if-ne p1, v0, :cond_4

    .line 77
    .line 78
    goto :goto_5

    .line 79
    :cond_4
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 80
    .line 81
    sget-object v1, Lxf/q;->a:Lxf/o;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 82
    .line 83
    :goto_1
    move-object v1, p1

    .line 84
    goto :goto_3

    .line 85
    :goto_2
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 86
    .line 87
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    goto :goto_1

    .line 92
    :goto_3
    instance-of p1, v1, Lxf/p;

    .line 93
    .line 94
    if-nez p1, :cond_5

    .line 95
    .line 96
    move-object p1, v1

    .line 97
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 98
    .line 99
    sget-object v6, LWf/I;->a:Lcg/f;

    .line 100
    .line 101
    sget-object v6, Lag/o;->a:LWf/p0;

    .line 102
    .line 103
    new-instance v7, LUa/w0;

    .line 104
    .line 105
    invoke-direct {v7, p1, v3, v2}, LUa/w0;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V

    .line 106
    .line 107
    .line 108
    iput-object v1, p0, LUa/y0;->b:Ljava/lang/Object;

    .line 109
    .line 110
    iput v5, p0, LUa/y0;->a:I

    .line 111
    .line 112
    invoke-static {v6, v7, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    if-ne p1, v0, :cond_5

    .line 117
    .line 118
    goto :goto_5

    .line 119
    :cond_5
    :goto_4
    invoke-static {v1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    if-eqz p1, :cond_6

    .line 124
    .line 125
    sget-object v5, LWf/I;->a:Lcg/f;

    .line 126
    .line 127
    sget-object v5, Lag/o;->a:LWf/p0;

    .line 128
    .line 129
    new-instance v6, LUa/x0;

    .line 130
    .line 131
    invoke-direct {v6, p1, v3, v2}, LUa/x0;-><init>(Ljava/lang/Throwable;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V

    .line 132
    .line 133
    .line 134
    iput-object v1, p0, LUa/y0;->b:Ljava/lang/Object;

    .line 135
    .line 136
    iput v4, p0, LUa/y0;->a:I

    .line 137
    .line 138
    invoke-static {v5, v6, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    if-ne p1, v0, :cond_6

    .line 143
    .line 144
    :goto_5
    return-object v0

    .line 145
    :cond_6
    :goto_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 146
    .line 147
    return-object p1
.end method
