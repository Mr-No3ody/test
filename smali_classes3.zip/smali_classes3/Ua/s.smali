.class public final LUa/s;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public synthetic a:Ljava/lang/Object;

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

.field public final synthetic c:Lkotlin/jvm/functions/Function0;


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    .line 1
    iput-object p2, p0, LUa/s;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 2
    .line 3
    iput-object p3, p0, LUa/s;->c:Lkotlin/jvm/functions/Function0;

    .line 4
    .line 5
    const/4 p2, 0x2

    .line 6
    invoke-direct {p0, p2, p1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance v0, LUa/s;

    .line 2
    .line 3
    iget-object v1, p0, LUa/s;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 4
    .line 5
    iget-object v2, p0, LUa/s;->c:Lkotlin/jvm/functions/Function0;

    .line 6
    .line 7
    invoke-direct {v0, p2, v1, v2}, LUa/s;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;Lkotlin/jvm/functions/Function0;)V

    .line 8
    .line 9
    .line 10
    iput-object p1, v0, LUa/s;->a:Ljava/lang/Object;

    .line 11
    .line 12
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/s;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/s;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/s;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LUa/s;->a:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 9
    .line 10
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryUserCouponsRsp;

    .line 11
    .line 12
    iget-object v0, p0, LUa/s;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;

    .line 13
    .line 14
    invoke-static {v0}, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->b(Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;)Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;->c(Z)V

    .line 20
    .line 21
    .line 22
    if-eqz p1, :cond_1

    .line 23
    .line 24
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryUserCouponsRsp;->getData()Lcom/transsnet/palmpay/core/bean/rsp/QueryUserCouponsRsp$DataBean;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    if-eqz p1, :cond_1

    .line 29
    .line 30
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryUserCouponsRsp$DataBean;->getList()Ljava/util/List;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    if-eqz p1, :cond_1

    .line 35
    .line 36
    iget-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->f:Ljava/util/ArrayList;

    .line 37
    .line 38
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 39
    .line 40
    .line 41
    iget-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->f:Ljava/util/ArrayList;

    .line 42
    .line 43
    check-cast p1, Ljava/util/Collection;

    .line 44
    .line 45
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 46
    .line 47
    .line 48
    invoke-static {v0}, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->b(Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;)Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    iget-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->f:Ljava/util/ArrayList;

    .line 53
    .line 54
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/core/viewmodel/ModelCouponListItemView;->d(Ljava/util/List;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, LUa/s;->c:Lkotlin/jvm/functions/Function0;

    .line 58
    .line 59
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    iget-object p1, v0, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->f:Ljava/util/ArrayList;

    .line 63
    .line 64
    if-eqz p1, :cond_1

    .line 65
    .line 66
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    if-eqz p1, :cond_0

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_0
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailableCouponItem;->f()V

    .line 74
    .line 75
    .line 76
    :cond_1
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 77
    .line 78
    return-object p1
.end method
