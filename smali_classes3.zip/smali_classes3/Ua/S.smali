.class public final LUa/S;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/bean/CommonResult;

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/S;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    iput-object p3, p0, LUa/S;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LUa/S;

    .line 2
    .line 3
    iget-object v0, p0, LUa/S;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 4
    .line 5
    iget-object v1, p0, LUa/S;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;

    .line 6
    .line 7
    invoke-direct {p1, v0, p2, v1}, LUa/S;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/S;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/S;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/S;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LUa/S;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 7
    .line 8
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_c

    .line 15
    .line 16
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;->title:Ljava/lang/String;

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    move-object v0, v1

    .line 27
    :goto_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    iget-object v2, p0, LUa/S;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;

    .line 32
    .line 33
    if-nez v0, :cond_2

    .line 34
    .line 35
    invoke-static {v2}, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->f(Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)Landroid/widget/TextView;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    iget-object v3, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v3, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;

    .line 42
    .line 43
    if-eqz v3, :cond_1

    .line 44
    .line 45
    iget-object v3, v3, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;->title:Ljava/lang/String;

    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_1
    move-object v3, v1

    .line 49
    :goto_1
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 50
    .line 51
    .line 52
    :cond_2
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v0, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;

    .line 55
    .line 56
    if-eqz v0, :cond_3

    .line 57
    .line 58
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;->ruleContent:Ljava/lang/String;

    .line 59
    .line 60
    goto :goto_2

    .line 61
    :cond_3
    move-object v0, v1

    .line 62
    :goto_2
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    const/4 v3, 0x0

    .line 67
    const/4 v4, 0x1

    .line 68
    if-nez v0, :cond_5

    .line 69
    .line 70
    invoke-static {v2}, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->e(Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    if-eqz v0, :cond_4

    .line 75
    .line 76
    invoke-static {v0, v4}, Loa/h;->s(Landroid/view/View;Z)V

    .line 77
    .line 78
    .line 79
    :cond_4
    invoke-static {v2}, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->e(Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    if-eqz v0, :cond_6

    .line 84
    .line 85
    new-instance v5, LC9/V;

    .line 86
    .line 87
    const/4 v6, 0x3

    .line 88
    invoke-direct {v5, v6, v2, p1}, LC9/V;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v0, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 92
    .line 93
    .line 94
    goto :goto_3

    .line 95
    :cond_5
    invoke-static {v2}, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->e(Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    if-eqz v0, :cond_6

    .line 100
    .line 101
    invoke-static {v0, v3}, Loa/h;->s(Landroid/view/View;Z)V

    .line 102
    .line 103
    .line 104
    :cond_6
    :goto_3
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v0, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;

    .line 107
    .line 108
    if-eqz v0, :cond_c

    .line 109
    .line 110
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;->items:Ljava/util/List;

    .line 111
    .line 112
    if-eqz v0, :cond_c

    .line 113
    .line 114
    move-object v5, v0

    .line 115
    check-cast v5, Ljava/util/Collection;

    .line 116
    .line 117
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    .line 118
    .line 119
    .line 120
    move-result v6

    .line 121
    if-nez v6, :cond_7

    .line 122
    .line 123
    goto :goto_4

    .line 124
    :cond_7
    const/16 v3, 0x8

    .line 125
    .line 126
    :goto_4
    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 127
    .line 128
    .line 129
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 130
    .line 131
    .line 132
    move-result v3

    .line 133
    if-lez v3, :cond_a

    .line 134
    .line 135
    check-cast v0, Ljava/lang/Iterable;

    .line 136
    .line 137
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    :goto_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 142
    .line 143
    .line 144
    move-result v3

    .line 145
    if-eqz v3, :cond_a

    .line 146
    .line 147
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v3

    .line 151
    check-cast v3, Lcom/transsnet/palmpay/core/bean/FlashSaleItemBean;

    .line 152
    .line 153
    iget-object v6, v3, Lcom/transsnet/palmpay/core/bean/FlashSaleItemBean;->saleCountdown:Ljava/lang/Long;

    .line 154
    .line 155
    const-wide/16 v7, 0x0

    .line 156
    .line 157
    if-eqz v6, :cond_8

    .line 158
    .line 159
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 160
    .line 161
    .line 162
    move-result-wide v9

    .line 163
    goto :goto_6

    .line 164
    :cond_8
    move-wide v9, v7

    .line 165
    :goto_6
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 166
    .line 167
    .line 168
    move-result-wide v11

    .line 169
    add-long/2addr v11, v9

    .line 170
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 171
    .line 172
    .line 173
    move-result-object v6

    .line 174
    iput-object v6, v3, Lcom/transsnet/palmpay/core/bean/FlashSaleItemBean;->endDownTime:Ljava/lang/Long;

    .line 175
    .line 176
    iget-object v6, v3, Lcom/transsnet/palmpay/core/bean/FlashSaleItemBean;->countdownShowTime:Ljava/lang/Long;

    .line 177
    .line 178
    if-eqz v6, :cond_9

    .line 179
    .line 180
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 181
    .line 182
    .line 183
    move-result-wide v7

    .line 184
    :cond_9
    sub-long/2addr v11, v7

    .line 185
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 186
    .line 187
    .line 188
    move-result-object v6

    .line 189
    iput-object v6, v3, Lcom/transsnet/palmpay/core/bean/FlashSaleItemBean;->startDownTime:Ljava/lang/Long;

    .line 190
    .line 191
    goto :goto_5

    .line 192
    :cond_a
    invoke-static {v2}, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->d(Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;)LUa/O;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    invoke-virtual {v0, v5}, LM1/j;->setList(Ljava/util/Collection;)V

    .line 197
    .line 198
    .line 199
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 200
    .line 201
    check-cast p1, Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;

    .line 202
    .line 203
    iget-object v0, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->g:LWf/t0;

    .line 204
    .line 205
    if-eqz v0, :cond_b

    .line 206
    .line 207
    invoke-virtual {v0}, LWf/n0;->isActive()Z

    .line 208
    .line 209
    .line 210
    move-result v0

    .line 211
    if-ne v0, v4, :cond_b

    .line 212
    .line 213
    iget-object v0, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->g:LWf/t0;

    .line 214
    .line 215
    if-eqz v0, :cond_b

    .line 216
    .line 217
    invoke-virtual {v0, v1}, LWf/n0;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 218
    .line 219
    .line 220
    :cond_b
    invoke-virtual {v2, p1}, Lcom/transsnet/palmpay/core/viewmodel/ModelDataPlanFlashSaleItem;->g(Lcom/transsnet/palmpay/core/bean/FlashSaleDataBundleBeanV2;)V

    .line 221
    .line 222
    .line 223
    :cond_c
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 224
    .line 225
    return-object p1
.end method
