.class public final synthetic LUa/d0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;I)V
    .locals 0

    .line 1
    iput p2, p0, LUa/d0;->a:I

    iput-object p1, p0, LUa/d0;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    iget p1, p0, LUa/d0;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LUa/d0;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;

    .line 7
    .line 8
    iget-object v0, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;->o:Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem$OnCheckedChangeListener;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-boolean p1, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;->j:Z

    .line 13
    .line 14
    xor-int/lit8 p1, p1, 0x1

    .line 15
    .line 16
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem$OnCheckedChangeListener;->onCheckedChanged(Z)V

    .line 17
    .line 18
    .line 19
    :cond_0
    return-void

    .line 20
    :pswitch_0
    iget-object p1, p0, LUa/d0;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;

    .line 21
    .line 22
    iget-object v0, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;->i:Lma/i;

    .line 23
    .line 24
    if-nez v0, :cond_4

    .line 25
    .line 26
    new-instance v0, Lma/i;

    .line 27
    .line 28
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    const-string v2, "getContext(...)"

    .line 33
    .line 34
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string v2, "context"

    .line 38
    .line 39
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-direct {v0, v1}, Lcom/transsnet/palmpay/custom_view/dialog/a;-><init>(Landroid/content/Context;)V

    .line 43
    .line 44
    .line 45
    new-instance v1, Lma/g;

    .line 46
    .line 47
    const/4 v2, 0x0

    .line 48
    invoke-direct {v1, v0, v2}, Lma/g;-><init>(Lma/i;I)V

    .line 49
    .line 50
    .line 51
    invoke-static {v1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    new-instance v2, Lma/g;

    .line 56
    .line 57
    const/4 v3, 0x1

    .line 58
    invoke-direct {v2, v0, v3}, Lma/g;-><init>(Lma/i;I)V

    .line 59
    .line 60
    .line 61
    invoke-static {v2}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    new-instance v3, Lma/g;

    .line 66
    .line 67
    const/4 v4, 0x2

    .line 68
    invoke-direct {v3, v0, v4}, Lma/g;-><init>(Lma/i;I)V

    .line 69
    .line 70
    .line 71
    invoke-static {v3}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    sget v4, Lba/g;->core_dialog_new_early_refund_protocol:I

    .line 76
    .line 77
    invoke-virtual {v0, v4}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->setContentView(I)V

    .line 78
    .line 79
    .line 80
    const/4 v4, 0x0

    .line 81
    invoke-virtual {v0, v4}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->setCancelable(Z)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v0, v4}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->setCanceledOnTouchOutside(Z)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    check-cast v3, Landroid/widget/ImageView;

    .line 92
    .line 93
    if-eqz v3, :cond_1

    .line 94
    .line 95
    new-instance v4, Lma/h;

    .line 96
    .line 97
    const/4 v5, 0x0

    .line 98
    invoke-direct {v4, v0, v5}, Lma/h;-><init>(Lma/i;I)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 102
    .line 103
    .line 104
    :cond_1
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    check-cast v1, Landroid/widget/TextView;

    .line 109
    .line 110
    if-eqz v1, :cond_2

    .line 111
    .line 112
    new-instance v3, Lma/h;

    .line 113
    .line 114
    const/4 v4, 0x1

    .line 115
    invoke-direct {v3, v0, v4}, Lma/h;-><init>(Lma/i;I)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 119
    .line 120
    .line 121
    :cond_2
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    check-cast v1, Lcom/transsnet/palmpay/core/viewmodel/AndroidXWebView;

    .line 126
    .line 127
    if-eqz v1, :cond_3

    .line 128
    .line 129
    const-string v2, "/h5/assurance-agreement"

    .line 130
    .line 131
    invoke-static {v2}, Lcom/transsnet/palmpay/core/config/d;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    invoke-virtual {v1, v2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    :cond_3
    const/high16 v1, 0x44090000    # 548.0f

    .line 139
    .line 140
    invoke-static {v1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 141
    .line 142
    .line 143
    move-result v1

    .line 144
    iput v1, v0, Lcom/transsnet/palmpay/custom_view/dialog/a;->a:I

    .line 145
    .line 146
    iput-object v0, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;->i:Lma/i;

    .line 147
    .line 148
    :cond_4
    iget-object v0, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;->i:Lma/i;

    .line 149
    .line 150
    if-eqz v0, :cond_5

    .line 151
    .line 152
    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    if-nez v0, :cond_5

    .line 157
    .line 158
    iget-object p1, p1, Lcom/transsnet/palmpay/core/viewmodel/ModelNewEarlyRefundItem;->i:Lma/i;

    .line 159
    .line 160
    if-eqz p1, :cond_5

    .line 161
    .line 162
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/a;->show()V

    .line 163
    .line 164
    .line 165
    :cond_5
    return-void

    .line 166
    nop

    .line 167
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
