.class public final LUa/v;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/bean/CommonResult;

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailablePointItem;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailablePointItem;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/v;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    iput-object p3, p0, LUa/v;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailablePointItem;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LUa/v;

    .line 2
    .line 3
    iget-object v0, p0, LUa/v;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 4
    .line 5
    iget-object v1, p0, LUa/v;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailablePointItem;

    .line 6
    .line 7
    invoke-direct {p1, v0, p2, v1}, LUa/v;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/ModelAvailablePointItem;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/v;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/v;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/v;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LUa/v;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 7
    .line 8
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 9
    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x1

    .line 17
    if-ne v0, v1, :cond_0

    .line 18
    .line 19
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 20
    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CorePointInfoBean;

    .line 24
    .line 25
    iget-object v0, p0, LUa/v;->b:Lcom/transsnet/palmpay/core/viewmodel/ModelAvailablePointItem;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 29
    .line 30
    .line 31
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/core/viewmodel/ModelAvailablePointItem;->a(Lcom/transsnet/palmpay/core/viewmodel/ModelAvailablePointItem;Lcom/transsnet/palmpay/core/bean/CorePointInfoBean;)V

    .line 32
    .line 33
    .line 34
    :cond_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 35
    .line 36
    return-object p1
.end method
