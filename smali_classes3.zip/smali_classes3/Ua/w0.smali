.class public final LUa/w0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/bean/CommonResult;

.field public final synthetic b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V
    .locals 0

    .line 1
    iput-object p1, p0, LUa/w0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    iput-object p3, p0, LUa/w0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LUa/w0;

    .line 2
    .line 3
    iget-object v0, p0, LUa/w0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 4
    .line 5
    iget-object v1, p0, LUa/w0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 6
    .line 7
    invoke-direct {p1, v0, p2, v1}, LUa/w0;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LUa/w0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LUa/w0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LUa/w0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget-object v2, LEf/a;->a:LEf/a;

    .line 4
    .line 5
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    iget-object v2, v0, LUa/w0;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 9
    .line 10
    check-cast v2, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 11
    .line 12
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    iget-object v4, v0, LUa/w0;->b:Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;

    .line 17
    .line 18
    if-eqz v3, :cond_13

    .line 19
    .line 20
    iget-object v2, v2, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 21
    .line 22
    if-eqz v2, :cond_13

    .line 23
    .line 24
    check-cast v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardResp;

    .line 25
    .line 26
    sget v3, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->t:I

    .line 27
    .line 28
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    iget-object v3, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardResp;->rewardZoneList:Ljava/util/List;

    .line 32
    .line 33
    check-cast v3, Ljava/util/Collection;

    .line 34
    .line 35
    if-eqz v3, :cond_12

    .line 36
    .line 37
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    if-eqz v3, :cond_0

    .line 42
    .line 43
    goto/16 :goto_7

    .line 44
    .line 45
    :cond_0
    iput-object v2, v4, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->i:Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardResp;

    .line 46
    .line 47
    const/4 v3, 0x0

    .line 48
    invoke-virtual {v4, v3}, Landroid/view/View;->setVisibility(I)V

    .line 49
    .line 50
    .line 51
    iget-object v5, v4, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->c:LBc/b;

    .line 52
    .line 53
    if-eqz v5, :cond_1

    .line 54
    .line 55
    iget-object v6, v5, LBc/b;->c:Landroid/view/View;

    .line 56
    .line 57
    check-cast v6, Landroid/widget/TextView;

    .line 58
    .line 59
    iget-object v7, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardResp;->rewardZoneTitle:Ljava/lang/String;

    .line 60
    .line 61
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 62
    .line 63
    .line 64
    :cond_1
    if-eqz v5, :cond_2

    .line 65
    .line 66
    iget-object v6, v5, LBc/b;->g:Landroid/view/View;

    .line 67
    .line 68
    check-cast v6, Landroid/widget/LinearLayout;

    .line 69
    .line 70
    invoke-static {v6}, Loa/h;->c(Landroid/view/View;)V

    .line 71
    .line 72
    .line 73
    :cond_2
    iget-object v2, v2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardResp;->rewardZoneList:Ljava/util/List;

    .line 74
    .line 75
    iput-object v2, v4, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->d:Ljava/util/List;

    .line 76
    .line 77
    new-instance v2, Ljava/util/ArrayList;

    .line 78
    .line 79
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 80
    .line 81
    .line 82
    iget-object v6, v4, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->d:Ljava/util/List;

    .line 83
    .line 84
    if-eqz v6, :cond_3

    .line 85
    .line 86
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 87
    .line 88
    .line 89
    move-result v6

    .line 90
    goto :goto_0

    .line 91
    :cond_3
    move v6, v3

    .line 92
    :goto_0
    if-gtz v6, :cond_4

    .line 93
    .line 94
    invoke-static {v4}, Loa/h;->c(Landroid/view/View;)V

    .line 95
    .line 96
    .line 97
    goto/16 :goto_8

    .line 98
    .line 99
    :cond_4
    move v7, v3

    .line 100
    :goto_1
    if-ge v7, v6, :cond_8

    .line 101
    .line 102
    iget-object v8, v4, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->d:Ljava/util/List;

    .line 103
    .line 104
    if-eqz v8, :cond_5

    .line 105
    .line 106
    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v8

    .line 110
    check-cast v8, Ljava/util/List;

    .line 111
    .line 112
    goto :goto_2

    .line 113
    :cond_5
    const/4 v8, 0x0

    .line 114
    :goto_2
    new-instance v9, Landroidx/recyclerview/widget/RecyclerView;

    .line 115
    .line 116
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 117
    .line 118
    .line 119
    move-result-object v10

    .line 120
    invoke-direct {v9, v10}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;)V

    .line 121
    .line 122
    .line 123
    new-instance v10, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 124
    .line 125
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 126
    .line 127
    .line 128
    move-result-object v11

    .line 129
    invoke-direct {v10, v11}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v9, v10}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 133
    .line 134
    .line 135
    new-instance v10, LUa/A0;

    .line 136
    .line 137
    invoke-direct {v10}, LUa/A0;-><init>()V

    .line 138
    .line 139
    .line 140
    invoke-virtual {v9, v10}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 141
    .line 142
    .line 143
    new-instance v11, LU8/a;

    .line 144
    .line 145
    const/4 v12, 0x2

    .line 146
    invoke-direct {v11, v12, v10, v4}, LU8/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v10, v11}, LM1/j;->setOnItemChildClickListener(Lcom/chad/library/adapter/base/listener/OnItemChildClickListener;)V

    .line 150
    .line 151
    .line 152
    move-object v11, v8

    .line 153
    check-cast v11, Ljava/util/Collection;

    .line 154
    .line 155
    invoke-virtual {v10, v11}, LM1/j;->setList(Ljava/util/Collection;)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 159
    .line 160
    .line 161
    if-nez v7, :cond_7

    .line 162
    .line 163
    sget v10, Lba/e;->core_order_reward_report:I

    .line 164
    .line 165
    sget-object v11, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 166
    .line 167
    invoke-virtual {v9, v10, v11}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    if-eqz v8, :cond_6

    .line 171
    .line 172
    check-cast v8, Ljava/lang/Iterable;

    .line 173
    .line 174
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 175
    .line 176
    .line 177
    move-result-object v8

    .line 178
    :goto_3
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 179
    .line 180
    .line 181
    move-result v9

    .line 182
    if-eqz v9, :cond_6

    .line 183
    .line 184
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v9

    .line 188
    check-cast v9, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 189
    .line 190
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 191
    .line 192
    .line 193
    move-result-object v10

    .line 194
    iget-object v11, v9, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardType:Ljava/lang/Integer;

    .line 195
    .line 196
    new-instance v12, Lkotlin/Pair;

    .line 197
    .line 198
    const-string v13, "rewardType"

    .line 199
    .line 200
    invoke-direct {v12, v13, v11}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    iget-object v11, v9, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->recordNo:Ljava/lang/String;

    .line 204
    .line 205
    new-instance v13, Lkotlin/Pair;

    .line 206
    .line 207
    const-string v14, "rewardid"

    .line 208
    .line 209
    invoke-direct {v13, v14, v11}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    iget-object v11, v9, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->activityNodeNo:Ljava/lang/String;

    .line 213
    .line 214
    new-instance v14, Lkotlin/Pair;

    .line 215
    .line 216
    const-string v15, "activityNodeNo"

    .line 217
    .line 218
    invoke-direct {v14, v15, v11}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 219
    .line 220
    .line 221
    iget-object v9, v9, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->transType:Ljava/lang/String;

    .line 222
    .line 223
    new-instance v15, Lkotlin/Pair;

    .line 224
    .line 225
    const-string v11, "transtype"

    .line 226
    .line 227
    invoke-direct {v15, v11, v9}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 228
    .line 229
    .line 230
    invoke-static {}, LC0/G;->k()Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object v9

    .line 234
    new-instance v11, Lkotlin/Pair;

    .line 235
    .line 236
    const-string v3, "memberid"

    .line 237
    .line 238
    invoke-direct {v11, v3, v9}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 239
    .line 240
    .line 241
    iget-object v3, v4, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->j:Ljava/lang/String;

    .line 242
    .line 243
    new-instance v9, Lkotlin/Pair;

    .line 244
    .line 245
    const/16 v18, 0x1

    .line 246
    .line 247
    const-string v1, "orderid"

    .line 248
    .line 249
    invoke-direct {v9, v1, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    move-object/from16 v17, v9

    .line 253
    .line 254
    move-object/from16 v16, v11

    .line 255
    .line 256
    filled-new-array/range {v12 .. v17}, [Lkotlin/Pair;

    .line 257
    .line 258
    .line 259
    move-result-object v1

    .line 260
    invoke-static {v1}, Lkotlin/collections/G;->g([Lkotlin/Pair;)Ljava/util/Map;

    .line 261
    .line 262
    .line 263
    move-result-object v1

    .line 264
    const-string v3, "ResultPage_Reward_View"

    .line 265
    .line 266
    invoke-virtual {v10, v3, v1}, LPa/n0;->w(Ljava/lang/String;Ljava/util/Map;)V

    .line 267
    .line 268
    .line 269
    const/4 v3, 0x0

    .line 270
    goto :goto_3

    .line 271
    :cond_6
    const/16 v18, 0x1

    .line 272
    .line 273
    goto :goto_4

    .line 274
    :cond_7
    const/16 v18, 0x1

    .line 275
    .line 276
    sget v1, Lba/e;->core_order_reward_report:I

    .line 277
    .line 278
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 279
    .line 280
    invoke-virtual {v9, v1, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 281
    .line 282
    .line 283
    :goto_4
    add-int/lit8 v7, v7, 0x1

    .line 284
    .line 285
    const/4 v3, 0x0

    .line 286
    goto/16 :goto_1

    .line 287
    .line 288
    :cond_8
    const/16 v18, 0x1

    .line 289
    .line 290
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 291
    .line 292
    .line 293
    move-result v1

    .line 294
    if-lez v1, :cond_14

    .line 295
    .line 296
    if-eqz v5, :cond_9

    .line 297
    .line 298
    iget-object v1, v5, LBc/b;->e:Ljava/lang/Object;

    .line 299
    .line 300
    check-cast v1, Lcom/transsnet/palmpay/custom_view/autoheightviewpager/AutoHeightViewPager;

    .line 301
    .line 302
    new-instance v3, LMb/a;

    .line 303
    .line 304
    invoke-direct {v3}, LMb/a;-><init>()V

    .line 305
    .line 306
    .line 307
    iput-object v3, v4, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->e:LMb/a;

    .line 308
    .line 309
    invoke-virtual {v1, v3}, Lcom/transsnet/palmpay/custom_view/autoheightviewpager/AutoHeightViewPager;->setAdapter(Landroidx/viewpager/widget/a;)V

    .line 310
    .line 311
    .line 312
    :cond_9
    if-eqz v5, :cond_a

    .line 313
    .line 314
    iget-object v1, v5, LBc/b;->e:Ljava/lang/Object;

    .line 315
    .line 316
    check-cast v1, Lcom/transsnet/palmpay/custom_view/autoheightviewpager/AutoHeightViewPager;

    .line 317
    .line 318
    new-instance v3, LUa/z0;

    .line 319
    .line 320
    invoke-direct {v3, v2, v4}, LUa/z0;-><init>(Ljava/util/ArrayList;Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v1, v3}, Landroidx/viewpager/widget/ViewPager;->addOnPageChangeListener(Landroidx/viewpager/widget/ViewPager$OnPageChangeListener;)V

    .line 324
    .line 325
    .line 326
    :cond_a
    iget-object v1, v4, Lcom/transsnet/palmpay/core/viewmodel/OrderResultRewardModel;->e:LMb/a;

    .line 327
    .line 328
    if-eqz v1, :cond_b

    .line 329
    .line 330
    const-string v3, "views"

    .line 331
    .line 332
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    iget-object v3, v1, LMb/a;->c:Ljava/util/ArrayList;

    .line 336
    .line 337
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 338
    .line 339
    .line 340
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 341
    .line 342
    .line 343
    invoke-virtual {v1}, Landroidx/viewpager/widget/a;->i()V

    .line 344
    .line 345
    .line 346
    :cond_b
    if-eqz v5, :cond_c

    .line 347
    .line 348
    iget-object v1, v5, LBc/b;->e:Ljava/lang/Object;

    .line 349
    .line 350
    check-cast v1, Lcom/transsnet/palmpay/custom_view/autoheightviewpager/AutoHeightViewPager;

    .line 351
    .line 352
    invoke-static {v1}, Loa/h;->C(Landroid/view/View;)V

    .line 353
    .line 354
    .line 355
    :cond_c
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 356
    .line 357
    .line 358
    move-result v1

    .line 359
    move/from16 v2, v18

    .line 360
    .line 361
    if-gt v1, v2, :cond_d

    .line 362
    .line 363
    if-eqz v5, :cond_14

    .line 364
    .line 365
    iget-object v1, v5, LBc/b;->b:Landroid/view/ViewGroup;

    .line 366
    .line 367
    check-cast v1, Landroid/widget/LinearLayout;

    .line 368
    .line 369
    const/16 v2, 0x8

    .line 370
    .line 371
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 372
    .line 373
    .line 374
    goto :goto_8

    .line 375
    :cond_d
    if-eqz v5, :cond_e

    .line 376
    .line 377
    iget-object v2, v5, LBc/b;->b:Landroid/view/ViewGroup;

    .line 378
    .line 379
    check-cast v2, Landroid/widget/LinearLayout;

    .line 380
    .line 381
    const/4 v3, 0x0

    .line 382
    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 383
    .line 384
    .line 385
    :cond_e
    if-eqz v5, :cond_f

    .line 386
    .line 387
    iget-object v2, v5, LBc/b;->b:Landroid/view/ViewGroup;

    .line 388
    .line 389
    check-cast v2, Landroid/widget/LinearLayout;

    .line 390
    .line 391
    invoke-virtual {v2}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 392
    .line 393
    .line 394
    :cond_f
    const/4 v3, 0x0

    .line 395
    :goto_5
    if-ge v3, v1, :cond_14

    .line 396
    .line 397
    new-instance v2, Landroid/view/View;

    .line 398
    .line 399
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 400
    .line 401
    .line 402
    move-result-object v6

    .line 403
    invoke-direct {v2, v6}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 404
    .line 405
    .line 406
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    .line 407
    .line 408
    const/16 v7, 0xa

    .line 409
    .line 410
    invoke-static {v7}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 411
    .line 412
    .line 413
    move-result v7

    .line 414
    const/4 v8, 0x3

    .line 415
    invoke-static {v8}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 416
    .line 417
    .line 418
    move-result v8

    .line 419
    invoke-direct {v6, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 420
    .line 421
    .line 422
    const/16 v18, 0x1

    .line 423
    .line 424
    invoke-static/range {v18 .. v18}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 425
    .line 426
    .line 427
    move-result v7

    .line 428
    invoke-static/range {v18 .. v18}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 429
    .line 430
    .line 431
    move-result v8

    .line 432
    const/4 v9, 0x0

    .line 433
    invoke-virtual {v6, v7, v9, v8, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 434
    .line 435
    .line 436
    invoke-virtual {v2, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 437
    .line 438
    .line 439
    if-nez v3, :cond_10

    .line 440
    .line 441
    sget v6, Lcom/transsnet/palmpay/custom_view/r;->cv_button_bg_purple_corner_1:I

    .line 442
    .line 443
    goto :goto_6

    .line 444
    :cond_10
    sget v6, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_rect_corner_12_bg_color_disable:I

    .line 445
    .line 446
    :goto_6
    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    .line 447
    .line 448
    .line 449
    if-eqz v5, :cond_11

    .line 450
    .line 451
    iget-object v6, v5, LBc/b;->b:Landroid/view/ViewGroup;

    .line 452
    .line 453
    check-cast v6, Landroid/widget/LinearLayout;

    .line 454
    .line 455
    invoke-virtual {v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 456
    .line 457
    .line 458
    :cond_11
    const/16 v18, 0x1

    .line 459
    .line 460
    add-int/lit8 v3, v3, 0x1

    .line 461
    .line 462
    goto :goto_5

    .line 463
    :cond_12
    :goto_7
    invoke-static {v4}, Loa/h;->c(Landroid/view/View;)V

    .line 464
    .line 465
    .line 466
    goto :goto_8

    .line 467
    :cond_13
    invoke-static {v4}, Loa/h;->c(Landroid/view/View;)V

    .line 468
    .line 469
    .line 470
    :cond_14
    :goto_8
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 471
    .line 472
    return-object v1
.end method
