.class public final LUa/h0;
.super LM1/j;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/viewmodel/ModelProgressListView;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/ModelProgressListView;)V
    .locals 1

    .line 1
    iput-object p1, p0, LUa/h0;->a:Lcom/transsnet/palmpay/core/viewmodel/ModelProgressListView;

    .line 2
    .line 3
    sget p1, Lba/g;->core_layout_item_progress_list:I

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-direct {p0, p1, v0}, LM1/j;-><init>(ILjava/util/List;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p2, Ljava/lang/String;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "item"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    sget v0, Lba/e;->tv_name:I

    .line 14
    .line 15
    invoke-virtual {p1, v0, p2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 16
    .line 17
    .line 18
    sget p2, Lba/e;->iv_done:I

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 22
    .line 23
    .line 24
    sget p2, Lba/e;->cpi_loading:I

    .line 25
    .line 26
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 27
    .line 28
    .line 29
    sget p2, Lba/e;->tv_name:I

    .line 30
    .line 31
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    sget v1, LL6/b;->ppColorTextDisable:I

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setTextColor(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 42
    .line 43
    .line 44
    iget-object p2, p0, LUa/h0;->a:Lcom/transsnet/palmpay/core/viewmodel/ModelProgressListView;

    .line 45
    .line 46
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/viewmodel/ModelProgressListView;->getProgress()I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getBindingAdapterPosition()I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    const/4 v2, 0x0

    .line 55
    if-ne v0, v1, :cond_0

    .line 56
    .line 57
    sget p2, Lba/e;->cpi_loading:I

    .line 58
    .line 59
    invoke-virtual {p1, p2, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 60
    .line 61
    .line 62
    sget p2, Lba/e;->tv_name:I

    .line 63
    .line 64
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    sget v1, LL6/b;->ppColorTextPrimary:I

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setTextColor(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :cond_0
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/viewmodel/ModelProgressListView;->getProgress()I

    .line 79
    .line 80
    .line 81
    move-result p2

    .line 82
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getBindingAdapterPosition()I

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-le p2, v0, :cond_1

    .line 87
    .line 88
    sget p2, Lba/e;->iv_done:I

    .line 89
    .line 90
    invoke-virtual {p1, p2, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 91
    .line 92
    .line 93
    sget p2, Lba/e;->tv_name:I

    .line 94
    .line 95
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    sget v1, LL6/b;->ppColorTextPrimary:I

    .line 100
    .line 101
    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setTextColor(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 106
    .line 107
    .line 108
    :cond_1
    return-void
.end method
