.class public final LUa/n0;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Z

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ZI)V
    .locals 0

    .line 1
    iput p3, p0, LUa/n0;->f:I

    iput-object p1, p0, LUa/n0;->i:Ljava/lang/Object;

    iput-boolean p2, p0, LUa/n0;->g:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 2

    .line 1
    iget v0, p0, LUa/n0;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->f(Lio/reactivex/disposables/Disposable;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_0
    const-string v0, "d"

    .line 20
    .line 21
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;

    .line 27
    .line 28
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->f(Lio/reactivex/disposables/Disposable;)V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :pswitch_1
    const-string v0, "d"

    .line 33
    .line 34
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    iget-object v0, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;

    .line 40
    .line 41
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->f(Lio/reactivex/disposables/Disposable;)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :pswitch_2
    const-string v0, "d"

    .line 46
    .line 47
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    iget-object v0, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;

    .line 53
    .line 54
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :pswitch_3
    const-string v0, "d"

    .line 59
    .line 60
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    iget-object v0, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;

    .line 66
    .line 67
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :pswitch_4
    const-string v0, "d"

    .line 72
    .line 73
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    iget-object v0, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;

    .line 79
    .line 80
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :pswitch_5
    iget-object v0, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;

    .line 87
    .line 88
    iget-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->j:Lgf/a;

    .line 89
    .line 90
    if-nez v1, :cond_0

    .line 91
    .line 92
    new-instance v1, Lgf/a;

    .line 93
    .line 94
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 95
    .line 96
    .line 97
    iput-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->j:Lgf/a;

    .line 98
    .line 99
    :cond_0
    iget-object v0, v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->j:Lgf/a;

    .line 100
    .line 101
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 102
    .line 103
    .line 104
    return-void

    .line 105
    :pswitch_6
    iget-object v0, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 106
    .line 107
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;

    .line 108
    .line 109
    iget-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->o:Lgf/a;

    .line 110
    .line 111
    if-nez v1, :cond_1

    .line 112
    .line 113
    new-instance v1, Lgf/a;

    .line 114
    .line 115
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 116
    .line 117
    .line 118
    iput-object v1, v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->o:Lgf/a;

    .line 119
    .line 120
    :cond_1
    iget-object v0, v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->o:Lgf/a;

    .line 121
    .line 122
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 123
    .line 124
    .line 125
    return-void

    .line 126
    nop

    .line 127
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 5

    .line 1
    iget-boolean v0, p0, LUa/n0;->g:Z

    .line 2
    .line 3
    const-string v1, "message"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object v3, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 7
    .line 8
    iget v4, p0, LUa/n0;->f:I

    .line 9
    .line 10
    packed-switch v4, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;

    .line 17
    .line 18
    iget v0, v3, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->I0:I

    .line 19
    .line 20
    add-int/lit8 v0, v0, -0x1

    .line 21
    .line 22
    iput v0, v3, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->I0:I

    .line 23
    .line 24
    new-array v0, v2, [Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_0
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;

    .line 34
    .line 35
    invoke-virtual {v3, v2}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 36
    .line 37
    .line 38
    iget v0, v3, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->t:I

    .line 39
    .line 40
    add-int/lit8 v0, v0, -0x1

    .line 41
    .line 42
    iput v0, v3, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->t:I

    .line 43
    .line 44
    new-array v0, v2, [Ljava/lang/Object;

    .line 45
    .line 46
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :pswitch_1
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;

    .line 54
    .line 55
    invoke-virtual {v3, v2}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 56
    .line 57
    .line 58
    iget v0, v3, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->t:I

    .line 59
    .line 60
    add-int/lit8 v0, v0, -0x1

    .line 61
    .line 62
    iput v0, v3, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->t:I

    .line 63
    .line 64
    new-array v0, v2, [Ljava/lang/Object;

    .line 65
    .line 66
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :pswitch_2
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;

    .line 74
    .line 75
    iget v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->o:I

    .line 76
    .line 77
    add-int/lit8 v0, v0, -0x1

    .line 78
    .line 79
    iput v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->o:I

    .line 80
    .line 81
    new-array v0, v2, [Ljava/lang/Object;

    .line 82
    .line 83
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :pswitch_3
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;

    .line 91
    .line 92
    iget v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->g:I

    .line 93
    .line 94
    add-int/lit8 v0, v0, -0x1

    .line 95
    .line 96
    iput v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->g:I

    .line 97
    .line 98
    new-array v0, v2, [Ljava/lang/Object;

    .line 99
    .line 100
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->n()Landroidx/recyclerview/widget/RecyclerView;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :pswitch_4
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;

    .line 115
    .line 116
    iget v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->t:I

    .line 117
    .line 118
    add-int/lit8 v0, v0, -0x1

    .line 119
    .line 120
    iput v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->t:I

    .line 121
    .line 122
    new-array v0, v2, [Ljava/lang/Object;

    .line 123
    .line 124
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->n()Landroidx/recyclerview/widget/RecyclerView;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 132
    .line 133
    .line 134
    return-void

    .line 135
    :pswitch_5
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 136
    .line 137
    .line 138
    if-eqz v0, :cond_0

    .line 139
    .line 140
    sget p1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->B:I

    .line 141
    .line 142
    check-cast v3, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;

    .line 143
    .line 144
    invoke-virtual {v3, v2}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->j(Z)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->l()V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->k()V

    .line 151
    .line 152
    .line 153
    :cond_0
    return-void

    .line 154
    :pswitch_6
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 155
    .line 156
    .line 157
    if-eqz v0, :cond_1

    .line 158
    .line 159
    check-cast v3, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;

    .line 160
    .line 161
    iget-object p1, v3, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->g:Lcom/wang/avi/AVLoadingIndicatorView;

    .line 162
    .line 163
    const/16 v0, 0x8

    .line 164
    .line 165
    invoke-virtual {p1, v0}, Lcom/wang/avi/AVLoadingIndicatorView;->setVisibility(I)V

    .line 166
    .line 167
    .line 168
    iget-object p1, v3, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->d:Landroid/widget/LinearLayout;

    .line 169
    .line 170
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->g()V

    .line 174
    .line 175
    .line 176
    :cond_1
    return-void

    .line 177
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 11

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    const-string v1, "mAdapter"

    .line 4
    .line 5
    const-string v2, "mData"

    .line 6
    .line 7
    const-wide/16 v3, -0x1

    .line 8
    .line 9
    const/4 v5, 0x1

    .line 10
    const/4 v6, 0x0

    .line 11
    iget-boolean v7, p0, LUa/n0;->g:Z

    .line 12
    .line 13
    iget-object v8, p0, LUa/n0;->i:Ljava/lang/Object;

    .line 14
    .line 15
    const/4 v9, 0x0

    .line 16
    iget v10, p0, LUa/n0;->f:I

    .line 17
    .line 18
    packed-switch v10, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;

    .line 22
    .line 23
    check-cast v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;

    .line 24
    .line 25
    if-eqz p1, :cond_18

    .line 26
    .line 27
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-ne v1, v5, :cond_18

    .line 32
    .line 33
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    if-eqz v1, :cond_0

    .line 38
    .line 39
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getTotal()Ljava/lang/Long;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    if-eqz v1, :cond_0

    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 46
    .line 47
    .line 48
    move-result-wide v3

    .line 49
    :cond_0
    iput-wide v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->J0:J

    .line 50
    .line 51
    const-string v1, "mListData"

    .line 52
    .line 53
    const-string v2, "mInstalmentListData"

    .line 54
    .line 55
    if-eqz v7, :cond_3

    .line 56
    .line 57
    iget-object v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->C0:Ljava/util/ArrayList;

    .line 58
    .line 59
    if-eqz v3, :cond_2

    .line 60
    .line 61
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 62
    .line 63
    .line 64
    iget-object v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->D0:Ljava/util/ArrayList;

    .line 65
    .line 66
    if-eqz v3, :cond_1

    .line 67
    .line 68
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 69
    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_1
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    throw v6

    .line 76
    :cond_2
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    throw v6

    .line 80
    :cond_3
    :goto_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    if-eqz v3, :cond_4

    .line 85
    .line 86
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getList()Ljava/util/List;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    goto :goto_1

    .line 91
    :cond_4
    move-object v3, v6

    .line 92
    :goto_1
    check-cast v3, Ljava/util/Collection;

    .line 93
    .line 94
    const-string v4, "99"

    .line 95
    .line 96
    if-eqz v3, :cond_b

    .line 97
    .line 98
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 99
    .line 100
    .line 101
    move-result v3

    .line 102
    if-eqz v3, :cond_5

    .line 103
    .line 104
    goto :goto_5

    .line 105
    :cond_5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    if-eqz p1, :cond_6

    .line 110
    .line 111
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getList()Ljava/util/List;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    goto :goto_2

    .line 116
    :cond_6
    move-object p1, v6

    .line 117
    :goto_2
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    :goto_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 125
    .line 126
    .line 127
    move-result v3

    .line 128
    if-eqz v3, :cond_b

    .line 129
    .line 130
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v3

    .line 134
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListDetail;

    .line 135
    .line 136
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListDetail;->getOperationType()Ljava/lang/Integer;

    .line 137
    .line 138
    .line 139
    move-result-object v5

    .line 140
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 141
    .line 142
    .line 143
    move-result v7

    .line 144
    if-nez v5, :cond_7

    .line 145
    .line 146
    goto :goto_4

    .line 147
    :cond_7
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 148
    .line 149
    .line 150
    move-result v5

    .line 151
    if-ne v5, v7, :cond_9

    .line 152
    .line 153
    iget-object v5, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->D0:Ljava/util/ArrayList;

    .line 154
    .line 155
    if-eqz v5, :cond_8

    .line 156
    .line 157
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    goto :goto_3

    .line 161
    :cond_8
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    throw v6

    .line 165
    :cond_9
    :goto_4
    iget-object v5, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->C0:Ljava/util/ArrayList;

    .line 166
    .line 167
    if-eqz v5, :cond_a

    .line 168
    .line 169
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 170
    .line 171
    .line 172
    goto :goto_3

    .line 173
    :cond_a
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    throw v6

    .line 177
    :cond_b
    :goto_5
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->K0:Ljava/lang/String;

    .line 178
    .line 179
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result p1

    .line 183
    if-eqz p1, :cond_c

    .line 184
    .line 185
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->B()Landroidx/recyclerview/widget/RecyclerView;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 190
    .line 191
    .line 192
    goto :goto_7

    .line 193
    :cond_c
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->C0:Ljava/util/ArrayList;

    .line 194
    .line 195
    if-eqz p1, :cond_17

    .line 196
    .line 197
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 198
    .line 199
    .line 200
    move-result p1

    .line 201
    if-eqz p1, :cond_e

    .line 202
    .line 203
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->D0:Ljava/util/ArrayList;

    .line 204
    .line 205
    if-eqz p1, :cond_d

    .line 206
    .line 207
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 208
    .line 209
    .line 210
    move-result p1

    .line 211
    if-nez p1, :cond_e

    .line 212
    .line 213
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->B()Landroidx/recyclerview/widget/RecyclerView;

    .line 214
    .line 215
    .line 216
    move-result-object p1

    .line 217
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 218
    .line 219
    .line 220
    goto :goto_7

    .line 221
    :cond_d
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    throw v6

    .line 225
    :cond_e
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->C0:Ljava/util/ArrayList;

    .line 226
    .line 227
    if-eqz p1, :cond_16

    .line 228
    .line 229
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 230
    .line 231
    .line 232
    move-result p1

    .line 233
    if-eqz p1, :cond_f

    .line 234
    .line 235
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->B()Landroidx/recyclerview/widget/RecyclerView;

    .line 236
    .line 237
    .line 238
    move-result-object p1

    .line 239
    invoke-virtual {p1, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 240
    .line 241
    .line 242
    goto :goto_6

    .line 243
    :cond_f
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->B()Landroidx/recyclerview/widget/RecyclerView;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    sget v1, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_rect_corner_12_bg_white:I

    .line 248
    .line 249
    invoke-virtual {p1, v1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 250
    .line 251
    .line 252
    :goto_6
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->B()Landroidx/recyclerview/widget/RecyclerView;

    .line 253
    .line 254
    .line 255
    move-result-object p1

    .line 256
    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    .line 257
    .line 258
    .line 259
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->E0:Lyb/l;

    .line 260
    .line 261
    if-eqz p1, :cond_10

    .line 262
    .line 263
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 264
    .line 265
    .line 266
    :cond_10
    :goto_7
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->K0:Ljava/lang/String;

    .line 267
    .line 268
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 269
    .line 270
    .line 271
    move-result p1

    .line 272
    if-nez p1, :cond_12

    .line 273
    .line 274
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->D0:Ljava/util/ArrayList;

    .line 275
    .line 276
    if-eqz p1, :cond_11

    .line 277
    .line 278
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 279
    .line 280
    .line 281
    move-result p1

    .line 282
    if-eqz p1, :cond_12

    .line 283
    .line 284
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->C()Landroidx/recyclerview/widget/RecyclerView;

    .line 285
    .line 286
    .line 287
    move-result-object p1

    .line 288
    if-eqz p1, :cond_1a

    .line 289
    .line 290
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 291
    .line 292
    .line 293
    goto :goto_9

    .line 294
    :cond_11
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    throw v6

    .line 298
    :cond_12
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->D0:Ljava/util/ArrayList;

    .line 299
    .line 300
    if-eqz p1, :cond_15

    .line 301
    .line 302
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 303
    .line 304
    .line 305
    move-result p1

    .line 306
    if-eqz p1, :cond_13

    .line 307
    .line 308
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->C()Landroidx/recyclerview/widget/RecyclerView;

    .line 309
    .line 310
    .line 311
    move-result-object p1

    .line 312
    invoke-virtual {p1, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 313
    .line 314
    .line 315
    goto :goto_8

    .line 316
    :cond_13
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->C()Landroidx/recyclerview/widget/RecyclerView;

    .line 317
    .line 318
    .line 319
    move-result-object p1

    .line 320
    sget v0, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_rect_corner_12_bg_white:I

    .line 321
    .line 322
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    .line 323
    .line 324
    .line 325
    :goto_8
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->C()Landroidx/recyclerview/widget/RecyclerView;

    .line 326
    .line 327
    .line 328
    move-result-object p1

    .line 329
    if-eqz p1, :cond_14

    .line 330
    .line 331
    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    .line 332
    .line 333
    .line 334
    :cond_14
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->F0:Lyb/l;

    .line 335
    .line 336
    if-eqz p1, :cond_1a

    .line 337
    .line 338
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 339
    .line 340
    .line 341
    goto :goto_9

    .line 342
    :cond_15
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 343
    .line 344
    .line 345
    throw v6

    .line 346
    :cond_16
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 347
    .line 348
    .line 349
    throw v6

    .line 350
    :cond_17
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 351
    .line 352
    .line 353
    throw v6

    .line 354
    :cond_18
    iget v0, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->I0:I

    .line 355
    .line 356
    add-int/lit8 v0, v0, -0x1

    .line 357
    .line 358
    iput v0, v8, Lcom/transsnet/palmpay/credit/ui/fragment/OcBillFragment;->I0:I

    .line 359
    .line 360
    if-eqz p1, :cond_19

    .line 361
    .line 362
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 363
    .line 364
    .line 365
    move-result-object v6

    .line 366
    :cond_19
    new-array p1, v9, [Ljava/lang/Object;

    .line 367
    .line 368
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 369
    .line 370
    .line 371
    :cond_1a
    :goto_9
    return-void

    .line 372
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;

    .line 373
    .line 374
    check-cast v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;

    .line 375
    .line 376
    invoke-virtual {v8, v9}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 377
    .line 378
    .line 379
    if-eqz p1, :cond_28

    .line 380
    .line 381
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 382
    .line 383
    .line 384
    move-result v10

    .line 385
    if-ne v10, v5, :cond_28

    .line 386
    .line 387
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 388
    .line 389
    .line 390
    move-result-object v5

    .line 391
    if-eqz v5, :cond_1b

    .line 392
    .line 393
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getTotal()Ljava/lang/Long;

    .line 394
    .line 395
    .line 396
    move-result-object v5

    .line 397
    if-eqz v5, :cond_1b

    .line 398
    .line 399
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 400
    .line 401
    .line 402
    move-result-wide v3

    .line 403
    :cond_1b
    iput-wide v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->v:J

    .line 404
    .line 405
    if-eqz v7, :cond_1d

    .line 406
    .line 407
    iget-object v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->o:Ljava/util/ArrayList;

    .line 408
    .line 409
    if-eqz v3, :cond_1c

    .line 410
    .line 411
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 412
    .line 413
    .line 414
    goto :goto_a

    .line 415
    :cond_1c
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 416
    .line 417
    .line 418
    throw v6

    .line 419
    :cond_1d
    :goto_a
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 420
    .line 421
    .line 422
    move-result-object v3

    .line 423
    if-eqz v3, :cond_1e

    .line 424
    .line 425
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getList()Ljava/util/List;

    .line 426
    .line 427
    .line 428
    move-result-object v3

    .line 429
    goto :goto_b

    .line 430
    :cond_1e
    move-object v3, v6

    .line 431
    :goto_b
    check-cast v3, Ljava/util/Collection;

    .line 432
    .line 433
    iget-object v4, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->j:Lxf/t;

    .line 434
    .line 435
    if-eqz v3, :cond_23

    .line 436
    .line 437
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 438
    .line 439
    .line 440
    move-result v3

    .line 441
    if-eqz v3, :cond_1f

    .line 442
    .line 443
    goto :goto_d

    .line 444
    :cond_1f
    iget-object v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->o:Ljava/util/ArrayList;

    .line 445
    .line 446
    if-eqz v3, :cond_22

    .line 447
    .line 448
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 449
    .line 450
    .line 451
    move-result-object p1

    .line 452
    if-eqz p1, :cond_20

    .line 453
    .line 454
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getList()Ljava/util/List;

    .line 455
    .line 456
    .line 457
    move-result-object p1

    .line 458
    goto :goto_c

    .line 459
    :cond_20
    move-object p1, v6

    .line 460
    :goto_c
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 461
    .line 462
    .line 463
    check-cast p1, Ljava/util/Collection;

    .line 464
    .line 465
    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 466
    .line 467
    .line 468
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->u()Landroidx/recyclerview/widget/RecyclerView;

    .line 469
    .line 470
    .line 471
    move-result-object p1

    .line 472
    if-eqz p1, :cond_21

    .line 473
    .line 474
    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    .line 475
    .line 476
    .line 477
    :cond_21
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 478
    .line 479
    .line 480
    move-result-object p1

    .line 481
    check-cast p1, Landroid/view/View;

    .line 482
    .line 483
    if-eqz p1, :cond_26

    .line 484
    .line 485
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 486
    .line 487
    .line 488
    goto :goto_e

    .line 489
    :cond_22
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 490
    .line 491
    .line 492
    throw v6

    .line 493
    :cond_23
    :goto_d
    if-eqz v7, :cond_26

    .line 494
    .line 495
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->u()Landroidx/recyclerview/widget/RecyclerView;

    .line 496
    .line 497
    .line 498
    move-result-object p1

    .line 499
    if-eqz p1, :cond_24

    .line 500
    .line 501
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 502
    .line 503
    .line 504
    :cond_24
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 505
    .line 506
    .line 507
    move-result-object p1

    .line 508
    check-cast p1, Landroid/view/View;

    .line 509
    .line 510
    if-eqz p1, :cond_25

    .line 511
    .line 512
    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    .line 513
    .line 514
    .line 515
    :cond_25
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 516
    .line 517
    .line 518
    move-result-object p1

    .line 519
    check-cast p1, Landroid/view/View;

    .line 520
    .line 521
    if-eqz p1, :cond_26

    .line 522
    .line 523
    sget v0, LYa/e;->tvTips:I

    .line 524
    .line 525
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 526
    .line 527
    .line 528
    move-result-object p1

    .line 529
    check-cast p1, Landroid/widget/TextView;

    .line 530
    .line 531
    if-eqz p1, :cond_26

    .line 532
    .line 533
    const-string v0, "No Repayment Records"

    .line 534
    .line 535
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 536
    .line 537
    .line 538
    :cond_26
    :goto_e
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->p:Lxb/v;

    .line 539
    .line 540
    if-eqz p1, :cond_27

    .line 541
    .line 542
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 543
    .line 544
    .line 545
    goto :goto_f

    .line 546
    :cond_27
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 547
    .line 548
    .line 549
    throw v6

    .line 550
    :cond_28
    iget v0, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->t:I

    .line 551
    .line 552
    add-int/lit8 v0, v0, -0x1

    .line 553
    .line 554
    iput v0, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLRepaymentListFragment;->t:I

    .line 555
    .line 556
    if-eqz p1, :cond_29

    .line 557
    .line 558
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 559
    .line 560
    .line 561
    move-result-object v6

    .line 562
    :cond_29
    new-array p1, v9, [Ljava/lang/Object;

    .line 563
    .line 564
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 565
    .line 566
    .line 567
    :goto_f
    return-void

    .line 568
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillResp;

    .line 569
    .line 570
    check-cast v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;

    .line 571
    .line 572
    invoke-virtual {v8, v9}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 573
    .line 574
    .line 575
    if-eqz p1, :cond_37

    .line 576
    .line 577
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 578
    .line 579
    .line 580
    move-result v10

    .line 581
    if-ne v10, v5, :cond_37

    .line 582
    .line 583
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillData;

    .line 584
    .line 585
    .line 586
    move-result-object v5

    .line 587
    if-eqz v5, :cond_2a

    .line 588
    .line 589
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillData;->getTotal()Ljava/lang/Long;

    .line 590
    .line 591
    .line 592
    move-result-object v5

    .line 593
    if-eqz v5, :cond_2a

    .line 594
    .line 595
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 596
    .line 597
    .line 598
    move-result-wide v3

    .line 599
    :cond_2a
    iput-wide v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->v:J

    .line 600
    .line 601
    if-eqz v7, :cond_2c

    .line 602
    .line 603
    iget-object v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->o:Ljava/util/ArrayList;

    .line 604
    .line 605
    if-eqz v3, :cond_2b

    .line 606
    .line 607
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 608
    .line 609
    .line 610
    goto :goto_10

    .line 611
    :cond_2b
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 612
    .line 613
    .line 614
    throw v6

    .line 615
    :cond_2c
    :goto_10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillData;

    .line 616
    .line 617
    .line 618
    move-result-object v3

    .line 619
    if-eqz v3, :cond_2d

    .line 620
    .line 621
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillData;->getList()Ljava/util/List;

    .line 622
    .line 623
    .line 624
    move-result-object v3

    .line 625
    goto :goto_11

    .line 626
    :cond_2d
    move-object v3, v6

    .line 627
    :goto_11
    check-cast v3, Ljava/util/Collection;

    .line 628
    .line 629
    iget-object v4, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->i:Lxf/t;

    .line 630
    .line 631
    if-eqz v3, :cond_32

    .line 632
    .line 633
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 634
    .line 635
    .line 636
    move-result v3

    .line 637
    if-eqz v3, :cond_2e

    .line 638
    .line 639
    goto :goto_13

    .line 640
    :cond_2e
    iget-object v3, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->o:Ljava/util/ArrayList;

    .line 641
    .line 642
    if-eqz v3, :cond_31

    .line 643
    .line 644
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillData;

    .line 645
    .line 646
    .line 647
    move-result-object p1

    .line 648
    if-eqz p1, :cond_2f

    .line 649
    .line 650
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLHistoryBillData;->getList()Ljava/util/List;

    .line 651
    .line 652
    .line 653
    move-result-object p1

    .line 654
    goto :goto_12

    .line 655
    :cond_2f
    move-object p1, v6

    .line 656
    :goto_12
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 657
    .line 658
    .line 659
    check-cast p1, Ljava/util/Collection;

    .line 660
    .line 661
    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 662
    .line 663
    .line 664
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->t()Landroidx/recyclerview/widget/RecyclerView;

    .line 665
    .line 666
    .line 667
    move-result-object p1

    .line 668
    if-eqz p1, :cond_30

    .line 669
    .line 670
    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    .line 671
    .line 672
    .line 673
    :cond_30
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 674
    .line 675
    .line 676
    move-result-object p1

    .line 677
    check-cast p1, Landroid/view/View;

    .line 678
    .line 679
    if-eqz p1, :cond_35

    .line 680
    .line 681
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 682
    .line 683
    .line 684
    goto :goto_14

    .line 685
    :cond_31
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 686
    .line 687
    .line 688
    throw v6

    .line 689
    :cond_32
    :goto_13
    if-eqz v7, :cond_35

    .line 690
    .line 691
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->t()Landroidx/recyclerview/widget/RecyclerView;

    .line 692
    .line 693
    .line 694
    move-result-object p1

    .line 695
    if-eqz p1, :cond_33

    .line 696
    .line 697
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 698
    .line 699
    .line 700
    :cond_33
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 701
    .line 702
    .line 703
    move-result-object p1

    .line 704
    check-cast p1, Landroid/view/View;

    .line 705
    .line 706
    if-eqz p1, :cond_34

    .line 707
    .line 708
    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    .line 709
    .line 710
    .line 711
    :cond_34
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 712
    .line 713
    .line 714
    move-result-object p1

    .line 715
    check-cast p1, Landroid/view/View;

    .line 716
    .line 717
    if-eqz p1, :cond_35

    .line 718
    .line 719
    sget v0, LYa/e;->tvTips:I

    .line 720
    .line 721
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 722
    .line 723
    .line 724
    move-result-object p1

    .line 725
    check-cast p1, Landroid/widget/TextView;

    .line 726
    .line 727
    if-eqz p1, :cond_35

    .line 728
    .line 729
    const-string v0, "No Loan Records"

    .line 730
    .line 731
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 732
    .line 733
    .line 734
    :cond_35
    :goto_14
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->p:Lxb/f;

    .line 735
    .line 736
    if-eqz p1, :cond_36

    .line 737
    .line 738
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 739
    .line 740
    .line 741
    goto :goto_15

    .line 742
    :cond_36
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 743
    .line 744
    .line 745
    throw v6

    .line 746
    :cond_37
    iget v0, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->t:I

    .line 747
    .line 748
    add-int/lit8 v0, v0, -0x1

    .line 749
    .line 750
    iput v0, v8, Lcom/transsnet/palmpay/credit/ui/fragment/CLBorrowListFragment;->t:I

    .line 751
    .line 752
    if-eqz p1, :cond_38

    .line 753
    .line 754
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 755
    .line 756
    .line 757
    move-result-object v6

    .line 758
    :cond_38
    new-array p1, v9, [Ljava/lang/Object;

    .line 759
    .line 760
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 761
    .line 762
    .line 763
    :goto_15
    return-void

    .line 764
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;

    .line 765
    .line 766
    check-cast v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;

    .line 767
    .line 768
    if-eqz p1, :cond_42

    .line 769
    .line 770
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 771
    .line 772
    .line 773
    move-result v0

    .line 774
    if-ne v0, v5, :cond_42

    .line 775
    .line 776
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 777
    .line 778
    .line 779
    move-result-object v0

    .line 780
    if-eqz v0, :cond_39

    .line 781
    .line 782
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getTotal()Ljava/lang/Long;

    .line 783
    .line 784
    .line 785
    move-result-object v0

    .line 786
    if-eqz v0, :cond_39

    .line 787
    .line 788
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 789
    .line 790
    .line 791
    move-result-wide v3

    .line 792
    :cond_39
    iput-wide v3, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->p:J

    .line 793
    .line 794
    if-eqz v7, :cond_3b

    .line 795
    .line 796
    iget-object v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->g:Ljava/util/ArrayList;

    .line 797
    .line 798
    if-eqz v0, :cond_3a

    .line 799
    .line 800
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 801
    .line 802
    .line 803
    goto :goto_16

    .line 804
    :cond_3a
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 805
    .line 806
    .line 807
    throw v6

    .line 808
    :cond_3b
    :goto_16
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 809
    .line 810
    .line 811
    move-result-object v0

    .line 812
    if-eqz v0, :cond_3c

    .line 813
    .line 814
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getList()Ljava/util/List;

    .line 815
    .line 816
    .line 817
    move-result-object v0

    .line 818
    goto :goto_17

    .line 819
    :cond_3c
    move-object v0, v6

    .line 820
    :goto_17
    check-cast v0, Ljava/util/Collection;

    .line 821
    .line 822
    if-eqz v0, :cond_40

    .line 823
    .line 824
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 825
    .line 826
    .line 827
    move-result v0

    .line 828
    if-eqz v0, :cond_3d

    .line 829
    .line 830
    goto :goto_19

    .line 831
    :cond_3d
    iget-object v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->g:Ljava/util/ArrayList;

    .line 832
    .line 833
    if-eqz v0, :cond_3f

    .line 834
    .line 835
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 836
    .line 837
    .line 838
    move-result-object p1

    .line 839
    if-eqz p1, :cond_3e

    .line 840
    .line 841
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getList()Ljava/util/List;

    .line 842
    .line 843
    .line 844
    move-result-object p1

    .line 845
    goto :goto_18

    .line 846
    :cond_3e
    move-object p1, v6

    .line 847
    :goto_18
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 848
    .line 849
    .line 850
    check-cast p1, Ljava/util/Collection;

    .line 851
    .line 852
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 853
    .line 854
    .line 855
    goto :goto_19

    .line 856
    :cond_3f
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 857
    .line 858
    .line 859
    throw v6

    .line 860
    :cond_40
    :goto_19
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->i:Lyb/W;

    .line 861
    .line 862
    if-eqz p1, :cond_41

    .line 863
    .line 864
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 865
    .line 866
    .line 867
    goto :goto_1a

    .line 868
    :cond_41
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 869
    .line 870
    .line 871
    throw v6

    .line 872
    :cond_42
    iget v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->o:I

    .line 873
    .line 874
    add-int/lit8 v0, v0, -0x1

    .line 875
    .line 876
    iput v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->o:I

    .line 877
    .line 878
    if-eqz p1, :cond_43

    .line 879
    .line 880
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 881
    .line 882
    .line 883
    move-result-object v6

    .line 884
    :cond_43
    new-array p1, v9, [Ljava/lang/Object;

    .line 885
    .line 886
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 887
    .line 888
    .line 889
    :goto_1a
    return-void

    .line 890
    :pswitch_3
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListResp;

    .line 891
    .line 892
    check-cast v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;

    .line 893
    .line 894
    if-eqz p1, :cond_4d

    .line 895
    .line 896
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 897
    .line 898
    .line 899
    move-result v0

    .line 900
    if-ne v0, v5, :cond_4d

    .line 901
    .line 902
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListData;

    .line 903
    .line 904
    .line 905
    move-result-object v0

    .line 906
    if-eqz v0, :cond_44

    .line 907
    .line 908
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListData;->getTotal()Ljava/lang/Long;

    .line 909
    .line 910
    .line 911
    move-result-object v0

    .line 912
    if-eqz v0, :cond_44

    .line 913
    .line 914
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 915
    .line 916
    .line 917
    move-result-wide v3

    .line 918
    :cond_44
    iput-wide v3, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->i:J

    .line 919
    .line 920
    if-eqz v7, :cond_46

    .line 921
    .line 922
    iget-object v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->e:Ljava/util/ArrayList;

    .line 923
    .line 924
    if-eqz v0, :cond_45

    .line 925
    .line 926
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 927
    .line 928
    .line 929
    goto :goto_1b

    .line 930
    :cond_45
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 931
    .line 932
    .line 933
    throw v6

    .line 934
    :cond_46
    :goto_1b
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListData;

    .line 935
    .line 936
    .line 937
    move-result-object v0

    .line 938
    if-eqz v0, :cond_47

    .line 939
    .line 940
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListData;->getList()Ljava/util/List;

    .line 941
    .line 942
    .line 943
    move-result-object v0

    .line 944
    goto :goto_1c

    .line 945
    :cond_47
    move-object v0, v6

    .line 946
    :goto_1c
    check-cast v0, Ljava/util/Collection;

    .line 947
    .line 948
    if-eqz v0, :cond_4b

    .line 949
    .line 950
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 951
    .line 952
    .line 953
    move-result v0

    .line 954
    if-eqz v0, :cond_48

    .line 955
    .line 956
    goto :goto_1e

    .line 957
    :cond_48
    iget-object v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->e:Ljava/util/ArrayList;

    .line 958
    .line 959
    if-eqz v0, :cond_4a

    .line 960
    .line 961
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListData;

    .line 962
    .line 963
    .line 964
    move-result-object p1

    .line 965
    if-eqz p1, :cond_49

    .line 966
    .line 967
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListData;->getList()Ljava/util/List;

    .line 968
    .line 969
    .line 970
    move-result-object p1

    .line 971
    goto :goto_1d

    .line 972
    :cond_49
    move-object p1, v6

    .line 973
    :goto_1d
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 974
    .line 975
    .line 976
    check-cast p1, Ljava/util/Collection;

    .line 977
    .line 978
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 979
    .line 980
    .line 981
    goto :goto_1e

    .line 982
    :cond_4a
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 983
    .line 984
    .line 985
    throw v6

    .line 986
    :cond_4b
    :goto_1e
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->f:Lyb/n;

    .line 987
    .line 988
    if-eqz p1, :cond_4c

    .line 989
    .line 990
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 991
    .line 992
    .line 993
    goto :goto_1f

    .line 994
    :cond_4c
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 995
    .line 996
    .line 997
    throw v6

    .line 998
    :cond_4d
    iget v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->g:I

    .line 999
    .line 1000
    add-int/lit8 v0, v0, -0x1

    .line 1001
    .line 1002
    iput v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->g:I

    .line 1003
    .line 1004
    if-eqz p1, :cond_4e

    .line 1005
    .line 1006
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 1007
    .line 1008
    .line 1009
    move-result-object v6

    .line 1010
    :cond_4e
    new-array p1, v9, [Ljava/lang/Object;

    .line 1011
    .line 1012
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1013
    .line 1014
    .line 1015
    :goto_1f
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->j:I

    .line 1016
    .line 1017
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->n()Landroidx/recyclerview/widget/RecyclerView;

    .line 1018
    .line 1019
    .line 1020
    move-result-object p1

    .line 1021
    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    .line 1022
    .line 1023
    .line 1024
    return-void

    .line 1025
    :pswitch_4
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;

    .line 1026
    .line 1027
    check-cast v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;

    .line 1028
    .line 1029
    if-eqz p1, :cond_58

    .line 1030
    .line 1031
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 1032
    .line 1033
    .line 1034
    move-result v0

    .line 1035
    if-ne v0, v5, :cond_58

    .line 1036
    .line 1037
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 1038
    .line 1039
    .line 1040
    move-result-object v0

    .line 1041
    if-eqz v0, :cond_4f

    .line 1042
    .line 1043
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getTotal()Ljava/lang/Long;

    .line 1044
    .line 1045
    .line 1046
    move-result-object v0

    .line 1047
    if-eqz v0, :cond_4f

    .line 1048
    .line 1049
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 1050
    .line 1051
    .line 1052
    move-result-wide v3

    .line 1053
    :cond_4f
    iput-wide v3, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->v:J

    .line 1054
    .line 1055
    if-eqz v7, :cond_51

    .line 1056
    .line 1057
    iget-object v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->o:Ljava/util/ArrayList;

    .line 1058
    .line 1059
    if-eqz v0, :cond_50

    .line 1060
    .line 1061
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 1062
    .line 1063
    .line 1064
    goto :goto_20

    .line 1065
    :cond_50
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1066
    .line 1067
    .line 1068
    throw v6

    .line 1069
    :cond_51
    :goto_20
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 1070
    .line 1071
    .line 1072
    move-result-object v0

    .line 1073
    if-eqz v0, :cond_52

    .line 1074
    .line 1075
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getList()Ljava/util/List;

    .line 1076
    .line 1077
    .line 1078
    move-result-object v0

    .line 1079
    goto :goto_21

    .line 1080
    :cond_52
    move-object v0, v6

    .line 1081
    :goto_21
    check-cast v0, Ljava/util/Collection;

    .line 1082
    .line 1083
    if-eqz v0, :cond_56

    .line 1084
    .line 1085
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 1086
    .line 1087
    .line 1088
    move-result v0

    .line 1089
    if-eqz v0, :cond_53

    .line 1090
    .line 1091
    goto :goto_23

    .line 1092
    :cond_53
    iget-object v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->o:Ljava/util/ArrayList;

    .line 1093
    .line 1094
    if-eqz v0, :cond_55

    .line 1095
    .line 1096
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;

    .line 1097
    .line 1098
    .line 1099
    move-result-object p1

    .line 1100
    if-eqz p1, :cond_54

    .line 1101
    .line 1102
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListData;->getList()Ljava/util/List;

    .line 1103
    .line 1104
    .line 1105
    move-result-object p1

    .line 1106
    goto :goto_22

    .line 1107
    :cond_54
    move-object p1, v6

    .line 1108
    :goto_22
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 1109
    .line 1110
    .line 1111
    check-cast p1, Ljava/util/Collection;

    .line 1112
    .line 1113
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 1114
    .line 1115
    .line 1116
    goto :goto_23

    .line 1117
    :cond_55
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1118
    .line 1119
    .line 1120
    throw v6

    .line 1121
    :cond_56
    :goto_23
    iget-object p1, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->p:Lyb/l;

    .line 1122
    .line 1123
    if-eqz p1, :cond_57

    .line 1124
    .line 1125
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 1126
    .line 1127
    .line 1128
    goto :goto_24

    .line 1129
    :cond_57
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1130
    .line 1131
    .line 1132
    throw v6

    .line 1133
    :cond_58
    iget v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->t:I

    .line 1134
    .line 1135
    add-int/lit8 v0, v0, -0x1

    .line 1136
    .line 1137
    iput v0, v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->t:I

    .line 1138
    .line 1139
    if-eqz p1, :cond_59

    .line 1140
    .line 1141
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 1142
    .line 1143
    .line 1144
    move-result-object v6

    .line 1145
    :cond_59
    new-array p1, v9, [Ljava/lang/Object;

    .line 1146
    .line 1147
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1148
    .line 1149
    .line 1150
    :goto_24
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->L:I

    .line 1151
    .line 1152
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillDetailActivity;->n()Landroidx/recyclerview/widget/RecyclerView;

    .line 1153
    .line 1154
    .line 1155
    move-result-object p1

    .line 1156
    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    .line 1157
    .line 1158
    .line 1159
    return-void

    .line 1160
    :pswitch_5
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;

    .line 1161
    .line 1162
    check-cast v8, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;

    .line 1163
    .line 1164
    if-eqz v7, :cond_5a

    .line 1165
    .line 1166
    sget v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->B:I

    .line 1167
    .line 1168
    invoke-virtual {v8, v9}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->j(Z)V

    .line 1169
    .line 1170
    .line 1171
    invoke-virtual {v8}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->l()V

    .line 1172
    .line 1173
    .line 1174
    :cond_5a
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 1175
    .line 1176
    .line 1177
    move-result v0

    .line 1178
    if-eqz v0, :cond_5b

    .line 1179
    .line 1180
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;->data:Ljava/util/List;

    .line 1181
    .line 1182
    iput-object p1, v8, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->t:Ljava/util/List;

    .line 1183
    .line 1184
    :cond_5b
    if-eqz v7, :cond_5c

    .line 1185
    .line 1186
    sget p1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->B:I

    .line 1187
    .line 1188
    invoke-virtual {v8}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->k()V

    .line 1189
    .line 1190
    .line 1191
    :cond_5c
    return-void

    .line 1192
    :pswitch_6
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;

    .line 1193
    .line 1194
    check-cast v8, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;

    .line 1195
    .line 1196
    if-eqz v7, :cond_5d

    .line 1197
    .line 1198
    iget-object v1, v8, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->g:Lcom/wang/avi/AVLoadingIndicatorView;

    .line 1199
    .line 1200
    invoke-virtual {v1, v0}, Lcom/wang/avi/AVLoadingIndicatorView;->setVisibility(I)V

    .line 1201
    .line 1202
    .line 1203
    iget-object v0, v8, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->d:Landroid/widget/LinearLayout;

    .line 1204
    .line 1205
    invoke-virtual {v0, v9}, Landroid/view/View;->setVisibility(I)V

    .line 1206
    .line 1207
    .line 1208
    :cond_5d
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 1209
    .line 1210
    .line 1211
    move-result v0

    .line 1212
    if-eqz v0, :cond_5e

    .line 1213
    .line 1214
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;->data:Ljava/util/List;

    .line 1215
    .line 1216
    iput-object p1, v8, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->v:Ljava/util/List;

    .line 1217
    .line 1218
    :cond_5e
    if-eqz v7, :cond_5f

    .line 1219
    .line 1220
    sget p1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->B:I

    .line 1221
    .line 1222
    invoke-virtual {v8}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->g()V

    .line 1223
    .line 1224
    .line 1225
    :cond_5f
    return-void

    .line 1226
    nop

    .line 1227
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
