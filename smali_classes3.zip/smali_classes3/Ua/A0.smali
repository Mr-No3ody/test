.class public final LUa/A0;
.super LM1/j;
.source "SourceFile"


# instance fields
.field public final a:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    sget v0, Lba/g;->core_item_payment_reward:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {p0, v0, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 5
    .line 6
    .line 7
    sget v0, Lba/e;->tv_btn:I

    .line 8
    .line 9
    filled-new-array {v0}, [I

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {p0, v0}, LM1/j;->addChildClickViewIds([I)V

    .line 14
    .line 15
    .line 16
    invoke-static {}, LPa/i0;->T()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    iput-boolean v0, p0, LUa/A0;->a:Z

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 6

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "item"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    sget v0, Lba/e;->iv_icon:I

    .line 14
    .line 15
    invoke-virtual {p1, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Landroid/widget/ImageView;

    .line 20
    .line 21
    iget-boolean v1, p0, LUa/A0;->a:Z

    .line 22
    .line 23
    if-eqz v1, :cond_0

    .line 24
    .line 25
    iget-object v2, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardDarkIcon:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    if-nez v2, :cond_0

    .line 32
    .line 33
    iget-object v2, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardDarkIcon:Ljava/lang/String;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    iget-object v2, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardIcon:Ljava/lang/String;

    .line 37
    .line 38
    :goto_0
    invoke-static {v2, v0}, LPa/r0;->l1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 39
    .line 40
    .line 41
    if-eqz v1, :cond_1

    .line 42
    .line 43
    iget-object v0, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardTopicDark:Ljava/lang/String;

    .line 44
    .line 45
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-nez v0, :cond_1

    .line 50
    .line 51
    iget-object v0, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardTopicDark:Ljava/lang/String;

    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_1
    iget-object v0, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardTopic:Ljava/lang/String;

    .line 55
    .line 56
    :goto_1
    sget v1, Lba/e;->tv_name:I

    .line 57
    .line 58
    invoke-virtual {p1, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    check-cast v1, Landroid/widget/TextView;

    .line 63
    .line 64
    invoke-static {v0}, Lcom/transsnet/palmpay/custom_view/utils/CommonExtKt;->formatHtmlText(Ljava/lang/String;)Landroid/text/Spanned;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 69
    .line 70
    .line 71
    sget v0, Lba/e;->tv_desc:I

    .line 72
    .line 73
    iget-object v1, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardIntroduce:Ljava/lang/String;

    .line 74
    .line 75
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 76
    .line 77
    .line 78
    iget-object v0, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->btnContentList:Ljava/util/List;

    .line 79
    .line 80
    iget-object p2, p2, Lcom/transsnet/palmpay/core/bean/reward/OrderResultRewardItemBean;->rewardStatus:Ljava/lang/Integer;

    .line 81
    .line 82
    const/4 v1, 0x0

    .line 83
    const/4 v2, 0x0

    .line 84
    if-eqz v0, :cond_5

    .line 85
    .line 86
    check-cast v0, Ljava/lang/Iterable;

    .line 87
    .line 88
    new-instance v3, Ljava/util/ArrayList;

    .line 89
    .line 90
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 91
    .line 92
    .line 93
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    :cond_2
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 98
    .line 99
    .line 100
    move-result v4

    .line 101
    if-eqz v4, :cond_3

    .line 102
    .line 103
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v4

    .line 107
    move-object v5, v4

    .line 108
    check-cast v5, Lcom/transsnet/palmpay/core/bean/reward/BtnContentItem;

    .line 109
    .line 110
    iget-object v5, v5, Lcom/transsnet/palmpay/core/bean/reward/BtnContentItem;->rewardStatus:Ljava/lang/Integer;

    .line 111
    .line 112
    invoke-static {v5, p2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v5

    .line 116
    if-eqz v5, :cond_2

    .line 117
    .line 118
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    goto :goto_2

    .line 122
    :cond_3
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 123
    .line 124
    .line 125
    move-result p2

    .line 126
    if-nez p2, :cond_4

    .line 127
    .line 128
    goto :goto_3

    .line 129
    :cond_4
    move-object v3, v2

    .line 130
    :goto_3
    if-eqz v3, :cond_5

    .line 131
    .line 132
    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object p2

    .line 136
    check-cast p2, Lcom/transsnet/palmpay/core/bean/reward/BtnContentItem;

    .line 137
    .line 138
    goto :goto_4

    .line 139
    :cond_5
    move-object p2, v2

    .line 140
    :goto_4
    sget v0, Lba/e;->tv_btn:I

    .line 141
    .line 142
    invoke-virtual {p1, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    check-cast p1, Landroid/widget/TextView;

    .line 147
    .line 148
    if-eqz p2, :cond_6

    .line 149
    .line 150
    iget-object v2, p2, Lcom/transsnet/palmpay/core/bean/reward/BtnContentItem;->buttonContent:Ljava/lang/String;

    .line 151
    .line 152
    :cond_6
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 153
    .line 154
    .line 155
    if-eqz p2, :cond_7

    .line 156
    .line 157
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    const-string v2, "getContext(...)"

    .line 162
    .line 163
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {p2, v0}, Lcom/transsnet/palmpay/core/bean/reward/BtnContentItem;->getBtnForeground(Landroid/content/Context;)I

    .line 167
    .line 168
    .line 169
    move-result v0

    .line 170
    goto :goto_5

    .line 171
    :cond_7
    sget v0, LL6/b;->ppColorButtonTextWhite:I

    .line 172
    .line 173
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    :goto_5
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 182
    .line 183
    .line 184
    if-eqz p2, :cond_8

    .line 185
    .line 186
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/reward/BtnContentItem;->getBtnBackground()I

    .line 187
    .line 188
    .line 189
    move-result v0

    .line 190
    goto :goto_6

    .line 191
    :cond_8
    sget v0, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_halfround_purple:I

    .line 192
    .line 193
    :goto_6
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    .line 194
    .line 195
    .line 196
    const/4 v0, 0x1

    .line 197
    if-eqz p2, :cond_9

    .line 198
    .line 199
    iget-object p2, p2, Lcom/transsnet/palmpay/core/bean/reward/BtnContentItem;->functionType:Ljava/lang/Integer;

    .line 200
    .line 201
    if-eqz p2, :cond_9

    .line 202
    .line 203
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 204
    .line 205
    .line 206
    move-result p2

    .line 207
    goto :goto_7

    .line 208
    :cond_9
    move p2, v0

    .line 209
    :goto_7
    const/4 v2, 0x3

    .line 210
    if-eq p2, v2, :cond_a

    .line 211
    .line 212
    move v1, v0

    .line 213
    :cond_a
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 214
    .line 215
    .line 216
    return-void
.end method
