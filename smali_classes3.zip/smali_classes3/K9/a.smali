.class public final LK9/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/base/SingleLiveData$Params;


# instance fields
.field public a:Z
