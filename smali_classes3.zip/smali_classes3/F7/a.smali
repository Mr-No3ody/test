.class public final LF7/a;
.super Landroidx/recyclerview/widget/RecyclerView$SimpleOnItemTouchListener;
.source "SourceFile"


# instance fields
.field public final a:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

.field public final b:Landroidx/recyclerview/widget/RecyclerView;

.field public c:I

.field public d:I

.field public e:I


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$SimpleOnItemTouchListener;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, LF7/a;->a:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 5
    .line 6
    iput-object p1, p0, LF7/a;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onInterceptTouchEvent(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)Z
    .locals 6

    .line 1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x1

    .line 10
    const/4 v2, 0x0

    .line 11
    iget-object v3, p0, LF7/a;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 12
    .line 13
    const/high16 v4, 0x3f000000    # 0.5f

    .line 14
    .line 15
    if-eqz p1, :cond_5

    .line 16
    .line 17
    const/4 v5, 0x2

    .line 18
    if-eq p1, v5, :cond_2

    .line 19
    .line 20
    const/4 v5, 0x5

    .line 21
    if-eq p1, v5, :cond_5

    .line 22
    .line 23
    const/4 v0, 0x6

    .line 24
    if-eq p1, v0, :cond_0

    .line 25
    .line 26
    goto/16 :goto_1

    .line 27
    .line 28
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    invoke-virtual {p2, p1}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    iget v3, p0, LF7/a;->c:I

    .line 37
    .line 38
    if-ne v0, v3, :cond_6

    .line 39
    .line 40
    if-nez p1, :cond_1

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    move v1, v2

    .line 44
    :goto_0
    invoke-virtual {p2, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    iput p1, p0, LF7/a;->c:I

    .line 49
    .line 50
    invoke-virtual {p2, v1}, Landroid/view/MotionEvent;->getX(I)F

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    add-float/2addr p1, v4

    .line 55
    float-to-int p1, p1

    .line 56
    iput p1, p0, LF7/a;->d:I

    .line 57
    .line 58
    invoke-virtual {p2, v1}, Landroid/view/MotionEvent;->getY(I)F

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    add-float/2addr p1, v4

    .line 63
    float-to-int p1, p1

    .line 64
    iput p1, p0, LF7/a;->e:I

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :cond_2
    iget p1, p0, LF7/a;->c:I

    .line 68
    .line 69
    invoke-virtual {p2, p1}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 70
    .line 71
    .line 72
    move-result p1

    .line 73
    if-gez p1, :cond_3

    .line 74
    .line 75
    return v2

    .line 76
    :cond_3
    invoke-virtual {p2, p1}, Landroid/view/MotionEvent;->getX(I)F

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    add-float/2addr v0, v4

    .line 81
    float-to-int v0, v0

    .line 82
    invoke-virtual {p2, p1}, Landroid/view/MotionEvent;->getY(I)F

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    add-float/2addr p1, v4

    .line 87
    float-to-int p1, p1

    .line 88
    iget p2, p0, LF7/a;->d:I

    .line 89
    .line 90
    sub-int/2addr v0, p2

    .line 91
    iget p2, p0, LF7/a;->e:I

    .line 92
    .line 93
    sub-int/2addr p1, p2

    .line 94
    iget-object p2, p0, LF7/a;->a:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 95
    .line 96
    invoke-virtual {p2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 97
    .line 98
    .line 99
    move-result v1

    .line 100
    if-eqz v1, :cond_4

    .line 101
    .line 102
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    neg-int v0, v0

    .line 107
    invoke-virtual {v3, v0}, Landroid/view/View;->canScrollHorizontally(I)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    invoke-interface {v1, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 112
    .line 113
    .line 114
    :cond_4
    invoke-virtual {p2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollVertically()Z

    .line 115
    .line 116
    .line 117
    move-result p2

    .line 118
    if-eqz p2, :cond_6

    .line 119
    .line 120
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 121
    .line 122
    .line 123
    move-result-object p2

    .line 124
    neg-int p1, p1

    .line 125
    invoke-virtual {v3, p1}, Landroid/view/View;->canScrollVertically(I)Z

    .line 126
    .line 127
    .line 128
    move-result p1

    .line 129
    invoke-interface {p2, p1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 130
    .line 131
    .line 132
    goto :goto_1

    .line 133
    :cond_5
    invoke-virtual {p2, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 134
    .line 135
    .line 136
    move-result p1

    .line 137
    iput p1, p0, LF7/a;->c:I

    .line 138
    .line 139
    invoke-virtual {p2, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 140
    .line 141
    .line 142
    move-result p1

    .line 143
    add-float/2addr p1, v4

    .line 144
    float-to-int p1, p1

    .line 145
    iput p1, p0, LF7/a;->d:I

    .line 146
    .line 147
    invoke-virtual {p2, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 148
    .line 149
    .line 150
    move-result p1

    .line 151
    add-float/2addr p1, v4

    .line 152
    float-to-int p1, p1

    .line 153
    iput p1, p0, LF7/a;->e:I

    .line 154
    .line 155
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    invoke-interface {p1, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 160
    .line 161
    .line 162
    :cond_6
    :goto_1
    return v2
.end method
