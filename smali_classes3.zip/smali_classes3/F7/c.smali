.class public final LF7/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final a:I

.field public final b:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

.field public final c:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(ILcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, LF7/c;->a:I

    .line 5
    .line 6
    iput-object p2, p0, LF7/c;->b:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 7
    .line 8
    iput-object p3, p0, LF7/c;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    new-instance v0, LF7/d;

    .line 2
    .line 3
    iget-object v1, p0, LF7/c;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    iget-object v2, p0, LF7/c;->b:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2}, LF7/d;-><init>(Landroidx/recyclerview/widget/RecyclerView;Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)V

    .line 8
    .line 9
    .line 10
    iget v1, p0, LF7/c;->a:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView$SmoothScroller;->setTargetPosition(I)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v2, v0}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->startSmoothScroll(Landroidx/recyclerview/widget/RecyclerView$SmoothScroller;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
