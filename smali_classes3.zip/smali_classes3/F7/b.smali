.class public final LF7/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:Z

.field public c:I

.field public d:I

.field public final e:Landroid/graphics/Rect;

.field public f:I

.field public g:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroid/graphics/Rect;

    .line 5
    .line 6
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LF7/b;->e:Landroid/graphics/Rect;

    .line 10
    .line 11
    return-void
.end method

.method public static a(IIIILandroidx/recyclerview/widget/RecyclerView$State;)I
    .locals 1

    .line 1
    mul-int v0, p2, p3

    .line 2
    .line 3
    if-nez p1, :cond_3

    .line 4
    .line 5
    rem-int p1, p0, v0

    .line 6
    .line 7
    add-int/lit8 v0, v0, -0x1

    .line 8
    .line 9
    if-ne p1, v0, :cond_0

    .line 10
    .line 11
    add-int/lit8 p0, p0, 0x1

    .line 12
    .line 13
    return p0

    .line 14
    :cond_0
    rem-int v0, p0, p3

    .line 15
    .line 16
    div-int/2addr p1, p3

    .line 17
    add-int/lit8 p2, p2, -0x1

    .line 18
    .line 19
    if-ne p1, p2, :cond_1

    .line 20
    .line 21
    :goto_0
    mul-int/2addr p1, p3

    .line 22
    sub-int/2addr p0, p1

    .line 23
    add-int/lit8 p0, p0, 0x1

    .line 24
    .line 25
    return p0

    .line 26
    :cond_1
    add-int p2, p0, p3

    .line 27
    .line 28
    invoke-virtual {p4}, Landroidx/recyclerview/widget/RecyclerView$State;->getItemCount()I

    .line 29
    .line 30
    .line 31
    move-result p4

    .line 32
    if-lt p2, p4, :cond_2

    .line 33
    .line 34
    add-int/lit8 p4, p3, -0x1

    .line 35
    .line 36
    if-eq v0, p4, :cond_2

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_2
    return p2

    .line 40
    :cond_3
    add-int/lit8 p0, p0, 0x1

    .line 41
    .line 42
    return p0
.end method

.method public static b(IIII)I
    .locals 1

    .line 1
    mul-int v0, p2, p3

    .line 2
    .line 3
    if-nez p1, :cond_2

    .line 4
    .line 5
    rem-int p1, p0, v0

    .line 6
    .line 7
    if-nez p1, :cond_0

    .line 8
    .line 9
    add-int/lit8 p0, p0, -0x1

    .line 10
    .line 11
    return p0

    .line 12
    :cond_0
    div-int/2addr p1, p3

    .line 13
    if-nez p1, :cond_1

    .line 14
    .line 15
    add-int/lit8 p0, p0, -0x1

    .line 16
    .line 17
    add-int/lit8 p2, p2, -0x1

    .line 18
    .line 19
    mul-int/2addr p2, p3

    .line 20
    add-int/2addr p2, p0

    .line 21
    return p2

    .line 22
    :cond_1
    sub-int/2addr p0, p3

    .line 23
    return p0

    .line 24
    :cond_2
    add-int/lit8 p0, p0, -0x1

    .line 25
    .line 26
    return p0
.end method
