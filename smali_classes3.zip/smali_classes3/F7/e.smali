.class public final LF7/e;
.super Landroidx/recyclerview/widget/SnapHelper;
.source "SourceFile"


# instance fields
.field public a:Landroidx/recyclerview/widget/RecyclerView;

.field public final b:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/SnapHelper;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 5
    .line 6
    const/4 v1, 0x2

    .line 7
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, LF7/e;->b:Ljava/util/ArrayList;

    .line 11
    .line 12
    return-void
.end method

.method public static a(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)I
    .locals 3

    .line 1
    invoke-virtual {p0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingStart()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingTop()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    :goto_0
    invoke-virtual {p0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_1

    .line 21
    .line 22
    invoke-virtual {p0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getWidth()I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingStart()I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    sub-int/2addr v1, v2

    .line 31
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingEnd()I

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    :goto_1
    sub-int/2addr v1, p0

    .line 36
    goto :goto_2

    .line 37
    :cond_1
    invoke-virtual {p0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getHeight()I

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingTop()I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    sub-int/2addr v1, v2

    .line 46
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingBottom()I

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    goto :goto_1

    .line 51
    :goto_2
    div-int/lit8 v1, v1, 0x2

    .line 52
    .line 53
    add-int/2addr v1, v0

    .line 54
    return v1
.end method

.method public static b(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I
    .locals 2

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;

    .line 6
    .line 7
    invoke-virtual {p0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getDecoratedRight(Landroid/view/View;)I

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 18
    .line 19
    :goto_0
    sub-int/2addr p0, p1

    .line 20
    return p0

    .line 21
    :cond_0
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getDecoratedBottom(Landroid/view/View;)I

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 26
    .line 27
    goto :goto_0
.end method

.method public static c(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I
    .locals 2

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView$LayoutParams;

    .line 6
    .line 7
    invoke-virtual {p0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getDecoratedLeft(Landroid/view/View;)I

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 18
    .line 19
    :goto_0
    sub-int/2addr p0, p1

    .line 20
    return p0

    .line 21
    :cond_0
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getDecoratedTop(Landroid/view/View;)I

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 26
    .line 27
    goto :goto_0
.end method


# virtual methods
.method public final attachToRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/SnapHelper;->attachToRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LF7/e;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 5
    .line 6
    return-void
.end method

.method public final calculateDistanceToFinalSnap(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;Landroid/view/View;)[I
    .locals 7

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v0, v0, [I

    .line 3
    .line 4
    invoke-virtual {p1, p2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPosition(Landroid/view/View;)I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    instance-of v2, p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 9
    .line 10
    if-eqz v2, :cond_f

    .line 11
    .line 12
    move-object v2, p1

    .line 13
    check-cast v2, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 14
    .line 15
    invoke-static {v2}, LF7/e;->a(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    new-instance v4, Landroid/graphics/Rect;

    .line 20
    .line 21
    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p1, p2, v4}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getDecoratedBoundsWithMargins(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->p()Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    const/4 v5, 0x0

    .line 32
    iget-object v6, v2, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->w:Landroid/graphics/Rect;

    .line 33
    .line 34
    if-eqz p1, :cond_7

    .line 35
    .line 36
    invoke-static {v2, p2}, LF7/e;->b(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    if-lt p1, v3, :cond_2

    .line 41
    .line 42
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    if-nez p1, :cond_0

    .line 47
    .line 48
    move p1, v5

    .line 49
    goto :goto_0

    .line 50
    :cond_0
    iget p1, v4, Landroid/graphics/Rect;->left:I

    .line 51
    .line 52
    iget p2, v6, Landroid/graphics/Rect;->left:I

    .line 53
    .line 54
    sub-int/2addr p1, p2

    .line 55
    :goto_0
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollVertically()Z

    .line 56
    .line 57
    .line 58
    move-result p2

    .line 59
    if-nez p2, :cond_1

    .line 60
    .line 61
    :goto_1
    move p2, v5

    .line 62
    goto/16 :goto_11

    .line 63
    .line 64
    :cond_1
    iget p2, v4, Landroid/graphics/Rect;->top:I

    .line 65
    .line 66
    iget v3, v6, Landroid/graphics/Rect;->top:I

    .line 67
    .line 68
    :goto_2
    sub-int/2addr p2, v3

    .line 69
    goto/16 :goto_11

    .line 70
    .line 71
    :cond_2
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 72
    .line 73
    .line 74
    move-result p1

    .line 75
    if-nez p1, :cond_3

    .line 76
    .line 77
    move p1, v5

    .line 78
    goto :goto_5

    .line 79
    :cond_3
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 80
    .line 81
    .line 82
    move-result p1

    .line 83
    if-eqz p1, :cond_4

    .line 84
    .line 85
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getWidth()I

    .line 86
    .line 87
    .line 88
    move-result p1

    .line 89
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingEnd()I

    .line 90
    .line 91
    .line 92
    move-result p2

    .line 93
    :goto_3
    sub-int/2addr p1, p2

    .line 94
    goto :goto_4

    .line 95
    :cond_4
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getHeight()I

    .line 96
    .line 97
    .line 98
    move-result p1

    .line 99
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingBottom()I

    .line 100
    .line 101
    .line 102
    move-result p2

    .line 103
    goto :goto_3

    .line 104
    :goto_4
    iget p2, v4, Landroid/graphics/Rect;->left:I

    .line 105
    .line 106
    sub-int/2addr p1, p2

    .line 107
    :goto_5
    neg-int p1, p1

    .line 108
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollVertically()Z

    .line 109
    .line 110
    .line 111
    move-result p2

    .line 112
    if-nez p2, :cond_5

    .line 113
    .line 114
    goto/16 :goto_c

    .line 115
    .line 116
    :cond_5
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 117
    .line 118
    .line 119
    move-result p2

    .line 120
    if-eqz p2, :cond_6

    .line 121
    .line 122
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getWidth()I

    .line 123
    .line 124
    .line 125
    move-result p2

    .line 126
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingEnd()I

    .line 127
    .line 128
    .line 129
    move-result v3

    .line 130
    :goto_6
    sub-int/2addr p2, v3

    .line 131
    goto :goto_7

    .line 132
    :cond_6
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getHeight()I

    .line 133
    .line 134
    .line 135
    move-result p2

    .line 136
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingBottom()I

    .line 137
    .line 138
    .line 139
    move-result v3

    .line 140
    goto :goto_6

    .line 141
    :goto_7
    iget v3, v4, Landroid/graphics/Rect;->top:I

    .line 142
    .line 143
    goto/16 :goto_f

    .line 144
    .line 145
    :cond_7
    invoke-static {v2, p2}, LF7/e;->c(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 146
    .line 147
    .line 148
    move-result p1

    .line 149
    if-gt p1, v3, :cond_a

    .line 150
    .line 151
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 152
    .line 153
    .line 154
    move-result p1

    .line 155
    if-nez p1, :cond_8

    .line 156
    .line 157
    move p1, v5

    .line 158
    goto :goto_8

    .line 159
    :cond_8
    iget p1, v4, Landroid/graphics/Rect;->left:I

    .line 160
    .line 161
    iget p2, v6, Landroid/graphics/Rect;->left:I

    .line 162
    .line 163
    sub-int/2addr p1, p2

    .line 164
    :goto_8
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollVertically()Z

    .line 165
    .line 166
    .line 167
    move-result p2

    .line 168
    if-nez p2, :cond_9

    .line 169
    .line 170
    goto :goto_1

    .line 171
    :cond_9
    iget p2, v4, Landroid/graphics/Rect;->top:I

    .line 172
    .line 173
    iget v3, v6, Landroid/graphics/Rect;->top:I

    .line 174
    .line 175
    goto :goto_2

    .line 176
    :cond_a
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 177
    .line 178
    .line 179
    move-result p1

    .line 180
    if-nez p1, :cond_b

    .line 181
    .line 182
    move p1, v5

    .line 183
    goto :goto_b

    .line 184
    :cond_b
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 185
    .line 186
    .line 187
    move-result p1

    .line 188
    if-eqz p1, :cond_c

    .line 189
    .line 190
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getWidth()I

    .line 191
    .line 192
    .line 193
    move-result p1

    .line 194
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingEnd()I

    .line 195
    .line 196
    .line 197
    move-result p2

    .line 198
    :goto_9
    sub-int/2addr p1, p2

    .line 199
    goto :goto_a

    .line 200
    :cond_c
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getHeight()I

    .line 201
    .line 202
    .line 203
    move-result p1

    .line 204
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingBottom()I

    .line 205
    .line 206
    .line 207
    move-result p2

    .line 208
    goto :goto_9

    .line 209
    :goto_a
    iget p2, v4, Landroid/graphics/Rect;->left:I

    .line 210
    .line 211
    sub-int/2addr p1, p2

    .line 212
    :goto_b
    neg-int p1, p1

    .line 213
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollVertically()Z

    .line 214
    .line 215
    .line 216
    move-result p2

    .line 217
    if-nez p2, :cond_d

    .line 218
    .line 219
    :goto_c
    move p2, v5

    .line 220
    goto :goto_10

    .line 221
    :cond_d
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 222
    .line 223
    .line 224
    move-result p2

    .line 225
    if-eqz p2, :cond_e

    .line 226
    .line 227
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getWidth()I

    .line 228
    .line 229
    .line 230
    move-result p2

    .line 231
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingEnd()I

    .line 232
    .line 233
    .line 234
    move-result v3

    .line 235
    :goto_d
    sub-int/2addr p2, v3

    .line 236
    goto :goto_e

    .line 237
    :cond_e
    invoke-virtual {v2}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->getHeight()I

    .line 238
    .line 239
    .line 240
    move-result p2

    .line 241
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPaddingBottom()I

    .line 242
    .line 243
    .line 244
    move-result v3

    .line 245
    goto :goto_d

    .line 246
    :goto_e
    iget v3, v4, Landroid/graphics/Rect;->top:I

    .line 247
    .line 248
    :goto_f
    sub-int/2addr p2, v3

    .line 249
    :goto_10
    neg-int p2, p2

    .line 250
    :goto_11
    aput p1, v0, v5

    .line 251
    .line 252
    const/4 v3, 0x1

    .line 253
    aput p2, v0, v3

    .line 254
    .line 255
    if-nez p1, :cond_f

    .line 256
    .line 257
    if-nez p2, :cond_f

    .line 258
    .line 259
    iget p1, v2, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->e:I

    .line 260
    .line 261
    div-int/2addr v1, p1

    .line 262
    invoke-virtual {v2, v1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->o(I)V

    .line 263
    .line 264
    .line 265
    :cond_f
    return-object v0
.end method

.method public final createScroller(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)Landroidx/recyclerview/widget/RecyclerView$SmoothScroller;
    .locals 2

    .line 1
    instance-of v0, p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    return-object v1

    .line 7
    :cond_0
    iget-object v0, p0, LF7/e;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    new-instance v1, LF7/d;

    .line 12
    .line 13
    check-cast p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 14
    .line 15
    invoke-direct {v1, v0, p1}, LF7/d;-><init>(Landroidx/recyclerview/widget/RecyclerView;Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)V

    .line 16
    .line 17
    .line 18
    :cond_1
    return-object v1
.end method

.method public final d(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)V
    .locals 6

    .line 1
    iget-object v0, p0, LF7/e;->b:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 10
    .line 11
    .line 12
    :cond_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getChildCount()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/4 v2, 0x0

    .line 17
    :goto_0
    if-ge v2, v1, :cond_3

    .line 18
    .line 19
    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getChildAt(I)Landroid/view/View;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    if-nez v3, :cond_1

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_1
    invoke-virtual {p1, v3}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPosition(Landroid/view/View;)I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    iget v5, p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->e:I

    .line 31
    .line 32
    rem-int/2addr v4, v5

    .line 33
    if-nez v4, :cond_2

    .line 34
    .line 35
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    :cond_2
    :goto_1
    add-int/lit8 v2, v2, 0x1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_3
    return-void
.end method

.method public final findSnapView(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)Landroid/view/View;
    .locals 6

    .line 1
    instance-of v0, p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_6

    .line 5
    .line 6
    check-cast p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, LF7/e;->d(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LF7/e;->b:Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const/4 v3, 0x0

    .line 18
    const/4 v4, 0x1

    .line 19
    if-eq v2, v4, :cond_5

    .line 20
    .line 21
    const/4 v5, 0x2

    .line 22
    if-eq v2, v5, :cond_1

    .line 23
    .line 24
    const/4 p1, 0x3

    .line 25
    if-eq v2, p1, :cond_0

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_0
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    move-object v1, p1

    .line 33
    check-cast v1, Landroid/view/View;

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_1
    invoke-static {p1}, LF7/e;->a(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    check-cast v2, Landroid/view/View;

    .line 45
    .line 46
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    check-cast v3, Landroid/view/View;

    .line 51
    .line 52
    new-instance v4, Landroid/graphics/Rect;

    .line 53
    .line 54
    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1, v3, v4}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getDecoratedBoundsWithMargins(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->p()Z

    .line 61
    .line 62
    .line 63
    move-result v4

    .line 64
    if-eqz v4, :cond_4

    .line 65
    .line 66
    invoke-static {p1, v3}, LF7/e;->b(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    if-gt p1, v1, :cond_2

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_2
    move-object v2, v3

    .line 74
    :cond_3
    :goto_0
    move-object v1, v2

    .line 75
    goto :goto_1

    .line 76
    :cond_4
    invoke-static {p1, v3}, LF7/e;->c(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 77
    .line 78
    .line 79
    move-result p1

    .line 80
    if-gt p1, v1, :cond_3

    .line 81
    .line 82
    move-object v1, v3

    .line 83
    goto :goto_1

    .line 84
    :cond_5
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    move-object v1, p1

    .line 89
    check-cast v1, Landroid/view/View;

    .line 90
    .line 91
    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 92
    .line 93
    .line 94
    :cond_6
    return-object v1
.end method

.method public final findTargetSnapPosition(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;II)I
    .locals 7

    .line 1
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getItemCount()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, -0x1

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getChildCount()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_1
    instance-of v0, p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 17
    .line 18
    if-nez v0, :cond_2

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_2
    check-cast p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 22
    .line 23
    iget-object v0, p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->t:LF7/b;

    .line 24
    .line 25
    iget v0, v0, LF7/b;->f:I

    .line 26
    .line 27
    if-nez v0, :cond_3

    .line 28
    .line 29
    :goto_0
    return v1

    .line 30
    :cond_3
    invoke-virtual {p0, p2, p3}, Landroidx/recyclerview/widget/SnapHelper;->calculateScrollDistance(II)[I

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {p1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    const/4 v3, 0x1

    .line 39
    const/4 v4, 0x0

    .line 40
    if-eqz v2, :cond_4

    .line 41
    .line 42
    aget v0, v0, v4

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_4
    aget v0, v0, v3

    .line 46
    .line 47
    :goto_1
    invoke-virtual {p1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->p()Z

    .line 48
    .line 49
    .line 50
    move-result v2

    .line 51
    if-eqz v2, :cond_5

    .line 52
    .line 53
    neg-int v0, v0

    .line 54
    :cond_5
    invoke-virtual {p1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-eqz v2, :cond_8

    .line 59
    .line 60
    iget-boolean p3, p1, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->C:Z

    .line 61
    .line 62
    if-eqz p3, :cond_7

    .line 63
    .line 64
    if-gez p2, :cond_6

    .line 65
    .line 66
    :goto_2
    move p2, v3

    .line 67
    goto :goto_3

    .line 68
    :cond_6
    move p2, v4

    .line 69
    goto :goto_3

    .line 70
    :cond_7
    if-lez p2, :cond_6

    .line 71
    .line 72
    goto :goto_2

    .line 73
    :cond_8
    if-lez p3, :cond_6

    .line 74
    .line 75
    goto :goto_2

    .line 76
    :goto_3
    invoke-static {p1}, LF7/e;->a(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)I

    .line 77
    .line 78
    .line 79
    move-result p3

    .line 80
    invoke-virtual {p0, p1}, LF7/e;->d(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)V

    .line 81
    .line 82
    .line 83
    iget-object v2, p0, LF7/e;->b:Ljava/util/ArrayList;

    .line 84
    .line 85
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 86
    .line 87
    .line 88
    move-result v5

    .line 89
    if-eq v5, v3, :cond_15

    .line 90
    .line 91
    const/4 v6, 0x2

    .line 92
    if-eq v5, v6, :cond_a

    .line 93
    .line 94
    const/4 p2, 0x3

    .line 95
    if-eq v5, p2, :cond_9

    .line 96
    .line 97
    goto/16 :goto_6

    .line 98
    .line 99
    :cond_9
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object p2

    .line 103
    check-cast p2, Landroid/view/View;

    .line 104
    .line 105
    invoke-virtual {p1, p2}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPosition(Landroid/view/View;)I

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    goto/16 :goto_6

    .line 110
    .line 111
    :cond_a
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v4

    .line 115
    check-cast v4, Landroid/view/View;

    .line 116
    .line 117
    invoke-virtual {p1, v4}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPosition(Landroid/view/View;)I

    .line 118
    .line 119
    .line 120
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    check-cast v3, Landroid/view/View;

    .line 125
    .line 126
    invoke-virtual {p1, v3}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPosition(Landroid/view/View;)I

    .line 127
    .line 128
    .line 129
    move-result v5

    .line 130
    invoke-virtual {p1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->p()Z

    .line 131
    .line 132
    .line 133
    move-result v6

    .line 134
    if-eqz v6, :cond_10

    .line 135
    .line 136
    if-eqz p2, :cond_e

    .line 137
    .line 138
    if-lt v0, p3, :cond_b

    .line 139
    .line 140
    goto :goto_4

    .line 141
    :cond_b
    invoke-static {p1, v3}, LF7/e;->b(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 142
    .line 143
    .line 144
    move-result p1

    .line 145
    add-int/2addr p1, v0

    .line 146
    if-lt p1, p3, :cond_d

    .line 147
    .line 148
    :cond_c
    :goto_4
    move v1, v5

    .line 149
    goto/16 :goto_6

    .line 150
    .line 151
    :cond_d
    add-int/lit8 v5, v5, -0x1

    .line 152
    .line 153
    if-gez v5, :cond_c

    .line 154
    .line 155
    goto/16 :goto_6

    .line 156
    .line 157
    :cond_e
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 158
    .line 159
    .line 160
    move-result p2

    .line 161
    if-lt p2, p3, :cond_f

    .line 162
    .line 163
    add-int/lit8 v5, v5, -0x1

    .line 164
    .line 165
    if-gez v5, :cond_c

    .line 166
    .line 167
    goto/16 :goto_6

    .line 168
    .line 169
    :cond_f
    invoke-static {p1, v4}, LF7/e;->c(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 170
    .line 171
    .line 172
    move-result p1

    .line 173
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 174
    .line 175
    .line 176
    move-result p2

    .line 177
    sub-int/2addr p1, p2

    .line 178
    if-gt p1, p3, :cond_c

    .line 179
    .line 180
    add-int/lit8 v5, v5, -0x1

    .line 181
    .line 182
    if-gez v5, :cond_c

    .line 183
    .line 184
    goto/16 :goto_6

    .line 185
    .line 186
    :cond_10
    if-eqz p2, :cond_13

    .line 187
    .line 188
    if-lt v0, p3, :cond_11

    .line 189
    .line 190
    goto :goto_4

    .line 191
    :cond_11
    invoke-static {p1, v3}, LF7/e;->c(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 192
    .line 193
    .line 194
    move-result p1

    .line 195
    sub-int/2addr p1, v0

    .line 196
    if-gt p1, p3, :cond_12

    .line 197
    .line 198
    goto :goto_4

    .line 199
    :cond_12
    add-int/lit8 v5, v5, -0x1

    .line 200
    .line 201
    if-gez v5, :cond_c

    .line 202
    .line 203
    goto/16 :goto_6

    .line 204
    .line 205
    :cond_13
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 206
    .line 207
    .line 208
    move-result p2

    .line 209
    if-lt p2, p3, :cond_14

    .line 210
    .line 211
    add-int/lit8 v5, v5, -0x1

    .line 212
    .line 213
    if-gez v5, :cond_c

    .line 214
    .line 215
    goto/16 :goto_6

    .line 216
    .line 217
    :cond_14
    invoke-static {p1, v4}, LF7/e;->b(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 218
    .line 219
    .line 220
    move-result p1

    .line 221
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 222
    .line 223
    .line 224
    move-result p2

    .line 225
    add-int/2addr p2, p1

    .line 226
    if-lt p2, p3, :cond_c

    .line 227
    .line 228
    add-int/lit8 v5, v5, -0x1

    .line 229
    .line 230
    if-gez v5, :cond_c

    .line 231
    .line 232
    goto/16 :goto_6

    .line 233
    .line 234
    :cond_15
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v3

    .line 238
    check-cast v3, Landroid/view/View;

    .line 239
    .line 240
    invoke-virtual {p1, v3}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPosition(Landroid/view/View;)I

    .line 241
    .line 242
    .line 243
    move-result v4

    .line 244
    if-eqz p2, :cond_1b

    .line 245
    .line 246
    if-lt v0, p3, :cond_16

    .line 247
    .line 248
    goto :goto_5

    .line 249
    :cond_16
    invoke-virtual {p1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->p()Z

    .line 250
    .line 251
    .line 252
    move-result p2

    .line 253
    if-eqz p2, :cond_19

    .line 254
    .line 255
    invoke-static {p1, v3}, LF7/e;->b(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 256
    .line 257
    .line 258
    move-result p1

    .line 259
    add-int/2addr p1, v0

    .line 260
    if-lt p1, p3, :cond_18

    .line 261
    .line 262
    :cond_17
    :goto_5
    move v1, v4

    .line 263
    goto :goto_6

    .line 264
    :cond_18
    add-int/lit8 v4, v4, -0x1

    .line 265
    .line 266
    if-gez v4, :cond_17

    .line 267
    .line 268
    goto :goto_6

    .line 269
    :cond_19
    invoke-static {p1, v3}, LF7/e;->c(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 270
    .line 271
    .line 272
    move-result p1

    .line 273
    sub-int/2addr p1, v0

    .line 274
    if-gt p1, p3, :cond_1a

    .line 275
    .line 276
    goto :goto_5

    .line 277
    :cond_1a
    add-int/lit8 v4, v4, -0x1

    .line 278
    .line 279
    if-gez v4, :cond_17

    .line 280
    .line 281
    goto :goto_6

    .line 282
    :cond_1b
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 283
    .line 284
    .line 285
    move-result p2

    .line 286
    if-lt p2, p3, :cond_1c

    .line 287
    .line 288
    add-int/lit8 v4, v4, -0x1

    .line 289
    .line 290
    if-gez v4, :cond_17

    .line 291
    .line 292
    goto :goto_6

    .line 293
    :cond_1c
    invoke-virtual {p1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->p()Z

    .line 294
    .line 295
    .line 296
    move-result p2

    .line 297
    if-eqz p2, :cond_1d

    .line 298
    .line 299
    invoke-static {p1, v3}, LF7/e;->c(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 300
    .line 301
    .line 302
    move-result p1

    .line 303
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 304
    .line 305
    .line 306
    move-result p2

    .line 307
    sub-int/2addr p1, p2

    .line 308
    if-ge p1, p3, :cond_17

    .line 309
    .line 310
    add-int/lit8 v4, v4, -0x1

    .line 311
    .line 312
    if-gez v4, :cond_17

    .line 313
    .line 314
    goto :goto_6

    .line 315
    :cond_1d
    invoke-static {p1, v3}, LF7/e;->b(Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;Landroid/view/View;)I

    .line 316
    .line 317
    .line 318
    move-result p1

    .line 319
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 320
    .line 321
    .line 322
    move-result p2

    .line 323
    add-int/2addr p2, p1

    .line 324
    if-le p2, p3, :cond_17

    .line 325
    .line 326
    add-int/lit8 v4, v4, -0x1

    .line 327
    .line 328
    if-gez v4, :cond_17

    .line 329
    .line 330
    :goto_6
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 331
    .line 332
    .line 333
    return v1
.end method
