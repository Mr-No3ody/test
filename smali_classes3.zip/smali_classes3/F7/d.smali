.class public final LF7/d;
.super Landroidx/recyclerview/widget/LinearSmoothScroller;
.source "SourceFile"


# instance fields
.field public final a:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/LinearSmoothScroller;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    iput-object p2, p0, LF7/d;->a:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final calculateSpeedPerPixel(Landroid/util/DisplayMetrics;)F
    .locals 1

    .line 1
    iget-object v0, p0, LF7/d;->a:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 2
    .line 3
    iget v0, v0, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->X:F

    .line 4
    .line 5
    iget p1, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    .line 6
    .line 7
    int-to-float p1, p1

    .line 8
    div-float/2addr v0, p1

    .line 9
    return v0
.end method

.method public final calculateTimeForScrolling(I)I
    .locals 1

    .line 1
    iget-object v0, p0, LF7/d;->a:Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 2
    .line 3
    iget v0, v0, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->Y:I

    .line 4
    .line 5
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/LinearSmoothScroller;->calculateTimeForScrolling(I)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    return p1
.end method

.method public final onTargetFound(Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView$State;Landroidx/recyclerview/widget/RecyclerView$SmoothScroller$Action;)V
    .locals 6

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$SmoothScroller;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$LayoutManager;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    instance-of v0, p2, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 6
    .line 7
    if-eqz v0, :cond_a

    .line 8
    .line 9
    move-object v0, p2

    .line 10
    check-cast v0, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getPosition(Landroid/view/View;)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView$SmoothScroller;->computeScrollVectorForPosition(I)Landroid/graphics/PointF;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    if-nez v2, :cond_0

    .line 21
    .line 22
    goto/16 :goto_7

    .line 23
    .line 24
    :cond_0
    iget v3, v2, Landroid/graphics/PointF;->x:F

    .line 25
    .line 26
    const/4 v4, 0x0

    .line 27
    cmpl-float v3, v3, v4

    .line 28
    .line 29
    const/4 v5, 0x0

    .line 30
    if-gtz v3, :cond_2

    .line 31
    .line 32
    iget v2, v2, Landroid/graphics/PointF;->y:F

    .line 33
    .line 34
    cmpl-float v2, v2, v4

    .line 35
    .line 36
    if-lez v2, :cond_1

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    move v2, v5

    .line 40
    goto :goto_1

    .line 41
    :cond_2
    :goto_0
    const/4 v2, 0x1

    .line 42
    :goto_1
    invoke-virtual {v0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->p()Z

    .line 43
    .line 44
    .line 45
    move-result v3

    .line 46
    if-eqz v3, :cond_3

    .line 47
    .line 48
    xor-int/lit8 v2, v2, 0x1

    .line 49
    .line 50
    :cond_3
    if-eqz v2, :cond_4

    .line 51
    .line 52
    iget-object v3, v0, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->w:Landroid/graphics/Rect;

    .line 53
    .line 54
    goto :goto_2

    .line 55
    :cond_4
    iget-object v3, v0, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->A:Landroid/graphics/Rect;

    .line 56
    .line 57
    :goto_2
    new-instance v4, Landroid/graphics/Rect;

    .line 58
    .line 59
    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p2, p1, v4}, Landroidx/recyclerview/widget/RecyclerView$LayoutManager;->getDecoratedBoundsWithMargins(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollHorizontally()Z

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    if-nez p1, :cond_5

    .line 70
    .line 71
    move p1, v5

    .line 72
    goto :goto_4

    .line 73
    :cond_5
    if-eqz v2, :cond_6

    .line 74
    .line 75
    iget p1, v4, Landroid/graphics/Rect;->left:I

    .line 76
    .line 77
    iget p2, v3, Landroid/graphics/Rect;->left:I

    .line 78
    .line 79
    :goto_3
    sub-int/2addr p1, p2

    .line 80
    goto :goto_4

    .line 81
    :cond_6
    iget p1, v4, Landroid/graphics/Rect;->right:I

    .line 82
    .line 83
    iget p2, v3, Landroid/graphics/Rect;->right:I

    .line 84
    .line 85
    goto :goto_3

    .line 86
    :goto_4
    invoke-virtual {v0}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->canScrollVertically()Z

    .line 87
    .line 88
    .line 89
    move-result p2

    .line 90
    if-nez p2, :cond_7

    .line 91
    .line 92
    goto :goto_6

    .line 93
    :cond_7
    if-eqz v2, :cond_8

    .line 94
    .line 95
    iget p2, v4, Landroid/graphics/Rect;->top:I

    .line 96
    .line 97
    iget v2, v3, Landroid/graphics/Rect;->top:I

    .line 98
    .line 99
    :goto_5
    sub-int v5, p2, v2

    .line 100
    .line 101
    goto :goto_6

    .line 102
    :cond_8
    iget p2, v4, Landroid/graphics/Rect;->bottom:I

    .line 103
    .line 104
    iget v2, v3, Landroid/graphics/Rect;->bottom:I

    .line 105
    .line 106
    goto :goto_5

    .line 107
    :goto_6
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    .line 108
    .line 109
    .line 110
    move-result p2

    .line 111
    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    .line 112
    .line 113
    .line 114
    move-result v2

    .line 115
    invoke-static {p2, v2}, Ljava/lang/Math;->max(II)I

    .line 116
    .line 117
    .line 118
    move-result p2

    .line 119
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearSmoothScroller;->calculateTimeForDeceleration(I)I

    .line 120
    .line 121
    .line 122
    move-result p2

    .line 123
    if-lez p2, :cond_9

    .line 124
    .line 125
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearSmoothScroller;->mDecelerateInterpolator:Landroid/view/animation/DecelerateInterpolator;

    .line 126
    .line 127
    invoke-virtual {p3, p1, v5, p2, v0}, Landroidx/recyclerview/widget/RecyclerView$SmoothScroller$Action;->update(IIILandroid/view/animation/Interpolator;)V

    .line 128
    .line 129
    .line 130
    return-void

    .line 131
    :cond_9
    iget p1, v0, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->e:I

    .line 132
    .line 133
    div-int/2addr v1, p1

    .line 134
    invoke-virtual {v0, v1}, Lcom/shencoder/pagergridlayoutmanager/PagerGridLayoutManager;->o(I)V

    .line 135
    .line 136
    .line 137
    :cond_a
    :goto_7
    return-void
.end method
