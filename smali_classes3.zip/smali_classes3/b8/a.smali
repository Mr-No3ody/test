.class public abstract Lb8/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/swmansion/rnscreens/stack/views/ChildrenDrawingOrderStrategy;


# instance fields
.field public a:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lb8/a;->a:Z

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final disable()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lb8/a;->a:Z

    .line 3
    .line 4
    return-void
.end method

.method public final enable()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lb8/a;->a:Z

    .line 3
    .line 4
    return-void
.end method

.method public final isEnabled()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lb8/a;->a:Z

    .line 2
    .line 3
    return v0
.end method
