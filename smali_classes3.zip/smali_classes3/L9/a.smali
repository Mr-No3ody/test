.class public final LL9/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static account_img:I = 0x7f0a0089

.field public static account_tv:I = 0x7f0a008e

.field public static adView:I = 0x7f0a00c4

.field public static bank_account_ll:I = 0x7f0a01c9

.field public static bank_account_prefix_tv:I = 0x7f0a01ca

.field public static bank_name_tv:I = 0x7f0a01d3

.field public static bottomView:I = 0x7f0a0248

.field public static btnConfirm:I = 0x7f0a027a

.field public static btnDetails:I = 0x7f0a0283

.field public static btnOk:I = 0x7f0a029b

.field public static btnPublish:I = 0x7f0a02a4

.field public static bvn_ll:I = 0x7f0a02dd

.field public static caanba_warn_iv:I = 0x7f0a02ec

.field public static caanba_warn_text_container:I = 0x7f0a02ed

.field public static cae_content:I = 0x7f0a02f3

.field public static cae_empty_view:I = 0x7f0a02f4

.field public static card_num_et:I = 0x7f0a0308

.field public static cbAnonymous:I = 0x7f0a031a

.field public static ciei_info_area:I = 0x7f0a03d1

.field public static confirm_bt:I = 0x7f0a0510

.field public static cptv_tv1:I = 0x7f0a0591

.field public static cvv_et:I = 0x7f0a06e1

.field public static editComment:I = 0x7f0a0790

.field public static emptyView:I = 0x7f0a07ac

.field public static et_bank_card_no:I = 0x7f0a07d3

.field public static et_card_pin:I = 0x7f0a07d4

.field public static et_cvv:I = 0x7f0a07d5

.field public static fragmentContainer:I = 0x7f0a099f

.field public static gaea_title:I = 0x7f0a09f7

.field public static gaeiCompanyTv:I = 0x7f0a09f8

.field public static gaeiOrderNoTv:I = 0x7f0a09f9

.field public static gaeiRcv:I = 0x7f0a09fa

.field public static gieaArriveIcon:I = 0x7f0a09ff

.field public static gieaExpressageTv:I = 0x7f0a0a00

.field public static gieaGrayPoint:I = 0x7f0a0a01

.field public static gieaLine:I = 0x7f0a0a02

.field public static gieaTimeTv:I = 0x7f0a0a03

.field public static giea_time_line_container:I = 0x7f0a0a04

.field public static iiv_card_pin_show:I = 0x7f0a0a99

.field public static imageViewClose:I = 0x7f0a0aa2

.field public static imageViewPic:I = 0x7f0a0aaa

.field public static input_card_pin_et:I = 0x7f0a0aff

.field public static item1:I = 0x7f0a0b41

.field public static item10:I = 0x7f0a0b42

.field public static item11:I = 0x7f0a0b43

.field public static item12:I = 0x7f0a0b44

.field public static item13:I = 0x7f0a0b45

.field public static item14:I = 0x7f0a0b46

.field public static item2:I = 0x7f0a0b47

.field public static item3:I = 0x7f0a0b48

.field public static item4:I = 0x7f0a0b49

.field public static item5:I = 0x7f0a0b4a

.field public static item6:I = 0x7f0a0b4b

.field public static item7:I = 0x7f0a0b4c

.field public static item8:I = 0x7f0a0b4d

.field public static item9:I = 0x7f0a0b4e

.field public static itemAccountNo:I = 0x7f0a0b50

.field public static itemBVN:I = 0x7f0a0b56

.field public static itemBankInfo:I = 0x7f0a0b57

.field public static itemBirth:I = 0x7f0a0b5a

.field public static itemMobileSms:I = 0x7f0a0b6f

.field public static ivClose:I = 0x7f0a0bee

.field public static ivCoupon:I = 0x7f0a0bfa

.field public static ivGrabEmpty:I = 0x7f0a0c2f

.field public static ivIcon:I = 0x7f0a0c39

.field public static ivShareClose:I = 0x7f0a0cb8

.field public static ivShareImg:I = 0x7f0a0cb9

.field public static iv_logo:I = 0x7f0a0d58

.field public static ll_container:I = 0x7f0a0fa4

.field public static ll_item_container:I = 0x7f0a0fb9

.field public static main:I = 0x7f0a101d

.field public static map:I = 0x7f0a103a

.field public static med_card_no:I = 0x7f0a10a7

.field public static med_card_pin:I = 0x7f0a10a8

.field public static med_cvv:I = 0x7f0a10a9

.field public static med_valid_thru:I = 0x7f0a10aa

.field public static msgContainer:I = 0x7f0a1147

.field public static next_bt:I = 0x7f0a1207

.field public static pin_next_bt:I = 0x7f0a1409

.field public static pp_title_bar:I = 0x7f0a141b

.field public static receiptView:I = 0x7f0a14bb

.field public static rvGrabShareImg:I = 0x7f0a15cd

.field public static saveTv:I = 0x7f0a1625

.field public static scrollView:I = 0x7f0a163b

.field public static select_other_method_tv:I = 0x7f0a1678

.field public static shareTv:I = 0x7f0a16a0

.field public static shippingToTv:I = 0x7f0a16a9

.field public static shippingToView:I = 0x7f0a16aa

.field public static tabLayout:I = 0x7f0a1755

.field public static textViewMessage:I = 0x7f0a17af

.field public static textViewNext:I = 0x7f0a17b3

.field public static textViewShare:I = 0x7f0a17be

.field public static titleBar:I = 0x7f0a17e5

.field public static titleStub1:I = 0x7f0a17eb

.field public static titleStub2:I = 0x7f0a17ec

.field public static title_bar:I = 0x7f0a17ef

.field public static top_tips_tv:I = 0x7f0a1817

.field public static tvAccountNoError:I = 0x7f0a1866

.field public static tvAddress:I = 0x7f0a1871

.field public static tvAppName:I = 0x7f0a1894

.field public static tvBottomDesc:I = 0x7f0a18cd

.field public static tvContent:I = 0x7f0a190e

.field public static tvCount:I = 0x7f0a1913

.field public static tvCvvTitle:I = 0x7f0a1937

.field public static tvError1:I = 0x7f0a1976

.field public static tvError2:I = 0x7f0a1977

.field public static tvError3:I = 0x7f0a1978

.field public static tvHeaderTitle:I = 0x7f0a19be

.field public static tvLine1:I = 0x7f0a1a23

.field public static tvLine2:I = 0x7f0a1a24

.field public static tvMessage:I = 0x7f0a1a49

.field public static tvMsg:I = 0x7f0a1a60

.field public static tvName:I = 0x7f0a1a68

.field public static tvNext:I = 0x7f0a1a70

.field public static tvNote:I = 0x7f0a1a87

.field public static tvPackageName:I = 0x7f0a1aab

.field public static tvTitle:I = 0x7f0a1b8e

.field public static tvTopTips:I = 0x7f0a1b9a

.field public static tvVersion:I = 0x7f0a1bec

.field public static tv_add_card_tips:I = 0x7f0a1c15

.field public static tv_amount:I = 0x7f0a1c1c

.field public static tv_card_no_title:I = 0x7f0a1c3a

.field public static tv_card_pin_title:I = 0x7f0a1c3b

.field public static tv_cvv_title:I = 0x7f0a1c64

.field public static tv_date:I = 0x7f0a1c69

.field public static tv_valid_thru:I = 0x7f0a1d8e

.field public static tv_valid_thru_title:I = 0x7f0a1d8f

.field public static ussdList:I = 0x7f0a1dbe

.field public static v_status_bar:I = 0x7f0a1df8

.field public static valid_date_tv:I = 0x7f0a1dff

.field public static viewOtc:I = 0x7f0a1e51

.field public static viewRoot:I = 0x7f0a1e61

.field public static viewpager:I = 0x7f0a1e9d


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
