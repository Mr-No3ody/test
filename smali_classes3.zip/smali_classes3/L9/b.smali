.class public final LL9/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static cm_activity_maps:I = 0x7f0d00e1

.field public static cm_activity_transaction_receipt:I = 0x7f0d00e2

.field public static cm_activity_web:I = 0x7f0d00e3

.field public static cm_fragment_add_bank_card_v2:I = 0x7f0d00e6

.field public static cm_layout_rn_loading:I = 0x7f0d00e8

.field public static cm_layout_web_header:I = 0x7f0d00e9

.field public static core_activity_add_bank_card_account:I = 0x7f0d00ec

.field public static core_activity_add_new_bank_account_v2:I = 0x7f0d00ed

.field public static core_activity_bind_new_bank_account:I = 0x7f0d00ee

.field public static core_activity_comment:I = 0x7f0d00f1

.field public static core_activity_core_receipt_print:I = 0x7f0d00f4

.field public static core_activity_expressage_info:I = 0x7f0d00f6

.field public static core_activity_receipt_share:I = 0x7f0d00fb

.field public static core_activity_risk_control_verify:I = 0x7f0d00fc

.field public static core_activity_use_new_card:I = 0x7f0d00fd

.field public static core_activity_ussd_list:I = 0x7f0d00fe

.field public static core_add_bank_account_fragment:I = 0x7f0d0101

.field public static core_comment_dialog_layout:I = 0x7f0d0108

.field public static core_fragment_add_bank_account_ng:I = 0x7f0d0125

.field public static core_fragment_add_bank_account_otp:I = 0x7f0d0126

.field public static core_fragment_add_bank_account_uba:I = 0x7f0d0127

.field public static core_fragment_receipt_share:I = 0x7f0d0135

.field public static core_fragment_risk_control_check_otc:I = 0x7f0d0136

.field public static core_grab_share_empty:I = 0x7f0d013a

.field public static core_grab_share_img:I = 0x7f0d013b

.field public static core_input_card_pin_layout:I = 0x7f0d013c

.field public static core_item_expressage_info:I = 0x7f0d0149

.field public static core_item_installed_app:I = 0x7f0d014c

.field public static core_item_installed_app_header:I = 0x7f0d014d

.field public static core_layout_ussd_head_item:I = 0x7f0d0199

.field public static core_layout_ussd_item:I = 0x7f0d019a

.field public static core_oc_switch_arouter_dialog_layout:I = 0x7f0d01b2

.field public static core_select_bank_account_fragment:I = 0x7f0d01bd


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
