.class public final LL9/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static cm_enter_16_19_digits_number:I = 0x7f140309

.field public static cm_mfb_empty_auth_code:I = 0x7f14030a

.field public static cm_mfb_generate_auth_code_failed:I = 0x7f14030b

.field public static cm_mfb_sdk_authorization_failed:I = 0x7f14030c

.field public static cm_mfb_sdk_not_initialized:I = 0x7f14030d

.field public static cm_mfb_unknown_error:I = 0x7f14030e

.field public static cm_mm_yy:I = 0x7f14030f

.field public static cm_palmpay_security_center:I = 0x7f140312


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
