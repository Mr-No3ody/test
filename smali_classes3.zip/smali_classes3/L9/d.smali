.class public final LL9/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static core_remote_config_defaults:I = 0x7f180008


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
