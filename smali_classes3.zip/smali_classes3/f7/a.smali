.class public final Lf7/a;
.super Lz5/k;
.source "SourceFile"


# instance fields
.field public final f:Landroid/app/Application;


# direct methods
.method public constructor <init>(Landroid/app/Application;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lz5/k;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lf7/a;->f:Landroid/app/Application;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final createToast(Lz5/j;)Lcom/hjq/toast/config/IToast;
    .locals 8

    .line 1
    const/16 v0, 0x1e

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-static {}, Lz5/a;->a()Lz5/a;

    .line 6
    .line 7
    .line 8
    move-result-object v3

    .line 9
    iget-object v3, v3, Lz5/a;->a:Landroid/app/Activity;

    .line 10
    .line 11
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 12
    .line 13
    iget-object v5, p0, Lf7/a;->f:Landroid/app/Application;

    .line 14
    .line 15
    invoke-static {v5}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    .line 16
    .line 17
    .line 18
    move-result v6

    .line 19
    if-eqz v6, :cond_0

    .line 20
    .line 21
    new-instance v3, Lz5/b;

    .line 22
    .line 23
    invoke-direct {v3, v5}, Lz5/b;-><init>(Landroid/app/Application;)V

    .line 24
    .line 25
    .line 26
    goto :goto_2

    .line 27
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    sget-object v6, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v6}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v6

    .line 36
    const-string v7, "Pixel 6"

    .line 37
    .line 38
    invoke-virtual {v7, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 39
    .line 40
    .line 41
    move-result v6

    .line 42
    if-nez v6, :cond_3

    .line 43
    .line 44
    if-nez v3, :cond_1

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_1
    invoke-virtual {v3}, Landroid/app/Activity;->isFinishing()Z

    .line 48
    .line 49
    .line 50
    move-result v6

    .line 51
    if-eqz v6, :cond_2

    .line 52
    .line 53
    :goto_0
    move v6, v1

    .line 54
    goto :goto_1

    .line 55
    :cond_2
    invoke-virtual {v3}, Landroid/app/Activity;->isDestroyed()Z

    .line 56
    .line 57
    .line 58
    move-result v6

    .line 59
    xor-int/2addr v6, v2

    .line 60
    :goto_1
    if-eqz v6, :cond_3

    .line 61
    .line 62
    new-instance v5, Lz5/b;

    .line 63
    .line 64
    invoke-direct {v5, v3}, Lz5/b;-><init>(Landroid/app/Activity;)V

    .line 65
    .line 66
    .line 67
    move-object v3, v5

    .line 68
    goto :goto_2

    .line 69
    :cond_3
    const/16 v3, 0x19

    .line 70
    .line 71
    if-ne v4, v3, :cond_4

    .line 72
    .line 73
    new-instance v3, Lz5/f;

    .line 74
    .line 75
    invoke-direct {v3, v5}, Landroid/widget/Toast;-><init>(Landroid/content/Context;)V

    .line 76
    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_4
    const/16 v3, 0x1d

    .line 80
    .line 81
    if-ge v4, v3, :cond_5

    .line 82
    .line 83
    const-class v3, Landroid/app/NotificationManager;

    .line 84
    .line 85
    invoke-virtual {v5, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v3

    .line 89
    check-cast v3, Landroid/app/NotificationManager;

    .line 90
    .line 91
    invoke-virtual {v3}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    .line 92
    .line 93
    .line 94
    move-result v3

    .line 95
    if-nez v3, :cond_5

    .line 96
    .line 97
    new-instance v3, Lz5/d;

    .line 98
    .line 99
    invoke-direct {v3, v5}, Landroid/widget/Toast;-><init>(Landroid/content/Context;)V

    .line 100
    .line 101
    .line 102
    goto :goto_2

    .line 103
    :cond_5
    new-instance v3, Lz5/g;

    .line 104
    .line 105
    invoke-direct {v3, v5}, Landroid/widget/Toast;-><init>(Landroid/content/Context;)V

    .line 106
    .line 107
    .line 108
    :goto_2
    instance-of v5, v3, Lz5/b;

    .line 109
    .line 110
    if-nez v5, :cond_7

    .line 111
    .line 112
    if-lt v4, v0, :cond_7

    .line 113
    .line 114
    iget-object v4, p0, Lz5/k;->a:Landroid/app/Application;

    .line 115
    .line 116
    invoke-virtual {v4}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 117
    .line 118
    .line 119
    move-result-object v4

    .line 120
    iget v4, v4, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    .line 121
    .line 122
    if-ge v4, v0, :cond_6

    .line 123
    .line 124
    goto :goto_3

    .line 125
    :cond_6
    move v4, v1

    .line 126
    goto :goto_4

    .line 127
    :cond_7
    :goto_3
    move v4, v2

    .line 128
    :goto_4
    if-nez v4, :cond_a

    .line 129
    .line 130
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 131
    .line 132
    if-ge v4, v0, :cond_8

    .line 133
    .line 134
    move v1, v2

    .line 135
    goto :goto_6

    .line 136
    :cond_8
    :try_start_0
    const-string v0, "android.app.compat.CompatChanges"

    .line 137
    .line 138
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    const-string v4, "isChangeEnabled"

    .line 143
    .line 144
    sget-object v5, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    .line 145
    .line 146
    filled-new-array {v5}, [Ljava/lang/Class;

    .line 147
    .line 148
    .line 149
    move-result-object v5

    .line 150
    invoke-virtual {v0, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 155
    .line 156
    .line 157
    const-wide/32 v4, 0x8cf3b87

    .line 158
    .line 159
    .line 160
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 161
    .line 162
    .line 163
    move-result-object v2

    .line 164
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    const/4 v4, 0x0

    .line 169
    invoke-virtual {v0, v4, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    .line 178
    .line 179
    .line 180
    move-result v1
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    .line 181
    goto :goto_6

    .line 182
    :catch_0
    move-exception v0

    .line 183
    goto :goto_5

    .line 184
    :catch_1
    move-exception v0

    .line 185
    goto :goto_5

    .line 186
    :catch_2
    move-exception v0

    .line 187
    goto :goto_5

    .line 188
    :catch_3
    move-exception v0

    .line 189
    :goto_5
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 190
    .line 191
    .line 192
    :goto_6
    if-nez v1, :cond_9

    .line 193
    .line 194
    goto :goto_7

    .line 195
    :cond_9
    return-object v3

    .line 196
    :cond_a
    :goto_7
    iget-object p1, p1, Lz5/j;->c:Lcom/hjq/toast/config/IToastStyle;

    .line 197
    .line 198
    iget-object v0, p0, Lz5/k;->a:Landroid/app/Application;

    .line 199
    .line 200
    invoke-interface {p1, v0}, Lcom/hjq/toast/config/IToastStyle;->createView(Landroid/content/Context;)Landroid/view/View;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    invoke-interface {v3, v0}, Lcom/hjq/toast/config/IToast;->setView(Landroid/view/View;)V

    .line 205
    .line 206
    .line 207
    invoke-interface {p1}, Lcom/hjq/toast/config/IToastStyle;->getGravity()I

    .line 208
    .line 209
    .line 210
    move-result v0

    .line 211
    invoke-interface {p1}, Lcom/hjq/toast/config/IToastStyle;->getXOffset()I

    .line 212
    .line 213
    .line 214
    move-result v1

    .line 215
    invoke-interface {p1}, Lcom/hjq/toast/config/IToastStyle;->getYOffset()I

    .line 216
    .line 217
    .line 218
    move-result v2

    .line 219
    invoke-interface {v3, v0, v1, v2}, Lcom/hjq/toast/config/IToast;->setGravity(III)V

    .line 220
    .line 221
    .line 222
    invoke-interface {p1}, Lcom/hjq/toast/config/IToastStyle;->getHorizontalMargin()F

    .line 223
    .line 224
    .line 225
    move-result v0

    .line 226
    invoke-interface {p1}, Lcom/hjq/toast/config/IToastStyle;->getVerticalMargin()F

    .line 227
    .line 228
    .line 229
    move-result p1

    .line 230
    invoke-interface {v3, v0, p1}, Lcom/hjq/toast/config/IToast;->setMargin(FF)V

    .line 231
    .line 232
    .line 233
    return-object v3
.end method
