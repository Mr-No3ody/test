.class public final Lu9/c;
.super Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lu9/c;->a:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;

    .line 2
    .line 3
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onScrolled(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 1

    .line 1
    const-string v0, "recyclerView"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$OnScrollListener;->onScrolled(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 7
    .line 8
    .line 9
    iget-object p1, p0, Lu9/c;->a:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;

    .line 10
    .line 11
    invoke-static {p1}, Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;->access$updateSideBarSelection(Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
