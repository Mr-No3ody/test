.class public final Lu9/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/teller/ui/view/SideBarView$OnLetterChangeListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lu9/d;->a:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onLetterChanged(Ljava/lang/String;I)V
    .locals 0

    .line 1
    const-string p2, "letter"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p2, p0, Lu9/d;->a:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;

    .line 7
    .line 8
    invoke-static {p2, p1}, Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;->access$scrollToSection(Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final onLetterGone()V
    .locals 1

    .line 1
    iget-object v0, p0, Lu9/d;->a:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;->access$updateSideBarSelection(Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
