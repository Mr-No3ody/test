.class public final synthetic Lu9/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, Lu9/a;->a:I

    iput-object p1, p0, Lu9/a;->b:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 1

    .line 1
    iget v0, p0, Lu9/a;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lu9/a;->b:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;

    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;->c(Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;LM1/j;Landroid/view/View;I)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lu9/a;->b:Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;

    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;->b(Lcom/transsnet/palmpay/betting/ui/dialog/PickBettingBillerDialog;LM1/j;Landroid/view/View;I)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
