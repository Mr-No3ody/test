.class public final LP5/l;
.super LP5/b;
.source "SourceFile"


# static fields
.field public static final B:Ljava/util/Set;


# instance fields
.field public final A:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ljava/util/HashSet;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "alg"

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    const-string v1, "jku"

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    const-string v1, "jwk"

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    const-string v1, "x5u"

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    const-string v1, "x5t"

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    const-string v1, "x5t#S256"

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    const-string v1, "x5c"

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    const-string v1, "kid"

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    const-string v1, "typ"

    .line 47
    .line 48
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    const-string v1, "cty"

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    const-string v1, "crit"

    .line 57
    .line 58
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    const-string v1, "b64"

    .line 62
    .line 63
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    sput-object v0, LP5/l;->B:Ljava/util/Set;

    .line 71
    .line 72
    return-void
.end method

.method public constructor <init>(LP5/k;LP5/f;Ljava/lang/String;Ljava/util/HashSet;Ljava/net/URI;LT5/d;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/lang/String;ZLjava/util/HashMap;LZ5/b;)V
    .locals 14

    .line 1
    move-object v0, p0

    .line 2
    move-object v1, p1

    .line 3
    move-object/from16 v2, p2

    .line 4
    .line 5
    move-object/from16 v3, p3

    .line 6
    .line 7
    move-object/from16 v4, p4

    .line 8
    .line 9
    move-object/from16 v5, p5

    .line 10
    .line 11
    move-object/from16 v6, p6

    .line 12
    .line 13
    move-object/from16 v7, p7

    .line 14
    .line 15
    move-object/from16 v8, p8

    .line 16
    .line 17
    move-object/from16 v9, p9

    .line 18
    .line 19
    move-object/from16 v10, p10

    .line 20
    .line 21
    move-object/from16 v11, p11

    .line 22
    .line 23
    move-object/from16 v12, p13

    .line 24
    .line 25
    move-object/from16 v13, p14

    .line 26
    .line 27
    invoke-direct/range {v0 .. v13}, LP5/b;-><init>(LP5/k;LP5/f;Ljava/lang/String;Ljava/util/HashSet;Ljava/net/URI;LT5/d;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/lang/String;Ljava/util/HashMap;LZ5/b;)V

    .line 28
    .line 29
    .line 30
    if-eqz p1, :cond_1

    .line 31
    .line 32
    sget-object v2, LP5/a;->b:LP5/a;

    .line 33
    .line 34
    iget-object v2, v2, LP5/a;->a:Ljava/lang/String;

    .line 35
    .line 36
    iget-object p1, p1, LP5/a;->a:Ljava/lang/String;

    .line 37
    .line 38
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    if-nez p1, :cond_0

    .line 43
    .line 44
    move/from16 p1, p12

    .line 45
    .line 46
    iput-boolean p1, p0, LP5/l;->A:Z

    .line 47
    .line 48
    return-void

    .line 49
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 50
    .line 51
    const-string v1, "The JWS algorithm \"alg\" cannot be \"none\""

    .line 52
    .line 53
    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    throw p1

    .line 57
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 58
    .line 59
    const-string v1, "The algorithm \"alg\" header parameter must not be null"

    .line 60
    .line 61
    invoke-direct {p1, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    throw p1
.end method

.method public static a(LZ5/b;)LP5/l;
    .locals 49

    .line 1
    new-instance v0, Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual/range {p0 .. p0}, LZ5/a;->a()[B

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v2, LZ5/e;->a:Ljava/nio/charset/Charset;

    .line 8
    .line 9
    invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 10
    .line 11
    .line 12
    const/16 v1, 0x4e20

    .line 13
    .line 14
    invoke-static {v1, v0}, LZ5/c;->g(ILjava/lang/String;)Ljava/util/Map;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const-string v1, "alg"

    .line 19
    .line 20
    invoke-static {v1, v0}, LZ5/c;->d(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    if-eqz v2, :cond_51

    .line 25
    .line 26
    sget-object v4, LP5/a;->b:LP5/a;

    .line 27
    .line 28
    iget-object v5, v4, LP5/a;->a:Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    if-eqz v5, :cond_0

    .line 35
    .line 36
    move-object v5, v4

    .line 37
    goto/16 :goto_0

    .line 38
    .line 39
    :cond_0
    const-string v5, "enc"

    .line 40
    .line 41
    invoke-interface {v0, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v5

    .line 45
    if-eqz v5, :cond_18

    .line 46
    .line 47
    sget-object v5, LP5/g;->c:LP5/g;

    .line 48
    .line 49
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 50
    .line 51
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    if-eqz v6, :cond_1

    .line 56
    .line 57
    goto/16 :goto_0

    .line 58
    .line 59
    :cond_1
    sget-object v5, LP5/g;->d:LP5/g;

    .line 60
    .line 61
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 62
    .line 63
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v6

    .line 67
    if-eqz v6, :cond_2

    .line 68
    .line 69
    goto/16 :goto_0

    .line 70
    .line 71
    :cond_2
    sget-object v5, LP5/g;->e:LP5/g;

    .line 72
    .line 73
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 74
    .line 75
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v6

    .line 79
    if-eqz v6, :cond_3

    .line 80
    .line 81
    goto/16 :goto_0

    .line 82
    .line 83
    :cond_3
    sget-object v5, LP5/g;->f:LP5/g;

    .line 84
    .line 85
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 86
    .line 87
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v6

    .line 91
    if-eqz v6, :cond_4

    .line 92
    .line 93
    goto/16 :goto_0

    .line 94
    .line 95
    :cond_4
    sget-object v5, LP5/g;->g:LP5/g;

    .line 96
    .line 97
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 98
    .line 99
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v6

    .line 103
    if-eqz v6, :cond_5

    .line 104
    .line 105
    goto/16 :goto_0

    .line 106
    .line 107
    :cond_5
    sget-object v5, LP5/g;->i:LP5/g;

    .line 108
    .line 109
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 110
    .line 111
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v6

    .line 115
    if-eqz v6, :cond_6

    .line 116
    .line 117
    goto/16 :goto_0

    .line 118
    .line 119
    :cond_6
    sget-object v5, LP5/g;->j:LP5/g;

    .line 120
    .line 121
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 122
    .line 123
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result v6

    .line 127
    if-eqz v6, :cond_7

    .line 128
    .line 129
    goto/16 :goto_0

    .line 130
    .line 131
    :cond_7
    sget-object v5, LP5/g;->o:LP5/g;

    .line 132
    .line 133
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 134
    .line 135
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v6

    .line 139
    if-eqz v6, :cond_8

    .line 140
    .line 141
    goto/16 :goto_0

    .line 142
    .line 143
    :cond_8
    sget-object v5, LP5/g;->p:LP5/g;

    .line 144
    .line 145
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 146
    .line 147
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    move-result v6

    .line 151
    if-eqz v6, :cond_9

    .line 152
    .line 153
    goto/16 :goto_0

    .line 154
    .line 155
    :cond_9
    sget-object v5, LP5/g;->t:LP5/g;

    .line 156
    .line 157
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 158
    .line 159
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v6

    .line 163
    if-eqz v6, :cond_a

    .line 164
    .line 165
    goto/16 :goto_0

    .line 166
    .line 167
    :cond_a
    sget-object v5, LP5/g;->v:LP5/g;

    .line 168
    .line 169
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 170
    .line 171
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result v6

    .line 175
    if-eqz v6, :cond_b

    .line 176
    .line 177
    goto/16 :goto_0

    .line 178
    .line 179
    :cond_b
    sget-object v5, LP5/g;->w:LP5/g;

    .line 180
    .line 181
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 182
    .line 183
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 184
    .line 185
    .line 186
    move-result v6

    .line 187
    if-eqz v6, :cond_c

    .line 188
    .line 189
    goto/16 :goto_0

    .line 190
    .line 191
    :cond_c
    sget-object v5, LP5/g;->A:LP5/g;

    .line 192
    .line 193
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 194
    .line 195
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 196
    .line 197
    .line 198
    move-result v6

    .line 199
    if-eqz v6, :cond_d

    .line 200
    .line 201
    goto/16 :goto_0

    .line 202
    .line 203
    :cond_d
    sget-object v5, LP5/g;->B:LP5/g;

    .line 204
    .line 205
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 206
    .line 207
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 208
    .line 209
    .line 210
    move-result v6

    .line 211
    if-eqz v6, :cond_e

    .line 212
    .line 213
    goto/16 :goto_0

    .line 214
    .line 215
    :cond_e
    sget-object v5, LP5/g;->C:LP5/g;

    .line 216
    .line 217
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 218
    .line 219
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v6

    .line 223
    if-eqz v6, :cond_f

    .line 224
    .line 225
    goto/16 :goto_0

    .line 226
    .line 227
    :cond_f
    sget-object v5, LP5/g;->H:LP5/g;

    .line 228
    .line 229
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 230
    .line 231
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    move-result v6

    .line 235
    if-eqz v6, :cond_10

    .line 236
    .line 237
    goto/16 :goto_0

    .line 238
    .line 239
    :cond_10
    sget-object v5, LP5/g;->L:LP5/g;

    .line 240
    .line 241
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 242
    .line 243
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 244
    .line 245
    .line 246
    move-result v6

    .line 247
    if-eqz v6, :cond_11

    .line 248
    .line 249
    goto/16 :goto_0

    .line 250
    .line 251
    :cond_11
    sget-object v5, LP5/g;->M:LP5/g;

    .line 252
    .line 253
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 254
    .line 255
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    move-result v6

    .line 259
    if-eqz v6, :cond_12

    .line 260
    .line 261
    goto/16 :goto_0

    .line 262
    .line 263
    :cond_12
    sget-object v5, LP5/g;->Q:LP5/g;

    .line 264
    .line 265
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 266
    .line 267
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 268
    .line 269
    .line 270
    move-result v6

    .line 271
    if-eqz v6, :cond_13

    .line 272
    .line 273
    goto/16 :goto_0

    .line 274
    .line 275
    :cond_13
    sget-object v5, LP5/g;->X:LP5/g;

    .line 276
    .line 277
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 278
    .line 279
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 280
    .line 281
    .line 282
    move-result v6

    .line 283
    if-eqz v6, :cond_14

    .line 284
    .line 285
    goto/16 :goto_0

    .line 286
    .line 287
    :cond_14
    sget-object v5, LP5/g;->Y:LP5/g;

    .line 288
    .line 289
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 290
    .line 291
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 292
    .line 293
    .line 294
    move-result v6

    .line 295
    if-eqz v6, :cond_15

    .line 296
    .line 297
    goto/16 :goto_0

    .line 298
    .line 299
    :cond_15
    sget-object v5, LP5/g;->Z:LP5/g;

    .line 300
    .line 301
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 302
    .line 303
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 304
    .line 305
    .line 306
    move-result v6

    .line 307
    if-eqz v6, :cond_16

    .line 308
    .line 309
    goto/16 :goto_0

    .line 310
    .line 311
    :cond_16
    sget-object v5, LP5/g;->k0:LP5/g;

    .line 312
    .line 313
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 314
    .line 315
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 316
    .line 317
    .line 318
    move-result v6

    .line 319
    if-eqz v6, :cond_17

    .line 320
    .line 321
    goto/16 :goto_0

    .line 322
    .line 323
    :cond_17
    new-instance v5, LP5/g;

    .line 324
    .line 325
    invoke-direct {v5, v2}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 326
    .line 327
    .line 328
    goto/16 :goto_0

    .line 329
    .line 330
    :cond_18
    sget-object v5, LP5/k;->c:LP5/k;

    .line 331
    .line 332
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 333
    .line 334
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 335
    .line 336
    .line 337
    move-result v6

    .line 338
    if-eqz v6, :cond_19

    .line 339
    .line 340
    goto/16 :goto_0

    .line 341
    .line 342
    :cond_19
    sget-object v5, LP5/k;->d:LP5/k;

    .line 343
    .line 344
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 345
    .line 346
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 347
    .line 348
    .line 349
    move-result v6

    .line 350
    if-eqz v6, :cond_1a

    .line 351
    .line 352
    goto/16 :goto_0

    .line 353
    .line 354
    :cond_1a
    sget-object v5, LP5/k;->e:LP5/k;

    .line 355
    .line 356
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 357
    .line 358
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 359
    .line 360
    .line 361
    move-result v6

    .line 362
    if-eqz v6, :cond_1b

    .line 363
    .line 364
    goto/16 :goto_0

    .line 365
    .line 366
    :cond_1b
    sget-object v5, LP5/k;->f:LP5/k;

    .line 367
    .line 368
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 369
    .line 370
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 371
    .line 372
    .line 373
    move-result v6

    .line 374
    if-eqz v6, :cond_1c

    .line 375
    .line 376
    goto/16 :goto_0

    .line 377
    .line 378
    :cond_1c
    sget-object v5, LP5/k;->g:LP5/k;

    .line 379
    .line 380
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 381
    .line 382
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 383
    .line 384
    .line 385
    move-result v6

    .line 386
    if-eqz v6, :cond_1d

    .line 387
    .line 388
    goto/16 :goto_0

    .line 389
    .line 390
    :cond_1d
    sget-object v5, LP5/k;->i:LP5/k;

    .line 391
    .line 392
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 393
    .line 394
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 395
    .line 396
    .line 397
    move-result v6

    .line 398
    if-eqz v6, :cond_1e

    .line 399
    .line 400
    goto :goto_0

    .line 401
    :cond_1e
    sget-object v5, LP5/k;->j:LP5/k;

    .line 402
    .line 403
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 404
    .line 405
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 406
    .line 407
    .line 408
    move-result v6

    .line 409
    if-eqz v6, :cond_1f

    .line 410
    .line 411
    goto :goto_0

    .line 412
    :cond_1f
    sget-object v5, LP5/k;->o:LP5/k;

    .line 413
    .line 414
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 415
    .line 416
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 417
    .line 418
    .line 419
    move-result v6

    .line 420
    if-eqz v6, :cond_20

    .line 421
    .line 422
    goto :goto_0

    .line 423
    :cond_20
    sget-object v5, LP5/k;->p:LP5/k;

    .line 424
    .line 425
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 426
    .line 427
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 428
    .line 429
    .line 430
    move-result v6

    .line 431
    if-eqz v6, :cond_21

    .line 432
    .line 433
    goto :goto_0

    .line 434
    :cond_21
    sget-object v5, LP5/k;->t:LP5/k;

    .line 435
    .line 436
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 437
    .line 438
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 439
    .line 440
    .line 441
    move-result v6

    .line 442
    if-eqz v6, :cond_22

    .line 443
    .line 444
    goto :goto_0

    .line 445
    :cond_22
    sget-object v5, LP5/k;->v:LP5/k;

    .line 446
    .line 447
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 448
    .line 449
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 450
    .line 451
    .line 452
    move-result v6

    .line 453
    if-eqz v6, :cond_23

    .line 454
    .line 455
    goto :goto_0

    .line 456
    :cond_23
    sget-object v5, LP5/k;->w:LP5/k;

    .line 457
    .line 458
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 459
    .line 460
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 461
    .line 462
    .line 463
    move-result v6

    .line 464
    if-eqz v6, :cond_24

    .line 465
    .line 466
    goto :goto_0

    .line 467
    :cond_24
    sget-object v5, LP5/k;->A:LP5/k;

    .line 468
    .line 469
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 470
    .line 471
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 472
    .line 473
    .line 474
    move-result v6

    .line 475
    if-eqz v6, :cond_25

    .line 476
    .line 477
    goto :goto_0

    .line 478
    :cond_25
    sget-object v5, LP5/k;->B:LP5/k;

    .line 479
    .line 480
    iget-object v6, v5, LP5/a;->a:Ljava/lang/String;

    .line 481
    .line 482
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 483
    .line 484
    .line 485
    move-result v6

    .line 486
    if-eqz v6, :cond_26

    .line 487
    .line 488
    goto :goto_0

    .line 489
    :cond_26
    new-instance v5, LP5/k;

    .line 490
    .line 491
    invoke-direct {v5, v2}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 492
    .line 493
    .line 494
    :goto_0
    instance-of v2, v5, LP5/k;

    .line 495
    .line 496
    if-eqz v2, :cond_50

    .line 497
    .line 498
    move-object v7, v5

    .line 499
    check-cast v7, LP5/k;

    .line 500
    .line 501
    iget-object v2, v4, LP5/a;->a:Ljava/lang/String;

    .line 502
    .line 503
    iget-object v4, v7, LP5/a;->a:Ljava/lang/String;

    .line 504
    .line 505
    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 506
    .line 507
    .line 508
    move-result v2

    .line 509
    if-nez v2, :cond_4f

    .line 510
    .line 511
    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 512
    .line 513
    .line 514
    move-result-object v2

    .line 515
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 516
    .line 517
    .line 518
    move-result-object v2

    .line 519
    const/4 v5, 0x1

    .line 520
    move/from16 v18, v5

    .line 521
    .line 522
    const/4 v8, 0x0

    .line 523
    const/4 v9, 0x0

    .line 524
    const/4 v10, 0x0

    .line 525
    const/4 v11, 0x0

    .line 526
    const/4 v12, 0x0

    .line 527
    const/4 v13, 0x0

    .line 528
    const/4 v14, 0x0

    .line 529
    const/4 v15, 0x0

    .line 530
    const/16 v16, 0x0

    .line 531
    .line 532
    const/16 v17, 0x0

    .line 533
    .line 534
    const/16 v19, 0x0

    .line 535
    .line 536
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 537
    .line 538
    .line 539
    move-result v5

    .line 540
    if-eqz v5, :cond_4e

    .line 541
    .line 542
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 543
    .line 544
    .line 545
    move-result-object v5

    .line 546
    check-cast v5, Ljava/lang/String;

    .line 547
    .line 548
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 549
    .line 550
    .line 551
    move-result v6

    .line 552
    if-eqz v6, :cond_28

    .line 553
    .line 554
    :cond_27
    :goto_2
    move-object/from16 v21, v1

    .line 555
    .line 556
    move-object/from16 v22, v2

    .line 557
    .line 558
    move-object/from16 v24, v7

    .line 559
    .line 560
    goto/16 :goto_d

    .line 561
    .line 562
    :cond_28
    const-string v6, "typ"

    .line 563
    .line 564
    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 565
    .line 566
    .line 567
    move-result v6

    .line 568
    const-class v4, Ljava/lang/String;

    .line 569
    .line 570
    if-eqz v6, :cond_29

    .line 571
    .line 572
    invoke-static {v0, v5, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 573
    .line 574
    .line 575
    move-result-object v4

    .line 576
    check-cast v4, Ljava/lang/String;

    .line 577
    .line 578
    if-eqz v4, :cond_27

    .line 579
    .line 580
    new-instance v8, LP5/f;

    .line 581
    .line 582
    invoke-direct {v8, v4}, LP5/f;-><init>(Ljava/lang/String;)V

    .line 583
    .line 584
    .line 585
    goto :goto_2

    .line 586
    :cond_29
    const-string v6, "cty"

    .line 587
    .line 588
    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 589
    .line 590
    .line 591
    move-result v6

    .line 592
    if-eqz v6, :cond_2a

    .line 593
    .line 594
    invoke-static {v0, v5, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 595
    .line 596
    .line 597
    move-result-object v4

    .line 598
    move-object v9, v4

    .line 599
    check-cast v9, Ljava/lang/String;

    .line 600
    .line 601
    goto :goto_2

    .line 602
    :cond_2a
    const-string v6, "crit"

    .line 603
    .line 604
    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 605
    .line 606
    .line 607
    move-result v6

    .line 608
    if-eqz v6, :cond_2b

    .line 609
    .line 610
    invoke-static {v5, v0}, LZ5/c;->e(Ljava/lang/String;Ljava/util/Map;)Ljava/util/List;

    .line 611
    .line 612
    .line 613
    move-result-object v4

    .line 614
    if-eqz v4, :cond_27

    .line 615
    .line 616
    new-instance v10, Ljava/util/HashSet;

    .line 617
    .line 618
    invoke-direct {v10, v4}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 619
    .line 620
    .line 621
    goto :goto_2

    .line 622
    :cond_2b
    const-string v6, "jku"

    .line 623
    .line 624
    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 625
    .line 626
    .line 627
    move-result v6

    .line 628
    if-eqz v6, :cond_2c

    .line 629
    .line 630
    invoke-static {v5, v0}, LZ5/c;->f(Ljava/lang/String;Ljava/util/Map;)Ljava/net/URI;

    .line 631
    .line 632
    .line 633
    move-result-object v11

    .line 634
    goto :goto_2

    .line 635
    :cond_2c
    const-string v6, "jwk"

    .line 636
    .line 637
    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 638
    .line 639
    .line 640
    move-result v6

    .line 641
    const-class v3, Ljava/util/List;

    .line 642
    .line 643
    move-object/from16 v21, v1

    .line 644
    .line 645
    const-string v1, "x5t#S256"

    .line 646
    .line 647
    move-object/from16 v22, v2

    .line 648
    .line 649
    const-string v2, "x5t"

    .line 650
    .line 651
    move/from16 v23, v6

    .line 652
    .line 653
    const-string v6, "x5u"

    .line 654
    .line 655
    move-object/from16 v24, v7

    .line 656
    .line 657
    const-string v7, "kid"

    .line 658
    .line 659
    move-object/from16 v25, v8

    .line 660
    .line 661
    const-string v8, "JSON object member with key "

    .line 662
    .line 663
    if-eqz v23, :cond_42

    .line 664
    .line 665
    const-class v12, Ljava/util/Map;

    .line 666
    .line 667
    invoke-static {v0, v5, v12}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 668
    .line 669
    .line 670
    move-result-object v12

    .line 671
    check-cast v12, Ljava/util/Map;

    .line 672
    .line 673
    if-nez v12, :cond_2e

    .line 674
    .line 675
    const/4 v12, 0x0

    .line 676
    :cond_2d
    move-object/from16 v26, v9

    .line 677
    .line 678
    goto :goto_4

    .line 679
    :cond_2e
    invoke-interface {v12}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 680
    .line 681
    .line 682
    move-result-object v23

    .line 683
    invoke-interface/range {v23 .. v23}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 684
    .line 685
    .line 686
    move-result-object v23

    .line 687
    :goto_3
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->hasNext()Z

    .line 688
    .line 689
    .line 690
    move-result v26

    .line 691
    if-eqz v26, :cond_2d

    .line 692
    .line 693
    move-object/from16 v26, v9

    .line 694
    .line 695
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 696
    .line 697
    .line 698
    move-result-object v9

    .line 699
    instance-of v9, v9, Ljava/lang/String;

    .line 700
    .line 701
    if-eqz v9, :cond_2f

    .line 702
    .line 703
    move-object/from16 v9, v26

    .line 704
    .line 705
    goto :goto_3

    .line 706
    :cond_2f
    new-instance v0, Ljava/text/ParseException;

    .line 707
    .line 708
    const-string v1, " not a JSON object"

    .line 709
    .line 710
    invoke-static {v8, v5, v1}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 711
    .line 712
    .line 713
    move-result-object v1

    .line 714
    const/4 v2, 0x0

    .line 715
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 716
    .line 717
    .line 718
    throw v0

    .line 719
    :goto_4
    if-nez v12, :cond_30

    .line 720
    .line 721
    move-object/from16 v23, v10

    .line 722
    .line 723
    move-object/from16 v27, v11

    .line 724
    .line 725
    const/4 v12, 0x0

    .line 726
    goto/16 :goto_a

    .line 727
    .line 728
    :cond_30
    const-string v5, "kty"

    .line 729
    .line 730
    invoke-static {v12, v5, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 731
    .line 732
    .line 733
    move-result-object v5

    .line 734
    check-cast v5, Ljava/lang/String;

    .line 735
    .line 736
    if-eqz v5, :cond_41

    .line 737
    .line 738
    invoke-static {v5}, LT5/h;->a(Ljava/lang/String;)LT5/h;

    .line 739
    .line 740
    .line 741
    move-result-object v5

    .line 742
    sget-object v8, LT5/h;->b:LT5/h;

    .line 743
    .line 744
    const-string v9, "x"

    .line 745
    .line 746
    move-object/from16 v23, v10

    .line 747
    .line 748
    const-string v10, "crv"

    .line 749
    .line 750
    move-object/from16 v27, v11

    .line 751
    .line 752
    const-string v11, "d"

    .line 753
    .line 754
    if-ne v5, v8, :cond_33

    .line 755
    .line 756
    sget-object v3, LT5/b;->H:Ljava/util/Set;

    .line 757
    .line 758
    invoke-static {v12}, Lz5/l;->w(Ljava/util/Map;)LT5/h;

    .line 759
    .line 760
    .line 761
    move-result-object v3

    .line 762
    invoke-virtual {v8, v3}, LT5/h;->equals(Ljava/lang/Object;)Z

    .line 763
    .line 764
    .line 765
    move-result v3

    .line 766
    if-eqz v3, :cond_32

    .line 767
    .line 768
    :try_start_0
    invoke-static {v12, v10, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 769
    .line 770
    .line 771
    move-result-object v3

    .line 772
    check-cast v3, Ljava/lang/String;

    .line 773
    .line 774
    invoke-static {v3}, LT5/a;->a(Ljava/lang/String;)LT5/a;

    .line 775
    .line 776
    .line 777
    move-result-object v29
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1

    .line 778
    invoke-static {v9, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 779
    .line 780
    .line 781
    move-result-object v30

    .line 782
    const-string v3, "y"

    .line 783
    .line 784
    invoke-static {v3, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 785
    .line 786
    .line 787
    move-result-object v31

    .line 788
    invoke-static {v11, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 789
    .line 790
    .line 791
    move-result-object v32

    .line 792
    if-nez v32, :cond_31

    .line 793
    .line 794
    :try_start_1
    new-instance v28, LT5/b;

    .line 795
    .line 796
    invoke-static {v12}, Lz5/l;->x(Ljava/util/Map;)LT5/i;

    .line 797
    .line 798
    .line 799
    move-result-object v32

    .line 800
    invoke-static {v12}, Lz5/l;->v(Ljava/util/Map;)Ljava/util/LinkedHashSet;

    .line 801
    .line 802
    .line 803
    move-result-object v33

    .line 804
    invoke-static {v12}, Lz5/l;->s(Ljava/util/Map;)LP5/a;

    .line 805
    .line 806
    .line 807
    move-result-object v34

    .line 808
    invoke-static {v12, v7, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 809
    .line 810
    .line 811
    move-result-object v3

    .line 812
    move-object/from16 v35, v3

    .line 813
    .line 814
    check-cast v35, Ljava/lang/String;

    .line 815
    .line 816
    invoke-static {v6, v12}, LZ5/c;->f(Ljava/lang/String;Ljava/util/Map;)Ljava/net/URI;

    .line 817
    .line 818
    .line 819
    move-result-object v36

    .line 820
    invoke-static {v2, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 821
    .line 822
    .line 823
    move-result-object v37

    .line 824
    invoke-static {v1, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 825
    .line 826
    .line 827
    move-result-object v38

    .line 828
    invoke-static {v12}, Lz5/l;->z(Ljava/util/Map;)Ljava/util/LinkedList;

    .line 829
    .line 830
    .line 831
    move-result-object v39

    .line 832
    invoke-static {v12}, Lz5/l;->t(Ljava/util/Map;)Ljava/util/Date;

    .line 833
    .line 834
    .line 835
    move-result-object v40

    .line 836
    invoke-static {v12}, Lz5/l;->y(Ljava/util/Map;)Ljava/util/Date;

    .line 837
    .line 838
    .line 839
    move-result-object v41

    .line 840
    invoke-static {v12}, Lz5/l;->u(Ljava/util/Map;)Ljava/util/Date;

    .line 841
    .line 842
    .line 843
    move-result-object v42

    .line 844
    invoke-direct/range {v28 .. v42}, LT5/b;-><init>(LT5/a;LZ5/b;LZ5/b;LT5/i;Ljava/util/LinkedHashSet;LP5/a;Ljava/lang/String;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/util/Date;Ljava/util/Date;Ljava/util/Date;)V

    .line 845
    .line 846
    .line 847
    goto/16 :goto_9

    .line 848
    .line 849
    :catch_0
    move-exception v0

    .line 850
    goto :goto_5

    .line 851
    :cond_31
    new-instance v28, LT5/b;

    .line 852
    .line 853
    invoke-static {v12}, Lz5/l;->x(Ljava/util/Map;)LT5/i;

    .line 854
    .line 855
    .line 856
    move-result-object v33

    .line 857
    invoke-static {v12}, Lz5/l;->v(Ljava/util/Map;)Ljava/util/LinkedHashSet;

    .line 858
    .line 859
    .line 860
    move-result-object v34

    .line 861
    invoke-static {v12}, Lz5/l;->s(Ljava/util/Map;)LP5/a;

    .line 862
    .line 863
    .line 864
    move-result-object v35

    .line 865
    invoke-static {v12, v7, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 866
    .line 867
    .line 868
    move-result-object v3

    .line 869
    move-object/from16 v36, v3

    .line 870
    .line 871
    check-cast v36, Ljava/lang/String;

    .line 872
    .line 873
    invoke-static {v6, v12}, LZ5/c;->f(Ljava/lang/String;Ljava/util/Map;)Ljava/net/URI;

    .line 874
    .line 875
    .line 876
    move-result-object v37

    .line 877
    invoke-static {v2, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 878
    .line 879
    .line 880
    move-result-object v38

    .line 881
    invoke-static {v1, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 882
    .line 883
    .line 884
    move-result-object v39

    .line 885
    invoke-static {v12}, Lz5/l;->z(Ljava/util/Map;)Ljava/util/LinkedList;

    .line 886
    .line 887
    .line 888
    move-result-object v40

    .line 889
    invoke-static {v12}, Lz5/l;->t(Ljava/util/Map;)Ljava/util/Date;

    .line 890
    .line 891
    .line 892
    move-result-object v41

    .line 893
    invoke-static {v12}, Lz5/l;->y(Ljava/util/Map;)Ljava/util/Date;

    .line 894
    .line 895
    .line 896
    move-result-object v42

    .line 897
    invoke-static {v12}, Lz5/l;->u(Ljava/util/Map;)Ljava/util/Date;

    .line 898
    .line 899
    .line 900
    move-result-object v43

    .line 901
    invoke-direct/range {v28 .. v43}, LT5/b;-><init>(LT5/a;LZ5/b;LZ5/b;LZ5/b;LT5/i;Ljava/util/LinkedHashSet;LP5/a;Ljava/lang/String;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/util/Date;Ljava/util/Date;Ljava/util/Date;)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    .line 902
    .line 903
    .line 904
    goto/16 :goto_9

    .line 905
    .line 906
    :goto_5
    new-instance v1, Ljava/text/ParseException;

    .line 907
    .line 908
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 909
    .line 910
    .line 911
    move-result-object v0

    .line 912
    const/4 v2, 0x0

    .line 913
    invoke-direct {v1, v0, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 914
    .line 915
    .line 916
    throw v1

    .line 917
    :catch_1
    move-exception v0

    .line 918
    new-instance v1, Ljava/text/ParseException;

    .line 919
    .line 920
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 921
    .line 922
    .line 923
    move-result-object v0

    .line 924
    const/4 v2, 0x0

    .line 925
    invoke-direct {v1, v0, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 926
    .line 927
    .line 928
    throw v1

    .line 929
    :cond_32
    const/4 v2, 0x0

    .line 930
    new-instance v0, Ljava/text/ParseException;

    .line 931
    .line 932
    const-string v1, "The key type \"kty\" must be EC"

    .line 933
    .line 934
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 935
    .line 936
    .line 937
    throw v0

    .line 938
    :cond_33
    sget-object v8, LT5/h;->c:LT5/h;

    .line 939
    .line 940
    if-ne v5, v8, :cond_38

    .line 941
    .line 942
    invoke-static {v12}, Lz5/l;->w(Ljava/util/Map;)LT5/h;

    .line 943
    .line 944
    .line 945
    move-result-object v5

    .line 946
    invoke-virtual {v8, v5}, LT5/h;->equals(Ljava/lang/Object;)Z

    .line 947
    .line 948
    .line 949
    move-result v5

    .line 950
    if-eqz v5, :cond_37

    .line 951
    .line 952
    const-string v5, "n"

    .line 953
    .line 954
    invoke-static {v5, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 955
    .line 956
    .line 957
    move-result-object v29

    .line 958
    const-string v5, "e"

    .line 959
    .line 960
    invoke-static {v5, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 961
    .line 962
    .line 963
    move-result-object v30

    .line 964
    invoke-static {v11, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 965
    .line 966
    .line 967
    move-result-object v31

    .line 968
    const-string v5, "p"

    .line 969
    .line 970
    invoke-static {v5, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 971
    .line 972
    .line 973
    move-result-object v32

    .line 974
    const-string v5, "q"

    .line 975
    .line 976
    invoke-static {v5, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 977
    .line 978
    .line 979
    move-result-object v33

    .line 980
    const-string v5, "dp"

    .line 981
    .line 982
    invoke-static {v5, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 983
    .line 984
    .line 985
    move-result-object v34

    .line 986
    const-string v5, "dq"

    .line 987
    .line 988
    invoke-static {v5, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 989
    .line 990
    .line 991
    move-result-object v35

    .line 992
    const-string v8, "qi"

    .line 993
    .line 994
    invoke-static {v8, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 995
    .line 996
    .line 997
    move-result-object v36

    .line 998
    const-string v8, "oth"

    .line 999
    .line 1000
    invoke-interface {v12, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 1001
    .line 1002
    .line 1003
    move-result v9

    .line 1004
    if-eqz v9, :cond_36

    .line 1005
    .line 1006
    invoke-static {v12, v8, v3}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1007
    .line 1008
    .line 1009
    move-result-object v3

    .line 1010
    check-cast v3, Ljava/util/List;

    .line 1011
    .line 1012
    if-eqz v3, :cond_36

    .line 1013
    .line 1014
    new-instance v8, Ljava/util/ArrayList;

    .line 1015
    .line 1016
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 1017
    .line 1018
    .line 1019
    move-result v9

    .line 1020
    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 1021
    .line 1022
    .line 1023
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1024
    .line 1025
    .line 1026
    move-result-object v3

    .line 1027
    :goto_6
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1028
    .line 1029
    .line 1030
    move-result v9

    .line 1031
    if-eqz v9, :cond_35

    .line 1032
    .line 1033
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1034
    .line 1035
    .line 1036
    move-result-object v9

    .line 1037
    instance-of v10, v9, Ljava/util/Map;

    .line 1038
    .line 1039
    if-eqz v10, :cond_34

    .line 1040
    .line 1041
    check-cast v9, Ljava/util/Map;

    .line 1042
    .line 1043
    const-string v10, "r"

    .line 1044
    .line 1045
    invoke-static {v10, v9}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1046
    .line 1047
    .line 1048
    move-result-object v10

    .line 1049
    invoke-static {v5, v9}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1050
    .line 1051
    .line 1052
    move-result-object v11

    .line 1053
    move-object/from16 v28, v3

    .line 1054
    .line 1055
    const-string v3, "t"

    .line 1056
    .line 1057
    invoke-static {v3, v9}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1058
    .line 1059
    .line 1060
    move-result-object v3

    .line 1061
    :try_start_2
    new-instance v9, LT5/m;

    .line 1062
    .line 1063
    invoke-direct {v9, v10, v11, v3}, LT5/m;-><init>(LZ5/b;LZ5/b;LZ5/b;)V

    .line 1064
    .line 1065
    .line 1066
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_2

    .line 1067
    .line 1068
    .line 1069
    goto :goto_7

    .line 1070
    :catch_2
    move-exception v0

    .line 1071
    new-instance v1, Ljava/text/ParseException;

    .line 1072
    .line 1073
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1074
    .line 1075
    .line 1076
    move-result-object v0

    .line 1077
    const/4 v2, 0x0

    .line 1078
    invoke-direct {v1, v0, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1079
    .line 1080
    .line 1081
    throw v1

    .line 1082
    :cond_34
    move-object/from16 v28, v3

    .line 1083
    .line 1084
    :goto_7
    move-object/from16 v3, v28

    .line 1085
    .line 1086
    goto :goto_6

    .line 1087
    :cond_35
    move-object/from16 v37, v8

    .line 1088
    .line 1089
    goto :goto_8

    .line 1090
    :cond_36
    const/16 v37, 0x0

    .line 1091
    .line 1092
    :goto_8
    :try_start_3
    new-instance v28, LT5/n;

    .line 1093
    .line 1094
    invoke-static {v12}, Lz5/l;->x(Ljava/util/Map;)LT5/i;

    .line 1095
    .line 1096
    .line 1097
    move-result-object v38

    .line 1098
    invoke-static {v12}, Lz5/l;->v(Ljava/util/Map;)Ljava/util/LinkedHashSet;

    .line 1099
    .line 1100
    .line 1101
    move-result-object v39

    .line 1102
    invoke-static {v12}, Lz5/l;->s(Ljava/util/Map;)LP5/a;

    .line 1103
    .line 1104
    .line 1105
    move-result-object v40

    .line 1106
    invoke-static {v12, v7, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1107
    .line 1108
    .line 1109
    move-result-object v3

    .line 1110
    move-object/from16 v41, v3

    .line 1111
    .line 1112
    check-cast v41, Ljava/lang/String;

    .line 1113
    .line 1114
    invoke-static {v6, v12}, LZ5/c;->f(Ljava/lang/String;Ljava/util/Map;)Ljava/net/URI;

    .line 1115
    .line 1116
    .line 1117
    move-result-object v42

    .line 1118
    invoke-static {v2, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1119
    .line 1120
    .line 1121
    move-result-object v43

    .line 1122
    invoke-static {v1, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1123
    .line 1124
    .line 1125
    move-result-object v44

    .line 1126
    invoke-static {v12}, Lz5/l;->z(Ljava/util/Map;)Ljava/util/LinkedList;

    .line 1127
    .line 1128
    .line 1129
    move-result-object v45

    .line 1130
    invoke-static {v12}, Lz5/l;->t(Ljava/util/Map;)Ljava/util/Date;

    .line 1131
    .line 1132
    .line 1133
    move-result-object v46

    .line 1134
    invoke-static {v12}, Lz5/l;->y(Ljava/util/Map;)Ljava/util/Date;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v47

    .line 1138
    invoke-static {v12}, Lz5/l;->u(Ljava/util/Map;)Ljava/util/Date;

    .line 1139
    .line 1140
    .line 1141
    move-result-object v48

    .line 1142
    invoke-direct/range {v28 .. v48}, LT5/n;-><init>(LZ5/b;LZ5/b;LZ5/b;LZ5/b;LZ5/b;LZ5/b;LZ5/b;LZ5/b;Ljava/util/ArrayList;LT5/i;Ljava/util/LinkedHashSet;LP5/a;Ljava/lang/String;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/util/Date;Ljava/util/Date;Ljava/util/Date;)V
    :try_end_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_3

    .line 1143
    .line 1144
    .line 1145
    goto/16 :goto_9

    .line 1146
    .line 1147
    :catch_3
    move-exception v0

    .line 1148
    new-instance v1, Ljava/text/ParseException;

    .line 1149
    .line 1150
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1151
    .line 1152
    .line 1153
    move-result-object v0

    .line 1154
    const/4 v2, 0x0

    .line 1155
    invoke-direct {v1, v0, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1156
    .line 1157
    .line 1158
    throw v1

    .line 1159
    :cond_37
    const/4 v2, 0x0

    .line 1160
    new-instance v0, Ljava/text/ParseException;

    .line 1161
    .line 1162
    const-string v1, "The key type \"kty\" must be RSA"

    .line 1163
    .line 1164
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1165
    .line 1166
    .line 1167
    throw v0

    .line 1168
    :cond_38
    sget-object v3, LT5/h;->d:LT5/h;

    .line 1169
    .line 1170
    const-string v8, "The key type kty must be "

    .line 1171
    .line 1172
    if-ne v5, v3, :cond_3a

    .line 1173
    .line 1174
    invoke-static {v12}, Lz5/l;->w(Ljava/util/Map;)LT5/h;

    .line 1175
    .line 1176
    .line 1177
    move-result-object v5

    .line 1178
    invoke-virtual {v3, v5}, LT5/h;->equals(Ljava/lang/Object;)Z

    .line 1179
    .line 1180
    .line 1181
    move-result v5

    .line 1182
    if-eqz v5, :cond_39

    .line 1183
    .line 1184
    const-string v3, "k"

    .line 1185
    .line 1186
    invoke-static {v3, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1187
    .line 1188
    .line 1189
    move-result-object v29

    .line 1190
    :try_start_4
    new-instance v28, LT5/l;

    .line 1191
    .line 1192
    invoke-static {v12}, Lz5/l;->x(Ljava/util/Map;)LT5/i;

    .line 1193
    .line 1194
    .line 1195
    move-result-object v30

    .line 1196
    invoke-static {v12}, Lz5/l;->v(Ljava/util/Map;)Ljava/util/LinkedHashSet;

    .line 1197
    .line 1198
    .line 1199
    move-result-object v31

    .line 1200
    invoke-static {v12}, Lz5/l;->s(Ljava/util/Map;)LP5/a;

    .line 1201
    .line 1202
    .line 1203
    move-result-object v32

    .line 1204
    invoke-static {v12, v7, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1205
    .line 1206
    .line 1207
    move-result-object v3

    .line 1208
    move-object/from16 v33, v3

    .line 1209
    .line 1210
    check-cast v33, Ljava/lang/String;

    .line 1211
    .line 1212
    invoke-static {v6, v12}, LZ5/c;->f(Ljava/lang/String;Ljava/util/Map;)Ljava/net/URI;

    .line 1213
    .line 1214
    .line 1215
    move-result-object v34

    .line 1216
    invoke-static {v2, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1217
    .line 1218
    .line 1219
    move-result-object v35

    .line 1220
    invoke-static {v1, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1221
    .line 1222
    .line 1223
    move-result-object v36

    .line 1224
    invoke-static {v12}, Lz5/l;->z(Ljava/util/Map;)Ljava/util/LinkedList;

    .line 1225
    .line 1226
    .line 1227
    move-result-object v37

    .line 1228
    invoke-static {v12}, Lz5/l;->t(Ljava/util/Map;)Ljava/util/Date;

    .line 1229
    .line 1230
    .line 1231
    move-result-object v38

    .line 1232
    invoke-static {v12}, Lz5/l;->y(Ljava/util/Map;)Ljava/util/Date;

    .line 1233
    .line 1234
    .line 1235
    move-result-object v39

    .line 1236
    invoke-static {v12}, Lz5/l;->u(Ljava/util/Map;)Ljava/util/Date;

    .line 1237
    .line 1238
    .line 1239
    move-result-object v40

    .line 1240
    invoke-direct/range {v28 .. v40}, LT5/l;-><init>(LZ5/b;LT5/i;Ljava/util/LinkedHashSet;LP5/a;Ljava/lang/String;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/util/Date;Ljava/util/Date;Ljava/util/Date;)V
    :try_end_4
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4 .. :try_end_4} :catch_4

    .line 1241
    .line 1242
    .line 1243
    goto/16 :goto_9

    .line 1244
    .line 1245
    :catch_4
    move-exception v0

    .line 1246
    new-instance v1, Ljava/text/ParseException;

    .line 1247
    .line 1248
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1249
    .line 1250
    .line 1251
    move-result-object v0

    .line 1252
    const/4 v2, 0x0

    .line 1253
    invoke-direct {v1, v0, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1254
    .line 1255
    .line 1256
    throw v1

    .line 1257
    :cond_39
    const/4 v2, 0x0

    .line 1258
    new-instance v0, Ljava/text/ParseException;

    .line 1259
    .line 1260
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1261
    .line 1262
    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1263
    .line 1264
    .line 1265
    iget-object v3, v3, LT5/h;->a:Ljava/lang/String;

    .line 1266
    .line 1267
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1268
    .line 1269
    .line 1270
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1271
    .line 1272
    .line 1273
    move-result-object v1

    .line 1274
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1275
    .line 1276
    .line 1277
    throw v0

    .line 1278
    :cond_3a
    sget-object v3, LT5/h;->e:LT5/h;

    .line 1279
    .line 1280
    if-ne v5, v3, :cond_40

    .line 1281
    .line 1282
    sget-object v5, LT5/k;->L:Ljava/util/Set;

    .line 1283
    .line 1284
    invoke-static {v12}, Lz5/l;->w(Ljava/util/Map;)LT5/h;

    .line 1285
    .line 1286
    .line 1287
    move-result-object v5

    .line 1288
    invoke-virtual {v3, v5}, LT5/h;->equals(Ljava/lang/Object;)Z

    .line 1289
    .line 1290
    .line 1291
    move-result v5

    .line 1292
    if-eqz v5, :cond_3f

    .line 1293
    .line 1294
    :try_start_5
    invoke-static {v12, v10, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1295
    .line 1296
    .line 1297
    move-result-object v3

    .line 1298
    check-cast v3, Ljava/lang/String;

    .line 1299
    .line 1300
    invoke-static {v3}, LT5/a;->a(Ljava/lang/String;)LT5/a;

    .line 1301
    .line 1302
    .line 1303
    move-result-object v29
    :try_end_5
    .catch Ljava/lang/IllegalArgumentException; {:try_start_5 .. :try_end_5} :catch_6

    .line 1304
    invoke-static {v9, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1305
    .line 1306
    .line 1307
    move-result-object v30

    .line 1308
    invoke-static {v11, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1309
    .line 1310
    .line 1311
    move-result-object v31

    .line 1312
    if-nez v31, :cond_3b

    .line 1313
    .line 1314
    :try_start_6
    new-instance v28, LT5/k;

    .line 1315
    .line 1316
    invoke-static {v12}, Lz5/l;->x(Ljava/util/Map;)LT5/i;

    .line 1317
    .line 1318
    .line 1319
    move-result-object v31

    .line 1320
    invoke-static {v12}, Lz5/l;->v(Ljava/util/Map;)Ljava/util/LinkedHashSet;

    .line 1321
    .line 1322
    .line 1323
    move-result-object v32

    .line 1324
    invoke-static {v12}, Lz5/l;->s(Ljava/util/Map;)LP5/a;

    .line 1325
    .line 1326
    .line 1327
    move-result-object v33

    .line 1328
    invoke-static {v12, v7, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1329
    .line 1330
    .line 1331
    move-result-object v3

    .line 1332
    move-object/from16 v34, v3

    .line 1333
    .line 1334
    check-cast v34, Ljava/lang/String;

    .line 1335
    .line 1336
    invoke-static {v6, v12}, LZ5/c;->f(Ljava/lang/String;Ljava/util/Map;)Ljava/net/URI;

    .line 1337
    .line 1338
    .line 1339
    move-result-object v35

    .line 1340
    invoke-static {v2, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1341
    .line 1342
    .line 1343
    move-result-object v36

    .line 1344
    invoke-static {v1, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1345
    .line 1346
    .line 1347
    move-result-object v37

    .line 1348
    invoke-static {v12}, Lz5/l;->z(Ljava/util/Map;)Ljava/util/LinkedList;

    .line 1349
    .line 1350
    .line 1351
    move-result-object v38

    .line 1352
    invoke-static {v12}, Lz5/l;->t(Ljava/util/Map;)Ljava/util/Date;

    .line 1353
    .line 1354
    .line 1355
    move-result-object v39

    .line 1356
    invoke-static {v12}, Lz5/l;->y(Ljava/util/Map;)Ljava/util/Date;

    .line 1357
    .line 1358
    .line 1359
    move-result-object v40

    .line 1360
    invoke-static {v12}, Lz5/l;->u(Ljava/util/Map;)Ljava/util/Date;

    .line 1361
    .line 1362
    .line 1363
    move-result-object v41

    .line 1364
    invoke-direct/range {v28 .. v41}, LT5/k;-><init>(LT5/a;LZ5/b;LT5/i;Ljava/util/LinkedHashSet;LP5/a;Ljava/lang/String;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/util/Date;Ljava/util/Date;Ljava/util/Date;)V

    .line 1365
    .line 1366
    .line 1367
    goto :goto_9

    .line 1368
    :catch_5
    move-exception v0

    .line 1369
    goto :goto_c

    .line 1370
    :cond_3b
    new-instance v28, LT5/k;

    .line 1371
    .line 1372
    invoke-static {v12}, Lz5/l;->x(Ljava/util/Map;)LT5/i;

    .line 1373
    .line 1374
    .line 1375
    move-result-object v32

    .line 1376
    invoke-static {v12}, Lz5/l;->v(Ljava/util/Map;)Ljava/util/LinkedHashSet;

    .line 1377
    .line 1378
    .line 1379
    move-result-object v33

    .line 1380
    invoke-static {v12}, Lz5/l;->s(Ljava/util/Map;)LP5/a;

    .line 1381
    .line 1382
    .line 1383
    move-result-object v34

    .line 1384
    invoke-static {v12, v7, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1385
    .line 1386
    .line 1387
    move-result-object v3

    .line 1388
    move-object/from16 v35, v3

    .line 1389
    .line 1390
    check-cast v35, Ljava/lang/String;

    .line 1391
    .line 1392
    invoke-static {v6, v12}, LZ5/c;->f(Ljava/lang/String;Ljava/util/Map;)Ljava/net/URI;

    .line 1393
    .line 1394
    .line 1395
    move-result-object v36

    .line 1396
    invoke-static {v2, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1397
    .line 1398
    .line 1399
    move-result-object v37

    .line 1400
    invoke-static {v1, v12}, LZ5/c;->a(Ljava/lang/String;Ljava/util/Map;)LZ5/b;

    .line 1401
    .line 1402
    .line 1403
    move-result-object v38

    .line 1404
    invoke-static {v12}, Lz5/l;->z(Ljava/util/Map;)Ljava/util/LinkedList;

    .line 1405
    .line 1406
    .line 1407
    move-result-object v39

    .line 1408
    invoke-static {v12}, Lz5/l;->t(Ljava/util/Map;)Ljava/util/Date;

    .line 1409
    .line 1410
    .line 1411
    move-result-object v40

    .line 1412
    invoke-static {v12}, Lz5/l;->y(Ljava/util/Map;)Ljava/util/Date;

    .line 1413
    .line 1414
    .line 1415
    move-result-object v41

    .line 1416
    invoke-static {v12}, Lz5/l;->u(Ljava/util/Map;)Ljava/util/Date;

    .line 1417
    .line 1418
    .line 1419
    move-result-object v42

    .line 1420
    invoke-direct/range {v28 .. v42}, LT5/k;-><init>(LT5/a;LZ5/b;LZ5/b;LT5/i;Ljava/util/LinkedHashSet;LP5/a;Ljava/lang/String;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/util/Date;Ljava/util/Date;Ljava/util/Date;)V
    :try_end_6
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_6} :catch_5

    .line 1421
    .line 1422
    .line 1423
    :goto_9
    invoke-virtual/range {v28 .. v28}, LT5/d;->b()Z

    .line 1424
    .line 1425
    .line 1426
    move-result v1

    .line 1427
    if-nez v1, :cond_3e

    .line 1428
    .line 1429
    move-object/from16 v12, v28

    .line 1430
    .line 1431
    :goto_a
    if-eqz v12, :cond_3d

    .line 1432
    .line 1433
    invoke-virtual {v12}, LT5/d;->b()Z

    .line 1434
    .line 1435
    .line 1436
    move-result v1

    .line 1437
    if-nez v1, :cond_3c

    .line 1438
    .line 1439
    goto :goto_b

    .line 1440
    :cond_3c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 1441
    .line 1442
    const-string v1, "The JWK must be public"

    .line 1443
    .line 1444
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1445
    .line 1446
    .line 1447
    throw v0

    .line 1448
    :cond_3d
    :goto_b
    move-object/from16 v10, v23

    .line 1449
    .line 1450
    move-object/from16 v8, v25

    .line 1451
    .line 1452
    move-object/from16 v9, v26

    .line 1453
    .line 1454
    move-object/from16 v11, v27

    .line 1455
    .line 1456
    goto/16 :goto_d

    .line 1457
    .line 1458
    :cond_3e
    new-instance v0, Ljava/text/ParseException;

    .line 1459
    .line 1460
    const-string v1, "Non-public key in jwk header parameter"

    .line 1461
    .line 1462
    const/4 v2, 0x0

    .line 1463
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1464
    .line 1465
    .line 1466
    throw v0

    .line 1467
    :goto_c
    new-instance v1, Ljava/text/ParseException;

    .line 1468
    .line 1469
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1470
    .line 1471
    .line 1472
    move-result-object v0

    .line 1473
    const/4 v2, 0x0

    .line 1474
    invoke-direct {v1, v0, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1475
    .line 1476
    .line 1477
    throw v1

    .line 1478
    :catch_6
    move-exception v0

    .line 1479
    new-instance v1, Ljava/text/ParseException;

    .line 1480
    .line 1481
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1482
    .line 1483
    .line 1484
    move-result-object v0

    .line 1485
    const/4 v2, 0x0

    .line 1486
    invoke-direct {v1, v0, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1487
    .line 1488
    .line 1489
    throw v1

    .line 1490
    :cond_3f
    const/4 v2, 0x0

    .line 1491
    new-instance v0, Ljava/text/ParseException;

    .line 1492
    .line 1493
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1494
    .line 1495
    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1496
    .line 1497
    .line 1498
    iget-object v3, v3, LT5/h;->a:Ljava/lang/String;

    .line 1499
    .line 1500
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1501
    .line 1502
    .line 1503
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1504
    .line 1505
    .line 1506
    move-result-object v1

    .line 1507
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1508
    .line 1509
    .line 1510
    throw v0

    .line 1511
    :cond_40
    const/4 v2, 0x0

    .line 1512
    new-instance v0, Ljava/text/ParseException;

    .line 1513
    .line 1514
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1515
    .line 1516
    const-string v3, "Unsupported key type \"kty\" parameter: "

    .line 1517
    .line 1518
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1519
    .line 1520
    .line 1521
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1522
    .line 1523
    .line 1524
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1525
    .line 1526
    .line 1527
    move-result-object v1

    .line 1528
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1529
    .line 1530
    .line 1531
    throw v0

    .line 1532
    :cond_41
    const/4 v2, 0x0

    .line 1533
    new-instance v0, Ljava/text/ParseException;

    .line 1534
    .line 1535
    const-string v1, "Missing key type \"kty\" parameter"

    .line 1536
    .line 1537
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1538
    .line 1539
    .line 1540
    throw v0

    .line 1541
    :cond_42
    move-object/from16 v26, v9

    .line 1542
    .line 1543
    move-object/from16 v23, v10

    .line 1544
    .line 1545
    move-object/from16 v27, v11

    .line 1546
    .line 1547
    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1548
    .line 1549
    .line 1550
    move-result v6

    .line 1551
    if-eqz v6, :cond_43

    .line 1552
    .line 1553
    invoke-static {v5, v0}, LZ5/c;->f(Ljava/lang/String;Ljava/util/Map;)Ljava/net/URI;

    .line 1554
    .line 1555
    .line 1556
    move-result-object v13

    .line 1557
    goto :goto_b

    .line 1558
    :cond_43
    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1559
    .line 1560
    .line 1561
    move-result v2

    .line 1562
    if-eqz v2, :cond_45

    .line 1563
    .line 1564
    invoke-static {v0, v5, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1565
    .line 1566
    .line 1567
    move-result-object v1

    .line 1568
    check-cast v1, Ljava/lang/String;

    .line 1569
    .line 1570
    if-nez v1, :cond_44

    .line 1571
    .line 1572
    const/4 v14, 0x0

    .line 1573
    goto :goto_b

    .line 1574
    :cond_44
    new-instance v2, LZ5/b;

    .line 1575
    .line 1576
    invoke-direct {v2, v1}, LZ5/a;-><init>(Ljava/lang/String;)V

    .line 1577
    .line 1578
    .line 1579
    move-object v14, v2

    .line 1580
    goto/16 :goto_b

    .line 1581
    .line 1582
    :cond_45
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1583
    .line 1584
    .line 1585
    move-result v1

    .line 1586
    if-eqz v1, :cond_47

    .line 1587
    .line 1588
    invoke-static {v0, v5, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1589
    .line 1590
    .line 1591
    move-result-object v1

    .line 1592
    check-cast v1, Ljava/lang/String;

    .line 1593
    .line 1594
    if-nez v1, :cond_46

    .line 1595
    .line 1596
    const/4 v15, 0x0

    .line 1597
    goto/16 :goto_b

    .line 1598
    .line 1599
    :cond_46
    new-instance v2, LZ5/b;

    .line 1600
    .line 1601
    invoke-direct {v2, v1}, LZ5/a;-><init>(Ljava/lang/String;)V

    .line 1602
    .line 1603
    .line 1604
    move-object v15, v2

    .line 1605
    goto/16 :goto_b

    .line 1606
    .line 1607
    :cond_47
    const-string v1, "x5c"

    .line 1608
    .line 1609
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1610
    .line 1611
    .line 1612
    move-result v1

    .line 1613
    if-eqz v1, :cond_48

    .line 1614
    .line 1615
    invoke-static {v0, v5, v3}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1616
    .line 1617
    .line 1618
    move-result-object v1

    .line 1619
    check-cast v1, Ljava/util/List;

    .line 1620
    .line 1621
    invoke-static {v1}, Lhf/a;->J(Ljava/util/List;)Ljava/util/LinkedList;

    .line 1622
    .line 1623
    .line 1624
    move-result-object v16

    .line 1625
    goto/16 :goto_b

    .line 1626
    .line 1627
    :cond_48
    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1628
    .line 1629
    .line 1630
    move-result v1

    .line 1631
    if-eqz v1, :cond_49

    .line 1632
    .line 1633
    invoke-static {v0, v5, v4}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1634
    .line 1635
    .line 1636
    move-result-object v1

    .line 1637
    move-object/from16 v17, v1

    .line 1638
    .line 1639
    check-cast v17, Ljava/lang/String;

    .line 1640
    .line 1641
    goto/16 :goto_b

    .line 1642
    .line 1643
    :cond_49
    const-string v1, "b64"

    .line 1644
    .line 1645
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1646
    .line 1647
    .line 1648
    move-result v1

    .line 1649
    if-eqz v1, :cond_4b

    .line 1650
    .line 1651
    const-class v1, Ljava/lang/Boolean;

    .line 1652
    .line 1653
    invoke-static {v0, v5, v1}, LZ5/c;->b(Ljava/util/Map;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1654
    .line 1655
    .line 1656
    move-result-object v1

    .line 1657
    check-cast v1, Ljava/lang/Boolean;

    .line 1658
    .line 1659
    if-eqz v1, :cond_4a

    .line 1660
    .line 1661
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1662
    .line 1663
    .line 1664
    move-result v1

    .line 1665
    move/from16 v18, v1

    .line 1666
    .line 1667
    goto/16 :goto_b

    .line 1668
    .line 1669
    :cond_4a
    new-instance v0, Ljava/text/ParseException;

    .line 1670
    .line 1671
    const-string v1, " is missing or null"

    .line 1672
    .line 1673
    invoke-static {v8, v5, v1}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1674
    .line 1675
    .line 1676
    move-result-object v1

    .line 1677
    const/4 v2, 0x0

    .line 1678
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1679
    .line 1680
    .line 1681
    throw v0

    .line 1682
    :cond_4b
    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1683
    .line 1684
    .line 1685
    move-result-object v1

    .line 1686
    sget-object v2, LP5/l;->B:Ljava/util/Set;

    .line 1687
    .line 1688
    invoke-interface {v2, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 1689
    .line 1690
    .line 1691
    move-result v2

    .line 1692
    if-nez v2, :cond_4d

    .line 1693
    .line 1694
    if-nez v19, :cond_4c

    .line 1695
    .line 1696
    new-instance v19, Ljava/util/HashMap;

    .line 1697
    .line 1698
    invoke-direct/range {v19 .. v19}, Ljava/util/HashMap;-><init>()V

    .line 1699
    .line 1700
    .line 1701
    :cond_4c
    move-object/from16 v2, v19

    .line 1702
    .line 1703
    invoke-virtual {v2, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1704
    .line 1705
    .line 1706
    move-object/from16 v19, v2

    .line 1707
    .line 1708
    goto/16 :goto_b

    .line 1709
    .line 1710
    :goto_d
    move-object/from16 v1, v21

    .line 1711
    .line 1712
    move-object/from16 v2, v22

    .line 1713
    .line 1714
    move-object/from16 v7, v24

    .line 1715
    .line 1716
    goto/16 :goto_1

    .line 1717
    .line 1718
    :cond_4d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 1719
    .line 1720
    const-string v1, "The parameter name \""

    .line 1721
    .line 1722
    const-string v2, "\" matches a registered name"

    .line 1723
    .line 1724
    invoke-static {v1, v5, v2}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1725
    .line 1726
    .line 1727
    move-result-object v1

    .line 1728
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1729
    .line 1730
    .line 1731
    throw v0

    .line 1732
    :cond_4e
    move-object/from16 v24, v7

    .line 1733
    .line 1734
    move-object/from16 v25, v8

    .line 1735
    .line 1736
    move-object/from16 v26, v9

    .line 1737
    .line 1738
    move-object/from16 v23, v10

    .line 1739
    .line 1740
    move-object/from16 v27, v11

    .line 1741
    .line 1742
    new-instance v6, LP5/l;

    .line 1743
    .line 1744
    move-object/from16 v20, p0

    .line 1745
    .line 1746
    invoke-direct/range {v6 .. v20}, LP5/l;-><init>(LP5/k;LP5/f;Ljava/lang/String;Ljava/util/HashSet;Ljava/net/URI;LT5/d;Ljava/net/URI;LZ5/b;LZ5/b;Ljava/util/LinkedList;Ljava/lang/String;ZLjava/util/HashMap;LZ5/b;)V

    .line 1747
    .line 1748
    .line 1749
    return-object v6

    .line 1750
    :cond_4f
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 1751
    .line 1752
    const-string v1, "The JWS algorithm \"alg\" cannot be \"none\""

    .line 1753
    .line 1754
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1755
    .line 1756
    .line 1757
    throw v0

    .line 1758
    :cond_50
    new-instance v0, Ljava/text/ParseException;

    .line 1759
    .line 1760
    const-string v1, "Not a JWS header"

    .line 1761
    .line 1762
    const/4 v2, 0x0

    .line 1763
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1764
    .line 1765
    .line 1766
    throw v0

    .line 1767
    :cond_51
    const/4 v2, 0x0

    .line 1768
    new-instance v0, Ljava/text/ParseException;

    .line 1769
    .line 1770
    const-string v1, "Missing \"alg\" in header JSON object"

    .line 1771
    .line 1772
    invoke-direct {v0, v1, v2}, Ljava/text/ParseException;-><init>(Ljava/lang/String;I)V

    .line 1773
    .line 1774
    .line 1775
    throw v0
.end method
