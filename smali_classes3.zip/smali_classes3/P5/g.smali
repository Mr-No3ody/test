.class public final LP5/g;
.super LP5/a;
.source "SourceFile"


# static fields
.field public static final A:LP5/g;

.field public static final B:LP5/g;

.field public static final C:LP5/g;

.field public static final H:LP5/g;

.field public static final L:LP5/g;

.field public static final M:LP5/g;

.field public static final Q:LP5/g;

.field public static final X:LP5/g;

.field public static final Y:LP5/g;

.field public static final Z:LP5/g;

.field public static final c:LP5/g;

.field public static final d:LP5/g;

.field public static final e:LP5/g;

.field public static final f:LP5/g;

.field public static final g:LP5/g;

.field public static final i:LP5/g;

.field public static final j:LP5/g;

.field public static final k0:LP5/g;

.field public static final o:LP5/g;

.field public static final p:LP5/g;

.field public static final t:LP5/g;

.field public static final v:LP5/g;

.field public static final w:LP5/g;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LP5/g;

    .line 2
    .line 3
    const-string v1, "RSA1_5"

    .line 4
    .line 5
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, LP5/g;->c:LP5/g;

    .line 9
    .line 10
    new-instance v0, LP5/g;

    .line 11
    .line 12
    const-string v1, "RSA-OAEP"

    .line 13
    .line 14
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    sput-object v0, LP5/g;->d:LP5/g;

    .line 18
    .line 19
    new-instance v0, LP5/g;

    .line 20
    .line 21
    const-string v1, "RSA-OAEP-256"

    .line 22
    .line 23
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    sput-object v0, LP5/g;->e:LP5/g;

    .line 27
    .line 28
    new-instance v0, LP5/g;

    .line 29
    .line 30
    const-string v1, "RSA-OAEP-384"

    .line 31
    .line 32
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    sput-object v0, LP5/g;->f:LP5/g;

    .line 36
    .line 37
    new-instance v0, LP5/g;

    .line 38
    .line 39
    const-string v1, "RSA-OAEP-512"

    .line 40
    .line 41
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    sput-object v0, LP5/g;->g:LP5/g;

    .line 45
    .line 46
    new-instance v0, LP5/g;

    .line 47
    .line 48
    const-string v1, "A128KW"

    .line 49
    .line 50
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    sput-object v0, LP5/g;->i:LP5/g;

    .line 54
    .line 55
    new-instance v0, LP5/g;

    .line 56
    .line 57
    const-string v1, "A192KW"

    .line 58
    .line 59
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    sput-object v0, LP5/g;->j:LP5/g;

    .line 63
    .line 64
    new-instance v0, LP5/g;

    .line 65
    .line 66
    const-string v1, "A256KW"

    .line 67
    .line 68
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    sput-object v0, LP5/g;->o:LP5/g;

    .line 72
    .line 73
    new-instance v0, LP5/g;

    .line 74
    .line 75
    const-string v1, "dir"

    .line 76
    .line 77
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    sput-object v0, LP5/g;->p:LP5/g;

    .line 81
    .line 82
    new-instance v0, LP5/g;

    .line 83
    .line 84
    const-string v1, "ECDH-ES"

    .line 85
    .line 86
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    sput-object v0, LP5/g;->t:LP5/g;

    .line 90
    .line 91
    new-instance v0, LP5/g;

    .line 92
    .line 93
    const-string v1, "ECDH-ES+A128KW"

    .line 94
    .line 95
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    sput-object v0, LP5/g;->v:LP5/g;

    .line 99
    .line 100
    new-instance v0, LP5/g;

    .line 101
    .line 102
    const-string v1, "ECDH-ES+A192KW"

    .line 103
    .line 104
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    sput-object v0, LP5/g;->w:LP5/g;

    .line 108
    .line 109
    new-instance v0, LP5/g;

    .line 110
    .line 111
    const-string v1, "ECDH-ES+A256KW"

    .line 112
    .line 113
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    sput-object v0, LP5/g;->A:LP5/g;

    .line 117
    .line 118
    new-instance v0, LP5/g;

    .line 119
    .line 120
    const-string v1, "ECDH-1PU"

    .line 121
    .line 122
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    sput-object v0, LP5/g;->B:LP5/g;

    .line 126
    .line 127
    new-instance v0, LP5/g;

    .line 128
    .line 129
    const-string v1, "ECDH-1PU+A128KW"

    .line 130
    .line 131
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    sput-object v0, LP5/g;->C:LP5/g;

    .line 135
    .line 136
    new-instance v0, LP5/g;

    .line 137
    .line 138
    const-string v1, "ECDH-1PU+A192KW"

    .line 139
    .line 140
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    sput-object v0, LP5/g;->H:LP5/g;

    .line 144
    .line 145
    new-instance v0, LP5/g;

    .line 146
    .line 147
    const-string v1, "ECDH-1PU+A256KW"

    .line 148
    .line 149
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    sput-object v0, LP5/g;->L:LP5/g;

    .line 153
    .line 154
    new-instance v0, LP5/g;

    .line 155
    .line 156
    const-string v1, "A128GCMKW"

    .line 157
    .line 158
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    sput-object v0, LP5/g;->M:LP5/g;

    .line 162
    .line 163
    new-instance v0, LP5/g;

    .line 164
    .line 165
    const-string v1, "A192GCMKW"

    .line 166
    .line 167
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    sput-object v0, LP5/g;->Q:LP5/g;

    .line 171
    .line 172
    new-instance v0, LP5/g;

    .line 173
    .line 174
    const-string v1, "A256GCMKW"

    .line 175
    .line 176
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    sput-object v0, LP5/g;->X:LP5/g;

    .line 180
    .line 181
    new-instance v0, LP5/g;

    .line 182
    .line 183
    const-string v1, "PBES2-HS256+A128KW"

    .line 184
    .line 185
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    sput-object v0, LP5/g;->Y:LP5/g;

    .line 189
    .line 190
    new-instance v0, LP5/g;

    .line 191
    .line 192
    const-string v1, "PBES2-HS384+A192KW"

    .line 193
    .line 194
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    sput-object v0, LP5/g;->Z:LP5/g;

    .line 198
    .line 199
    new-instance v0, LP5/g;

    .line 200
    .line 201
    const-string v1, "PBES2-HS512+A256KW"

    .line 202
    .line 203
    invoke-direct {v0, v1}, LP5/a;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    sput-object v0, LP5/g;->k0:LP5/g;

    .line 207
    .line 208
    return-void
.end method
