.class public final LX6/k;
.super LX6/b;
.source "SourceFile"


# instance fields
.field public d:LN6/d;

.field public e:Ljava/util/List;

.field public f:Lkotlin/jvm/functions/Function3;

.field public g:Ljava/lang/Integer;


# virtual methods
.method public final c(Landroidx/viewbinding/ViewBinding;)V
    .locals 6

    .line 1
    check-cast p1, LN6/b;

    .line 2
    .line 3
    const-string v0, "binding"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-super {p0, p1}, LX6/b;->e(LN6/b;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sget v1, LL6/g;->lib_ui_layout_picker_cascade:I

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    const/4 v3, 0x0

    .line 23
    invoke-virtual {v0, v1, v3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    if-eqz v0, :cond_10

    .line 28
    .line 29
    check-cast v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 30
    .line 31
    new-instance v1, LN6/d;

    .line 32
    .line 33
    const/4 v2, 0x1

    .line 34
    invoke-direct {v1, v0, v0, v2}, LN6/d;-><init>(Lcom/palmpay/lib/ui/picker/picker/PickerView;Lcom/palmpay/lib/ui/picker/picker/PickerView;I)V

    .line 35
    .line 36
    .line 37
    iput-object v1, p0, LX6/k;->d:LN6/d;

    .line 38
    .line 39
    iget-object v1, p1, LN6/b;->b:Landroid/widget/FrameLayout;

    .line 40
    .line 41
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 42
    .line 43
    .line 44
    new-instance v0, LX6/g;

    .line 45
    .line 46
    const/4 v1, 0x0

    .line 47
    invoke-direct {v0, p0, v1}, LX6/g;-><init>(LX6/k;I)V

    .line 48
    .line 49
    .line 50
    iget-object v1, p0, LX6/k;->e:Ljava/util/List;

    .line 51
    .line 52
    if-eqz v1, :cond_4

    .line 53
    .line 54
    move-object v2, v1

    .line 55
    check-cast v2, Ljava/util/Collection;

    .line 56
    .line 57
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    if-nez v2, :cond_4

    .line 62
    .line 63
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    check-cast v2, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 68
    .line 69
    if-eqz v2, :cond_0

    .line 70
    .line 71
    invoke-interface {v2}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    goto :goto_0

    .line 76
    :cond_0
    move-object v2, v3

    .line 77
    :goto_0
    check-cast v2, Ljava/util/Collection;

    .line 78
    .line 79
    if-eqz v2, :cond_4

    .line 80
    .line 81
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    if-eqz v2, :cond_1

    .line 86
    .line 87
    goto :goto_2

    .line 88
    :cond_1
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    check-cast v1, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 93
    .line 94
    if-eqz v1, :cond_2

    .line 95
    .line 96
    invoke-interface {v1}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    if-eqz v1, :cond_2

    .line 101
    .line 102
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    check-cast v1, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 107
    .line 108
    if-eqz v1, :cond_2

    .line 109
    .line 110
    invoke-interface {v1}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    goto :goto_1

    .line 115
    :cond_2
    move-object v1, v3

    .line 116
    :goto_1
    check-cast v1, Ljava/util/Collection;

    .line 117
    .line 118
    if-eqz v1, :cond_4

    .line 119
    .line 120
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 121
    .line 122
    .line 123
    move-result v1

    .line 124
    if-eqz v1, :cond_3

    .line 125
    .line 126
    goto :goto_2

    .line 127
    :cond_3
    iget-object v1, p0, LX6/k;->d:LN6/d;

    .line 128
    .line 129
    if-eqz v1, :cond_e

    .line 130
    .line 131
    iget-object v1, v1, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 132
    .line 133
    new-instance v2, LX6/g;

    .line 134
    .line 135
    const/4 v3, 0x1

    .line 136
    invoke-direct {v2, p0, v3}, LX6/g;-><init>(LX6/k;I)V

    .line 137
    .line 138
    .line 139
    new-instance v3, LX6/h;

    .line 140
    .line 141
    const/4 v4, 0x0

    .line 142
    invoke-direct {v3, p0, v4}, LX6/h;-><init>(LX6/k;I)V

    .line 143
    .line 144
    .line 145
    new-instance v4, LBa/a;

    .line 146
    .line 147
    const/16 v5, 0x15

    .line 148
    .line 149
    invoke-direct {v4, p0, v5}, LBa/a;-><init>(Ljava/lang/Object;I)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v1, v2, v3, v4}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->e(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;LBa/a;)V

    .line 153
    .line 154
    .line 155
    goto/16 :goto_8

    .line 156
    .line 157
    :cond_4
    :goto_2
    iget-object v1, p0, LX6/k;->e:Ljava/util/List;

    .line 158
    .line 159
    if-eqz v1, :cond_9

    .line 160
    .line 161
    move-object v2, v1

    .line 162
    check-cast v2, Ljava/util/Collection;

    .line 163
    .line 164
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    if-nez v2, :cond_9

    .line 169
    .line 170
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v2

    .line 174
    check-cast v2, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 175
    .line 176
    if-eqz v2, :cond_5

    .line 177
    .line 178
    invoke-interface {v2}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 179
    .line 180
    .line 181
    move-result-object v2

    .line 182
    goto :goto_3

    .line 183
    :cond_5
    move-object v2, v3

    .line 184
    :goto_3
    check-cast v2, Ljava/util/Collection;

    .line 185
    .line 186
    if-eqz v2, :cond_9

    .line 187
    .line 188
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 189
    .line 190
    .line 191
    move-result v2

    .line 192
    if-eqz v2, :cond_6

    .line 193
    .line 194
    goto :goto_5

    .line 195
    :cond_6
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v1

    .line 199
    check-cast v1, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 200
    .line 201
    if-eqz v1, :cond_7

    .line 202
    .line 203
    invoke-interface {v1}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 204
    .line 205
    .line 206
    move-result-object v1

    .line 207
    if-eqz v1, :cond_7

    .line 208
    .line 209
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object v1

    .line 213
    check-cast v1, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 214
    .line 215
    if-eqz v1, :cond_7

    .line 216
    .line 217
    invoke-interface {v1}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 218
    .line 219
    .line 220
    move-result-object v1

    .line 221
    goto :goto_4

    .line 222
    :cond_7
    move-object v1, v3

    .line 223
    :goto_4
    check-cast v1, Ljava/util/Collection;

    .line 224
    .line 225
    if-eqz v1, :cond_8

    .line 226
    .line 227
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 228
    .line 229
    .line 230
    move-result v1

    .line 231
    if-eqz v1, :cond_9

    .line 232
    .line 233
    :cond_8
    iget-object v1, p0, LX6/k;->d:LN6/d;

    .line 234
    .line 235
    if-eqz v1, :cond_e

    .line 236
    .line 237
    iget-object v1, v1, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 238
    .line 239
    new-instance v2, LX6/g;

    .line 240
    .line 241
    const/4 v3, 0x2

    .line 242
    invoke-direct {v2, p0, v3}, LX6/g;-><init>(LX6/k;I)V

    .line 243
    .line 244
    .line 245
    new-instance v3, LX6/h;

    .line 246
    .line 247
    const/4 v4, 0x1

    .line 248
    invoke-direct {v3, p0, v4}, LX6/h;-><init>(LX6/k;I)V

    .line 249
    .line 250
    .line 251
    const/4 v4, 0x4

    .line 252
    invoke-static {v1, v2, v3, v4}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->f(Lcom/palmpay/lib/ui/picker/picker/PickerView;Lkotlin/jvm/functions/Function0;LX6/h;I)V

    .line 253
    .line 254
    .line 255
    goto :goto_8

    .line 256
    :cond_9
    :goto_5
    iget-object v1, p0, LX6/k;->e:Ljava/util/List;

    .line 257
    .line 258
    if-eqz v1, :cond_e

    .line 259
    .line 260
    move-object v2, v1

    .line 261
    check-cast v2, Ljava/util/Collection;

    .line 262
    .line 263
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 264
    .line 265
    .line 266
    move-result v2

    .line 267
    if-nez v2, :cond_e

    .line 268
    .line 269
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v2

    .line 273
    check-cast v2, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 274
    .line 275
    if-eqz v2, :cond_a

    .line 276
    .line 277
    invoke-interface {v2}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 278
    .line 279
    .line 280
    move-result-object v2

    .line 281
    goto :goto_6

    .line 282
    :cond_a
    move-object v2, v3

    .line 283
    :goto_6
    check-cast v2, Ljava/util/Collection;

    .line 284
    .line 285
    if-eqz v2, :cond_b

    .line 286
    .line 287
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 288
    .line 289
    .line 290
    move-result v2

    .line 291
    if-eqz v2, :cond_e

    .line 292
    .line 293
    :cond_b
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 294
    .line 295
    .line 296
    move-result-object v1

    .line 297
    check-cast v1, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 298
    .line 299
    if-eqz v1, :cond_c

    .line 300
    .line 301
    invoke-interface {v1}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 302
    .line 303
    .line 304
    move-result-object v1

    .line 305
    if-eqz v1, :cond_c

    .line 306
    .line 307
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 308
    .line 309
    .line 310
    move-result-object v1

    .line 311
    check-cast v1, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 312
    .line 313
    if-eqz v1, :cond_c

    .line 314
    .line 315
    invoke-interface {v1}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 316
    .line 317
    .line 318
    move-result-object v1

    .line 319
    goto :goto_7

    .line 320
    :cond_c
    move-object v1, v3

    .line 321
    :goto_7
    check-cast v1, Ljava/util/Collection;

    .line 322
    .line 323
    if-eqz v1, :cond_d

    .line 324
    .line 325
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 326
    .line 327
    .line 328
    move-result v1

    .line 329
    if-eqz v1, :cond_e

    .line 330
    .line 331
    :cond_d
    iget-object v1, p0, LX6/k;->d:LN6/d;

    .line 332
    .line 333
    if-eqz v1, :cond_e

    .line 334
    .line 335
    iget-object v1, v1, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 336
    .line 337
    new-instance v2, LX6/g;

    .line 338
    .line 339
    const/4 v4, 0x3

    .line 340
    invoke-direct {v2, p0, v4}, LX6/g;-><init>(LX6/k;I)V

    .line 341
    .line 342
    .line 343
    const/4 v4, 0x6

    .line 344
    invoke-static {v1, v2, v3, v4}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->f(Lcom/palmpay/lib/ui/picker/picker/PickerView;Lkotlin/jvm/functions/Function0;LX6/h;I)V

    .line 345
    .line 346
    .line 347
    :cond_e
    :goto_8
    iget-object v1, p0, LX6/k;->d:LN6/d;

    .line 348
    .line 349
    if-eqz v1, :cond_f

    .line 350
    .line 351
    iget-object v1, v1, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 352
    .line 353
    iget-object v2, p0, LX6/k;->g:Ljava/lang/Integer;

    .line 354
    .line 355
    invoke-virtual {v1, v2}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->b(Ljava/lang/Integer;)V

    .line 356
    .line 357
    .line 358
    :cond_f
    iget-object p1, p1, LN6/b;->c:LBc/k;

    .line 359
    .line 360
    iget-object p1, p1, LBc/k;->b:Landroid/view/View;

    .line 361
    .line 362
    check-cast p1, Landroid/widget/TextView;

    .line 363
    .line 364
    const-string v1, "tvPositive"

    .line 365
    .line 366
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 367
    .line 368
    .line 369
    new-instance v1, LC9/V;

    .line 370
    .line 371
    const/4 v2, 0x7

    .line 372
    invoke-direct {v1, v2, p1, v0}, LC9/V;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 373
    .line 374
    .line 375
    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 376
    .line 377
    .line 378
    return-void

    .line 379
    :cond_10
    new-instance p1, Ljava/lang/NullPointerException;

    .line 380
    .line 381
    const-string v0, "rootView"

    .line 382
    .line 383
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 384
    .line 385
    .line 386
    throw p1
.end method

.method public final d()Landroidx/viewbinding/ViewBinding;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/app/Dialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, LN6/b;->a(Landroid/view/LayoutInflater;)LN6/b;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method
