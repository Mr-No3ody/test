.class public final LX6/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/View;

.field public final synthetic c:LX6/c;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;LX6/c;I)V
    .locals 0

    .line 1
    iput p3, p0, LX6/n;->a:I

    iput-object p1, p0, LX6/n;->b:Landroid/view/View;

    iput-object p2, p0, LX6/n;->c:LX6/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget p1, p0, LX6/n;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LX6/n;->b:Landroid/view/View;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-virtual {p1, v0}, Landroid/view/View;->setClickable(Z)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, LX6/n;->c:LX6/c;

    .line 13
    .line 14
    invoke-virtual {v0}, LX6/c;->invoke()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    new-instance v0, LX6/a;

    .line 18
    .line 19
    const/4 v1, 0x4

    .line 20
    invoke-direct {v0, p1, v1}, LX6/a;-><init>(Landroid/view/View;I)V

    .line 21
    .line 22
    .line 23
    const-wide/16 v1, 0x7d0

    .line 24
    .line 25
    invoke-virtual {p1, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_0
    iget-object p1, p0, LX6/n;->b:Landroid/view/View;

    .line 30
    .line 31
    const/4 v0, 0x0

    .line 32
    invoke-virtual {p1, v0}, Landroid/view/View;->setClickable(Z)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, LX6/n;->c:LX6/c;

    .line 36
    .line 37
    invoke-virtual {v0}, LX6/c;->invoke()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    new-instance v0, LX6/a;

    .line 41
    .line 42
    const/4 v1, 0x2

    .line 43
    invoke-direct {v0, p1, v1}, LX6/a;-><init>(Landroid/view/View;I)V

    .line 44
    .line 45
    .line 46
    const-wide/16 v1, 0x7d0

    .line 47
    .line 48
    invoke-virtual {p1, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    nop

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
