.class public final LX6/m;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic h:I


# instance fields
.field public final a:Landroid/content/Context;

.field public b:Ljava/lang/String;

.field public c:I

.field public d:Ljava/lang/Long;

.field public e:Ljava/lang/Long;

.field public f:Ljava/lang/Long;

.field public g:Lkotlin/jvm/functions/Function2;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LX6/l;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LX6/l;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LX6/m;->a:Landroid/content/Context;

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    iput p1, p0, LX6/m;->c:I

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final a()LX6/o;
    .locals 3

    .line 1
    new-instance v0, LX6/o;

    .line 2
    .line 3
    const-string v1, "context"

    .line 4
    .line 5
    iget-object v2, p0, LX6/m;->a:Landroid/content/Context;

    .line 6
    .line 7
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-direct {v0, v2}, LX6/b;-><init>(Landroid/content/Context;)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, LX6/m;->b:Ljava/lang/String;

    .line 14
    .line 15
    iput-object v1, v0, LX6/b;->c:Ljava/lang/String;

    .line 16
    .line 17
    iget v1, p0, LX6/m;->c:I

    .line 18
    .line 19
    iput v1, v0, LX6/o;->e:I

    .line 20
    .line 21
    iget-object v1, p0, LX6/m;->d:Ljava/lang/Long;

    .line 22
    .line 23
    iput-object v1, v0, LX6/o;->g:Ljava/lang/Long;

    .line 24
    .line 25
    iget-object v1, p0, LX6/m;->e:Ljava/lang/Long;

    .line 26
    .line 27
    iput-object v1, v0, LX6/o;->f:Ljava/lang/Long;

    .line 28
    .line 29
    iget-object v1, p0, LX6/m;->f:Ljava/lang/Long;

    .line 30
    .line 31
    iput-object v1, v0, LX6/o;->i:Ljava/lang/Long;

    .line 32
    .line 33
    iget-object v1, p0, LX6/m;->g:Lkotlin/jvm/functions/Function2;

    .line 34
    .line 35
    iput-object v1, v0, LX6/o;->j:Lkotlin/jvm/functions/Function2;

    .line 36
    .line 37
    return-object v0
.end method
