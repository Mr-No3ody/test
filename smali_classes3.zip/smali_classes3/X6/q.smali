.class public final LX6/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/View;

.field public final synthetic c:LX6/r;

.field public final synthetic d:LN8/g;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;LX6/r;LN8/g;I)V
    .locals 0

    .line 1
    iput p4, p0, LX6/q;->a:I

    iput-object p1, p0, LX6/q;->b:Landroid/view/View;

    iput-object p2, p0, LX6/q;->c:LX6/r;

    iput-object p3, p0, LX6/q;->d:LN8/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget p1, p0, LX6/q;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LX6/q;->b:Landroid/view/View;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-virtual {p1, v0}, Landroid/view/View;->setClickable(Z)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, LX6/q;->c:LX6/r;

    .line 13
    .line 14
    iget-object v0, v0, LX6/r;->e:LN6/d;

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    iget-object v0, v0, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 19
    .line 20
    invoke-virtual {v0}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->getOneWheelView()Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v0}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    iget-object v1, p0, LX6/q;->d:LN8/g;

    .line 33
    .line 34
    invoke-virtual {v1, v0}, LN8/g;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    new-instance v0, LX6/a;

    .line 38
    .line 39
    const/4 v1, 0x6

    .line 40
    invoke-direct {v0, p1, v1}, LX6/a;-><init>(Landroid/view/View;I)V

    .line 41
    .line 42
    .line 43
    const-wide/16 v1, 0x7d0

    .line 44
    .line 45
    invoke-virtual {p1, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :cond_0
    const-string p1, "pickerBinding"

    .line 50
    .line 51
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const/4 p1, 0x0

    .line 55
    throw p1

    .line 56
    :pswitch_0
    iget-object p1, p0, LX6/q;->b:Landroid/view/View;

    .line 57
    .line 58
    const/4 v0, 0x0

    .line 59
    invoke-virtual {p1, v0}, Landroid/view/View;->setClickable(Z)V

    .line 60
    .line 61
    .line 62
    iget-object v0, p0, LX6/q;->c:LX6/r;

    .line 63
    .line 64
    iget-object v1, v0, LX6/r;->e:LN6/d;

    .line 65
    .line 66
    if-eqz v1, :cond_1

    .line 67
    .line 68
    iget-object v1, v1, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 69
    .line 70
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->getOneWheelView()Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    iget-object v2, p0, LX6/q;->d:LN8/g;

    .line 83
    .line 84
    invoke-virtual {v2, v1}, LN8/g;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    .line 88
    .line 89
    .line 90
    new-instance v0, LX6/a;

    .line 91
    .line 92
    const/4 v1, 0x5

    .line 93
    invoke-direct {v0, p1, v1}, LX6/a;-><init>(Landroid/view/View;I)V

    .line 94
    .line 95
    .line 96
    const-wide/16 v1, 0x7d0

    .line 97
    .line 98
    invoke-virtual {p1, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 99
    .line 100
    .line 101
    return-void

    .line 102
    :cond_1
    const-string p1, "pickerBinding"

    .line 103
    .line 104
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    const/4 p1, 0x0

    .line 108
    throw p1

    .line 109
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
