.class public final synthetic LX6/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/palmpay/lib/ui/picker/wheel/listener/OnItemSelectedListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/palmpay/lib/ui/picker/picker/PickerView;


# direct methods
.method public synthetic constructor <init>(Lcom/palmpay/lib/ui/picker/picker/PickerView;I)V
    .locals 0

    .line 1
    iput p2, p0, LX6/d;->a:I

    iput-object p1, p0, LX6/d;->b:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onItemSelected(I)V
    .locals 8

    .line 1
    iget v0, p0, LX6/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LX6/d;->b:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 7
    .line 8
    iget-object v1, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->p:Lkotlin/jvm/functions/Function4;

    .line 9
    .line 10
    iget-object v2, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->c:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 11
    .line 12
    iget-object v3, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->b:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    const/4 v4, 0x1

    .line 17
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 26
    .line 27
    .line 28
    move-result v6

    .line 29
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object v6

    .line 33
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 34
    .line 35
    .line 36
    move-result v7

    .line 37
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 38
    .line 39
    .line 40
    move-result-object v7

    .line 41
    invoke-interface {v1, v4, v5, v6, v7}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    :cond_0
    iget-object v1, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->e:Lkotlin/jvm/functions/Function1;

    .line 45
    .line 46
    if-eqz v1, :cond_1

    .line 47
    .line 48
    new-instance v4, Lm6/j;

    .line 49
    .line 50
    iget-object v5, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->a:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 51
    .line 52
    invoke-virtual {v5}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 57
    .line 58
    .line 59
    move-result-object v5

    .line 60
    invoke-interface {v1, v5}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    check-cast v1, Ljava/util/List;

    .line 65
    .line 66
    invoke-direct {v4, v1}, Lm6/j;-><init>(Ljava/util/List;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v3, v4}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->setAdapter(Lcom/palmpay/lib/ui/picker/wheel/adapter/WheelAdapter;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->d()V

    .line 73
    .line 74
    .line 75
    :cond_1
    iget-object v0, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->o:Lkotlin/jvm/functions/Function3;

    .line 76
    .line 77
    if-eqz v0, :cond_2

    .line 78
    .line 79
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    invoke-interface {v0, p1, v1, v2}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    :cond_2
    return-void

    .line 103
    :pswitch_0
    iget-object v0, p0, LX6/d;->b:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 104
    .line 105
    iget-object v1, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->p:Lkotlin/jvm/functions/Function4;

    .line 106
    .line 107
    iget-object v2, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->b:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 108
    .line 109
    iget-object v3, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->a:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 110
    .line 111
    if-eqz v1, :cond_3

    .line 112
    .line 113
    const/4 v4, 0x3

    .line 114
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 119
    .line 120
    .line 121
    move-result v5

    .line 122
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 123
    .line 124
    .line 125
    move-result-object v5

    .line 126
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 127
    .line 128
    .line 129
    move-result v6

    .line 130
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 131
    .line 132
    .line 133
    move-result-object v6

    .line 134
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 135
    .line 136
    .line 137
    move-result-object v7

    .line 138
    invoke-interface {v1, v4, v5, v6, v7}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    :cond_3
    iget-object v1, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->o:Lkotlin/jvm/functions/Function3;

    .line 142
    .line 143
    if-eqz v1, :cond_4

    .line 144
    .line 145
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 146
    .line 147
    .line 148
    move-result v3

    .line 149
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 154
    .line 155
    .line 156
    move-result v2

    .line 157
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 158
    .line 159
    .line 160
    move-result-object v2

    .line 161
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 162
    .line 163
    .line 164
    move-result-object v4

    .line 165
    invoke-interface {v1, v3, v2, v4}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    :cond_4
    iget-object v0, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->c:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 169
    .line 170
    invoke-virtual {v0, p1}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->setCurrentItem(I)V

    .line 171
    .line 172
    .line 173
    return-void

    .line 174
    :pswitch_1
    iget-object v0, p0, LX6/d;->b:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 175
    .line 176
    iget-object v1, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->p:Lkotlin/jvm/functions/Function4;

    .line 177
    .line 178
    iget-object v2, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->a:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 179
    .line 180
    iget-object v3, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->c:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 181
    .line 182
    if-eqz v1, :cond_5

    .line 183
    .line 184
    const/4 v4, 0x2

    .line 185
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 186
    .line 187
    .line 188
    move-result-object v4

    .line 189
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 190
    .line 191
    .line 192
    move-result v5

    .line 193
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 194
    .line 195
    .line 196
    move-result-object v5

    .line 197
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 198
    .line 199
    .line 200
    move-result-object v6

    .line 201
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 202
    .line 203
    .line 204
    move-result v7

    .line 205
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 206
    .line 207
    .line 208
    move-result-object v7

    .line 209
    invoke-interface {v1, v4, v5, v6, v7}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    :cond_5
    iget-object v1, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->f:Lkotlin/jvm/functions/Function2;

    .line 213
    .line 214
    iget-object v4, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->b:Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 215
    .line 216
    if-eqz v1, :cond_6

    .line 217
    .line 218
    new-instance v5, Lm6/j;

    .line 219
    .line 220
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 221
    .line 222
    .line 223
    move-result v6

    .line 224
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 225
    .line 226
    .line 227
    move-result-object v6

    .line 228
    invoke-virtual {v4}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 229
    .line 230
    .line 231
    move-result v7

    .line 232
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 233
    .line 234
    .line 235
    move-result-object v7

    .line 236
    invoke-interface {v1, v6, v7}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    check-cast v1, Ljava/util/List;

    .line 241
    .line 242
    invoke-direct {v5, v1}, Lm6/j;-><init>(Ljava/util/List;)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v3, v5}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->setAdapter(Lcom/palmpay/lib/ui/picker/wheel/adapter/WheelAdapter;)V

    .line 246
    .line 247
    .line 248
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->d()V

    .line 249
    .line 250
    .line 251
    :cond_6
    iget-object v0, v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;->o:Lkotlin/jvm/functions/Function3;

    .line 252
    .line 253
    if-eqz v0, :cond_7

    .line 254
    .line 255
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 256
    .line 257
    .line 258
    move-result v1

    .line 259
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 260
    .line 261
    .line 262
    move-result-object v1

    .line 263
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 264
    .line 265
    .line 266
    move-result-object v2

    .line 267
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 268
    .line 269
    .line 270
    move-result v3

    .line 271
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 272
    .line 273
    .line 274
    move-result-object v3

    .line 275
    invoke-interface {v0, v1, v2, v3}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    :cond_7
    invoke-virtual {v4, p1}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->setCurrentItem(I)V

    .line 279
    .line 280
    .line 281
    return-void

    .line 282
    nop

    .line 283
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
