.class public final LX6/o;
.super LX6/b;
.source "SourceFile"


# instance fields
.field public d:LBc/l;

.field public e:I

.field public f:Ljava/lang/Long;

.field public g:Ljava/lang/Long;

.field public i:Ljava/lang/Long;

.field public j:Lkotlin/jvm/functions/Function2;


# virtual methods
.method public final c(Landroidx/viewbinding/ViewBinding;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x2

    .line 6
    move-object/from16 v4, p1

    .line 7
    .line 8
    check-cast v4, LN6/b;

    .line 9
    .line 10
    const-string v5, "binding"

    .line 11
    .line 12
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-super {v0, v4}, LX6/b;->e(LN6/b;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    invoke-static {v5}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 23
    .line 24
    .line 25
    move-result-object v5

    .line 26
    invoke-static {v5}, LBc/l;->b(Landroid/view/LayoutInflater;)LBc/l;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    iput-object v5, v0, LX6/o;->d:LBc/l;

    .line 31
    .line 32
    iget-object v5, v5, LBc/l;->c:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v5, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;

    .line 35
    .line 36
    iget-object v6, v4, LN6/b;->b:Landroid/widget/FrameLayout;

    .line 37
    .line 38
    invoke-virtual {v6, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 39
    .line 40
    .line 41
    new-instance v5, LX6/c;

    .line 42
    .line 43
    invoke-direct {v5, v0, v3}, LX6/c;-><init>(Ljava/lang/Object;I)V

    .line 44
    .line 45
    .line 46
    iget-object v4, v4, LN6/b;->c:LBc/k;

    .line 47
    .line 48
    iget-object v6, v4, LBc/k;->b:Landroid/view/View;

    .line 49
    .line 50
    check-cast v6, Landroid/widget/TextView;

    .line 51
    .line 52
    const-string v7, "tvPositive"

    .line 53
    .line 54
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    new-instance v8, LX6/n;

    .line 58
    .line 59
    invoke-direct {v8, v6, v5, v2}, LX6/n;-><init>(Landroid/view/View;LX6/c;I)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v6, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 63
    .line 64
    .line 65
    iget v8, v0, LX6/o;->e:I

    .line 66
    .line 67
    const/4 v9, 0x0

    .line 68
    const/4 v10, 0x3

    .line 69
    const-string v11, "pickerBinding"

    .line 70
    .line 71
    if-ne v8, v10, :cond_1

    .line 72
    .line 73
    iget-object v8, v0, LX6/o;->d:LBc/l;

    .line 74
    .line 75
    if-eqz v8, :cond_0

    .line 76
    .line 77
    iget-object v8, v8, LBc/l;->c:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v8, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;

    .line 80
    .line 81
    iput-boolean v1, v8, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->C:Z

    .line 82
    .line 83
    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 84
    .line 85
    invoke-virtual {v8, v10}, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->l(Ljava/lang/Boolean;)V

    .line 86
    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_0
    invoke-static {v11}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    throw v9

    .line 93
    :cond_1
    :goto_0
    iget-object v8, v0, LX6/o;->i:Ljava/lang/Long;

    .line 94
    .line 95
    if-eqz v8, :cond_4

    .line 96
    .line 97
    invoke-virtual {v8}, Ljava/lang/Number;->longValue()J

    .line 98
    .line 99
    .line 100
    move-result-wide v15

    .line 101
    iget-object v8, v0, LX6/o;->d:LBc/l;

    .line 102
    .line 103
    if-eqz v8, :cond_3

    .line 104
    .line 105
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 106
    .line 107
    .line 108
    move-result-object v10

    .line 109
    iget-object v12, v0, LX6/o;->g:Ljava/lang/Long;

    .line 110
    .line 111
    if-eqz v12, :cond_2

    .line 112
    .line 113
    invoke-virtual {v12}, Ljava/lang/Number;->longValue()J

    .line 114
    .line 115
    .line 116
    move-result-wide v2

    .line 117
    invoke-virtual {v10, v2, v3}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 118
    .line 119
    .line 120
    goto :goto_1

    .line 121
    :cond_2
    const/16 v12, 0x6fe

    .line 122
    .line 123
    invoke-virtual {v10, v1, v12}, Ljava/util/Calendar;->set(II)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v10, v3, v2}, Ljava/util/Calendar;->set(II)V

    .line 127
    .line 128
    .line 129
    const/4 v2, 0x5

    .line 130
    invoke-virtual {v10, v2, v1}, Ljava/util/Calendar;->set(II)V

    .line 131
    .line 132
    .line 133
    :goto_1
    invoke-static {v10}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    invoke-static {v10}, LW6/a;->b(Ljava/util/Calendar;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v10}, Ljava/util/Calendar;->getTimeInMillis()J

    .line 140
    .line 141
    .line 142
    move-result-wide v13

    .line 143
    iget-object v2, v8, LBc/l;->c:Ljava/lang/Object;

    .line 144
    .line 145
    move-object v12, v2

    .line 146
    check-cast v12, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;

    .line 147
    .line 148
    sget v2, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->u0:I

    .line 149
    .line 150
    const/16 v17, 0x0

    .line 151
    .line 152
    invoke-virtual/range {v12 .. v17}, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->k(JJLjava/lang/Long;)V

    .line 153
    .line 154
    .line 155
    goto :goto_2

    .line 156
    :cond_3
    invoke-static {v11}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    throw v9

    .line 160
    :cond_4
    :goto_2
    iget-object v2, v0, LX6/o;->f:Ljava/lang/Long;

    .line 161
    .line 162
    if-eqz v2, :cond_6

    .line 163
    .line 164
    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    .line 165
    .line 166
    .line 167
    move-result-wide v2

    .line 168
    iget-object v8, v0, LX6/o;->d:LBc/l;

    .line 169
    .line 170
    if-eqz v8, :cond_5

    .line 171
    .line 172
    iget-object v8, v8, LBc/l;->c:Ljava/lang/Object;

    .line 173
    .line 174
    check-cast v8, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;

    .line 175
    .line 176
    invoke-virtual {v8, v2, v3}, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->j(J)V

    .line 177
    .line 178
    .line 179
    goto :goto_3

    .line 180
    :cond_5
    invoke-static {v11}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    throw v9

    .line 184
    :cond_6
    :goto_3
    iget-object v2, v4, LBc/k;->c:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast v2, Landroid/widget/TextView;

    .line 187
    .line 188
    const-string v3, "tvNegative"

    .line 189
    .line 190
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    new-instance v3, LC9/V;

    .line 194
    .line 195
    const/16 v4, 0x8

    .line 196
    .line 197
    invoke-direct {v3, v4, v2, v0}, LC9/V;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 201
    .line 202
    .line 203
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    new-instance v2, LX6/n;

    .line 207
    .line 208
    invoke-direct {v2, v6, v5, v1}, LX6/n;-><init>(Landroid/view/View;LX6/c;I)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v6, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 212
    .line 213
    .line 214
    return-void
.end method

.method public final d()Landroidx/viewbinding/ViewBinding;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/app/Dialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, LN6/b;->a(Landroid/view/LayoutInflater;)LN6/b;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method
