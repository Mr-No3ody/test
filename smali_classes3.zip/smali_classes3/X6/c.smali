.class public final synthetic LX6/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/managemoney/ui/dialog/CongratulationsDialogFragment;Lcom/transsnet/palmpay/managemoney/ui/fragment/OldUserFixedSavingFragment;)V
    .locals 0

    .line 1
    const/16 p2, 0x1a

    iput p2, p0, LX6/c;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LX6/c;->b:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p2, p0, LX6/c;->a:I

    iput-object p1, p0, LX6/c;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 6

    .line 1
    const-string v0, ". Check R8 Signature keep for BaseMvvm* subclasses."

    .line 2
    .line 3
    const-string v1, "Cannot resolve ViewModel for "

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    iget-object v4, p0, LX6/c;->b:Ljava/lang/Object;

    .line 8
    .line 9
    iget v5, p0, LX6/c;->a:I

    .line 10
    .line 11
    packed-switch v5, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    sget-object v0, Lcom/transsnet/palmpay/r2c/ui/activity/Recharge2CashHomeActivity;->v:Ljava/util/ArrayList;

    .line 15
    .line 16
    check-cast v4, Lcom/transsnet/palmpay/r2c/ui/activity/Recharge2CashHomeActivity;

    .line 17
    .line 18
    invoke-virtual {v4}, Lcom/transsnet/palmpay/core/base/BaseActivity;->getUIHandler()Landroid/os/Handler;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    new-instance v1, Lcom/transsnet/adsdk/widgets/banner/bannerview/b;

    .line 23
    .line 24
    const/16 v2, 0xb

    .line 25
    .line 26
    invoke-direct {v1, v4, v2}, Lcom/transsnet/adsdk/widgets/banner/bannerview/b;-><init>(Ljava/lang/Object;I)V

    .line 27
    .line 28
    .line 29
    const-wide/16 v2, 0x320

    .line 30
    .line 31
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 32
    .line 33
    .line 34
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 35
    .line 36
    return-object v0

    .line 37
    :pswitch_0
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    check-cast v4, Lcom/transsnet/palmpay/account/bean/req/ResetPasswordReq;

    .line 42
    .line 43
    if-eqz v0, :cond_0

    .line 44
    .line 45
    invoke-static {}, LG8/a;->t()Lcom/transsnet/palmpay/account/business/IApiAccountService;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-interface {v0, v4}, Lcom/transsnet/palmpay/account/business/IApiAccountService;->resetPassword(Lcom/transsnet/palmpay/account/bean/req/ResetPasswordReq;)Ldf/d;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    goto :goto_0

    .line 54
    :cond_0
    invoke-static {}, LG8/a;->t()Lcom/transsnet/palmpay/account/business/IApiAccountService;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-interface {v0, v4}, Lcom/transsnet/palmpay/account/business/IApiAccountService;->resetPasswordNoToken(Lcom/transsnet/palmpay/account/bean/req/ResetPasswordReq;)Ldf/d;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    :goto_0
    return-object v0

    .line 63
    :pswitch_1
    invoke-static {}, LG8/a;->t()Lcom/transsnet/palmpay/account/business/IApiAccountService;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v4, Lcom/transsnet/palmpay/account/bean/ApplyForTier3Req;

    .line 68
    .line 69
    invoke-interface {v0, v4}, Lcom/transsnet/palmpay/account/business/IApiAccountService;->applyForTier3(Lcom/transsnet/palmpay/account/bean/ApplyForTier3Req;)Ldf/d;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    return-object v0

    .line 74
    :pswitch_2
    sget-object v0, Lcom/transsnet/palmpay/managemoney/ui/fragment/OldUserFixedSavingFragment;->Z:Lcom/transsnet/palmpay/managemoney/ui/fragment/OldUserFixedSavingFragment$a;

    .line 75
    .line 76
    check-cast v4, Lcom/transsnet/palmpay/managemoney/ui/dialog/CongratulationsDialogFragment;

    .line 77
    .line 78
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    if-eqz v0, :cond_1

    .line 83
    .line 84
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    const-string v1, "null cannot be cast to non-null type com.transsnet.palmpay.managemoney.ui.activity.UserFixedSavingActivity"

    .line 89
    .line 90
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    check-cast v0, Lcom/transsnet/palmpay/managemoney/ui/activity/UserFixedSavingActivity;

    .line 94
    .line 95
    invoke-virtual {v0, v3}, Lcom/transsnet/palmpay/managemoney/ui/activity/UserFixedSavingActivity;->n(I)V

    .line 96
    .line 97
    .line 98
    :cond_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 99
    .line 100
    return-object v0

    .line 101
    :pswitch_3
    sget v0, Lcom/transsnet/palmpay/managemoney/ui/activity/CashBoxOrderDetailActivity;->w:I

    .line 102
    .line 103
    check-cast v4, Lcom/transsnet/palmpay/managemoney/bean/CashBoxInterestDetail;

    .line 104
    .line 105
    invoke-virtual {v4}, Lcom/transsnet/palmpay/managemoney/bean/CashBoxInterestDetail;->getOrgOrderNo()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-static {v0}, Lcom/transsnet/palmpay/util/ClipboardUtils;->copyText(Ljava/lang/CharSequence;)V

    .line 110
    .line 111
    .line 112
    sget v0, Lba/k;->core_copy_success:I

    .line 113
    .line 114
    invoke-static {v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 115
    .line 116
    .line 117
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 118
    .line 119
    return-object v0

    .line 120
    :pswitch_4
    sget v0, Lcom/transsnet/palmpay/managemoney/ui/activity/CashBoxOrderDetailActivity;->w:I

    .line 121
    .line 122
    check-cast v4, Lcom/transsnet/palmpay/managemoney/bean/resp/GetCashBoxOrderDetailResp$CashBoxOrderDetail;

    .line 123
    .line 124
    invoke-virtual {v4}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetCashBoxOrderDetailResp$CashBoxOrderDetail;->getTransactionId()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-static {v0}, Lcom/transsnet/palmpay/util/ClipboardUtils;->copyText(Ljava/lang/CharSequence;)V

    .line 129
    .line 130
    .line 131
    sget v0, Lba/k;->core_copy_success:I

    .line 132
    .line 133
    invoke-static {v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 134
    .line 135
    .line 136
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 137
    .line 138
    return-object v0

    .line 139
    :pswitch_5
    check-cast v4, Lcom/transsnet/palmpay/custom_view/input/OperatorSelectNewPopWindow;

    .line 140
    .line 141
    invoke-static {v4}, Lcom/transsnet/palmpay/custom_view/input/OperatorSelectNewPopWindow;->a(Lcom/transsnet/palmpay/custom_view/input/OperatorSelectNewPopWindow;)Landroidx/recyclerview/widget/RecyclerView;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    return-object v0

    .line 146
    :pswitch_6
    check-cast v4, Lcom/transsnet/palmpay/custom_view/input/ModelMobileInputAdapter;

    .line 147
    .line 148
    invoke-static {v4}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileInputAdapter;->a(Lcom/transsnet/palmpay/custom_view/input/ModelMobileInputAdapter;)Lkotlin/Unit;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    return-object v0

    .line 153
    :pswitch_7
    check-cast v4, Lcom/transsnet/palmpay/custom_view/input/CustomAutoCompleteTextView;

    .line 154
    .line 155
    invoke-static {v4}, Lcom/transsnet/palmpay/custom_view/input/CustomAutoCompleteTextView;->b(Lcom/transsnet/palmpay/custom_view/input/CustomAutoCompleteTextView;)I

    .line 156
    .line 157
    .line 158
    move-result v0

    .line 159
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    return-object v0

    .line 164
    :pswitch_8
    sget v0, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->q0:I

    .line 165
    .line 166
    new-instance v0, Landroidx/camera/video/internal/c;

    .line 167
    .line 168
    check-cast v4, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;

    .line 169
    .line 170
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 171
    .line 172
    .line 173
    move-result-object v1

    .line 174
    const-string v2, "requireActivity(...)"

    .line 175
    .line 176
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    invoke-direct {v0, v1}, Landroidx/camera/video/internal/c;-><init>(Landroidx/lifecycle/ViewModelStoreOwner;)V

    .line 180
    .line 181
    .line 182
    const-class v1, Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;

    .line 183
    .line 184
    invoke-virtual {v0, v1}, Landroidx/camera/video/internal/c;->h(Ljava/lang/Class;)Landroidx/lifecycle/a0;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    check-cast v0, Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;

    .line 189
    .line 190
    return-object v0

    .line 191
    :pswitch_9
    check-cast v4, Lcom/transsnet/palmpay/credit/ui/dialog/OcREUnFreezeDialog;

    .line 192
    .line 193
    invoke-static {v4}, Lcom/transsnet/palmpay/credit/ui/dialog/OcREUnFreezeDialog;->a(Lcom/transsnet/palmpay/credit/ui/dialog/OcREUnFreezeDialog;)Landroid/widget/Button;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    return-object v0

    .line 198
    :pswitch_a
    sget-object v0, Lcom/transsnet/palmpay/credit/ui/dialog/AvailableCouponListDialogFragment;->H:Lcom/transsnet/palmpay/credit/ui/dialog/AvailableCouponListDialogFragment$a;

    .line 199
    .line 200
    new-instance v0, Lda/I;

    .line 201
    .line 202
    check-cast v4, Lcom/transsnet/palmpay/credit/ui/dialog/AvailableCouponListDialogFragment;

    .line 203
    .line 204
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 205
    .line 206
    .line 207
    move-result-object v1

    .line 208
    invoke-direct {v0, v1}, Lda/I;-><init>(Landroid/content/Context;)V

    .line 209
    .line 210
    .line 211
    return-object v0

    .line 212
    :pswitch_b
    sget v0, Lcom/transsnet/palmpay/core/ui/activity/RNCorePreviewActivity;->a1:I

    .line 213
    .line 214
    check-cast v4, Lcom/transsnet/palmpay/core/ui/activity/RNCorePreviewActivity;

    .line 215
    .line 216
    invoke-virtual {v4}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 217
    .line 218
    .line 219
    move-result-object v0

    .line 220
    if-eqz v0, :cond_2

    .line 221
    .line 222
    const-string v1, "mShowCashierPreview"

    .line 223
    .line 224
    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 225
    .line 226
    .line 227
    move-result v3

    .line 228
    :cond_2
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 229
    .line 230
    .line 231
    move-result-object v0

    .line 232
    return-object v0

    .line 233
    :pswitch_c
    sget v0, Lcom/transsnet/palmpay/core/ui/activity/CoreUssdListActivity;->d:I

    .line 234
    .line 235
    sget v0, LL9/a;->ussdList:I

    .line 236
    .line 237
    check-cast v4, Lcom/transsnet/palmpay/core/ui/activity/CoreUssdListActivity;

    .line 238
    .line 239
    invoke-virtual {v4, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    check-cast v0, Lcom/transsnet/palmpay/custom_view/SwipeRecyclerView;

    .line 244
    .line 245
    return-object v0

    .line 246
    :pswitch_d
    sget v2, Lcom/transsnet/palmpay/core/base/BaseMvvmDialogFragment;->H:I

    .line 247
    .line 248
    check-cast v4, Lcom/transsnet/palmpay/core/base/BaseMvvmDialogFragment;

    .line 249
    .line 250
    invoke-static {v4}, La/a;->A(Ljava/lang/Object;)Ljava/lang/Class;

    .line 251
    .line 252
    .line 253
    move-result-object v2

    .line 254
    if-eqz v2, :cond_3

    .line 255
    .line 256
    new-instance v0, Landroidx/camera/video/internal/c;

    .line 257
    .line 258
    invoke-direct {v0, v4}, Landroidx/camera/video/internal/c;-><init>(Landroidx/lifecycle/ViewModelStoreOwner;)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v0, v2}, Landroidx/camera/video/internal/c;->h(Ljava/lang/Class;)Landroidx/lifecycle/a0;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    check-cast v0, Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 266
    .line 267
    return-object v0

    .line 268
    :cond_3
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 269
    .line 270
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 271
    .line 272
    .line 273
    move-result-object v3

    .line 274
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object v3

    .line 278
    invoke-static {v1, v3, v0}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v0

    .line 282
    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 283
    .line 284
    .line 285
    throw v2

    .line 286
    :pswitch_e
    sget v2, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->b:I

    .line 287
    .line 288
    check-cast v4, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;

    .line 289
    .line 290
    invoke-static {v4}, La/a;->A(Ljava/lang/Object;)Ljava/lang/Class;

    .line 291
    .line 292
    .line 293
    move-result-object v2

    .line 294
    if-eqz v2, :cond_4

    .line 295
    .line 296
    new-instance v0, Landroidx/camera/video/internal/c;

    .line 297
    .line 298
    invoke-direct {v0, v4}, Landroidx/camera/video/internal/c;-><init>(Landroidx/lifecycle/ViewModelStoreOwner;)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v0, v2}, Landroidx/camera/video/internal/c;->h(Ljava/lang/Class;)Landroidx/lifecycle/a0;

    .line 302
    .line 303
    .line 304
    move-result-object v0

    .line 305
    check-cast v0, Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 306
    .line 307
    return-object v0

    .line 308
    :cond_4
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 309
    .line 310
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 311
    .line 312
    .line 313
    move-result-object v3

    .line 314
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 315
    .line 316
    .line 317
    move-result-object v3

    .line 318
    invoke-static {v1, v3, v0}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 319
    .line 320
    .line 321
    move-result-object v0

    .line 322
    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 323
    .line 324
    .line 325
    throw v2

    .line 326
    :pswitch_f
    check-cast v4, Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 327
    .line 328
    invoke-static {v4}, Lcom/transsnet/palmpay/core/base/BaseApplication;->d(Lcom/transsnet/palmpay/core/base/BaseApplication;)Ljava/lang/Object;

    .line 329
    .line 330
    .line 331
    move-result-object v0

    .line 332
    return-object v0

    .line 333
    :pswitch_10
    check-cast v4, Lcom/transsnet/palmpay/teller/ui/view/SideBarView;

    .line 334
    .line 335
    iget v0, v4, Lcom/transsnet/palmpay/teller/ui/view/SideBarView;->v:F

    .line 336
    .line 337
    invoke-virtual {v4}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 338
    .line 339
    .line 340
    move-result-object v1

    .line 341
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 342
    .line 343
    .line 344
    move-result-object v1

    .line 345
    invoke-static {v3, v0, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 346
    .line 347
    .line 348
    move-result v0

    .line 349
    float-to-int v0, v0

    .line 350
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 351
    .line 352
    .line 353
    move-result-object v0

    .line 354
    return-object v0

    .line 355
    :pswitch_11
    sget v0, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;->i:I

    .line 356
    .line 357
    new-instance v0, LXd/g;

    .line 358
    .line 359
    check-cast v4, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;

    .line 360
    .line 361
    iget v1, v4, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;->f:I

    .line 362
    .line 363
    invoke-direct {v0, v1}, LXd/g;-><init>(I)V

    .line 364
    .line 365
    .line 366
    return-object v0

    .line 367
    :pswitch_12
    sget-object v0, Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;->j:Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon$a;

    .line 368
    .line 369
    new-instance v0, Lcom/transsnet/palmpay/teller/ui/view/c;

    .line 370
    .line 371
    check-cast v4, Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;

    .line 372
    .line 373
    invoke-direct {v0}, LM1/d;-><init>()V

    .line 374
    .line 375
    .line 376
    new-instance v1, Lcom/transsnet/palmpay/teller/ui/view/d;

    .line 377
    .line 378
    new-instance v5, Lce/i;

    .line 379
    .line 380
    invoke-direct {v5, v0, v2}, Lce/i;-><init>(Lcom/transsnet/palmpay/teller/ui/view/c;I)V

    .line 381
    .line 382
    .line 383
    new-instance v2, Lce/i;

    .line 384
    .line 385
    invoke-direct {v2, v0, v3}, Lce/i;-><init>(Lcom/transsnet/palmpay/teller/ui/view/c;I)V

    .line 386
    .line 387
    .line 388
    invoke-direct {v1, v5, v2}, Lcom/transsnet/palmpay/teller/ui/view/d;-><init>(Lce/i;Lce/i;)V

    .line 389
    .line 390
    .line 391
    invoke-virtual {v0, v1}, LM1/d;->a(LT1/b;)V

    .line 392
    .line 393
    .line 394
    new-instance v1, Lcom/transsnet/palmpay/teller/ui/view/b;

    .line 395
    .line 396
    new-instance v2, Lce/i;

    .line 397
    .line 398
    const/4 v3, 0x2

    .line 399
    invoke-direct {v2, v0, v3}, Lce/i;-><init>(Lcom/transsnet/palmpay/teller/ui/view/c;I)V

    .line 400
    .line 401
    .line 402
    new-instance v3, Lce/i;

    .line 403
    .line 404
    const/4 v5, 0x3

    .line 405
    invoke-direct {v3, v0, v5}, Lce/i;-><init>(Lcom/transsnet/palmpay/teller/ui/view/c;I)V

    .line 406
    .line 407
    .line 408
    invoke-direct {v1, v4, v2, v3}, Lcom/transsnet/palmpay/teller/ui/view/b;-><init>(Lcom/transsnet/palmpay/teller/ui/view/ModelActivityBannerWithCoupon;Lce/i;Lce/i;)V

    .line 409
    .line 410
    .line 411
    invoke-virtual {v0, v1}, LM1/d;->a(LT1/b;)V

    .line 412
    .line 413
    .line 414
    sget v1, LPd/c;->layoutCouponCL:I

    .line 415
    .line 416
    filled-new-array {v1}, [I

    .line 417
    .line 418
    .line 419
    move-result-object v1

    .line 420
    invoke-virtual {v0, v1}, LM1/j;->addChildClickViewIds([I)V

    .line 421
    .line 422
    .line 423
    return-object v0

    .line 424
    :pswitch_13
    sget v0, Lcom/transsnet/palmpay/account/ui/fragment/upgrade/UpgradeTier3StepAddressEditFragment;->C:I

    .line 425
    .line 426
    new-instance v0, Lcom/transsnet/palmpay/custom_view/utils/KeyBoardListenerHelper;

    .line 427
    .line 428
    check-cast v4, Lcom/transsnet/palmpay/account/ui/fragment/upgrade/UpgradeTier3StepAddressEditFragment;

    .line 429
    .line 430
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 431
    .line 432
    .line 433
    move-result-object v1

    .line 434
    invoke-direct {v0, v1}, Lcom/transsnet/palmpay/custom_view/utils/KeyBoardListenerHelper;-><init>(Landroid/app/Activity;)V

    .line 435
    .line 436
    .line 437
    return-object v0

    .line 438
    :pswitch_14
    check-cast v4, Lb9/d;

    .line 439
    .line 440
    iget-object v0, v4, Lb9/d;->e:Lkotlin/jvm/functions/Function1;

    .line 441
    .line 442
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 443
    .line 444
    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 445
    .line 446
    .line 447
    iget-object v0, v4, Lb9/d;->a:Lcom/transsnet/palmpay/core/base/BaseMVPFragment;

    .line 448
    .line 449
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 450
    .line 451
    .line 452
    move-result-object v0

    .line 453
    if-nez v0, :cond_5

    .line 454
    .line 455
    goto :goto_1

    .line 456
    :cond_5
    sget v1, LF8/h;->ac_upload_receipt_failed:I

    .line 457
    .line 458
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 459
    .line 460
    .line 461
    move-result-object v0

    .line 462
    new-array v1, v2, [Ljava/lang/Object;

    .line 463
    .line 464
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 465
    .line 466
    .line 467
    :goto_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 468
    .line 469
    return-object v0

    .line 470
    :pswitch_15
    check-cast v4, Landroidx/work/impl/s;

    .line 471
    .line 472
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 473
    .line 474
    .line 475
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 476
    .line 477
    sget-object v1, Landroidx/work/impl/background/systemjob/d;->f:Ljava/lang/String;

    .line 478
    .line 479
    iget-object v1, v4, Landroidx/work/impl/s;->b:Landroid/content/Context;

    .line 480
    .line 481
    const/16 v2, 0x22

    .line 482
    .line 483
    if-lt v0, v2, :cond_6

    .line 484
    .line 485
    invoke-static {v1}, Landroidx/work/impl/background/systemjob/a;->b(Landroid/content/Context;)Landroid/app/job/JobScheduler;

    .line 486
    .line 487
    .line 488
    move-result-object v0

    .line 489
    invoke-virtual {v0}, Landroid/app/job/JobScheduler;->cancelAll()V

    .line 490
    .line 491
    .line 492
    :cond_6
    const-string v0, "jobscheduler"

    .line 493
    .line 494
    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 495
    .line 496
    .line 497
    move-result-object v0

    .line 498
    check-cast v0, Landroid/app/job/JobScheduler;

    .line 499
    .line 500
    invoke-static {v1, v0}, Landroidx/work/impl/background/systemjob/d;->b(Landroid/content/Context;Landroid/app/job/JobScheduler;)Ljava/util/ArrayList;

    .line 501
    .line 502
    .line 503
    move-result-object v1

    .line 504
    if-eqz v1, :cond_7

    .line 505
    .line 506
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 507
    .line 508
    .line 509
    move-result v2

    .line 510
    if-nez v2, :cond_7

    .line 511
    .line 512
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 513
    .line 514
    .line 515
    move-result-object v1

    .line 516
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 517
    .line 518
    .line 519
    move-result v2

    .line 520
    if-eqz v2, :cond_7

    .line 521
    .line 522
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 523
    .line 524
    .line 525
    move-result-object v2

    .line 526
    check-cast v2, Landroid/app/job/JobInfo;

    .line 527
    .line 528
    invoke-virtual {v2}, Landroid/app/job/JobInfo;->getId()I

    .line 529
    .line 530
    .line 531
    move-result v2

    .line 532
    invoke-static {v0, v2}, Landroidx/work/impl/background/systemjob/d;->a(Landroid/app/job/JobScheduler;I)V

    .line 533
    .line 534
    .line 535
    goto :goto_2

    .line 536
    :cond_7
    iget-object v0, v4, Landroidx/work/impl/s;->d:Landroidx/work/impl/WorkDatabase;

    .line 537
    .line 538
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->h()Landroidx/work/impl/model/WorkSpecDao;

    .line 539
    .line 540
    .line 541
    move-result-object v1

    .line 542
    invoke-interface {v1}, Landroidx/work/impl/model/WorkSpecDao;->resetScheduledState()I

    .line 543
    .line 544
    .line 545
    iget-object v1, v4, Landroidx/work/impl/s;->c:LV0/c;

    .line 546
    .line 547
    iget-object v2, v4, Landroidx/work/impl/s;->f:Ljava/util/List;

    .line 548
    .line 549
    invoke-static {v1, v0, v2}, Landroidx/work/impl/g;->b(LV0/c;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 550
    .line 551
    .line 552
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 553
    .line 554
    return-object v0

    .line 555
    :pswitch_16
    check-cast v4, Landroidx/work/impl/n;

    .line 556
    .line 557
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 558
    .line 559
    .line 560
    invoke-static {v4}, Landroidx/work/impl/utils/c;->a(Landroidx/work/impl/n;)V

    .line 561
    .line 562
    .line 563
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 564
    .line 565
    return-object v0

    .line 566
    :pswitch_17
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 567
    .line 568
    check-cast v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 569
    .line 570
    iget-object v0, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 571
    .line 572
    check-cast v0, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;

    .line 573
    .line 574
    if-eqz v0, :cond_8

    .line 575
    .line 576
    iget-object v1, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 577
    .line 578
    invoke-virtual {v0, v1, v2, v2}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;->e(Ljava/lang/String;ZZ)V

    .line 579
    .line 580
    .line 581
    :cond_8
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 582
    .line 583
    return-object v0

    .line 584
    :pswitch_18
    check-cast v4, LZ6/i;

    .line 585
    .line 586
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 587
    .line 588
    .line 589
    invoke-virtual {v4}, Landroid/app/Dialog;->dismiss()V

    .line 590
    .line 591
    .line 592
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 593
    .line 594
    return-object v0

    .line 595
    :pswitch_19
    check-cast v4, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 596
    .line 597
    invoke-static {v4}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;->b(Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;)Landroid/view/View$OnClickListener;

    .line 598
    .line 599
    .line 600
    move-result-object v0

    .line 601
    return-object v0

    .line 602
    :pswitch_1a
    check-cast v4, LX6/o;

    .line 603
    .line 604
    iget-object v0, v4, LX6/o;->d:LBc/l;

    .line 605
    .line 606
    const/4 v1, 0x0

    .line 607
    if-eqz v0, :cond_a

    .line 608
    .line 609
    iget-object v0, v0, LBc/l;->c:Ljava/lang/Object;

    .line 610
    .line 611
    check-cast v0, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;

    .line 612
    .line 613
    invoke-virtual {v0}, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->getTime()J

    .line 614
    .line 615
    .line 616
    move-result-wide v2

    .line 617
    iget-object v0, v4, LX6/o;->j:Lkotlin/jvm/functions/Function2;

    .line 618
    .line 619
    if-eqz v0, :cond_9

    .line 620
    .line 621
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 622
    .line 623
    .line 624
    move-result-object v2

    .line 625
    invoke-interface {v0, v2, v1}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 626
    .line 627
    .line 628
    :cond_9
    invoke-virtual {v4}, Landroid/app/Dialog;->dismiss()V

    .line 629
    .line 630
    .line 631
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 632
    .line 633
    return-object v0

    .line 634
    :cond_a
    const-string v0, "pickerBinding"

    .line 635
    .line 636
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 637
    .line 638
    .line 639
    throw v1

    .line 640
    :pswitch_1b
    check-cast v4, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;

    .line 641
    .line 642
    invoke-static {v4}, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->g(Lcom/palmpay/lib/ui/picker/picker/TimePickerView;)Ljava/util/List;

    .line 643
    .line 644
    .line 645
    move-result-object v0

    .line 646
    return-object v0

    .line 647
    :pswitch_1c
    check-cast v4, Lcom/palmpay/lib/ui/picker/picker/HoursMinutesPickerView;

    .line 648
    .line 649
    iget-object v0, v4, Lcom/palmpay/lib/ui/picker/picker/HoursMinutesPickerView;->A:Ljava/util/ArrayList;

    .line 650
    .line 651
    return-object v0

    .line 652
    nop

    .line 653
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
