.class public final synthetic LX6/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# instance fields
.field public final synthetic a:Lcom/palmpay/lib/ui/picker/picker/TimePickerView;


# direct methods
.method public synthetic constructor <init>(Lcom/palmpay/lib/ui/picker/picker/TimePickerView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LX6/e;->a:Lcom/palmpay/lib/ui/picker/picker/TimePickerView;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    check-cast p1, Ljava/lang/Integer;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    check-cast p2, Ljava/lang/Integer;

    .line 8
    .line 9
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 10
    .line 11
    .line 12
    move-result p2

    .line 13
    check-cast p3, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result p3

    .line 19
    check-cast p4, Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-virtual {p4}, Ljava/lang/Integer;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result p4

    .line 25
    sget v0, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->u0:I

    .line 26
    .line 27
    iget-object v0, p0, LX6/e;->a:Lcom/palmpay/lib/ui/picker/picker/TimePickerView;

    .line 28
    .line 29
    iget-object v1, v0, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->Q:Ljava/util/ArrayList;

    .line 30
    .line 31
    iget-object v2, v0, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->B:Ljava/util/Calendar;

    .line 32
    .line 33
    const/4 v3, 0x1

    .line 34
    const-string v4, "getTime(...)"

    .line 35
    .line 36
    if-eq p1, v3, :cond_3

    .line 37
    .line 38
    const/4 v5, 0x2

    .line 39
    const/4 v6, 0x5

    .line 40
    if-eq p1, v5, :cond_1

    .line 41
    .line 42
    const/4 p2, 0x3

    .line 43
    if-eq p1, p2, :cond_0

    .line 44
    .line 45
    goto/16 :goto_0

    .line 46
    .line 47
    :cond_0
    iget-object p1, v0, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->p0:Ljava/util/ArrayList;

    .line 48
    .line 49
    invoke-virtual {p1, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    check-cast p1, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;

    .line 54
    .line 55
    invoke-virtual {p1}, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;->getTime()Ljava/lang/Integer;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 63
    .line 64
    .line 65
    move-result p1

    .line 66
    invoke-virtual {v2, v6, p1}, Ljava/util/Calendar;->set(II)V

    .line 67
    .line 68
    .line 69
    goto/16 :goto_0

    .line 70
    .line 71
    :cond_1
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    check-cast p2, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;

    .line 80
    .line 81
    invoke-virtual {p2}, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;->getTime()Ljava/lang/Integer;

    .line 82
    .line 83
    .line 84
    move-result-object p2

    .line 85
    invoke-static {p2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 89
    .line 90
    .line 91
    move-result p2

    .line 92
    invoke-virtual {p1, v3, p2}, Ljava/util/Calendar;->set(II)V

    .line 93
    .line 94
    .line 95
    iget-object p2, v0, Lcom/palmpay/lib/ui/picker/picker/TimePickerView;->k0:Ljava/util/ArrayList;

    .line 96
    .line 97
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p4

    .line 101
    check-cast p4, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;

    .line 102
    .line 103
    invoke-virtual {p4}, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;->getTime()Ljava/lang/Integer;

    .line 104
    .line 105
    .line 106
    move-result-object p4

    .line 107
    invoke-static {p4, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {p4}, Ljava/lang/Number;->intValue()I

    .line 111
    .line 112
    .line 113
    move-result p4

    .line 114
    invoke-virtual {p1, v5, p4}, Ljava/util/Calendar;->set(II)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v2, v6}, Ljava/util/Calendar;->getActualMaximum(I)I

    .line 118
    .line 119
    .line 120
    move-result p4

    .line 121
    invoke-virtual {p1, v6}, Ljava/util/Calendar;->getActualMaximum(I)I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    if-le p4, v0, :cond_2

    .line 126
    .line 127
    invoke-virtual {p1, v6}, Ljava/util/Calendar;->getActualMaximum(I)I

    .line 128
    .line 129
    .line 130
    move-result p1

    .line 131
    invoke-virtual {v2, v6, p1}, Ljava/util/Calendar;->set(II)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    check-cast p1, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;

    .line 139
    .line 140
    invoke-virtual {p1}, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;->getTime()Ljava/lang/Integer;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 148
    .line 149
    .line 150
    move-result p1

    .line 151
    invoke-virtual {v2, v5, p1}, Ljava/util/Calendar;->set(II)V

    .line 152
    .line 153
    .line 154
    goto :goto_0

    .line 155
    :cond_2
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    check-cast p1, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;

    .line 160
    .line 161
    invoke-virtual {p1}, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;->getTime()Ljava/lang/Integer;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 169
    .line 170
    .line 171
    move-result p1

    .line 172
    invoke-virtual {v2, v5, p1}, Ljava/util/Calendar;->set(II)V

    .line 173
    .line 174
    .line 175
    goto :goto_0

    .line 176
    :cond_3
    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object p1

    .line 180
    check-cast p1, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;

    .line 181
    .line 182
    invoke-virtual {p1}, Lcom/palmpay/lib/ui/picker/picker/model/TimePickerBean;->getTime()Ljava/lang/Integer;

    .line 183
    .line 184
    .line 185
    move-result-object p1

    .line 186
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 190
    .line 191
    .line 192
    move-result p1

    .line 193
    invoke-virtual {v2, v3, p1}, Ljava/util/Calendar;->set(II)V

    .line 194
    .line 195
    .line 196
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 197
    .line 198
    return-object p1
.end method
