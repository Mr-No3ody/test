.class public final LX6/r;
.super LX6/b;
.source "SourceFile"


# instance fields
.field public d:LAd/e;

.field public e:LN6/d;

.field public f:I

.field public g:Ljava/util/ArrayList;


# virtual methods
.method public final c(Landroidx/viewbinding/ViewBinding;)V
    .locals 8

    .line 1
    check-cast p1, LN6/b;

    .line 2
    .line 3
    const-string v0, "binding"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-super {p0, p1}, LX6/b;->e(LN6/b;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sget v1, LL6/g;->lib_ui_layout_picker:I

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    const/4 v3, 0x0

    .line 23
    invoke-virtual {v0, v1, v3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    if-eqz v0, :cond_3

    .line 28
    .line 29
    check-cast v0, Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 30
    .line 31
    new-instance v1, LN6/d;

    .line 32
    .line 33
    const/4 v2, 0x0

    .line 34
    invoke-direct {v1, v0, v0, v2}, LN6/d;-><init>(Lcom/palmpay/lib/ui/picker/picker/PickerView;Lcom/palmpay/lib/ui/picker/picker/PickerView;I)V

    .line 35
    .line 36
    .line 37
    iput-object v1, p0, LX6/r;->e:LN6/d;

    .line 38
    .line 39
    iget-object v1, p1, LN6/b;->b:Landroid/widget/FrameLayout;

    .line 40
    .line 41
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 42
    .line 43
    .line 44
    new-instance v0, LN8/g;

    .line 45
    .line 46
    const/16 v1, 0x19

    .line 47
    .line 48
    invoke-direct {v0, p0, v1}, LN8/g;-><init>(Ljava/lang/Object;I)V

    .line 49
    .line 50
    .line 51
    iget-object p1, p1, LN6/b;->c:LBc/k;

    .line 52
    .line 53
    iget-object p1, p1, LBc/k;->b:Landroid/view/View;

    .line 54
    .line 55
    check-cast p1, Landroid/widget/TextView;

    .line 56
    .line 57
    const-string v1, "tvPositive"

    .line 58
    .line 59
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    new-instance v2, LX6/q;

    .line 63
    .line 64
    const/4 v4, 0x0

    .line 65
    invoke-direct {v2, p1, p0, v0, v4}, LX6/q;-><init>(Landroid/view/View;LX6/r;LN8/g;I)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {p1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 69
    .line 70
    .line 71
    new-instance v2, Ljava/util/ArrayList;

    .line 72
    .line 73
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 74
    .line 75
    .line 76
    iget-object v4, p0, LX6/r;->g:Ljava/util/ArrayList;

    .line 77
    .line 78
    if-eqz v4, :cond_0

    .line 79
    .line 80
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 85
    .line 86
    .line 87
    move-result v5

    .line 88
    if-eqz v5, :cond_0

    .line 89
    .line 90
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v5

    .line 94
    check-cast v5, Lcom/palmpay/lib/ui/picker/picker/interfac/IPickerItem;

    .line 95
    .line 96
    invoke-interface {v5}, Lcom/palmpay/lib/ui/picker/picker/interfac/IPickerItem;->getItemName()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v5

    .line 100
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    goto :goto_0

    .line 104
    :cond_0
    iget-object v4, p0, LX6/r;->e:LN6/d;

    .line 105
    .line 106
    const-string v5, "pickerBinding"

    .line 107
    .line 108
    if-eqz v4, :cond_2

    .line 109
    .line 110
    new-instance v6, LX6/p;

    .line 111
    .line 112
    const/4 v7, 0x0

    .line 113
    invoke-direct {v6, v7, v2}, LX6/p;-><init>(ILjava/util/ArrayList;)V

    .line 114
    .line 115
    .line 116
    iget-object v2, v4, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 117
    .line 118
    const/16 v4, 0xe

    .line 119
    .line 120
    invoke-static {v2, v6, v3, v3, v4}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->d(Lcom/palmpay/lib/ui/picker/picker/PickerView;Lkotlin/jvm/functions/Function0;LN8/g;LBa/a;I)V

    .line 121
    .line 122
    .line 123
    iget-object v2, p0, LX6/r;->e:LN6/d;

    .line 124
    .line 125
    if-eqz v2, :cond_1

    .line 126
    .line 127
    iget-object v2, v2, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 128
    .line 129
    invoke-virtual {v2}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->getOneWheelView()Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    iget v3, p0, LX6/r;->f:I

    .line 134
    .line 135
    invoke-virtual {v2, v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->setCurrentItem(I)V

    .line 136
    .line 137
    .line 138
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    new-instance v1, LX6/q;

    .line 142
    .line 143
    const/4 v2, 0x1

    .line 144
    invoke-direct {v1, p1, p0, v0, v2}, LX6/q;-><init>(Landroid/view/View;LX6/r;LN8/g;I)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 148
    .line 149
    .line 150
    return-void

    .line 151
    :cond_1
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    throw v3

    .line 155
    :cond_2
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    throw v3

    .line 159
    :cond_3
    new-instance p1, Ljava/lang/NullPointerException;

    .line 160
    .line 161
    const-string v0, "rootView"

    .line 162
    .line 163
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    throw p1
.end method

.method public final d()Landroidx/viewbinding/ViewBinding;
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/app/Dialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, LN6/b;->a(Landroid/view/LayoutInflater;)LN6/b;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method
