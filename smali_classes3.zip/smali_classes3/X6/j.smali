.class public final LX6/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic f:I


# instance fields
.field public final a:Landroid/content/Context;

.field public b:Ljava/lang/String;

.field public c:Ljava/util/List;

.field public d:I

.field public e:Lkotlin/jvm/functions/Function3;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LX6/i;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LX6/i;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LX6/j;->a:Landroid/content/Context;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final a()LX6/k;
    .locals 3

    .line 1
    new-instance v0, LX6/k;

    .line 2
    .line 3
    const-string v1, "context"

    .line 4
    .line 5
    iget-object v2, p0, LX6/j;->a:Landroid/content/Context;

    .line 6
    .line 7
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-direct {v0, v2}, LX6/b;-><init>(Landroid/content/Context;)V

    .line 11
    .line 12
    .line 13
    new-instance v1, Ljava/util/ArrayList;

    .line 14
    .line 15
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, LX6/j;->c:Ljava/util/List;

    .line 19
    .line 20
    iput-object v1, v0, LX6/k;->e:Ljava/util/List;

    .line 21
    .line 22
    iget-object v1, p0, LX6/j;->b:Ljava/lang/String;

    .line 23
    .line 24
    iput-object v1, v0, LX6/b;->c:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v1, p0, LX6/j;->e:Lkotlin/jvm/functions/Function3;

    .line 27
    .line 28
    iput-object v1, v0, LX6/k;->f:Lkotlin/jvm/functions/Function3;

    .line 29
    .line 30
    iget v1, p0, LX6/j;->d:I

    .line 31
    .line 32
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    iput-object v1, v0, LX6/k;->g:Ljava/lang/Integer;

    .line 37
    .line 38
    iget-object v2, v0, LX6/k;->d:LN6/d;

    .line 39
    .line 40
    if-eqz v2, :cond_0

    .line 41
    .line 42
    iget-object v2, v2, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 43
    .line 44
    invoke-virtual {v2, v1}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->b(Ljava/lang/Integer;)V

    .line 45
    .line 46
    .line 47
    :cond_0
    return-object v0
.end method
