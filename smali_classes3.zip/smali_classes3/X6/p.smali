.class public final synthetic LX6/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/util/ArrayList;


# direct methods
.method public synthetic constructor <init>(ILjava/util/ArrayList;)V
    .locals 0

    .line 1
    iput p1, p0, LX6/p;->a:I

    iput-object p2, p0, LX6/p;->b:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LX6/p;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LX6/p;->b:Ljava/util/ArrayList;

    invoke-static {v0}, Lcom/facebook/react/uimanager/ViewManagerRegistry;->b(Ljava/util/ArrayList;)Lkotlin/Unit;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LX6/p;->b:Ljava/util/ArrayList;

    invoke-static {v0}, Lcom/facebook/react/uimanager/ViewManagerRegistry;->e(Ljava/util/ArrayList;)Lkotlin/Unit;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LX6/p;->b:Ljava/util/ArrayList;

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
