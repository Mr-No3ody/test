.class public final synthetic LX6/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LX6/k;


# direct methods
.method public synthetic constructor <init>(LX6/k;I)V
    .locals 0

    .line 1
    iput p2, p0, LX6/h;->a:I

    iput-object p1, p0, LX6/h;->b:LX6/k;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LX6/h;->a:I

    .line 2
    .line 3
    check-cast p1, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, LX6/h;->b:LX6/k;

    .line 13
    .line 14
    iget-object v1, v0, LX6/k;->e:Ljava/util/List;

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v1, 0x0

    .line 24
    :goto_0
    if-le v1, p1, :cond_2

    .line 25
    .line 26
    iget-object v0, v0, LX6/k;->e:Ljava/util/List;

    .line 27
    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    check-cast p1, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 35
    .line 36
    if-eqz p1, :cond_1

    .line 37
    .line 38
    invoke-interface {p1}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-nez p1, :cond_3

    .line 43
    .line 44
    :cond_1
    sget-object p1, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_2
    sget-object p1, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 48
    .line 49
    :cond_3
    :goto_1
    return-object p1

    .line 50
    :pswitch_0
    iget-object v0, p0, LX6/h;->b:LX6/k;

    .line 51
    .line 52
    iget-object v1, v0, LX6/k;->e:Ljava/util/List;

    .line 53
    .line 54
    if-eqz v1, :cond_4

    .line 55
    .line 56
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    goto :goto_2

    .line 61
    :cond_4
    const/4 v1, 0x0

    .line 62
    :goto_2
    if-le v1, p1, :cond_6

    .line 63
    .line 64
    iget-object v0, v0, LX6/k;->e:Ljava/util/List;

    .line 65
    .line 66
    if-eqz v0, :cond_5

    .line 67
    .line 68
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    check-cast p1, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;

    .line 73
    .line 74
    if-eqz p1, :cond_5

    .line 75
    .line 76
    invoke-interface {p1}, Lcom/palmpay/lib/ui/picker/wheel/interfaces/IPickerViewData;->getChildList()Ljava/util/List;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    if-nez p1, :cond_7

    .line 81
    .line 82
    :cond_5
    sget-object p1, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 83
    .line 84
    goto :goto_3

    .line 85
    :cond_6
    sget-object p1, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 86
    .line 87
    :cond_7
    :goto_3
    return-object p1

    .line 88
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
