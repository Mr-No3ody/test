.class public final synthetic LX6/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LX6/k;


# direct methods
.method public synthetic constructor <init>(LX6/k;I)V
    .locals 0

    .line 1
    iput p2, p0, LX6/g;->a:I

    iput-object p1, p0, LX6/g;->b:LX6/k;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LX6/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LX6/g;->b:LX6/k;

    .line 7
    .line 8
    iget-object v0, v0, LX6/k;->e:Ljava/util/List;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    sget-object v0, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 13
    .line 14
    :cond_0
    return-object v0

    .line 15
    :pswitch_0
    iget-object v0, p0, LX6/g;->b:LX6/k;

    .line 16
    .line 17
    iget-object v0, v0, LX6/k;->e:Ljava/util/List;

    .line 18
    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    sget-object v0, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 22
    .line 23
    :cond_1
    return-object v0

    .line 24
    :pswitch_1
    iget-object v0, p0, LX6/g;->b:LX6/k;

    .line 25
    .line 26
    iget-object v0, v0, LX6/k;->e:Ljava/util/List;

    .line 27
    .line 28
    if-nez v0, :cond_2

    .line 29
    .line 30
    sget-object v0, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 31
    .line 32
    :cond_2
    return-object v0

    .line 33
    :pswitch_2
    iget-object v0, p0, LX6/g;->b:LX6/k;

    .line 34
    .line 35
    iget-object v1, v0, LX6/k;->d:LN6/d;

    .line 36
    .line 37
    if-eqz v1, :cond_3

    .line 38
    .line 39
    iget-object v1, v1, LN6/d;->c:Lcom/palmpay/lib/ui/picker/picker/PickerView;

    .line 40
    .line 41
    iget-object v2, v0, LX6/k;->f:Lkotlin/jvm/functions/Function3;

    .line 42
    .line 43
    if-eqz v2, :cond_3

    .line 44
    .line 45
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->getOneWheelView()Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    invoke-virtual {v3}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->getTowWheelView()Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 58
    .line 59
    .line 60
    move-result-object v4

    .line 61
    invoke-virtual {v4}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 62
    .line 63
    .line 64
    move-result v4

    .line 65
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/picker/picker/PickerView;->getThreeWheelView()Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/picker/wheel/view/WheelView;->getCurrentItem()I

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    invoke-interface {v2, v3, v4, v1}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    :cond_3
    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    .line 85
    .line 86
    .line 87
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 88
    .line 89
    return-object v0

    .line 90
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
