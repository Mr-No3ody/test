.class public abstract Lva/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Landroidx/camera/video/internal/c;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    const/16 v1, 0x17

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Landroidx/camera/video/internal/c;-><init>(IZ)V

    .line 7
    .line 8
    .line 9
    invoke-static {}, Lva/e;->a()Lva/e;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-object v1, v1, Lva/e;->a:Lretrofit2/N;

    .line 14
    .line 15
    const-class v2, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Lretrofit2/N;->b(Ljava/lang/Class;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 22
    .line 23
    iput-object v1, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 24
    .line 25
    invoke-static {}, Lva/e;->a()Lva/e;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    iget-object v1, v1, Lva/e;->a:Lretrofit2/N;

    .line 30
    .line 31
    const-class v2, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 32
    .line 33
    invoke-virtual {v1, v2}, Lretrofit2/N;->b(Ljava/lang/Class;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    check-cast v1, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 38
    .line 39
    iput-object v1, v0, Landroidx/camera/video/internal/c;->d:Ljava/lang/Object;

    .line 40
    .line 41
    invoke-static {}, Lva/e;->a()Lva/e;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    iget-object v1, v1, Lva/e;->a:Lretrofit2/N;

    .line 46
    .line 47
    const-class v2, Lcom/transsnet/palmpay/core/network/api/MemberApiService;

    .line 48
    .line 49
    invoke-virtual {v1, v2}, Lretrofit2/N;->b(Ljava/lang/Class;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Lcom/transsnet/palmpay/core/network/api/MemberApiService;

    .line 54
    .line 55
    iput-object v1, v0, Landroidx/camera/video/internal/c;->c:Ljava/lang/Object;

    .line 56
    .line 57
    sput-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 58
    .line 59
    return-void
.end method
