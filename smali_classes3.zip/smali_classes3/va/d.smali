.class public abstract Lva/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Landroidx/work/impl/model/b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Landroidx/work/impl/model/b;

    .line 2
    .line 3
    const/16 v1, 0x18

    .line 4
    .line 5
    invoke-direct {v0, v1}, Landroidx/work/impl/model/b;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lva/d;->a:Landroidx/work/impl/model/b;

    .line 9
    .line 10
    return-void
.end method
