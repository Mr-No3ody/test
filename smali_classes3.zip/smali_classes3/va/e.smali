.class public final Lva/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static volatile b:Lva/e;

.field public static final c:Ljava/lang/Object;


# instance fields
.field public final a:Lretrofit2/N;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lva/e;->c:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lretrofit2/M;

    .line 5
    .line 6
    invoke-direct {v0}, Lretrofit2/M;-><init>()V

    .line 7
    .line 8
    .line 9
    sget-object v1, Lva/d;->a:Landroidx/work/impl/model/b;

    .line 10
    .line 11
    iget-object v1, v1, Landroidx/work/impl/model/b;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Lokhttp3/U;

    .line 14
    .line 15
    const-string v2, "client == null"

    .line 16
    .line 17
    invoke-static {v1, v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    iput-object v1, v0, Lretrofit2/M;->a:Lokhttp3/U;

    .line 21
    .line 22
    new-instance v1, Lcom/google/gson/GsonBuilder;

    .line 23
    .line 24
    invoke-direct {v1}, Lcom/google/gson/GsonBuilder;-><init>()V

    .line 25
    .line 26
    .line 27
    new-instance v2, Lf4/e;

    .line 28
    .line 29
    const/4 v3, 0x3

    .line 30
    invoke-direct {v2, v3}, Lf4/e;-><init>(I)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1, v2}, Lcom/google/gson/GsonBuilder;->addSerializationExclusionStrategy(Lcom/google/gson/ExclusionStrategy;)Lcom/google/gson/GsonBuilder;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    new-instance v2, Lf4/e;

    .line 38
    .line 39
    const/4 v3, 0x2

    .line 40
    invoke-direct {v2, v3}, Lf4/e;-><init>(I)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v1, v2}, Lcom/google/gson/GsonBuilder;->addDeserializationExclusionStrategy(Lcom/google/gson/ExclusionStrategy;)Lcom/google/gson/GsonBuilder;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-virtual {v1}, Lcom/google/gson/GsonBuilder;->disableHtmlEscaping()Lcom/google/gson/GsonBuilder;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-virtual {v1}, Lcom/google/gson/GsonBuilder;->create()Lcom/google/gson/Gson;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    if-eqz v1, :cond_0

    .line 56
    .line 57
    new-instance v2, Lretrofit2/converter/gson/a;

    .line 58
    .line 59
    const/4 v3, 0x1

    .line 60
    invoke-direct {v2, v1, v3}, Lretrofit2/converter/gson/a;-><init>(Lcom/google/gson/Gson;I)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v0, v2}, Lretrofit2/M;->a(Lretrofit2/g;)V

    .line 64
    .line 65
    .line 66
    new-instance v1, Lretrofit2/f;

    .line 67
    .line 68
    const/4 v2, 0x1

    .line 69
    invoke-direct {v1, v2}, Lretrofit2/f;-><init>(I)V

    .line 70
    .line 71
    .line 72
    iget-object v2, v0, Lretrofit2/M;->d:Ljava/util/ArrayList;

    .line 73
    .line 74
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    const-string v1, "https://ng-m.palmpay.app"

    .line 78
    .line 79
    invoke-virtual {v0, v1}, Lretrofit2/M;->b(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v0}, Lretrofit2/M;->c()Lretrofit2/N;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    iput-object v0, p0, Lva/e;->a:Lretrofit2/N;

    .line 87
    .line 88
    return-void

    .line 89
    :cond_0
    new-instance v0, Ljava/lang/NullPointerException;

    .line 90
    .line 91
    const-string v1, "gson == null"

    .line 92
    .line 93
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    throw v0
.end method

.method public static a()Lva/e;
    .locals 2

    .line 1
    sget-object v0, Lva/e;->b:Lva/e;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    sget-object v0, Lva/e;->c:Ljava/lang/Object;

    .line 7
    .line 8
    monitor-enter v0

    .line 9
    :try_start_0
    sget-object v1, Lva/e;->b:Lva/e;

    .line 10
    .line 11
    if-nez v1, :cond_1

    .line 12
    .line 13
    new-instance v1, Lva/e;

    .line 14
    .line 15
    invoke-direct {v1}, Lva/e;-><init>()V

    .line 16
    .line 17
    .line 18
    sput-object v1, Lva/e;->b:Lva/e;

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :catchall_0
    move-exception v1

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    :goto_0
    sget-object v1, Lva/e;->b:Lva/e;

    .line 24
    .line 25
    monitor-exit v0

    .line 26
    return-object v1

    .line 27
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    throw v1
.end method
