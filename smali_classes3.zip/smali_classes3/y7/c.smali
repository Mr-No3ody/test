.class public final Ly7/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ly7/e;

.field public final b:Landroid/graphics/Paint;

.field public c:Ljava/util/List;

.field public d:Lz7/b;

.field public e:F

.field public f:C

.field public g:F

.field public h:D

.field public i:D

.field public j:I

.field public k:F

.field public l:F


# direct methods
.method public constructor <init>(Ly7/e;Landroid/graphics/Paint;Ljava/util/List;Lz7/b;)V
    .locals 1

    .line 1
    const-string v0, "manager"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "textPaint"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "changeCharList"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "direction"

    .line 17
    .line 18
    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, Ly7/c;->a:Ly7/e;

    .line 25
    .line 26
    iput-object p2, p0, Ly7/c;->b:Landroid/graphics/Paint;

    .line 27
    .line 28
    iput-object p3, p0, Ly7/c;->c:Ljava/util/List;

    .line 29
    .line 30
    iput-object p4, p0, Ly7/c;->d:Lz7/b;

    .line 31
    .line 32
    invoke-virtual {p0}, Ly7/c;->c()V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public static a(Ly7/c;Landroid/graphics/Canvas;IFFI)V
    .locals 9

    .line 1
    and-int/lit8 v0, p5, 0x8

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move v6, v1

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    move v6, p3

    .line 9
    :goto_0
    and-int/lit8 p3, p5, 0x10

    .line 10
    .line 11
    if-eqz p3, :cond_1

    .line 12
    .line 13
    move v7, v1

    .line 14
    goto :goto_1

    .line 15
    :cond_1
    move v7, p4

    .line 16
    :goto_1
    if-ltz p2, :cond_2

    .line 17
    .line 18
    iget-object p3, p0, Ly7/c;->c:Ljava/util/List;

    .line 19
    .line 20
    invoke-interface {p3}, Ljava/util/List;->size()I

    .line 21
    .line 22
    .line 23
    move-result p3

    .line 24
    if-ge p2, p3, :cond_2

    .line 25
    .line 26
    iget-object p3, p0, Ly7/c;->c:Ljava/util/List;

    .line 27
    .line 28
    invoke-interface {p3, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p3

    .line 32
    check-cast p3, Ljava/lang/Character;

    .line 33
    .line 34
    invoke-virtual {p3}, Ljava/lang/Character;->charValue()C

    .line 35
    .line 36
    .line 37
    move-result p3

    .line 38
    if-eqz p3, :cond_2

    .line 39
    .line 40
    iget-object p3, p0, Ly7/c;->c:Ljava/util/List;

    .line 41
    .line 42
    invoke-interface {p3, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p2

    .line 46
    check-cast p2, Ljava/lang/Character;

    .line 47
    .line 48
    invoke-virtual {p2}, Ljava/lang/Character;->charValue()C

    .line 49
    .line 50
    .line 51
    move-result p2

    .line 52
    const/4 p3, 0x1

    .line 53
    new-array v3, p3, [C

    .line 54
    .line 55
    const/4 p3, 0x0

    .line 56
    aput-char p2, v3, p3

    .line 57
    .line 58
    iget-object v8, p0, Ly7/c;->b:Landroid/graphics/Paint;

    .line 59
    .line 60
    const/4 v4, 0x0

    .line 61
    const/4 v5, 0x1

    .line 62
    move-object v2, p1

    .line 63
    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Canvas;->drawText([CIIFFLandroid/graphics/Paint;)V

    .line 64
    .line 65
    .line 66
    :cond_2
    return-void
.end method


# virtual methods
.method public final b()C
    .locals 1

    .line 1
    iget-object v0, p0, Ly7/c;->c:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    return v0

    .line 11
    :cond_0
    iget-object v0, p0, Ly7/c;->c:Ljava/util/List;

    .line 12
    .line 13
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->K(Ljava/util/List;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Ljava/lang/Character;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Character;->charValue()C

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    return v0
.end method

.method public final c()V
    .locals 7

    .line 1
    iget-object v0, p0, Ly7/c;->c:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x2

    .line 8
    if-ge v0, v1, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0}, Ly7/c;->b()C

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    iput-char v0, p0, Ly7/c;->f:C

    .line 15
    .line 16
    :cond_0
    iget-object v0, p0, Ly7/c;->c:Ljava/util/List;

    .line 17
    .line 18
    check-cast v0, Ljava/lang/Iterable;

    .line 19
    .line 20
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    const/4 v2, 0x0

    .line 29
    if-eqz v1, :cond_2

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    move-object v3, v1

    .line 36
    check-cast v3, Ljava/lang/Character;

    .line 37
    .line 38
    invoke-virtual {v3}, Ljava/lang/Character;->charValue()C

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    if-eqz v3, :cond_1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_2
    move-object v1, v2

    .line 46
    :goto_0
    check-cast v1, Ljava/lang/Character;

    .line 47
    .line 48
    const/4 v0, 0x0

    .line 49
    if-nez v1, :cond_3

    .line 50
    .line 51
    move v1, v0

    .line 52
    goto :goto_1

    .line 53
    :cond_3
    invoke-virtual {v1}, Ljava/lang/Character;->charValue()C

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    :goto_1
    iget-object v3, p0, Ly7/c;->b:Landroid/graphics/Paint;

    .line 58
    .line 59
    iget-object v4, p0, Ly7/c;->a:Ly7/e;

    .line 60
    .line 61
    invoke-virtual {v4, v1, v3}, Ly7/e;->a(CLandroid/graphics/Paint;)F

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    iput v1, p0, Ly7/c;->k:F

    .line 66
    .line 67
    iget-object v1, p0, Ly7/c;->c:Ljava/util/List;

    .line 68
    .line 69
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 70
    .line 71
    .line 72
    move-result v5

    .line 73
    invoke-interface {v1, v5}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    :cond_4
    invoke-interface {v1}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    if-eqz v5, :cond_5

    .line 82
    .line 83
    invoke-interface {v1}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    move-object v6, v5

    .line 88
    check-cast v6, Ljava/lang/Character;

    .line 89
    .line 90
    invoke-virtual {v6}, Ljava/lang/Character;->charValue()C

    .line 91
    .line 92
    .line 93
    move-result v6

    .line 94
    if-eqz v6, :cond_4

    .line 95
    .line 96
    move-object v2, v5

    .line 97
    :cond_5
    check-cast v2, Ljava/lang/Character;

    .line 98
    .line 99
    if-nez v2, :cond_6

    .line 100
    .line 101
    goto :goto_2

    .line 102
    :cond_6
    invoke-virtual {v2}, Ljava/lang/Character;->charValue()C

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    :goto_2
    invoke-virtual {v4, v0, v3}, Ly7/e;->a(CLandroid/graphics/Paint;)F

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    iput v0, p0, Ly7/c;->l:F

    .line 111
    .line 112
    invoke-virtual {p0}, Ly7/c;->d()V

    .line 113
    .line 114
    .line 115
    return-void
.end method

.method public final d()V
    .locals 3

    .line 1
    iget-object v0, p0, Ly7/c;->c:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x2

    .line 8
    if-ge v0, v1, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v0, p0, Ly7/c;->c:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->F(Ljava/util/List;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Ljava/lang/Character;

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/Character;->charValue()C

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    :goto_0
    iget-object v1, p0, Ly7/c;->a:Ly7/e;

    .line 25
    .line 26
    iget-object v2, p0, Ly7/c;->b:Landroid/graphics/Paint;

    .line 27
    .line 28
    invoke-virtual {v1, v0, v2}, Ly7/e;->a(CLandroid/graphics/Paint;)F

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    iput v0, p0, Ly7/c;->g:F

    .line 33
    .line 34
    invoke-virtual {p0}, Ly7/c;->b()C

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-virtual {v1, v0, v2}, Ly7/e;->a(CLandroid/graphics/Paint;)F

    .line 39
    .line 40
    .line 41
    iget v0, p0, Ly7/c;->g:F

    .line 42
    .line 43
    iget v1, p0, Ly7/c;->k:F

    .line 44
    .line 45
    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    iput v0, p0, Ly7/c;->e:F

    .line 50
    .line 51
    return-void
.end method
