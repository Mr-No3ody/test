.class public abstract Lt5/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Z

.field public static final b:Z

.field public static final c:Z

.field public static final d:Z

.field public static final e:Z

.field public static final f:Z

.field public static final g:Z

.field public static final h:Z

.field public static final i:Z

.field public static final j:Z


# direct methods
.method static constructor <clinit>()V
    .locals 8

    .line 1
    const-string v0, "com.tencent.smtt.sdk.WebView"

    .line 2
    .line 3
    invoke-static {v0}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    sput-boolean v0, Lt5/a;->e:Z

    .line 8
    .line 9
    const-string v0, "com.uc.webview.export.WebView"

    .line 10
    .line 11
    invoke-static {v0}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    sput-boolean v0, Lt5/a;->f:Z

    .line 16
    .line 17
    const-string v0, "androidx.recyclerview.widget.RecyclerView"

    .line 18
    .line 19
    invoke-static {v0}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    sput-boolean v1, Lt5/a;->g:Z

    .line 24
    .line 25
    const-string v1, "androidx.viewpager.widget.ViewPager"

    .line 26
    .line 27
    invoke-static {v1}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    sput-boolean v2, Lt5/a;->a:Z

    .line 32
    .line 33
    const-string v2, "androidx.swiperefreshlayout.widget.SwipeRefreshLayout"

    .line 34
    .line 35
    invoke-static {v2}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    sput-boolean v3, Lt5/a;->h:Z

    .line 40
    .line 41
    const-string v3, "androidx.fragment.app.Fragment"

    .line 42
    .line 43
    invoke-static {v3}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 44
    .line 45
    .line 46
    const-string v4, "androidx.fragment.app.FragmentActivity"

    .line 47
    .line 48
    invoke-static {v4}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 49
    .line 50
    .line 51
    const-string v5, "androidx.appcompat.app.AlertDialog"

    .line 52
    .line 53
    invoke-static {v5}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 54
    .line 55
    .line 56
    const-string v6, "androidx.appcompat.view.menu.ListMenuItemView"

    .line 57
    .line 58
    invoke-static {v6}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 59
    .line 60
    .line 61
    move-result v7

    .line 62
    sput-boolean v7, Lt5/a;->b:Z

    .line 63
    .line 64
    invoke-static {v0}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    sput-boolean v0, Lt5/a;->i:Z

    .line 69
    .line 70
    invoke-static {v1}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    sput-boolean v0, Lt5/a;->c:Z

    .line 75
    .line 76
    invoke-static {v2}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    sput-boolean v0, Lt5/a;->j:Z

    .line 81
    .line 82
    invoke-static {v3}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 83
    .line 84
    .line 85
    invoke-static {v4}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 86
    .line 87
    .line 88
    invoke-static {v5}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 89
    .line 90
    .line 91
    invoke-static {v6}, Lt5/a;->a(Ljava/lang/String;)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    sput-boolean v0, Lt5/a;->d:Z

    .line 96
    .line 97
    return-void
.end method

.method public static a(Ljava/lang/String;)Z
    .locals 0

    .line 1
    :try_start_0
    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x1

    .line 5
    return p0

    .line 6
    :catchall_0
    const/4 p0, 0x0

    .line 7
    return p0
.end method

.method public static b(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    sget-boolean v0, Lt5/a;->f:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of p0, p0, Lcom/uc/webview/export/WebView;

    .line 6
    .line 7
    if-eqz p0, :cond_0

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    return p0

    .line 11
    :cond_0
    const/4 p0, 0x0

    .line 12
    return p0
.end method

.method public static c(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    sget-boolean v0, Lt5/a;->e:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of p0, p0, Lcom/tencent/smtt/sdk/WebView;

    .line 6
    .line 7
    if-eqz p0, :cond_0

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    return p0

    .line 11
    :cond_0
    const/4 p0, 0x0

    .line 12
    return p0
.end method

.method public static d(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    instance-of v0, p0, Landroid/widget/AdapterView;

    .line 2
    .line 3
    if-nez v0, :cond_4

    .line 4
    .line 5
    sget-boolean v0, Lt5/a;->i:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    instance-of v0, p0, Landroidx/recyclerview/widget/RecyclerView;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    sget-boolean v0, Lt5/a;->c:Z

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    instance-of v0, p0, Landroidx/viewpager/widget/ViewPager;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    sget-boolean v0, Lt5/a;->g:Z

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    instance-of v0, p0, Landroidx/recyclerview/widget/RecyclerView;

    .line 28
    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_2
    sget-boolean v0, Lt5/a;->a:Z

    .line 33
    .line 34
    if-eqz v0, :cond_3

    .line 35
    .line 36
    instance-of p0, p0, Landroidx/viewpager/widget/ViewPager;

    .line 37
    .line 38
    if-eqz p0, :cond_3

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_3
    const/4 p0, 0x0

    .line 42
    return p0

    .line 43
    :cond_4
    :goto_0
    const/4 p0, 0x1

    .line 44
    return p0
.end method
