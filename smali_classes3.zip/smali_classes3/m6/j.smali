.class public final Lm6/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/interfac/OnRvItemClickListener;
.implements Lio/reactivex/ObservableOnSubscribe;
.implements Lio/reactivex/functions/Consumer;
.implements Lcom/transsnet/palmpay/core/viewmodel/TimeRemindViewHandler$CallBack1;
.implements Lcom/palmpay/lib/ui/picker/wheel/adapter/WheelAdapter;
.implements Landroidx/camera/core/impl/utils/futures/FutureCallback;
.implements Landroidx/webkit/ProfileStore;
.implements Lcom/bumptech/glide/util/GlideSuppliers$GlideSupplier;
.implements Lcom/nimbusds/jose/shaded/gson/internal/ObjectConstructor;
.implements Lcom/facebook/imagepipeline/cache/MemoryCacheTracker;
.implements Landroidx/webkit/WebViewCompat$WebMessageListener;
.implements Lretrofit2/Callback;
.implements Lcom/transsnet/palmpay/core/util/ScanFaceLogicUtil$IScanFaceResultCallBack;


# static fields
.field public static volatile c:Lm6/j;

.field public static d:Lm6/j;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/16 v0, 0xa

    iput v0, p0, Lm6/j;->a:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    sget-object v0, Landroidx/camera/camera2/internal/compat/quirk/a;->a:Landroidx/camera/core/impl/y0;

    const-class v1, Landroidx/camera/camera2/internal/compat/quirk/SmallDisplaySizeQuirk;

    invoke-virtual {v0, v1}, Landroidx/camera/core/impl/y0;->b(Ljava/lang/Class;)Landroidx/camera/core/impl/Quirk;

    move-result-object v0

    .line 6
    check-cast v0, Landroidx/camera/camera2/internal/compat/quirk/SmallDisplaySizeQuirk;

    iput-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Lm6/j;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p2, p0, Lm6/j;->a:I

    iput-object p1, p0, Lm6/j;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/util/List;)V
    .locals 1

    const/16 v0, 0x9

    iput v0, p0, Lm6/j;->a:I

    const-string v0, "items"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lm6/j;->b:Ljava/lang/Object;

    return-void
.end method

.method public static a(Lm6/j;Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 7
    .line 8
    .line 9
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->v0:Lub/k0;

    .line 10
    .line 11
    iget-object v0, v0, Lub/k0;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    iput-boolean v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->y0:Z

    .line 17
    .line 18
    new-instance v0, Lcom/transsnet/palmpay/credit/bean/req/SendMTNOTPReq;

    .line 19
    .line 20
    invoke-direct {v0}, Lcom/transsnet/palmpay/credit/bean/req/SendMTNOTPReq;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object p1, v0, Lcom/transsnet/palmpay/credit/bean/req/SendMTNOTPReq;->applyId:Ljava/lang/String;

    .line 24
    .line 25
    sget-object p1, Lob/c;->a:Lob/a;

    .line 26
    .line 27
    invoke-virtual {p1}, Lob/a;->getInstance()Lob/c;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    .line 33
    .line 34
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->sendMTNOTP(Lcom/transsnet/palmpay/credit/bean/req/SendMTNOTPReq;)Ldf/d;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 43
    .line 44
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    new-instance v0, Lub/h0;

    .line 57
    .line 58
    invoke-direct {v0, p0}, Lub/h0;-><init>(Lm6/j;)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 62
    .line 63
    .line 64
    return-void
.end method

.method public static c()Lm6/j;
    .locals 3

    .line 1
    sget-object v0, Lm6/j;->c:Lm6/j;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    const-class v0, Lm6/j;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    sget-object v1, Lm6/j;->c:Lm6/j;

    .line 9
    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    new-instance v1, Lm6/j;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-direct {v1, v2}, Lm6/j;-><init>(I)V

    .line 16
    .line 17
    .line 18
    new-instance v2, Lcom/google/gson/Gson;

    .line 19
    .line 20
    invoke-direct {v2}, Lcom/google/gson/Gson;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v2, v1, Lm6/j;->b:Ljava/lang/Object;

    .line 24
    .line 25
    sput-object v1, Lm6/j;->c:Lm6/j;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :catchall_0
    move-exception v1

    .line 29
    goto :goto_1

    .line 30
    :cond_0
    :goto_0
    monitor-exit v0

    .line 31
    goto :goto_2

    .line 32
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    throw v1

    .line 34
    :cond_1
    :goto_2
    sget-object v0, Lm6/j;->c:Lm6/j;

    .line 35
    .line 36
    return-object v0
.end method


# virtual methods
.method public accept(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, Lm6/j;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/lang/String;

    .line 7
    .line 8
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LU9/f;

    .line 11
    .line 12
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    check-cast v0, Lcom/transsnet/palmpay/contacts/contract/PersonalQRCodeContract$IView;

    .line 17
    .line 18
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/contacts/contract/PersonalQRCodeContract$IView;->showSavePath(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    return-void

    .line 22
    :pswitch_0
    check-cast p1, Lio/reactivex/disposables/Disposable;

    .line 23
    .line 24
    iget-object p1, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, LPa/Y;

    .line 27
    .line 28
    iget-object p1, p1, LPa/Y;->b:Ljava/lang/ref/WeakReference;

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    check-cast p1, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 35
    .line 36
    if-eqz p1, :cond_1

    .line 37
    .line 38
    const/4 v0, 0x1

    .line 39
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 40
    .line 41
    .line 42
    :cond_1
    return-void

    .line 43
    :pswitch_1
    check-cast p1, Lio/reactivex/disposables/Disposable;

    .line 44
    .line 45
    iget-object p1, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p1, LPa/Y;

    .line 48
    .line 49
    iget-object p1, p1, LPa/Y;->b:Ljava/lang/ref/WeakReference;

    .line 50
    .line 51
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    check-cast p1, Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 56
    .line 57
    if-eqz p1, :cond_2

    .line 58
    .line 59
    const/4 v0, 0x1

    .line 60
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 61
    .line 62
    .line 63
    :cond_2
    return-void

    .line 64
    nop

    .line 65
    :pswitch_data_0
    .packed-switch 0x5
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public b(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    :try_start_0
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lcom/google/gson/Gson;

    .line 11
    .line 12
    invoke-virtual {v0, p1, p2}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    return-object p1

    .line 17
    :catch_0
    :goto_0
    const/4 p1, 0x0

    .line 18
    return-object p1
.end method

.method public construct()Ljava/lang/Object;
    .locals 4

    .line 1
    new-instance v0, Lcom/nimbusds/jose/shaded/gson/p;

    .line 2
    .line 3
    iget-object v1, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Ljava/lang/String;

    .line 6
    .line 7
    const/16 v2, 0xa

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    invoke-direct {v0, v1, v2, v3}, LP0/c;-><init>(Ljava/lang/String;IZ)V

    .line 11
    .line 12
    .line 13
    throw v0
.end method

.method public d(Ljava/util/List;)Lo7/h;
    .locals 7

    .line 1
    const-string v0, "permissions"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 9
    .line 10
    .line 11
    new-instance v1, Ljava/util/LinkedHashSet;

    .line 12
    .line 13
    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 14
    .line 15
    .line 16
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 17
    .line 18
    iget-object v3, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v3, Landroidx/fragment/app/E;

    .line 21
    .line 22
    if-eqz v3, :cond_5

    .line 23
    .line 24
    invoke-virtual {v3}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    iget v4, v4, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    .line 29
    .line 30
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    .line 36
    .line 37
    move-result v5

    .line 38
    if-eqz v5, :cond_1

    .line 39
    .line 40
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    check-cast v5, Ljava/lang/String;

    .line 45
    .line 46
    sget-object v6, Ln7/a;->a:Ljava/util/Set;

    .line 47
    .line 48
    invoke-interface {v6, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v6

    .line 52
    if-eqz v6, :cond_0

    .line 53
    .line 54
    invoke-virtual {v1, v5}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_0
    invoke-virtual {v0, v5}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_1
    const-string p1, "android.permission.ACCESS_BACKGROUND_LOCATION"

    .line 63
    .line 64
    invoke-virtual {v1, p1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    if-eqz v5, :cond_3

    .line 69
    .line 70
    const/16 v5, 0x1d

    .line 71
    .line 72
    if-eq v2, v5, :cond_2

    .line 73
    .line 74
    const/16 v5, 0x1e

    .line 75
    .line 76
    if-ne v2, v5, :cond_3

    .line 77
    .line 78
    if-ge v4, v5, :cond_3

    .line 79
    .line 80
    :cond_2
    invoke-virtual {v1, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    :cond_3
    const-string p1, "android.permission.POST_NOTIFICATIONS"

    .line 87
    .line 88
    invoke-virtual {v1, p1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    move-result v5

    .line 92
    if-eqz v5, :cond_4

    .line 93
    .line 94
    const/16 v5, 0x21

    .line 95
    .line 96
    if-lt v2, v5, :cond_4

    .line 97
    .line 98
    if-lt v4, v5, :cond_4

    .line 99
    .line 100
    invoke-virtual {v1, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    :cond_4
    new-instance p1, Lo7/h;

    .line 107
    .line 108
    const-string v2, "normalPermissions"

    .line 109
    .line 110
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    const-string v2, "specialPermissions"

    .line 114
    .line 115
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 119
    .line 120
    .line 121
    const/4 v2, -0x1

    .line 122
    iput v2, p1, Lo7/h;->b:I

    .line 123
    .line 124
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 125
    .line 126
    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    .line 127
    .line 128
    .line 129
    iput-object v2, p1, Lo7/h;->e:Ljava/util/LinkedHashSet;

    .line 130
    .line 131
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 132
    .line 133
    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    .line 134
    .line 135
    .line 136
    iput-object v2, p1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 137
    .line 138
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 139
    .line 140
    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    .line 141
    .line 142
    .line 143
    iput-object v2, p1, Lo7/h;->g:Ljava/util/LinkedHashSet;

    .line 144
    .line 145
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 146
    .line 147
    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    .line 148
    .line 149
    .line 150
    iput-object v2, p1, Lo7/h;->h:Ljava/util/LinkedHashSet;

    .line 151
    .line 152
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 153
    .line 154
    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    .line 155
    .line 156
    .line 157
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 158
    .line 159
    invoke-direct {v2}, Ljava/util/LinkedHashSet;-><init>()V

    .line 160
    .line 161
    .line 162
    iput-object v2, p1, Lo7/h;->i:Ljava/util/LinkedHashSet;

    .line 163
    .line 164
    const-string v2, "<set-?>"

    .line 165
    .line 166
    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    iput-object v3, p1, Lo7/h;->a:Landroidx/fragment/app/E;

    .line 170
    .line 171
    iput-object v0, p1, Lo7/h;->c:Ljava/util/LinkedHashSet;

    .line 172
    .line 173
    iput-object v1, p1, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 174
    .line 175
    return-object p1

    .line 176
    :cond_5
    const/4 p1, 0x0

    .line 177
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    throw p1
.end method

.method public deleteProfile(Ljava/lang/String;)Z
    .locals 1

    .line 1
    sget-object v0, Landroidx/webkit/internal/o;->g:Landroidx/webkit/internal/n;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/webkit/internal/n;->b()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lorg/chromium/support_lib_boundary/ProfileStoreBoundaryInterface;

    .line 12
    .line 13
    invoke-interface {v0, p1}, Lorg/chromium/support_lib_boundary/ProfileStoreBoundaryInterface;->deleteProfile(Ljava/lang/String;)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    return p1

    .line 18
    :cond_0
    invoke-static {}, Landroidx/webkit/internal/o;->a()Ljava/lang/UnsupportedOperationException;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    throw p1
.end method

.method public varargs e([Ljava/lang/String;)Lo7/h;
    .locals 1

    .line 1
    const-string v0, "permissions"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    array-length v0, p1

    .line 7
    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-static {p1}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {p0, p1}, Lm6/j;->d(Ljava/util/List;)Lo7/h;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    return-object p1
.end method

.method public get()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/Context;

    .line 4
    .line 5
    const-string v1, "connectivity"

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Landroid/net/ConnectivityManager;

    .line 12
    .line 13
    return-object v0
.end method

.method public getAllProfileNames()Ljava/util/List;
    .locals 1

    .line 1
    sget-object v0, Landroidx/webkit/internal/o;->g:Landroidx/webkit/internal/n;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/webkit/internal/n;->b()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lorg/chromium/support_lib_boundary/ProfileStoreBoundaryInterface;

    .line 12
    .line 13
    invoke-interface {v0}, Lorg/chromium/support_lib_boundary/ProfileStoreBoundaryInterface;->getAllProfileNames()Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0

    .line 18
    :cond_0
    invoke-static {}, Landroidx/webkit/internal/o;->a()Ljava/lang/UnsupportedOperationException;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    throw v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/List;

    .line 4
    .line 5
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-lt p1, v1, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->K(Ljava/util/List;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1

    .line 16
    :cond_0
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    return-object p1
.end method

.method public getItemsCount()I
    .locals 1

    .line 1
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/List;

    .line 4
    .line 5
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public getOrCreateProfile(Ljava/lang/String;)Landroidx/webkit/Profile;
    .locals 2

    .line 1
    sget-object v0, Landroidx/webkit/internal/o;->g:Landroidx/webkit/internal/n;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/webkit/internal/n;->b()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    new-instance v0, Landroidx/webkit/internal/h;

    .line 10
    .line 11
    iget-object v1, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Lorg/chromium/support_lib_boundary/ProfileStoreBoundaryInterface;

    .line 14
    .line 15
    invoke-interface {v1, p1}, Lorg/chromium/support_lib_boundary/ProfileStoreBoundaryInterface;->getOrCreateProfile(Ljava/lang/String;)Ljava/lang/reflect/InvocationHandler;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    const-class v1, Lorg/chromium/support_lib_boundary/ProfileBoundaryInterface;

    .line 20
    .line 21
    invoke-static {v1, p1}, Lorg/chromium/support_lib_boundary/util/b;->n(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, Lorg/chromium/support_lib_boundary/ProfileBoundaryInterface;

    .line 26
    .line 27
    invoke-direct {v0, p1}, Landroidx/webkit/internal/h;-><init>(Lorg/chromium/support_lib_boundary/ProfileBoundaryInterface;)V

    .line 28
    .line 29
    .line 30
    return-object v0

    .line 31
    :cond_0
    invoke-static {}, Landroidx/webkit/internal/o;->a()Ljava/lang/UnsupportedOperationException;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    throw p1
.end method

.method public getProfile(Ljava/lang/String;)Landroidx/webkit/Profile;
    .locals 2

    .line 1
    sget-object v0, Landroidx/webkit/internal/o;->g:Landroidx/webkit/internal/n;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/webkit/internal/n;->b()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lorg/chromium/support_lib_boundary/ProfileStoreBoundaryInterface;

    .line 12
    .line 13
    invoke-interface {v0, p1}, Lorg/chromium/support_lib_boundary/ProfileStoreBoundaryInterface;->getProfile(Ljava/lang/String;)Ljava/lang/reflect/InvocationHandler;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    if-eqz p1, :cond_0

    .line 18
    .line 19
    new-instance v0, Landroidx/webkit/internal/h;

    .line 20
    .line 21
    const-class v1, Lorg/chromium/support_lib_boundary/ProfileBoundaryInterface;

    .line 22
    .line 23
    invoke-static {v1, p1}, Lorg/chromium/support_lib_boundary/util/b;->n(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Lorg/chromium/support_lib_boundary/ProfileBoundaryInterface;

    .line 28
    .line 29
    invoke-direct {v0, p1}, Landroidx/webkit/internal/h;-><init>(Lorg/chromium/support_lib_boundary/ProfileBoundaryInterface;)V

    .line 30
    .line 31
    .line 32
    return-object v0

    .line 33
    :cond_0
    const/4 p1, 0x0

    .line 34
    return-object p1

    .line 35
    :cond_1
    invoke-static {}, Landroidx/webkit/internal/o;->a()Ljava/lang/UnsupportedOperationException;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    throw p1
.end method

.method public indexOf(Ljava/lang/Object;)I
    .locals 1

    .line 1
    const-string v0, "o"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ljava/util/List;

    .line 9
    .line 10
    invoke-interface {v0, p1}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    return p1
.end method

.method public isChecked(Z)V
    .locals 0

    .line 1
    return-void
.end method

.method public onCacheHit(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/facebook/cache/common/CacheKey;

    .line 2
    .line 3
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;->onBitmapCacheHit(Lcom/facebook/cache/common/CacheKey;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onCacheMiss(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/facebook/cache/common/CacheKey;

    .line 2
    .line 3
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;->onBitmapCacheMiss(Lcom/facebook/cache/common/CacheKey;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onCachePut(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/facebook/cache/common/CacheKey;

    .line 2
    .line 3
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;->onBitmapCachePut(Lcom/facebook/cache/common/CacheKey;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onFailed(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    .line 1
    iget-object p3, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v1, p3

    .line 4
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 5
    .line 6
    const/4 p3, 0x0

    .line 7
    invoke-virtual {v1, p3}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 8
    .line 9
    .line 10
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->X:I

    .line 11
    .line 12
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 13
    .line 14
    const-string v2, "checkAliFaceResultFailed >>> errorCode="

    .line 15
    .line 16
    const-string v3, ", errorMsg="

    .line 17
    .line 18
    invoke-static {v2, p1, v3, p2}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p2

    .line 26
    const/4 v2, 0x3

    .line 27
    invoke-static {v0, v2, p2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    const-string p2, "VL000073"

    .line 31
    .line 32
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    if-eqz p2, :cond_0

    .line 37
    .line 38
    new-instance v0, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;

    .line 39
    .line 40
    sget p1, Lba/k;->core_sign_out:I

    .line 41
    .line 42
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    sget p1, LYa/g;->cs_oc_face_recognition_failed:I

    .line 47
    .line 48
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    sget p1, LYa/g;->cs_oc_ali_face_max_time:I

    .line 53
    .line 54
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    const/4 v2, 0x0

    .line 59
    invoke-direct/range {v0 .. v5}, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    new-instance p1, Lub/g;

    .line 63
    .line 64
    invoke-direct {p1, v1, p3}, Lub/g;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;I)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;->setRightListener(Landroid/view/View$OnClickListener;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v0}, LO6/f;->show()V

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :cond_0
    const-string p2, "VL000075"

    .line 75
    .line 76
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result p2

    .line 80
    if-eqz p2, :cond_1

    .line 81
    .line 82
    new-instance v0, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;

    .line 83
    .line 84
    sget p1, LYa/g;->cs_oc_face_give_up:I

    .line 85
    .line 86
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    sget p1, Lba/k;->core_try_again1:I

    .line 91
    .line 92
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    sget p1, LYa/g;->cs_oc_face_recognition_failed:I

    .line 97
    .line 98
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    sget p1, LYa/g;->cs_oc_face_common_failed_reason:I

    .line 103
    .line 104
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v5

    .line 108
    invoke-direct/range {v0 .. v5}, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    new-instance p1, Lub/g;

    .line 112
    .line 113
    const/4 p2, 0x1

    .line 114
    invoke-direct {p1, v1, p2}, Lub/g;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;I)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;->setLeftListener(Landroid/view/View$OnClickListener;)V

    .line 118
    .line 119
    .line 120
    new-instance p1, Lsb/A;

    .line 121
    .line 122
    const/16 p2, 0xf

    .line 123
    .line 124
    invoke-direct {p1, p2}, Lsb/A;-><init>(I)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;->setRightListener(Landroid/view/View$OnClickListener;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v0}, LO6/f;->show()V

    .line 131
    .line 132
    .line 133
    return-void

    .line 134
    :cond_1
    new-instance v0, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;

    .line 135
    .line 136
    sget p2, Lba/k;->core_got_it:I

    .line 137
    .line 138
    invoke-virtual {v1, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v3

    .line 142
    sget p2, LYa/g;->cs_oc_face_recognition_failed:I

    .line 143
    .line 144
    invoke-virtual {v1, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v4

    .line 148
    sget p2, LYa/g;->cs_oc_face_service_unavailable:I

    .line 149
    .line 150
    invoke-virtual {v1, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v5

    .line 154
    const/4 v2, 0x0

    .line 155
    invoke-direct/range {v0 .. v5}, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    new-instance p2, Ltb/W;

    .line 159
    .line 160
    const/4 p3, 0x4

    .line 161
    invoke-direct {p2, p3, p1, v1}, Ltb/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v0, p2}, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceFailedDialog;->setRightListener(Landroid/view/View$OnClickListener;)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v0}, LO6/f;->show()V

    .line 168
    .line 169
    .line 170
    return-void
.end method

.method public onFailure(Ljava/lang/Throwable;)V
    .locals 3

    iget v0, p0, Lm6/j;->a:I

    packed-switch v0, :pswitch_data_0

    .line 2
    instance-of v0, p1, Landroid/media/MediaCodec$CodecException;

    iget-object v1, p0, Lm6/j;->b:Ljava/lang/Object;

    check-cast v1, Lorg/greenrobot/eventbus/f;

    iget-object v1, v1, Lorg/greenrobot/eventbus/f;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/camera/video/internal/encoder/v;

    if-eqz v0, :cond_0

    .line 3
    check-cast p1, Landroid/media/MediaCodec$CodecException;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    invoke-virtual {v1, v2, v0, p1}, Landroidx/camera/video/internal/encoder/v;->b(ILjava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_0

    .line 5
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    .line 6
    invoke-virtual {v1, v2, v0, p1}, Landroidx/camera/video/internal/encoder/v;->b(ILjava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    return-void

    .line 7
    :pswitch_0
    instance-of v0, p1, Ljava/util/concurrent/TimeoutException;

    iget-object v1, p0, Lm6/j;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/concurrent/futures/k;

    if-eqz v0, :cond_1

    .line 8
    invoke-virtual {v1, p1}, Landroidx/concurrent/futures/k;->d(Ljava/lang/Throwable;)Z

    goto :goto_1

    .line 9
    :cond_1
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    invoke-virtual {v1, p1}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Object;)Z

    :goto_1
    return-void

    :pswitch_data_0
    .packed-switch 0xb
        :pswitch_0
    .end packed-switch
.end method

.method public onFailure(Lretrofit2/Call;Ljava/lang/Throwable;)V
    .locals 1

    const-string v0, "call"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "t"

    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    sget-object p1, Lxf/q;->a:Lxf/o;

    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    move-result-object p1

    iget-object p2, p0, Lm6/j;->b:Ljava/lang/Object;

    check-cast p2, LWf/i;

    invoke-virtual {p2, p1}, LWf/i;->resumeWith(Ljava/lang/Object;)V

    return-void
.end method

.method public onInputChanged(Z)V
    .locals 2

    .line 1
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/contacts/ui/activity/EditCloseContactsActivity;

    .line 4
    .line 5
    iput-boolean p1, v0, Lcom/transsnet/palmpay/contacts/ui/activity/EditCloseContactsActivity;->B:Z

    .line 6
    .line 7
    iget-object v1, v0, Lcom/transsnet/palmpay/contacts/ui/activity/EditCloseContactsActivity;->c:Landroid/widget/TextView;

    .line 8
    .line 9
    iget-boolean v0, v0, Lcom/transsnet/palmpay/contacts/ui/activity/EditCloseContactsActivity;->A:Z

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    if-eqz p1, :cond_0

    .line 14
    .line 15
    const/4 p1, 0x1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 p1, 0x0

    .line 18
    :goto_0
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public onItemClick(Landroid/view/View;I)V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const-string v1, "get(...)"

    .line 3
    .line 4
    const-string v2, "itemView"

    .line 5
    .line 6
    iget v3, p0, Lm6/j;->a:I

    .line 7
    .line 8
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sparse-switch v3, :sswitch_data_0

    .line 12
    .line 13
    .line 14
    iget-object p1, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/OcMainFragment;

    .line 17
    .line 18
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/ui/fragment/OcMainFragment;->z0:Ljava/util/ArrayList;

    .line 19
    .line 20
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcFinanceMenuData;

    .line 28
    .line 29
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcFinanceMenuData;->getJumpType()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcFinanceMenuData;->getJumpPath()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcFinanceMenuData;->getJumpParams()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    invoke-static {p2, v1, p1, v0}, Lorg/chromium/support_lib_boundary/util/b;->Q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :sswitch_0
    iget-object p1, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/cashloan/CLRepaymentListActivity;

    .line 48
    .line 49
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/ui/activity/cashloan/CLRepaymentListActivity;->e:Ljava/util/ArrayList;

    .line 50
    .line 51
    if-eqz p1, :cond_0

    .line 52
    .line 53
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListDetail;

    .line 61
    .line 62
    new-instance p2, Landroid/os/Bundle;

    .line 63
    .line 64
    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    .line 65
    .line 66
    .line 67
    const-string v0, "orderType"

    .line 68
    .line 69
    const-string v1, "j7"

    .line 70
    .line 71
    invoke-virtual {p2, v0, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListDetail;->getPayId()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    const-string v1, "orderNo"

    .line 79
    .line 80
    invoke-virtual {p2, v1, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    const-string v0, "cardNo"

    .line 84
    .line 85
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListDetail;->getCardNo()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    invoke-virtual {p2, v0, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    const-string p1, "RepaymentDetails"

    .line 93
    .line 94
    invoke-static {p2, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    :cond_0
    const-string p1, "mData"

    .line 99
    .line 100
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    throw v0

    .line 104
    :sswitch_1
    iget-object p1, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;

    .line 107
    .line 108
    iput p2, p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->y1:I

    .line 109
    .line 110
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->z1:Ljava/util/ArrayList;

    .line 111
    .line 112
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object p2

    .line 116
    check-cast p2, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 117
    .line 118
    iput-object p2, p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->q1:Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 119
    .line 120
    sget p2, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->M1:I

    .line 121
    .line 122
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->n0()V

    .line 123
    .line 124
    .line 125
    return-void

    .line 126
    nop

    .line 127
    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x16 -> :sswitch_0
    .end sparse-switch
.end method

.method public onPostMessage(Landroid/webkit/WebView;Landroidx/webkit/h;Landroid/net/Uri;ZLandroidx/webkit/b;)V
    .locals 0

    .line 1
    iget p1, p2, Landroidx/webkit/h;->b:I

    .line 2
    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    invoke-virtual {p3}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iget-object p3, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p3, Lcom/reactnativecommunity/webview/RNCWebView;

    .line 12
    .line 13
    iget-object p2, p2, Landroidx/webkit/h;->a:Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {p3, p2, p1}, Lcom/reactnativecommunity/webview/RNCWebView;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    new-instance p3, Ljava/lang/StringBuilder;

    .line 22
    .line 23
    const-string p4, "Wrong data accessor type detected. "

    .line 24
    .line 25
    invoke-direct {p3, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    const-string p4, "String"

    .line 29
    .line 30
    if-eqz p1, :cond_2

    .line 31
    .line 32
    const/4 p5, 0x1

    .line 33
    if-eq p1, p5, :cond_1

    .line 34
    .line 35
    const-string p1, "Unknown"

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_1
    const-string p1, "ArrayBuffer"

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_2
    move-object p1, p4

    .line 42
    :goto_0
    const-string p5, " expected, but got "

    .line 43
    .line 44
    invoke-static {p3, p1, p5, p4}, Landroidx/camera/camera2/internal/F;->d(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw p2
.end method

.method public onProcessing()V
    .locals 2

    .line 1
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public onResponse(Lretrofit2/Call;Lretrofit2/K;)V
    .locals 1

    .line 1
    const-string v0, "call"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "response"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p2, Lretrofit2/K;->a:Lokhttp3/e0;

    .line 12
    .line 13
    invoke-virtual {p1}, Lokhttp3/e0;->isSuccessful()Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, LWf/i;

    .line 20
    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 24
    .line 25
    iget-object p1, p2, Lretrofit2/K;->b:Ljava/lang/Object;

    .line 26
    .line 27
    invoke-virtual {v0, p1}, LWf/i;->resumeWith(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_0
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 32
    .line 33
    new-instance p1, Lretrofit2/k;

    .line 34
    .line 35
    invoke-direct {p1, p2}, Lretrofit2/k;-><init>(Lretrofit2/K;)V

    .line 36
    .line 37
    .line 38
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-virtual {v0, p1}, LWf/i;->resumeWith(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method public onSelectBillType(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public onSuccess(Lcom/transsnet/palmpay/core/bean/rsp/ALiFaceCheckResultData;)V
    .locals 7

    const-string v0, "data"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, Lm6/j;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    const/4 v2, 0x1

    .line 2
    iput-boolean v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v:Z

    .line 3
    iget-object v2, v0, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 4
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "checkAliFaceResultSuccess >>> resp="

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const/4 v4, 0x3

    .line 5
    invoke-static {v2, v4, v3}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 6
    iget-boolean v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v:Z

    if-eqz v2, :cond_3

    .line 7
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/ALiFaceCheckResultData;->s3Url:Ljava/lang/String;

    .line 8
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    const-string v3, "OK_CARD"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 9
    const-string v2, "OK_CARD_APPLY"

    goto :goto_0

    .line 10
    :cond_0
    const-string v2, "CASH_LOAN_APPLY"

    .line 11
    :goto_0
    new-instance v3, Lcom/transsnet/palmpay/credit/bean/req/OcUploadALiFaceResultReq;

    .line 12
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    const/4 v5, 0x0

    if-eqz v4, :cond_1

    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplyId()Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_1
    move-object v4, v5

    .line 13
    :goto_1
    iget-object v6, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    if-eqz v6, :cond_2

    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    move-result-object v6

    goto :goto_2

    :cond_2
    move-object v6, v5

    .line 14
    :goto_2
    invoke-direct {v3, p1, v4, v6, v2}, Lcom/transsnet/palmpay/credit/bean/req/OcUploadALiFaceResultReq;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    move-result-object p1

    check-cast p1, Lcom/transsnet/palmpay/credit/viewmodel/OcApplyBaseViewModel;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    new-instance v0, LJb/d;

    invoke-direct {v0, v3, v5}, LJb/d;-><init>(Lcom/transsnet/palmpay/credit/bean/req/OcUploadALiFaceResultReq;Lkotlin/coroutines/Continuation;)V

    const/16 v2, 0x1c

    iget-object v3, p1, Lcom/transsnet/palmpay/credit/viewmodel/OcApplyBaseViewModel;->p:Lcom/transsnet/palmpay/core/base/l;

    invoke-static {p1, v0, v3, v1, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    :cond_3
    return-void
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .locals 1

    iget v0, p0, Lm6/j;->a:I

    packed-switch v0, :pswitch_data_0

    .line 17
    check-cast p1, Ljava/lang/Void;

    return-void

    .line 18
    :pswitch_0
    check-cast p1, Ljava/util/List;

    .line 19
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 21
    iget-object p1, p0, Lm6/j;->b:Ljava/lang/Object;

    check-cast p1, Landroidx/concurrent/futures/k;

    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Object;)Z

    return-void

    :pswitch_data_0
    .packed-switch 0xb
        :pswitch_0
    .end packed-switch
.end method

.method public subscribe(Lio/reactivex/ObservableEmitter;)V
    .locals 8

    .line 1
    new-instance v0, Ljava/io/File;

    .line 2
    .line 3
    new-instance v1, Ljava/io/File;

    .line 4
    .line 5
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    sget-object v3, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const-string v3, "qrcode"

    .line 16
    .line 17
    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    if-nez v2, :cond_0

    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 27
    .line 28
    .line 29
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 30
    .line 31
    const-string v3, "qrcode_"

    .line 32
    .line 33
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 37
    .line 38
    .line 39
    move-result-wide v3

    .line 40
    new-instance v5, Ljava/text/SimpleDateFormat;

    .line 41
    .line 42
    const-string/jumbo v6, "yyyy-MM-dd_HH-mm_ss"

    .line 43
    .line 44
    .line 45
    sget-object v7, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 46
    .line 47
    invoke-direct {v5, v6, v7}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 48
    .line 49
    .line 50
    invoke-static {v3, v4, v5}, Lcom/transsnet/palmpay/util/TimeUtils;->millis2String(JLjava/text/DateFormat;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string v3, ".jpg"

    .line 58
    .line 59
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    iget-object v1, p0, Lm6/j;->b:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v1, Landroid/graphics/Bitmap;

    .line 72
    .line 73
    sget-object v2, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    .line 74
    .line 75
    invoke-static {v1, v0, v2}, Lcom/transsnet/palmpay/util/ImageUtils;->save(Landroid/graphics/Bitmap;Ljava/io/File;Landroid/graphics/Bitmap$CompressFormat;)Z

    .line 76
    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    if-nez v1, :cond_1

    .line 87
    .line 88
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    invoke-static {v1, v0}, LPa/r0;->N1(Landroid/content/Context;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    invoke-interface {p1, v0}, Lio/reactivex/Emitter;->onNext(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    :cond_1
    invoke-interface {p1}, Lio/reactivex/Emitter;->onComplete()V

    .line 99
    .line 100
    .line 101
    return-void
.end method
