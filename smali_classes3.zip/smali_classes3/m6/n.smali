.class public abstract Lm6/n;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lm6/m;

.field public static volatile b:Lm6/n;

.field public static volatile c:Z

.field public static d:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lm6/m;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lm6/m;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lm6/n;->a:Lm6/m;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public varargs abstract a(La9/f;[Ljava/lang/String;)V
.end method

.method public abstract b(Ljava/lang/String;Z)Z
.end method

.method public abstract c(Ljava/lang/String;Ljava/lang/Number;)Ljava/lang/Number;
.end method

.method public abstract d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
.end method

.method public abstract e(Ljava/lang/String;)V
.end method
