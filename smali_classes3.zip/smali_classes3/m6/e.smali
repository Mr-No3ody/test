.class public final Lm6/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final h:J


# instance fields
.field public final a:Lag/c;

.field public final b:LWf/s;

.field public final c:J

.field public final d:Landroid/content/Context;

.field public e:LWf/t0;

.field public f:LWf/t0;

.field public g:Lm6/f;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lm6/a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lm6/a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 8
    .line 9
    const-wide/16 v1, 0x1e

    .line 10
    .line 11
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    sput-wide v0, Lm6/e;->h:J

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;J)V
    .locals 3

    .line 1
    invoke-static {}, LWf/y;->c()LWf/v0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, LWf/I;->a:Lcg/f;

    .line 6
    .line 7
    sget-object v1, Lcg/e;->c:Lcg/e;

    .line 8
    .line 9
    invoke-static {v0, v1}, Lkotlin/coroutines/e;->c(Lkotlin/coroutines/CoroutineContext$Element;Lkotlin/coroutines/CoroutineContext;)Lkotlin/coroutines/CoroutineContext;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-static {v0}, LWf/v;->a(Lkotlin/coroutines/CoroutineContext;)Lag/c;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const-string v2, "context"

    .line 18
    .line 19
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const-string v2, "scope"

    .line 23
    .line 24
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const-string v2, "dispatcher"

    .line 28
    .line 29
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    iput-object v0, p0, Lm6/e;->a:Lag/c;

    .line 36
    .line 37
    iput-object v1, p0, Lm6/e;->b:LWf/s;

    .line 38
    .line 39
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 40
    .line 41
    invoke-virtual {v0, p2, p3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    .line 42
    .line 43
    .line 44
    move-result-wide p2

    .line 45
    iput-wide p2, p0, Lm6/e;->c:J

    .line 46
    .line 47
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    const-string p2, "getApplicationContext(...)"

    .line 52
    .line 53
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    iput-object p1, p0, Lm6/e;->d:Landroid/content/Context;

    .line 57
    .line 58
    return-void
.end method


# virtual methods
.method public final declared-synchronized a(ZLm6/f;)V
    .locals 9

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    const-string v0, "method"

    .line 3
    .line 4
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Lm6/e;->b()V

    .line 8
    .line 9
    .line 10
    iput-object p2, p0, Lm6/e;->g:Lm6/f;

    .line 11
    .line 12
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 13
    .line 14
    .line 15
    move-result-wide v0

    .line 16
    iget-object v2, p0, Lm6/e;->d:Landroid/content/Context;

    .line 17
    .line 18
    const-string v3, "PalmPayRemoteConfig"

    .line 19
    .line 20
    sget-object v4, Lm6/k;->a:Lcom/tencent/mmkv/MMKV;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    .line 22
    if-nez v4, :cond_0

    .line 23
    .line 24
    :try_start_1
    invoke-static {v3}, Lcom/tencent/mmkv/MMKV;->o(Ljava/lang/String;)Lcom/tencent/mmkv/MMKV;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    sput-object v4, Lm6/k;->a:Lcom/tencent/mmkv/MMKV;
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :catch_0
    :try_start_2
    invoke-static {v2}, Lcom/tencent/mmkv/MMKV;->m(Landroid/content/Context;)V

    .line 32
    .line 33
    .line 34
    invoke-static {v3}, Lcom/tencent/mmkv/MMKV;->o(Ljava/lang/String;)Lcom/tencent/mmkv/MMKV;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    sput-object v2, Lm6/k;->a:Lcom/tencent/mmkv/MMKV;

    .line 39
    .line 40
    :cond_0
    :goto_0
    sget-object v2, Lm6/k;->a:Lcom/tencent/mmkv/MMKV;

    .line 41
    .line 42
    const-wide/16 v3, 0x0

    .line 43
    .line 44
    if-eqz v2, :cond_1

    .line 45
    .line 46
    const-string v5, "_lats_poll_time"

    .line 47
    .line 48
    invoke-virtual {v2, v5, v3, v4}, Lcom/tencent/mmkv/MMKV;->getLong(Ljava/lang/String;J)J

    .line 49
    .line 50
    .line 51
    move-result-wide v5

    .line 52
    goto :goto_1

    .line 53
    :cond_1
    move-wide v5, v3

    .line 54
    :goto_1
    sub-long/2addr v0, v5

    .line 55
    iget-wide v5, p0, Lm6/e;->c:J

    .line 56
    .line 57
    new-instance v2, Lkotlin/jvm/internal/E;

    .line 58
    .line 59
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 60
    .line 61
    .line 62
    if-eqz p1, :cond_2

    .line 63
    .line 64
    const-wide/16 v7, 0x4e20

    .line 65
    .line 66
    cmp-long p1, v0, v7

    .line 67
    .line 68
    if-gtz p1, :cond_4

    .line 69
    .line 70
    :cond_2
    cmp-long p1, v0, v5

    .line 71
    .line 72
    if-gtz p1, :cond_4

    .line 73
    .line 74
    cmp-long p1, v0, v3

    .line 75
    .line 76
    if-gtz p1, :cond_3

    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_3
    sub-long v3, v5, v0

    .line 80
    .line 81
    :cond_4
    :goto_2
    iput-wide v3, v2, Lkotlin/jvm/internal/E;->a:J

    .line 82
    .line 83
    iget-object p1, p0, Lm6/e;->a:Lag/c;

    .line 84
    .line 85
    iget-object v0, p0, Lm6/e;->b:LWf/s;

    .line 86
    .line 87
    new-instance v1, Lm6/d;

    .line 88
    .line 89
    const/4 v3, 0x0

    .line 90
    invoke-direct {v1, v2, p2, p0, v3}, Lm6/d;-><init>(Lkotlin/jvm/internal/E;Lm6/f;Lm6/e;Lkotlin/coroutines/Continuation;)V

    .line 91
    .line 92
    .line 93
    const/4 p2, 0x2

    .line 94
    invoke-static {p1, v0, v3, v1, p2}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    iput-object p1, p0, Lm6/e;->e:LWf/t0;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 99
    .line 100
    monitor-exit p0

    .line 101
    return-void

    .line 102
    :catchall_0
    move-exception p1

    .line 103
    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 104
    throw p1
.end method

.method public final declared-synchronized b()V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Lm6/e;->e:LWf/t0;

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {v0, v1}, LWf/n0;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 8
    .line 9
    .line 10
    :cond_0
    iget-object v0, p0, Lm6/e;->f:LWf/t0;

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    invoke-virtual {v0, v1}, LWf/n0;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 15
    .line 16
    .line 17
    :cond_1
    iput-object v1, p0, Lm6/e;->e:LWf/t0;

    .line 18
    .line 19
    iput-object v1, p0, Lm6/e;->f:LWf/t0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    .line 21
    monitor-exit p0

    .line 22
    return-void

    .line 23
    :catchall_0
    move-exception v0

    .line 24
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 25
    throw v0
.end method
