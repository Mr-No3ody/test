.class public final Lm6/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ln6/c;

.field public final c:Ljava/io/File;

.field public final d:Lm6/e;

.field public e:Ljava/lang/String;

.field public final f:Lm6/s;

.field public final g:LWf/s;

.field public h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

.field public final i:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lm6/g;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lm6/g;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ln6/c;Ljava/io/File;Lm6/e;Lm6/s;I)V
    .locals 4

    .line 1
    const/4 v0, 0x2

    .line 2
    and-int/lit8 v1, p6, 0x2

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    move-object p2, v2

    .line 8
    :cond_0
    and-int/lit8 v1, p6, 0x4

    .line 9
    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    move-object p3, v2

    .line 13
    :cond_1
    and-int/lit8 p6, p6, 0x8

    .line 14
    .line 15
    if-eqz p6, :cond_2

    .line 16
    .line 17
    move-object p4, v2

    .line 18
    :cond_2
    sget-object p6, LWf/I;->a:Lcg/f;

    .line 19
    .line 20
    sget-object p6, Lcg/e;->c:Lcg/e;

    .line 21
    .line 22
    const-string v1, "context"

    .line 23
    .line 24
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const-string v1, "dispatcher"

    .line 28
    .line 29
    invoke-static {p6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    iput-object p1, p0, Lm6/i;->a:Landroid/content/Context;

    .line 36
    .line 37
    iput-object p2, p0, Lm6/i;->b:Ln6/c;

    .line 38
    .line 39
    iput-object p3, p0, Lm6/i;->c:Ljava/io/File;

    .line 40
    .line 41
    iput-object p4, p0, Lm6/i;->d:Lm6/e;

    .line 42
    .line 43
    iput-object v2, p0, Lm6/i;->e:Ljava/lang/String;

    .line 44
    .line 45
    iput-object p5, p0, Lm6/i;->f:Lm6/s;

    .line 46
    .line 47
    iput-object p6, p0, Lm6/i;->g:LWf/s;

    .line 48
    .line 49
    if-nez p3, :cond_5

    .line 50
    .line 51
    if-eqz p5, :cond_3

    .line 52
    .line 53
    iget-object p2, p5, Lm6/s;->b:Ljava/lang/String;

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_3
    move-object p2, v2

    .line 57
    :goto_0
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 58
    .line 59
    .line 60
    move-result p2

    .line 61
    if-nez p2, :cond_5

    .line 62
    .line 63
    new-instance p2, Ljava/io/File;

    .line 64
    .line 65
    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    if-eqz p5, :cond_4

    .line 70
    .line 71
    iget-object p3, p5, Lm6/s;->b:Ljava/lang/String;

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_4
    move-object p3, v2

    .line 75
    :goto_1
    const-string p4, "-config.cache.json"

    .line 76
    .line 77
    invoke-static {p3, p4}, LN8/q0;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object p3

    .line 81
    invoke-direct {p2, p1, p3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    iput-object p2, p0, Lm6/i;->c:Ljava/io/File;

    .line 85
    .line 86
    :cond_5
    iget-object p1, p0, Lm6/i;->c:Ljava/io/File;

    .line 87
    .line 88
    const-string p2, "Config"

    .line 89
    .line 90
    const/4 p3, 0x1

    .line 91
    if-eqz p1, :cond_6

    .line 92
    .line 93
    :try_start_0
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    .line 94
    .line 95
    .line 96
    move-result p4

    .line 97
    if-ne p4, p3, :cond_6

    .line 98
    .line 99
    invoke-static {p1}, LKf/m;->b(Ljava/io/File;)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 104
    .line 105
    .line 106
    move-result p4

    .line 107
    if-nez p4, :cond_6

    .line 108
    .line 109
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 110
    .line 111
    .line 112
    :try_start_1
    invoke-static {}, Lm6/j;->c()Lm6/j;

    .line 113
    .line 114
    .line 115
    move-result-object p4

    .line 116
    const-class p5, Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 117
    .line 118
    invoke-virtual {p4, p1, p5}, Lm6/j;->b(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    check-cast p1, Lcom/palmpay/lib/config/api/bean/ConfigRsp;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :catch_0
    move-exception p1

    .line 126
    :try_start_2
    const-string p4, "Error parsing config from cached file"

    .line 127
    .line 128
    invoke-static {p2, p4, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 129
    .line 130
    .line 131
    :catchall_0
    :cond_6
    move-object p1, v2

    .line 132
    :goto_2
    iput-object p1, p0, Lm6/i;->h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 133
    .line 134
    new-instance p4, Lkotlin/jvm/internal/B;

    .line 135
    .line 136
    invoke-direct {p4}, Ljava/lang/Object;-><init>()V

    .line 137
    .line 138
    .line 139
    iput-boolean p3, p4, Lkotlin/jvm/internal/B;->a:Z

    .line 140
    .line 141
    const/4 p5, 0x0

    .line 142
    if-nez p1, :cond_7

    .line 143
    .line 144
    iput-boolean p5, p4, Lkotlin/jvm/internal/B;->a:Z

    .line 145
    .line 146
    new-instance p1, Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 147
    .line 148
    invoke-direct {p1}, Lcom/palmpay/lib/config/api/bean/ConfigRsp;-><init>()V

    .line 149
    .line 150
    .line 151
    iput-object p1, p0, Lm6/i;->h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 152
    .line 153
    :cond_7
    iget-object p1, p0, Lm6/i;->a:Landroid/content/Context;

    .line 154
    .line 155
    iget-object p6, p0, Lm6/i;->f:Lm6/s;

    .line 156
    .line 157
    if-eqz p6, :cond_8

    .line 158
    .line 159
    iget p6, p6, Lm6/s;->f:I

    .line 160
    .line 161
    goto :goto_3

    .line 162
    :cond_8
    move p6, p5

    .line 163
    :goto_3
    if-nez p6, :cond_9

    .line 164
    .line 165
    invoke-static {}, Lkotlin/collections/G;->c()Lkotlin/collections/A;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    goto :goto_5

    .line 170
    :cond_9
    :try_start_3
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 171
    .line 172
    .line 173
    move-result-object p1

    .line 174
    invoke-virtual {p1, p6}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    .line 175
    .line 176
    .line 177
    move-result-object p1
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 178
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 179
    .line 180
    .line 181
    new-instance p2, Ljava/util/HashMap;

    .line 182
    .line 183
    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    .line 184
    .line 185
    .line 186
    move-object p6, v2

    .line 187
    :goto_4
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    .line 188
    .line 189
    .line 190
    move-result v1

    .line 191
    if-eq v1, p3, :cond_d

    .line 192
    .line 193
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    .line 194
    .line 195
    .line 196
    move-result v1

    .line 197
    if-ne v1, v0, :cond_a

    .line 198
    .line 199
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object v1

    .line 203
    const-string v3, "key"

    .line 204
    .line 205
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    move-result v1

    .line 209
    if-eqz v1, :cond_a

    .line 210
    .line 211
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object p6

    .line 215
    :cond_a
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    .line 216
    .line 217
    .line 218
    move-result v1

    .line 219
    if-ne v1, v0, :cond_c

    .line 220
    .line 221
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object v1

    .line 225
    const-string v3, "value"

    .line 226
    .line 227
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 228
    .line 229
    .line 230
    move-result v1

    .line 231
    if-eqz v1, :cond_c

    .line 232
    .line 233
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    .line 234
    .line 235
    .line 236
    move-result-object v1

    .line 237
    invoke-static {p6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 238
    .line 239
    .line 240
    move-result v3

    .line 241
    if-nez v3, :cond_b

    .line 242
    .line 243
    invoke-static {p6}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    invoke-virtual {p2, p6, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    :cond_b
    move-object p6, v2

    .line 250
    :cond_c
    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    .line 251
    .line 252
    .line 253
    goto :goto_4

    .line 254
    :cond_d
    move-object p1, p2

    .line 255
    goto :goto_5

    .line 256
    :catch_1
    move-exception p1

    .line 257
    new-instance p3, Ljava/lang/StringBuilder;

    .line 258
    .line 259
    const-string v0, "Default config xml not found: "

    .line 260
    .line 261
    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    invoke-virtual {p3, p6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 265
    .line 266
    .line 267
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 268
    .line 269
    .line 270
    move-result-object p3

    .line 271
    invoke-static {p2, p3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 272
    .line 273
    .line 274
    invoke-static {}, Lkotlin/collections/G;->c()Lkotlin/collections/A;

    .line 275
    .line 276
    .line 277
    move-result-object p1

    .line 278
    :goto_5
    iput-object p1, p0, Lm6/i;->i:Ljava/lang/Object;

    .line 279
    .line 280
    iget-object p1, p0, Lm6/i;->d:Lm6/e;

    .line 281
    .line 282
    if-eqz p1, :cond_f

    .line 283
    .line 284
    iget-object p2, p0, Lm6/i;->f:Lm6/s;

    .line 285
    .line 286
    if-eqz p2, :cond_e

    .line 287
    .line 288
    iget-boolean p5, p2, Lm6/s;->h:Z

    .line 289
    .line 290
    :cond_e
    new-instance p2, Lm6/f;

    .line 291
    .line 292
    invoke-direct {p2, p4, p0, v2}, Lm6/f;-><init>(Lkotlin/jvm/internal/B;Lm6/i;Lkotlin/coroutines/Continuation;)V

    .line 293
    .line 294
    .line 295
    invoke-virtual {p1, p5, p2}, Lm6/e;->a(ZLm6/f;)V

    .line 296
    .line 297
    .line 298
    :cond_f
    return-void
.end method

.method public static final a(Lm6/i;Ljava/io/File;Lcom/palmpay/lib/config/api/bean/ConfigRsp;)V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    if-eqz p1, :cond_1

    .line 3
    .line 4
    :try_start_0
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/io/File;->createNewFile()Z

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :catchall_0
    move-exception p1

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    :goto_0
    invoke-static {}, Lm6/j;->c()Lm6/j;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget-object v0, v0, Lm6/j;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, Lcom/google/gson/Gson;

    .line 23
    .line 24
    invoke-virtual {v0, p2}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p2

    .line 28
    const-string v0, "toJson(...)"

    .line 29
    .line 30
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-static {p1, p2}, LKf/m;->c(Ljava/io/File;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 34
    .line 35
    .line 36
    goto :goto_2

    .line 37
    :catch_0
    :try_start_1
    invoke-virtual {p1}, Ljava/io/File;->delete()Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 38
    .line 39
    .line 40
    goto :goto_2

    .line 41
    :catch_1
    :try_start_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 42
    .line 43
    goto :goto_2

    .line 44
    :goto_1
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 45
    throw p1

    .line 46
    :cond_1
    :goto_2
    monitor-exit p0

    .line 47
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/String;Ljava/util/List;)Lcom/palmpay/lib/config/api/bean/ConfigRsp;
    .locals 3

    .line 1
    new-instance v0, Lcom/palmpay/lib/config/api/bean/ConfigReq;

    .line 2
    .line 3
    iget-object v1, p0, Lm6/i;->f:Lm6/s;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    iget-object v1, v1, Lm6/s;->b:Ljava/lang/String;

    .line 8
    .line 9
    if-nez v1, :cond_1

    .line 10
    .line 11
    :cond_0
    const-string v1, "no_id"

    .line 12
    .line 13
    :cond_1
    iget-object v2, p0, Lm6/i;->a:Landroid/content/Context;

    .line 14
    .line 15
    invoke-direct {v0, v2, v1}, Lcom/palmpay/lib/config/api/bean/ConfigReq;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, v0, Lcom/palmpay/lib/config/api/bean/ConfigReq;->nebulaClientParam:Lcom/palmpay/lib/config/api/bean/ConfigReq$Extra;

    .line 19
    .line 20
    iput-object p1, v1, Lcom/palmpay/lib/config/api/bean/ConfigReq$Extra;->memberId:Ljava/lang/String;

    .line 21
    .line 22
    const/4 p1, 0x0

    .line 23
    if-eqz p2, :cond_3

    .line 24
    .line 25
    move-object v1, p2

    .line 26
    check-cast v1, Ljava/util/Collection;

    .line 27
    .line 28
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-nez v1, :cond_2

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_2
    move-object p2, p1

    .line 36
    :goto_0
    if-eqz p2, :cond_3

    .line 37
    .line 38
    new-instance v1, Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 41
    .line 42
    .line 43
    iput-object v1, v0, Lcom/palmpay/lib/config/api/bean/ConfigReq;->codes:Ljava/util/List;

    .line 44
    .line 45
    check-cast p2, Ljava/util/Collection;

    .line 46
    .line 47
    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 48
    .line 49
    .line 50
    :cond_3
    :try_start_0
    iget-object p2, p0, Lm6/i;->b:Ln6/c;

    .line 51
    .line 52
    if-eqz p2, :cond_4

    .line 53
    .line 54
    invoke-virtual {p2, v0}, Ln6/c;->a(Lcom/palmpay/lib/config/api/bean/ConfigReq;)Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 55
    .line 56
    .line 57
    move-result-object p2

    .line 58
    goto :goto_1

    .line 59
    :cond_4
    move-object p2, p1

    .line 60
    :goto_1
    if-eqz p2, :cond_5

    .line 61
    .line 62
    invoke-virtual {p2}, Lcom/palmpay/lib/config/api/bean/ConfigRsp;->isSuccess()Z

    .line 63
    .line 64
    .line 65
    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 66
    const/4 v1, 0x1

    .line 67
    if-ne v0, v1, :cond_5

    .line 68
    .line 69
    return-object p2

    .line 70
    :catch_0
    :cond_5
    return-object p1
.end method

.method public final declared-synchronized c(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    const-string v0, "key"

    .line 3
    .line 4
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lm6/i;->h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/palmpay/lib/config/api/bean/ConfigRsp;->getData()Ljava/util/HashMap;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    monitor-exit p0

    .line 26
    return-object v0

    .line 27
    :catchall_0
    move-exception p1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    :try_start_1
    iget-object v0, p0, Lm6/i;->i:Ljava/lang/Object;

    .line 30
    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    check-cast p1, Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 38
    .line 39
    if-eqz p1, :cond_1

    .line 40
    .line 41
    monitor-exit p0

    .line 42
    return-object p1

    .line 43
    :cond_1
    monitor-exit p0

    .line 44
    const/4 p1, 0x0

    .line 45
    return-object p1

    .line 46
    :goto_0
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 47
    throw p1
.end method
