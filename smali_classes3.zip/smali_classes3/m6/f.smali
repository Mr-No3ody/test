.class public final Lm6/f;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public a:Lkotlin/jvm/internal/B;

.field public b:I

.field public final synthetic c:Lkotlin/jvm/internal/B;

.field public final synthetic d:Lm6/i;


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/B;Lm6/i;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lm6/f;->c:Lkotlin/jvm/internal/B;

    .line 2
    .line 3
    iput-object p2, p0, Lm6/f;->d:Lm6/i;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1, p3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance v0, Lm6/f;

    .line 2
    .line 3
    iget-object v1, p0, Lm6/f;->c:Lkotlin/jvm/internal/B;

    .line 4
    .line 5
    iget-object v2, p0, Lm6/f;->d:Lm6/i;

    .line 6
    .line 7
    invoke-direct {v0, v1, v2, p1}, Lm6/f;-><init>(Lkotlin/jvm/internal/B;Lm6/i;Lkotlin/coroutines/Continuation;)V

    .line 8
    .line 9
    .line 10
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Lkotlin/coroutines/Continuation;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lm6/f;->create(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lm6/f;

    .line 8
    .line 9
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 10
    .line 11
    invoke-virtual {p1, v0}, Lm6/f;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, Lm6/f;->b:I

    .line 4
    .line 5
    iget-object v2, p0, Lm6/f;->d:Lm6/i;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    if-ne v1, v3, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Lm6/f;->a:Lkotlin/jvm/internal/B;

    .line 13
    .line 14
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception p1

    .line 19
    goto :goto_2

    .line 20
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 21
    .line 22
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 23
    .line 24
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    throw p1

    .line 28
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    new-instance p1, Lkotlin/jvm/internal/B;

    .line 32
    .line 33
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Lm6/f;->c:Lkotlin/jvm/internal/B;

    .line 37
    .line 38
    iget-boolean v1, v1, Lkotlin/jvm/internal/B;->a:Z

    .line 39
    .line 40
    iput-boolean v1, p1, Lkotlin/jvm/internal/B;->a:Z

    .line 41
    .line 42
    :try_start_1
    iget-object v1, v2, Lm6/i;->e:Ljava/lang/String;

    .line 43
    .line 44
    iput-object p1, p0, Lm6/f;->a:Lkotlin/jvm/internal/B;

    .line 45
    .line 46
    iput v3, p0, Lm6/f;->b:I

    .line 47
    .line 48
    const/4 v4, 0x0

    .line 49
    invoke-virtual {v2, v1, v4}, Lm6/i;->b(Ljava/lang/String;Ljava/util/List;)Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 50
    .line 51
    .line 52
    move-result-object v1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 53
    if-ne v1, v0, :cond_2

    .line 54
    .line 55
    return-object v0

    .line 56
    :cond_2
    move-object v0, p1

    .line 57
    move-object p1, v1

    .line 58
    :goto_0
    :try_start_2
    check-cast p1, Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 59
    .line 60
    if-eqz p1, :cond_3

    .line 61
    .line 62
    iput-object p1, v2, Lm6/i;->h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 63
    .line 64
    iget-object v1, v2, Lm6/i;->c:Ljava/io/File;

    .line 65
    .line 66
    invoke-static {v2, v1, p1}, Lm6/i;->a(Lm6/i;Ljava/io/File;Lcom/palmpay/lib/config/api/bean/ConfigRsp;)V

    .line 67
    .line 68
    .line 69
    iput-boolean v3, v0, Lkotlin/jvm/internal/B;->a:Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 70
    .line 71
    goto :goto_3

    .line 72
    :goto_1
    move-object v5, v0

    .line 73
    move-object v0, p1

    .line 74
    move-object p1, v5

    .line 75
    goto :goto_2

    .line 76
    :catch_1
    move-exception v0

    .line 77
    goto :goto_1

    .line 78
    :goto_2
    const-string v1, "Config"

    .line 79
    .line 80
    const-string v2, "Error while fetching config from server"

    .line 81
    .line 82
    invoke-static {v1, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 83
    .line 84
    .line 85
    :cond_3
    :goto_3
    iget-boolean p1, v0, Lkotlin/jvm/internal/B;->a:Z

    .line 86
    .line 87
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    return-object p1
.end method
