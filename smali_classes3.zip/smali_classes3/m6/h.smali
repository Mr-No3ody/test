.class public final Lm6/h;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lm6/i;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Ljava/util/List;


# direct methods
.method public constructor <init>(Lm6/i;Ljava/lang/String;Ljava/util/List;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lm6/h;->b:Lm6/i;

    .line 2
    .line 3
    iput-object p2, p0, Lm6/h;->c:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p3, p0, Lm6/h;->d:Ljava/util/List;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance p1, Lm6/h;

    .line 2
    .line 3
    iget-object v0, p0, Lm6/h;->c:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v1, p0, Lm6/h;->d:Ljava/util/List;

    .line 6
    .line 7
    iget-object v2, p0, Lm6/h;->b:Lm6/i;

    .line 8
    .line 9
    invoke-direct {p1, v2, v0, v1, p2}, Lm6/h;-><init>(Lm6/i;Ljava/lang/String;Ljava/util/List;Lkotlin/coroutines/Continuation;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lm6/h;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lm6/h;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lm6/h;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, Lm6/h;->a:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v1, :cond_1

    .line 8
    .line 9
    if-ne v1, v3, :cond_0

    .line 10
    .line 11
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 16
    .line 17
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 18
    .line 19
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    throw p1

    .line 23
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    iget-object p1, p0, Lm6/h;->b:Lm6/i;

    .line 27
    .line 28
    iget-object p1, p1, Lm6/i;->d:Lm6/e;

    .line 29
    .line 30
    if-nez p1, :cond_2

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_2
    invoke-virtual {p1}, Lm6/e;->b()V

    .line 34
    .line 35
    .line 36
    iget-object p1, p0, Lm6/h;->b:Lm6/i;

    .line 37
    .line 38
    iget-object v1, p0, Lm6/h;->c:Ljava/lang/String;

    .line 39
    .line 40
    iget-object v4, p0, Lm6/h;->d:Ljava/util/List;

    .line 41
    .line 42
    iput v3, p0, Lm6/h;->a:I

    .line 43
    .line 44
    invoke-virtual {p1, v1, v4}, Lm6/i;->b(Ljava/lang/String;Ljava/util/List;)Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    if-ne p1, v0, :cond_3

    .line 49
    .line 50
    return-object v0

    .line 51
    :cond_3
    :goto_0
    check-cast p1, Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 52
    .line 53
    if-nez p1, :cond_4

    .line 54
    .line 55
    :goto_1
    return-object v2

    .line 56
    :cond_4
    iget-object v0, p0, Lm6/h;->b:Lm6/i;

    .line 57
    .line 58
    iget-object v1, p0, Lm6/h;->d:Ljava/util/List;

    .line 59
    .line 60
    monitor-enter v0

    .line 61
    :try_start_0
    check-cast v1, Ljava/util/Collection;

    .line 62
    .line 63
    if-eqz v1, :cond_8

    .line 64
    .line 65
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    if-eqz v1, :cond_5

    .line 70
    .line 71
    goto :goto_4

    .line 72
    :cond_5
    invoke-virtual {p1}, Lcom/palmpay/lib/config/api/bean/ConfigRsp;->getData()Ljava/util/HashMap;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    if-eqz p1, :cond_6

    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_6
    invoke-static {}, Lkotlin/collections/G;->c()Lkotlin/collections/A;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    :goto_2
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    :cond_7
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 92
    .line 93
    .line 94
    move-result v4

    .line 95
    if-eqz v4, :cond_9

    .line 96
    .line 97
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    check-cast v4, Ljava/lang/String;

    .line 102
    .line 103
    iget-object v5, v0, Lm6/i;->h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 104
    .line 105
    if-eqz v5, :cond_7

    .line 106
    .line 107
    invoke-virtual {v5}, Lcom/palmpay/lib/config/api/bean/ConfigRsp;->getData()Ljava/util/HashMap;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    if-eqz v5, :cond_7

    .line 112
    .line 113
    invoke-interface {p1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v6

    .line 117
    invoke-virtual {v5, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v4

    .line 121
    check-cast v4, Ljava/lang/String;

    .line 122
    .line 123
    goto :goto_3

    .line 124
    :catchall_0
    move-exception p1

    .line 125
    goto :goto_6

    .line 126
    :cond_8
    :goto_4
    iput-object p1, v0, Lm6/i;->h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 127
    .line 128
    :cond_9
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 129
    .line 130
    monitor-exit v0

    .line 131
    iget-object p1, p0, Lm6/h;->b:Lm6/i;

    .line 132
    .line 133
    iget-object v0, p1, Lm6/i;->c:Ljava/io/File;

    .line 134
    .line 135
    iget-object v1, p1, Lm6/i;->h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 136
    .line 137
    invoke-static {p1, v0, v1}, Lm6/i;->a(Lm6/i;Ljava/io/File;Lcom/palmpay/lib/config/api/bean/ConfigRsp;)V

    .line 138
    .line 139
    .line 140
    iget-object p1, p0, Lm6/h;->b:Lm6/i;

    .line 141
    .line 142
    iget-object p1, p1, Lm6/i;->d:Lm6/e;

    .line 143
    .line 144
    if-eqz p1, :cond_d

    .line 145
    .line 146
    monitor-enter p1

    .line 147
    :try_start_1
    iget-object v0, p1, Lm6/e;->g:Lm6/f;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 148
    .line 149
    if-nez v0, :cond_a

    .line 150
    .line 151
    monitor-exit p1

    .line 152
    goto :goto_5

    .line 153
    :cond_a
    :try_start_2
    iget-object v1, p1, Lm6/e;->e:LWf/t0;

    .line 154
    .line 155
    if-eqz v1, :cond_b

    .line 156
    .line 157
    invoke-virtual {v1}, LWf/n0;->isActive()Z

    .line 158
    .line 159
    .line 160
    move-result v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 161
    if-ne v1, v3, :cond_b

    .line 162
    .line 163
    monitor-exit p1

    .line 164
    goto :goto_5

    .line 165
    :cond_b
    :try_start_3
    iget-object v1, p1, Lm6/e;->f:LWf/t0;

    .line 166
    .line 167
    if-eqz v1, :cond_c

    .line 168
    .line 169
    invoke-virtual {v1}, LWf/n0;->isActive()Z

    .line 170
    .line 171
    .line 172
    move-result v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 173
    if-ne v1, v3, :cond_c

    .line 174
    .line 175
    monitor-exit p1

    .line 176
    goto :goto_5

    .line 177
    :cond_c
    :try_start_4
    iget-object v1, p1, Lm6/e;->a:Lag/c;

    .line 178
    .line 179
    iget-object v3, p1, Lm6/e;->b:LWf/s;

    .line 180
    .line 181
    new-instance v4, Lm6/b;

    .line 182
    .line 183
    invoke-direct {v4, p1, v0, v2}, Lm6/b;-><init>(Lm6/e;Lm6/f;Lkotlin/coroutines/Continuation;)V

    .line 184
    .line 185
    .line 186
    const/4 v0, 0x2

    .line 187
    invoke-static {v1, v3, v2, v4, v0}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    iput-object v0, p1, Lm6/e;->f:LWf/t0;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 192
    .line 193
    monitor-exit p1

    .line 194
    goto :goto_5

    .line 195
    :catchall_1
    move-exception v0

    .line 196
    :try_start_5
    monitor-exit p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 197
    throw v0

    .line 198
    :cond_d
    :goto_5
    iget-object p1, p0, Lm6/h;->b:Lm6/i;

    .line 199
    .line 200
    iget-object p1, p1, Lm6/i;->h:Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 201
    .line 202
    return-object p1

    .line 203
    :goto_6
    monitor-exit v0

    .line 204
    throw p1
.end method
