.class public final Lm6/s;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:J

.field public final b:Ljava/lang/String;

.field public final c:I

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/String;

.field public final f:I

.field public final g:Ljava/lang/String;

.field public final h:Z


# direct methods
.method public constructor <init>(Lm6/r;)V
    .locals 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "NG"

    .line 5
    .line 6
    iput-object v0, p0, Lm6/s;->e:Ljava/lang/String;

    .line 7
    .line 8
    iget-object v0, p1, Lm6/r;->b:Ljava/lang/String;

    .line 9
    .line 10
    iput-object v0, p0, Lm6/s;->b:Ljava/lang/String;

    .line 11
    .line 12
    iget v0, p1, Lm6/r;->c:I

    .line 13
    .line 14
    iput v0, p0, Lm6/s;->c:I

    .line 15
    .line 16
    const/4 v1, 0x4

    .line 17
    if-eq v0, v1, :cond_4

    .line 18
    .line 19
    const/4 v1, 0x3

    .line 20
    if-ne v1, v0, :cond_0

    .line 21
    .line 22
    goto :goto_1

    .line 23
    :cond_0
    if-eqz v0, :cond_3

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    if-ne v0, v1, :cond_1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_1
    iget-wide v0, p1, Lm6/r;->a:J

    .line 30
    .line 31
    sget-object v2, Ljava/util/concurrent/TimeUnit;->HOURS:Ljava/util/concurrent/TimeUnit;

    .line 32
    .line 33
    const-wide/16 v3, 0x1

    .line 34
    .line 35
    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    .line 36
    .line 37
    .line 38
    move-result-wide v5

    .line 39
    cmp-long v0, v0, v5

    .line 40
    .line 41
    if-gez v0, :cond_2

    .line 42
    .line 43
    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    .line 44
    .line 45
    .line 46
    move-result-wide v0

    .line 47
    goto :goto_2

    .line 48
    :cond_2
    iget-wide v0, p1, Lm6/r;->a:J

    .line 49
    .line 50
    goto :goto_2

    .line 51
    :cond_3
    :goto_0
    iget-wide v0, p1, Lm6/r;->a:J

    .line 52
    .line 53
    const-wide/16 v2, 0x1e

    .line 54
    .line 55
    cmp-long v4, v0, v2

    .line 56
    .line 57
    if-gez v4, :cond_6

    .line 58
    .line 59
    move-wide v0, v2

    .line 60
    goto :goto_2

    .line 61
    :cond_4
    :goto_1
    iget-wide v0, p1, Lm6/r;->a:J

    .line 62
    .line 63
    sget-object v2, Ljava/util/concurrent/TimeUnit;->HOURS:Ljava/util/concurrent/TimeUnit;

    .line 64
    .line 65
    const-wide/16 v3, 0x8

    .line 66
    .line 67
    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    .line 68
    .line 69
    .line 70
    move-result-wide v5

    .line 71
    cmp-long v0, v0, v5

    .line 72
    .line 73
    if-gez v0, :cond_5

    .line 74
    .line 75
    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    .line 76
    .line 77
    .line 78
    move-result-wide v0

    .line 79
    goto :goto_2

    .line 80
    :cond_5
    iget-wide v0, p1, Lm6/r;->a:J

    .line 81
    .line 82
    :cond_6
    :goto_2
    iput-wide v0, p0, Lm6/s;->a:J

    .line 83
    .line 84
    iget-object v0, p1, Lm6/r;->d:Ljava/lang/String;

    .line 85
    .line 86
    iput-object v0, p0, Lm6/s;->d:Ljava/lang/String;

    .line 87
    .line 88
    iget-object v0, p1, Lm6/r;->e:Ljava/lang/String;

    .line 89
    .line 90
    iput-object v0, p0, Lm6/s;->e:Ljava/lang/String;

    .line 91
    .line 92
    iget v0, p1, Lm6/r;->f:I

    .line 93
    .line 94
    iput v0, p0, Lm6/s;->f:I

    .line 95
    .line 96
    iget-object v0, p1, Lm6/r;->g:Ljava/lang/String;

    .line 97
    .line 98
    iput-object v0, p0, Lm6/s;->g:Ljava/lang/String;

    .line 99
    .line 100
    iget-boolean p1, p1, Lm6/r;->h:Z

    .line 101
    .line 102
    iput-boolean p1, p0, Lm6/s;->h:Z

    .line 103
    .line 104
    return-void
.end method
