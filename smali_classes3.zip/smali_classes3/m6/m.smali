.class public final Lm6/m;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lm6/m;-><init>()V

    return-void
.end method

.method private final checkInitialized()V
    .locals 2

    .line 1
    sget-boolean v0, Lm6/n;->c:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    sget-object v0, Lm6/n;->b:Lm6/n;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 11
    .line 12
    const-string v1, "PalmPayRemoteConfig is not initialized. Call PalmPayRemoteConfig.init(context, remoteConfigSettings) first."

    .line 13
    .line 14
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    throw v0
.end method

.method private final declared-synchronized init(Lm6/i;Lm6/s;)V
    .locals 1

    monitor-enter p0

    .line 45
    :try_start_0
    new-instance v0, Lm6/q;

    .line 46
    iget-object p2, p2, Lm6/s;->g:Ljava/lang/String;

    .line 47
    invoke-direct {v0, p1, p2}, Lm6/q;-><init>(Lm6/i;Ljava/lang/String;)V

    .line 48
    sput-object v0, Lm6/n;->b:Lm6/n;

    const/4 p1, 0x1

    .line 49
    sput-boolean p1, Lm6/n;->c:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 50
    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method


# virtual methods
.method public final init(Landroid/content/Context;Lm6/s;)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # Lm6/s;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "remoteConfigSettings"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a

    .line 2
    iget-object v0, p2, Lm6/s;->e:Ljava/lang/String;

    .line 3
    iget v1, p2, Lm6/s;->c:I

    const-string v2, "pk"

    if-eqz v1, :cond_7

    const/4 v3, 0x1

    if-eq v1, v3, :cond_5

    const/4 v3, 0x2

    if-eq v1, v3, :cond_3

    const/4 v3, 0x3

    if-eq v1, v3, :cond_1

    .line 4
    invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 5
    const-string v0, "https://api.palmpay.pk"

    goto :goto_0

    :cond_0
    const-string v0, "https://nebula-prod.palmpay-inc.com"

    goto :goto_0

    .line 6
    :cond_1
    invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 7
    const-string v0, "https://api-pre.palmpay.pk"

    goto :goto_0

    :cond_2
    const-string v0, "https://nebula-pre.palmpay-inc.com"

    goto :goto_0

    .line 8
    :cond_3
    invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 9
    const-string v0, "https://api-sit.palmpay.pk"

    goto :goto_0

    :cond_4
    const-string v0, "https://nebula-gray.palmpay-inc.com"

    goto :goto_0

    .line 10
    :cond_5
    invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 11
    const-string v0, "https://api-daily.palmpay.pk"

    goto :goto_0

    :cond_6
    const-string v0, "https://nebula-daily.palmpay-inc.com"

    goto :goto_0

    .line 12
    :cond_7
    invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 13
    const-string v0, "https://api-dev.palmpay.pk"

    goto :goto_0

    :cond_8
    const-string v0, "https://nebula-dev.palmpay-inc.com"

    .line 14
    :goto_0
    new-instance v1, LO2/a;

    iget v2, p2, Lm6/s;->c:I

    .line 15
    const-string v3, "context"

    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "baseUrl"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "remoteConfigSettings"

    invoke-static {p2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    .line 17
    iput-object v3, v1, LO2/a;->a:Ljava/lang/Object;

    .line 18
    iput-object v3, v1, LO2/a;->b:Ljava/lang/Object;

    .line 19
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v4, "android_id"

    invoke-static {v3, v4}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 20
    iput-object v3, v1, LO2/a;->a:Ljava/lang/Object;

    .line 21
    invoke-static {p1}, Lm6/k;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v1, LO2/a;->b:Ljava/lang/Object;

    .line 22
    new-instance v3, Lokhttp3/S;

    invoke-direct {v3}, Lokhttp3/S;-><init>()V

    .line 23
    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v5, 0x14

    invoke-virtual {v3, v5, v6, v4}, Lokhttp3/S;->b(JLjava/util/concurrent/TimeUnit;)V

    .line 24
    invoke-virtual {v3, v5, v6, v4}, Lokhttp3/S;->e(JLjava/util/concurrent/TimeUnit;)V

    .line 25
    new-instance v4, Ln6/a;

    invoke-direct {v4, v1, p2}, Ln6/a;-><init>(LO2/a;Lm6/s;)V

    invoke-virtual {v3, v4}, Lokhttp3/S;->a(Lokhttp3/Interceptor;)V

    .line 26
    new-instance v4, LOg/b;

    new-instance v5, Lm8/b;

    const/4 v6, 0x1

    invoke-direct {v5, v6}, Lm8/b;-><init>(I)V

    invoke-direct {v4, v5}, LOg/b;-><init>(Lokhttp3/logging/HttpLoggingInterceptor$Logger;)V

    const/4 v5, 0x4

    if-ne v2, v5, :cond_9

    .line 27
    sget-object v2, LOg/a;->a:LOg/a;

    goto :goto_1

    :cond_9
    sget-object v2, LOg/a;->d:LOg/a;

    .line 28
    :goto_1
    const-string v5, "level"

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    iput-object v2, v4, LOg/b;->c:LOg/a;

    .line 30
    invoke-virtual {v3, v4}, Lokhttp3/S;->a(Lokhttp3/Interceptor;)V

    .line 31
    new-instance v2, Lokhttp3/U;

    invoke-direct {v2, v3}, Lokhttp3/U;-><init>(Lokhttp3/S;)V

    .line 32
    iput-object v2, v1, LO2/a;->c:Ljava/lang/Object;

    .line 33
    :try_start_0
    sget-object v2, Lokhttp3/J;->k:Lokhttp3/I;

    invoke-virtual {v2, v0}, Lokhttp3/I;->get(Ljava/lang/String;)Lokhttp3/J;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    iput-object v0, v1, LO2/a;->d:Ljava/lang/Object;

    .line 35
    new-instance v4, Ln6/c;

    invoke-direct {v4, v1, p1}, Ln6/c;-><init>(LO2/a;Landroid/content/Context;)V

    .line 36
    new-instance v2, Lm6/i;

    .line 37
    new-instance v6, Lm6/e;

    iget-wide v0, p2, Lm6/s;->a:J

    invoke-direct {v6, p1, v0, v1}, Lm6/e;-><init>(Landroid/content/Context;J)V

    const/16 v8, 0x54

    const/4 v5, 0x0

    move-object v3, p1

    move-object v7, p2

    .line 38
    invoke-direct/range {v2 .. v8}, Lm6/i;-><init>(Landroid/content/Context;Ln6/c;Ljava/io/File;Lm6/e;Lm6/s;I)V

    .line 39
    invoke-direct {p0, v2, v7}, Lm6/m;->init(Lm6/i;Lm6/s;)V

    return-void

    :catch_0
    move-exception v0

    move-object p1, v0

    .line 40
    new-instance p2, Lgg/c;

    .line 41
    const-string v0, "exception"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    const-string v0, "An invalid URL was provided for the Remote Config base url."

    invoke-direct {p2, v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 43
    throw p2

    .line 44
    :cond_a
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "PalmPayRemoteConfig.init() must NOT be called on the main thread."

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final instance()Lm6/n;
    .locals 1
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    sget-object v0, Lm6/n;->d:Landroid/content/Context;

    .line 2
    invoke-virtual {p0, v0}, Lm6/m;->instance(Landroid/content/Context;)Lm6/n;

    move-result-object v0

    return-object v0
.end method

.method public final instance(Landroid/content/Context;)Lm6/n;
    .locals 1
    .param p1    # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    if-nez p1, :cond_1

    .line 3
    invoke-direct {p0}, Lm6/m;->checkInitialized()V

    .line 4
    sget-object p1, Lm6/n;->b:Lm6/n;

    if-eqz p1, :cond_0

    return-object p1

    .line 5
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Required value was null."

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 6
    :cond_1
    sget-object v0, Lm6/n;->b:Lm6/n;

    if-nez v0, :cond_2

    .line 7
    new-instance v0, Lm6/l;

    invoke-direct {v0, p1}, Lm6/l;-><init>(Landroid/content/Context;)V

    .line 8
    sput-object v0, Lm6/n;->b:Lm6/n;

    .line 9
    :cond_2
    sget-object p1, Lm6/n;->b:Lm6/n;

    .line 10
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    return-object p1
.end method

.method public final isInitialized()Z
    .locals 1
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    sget-boolean v0, Lm6/n;->c:Z

    .line 2
    .line 3
    return v0
.end method

.method public final setContext(Landroid/content/Context;)V
    .locals 0
    .param p1    # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const/4 p1, 0x0

    .line 9
    :goto_0
    sput-object p1, Lm6/n;->d:Landroid/content/Context;

    .line 10
    .line 11
    return-void
.end method
