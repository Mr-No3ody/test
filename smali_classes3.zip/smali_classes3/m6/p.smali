.class public final Lm6/p;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lm6/q;

.field public final synthetic c:Ljava/util/List;

.field public final synthetic d:Ljava/lang/ref/WeakReference;


# direct methods
.method public constructor <init>(Lm6/q;Ljava/util/List;Ljava/lang/ref/WeakReference;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lm6/p;->b:Lm6/q;

    .line 2
    .line 3
    iput-object p2, p0, Lm6/p;->c:Ljava/util/List;

    .line 4
    .line 5
    iput-object p3, p0, Lm6/p;->d:Ljava/lang/ref/WeakReference;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance p1, Lm6/p;

    .line 2
    .line 3
    iget-object v0, p0, Lm6/p;->c:Ljava/util/List;

    .line 4
    .line 5
    iget-object v1, p0, Lm6/p;->d:Ljava/lang/ref/WeakReference;

    .line 6
    .line 7
    iget-object v2, p0, Lm6/p;->b:Lm6/q;

    .line 8
    .line 9
    invoke-direct {p1, v2, v0, v1, p2}, Lm6/p;-><init>(Lm6/q;Ljava/util/List;Ljava/lang/ref/WeakReference;Lkotlin/coroutines/Continuation;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lm6/p;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lm6/p;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lm6/p;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, Lm6/p;->a:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object p1, p0, Lm6/p;->b:Lm6/q;

    .line 26
    .line 27
    iget-object v1, p1, Lm6/q;->e:Lm6/i;

    .line 28
    .line 29
    iget-object p1, p1, Lm6/q;->f:Ljava/lang/String;

    .line 30
    .line 31
    iput v2, p0, Lm6/p;->a:I

    .line 32
    .line 33
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    new-instance v3, Lm6/h;

    .line 37
    .line 38
    const/4 v4, 0x0

    .line 39
    iget-object v5, p0, Lm6/p;->c:Ljava/util/List;

    .line 40
    .line 41
    invoke-direct {v3, v1, p1, v5, v4}, Lm6/h;-><init>(Lm6/i;Ljava/lang/String;Ljava/util/List;Lkotlin/coroutines/Continuation;)V

    .line 42
    .line 43
    .line 44
    iget-object p1, v1, Lm6/i;->g:LWf/s;

    .line 45
    .line 46
    invoke-static {p1, v3, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    if-ne p1, v0, :cond_2

    .line 51
    .line 52
    return-object v0

    .line 53
    :cond_2
    :goto_0
    check-cast p1, Lcom/palmpay/lib/config/api/bean/ConfigRsp;

    .line 54
    .line 55
    iget-object v0, p0, Lm6/p;->d:Ljava/lang/ref/WeakReference;

    .line 56
    .line 57
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    check-cast v0, Lcom/palmpay/lib/config/OnFetchResultListener;

    .line 62
    .line 63
    if-eqz v0, :cond_4

    .line 64
    .line 65
    if-eqz p1, :cond_3

    .line 66
    .line 67
    goto :goto_1

    .line 68
    :cond_3
    const/4 v2, 0x0

    .line 69
    :goto_1
    invoke-interface {v0, v2}, Lcom/palmpay/lib/config/OnFetchResultListener;->onComplete(Z)V

    .line 70
    .line 71
    .line 72
    :cond_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 73
    .line 74
    return-object p1
.end method
