.class public final Lm6/c;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:J

.field public b:I

.field public synthetic c:Ljava/lang/Object;

.field public final synthetic d:Lkotlin/jvm/internal/E;

.field public final synthetic e:Lm6/f;

.field public final synthetic f:Lm6/e;


# direct methods
.method public constructor <init>(Lkotlin/jvm/internal/E;Lm6/f;Lm6/e;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lm6/c;->d:Lkotlin/jvm/internal/E;

    .line 2
    .line 3
    iput-object p2, p0, Lm6/c;->e:Lm6/f;

    .line 4
    .line 5
    iput-object p3, p0, Lm6/c;->f:Lm6/e;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 4

    .line 1
    new-instance v0, Lm6/c;

    .line 2
    .line 3
    iget-object v1, p0, Lm6/c;->d:Lkotlin/jvm/internal/E;

    .line 4
    .line 5
    iget-object v2, p0, Lm6/c;->e:Lm6/f;

    .line 6
    .line 7
    iget-object v3, p0, Lm6/c;->f:Lm6/e;

    .line 8
    .line 9
    invoke-direct {v0, v1, v2, v3, p2}, Lm6/c;-><init>(Lkotlin/jvm/internal/E;Lm6/f;Lm6/e;Lkotlin/coroutines/Continuation;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lm6/c;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lm6/c;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lm6/c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget-object v1, LEf/a;->a:LEf/a;

    .line 4
    .line 5
    iget v2, v0, Lm6/c;->b:I

    .line 6
    .line 7
    iget-object v3, v0, Lm6/c;->d:Lkotlin/jvm/internal/E;

    .line 8
    .line 9
    const/4 v4, 0x4

    .line 10
    const/4 v5, 0x3

    .line 11
    const/4 v6, 0x1

    .line 12
    const/4 v7, 0x2

    .line 13
    iget-object v8, v0, Lm6/c;->f:Lm6/e;

    .line 14
    .line 15
    if-eqz v2, :cond_4

    .line 16
    .line 17
    if-eq v2, v6, :cond_3

    .line 18
    .line 19
    if-eq v2, v7, :cond_2

    .line 20
    .line 21
    if-eq v2, v5, :cond_1

    .line 22
    .line 23
    if-ne v2, v4, :cond_0

    .line 24
    .line 25
    iget-wide v9, v0, Lm6/c;->a:J

    .line 26
    .line 27
    iget-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v2, Lkotlinx/coroutines/CoroutineScope;

    .line 30
    .line 31
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    goto/16 :goto_6

    .line 35
    .line 36
    :cond_0
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 37
    .line 38
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 39
    .line 40
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    throw v1

    .line 44
    :cond_1
    iget-wide v9, v0, Lm6/c;->a:J

    .line 45
    .line 46
    iget-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v2, Lkotlinx/coroutines/CoroutineScope;

    .line 49
    .line 50
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_2
    iget-wide v9, v0, Lm6/c;->a:J

    .line 55
    .line 56
    iget-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v2, Lkotlinx/coroutines/CoroutineScope;

    .line 59
    .line 60
    :try_start_0
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 61
    .line 62
    .line 63
    move-object/from16 v11, p1

    .line 64
    .line 65
    goto :goto_2

    .line 66
    :cond_3
    iget-wide v9, v0, Lm6/c;->a:J

    .line 67
    .line 68
    iget-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast v2, Lkotlinx/coroutines/CoroutineScope;

    .line 71
    .line 72
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_4
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    iget-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v2, Lkotlinx/coroutines/CoroutineScope;

    .line 82
    .line 83
    sget-wide v9, Lm6/e;->h:J

    .line 84
    .line 85
    :cond_5
    :goto_0
    invoke-static {v2}, LWf/v;->e(Lkotlinx/coroutines/CoroutineScope;)Z

    .line 86
    .line 87
    .line 88
    move-result v11

    .line 89
    if-eqz v11, :cond_f

    .line 90
    .line 91
    iget-wide v11, v3, Lkotlin/jvm/internal/E;->a:J

    .line 92
    .line 93
    const-wide/16 v13, 0x2710

    .line 94
    .line 95
    cmp-long v13, v11, v13

    .line 96
    .line 97
    if-lez v13, :cond_7

    .line 98
    .line 99
    iput-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 100
    .line 101
    iput-wide v9, v0, Lm6/c;->a:J

    .line 102
    .line 103
    iput v6, v0, Lm6/c;->b:I

    .line 104
    .line 105
    invoke-static {v11, v12, v0}, LWf/D;->b(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v11

    .line 109
    if-ne v11, v1, :cond_6

    .line 110
    .line 111
    goto :goto_5

    .line 112
    :cond_6
    :goto_1
    const-wide/16 v11, 0x0

    .line 113
    .line 114
    iput-wide v11, v3, Lkotlin/jvm/internal/E;->a:J

    .line 115
    .line 116
    goto :goto_0

    .line 117
    :cond_7
    :try_start_1
    iget-object v11, v0, Lm6/c;->e:Lm6/f;

    .line 118
    .line 119
    iput-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 120
    .line 121
    iput-wide v9, v0, Lm6/c;->a:J

    .line 122
    .line 123
    iput v7, v0, Lm6/c;->b:I

    .line 124
    .line 125
    invoke-virtual {v11, v0}, Lm6/f;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v11

    .line 129
    if-ne v11, v1, :cond_8

    .line 130
    .line 131
    goto :goto_5

    .line 132
    :cond_8
    :goto_2
    check-cast v11, Ljava/lang/Boolean;

    .line 133
    .line 134
    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    .line 135
    .line 136
    .line 137
    move-result v11
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 138
    goto :goto_3

    .line 139
    :catchall_0
    const/4 v11, 0x0

    .line 140
    :goto_3
    if-eqz v11, :cond_b

    .line 141
    .line 142
    iget-object v9, v8, Lm6/e;->d:Landroid/content/Context;

    .line 143
    .line 144
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 145
    .line 146
    .line 147
    move-result-wide v10

    .line 148
    const-string v12, "PalmPayRemoteConfig"

    .line 149
    .line 150
    sget-object v13, Lm6/k;->a:Lcom/tencent/mmkv/MMKV;

    .line 151
    .line 152
    if-nez v13, :cond_9

    .line 153
    .line 154
    :try_start_2
    invoke-static {v12}, Lcom/tencent/mmkv/MMKV;->o(Ljava/lang/String;)Lcom/tencent/mmkv/MMKV;

    .line 155
    .line 156
    .line 157
    move-result-object v13

    .line 158
    sput-object v13, Lm6/k;->a:Lcom/tencent/mmkv/MMKV;
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_0

    .line 159
    .line 160
    goto :goto_4

    .line 161
    :catch_0
    invoke-static {v9}, Lcom/tencent/mmkv/MMKV;->m(Landroid/content/Context;)V

    .line 162
    .line 163
    .line 164
    invoke-static {v12}, Lcom/tencent/mmkv/MMKV;->o(Ljava/lang/String;)Lcom/tencent/mmkv/MMKV;

    .line 165
    .line 166
    .line 167
    move-result-object v9

    .line 168
    sput-object v9, Lm6/k;->a:Lcom/tencent/mmkv/MMKV;

    .line 169
    .line 170
    :cond_9
    :goto_4
    sget-object v9, Lm6/k;->a:Lcom/tencent/mmkv/MMKV;

    .line 171
    .line 172
    if-eqz v9, :cond_a

    .line 173
    .line 174
    const-string v12, "_lats_poll_time"

    .line 175
    .line 176
    invoke-virtual {v9, v12, v10, v11}, Lcom/tencent/mmkv/MMKV;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 177
    .line 178
    .line 179
    :cond_a
    sget-wide v9, Lm6/e;->h:J

    .line 180
    .line 181
    iput-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 182
    .line 183
    iput-wide v9, v0, Lm6/c;->a:J

    .line 184
    .line 185
    iput v5, v0, Lm6/c;->b:I

    .line 186
    .line 187
    iget-wide v11, v8, Lm6/e;->c:J

    .line 188
    .line 189
    invoke-static {v11, v12, v0}, LWf/D;->b(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v11

    .line 193
    if-ne v11, v1, :cond_5

    .line 194
    .line 195
    goto :goto_5

    .line 196
    :cond_b
    iget-wide v11, v8, Lm6/e;->c:J

    .line 197
    .line 198
    invoke-static {v9, v10, v11, v12}, Ljava/lang/Math;->min(JJ)J

    .line 199
    .line 200
    .line 201
    move-result-wide v11

    .line 202
    iput-object v2, v0, Lm6/c;->c:Ljava/lang/Object;

    .line 203
    .line 204
    iput-wide v9, v0, Lm6/c;->a:J

    .line 205
    .line 206
    iput v4, v0, Lm6/c;->b:I

    .line 207
    .line 208
    invoke-static {v11, v12, v0}, LWf/D;->b(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v11

    .line 212
    if-ne v11, v1, :cond_c

    .line 213
    .line 214
    :goto_5
    return-object v1

    .line 215
    :cond_c
    :goto_6
    iget-wide v11, v8, Lm6/e;->c:J

    .line 216
    .line 217
    cmp-long v13, v9, v11

    .line 218
    .line 219
    if-ltz v13, :cond_d

    .line 220
    .line 221
    move-wide v9, v11

    .line 222
    goto/16 :goto_0

    .line 223
    .line 224
    :cond_d
    int-to-long v13, v7

    .line 225
    div-long v15, v11, v13

    .line 226
    .line 227
    cmp-long v15, v9, v15

    .line 228
    .line 229
    if-lez v15, :cond_e

    .line 230
    .line 231
    move-wide v9, v11

    .line 232
    goto :goto_7

    .line 233
    :cond_e
    mul-long/2addr v9, v13

    .line 234
    :goto_7
    invoke-static {v9, v10, v11, v12}, Ljava/lang/Math;->min(JJ)J

    .line 235
    .line 236
    .line 237
    move-result-wide v9

    .line 238
    goto/16 :goto_0

    .line 239
    .line 240
    :cond_f
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 241
    .line 242
    return-object v1
.end method
