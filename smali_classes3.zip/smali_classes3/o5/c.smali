.class public final Lo5/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:LG6/b;

.field public final c:Landroid/content/SharedPreferences;

.field public final d:LGb/f;

.field public final e:LE2/a;

.field public final f:J

.field public final g:J

.field public final h:I

.field public final i:I

.field public j:I

.field public final k:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroid/content/Context;LG6/b;JJII)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lo5/c;->j:I

    .line 6
    .line 7
    new-instance v1, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v1, p0, Lo5/c;->k:Ljava/util/ArrayList;

    .line 13
    .line 14
    iput-object p1, p0, Lo5/c;->a:Landroid/content/Context;

    .line 15
    .line 16
    const-wide/32 v1, 0x100000

    .line 17
    .line 18
    .line 19
    mul-long/2addr p5, v1

    .line 20
    iput-wide p5, p0, Lo5/c;->g:J

    .line 21
    .line 22
    const-wide/16 p5, 0x3e8

    .line 23
    .line 24
    mul-long/2addr p3, p5

    .line 25
    iput-wide p3, p0, Lo5/c;->f:J

    .line 26
    .line 27
    const/4 p3, 0x1

    .line 28
    invoke-static {p3, p7}, Ljava/lang/Math;->max(II)I

    .line 29
    .line 30
    .line 31
    move-result p4

    .line 32
    iput p4, p0, Lo5/c;->h:I

    .line 33
    .line 34
    invoke-static {p3, p8}, Ljava/lang/Math;->max(II)I

    .line 35
    .line 36
    .line 37
    move-result p3

    .line 38
    iput p3, p0, Lo5/c;->i:I

    .line 39
    .line 40
    iput-object p2, p0, Lo5/c;->b:LG6/b;

    .line 41
    .line 42
    new-instance p2, LE2/a;

    .line 43
    .line 44
    const-class p3, Lo5/c;

    .line 45
    .line 46
    invoke-virtual {p3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p4

    .line 50
    invoke-direct {p2, p1, p4}, LE2/a;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    iput-object p2, p0, Lo5/c;->e:LE2/a;

    .line 54
    .line 55
    const-string p2, "growing3_sender"

    .line 56
    .line 57
    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    iput-object p1, p0, Lo5/c;->c:Landroid/content/SharedPreferences;

    .line 62
    .line 63
    new-instance p1, Lcom/didiglobal/booster/instrument/ShadowHandlerThread;

    .line 64
    .line 65
    invoke-virtual {p3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p2

    .line 69
    const-string/jumbo p3, "\u200bcom.growingio.android.sdk.track.middleware.EventSender"

    .line 70
    .line 71
    .line 72
    invoke-direct {p1, p2, p3}, Lcom/didiglobal/booster/instrument/ShadowHandlerThread;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-static {p1, p3}, Lcom/didiglobal/booster/instrument/ShadowThread;->setThreadName(Ljava/lang/Thread;Ljava/lang/String;)Ljava/lang/Thread;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    .line 80
    .line 81
    .line 82
    new-instance p2, LGb/f;

    .line 83
    .line 84
    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    invoke-direct {p2, p0, p1}, LGb/f;-><init>(Lo5/c;Landroid/os/Looper;)V

    .line 89
    .line 90
    .line 91
    iput-object p2, p0, Lo5/c;->d:LGb/f;

    .line 92
    .line 93
    return-void
.end method

.method public static a(Lo5/a;)Lo5/b;
    .locals 2

    .line 1
    invoke-static {}, Lcom/growingio/android/sdk/d;->a()Lcom/growingio/android/sdk/d;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Lcom/growingio/android/sdk/d;->a:Lq5/c;

    .line 6
    .line 7
    const-class v1, Lo5/a;

    .line 8
    .line 9
    invoke-virtual {v0, v1}, Lq5/c;->a(Ljava/lang/Class;)Lcom/growingio/android/sdk/track/modelloader/ModelLoader;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    const/4 p0, 0x0

    .line 16
    new-array p0, p0, [Ljava/lang/Object;

    .line 17
    .line 18
    const-string v0, "EventSender"

    .line 19
    .line 20
    const-string v1, "please register database component first"

    .line 21
    .line 22
    invoke-static {v0, v1, p0}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    new-instance p0, Lo5/b;

    .line 26
    .line 27
    invoke-direct {p0}, Lo5/b;-><init>()V

    .line 28
    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_0
    invoke-interface {v0, p0}, Lcom/growingio/android/sdk/track/modelloader/ModelLoader;->buildLoadData(Ljava/lang/Object;)Lq5/a;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    iget-object p0, p0, Lq5/a;->a:Lcom/growingio/android/sdk/track/modelloader/DataFetcher;

    .line 36
    .line 37
    invoke-interface {p0}, Lcom/growingio/android/sdk/track/modelloader/DataFetcher;->executeData()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    check-cast p0, Lo5/b;

    .line 42
    .line 43
    return-object p0
.end method


# virtual methods
.method public final b()V
    .locals 2

    .line 1
    iget-object v0, p0, Lo5/c;->k:Ljava/util/ArrayList;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    invoke-virtual {p0}, Lo5/c;->c()V

    .line 5
    .line 6
    .line 7
    monitor-exit v0

    .line 8
    return-void

    .line 9
    :catchall_0
    move-exception v1

    .line 10
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    throw v1
.end method

.method public final c()V
    .locals 5

    .line 1
    iget-object v0, p0, Lo5/c;->k:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 16
    .line 17
    .line 18
    new-instance v0, Ljava/lang/StringBuilder;

    .line 19
    .line 20
    const-string v2, "flushPendingEvents: size="

    .line 21
    .line 22
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    const/4 v2, 0x0

    .line 37
    new-array v3, v2, [Ljava/lang/Object;

    .line 38
    .line 39
    const-string v4, "EventSender"

    .line 40
    .line 41
    invoke-static {v4, v0, v3}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    new-instance v0, Lo5/a;

    .line 45
    .line 46
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 47
    .line 48
    .line 49
    iput v2, v0, Lo5/a;->a:I

    .line 50
    .line 51
    new-instance v2, Ljava/util/ArrayList;

    .line 52
    .line 53
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 54
    .line 55
    .line 56
    iput-object v2, v0, Lo5/a;->b:Ljava/util/ArrayList;

    .line 57
    .line 58
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 59
    .line 60
    .line 61
    invoke-static {v0}, Lo5/c;->a(Lo5/a;)Lo5/b;

    .line 62
    .line 63
    .line 64
    return-void
.end method

.method public final d(Z)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual {v0}, Lo5/c;->b()V

    .line 4
    .line 5
    .line 6
    iget-object v1, v0, Lo5/c;->e:LE2/a;

    .line 7
    .line 8
    iget-object v2, v1, LE2/a;->f:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v2, Ljava/nio/channels/FileLock;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    if-nez v2, :cond_2

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    :try_start_0
    iget-object v4, v1, LE2/a;->d:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v4, Ljava/io/FileOutputStream;

    .line 19
    .line 20
    if-eqz v4, :cond_0

    .line 21
    .line 22
    iget-object v4, v1, LE2/a;->e:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v4, Ljava/nio/channels/FileChannel;

    .line 25
    .line 26
    if-nez v4, :cond_1

    .line 27
    .line 28
    :cond_0
    iget-object v4, v1, LE2/a;->b:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v4, Landroid/content/Context;

    .line 31
    .line 32
    iget-object v5, v1, LE2/a;->c:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v5, Ljava/lang/String;

    .line 35
    .line 36
    invoke-virtual {v4, v5, v3}, Landroid/content/Context;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    iput-object v4, v1, LE2/a;->d:Ljava/lang/Object;

    .line 41
    .line 42
    invoke-virtual {v4}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    iput-object v4, v1, LE2/a;->e:Ljava/lang/Object;

    .line 47
    .line 48
    :cond_1
    iget-object v4, v1, LE2/a;->e:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v4, Ljava/nio/channels/FileChannel;

    .line 51
    .line 52
    invoke-virtual {v4}, Ljava/nio/channels/FileChannel;->tryLock()Ljava/nio/channels/FileLock;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    iput-object v4, v1, LE2/a;->f:Ljava/lang/Object;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/nio/channels/OverlappingFileLockException; {:try_start_0 .. :try_end_0} :catch_0

    .line 57
    .line 58
    :cond_2
    iget-object v1, v1, LE2/a;->f:Ljava/lang/Object;

    .line 59
    .line 60
    move-object v2, v1

    .line 61
    check-cast v2, Ljava/nio/channels/FileLock;

    .line 62
    .line 63
    :catch_0
    const-string v1, "EventSender"

    .line 64
    .line 65
    if-eqz v2, :cond_d

    .line 66
    .line 67
    invoke-virtual {v2}, Ljava/nio/channels/FileLock;->isValid()Z

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    if-eqz v2, :cond_d

    .line 72
    .line 73
    iget-object v2, v0, Lo5/c;->a:Landroid/content/Context;

    .line 74
    .line 75
    invoke-static {v2}, Lt5/b;->a(Landroid/content/Context;)LV7/g;

    .line 76
    .line 77
    .line 78
    move-result-object v4

    .line 79
    iget-boolean v5, v4, LV7/g;->a:Z

    .line 80
    .line 81
    if-nez v5, :cond_3

    .line 82
    .line 83
    goto/16 :goto_6

    .line 84
    .line 85
    :cond_3
    const/4 v5, 0x1

    .line 86
    const/4 v6, 0x3

    .line 87
    if-eqz p1, :cond_4

    .line 88
    .line 89
    new-array v7, v5, [I

    .line 90
    .line 91
    aput v5, v7, v3

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_4
    iget-boolean v7, v4, LV7/g;->c:Z

    .line 95
    .line 96
    const/4 v8, 0x2

    .line 97
    if-eqz v7, :cond_5

    .line 98
    .line 99
    new-array v7, v6, [I

    .line 100
    .line 101
    aput v5, v7, v3

    .line 102
    .line 103
    aput v8, v7, v5

    .line 104
    .line 105
    aput v6, v7, v8

    .line 106
    .line 107
    goto :goto_0

    .line 108
    :cond_5
    new-array v7, v8, [I

    .line 109
    .line 110
    aput v5, v7, v3

    .line 111
    .line 112
    aput v8, v7, v5

    .line 113
    .line 114
    :goto_0
    array-length v8, v7

    .line 115
    move v9, v3

    .line 116
    :goto_1
    if-ge v9, v8, :cond_c

    .line 117
    .line 118
    aget v10, v7, v9

    .line 119
    .line 120
    :goto_2
    iget-boolean v11, v4, LV7/g;->b:Z

    .line 121
    .line 122
    if-eq v10, v5, :cond_7

    .line 123
    .line 124
    if-eqz v11, :cond_7

    .line 125
    .line 126
    const-wide/16 v12, 0x0

    .line 127
    .line 128
    invoke-virtual {v0, v12, v13}, Lo5/c;->e(J)J

    .line 129
    .line 130
    .line 131
    move-result-wide v12

    .line 132
    iget-wide v14, v0, Lo5/c;->g:J

    .line 133
    .line 134
    cmp-long v12, v14, v12

    .line 135
    .line 136
    if-gez v12, :cond_7

    .line 137
    .line 138
    const-string v10, "Today\'s mobile data is exhausted"

    .line 139
    .line 140
    new-array v11, v3, [Ljava/lang/Object;

    .line 141
    .line 142
    invoke-static {v1, v10, v11}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    :cond_6
    move-object/from16 v16, v4

    .line 146
    .line 147
    goto :goto_5

    .line 148
    :cond_7
    const-string v12, "activity"

    .line 149
    .line 150
    invoke-virtual {v2, v12}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v12

    .line 154
    check-cast v12, Landroid/app/ActivityManager;

    .line 155
    .line 156
    new-instance v13, Landroid/app/ActivityManager$MemoryInfo;

    .line 157
    .line 158
    invoke-direct {v13}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    .line 159
    .line 160
    .line 161
    invoke-virtual {v12, v13}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    .line 162
    .line 163
    .line 164
    iget-boolean v12, v13, Landroid/app/ActivityManager$MemoryInfo;->lowMemory:Z

    .line 165
    .line 166
    if-eqz v12, :cond_8

    .line 167
    .line 168
    move v12, v6

    .line 169
    goto :goto_3

    .line 170
    :cond_8
    const/16 v12, 0x32

    .line 171
    .line 172
    :goto_3
    new-instance v13, Lo5/a;

    .line 173
    .line 174
    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    .line 175
    .line 176
    .line 177
    iput v5, v13, Lo5/a;->a:I

    .line 178
    .line 179
    iput v10, v13, Lo5/a;->c:I

    .line 180
    .line 181
    iput v12, v13, Lo5/a;->d:I

    .line 182
    .line 183
    invoke-static {v13}, Lo5/c;->a(Lo5/a;)Lo5/b;

    .line 184
    .line 185
    .line 186
    move-result-object v12

    .line 187
    iget-boolean v13, v12, Lo5/b;->a:Z

    .line 188
    .line 189
    if-eqz v13, :cond_6

    .line 190
    .line 191
    iget v13, v12, Lo5/b;->c:I

    .line 192
    .line 193
    if-lez v13, :cond_6

    .line 194
    .line 195
    iget-object v13, v12, Lo5/b;->d:[B

    .line 196
    .line 197
    iget-object v14, v12, Lo5/b;->f:Ljava/lang/String;

    .line 198
    .line 199
    iget-object v15, v0, Lo5/c;->b:LG6/b;

    .line 200
    .line 201
    invoke-virtual {v15, v13, v14}, LG6/b;->send([BLjava/lang/String;)Lo5/e;

    .line 202
    .line 203
    .line 204
    move-result-object v13

    .line 205
    iget-boolean v14, v13, Lo5/e;->a:Z

    .line 206
    .line 207
    if-eqz v14, :cond_9

    .line 208
    .line 209
    iget-object v15, v12, Lo5/b;->e:Ljava/lang/String;

    .line 210
    .line 211
    move-object/from16 v16, v4

    .line 212
    .line 213
    iget-wide v3, v12, Lo5/b;->b:J

    .line 214
    .line 215
    new-instance v12, Lo5/a;

    .line 216
    .line 217
    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    .line 218
    .line 219
    .line 220
    iput v6, v12, Lo5/a;->a:I

    .line 221
    .line 222
    iput v10, v12, Lo5/a;->c:I

    .line 223
    .line 224
    iput-object v15, v12, Lo5/a;->f:Ljava/lang/String;

    .line 225
    .line 226
    iput-wide v3, v12, Lo5/a;->e:J

    .line 227
    .line 228
    invoke-static {v12}, Lo5/c;->a(Lo5/a;)Lo5/b;

    .line 229
    .line 230
    .line 231
    if-eqz v11, :cond_a

    .line 232
    .line 233
    iget-wide v3, v13, Lo5/e;->b:J

    .line 234
    .line 235
    invoke-virtual {v0, v3, v4}, Lo5/c;->e(J)J

    .line 236
    .line 237
    .line 238
    goto :goto_4

    .line 239
    :cond_9
    move-object/from16 v16, v4

    .line 240
    .line 241
    :cond_a
    :goto_4
    if-nez v14, :cond_b

    .line 242
    .line 243
    goto :goto_5

    .line 244
    :cond_b
    move-object/from16 v4, v16

    .line 245
    .line 246
    const/4 v3, 0x0

    .line 247
    goto :goto_2

    .line 248
    :goto_5
    add-int/lit8 v9, v9, 0x1

    .line 249
    .line 250
    move-object/from16 v4, v16

    .line 251
    .line 252
    const/4 v3, 0x0

    .line 253
    goto/16 :goto_1

    .line 254
    .line 255
    :cond_c
    :goto_6
    return-void

    .line 256
    :cond_d
    const-string v2, "sendEvents: this process can not get lock"

    .line 257
    .line 258
    const/4 v3, 0x0

    .line 259
    new-array v3, v3, [Ljava/lang/Object;

    .line 260
    .line 261
    invoke-static {v1, v2, v3}, Ln5/h;->c(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 262
    .line 263
    .line 264
    return-void
.end method

.method public final e(J)J
    .locals 7

    .line 1
    const-string v0, ""

    .line 2
    .line 3
    iget-object v1, p0, Lo5/c;->c:Landroid/content/SharedPreferences;

    .line 4
    .line 5
    const-string v2, "today"

    .line 6
    .line 7
    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    new-instance v3, Ljava/text/SimpleDateFormat;

    .line 12
    .line 13
    const-string/jumbo v4, "yyyyMMdd"

    .line 14
    .line 15
    .line 16
    invoke-direct {v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    new-instance v4, Ljava/util/Date;

    .line 20
    .line 21
    invoke-direct {v4}, Ljava/util/Date;-><init>()V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v3, v4}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    const-wide/16 v4, 0x0

    .line 33
    .line 34
    const-string v6, "today_bytes"

    .line 35
    .line 36
    if-nez v0, :cond_0

    .line 37
    .line 38
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 43
    .line 44
    .line 45
    invoke-interface {v0, v6, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 46
    .line 47
    .line 48
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 49
    .line 50
    .line 51
    move-wide v2, v4

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    invoke-interface {v1, v6, v4, v5}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    .line 54
    .line 55
    .line 56
    move-result-wide v2

    .line 57
    :goto_0
    cmp-long v0, p1, v4

    .line 58
    .line 59
    if-lez v0, :cond_1

    .line 60
    .line 61
    add-long/2addr v2, p1

    .line 62
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-interface {p1, v6, v2, v3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 71
    .line 72
    .line 73
    :cond_1
    return-wide v2
.end method
