.class public final Lo5/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:J


# direct methods
.method public constructor <init>(JZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p3, p0, Lo5/e;->a:Z

    .line 5
    .line 6
    iput-wide p1, p0, Lo5/e;->b:J

    .line 7
    .line 8
    return-void
.end method
