.class public final LO6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public b:Ljava/lang/CharSequence;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/CharSequence;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Landroid/view/View$OnClickListener;

.field public i:Landroid/view/View$OnClickListener;

.field public j:Landroid/view/View$OnClickListener;

.field public k:Z

.field public l:I

.field public m:I

.field public n:Landroid/graphics/drawable/Drawable;

.field public o:Ljava/lang/String;

.field public p:Landroid/graphics/drawable/Drawable;

.field public q:Ljava/lang/String;

.field public r:Ljava/lang/String;

.field public s:Ljava/lang/String;

.field public t:Ljava/lang/String;

.field public u:I

.field public v:I

.field public w:Landroid/view/View;

.field public x:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iput v0, p0, LO6/c;->u:I

    .line 6
    .line 7
    sget v1, LL6/i;->ppDefaultDialogTheme:I

    .line 8
    .line 9
    iput v1, p0, LO6/c;->v:I

    .line 10
    .line 11
    iput-boolean v0, p0, LO6/c;->x:Z

    .line 12
    .line 13
    iput-object p1, p0, LO6/c;->a:Landroid/content/Context;

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final a()LO6/d;
    .locals 5

    .line 1
    iget v0, p0, LO6/c;->u:I

    .line 2
    .line 3
    iget-object v1, p0, LO6/c;->a:Landroid/content/Context;

    .line 4
    .line 5
    const/4 v2, 0x4

    .line 6
    const/4 v3, 0x3

    .line 7
    if-eq v0, v3, :cond_1

    .line 8
    .line 9
    if-ne v0, v2, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance v0, LO6/d;

    .line 13
    .line 14
    sget v4, LL6/g;->lib_ui_layout_dialog_type_at_center:I

    .line 15
    .line 16
    invoke-direct {v0, v1, v4}, LO6/d;-><init>(Landroid/content/Context;I)V

    .line 17
    .line 18
    .line 19
    goto :goto_1

    .line 20
    :cond_1
    :goto_0
    new-instance v0, LO6/d;

    .line 21
    .line 22
    sget v4, LL6/g;->lib_ui_layout_dialog_type_at_bottom:I

    .line 23
    .line 24
    invoke-direct {v0, v1, v4}, LO6/d;-><init>(Landroid/content/Context;I)V

    .line 25
    .line 26
    .line 27
    :goto_1
    iget v4, p0, LO6/c;->l:I

    .line 28
    .line 29
    if-nez v4, :cond_3

    .line 30
    .line 31
    iget v4, p0, LO6/c;->u:I

    .line 32
    .line 33
    if-eq v4, v3, :cond_2

    .line 34
    .line 35
    if-ne v4, v2, :cond_3

    .line 36
    .line 37
    :cond_2
    iput v3, p0, LO6/c;->l:I

    .line 38
    .line 39
    :cond_3
    iget-object v2, p0, LO6/c;->w:Landroid/view/View;

    .line 40
    .line 41
    iput-object v2, v0, LO6/d;->d:Landroid/view/View;

    .line 42
    .line 43
    iget-object v2, p0, LO6/c;->d:Ljava/lang/CharSequence;

    .line 44
    .line 45
    iput-object v2, v0, LO6/d;->Q:Ljava/lang/CharSequence;

    .line 46
    .line 47
    iget-object v2, p0, LO6/c;->e:Ljava/lang/String;

    .line 48
    .line 49
    iput-object v2, v0, LO6/d;->X:Ljava/lang/String;

    .line 50
    .line 51
    iget-object v2, p0, LO6/c;->b:Ljava/lang/CharSequence;

    .line 52
    .line 53
    iput-object v2, v0, LO6/d;->M:Ljava/lang/CharSequence;

    .line 54
    .line 55
    iget-object v2, p0, LO6/c;->c:Ljava/lang/String;

    .line 56
    .line 57
    invoke-static {v2}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    if-nez v3, :cond_4

    .line 62
    .line 63
    const/4 v2, 0x0

    .line 64
    goto :goto_2

    .line 65
    :cond_4
    invoke-virtual {v2}, Ljava/lang/String;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    :goto_2
    iput-object v2, v0, LO6/d;->L:Ljava/lang/String;

    .line 70
    .line 71
    iget-object v2, p0, LO6/c;->g:Ljava/lang/String;

    .line 72
    .line 73
    iput-object v2, v0, LO6/d;->k0:Ljava/lang/String;

    .line 74
    .line 75
    iget-object v2, p0, LO6/c;->f:Ljava/lang/String;

    .line 76
    .line 77
    iput-object v2, v0, LO6/d;->Z:Ljava/lang/String;

    .line 78
    .line 79
    iget-object v2, p0, LO6/c;->i:Landroid/view/View$OnClickListener;

    .line 80
    .line 81
    iput-object v2, v0, LO6/d;->q0:Landroid/view/View$OnClickListener;

    .line 82
    .line 83
    iget-object v2, p0, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 84
    .line 85
    iput-object v2, v0, LO6/d;->p0:Landroid/view/View$OnClickListener;

    .line 86
    .line 87
    iget-object v2, p0, LO6/c;->j:Landroid/view/View$OnClickListener;

    .line 88
    .line 89
    iput-object v2, v0, LO6/d;->r0:Landroid/view/View$OnClickListener;

    .line 90
    .line 91
    iget-boolean v2, p0, LO6/c;->k:Z

    .line 92
    .line 93
    iput-boolean v2, v0, LO6/d;->s0:Z

    .line 94
    .line 95
    iget v2, p0, LO6/c;->l:I

    .line 96
    .line 97
    iput v2, v0, LO6/d;->Y:I

    .line 98
    .line 99
    iget v2, p0, LO6/c;->m:I

    .line 100
    .line 101
    iput v2, v0, LO6/d;->t0:I

    .line 102
    .line 103
    iget-object v2, p0, LO6/c;->n:Landroid/graphics/drawable/Drawable;

    .line 104
    .line 105
    iput-object v2, v0, LO6/d;->v0:Landroid/graphics/drawable/Drawable;

    .line 106
    .line 107
    iget-object v2, p0, LO6/c;->o:Ljava/lang/String;

    .line 108
    .line 109
    iput-object v2, v0, LO6/d;->w0:Ljava/lang/String;

    .line 110
    .line 111
    const/4 v2, 0x0

    .line 112
    iput v2, v0, LO6/d;->u0:I

    .line 113
    .line 114
    iget-object v2, p0, LO6/c;->p:Landroid/graphics/drawable/Drawable;

    .line 115
    .line 116
    iput-object v2, v0, LO6/d;->x0:Landroid/graphics/drawable/Drawable;

    .line 117
    .line 118
    iget-object v2, p0, LO6/c;->q:Ljava/lang/String;

    .line 119
    .line 120
    iput-object v2, v0, LO6/d;->y0:Ljava/lang/String;

    .line 121
    .line 122
    iget-object v2, p0, LO6/c;->r:Ljava/lang/String;

    .line 123
    .line 124
    iput-object v2, v0, LO6/d;->z0:Ljava/lang/String;

    .line 125
    .line 126
    iget-object v2, p0, LO6/c;->s:Ljava/lang/String;

    .line 127
    .line 128
    iput-object v2, v0, LO6/d;->A0:Ljava/lang/String;

    .line 129
    .line 130
    iget-object v2, p0, LO6/c;->t:Ljava/lang/String;

    .line 131
    .line 132
    iput-object v2, v0, LO6/d;->B0:Ljava/lang/String;

    .line 133
    .line 134
    iput-object v1, v0, LO6/a;->a:Landroid/content/Context;

    .line 135
    .line 136
    iget v1, p0, LO6/c;->u:I

    .line 137
    .line 138
    iput v1, v0, LO6/d;->C0:I

    .line 139
    .line 140
    iget v1, p0, LO6/c;->v:I

    .line 141
    .line 142
    iput v1, v0, LO6/d;->D0:I

    .line 143
    .line 144
    iget-boolean v1, p0, LO6/c;->x:Z

    .line 145
    .line 146
    invoke-virtual {v0, v1}, LO6/d;->setCancelable(Z)V

    .line 147
    .line 148
    .line 149
    return-object v0
.end method

.method public final b(I)V
    .locals 1

    .line 1
    iget-object v0, p0, LO6/c;->a:Landroid/content/Context;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, LO6/c;->d:Ljava/lang/CharSequence;

    .line 10
    .line 11
    :cond_0
    return-void
.end method

.method public final c(ILandroid/view/View$OnClickListener;)V
    .locals 1

    .line 1
    iget-object v0, p0, LO6/c;->a:Landroid/content/Context;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, LO6/c;->g:Ljava/lang/String;

    .line 10
    .line 11
    :cond_0
    iput-object p2, p0, LO6/c;->i:Landroid/view/View$OnClickListener;

    .line 12
    .line 13
    return-void
.end method

.method public final d(ILandroid/view/View$OnClickListener;)V
    .locals 1

    .line 1
    iget-object v0, p0, LO6/c;->a:Landroid/content/Context;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, LO6/c;->f:Ljava/lang/String;

    .line 10
    .line 11
    :cond_0
    iput-object p2, p0, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 12
    .line 13
    return-void
.end method

.method public final e(I)V
    .locals 1

    .line 1
    iget-object v0, p0, LO6/c;->a:Landroid/content/Context;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, LO6/c;->b:Ljava/lang/CharSequence;

    .line 10
    .line 11
    :cond_0
    return-void
.end method

.method public final f(Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-static {p1}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iput-object p1, p0, LO6/c;->b:Ljava/lang/CharSequence;

    .line 6
    .line 7
    return-void
.end method

.method public final g()LO6/d;
    .locals 5

    .line 1
    invoke-virtual {p0}, LO6/c;->a()LO6/d;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, LO6/d;->show()V

    .line 6
    .line 7
    .line 8
    iget v1, p0, LO6/c;->u:I

    .line 9
    .line 10
    const/4 v2, 0x3

    .line 11
    if-eq v1, v2, :cond_1

    .line 12
    .line 13
    const/4 v2, 0x4

    .line 14
    if-ne v1, v2, :cond_0

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    iget-object v3, p0, LO6/c;->a:Landroid/content/Context;

    .line 26
    .line 27
    invoke-static {v3}, Le1/a;->y(Landroid/content/Context;)I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    int-to-float v3, v3

    .line 32
    const v4, 0x3f6a7efa    # 0.916f

    .line 33
    .line 34
    .line 35
    mul-float/2addr v3, v4

    .line 36
    float-to-int v3, v3

    .line 37
    iput v3, v2, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 38
    .line 39
    invoke-virtual {v1, v2}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 40
    .line 41
    .line 42
    return-object v0

    .line 43
    :cond_1
    :goto_0
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-virtual {v0, v1}, LO6/a;->showAtBottom(Landroid/view/Window;)V

    .line 48
    .line 49
    .line 50
    return-object v0
.end method
