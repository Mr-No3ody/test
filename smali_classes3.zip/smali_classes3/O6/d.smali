.class public final LO6/d;
.super LO6/a;
.source "SourceFile"


# instance fields
.field public A:Landroidx/appcompat/widget/AppCompatImageView;

.field public A0:Ljava/lang/String;

.field public B:Landroid/view/View;

.field public B0:Ljava/lang/String;

.field public C:Landroid/view/View;

.field public C0:I

.field public D0:I

.field public H:Landroid/view/View;

.field public L:Ljava/lang/String;

.field public M:Ljava/lang/CharSequence;

.field public Q:Ljava/lang/CharSequence;

.field public X:Ljava/lang/String;

.field public Y:I

.field public Z:Ljava/lang/String;

.field public d:Landroid/view/View;

.field public e:Landroid/widget/LinearLayout;

.field public f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

.field public g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

.field public i:Landroid/widget/TextView;

.field public j:Landroid/widget/TextView;

.field public k0:Ljava/lang/String;

.field public o:Landroid/widget/ImageView;

.field public p:Landroidx/appcompat/widget/AppCompatImageView;

.field public p0:Landroid/view/View$OnClickListener;

.field public q0:Landroid/view/View$OnClickListener;

.field public r0:Landroid/view/View$OnClickListener;

.field public s0:Z

.field public t:Landroidx/appcompat/widget/AppCompatImageView;

.field public t0:I

.field public u0:I

.field public v:Landroidx/appcompat/widget/AppCompatImageView;

.field public v0:Landroid/graphics/drawable/Drawable;

.field public w:Landroidx/appcompat/widget/AppCompatImageView;

.field public w0:Ljava/lang/String;

.field public x0:Landroid/graphics/drawable/Drawable;

.field public y0:Ljava/lang/String;

.field public z0:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LO6/a;-><init>(Landroid/content/Context;I)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, LO6/d;->Q:Ljava/lang/CharSequence;

    .line 6
    .line 7
    iput-object p1, p0, LO6/d;->X:Ljava/lang/String;

    .line 8
    .line 9
    const/4 p2, -0x1

    .line 10
    iput p2, p0, LO6/d;->t0:I

    .line 11
    .line 12
    iput p2, p0, LO6/d;->u0:I

    .line 13
    .line 14
    iput-object p1, p0, LO6/d;->v0:Landroid/graphics/drawable/Drawable;

    .line 15
    .line 16
    iput-object p1, p0, LO6/d;->x0:Landroid/graphics/drawable/Drawable;

    .line 17
    .line 18
    const/4 p1, 0x1

    .line 19
    iput p1, p0, LO6/d;->C0:I

    .line 20
    .line 21
    sget p1, LL6/i;->ppDefaultDialogTheme:I

    .line 22
    .line 23
    iput p1, p0, LO6/d;->D0:I

    .line 24
    .line 25
    return-void
.end method

.method public static e(ILandroid/view/View;)V
    .locals 1

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 9
    .line 10
    iput p0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 11
    .line 12
    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public static f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    .locals 3

    .line 1
    if-nez p0, :cond_0

    .line 2
    .line 3
    const/4 p0, 0x0

    .line 4
    return-object p0

    .line 5
    :cond_0
    :try_start_0
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    :goto_0
    if-ge v1, v0, :cond_1

    .line 11
    .line 12
    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    invoke-static {v2}, Ljava/lang/Character;->isWhitespace(C)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_1

    .line 21
    .line 22
    add-int/lit8 v1, v1, 0x1

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_1
    :goto_1
    if-le v0, v1, :cond_2

    .line 26
    .line 27
    add-int/lit8 v2, v0, -0x1

    .line 28
    .line 29
    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    invoke-static {v2}, Ljava/lang/Character;->isWhitespace(C)Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_2

    .line 38
    .line 39
    add-int/lit8 v0, v0, -0x1

    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_2
    if-nez v1, :cond_3

    .line 43
    .line 44
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    if-ne v0, v2, :cond_3

    .line 49
    .line 50
    goto :goto_2

    .line 51
    :cond_3
    instance-of v2, p0, Landroid/text/Spanned;

    .line 52
    .line 53
    if-eqz v2, :cond_4

    .line 54
    .line 55
    new-instance v2, Landroid/text/SpannableStringBuilder;

    .line 56
    .line 57
    invoke-direct {v2, p0}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v2, v1, v0}, Landroid/text/SpannableStringBuilder;->subSequence(II)Ljava/lang/CharSequence;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    return-object p0

    .line 65
    :cond_4
    invoke-interface {p0, v1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    .line 66
    .line 67
    .line 68
    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 69
    :catch_0
    :goto_2
    return-object p0
.end method


# virtual methods
.method public final a(Landroid/content/Context;)V
    .locals 11

    .line 1
    iput-object p1, p0, LO6/a;->a:Landroid/content/Context;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const v1, 0x3f19999a    # 0.6f

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, v1}, Landroid/view/Window;->setDimAmount(F)V

    .line 17
    .line 18
    .line 19
    :cond_0
    iget v0, p0, LO6/d;->C0:I

    .line 20
    .line 21
    const/4 v1, 0x2

    .line 22
    const/4 v2, 0x4

    .line 23
    if-eq v0, v1, :cond_2

    .line 24
    .line 25
    if-ne v0, v2, :cond_1

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_1
    sget v0, LL6/f;->horizontalButtonStub:I

    .line 29
    .line 30
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    check-cast v0, Landroid/view/ViewStub;

    .line 35
    .line 36
    if-eqz v0, :cond_3

    .line 37
    .line 38
    invoke-virtual {v0}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 39
    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_2
    :goto_0
    sget v0, LL6/f;->verticalButtonStub:I

    .line 43
    .line 44
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    check-cast v0, Landroid/view/ViewStub;

    .line 49
    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    invoke-virtual {v0}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 53
    .line 54
    .line 55
    :cond_3
    :goto_1
    iget-object v0, p0, LO6/d;->B0:Ljava/lang/String;

    .line 56
    .line 57
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    const/4 v1, 0x0

    .line 62
    const/4 v3, 0x1

    .line 63
    if-eqz v0, :cond_4

    .line 64
    .line 65
    iget-object v4, p0, LO6/d;->A0:Ljava/lang/String;

    .line 66
    .line 67
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-nez v4, :cond_4

    .line 72
    .line 73
    move v4, v3

    .line 74
    goto :goto_2

    .line 75
    :cond_4
    move v4, v1

    .line 76
    :goto_2
    iget-object v5, p0, LO6/d;->z0:Ljava/lang/String;

    .line 77
    .line 78
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 79
    .line 80
    .line 81
    move-result v5

    .line 82
    if-nez v5, :cond_6

    .line 83
    .line 84
    iget v5, p0, LO6/d;->t0:I

    .line 85
    .line 86
    if-gtz v5, :cond_6

    .line 87
    .line 88
    iget-object v5, p0, LO6/d;->v0:Landroid/graphics/drawable/Drawable;

    .line 89
    .line 90
    if-nez v5, :cond_6

    .line 91
    .line 92
    iget-object v5, p0, LO6/d;->w0:Ljava/lang/String;

    .line 93
    .line 94
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 95
    .line 96
    .line 97
    move-result v5

    .line 98
    if-nez v5, :cond_5

    .line 99
    .line 100
    goto :goto_3

    .line 101
    :cond_5
    invoke-virtual {p0}, LO6/d;->c()V

    .line 102
    .line 103
    .line 104
    :cond_6
    :goto_3
    sget v5, LL6/f;->tv_title:I

    .line 105
    .line 106
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 107
    .line 108
    .line 109
    move-result-object v5

    .line 110
    check-cast v5, Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 111
    .line 112
    iput-object v5, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 113
    .line 114
    invoke-virtual {p0}, LO6/d;->d()Z

    .line 115
    .line 116
    .line 117
    move-result v5

    .line 118
    if-eqz v5, :cond_7

    .line 119
    .line 120
    iget-object v5, p0, LO6/d;->z0:Ljava/lang/String;

    .line 121
    .line 122
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 123
    .line 124
    .line 125
    move-result v5

    .line 126
    if-eqz v5, :cond_7

    .line 127
    .line 128
    if-nez v4, :cond_7

    .line 129
    .line 130
    sget v5, LL6/f;->tv_title_2:I

    .line 131
    .line 132
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 133
    .line 134
    .line 135
    move-result-object v5

    .line 136
    check-cast v5, Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 137
    .line 138
    iput-object v5, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 139
    .line 140
    :cond_7
    sget v5, LL6/f;->tv_message:I

    .line 141
    .line 142
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 143
    .line 144
    .line 145
    move-result-object v5

    .line 146
    check-cast v5, Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 147
    .line 148
    iput-object v5, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 149
    .line 150
    sget v5, LL6/f;->tv_confirm:I

    .line 151
    .line 152
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    check-cast v5, Landroid/widget/TextView;

    .line 157
    .line 158
    iput-object v5, p0, LO6/d;->i:Landroid/widget/TextView;

    .line 159
    .line 160
    sget v5, LL6/f;->tv_cancel:I

    .line 161
    .line 162
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 163
    .line 164
    .line 165
    move-result-object v5

    .line 166
    check-cast v5, Landroid/widget/TextView;

    .line 167
    .line 168
    iput-object v5, p0, LO6/d;->j:Landroid/widget/TextView;

    .line 169
    .line 170
    sget v5, LL6/f;->view_gap:I

    .line 171
    .line 172
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 173
    .line 174
    .line 175
    move-result-object v5

    .line 176
    iput-object v5, p0, LO6/d;->B:Landroid/view/View;

    .line 177
    .line 178
    sget v5, LL6/f;->layout_btn_container:I

    .line 179
    .line 180
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 181
    .line 182
    .line 183
    move-result-object v5

    .line 184
    iput-object v5, p0, LO6/d;->C:Landroid/view/View;

    .line 185
    .line 186
    sget v5, LL6/f;->iv_close:I

    .line 187
    .line 188
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 189
    .line 190
    .line 191
    move-result-object v5

    .line 192
    check-cast v5, Landroid/widget/ImageView;

    .line 193
    .line 194
    iput-object v5, p0, LO6/d;->o:Landroid/widget/ImageView;

    .line 195
    .line 196
    sget v5, LL6/f;->iv_icon:I

    .line 197
    .line 198
    invoke-virtual {p0, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 199
    .line 200
    .line 201
    move-result-object v5

    .line 202
    check-cast v5, Landroidx/appcompat/widget/AppCompatImageView;

    .line 203
    .line 204
    iput-object v5, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 205
    .line 206
    const/4 v5, 0x0

    .line 207
    iput-object v5, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 208
    .line 209
    iput-object v5, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 210
    .line 211
    sget v6, LL6/f;->viewContainer:I

    .line 212
    .line 213
    invoke-virtual {p0, v6}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 214
    .line 215
    .line 216
    move-result-object v6

    .line 217
    check-cast v6, Landroid/widget/LinearLayout;

    .line 218
    .line 219
    iput-object v6, p0, LO6/d;->e:Landroid/widget/LinearLayout;

    .line 220
    .line 221
    sget v6, LL6/f;->viewRoot:I

    .line 222
    .line 223
    invoke-virtual {p0, v6}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 224
    .line 225
    .line 226
    move-result-object v6

    .line 227
    iput-object v6, p0, LO6/d;->H:Landroid/view/View;

    .line 228
    .line 229
    sget v6, LL6/f;->topHeaderBgStub:I

    .line 230
    .line 231
    invoke-virtual {p0, v6}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 232
    .line 233
    .line 234
    move-result-object v6

    .line 235
    check-cast v6, Landroid/view/ViewStub;

    .line 236
    .line 237
    if-nez v0, :cond_8

    .line 238
    .line 239
    if-eqz v6, :cond_8

    .line 240
    .line 241
    invoke-virtual {v6}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 242
    .line 243
    .line 244
    sget v6, LL6/f;->ivTopHeaderBg:I

    .line 245
    .line 246
    invoke-virtual {p0, v6}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 247
    .line 248
    .line 249
    move-result-object v6

    .line 250
    check-cast v6, Landroidx/appcompat/widget/AppCompatImageView;

    .line 251
    .line 252
    iput-object v6, p0, LO6/d;->w:Landroidx/appcompat/widget/AppCompatImageView;

    .line 253
    .line 254
    :cond_8
    sget v6, LL6/f;->topHeaderIconStub:I

    .line 255
    .line 256
    invoke-virtual {p0, v6}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 257
    .line 258
    .line 259
    move-result-object v6

    .line 260
    check-cast v6, Landroid/view/ViewStub;

    .line 261
    .line 262
    if-eqz v4, :cond_9

    .line 263
    .line 264
    if-eqz v6, :cond_9

    .line 265
    .line 266
    invoke-virtual {v6}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 267
    .line 268
    .line 269
    sget v6, LL6/f;->ivTopHeader:I

    .line 270
    .line 271
    invoke-virtual {p0, v6}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 272
    .line 273
    .line 274
    move-result-object v6

    .line 275
    check-cast v6, Landroidx/appcompat/widget/AppCompatImageView;

    .line 276
    .line 277
    iput-object v6, p0, LO6/d;->A:Landroidx/appcompat/widget/AppCompatImageView;

    .line 278
    .line 279
    :cond_9
    iget v6, p0, LO6/d;->u0:I

    .line 280
    .line 281
    if-gtz v6, :cond_a

    .line 282
    .line 283
    iget-object v6, p0, LO6/d;->x0:Landroid/graphics/drawable/Drawable;

    .line 284
    .line 285
    if-nez v6, :cond_a

    .line 286
    .line 287
    iget-object v6, p0, LO6/d;->y0:Ljava/lang/String;

    .line 288
    .line 289
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 290
    .line 291
    .line 292
    move-result v6

    .line 293
    if-nez v6, :cond_b

    .line 294
    .line 295
    :cond_a
    invoke-virtual {p0}, LO6/d;->b()V

    .line 296
    .line 297
    .line 298
    :cond_b
    iget-object v6, p0, LO6/d;->H:Landroid/view/View;

    .line 299
    .line 300
    if-eqz v6, :cond_e

    .line 301
    .line 302
    const/high16 v7, 0x41c00000    # 24.0f

    .line 303
    .line 304
    if-nez v0, :cond_c

    .line 305
    .line 306
    invoke-static {p1, v7}, Le1/a;->j(Landroid/content/Context;F)I

    .line 307
    .line 308
    .line 309
    move-result v7

    .line 310
    neg-int v7, v7

    .line 311
    invoke-static {v7, v6}, LO6/d;->e(ILandroid/view/View;)V

    .line 312
    .line 313
    .line 314
    goto :goto_4

    .line 315
    :cond_c
    if-eqz v4, :cond_d

    .line 316
    .line 317
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 318
    .line 319
    .line 320
    move-result-object v7

    .line 321
    sget v8, LL6/c;->ppDialogHeaderIconHalfHeight:I

    .line 322
    .line 323
    invoke-virtual {v7, v8}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 324
    .line 325
    .line 326
    move-result v7

    .line 327
    invoke-static {v7, v6}, LO6/d;->e(ILandroid/view/View;)V

    .line 328
    .line 329
    .line 330
    goto :goto_4

    .line 331
    :cond_d
    invoke-static {p1, v7}, Le1/a;->j(Landroid/content/Context;F)I

    .line 332
    .line 333
    .line 334
    move-result v7

    .line 335
    neg-int v7, v7

    .line 336
    invoke-static {v7, v6}, LO6/d;->e(ILandroid/view/View;)V

    .line 337
    .line 338
    .line 339
    :goto_4
    if-eqz v4, :cond_e

    .line 340
    .line 341
    iget-object v6, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 342
    .line 343
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 344
    .line 345
    .line 346
    move-result-object v7

    .line 347
    sget v8, LL6/c;->ppDialogHeaderIconBottomMargin:I

    .line 348
    .line 349
    invoke-virtual {v7, v8}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 350
    .line 351
    .line 352
    move-result v7

    .line 353
    invoke-static {v7, v6}, LO6/d;->e(ILandroid/view/View;)V

    .line 354
    .line 355
    .line 356
    :cond_e
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 357
    .line 358
    .line 359
    move-result-object v6

    .line 360
    iget v7, p0, LO6/d;->D0:I

    .line 361
    .line 362
    invoke-virtual {v6}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 363
    .line 364
    .line 365
    move-result-object v8

    .line 366
    sget-object v9, LL6/j;->ppDialogStyle:[I

    .line 367
    .line 368
    invoke-virtual {v8, v7, v9}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 369
    .line 370
    .line 371
    move-result-object v7

    .line 372
    sget v8, LL6/j;->ppDialogStyle_dialog_title_text_size:I

    .line 373
    .line 374
    invoke-virtual {v6}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 375
    .line 376
    .line 377
    move-result-object v9

    .line 378
    sget v10, LL6/c;->ppDialogTitleTextSize:I

    .line 379
    .line 380
    invoke-virtual {v9, v10}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 381
    .line 382
    .line 383
    move-result v9

    .line 384
    invoke-virtual {v7, v8, v9}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 385
    .line 386
    .line 387
    move-result v8

    .line 388
    iget-object v9, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 389
    .line 390
    int-to-float v8, v8

    .line 391
    invoke-virtual {v9, v1, v8}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 392
    .line 393
    .line 394
    sget v8, LL6/j;->ppDialogStyle_dialog_positive_button_bg:I

    .line 395
    .line 396
    invoke-virtual {v7, v8}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 397
    .line 398
    .line 399
    move-result-object v8

    .line 400
    if-eqz v8, :cond_f

    .line 401
    .line 402
    iget-object v9, p0, LO6/d;->i:Landroid/widget/TextView;

    .line 403
    .line 404
    invoke-virtual {v9, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 405
    .line 406
    .line 407
    :cond_f
    sget v8, LL6/j;->ppDialogStyle_dialog_positive_button_text_color:I

    .line 408
    .line 409
    const v9, 0x106000b

    .line 410
    .line 411
    .line 412
    invoke-virtual {v6, v9}, Landroid/content/Context;->getColor(I)I

    .line 413
    .line 414
    .line 415
    move-result v9

    .line 416
    invoke-virtual {v7, v8, v9}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 417
    .line 418
    .line 419
    move-result v8

    .line 420
    iget-object v9, p0, LO6/d;->i:Landroid/widget/TextView;

    .line 421
    .line 422
    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 423
    .line 424
    .line 425
    sget v8, LL6/j;->ppDialogStyle_dialog_negative_button_bg:I

    .line 426
    .line 427
    invoke-virtual {v7, v8}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 428
    .line 429
    .line 430
    move-result v8

    .line 431
    if-eqz v8, :cond_10

    .line 432
    .line 433
    sget v8, LL6/j;->ppDialogStyle_dialog_negative_button_bg:I

    .line 434
    .line 435
    invoke-virtual {v7, v8}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 436
    .line 437
    .line 438
    move-result-object v8

    .line 439
    iget-object v9, p0, LO6/d;->j:Landroid/widget/TextView;

    .line 440
    .line 441
    invoke-virtual {v9, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 442
    .line 443
    .line 444
    :cond_10
    sget v8, LL6/j;->ppDialogStyle_dialog_negative_button_text_color:I

    .line 445
    .line 446
    sget v9, LL6/b;->ppColorPrimary:I

    .line 447
    .line 448
    invoke-virtual {v6, v9}, Landroid/content/Context;->getColor(I)I

    .line 449
    .line 450
    .line 451
    move-result v9

    .line 452
    invoke-virtual {v7, v8, v9}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 453
    .line 454
    .line 455
    move-result v8

    .line 456
    iget-object v9, p0, LO6/d;->j:Landroid/widget/TextView;

    .line 457
    .line 458
    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 459
    .line 460
    .line 461
    sget v8, LL6/j;->ppDialogStyle_dialog_message_text_color:I

    .line 462
    .line 463
    sget v9, LL6/b;->ppColorTextNormal:I

    .line 464
    .line 465
    invoke-virtual {v6, v9}, Landroid/content/Context;->getColor(I)I

    .line 466
    .line 467
    .line 468
    move-result v9

    .line 469
    invoke-virtual {v7, v8, v9}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 470
    .line 471
    .line 472
    move-result v8

    .line 473
    iget-object v9, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 474
    .line 475
    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 476
    .line 477
    .line 478
    sget v8, LL6/j;->ppDialogStyle_dialog_message_text_size:I

    .line 479
    .line 480
    invoke-virtual {v6}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 481
    .line 482
    .line 483
    move-result-object v6

    .line 484
    sget v9, LL6/c;->ppDialogMessageTextSize:I

    .line 485
    .line 486
    invoke-virtual {v6, v9}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 487
    .line 488
    .line 489
    move-result v6

    .line 490
    invoke-virtual {v7, v8, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 491
    .line 492
    .line 493
    move-result v6

    .line 494
    iget-object v8, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 495
    .line 496
    int-to-float v6, v6

    .line 497
    invoke-virtual {v8, v1, v6}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 498
    .line 499
    .line 500
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->recycle()V

    .line 501
    .line 502
    .line 503
    iget-object v6, p0, LO6/d;->o:Landroid/widget/ImageView;

    .line 504
    .line 505
    sget-object v7, LS6/a;->C:LS6/a;

    .line 506
    .line 507
    sget v8, LL6/b;->ppColorTextAssist:I

    .line 508
    .line 509
    invoke-virtual {p1, v8}, Landroid/content/Context;->getColor(I)I

    .line 510
    .line 511
    .line 512
    move-result v8

    .line 513
    const/high16 v9, 0x41a00000    # 20.0f

    .line 514
    .line 515
    invoke-static {p1, v7, v5, v8, v9}, Le1/a;->h(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;Ljava/lang/String;IF)Lcom/mikepenz/iconics/IconicsDrawable;

    .line 516
    .line 517
    .line 518
    move-result-object v5

    .line 519
    invoke-virtual {v6, v5}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 520
    .line 521
    .line 522
    iget-object v5, p0, LO6/d;->o:Landroid/widget/ImageView;

    .line 523
    .line 524
    new-instance v6, LO6/b;

    .line 525
    .line 526
    const/4 v7, 0x0

    .line 527
    invoke-direct {v6, p0, v7}, LO6/b;-><init>(LO6/d;I)V

    .line 528
    .line 529
    .line 530
    invoke-virtual {v5, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 531
    .line 532
    .line 533
    iget-object v5, p0, LO6/d;->X:Ljava/lang/String;

    .line 534
    .line 535
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 536
    .line 537
    .line 538
    move-result v5

    .line 539
    const/16 v6, 0x8

    .line 540
    .line 541
    if-nez v5, :cond_11

    .line 542
    .line 543
    iget-object v5, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 544
    .line 545
    invoke-virtual {v5, v1}, Landroid/view/View;->setVisibility(I)V

    .line 546
    .line 547
    .line 548
    iget-object v5, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 549
    .line 550
    iget-object v7, p0, LO6/d;->X:Ljava/lang/String;

    .line 551
    .line 552
    invoke-virtual {v5, v7}, Lorg/sufficientlysecure/htmltextview/HtmlTextView;->setHtml(Ljava/lang/String;)V

    .line 553
    .line 554
    .line 555
    goto :goto_5

    .line 556
    :cond_11
    iget-object v5, p0, LO6/d;->Q:Ljava/lang/CharSequence;

    .line 557
    .line 558
    if-eqz v5, :cond_12

    .line 559
    .line 560
    iget-object v5, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 561
    .line 562
    invoke-virtual {v5, v1}, Landroid/view/View;->setVisibility(I)V

    .line 563
    .line 564
    .line 565
    iget-object v5, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 566
    .line 567
    iget-object v7, p0, LO6/d;->Q:Ljava/lang/CharSequence;

    .line 568
    .line 569
    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 570
    .line 571
    .line 572
    goto :goto_5

    .line 573
    :cond_12
    iget-object v5, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 574
    .line 575
    invoke-virtual {v5, v6}, Landroid/view/View;->setVisibility(I)V

    .line 576
    .line 577
    .line 578
    :goto_5
    iget v5, p0, LO6/d;->Y:I

    .line 579
    .line 580
    if-nez v5, :cond_13

    .line 581
    .line 582
    iput v3, p0, LO6/d;->Y:I

    .line 583
    .line 584
    :cond_13
    iget-object v3, p0, LO6/d;->g:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 585
    .line 586
    iget v5, p0, LO6/d;->Y:I

    .line 587
    .line 588
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 589
    .line 590
    .line 591
    iget-object v3, p0, LO6/d;->L:Ljava/lang/String;

    .line 592
    .line 593
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 594
    .line 595
    .line 596
    move-result v3

    .line 597
    if-nez v3, :cond_14

    .line 598
    .line 599
    iget-object v3, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 600
    .line 601
    iget-object v5, p0, LO6/d;->L:Ljava/lang/String;

    .line 602
    .line 603
    invoke-virtual {v3, v5}, Lorg/sufficientlysecure/htmltextview/HtmlTextView;->setHtml(Ljava/lang/String;)V

    .line 604
    .line 605
    .line 606
    iget-object v3, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 607
    .line 608
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 609
    .line 610
    .line 611
    goto :goto_6

    .line 612
    :cond_14
    iget-object v3, p0, LO6/d;->M:Ljava/lang/CharSequence;

    .line 613
    .line 614
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 615
    .line 616
    .line 617
    move-result v3

    .line 618
    if-nez v3, :cond_15

    .line 619
    .line 620
    iget-object v3, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 621
    .line 622
    iget-object v5, p0, LO6/d;->M:Ljava/lang/CharSequence;

    .line 623
    .line 624
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 625
    .line 626
    .line 627
    iget-object v3, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 628
    .line 629
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 630
    .line 631
    .line 632
    :cond_15
    :goto_6
    iget-object v3, p0, LO6/d;->M:Ljava/lang/CharSequence;

    .line 633
    .line 634
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 635
    .line 636
    .line 637
    move-result v3

    .line 638
    if-eqz v3, :cond_16

    .line 639
    .line 640
    iget-object v3, p0, LO6/d;->L:Ljava/lang/String;

    .line 641
    .line 642
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 643
    .line 644
    .line 645
    move-result v3

    .line 646
    if-eqz v3, :cond_16

    .line 647
    .line 648
    iget-object v3, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 649
    .line 650
    invoke-virtual {v3, v6}, Landroid/view/View;->setVisibility(I)V

    .line 651
    .line 652
    .line 653
    :cond_16
    sget v3, LL6/f;->tv_title_2:I

    .line 654
    .line 655
    invoke-virtual {p0, v3}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 656
    .line 657
    .line 658
    move-result-object v3

    .line 659
    if-eqz v3, :cond_17

    .line 660
    .line 661
    iget-object v5, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 662
    .line 663
    if-eq v5, v3, :cond_17

    .line 664
    .line 665
    const/high16 v5, 0x42000000    # 32.0f

    .line 666
    .line 667
    invoke-static {p1, v5}, Le1/a;->j(Landroid/content/Context;F)I

    .line 668
    .line 669
    .line 670
    move-result v5

    .line 671
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 672
    .line 673
    .line 674
    move-result-object v7

    .line 675
    check-cast v7, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 676
    .line 677
    iput v5, v7, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 678
    .line 679
    invoke-virtual {v3, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 680
    .line 681
    .line 682
    :cond_17
    iget-object v3, p0, LO6/d;->o:Landroid/widget/ImageView;

    .line 683
    .line 684
    iget-boolean v5, p0, LO6/d;->s0:Z

    .line 685
    .line 686
    if-eqz v5, :cond_18

    .line 687
    .line 688
    goto :goto_7

    .line 689
    :cond_18
    move v2, v1

    .line 690
    :goto_7
    invoke-virtual {v3, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 691
    .line 692
    .line 693
    iget-object v2, p0, LO6/d;->Z:Ljava/lang/String;

    .line 694
    .line 695
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 696
    .line 697
    .line 698
    move-result v2

    .line 699
    if-eqz v2, :cond_19

    .line 700
    .line 701
    iget-object v2, p0, LO6/d;->i:Landroid/widget/TextView;

    .line 702
    .line 703
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 704
    .line 705
    .line 706
    iget-object v2, p0, LO6/d;->B:Landroid/view/View;

    .line 707
    .line 708
    if-eqz v2, :cond_1a

    .line 709
    .line 710
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 711
    .line 712
    .line 713
    goto :goto_8

    .line 714
    :cond_19
    iget-object v2, p0, LO6/d;->i:Landroid/widget/TextView;

    .line 715
    .line 716
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 717
    .line 718
    .line 719
    iget-object v2, p0, LO6/d;->i:Landroid/widget/TextView;

    .line 720
    .line 721
    iget-object v3, p0, LO6/d;->Z:Ljava/lang/String;

    .line 722
    .line 723
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 724
    .line 725
    .line 726
    iget-object v2, p0, LO6/d;->i:Landroid/widget/TextView;

    .line 727
    .line 728
    new-instance v3, LO6/b;

    .line 729
    .line 730
    const/4 v5, 0x1

    .line 731
    invoke-direct {v3, p0, v5}, LO6/b;-><init>(LO6/d;I)V

    .line 732
    .line 733
    .line 734
    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 735
    .line 736
    .line 737
    :cond_1a
    :goto_8
    iget-object v2, p0, LO6/d;->k0:Ljava/lang/String;

    .line 738
    .line 739
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 740
    .line 741
    .line 742
    move-result v2

    .line 743
    if-eqz v2, :cond_1b

    .line 744
    .line 745
    iget-object v2, p0, LO6/d;->j:Landroid/widget/TextView;

    .line 746
    .line 747
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 748
    .line 749
    .line 750
    iget-object v2, p0, LO6/d;->B:Landroid/view/View;

    .line 751
    .line 752
    if-eqz v2, :cond_1c

    .line 753
    .line 754
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 755
    .line 756
    .line 757
    goto :goto_9

    .line 758
    :cond_1b
    iget-object v2, p0, LO6/d;->j:Landroid/widget/TextView;

    .line 759
    .line 760
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 761
    .line 762
    .line 763
    iget-object v2, p0, LO6/d;->j:Landroid/widget/TextView;

    .line 764
    .line 765
    iget-object v3, p0, LO6/d;->k0:Ljava/lang/String;

    .line 766
    .line 767
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 768
    .line 769
    .line 770
    iget-object v2, p0, LO6/d;->j:Landroid/widget/TextView;

    .line 771
    .line 772
    new-instance v3, LO6/b;

    .line 773
    .line 774
    const/4 v5, 0x2

    .line 775
    invoke-direct {v3, p0, v5}, LO6/b;-><init>(LO6/d;I)V

    .line 776
    .line 777
    .line 778
    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 779
    .line 780
    .line 781
    :cond_1c
    :goto_9
    iget-object v2, p0, LO6/d;->Z:Ljava/lang/String;

    .line 782
    .line 783
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 784
    .line 785
    .line 786
    move-result v2

    .line 787
    if-eqz v2, :cond_1d

    .line 788
    .line 789
    iget-object v2, p0, LO6/d;->k0:Ljava/lang/String;

    .line 790
    .line 791
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 792
    .line 793
    .line 794
    move-result v2

    .line 795
    if-eqz v2, :cond_1d

    .line 796
    .line 797
    iget-object v2, p0, LO6/d;->C:Landroid/view/View;

    .line 798
    .line 799
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 800
    .line 801
    .line 802
    :cond_1d
    iget v2, p0, LO6/d;->t0:I

    .line 803
    .line 804
    const/high16 v3, 0x41000000    # 8.0f

    .line 805
    .line 806
    if-lez v2, :cond_1e

    .line 807
    .line 808
    iget-object v2, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 809
    .line 810
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 811
    .line 812
    .line 813
    iget-object v2, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 814
    .line 815
    iget v5, p0, LO6/d;->t0:I

    .line 816
    .line 817
    invoke-virtual {v2, v5}, Landroidx/appcompat/widget/AppCompatImageView;->setImageResource(I)V

    .line 818
    .line 819
    .line 820
    invoke-virtual {p0}, LO6/d;->d()Z

    .line 821
    .line 822
    .line 823
    move-result v2

    .line 824
    if-eqz v2, :cond_21

    .line 825
    .line 826
    iget-object v2, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 827
    .line 828
    invoke-static {p1, v3}, Le1/a;->j(Landroid/content/Context;F)I

    .line 829
    .line 830
    .line 831
    move-result p1

    .line 832
    invoke-static {p1, v2}, LO6/d;->e(ILandroid/view/View;)V

    .line 833
    .line 834
    .line 835
    goto :goto_a

    .line 836
    :cond_1e
    iget-object v2, p0, LO6/d;->v0:Landroid/graphics/drawable/Drawable;

    .line 837
    .line 838
    if-eqz v2, :cond_1f

    .line 839
    .line 840
    iget-object v2, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 841
    .line 842
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 843
    .line 844
    .line 845
    iget-object v2, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 846
    .line 847
    iget-object v5, p0, LO6/d;->v0:Landroid/graphics/drawable/Drawable;

    .line 848
    .line 849
    invoke-virtual {v2, v5}, Landroidx/appcompat/widget/AppCompatImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 850
    .line 851
    .line 852
    invoke-virtual {p0}, LO6/d;->d()Z

    .line 853
    .line 854
    .line 855
    move-result v2

    .line 856
    if-eqz v2, :cond_21

    .line 857
    .line 858
    iget-object v2, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 859
    .line 860
    invoke-static {p1, v3}, Le1/a;->j(Landroid/content/Context;F)I

    .line 861
    .line 862
    .line 863
    move-result p1

    .line 864
    invoke-static {p1, v2}, LO6/d;->e(ILandroid/view/View;)V

    .line 865
    .line 866
    .line 867
    goto :goto_a

    .line 868
    :cond_1f
    iget-object v2, p0, LO6/d;->w0:Ljava/lang/String;

    .line 869
    .line 870
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 871
    .line 872
    .line 873
    move-result v2

    .line 874
    if-nez v2, :cond_20

    .line 875
    .line 876
    iget-object v2, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 877
    .line 878
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 879
    .line 880
    .line 881
    iget-object v2, p0, LO6/a;->a:Landroid/content/Context;

    .line 882
    .line 883
    iget-object v5, p0, LO6/d;->w0:Ljava/lang/String;

    .line 884
    .line 885
    iget-object v7, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 886
    .line 887
    invoke-static {v2, v5, v7, v1}, Le1/a;->N(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;I)V

    .line 888
    .line 889
    .line 890
    invoke-virtual {p0}, LO6/d;->d()Z

    .line 891
    .line 892
    .line 893
    move-result v2

    .line 894
    if-eqz v2, :cond_21

    .line 895
    .line 896
    iget-object v2, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 897
    .line 898
    invoke-static {p1, v3}, Le1/a;->j(Landroid/content/Context;F)I

    .line 899
    .line 900
    .line 901
    move-result p1

    .line 902
    invoke-static {p1, v2}, LO6/d;->e(ILandroid/view/View;)V

    .line 903
    .line 904
    .line 905
    goto :goto_a

    .line 906
    :cond_20
    iget-object p1, p0, LO6/d;->p:Landroidx/appcompat/widget/AppCompatImageView;

    .line 907
    .line 908
    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 909
    .line 910
    .line 911
    :cond_21
    :goto_a
    iget-object p1, p0, LO6/d;->z0:Ljava/lang/String;

    .line 912
    .line 913
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 914
    .line 915
    .line 916
    move-result p1

    .line 917
    if-nez p1, :cond_25

    .line 918
    .line 919
    iget p1, p0, LO6/d;->t0:I

    .line 920
    .line 921
    if-gtz p1, :cond_25

    .line 922
    .line 923
    iget-object p1, p0, LO6/d;->v0:Landroid/graphics/drawable/Drawable;

    .line 924
    .line 925
    if-nez p1, :cond_25

    .line 926
    .line 927
    iget-object p1, p0, LO6/d;->w0:Ljava/lang/String;

    .line 928
    .line 929
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 930
    .line 931
    .line 932
    move-result p1

    .line 933
    if-nez p1, :cond_22

    .line 934
    .line 935
    goto :goto_b

    .line 936
    :cond_22
    iget-object p1, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 937
    .line 938
    if-nez p1, :cond_23

    .line 939
    .line 940
    invoke-virtual {p0}, LO6/d;->c()V

    .line 941
    .line 942
    .line 943
    :cond_23
    iget-object p1, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 944
    .line 945
    if-eqz p1, :cond_26

    .line 946
    .line 947
    iget-object p1, p0, LO6/d;->z0:Ljava/lang/String;

    .line 948
    .line 949
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 950
    .line 951
    .line 952
    move-result p1

    .line 953
    if-nez p1, :cond_24

    .line 954
    .line 955
    iget-object p1, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 956
    .line 957
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 958
    .line 959
    .line 960
    iget-object p1, p0, LO6/a;->a:Landroid/content/Context;

    .line 961
    .line 962
    invoke-static {p1}, Le1/a;->y(Landroid/content/Context;)I

    .line 963
    .line 964
    .line 965
    move-result p1

    .line 966
    iget-object v2, p0, LO6/a;->a:Landroid/content/Context;

    .line 967
    .line 968
    iget-object v3, p0, LO6/d;->z0:Ljava/lang/String;

    .line 969
    .line 970
    iget-object v5, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 971
    .line 972
    invoke-static {v2, v3, v5, p1}, Le1/a;->N(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;I)V

    .line 973
    .line 974
    .line 975
    :cond_24
    iget-object p1, p0, LO6/d;->f:Lorg/sufficientlysecure/htmltextview/HtmlTextView;

    .line 976
    .line 977
    iget-object v2, p0, LO6/a;->a:Landroid/content/Context;

    .line 978
    .line 979
    const/high16 v3, 0x41800000    # 16.0f

    .line 980
    .line 981
    invoke-static {v2, v3}, Le1/a;->j(Landroid/content/Context;F)I

    .line 982
    .line 983
    .line 984
    move-result v2

    .line 985
    invoke-static {v2, p1}, LO6/d;->e(ILandroid/view/View;)V

    .line 986
    .line 987
    .line 988
    goto :goto_c

    .line 989
    :cond_25
    :goto_b
    iget-object p1, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 990
    .line 991
    if-eqz p1, :cond_26

    .line 992
    .line 993
    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 994
    .line 995
    .line 996
    :cond_26
    :goto_c
    iget p1, p0, LO6/d;->u0:I

    .line 997
    .line 998
    if-gtz p1, :cond_28

    .line 999
    .line 1000
    iget-object p1, p0, LO6/d;->x0:Landroid/graphics/drawable/Drawable;

    .line 1001
    .line 1002
    if-nez p1, :cond_28

    .line 1003
    .line 1004
    iget-object p1, p0, LO6/d;->y0:Ljava/lang/String;

    .line 1005
    .line 1006
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1007
    .line 1008
    .line 1009
    move-result p1

    .line 1010
    if-nez p1, :cond_27

    .line 1011
    .line 1012
    goto :goto_d

    .line 1013
    :cond_27
    iget-object p1, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1014
    .line 1015
    if-eqz p1, :cond_2c

    .line 1016
    .line 1017
    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 1018
    .line 1019
    .line 1020
    goto :goto_e

    .line 1021
    :cond_28
    :goto_d
    iget-object p1, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1022
    .line 1023
    if-nez p1, :cond_29

    .line 1024
    .line 1025
    invoke-virtual {p0}, LO6/d;->b()V

    .line 1026
    .line 1027
    .line 1028
    :cond_29
    iget-object p1, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1029
    .line 1030
    if-eqz p1, :cond_2c

    .line 1031
    .line 1032
    iget v2, p0, LO6/d;->u0:I

    .line 1033
    .line 1034
    if-lez v2, :cond_2a

    .line 1035
    .line 1036
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1037
    .line 1038
    .line 1039
    iget-object p1, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1040
    .line 1041
    iget v2, p0, LO6/d;->u0:I

    .line 1042
    .line 1043
    invoke-virtual {p1, v2}, Landroidx/appcompat/widget/AppCompatImageView;->setImageResource(I)V

    .line 1044
    .line 1045
    .line 1046
    goto :goto_e

    .line 1047
    :cond_2a
    iget-object v2, p0, LO6/d;->x0:Landroid/graphics/drawable/Drawable;

    .line 1048
    .line 1049
    if-eqz v2, :cond_2b

    .line 1050
    .line 1051
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1052
    .line 1053
    .line 1054
    iget-object p1, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1055
    .line 1056
    iget-object v2, p0, LO6/d;->x0:Landroid/graphics/drawable/Drawable;

    .line 1057
    .line 1058
    invoke-virtual {p1, v2}, Landroidx/appcompat/widget/AppCompatImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1059
    .line 1060
    .line 1061
    goto :goto_e

    .line 1062
    :cond_2b
    iget-object p1, p0, LO6/d;->y0:Ljava/lang/String;

    .line 1063
    .line 1064
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1065
    .line 1066
    .line 1067
    move-result p1

    .line 1068
    if-nez p1, :cond_2c

    .line 1069
    .line 1070
    iget-object p1, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1071
    .line 1072
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1073
    .line 1074
    .line 1075
    iget-object p1, p0, LO6/a;->a:Landroid/content/Context;

    .line 1076
    .line 1077
    invoke-static {p1}, Le1/a;->y(Landroid/content/Context;)I

    .line 1078
    .line 1079
    .line 1080
    move-result p1

    .line 1081
    iget-object v2, p0, LO6/a;->a:Landroid/content/Context;

    .line 1082
    .line 1083
    iget-object v3, p0, LO6/d;->y0:Ljava/lang/String;

    .line 1084
    .line 1085
    iget-object v5, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1086
    .line 1087
    invoke-static {v2, v3, v5, p1}, Le1/a;->N(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;I)V

    .line 1088
    .line 1089
    .line 1090
    :cond_2c
    :goto_e
    iget-object p1, p0, LO6/d;->w:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1091
    .line 1092
    if-eqz p1, :cond_2e

    .line 1093
    .line 1094
    if-nez v0, :cond_2d

    .line 1095
    .line 1096
    iget-object p1, p0, LO6/d;->B0:Ljava/lang/String;

    .line 1097
    .line 1098
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1099
    .line 1100
    .line 1101
    move-result p1

    .line 1102
    if-nez p1, :cond_2e

    .line 1103
    .line 1104
    iget-object p1, p0, LO6/d;->w:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1105
    .line 1106
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1107
    .line 1108
    .line 1109
    iget-object p1, p0, LO6/a;->a:Landroid/content/Context;

    .line 1110
    .line 1111
    invoke-static {p1}, Le1/a;->y(Landroid/content/Context;)I

    .line 1112
    .line 1113
    .line 1114
    iget-object p1, p0, LO6/a;->a:Landroid/content/Context;

    .line 1115
    .line 1116
    iget-object v0, p0, LO6/d;->B0:Ljava/lang/String;

    .line 1117
    .line 1118
    iget-object v2, p0, LO6/d;->w:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1119
    .line 1120
    invoke-static {p1, v0, v2, v1}, Le1/a;->N(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;I)V

    .line 1121
    .line 1122
    .line 1123
    goto :goto_f

    .line 1124
    :cond_2d
    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 1125
    .line 1126
    .line 1127
    :cond_2e
    :goto_f
    iget-object p1, p0, LO6/d;->A:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1128
    .line 1129
    if-eqz p1, :cond_30

    .line 1130
    .line 1131
    if-eqz v4, :cond_2f

    .line 1132
    .line 1133
    iget-object p1, p0, LO6/d;->A0:Ljava/lang/String;

    .line 1134
    .line 1135
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1136
    .line 1137
    .line 1138
    move-result p1

    .line 1139
    if-nez p1, :cond_30

    .line 1140
    .line 1141
    iget-object p1, p0, LO6/d;->A:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1142
    .line 1143
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1144
    .line 1145
    .line 1146
    iget-object p1, p0, LO6/a;->a:Landroid/content/Context;

    .line 1147
    .line 1148
    invoke-static {p1}, Le1/a;->y(Landroid/content/Context;)I

    .line 1149
    .line 1150
    .line 1151
    move-result p1

    .line 1152
    iget-object v0, p0, LO6/a;->a:Landroid/content/Context;

    .line 1153
    .line 1154
    iget-object v2, p0, LO6/d;->A0:Ljava/lang/String;

    .line 1155
    .line 1156
    iget-object v3, p0, LO6/d;->A:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1157
    .line 1158
    invoke-static {v0, v2, v3, p1}, Le1/a;->N(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;I)V

    .line 1159
    .line 1160
    .line 1161
    goto :goto_10

    .line 1162
    :cond_2f
    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 1163
    .line 1164
    .line 1165
    :cond_30
    :goto_10
    iget-object p1, p0, LO6/d;->d:Landroid/view/View;

    .line 1166
    .line 1167
    if-eqz p1, :cond_31

    .line 1168
    .line 1169
    iget-object v0, p0, LO6/d;->e:Landroid/widget/LinearLayout;

    .line 1170
    .line 1171
    if-eqz v0, :cond_31

    .line 1172
    .line 1173
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 1174
    .line 1175
    const/4 v3, -0x1

    .line 1176
    const/4 v4, -0x2

    .line 1177
    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1178
    .line 1179
    .line 1180
    invoke-virtual {v0, p1, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 1181
    .line 1182
    .line 1183
    iget-object p1, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 1184
    .line 1185
    if-eqz p1, :cond_31

    .line 1186
    .line 1187
    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 1188
    .line 1189
    .line 1190
    :cond_31
    iget-object p1, p0, LO6/d;->d:Landroid/view/View;

    .line 1191
    .line 1192
    if-nez p1, :cond_32

    .line 1193
    .line 1194
    iget-object p1, p0, LO6/d;->e:Landroid/widget/LinearLayout;

    .line 1195
    .line 1196
    if-eqz p1, :cond_32

    .line 1197
    .line 1198
    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 1199
    .line 1200
    .line 1201
    :cond_32
    return-void
.end method

.method public final b()V
    .locals 1

    .line 1
    iget-object v0, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    sget v0, LL6/f;->iv_big_icon:I

    .line 7
    .line 8
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Landroidx/appcompat/widget/AppCompatImageView;

    .line 13
    .line 14
    iput-object v0, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    sget v0, LL6/f;->bigIconStub:I

    .line 20
    .line 21
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/view/ViewStub;

    .line 26
    .line 27
    if-eqz v0, :cond_2

    .line 28
    .line 29
    invoke-virtual {v0}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 30
    .line 31
    .line 32
    sget v0, LL6/f;->iv_big_icon:I

    .line 33
    .line 34
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroidx/appcompat/widget/AppCompatImageView;

    .line 39
    .line 40
    iput-object v0, p0, LO6/d;->t:Landroidx/appcompat/widget/AppCompatImageView;

    .line 41
    .line 42
    :cond_2
    :goto_0
    return-void
.end method

.method public final c()V
    .locals 1

    .line 1
    iget-object v0, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    sget v0, LL6/f;->ivSecondHeader:I

    .line 7
    .line 8
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Landroidx/appcompat/widget/AppCompatImageView;

    .line 13
    .line 14
    iput-object v0, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    sget v0, LL6/f;->secondHeaderStub:I

    .line 20
    .line 21
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/view/ViewStub;

    .line 26
    .line 27
    if-eqz v0, :cond_2

    .line 28
    .line 29
    invoke-virtual {v0}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    .line 30
    .line 31
    .line 32
    sget v0, LL6/f;->ivSecondHeader:I

    .line 33
    .line 34
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroidx/appcompat/widget/AppCompatImageView;

    .line 39
    .line 40
    iput-object v0, p0, LO6/d;->v:Landroidx/appcompat/widget/AppCompatImageView;

    .line 41
    .line 42
    :cond_2
    :goto_0
    return-void
.end method

.method public final d()Z
    .locals 2

    .line 1
    iget v0, p0, LO6/d;->C0:I

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    if-eq v0, v1, :cond_1

    .line 5
    .line 6
    const/4 v1, 0x4

    .line 7
    if-ne v0, v1, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    return v0

    .line 12
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 13
    return v0
.end method

.method public final onDetachedFromWindow()V
    .locals 0

    .line 1
    invoke-super {p0}, Landroid/app/Dialog;->onDetachedFromWindow()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final setCancelable(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 2
    .line 3
    .line 4
    xor-int/lit8 p1, p1, 0x1

    .line 5
    .line 6
    iput-boolean p1, p0, LO6/d;->s0:Z

    .line 7
    .line 8
    return-void
.end method

.method public final setTitle(Ljava/lang/CharSequence;)V
    .locals 0

    .line 1
    iput-object p1, p0, LO6/d;->M:Ljava/lang/CharSequence;

    .line 2
    .line 3
    return-void
.end method

.method public final show()V
    .locals 2

    .line 1
    iget-object v0, p0, LO6/a;->a:Landroid/content/Context;

    .line 2
    .line 3
    instance-of v1, v0, Landroid/app/Activity;

    .line 4
    .line 5
    if-eqz v1, :cond_1

    .line 6
    .line 7
    check-cast v0, Landroid/app/Activity;

    .line 8
    .line 9
    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-nez v1, :cond_0

    .line 14
    .line 15
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    :cond_0
    return-void

    .line 22
    :cond_1
    invoke-super {p0}, LO6/f;->show()V

    .line 23
    .line 24
    .line 25
    iget v0, p0, LO6/d;->C0:I

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    if-eq v0, v1, :cond_2

    .line 29
    .line 30
    const/4 v1, 0x4

    .line 31
    if-ne v0, v1, :cond_3

    .line 32
    .line 33
    :cond_2
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {p0, v0}, LO6/a;->showAtBottom(Landroid/view/Window;)V

    .line 38
    .line 39
    .line 40
    :cond_3
    return-void
.end method
