.class public final Lx5/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:J

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:I

.field public final f:I

.field public final g:I

.field public final h:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    iput-wide v0, p0, Lx5/a;->b:J

    .line 9
    .line 10
    iput-object p2, p0, Lx5/a;->a:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p4, p0, Lx5/a;->c:Ljava/lang/String;

    .line 13
    .line 14
    const-string p2, "3.3.6"

    .line 15
    .line 16
    iput-object p2, p0, Lx5/a;->d:Ljava/lang/String;

    .line 17
    .line 18
    const/16 p2, 0x7662

    .line 19
    .line 20
    iput p2, p0, Lx5/a;->e:I

    .line 21
    .line 22
    iput p1, p0, Lx5/a;->f:I

    .line 23
    .line 24
    iput p3, p0, Lx5/a;->g:I

    .line 25
    .line 26
    iput-object p5, p0, Lx5/a;->h:Ljava/lang/String;

    .line 27
    .line 28
    return-void
.end method

.method public static a()Lx5/a;
    .locals 8

    .line 1
    invoke-static {}, Lcom/growingio/android/sdk/d;->a()Lcom/growingio/android/sdk/d;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {}, Ls5/d;->b()Ls5/d;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-object v1, v1, Ls5/d;->b:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Lcom/growingio/android/sdk/a;

    .line 16
    .line 17
    iget-object v4, v1, Lcom/growingio/android/sdk/a;->a:Ljava/lang/String;

    .line 18
    .line 19
    sget-object v1, Ls5/c;->a:LE2/a;

    .line 20
    .line 21
    invoke-virtual {v1}, LE2/a;->d()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    invoke-static {v0}, Lt5/b;->b(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {}, Ls5/d;->b()Ls5/d;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    iget-object v1, v1, Ls5/d;->b:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, Lcom/growingio/android/sdk/a;

    .line 36
    .line 37
    iget-object v7, v1, Lcom/growingio/android/sdk/a;->b:Ljava/lang/String;

    .line 38
    .line 39
    new-instance v2, Lx5/a;

    .line 40
    .line 41
    iget v3, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 42
    .line 43
    iget v5, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 44
    .line 45
    invoke-direct/range {v2 .. v7}, Lx5/a;-><init>(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    return-object v2
.end method


# virtual methods
.method public final b()Lorg/json/JSONObject;
    .locals 4

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    .line 2
    .line 3
    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 4
    .line 5
    .line 6
    :try_start_0
    const-string v1, "projectId"

    .line 7
    .line 8
    iget-object v2, p0, Lx5/a;->a:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 11
    .line 12
    .line 13
    const-string v1, "msgType"

    .line 14
    .line 15
    const-string v2, "ready"

    .line 16
    .line 17
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 18
    .line 19
    .line 20
    const-string v1, "timestamp"

    .line 21
    .line 22
    iget-wide v2, p0, Lx5/a;->b:J

    .line 23
    .line 24
    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 25
    .line 26
    .line 27
    const-string v1, "domain"

    .line 28
    .line 29
    iget-object v2, p0, Lx5/a;->c:Ljava/lang/String;

    .line 30
    .line 31
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 32
    .line 33
    .line 34
    const-string v1, "sdkVersion"

    .line 35
    .line 36
    iget-object v2, p0, Lx5/a;->d:Ljava/lang/String;

    .line 37
    .line 38
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 39
    .line 40
    .line 41
    const-string v1, "sdkVersionCode"

    .line 42
    .line 43
    iget v2, p0, Lx5/a;->e:I

    .line 44
    .line 45
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 46
    .line 47
    .line 48
    const-string v1, "os"

    .line 49
    .line 50
    const-string v2, "Android"

    .line 51
    .line 52
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 53
    .line 54
    .line 55
    const-string v1, "screenWidth"

    .line 56
    .line 57
    iget v2, p0, Lx5/a;->f:I

    .line 58
    .line 59
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 60
    .line 61
    .line 62
    const-string v1, "screenHeight"

    .line 63
    .line 64
    iget v2, p0, Lx5/a;->g:I

    .line 65
    .line 66
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 67
    .line 68
    .line 69
    const-string v1, "urlScheme"

    .line 70
    .line 71
    iget-object v2, p0, Lx5/a;->h:Ljava/lang/String;

    .line 72
    .line 73
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 74
    .line 75
    .line 76
    const-string v1, "READY MESSAGE"

    .line 77
    .line 78
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    const/4 v3, 0x0

    .line 83
    new-array v3, v3, [Ljava/lang/Object;

    .line 84
    .line 85
    invoke-static {v1, v2, v3}, Ln5/h;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 86
    .line 87
    .line 88
    :catch_0
    return-object v0
.end method
