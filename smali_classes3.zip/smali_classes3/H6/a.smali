.class public abstract LH6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/didi/drouter/router/RouterCallback;
