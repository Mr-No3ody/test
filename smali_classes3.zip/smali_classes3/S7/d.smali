.class public final LS7/d;
.super Lcom/facebook/imagepipeline/nativecode/b;
.source "SourceFile"


# instance fields
.field public final f:Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreen;


# direct methods
.method public constructor <init>(Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreen;)V
    .locals 1

    .line 1
    const-string v0, "screen"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LS7/d;->f:Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreen;

    .line 10
    .line 11
    return-void
.end method
