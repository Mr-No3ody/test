.class public final LS7/a;
.super LS7/b;
.source "SourceFile"


# instance fields
.field public final a:Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenFragment;

.field public final b:I

.field public final c:Z


# direct methods
.method public constructor <init>(Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenFragment;IZ)V
    .locals 1

    .line 1
    const-string v0, "fragment"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LS7/a;->a:Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenFragment;

    .line 10
    .line 11
    iput p2, p0, LS7/a;->b:I

    .line 12
    .line 13
    iput-boolean p3, p0, LS7/a;->c:Z

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final a(Landroidx/fragment/app/Z;Ld3/j;)V
    .locals 3

    .line 1
    const-string v0, "fragmentManager"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v1, "executor"

    .line 7
    .line 8
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const-string p2, "op"

    .line 18
    .line 19
    invoke-static {p0, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const-string p2, "<this>"

    .line 23
    .line 24
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    new-instance p2, Landroidx/fragment/app/a;

    .line 28
    .line 29
    invoke-direct {p2, p1}, Landroidx/fragment/app/a;-><init>(Landroidx/fragment/app/Z;)V

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x1

    .line 33
    iput-boolean p1, p2, Landroidx/fragment/app/k0;->p:Z

    .line 34
    .line 35
    const-string v0, "setReorderingAllowed(...)"

    .line 36
    .line 37
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    iget-object v0, p0, LS7/a;->a:Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenFragment;

    .line 41
    .line 42
    const/4 v1, 0x0

    .line 43
    iget v2, p0, LS7/a;->b:I

    .line 44
    .line 45
    invoke-virtual {p2, v2, v0, v1, p1}, Landroidx/fragment/app/a;->d(ILandroidx/fragment/app/Fragment;Ljava/lang/String;I)V

    .line 46
    .line 47
    .line 48
    iget-boolean v1, p0, LS7/a;->c:Z

    .line 49
    .line 50
    if-eqz v1, :cond_0

    .line 51
    .line 52
    iget-object v0, v0, Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreenFragment;->a:Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreen;

    .line 53
    .line 54
    invoke-virtual {v0}, Lcom/swmansion/rnscreens/gamma/stack/screen/StackScreen;->getScreenKey()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-virtual {p2, v0}, Landroidx/fragment/app/k0;->c(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    :cond_0
    invoke-virtual {p2, p1}, Landroidx/fragment/app/a;->h(Z)I

    .line 62
    .line 63
    .line 64
    return-void
.end method
