.class public final Lq5/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Class;

.field public final b:Ljava/lang/Class;

.field public final c:Lcom/growingio/android/sdk/track/modelloader/ModelLoaderFactory;


# direct methods
.method public constructor <init>(Ljava/lang/Class;Ljava/lang/Class;Lcom/growingio/android/sdk/track/modelloader/ModelLoaderFactory;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lq5/b;->a:Ljava/lang/Class;

    .line 5
    .line 6
    iput-object p2, p0, Lq5/b;->b:Ljava/lang/Class;

    .line 7
    .line 8
    iput-object p3, p0, Lq5/b;->c:Lcom/growingio/android/sdk/track/modelloader/ModelLoaderFactory;

    .line 9
    .line 10
    return-void
.end method
