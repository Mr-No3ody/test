.class public final Lq5/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lcom/growingio/android/sdk/track/modelloader/DataFetcher;


# direct methods
.method public constructor <init>(Lcom/growingio/android/sdk/track/modelloader/DataFetcher;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lq5/a;->a:Lcom/growingio/android/sdk/track/modelloader/DataFetcher;

    .line 5
    .line 6
    return-void
.end method
