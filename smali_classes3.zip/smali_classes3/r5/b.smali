.class public final Lr5/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroid/view/View;

.field public final b:Lcom/growingio/android/sdk/track/modelloader/data/HybridDom$OnDomChangedListener;


# direct methods
.method public constructor <init>(Lcom/growingio/android/sdk/track/modelloader/data/HybridDom$OnDomChangedListener;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lr5/b;->b:Lcom/growingio/android/sdk/track/modelloader/data/HybridDom$OnDomChangedListener;

    .line 5
    .line 6
    return-void
.end method
