.class public abstract Lr5/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static C(Landroid/widget/EdgeEffect;FF)F
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1f

    .line 4
    .line 5
    if-lt v0, v1, :cond_0

    .line 6
    .line 7
    invoke-static {p0, p1, p2}, Landroidx/core/widget/d;->c(Landroid/widget/EdgeEffect;FF)F

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_0
    invoke-static {p0, p1, p2}, Landroidx/core/widget/c;->a(Landroid/widget/EdgeEffect;FF)V

    .line 13
    .line 14
    .line 15
    return p1
.end method

.method public static D(Lk1/a;Landroid/media/MediaCodec$BufferInfo;Landroid/media/MediaExtractor;)V
    .locals 11

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {p2, v0}, Lorg/chromium/support_lib_boundary/util/b;->w(Landroid/media/MediaExtractor;Z)I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    if-ltz v1, :cond_6

    .line 7
    .line 8
    invoke-virtual {p2, v1}, Landroid/media/MediaExtractor;->selectTrack(I)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p2, v1}, Landroid/media/MediaExtractor;->getTrackFormat(I)Landroid/media/MediaFormat;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    const-string v3, "extractor.getTrackFormat(audioIndex)"

    .line 16
    .line 17
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    const/4 v3, 0x1

    .line 21
    invoke-virtual {p0, v2, v3}, Lk1/a;->a(Landroid/media/MediaFormat;Z)I

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    const-string v5, "max-input-size"

    .line 26
    .line 27
    invoke-virtual {v2, v5}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    if-gtz v2, :cond_0

    .line 32
    .line 33
    const/high16 v2, 0x10000

    .line 34
    .line 35
    :cond_0
    invoke-static {v2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    const-string v6, "allocateDirect(maxBufferSize)"

    .line 40
    .line 41
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 45
    .line 46
    const/16 v8, 0x1c

    .line 47
    .line 48
    if-lt v7, v8, :cond_1

    .line 49
    .line 50
    invoke-static {p2}, Lcom/facebook/react/uimanager/a;->b(Landroid/media/MediaExtractor;)J

    .line 51
    .line 52
    .line 53
    move-result-wide v7

    .line 54
    int-to-long v9, v2

    .line 55
    cmp-long v2, v7, v9

    .line 56
    .line 57
    if-lez v2, :cond_1

    .line 58
    .line 59
    const/16 v2, 0x400

    .line 60
    .line 61
    int-to-long v9, v2

    .line 62
    add-long/2addr v7, v9

    .line 63
    long-to-int v2, v7

    .line 64
    invoke-static {v2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    .line 65
    .line 66
    .line 67
    move-result-object v5

    .line 68
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    :cond_1
    const-wide/16 v6, 0x0

    .line 72
    .line 73
    invoke-virtual {p2, v6, v7, v0}, Landroid/media/MediaExtractor;->seekTo(JI)V

    .line 74
    .line 75
    .line 76
    move v2, v0

    .line 77
    :cond_2
    :goto_0
    if-nez v2, :cond_5

    .line 78
    .line 79
    invoke-virtual {p2}, Landroid/media/MediaExtractor;->getSampleTrackIndex()I

    .line 80
    .line 81
    .line 82
    move-result v6

    .line 83
    if-ne v6, v1, :cond_4

    .line 84
    .line 85
    invoke-virtual {p2, v5, v0}, Landroid/media/MediaExtractor;->readSampleData(Ljava/nio/ByteBuffer;I)I

    .line 86
    .line 87
    .line 88
    move-result v6

    .line 89
    iput v6, p1, Landroid/media/MediaCodec$BufferInfo;->size:I

    .line 90
    .line 91
    if-ltz v6, :cond_3

    .line 92
    .line 93
    invoke-virtual {p2}, Landroid/media/MediaExtractor;->getSampleTime()J

    .line 94
    .line 95
    .line 96
    move-result-wide v6

    .line 97
    iput-wide v6, p1, Landroid/media/MediaCodec$BufferInfo;->presentationTimeUs:J

    .line 98
    .line 99
    iput v0, p1, Landroid/media/MediaCodec$BufferInfo;->offset:I

    .line 100
    .line 101
    iput v3, p1, Landroid/media/MediaCodec$BufferInfo;->flags:I

    .line 102
    .line 103
    invoke-virtual {p0, v4, v5, p1, v3}, Lk1/a;->g(ILjava/nio/ByteBuffer;Landroid/media/MediaCodec$BufferInfo;Z)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {p2}, Landroid/media/MediaExtractor;->advance()Z

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_3
    iput v0, p1, Landroid/media/MediaCodec$BufferInfo;->size:I

    .line 111
    .line 112
    :goto_1
    move v2, v3

    .line 113
    goto :goto_0

    .line 114
    :cond_4
    const/4 v7, -0x1

    .line 115
    if-ne v6, v7, :cond_2

    .line 116
    .line 117
    goto :goto_1

    .line 118
    :cond_5
    invoke-virtual {p2, v1}, Landroid/media/MediaExtractor;->unselectTrack(I)V

    .line 119
    .line 120
    .line 121
    :cond_6
    return-void
.end method

.method public static final E(Ljava/io/Reader;)Ljava/lang/String;
    .locals 4

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v1, Ljava/io/StringWriter;

    .line 7
    .line 8
    invoke-direct {v1}, Ljava/io/StringWriter;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v0, "out"

    .line 15
    .line 16
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const/16 v0, 0x2000

    .line 20
    .line 21
    new-array v0, v0, [C

    .line 22
    .line 23
    invoke-virtual {p0, v0}, Ljava/io/Reader;->read([C)I

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    :goto_0
    if-ltz v2, :cond_0

    .line 28
    .line 29
    const/4 v3, 0x0

    .line 30
    invoke-virtual {v1, v0, v3, v2}, Ljava/io/Writer;->write([CII)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p0, v0}, Ljava/io/Reader;->read([C)I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    invoke-virtual {v1}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    const-string v0, "toString(...)"

    .line 43
    .line 44
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    return-object p0
.end method

.method public static F(Ljava/io/Closeable;)V
    .locals 1

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    :try_start_0
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :catch_0
    const-string p0, "StreamableVideo"

    .line 8
    .line 9
    const-string v0, "Failed to close file: "

    .line 10
    .line 11
    invoke-static {p0, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
.end method

.method public static G(Ljava/io/File;Ljava/io/File;)Z
    .locals 4

    .line 1
    const-string v0, "out"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    :try_start_0
    new-instance v1, Ljava/io/FileInputStream;

    .line 8
    .line 9
    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 10
    .line 11
    .line 12
    :try_start_1
    invoke-virtual {v1}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    new-instance v2, Ljava/io/FileOutputStream;

    .line 17
    .line 18
    invoke-direct {v2, p1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 19
    .line 20
    .line 21
    :try_start_2
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    const-string v3, "infile"

    .line 26
    .line 27
    invoke-static {p0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const-string v3, "outfile"

    .line 31
    .line 32
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-static {p0, v0}, Lr5/a;->g(Ljava/nio/channels/FileChannel;Ljava/nio/channels/FileChannel;)Z

    .line 36
    .line 37
    .line 38
    move-result p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 39
    invoke-static {v1}, Lr5/a;->F(Ljava/io/Closeable;)V

    .line 40
    .line 41
    .line 42
    invoke-static {v2}, Lr5/a;->F(Ljava/io/Closeable;)V

    .line 43
    .line 44
    .line 45
    if-nez p0, :cond_0

    .line 46
    .line 47
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 48
    .line 49
    .line 50
    :cond_0
    return p0

    .line 51
    :catchall_0
    move-exception p0

    .line 52
    :goto_0
    move-object v0, v1

    .line 53
    goto :goto_1

    .line 54
    :catchall_1
    move-exception p0

    .line 55
    move-object v2, v0

    .line 56
    goto :goto_0

    .line 57
    :catchall_2
    move-exception p0

    .line 58
    move-object v2, v0

    .line 59
    :goto_1
    invoke-static {v0}, Lr5/a;->F(Ljava/io/Closeable;)V

    .line 60
    .line 61
    .line 62
    invoke-static {v2}, Lr5/a;->F(Ljava/io/Closeable;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 66
    .line 67
    .line 68
    throw p0
.end method

.method public static final H(Lkotlin/jvm/functions/Function2;LWf/a;LWf/a;)V
    .locals 0

    .line 1
    :try_start_0
    invoke-static {p1, p2, p0}, LEf/f;->a(Lkotlin/coroutines/Continuation;Lkotlin/coroutines/Continuation;Lkotlin/jvm/functions/Function2;)Lkotlin/coroutines/Continuation;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-static {p0}, LEf/f;->b(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 10
    .line 11
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-static {p1, p0}, Lag/a;->g(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :catchall_0
    move-exception p0

    .line 18
    instance-of p1, p0, LWf/E;

    .line 19
    .line 20
    if-eqz p1, :cond_0

    .line 21
    .line 22
    check-cast p0, LWf/E;

    .line 23
    .line 24
    iget-object p0, p0, LWf/E;->a:Ljava/lang/Throwable;

    .line 25
    .line 26
    :cond_0
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 27
    .line 28
    invoke-static {p0}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {p2, p1}, LWf/a;->resumeWith(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    throw p0
.end method

.method public static I(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    .locals 8

    .line 1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    instance-of v2, p0, Landroid/graphics/drawable/BitmapDrawable;

    .line 10
    .line 11
    if-eqz v2, :cond_2

    .line 12
    .line 13
    check-cast p0, Landroid/graphics/drawable/BitmapDrawable;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    if-eqz v2, :cond_1

    .line 20
    .line 21
    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-ne v0, v2, :cond_0

    .line 30
    .line 31
    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-ne v1, v2, :cond_0

    .line 40
    .line 41
    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    return-object p0

    .line 46
    :cond_0
    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    const/4 v2, 0x1

    .line 51
    invoke-static {p0, v0, v1, v2}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0

    .line 56
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 57
    .line 58
    const-string v0, "bitmap is null"

    .line 59
    .line 60
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    throw p0

    .line 64
    :cond_2
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    iget v3, v2, Landroid/graphics/Rect;->left:I

    .line 69
    .line 70
    iget v4, v2, Landroid/graphics/Rect;->top:I

    .line 71
    .line 72
    iget v5, v2, Landroid/graphics/Rect;->right:I

    .line 73
    .line 74
    iget v2, v2, Landroid/graphics/Rect;->bottom:I

    .line 75
    .line 76
    sget-object v6, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 77
    .line 78
    invoke-static {v0, v1, v6}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 79
    .line 80
    .line 81
    move-result-object v6

    .line 82
    const/4 v7, 0x0

    .line 83
    invoke-virtual {p0, v7, v7, v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 84
    .line 85
    .line 86
    new-instance v0, Landroid/graphics/Canvas;

    .line 87
    .line 88
    invoke-direct {v0, v6}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 92
    .line 93
    .line 94
    invoke-virtual {p0, v3, v4, v5, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 95
    .line 96
    .line 97
    return-object v6
.end method

.method public static J(Lcom/facebook/react/bridge/ReadableArray;[FF)I
    .locals 6

    .line 1
    invoke-interface {p0}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x6

    .line 6
    if-eq v0, v1, :cond_0

    .line 7
    .line 8
    return v0

    .line 9
    :cond_0
    const/4 v0, 0x0

    .line 10
    invoke-interface {p0, v0}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 11
    .line 12
    .line 13
    move-result-wide v2

    .line 14
    double-to-float v2, v2

    .line 15
    aput v2, p1, v0

    .line 16
    .line 17
    const/4 v0, 0x2

    .line 18
    invoke-interface {p0, v0}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 19
    .line 20
    .line 21
    move-result-wide v2

    .line 22
    double-to-float v2, v2

    .line 23
    const/4 v3, 0x1

    .line 24
    aput v2, p1, v3

    .line 25
    .line 26
    const/4 v2, 0x4

    .line 27
    invoke-interface {p0, v2}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 28
    .line 29
    .line 30
    move-result-wide v4

    .line 31
    double-to-float v4, v4

    .line 32
    mul-float/2addr v4, p2

    .line 33
    aput v4, p1, v0

    .line 34
    .line 35
    invoke-interface {p0, v3}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 36
    .line 37
    .line 38
    move-result-wide v3

    .line 39
    double-to-float v0, v3

    .line 40
    const/4 v3, 0x3

    .line 41
    aput v0, p1, v3

    .line 42
    .line 43
    invoke-interface {p0, v3}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 44
    .line 45
    .line 46
    move-result-wide v3

    .line 47
    double-to-float v0, v3

    .line 48
    aput v0, p1, v2

    .line 49
    .line 50
    const/4 v0, 0x5

    .line 51
    invoke-interface {p0, v0}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 52
    .line 53
    .line 54
    move-result-wide v2

    .line 55
    double-to-float p0, v2

    .line 56
    mul-float/2addr p0, p2

    .line 57
    aput p0, p1, v0

    .line 58
    .line 59
    return v1
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 1
    invoke-static {}, Lcom/transsnet/mtn/sdk/util/NDKTools;->getEncryptKey()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    :try_start_0
    new-instance v1, Ljavax/crypto/spec/DESedeKeySpec;

    .line 6
    .line 7
    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 8
    .line 9
    invoke-virtual {v0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-direct {v1, v0}, Ljavax/crypto/spec/DESedeKeySpec;-><init>([B)V

    .line 14
    .line 15
    .line 16
    const-string v0, "DESede"

    .line 17
    .line 18
    invoke-static {v0}, Ljavax/crypto/SecretKeyFactory;->getInstance(Ljava/lang/String;)Ljavax/crypto/SecretKeyFactory;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v0, v1}, Ljavax/crypto/SecretKeyFactory;->generateSecret(Ljava/security/spec/KeySpec;)Ljavax/crypto/SecretKey;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    const-string v1, "DESede/ECB/PKCS5Padding"

    .line 27
    .line 28
    invoke-static {v1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    const/4 v3, 0x0

    .line 33
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 34
    .line 35
    .line 36
    move-result v4

    .line 37
    if-eqz v4, :cond_0

    .line 38
    .line 39
    const/4 v3, 0x2

    .line 40
    invoke-virtual {v1, v3, v0}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    invoke-static {p0, v3}, Landroid/util/Base64;->decode([BI)[B

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    invoke-virtual {v1, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    new-instance v0, Ljava/lang/String;

    .line 56
    .line 57
    invoke-direct {v0, p0, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 58
    .line 59
    .line 60
    return-object v0

    .line 61
    :cond_0
    new-instance p0, Ljavax/crypto/spec/IvParameterSpec;

    .line 62
    .line 63
    throw v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 64
    :catch_0
    new-instance p0, Ljava/lang/RuntimeException;

    .line 65
    .line 66
    const-string v0, "3DES Error"

    .line 67
    .line 68
    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    throw p0
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p0, :cond_0

    .line 3
    .line 4
    return-object v0

    .line 5
    :cond_0
    invoke-static {}, Lcom/transsnet/mtn/sdk/util/NDKTools;->getEncryptKey()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    :try_start_0
    new-instance v2, Ljavax/crypto/spec/DESedeKeySpec;

    .line 10
    .line 11
    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 12
    .line 13
    invoke-virtual {v1, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-direct {v2, v1}, Ljavax/crypto/spec/DESedeKeySpec;-><init>([B)V

    .line 18
    .line 19
    .line 20
    const-string v1, "DESede"

    .line 21
    .line 22
    invoke-static {v1}, Ljavax/crypto/SecretKeyFactory;->getInstance(Ljava/lang/String;)Ljavax/crypto/SecretKeyFactory;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-virtual {v1, v2}, Ljavax/crypto/SecretKeyFactory;->generateSecret(Ljava/security/spec/KeySpec;)Ljavax/crypto/SecretKey;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    const-string v2, "DESede/ECB/PKCS5Padding"

    .line 31
    .line 32
    invoke-static {v2}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    if-eqz v4, :cond_1

    .line 41
    .line 42
    const/4 v0, 0x1

    .line 43
    invoke-virtual {v2, v0, v1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    invoke-virtual {v2, p0}, Ljavax/crypto/Cipher;->doFinal([B)[B

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    new-instance v0, Ljava/lang/String;

    .line 55
    .line 56
    const/4 v1, 0x2

    .line 57
    invoke-static {p0, v1}, Landroid/util/Base64;->encode([BI)[B

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    .line 62
    .line 63
    .line 64
    return-object v0

    .line 65
    :cond_1
    new-instance p0, Ljavax/crypto/spec/IvParameterSpec;

    .line 66
    .line 67
    throw v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 68
    :catch_0
    new-instance p0, Ljava/lang/RuntimeException;

    .line 69
    .line 70
    const-string v0, "3DES Error"

    .line 71
    .line 72
    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    throw p0
.end method

.method public static c(Lcom/transsnet/palmpay/core/bean/TransferByLoanOpenParams;Ljava/lang/String;Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;)Ljava/util/LinkedHashMap;
    .locals 19

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    const-string v1, "params"

    .line 4
    .line 5
    move-object/from16 v2, p0

    .line 6
    .line 7
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v1, "cardNo"

    .line 11
    .line 12
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const-string v3, "plan"

    .line 16
    .line 17
    move-object/from16 v4, p2

    .line 18
    .line 19
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getRepaymentPlanList()Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    if-eqz v3, :cond_0

    .line 27
    .line 28
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->L(Ljava/util/List;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/resp/RepaymentPlan;

    .line 33
    .line 34
    if-eqz v3, :cond_0

    .line 35
    .line 36
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/RepaymentPlan;->getRepaymentDate()Ljava/lang/Long;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    goto :goto_0

    .line 41
    :cond_0
    const/4 v3, 0x0

    .line 42
    :goto_0
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/bean/TransferByLoanOpenParams;->getLoanAmount()J

    .line 43
    .line 44
    .line 45
    move-result-wide v5

    .line 46
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    new-instance v6, Lkotlin/Pair;

    .line 51
    .line 52
    const-string v7, "loanAmount"

    .line 53
    .line 54
    invoke-direct {v6, v7, v5}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    const/16 v5, 0x9

    .line 58
    .line 59
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 60
    .line 61
    .line 62
    move-result-object v5

    .line 63
    new-instance v7, Lkotlin/Pair;

    .line 64
    .line 65
    const-string v8, "accountType"

    .line 66
    .line 67
    invoke-direct {v7, v8, v5}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    new-instance v8, Lkotlin/Pair;

    .line 71
    .line 72
    invoke-direct {v8, v1, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getProductSubId()Ljava/lang/Integer;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    new-instance v9, Lkotlin/Pair;

    .line 80
    .line 81
    const-string v1, "productSubId"

    .line 82
    .line 83
    invoke-direct {v9, v1, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getTerm()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    new-instance v10, Lkotlin/Pair;

    .line 91
    .line 92
    const-string v1, "term"

    .line 93
    .line 94
    invoke-direct {v10, v1, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getLoanTerm()Ljava/lang/Integer;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    new-instance v11, Lkotlin/Pair;

    .line 102
    .line 103
    const-string v1, "loanTerm"

    .line 104
    .line 105
    invoke-direct {v11, v1, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getLoanDays()Ljava/lang/Integer;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    new-instance v12, Lkotlin/Pair;

    .line 113
    .line 114
    const-string v1, "loanDays"

    .line 115
    .line 116
    invoke-direct {v12, v1, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getTermSpan()Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    new-instance v13, Lkotlin/Pair;

    .line 124
    .line 125
    const-string v1, "termSpan"

    .line 126
    .line 127
    invoke-direct {v13, v1, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getTermSpanUnit()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    new-instance v14, Lkotlin/Pair;

    .line 135
    .line 136
    const-string v1, "termSpanUnit"

    .line 137
    .line 138
    invoke-direct {v14, v1, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    new-instance v15, Lkotlin/Pair;

    .line 142
    .line 143
    const-string v0, "repaymentDate"

    .line 144
    .line 145
    invoke-direct {v15, v0, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getRepaymentPlanList()Ljava/util/List;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    new-instance v1, Lkotlin/Pair;

    .line 153
    .line 154
    const-string v3, "repaymentPlanList"

    .line 155
    .line 156
    invoke-direct {v1, v3, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getOutstandingAmountSum()Ljava/lang/Long;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    new-instance v3, Lkotlin/Pair;

    .line 164
    .line 165
    const-string v4, "totalRepaymentAmount"

    .line 166
    .line 167
    invoke-direct {v3, v4, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/bean/TransferByLoanOpenParams;->getCashierContextId()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    new-instance v2, Lkotlin/Pair;

    .line 175
    .line 176
    const-string v4, "cashierContextId"

    .line 177
    .line 178
    invoke-direct {v2, v4, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 179
    .line 180
    .line 181
    move-object/from16 v16, v1

    .line 182
    .line 183
    move-object/from16 v18, v2

    .line 184
    .line 185
    move-object/from16 v17, v3

    .line 186
    .line 187
    filled-new-array/range {v6 .. v18}, [Lkotlin/Pair;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    invoke-static {v0}, Lkotlin/collections/G;->f([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 196
    .line 197
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 198
    .line 199
    .line 200
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    :cond_1
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 209
    .line 210
    .line 211
    move-result v2

    .line 212
    if-eqz v2, :cond_2

    .line 213
    .line 214
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v2

    .line 218
    check-cast v2, Ljava/util/Map$Entry;

    .line 219
    .line 220
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v3

    .line 224
    if-eqz v3, :cond_1

    .line 225
    .line 226
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v3

    .line 230
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object v2

    .line 234
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    goto :goto_1

    .line 238
    :cond_2
    return-object v1
.end method

.method public static d([B)Ljava/lang/String;
    .locals 5

    .line 1
    if-eqz p0, :cond_3

    .line 2
    .line 3
    array-length v0, p0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    goto :goto_1

    .line 7
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 10
    .line 11
    .line 12
    array-length v1, p0

    .line 13
    const/4 v2, 0x0

    .line 14
    :goto_0
    const/4 v3, 0x1

    .line 15
    if-ge v2, v1, :cond_1

    .line 16
    .line 17
    aget-byte v4, p0, v2

    .line 18
    .line 19
    invoke-static {v4}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    invoke-static {v4, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    const-string v4, "%02X:"

    .line 32
    .line 33
    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    const-string v4, "format(...)"

    .line 38
    .line 39
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    add-int/lit8 v2, v2, 0x1

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    .line 49
    .line 50
    .line 51
    move-result p0

    .line 52
    if-lez p0, :cond_2

    .line 53
    .line 54
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    .line 55
    .line 56
    .line 57
    move-result p0

    .line 58
    sub-int/2addr p0, v3

    .line 59
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    :cond_2
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p0

    .line 66
    return-object p0

    .line 67
    :cond_3
    :goto_1
    const/4 p0, 0x0

    .line 68
    return-object p0
.end method

.method public static e(Landroid/graphics/Rect;ZLandroid/util/Rational;IIILjava/util/HashMap;)Ljava/util/HashMap;
    .locals 13

    .line 1
    move/from16 v0, p3

    .line 2
    .line 3
    move/from16 v1, p4

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/graphics/Rect;->width()I

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const/4 v3, 0x0

    .line 10
    const/4 v4, 0x1

    .line 11
    if-lez v2, :cond_0

    .line 12
    .line 13
    invoke-virtual {p0}, Landroid/graphics/Rect;->height()I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-lez v2, :cond_0

    .line 18
    .line 19
    move v2, v4

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    move v2, v3

    .line 22
    :goto_0
    const-string v5, "Cannot compute viewport crop rects zero sized sensor rect."

    .line 23
    .line 24
    invoke-static {v2, v5}, Lhf/a;->g(ZLjava/lang/String;)V

    .line 25
    .line 26
    .line 27
    new-instance v2, Landroid/graphics/RectF;

    .line 28
    .line 29
    invoke-direct {v2, p0}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    .line 30
    .line 31
    .line 32
    new-instance v5, Ljava/util/HashMap;

    .line 33
    .line 34
    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    .line 35
    .line 36
    .line 37
    new-instance v6, Landroid/graphics/RectF;

    .line 38
    .line 39
    invoke-direct {v6, p0}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual/range {p6 .. p6}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 51
    .line 52
    .line 53
    move-result v7

    .line 54
    const/4 v8, 0x0

    .line 55
    if-eqz v7, :cond_1

    .line 56
    .line 57
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v7

    .line 61
    check-cast v7, Ljava/util/Map$Entry;

    .line 62
    .line 63
    new-instance v9, Landroid/graphics/Matrix;

    .line 64
    .line 65
    invoke-direct {v9}, Landroid/graphics/Matrix;-><init>()V

    .line 66
    .line 67
    .line 68
    new-instance v10, Landroid/graphics/RectF;

    .line 69
    .line 70
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v11

    .line 74
    check-cast v11, Landroidx/camera/core/impl/n;

    .line 75
    .line 76
    iget-object v11, v11, Landroidx/camera/core/impl/n;->a:Landroid/util/Size;

    .line 77
    .line 78
    invoke-virtual {v11}, Landroid/util/Size;->getWidth()I

    .line 79
    .line 80
    .line 81
    move-result v11

    .line 82
    int-to-float v11, v11

    .line 83
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v12

    .line 87
    check-cast v12, Landroidx/camera/core/impl/n;

    .line 88
    .line 89
    iget-object v12, v12, Landroidx/camera/core/impl/n;->a:Landroid/util/Size;

    .line 90
    .line 91
    invoke-virtual {v12}, Landroid/util/Size;->getHeight()I

    .line 92
    .line 93
    .line 94
    move-result v12

    .line 95
    int-to-float v12, v12

    .line 96
    invoke-direct {v10, v8, v8, v11, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 97
    .line 98
    .line 99
    sget-object v8, Landroid/graphics/Matrix$ScaleToFit;->CENTER:Landroid/graphics/Matrix$ScaleToFit;

    .line 100
    .line 101
    invoke-virtual {v9, v10, v2, v8}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    .line 102
    .line 103
    .line 104
    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v7

    .line 108
    check-cast v7, LE/n0;

    .line 109
    .line 110
    invoke-virtual {v5, v7, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    new-instance v7, Landroid/graphics/RectF;

    .line 114
    .line 115
    invoke-direct {v7}, Landroid/graphics/RectF;-><init>()V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v9, v7, v10}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z

    .line 119
    .line 120
    .line 121
    invoke-virtual {v6, v7}, Landroid/graphics/RectF;->intersect(Landroid/graphics/RectF;)Z

    .line 122
    .line 123
    .line 124
    goto :goto_1

    .line 125
    :cond_1
    invoke-static {v0, p2}, Landroidx/camera/core/internal/utils/c;->b(ILandroid/util/Rational;)Landroid/util/Rational;

    .line 126
    .line 127
    .line 128
    move-result-object p0

    .line 129
    const/4 v2, 0x3

    .line 130
    if-ne v1, v2, :cond_2

    .line 131
    .line 132
    goto/16 :goto_f

    .line 133
    .line 134
    :cond_2
    new-instance v2, Landroid/graphics/Matrix;

    .line 135
    .line 136
    invoke-direct {v2}, Landroid/graphics/Matrix;-><init>()V

    .line 137
    .line 138
    .line 139
    new-instance v7, Landroid/graphics/RectF;

    .line 140
    .line 141
    invoke-virtual {p0}, Landroid/util/Rational;->getNumerator()I

    .line 142
    .line 143
    .line 144
    move-result v9

    .line 145
    int-to-float v9, v9

    .line 146
    invoke-virtual {p0}, Landroid/util/Rational;->getDenominator()I

    .line 147
    .line 148
    .line 149
    move-result p0

    .line 150
    int-to-float p0, p0

    .line 151
    invoke-direct {v7, v8, v8, v9, p0}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 152
    .line 153
    .line 154
    if-eqz v1, :cond_5

    .line 155
    .line 156
    if-eq v1, v4, :cond_4

    .line 157
    .line 158
    const/4 p0, 0x2

    .line 159
    if-ne v1, p0, :cond_3

    .line 160
    .line 161
    sget-object p0, Landroid/graphics/Matrix$ScaleToFit;->END:Landroid/graphics/Matrix$ScaleToFit;

    .line 162
    .line 163
    invoke-virtual {v2, v7, v6, p0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    .line 164
    .line 165
    .line 166
    goto :goto_2

    .line 167
    :cond_3
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 168
    .line 169
    const-string p1, "Unexpected scale type: "

    .line 170
    .line 171
    invoke-static {v1, p1}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 176
    .line 177
    .line 178
    throw p0

    .line 179
    :cond_4
    sget-object p0, Landroid/graphics/Matrix$ScaleToFit;->CENTER:Landroid/graphics/Matrix$ScaleToFit;

    .line 180
    .line 181
    invoke-virtual {v2, v7, v6, p0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    .line 182
    .line 183
    .line 184
    goto :goto_2

    .line 185
    :cond_5
    sget-object p0, Landroid/graphics/Matrix$ScaleToFit;->START:Landroid/graphics/Matrix$ScaleToFit;

    .line 186
    .line 187
    invoke-virtual {v2, v7, v6, p0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    .line 188
    .line 189
    .line 190
    :goto_2
    new-instance p0, Landroid/graphics/RectF;

    .line 191
    .line 192
    invoke-direct {p0}, Landroid/graphics/RectF;-><init>()V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v2, p0, v7}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z

    .line 196
    .line 197
    .line 198
    move/from16 v1, p5

    .line 199
    .line 200
    if-ne v1, v4, :cond_6

    .line 201
    .line 202
    move v1, v4

    .line 203
    goto :goto_3

    .line 204
    :cond_6
    move v1, v3

    .line 205
    :goto_3
    xor-int/2addr p1, v1

    .line 206
    if-nez v0, :cond_7

    .line 207
    .line 208
    if-nez p1, :cond_7

    .line 209
    .line 210
    move v1, v4

    .line 211
    goto :goto_4

    .line 212
    :cond_7
    move v1, v3

    .line 213
    :goto_4
    const/16 v2, 0x5a

    .line 214
    .line 215
    if-ne v0, v2, :cond_8

    .line 216
    .line 217
    if-eqz p1, :cond_8

    .line 218
    .line 219
    move v7, v4

    .line 220
    goto :goto_5

    .line 221
    :cond_8
    move v7, v3

    .line 222
    :goto_5
    if-nez v1, :cond_16

    .line 223
    .line 224
    if-eqz v7, :cond_9

    .line 225
    .line 226
    goto/16 :goto_e

    .line 227
    .line 228
    :cond_9
    if-nez v0, :cond_a

    .line 229
    .line 230
    if-eqz p1, :cond_a

    .line 231
    .line 232
    move v1, v4

    .line 233
    goto :goto_6

    .line 234
    :cond_a
    move v1, v3

    .line 235
    :goto_6
    const/16 v7, 0x10e

    .line 236
    .line 237
    if-ne v0, v7, :cond_b

    .line 238
    .line 239
    if-nez p1, :cond_b

    .line 240
    .line 241
    move v8, v4

    .line 242
    goto :goto_7

    .line 243
    :cond_b
    move v8, v3

    .line 244
    :goto_7
    if-nez v1, :cond_15

    .line 245
    .line 246
    if-eqz v8, :cond_c

    .line 247
    .line 248
    goto/16 :goto_d

    .line 249
    .line 250
    :cond_c
    if-ne v0, v2, :cond_d

    .line 251
    .line 252
    if-nez p1, :cond_d

    .line 253
    .line 254
    move v1, v4

    .line 255
    goto :goto_8

    .line 256
    :cond_d
    move v1, v3

    .line 257
    :goto_8
    const/16 v2, 0xb4

    .line 258
    .line 259
    if-ne v0, v2, :cond_e

    .line 260
    .line 261
    if-eqz p1, :cond_e

    .line 262
    .line 263
    move v8, v4

    .line 264
    goto :goto_9

    .line 265
    :cond_e
    move v8, v3

    .line 266
    :goto_9
    if-nez v1, :cond_14

    .line 267
    .line 268
    if-eqz v8, :cond_f

    .line 269
    .line 270
    goto :goto_c

    .line 271
    :cond_f
    if-ne v0, v2, :cond_10

    .line 272
    .line 273
    if-nez p1, :cond_10

    .line 274
    .line 275
    move v1, v4

    .line 276
    goto :goto_a

    .line 277
    :cond_10
    move v1, v3

    .line 278
    :goto_a
    if-ne v0, v7, :cond_11

    .line 279
    .line 280
    if-eqz p1, :cond_11

    .line 281
    .line 282
    move v3, v4

    .line 283
    :cond_11
    if-nez v1, :cond_13

    .line 284
    .line 285
    if-eqz v3, :cond_12

    .line 286
    .line 287
    goto :goto_b

    .line 288
    :cond_12
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 289
    .line 290
    new-instance v1, Ljava/lang/StringBuilder;

    .line 291
    .line 292
    const-string v2, "Invalid argument: mirrored "

    .line 293
    .line 294
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 298
    .line 299
    .line 300
    const-string p1, " rotation "

    .line 301
    .line 302
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 303
    .line 304
    .line 305
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 306
    .line 307
    .line 308
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 309
    .line 310
    .line 311
    move-result-object p1

    .line 312
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 313
    .line 314
    .line 315
    throw p0

    .line 316
    :cond_13
    :goto_b
    invoke-virtual {v6}, Landroid/graphics/RectF;->centerY()F

    .line 317
    .line 318
    .line 319
    move-result p1

    .line 320
    new-instance v0, Landroid/graphics/RectF;

    .line 321
    .line 322
    iget v1, p0, Landroid/graphics/RectF;->left:F

    .line 323
    .line 324
    iget v2, p0, Landroid/graphics/RectF;->bottom:F

    .line 325
    .line 326
    add-float/2addr p1, p1

    .line 327
    sub-float v2, p1, v2

    .line 328
    .line 329
    iget v3, p0, Landroid/graphics/RectF;->right:F

    .line 330
    .line 331
    iget p0, p0, Landroid/graphics/RectF;->top:F

    .line 332
    .line 333
    sub-float/2addr p1, p0

    .line 334
    invoke-direct {v0, v1, v2, v3, p1}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {v6}, Landroid/graphics/RectF;->centerX()F

    .line 338
    .line 339
    .line 340
    move-result p0

    .line 341
    new-instance v6, Landroid/graphics/RectF;

    .line 342
    .line 343
    iget p1, v0, Landroid/graphics/RectF;->right:F

    .line 344
    .line 345
    add-float/2addr p0, p0

    .line 346
    sub-float p1, p0, p1

    .line 347
    .line 348
    iget v1, v0, Landroid/graphics/RectF;->top:F

    .line 349
    .line 350
    iget v2, v0, Landroid/graphics/RectF;->left:F

    .line 351
    .line 352
    sub-float/2addr p0, v2

    .line 353
    iget v0, v0, Landroid/graphics/RectF;->bottom:F

    .line 354
    .line 355
    invoke-direct {v6, p1, v1, p0, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 356
    .line 357
    .line 358
    goto :goto_f

    .line 359
    :cond_14
    :goto_c
    invoke-virtual {v6}, Landroid/graphics/RectF;->centerY()F

    .line 360
    .line 361
    .line 362
    move-result p1

    .line 363
    new-instance v6, Landroid/graphics/RectF;

    .line 364
    .line 365
    iget v0, p0, Landroid/graphics/RectF;->left:F

    .line 366
    .line 367
    iget v1, p0, Landroid/graphics/RectF;->bottom:F

    .line 368
    .line 369
    add-float/2addr p1, p1

    .line 370
    sub-float v1, p1, v1

    .line 371
    .line 372
    iget v2, p0, Landroid/graphics/RectF;->right:F

    .line 373
    .line 374
    iget p0, p0, Landroid/graphics/RectF;->top:F

    .line 375
    .line 376
    sub-float/2addr p1, p0

    .line 377
    invoke-direct {v6, v0, v1, v2, p1}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 378
    .line 379
    .line 380
    goto :goto_f

    .line 381
    :cond_15
    :goto_d
    invoke-virtual {v6}, Landroid/graphics/RectF;->centerX()F

    .line 382
    .line 383
    .line 384
    move-result p1

    .line 385
    new-instance v6, Landroid/graphics/RectF;

    .line 386
    .line 387
    iget v0, p0, Landroid/graphics/RectF;->right:F

    .line 388
    .line 389
    add-float/2addr p1, p1

    .line 390
    sub-float v0, p1, v0

    .line 391
    .line 392
    iget v1, p0, Landroid/graphics/RectF;->top:F

    .line 393
    .line 394
    iget v2, p0, Landroid/graphics/RectF;->left:F

    .line 395
    .line 396
    sub-float/2addr p1, v2

    .line 397
    iget p0, p0, Landroid/graphics/RectF;->bottom:F

    .line 398
    .line 399
    invoke-direct {v6, v0, v1, p1, p0}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 400
    .line 401
    .line 402
    goto :goto_f

    .line 403
    :cond_16
    :goto_e
    move-object v6, p0

    .line 404
    :goto_f
    new-instance p0, Ljava/util/HashMap;

    .line 405
    .line 406
    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    .line 407
    .line 408
    .line 409
    new-instance p1, Landroid/graphics/RectF;

    .line 410
    .line 411
    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    .line 412
    .line 413
    .line 414
    new-instance v0, Landroid/graphics/Matrix;

    .line 415
    .line 416
    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    .line 417
    .line 418
    .line 419
    invoke-virtual {v5}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 420
    .line 421
    .line 422
    move-result-object v1

    .line 423
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 424
    .line 425
    .line 426
    move-result-object v1

    .line 427
    :goto_10
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 428
    .line 429
    .line 430
    move-result v2

    .line 431
    if-eqz v2, :cond_17

    .line 432
    .line 433
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 434
    .line 435
    .line 436
    move-result-object v2

    .line 437
    check-cast v2, Ljava/util/Map$Entry;

    .line 438
    .line 439
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 440
    .line 441
    .line 442
    move-result-object v3

    .line 443
    check-cast v3, Landroid/graphics/Matrix;

    .line 444
    .line 445
    invoke-virtual {v3, v0}, Landroid/graphics/Matrix;->invert(Landroid/graphics/Matrix;)Z

    .line 446
    .line 447
    .line 448
    invoke-virtual {v0, p1, v6}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;Landroid/graphics/RectF;)Z

    .line 449
    .line 450
    .line 451
    new-instance v3, Landroid/graphics/Rect;

    .line 452
    .line 453
    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    .line 454
    .line 455
    .line 456
    invoke-virtual {p1, v3}, Landroid/graphics/RectF;->round(Landroid/graphics/Rect;)V

    .line 457
    .line 458
    .line 459
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 460
    .line 461
    .line 462
    move-result-object v2

    .line 463
    check-cast v2, LE/n0;

    .line 464
    .line 465
    invoke-virtual {p0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 466
    .line 467
    .line 468
    goto :goto_10

    .line 469
    :cond_17
    return-object p0
.end method

.method public static f(Ljava/lang/Object;)V
    .locals 1

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    .line 5
    .line 6
    const-string v0, "Cannot return null from a non-@Nullable @Provides method"

    .line 7
    .line 8
    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    throw p0
.end method

.method public static g(Ljava/nio/channels/FileChannel;Ljava/nio/channels/FileChannel;)Z
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v5, p1

    .line 4
    .line 5
    const/16 v1, 0x8

    .line 6
    .line 7
    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    sget-object v3, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 12
    .line 13
    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    const-wide/16 v6, 0x0

    .line 18
    .line 19
    const/4 v4, 0x0

    .line 20
    move-wide v9, v6

    .line 21
    move-wide v11, v9

    .line 22
    const/4 v8, 0x0

    .line 23
    :goto_0
    const-string v13, "atomBytes"

    .line 24
    .line 25
    invoke-static {v2, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, v2}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    .line 32
    .line 33
    .line 34
    move-result v13

    .line 35
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v2}, Ljava/nio/Buffer;->capacity()I

    .line 39
    .line 40
    .line 41
    move-result v14

    .line 42
    if-ne v13, v14, :cond_0

    .line 43
    .line 44
    const/4 v13, 0x1

    .line 45
    goto :goto_1

    .line 46
    :cond_0
    const/4 v13, 0x0

    .line 47
    :goto_1
    const-wide/32 v16, 0x7fffffff

    .line 48
    .line 49
    .line 50
    const-string v14, "uInt32 value is too large"

    .line 51
    .line 52
    const/16 v18, 0x0

    .line 53
    .line 54
    const-string v3, "StreamableVideo"

    .line 55
    .line 56
    if-eqz v13, :cond_9

    .line 57
    .line 58
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 59
    .line 60
    .line 61
    move-result v8

    .line 62
    int-to-long v9, v8

    .line 63
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 64
    .line 65
    .line 66
    move-result v8

    .line 67
    sget v13, Li1/a;->i:I

    .line 68
    .line 69
    if-ne v8, v13, :cond_3

    .line 70
    .line 71
    cmp-long v4, v9, v16

    .line 72
    .line 73
    if-gtz v4, :cond_2

    .line 74
    .line 75
    cmp-long v4, v9, v6

    .line 76
    .line 77
    if-ltz v4, :cond_2

    .line 78
    .line 79
    long-to-int v4, v9

    .line 80
    move-wide/from16 v19, v6

    .line 81
    .line 82
    invoke-static {v4}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 83
    .line 84
    .line 85
    move-result-object v6

    .line 86
    sget-object v7, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 87
    .line 88
    invoke-virtual {v6, v7}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 89
    .line 90
    .line 91
    move-result-object v6

    .line 92
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v6, v2}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    .line 96
    .line 97
    .line 98
    invoke-virtual {v0, v6}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    .line 99
    .line 100
    .line 101
    move-result v7

    .line 102
    sub-int/2addr v4, v1

    .line 103
    if-lt v7, v4, :cond_1

    .line 104
    .line 105
    invoke-virtual {v6}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->position()J

    .line 109
    .line 110
    .line 111
    move-result-wide v11

    .line 112
    move-object/from16 v22, v2

    .line 113
    .line 114
    move-object v4, v6

    .line 115
    const/16 v21, 0x1

    .line 116
    .line 117
    goto :goto_4

    .line 118
    :cond_1
    move-object v4, v6

    .line 119
    move-wide v1, v11

    .line 120
    const/16 v21, 0x1

    .line 121
    .line 122
    goto/16 :goto_6

    .line 123
    .line 124
    :cond_2
    new-instance v0, Ljava/lang/Exception;

    .line 125
    .line 126
    invoke-direct {v0, v14}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    throw v0

    .line 130
    :cond_3
    move-wide/from16 v19, v6

    .line 131
    .line 132
    const-wide/16 v6, 0x1

    .line 133
    .line 134
    cmp-long v6, v9, v6

    .line 135
    .line 136
    if-nez v6, :cond_6

    .line 137
    .line 138
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    .line 139
    .line 140
    .line 141
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    .line 142
    .line 143
    .line 144
    invoke-virtual {v0, v2}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;)I

    .line 145
    .line 146
    .line 147
    move-result v6

    .line 148
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    .line 149
    .line 150
    .line 151
    invoke-virtual {v2}, Ljava/nio/Buffer;->capacity()I

    .line 152
    .line 153
    .line 154
    move-result v7

    .line 155
    if-ne v6, v7, :cond_5

    .line 156
    .line 157
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getLong()J

    .line 158
    .line 159
    .line 160
    move-result-wide v6

    .line 161
    cmp-long v9, v6, v19

    .line 162
    .line 163
    if-ltz v9, :cond_4

    .line 164
    .line 165
    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->position()J

    .line 166
    .line 167
    .line 168
    move-result-wide v9

    .line 169
    add-long/2addr v9, v6

    .line 170
    const/16 v21, 0x1

    .line 171
    .line 172
    const/16 v15, 0x10

    .line 173
    .line 174
    move-object/from16 v22, v2

    .line 175
    .line 176
    int-to-long v1, v15

    .line 177
    sub-long/2addr v9, v1

    .line 178
    invoke-virtual {v0, v9, v10}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    .line 179
    .line 180
    .line 181
    move-wide v9, v6

    .line 182
    goto :goto_4

    .line 183
    :cond_4
    new-instance v0, Ljava/lang/Exception;

    .line 184
    .line 185
    const-string v1, "uInt64 value is too large"

    .line 186
    .line 187
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    throw v0

    .line 191
    :cond_5
    :goto_2
    const/16 v21, 0x1

    .line 192
    .line 193
    :goto_3
    move-wide v1, v11

    .line 194
    goto :goto_6

    .line 195
    :cond_6
    move-object/from16 v22, v2

    .line 196
    .line 197
    const/16 v21, 0x1

    .line 198
    .line 199
    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->position()J

    .line 200
    .line 201
    .line 202
    move-result-wide v1

    .line 203
    add-long/2addr v1, v9

    .line 204
    move-wide/from16 v23, v1

    .line 205
    .line 206
    const/16 v6, 0x8

    .line 207
    .line 208
    int-to-long v1, v6

    .line 209
    sub-long v1, v23, v1

    .line 210
    .line 211
    invoke-virtual {v0, v1, v2}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    .line 212
    .line 213
    .line 214
    :goto_4
    sget v1, Li1/a;->a:I

    .line 215
    .line 216
    if-eq v8, v1, :cond_7

    .line 217
    .line 218
    sget v1, Li1/a;->b:I

    .line 219
    .line 220
    if-eq v8, v1, :cond_7

    .line 221
    .line 222
    sget v1, Li1/a;->c:I

    .line 223
    .line 224
    if-eq v8, v1, :cond_7

    .line 225
    .line 226
    sget v1, Li1/a;->d:I

    .line 227
    .line 228
    if-eq v8, v1, :cond_7

    .line 229
    .line 230
    sget v1, Li1/a;->e:I

    .line 231
    .line 232
    if-eq v8, v1, :cond_7

    .line 233
    .line 234
    sget v1, Li1/a;->f:I

    .line 235
    .line 236
    if-eq v8, v1, :cond_7

    .line 237
    .line 238
    sget v1, Li1/a;->g:I

    .line 239
    .line 240
    if-eq v8, v1, :cond_7

    .line 241
    .line 242
    sget v1, Li1/a;->h:I

    .line 243
    .line 244
    if-eq v8, v1, :cond_7

    .line 245
    .line 246
    sget v1, Li1/a;->j:I

    .line 247
    .line 248
    if-eq v8, v1, :cond_7

    .line 249
    .line 250
    if-eq v8, v13, :cond_7

    .line 251
    .line 252
    const-string v1, "encountered non-QT top-level atom (is this a QuickTime file?)"

    .line 253
    .line 254
    invoke-static {v3, v1}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;)I

    .line 255
    .line 256
    .line 257
    goto :goto_5

    .line 258
    :cond_7
    const-wide/16 v1, 0x8

    .line 259
    .line 260
    cmp-long v1, v9, v1

    .line 261
    .line 262
    if-gez v1, :cond_8

    .line 263
    .line 264
    :goto_5
    goto :goto_3

    .line 265
    :cond_8
    move-wide/from16 v6, v19

    .line 266
    .line 267
    move-object/from16 v2, v22

    .line 268
    .line 269
    const/16 v1, 0x8

    .line 270
    .line 271
    goto/16 :goto_0

    .line 272
    .line 273
    :cond_9
    move-wide/from16 v19, v6

    .line 274
    .line 275
    goto :goto_2

    .line 276
    :goto_6
    sget v6, Li1/a;->d:I

    .line 277
    .line 278
    if-eq v8, v6, :cond_a

    .line 279
    .line 280
    const-string v0, "last atom in file was not a moov atom"

    .line 281
    .line 282
    invoke-static {v3, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;)I

    .line 283
    .line 284
    .line 285
    return v18

    .line 286
    :cond_a
    cmp-long v6, v9, v16

    .line 287
    .line 288
    if-gtz v6, :cond_19

    .line 289
    .line 290
    cmp-long v6, v9, v19

    .line 291
    .line 292
    if-ltz v6, :cond_19

    .line 293
    .line 294
    long-to-int v6, v9

    .line 295
    invoke-virtual {v0}, Ljava/nio/channels/FileChannel;->size()J

    .line 296
    .line 297
    .line 298
    move-result-wide v7

    .line 299
    int-to-long v9, v6

    .line 300
    sub-long/2addr v7, v9

    .line 301
    invoke-static {v6}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 302
    .line 303
    .line 304
    move-result-object v11

    .line 305
    sget-object v12, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 306
    .line 307
    invoke-virtual {v11, v12}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 308
    .line 309
    .line 310
    move-result-object v11

    .line 311
    const-string v12, "allocate(moovAtomSize).order(ByteOrder.BIG_ENDIAN)"

    .line 312
    .line 313
    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v11}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    .line 317
    .line 318
    .line 319
    invoke-virtual {v0, v11, v7, v8}, Ljava/nio/channels/FileChannel;->read(Ljava/nio/ByteBuffer;J)I

    .line 320
    .line 321
    .line 322
    move-result v12

    .line 323
    invoke-virtual {v11}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    .line 324
    .line 325
    .line 326
    invoke-virtual {v11}, Ljava/nio/Buffer;->capacity()I

    .line 327
    .line 328
    .line 329
    move-result v13

    .line 330
    if-ne v12, v13, :cond_18

    .line 331
    .line 332
    const/16 v12, 0xc

    .line 333
    .line 334
    invoke-virtual {v11, v12}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 335
    .line 336
    .line 337
    move-result v12

    .line 338
    sget v13, Li1/a;->k:I

    .line 339
    .line 340
    if-eq v12, v13, :cond_17

    .line 341
    .line 342
    :goto_7
    invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I

    .line 343
    .line 344
    .line 345
    move-result v12

    .line 346
    const/16 v13, 0x8

    .line 347
    .line 348
    if-lt v12, v13, :cond_15

    .line 349
    .line 350
    invoke-virtual {v11}, Ljava/nio/Buffer;->position()I

    .line 351
    .line 352
    .line 353
    move-result v12

    .line 354
    add-int/lit8 v15, v12, 0x4

    .line 355
    .line 356
    invoke-virtual {v11, v15}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 357
    .line 358
    .line 359
    move-result v15

    .line 360
    sget v13, Li1/a;->l:I

    .line 361
    .line 362
    move/from16 v16, v6

    .line 363
    .line 364
    if-eq v15, v13, :cond_b

    .line 365
    .line 366
    sget v6, Li1/a;->m:I

    .line 367
    .line 368
    if-eq v15, v6, :cond_b

    .line 369
    .line 370
    invoke-virtual {v11}, Ljava/nio/Buffer;->position()I

    .line 371
    .line 372
    .line 373
    move-result v6

    .line 374
    add-int/lit8 v6, v6, 0x1

    .line 375
    .line 376
    invoke-virtual {v11, v6}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 377
    .line 378
    .line 379
    move/from16 v6, v16

    .line 380
    .line 381
    goto :goto_7

    .line 382
    :cond_b
    invoke-virtual {v11, v12}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 383
    .line 384
    .line 385
    move-result v6

    .line 386
    move-wide/from16 v19, v7

    .line 387
    .line 388
    int-to-long v6, v6

    .line 389
    invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I

    .line 390
    .line 391
    .line 392
    move-result v8

    .line 393
    move-wide/from16 v22, v6

    .line 394
    .line 395
    int-to-long v6, v8

    .line 396
    cmp-long v6, v22, v6

    .line 397
    .line 398
    if-gtz v6, :cond_14

    .line 399
    .line 400
    add-int/lit8 v12, v12, 0xc

    .line 401
    .line 402
    invoke-virtual {v11, v12}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    .line 403
    .line 404
    .line 405
    invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I

    .line 406
    .line 407
    .line 408
    move-result v6

    .line 409
    const/4 v7, 0x4

    .line 410
    if-lt v6, v7, :cond_13

    .line 411
    .line 412
    invoke-virtual {v11}, Ljava/nio/ByteBuffer;->getInt()I

    .line 413
    .line 414
    .line 415
    move-result v6

    .line 416
    if-ltz v6, :cond_12

    .line 417
    .line 418
    const-string v7, "bad atom size/element count"

    .line 419
    .line 420
    if-ne v15, v13, :cond_10

    .line 421
    .line 422
    invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I

    .line 423
    .line 424
    .line 425
    move-result v8

    .line 426
    mul-int/lit8 v12, v6, 0x4

    .line 427
    .line 428
    if-lt v8, v12, :cond_f

    .line 429
    .line 430
    move/from16 v7, v18

    .line 431
    .line 432
    :goto_8
    if-ge v7, v6, :cond_e

    .line 433
    .line 434
    invoke-virtual {v11}, Ljava/nio/Buffer;->position()I

    .line 435
    .line 436
    .line 437
    move-result v8

    .line 438
    invoke-virtual {v11, v8}, Ljava/nio/ByteBuffer;->getInt(I)I

    .line 439
    .line 440
    .line 441
    move-result v8

    .line 442
    add-int v12, v8, v16

    .line 443
    .line 444
    if-gez v8, :cond_d

    .line 445
    .line 446
    if-gez v12, :cond_c

    .line 447
    .line 448
    goto :goto_9

    .line 449
    :cond_c
    new-instance v0, Ljava/lang/Exception;

    .line 450
    .line 451
    const-string v1, "This is bug in original qt-faststart.c: stco atom should be extended to co64 atom as new offset value overflows uint32, but is not implemented."

    .line 452
    .line 453
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 454
    .line 455
    .line 456
    throw v0

    .line 457
    :cond_d
    :goto_9
    invoke-virtual {v11, v12}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 458
    .line 459
    .line 460
    add-int/lit8 v7, v7, 0x1

    .line 461
    .line 462
    goto :goto_8

    .line 463
    :cond_e
    move/from16 v6, v16

    .line 464
    .line 465
    move-wide/from16 v7, v19

    .line 466
    .line 467
    goto :goto_7

    .line 468
    :cond_f
    new-instance v0, Ljava/lang/Exception;

    .line 469
    .line 470
    invoke-direct {v0, v7}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 471
    .line 472
    .line 473
    throw v0

    .line 474
    :cond_10
    sget v8, Li1/a;->m:I

    .line 475
    .line 476
    if-ne v15, v8, :cond_e

    .line 477
    .line 478
    const-string v8, "patching co64 atom..."

    .line 479
    .line 480
    invoke-static {v3, v8}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;)I

    .line 481
    .line 482
    .line 483
    invoke-virtual {v11}, Ljava/nio/Buffer;->remaining()I

    .line 484
    .line 485
    .line 486
    move-result v8

    .line 487
    mul-int/lit8 v12, v6, 0x8

    .line 488
    .line 489
    if-lt v8, v12, :cond_11

    .line 490
    .line 491
    move/from16 v7, v18

    .line 492
    .line 493
    :goto_a
    if-ge v7, v6, :cond_e

    .line 494
    .line 495
    invoke-virtual {v11}, Ljava/nio/Buffer;->position()I

    .line 496
    .line 497
    .line 498
    move-result v8

    .line 499
    invoke-virtual {v11, v8}, Ljava/nio/ByteBuffer;->getLong(I)J

    .line 500
    .line 501
    .line 502
    move-result-wide v12

    .line 503
    add-long/2addr v12, v9

    .line 504
    invoke-virtual {v11, v12, v13}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 505
    .line 506
    .line 507
    add-int/lit8 v7, v7, 0x1

    .line 508
    .line 509
    goto :goto_a

    .line 510
    :cond_11
    new-instance v0, Ljava/lang/Exception;

    .line 511
    .line 512
    invoke-direct {v0, v7}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 513
    .line 514
    .line 515
    throw v0

    .line 516
    :cond_12
    new-instance v0, Ljava/lang/Exception;

    .line 517
    .line 518
    invoke-direct {v0, v14}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 519
    .line 520
    .line 521
    throw v0

    .line 522
    :cond_13
    new-instance v0, Ljava/lang/Exception;

    .line 523
    .line 524
    const-string v1, "malformed atom"

    .line 525
    .line 526
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 527
    .line 528
    .line 529
    throw v0

    .line 530
    :cond_14
    new-instance v0, Ljava/lang/Exception;

    .line 531
    .line 532
    const-string v1, "bad atom size"

    .line 533
    .line 534
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 535
    .line 536
    .line 537
    throw v0

    .line 538
    :cond_15
    move-wide/from16 v19, v7

    .line 539
    .line 540
    invoke-virtual {v0, v1, v2}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    .line 541
    .line 542
    .line 543
    if-eqz v4, :cond_16

    .line 544
    .line 545
    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 546
    .line 547
    .line 548
    invoke-virtual {v5, v4}, Ljava/nio/channels/FileChannel;->write(Ljava/nio/ByteBuffer;)I

    .line 549
    .line 550
    .line 551
    :cond_16
    invoke-virtual {v11}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 552
    .line 553
    .line 554
    invoke-virtual {v5, v11}, Ljava/nio/channels/FileChannel;->write(Ljava/nio/ByteBuffer;)I

    .line 555
    .line 556
    .line 557
    sub-long v3, v19, v1

    .line 558
    .line 559
    invoke-virtual/range {v0 .. v5}, Ljava/nio/channels/FileChannel;->transferTo(JJLjava/nio/channels/WritableByteChannel;)J

    .line 560
    .line 561
    .line 562
    return v21

    .line 563
    :cond_17
    new-instance v0, Ljava/lang/Exception;

    .line 564
    .line 565
    const-string v1, "this utility does not support compressed moov atoms yet"

    .line 566
    .line 567
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 568
    .line 569
    .line 570
    throw v0

    .line 571
    :cond_18
    new-instance v0, Ljava/lang/Exception;

    .line 572
    .line 573
    const-string v1, "failed to read moov atom"

    .line 574
    .line 575
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 576
    .line 577
    .line 578
    throw v0

    .line 579
    :cond_19
    new-instance v0, Ljava/lang/Exception;

    .line 580
    .line 581
    invoke-direct {v0, v14}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 582
    .line 583
    .line 584
    throw v0
.end method

.method public static h(Lk0/a;Ljava/util/List;Lag/c;LE0/h;)Ln0/d;
    .locals 6

    .line 1
    const-string v0, "migrations"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v1, "scope"

    .line 7
    .line 8
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v2, "produceFile"

    .line 12
    .line 13
    invoke-static {p3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    new-instance v2, Lj0/U;

    .line 17
    .line 18
    sget-object v3, Ln0/i;->a:Ln0/i;

    .line 19
    .line 20
    new-instance v4, LC0/t;

    .line 21
    .line 22
    const/16 v5, 0x12

    .line 23
    .line 24
    invoke-direct {v4, p3, v5}, LC0/t;-><init>(Ljava/lang/Object;I)V

    .line 25
    .line 26
    .line 27
    sget-object p3, Lj0/S;->a:Lj0/S;

    .line 28
    .line 29
    invoke-direct {v2, v3, p3, v4}, Lj0/U;-><init>(Landroidx/datastore/core/Serializer;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V

    .line 30
    .line 31
    .line 32
    const-string p3, "storage"

    .line 33
    .line 34
    invoke-static {v2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    new-instance v3, Ln0/d;

    .line 44
    .line 45
    invoke-static {v2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    sget-object p3, Lj0/h;->a:Lj0/g;

    .line 55
    .line 56
    invoke-virtual {p3, p1}, Lj0/g;->getInitializer(Ljava/util/List;)Lkotlin/jvm/functions/Function2;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-static {p1}, Lkotlin/collections/p;->c(Ljava/lang/Object;)Ljava/util/List;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    new-instance p3, Lj0/O;

    .line 65
    .line 66
    invoke-direct {p3, v2, p1, p0, p2}, Lj0/O;-><init>(Lj0/U;Ljava/util/List;Landroidx/datastore/core/CorruptionHandler;Lkotlinx/coroutines/CoroutineScope;)V

    .line 67
    .line 68
    .line 69
    invoke-direct {v3, p3}, Ln0/d;-><init>(Landroidx/datastore/core/DataStore;)V

    .line 70
    .line 71
    .line 72
    new-instance p0, Ln0/d;

    .line 73
    .line 74
    invoke-direct {p0, v3}, Ln0/d;-><init>(Landroidx/datastore/core/DataStore;)V

    .line 75
    .line 76
    .line 77
    return-object p0
.end method

.method public static i(Ljava/util/ArrayList;)Landroid/hardware/camera2/CameraDevice$StateCallback;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    new-instance p0, Landroidx/camera/camera2/internal/q0;

    .line 8
    .line 9
    invoke-direct {p0}, Landroid/hardware/camera2/CameraDevice$StateCallback;-><init>()V

    .line 10
    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/4 v1, 0x1

    .line 18
    if-ne v0, v1, :cond_1

    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    check-cast p0, Landroid/hardware/camera2/CameraDevice$StateCallback;

    .line 26
    .line 27
    return-object p0

    .line 28
    :cond_1
    new-instance v0, Landroidx/camera/camera2/internal/p0;

    .line 29
    .line 30
    invoke-direct {v0, p0}, Landroidx/camera/camera2/internal/p0;-><init>(Ljava/util/ArrayList;)V

    .line 31
    .line 32
    .line 33
    return-object v0
.end method

.method public static j(DDDLjava/lang/String;)D
    .locals 8

    .line 1
    const/4 v0, 0x2

    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-virtual {p6}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p6

    .line 7
    invoke-virtual {p6}, Ljava/lang/String;->length()I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    const/4 v3, 0x1

    .line 12
    add-int/lit8 v4, v2, -0x1

    .line 13
    .line 14
    if-eqz v2, :cond_a

    .line 15
    .line 16
    const-string v5, "normal"

    .line 17
    .line 18
    invoke-virtual {p6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    if-eqz v5, :cond_0

    .line 23
    .line 24
    goto/16 :goto_6

    .line 25
    .line 26
    :cond_0
    invoke-virtual {p6, v4}, Ljava/lang/String;->codePointAt(I)I

    .line 27
    .line 28
    .line 29
    move-result v5

    .line 30
    const/16 v6, 0x25

    .line 31
    .line 32
    if-ne v5, v6, :cond_1

    .line 33
    .line 34
    invoke-virtual {p6, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object p2

    .line 38
    invoke-static {p2}, Ljava/lang/Double;->valueOf(Ljava/lang/String;)Ljava/lang/Double;

    .line 39
    .line 40
    .line 41
    move-result-object p2

    .line 42
    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    .line 43
    .line 44
    .line 45
    move-result-wide p2

    .line 46
    const-wide/high16 p4, 0x4059000000000000L    # 100.0

    .line 47
    .line 48
    div-double/2addr p2, p4

    .line 49
    mul-double/2addr p2, p0

    .line 50
    return-wide p2

    .line 51
    :cond_1
    add-int/lit8 p0, v2, -0x2

    .line 52
    .line 53
    if-lez p0, :cond_9

    .line 54
    .line 55
    invoke-virtual {p6, p0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    .line 63
    .line 64
    const/4 v6, -0x1

    .line 65
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 66
    .line 67
    .line 68
    move-result v7

    .line 69
    sparse-switch v7, :sswitch_data_0

    .line 70
    .line 71
    .line 72
    :goto_0
    move v0, v6

    .line 73
    goto :goto_1

    .line 74
    :sswitch_0
    const-string v0, "px"

    .line 75
    .line 76
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result p1

    .line 80
    if-nez p1, :cond_2

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_2
    const/4 v0, 0x6

    .line 84
    goto :goto_1

    .line 85
    :sswitch_1
    const-string v0, "pt"

    .line 86
    .line 87
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result p1

    .line 91
    if-nez p1, :cond_3

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_3
    const/4 v0, 0x5

    .line 95
    goto :goto_1

    .line 96
    :sswitch_2
    const-string v0, "pc"

    .line 97
    .line 98
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result p1

    .line 102
    if-nez p1, :cond_4

    .line 103
    .line 104
    goto :goto_0

    .line 105
    :cond_4
    const/4 v0, 0x4

    .line 106
    goto :goto_1

    .line 107
    :sswitch_3
    const-string v0, "mm"

    .line 108
    .line 109
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result p1

    .line 113
    if-nez p1, :cond_5

    .line 114
    .line 115
    goto :goto_0

    .line 116
    :cond_5
    const/4 v0, 0x3

    .line 117
    goto :goto_1

    .line 118
    :sswitch_4
    const-string v3, "in"

    .line 119
    .line 120
    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    move-result p1

    .line 124
    if-nez p1, :cond_8

    .line 125
    .line 126
    goto :goto_0

    .line 127
    :sswitch_5
    const-string v0, "em"

    .line 128
    .line 129
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result p1

    .line 133
    if-nez p1, :cond_6

    .line 134
    .line 135
    goto :goto_0

    .line 136
    :cond_6
    move v0, v3

    .line 137
    goto :goto_1

    .line 138
    :sswitch_6
    const-string v0, "cm"

    .line 139
    .line 140
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result p1

    .line 144
    if-nez p1, :cond_7

    .line 145
    .line 146
    goto :goto_0

    .line 147
    :cond_7
    move v0, v1

    .line 148
    :cond_8
    :goto_1
    packed-switch v0, :pswitch_data_0

    .line 149
    .line 150
    .line 151
    :goto_2
    move-wide p4, v4

    .line 152
    goto :goto_4

    .line 153
    :pswitch_0
    move v2, p0

    .line 154
    goto :goto_2

    .line 155
    :pswitch_1
    const-wide/high16 p4, 0x3ff4000000000000L    # 1.25

    .line 156
    .line 157
    :goto_3
    :pswitch_2
    move v2, p0

    .line 158
    goto :goto_4

    .line 159
    :pswitch_3
    const-wide/high16 p4, 0x402e000000000000L    # 15.0

    .line 160
    .line 161
    goto :goto_3

    .line 162
    :pswitch_4
    const-wide p4, 0x400c58b1572580c3L    # 3.543307

    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    goto :goto_3

    .line 168
    :pswitch_5
    const-wide p4, 0x4056800000000000L    # 90.0

    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    goto :goto_3

    .line 174
    :pswitch_6
    const-wide p4, 0x4041b76ed677707aL    # 35.43307

    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    goto :goto_3

    .line 180
    :goto_4
    invoke-virtual {p6, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object p0

    .line 184
    invoke-static {p0}, Ljava/lang/Double;->valueOf(Ljava/lang/String;)Ljava/lang/Double;

    .line 185
    .line 186
    .line 187
    move-result-object p0

    .line 188
    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    .line 189
    .line 190
    .line 191
    move-result-wide p0

    .line 192
    mul-double/2addr p0, p4

    .line 193
    :goto_5
    mul-double/2addr p0, p2

    .line 194
    return-wide p0

    .line 195
    :cond_9
    invoke-static {p6}, Ljava/lang/Double;->valueOf(Ljava/lang/String;)Ljava/lang/Double;

    .line 196
    .line 197
    .line 198
    move-result-object p0

    .line 199
    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    .line 200
    .line 201
    .line 202
    move-result-wide p0

    .line 203
    goto :goto_5

    .line 204
    :cond_a
    :goto_6
    const-wide/16 p0, 0x0

    .line 205
    .line 206
    return-wide p0

    .line 207
    :sswitch_data_0
    .sparse-switch
        0xc6a -> :sswitch_6
        0xca8 -> :sswitch_5
        0xd25 -> :sswitch_4
        0xda0 -> :sswitch_3
        0xdf3 -> :sswitch_2
        0xe04 -> :sswitch_1
        0xe08 -> :sswitch_0
    .end sparse-switch

    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_2
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static k(Lcom/horcrux/svg/q;DDD)D
    .locals 8

    .line 1
    const-wide/16 v6, 0x0

    .line 2
    .line 3
    if-nez p0, :cond_0

    .line 4
    .line 5
    return-wide v6

    .line 6
    :cond_0
    sget-object v0, Lcom/horcrux/svg/m;->a:[I

    .line 7
    .line 8
    iget-object v1, p0, Lcom/horcrux/svg/q;->b:Lcom/horcrux/svg/SVGLength$UnitType;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    aget v0, v0, v1

    .line 15
    .line 16
    iget-wide v1, p0, Lcom/horcrux/svg/q;->a:D

    .line 17
    .line 18
    packed-switch v0, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    mul-double/2addr v1, p3

    .line 22
    :goto_0
    add-double/2addr v1, v6

    .line 23
    return-wide v1

    .line 24
    :pswitch_0
    const-wide/high16 p5, 0x402e000000000000L    # 15.0

    .line 25
    .line 26
    :goto_1
    :pswitch_1
    move-wide v4, p3

    .line 27
    move-wide v0, v1

    .line 28
    move-wide v2, p5

    .line 29
    goto :goto_2

    .line 30
    :pswitch_2
    const-wide/high16 p5, 0x3ff4000000000000L    # 1.25

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :pswitch_3
    const-wide p5, 0x4056800000000000L    # 90.0

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :pswitch_4
    const-wide p5, 0x400c58b1572580c3L    # 3.543307

    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :pswitch_5
    const-wide p5, 0x4041b76ed677707aL    # 35.43307

    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    goto :goto_1

    .line 51
    :pswitch_6
    const-wide/high16 p0, 0x4000000000000000L    # 2.0

    .line 52
    .line 53
    div-double/2addr p5, p0

    .line 54
    goto :goto_1

    .line 55
    :pswitch_7
    const-wide/high16 p3, 0x4059000000000000L    # 100.0

    .line 56
    .line 57
    div-double/2addr v1, p3

    .line 58
    mul-double/2addr v1, p1

    .line 59
    goto :goto_0

    .line 60
    :pswitch_8
    const-wide/high16 p5, 0x3ff0000000000000L    # 1.0

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :goto_2
    invoke-static/range {v0 .. v7}, LN8/q0;->x(DDDD)D

    .line 64
    .line 65
    .line 66
    move-result-wide p0

    .line 67
    return-wide p0

    .line 68
    nop

    .line 69
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_8
        :pswitch_7
        :pswitch_1
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
    .end packed-switch
.end method

.method public static m()Ljava/lang/String;
    .locals 3

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getCID()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_5

    .line 10
    .line 11
    :try_start_0
    invoke-static {}, Lcom/transsnet/palmpay/util/Utils;->getApp()Landroid/app/Application;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const-string v1, "phone"

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const-string v1, "null cannot be cast to non-null type android.telephony.TelephonyManager"

    .line 22
    .line 23
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    check-cast v0, Landroid/telephony/TelephonyManager;

    .line 27
    .line 28
    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getAllCellInfo()Ljava/util/List;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-eqz v1, :cond_4

    .line 41
    .line 42
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    check-cast v1, Landroid/telephony/CellInfo;

    .line 47
    .line 48
    instance-of v2, v1, Landroid/telephony/CellInfoCdma;

    .line 49
    .line 50
    if-eqz v2, :cond_1

    .line 51
    .line 52
    check-cast v1, Landroid/telephony/CellInfoCdma;

    .line 53
    .line 54
    invoke-virtual {v1}, Landroid/telephony/CellInfoCdma;->getCellIdentity()Landroid/telephony/CellIdentityCdma;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-virtual {v0}, Landroid/telephony/CellIdentityCdma;->getBasestationId()I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    goto :goto_0

    .line 67
    :cond_1
    instance-of v2, v1, Landroid/telephony/CellInfoGsm;

    .line 68
    .line 69
    if-eqz v2, :cond_2

    .line 70
    .line 71
    check-cast v1, Landroid/telephony/CellInfoGsm;

    .line 72
    .line 73
    invoke-virtual {v1}, Landroid/telephony/CellInfoGsm;->getCellIdentity()Landroid/telephony/CellIdentityGsm;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-virtual {v0}, Landroid/telephony/CellIdentityGsm;->getCid()I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    goto :goto_0

    .line 86
    :cond_2
    instance-of v2, v1, Landroid/telephony/CellInfoLte;

    .line 87
    .line 88
    if-eqz v2, :cond_3

    .line 89
    .line 90
    check-cast v1, Landroid/telephony/CellInfoLte;

    .line 91
    .line 92
    invoke-virtual {v1}, Landroid/telephony/CellInfoLte;->getCellIdentity()Landroid/telephony/CellIdentityLte;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-virtual {v0}, Landroid/telephony/CellIdentityLte;->getCi()I

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    goto :goto_0

    .line 105
    :cond_3
    instance-of v2, v1, Landroid/telephony/CellInfoWcdma;

    .line 106
    .line 107
    if-eqz v2, :cond_0

    .line 108
    .line 109
    check-cast v1, Landroid/telephony/CellInfoWcdma;

    .line 110
    .line 111
    invoke-virtual {v1}, Landroid/telephony/CellInfoWcdma;->getCellIdentity()Landroid/telephony/CellIdentityWcdma;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-virtual {v0}, Landroid/telephony/CellIdentityWcdma;->getCid()I

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 123
    goto :goto_0

    .line 124
    :catch_0
    move-exception v0

    .line 125
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 126
    .line 127
    .line 128
    :cond_4
    const-string v0, "0"

    .line 129
    .line 130
    :cond_5
    :goto_0
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    return-object v0
.end method

.method public static final o()Ljava/lang/String;
    .locals 10

    .line 1
    const/4 v0, 0x1

    .line 2
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 3
    .line 4
    const/16 v2, 0x1c

    .line 5
    .line 6
    if-lt v1, v2, :cond_0

    .line 7
    .line 8
    invoke-static {}, Lcom/facebook/react/uimanager/a;->e()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    return-object v0

    .line 13
    :cond_0
    invoke-static {}, Landroid/os/Process;->myPid()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    const-string v2, "/proc/"

    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    if-gtz v1, :cond_1

    .line 21
    .line 22
    return-object v3

    .line 23
    :cond_1
    :try_start_0
    sget-object v4, Lxf/q;->a:Lxf/o;

    .line 24
    .line 25
    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;

    .line 26
    .line 27
    .line 28
    move-result-object v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 29
    :try_start_1
    new-instance v5, Ljava/io/BufferedReader;

    .line 30
    .line 31
    new-instance v6, Ljava/io/FileReader;

    .line 32
    .line 33
    new-instance v7, Ljava/lang/StringBuilder;

    .line 34
    .line 35
    invoke-direct {v7, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    const-string v1, "/cmdline"

    .line 42
    .line 43
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    invoke-direct {v6, v1}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-direct {v5, v6}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 54
    .line 55
    .line 56
    :try_start_2
    invoke-static {v4}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v5}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    const-string v2, "readLine(...)"

    .line 64
    .line 65
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    sub-int/2addr v2, v0

    .line 73
    const/4 v4, 0x0

    .line 74
    move v6, v4

    .line 75
    move v7, v6

    .line 76
    :goto_0
    if-gt v6, v2, :cond_7

    .line 77
    .line 78
    if-nez v7, :cond_2

    .line 79
    .line 80
    move v8, v6

    .line 81
    goto :goto_1

    .line 82
    :cond_2
    move v8, v2

    .line 83
    :goto_1
    invoke-virtual {v1, v8}, Ljava/lang/String;->charAt(I)C

    .line 84
    .line 85
    .line 86
    move-result v8

    .line 87
    const/16 v9, 0x20

    .line 88
    .line 89
    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->h(II)I

    .line 90
    .line 91
    .line 92
    move-result v8

    .line 93
    if-gtz v8, :cond_3

    .line 94
    .line 95
    move v8, v0

    .line 96
    goto :goto_2

    .line 97
    :cond_3
    move v8, v4

    .line 98
    :goto_2
    if-nez v7, :cond_5

    .line 99
    .line 100
    if-nez v8, :cond_4

    .line 101
    .line 102
    move v7, v0

    .line 103
    goto :goto_0

    .line 104
    :cond_4
    add-int/2addr v6, v0

    .line 105
    goto :goto_0

    .line 106
    :cond_5
    if-nez v8, :cond_6

    .line 107
    .line 108
    goto :goto_3

    .line 109
    :cond_6
    add-int/lit8 v2, v2, -0x1

    .line 110
    .line 111
    goto :goto_0

    .line 112
    :catchall_0
    move-exception v0

    .line 113
    goto :goto_4

    .line 114
    :cond_7
    :goto_3
    add-int/2addr v2, v0

    .line 115
    invoke-virtual {v1, v6, v2}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 123
    :try_start_3
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 124
    .line 125
    invoke-virtual {v5}, Ljava/io/BufferedReader;->close()V

    .line 126
    .line 127
    .line 128
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 129
    .line 130
    goto :goto_5

    .line 131
    :catchall_1
    move-exception v1

    .line 132
    :try_start_4
    sget-object v2, Lxf/q;->a:Lxf/o;

    .line 133
    .line 134
    invoke-static {v1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 135
    .line 136
    .line 137
    goto :goto_5

    .line 138
    :catchall_2
    move-exception v0

    .line 139
    invoke-static {v4}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    .line 140
    .line 141
    .line 142
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 143
    :goto_4
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 144
    .line 145
    invoke-static {v0}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    :goto_5
    instance-of v1, v0, Lxf/p;

    .line 150
    .line 151
    if-eqz v1, :cond_8

    .line 152
    .line 153
    goto :goto_6

    .line 154
    :cond_8
    move-object v3, v0

    .line 155
    :goto_6
    check-cast v3, Ljava/lang/String;

    .line 156
    .line 157
    return-object v3
.end method

.method public static p(Landroid/widget/EdgeEffect;)F
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1f

    .line 4
    .line 5
    if-lt v0, v1, :cond_0

    .line 6
    .line 7
    invoke-static {p0}, Landroidx/core/widget/d;->b(Landroid/widget/EdgeEffect;)F

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_0
    const/4 p0, 0x0

    .line 13
    return p0
.end method

.method public static q(ILandroid/content/Context;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    invoke-static {}, Landroidx/appcompat/widget/B0;->b()Landroidx/appcompat/widget/B0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p0, p1}, Landroidx/appcompat/widget/B0;->d(ILandroid/content/Context;)Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public static r()Ljava/lang/String;
    .locals 11

    .line 1
    const-string v0, "HWaddr"

    .line 2
    .line 3
    const-string v1, "02:00:00:00:00:00"

    .line 4
    .line 5
    invoke-static {v1}, Lr5/a;->y(Ljava/lang/String;)Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    invoke-static {}, Lcom/transsnet/palmpay/util/Utils;->getApp()Landroid/app/Application;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    const-string v2, "wifi"

    .line 20
    .line 21
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const-string v2, "null cannot be cast to non-null type android.net.wifi.WifiManager"

    .line 26
    .line 27
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    check-cast v1, Landroid/net/wifi/WifiManager;

    .line 31
    .line 32
    invoke-virtual {v1}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getMacAddress()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    :cond_0
    invoke-static {v1}, Lr5/a;->y(Ljava/lang/String;)Z

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    const/4 v3, 0x1

    .line 45
    const/4 v4, 0x0

    .line 46
    const/4 v5, 0x0

    .line 47
    if-eqz v2, :cond_4

    .line 48
    .line 49
    :try_start_0
    invoke-static {}, Lr5/a;->s()Ljava/net/InetAddress;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-static {v1}, Ljava/net/NetworkInterface;->getByInetAddress(Ljava/net/InetAddress;)Ljava/net/NetworkInterface;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    invoke-virtual {v1}, Ljava/net/NetworkInterface;->getHardwareAddress()[B

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    new-instance v2, Ljava/lang/StringBuffer;

    .line 62
    .line 63
    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    .line 64
    .line 65
    .line 66
    array-length v6, v1

    .line 67
    move v7, v4

    .line 68
    :goto_0
    if-ge v7, v6, :cond_3

    .line 69
    .line 70
    if-eqz v7, :cond_1

    .line 71
    .line 72
    const/16 v8, 0x3a

    .line 73
    .line 74
    invoke-virtual {v2, v8}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    .line 75
    .line 76
    .line 77
    :cond_1
    aget-byte v8, v1, v7

    .line 78
    .line 79
    and-int/lit16 v8, v8, 0xff

    .line 80
    .line 81
    invoke-static {v8}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v8

    .line 85
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 86
    .line 87
    .line 88
    move-result v9

    .line 89
    if-ne v9, v3, :cond_2

    .line 90
    .line 91
    new-instance v9, Ljava/lang/StringBuilder;

    .line 92
    .line 93
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 94
    .line 95
    .line 96
    const-string v10, "0"

    .line 97
    .line 98
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v8

    .line 108
    :cond_2
    invoke-virtual {v2, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 109
    .line 110
    .line 111
    add-int/lit8 v7, v7, 0x1

    .line 112
    .line 113
    goto :goto_0

    .line 114
    :cond_3
    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    const-string v2, "toString(...)"

    .line 119
    .line 120
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    const-string v6, "getDefault(...)"

    .line 128
    .line 129
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    const-string v2, "toUpperCase(...)"

    .line 137
    .line 138
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 139
    .line 140
    .line 141
    goto :goto_1

    .line 142
    :catch_0
    move-object v1, v5

    .line 143
    :cond_4
    :goto_1
    invoke-static {v1}, Lr5/a;->y(Ljava/lang/String;)Z

    .line 144
    .line 145
    .line 146
    move-result v2

    .line 147
    if-eqz v2, :cond_7

    .line 148
    .line 149
    :try_start_1
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    .line 150
    .line 151
    .line 152
    move-result-object v1
    :try_end_1
    .catch Ljava/net/SocketException; {:try_start_1 .. :try_end_1} :catch_1

    .line 153
    goto :goto_2

    .line 154
    :catch_1
    move-exception v1

    .line 155
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 156
    .line 157
    .line 158
    move-object v1, v5

    .line 159
    :goto_2
    if-nez v1, :cond_5

    .line 160
    .line 161
    goto :goto_4

    .line 162
    :cond_5
    :goto_3
    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    .line 163
    .line 164
    .line 165
    move-result v2

    .line 166
    if-eqz v2, :cond_6

    .line 167
    .line 168
    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    check-cast v2, Ljava/net/NetworkInterface;

    .line 173
    .line 174
    :try_start_2
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getHardwareAddress()[B

    .line 178
    .line 179
    .line 180
    move-result-object v2

    .line 181
    invoke-static {v2}, Lr5/a;->d([B)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v5
    :try_end_2
    .catch Ljava/net/SocketException; {:try_start_2 .. :try_end_2} :catch_2

    .line 185
    if-eqz v5, :cond_5

    .line 186
    .line 187
    goto :goto_4

    .line 188
    :catch_2
    move-exception v2

    .line 189
    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    .line 190
    .line 191
    .line 192
    goto :goto_3

    .line 193
    :cond_6
    :goto_4
    move-object v1, v5

    .line 194
    :cond_7
    invoke-static {v1}, Lr5/a;->y(Ljava/lang/String;)Z

    .line 195
    .line 196
    .line 197
    move-result v2

    .line 198
    if-eqz v2, :cond_b

    .line 199
    .line 200
    const-string v1, ""

    .line 201
    .line 202
    const-string v2, "busybox ifconfig"

    .line 203
    .line 204
    :try_start_3
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 205
    .line 206
    .line 207
    move-result-object v5

    .line 208
    invoke-virtual {v5, v2}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    .line 209
    .line 210
    .line 211
    move-result-object v2

    .line 212
    new-instance v5, Ljava/io/InputStreamReader;

    .line 213
    .line 214
    invoke-virtual {v2}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    .line 215
    .line 216
    .line 217
    move-result-object v2

    .line 218
    invoke-direct {v5, v2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 219
    .line 220
    .line 221
    new-instance v2, Ljava/io/BufferedReader;

    .line 222
    .line 223
    invoke-direct {v2, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4

    .line 224
    .line 225
    .line 226
    move-object v5, v1

    .line 227
    :goto_5
    :try_start_4
    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v6

    .line 231
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 232
    .line 233
    .line 234
    invoke-static {v6, v0, v4}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 235
    .line 236
    .line 237
    move-result v7

    .line 238
    if-nez v7, :cond_8

    .line 239
    .line 240
    new-instance v7, Ljava/lang/StringBuilder;

    .line 241
    .line 242
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 246
    .line 247
    .line 248
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 249
    .line 250
    .line 251
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 252
    .line 253
    .line 254
    move-result-object v5
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    .line 255
    goto :goto_5

    .line 256
    :catch_3
    move-exception v2

    .line 257
    goto :goto_6

    .line 258
    :catch_4
    move-exception v2

    .line 259
    move-object v5, v1

    .line 260
    :goto_6
    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    .line 261
    .line 262
    .line 263
    move-object v6, v5

    .line 264
    :cond_8
    if-nez v6, :cond_9

    .line 265
    .line 266
    goto :goto_7

    .line 267
    :cond_9
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 268
    .line 269
    .line 270
    move-result v1

    .line 271
    if-lez v1, :cond_a

    .line 272
    .line 273
    invoke-static {v6, v0, v4}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 274
    .line 275
    .line 276
    move-result v1

    .line 277
    if-eqz v1, :cond_a

    .line 278
    .line 279
    const/4 v1, 0x6

    .line 280
    invoke-static {v6, v0, v4, v4, v1}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 281
    .line 282
    .line 283
    move-result v0

    .line 284
    add-int/2addr v0, v1

    .line 285
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 286
    .line 287
    .line 288
    move-result v1

    .line 289
    sub-int/2addr v1, v3

    .line 290
    invoke-virtual {v6, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object v6

    .line 294
    const-string v0, "substring(...)"

    .line 295
    .line 296
    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 297
    .line 298
    .line 299
    :cond_a
    move-object v1, v6

    .line 300
    :cond_b
    :goto_7
    return-object v1
.end method

.method public static s()Ljava/net/InetAddress;
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    .line 3
    .line 4
    .line 5
    move-result-object v1
    :try_end_0
    .catch Ljava/net/SocketException; {:try_start_0 .. :try_end_0} :catch_2

    .line 6
    move-object v2, v0

    .line 7
    :cond_0
    :try_start_1
    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-eqz v3, :cond_3

    .line 12
    .line 13
    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const-string v4, "null cannot be cast to non-null type java.net.NetworkInterface"

    .line 18
    .line 19
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    check-cast v3, Ljava/net/NetworkInterface;

    .line 23
    .line 24
    invoke-virtual {v3}, Ljava/net/NetworkInterface;->getInetAddresses()Ljava/util/Enumeration;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    :goto_0
    invoke-interface {v3}, Ljava/util/Enumeration;->hasMoreElements()Z

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    if-eqz v4, :cond_2

    .line 33
    .line 34
    invoke-interface {v3}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    check-cast v4, Ljava/net/InetAddress;
    :try_end_1
    .catch Ljava/net/SocketException; {:try_start_1 .. :try_end_1} :catch_1

    .line 39
    .line 40
    :try_start_2
    invoke-virtual {v4}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    if-nez v2, :cond_1

    .line 45
    .line 46
    invoke-virtual {v4}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    const-string v5, "getHostAddress(...)"

    .line 51
    .line 52
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    const-string v5, ":"

    .line 56
    .line 57
    const/4 v6, 0x6

    .line 58
    const/4 v7, 0x0

    .line 59
    invoke-static {v2, v5, v7, v7, v6}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 60
    .line 61
    .line 62
    move-result v2
    :try_end_2
    .catch Ljava/net/SocketException; {:try_start_2 .. :try_end_2} :catch_0

    .line 63
    const/4 v5, -0x1

    .line 64
    if-ne v2, v5, :cond_1

    .line 65
    .line 66
    move-object v2, v4

    .line 67
    goto :goto_1

    .line 68
    :catch_0
    move-exception v0

    .line 69
    move-object v2, v4

    .line 70
    goto :goto_2

    .line 71
    :cond_1
    move-object v2, v0

    .line 72
    goto :goto_0

    .line 73
    :catch_1
    move-exception v0

    .line 74
    goto :goto_2

    .line 75
    :cond_2
    :goto_1
    if-eqz v2, :cond_0

    .line 76
    .line 77
    :cond_3
    return-object v2

    .line 78
    :catch_2
    move-exception v1

    .line 79
    move-object v2, v0

    .line 80
    move-object v0, v1

    .line 81
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 82
    .line 83
    .line 84
    return-object v2
.end method

.method public static t(Ljava/lang/Class;)Lr5/a;
    .locals 2

    .line 1
    const-string v0, "java.vm.name"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "Dalvik"

    .line 8
    .line 9
    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    new-instance v0, LT4/a;

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 21
    .line 22
    .line 23
    return-object v0

    .line 24
    :cond_0
    new-instance v0, LT4/b;

    .line 25
    .line 26
    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 31
    .line 32
    .line 33
    invoke-static {p0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    iput-object p0, v0, LT4/b;->a:Ljava/util/logging/Logger;

    .line 38
    .line 39
    return-object v0
.end method

.method public static u()Ljava/lang/String;
    .locals 9

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getMacAddress()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    :try_start_0
    invoke-static {v0}, Lr5/a;->y(Ljava/lang/String;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_3

    .line 10
    .line 11
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-static {v1}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    const-string v2, "list(...)"

    .line 20
    .line 21
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_3

    .line 33
    .line 34
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    check-cast v2, Ljava/net/NetworkInterface;

    .line 39
    .line 40
    invoke-virtual {v2}, Ljava/net/NetworkInterface;->getHardwareAddress()[B

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    if-eqz v2, :cond_0

    .line 45
    .line 46
    new-instance v3, Ljava/lang/StringBuilder;

    .line 47
    .line 48
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 49
    .line 50
    .line 51
    array-length v4, v2

    .line 52
    const/4 v5, 0x0

    .line 53
    :goto_1
    const/4 v6, 0x1

    .line 54
    if-ge v5, v4, :cond_1

    .line 55
    .line 56
    aget-byte v7, v2, v5

    .line 57
    .line 58
    const-string v8, "%02X:"

    .line 59
    .line 60
    invoke-static {v7}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 61
    .line 62
    .line 63
    move-result-object v7

    .line 64
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v7

    .line 68
    invoke-static {v7, v6}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    invoke-static {v8, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v6

    .line 76
    const-string v7, "format(...)"

    .line 77
    .line 78
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    add-int/lit8 v5, v5, 0x1

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :catch_0
    move-exception v1

    .line 88
    goto :goto_2

    .line 89
    :cond_1
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    .line 90
    .line 91
    .line 92
    move-result v2

    .line 93
    if-lez v2, :cond_2

    .line 94
    .line 95
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    .line 96
    .line 97
    .line 98
    move-result v2

    .line 99
    sub-int/2addr v2, v6

    .line 100
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    :cond_2
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    goto :goto_0

    .line 108
    :cond_3
    invoke-static {v0}, Lr5/a;->y(Ljava/lang/String;)Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-eqz v1, :cond_4

    .line 113
    .line 114
    invoke-static {}, Lr5/a;->r()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 118
    goto :goto_3

    .line 119
    :goto_2
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 120
    .line 121
    .line 122
    :cond_4
    :goto_3
    invoke-static {v0}, Lr5/a;->y(Ljava/lang/String;)Z

    .line 123
    .line 124
    .line 125
    move-result v1

    .line 126
    if-eqz v1, :cond_5

    .line 127
    .line 128
    const-string v0, "02:00:00:00:00:00"

    .line 129
    .line 130
    :cond_5
    return-object v0
.end method

.method public static final synthetic w(Landroid/view/View;)Landroid/graphics/Point;
    .locals 3

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    filled-new-array {v0, v0}, [I

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {p0, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 12
    .line 13
    .line 14
    new-instance p0, Landroid/graphics/Point;

    .line 15
    .line 16
    aget v0, v1, v0

    .line 17
    .line 18
    const/4 v2, 0x1

    .line 19
    aget v1, v1, v2

    .line 20
    .line 21
    invoke-direct {p0, v0, v1}, Landroid/graphics/Point;-><init>(II)V

    .line 22
    .line 23
    .line 24
    return-object p0
.end method

.method public static x()Lxf/u;
    .locals 10

    .line 1
    const/4 v0, -0x1

    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const/4 v2, 0x0

    .line 7
    :try_start_0
    invoke-static {}, Lcom/transsnet/palmpay/util/Utils;->getApp()Landroid/app/Application;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    const-string v4, "wifi"

    .line 12
    .line 13
    invoke-virtual {v3, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    const-string v4, "null cannot be cast to non-null type android.net.wifi.WifiManager"

    .line 18
    .line 19
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    check-cast v3, Landroid/net/wifi/WifiManager;

    .line 23
    .line 24
    invoke-virtual {v3}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    .line 25
    .line 26
    .line 27
    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    const-string v5, "unknown ssid"

    .line 29
    .line 30
    const/4 v6, 0x1

    .line 31
    if-eqz v4, :cond_9

    .line 32
    .line 33
    :try_start_1
    invoke-virtual {v3}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    if-eqz v1, :cond_0

    .line 38
    .line 39
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getSSID()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    goto :goto_0

    .line 44
    :catchall_0
    move-exception v0

    .line 45
    goto/16 :goto_9

    .line 46
    .line 47
    :cond_0
    move-object v1, v2

    .line 48
    :goto_0
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    if-nez v4, :cond_1

    .line 53
    .line 54
    if-eqz v1, :cond_3

    .line 55
    .line 56
    invoke-static {v1, v5, v6}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 57
    .line 58
    .line 59
    move-result v4

    .line 60
    if-ne v4, v6, :cond_3

    .line 61
    .line 62
    :cond_1
    invoke-virtual {v3}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    .line 63
    .line 64
    .line 65
    move-result-object v4

    .line 66
    invoke-virtual {v4}, Landroid/net/wifi/WifiInfo;->getNetworkId()I

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    invoke-virtual {v3}, Landroid/net/wifi/WifiManager;->getConfiguredNetworks()Ljava/util/List;

    .line 71
    .line 72
    .line 73
    move-result-object v7

    .line 74
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 75
    .line 76
    .line 77
    move-result-object v7

    .line 78
    :cond_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 79
    .line 80
    .line 81
    move-result v8

    .line 82
    if-eqz v8, :cond_3

    .line 83
    .line 84
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v8

    .line 88
    check-cast v8, Landroid/net/wifi/WifiConfiguration;

    .line 89
    .line 90
    iget v9, v8, Landroid/net/wifi/WifiConfiguration;->networkId:I

    .line 91
    .line 92
    if-ne v9, v4, :cond_2

    .line 93
    .line 94
    iget-object v1, v8, Landroid/net/wifi/WifiConfiguration;->SSID:Ljava/lang/String;

    .line 95
    .line 96
    :cond_3
    invoke-virtual {v3}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    if-eqz v4, :cond_4

    .line 101
    .line 102
    invoke-virtual {v4}, Landroid/net/wifi/WifiInfo;->getRssi()I

    .line 103
    .line 104
    .line 105
    move-result v4

    .line 106
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    goto :goto_1

    .line 111
    :cond_4
    move-object v4, v2

    .line 112
    :goto_1
    const-string v7, "02:00:00:00:00:00"

    .line 113
    .line 114
    invoke-virtual {v3}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    .line 115
    .line 116
    .line 117
    move-result-object v8

    .line 118
    if-eqz v8, :cond_5

    .line 119
    .line 120
    invoke-virtual {v8}, Landroid/net/wifi/WifiInfo;->getBSSID()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v8

    .line 124
    goto :goto_2

    .line 125
    :cond_5
    move-object v8, v2

    .line 126
    :goto_2
    invoke-virtual {v7, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v7

    .line 130
    if-eqz v7, :cond_6

    .line 131
    .line 132
    const-string v3, ""

    .line 133
    .line 134
    goto :goto_3

    .line 135
    :cond_6
    invoke-virtual {v3}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    .line 136
    .line 137
    .line 138
    move-result-object v3

    .line 139
    if-eqz v3, :cond_7

    .line 140
    .line 141
    invoke-virtual {v3}, Landroid/net/wifi/WifiInfo;->getBSSID()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    goto :goto_3

    .line 146
    :cond_7
    move-object v3, v2

    .line 147
    :goto_3
    new-instance v7, Lxf/u;

    .line 148
    .line 149
    if-eqz v4, :cond_8

    .line 150
    .line 151
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 152
    .line 153
    .line 154
    move-result v8

    .line 155
    goto :goto_4

    .line 156
    :cond_8
    move v8, v0

    .line 157
    :goto_4
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 158
    .line 159
    .line 160
    move-result-object v8

    .line 161
    invoke-direct {v7, v1, v8, v3}, Lxf/u;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 162
    .line 163
    .line 164
    move-object v2, v1

    .line 165
    move-object v1, v4

    .line 166
    goto :goto_5

    .line 167
    :cond_9
    move-object v3, v2

    .line 168
    move-object v7, v3

    .line 169
    :goto_5
    :try_start_2
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 170
    .line 171
    .line 172
    move-result v4

    .line 173
    if-nez v4, :cond_a

    .line 174
    .line 175
    if-eqz v2, :cond_c

    .line 176
    .line 177
    invoke-static {v2, v5, v6}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 178
    .line 179
    .line 180
    move-result v2

    .line 181
    if-ne v2, v6, :cond_c

    .line 182
    .line 183
    goto :goto_7

    .line 184
    :goto_6
    move-object v2, v7

    .line 185
    goto :goto_9

    .line 186
    :cond_a
    :goto_7
    invoke-static {}, Lcom/transsnet/palmpay/util/Utils;->getApp()Landroid/app/Application;

    .line 187
    .line 188
    .line 189
    move-result-object v2

    .line 190
    const-string v4, "connectivity"

    .line 191
    .line 192
    invoke-virtual {v2, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v2

    .line 196
    const-string v4, "null cannot be cast to non-null type android.net.ConnectivityManager"

    .line 197
    .line 198
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    check-cast v2, Landroid/net/ConnectivityManager;

    .line 202
    .line 203
    invoke-virtual {v2}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    .line 204
    .line 205
    .line 206
    move-result-object v2

    .line 207
    if-eqz v2, :cond_c

    .line 208
    .line 209
    invoke-virtual {v2}, Landroid/net/NetworkInfo;->getType()I

    .line 210
    .line 211
    .line 212
    move-result v4

    .line 213
    if-ne v4, v6, :cond_c

    .line 214
    .line 215
    invoke-virtual {v2}, Landroid/net/NetworkInfo;->isConnected()Z

    .line 216
    .line 217
    .line 218
    move-result v4

    .line 219
    if-eqz v4, :cond_c

    .line 220
    .line 221
    invoke-virtual {v2}, Landroid/net/NetworkInfo;->getExtraInfo()Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object v2

    .line 225
    new-instance v4, Lxf/u;

    .line 226
    .line 227
    if-eqz v1, :cond_b

    .line 228
    .line 229
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 230
    .line 231
    .line 232
    move-result v0

    .line 233
    goto :goto_8

    .line 234
    :catchall_1
    move-exception v0

    .line 235
    goto :goto_6

    .line 236
    :cond_b
    :goto_8
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 237
    .line 238
    .line 239
    move-result-object v0

    .line 240
    invoke-direct {v4, v2, v0, v3}, Lxf/u;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 241
    .line 242
    .line 243
    return-object v4

    .line 244
    :cond_c
    return-object v7

    .line 245
    :goto_9
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 246
    .line 247
    .line 248
    return-object v2
.end method

.method public static y(Ljava/lang/String;)Z
    .locals 1

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_1

    .line 6
    .line 7
    const-string v0, "please open wifi"

    .line 8
    .line 9
    invoke-virtual {v0, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    const-string v0, "02:00:00:00:00:00"

    .line 16
    .line 17
    invoke-virtual {v0, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    if-eqz p0, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 p0, 0x0

    .line 25
    return p0

    .line 26
    :cond_1
    :goto_0
    const/4 p0, 0x1

    .line 27
    return p0
.end method

.method public static final z(LPg/k;)Z
    .locals 7

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    :try_start_0
    new-instance v2, LPg/k;

    .line 8
    .line 9
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    iget-wide v3, p0, LPg/k;->b:J

    .line 13
    .line 14
    const-wide/16 v5, 0x40

    .line 15
    .line 16
    cmp-long v1, v3, v5

    .line 17
    .line 18
    if-lez v1, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    move-wide v5, v3

    .line 22
    :goto_0
    const-wide/16 v3, 0x0

    .line 23
    .line 24
    move-object v1, p0

    .line 25
    invoke-virtual/range {v1 .. v6}, LPg/k;->d(LPg/k;JJ)V

    .line 26
    .line 27
    .line 28
    move p0, v0

    .line 29
    :goto_1
    const/16 v1, 0x10

    .line 30
    .line 31
    if-ge p0, v1, :cond_3

    .line 32
    .line 33
    invoke-virtual {v2}, LPg/k;->exhausted()Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_1

    .line 38
    .line 39
    goto :goto_2

    .line 40
    :cond_1
    invoke-virtual {v2}, LPg/k;->readUtf8CodePoint()I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    invoke-static {v1}, Ljava/lang/Character;->isISOControl(I)Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    if-eqz v3, :cond_2

    .line 49
    .line 50
    invoke-static {v1}, Ljava/lang/Character;->isWhitespace(I)Z

    .line 51
    .line 52
    .line 53
    move-result v1
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 54
    if-nez v1, :cond_2

    .line 55
    .line 56
    goto :goto_3

    .line 57
    :cond_2
    add-int/lit8 p0, p0, 0x1

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_3
    :goto_2
    const/4 p0, 0x1

    .line 61
    return p0

    .line 62
    :catch_0
    :goto_3
    return v0
.end method


# virtual methods
.method public abstract A(Ljava/lang/Class;)Z
.end method

.method public abstract B(Ljava/lang/String;)V
.end method

.method public abstract l(Ljava/lang/Class;Ljava/lang/reflect/Field;)Ljava/lang/reflect/Method;
.end method

.method public abstract n(Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
.end method

.method public abstract v(Ljava/lang/Class;)[Ljava/lang/String;
.end method
