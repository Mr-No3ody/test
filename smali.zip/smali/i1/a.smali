.class public abstract Li1/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:I

.field public static final b:I

.field public static final c:I

.field public static final d:I

.field public static final e:I

.field public static final f:I

.field public static final g:I

.field public static final h:I

.field public static final i:I

.field public static final j:I

.field public static final k:I

.field public static final l:I

.field public static final m:I


# direct methods
.method static constructor <clinit>()V
    .locals 20

    .line 1
    const/16 v0, 0x66

    .line 2
    .line 3
    int-to-byte v0, v0

    .line 4
    const/16 v1, 0x72

    .line 5
    .line 6
    int-to-byte v1, v1

    .line 7
    const/16 v2, 0x65

    .line 8
    .line 9
    int-to-byte v2, v2

    .line 10
    const/4 v3, 0x4

    .line 11
    new-array v4, v3, [B

    .line 12
    .line 13
    const/4 v5, 0x0

    .line 14
    aput-byte v0, v4, v5

    .line 15
    .line 16
    const/4 v6, 0x1

    .line 17
    aput-byte v1, v4, v6

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    aput-byte v2, v4, v1

    .line 21
    .line 22
    const/4 v7, 0x3

    .line 23
    aput-byte v2, v4, v7

    .line 24
    .line 25
    invoke-static {v4}, Li1/a;->a([B)I

    .line 26
    .line 27
    .line 28
    move-result v4

    .line 29
    sput v4, Li1/a;->a:I

    .line 30
    .line 31
    const/16 v4, 0x6a

    .line 32
    .line 33
    int-to-byte v4, v4

    .line 34
    const/16 v8, 0x75

    .line 35
    .line 36
    int-to-byte v8, v8

    .line 37
    const/16 v9, 0x6e

    .line 38
    .line 39
    int-to-byte v9, v9

    .line 40
    const/16 v10, 0x6b

    .line 41
    .line 42
    int-to-byte v10, v10

    .line 43
    new-array v11, v3, [B

    .line 44
    .line 45
    aput-byte v4, v11, v5

    .line 46
    .line 47
    aput-byte v8, v11, v6

    .line 48
    .line 49
    aput-byte v9, v11, v1

    .line 50
    .line 51
    aput-byte v10, v11, v7

    .line 52
    .line 53
    invoke-static {v11}, Li1/a;->a([B)I

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    sput v4, Li1/a;->b:I

    .line 58
    .line 59
    const/16 v4, 0x6d

    .line 60
    .line 61
    int-to-byte v4, v4

    .line 62
    const/16 v11, 0x64

    .line 63
    .line 64
    int-to-byte v11, v11

    .line 65
    const/16 v12, 0x61

    .line 66
    .line 67
    int-to-byte v12, v12

    .line 68
    const/16 v13, 0x74

    .line 69
    .line 70
    int-to-byte v13, v13

    .line 71
    new-array v14, v3, [B

    .line 72
    .line 73
    aput-byte v4, v14, v5

    .line 74
    .line 75
    aput-byte v11, v14, v6

    .line 76
    .line 77
    aput-byte v12, v14, v1

    .line 78
    .line 79
    aput-byte v13, v14, v7

    .line 80
    .line 81
    invoke-static {v14}, Li1/a;->a([B)I

    .line 82
    .line 83
    .line 84
    move-result v12

    .line 85
    sput v12, Li1/a;->c:I

    .line 86
    .line 87
    const/16 v12, 0x6f

    .line 88
    .line 89
    int-to-byte v12, v12

    .line 90
    const/16 v14, 0x76

    .line 91
    .line 92
    int-to-byte v14, v14

    .line 93
    new-array v15, v3, [B

    .line 94
    .line 95
    aput-byte v4, v15, v5

    .line 96
    .line 97
    aput-byte v12, v15, v6

    .line 98
    .line 99
    aput-byte v12, v15, v1

    .line 100
    .line 101
    aput-byte v14, v15, v7

    .line 102
    .line 103
    invoke-static {v15}, Li1/a;->a([B)I

    .line 104
    .line 105
    .line 106
    move-result v15

    .line 107
    sput v15, Li1/a;->d:I

    .line 108
    .line 109
    const/16 v15, 0x70

    .line 110
    .line 111
    int-to-byte v15, v15

    .line 112
    move/from16 v16, v1

    .line 113
    .line 114
    new-array v1, v3, [B

    .line 115
    .line 116
    aput-byte v15, v1, v5

    .line 117
    .line 118
    aput-byte v9, v1, v6

    .line 119
    .line 120
    aput-byte v12, v1, v16

    .line 121
    .line 122
    aput-byte v13, v1, v7

    .line 123
    .line 124
    invoke-static {v1}, Li1/a;->a([B)I

    .line 125
    .line 126
    .line 127
    move-result v1

    .line 128
    sput v1, Li1/a;->e:I

    .line 129
    .line 130
    const/16 v1, 0x73

    .line 131
    .line 132
    int-to-byte v1, v1

    .line 133
    const/16 v9, 0x69

    .line 134
    .line 135
    int-to-byte v9, v9

    .line 136
    move/from16 v17, v5

    .line 137
    .line 138
    new-array v5, v3, [B

    .line 139
    .line 140
    aput-byte v1, v5, v17

    .line 141
    .line 142
    aput-byte v10, v5, v6

    .line 143
    .line 144
    aput-byte v9, v5, v16

    .line 145
    .line 146
    aput-byte v15, v5, v7

    .line 147
    .line 148
    invoke-static {v5}, Li1/a;->a([B)I

    .line 149
    .line 150
    .line 151
    move-result v5

    .line 152
    sput v5, Li1/a;->f:I

    .line 153
    .line 154
    const/16 v5, 0x77

    .line 155
    .line 156
    int-to-byte v5, v5

    .line 157
    new-array v10, v3, [B

    .line 158
    .line 159
    aput-byte v5, v10, v17

    .line 160
    .line 161
    aput-byte v9, v10, v6

    .line 162
    .line 163
    aput-byte v11, v10, v16

    .line 164
    .line 165
    aput-byte v2, v10, v7

    .line 166
    .line 167
    invoke-static {v10}, Li1/a;->a([B)I

    .line 168
    .line 169
    .line 170
    move-result v2

    .line 171
    sput v2, Li1/a;->g:I

    .line 172
    .line 173
    const/16 v2, 0x50

    .line 174
    .line 175
    int-to-byte v2, v2

    .line 176
    const/16 v5, 0x49

    .line 177
    .line 178
    int-to-byte v5, v5

    .line 179
    const/16 v10, 0x43

    .line 180
    .line 181
    int-to-byte v10, v10

    .line 182
    move/from16 v18, v6

    .line 183
    .line 184
    const/16 v6, 0x54

    .line 185
    .line 186
    int-to-byte v6, v6

    .line 187
    move/from16 v19, v7

    .line 188
    .line 189
    new-array v7, v3, [B

    .line 190
    .line 191
    aput-byte v2, v7, v17

    .line 192
    .line 193
    aput-byte v5, v7, v18

    .line 194
    .line 195
    aput-byte v10, v7, v16

    .line 196
    .line 197
    aput-byte v6, v7, v19

    .line 198
    .line 199
    invoke-static {v7}, Li1/a;->a([B)I

    .line 200
    .line 201
    .line 202
    move-result v2

    .line 203
    sput v2, Li1/a;->h:I

    .line 204
    .line 205
    const/16 v2, 0x79

    .line 206
    .line 207
    int-to-byte v2, v2

    .line 208
    new-array v5, v3, [B

    .line 209
    .line 210
    aput-byte v0, v5, v17

    .line 211
    .line 212
    aput-byte v13, v5, v18

    .line 213
    .line 214
    aput-byte v2, v5, v16

    .line 215
    .line 216
    aput-byte v15, v5, v19

    .line 217
    .line 218
    invoke-static {v5}, Li1/a;->a([B)I

    .line 219
    .line 220
    .line 221
    move-result v0

    .line 222
    sput v0, Li1/a;->i:I

    .line 223
    .line 224
    new-array v0, v3, [B

    .line 225
    .line 226
    aput-byte v8, v0, v17

    .line 227
    .line 228
    aput-byte v8, v0, v18

    .line 229
    .line 230
    aput-byte v9, v0, v16

    .line 231
    .line 232
    aput-byte v11, v0, v19

    .line 233
    .line 234
    invoke-static {v0}, Li1/a;->a([B)I

    .line 235
    .line 236
    .line 237
    move-result v0

    .line 238
    sput v0, Li1/a;->j:I

    .line 239
    .line 240
    const/16 v0, 0x63

    .line 241
    .line 242
    int-to-byte v0, v0

    .line 243
    new-array v2, v3, [B

    .line 244
    .line 245
    aput-byte v0, v2, v17

    .line 246
    .line 247
    aput-byte v4, v2, v18

    .line 248
    .line 249
    aput-byte v12, v2, v16

    .line 250
    .line 251
    aput-byte v14, v2, v19

    .line 252
    .line 253
    invoke-static {v2}, Li1/a;->a([B)I

    .line 254
    .line 255
    .line 256
    move-result v2

    .line 257
    sput v2, Li1/a;->k:I

    .line 258
    .line 259
    new-array v2, v3, [B

    .line 260
    .line 261
    aput-byte v1, v2, v17

    .line 262
    .line 263
    aput-byte v13, v2, v18

    .line 264
    .line 265
    aput-byte v0, v2, v16

    .line 266
    .line 267
    aput-byte v12, v2, v19

    .line 268
    .line 269
    invoke-static {v2}, Li1/a;->a([B)I

    .line 270
    .line 271
    .line 272
    move-result v1

    .line 273
    sput v1, Li1/a;->l:I

    .line 274
    .line 275
    const/16 v1, 0x36

    .line 276
    .line 277
    int-to-byte v1, v1

    .line 278
    const/16 v2, 0x34

    .line 279
    .line 280
    int-to-byte v2, v2

    .line 281
    new-array v3, v3, [B

    .line 282
    .line 283
    aput-byte v0, v3, v17

    .line 284
    .line 285
    aput-byte v12, v3, v18

    .line 286
    .line 287
    aput-byte v1, v3, v16

    .line 288
    .line 289
    aput-byte v2, v3, v19

    .line 290
    .line 291
    invoke-static {v3}, Li1/a;->a([B)I

    .line 292
    .line 293
    .line 294
    move-result v0

    .line 295
    sput v0, Li1/a;->m:I

    .line 296
    .line 297
    return-void
.end method

.method public static final a([B)I
    .locals 1

    .line 1
    const-string v0, "byteArray"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->getInt()I

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    return p0
.end method
