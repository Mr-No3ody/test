.class public abstract Ls0/i;
.super Ls0/j;
.source "SourceFile"
