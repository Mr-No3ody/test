.class public final Le3/r;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lorg/sufficientlysecure/htmltextview/f;

.field public final b:LQ2/a;

.field public final c:LQ2/a;

.field public final d:Z

.field public final e:Z

.field public final f:I

.field public final g:I

.field public final h:Ld3/g;

.field public final i:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Le3/q;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Le3/q;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Le3/p;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    new-instance v0, Lorg/sufficientlysecure/htmltextview/f;

    .line 8
    .line 9
    const/16 v1, 0x9

    .line 10
    .line 11
    invoke-direct {v0, v1}, Lorg/sufficientlysecure/htmltextview/f;-><init>(I)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Le3/r;->a:Lorg/sufficientlysecure/htmltextview/f;

    .line 15
    .line 16
    sget-object v0, Lo2/e;->b:LQ2/a;

    .line 17
    .line 18
    const-string v1, "BOOLEAN_FALSE"

    .line 19
    .line 20
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Le3/r;->b:LQ2/a;

    .line 24
    .line 25
    iget-object v0, p1, Le3/p;->a:LQ2/a;

    .line 26
    .line 27
    iput-object v0, p0, Le3/r;->c:LQ2/a;

    .line 28
    .line 29
    iget-boolean v0, p1, Le3/p;->b:Z

    .line 30
    .line 31
    iput-boolean v0, p0, Le3/r;->d:Z

    .line 32
    .line 33
    iget-boolean v0, p1, Le3/p;->c:Z

    .line 34
    .line 35
    iput-boolean v0, p0, Le3/r;->e:Z

    .line 36
    .line 37
    iget v0, p1, Le3/p;->d:I

    .line 38
    .line 39
    iput v0, p0, Le3/r;->f:I

    .line 40
    .line 41
    iget v0, p1, Le3/p;->e:I

    .line 42
    .line 43
    iput v0, p0, Le3/r;->g:I

    .line 44
    .line 45
    iget-object v0, p1, Le3/p;->f:Ld3/g;

    .line 46
    .line 47
    iput-object v0, p0, Le3/r;->h:Ld3/g;

    .line 48
    .line 49
    iget-boolean p1, p1, Le3/p;->g:Z

    .line 50
    .line 51
    iput-boolean p1, p0, Le3/r;->i:Z

    .line 52
    .line 53
    return-void
.end method
