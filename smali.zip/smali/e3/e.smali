.class public final synthetic Le3/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Le3/h;


# direct methods
.method public synthetic constructor <init>(Le3/h;I)V
    .locals 0

    .line 1
    iput p2, p0, Le3/e;->a:I

    iput-object p1, p0, Le3/e;->b:Le3/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, Le3/e;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Le3/e;->b:Le3/h;

    .line 7
    .line 8
    const-string/jumbo v1, "this$0"

    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v1, v0, Le3/h;->a:LAb/r;

    .line 15
    .line 16
    iget-object v0, v0, Le3/h;->g:Lj2/b;

    .line 17
    .line 18
    invoke-virtual {v1, v0}, LAb/r;->get(Lj2/b;)Lcom/facebook/cache/disk/FileCache;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    return-object v0

    .line 23
    :pswitch_0
    iget-object v0, p0, Le3/e;->b:Le3/h;

    .line 24
    .line 25
    const-string/jumbo v1, "this$0"

    .line 26
    .line 27
    .line 28
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    iget-object v1, v0, Le3/h;->a:LAb/r;

    .line 32
    .line 33
    iget-object v0, v0, Le3/h;->f:Lj2/b;

    .line 34
    .line 35
    invoke-virtual {v1, v0}, LAb/r;->get(Lj2/b;)Lcom/facebook/cache/disk/FileCache;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    return-object v0

    .line 40
    :pswitch_1
    iget-object v0, p0, Le3/e;->b:Le3/h;

    .line 41
    .line 42
    const-string/jumbo v1, "this$0"

    .line 43
    .line 44
    .line 45
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    new-instance v1, Le3/g;

    .line 49
    .line 50
    invoke-direct {v1, v0}, Le3/g;-><init>(Le3/h;)V

    .line 51
    .line 52
    .line 53
    return-object v1

    .line 54
    nop

    .line 55
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
