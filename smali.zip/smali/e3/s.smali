.class public final Le3/s;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static p:Le3/s;

.field public static q:Le3/k;


# instance fields
.field public final a:LHe/a;

.field public final b:Le3/o;

.field public final c:Le3/b;

.field public final d:Lcom/facebook/common/internal/Supplier;

.field public e:Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

.field public f:Landroidx/work/impl/model/b;

.field public g:Lcom/facebook/imagepipeline/cache/f;

.field public h:Landroidx/work/impl/model/b;

.field public i:Lcom/facebook/imagepipeline/decoder/ImageDecoder;

.field public j:Ln3/c;

.field public k:Le3/u;

.field public l:Le3/x;

.field public m:Lc3/a;

.field public n:Lk3/a;

.field public o:Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;


# direct methods
.method public constructor <init>(Le3/o;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Le3/s;->b:Le3/o;

    .line 8
    .line 9
    iget-object v0, p1, Le3/o;->z:Le3/r;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    new-instance v1, LHe/a;

    .line 15
    .line 16
    iget-object v2, p1, Le3/o;->j:Le3/d;

    .line 17
    .line 18
    iget-object v2, v2, Le3/d;->d:Ljava/util/concurrent/ExecutorService;

    .line 19
    .line 20
    invoke-direct {v1, v2}, LHe/a;-><init>(Ljava/util/concurrent/Executor;)V

    .line 21
    .line 22
    .line 23
    iput-object v1, p0, Le3/s;->a:LHe/a;

    .line 24
    .line 25
    new-instance v1, Le3/b;

    .line 26
    .line 27
    iget-object v2, p1, Le3/o;->B:Lcom/facebook/imagepipeline/debug/a;

    .line 28
    .line 29
    invoke-direct {v1, v2}, Le3/b;-><init>(Lcom/facebook/imagepipeline/debug/CloseableReferenceLeakTracker;)V

    .line 30
    .line 31
    .line 32
    iput-object v1, p0, Le3/s;->c:Le3/b;

    .line 33
    .line 34
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 35
    .line 36
    .line 37
    iget-object p1, p1, Le3/o;->h:Le3/h;

    .line 38
    .line 39
    iput-object p1, p0, Le3/s;->d:Lcom/facebook/common/internal/Supplier;

    .line 40
    .line 41
    iget-boolean p1, v0, Le3/r;->i:Z

    .line 42
    .line 43
    if-eqz p1, :cond_0

    .line 44
    .line 45
    sget-object p1, LW2/g;->d:LW2/f;

    .line 46
    .line 47
    invoke-virtual {p1}, LW2/f;->getInstance()LW2/g;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    const/4 v0, 0x1

    .line 52
    iput-boolean v0, p1, LW2/g;->c:Z

    .line 53
    .line 54
    :cond_0
    return-void
.end method

.method public static declared-synchronized h(Le3/o;)V
    .locals 3

    .line 1
    const-class v0, Le3/s;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    sget-object v1, Le3/s;->p:Le3/s;

    .line 5
    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    const-class v1, Le3/s;

    .line 9
    .line 10
    const-string v2, "ImagePipelineFactory has already been initialized! `ImagePipelineFactory.initialize(...)` should only be called once to avoid unexpected behavior."

    .line 11
    .line 12
    invoke-static {v1, v2}, Lp2/a;->s(Ljava/lang/Class;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :catchall_0
    move-exception p0

    .line 17
    goto :goto_1

    .line 18
    :cond_0
    :goto_0
    new-instance v1, Le3/s;

    .line 19
    .line 20
    invoke-direct {v1, p0}, Le3/s;-><init>(Le3/o;)V

    .line 21
    .line 22
    .line 23
    sput-object v1, Le3/s;->p:Le3/s;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 24
    .line 25
    monitor-exit v0

    .line 26
    return-void

    .line 27
    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 28
    throw p0
.end method


# virtual methods
.method public final a()Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;
    .locals 13

    .line 1
    iget-object v0, p0, Le3/s;->o:Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    invoke-virtual {p0}, Le3/s;->f()Lc3/b;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    iget-object v0, p0, Le3/s;->b:Le3/o;

    .line 10
    .line 11
    iget-object v2, v0, Le3/o;->j:Le3/d;

    .line 12
    .line 13
    invoke-virtual {p0}, Le3/s;->b()Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    iget-object v0, v0, Le3/o;->z:Le3/r;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    iget v4, v0, Le3/r;->g:I

    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    sget-boolean v0, Landroidx/camera/core/impl/utils/n;->c:Z

    .line 31
    .line 32
    if-nez v0, :cond_0

    .line 33
    .line 34
    :try_start_0
    const-class v0, Lcom/facebook/fresco/animation/factory/AnimatedFactoryV2Impl;

    .line 35
    .line 36
    const-class v5, Lc3/b;

    .line 37
    .line 38
    const-class v6, Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 39
    .line 40
    const-class v7, Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

    .line 41
    .line 42
    sget-object v8, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 43
    .line 44
    sget-object v10, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 45
    .line 46
    const-class v12, Lcom/facebook/common/executors/SerialExecutorService;

    .line 47
    .line 48
    move-object v9, v8

    .line 49
    move-object v11, v10

    .line 50
    filled-new-array/range {v5 .. v12}, [Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    invoke-virtual {v0, v5}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    move v5, v4

    .line 59
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 60
    .line 61
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 62
    .line 63
    .line 64
    move-result-object v6

    .line 65
    const/16 v5, 0x3e8

    .line 66
    .line 67
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 68
    .line 69
    .line 70
    move-result-object v7

    .line 71
    const/4 v8, 0x0

    .line 72
    move-object v5, v4

    .line 73
    filled-new-array/range {v1 .. v8}, [Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    const-string v1, "null cannot be cast to non-null type com.facebook.imagepipeline.animated.factory.AnimatedFactory"

    .line 82
    .line 83
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    check-cast v0, Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;

    .line 87
    .line 88
    sput-object v0, Landroidx/camera/core/impl/utils/n;->d:Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 89
    .line 90
    :catchall_0
    sget-object v0, Landroidx/camera/core/impl/utils/n;->d:Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;

    .line 91
    .line 92
    if-eqz v0, :cond_0

    .line 93
    .line 94
    const/4 v0, 0x1

    .line 95
    sput-boolean v0, Landroidx/camera/core/impl/utils/n;->c:Z

    .line 96
    .line 97
    :cond_0
    sget-object v0, Landroidx/camera/core/impl/utils/n;->d:Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;

    .line 98
    .line 99
    iput-object v0, p0, Le3/s;->o:Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;

    .line 100
    .line 101
    :cond_1
    iget-object v0, p0, Le3/s;->o:Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;

    .line 102
    .line 103
    return-object v0
.end method

.method public final b()Lcom/facebook/imagepipeline/cache/CountingMemoryCache;
    .locals 8

    .line 1
    iget-object v0, p0, Le3/s;->e:Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Le3/s;->b:Le3/o;

    .line 6
    .line 7
    iget-object v1, v0, Le3/o;->C:Lcom/facebook/imagepipeline/cache/c;

    .line 8
    .line 9
    iget-object v2, v0, Le3/o;->z:Le3/r;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    const/4 v7, 0x0

    .line 18
    const/4 v5, 0x0

    .line 19
    iget-object v2, v0, Le3/o;->b:Ld3/f;

    .line 20
    .line 21
    iget-object v3, v0, Le3/o;->p:Lr2/c;

    .line 22
    .line 23
    iget-object v4, v0, Le3/o;->c:Lcom/facebook/imagepipeline/cache/a;

    .line 24
    .line 25
    const/4 v6, 0x0

    .line 26
    invoke-virtual/range {v1 .. v7}, Lcom/facebook/imagepipeline/cache/c;->create(Lcom/facebook/common/internal/Supplier;Lcom/facebook/common/memory/MemoryTrimmableRegistry;Lcom/facebook/imagepipeline/cache/MemoryCache$CacheTrimStrategy;ZZLcom/facebook/imagepipeline/cache/CountingMemoryCache$EntryStateObserver;)Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iput-object v0, p0, Le3/s;->e:Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

    .line 31
    .line 32
    :cond_0
    iget-object v0, p0, Le3/s;->e:Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

    .line 33
    .line 34
    return-object v0
.end method

.method public final c()Landroidx/work/impl/model/b;
    .locals 4

    .line 1
    iget-object v0, p0, Le3/s;->f:Landroidx/work/impl/model/b;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, Le3/s;->b()Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Le3/s;->b:Le3/o;

    .line 10
    .line 11
    iget-object v1, v1, Le3/o;->k:Ld3/j;

    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    new-instance v2, Lm6/j;

    .line 17
    .line 18
    const/16 v3, 0x11

    .line 19
    .line 20
    invoke-direct {v2, v1, v3}, Lm6/j;-><init>(Ljava/lang/Object;I)V

    .line 21
    .line 22
    .line 23
    new-instance v1, Landroidx/work/impl/model/b;

    .line 24
    .line 25
    const/16 v3, 0x8

    .line 26
    .line 27
    invoke-direct {v1, v3, v0, v2}, Landroidx/work/impl/model/b;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iput-object v1, p0, Le3/s;->f:Landroidx/work/impl/model/b;

    .line 31
    .line 32
    :cond_0
    iget-object v0, p0, Le3/s;->f:Landroidx/work/impl/model/b;

    .line 33
    .line 34
    return-object v0
.end method

.method public final d()Landroidx/work/impl/model/b;
    .locals 9

    .line 1
    iget-object v0, p0, Le3/s;->h:Landroidx/work/impl/model/b;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Le3/s;->b:Le3/o;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Le3/s;->g:Lcom/facebook/imagepipeline/cache/f;

    .line 11
    .line 12
    if-nez v1, :cond_0

    .line 13
    .line 14
    new-instance v3, Lcom/facebook/imagepipeline/cache/e;

    .line 15
    .line 16
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 17
    .line 18
    .line 19
    new-instance v2, Lcom/facebook/imagepipeline/cache/f;

    .line 20
    .line 21
    const/4 v7, 0x0

    .line 22
    const/4 v8, 0x0

    .line 23
    iget-object v4, v0, Le3/o;->d:Lcom/facebook/imagepipeline/cache/g;

    .line 24
    .line 25
    iget-object v5, v0, Le3/o;->i:Ld3/h;

    .line 26
    .line 27
    const/4 v6, 0x0

    .line 28
    invoke-direct/range {v2 .. v8}, Lcom/facebook/imagepipeline/cache/f;-><init>(Lcom/facebook/imagepipeline/cache/ValueDescriptor;Lcom/facebook/imagepipeline/cache/MemoryCache$CacheTrimStrategy;Lcom/facebook/common/internal/Supplier;Lcom/facebook/imagepipeline/cache/CountingMemoryCache$EntryStateObserver;ZZ)V

    .line 29
    .line 30
    .line 31
    iget-object v1, v0, Le3/o;->p:Lr2/c;

    .line 32
    .line 33
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    iput-object v2, p0, Le3/s;->g:Lcom/facebook/imagepipeline/cache/f;

    .line 37
    .line 38
    :cond_0
    iget-object v1, p0, Le3/s;->g:Lcom/facebook/imagepipeline/cache/f;

    .line 39
    .line 40
    iget-object v0, v0, Le3/o;->k:Ld3/j;

    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    new-instance v2, Ld3/k;

    .line 46
    .line 47
    const/16 v3, 0x15

    .line 48
    .line 49
    invoke-direct {v2, v0, v3}, Ld3/k;-><init>(Ljava/lang/Object;I)V

    .line 50
    .line 51
    .line 52
    new-instance v0, Landroidx/work/impl/model/b;

    .line 53
    .line 54
    const/16 v3, 0x8

    .line 55
    .line 56
    invoke-direct {v0, v3, v1, v2}, Landroidx/work/impl/model/b;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    iput-object v0, p0, Le3/s;->h:Landroidx/work/impl/model/b;

    .line 60
    .line 61
    :cond_1
    iget-object v0, p0, Le3/s;->h:Landroidx/work/impl/model/b;

    .line 62
    .line 63
    return-object v0
.end method

.method public final e()Le3/k;
    .locals 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget-object v1, Le3/s;->q:Le3/k;

    .line 4
    .line 5
    if-nez v1, :cond_8

    .line 6
    .line 7
    new-instance v2, Le3/k;

    .line 8
    .line 9
    iget-object v1, v0, Le3/s;->b:Le3/o;

    .line 10
    .line 11
    iget-object v3, v1, Le3/o;->z:Le3/r;

    .line 12
    .line 13
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    iget-object v3, v0, Le3/s;->l:Le3/x;

    .line 17
    .line 18
    iget-object v4, v1, Le3/o;->z:Le3/r;

    .line 19
    .line 20
    iget-object v10, v0, Le3/s;->a:LHe/a;

    .line 21
    .line 22
    if-nez v3, :cond_7

    .line 23
    .line 24
    new-instance v5, Le3/x;

    .line 25
    .line 26
    iget-object v3, v1, Le3/o;->f:Landroid/content/Context;

    .line 27
    .line 28
    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 29
    .line 30
    .line 31
    move-result-object v6

    .line 32
    invoke-virtual {v6}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 33
    .line 34
    .line 35
    move-result-object v6

    .line 36
    iget-object v7, v0, Le3/s;->k:Le3/u;

    .line 37
    .line 38
    if-nez v7, :cond_4

    .line 39
    .line 40
    iget-object v11, v4, Le3/r;->a:Lorg/sufficientlysecure/htmltextview/f;

    .line 41
    .line 42
    iget-object v7, v1, Le3/o;->s:Lj3/w;

    .line 43
    .line 44
    iget-object v9, v7, Lj3/w;->h:Lj3/p;

    .line 45
    .line 46
    if-nez v9, :cond_0

    .line 47
    .line 48
    new-instance v9, Lj3/p;

    .line 49
    .line 50
    iget-object v12, v7, Lj3/w;->a:Lj3/v;

    .line 51
    .line 52
    iget-object v13, v12, Lj3/v;->g:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v13, Lj3/x;

    .line 55
    .line 56
    iget-object v14, v12, Lj3/v;->j:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v14, Lj3/u;

    .line 59
    .line 60
    iget-object v12, v12, Lj3/v;->k:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v12, Lr2/c;

    .line 63
    .line 64
    invoke-direct {v9, v12, v13, v14}, Lj3/p;-><init>(Lr2/c;Lj3/x;Lj3/u;)V

    .line 65
    .line 66
    .line 67
    iput-object v9, v7, Lj3/w;->h:Lj3/p;

    .line 68
    .line 69
    :cond_0
    iget-object v13, v7, Lj3/w;->h:Lj3/p;

    .line 70
    .line 71
    iget-object v9, v0, Le3/s;->i:Lcom/facebook/imagepipeline/decoder/ImageDecoder;

    .line 72
    .line 73
    if-nez v9, :cond_3

    .line 74
    .line 75
    invoke-virtual {v0}, Le3/s;->a()Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;

    .line 76
    .line 77
    .line 78
    move-result-object v9

    .line 79
    if-eqz v9, :cond_1

    .line 80
    .line 81
    invoke-interface {v9}, Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;->getGifDecoder()Lcom/facebook/imagepipeline/decoder/ImageDecoder;

    .line 82
    .line 83
    .line 84
    move-result-object v12

    .line 85
    invoke-interface {v9}, Lcom/facebook/imagepipeline/animated/factory/AnimatedFactory;->getWebPDecoder()Lcom/facebook/imagepipeline/decoder/ImageDecoder;

    .line 86
    .line 87
    .line 88
    move-result-object v9

    .line 89
    goto :goto_0

    .line 90
    :cond_1
    const/4 v9, 0x0

    .line 91
    const/4 v12, 0x0

    .line 92
    :goto_0
    iget-boolean v14, v4, Le3/r;->i:Z

    .line 93
    .line 94
    if-eqz v14, :cond_2

    .line 95
    .line 96
    new-instance v14, Lo3/b;

    .line 97
    .line 98
    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 99
    .line 100
    .line 101
    move-result-object v3

    .line 102
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    invoke-direct {v14, v3}, Lo3/b;-><init>(Landroid/content/res/Resources;)V

    .line 107
    .line 108
    .line 109
    goto :goto_1

    .line 110
    :cond_2
    const/4 v14, 0x0

    .line 111
    :goto_1
    new-instance v3, LN2/a;

    .line 112
    .line 113
    invoke-virtual {v0}, Le3/s;->g()Lcom/facebook/imagepipeline/platform/PlatformDecoder;

    .line 114
    .line 115
    .line 116
    move-result-object v15

    .line 117
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 118
    .line 119
    .line 120
    new-instance v8, LAb/r;

    .line 121
    .line 122
    move-object/from16 v34, v2

    .line 123
    .line 124
    const/16 v2, 0x12

    .line 125
    .line 126
    invoke-direct {v8, v3, v2}, LAb/r;-><init>(Ljava/lang/Object;I)V

    .line 127
    .line 128
    .line 129
    iput-object v8, v3, LN2/a;->e:Ljava/lang/Object;

    .line 130
    .line 131
    iput-object v12, v3, LN2/a;->a:Ljava/lang/Object;

    .line 132
    .line 133
    iput-object v9, v3, LN2/a;->b:Ljava/lang/Object;

    .line 134
    .line 135
    iput-object v14, v3, LN2/a;->c:Ljava/lang/Object;

    .line 136
    .line 137
    iput-object v15, v3, LN2/a;->d:Ljava/lang/Object;

    .line 138
    .line 139
    iput-object v3, v0, Le3/s;->i:Lcom/facebook/imagepipeline/decoder/ImageDecoder;

    .line 140
    .line 141
    goto :goto_2

    .line 142
    :cond_3
    move-object/from16 v34, v2

    .line 143
    .line 144
    :goto_2
    iget-object v14, v0, Le3/s;->i:Lcom/facebook/imagepipeline/decoder/ImageDecoder;

    .line 145
    .line 146
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    .line 148
    .line 149
    iget v2, v1, Le3/o;->q:I

    .line 150
    .line 151
    invoke-virtual {v7, v2}, Lj3/w;->b(I)Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 152
    .line 153
    .line 154
    move-result-object v20

    .line 155
    invoke-virtual {v7}, Lj3/w;->c()Lr2/g;

    .line 156
    .line 157
    .line 158
    move-result-object v21

    .line 159
    invoke-virtual {v0}, Le3/s;->c()Landroidx/work/impl/model/b;

    .line 160
    .line 161
    .line 162
    move-result-object v22

    .line 163
    invoke-virtual {v0}, Le3/s;->d()Landroidx/work/impl/model/b;

    .line 164
    .line 165
    .line 166
    move-result-object v23

    .line 167
    invoke-virtual {v0}, Le3/s;->f()Lc3/b;

    .line 168
    .line 169
    .line 170
    move-result-object v26

    .line 171
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 172
    .line 173
    .line 174
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 175
    .line 176
    .line 177
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 178
    .line 179
    .line 180
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 181
    .line 182
    .line 183
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 184
    .line 185
    .line 186
    iget v2, v4, Le3/r;->f:I

    .line 187
    .line 188
    const/16 v29, 0x0

    .line 189
    .line 190
    const/16 v30, 0x800

    .line 191
    .line 192
    iget-object v12, v1, Le3/o;->f:Landroid/content/Context;

    .line 193
    .line 194
    iget-object v15, v1, Le3/o;->t:Lorg/sufficientlysecure/htmltextview/l;

    .line 195
    .line 196
    iget-object v3, v1, Le3/o;->g:Le3/i;

    .line 197
    .line 198
    iget-boolean v7, v1, Le3/o;->x:Z

    .line 199
    .line 200
    const/16 v18, 0x0

    .line 201
    .line 202
    iget-object v8, v1, Le3/o;->j:Le3/d;

    .line 203
    .line 204
    iget-object v9, v0, Le3/s;->d:Lcom/facebook/common/internal/Supplier;

    .line 205
    .line 206
    move/from16 v33, v2

    .line 207
    .line 208
    iget-object v2, v1, Le3/o;->e:Ld3/g;

    .line 209
    .line 210
    const/16 v27, 0x0

    .line 211
    .line 212
    const/16 v28, 0x0

    .line 213
    .line 214
    move-object/from16 v25, v2

    .line 215
    .line 216
    iget-object v2, v0, Le3/s;->c:Le3/b;

    .line 217
    .line 218
    const/16 v32, 0x0

    .line 219
    .line 220
    move-object/from16 v31, v2

    .line 221
    .line 222
    move-object/from16 v16, v3

    .line 223
    .line 224
    move/from16 v17, v7

    .line 225
    .line 226
    move-object/from16 v19, v8

    .line 227
    .line 228
    move-object/from16 v24, v9

    .line 229
    .line 230
    invoke-virtual/range {v11 .. v33}, Lorg/sufficientlysecure/htmltextview/f;->createProducerFactory(Landroid/content/Context;Lcom/facebook/common/memory/ByteArrayPool;Lcom/facebook/imagepipeline/decoder/ImageDecoder;Lcom/facebook/imagepipeline/decoder/ProgressiveJpegConfig;Le3/i;ZZLcom/facebook/imagepipeline/core/ExecutorSupplier;Lcom/facebook/common/memory/PooledByteBufferFactory;Lr2/g;Lcom/facebook/imagepipeline/cache/MemoryCache;Lcom/facebook/imagepipeline/cache/MemoryCache;Lcom/facebook/common/internal/Supplier;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lc3/b;IIZILe3/b;ZI)Le3/u;

    .line 231
    .line 232
    .line 233
    move-result-object v2

    .line 234
    iput-object v2, v0, Le3/s;->k:Le3/u;

    .line 235
    .line 236
    goto :goto_3

    .line 237
    :cond_4
    move-object/from16 v34, v2

    .line 238
    .line 239
    :goto_3
    iget-object v7, v0, Le3/s;->k:Le3/u;

    .line 240
    .line 241
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 242
    .line 243
    .line 244
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 245
    .line 246
    .line 247
    iget-object v2, v0, Le3/s;->j:Ln3/c;

    .line 248
    .line 249
    if-nez v2, :cond_6

    .line 250
    .line 251
    iget-object v2, v1, Le3/o;->l:Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;

    .line 252
    .line 253
    if-nez v2, :cond_5

    .line 254
    .line 255
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 256
    .line 257
    .line 258
    :cond_5
    new-instance v3, Ln3/c;

    .line 259
    .line 260
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 261
    .line 262
    .line 263
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 264
    .line 265
    .line 266
    iget-boolean v8, v4, Le3/r;->e:Z

    .line 267
    .line 268
    const/4 v9, 0x0

    .line 269
    invoke-direct {v3, v2, v9, v8}, Ln3/c;-><init>(Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;Ljava/lang/Integer;Z)V

    .line 270
    .line 271
    .line 272
    iput-object v3, v0, Le3/s;->j:Ln3/c;

    .line 273
    .line 274
    :cond_6
    iget-object v13, v0, Le3/s;->j:Ln3/c;

    .line 275
    .line 276
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 277
    .line 278
    .line 279
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 280
    .line 281
    .line 282
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 283
    .line 284
    .line 285
    iget-object v8, v1, Le3/o;->r:Lcom/facebook/imagepipeline/producers/NetworkFetcher;

    .line 286
    .line 287
    iget-boolean v9, v1, Le3/o;->x:Z

    .line 288
    .line 289
    iget-object v11, v1, Le3/o;->g:Le3/i;

    .line 290
    .line 291
    iget-boolean v12, v1, Le3/o;->A:Z

    .line 292
    .line 293
    iget-object v14, v1, Le3/o;->w:Lkotlin/collections/B;

    .line 294
    .line 295
    invoke-direct/range {v5 .. v14}, Le3/x;-><init>(Landroid/content/ContentResolver;Le3/u;Lcom/facebook/imagepipeline/producers/NetworkFetcher;ZLHe/a;Le3/i;ZLn3/c;Ljava/util/Set;)V

    .line 296
    .line 297
    .line 298
    iput-object v5, v0, Le3/s;->l:Le3/x;

    .line 299
    .line 300
    goto :goto_4

    .line 301
    :cond_7
    move-object/from16 v34, v2

    .line 302
    .line 303
    :goto_4
    iget-object v3, v0, Le3/s;->l:Le3/x;

    .line 304
    .line 305
    invoke-virtual {v0}, Le3/s;->c()Landroidx/work/impl/model/b;

    .line 306
    .line 307
    .line 308
    move-result-object v7

    .line 309
    invoke-virtual {v0}, Le3/s;->d()Landroidx/work/impl/model/b;

    .line 310
    .line 311
    .line 312
    move-result-object v8

    .line 313
    iget-object v12, v4, Le3/r;->c:LQ2/a;

    .line 314
    .line 315
    iget-object v13, v4, Le3/r;->b:LQ2/a;

    .line 316
    .line 317
    iget-object v15, v0, Le3/s;->b:Le3/o;

    .line 318
    .line 319
    iget-object v9, v0, Le3/s;->d:Lcom/facebook/common/internal/Supplier;

    .line 320
    .line 321
    iget-object v4, v1, Le3/o;->u:Ljava/util/Set;

    .line 322
    .line 323
    iget-object v5, v1, Le3/o;->v:Lkotlin/collections/B;

    .line 324
    .line 325
    iget-object v6, v1, Le3/o;->n:LQ2/a;

    .line 326
    .line 327
    iget-object v1, v1, Le3/o;->e:Ld3/g;

    .line 328
    .line 329
    const/4 v14, 0x0

    .line 330
    move-object v11, v10

    .line 331
    move-object/from16 v2, v34

    .line 332
    .line 333
    move-object v10, v1

    .line 334
    invoke-direct/range {v2 .. v15}, Le3/k;-><init>(Le3/x;Ljava/util/Set;Ljava/util/Set;Lcom/facebook/common/internal/Supplier;Landroidx/work/impl/model/b;Landroidx/work/impl/model/b;Lcom/facebook/common/internal/Supplier;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;LHe/a;LQ2/a;LQ2/a;Lcom/facebook/callercontext/CallerContextVerifier;Le3/o;)V

    .line 335
    .line 336
    .line 337
    sput-object v2, Le3/s;->q:Le3/k;

    .line 338
    .line 339
    :cond_8
    sget-object v1, Le3/s;->q:Le3/k;

    .line 340
    .line 341
    return-object v1
.end method

.method public final f()Lc3/b;
    .locals 4

    .line 1
    iget-object v0, p0, Le3/s;->m:Lc3/a;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Le3/s;->b:Le3/o;

    .line 6
    .line 7
    iget-object v0, v0, Le3/o;->s:Lj3/w;

    .line 8
    .line 9
    invoke-virtual {p0}, Le3/s;->g()Lcom/facebook/imagepipeline/platform/PlatformDecoder;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const-string v2, "poolFactory"

    .line 14
    .line 15
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    const-string v2, "platformDecoder"

    .line 19
    .line 20
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget-object v1, p0, Le3/s;->c:Le3/b;

    .line 24
    .line 25
    const-string v2, "closeableReferenceFactory"

    .line 26
    .line 27
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    new-instance v2, Lc3/a;

    .line 31
    .line 32
    invoke-virtual {v0}, Lj3/w;->a()Lcom/facebook/imagepipeline/memory/BitmapPool;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    const-string v3, "getBitmapPool(...)"

    .line 37
    .line 38
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-direct {v2, v0, v1}, Lc3/a;-><init>(Lcom/facebook/imagepipeline/memory/BitmapPool;Le3/b;)V

    .line 42
    .line 43
    .line 44
    iput-object v2, p0, Le3/s;->m:Lc3/a;

    .line 45
    .line 46
    :cond_0
    iget-object v0, p0, Le3/s;->m:Lc3/a;

    .line 47
    .line 48
    return-object v0
.end method

.method public final g()Lcom/facebook/imagepipeline/platform/PlatformDecoder;
    .locals 8

    .line 1
    iget-object v0, p0, Le3/s;->n:Lk3/a;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Le3/s;->b:Le3/o;

    .line 6
    .line 7
    iget-object v1, v0, Le3/o;->s:Lj3/w;

    .line 8
    .line 9
    iget-object v0, v0, Le3/o;->z:Le3/r;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Le3/r;->h:Ld3/g;

    .line 18
    .line 19
    const-string v2, "poolFactory"

    .line 20
    .line 21
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const-string v2, "platformDecoderOptions"

    .line 25
    .line 26
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 30
    .line 31
    const/16 v4, 0x1a

    .line 32
    .line 33
    const-string v5, "decodeBuffers"

    .line 34
    .line 35
    const-string v6, "bitmapPool"

    .line 36
    .line 37
    const-string v7, "getBitmapPool(...)"

    .line 38
    .line 39
    if-lt v3, v4, :cond_0

    .line 40
    .line 41
    new-instance v3, Lk3/a;

    .line 42
    .line 43
    invoke-virtual {v1}, Lj3/w;->a()Lcom/facebook/imagepipeline/memory/BitmapPool;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-static {v1}, Landroidx/camera/core/impl/utils/executor/g;->g(Lj3/w;)Landroidx/core/util/Pools$Pool;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    const/4 v2, 0x1

    .line 64
    invoke-direct {v3, v4, v1, v0, v2}, Lk3/a;-><init>(Lcom/facebook/imagepipeline/memory/BitmapPool;Landroidx/core/util/Pools$Pool;Ld3/g;I)V

    .line 65
    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_0
    new-instance v3, Lk3/a;

    .line 69
    .line 70
    invoke-virtual {v1}, Lj3/w;->a()Lcom/facebook/imagepipeline/memory/BitmapPool;

    .line 71
    .line 72
    .line 73
    move-result-object v4

    .line 74
    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-static {v1}, Landroidx/camera/core/impl/utils/executor/g;->g(Lj3/w;)Landroidx/core/util/Pools$Pool;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    const/4 v2, 0x0

    .line 91
    invoke-direct {v3, v4, v1, v0, v2}, Lk3/a;-><init>(Lcom/facebook/imagepipeline/memory/BitmapPool;Landroidx/core/util/Pools$Pool;Ld3/g;I)V

    .line 92
    .line 93
    .line 94
    :goto_0
    iput-object v3, p0, Le3/s;->n:Lk3/a;

    .line 95
    .line 96
    :cond_1
    iget-object v0, p0, Le3/s;->n:Lk3/a;

    .line 97
    .line 98
    return-object v0
.end method
