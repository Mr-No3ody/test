.class public final Le3/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Le3/a;


# direct methods
.method public constructor <init>(Lcom/facebook/imagepipeline/debug/CloseableReferenceLeakTracker;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Le3/a;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Le3/a;-><init>(Lcom/facebook/imagepipeline/debug/CloseableReferenceLeakTracker;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Le3/b;->a:Le3/a;

    .line 10
    .line 11
    return-void
.end method
