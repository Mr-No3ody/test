.class public final synthetic Le3/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Le3/g;

.field public final synthetic c:Le3/h;


# direct methods
.method public synthetic constructor <init>(Le3/g;Le3/h;I)V
    .locals 0

    .line 1
    iput p3, p0, Le3/f;->a:I

    iput-object p1, p0, Le3/f;->b:Le3/g;

    iput-object p2, p0, Le3/f;->c:Le3/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Le3/h;Le3/g;)V
    .locals 1

    .line 2
    const/4 v0, 0x2

    iput v0, p0, Le3/f;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Le3/f;->c:Le3/h;

    iput-object p2, p0, Le3/f;->b:Le3/g;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 12

    .line 1
    iget v0, p0, Le3/f;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Le3/f;->b:Le3/g;

    .line 7
    .line 8
    const-string/jumbo v1, "this$0"

    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, Le3/f;->c:Le3/h;

    .line 15
    .line 16
    const-string/jumbo v2, "this$1"

    .line 17
    .line 18
    .line 19
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Le3/g;->getDynamicFileCaches()Ljava/util/Map;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 27
    .line 28
    invoke-interface {v0}, Ljava/util/Map;->size()I

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    invoke-static {v3}, Lkotlin/collections/F;->a(I)I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    invoke-direct {v2, v3}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 37
    .line 38
    .line 39
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    if-eqz v3, :cond_0

    .line 52
    .line 53
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    check-cast v3, Ljava/util/Map$Entry;

    .line 58
    .line 59
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    move-object v6, v3

    .line 68
    check-cast v6, Lcom/facebook/cache/disk/FileCache;

    .line 69
    .line 70
    new-instance v5, Ld3/d;

    .line 71
    .line 72
    iget-object v3, v1, Le3/h;->b:Lj3/w;

    .line 73
    .line 74
    iget v7, v1, Le3/h;->e:I

    .line 75
    .line 76
    invoke-virtual {v3, v7}, Lj3/w;->b(I)Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 77
    .line 78
    .line 79
    move-result-object v7

    .line 80
    const-string v3, "getPooledByteBufferFactory(...)"

    .line 81
    .line 82
    invoke-static {v7, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    iget-object v3, v1, Le3/h;->b:Lj3/w;

    .line 86
    .line 87
    invoke-virtual {v3}, Lj3/w;->c()Lr2/g;

    .line 88
    .line 89
    .line 90
    move-result-object v8

    .line 91
    const-string v3, "getPooledByteStreams(...)"

    .line 92
    .line 93
    invoke-static {v8, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    iget-object v3, v1, Le3/h;->c:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 97
    .line 98
    invoke-interface {v3}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 99
    .line 100
    .line 101
    move-result-object v9

    .line 102
    const-string v10, "forLocalStorageRead(...)"

    .line 103
    .line 104
    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    invoke-interface {v3}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageWrite()Ljava/util/concurrent/Executor;

    .line 108
    .line 109
    .line 110
    move-result-object v10

    .line 111
    const-string v3, "forLocalStorageWrite(...)"

    .line 112
    .line 113
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    iget-object v11, v1, Le3/h;->d:Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;

    .line 117
    .line 118
    invoke-direct/range {v5 .. v11}, Ld3/d;-><init>(Lcom/facebook/cache/disk/FileCache;Lcom/facebook/common/memory/PooledByteBufferFactory;Lr2/g;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;)V

    .line 119
    .line 120
    .line 121
    invoke-interface {v2, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    goto :goto_0

    .line 125
    :cond_0
    new-instance v0, Lo2/d;

    .line 126
    .line 127
    invoke-direct {v0, v2}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 128
    .line 129
    .line 130
    return-object v0

    .line 131
    :pswitch_0
    iget-object v0, p0, Le3/f;->c:Le3/h;

    .line 132
    .line 133
    const-string/jumbo v1, "this$0"

    .line 134
    .line 135
    .line 136
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    const-string/jumbo v1, "this$1"

    .line 140
    .line 141
    .line 142
    iget-object v2, p0, Le3/f;->b:Le3/g;

    .line 143
    .line 144
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    iget-object v1, v0, Le3/h;->h:Ljava/util/Map;

    .line 148
    .line 149
    if-eqz v1, :cond_1

    .line 150
    .line 151
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 152
    .line 153
    invoke-interface {v1}, Ljava/util/Map;->size()I

    .line 154
    .line 155
    .line 156
    move-result v3

    .line 157
    invoke-static {v3}, Lkotlin/collections/F;->a(I)I

    .line 158
    .line 159
    .line 160
    move-result v3

    .line 161
    invoke-direct {v2, v3}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 162
    .line 163
    .line 164
    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 169
    .line 170
    .line 171
    move-result-object v1

    .line 172
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 173
    .line 174
    .line 175
    move-result v3

    .line 176
    if-eqz v3, :cond_2

    .line 177
    .line 178
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v3

    .line 182
    check-cast v3, Ljava/util/Map$Entry;

    .line 183
    .line 184
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v4

    .line 188
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v3

    .line 192
    check-cast v3, Lj2/b;

    .line 193
    .line 194
    iget-object v5, v0, Le3/h;->a:LAb/r;

    .line 195
    .line 196
    invoke-virtual {v5, v3}, LAb/r;->get(Lj2/b;)Lcom/facebook/cache/disk/FileCache;

    .line 197
    .line 198
    .line 199
    move-result-object v3

    .line 200
    invoke-interface {v2, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    goto :goto_1

    .line 204
    :cond_1
    invoke-static {}, Lkotlin/collections/G;->c()Lkotlin/collections/A;

    .line 205
    .line 206
    .line 207
    move-result-object v2

    .line 208
    :cond_2
    return-object v2

    .line 209
    :pswitch_1
    iget-object v0, p0, Le3/f;->b:Le3/g;

    .line 210
    .line 211
    const-string/jumbo v1, "this$0"

    .line 212
    .line 213
    .line 214
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    iget-object v1, p0, Le3/f;->c:Le3/h;

    .line 218
    .line 219
    const-string/jumbo v2, "this$1"

    .line 220
    .line 221
    .line 222
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 223
    .line 224
    .line 225
    new-instance v3, Ld3/d;

    .line 226
    .line 227
    invoke-virtual {v0}, Le3/g;->getSmallImageFileCache()Lcom/facebook/cache/disk/FileCache;

    .line 228
    .line 229
    .line 230
    move-result-object v4

    .line 231
    iget-object v0, v1, Le3/h;->b:Lj3/w;

    .line 232
    .line 233
    iget v2, v1, Le3/h;->e:I

    .line 234
    .line 235
    invoke-virtual {v0, v2}, Lj3/w;->b(I)Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 236
    .line 237
    .line 238
    move-result-object v5

    .line 239
    const-string v0, "getPooledByteBufferFactory(...)"

    .line 240
    .line 241
    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 242
    .line 243
    .line 244
    iget-object v0, v1, Le3/h;->b:Lj3/w;

    .line 245
    .line 246
    invoke-virtual {v0}, Lj3/w;->c()Lr2/g;

    .line 247
    .line 248
    .line 249
    move-result-object v6

    .line 250
    const-string v0, "getPooledByteStreams(...)"

    .line 251
    .line 252
    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 253
    .line 254
    .line 255
    iget-object v0, v1, Le3/h;->c:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 256
    .line 257
    invoke-interface {v0}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 258
    .line 259
    .line 260
    move-result-object v7

    .line 261
    const-string v2, "forLocalStorageRead(...)"

    .line 262
    .line 263
    invoke-static {v7, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    invoke-interface {v0}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageWrite()Ljava/util/concurrent/Executor;

    .line 267
    .line 268
    .line 269
    move-result-object v8

    .line 270
    const-string v0, "forLocalStorageWrite(...)"

    .line 271
    .line 272
    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    iget-object v9, v1, Le3/h;->d:Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;

    .line 276
    .line 277
    invoke-direct/range {v3 .. v9}, Ld3/d;-><init>(Lcom/facebook/cache/disk/FileCache;Lcom/facebook/common/memory/PooledByteBufferFactory;Lr2/g;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;)V

    .line 278
    .line 279
    .line 280
    return-object v3

    .line 281
    :pswitch_2
    iget-object v0, p0, Le3/f;->b:Le3/g;

    .line 282
    .line 283
    const-string/jumbo v1, "this$0"

    .line 284
    .line 285
    .line 286
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    iget-object v1, p0, Le3/f;->c:Le3/h;

    .line 290
    .line 291
    const-string/jumbo v2, "this$1"

    .line 292
    .line 293
    .line 294
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    new-instance v3, Ld3/d;

    .line 298
    .line 299
    invoke-virtual {v0}, Le3/g;->getMainFileCache()Lcom/facebook/cache/disk/FileCache;

    .line 300
    .line 301
    .line 302
    move-result-object v4

    .line 303
    iget-object v0, v1, Le3/h;->b:Lj3/w;

    .line 304
    .line 305
    iget v2, v1, Le3/h;->e:I

    .line 306
    .line 307
    invoke-virtual {v0, v2}, Lj3/w;->b(I)Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 308
    .line 309
    .line 310
    move-result-object v5

    .line 311
    const-string v0, "getPooledByteBufferFactory(...)"

    .line 312
    .line 313
    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 314
    .line 315
    .line 316
    iget-object v0, v1, Le3/h;->b:Lj3/w;

    .line 317
    .line 318
    invoke-virtual {v0}, Lj3/w;->c()Lr2/g;

    .line 319
    .line 320
    .line 321
    move-result-object v6

    .line 322
    const-string v0, "getPooledByteStreams(...)"

    .line 323
    .line 324
    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 325
    .line 326
    .line 327
    iget-object v0, v1, Le3/h;->c:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 328
    .line 329
    invoke-interface {v0}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 330
    .line 331
    .line 332
    move-result-object v7

    .line 333
    const-string v2, "forLocalStorageRead(...)"

    .line 334
    .line 335
    invoke-static {v7, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 336
    .line 337
    .line 338
    invoke-interface {v0}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageWrite()Ljava/util/concurrent/Executor;

    .line 339
    .line 340
    .line 341
    move-result-object v8

    .line 342
    const-string v0, "forLocalStorageWrite(...)"

    .line 343
    .line 344
    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 345
    .line 346
    .line 347
    iget-object v9, v1, Le3/h;->d:Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;

    .line 348
    .line 349
    invoke-direct/range {v3 .. v9}, Ld3/d;-><init>(Lcom/facebook/cache/disk/FileCache;Lcom/facebook/common/memory/PooledByteBufferFactory;Lr2/g;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;)V

    .line 350
    .line 351
    .line 352
    return-object v3

    .line 353
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
