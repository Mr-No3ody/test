.class public final Le3/x;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final z:Le3/w;


# instance fields
.field public final a:Landroid/content/ContentResolver;

.field public final b:Le3/u;

.field public final c:Lcom/facebook/imagepipeline/producers/NetworkFetcher;

.field public final d:Z

.field public final e:LHe/a;

.field public final f:Le3/i;

.field public final g:Z

.field public final h:Ln3/c;

.field public final i:Ljava/util/Set;

.field public final j:Ljava/util/LinkedHashMap;

.field public final k:Lxf/t;

.field public final l:Lxf/t;

.field public final m:Lxf/t;

.field public final n:Lxf/t;

.field public final o:Lxf/t;

.field public final p:Lxf/t;

.field public final q:Lxf/t;

.field public final r:Lxf/t;

.field public final s:Lxf/t;

.field public final t:Lxf/t;

.field public final u:Lxf/t;

.field public final v:Lxf/t;

.field public final w:Lxf/t;

.field public final x:Lxf/t;

.field public final y:Lxf/t;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Le3/w;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Le3/w;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Le3/x;->z:Le3/w;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Landroid/content/ContentResolver;Le3/u;Lcom/facebook/imagepipeline/producers/NetworkFetcher;ZLHe/a;Le3/i;ZLn3/c;Ljava/util/Set;)V
    .locals 1

    .line 1
    const-string v0, "contentResolver"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "producerFactory"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "networkFetcher"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string/jumbo v0, "threadHandoffProducerQueue"

    .line 17
    .line 18
    .line 19
    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const-string v0, "downsampleMode"

    .line 23
    .line 24
    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const-string v0, "imageTranscoderFactory"

    .line 28
    .line 29
    invoke-static {p8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    iput-object p1, p0, Le3/x;->a:Landroid/content/ContentResolver;

    .line 36
    .line 37
    iput-object p2, p0, Le3/x;->b:Le3/u;

    .line 38
    .line 39
    iput-object p3, p0, Le3/x;->c:Lcom/facebook/imagepipeline/producers/NetworkFetcher;

    .line 40
    .line 41
    iput-boolean p4, p0, Le3/x;->d:Z

    .line 42
    .line 43
    iput-object p5, p0, Le3/x;->e:LHe/a;

    .line 44
    .line 45
    iput-object p6, p0, Le3/x;->f:Le3/i;

    .line 46
    .line 47
    iput-boolean p7, p0, Le3/x;->g:Z

    .line 48
    .line 49
    iput-object p8, p0, Le3/x;->h:Ln3/c;

    .line 50
    .line 51
    iput-object p9, p0, Le3/x;->i:Ljava/util/Set;

    .line 52
    .line 53
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 54
    .line 55
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 56
    .line 57
    .line 58
    iput-object p1, p0, Le3/x;->j:Ljava/util/LinkedHashMap;

    .line 59
    .line 60
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 61
    .line 62
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 63
    .line 64
    .line 65
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 66
    .line 67
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 68
    .line 69
    .line 70
    new-instance p1, Le3/v;

    .line 71
    .line 72
    const/4 p2, 0x0

    .line 73
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 74
    .line 75
    .line 76
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 77
    .line 78
    .line 79
    new-instance p1, Le3/v;

    .line 80
    .line 81
    const/16 p2, 0x11

    .line 82
    .line 83
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 84
    .line 85
    .line 86
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 87
    .line 88
    .line 89
    new-instance p1, Le3/v;

    .line 90
    .line 91
    const/4 p2, 0x1

    .line 92
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 93
    .line 94
    .line 95
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 96
    .line 97
    .line 98
    new-instance p1, Le3/v;

    .line 99
    .line 100
    const/4 p2, 0x2

    .line 101
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 102
    .line 103
    .line 104
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    iput-object p1, p0, Le3/x;->k:Lxf/t;

    .line 109
    .line 110
    new-instance p1, Le3/v;

    .line 111
    .line 112
    const/4 p2, 0x3

    .line 113
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 114
    .line 115
    .line 116
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    iput-object p1, p0, Le3/x;->l:Lxf/t;

    .line 121
    .line 122
    new-instance p1, Le3/v;

    .line 123
    .line 124
    const/4 p2, 0x4

    .line 125
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 126
    .line 127
    .line 128
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    iput-object p1, p0, Le3/x;->m:Lxf/t;

    .line 133
    .line 134
    new-instance p1, Le3/v;

    .line 135
    .line 136
    const/4 p2, 0x5

    .line 137
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 138
    .line 139
    .line 140
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    iput-object p1, p0, Le3/x;->n:Lxf/t;

    .line 145
    .line 146
    new-instance p1, Le3/v;

    .line 147
    .line 148
    const/4 p2, 0x6

    .line 149
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 150
    .line 151
    .line 152
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    iput-object p1, p0, Le3/x;->o:Lxf/t;

    .line 157
    .line 158
    new-instance p1, Le3/v;

    .line 159
    .line 160
    const/4 p2, 0x7

    .line 161
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 162
    .line 163
    .line 164
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    iput-object p1, p0, Le3/x;->p:Lxf/t;

    .line 169
    .line 170
    new-instance p1, Le3/v;

    .line 171
    .line 172
    const/16 p2, 0x8

    .line 173
    .line 174
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 175
    .line 176
    .line 177
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    iput-object p1, p0, Le3/x;->q:Lxf/t;

    .line 182
    .line 183
    new-instance p1, Le3/v;

    .line 184
    .line 185
    const/16 p2, 0x9

    .line 186
    .line 187
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 188
    .line 189
    .line 190
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 191
    .line 192
    .line 193
    move-result-object p1

    .line 194
    iput-object p1, p0, Le3/x;->r:Lxf/t;

    .line 195
    .line 196
    new-instance p1, Le3/v;

    .line 197
    .line 198
    const/16 p2, 0xa

    .line 199
    .line 200
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 201
    .line 202
    .line 203
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    iput-object p1, p0, Le3/x;->s:Lxf/t;

    .line 208
    .line 209
    new-instance p1, Le3/v;

    .line 210
    .line 211
    const/16 p2, 0xb

    .line 212
    .line 213
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 214
    .line 215
    .line 216
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 217
    .line 218
    .line 219
    move-result-object p1

    .line 220
    iput-object p1, p0, Le3/x;->t:Lxf/t;

    .line 221
    .line 222
    new-instance p1, Le3/v;

    .line 223
    .line 224
    const/16 p2, 0xc

    .line 225
    .line 226
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 227
    .line 228
    .line 229
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 230
    .line 231
    .line 232
    move-result-object p1

    .line 233
    iput-object p1, p0, Le3/x;->u:Lxf/t;

    .line 234
    .line 235
    new-instance p1, Le3/v;

    .line 236
    .line 237
    const/16 p2, 0xd

    .line 238
    .line 239
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 240
    .line 241
    .line 242
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 243
    .line 244
    .line 245
    move-result-object p1

    .line 246
    iput-object p1, p0, Le3/x;->v:Lxf/t;

    .line 247
    .line 248
    new-instance p1, Le3/v;

    .line 249
    .line 250
    const/16 p2, 0xe

    .line 251
    .line 252
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 253
    .line 254
    .line 255
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 256
    .line 257
    .line 258
    move-result-object p1

    .line 259
    iput-object p1, p0, Le3/x;->w:Lxf/t;

    .line 260
    .line 261
    new-instance p1, Le3/v;

    .line 262
    .line 263
    const/16 p2, 0xf

    .line 264
    .line 265
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 266
    .line 267
    .line 268
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 269
    .line 270
    .line 271
    move-result-object p1

    .line 272
    iput-object p1, p0, Le3/x;->x:Lxf/t;

    .line 273
    .line 274
    new-instance p1, Le3/v;

    .line 275
    .line 276
    const/16 p2, 0x10

    .line 277
    .line 278
    invoke-direct {p1, p0, p2}, Le3/v;-><init>(Le3/x;I)V

    .line 279
    .line 280
    .line 281
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 282
    .line 283
    .line 284
    move-result-object p1

    .line 285
    iput-object p1, p0, Le3/x;->y:Lxf/t;

    .line 286
    .line 287
    return-void
.end method


# virtual methods
.method public final a()Lcom/facebook/imagepipeline/producers/Producer;
    .locals 2

    .line 1
    iget-object v0, p0, Le3/x;->p:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "getValue(...)"

    .line 8
    .line 9
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    check-cast v0, Lcom/facebook/imagepipeline/producers/Producer;

    .line 13
    .line 14
    return-object v0
.end method

.method public final b()Lcom/facebook/imagepipeline/producers/Producer;
    .locals 2

    .line 1
    iget-object v0, p0, Le3/x;->l:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "getValue(...)"

    .line 8
    .line 9
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    check-cast v0, Lcom/facebook/imagepipeline/producers/Producer;

    .line 13
    .line 14
    return-object v0
.end method

.method public final c(Lcom/facebook/imagepipeline/request/d;)Lcom/facebook/imagepipeline/producers/Producer;
    .locals 3

    .line 1
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getSourceUri()Landroid/net/Uri;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    const-string v1, "getSourceUri(...)"

    .line 9
    .line 10
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    if-eqz v0, :cond_7

    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getSourceUriType()I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_6

    .line 20
    .line 21
    iget-object v2, p0, Le3/x;->s:Lxf/t;

    .line 22
    .line 23
    packed-switch v1, :pswitch_data_0

    .line 24
    .line 25
    .line 26
    iget-object p1, p0, Le3/x;->i:Ljava/util/Set;

    .line 27
    .line 28
    if-eqz p1, :cond_0

    .line 29
    .line 30
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_0

    .line 39
    .line 40
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    new-instance p1, Ljava/lang/ClassCastException;

    .line 48
    .line 49
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 50
    .line 51
    .line 52
    throw p1

    .line 53
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 54
    .line 55
    sget-object v1, Le3/x;->z:Le3/w;

    .line 56
    .line 57
    invoke-static {v1, v0}, Le3/w;->access$getShortenedUriString(Le3/w;Landroid/net/Uri;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    const-string v1, "Unsupported uri scheme! Uri is: "

    .line 62
    .line 63
    invoke-static {v1, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    throw p1

    .line 71
    :pswitch_0
    iget-object p1, p0, Le3/x;->v:Lxf/t;

    .line 72
    .line 73
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 78
    .line 79
    return-object p1

    .line 80
    :pswitch_1
    iget-object p1, p0, Le3/x;->y:Lxf/t;

    .line 81
    .line 82
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 87
    .line 88
    return-object p1

    .line 89
    :pswitch_2
    iget-object p1, p0, Le3/x;->w:Lxf/t;

    .line 90
    .line 91
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 96
    .line 97
    return-object p1

    .line 98
    :pswitch_3
    iget-object p1, p0, Le3/x;->x:Lxf/t;

    .line 99
    .line 100
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 105
    .line 106
    return-object p1

    .line 107
    :pswitch_4
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getLoadThumbnailOnlyForAndroidSdkAboveQ()Z

    .line 108
    .line 109
    .line 110
    move-result p1

    .line 111
    if-eqz p1, :cond_1

    .line 112
    .line 113
    invoke-virtual {p0}, Le3/x;->e()Lcom/facebook/imagepipeline/producers/Producer;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    return-object p1

    .line 118
    :cond_1
    iget-object p1, p0, Le3/x;->a:Landroid/content/ContentResolver;

    .line 119
    .line 120
    invoke-virtual {p1, v0}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    sget-object v0, Lq2/a;->a:Ljava/lang/Object;

    .line 125
    .line 126
    const/4 v0, 0x0

    .line 127
    if-eqz p1, :cond_2

    .line 128
    .line 129
    const-string/jumbo v1, "video/"

    .line 130
    .line 131
    .line 132
    invoke-static {p1, v1, v0}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    :cond_2
    if-eqz v0, :cond_3

    .line 137
    .line 138
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 143
    .line 144
    return-object p1

    .line 145
    :cond_3
    iget-object p1, p0, Le3/x;->t:Lxf/t;

    .line 146
    .line 147
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 152
    .line 153
    return-object p1

    .line 154
    :pswitch_5
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getLoadThumbnailOnlyForAndroidSdkAboveQ()Z

    .line 155
    .line 156
    .line 157
    move-result p1

    .line 158
    if-eqz p1, :cond_4

    .line 159
    .line 160
    invoke-virtual {p0}, Le3/x;->e()Lcom/facebook/imagepipeline/producers/Producer;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    return-object p1

    .line 165
    :cond_4
    iget-object p1, p0, Le3/x;->r:Lxf/t;

    .line 166
    .line 167
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object p1

    .line 171
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 172
    .line 173
    return-object p1

    .line 174
    :pswitch_6
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getLoadThumbnailOnlyForAndroidSdkAboveQ()Z

    .line 175
    .line 176
    .line 177
    move-result p1

    .line 178
    if-eqz p1, :cond_5

    .line 179
    .line 180
    invoke-virtual {p0}, Le3/x;->e()Lcom/facebook/imagepipeline/producers/Producer;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    return-object p1

    .line 185
    :cond_5
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 190
    .line 191
    return-object p1

    .line 192
    :cond_6
    iget-object p1, p0, Le3/x;->k:Lxf/t;

    .line 193
    .line 194
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 199
    .line 200
    return-object p1

    .line 201
    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 202
    .line 203
    const-string v0, "Uri is null."

    .line 204
    .line 205
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 206
    .line 207
    .line 208
    throw p1

    .line 209
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final d(Lcom/facebook/imagepipeline/request/d;)Lcom/facebook/imagepipeline/producers/Producer;
    .locals 4

    .line 1
    const-string v0, "imageRequest"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Le3/x;->z:Le3/w;

    .line 7
    .line 8
    invoke-static {v0, p1}, Le3/w;->access$validateEncodedImageRequest(Le3/w;Lcom/facebook/imagepipeline/request/d;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getSourceUriType()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    const-string v2, "getValue(...)"

    .line 16
    .line 17
    if-eqz v1, :cond_2

    .line 18
    .line 19
    const/4 v3, 0x2

    .line 20
    if-eq v1, v3, :cond_1

    .line 21
    .line 22
    const/4 v3, 0x3

    .line 23
    if-ne v1, v3, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getSourceUri()Landroid/net/Uri;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    const-string v1, "getSourceUri(...)"

    .line 31
    .line 32
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 36
    .line 37
    invoke-static {v0, p1}, Le3/w;->access$getShortenedUriString(Le3/w;Landroid/net/Uri;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    const-string v0, "Unsupported uri scheme for encoded image fetch! Uri is: "

    .line 42
    .line 43
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-direct {v1, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw v1

    .line 51
    :cond_1
    :goto_0
    iget-object p1, p0, Le3/x;->o:Lxf/t;

    .line 52
    .line 53
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 61
    .line 62
    return-object p1

    .line 63
    :cond_2
    iget-object p1, p0, Le3/x;->m:Lxf/t;

    .line 64
    .line 65
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    check-cast p1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 73
    .line 74
    return-object p1
.end method

.method public final e()Lcom/facebook/imagepipeline/producers/Producer;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/x;->u:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/facebook/imagepipeline/producers/Producer;

    .line 8
    .line 9
    return-object v0
.end method

.method public final declared-synchronized f(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;
    .locals 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, Le3/x;->j:Ljava/util/LinkedHashMap;

    .line 3
    .line 4
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lcom/facebook/imagepipeline/producers/Producer;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Le3/x;->b:Le3/u;

    .line 13
    .line 14
    new-instance v1, Lcom/facebook/imagepipeline/producers/w;

    .line 15
    .line 16
    iget-object v2, v0, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 17
    .line 18
    invoke-interface {v2}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forBackgroundTasks()Ljava/util/concurrent/Executor;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    iget-object v0, v0, Le3/u;->p:Lc3/b;

    .line 23
    .line 24
    invoke-direct {v1, p1, v0, v2}, Lcom/facebook/imagepipeline/producers/w;-><init>(Lcom/facebook/imagepipeline/producers/Producer;Lc3/b;Ljava/util/concurrent/Executor;)V

    .line 25
    .line 26
    .line 27
    const-string v0, "newPostprocessorProducer(...)"

    .line 28
    .line 29
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Le3/x;->b:Le3/u;

    .line 33
    .line 34
    new-instance v2, Lcom/facebook/imagepipeline/producers/w;

    .line 35
    .line 36
    iget-object v3, v0, Le3/u;->n:Lcom/facebook/imagepipeline/cache/MemoryCache;

    .line 37
    .line 38
    iget-object v0, v0, Le3/u;->o:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    .line 39
    .line 40
    const/4 v4, 0x2

    .line 41
    invoke-direct {v2, v3, v0, v1, v4}, Lcom/facebook/imagepipeline/producers/w;-><init>(Ljava/lang/Object;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p0, Le3/x;->j:Ljava/util/LinkedHashMap;

    .line 45
    .line 46
    invoke-interface {v0, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 47
    .line 48
    .line 49
    move-object v0, v2

    .line 50
    goto :goto_0

    .line 51
    :catchall_0
    move-exception p1

    .line 52
    goto :goto_1

    .line 53
    :cond_0
    :goto_0
    monitor-exit p0

    .line 54
    return-object v0

    .line 55
    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 56
    throw p1
.end method

.method public final g(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;
    .locals 5

    .line 1
    new-instance v0, Lcom/facebook/imagepipeline/producers/k;

    .line 2
    .line 3
    iget-object v1, p0, Le3/x;->b:Le3/u;

    .line 4
    .line 5
    iget-object v2, v1, Le3/u;->n:Lcom/facebook/imagepipeline/cache/MemoryCache;

    .line 6
    .line 7
    iget-object v3, v1, Le3/u;->o:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    invoke-direct {v0, v2, v3, p1, v4}, Lcom/facebook/imagepipeline/producers/k;-><init>(Lcom/facebook/imagepipeline/cache/MemoryCache;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 11
    .line 12
    .line 13
    const-string p1, "newBitmapMemoryCacheProducer(...)"

    .line 14
    .line 15
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    new-instance p1, Lcom/facebook/imagepipeline/producers/i;

    .line 19
    .line 20
    invoke-direct {p1, v3, v0}, Lcom/facebook/imagepipeline/producers/i;-><init>(Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lcom/facebook/imagepipeline/producers/k;)V

    .line 21
    .line 22
    .line 23
    const-string v0, "newBitmapMemoryCacheKeyMultiplexProducer(...)"

    .line 24
    .line 25
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    new-instance v0, Lcom/facebook/imagepipeline/producers/l0;

    .line 29
    .line 30
    iget-object v2, p0, Le3/x;->e:LHe/a;

    .line 31
    .line 32
    invoke-direct {v0, p1, v2}, Lcom/facebook/imagepipeline/producers/l0;-><init>(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/producers/ThreadHandoffProducerQueue;)V

    .line 33
    .line 34
    .line 35
    const-string p1, "newBackgroundThreadHandoffProducer(...)"

    .line 36
    .line 37
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    new-instance p1, Lcom/facebook/imagepipeline/producers/h;

    .line 41
    .line 42
    const-string v2, "memoryCache"

    .line 43
    .line 44
    iget-object v1, v1, Le3/u;->n:Lcom/facebook/imagepipeline/cache/MemoryCache;

    .line 45
    .line 46
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    const-string v2, "cacheKeyFactory"

    .line 50
    .line 51
    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const-string v2, "inputProducer"

    .line 55
    .line 56
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    const/4 v2, 0x0

    .line 60
    invoke-direct {p1, v1, v3, v0, v2}, Lcom/facebook/imagepipeline/producers/k;-><init>(Lcom/facebook/imagepipeline/cache/MemoryCache;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 61
    .line 62
    .line 63
    const-string v0, "newBitmapMemoryCacheGetProducer(...)"

    .line 64
    .line 65
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    return-object p1
.end method

.method public final h(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;
    .locals 12

    .line 1
    const-string v0, "inputProducer"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Le3/x;->b:Le3/u;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    new-instance v1, Lcom/facebook/imagepipeline/producers/s;

    .line 15
    .line 16
    iget-object v2, v0, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 17
    .line 18
    invoke-interface {v2}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forDecode()Ljava/util/concurrent/Executor;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    iget v10, v0, Le3/u;->r:I

    .line 23
    .line 24
    iget-object v11, v0, Le3/u;->q:Le3/b;

    .line 25
    .line 26
    iget-object v2, v0, Le3/u;->d:Lcom/facebook/common/memory/ByteArrayPool;

    .line 27
    .line 28
    iget-object v4, v0, Le3/u;->e:Lcom/facebook/imagepipeline/decoder/ImageDecoder;

    .line 29
    .line 30
    iget-object v5, v0, Le3/u;->f:Lcom/facebook/imagepipeline/decoder/ProgressiveJpegConfig;

    .line 31
    .line 32
    iget-object v6, v0, Le3/u;->g:Le3/i;

    .line 33
    .line 34
    iget-boolean v7, v0, Le3/u;->h:Z

    .line 35
    .line 36
    iget-boolean v8, v0, Le3/u;->i:Z

    .line 37
    .line 38
    move-object v9, p1

    .line 39
    invoke-direct/range {v1 .. v11}, Lcom/facebook/imagepipeline/producers/s;-><init>(Lcom/facebook/common/memory/ByteArrayPool;Ljava/util/concurrent/Executor;Lcom/facebook/imagepipeline/decoder/ImageDecoder;Lcom/facebook/imagepipeline/decoder/ProgressiveJpegConfig;Le3/i;ZZLcom/facebook/imagepipeline/producers/Producer;ILe3/b;)V

    .line 40
    .line 41
    .line 42
    const-string p1, "newDecodeProducer(...)"

    .line 43
    .line 44
    invoke-static {v1, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0, v1}, Le3/x;->g(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    return-object p1
.end method

.method public final i(Lcom/facebook/imagepipeline/producers/P;[Lcom/facebook/imagepipeline/producers/ThumbnailProducer;)Lcom/facebook/imagepipeline/producers/Producer;
    .locals 5

    .line 1
    invoke-virtual {p0, p1}, Le3/x;->j(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/i;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    new-instance v0, Lcom/facebook/imagepipeline/producers/b;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-direct {v0, p1, v1}, Lcom/facebook/imagepipeline/producers/b;-><init>(Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 9
    .line 10
    .line 11
    const-string p1, "newAddImageTransformMetaDataProducer(...)"

    .line 12
    .line 13
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object p1, p0, Le3/x;->b:Le3/u;

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    iget-object v2, p0, Le3/x;->h:Ln3/c;

    .line 20
    .line 21
    invoke-virtual {p1, v0, v1, v2}, Le3/u;->b(Lcom/facebook/imagepipeline/producers/Producer;ZLn3/c;)Lcom/facebook/imagepipeline/producers/h0;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v3, Lcom/facebook/imagepipeline/producers/n0;

    .line 26
    .line 27
    iget-object v4, p1, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 28
    .line 29
    invoke-interface {v4}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLightweightBackgroundTasks()Ljava/util/concurrent/Executor;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    invoke-direct {v3, v4, v0}, Lcom/facebook/imagepipeline/producers/n0;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/imagepipeline/producers/h0;)V

    .line 34
    .line 35
    .line 36
    const-string v0, "newThrottlingProducer(...)"

    .line 37
    .line 38
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    new-instance v0, Lcom/facebook/imagepipeline/producers/b;

    .line 42
    .line 43
    invoke-direct {v0, p2}, Lcom/facebook/imagepipeline/producers/b;-><init>([Lcom/facebook/imagepipeline/producers/ThumbnailProducer;)V

    .line 44
    .line 45
    .line 46
    const-string p2, "newThumbnailBranchProducer(...)"

    .line 47
    .line 48
    invoke-static {v0, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p1, v0, v1, v2}, Le3/u;->b(Lcom/facebook/imagepipeline/producers/Producer;ZLn3/c;)Lcom/facebook/imagepipeline/producers/h0;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    const-string p2, "newResizeAndRotateProducer(...)"

    .line 56
    .line 57
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    new-instance p2, Lcom/facebook/imagepipeline/producers/W;

    .line 61
    .line 62
    const/4 v0, 0x2

    .line 63
    invoke-direct {p2, v0, p1, v3}, Lcom/facebook/imagepipeline/producers/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    const-string p1, "newBranchOnSeparateImagesProducer(...)"

    .line 67
    .line 68
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0, p2}, Le3/x;->h(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    return-object p1
.end method

.method public final j(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/i;
    .locals 5

    .line 1
    iget-boolean v0, p0, Le3/x;->g:Z

    .line 2
    .line 3
    iget-object v1, p0, Le3/x;->b:Le3/u;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 8
    .line 9
    .line 10
    new-instance v0, Lcom/facebook/imagepipeline/producers/w;

    .line 11
    .line 12
    iget-object v2, v1, Le3/u;->l:Lcom/facebook/common/internal/Supplier;

    .line 13
    .line 14
    iget-object v3, v1, Le3/u;->o:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    .line 15
    .line 16
    const/4 v4, 0x1

    .line 17
    invoke-direct {v0, v2, v3, p1, v4}, Lcom/facebook/imagepipeline/producers/w;-><init>(Ljava/lang/Object;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 18
    .line 19
    .line 20
    new-instance p1, Lcom/facebook/imagepipeline/producers/w;

    .line 21
    .line 22
    const/4 v4, 0x0

    .line 23
    invoke-direct {p1, v2, v3, v0, v4}, Lcom/facebook/imagepipeline/producers/w;-><init>(Ljava/lang/Object;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 24
    .line 25
    .line 26
    const-string v0, "newDiskCacheReadProducer(...)"

    .line 27
    .line 28
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    new-instance v0, Lcom/facebook/imagepipeline/producers/k;

    .line 32
    .line 33
    iget-object v2, v1, Le3/u;->m:Lcom/facebook/imagepipeline/cache/MemoryCache;

    .line 34
    .line 35
    iget-object v3, v1, Le3/u;->o:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    .line 36
    .line 37
    const/4 v4, 0x1

    .line 38
    invoke-direct {v0, v2, v3, p1, v4}, Lcom/facebook/imagepipeline/producers/k;-><init>(Lcom/facebook/imagepipeline/cache/MemoryCache;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 39
    .line 40
    .line 41
    const-string p1, "newEncodedMemoryCacheProducer(...)"

    .line 42
    .line 43
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    new-instance p1, Lcom/facebook/imagepipeline/producers/i;

    .line 47
    .line 48
    iget-boolean v1, v1, Le3/u;->s:Z

    .line 49
    .line 50
    invoke-direct {p1, v3, v1, v0}, Lcom/facebook/imagepipeline/producers/i;-><init>(Lcom/facebook/imagepipeline/cache/CacheKeyFactory;ZLcom/facebook/imagepipeline/producers/Producer;)V

    .line 51
    .line 52
    .line 53
    const-string v0, "newEncodedCacheKeyMultiplexProducer(...)"

    .line 54
    .line 55
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    return-object p1
.end method
