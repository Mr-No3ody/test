.class public final Le3/l;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public b:Le3/i;

.field public c:Lb3/e;

.field public d:Ljava/util/HashSet;

.field public final e:Z

.field public final f:I

.field public final g:Le3/p;

.field public final h:Z

.field public final i:Lcom/facebook/imagepipeline/debug/a;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    sget-object v0, Le3/i;->b:Le3/i;

    .line 10
    .line 11
    iput-object v0, p0, Le3/l;->b:Le3/i;

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    iput-boolean v0, p0, Le3/l;->e:Z

    .line 15
    .line 16
    const/4 v1, -0x1

    .line 17
    iput v1, p0, Le3/l;->f:I

    .line 18
    .line 19
    new-instance v1, Le3/p;

    .line 20
    .line 21
    invoke-direct {v1, p0}, Le3/p;-><init>(Le3/l;)V

    .line 22
    .line 23
    .line 24
    iput-object v1, p0, Le3/l;->g:Le3/p;

    .line 25
    .line 26
    iput-boolean v0, p0, Le3/l;->h:Z

    .line 27
    .line 28
    new-instance v0, Lcom/facebook/imagepipeline/debug/a;

    .line 29
    .line 30
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Le3/l;->i:Lcom/facebook/imagepipeline/debug/a;

    .line 34
    .line 35
    iput-object p1, p0, Le3/l;->a:Landroid/content/Context;

    .line 36
    .line 37
    return-void
.end method
