.class public final Le3/k;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final l:Ljava/util/concurrent/CancellationException;

.field public static final m:Ljava/util/concurrent/CancellationException;


# instance fields
.field public final a:Le3/x;

.field public final b:Lcom/facebook/common/internal/Supplier;

.field public final c:Lcom/facebook/common/internal/Supplier;

.field public final d:Li3/d;

.field public final e:Li3/c;

.field public final f:Landroidx/work/impl/model/b;

.field public final g:Landroidx/work/impl/model/b;

.field public final h:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

.field public final i:Ljava/util/concurrent/atomic/AtomicLong;

.field public final j:Lcom/facebook/callercontext/CallerContextVerifier;

.field public final k:Le3/o;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Le3/j;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Le3/j;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    new-instance v0, Ljava/util/concurrent/CancellationException;

    .line 8
    .line 9
    const-string v1, "Prefetching is not enabled"

    .line 10
    .line 11
    invoke-direct {v0, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Le3/k;->l:Ljava/util/concurrent/CancellationException;

    .line 15
    .line 16
    new-instance v0, Ljava/util/concurrent/CancellationException;

    .line 17
    .line 18
    const-string v1, "ImageRequest is null"

    .line 19
    .line 20
    invoke-direct {v0, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    new-instance v0, Ljava/util/concurrent/CancellationException;

    .line 24
    .line 25
    const-string v1, "Modified URL is null"

    .line 26
    .line 27
    invoke-direct {v0, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    sput-object v0, Le3/k;->m:Ljava/util/concurrent/CancellationException;

    .line 31
    .line 32
    return-void
.end method

.method public constructor <init>(Le3/x;Ljava/util/Set;Ljava/util/Set;Lcom/facebook/common/internal/Supplier;Landroidx/work/impl/model/b;Landroidx/work/impl/model/b;Lcom/facebook/common/internal/Supplier;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;LHe/a;LQ2/a;LQ2/a;Lcom/facebook/callercontext/CallerContextVerifier;Le3/o;)V
    .locals 1

    .line 1
    const-string v0, "producerSequenceFactory"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "requestListeners"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "requestListener2s"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "isPrefetchEnabledSupplier"

    .line 17
    .line 18
    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string v0, "bitmapMemoryCache"

    .line 22
    .line 23
    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v0, "encodedMemoryCache"

    .line 27
    .line 28
    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const-string v0, "diskCachesStoreSupplier"

    .line 32
    .line 33
    invoke-static {p7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const-string v0, "cacheKeyFactory"

    .line 37
    .line 38
    invoke-static {p8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    const-string/jumbo v0, "threadHandoffProducerQueue"

    .line 42
    .line 43
    .line 44
    invoke-static {p9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    const-string/jumbo p9, "suppressBitmapPrefetchingSupplier"

    .line 48
    .line 49
    .line 50
    invoke-static {p10, p9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    const-string p9, "lazyDataSource"

    .line 54
    .line 55
    invoke-static {p11, p9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    const-string p9, "config"

    .line 59
    .line 60
    invoke-static {p13, p9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 64
    .line 65
    .line 66
    iput-object p1, p0, Le3/k;->a:Le3/x;

    .line 67
    .line 68
    iput-object p4, p0, Le3/k;->b:Lcom/facebook/common/internal/Supplier;

    .line 69
    .line 70
    iput-object p7, p0, Le3/k;->c:Lcom/facebook/common/internal/Supplier;

    .line 71
    .line 72
    new-instance p1, Li3/d;

    .line 73
    .line 74
    invoke-direct {p1, p2}, Li3/d;-><init>(Ljava/util/Set;)V

    .line 75
    .line 76
    .line 77
    iput-object p1, p0, Le3/k;->d:Li3/d;

    .line 78
    .line 79
    new-instance p1, Li3/c;

    .line 80
    .line 81
    invoke-direct {p1, p3}, Li3/c;-><init>(Ljava/util/Set;)V

    .line 82
    .line 83
    .line 84
    iput-object p1, p0, Le3/k;->e:Li3/c;

    .line 85
    .line 86
    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    .line 87
    .line 88
    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 89
    .line 90
    .line 91
    iput-object p1, p0, Le3/k;->i:Ljava/util/concurrent/atomic/AtomicLong;

    .line 92
    .line 93
    iput-object p5, p0, Le3/k;->f:Landroidx/work/impl/model/b;

    .line 94
    .line 95
    iput-object p6, p0, Le3/k;->g:Landroidx/work/impl/model/b;

    .line 96
    .line 97
    iput-object p8, p0, Le3/k;->h:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    .line 98
    .line 99
    iput-object p12, p0, Le3/k;->j:Lcom/facebook/callercontext/CallerContextVerifier;

    .line 100
    .line 101
    iput-object p13, p0, Le3/k;->k:Le3/o;

    .line 102
    .line 103
    return-void
.end method


# virtual methods
.method public final a(Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;)Ly2/b;
    .locals 6

    .line 1
    const/4 v4, 0x0

    .line 2
    const/4 v5, 0x0

    .line 3
    const/4 v3, 0x0

    .line 4
    move-object v0, p0

    .line 5
    move-object v1, p1

    .line 6
    move-object v2, p2

    .line 7
    invoke-virtual/range {v0 .. v5}, Le3/k;->b(Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;Lcom/facebook/imagepipeline/request/c;Lcom/facebook/imagepipeline/listener/RequestListener;Ljava/lang/String;)Ly2/b;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    return-object p1
.end method

.method public final b(Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;Lcom/facebook/imagepipeline/request/c;Lcom/facebook/imagepipeline/listener/RequestListener;Ljava/lang/String;)Ly2/b;
    .locals 8

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    new-instance p1, Ljava/lang/NullPointerException;

    .line 4
    .line 5
    invoke-direct {p1}, Ljava/lang/NullPointerException;-><init>()V

    .line 6
    .line 7
    .line 8
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->z(Ljava/lang/Exception;)Ly2/g;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const-string p2, "immediateFailedDataSource(...)"

    .line 13
    .line 14
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-object p1

    .line 18
    :cond_0
    :try_start_0
    iget-object v0, p0, Le3/k;->a:Le3/x;

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    const-string v1, "imageRequest"

    .line 24
    .line 25
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, p1}, Le3/x;->c(Lcom/facebook/imagepipeline/request/d;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getPostprocessor()Lcom/facebook/imagepipeline/request/Postprocessor;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    if-eqz v2, :cond_1

    .line 40
    .line 41
    invoke-virtual {v0, v1}, Le3/x;->f(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    :cond_1
    move-object v2, v1

    .line 46
    if-nez p3, :cond_2

    .line 47
    .line 48
    sget-object p3, Lcom/facebook/imagepipeline/request/c;->b:Lcom/facebook/imagepipeline/request/c;

    .line 49
    .line 50
    :cond_2
    move-object v1, p0

    .line 51
    move-object v3, p1

    .line 52
    move-object v5, p2

    .line 53
    move-object v4, p3

    .line 54
    move-object v6, p4

    .line 55
    move-object v7, p5

    .line 56
    goto :goto_0

    .line 57
    :catch_0
    move-exception v0

    .line 58
    move-object p1, v0

    .line 59
    goto :goto_1

    .line 60
    :goto_0
    invoke-virtual/range {v1 .. v7}, Le3/k;->f(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/request/d;Lcom/facebook/imagepipeline/request/c;Ljava/lang/Object;Lcom/facebook/imagepipeline/listener/RequestListener;Ljava/lang/String;)Ly2/b;

    .line 61
    .line 62
    .line 63
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 64
    return-object p1

    .line 65
    :goto_1
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->z(Ljava/lang/Exception;)Ly2/g;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    return-object p1
.end method

.method public final c(Lcom/facebook/imagepipeline/request/d;Lcom/facebook/imagepipeline/listener/RequestListener;)Li3/d;
    .locals 6

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x2

    .line 4
    if-eqz p1, :cond_3

    .line 5
    .line 6
    iget-object v3, p0, Le3/k;->d:Li3/d;

    .line 7
    .line 8
    if-nez p2, :cond_1

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getRequestListener()Lcom/facebook/imagepipeline/listener/RequestListener;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    if-nez p2, :cond_0

    .line 15
    .line 16
    return-object v3

    .line 17
    :cond_0
    new-instance p2, Li3/d;

    .line 18
    .line 19
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getRequestListener()Lcom/facebook/imagepipeline/listener/RequestListener;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    new-array v2, v2, [Lcom/facebook/imagepipeline/listener/RequestListener;

    .line 24
    .line 25
    aput-object v3, v2, v1

    .line 26
    .line 27
    aput-object p1, v2, v0

    .line 28
    .line 29
    invoke-direct {p2, v2}, Li3/d;-><init>([Lcom/facebook/imagepipeline/listener/RequestListener;)V

    .line 30
    .line 31
    .line 32
    return-object p2

    .line 33
    :cond_1
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getRequestListener()Lcom/facebook/imagepipeline/listener/RequestListener;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    if-nez v4, :cond_2

    .line 38
    .line 39
    new-instance p1, Li3/d;

    .line 40
    .line 41
    new-array v2, v2, [Lcom/facebook/imagepipeline/listener/RequestListener;

    .line 42
    .line 43
    aput-object v3, v2, v1

    .line 44
    .line 45
    aput-object p2, v2, v0

    .line 46
    .line 47
    invoke-direct {p1, v2}, Li3/d;-><init>([Lcom/facebook/imagepipeline/listener/RequestListener;)V

    .line 48
    .line 49
    .line 50
    return-object p1

    .line 51
    :cond_2
    new-instance v4, Li3/d;

    .line 52
    .line 53
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getRequestListener()Lcom/facebook/imagepipeline/listener/RequestListener;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    const/4 v5, 0x3

    .line 58
    new-array v5, v5, [Lcom/facebook/imagepipeline/listener/RequestListener;

    .line 59
    .line 60
    aput-object v3, v5, v1

    .line 61
    .line 62
    aput-object p2, v5, v0

    .line 63
    .line 64
    aput-object p1, v5, v2

    .line 65
    .line 66
    invoke-direct {v4, v5}, Li3/d;-><init>([Lcom/facebook/imagepipeline/listener/RequestListener;)V

    .line 67
    .line 68
    .line 69
    return-object v4

    .line 70
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 71
    .line 72
    const-string p2, "Required value was null."

    .line 73
    .line 74
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    throw p1
.end method

.method public final d(Landroid/net/Uri;Lcom/facebook/imagepipeline/request/b;)Z
    .locals 4

    .line 1
    invoke-static {p1}, Lcom/facebook/imagepipeline/request/e;->d(Landroid/net/Uri;)Lcom/facebook/imagepipeline/request/e;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iput-object p2, p1, Lcom/facebook/imagepipeline/request/e;->g:Lcom/facebook/imagepipeline/request/b;

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/e;->a()Lcom/facebook/imagepipeline/request/d;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    const-string p2, "imageRequest"

    .line 12
    .line 13
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object p2, p0, Le3/k;->c:Lcom/facebook/common/internal/Supplier;

    .line 17
    .line 18
    invoke-interface {p2}, Lcom/facebook/common/internal/Supplier;->get()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    const-string v0, "get(...)"

    .line 23
    .line 24
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    check-cast p2, Lcom/facebook/imagepipeline/core/DiskCachesStore;

    .line 28
    .line 29
    iget-object v0, p0, Le3/k;->h:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    invoke-interface {v0, p1, v1}, Lcom/facebook/imagepipeline/cache/CacheKeyFactory;->getEncodedCacheKey(Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;)Lcom/facebook/cache/common/CacheKey;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getCacheChoice()Lcom/facebook/imagepipeline/request/b;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const-string v2, "getCacheChoice(...)"

    .line 41
    .line 42
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    :try_start_0
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    if-eqz v1, :cond_2

    .line 54
    .line 55
    const/4 v3, 0x1

    .line 56
    if-eq v1, v3, :cond_1

    .line 57
    .line 58
    const/4 p2, 0x2

    .line 59
    if-ne v1, p2, :cond_0

    .line 60
    .line 61
    invoke-virtual {p0, p1}, Le3/k;->e(Lcom/facebook/imagepipeline/request/d;)Z

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    goto :goto_0

    .line 66
    :catchall_0
    move-exception p1

    .line 67
    goto :goto_1

    .line 68
    :cond_0
    new-instance p1, Lxf/l;

    .line 69
    .line 70
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 71
    .line 72
    .line 73
    throw p1

    .line 74
    :cond_1
    invoke-interface {p2}, Lcom/facebook/imagepipeline/core/DiskCachesStore;->getMainBufferedDiskCache()Ld3/d;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {p1, v0}, Ld3/d;->c(Lcom/facebook/cache/common/CacheKey;)Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    goto :goto_0

    .line 86
    :cond_2
    invoke-interface {p2}, Lcom/facebook/imagepipeline/core/DiskCachesStore;->getSmallImageBufferedDiskCache()Ld3/d;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {p1, v0}, Ld3/d;->c(Lcom/facebook/cache/common/CacheKey;)Z

    .line 94
    .line 95
    .line 96
    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 97
    :goto_0
    invoke-static {v2}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    .line 98
    .line 99
    .line 100
    return p1

    .line 101
    :goto_1
    invoke-static {v2}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    .line 102
    .line 103
    .line 104
    throw p1
.end method

.method public final e(Lcom/facebook/imagepipeline/request/d;)Z
    .locals 3

    .line 1
    iget-object v0, p0, Le3/k;->c:Lcom/facebook/common/internal/Supplier;

    .line 2
    .line 3
    invoke-interface {v0}, Lcom/facebook/common/internal/Supplier;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "get(...)"

    .line 8
    .line 9
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    check-cast v0, Lcom/facebook/imagepipeline/core/DiskCachesStore;

    .line 13
    .line 14
    iget-object v1, p0, Le3/k;->h:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-interface {v1, p1, v2}, Lcom/facebook/imagepipeline/cache/CacheKeyFactory;->getEncodedCacheKey(Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;)Lcom/facebook/cache/common/CacheKey;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/d;->getDiskCacheId()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    if-eqz p1, :cond_0

    .line 26
    .line 27
    invoke-interface {v0}, Lcom/facebook/imagepipeline/core/DiskCachesStore;->getDynamicBufferedDiskCaches()Lo2/d;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0, p1}, Ljava/util/AbstractMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    check-cast p1, Ld3/d;

    .line 36
    .line 37
    if-eqz p1, :cond_2

    .line 38
    .line 39
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p1, v1}, Ld3/d;->c(Lcom/facebook/cache/common/CacheKey;)Z

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    return p1

    .line 47
    :cond_0
    invoke-interface {v0}, Lcom/facebook/imagepipeline/core/DiskCachesStore;->getDynamicBufferedDiskCaches()Lo2/d;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-virtual {p1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    :cond_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_2

    .line 64
    .line 65
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Ljava/util/Map$Entry;

    .line 70
    .line 71
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    check-cast v0, Ld3/d;

    .line 76
    .line 77
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0, v1}, Ld3/d;->c(Lcom/facebook/cache/common/CacheKey;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_1

    .line 85
    .line 86
    const/4 p1, 0x1

    .line 87
    return p1

    .line 88
    :cond_2
    const/4 p1, 0x0

    .line 89
    return p1
.end method

.method public final f(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/request/d;Lcom/facebook/imagepipeline/request/c;Ljava/lang/Object;Lcom/facebook/imagepipeline/listener/RequestListener;Ljava/lang/String;)Ly2/b;
    .locals 12

    .line 1
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 2
    .line 3
    .line 4
    const-string v0, "getMax(...)"

    .line 5
    .line 6
    new-instance v5, Lcom/facebook/imagepipeline/producers/E;

    .line 7
    .line 8
    move-object/from16 v1, p5

    .line 9
    .line 10
    invoke-virtual {p0, p2, v1}, Le3/k;->c(Lcom/facebook/imagepipeline/request/d;Lcom/facebook/imagepipeline/listener/RequestListener;)Li3/d;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    iget-object v2, p0, Le3/k;->e:Li3/c;

    .line 15
    .line 16
    invoke-direct {v5, v1, v2}, Lcom/facebook/imagepipeline/producers/E;-><init>(Li3/d;Li3/c;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Le3/k;->j:Lcom/facebook/callercontext/CallerContextVerifier;

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    move-object/from16 v6, p4

    .line 23
    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    invoke-interface {v1, v6, v2}, Lcom/facebook/callercontext/CallerContextVerifier;->verifyCallerContext(Ljava/lang/Object;Z)V

    .line 27
    .line 28
    .line 29
    :cond_0
    :try_start_0
    invoke-virtual {p2}, Lcom/facebook/imagepipeline/request/d;->getLowestPermittedRequestLevel()Lcom/facebook/imagepipeline/request/c;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    iget v3, v1, Lcom/facebook/imagepipeline/request/c;->a:I

    .line 34
    .line 35
    iget v4, p3, Lcom/facebook/imagepipeline/request/c;->a:I

    .line 36
    .line 37
    if-le v3, v4, :cond_1

    .line 38
    .line 39
    move-object v7, v1

    .line 40
    goto :goto_0

    .line 41
    :cond_1
    move-object v7, p3

    .line 42
    :goto_0
    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    new-instance v1, Lcom/facebook/imagepipeline/producers/i0;

    .line 46
    .line 47
    iget-object p3, p0, Le3/k;->i:Ljava/util/concurrent/atomic/AtomicLong;

    .line 48
    .line 49
    invoke-virtual {p3}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    .line 50
    .line 51
    .line 52
    move-result-wide v3

    .line 53
    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-virtual {p2}, Lcom/facebook/imagepipeline/request/d;->getProgressiveRenderingEnabled()Z

    .line 58
    .line 59
    .line 60
    move-result p3

    .line 61
    if-nez p3, :cond_3

    .line 62
    .line 63
    invoke-virtual {p2}, Lcom/facebook/imagepipeline/request/d;->getSourceUri()Landroid/net/Uri;

    .line 64
    .line 65
    .line 66
    move-result-object p3

    .line 67
    invoke-static {p3}, Lw2/a;->c(Landroid/net/Uri;)Z

    .line 68
    .line 69
    .line 70
    move-result p3

    .line 71
    if-nez p3, :cond_2

    .line 72
    .line 73
    goto :goto_2

    .line 74
    :cond_2
    :goto_1
    move v9, v2

    .line 75
    goto :goto_3

    .line 76
    :catch_0
    move-exception v0

    .line 77
    move-object p1, v0

    .line 78
    goto :goto_4

    .line 79
    :cond_3
    :goto_2
    const/4 v2, 0x1

    .line 80
    goto :goto_1

    .line 81
    :goto_3
    invoke-virtual {p2}, Lcom/facebook/imagepipeline/request/d;->getPriority()Lcom/facebook/imagepipeline/common/e;

    .line 82
    .line 83
    .line 84
    move-result-object v10

    .line 85
    iget-object v11, p0, Le3/k;->k:Le3/o;

    .line 86
    .line 87
    const/4 v8, 0x0

    .line 88
    move-object v2, p2

    .line 89
    move-object/from16 v4, p6

    .line 90
    .line 91
    invoke-direct/range {v1 .. v11}, Lcom/facebook/imagepipeline/producers/e;-><init>(Lcom/facebook/imagepipeline/request/d;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/imagepipeline/producers/ProducerListener2;Ljava/lang/Object;Lcom/facebook/imagepipeline/request/c;ZZLcom/facebook/imagepipeline/common/e;Lcom/facebook/imagepipeline/core/ImagePipelineConfigInterface;)V

    .line 92
    .line 93
    .line 94
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 95
    .line 96
    .line 97
    new-instance p2, Lf3/b;

    .line 98
    .line 99
    invoke-direct {p2, p1, v1, v5}, Lf3/a;-><init>(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/producers/i0;Lcom/facebook/imagepipeline/listener/RequestListener2;)V

    .line 100
    .line 101
    .line 102
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 103
    .line 104
    .line 105
    return-object p2

    .line 106
    :goto_4
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->z(Ljava/lang/Exception;)Ly2/g;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    return-object p1
.end method

.method public final g(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;)Lcom/facebook/datasource/DataSource;
    .locals 12

    .line 1
    sget-object v0, Lcom/facebook/imagepipeline/request/c;->b:Lcom/facebook/imagepipeline/request/c;

    .line 2
    .line 3
    sget-object v10, Lcom/facebook/imagepipeline/common/e;->c:Lcom/facebook/imagepipeline/common/e;

    .line 4
    .line 5
    new-instance v5, Lcom/facebook/imagepipeline/producers/E;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-virtual {p0, p2, v1}, Le3/k;->c(Lcom/facebook/imagepipeline/request/d;Lcom/facebook/imagepipeline/listener/RequestListener;)Li3/d;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    iget-object v2, p0, Le3/k;->e:Li3/c;

    .line 13
    .line 14
    invoke-direct {v5, v1, v2}, Lcom/facebook/imagepipeline/producers/E;-><init>(Li3/d;Li3/c;)V

    .line 15
    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    iget-object v2, p0, Le3/k;->j:Lcom/facebook/callercontext/CallerContextVerifier;

    .line 19
    .line 20
    if-eqz v2, :cond_0

    .line 21
    .line 22
    invoke-interface {v2, p3, v1}, Lcom/facebook/callercontext/CallerContextVerifier;->verifyCallerContext(Ljava/lang/Object;Z)V

    .line 23
    .line 24
    .line 25
    :cond_0
    invoke-virtual {p2}, Lcom/facebook/imagepipeline/request/d;->getSourceUri()Landroid/net/Uri;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    const-string v3, "getSourceUri(...)"

    .line 30
    .line 31
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    const-string/jumbo v3, "uri"

    .line 35
    .line 36
    .line 37
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    if-nez v2, :cond_1

    .line 41
    .line 42
    sget-object p1, Le3/k;->m:Ljava/util/concurrent/CancellationException;

    .line 43
    .line 44
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->z(Ljava/lang/Exception;)Ly2/g;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    const-string p2, "immediateFailedDataSource(...)"

    .line 49
    .line 50
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    return-object p1

    .line 54
    :cond_1
    invoke-virtual {v2, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    if-eqz v3, :cond_2

    .line 59
    .line 60
    :goto_0
    move-object v2, p2

    .line 61
    goto :goto_1

    .line 62
    :cond_2
    invoke-static {p2}, Lcom/facebook/imagepipeline/request/e;->b(Lcom/facebook/imagepipeline/request/d;)Lcom/facebook/imagepipeline/request/e;

    .line 63
    .line 64
    .line 65
    move-result-object p2

    .line 66
    iput-object v2, p2, Lcom/facebook/imagepipeline/request/e;->a:Landroid/net/Uri;

    .line 67
    .line 68
    invoke-virtual {p2}, Lcom/facebook/imagepipeline/request/e;->a()Lcom/facebook/imagepipeline/request/d;

    .line 69
    .line 70
    .line 71
    move-result-object p2

    .line 72
    goto :goto_0

    .line 73
    :goto_1
    :try_start_0
    invoke-virtual {v2}, Lcom/facebook/imagepipeline/request/d;->getLowestPermittedRequestLevel()Lcom/facebook/imagepipeline/request/c;

    .line 74
    .line 75
    .line 76
    move-result-object p2

    .line 77
    iget v3, p2, Lcom/facebook/imagepipeline/request/c;->a:I

    .line 78
    .line 79
    if-le v3, v1, :cond_3

    .line 80
    .line 81
    move-object v7, p2

    .line 82
    goto :goto_2

    .line 83
    :cond_3
    move-object v7, v0

    .line 84
    :goto_2
    const-string p2, "getMax(...)"

    .line 85
    .line 86
    invoke-static {v7, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    new-instance v1, Lcom/facebook/imagepipeline/producers/i0;

    .line 90
    .line 91
    iget-object p2, p0, Le3/k;->i:Ljava/util/concurrent/atomic/AtomicLong;

    .line 92
    .line 93
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    .line 94
    .line 95
    .line 96
    move-result-wide v3

    .line 97
    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    iget-object p2, p0, Le3/k;->k:Le3/o;

    .line 102
    .line 103
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 104
    .line 105
    .line 106
    iget-object v11, p0, Le3/k;->k:Le3/o;

    .line 107
    .line 108
    const/4 v4, 0x0

    .line 109
    const/4 v8, 0x1

    .line 110
    const/4 v9, 0x0

    .line 111
    move-object v6, p3

    .line 112
    invoke-direct/range {v1 .. v11}, Lcom/facebook/imagepipeline/producers/e;-><init>(Lcom/facebook/imagepipeline/request/d;Ljava/lang/String;Ljava/lang/String;Lcom/facebook/imagepipeline/producers/ProducerListener2;Ljava/lang/Object;Lcom/facebook/imagepipeline/request/c;ZZLcom/facebook/imagepipeline/common/e;Lcom/facebook/imagepipeline/core/ImagePipelineConfigInterface;)V

    .line 113
    .line 114
    .line 115
    sget-object p2, Lf3/d;->j:Lf3/c;

    .line 116
    .line 117
    invoke-virtual {p2, p1, v1, v5}, Lf3/c;->create(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/producers/i0;Lcom/facebook/imagepipeline/listener/RequestListener2;)Lcom/facebook/datasource/DataSource;

    .line 118
    .line 119
    .line 120
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 121
    return-object p1

    .line 122
    :catch_0
    move-exception v0

    .line 123
    move-object p1, v0

    .line 124
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->z(Ljava/lang/Exception;)Ly2/g;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    return-object p1
.end method
