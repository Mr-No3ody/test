.class public final Le3/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/imagepipeline/core/DiskCachesStore;


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;

.field public final e:Ljava/lang/Object;

.field public final f:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Le3/h;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lxf/k;->a:Lxf/k;

    .line 5
    .line 6
    new-instance v1, Le3/e;

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    invoke-direct {v1, p1, v2}, Le3/e;-><init>(Le3/h;I)V

    .line 10
    .line 11
    .line 12
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    iput-object v1, p0, Le3/g;->a:Ljava/lang/Object;

    .line 17
    .line 18
    new-instance v1, Le3/f;

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    invoke-direct {v1, p0, p1, v2}, Le3/f;-><init>(Le3/g;Le3/h;I)V

    .line 22
    .line 23
    .line 24
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    iput-object v1, p0, Le3/g;->b:Ljava/lang/Object;

    .line 29
    .line 30
    new-instance v1, Le3/e;

    .line 31
    .line 32
    const/4 v2, 0x2

    .line 33
    invoke-direct {v1, p1, v2}, Le3/e;-><init>(Le3/h;I)V

    .line 34
    .line 35
    .line 36
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    iput-object v1, p0, Le3/g;->c:Ljava/lang/Object;

    .line 41
    .line 42
    new-instance v1, Le3/f;

    .line 43
    .line 44
    const/4 v2, 0x1

    .line 45
    invoke-direct {v1, p0, p1, v2}, Le3/f;-><init>(Le3/g;Le3/h;I)V

    .line 46
    .line 47
    .line 48
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    iput-object v1, p0, Le3/g;->d:Ljava/lang/Object;

    .line 53
    .line 54
    new-instance v1, Le3/f;

    .line 55
    .line 56
    invoke-direct {v1, p1, p0}, Le3/f;-><init>(Le3/h;Le3/g;)V

    .line 57
    .line 58
    .line 59
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    iput-object v1, p0, Le3/g;->e:Ljava/lang/Object;

    .line 64
    .line 65
    new-instance v1, Le3/f;

    .line 66
    .line 67
    const/4 v2, 0x3

    .line 68
    invoke-direct {v1, p0, p1, v2}, Le3/f;-><init>(Le3/g;Le3/h;I)V

    .line 69
    .line 70
    .line 71
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    iput-object p1, p0, Le3/g;->f:Ljava/lang/Object;

    .line 76
    .line 77
    return-void
.end method


# virtual methods
.method public final getDynamicBufferedDiskCaches()Lo2/d;
    .locals 2

    .line 1
    iget-object v0, p0, Le3/g;->f:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "getValue(...)"

    .line 8
    .line 9
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    check-cast v0, Lo2/d;

    .line 13
    .line 14
    return-object v0
.end method

.method public final getDynamicFileCaches()Ljava/util/Map;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/g;->e:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/util/Map;

    .line 8
    .line 9
    return-object v0
.end method

.method public final getMainBufferedDiskCache()Ld3/d;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ld3/d;

    .line 8
    .line 9
    return-object v0
.end method

.method public final getMainFileCache()Lcom/facebook/cache/disk/FileCache;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/g;->a:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/facebook/cache/disk/FileCache;

    .line 8
    .line 9
    return-object v0
.end method

.method public final getSmallImageBufferedDiskCache()Ld3/d;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/g;->d:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ld3/d;

    .line 8
    .line 9
    return-object v0
.end method

.method public final getSmallImageFileCache()Lcom/facebook/cache/disk/FileCache;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/g;->c:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/facebook/cache/disk/FileCache;

    .line 8
    .line 9
    return-object v0
.end method
