.class public final Le3/u;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/ContentResolver;

.field public final b:Landroid/content/res/Resources;

.field public final c:Landroid/content/res/AssetManager;

.field public final d:Lcom/facebook/common/memory/ByteArrayPool;

.field public final e:Lcom/facebook/imagepipeline/decoder/ImageDecoder;

.field public final f:Lcom/facebook/imagepipeline/decoder/ProgressiveJpegConfig;

.field public final g:Le3/i;

.field public final h:Z

.field public final i:Z

.field public final j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

.field public final k:Lcom/facebook/common/memory/PooledByteBufferFactory;

.field public final l:Lcom/facebook/common/internal/Supplier;

.field public final m:Lcom/facebook/imagepipeline/cache/MemoryCache;

.field public final n:Lcom/facebook/imagepipeline/cache/MemoryCache;

.field public final o:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

.field public final p:Lc3/b;

.field public final q:Le3/b;

.field public final r:I

.field public final s:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/facebook/common/memory/ByteArrayPool;Lcom/facebook/imagepipeline/decoder/ImageDecoder;Lcom/facebook/imagepipeline/decoder/ProgressiveJpegConfig;Le3/i;ZZLcom/facebook/imagepipeline/core/ExecutorSupplier;Lcom/facebook/common/memory/PooledByteBufferFactory;Lcom/facebook/imagepipeline/cache/MemoryCache;Lcom/facebook/imagepipeline/cache/MemoryCache;Lcom/facebook/common/internal/Supplier;Lcom/facebook/imagepipeline/cache/CacheKeyFactory;Lc3/b;IIZILe3/b;ZI)V
    .locals 2

    move/from16 v0, p21

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    iput-object v1, p0, Le3/u;->a:Landroid/content/ContentResolver;

    .line 3
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    iput-object v1, p0, Le3/u;->b:Landroid/content/res/Resources;

    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p1

    iput-object p1, p0, Le3/u;->c:Landroid/content/res/AssetManager;

    .line 5
    iput-object p2, p0, Le3/u;->d:Lcom/facebook/common/memory/ByteArrayPool;

    .line 6
    iput-object p3, p0, Le3/u;->e:Lcom/facebook/imagepipeline/decoder/ImageDecoder;

    .line 7
    iput-object p4, p0, Le3/u;->f:Lcom/facebook/imagepipeline/decoder/ProgressiveJpegConfig;

    .line 8
    iput-object p5, p0, Le3/u;->g:Le3/i;

    .line 9
    iput-boolean p6, p0, Le3/u;->h:Z

    .line 10
    iput-boolean p7, p0, Le3/u;->i:Z

    .line 11
    iput-object p8, p0, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 12
    iput-object p9, p0, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 13
    iput-object p10, p0, Le3/u;->n:Lcom/facebook/imagepipeline/cache/MemoryCache;

    .line 14
    iput-object p11, p0, Le3/u;->m:Lcom/facebook/imagepipeline/cache/MemoryCache;

    .line 15
    iput-object p12, p0, Le3/u;->l:Lcom/facebook/common/internal/Supplier;

    .line 16
    iput-object p13, p0, Le3/u;->o:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    move-object/from16 p1, p14

    .line 17
    iput-object p1, p0, Le3/u;->p:Lc3/b;

    .line 18
    new-instance p1, Li2/d;

    invoke-direct {p1, v0}, Li2/d;-><init>(I)V

    .line 19
    new-instance p1, Li2/d;

    invoke-direct {p1, v0}, Li2/d;-><init>(I)V

    move/from16 p1, p18

    .line 20
    iput p1, p0, Le3/u;->r:I

    move-object/from16 p1, p19

    .line 21
    iput-object p1, p0, Le3/u;->q:Le3/b;

    move/from16 p1, p20

    .line 22
    iput-boolean p1, p0, Le3/u;->s:Z

    return-void
.end method


# virtual methods
.method public final a()Lcom/facebook/imagepipeline/producers/S;
    .locals 4

    .line 1
    new-instance v0, Lcom/facebook/imagepipeline/producers/S;

    .line 2
    .line 3
    iget-object v1, p0, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 4
    .line 5
    invoke-interface {v1}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const-string v2, "executor"

    .line 10
    .line 11
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v2, p0, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 15
    .line 16
    const-string v3, "pooledByteBufferFactory"

    .line 17
    .line 18
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-direct {v0, v1, v2}, Lcom/facebook/imagepipeline/producers/P;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;)V

    .line 22
    .line 23
    .line 24
    return-object v0
.end method

.method public final b(Lcom/facebook/imagepipeline/producers/Producer;ZLn3/c;)Lcom/facebook/imagepipeline/producers/h0;
    .locals 6

    .line 1
    new-instance v0, Lcom/facebook/imagepipeline/producers/h0;

    .line 2
    .line 3
    iget-object v1, p0, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 4
    .line 5
    invoke-interface {v1}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forBackgroundTasks()Ljava/util/concurrent/Executor;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    iget-object v2, p0, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 10
    .line 11
    move-object v3, p1

    .line 12
    move v4, p2

    .line 13
    move-object v5, p3

    .line 14
    invoke-direct/range {v0 .. v5}, Lcom/facebook/imagepipeline/producers/h0;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Lcom/facebook/imagepipeline/producers/Producer;ZLn3/c;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method
