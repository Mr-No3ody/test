.class public final Le3/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/imagepipeline/core/ImagePipelineConfigInterface;


# static fields
.field public static final D:Le3/m;

.field public static E:Le3/n;


# instance fields
.field public final A:Z

.field public final B:Lcom/facebook/imagepipeline/debug/a;

.field public final C:Lcom/facebook/imagepipeline/cache/c;

.field public final a:Landroid/graphics/Bitmap$Config;

.field public final b:Ld3/f;

.field public final c:Lcom/facebook/imagepipeline/cache/a;

.field public final d:Lcom/facebook/imagepipeline/cache/g;

.field public final e:Ld3/g;

.field public final f:Landroid/content/Context;

.field public final g:Le3/i;

.field public final h:Le3/h;

.field public final i:Ld3/h;

.field public final j:Le3/d;

.field public final k:Ld3/j;

.field public final l:Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;

.field public final m:LQ2/a;

.field public final n:LQ2/a;

.field public final o:Lj2/b;

.field public final p:Lr2/c;

.field public final q:I

.field public final r:Lcom/facebook/imagepipeline/producers/NetworkFetcher;

.field public final s:Lj3/w;

.field public final t:Lorg/sufficientlysecure/htmltextview/l;

.field public final u:Ljava/util/Set;

.field public final v:Lkotlin/collections/B;

.field public final w:Lkotlin/collections/B;

.field public final x:Z

.field public final y:Lj2/b;

.field public final z:Le3/r;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Le3/m;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Le3/m;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Le3/o;->D:Le3/m;

    .line 8
    .line 9
    new-instance v0, Le3/n;

    .line 10
    .line 11
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    sput-object v0, Le3/o;->E:Le3/n;

    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(Le3/l;)V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 5
    .line 6
    .line 7
    iget-object v0, p1, Le3/l;->g:Le3/p;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    new-instance v1, Le3/r;

    .line 13
    .line 14
    invoke-direct {v1, v0}, Le3/r;-><init>(Le3/p;)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, Le3/o;->z:Le3/r;

    .line 18
    .line 19
    new-instance v0, Ld3/f;

    .line 20
    .line 21
    iget-object v2, p1, Le3/l;->a:Landroid/content/Context;

    .line 22
    .line 23
    const-string v3, "activity"

    .line 24
    .line 25
    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    if-eqz v2, :cond_6

    .line 30
    .line 31
    check-cast v2, Landroid/app/ActivityManager;

    .line 32
    .line 33
    invoke-direct {v0, v2}, Ld3/f;-><init>(Landroid/app/ActivityManager;)V

    .line 34
    .line 35
    .line 36
    iput-object v0, p0, Le3/o;->b:Ld3/f;

    .line 37
    .line 38
    new-instance v0, Lcom/facebook/imagepipeline/cache/a;

    .line 39
    .line 40
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 41
    .line 42
    .line 43
    iput-object v0, p0, Le3/o;->c:Lcom/facebook/imagepipeline/cache/a;

    .line 44
    .line 45
    new-instance v0, Lcom/facebook/imagepipeline/cache/g;

    .line 46
    .line 47
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 48
    .line 49
    .line 50
    iput-object v0, p0, Le3/o;->d:Lcom/facebook/imagepipeline/cache/g;

    .line 51
    .line 52
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 53
    .line 54
    iput-object v0, p0, Le3/o;->a:Landroid/graphics/Bitmap$Config;

    .line 55
    .line 56
    const-class v0, Ld3/g;

    .line 57
    .line 58
    monitor-enter v0

    .line 59
    :try_start_0
    sget-object v2, Ld3/g;->b:Ld3/g;

    .line 60
    .line 61
    if-nez v2, :cond_0

    .line 62
    .line 63
    new-instance v2, Ld3/g;

    .line 64
    .line 65
    const/4 v3, 0x0

    .line 66
    invoke-direct {v2, v3}, Ld3/g;-><init>(I)V

    .line 67
    .line 68
    .line 69
    sput-object v2, Ld3/g;->b:Ld3/g;

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :catchall_0
    move-exception p1

    .line 73
    goto/16 :goto_3

    .line 74
    .line 75
    :cond_0
    :goto_0
    sget-object v2, Ld3/g;->b:Ld3/g;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 76
    .line 77
    monitor-exit v0

    .line 78
    const-string v0, "getInstance(...)"

    .line 79
    .line 80
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    iput-object v2, p0, Le3/o;->e:Ld3/g;

    .line 84
    .line 85
    iget-object v0, p1, Le3/l;->a:Landroid/content/Context;

    .line 86
    .line 87
    if-eqz v0, :cond_5

    .line 88
    .line 89
    iput-object v0, p0, Le3/o;->f:Landroid/content/Context;

    .line 90
    .line 91
    iget-object v0, p1, Le3/l;->b:Le3/i;

    .line 92
    .line 93
    iput-object v0, p0, Le3/o;->g:Le3/i;

    .line 94
    .line 95
    new-instance v0, Ld3/h;

    .line 96
    .line 97
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 98
    .line 99
    .line 100
    iput-object v0, p0, Le3/o;->i:Ld3/h;

    .line 101
    .line 102
    const-class v0, Ld3/j;

    .line 103
    .line 104
    monitor-enter v0

    .line 105
    :try_start_1
    sget-object v2, Ld3/j;->b:Ld3/j;

    .line 106
    .line 107
    if-nez v2, :cond_1

    .line 108
    .line 109
    new-instance v2, Ld3/j;

    .line 110
    .line 111
    const/4 v3, 0x0

    .line 112
    invoke-direct {v2, v3}, Ld3/j;-><init>(I)V

    .line 113
    .line 114
    .line 115
    sput-object v2, Ld3/j;->b:Ld3/j;

    .line 116
    .line 117
    goto :goto_1

    .line 118
    :catchall_1
    move-exception p1

    .line 119
    goto/16 :goto_2

    .line 120
    .line 121
    :cond_1
    :goto_1
    sget-object v2, Ld3/j;->b:Ld3/j;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 122
    .line 123
    monitor-exit v0

    .line 124
    const-string v0, "getInstance(...)"

    .line 125
    .line 126
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    iput-object v2, p0, Le3/o;->k:Ld3/j;

    .line 130
    .line 131
    sget-object v0, Lo2/e;->b:LQ2/a;

    .line 132
    .line 133
    const-string v2, "BOOLEAN_FALSE"

    .line 134
    .line 135
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    iput-object v0, p0, Le3/o;->m:LQ2/a;

    .line 139
    .line 140
    sget-object v0, Le3/o;->D:Le3/m;

    .line 141
    .line 142
    invoke-static {v0, p1}, Le3/m;->access$getImageTranscoderFactory(Le3/m;Le3/l;)Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;

    .line 143
    .line 144
    .line 145
    move-result-object v2

    .line 146
    iput-object v2, p0, Le3/o;->l:Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;

    .line 147
    .line 148
    sget-object v2, Lo2/e;->a:LQ2/a;

    .line 149
    .line 150
    const-string v3, "BOOLEAN_TRUE"

    .line 151
    .line 152
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    iput-object v2, p0, Le3/o;->n:LQ2/a;

    .line 156
    .line 157
    iget-object v2, p1, Le3/l;->a:Landroid/content/Context;

    .line 158
    .line 159
    invoke-static {v0, v2}, Le3/m;->access$getDefaultMainDiskCacheConfig(Le3/m;Landroid/content/Context;)Lj2/b;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    iput-object v2, p0, Le3/o;->o:Lj2/b;

    .line 164
    .line 165
    invoke-static {}, Lr2/c;->a()Lr2/c;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    const-string v4, "getInstance(...)"

    .line 170
    .line 171
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 172
    .line 173
    .line 174
    iput-object v3, p0, Le3/o;->p:Lr2/c;

    .line 175
    .line 176
    invoke-static {v0, p1, v1}, Le3/m;->access$getMemoryChunkType(Le3/m;Le3/l;Le3/r;)I

    .line 177
    .line 178
    .line 179
    move-result v0

    .line 180
    iput v0, p0, Le3/o;->q:I

    .line 181
    .line 182
    iget v0, p1, Le3/l;->f:I

    .line 183
    .line 184
    if-gez v0, :cond_2

    .line 185
    .line 186
    const/16 v0, 0x7530

    .line 187
    .line 188
    :cond_2
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 189
    .line 190
    .line 191
    iget-object v1, p1, Le3/l;->c:Lb3/e;

    .line 192
    .line 193
    if-nez v1, :cond_3

    .line 194
    .line 195
    new-instance v1, Lcom/facebook/imagepipeline/producers/D;

    .line 196
    .line 197
    invoke-direct {v1, v0}, Lcom/facebook/imagepipeline/producers/D;-><init>(I)V

    .line 198
    .line 199
    .line 200
    :cond_3
    iput-object v1, p0, Le3/o;->r:Lcom/facebook/imagepipeline/producers/NetworkFetcher;

    .line 201
    .line 202
    new-instance v0, Lj3/w;

    .line 203
    .line 204
    new-instance v1, Lorg/sufficientlysecure/htmltextview/o;

    .line 205
    .line 206
    const/16 v3, 0x9

    .line 207
    .line 208
    invoke-direct {v1, v3}, Lorg/sufficientlysecure/htmltextview/o;-><init>(I)V

    .line 209
    .line 210
    .line 211
    new-instance v3, Lj3/v;

    .line 212
    .line 213
    invoke-direct {v3, v1}, Lj3/v;-><init>(Lorg/sufficientlysecure/htmltextview/o;)V

    .line 214
    .line 215
    .line 216
    invoke-direct {v0, v3}, Lj3/w;-><init>(Lj3/v;)V

    .line 217
    .line 218
    .line 219
    iput-object v0, p0, Le3/o;->s:Lj3/w;

    .line 220
    .line 221
    new-instance v0, Lorg/sufficientlysecure/htmltextview/l;

    .line 222
    .line 223
    const/16 v1, 0x9

    .line 224
    .line 225
    invoke-direct {v0, v1}, Lorg/sufficientlysecure/htmltextview/l;-><init>(I)V

    .line 226
    .line 227
    .line 228
    iput-object v0, p0, Le3/o;->t:Lorg/sufficientlysecure/htmltextview/l;

    .line 229
    .line 230
    iget-object v0, p1, Le3/l;->d:Ljava/util/HashSet;

    .line 231
    .line 232
    if-nez v0, :cond_4

    .line 233
    .line 234
    sget-object v0, Lkotlin/collections/B;->a:Lkotlin/collections/B;

    .line 235
    .line 236
    :cond_4
    iput-object v0, p0, Le3/o;->u:Ljava/util/Set;

    .line 237
    .line 238
    sget-object v0, Lkotlin/collections/B;->a:Lkotlin/collections/B;

    .line 239
    .line 240
    iput-object v0, p0, Le3/o;->v:Lkotlin/collections/B;

    .line 241
    .line 242
    iput-object v0, p0, Le3/o;->w:Lkotlin/collections/B;

    .line 243
    .line 244
    iget-boolean v0, p1, Le3/l;->e:Z

    .line 245
    .line 246
    iput-boolean v0, p0, Le3/o;->x:Z

    .line 247
    .line 248
    iput-object v2, p0, Le3/o;->y:Lj2/b;

    .line 249
    .line 250
    iget-object v0, v3, Lj3/v;->e:Ljava/lang/Object;

    .line 251
    .line 252
    check-cast v0, Lj3/x;

    .line 253
    .line 254
    iget v0, v0, Lj3/x;->d:I

    .line 255
    .line 256
    new-instance v1, Le3/d;

    .line 257
    .line 258
    invoke-direct {v1, v0}, Le3/d;-><init>(I)V

    .line 259
    .line 260
    .line 261
    iput-object v1, p0, Le3/o;->j:Le3/d;

    .line 262
    .line 263
    iget-boolean v0, p1, Le3/l;->h:Z

    .line 264
    .line 265
    iput-boolean v0, p0, Le3/o;->A:Z

    .line 266
    .line 267
    iget-object p1, p1, Le3/l;->i:Lcom/facebook/imagepipeline/debug/a;

    .line 268
    .line 269
    iput-object p1, p0, Le3/o;->B:Lcom/facebook/imagepipeline/debug/a;

    .line 270
    .line 271
    new-instance p1, Lcom/facebook/imagepipeline/cache/c;

    .line 272
    .line 273
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 274
    .line 275
    .line 276
    iput-object p1, p0, Le3/o;->C:Lcom/facebook/imagepipeline/cache/c;

    .line 277
    .line 278
    new-instance p1, Le3/h;

    .line 279
    .line 280
    new-instance v0, LAb/r;

    .line 281
    .line 282
    new-instance v1, Ll2/a;

    .line 283
    .line 284
    const/16 v2, 0x9

    .line 285
    .line 286
    invoke-direct {v1, v2}, Ll2/a;-><init>(I)V

    .line 287
    .line 288
    .line 289
    const/16 v2, 0x11

    .line 290
    .line 291
    const/4 v3, 0x0

    .line 292
    invoke-direct {v0, v2, v3}, LAb/r;-><init>(IZ)V

    .line 293
    .line 294
    .line 295
    iput-object v1, v0, LAb/r;->b:Ljava/lang/Object;

    .line 296
    .line 297
    invoke-direct {p1, v0, p0}, Le3/h;-><init>(LAb/r;Le3/o;)V

    .line 298
    .line 299
    .line 300
    iput-object p1, p0, Le3/o;->h:Le3/h;

    .line 301
    .line 302
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 303
    .line 304
    .line 305
    return-void

    .line 306
    :goto_2
    :try_start_2
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 307
    throw p1

    .line 308
    :cond_5
    const-string p1, "Required value was null."

    .line 309
    .line 310
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 311
    .line 312
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 313
    .line 314
    .line 315
    throw v0

    .line 316
    :goto_3
    :try_start_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 317
    throw p1

    .line 318
    :cond_6
    const-string p1, "Required value was null."

    .line 319
    .line 320
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 321
    .line 322
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 323
    .line 324
    .line 325
    throw v0
.end method


# virtual methods
.method public final getBitmapCacheOverride()Lcom/facebook/imagepipeline/cache/MemoryCache;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getBitmapConfig()Landroid/graphics/Bitmap$Config;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->a:Landroid/graphics/Bitmap$Config;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getBitmapMemoryCacheEntryStateObserver()Lcom/facebook/imagepipeline/cache/CountingMemoryCache$EntryStateObserver;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getBitmapMemoryCacheFactory()Lcom/facebook/imagepipeline/cache/BitmapMemoryCacheFactory;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->C:Lcom/facebook/imagepipeline/cache/c;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getBitmapMemoryCacheParamsSupplier()Lcom/facebook/common/internal/Supplier;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->b:Ld3/f;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getBitmapMemoryCacheTrimStrategy()Lcom/facebook/imagepipeline/cache/MemoryCache$CacheTrimStrategy;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->c:Lcom/facebook/imagepipeline/cache/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getCacheKeyFactory()Lcom/facebook/imagepipeline/cache/CacheKeyFactory;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->e:Ld3/g;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getCallerContextVerifier()Lcom/facebook/callercontext/CallerContextVerifier;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getCloseableReferenceLeakTracker()Lcom/facebook/imagepipeline/debug/CloseableReferenceLeakTracker;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->B:Lcom/facebook/imagepipeline/debug/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getContext()Landroid/content/Context;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->f:Landroid/content/Context;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getCustomProducerSequenceFactories()Ljava/util/Set;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->w:Lkotlin/collections/B;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getDiskCachesStoreSupplier()Lcom/facebook/common/internal/Supplier;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->h:Le3/h;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getDownsampleMode()Le3/i;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->g:Le3/i;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getDynamicDiskCacheConfigMap()Ljava/util/Map;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getEnableEncodedImageColorSpaceUsage()Lcom/facebook/common/internal/Supplier;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->m:LQ2/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getEncodedMemoryCacheOverride()Lcom/facebook/imagepipeline/cache/MemoryCache;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getEncodedMemoryCacheParamsSupplier()Lcom/facebook/common/internal/Supplier;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->i:Ld3/h;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getEncodedMemoryCacheTrimStrategy()Lcom/facebook/imagepipeline/cache/MemoryCache$CacheTrimStrategy;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->d:Lcom/facebook/imagepipeline/cache/g;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getExecutorServiceForAnimatedImages()Lcom/facebook/common/executors/SerialExecutorService;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getExecutorSupplier()Lcom/facebook/imagepipeline/core/ExecutorSupplier;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->j:Le3/d;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getExperiments()Le3/r;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->z:Le3/r;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getImageCacheStatsTracker()Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->k:Ld3/j;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getImageDecoder()Lcom/facebook/imagepipeline/decoder/ImageDecoder;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getImageDecoderConfig()Lg3/b;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getImageTranscoderFactory()Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->l:Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getImageTranscoderType()Ljava/lang/Integer;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getMainDiskCacheConfig()Lj2/b;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->o:Lj2/b;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getMemoryChunkType()I
    .locals 1

    .line 1
    iget v0, p0, Le3/o;->q:I

    .line 2
    .line 3
    return v0
.end method

.method public final getMemoryTrimmableRegistry()Lcom/facebook/common/memory/MemoryTrimmableRegistry;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->p:Lr2/c;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getNetworkFetcher()Lcom/facebook/imagepipeline/producers/NetworkFetcher;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->r:Lcom/facebook/imagepipeline/producers/NetworkFetcher;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getPlatformBitmapFactory()Lc3/b;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final getPoolFactory()Lj3/w;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->s:Lj3/w;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getProgressiveJpegConfig()Lcom/facebook/imagepipeline/decoder/ProgressiveJpegConfig;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->t:Lorg/sufficientlysecure/htmltextview/l;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getRequestListener2s()Ljava/util/Set;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->v:Lkotlin/collections/B;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getRequestListeners()Ljava/util/Set;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->u:Ljava/util/Set;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getSmallImageDiskCacheConfig()Lj2/b;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->y:Lj2/b;

    .line 2
    .line 3
    return-object v0
.end method

.method public final isDiskCacheEnabled()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Le3/o;->A:Z

    .line 2
    .line 3
    return v0
.end method

.method public final isPrefetchEnabledSupplier()Lcom/facebook/common/internal/Supplier;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/o;->n:LQ2/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public final isResizeAndRotateEnabledForNetwork()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Le3/o;->x:Z

    .line 2
    .line 3
    return v0
.end method
