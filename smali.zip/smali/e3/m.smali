.class public final Le3/m;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Le3/m;-><init>()V

    return-void
.end method

.method public static final synthetic access$getDefaultMainDiskCacheConfig(Le3/m;Landroid/content/Context;)Lj2/b;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Le3/m;->getDefaultMainDiskCacheConfig(Landroid/content/Context;)Lj2/b;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static final synthetic access$getImageTranscoderFactory(Le3/m;Le3/l;)Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Le3/m;->getImageTranscoderFactory(Le3/l;)Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static final synthetic access$getMemoryChunkType(Le3/m;Le3/l;Le3/r;)I
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Le3/m;->getMemoryChunkType(Le3/l;Le3/r;)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$setWebpBitmapFactory(Le3/m;Lcom/facebook/common/webp/WebpBitmapFactory;Le3/r;Lcom/facebook/common/webp/BitmapCreator;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, Le3/m;->setWebpBitmapFactory(Lcom/facebook/common/webp/WebpBitmapFactory;Le3/r;Lcom/facebook/common/webp/BitmapCreator;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static synthetic getDefaultImageRequestConfig$annotations()V
    .locals 0
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    return-void
.end method

.method private final getDefaultMainDiskCacheConfig(Landroid/content/Context;)Lj2/b;
    .locals 2

    .line 1
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroidx/camera/video/internal/c;

    .line 5
    .line 6
    const/16 v1, 0xf

    .line 7
    .line 8
    invoke-direct {v0, p1, v1}, Landroidx/camera/video/internal/c;-><init>(Landroid/content/Context;I)V

    .line 9
    .line 10
    .line 11
    new-instance p1, Lj2/b;

    .line 12
    .line 13
    invoke-direct {p1, v0}, Lj2/b;-><init>(Landroidx/camera/video/internal/c;)V

    .line 14
    .line 15
    .line 16
    const-string/jumbo v0, "traceSection(...)"

    .line 17
    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    return-object p1
.end method

.method private final getImageTranscoderFactory(Le3/l;)Lcom/facebook/imagepipeline/transcoder/ImageTranscoderFactory;
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    return-object p1
.end method

.method private final getMemoryChunkType(Le3/l;Le3/r;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    return p1
.end method

.method private final setWebpBitmapFactory(Lcom/facebook/common/webp/WebpBitmapFactory;Le3/r;Lcom/facebook/common/webp/BitmapCreator;)V
    .locals 0

    .line 1
    sput-object p1, Lx2/a;->a:Lcom/facebook/common/webp/WebpBitmapFactory;

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    if-eqz p3, :cond_0

    .line 7
    .line 8
    invoke-interface {p1, p3}, Lcom/facebook/common/webp/WebpBitmapFactory;->setBitmapCreator(Lcom/facebook/common/webp/BitmapCreator;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-void
.end method


# virtual methods
.method public final getDefaultImageRequestConfig()Le3/n;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    sget-object v0, Le3/o;->E:Le3/n;

    .line 2
    .line 3
    return-object v0
.end method

.method public final newBuilder(Landroid/content/Context;)Le3/l;
    .locals 1
    .param p1    # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Le3/l;

    .line 7
    .line 8
    invoke-direct {v0, p1}, Le3/l;-><init>(Landroid/content/Context;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public final resetDefaultRequestConfig()V
    .locals 1
    .annotation build Landroidx/annotation/VisibleForTesting;
    .end annotation

    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    new-instance v0, Le3/n;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Le3/o;->E:Le3/n;

    .line 7
    .line 8
    return-void
.end method
