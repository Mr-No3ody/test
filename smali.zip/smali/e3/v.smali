.class public final synthetic Le3/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Le3/x;


# direct methods
.method public synthetic constructor <init>(Le3/x;I)V
    .locals 0

    .line 1
    iput p2, p0, Le3/v;->a:I

    iput-object p1, p0, Le3/v;->b:Le3/x;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 11

    .line 1
    const/4 v0, 0x2

    .line 2
    const/4 v1, 0x1

    .line 3
    const/4 v2, 0x0

    .line 4
    iget v3, p0, Le3/v;->a:I

    .line 5
    .line 6
    packed-switch v3, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 10
    .line 11
    const-string/jumbo v1, "this$0"

    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 18
    .line 19
    .line 20
    new-instance v1, Lcom/facebook/imagepipeline/producers/b;

    .line 21
    .line 22
    invoke-virtual {v0}, Le3/x;->a()Lcom/facebook/imagepipeline/producers/Producer;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-direct {v1, v0}, Lcom/facebook/imagepipeline/producers/b;-><init>(Lcom/facebook/imagepipeline/producers/Producer;)V

    .line 27
    .line 28
    .line 29
    return-object v1

    .line 30
    :pswitch_0
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 31
    .line 32
    const-string/jumbo v3, "this$0"

    .line 33
    .line 34
    .line 35
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    iget-object v3, v0, Le3/x;->b:Le3/u;

    .line 39
    .line 40
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    new-instance v4, Lcom/facebook/imagepipeline/producers/m;

    .line 44
    .line 45
    sget-object v5, Lm2/a;->a:Lm2/a;

    .line 46
    .line 47
    iget-object v3, v3, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 48
    .line 49
    invoke-direct {v4, v5, v3}, Lcom/facebook/imagepipeline/producers/P;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;)V

    .line 50
    .line 51
    .line 52
    const-string v3, "newDataFetchProducer(...)"

    .line 53
    .line 54
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    new-instance v3, Lcom/facebook/imagepipeline/producers/b;

    .line 58
    .line 59
    invoke-direct {v3, v4, v2}, Lcom/facebook/imagepipeline/producers/b;-><init>(Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 60
    .line 61
    .line 62
    iget-object v2, v0, Le3/x;->h:Ln3/c;

    .line 63
    .line 64
    iget-object v4, v0, Le3/x;->b:Le3/u;

    .line 65
    .line 66
    invoke-virtual {v4, v3, v1, v2}, Le3/u;->b(Lcom/facebook/imagepipeline/producers/Producer;ZLn3/c;)Lcom/facebook/imagepipeline/producers/h0;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    invoke-virtual {v0, v1}, Le3/x;->h(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    return-object v0

    .line 75
    :pswitch_1
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 76
    .line 77
    const-string/jumbo v3, "this$0"

    .line 78
    .line 79
    .line 80
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    iget-object v3, v0, Le3/x;->b:Le3/u;

    .line 84
    .line 85
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    new-instance v4, Lcom/facebook/imagepipeline/producers/I;

    .line 89
    .line 90
    iget-object v5, v3, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 91
    .line 92
    invoke-interface {v5}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 93
    .line 94
    .line 95
    move-result-object v5

    .line 96
    iget-object v6, v3, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 97
    .line 98
    iget-object v3, v3, Le3/u;->c:Landroid/content/res/AssetManager;

    .line 99
    .line 100
    invoke-direct {v4, v5, v6, v3}, Lcom/facebook/imagepipeline/producers/I;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/res/AssetManager;)V

    .line 101
    .line 102
    .line 103
    const-string v3, "newLocalAssetFetchProducer(...)"

    .line 104
    .line 105
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    new-instance v3, Lcom/facebook/imagepipeline/producers/N;

    .line 109
    .line 110
    iget-object v5, v0, Le3/x;->b:Le3/u;

    .line 111
    .line 112
    iget-object v6, v5, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 113
    .line 114
    invoke-interface {v6}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forThumbnailProducer()Ljava/util/concurrent/Executor;

    .line 115
    .line 116
    .line 117
    move-result-object v6

    .line 118
    iget-object v7, v5, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 119
    .line 120
    iget-object v5, v5, Le3/u;->a:Landroid/content/ContentResolver;

    .line 121
    .line 122
    invoke-direct {v3, v6, v7, v5}, Lcom/facebook/imagepipeline/producers/N;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 123
    .line 124
    .line 125
    new-array v1, v1, [Lcom/facebook/imagepipeline/producers/ThumbnailProducer;

    .line 126
    .line 127
    aput-object v3, v1, v2

    .line 128
    .line 129
    invoke-virtual {v0, v4, v1}, Le3/x;->i(Lcom/facebook/imagepipeline/producers/P;[Lcom/facebook/imagepipeline/producers/ThumbnailProducer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    return-object v0

    .line 134
    :pswitch_2
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 135
    .line 136
    const-string/jumbo v3, "this$0"

    .line 137
    .line 138
    .line 139
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    iget-object v3, v0, Le3/x;->b:Le3/u;

    .line 143
    .line 144
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 145
    .line 146
    .line 147
    new-instance v4, Lcom/facebook/imagepipeline/producers/U;

    .line 148
    .line 149
    iget-object v5, v3, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 150
    .line 151
    invoke-interface {v5}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 152
    .line 153
    .line 154
    move-result-object v5

    .line 155
    iget-object v6, v3, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 156
    .line 157
    iget-object v3, v3, Le3/u;->b:Landroid/content/res/Resources;

    .line 158
    .line 159
    invoke-direct {v4, v5, v6, v3}, Lcom/facebook/imagepipeline/producers/U;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/res/Resources;)V

    .line 160
    .line 161
    .line 162
    const-string v3, "newLocalResourceFetchProducer(...)"

    .line 163
    .line 164
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    new-instance v3, Lcom/facebook/imagepipeline/producers/N;

    .line 168
    .line 169
    iget-object v5, v0, Le3/x;->b:Le3/u;

    .line 170
    .line 171
    iget-object v6, v5, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 172
    .line 173
    invoke-interface {v6}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forThumbnailProducer()Ljava/util/concurrent/Executor;

    .line 174
    .line 175
    .line 176
    move-result-object v6

    .line 177
    iget-object v7, v5, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 178
    .line 179
    iget-object v5, v5, Le3/u;->a:Landroid/content/ContentResolver;

    .line 180
    .line 181
    invoke-direct {v3, v6, v7, v5}, Lcom/facebook/imagepipeline/producers/N;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 182
    .line 183
    .line 184
    new-array v1, v1, [Lcom/facebook/imagepipeline/producers/ThumbnailProducer;

    .line 185
    .line 186
    aput-object v3, v1, v2

    .line 187
    .line 188
    invoke-virtual {v0, v4, v1}, Le3/x;->i(Lcom/facebook/imagepipeline/producers/P;[Lcom/facebook/imagepipeline/producers/ThumbnailProducer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    return-object v0

    .line 193
    :pswitch_3
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 194
    .line 195
    const-string/jumbo v3, "this$0"

    .line 196
    .line 197
    .line 198
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    iget-object v3, v0, Le3/x;->b:Le3/u;

    .line 202
    .line 203
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 204
    .line 205
    .line 206
    new-instance v4, Lcom/facebook/imagepipeline/producers/f0;

    .line 207
    .line 208
    iget-object v5, v3, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 209
    .line 210
    invoke-interface {v5}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 211
    .line 212
    .line 213
    move-result-object v5

    .line 214
    iget-object v6, v3, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 215
    .line 216
    iget-object v3, v3, Le3/u;->a:Landroid/content/ContentResolver;

    .line 217
    .line 218
    invoke-direct {v4, v5, v6, v3}, Lcom/facebook/imagepipeline/producers/f0;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 219
    .line 220
    .line 221
    const-string v3, "newQualifiedResourceFetchProducer(...)"

    .line 222
    .line 223
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    new-instance v3, Lcom/facebook/imagepipeline/producers/N;

    .line 227
    .line 228
    iget-object v5, v0, Le3/x;->b:Le3/u;

    .line 229
    .line 230
    iget-object v6, v5, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 231
    .line 232
    invoke-interface {v6}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forThumbnailProducer()Ljava/util/concurrent/Executor;

    .line 233
    .line 234
    .line 235
    move-result-object v6

    .line 236
    iget-object v7, v5, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 237
    .line 238
    iget-object v5, v5, Le3/u;->a:Landroid/content/ContentResolver;

    .line 239
    .line 240
    invoke-direct {v3, v6, v7, v5}, Lcom/facebook/imagepipeline/producers/N;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 241
    .line 242
    .line 243
    new-array v1, v1, [Lcom/facebook/imagepipeline/producers/ThumbnailProducer;

    .line 244
    .line 245
    aput-object v3, v1, v2

    .line 246
    .line 247
    invoke-virtual {v0, v4, v1}, Le3/x;->i(Lcom/facebook/imagepipeline/producers/P;[Lcom/facebook/imagepipeline/producers/ThumbnailProducer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    return-object v0

    .line 252
    :pswitch_4
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 253
    .line 254
    const-string/jumbo v1, "this$0"

    .line 255
    .line 256
    .line 257
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 261
    .line 262
    const/16 v3, 0x1d

    .line 263
    .line 264
    if-lt v1, v3, :cond_0

    .line 265
    .line 266
    iget-object v1, v0, Le3/x;->b:Le3/u;

    .line 267
    .line 268
    new-instance v3, Lcom/facebook/imagepipeline/producers/W;

    .line 269
    .line 270
    iget-object v4, v1, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 271
    .line 272
    invoke-interface {v4}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forBackgroundTasks()Ljava/util/concurrent/Executor;

    .line 273
    .line 274
    .line 275
    move-result-object v4

    .line 276
    iget-object v1, v1, Le3/u;->a:Landroid/content/ContentResolver;

    .line 277
    .line 278
    invoke-direct {v3, v2, v4, v1}, Lcom/facebook/imagepipeline/producers/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 279
    .line 280
    .line 281
    const-string v1, "newLocalThumbnailBitmapSdk29Producer(...)"

    .line 282
    .line 283
    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {v0, v3}, Le3/x;->g(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    return-object v0

    .line 291
    :cond_0
    new-instance v0, Ljava/lang/Throwable;

    .line 292
    .line 293
    const-string v1, "Unreachable exception. Just to make linter happy for the lazy block."

    .line 294
    .line 295
    invoke-direct {v0, v1}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V

    .line 296
    .line 297
    .line 298
    throw v0

    .line 299
    :pswitch_5
    iget-object v3, p0, Le3/v;->b:Le3/x;

    .line 300
    .line 301
    const-string/jumbo v4, "this$0"

    .line 302
    .line 303
    .line 304
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 305
    .line 306
    .line 307
    iget-object v4, v3, Le3/x;->b:Le3/u;

    .line 308
    .line 309
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 310
    .line 311
    .line 312
    new-instance v5, Lcom/facebook/imagepipeline/producers/K;

    .line 313
    .line 314
    iget-object v6, v4, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 315
    .line 316
    invoke-interface {v6}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 317
    .line 318
    .line 319
    move-result-object v6

    .line 320
    iget-object v7, v4, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 321
    .line 322
    iget-object v4, v4, Le3/u;->a:Landroid/content/ContentResolver;

    .line 323
    .line 324
    invoke-direct {v5, v6, v7, v4}, Lcom/facebook/imagepipeline/producers/K;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 325
    .line 326
    .line 327
    const-string v4, "newLocalContentUriFetchProducer(...)"

    .line 328
    .line 329
    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    iget-object v4, v3, Le3/x;->b:Le3/u;

    .line 333
    .line 334
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 335
    .line 336
    .line 337
    new-instance v6, Lcom/facebook/imagepipeline/producers/L;

    .line 338
    .line 339
    iget-object v7, v4, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 340
    .line 341
    invoke-interface {v7}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 342
    .line 343
    .line 344
    move-result-object v8

    .line 345
    iget-object v9, v4, Le3/u;->a:Landroid/content/ContentResolver;

    .line 346
    .line 347
    iget-object v10, v4, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 348
    .line 349
    invoke-direct {v6, v8, v10, v9}, Lcom/facebook/imagepipeline/producers/L;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 350
    .line 351
    .line 352
    new-instance v8, Lcom/facebook/imagepipeline/producers/N;

    .line 353
    .line 354
    invoke-interface {v7}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forThumbnailProducer()Ljava/util/concurrent/Executor;

    .line 355
    .line 356
    .line 357
    move-result-object v7

    .line 358
    iget-object v4, v4, Le3/u;->a:Landroid/content/ContentResolver;

    .line 359
    .line 360
    invoke-direct {v8, v7, v10, v4}, Lcom/facebook/imagepipeline/producers/N;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 361
    .line 362
    .line 363
    new-array v0, v0, [Lcom/facebook/imagepipeline/producers/ThumbnailProducer;

    .line 364
    .line 365
    aput-object v6, v0, v2

    .line 366
    .line 367
    aput-object v8, v0, v1

    .line 368
    .line 369
    invoke-virtual {v3, v5, v0}, Le3/x;->i(Lcom/facebook/imagepipeline/producers/P;[Lcom/facebook/imagepipeline/producers/ThumbnailProducer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 370
    .line 371
    .line 372
    move-result-object v0

    .line 373
    return-object v0

    .line 374
    :pswitch_6
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 375
    .line 376
    const-string/jumbo v2, "this$0"

    .line 377
    .line 378
    .line 379
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 380
    .line 381
    .line 382
    iget-object v2, v0, Le3/x;->b:Le3/u;

    .line 383
    .line 384
    new-instance v3, Lcom/facebook/imagepipeline/producers/W;

    .line 385
    .line 386
    iget-object v4, v2, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 387
    .line 388
    invoke-interface {v4}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 389
    .line 390
    .line 391
    move-result-object v4

    .line 392
    iget-object v2, v2, Le3/u;->a:Landroid/content/ContentResolver;

    .line 393
    .line 394
    invoke-direct {v3, v1, v4, v2}, Lcom/facebook/imagepipeline/producers/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 395
    .line 396
    .line 397
    const-string v1, "newLocalVideoThumbnailProducer(...)"

    .line 398
    .line 399
    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 400
    .line 401
    .line 402
    invoke-virtual {v0, v3}, Le3/x;->g(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 403
    .line 404
    .line 405
    move-result-object v0

    .line 406
    return-object v0

    .line 407
    :pswitch_7
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 408
    .line 409
    const-string/jumbo v3, "this$0"

    .line 410
    .line 411
    .line 412
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 413
    .line 414
    .line 415
    iget-object v3, v0, Le3/x;->b:Le3/u;

    .line 416
    .line 417
    invoke-virtual {v3}, Le3/u;->a()Lcom/facebook/imagepipeline/producers/S;

    .line 418
    .line 419
    .line 420
    move-result-object v3

    .line 421
    const-string v4, "newLocalFileFetchProducer(...)"

    .line 422
    .line 423
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 424
    .line 425
    .line 426
    new-instance v4, Lcom/facebook/imagepipeline/producers/N;

    .line 427
    .line 428
    iget-object v5, v0, Le3/x;->b:Le3/u;

    .line 429
    .line 430
    iget-object v6, v5, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 431
    .line 432
    invoke-interface {v6}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forThumbnailProducer()Ljava/util/concurrent/Executor;

    .line 433
    .line 434
    .line 435
    move-result-object v6

    .line 436
    iget-object v7, v5, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 437
    .line 438
    iget-object v5, v5, Le3/u;->a:Landroid/content/ContentResolver;

    .line 439
    .line 440
    invoke-direct {v4, v6, v7, v5}, Lcom/facebook/imagepipeline/producers/N;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 441
    .line 442
    .line 443
    new-array v1, v1, [Lcom/facebook/imagepipeline/producers/ThumbnailProducer;

    .line 444
    .line 445
    aput-object v4, v1, v2

    .line 446
    .line 447
    invoke-virtual {v0, v3, v1}, Le3/x;->i(Lcom/facebook/imagepipeline/producers/P;[Lcom/facebook/imagepipeline/producers/ThumbnailProducer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 448
    .line 449
    .line 450
    move-result-object v0

    .line 451
    return-object v0

    .line 452
    :pswitch_8
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 453
    .line 454
    const-string/jumbo v1, "this$0"

    .line 455
    .line 456
    .line 457
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 458
    .line 459
    .line 460
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 461
    .line 462
    .line 463
    iget-object v1, v0, Le3/x;->b:Le3/u;

    .line 464
    .line 465
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 466
    .line 467
    .line 468
    new-instance v2, Lcom/facebook/imagepipeline/producers/K;

    .line 469
    .line 470
    iget-object v3, v1, Le3/u;->j:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 471
    .line 472
    invoke-interface {v3}, Lcom/facebook/imagepipeline/core/ExecutorSupplier;->forLocalStorageRead()Ljava/util/concurrent/Executor;

    .line 473
    .line 474
    .line 475
    move-result-object v3

    .line 476
    iget-object v4, v1, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 477
    .line 478
    iget-object v1, v1, Le3/u;->a:Landroid/content/ContentResolver;

    .line 479
    .line 480
    invoke-direct {v2, v3, v4, v1}, Lcom/facebook/imagepipeline/producers/K;-><init>(Ljava/util/concurrent/Executor;Lcom/facebook/common/memory/PooledByteBufferFactory;Landroid/content/ContentResolver;)V

    .line 481
    .line 482
    .line 483
    const-string v1, "newLocalContentUriFetchProducer(...)"

    .line 484
    .line 485
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 486
    .line 487
    .line 488
    invoke-virtual {v0, v2}, Le3/x;->j(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/i;

    .line 489
    .line 490
    .line 491
    move-result-object v1

    .line 492
    iget-object v2, v0, Le3/x;->b:Le3/u;

    .line 493
    .line 494
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 495
    .line 496
    .line 497
    new-instance v2, Lcom/facebook/imagepipeline/producers/l0;

    .line 498
    .line 499
    iget-object v0, v0, Le3/x;->e:LHe/a;

    .line 500
    .line 501
    invoke-direct {v2, v1, v0}, Lcom/facebook/imagepipeline/producers/l0;-><init>(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/producers/ThreadHandoffProducerQueue;)V

    .line 502
    .line 503
    .line 504
    return-object v2

    .line 505
    :pswitch_9
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 506
    .line 507
    const-string/jumbo v1, "this$0"

    .line 508
    .line 509
    .line 510
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 511
    .line 512
    .line 513
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 514
    .line 515
    .line 516
    iget-object v1, v0, Le3/x;->b:Le3/u;

    .line 517
    .line 518
    invoke-virtual {v1}, Le3/u;->a()Lcom/facebook/imagepipeline/producers/S;

    .line 519
    .line 520
    .line 521
    move-result-object v1

    .line 522
    const-string v2, "newLocalFileFetchProducer(...)"

    .line 523
    .line 524
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 525
    .line 526
    .line 527
    invoke-virtual {v0, v1}, Le3/x;->j(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/i;

    .line 528
    .line 529
    .line 530
    move-result-object v1

    .line 531
    iget-object v2, v0, Le3/x;->b:Le3/u;

    .line 532
    .line 533
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 534
    .line 535
    .line 536
    new-instance v2, Lcom/facebook/imagepipeline/producers/l0;

    .line 537
    .line 538
    iget-object v0, v0, Le3/x;->e:LHe/a;

    .line 539
    .line 540
    invoke-direct {v2, v1, v0}, Lcom/facebook/imagepipeline/producers/l0;-><init>(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/producers/ThreadHandoffProducerQueue;)V

    .line 541
    .line 542
    .line 543
    return-object v2

    .line 544
    :pswitch_a
    iget-object v1, p0, Le3/v;->b:Le3/x;

    .line 545
    .line 546
    const-string/jumbo v2, "this$0"

    .line 547
    .line 548
    .line 549
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 550
    .line 551
    .line 552
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 553
    .line 554
    .line 555
    iget-object v2, v1, Le3/x;->b:Le3/u;

    .line 556
    .line 557
    invoke-virtual {v1}, Le3/x;->a()Lcom/facebook/imagepipeline/producers/Producer;

    .line 558
    .line 559
    .line 560
    move-result-object v1

    .line 561
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 562
    .line 563
    .line 564
    new-instance v2, Lcom/facebook/imagepipeline/producers/b;

    .line 565
    .line 566
    invoke-direct {v2, v1, v0}, Lcom/facebook/imagepipeline/producers/b;-><init>(Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 567
    .line 568
    .line 569
    return-object v2

    .line 570
    :pswitch_b
    iget-object v3, p0, Le3/v;->b:Le3/x;

    .line 571
    .line 572
    const-string/jumbo v0, "this$0"

    .line 573
    .line 574
    .line 575
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 576
    .line 577
    .line 578
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 579
    .line 580
    .line 581
    iget-object v0, v3, Le3/x;->c:Lcom/facebook/imagepipeline/producers/NetworkFetcher;

    .line 582
    .line 583
    monitor-enter v3

    .line 584
    :try_start_0
    const-string v4, "networkFetcher"

    .line 585
    .line 586
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 587
    .line 588
    .line 589
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 590
    .line 591
    .line 592
    iget-object v4, v3, Le3/x;->b:Le3/u;

    .line 593
    .line 594
    new-instance v5, Lcom/facebook/imagepipeline/producers/b0;

    .line 595
    .line 596
    iget-object v6, v4, Le3/u;->k:Lcom/facebook/common/memory/PooledByteBufferFactory;

    .line 597
    .line 598
    iget-object v4, v4, Le3/u;->d:Lcom/facebook/common/memory/ByteArrayPool;

    .line 599
    .line 600
    invoke-direct {v5, v6, v4, v0}, Lcom/facebook/imagepipeline/producers/b0;-><init>(Lcom/facebook/common/memory/PooledByteBufferFactory;Lcom/facebook/common/memory/ByteArrayPool;Lcom/facebook/imagepipeline/producers/NetworkFetcher;)V

    .line 601
    .line 602
    .line 603
    const-string v0, "newNetworkFetchProducer(...)"

    .line 604
    .line 605
    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 606
    .line 607
    .line 608
    invoke-virtual {v3, v5}, Le3/x;->j(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/i;

    .line 609
    .line 610
    .line 611
    move-result-object v0

    .line 612
    new-instance v4, Lcom/facebook/imagepipeline/producers/b;

    .line 613
    .line 614
    invoke-direct {v4, v0, v2}, Lcom/facebook/imagepipeline/producers/b;-><init>(Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 615
    .line 616
    .line 617
    const-string v0, "newAddImageTransformMetaDataProducer(...)"

    .line 618
    .line 619
    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 620
    .line 621
    .line 622
    iget-object v0, v3, Le3/x;->b:Le3/u;

    .line 623
    .line 624
    iget-boolean v5, v3, Le3/x;->d:Z

    .line 625
    .line 626
    if-eqz v5, :cond_1

    .line 627
    .line 628
    iget-object v5, v3, Le3/x;->f:Le3/i;

    .line 629
    .line 630
    sget-object v6, Le3/i;->c:Le3/i;

    .line 631
    .line 632
    if-eq v5, v6, :cond_1

    .line 633
    .line 634
    goto :goto_0

    .line 635
    :catchall_0
    move-exception v0

    .line 636
    goto :goto_1

    .line 637
    :cond_1
    move v1, v2

    .line 638
    :goto_0
    iget-object v2, v3, Le3/x;->h:Ln3/c;

    .line 639
    .line 640
    invoke-virtual {v0, v4, v1, v2}, Le3/u;->b(Lcom/facebook/imagepipeline/producers/Producer;ZLn3/c;)Lcom/facebook/imagepipeline/producers/h0;

    .line 641
    .line 642
    .line 643
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 644
    monitor-exit v3

    .line 645
    return-object v0

    .line 646
    :goto_1
    :try_start_1
    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 647
    throw v0

    .line 648
    :pswitch_c
    iget-object v1, p0, Le3/v;->b:Le3/x;

    .line 649
    .line 650
    const-string/jumbo v2, "this$0"

    .line 651
    .line 652
    .line 653
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 654
    .line 655
    .line 656
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 657
    .line 658
    .line 659
    iget-object v2, v1, Le3/x;->b:Le3/u;

    .line 660
    .line 661
    invoke-virtual {v1}, Le3/x;->b()Lcom/facebook/imagepipeline/producers/Producer;

    .line 662
    .line 663
    .line 664
    move-result-object v1

    .line 665
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 666
    .line 667
    .line 668
    new-instance v2, Lcom/facebook/imagepipeline/producers/b;

    .line 669
    .line 670
    invoke-direct {v2, v1, v0}, Lcom/facebook/imagepipeline/producers/b;-><init>(Lcom/facebook/imagepipeline/producers/Producer;I)V

    .line 671
    .line 672
    .line 673
    return-object v2

    .line 674
    :pswitch_d
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 675
    .line 676
    const-string/jumbo v1, "this$0"

    .line 677
    .line 678
    .line 679
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 680
    .line 681
    .line 682
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 683
    .line 684
    .line 685
    iget-object v1, v0, Le3/x;->b:Le3/u;

    .line 686
    .line 687
    iget-object v2, v0, Le3/x;->n:Lxf/t;

    .line 688
    .line 689
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 690
    .line 691
    .line 692
    move-result-object v2

    .line 693
    check-cast v2, Lcom/facebook/imagepipeline/producers/Producer;

    .line 694
    .line 695
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 696
    .line 697
    .line 698
    new-instance v1, Lcom/facebook/imagepipeline/producers/l0;

    .line 699
    .line 700
    iget-object v0, v0, Le3/x;->e:LHe/a;

    .line 701
    .line 702
    invoke-direct {v1, v2, v0}, Lcom/facebook/imagepipeline/producers/l0;-><init>(Lcom/facebook/imagepipeline/producers/Producer;Lcom/facebook/imagepipeline/producers/ThreadHandoffProducerQueue;)V

    .line 703
    .line 704
    .line 705
    return-object v1

    .line 706
    :pswitch_e
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 707
    .line 708
    const-string/jumbo v1, "this$0"

    .line 709
    .line 710
    .line 711
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 712
    .line 713
    .line 714
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 715
    .line 716
    .line 717
    iget-object v1, v0, Le3/x;->n:Lxf/t;

    .line 718
    .line 719
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 720
    .line 721
    .line 722
    move-result-object v1

    .line 723
    check-cast v1, Lcom/facebook/imagepipeline/producers/Producer;

    .line 724
    .line 725
    invoke-virtual {v0, v1}, Le3/x;->h(Lcom/facebook/imagepipeline/producers/Producer;)Lcom/facebook/imagepipeline/producers/Producer;

    .line 726
    .line 727
    .line 728
    move-result-object v0

    .line 729
    return-object v0

    .line 730
    :pswitch_f
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 731
    .line 732
    const-string/jumbo v1, "this$0"

    .line 733
    .line 734
    .line 735
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 736
    .line 737
    .line 738
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 739
    .line 740
    .line 741
    new-instance v1, Lcom/facebook/imagepipeline/producers/b;

    .line 742
    .line 743
    iget-object v0, v0, Le3/x;->q:Lxf/t;

    .line 744
    .line 745
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 746
    .line 747
    .line 748
    move-result-object v0

    .line 749
    const-string v2, "getValue(...)"

    .line 750
    .line 751
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 752
    .line 753
    .line 754
    check-cast v0, Lcom/facebook/imagepipeline/producers/Producer;

    .line 755
    .line 756
    invoke-direct {v1, v0}, Lcom/facebook/imagepipeline/producers/b;-><init>(Lcom/facebook/imagepipeline/producers/Producer;)V

    .line 757
    .line 758
    .line 759
    return-object v1

    .line 760
    :pswitch_10
    iget-object v0, p0, Le3/v;->b:Le3/x;

    .line 761
    .line 762
    const-string/jumbo v1, "this$0"

    .line 763
    .line 764
    .line 765
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 766
    .line 767
    .line 768
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 769
    .line 770
    .line 771
    new-instance v1, Lcom/facebook/imagepipeline/producers/b;

    .line 772
    .line 773
    invoke-virtual {v0}, Le3/x;->b()Lcom/facebook/imagepipeline/producers/Producer;

    .line 774
    .line 775
    .line 776
    move-result-object v0

    .line 777
    invoke-direct {v1, v0}, Lcom/facebook/imagepipeline/producers/b;-><init>(Lcom/facebook/imagepipeline/producers/Producer;)V

    .line 778
    .line 779
    .line 780
    return-object v1

    .line 781
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
