.class public final Le3/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/common/internal/Supplier;


# instance fields
.field public final a:LAb/r;

.field public final b:Lj3/w;

.field public final c:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

.field public final d:Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;

.field public final e:I

.field public final f:Lj2/b;

.field public final g:Lj2/b;

.field public final h:Ljava/util/Map;

.field public final i:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LAb/r;Le3/o;)V
    .locals 6

    .line 1
    const-string v0, "fileCacheFactory"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v1, "config"

    .line 7
    .line 8
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v0, "poolFactory"

    .line 15
    .line 16
    iget-object v1, p2, Le3/o;->s:Lj3/w;

    .line 17
    .line 18
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string v0, "executorSupplier"

    .line 22
    .line 23
    iget-object v2, p2, Le3/o;->j:Le3/d;

    .line 24
    .line 25
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    const-string v0, "imageCacheStatsTracker"

    .line 29
    .line 30
    iget-object v3, p2, Le3/o;->k:Ld3/j;

    .line 31
    .line 32
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    const-string v0, "mainDiskCacheConfig"

    .line 36
    .line 37
    iget-object v4, p2, Le3/o;->o:Lj2/b;

    .line 38
    .line 39
    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    const-string/jumbo v0, "smallImageDiskCacheConfig"

    .line 43
    .line 44
    .line 45
    iget-object v5, p2, Le3/o;->y:Lj2/b;

    .line 46
    .line 47
    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 51
    .line 52
    .line 53
    iput-object p1, p0, Le3/h;->a:LAb/r;

    .line 54
    .line 55
    iput-object v1, p0, Le3/h;->b:Lj3/w;

    .line 56
    .line 57
    iput-object v2, p0, Le3/h;->c:Lcom/facebook/imagepipeline/core/ExecutorSupplier;

    .line 58
    .line 59
    iput-object v3, p0, Le3/h;->d:Lcom/facebook/imagepipeline/cache/ImageCacheStatsTracker;

    .line 60
    .line 61
    iget p1, p2, Le3/o;->q:I

    .line 62
    .line 63
    iput p1, p0, Le3/h;->e:I

    .line 64
    .line 65
    iput-object v4, p0, Le3/h;->f:Lj2/b;

    .line 66
    .line 67
    iput-object v5, p0, Le3/h;->g:Lj2/b;

    .line 68
    .line 69
    const/4 p1, 0x0

    .line 70
    iput-object p1, p0, Le3/h;->h:Ljava/util/Map;

    .line 71
    .line 72
    sget-object p1, Lxf/k;->a:Lxf/k;

    .line 73
    .line 74
    new-instance p2, Le3/e;

    .line 75
    .line 76
    const/4 v0, 0x0

    .line 77
    invoke-direct {p2, p0, v0}, Le3/e;-><init>(Le3/h;I)V

    .line 78
    .line 79
    .line 80
    invoke-static {p1, p2}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    iput-object p1, p0, Le3/h;->i:Ljava/lang/Object;

    .line 85
    .line 86
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Le3/h;->i:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/facebook/imagepipeline/core/DiskCachesStore;

    .line 8
    .line 9
    return-object v0
.end method
