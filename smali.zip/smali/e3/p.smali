.class public final Le3/p;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LQ2/a;

.field public final b:Z

.field public final c:Z

.field public final d:I

.field public final e:I

.field public final f:Ld3/g;

.field public g:Z


# direct methods
.method public constructor <init>(Le3/l;)V
    .locals 1

    .line 1
    const-string v0, "configBuilder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    new-instance p1, LQ2/a;

    .line 10
    .line 11
    const/4 v0, 0x2

    .line 12
    invoke-direct {p1, v0}, LQ2/a;-><init>(I)V

    .line 13
    .line 14
    .line 15
    const-string v0, "of(...)"

    .line 16
    .line 17
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Le3/p;->a:LQ2/a;

    .line 21
    .line 22
    const/4 p1, 0x1

    .line 23
    iput-boolean p1, p0, Le3/p;->b:Z

    .line 24
    .line 25
    iput-boolean p1, p0, Le3/p;->c:Z

    .line 26
    .line 27
    const/16 p1, 0x14

    .line 28
    .line 29
    iput p1, p0, Le3/p;->d:I

    .line 30
    .line 31
    const/16 p1, 0x1e

    .line 32
    .line 33
    iput p1, p0, Le3/p;->e:I

    .line 34
    .line 35
    new-instance p1, Ld3/g;

    .line 36
    .line 37
    const/16 v0, 0xa

    .line 38
    .line 39
    invoke-direct {p1, v0}, Ld3/g;-><init>(I)V

    .line 40
    .line 41
    .line 42
    iput-object p1, p0, Le3/p;->f:Ld3/g;

    .line 43
    .line 44
    return-void
.end method
