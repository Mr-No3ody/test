.class public final La2/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:La2/a;

.field public b:La2/b;
