.class public final La2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/daimajia/swipe/interfaces/SwipeItemMangerInterface;


# instance fields
.field public a:Lb2/a;

.field public b:I

.field public c:Ljava/util/HashSet;

.field public d:Ljava/util/HashSet;

.field public e:LZ1/a;


# virtual methods
.method public final a(ILandroid/view/View;)V
    .locals 3

    .line 1
    iget-object v0, p0, La2/d;->e:LZ1/a;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Lcom/daimajia/swipe/interfaces/SwipeAdapterInterface;->getSwipeLayoutResourceId(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 8
    .line 9
    .line 10
    move-result-object p2

    .line 11
    check-cast p2, Lcom/daimajia/swipe/SwipeLayout;

    .line 12
    .line 13
    if-eqz p2, :cond_2

    .line 14
    .line 15
    invoke-virtual {p2, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    if-nez v1, :cond_1

    .line 20
    .line 21
    new-instance v1, La2/a;

    .line 22
    .line 23
    invoke-direct {v1, p0, p1}, La2/a;-><init>(La2/d;I)V

    .line 24
    .line 25
    .line 26
    new-instance v2, La2/b;

    .line 27
    .line 28
    invoke-direct {v2, p0, p1}, La2/b;-><init>(La2/d;I)V

    .line 29
    .line 30
    .line 31
    iget-object p1, p2, Lcom/daimajia/swipe/SwipeLayout;->i:Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    iget-object p1, p2, Lcom/daimajia/swipe/SwipeLayout;->M:Ljava/util/ArrayList;

    .line 37
    .line 38
    if-nez p1, :cond_0

    .line 39
    .line 40
    new-instance p1, Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 43
    .line 44
    .line 45
    iput-object p1, p2, Lcom/daimajia/swipe/SwipeLayout;->M:Ljava/util/ArrayList;

    .line 46
    .line 47
    :cond_0
    iget-object p1, p2, Lcom/daimajia/swipe/SwipeLayout;->M:Ljava/util/ArrayList;

    .line 48
    .line 49
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    new-instance p1, La2/c;

    .line 53
    .line 54
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 55
    .line 56
    .line 57
    iput-object v2, p1, La2/c;->b:La2/b;

    .line 58
    .line 59
    iput-object v1, p1, La2/c;->a:La2/a;

    .line 60
    .line 61
    invoke-virtual {p2, v0, p1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    iget-object p1, p0, La2/d;->d:Ljava/util/HashSet;

    .line 65
    .line 66
    invoke-virtual {p1, p2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :cond_1
    invoke-virtual {p2, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    check-cast p2, La2/c;

    .line 75
    .line 76
    iget-object v0, p2, La2/c;->b:La2/b;

    .line 77
    .line 78
    iput p1, v0, La2/b;->a:I

    .line 79
    .line 80
    iget-object p2, p2, La2/c;->a:La2/a;

    .line 81
    .line 82
    iput p1, p2, La2/a;->a:I

    .line 83
    .line 84
    return-void

    .line 85
    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 86
    .line 87
    const-string p2, "can not find SwipeLayout in target view"

    .line 88
    .line 89
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    throw p1
.end method

.method public final closeAllExcept(Lcom/daimajia/swipe/SwipeLayout;)V
    .locals 3

    .line 1
    iget-object v0, p0, La2/d;->d:Ljava/util/HashSet;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Lcom/daimajia/swipe/SwipeLayout;

    .line 18
    .line 19
    if-eq v1, p1, :cond_0

    .line 20
    .line 21
    const/4 v2, 0x1

    .line 22
    invoke-virtual {v1, v2, v2}, Lcom/daimajia/swipe/SwipeLayout;->b(ZZ)V

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_1
    return-void
.end method

.method public final closeAllItems()V
    .locals 3

    .line 1
    iget-object v0, p0, La2/d;->a:Lb2/a;

    .line 2
    .line 3
    sget-object v1, Lb2/a;->b:Lb2/a;

    .line 4
    .line 5
    if-ne v0, v1, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, La2/d;->c:Ljava/util/HashSet;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    .line 10
    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/4 v0, -0x1

    .line 14
    iput v0, p0, La2/d;->b:I

    .line 15
    .line 16
    :goto_0
    iget-object v0, p0, La2/d;->d:Ljava/util/HashSet;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Lcom/daimajia/swipe/SwipeLayout;

    .line 33
    .line 34
    const/4 v2, 0x1

    .line 35
    invoke-virtual {v1, v2, v2}, Lcom/daimajia/swipe/SwipeLayout;->b(ZZ)V

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    return-void
.end method

.method public final closeItem(I)V
    .locals 2

    .line 1
    iget-object v0, p0, La2/d;->a:Lb2/a;

    .line 2
    .line 3
    sget-object v1, Lb2/a;->b:Lb2/a;

    .line 4
    .line 5
    if-ne v0, v1, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, La2/d;->c:Ljava/util/HashSet;

    .line 8
    .line 9
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    iget v0, p0, La2/d;->b:I

    .line 18
    .line 19
    if-ne v0, p1, :cond_1

    .line 20
    .line 21
    const/4 p1, -0x1

    .line 22
    iput p1, p0, La2/d;->b:I

    .line 23
    .line 24
    :cond_1
    :goto_0
    iget-object p1, p0, La2/d;->e:LZ1/a;

    .line 25
    .line 26
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public final getMode()Lb2/a;
    .locals 1

    .line 1
    iget-object v0, p0, La2/d;->a:Lb2/a;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getOpenItems()Ljava/util/List;
    .locals 2

    .line 1
    iget-object v0, p0, La2/d;->a:Lb2/a;

    .line 2
    .line 3
    sget-object v1, Lb2/a;->b:Lb2/a;

    .line 4
    .line 5
    if-ne v0, v1, :cond_0

    .line 6
    .line 7
    new-instance v0, Ljava/util/ArrayList;

    .line 8
    .line 9
    iget-object v1, p0, La2/d;->c:Ljava/util/HashSet;

    .line 10
    .line 11
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 12
    .line 13
    .line 14
    return-object v0

    .line 15
    :cond_0
    iget v0, p0, La2/d;->b:I

    .line 16
    .line 17
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    return-object v0
.end method

.method public final getOpenLayouts()Ljava/util/List;
    .locals 2

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    iget-object v1, p0, La2/d;->d:Ljava/util/HashSet;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final isOpen(I)Z
    .locals 2

    .line 1
    iget-object v0, p0, La2/d;->a:Lb2/a;

    .line 2
    .line 3
    sget-object v1, Lb2/a;->b:Lb2/a;

    .line 4
    .line 5
    if-ne v0, v1, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, La2/d;->c:Ljava/util/HashSet;

    .line 8
    .line 9
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    return p1

    .line 18
    :cond_0
    iget v0, p0, La2/d;->b:I

    .line 19
    .line 20
    if-ne v0, p1, :cond_1

    .line 21
    .line 22
    const/4 p1, 0x1

    .line 23
    return p1

    .line 24
    :cond_1
    const/4 p1, 0x0

    .line 25
    return p1
.end method

.method public final openItem(I)V
    .locals 2

    .line 1
    iget-object v0, p0, La2/d;->a:Lb2/a;

    .line 2
    .line 3
    sget-object v1, Lb2/a;->b:Lb2/a;

    .line 4
    .line 5
    if-ne v0, v1, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, La2/d;->c:Ljava/util/HashSet;

    .line 8
    .line 9
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-nez v1, :cond_1

    .line 18
    .line 19
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    iput p1, p0, La2/d;->b:I

    .line 28
    .line 29
    :cond_1
    :goto_0
    iget-object p1, p0, La2/d;->e:LZ1/a;

    .line 30
    .line 31
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final removeShownLayouts(Lcom/daimajia/swipe/SwipeLayout;)V
    .locals 1

    .line 1
    iget-object v0, p0, La2/d;->d:Ljava/util/HashSet;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final setMode(Lb2/a;)V
    .locals 0

    .line 1
    iput-object p1, p0, La2/d;->a:Lb2/a;

    .line 2
    .line 3
    iget-object p1, p0, La2/d;->c:Ljava/util/HashSet;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/util/HashSet;->clear()V

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, La2/d;->d:Ljava/util/HashSet;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/util/HashSet;->clear()V

    .line 11
    .line 12
    .line 13
    const/4 p1, -0x1

    .line 14
    iput p1, p0, La2/d;->b:I

    .line 15
    .line 16
    return-void
.end method
