.class public final La2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/daimajia/swipe/SwipeLayout$OnLayout;


# instance fields
.field public a:I

.field public final synthetic b:La2/d;


# direct methods
.method public constructor <init>(La2/d;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La2/a;->b:La2/d;

    .line 5
    .line 6
    iput p2, p0, La2/a;->a:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onLayout(Lcom/daimajia/swipe/SwipeLayout;)V
    .locals 2

    .line 1
    iget-object v0, p0, La2/a;->b:La2/d;

    .line 2
    .line 3
    iget v1, p0, La2/a;->a:I

    .line 4
    .line 5
    invoke-virtual {v0, v1}, La2/d;->isOpen(I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {p1, v1, v1}, Lcom/daimajia/swipe/SwipeLayout;->i(ZZ)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    invoke-virtual {p1, v1, v1}, Lcom/daimajia/swipe/SwipeLayout;->b(ZZ)V

    .line 17
    .line 18
    .line 19
    return-void
.end method
