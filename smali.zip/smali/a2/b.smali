.class public final La2/b;
.super Lcom/daimajia/swipe/a;
.source "SourceFile"


# instance fields
.field public a:I

.field public final synthetic b:La2/d;


# direct methods
.method public constructor <init>(La2/d;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La2/b;->b:La2/d;

    .line 5
    .line 6
    iput p2, p0, La2/b;->a:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onClose(Lcom/daimajia/swipe/SwipeLayout;)V
    .locals 2

    .line 1
    iget-object p1, p0, La2/b;->b:La2/d;

    .line 2
    .line 3
    iget-object v0, p1, La2/d;->a:Lb2/a;

    .line 4
    .line 5
    sget-object v1, Lb2/a;->b:Lb2/a;

    .line 6
    .line 7
    if-ne v0, v1, :cond_0

    .line 8
    .line 9
    iget-object p1, p1, La2/d;->c:Ljava/util/HashSet;

    .line 10
    .line 11
    iget v0, p0, La2/b;->a:I

    .line 12
    .line 13
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {p1, v0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    const/4 v0, -0x1

    .line 22
    iput v0, p1, La2/d;->b:I

    .line 23
    .line 24
    return-void
.end method

.method public final onOpen(Lcom/daimajia/swipe/SwipeLayout;)V
    .locals 3

    .line 1
    iget-object v0, p0, La2/b;->b:La2/d;

    .line 2
    .line 3
    iget-object v1, v0, La2/d;->a:Lb2/a;

    .line 4
    .line 5
    sget-object v2, Lb2/a;->b:Lb2/a;

    .line 6
    .line 7
    if-ne v1, v2, :cond_0

    .line 8
    .line 9
    iget-object p1, v0, La2/d;->c:Ljava/util/HashSet;

    .line 10
    .line 11
    iget v0, p0, La2/b;->a:I

    .line 12
    .line 13
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {p1, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    invoke-virtual {v0, p1}, La2/d;->closeAllExcept(Lcom/daimajia/swipe/SwipeLayout;)V

    .line 22
    .line 23
    .line 24
    iget p1, p0, La2/b;->a:I

    .line 25
    .line 26
    iput p1, v0, La2/d;->b:I

    .line 27
    .line 28
    return-void
.end method

.method public final onStartOpen(Lcom/daimajia/swipe/SwipeLayout;)V
    .locals 3

    .line 1
    iget-object v0, p0, La2/b;->b:La2/d;

    .line 2
    .line 3
    iget-object v1, v0, La2/d;->a:Lb2/a;

    .line 4
    .line 5
    sget-object v2, Lb2/a;->a:Lb2/a;

    .line 6
    .line 7
    if-ne v1, v2, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0, p1}, La2/d;->closeAllExcept(Lcom/daimajia/swipe/SwipeLayout;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-void
.end method
