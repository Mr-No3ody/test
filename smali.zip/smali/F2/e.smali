.class public final LF2/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/common/internal/Supplier;


# instance fields
.field public final synthetic a:LC2/a;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:I

.field public final synthetic f:LF2/f;


# direct methods
.method public constructor <init>(LF2/f;LC2/a;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LF2/e;->f:LF2/f;

    .line 5
    .line 6
    iput-object p2, p0, LF2/e;->a:LC2/a;

    .line 7
    .line 8
    iput-object p3, p0, LF2/e;->b:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, LF2/e;->c:Ljava/lang/Object;

    .line 11
    .line 12
    iput-object p5, p0, LF2/e;->d:Ljava/lang/Object;

    .line 13
    .line 14
    iput p6, p0, LF2/e;->e:I

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 8

    .line 1
    iget-object v0, p0, LF2/e;->f:LF2/f;

    .line 2
    .line 3
    iget-object v1, p0, LF2/e;->a:LC2/a;

    .line 4
    .line 5
    iget-object v7, p0, LF2/e;->b:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v2, p0, LF2/e;->c:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, p0, LF2/e;->d:Ljava/lang/Object;

    .line 10
    .line 11
    iget v3, p0, LF2/e;->e:I

    .line 12
    .line 13
    check-cast v0, LC2/b;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    check-cast v2, Lcom/facebook/imagepipeline/request/d;

    .line 19
    .line 20
    iget-object v0, v0, LC2/b;->j:Le3/k;

    .line 21
    .line 22
    invoke-static {v3}, Landroidx/camera/camera2/internal/F;->i(I)I

    .line 23
    .line 24
    .line 25
    move-result v5

    .line 26
    if-eqz v5, :cond_5

    .line 27
    .line 28
    const/4 v6, 0x1

    .line 29
    if-eq v5, v6, :cond_4

    .line 30
    .line 31
    const/4 v6, 0x2

    .line 32
    if-ne v5, v6, :cond_0

    .line 33
    .line 34
    sget-object v3, Lcom/facebook/imagepipeline/request/c;->d:Lcom/facebook/imagepipeline/request/c;

    .line 35
    .line 36
    :goto_0
    move-object v5, v3

    .line 37
    goto :goto_2

    .line 38
    :cond_0
    new-instance v0, Ljava/lang/RuntimeException;

    .line 39
    .line 40
    new-instance v1, Ljava/lang/StringBuilder;

    .line 41
    .line 42
    const-string v2, "Cache level"

    .line 43
    .line 44
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    const/4 v2, 0x1

    .line 48
    if-eq v3, v2, :cond_3

    .line 49
    .line 50
    const/4 v2, 0x2

    .line 51
    if-eq v3, v2, :cond_2

    .line 52
    .line 53
    const/4 v2, 0x3

    .line 54
    if-eq v3, v2, :cond_1

    .line 55
    .line 56
    const-string v2, "null"

    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_1
    const-string v2, "BITMAP_MEMORY_CACHE"

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    const-string v2, "DISK_CACHE"

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_3
    const-string v2, "FULL_FETCH"

    .line 66
    .line 67
    :goto_1
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    const-string v2, "is not supported. "

    .line 71
    .line 72
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    throw v0

    .line 83
    :cond_4
    sget-object v3, Lcom/facebook/imagepipeline/request/c;->c:Lcom/facebook/imagepipeline/request/c;

    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_5
    sget-object v3, Lcom/facebook/imagepipeline/request/c;->b:Lcom/facebook/imagepipeline/request/c;

    .line 87
    .line 88
    goto :goto_0

    .line 89
    :goto_2
    const/4 v6, 0x0

    .line 90
    if-eqz v1, :cond_6

    .line 91
    .line 92
    monitor-enter v1

    .line 93
    monitor-exit v1

    .line 94
    :cond_6
    move-object v3, v2

    .line 95
    move-object v2, v0

    .line 96
    invoke-virtual/range {v2 .. v7}, Le3/k;->b(Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;Lcom/facebook/imagepipeline/request/c;Lcom/facebook/imagepipeline/listener/RequestListener;Ljava/lang/String;)Ly2/b;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    invoke-static {p0}, Lo2/e;->m(Ljava/lang/Object;)Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, LF2/e;->c:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const-string v2, "request"

    .line 12
    .line 13
    invoke-virtual {v0, v1, v2}, Landroidx/camera/video/internal/c;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0}, Landroidx/camera/video/internal/c;->toString()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    return-object v0
.end method
