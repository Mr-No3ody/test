.class public final LF2/a;
.super Ly2/c;
.source "SourceFile"


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Z

.field public final synthetic c:LF2/c;


# direct methods
.method public constructor <init>(LF2/c;Ljava/lang/String;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LF2/a;->c:LF2/c;

    .line 5
    .line 6
    iput-object p2, p0, LF2/a;->a:Ljava/lang/String;

    .line 7
    .line 8
    iput-boolean p3, p0, LF2/a;->b:Z

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final onFailureImpl(Lcom/facebook/datasource/DataSource;)V
    .locals 4

    .line 1
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->getFailureCause()Ljava/lang/Throwable;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, LF2/a;->c:LF2/c;

    .line 6
    .line 7
    iget-object v2, p0, LF2/a;->a:Ljava/lang/String;

    .line 8
    .line 9
    const/4 v3, 0x1

    .line 10
    invoke-virtual {v1, v2, p1, v0, v3}, LF2/c;->k(Ljava/lang/String;Lcom/facebook/datasource/DataSource;Ljava/lang/Throwable;Z)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onNewResultImpl(Lcom/facebook/datasource/DataSource;)V
    .locals 8

    .line 1
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->isFinished()Z

    .line 2
    .line 3
    .line 4
    move-result v5

    .line 5
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->hasMultipleResults()Z

    .line 6
    .line 7
    .line 8
    move-result v7

    .line 9
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->getProgress()F

    .line 10
    .line 11
    .line 12
    move-result v4

    .line 13
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->getResult()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    if-eqz v3, :cond_0

    .line 18
    .line 19
    iget-object v1, p0, LF2/a;->a:Ljava/lang/String;

    .line 20
    .line 21
    iget-boolean v6, p0, LF2/a;->b:Z

    .line 22
    .line 23
    iget-object v0, p0, LF2/a;->c:LF2/c;

    .line 24
    .line 25
    move-object v2, p1

    .line 26
    invoke-virtual/range {v0 .. v7}, LF2/c;->l(Ljava/lang/String;Lcom/facebook/datasource/DataSource;Ljava/lang/Object;FZZZ)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_0
    move-object v2, p1

    .line 31
    if-eqz v5, :cond_1

    .line 32
    .line 33
    new-instance p1, Ljava/lang/NullPointerException;

    .line 34
    .line 35
    invoke-direct {p1}, Ljava/lang/NullPointerException;-><init>()V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, LF2/a;->a:Ljava/lang/String;

    .line 39
    .line 40
    const/4 v1, 0x1

    .line 41
    iget-object v3, p0, LF2/a;->c:LF2/c;

    .line 42
    .line 43
    invoke-virtual {v3, v0, v2, p1, v1}, LF2/c;->k(Ljava/lang/String;Lcom/facebook/datasource/DataSource;Ljava/lang/Throwable;Z)V

    .line 44
    .line 45
    .line 46
    :cond_1
    return-void
.end method

.method public final onProgressUpdate(Lcom/facebook/datasource/DataSource;)V
    .locals 4

    .line 1
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->isFinished()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->getProgress()F

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    iget-object v2, p0, LF2/a;->c:LF2/c;

    .line 10
    .line 11
    iget-object v3, p0, LF2/a;->a:Ljava/lang/String;

    .line 12
    .line 13
    invoke-virtual {v2, v3, p1}, LF2/c;->g(Ljava/lang/String;Lcom/facebook/datasource/DataSource;)Z

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    if-nez v3, :cond_0

    .line 18
    .line 19
    const-string v0, "ignore_old_datasource @ onProgress"

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    invoke-virtual {v2, v0, v1}, LF2/c;->h(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 23
    .line 24
    .line 25
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->close()Z

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :cond_0
    if-nez v0, :cond_1

    .line 30
    .line 31
    iget-object p1, v2, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 32
    .line 33
    const/4 v0, 0x0

    .line 34
    invoke-interface {p1, v1, v0}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setProgress(FZ)V

    .line 35
    .line 36
    .line 37
    :cond_1
    return-void
.end method
