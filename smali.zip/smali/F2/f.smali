.class public abstract LF2/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/drawee/interfaces/SimpleDraweeControllerBuilder;


# static fields
.field public static final g:LF2/d;

.field public static final h:Ljava/lang/NullPointerException;

.field public static final i:Ljava/util/concurrent/atomic/AtomicLong;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Lcom/facebook/imagepipeline/request/d;

.field public c:Lcom/facebook/imagepipeline/request/d;

.field public d:Lcom/facebook/drawee/controller/ControllerListener;

.field public e:Z

.field public f:Lcom/facebook/drawee/interfaces/DraweeController;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LF2/d;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LF2/f;->g:LF2/d;

    .line 7
    .line 8
    new-instance v0, Ljava/lang/NullPointerException;

    .line 9
    .line 10
    const-string v1, "No image request was specified!"

    .line 11
    .line 12
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    sput-object v0, LF2/f;->h:Ljava/lang/NullPointerException;

    .line 16
    .line 17
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 18
    .line 19
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    .line 20
    .line 21
    .line 22
    sput-object v0, LF2/f;->i:Ljava/util/concurrent/atomic/AtomicLong;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a()LC2/a;
    .locals 12

    .line 1
    iget-object v0, p0, LF2/f;->b:Lcom/facebook/imagepipeline/request/d;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    iget-object v0, p0, LF2/f;->c:Lcom/facebook/imagepipeline/request/d;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iput-object v0, p0, LF2/f;->b:Lcom/facebook/imagepipeline/request/d;

    .line 11
    .line 12
    iput-object v1, p0, LF2/f;->c:Lcom/facebook/imagepipeline/request/d;

    .line 13
    .line 14
    :cond_0
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 15
    .line 16
    .line 17
    move-object v0, p0

    .line 18
    check-cast v0, LC2/b;

    .line 19
    .line 20
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 21
    .line 22
    .line 23
    :try_start_0
    iget-object v2, v0, LF2/f;->f:Lcom/facebook/drawee/interfaces/DraweeController;

    .line 24
    .line 25
    sget-object v3, LF2/f;->i:Ljava/util/concurrent/atomic/AtomicLong;

    .line 26
    .line 27
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    .line 28
    .line 29
    .line 30
    move-result-wide v3

    .line 31
    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    instance-of v4, v2, LC2/a;

    .line 36
    .line 37
    if-eqz v4, :cond_1

    .line 38
    .line 39
    check-cast v2, LC2/a;

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move-exception v0

    .line 43
    goto/16 :goto_2

    .line 44
    .line 45
    :cond_1
    iget-object v2, v0, LC2/b;->k:Landroidx/appcompat/widget/m1;

    .line 46
    .line 47
    iget-object v4, v2, Landroidx/appcompat/widget/m1;->a:Ljava/lang/Object;

    .line 48
    .line 49
    move-object v6, v4

    .line 50
    check-cast v6, Landroid/content/res/Resources;

    .line 51
    .line 52
    iget-object v4, v2, Landroidx/appcompat/widget/m1;->b:Ljava/lang/Object;

    .line 53
    .line 54
    move-object v7, v4

    .line 55
    check-cast v7, LE2/a;

    .line 56
    .line 57
    iget-object v4, v2, Landroidx/appcompat/widget/m1;->c:Ljava/lang/Object;

    .line 58
    .line 59
    move-object v8, v4

    .line 60
    check-cast v8, Lcom/facebook/imagepipeline/drawable/DrawableFactory;

    .line 61
    .line 62
    iget-object v4, v2, Landroidx/appcompat/widget/m1;->d:Ljava/lang/Object;

    .line 63
    .line 64
    move-object v9, v4

    .line 65
    check-cast v9, Lorg/sufficientlysecure/htmltextview/f;

    .line 66
    .line 67
    iget-object v4, v2, Landroidx/appcompat/widget/m1;->e:Ljava/lang/Object;

    .line 68
    .line 69
    move-object v10, v4

    .line 70
    check-cast v10, Lm2/d;

    .line 71
    .line 72
    iget-object v4, v2, Landroidx/appcompat/widget/m1;->f:Ljava/lang/Object;

    .line 73
    .line 74
    move-object v11, v4

    .line 75
    check-cast v11, Landroidx/work/impl/model/b;

    .line 76
    .line 77
    new-instance v5, LC2/a;

    .line 78
    .line 79
    invoke-direct/range {v5 .. v11}, LC2/a;-><init>(Landroid/content/res/Resources;LE2/a;Lcom/facebook/imagepipeline/drawable/DrawableFactory;Lorg/sufficientlysecure/htmltextview/f;Lm2/d;Landroidx/work/impl/model/b;)V

    .line 80
    .line 81
    .line 82
    iget-object v2, v2, Landroidx/appcompat/widget/m1;->g:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast v2, LQ2/a;

    .line 85
    .line 86
    if-eqz v2, :cond_2

    .line 87
    .line 88
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 89
    .line 90
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 91
    .line 92
    .line 93
    move-result v2

    .line 94
    iput-boolean v2, v5, LC2/a;->y:Z

    .line 95
    .line 96
    :cond_2
    move-object v2, v5

    .line 97
    :goto_0
    invoke-virtual {v0, v2, v3}, LF2/f;->c(LC2/a;Ljava/lang/String;)Lcom/facebook/common/internal/Supplier;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    iget-object v5, v0, LF2/f;->b:Lcom/facebook/imagepipeline/request/d;

    .line 102
    .line 103
    iget-object v6, v0, LC2/b;->j:Le3/k;

    .line 104
    .line 105
    iget-object v6, v6, Le3/k;->h:Lcom/facebook/imagepipeline/cache/CacheKeyFactory;

    .line 106
    .line 107
    if-eqz v6, :cond_4

    .line 108
    .line 109
    if-eqz v5, :cond_4

    .line 110
    .line 111
    invoke-virtual {v5}, Lcom/facebook/imagepipeline/request/d;->getPostprocessor()Lcom/facebook/imagepipeline/request/Postprocessor;

    .line 112
    .line 113
    .line 114
    move-result-object v7

    .line 115
    if-eqz v7, :cond_3

    .line 116
    .line 117
    iget-object v7, v0, LF2/f;->a:Ljava/lang/Object;

    .line 118
    .line 119
    invoke-interface {v6, v5, v7}, Lcom/facebook/imagepipeline/cache/CacheKeyFactory;->getPostprocessedBitmapCacheKey(Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;)Lcom/facebook/cache/common/CacheKey;

    .line 120
    .line 121
    .line 122
    move-result-object v5

    .line 123
    goto :goto_1

    .line 124
    :cond_3
    iget-object v7, v0, LF2/f;->a:Ljava/lang/Object;

    .line 125
    .line 126
    invoke-interface {v6, v5, v7}, Lcom/facebook/imagepipeline/cache/CacheKeyFactory;->getBitmapCacheKey(Lcom/facebook/imagepipeline/request/d;Ljava/lang/Object;)Lcom/facebook/cache/common/CacheKey;

    .line 127
    .line 128
    .line 129
    move-result-object v5

    .line 130
    goto :goto_1

    .line 131
    :cond_4
    move-object v5, v1

    .line 132
    :goto_1
    iget-object v6, v0, LF2/f;->a:Ljava/lang/Object;

    .line 133
    .line 134
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 135
    .line 136
    .line 137
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 138
    .line 139
    .line 140
    invoke-virtual {v2, v6, v3}, LF2/c;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    const/4 v3, 0x0

    .line 144
    iput-boolean v3, v2, LF2/c;->p:Z

    .line 145
    .line 146
    iput-object v4, v2, LC2/a;->x:Lcom/facebook/common/internal/Supplier;

    .line 147
    .line 148
    invoke-virtual {v2, v1}, LC2/a;->p(Lcom/facebook/imagepipeline/image/CloseableImage;)V

    .line 149
    .line 150
    .line 151
    iput-object v5, v2, LC2/a;->w:Lcom/facebook/cache/common/CacheKey;

    .line 152
    .line 153
    invoke-virtual {v2, v1}, LC2/a;->p(Lcom/facebook/imagepipeline/image/CloseableImage;)V

    .line 154
    .line 155
    .line 156
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 157
    .line 158
    .line 159
    monitor-enter v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 160
    :try_start_1
    iget-object v3, v0, LF2/f;->b:Lcom/facebook/imagepipeline/request/d;

    .line 161
    .line 162
    iput-object v3, v2, LC2/a;->z:Lcom/facebook/imagepipeline/request/d;

    .line 163
    .line 164
    iget-object v0, v0, LF2/f;->c:Lcom/facebook/imagepipeline/request/d;

    .line 165
    .line 166
    iput-object v0, v2, LC2/a;->A:Lcom/facebook/imagepipeline/request/d;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 167
    .line 168
    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 169
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 170
    .line 171
    .line 172
    iput-object v1, v2, LF2/c;->m:Ljava/lang/String;

    .line 173
    .line 174
    iget-object v0, p0, LF2/f;->d:Lcom/facebook/drawee/controller/ControllerListener;

    .line 175
    .line 176
    if-eqz v0, :cond_5

    .line 177
    .line 178
    invoke-virtual {v2, v0}, LF2/c;->a(Lcom/facebook/drawee/controller/ControllerListener;)V

    .line 179
    .line 180
    .line 181
    :cond_5
    iget-boolean v0, p0, LF2/f;->e:Z

    .line 182
    .line 183
    if-eqz v0, :cond_6

    .line 184
    .line 185
    sget-object v0, LF2/f;->g:LF2/d;

    .line 186
    .line 187
    invoke-virtual {v2, v0}, LF2/c;->a(Lcom/facebook/drawee/controller/ControllerListener;)V

    .line 188
    .line 189
    .line 190
    :cond_6
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 191
    .line 192
    .line 193
    return-object v2

    .line 194
    :catchall_1
    move-exception v0

    .line 195
    :try_start_3
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 196
    :try_start_4
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 197
    :goto_2
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 198
    .line 199
    .line 200
    throw v0
.end method

.method public final b()V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, LF2/f;->a:Ljava/lang/Object;

    .line 3
    .line 4
    iput-object v0, p0, LF2/f;->b:Lcom/facebook/imagepipeline/request/d;

    .line 5
    .line 6
    iput-object v0, p0, LF2/f;->c:Lcom/facebook/imagepipeline/request/d;

    .line 7
    .line 8
    iput-object v0, p0, LF2/f;->d:Lcom/facebook/drawee/controller/ControllerListener;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    iput-boolean v1, p0, LF2/f;->e:Z

    .line 12
    .line 13
    iput-object v0, p0, LF2/f;->f:Lcom/facebook/drawee/interfaces/DraweeController;

    .line 14
    .line 15
    return-void
.end method

.method public final bridge synthetic build()Lcom/facebook/drawee/interfaces/DraweeController;
    .locals 1

    .line 1
    invoke-virtual {p0}, LF2/f;->a()LC2/a;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final c(LC2/a;Ljava/lang/String;)Lcom/facebook/common/internal/Supplier;
    .locals 12

    .line 1
    iget-object v4, p0, LF2/f;->b:Lcom/facebook/imagepipeline/request/d;

    .line 2
    .line 3
    const/4 v6, 0x1

    .line 4
    if-eqz v4, :cond_0

    .line 5
    .line 6
    iget-object v5, p0, LF2/f;->a:Ljava/lang/Object;

    .line 7
    .line 8
    new-instance v0, LF2/e;

    .line 9
    .line 10
    move-object v1, p0

    .line 11
    move-object v2, p1

    .line 12
    move-object v3, p2

    .line 13
    invoke-direct/range {v0 .. v6}, LF2/e;-><init>(LF2/f;LC2/a;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    move-object v1, p0

    .line 18
    move-object v2, p1

    .line 19
    move-object v3, p2

    .line 20
    const/4 v0, 0x0

    .line 21
    :goto_0
    if-eqz v0, :cond_1

    .line 22
    .line 23
    iget-object p1, v1, LF2/f;->c:Lcom/facebook/imagepipeline/request/d;

    .line 24
    .line 25
    if-eqz p1, :cond_1

    .line 26
    .line 27
    new-instance p1, Ljava/util/ArrayList;

    .line 28
    .line 29
    const/4 p2, 0x2

    .line 30
    invoke-direct {p1, p2}, Ljava/util/ArrayList;-><init>(I)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    iget-object v9, v1, LF2/f;->c:Lcom/facebook/imagepipeline/request/d;

    .line 37
    .line 38
    iget-object v10, v1, LF2/f;->a:Ljava/lang/Object;

    .line 39
    .line 40
    new-instance v5, LF2/e;

    .line 41
    .line 42
    move-object v7, v2

    .line 43
    move-object v8, v3

    .line 44
    move v11, v6

    .line 45
    move-object v6, v1

    .line 46
    invoke-direct/range {v5 .. v11}, LF2/e;-><init>(LF2/f;LC2/a;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    new-instance v0, Ly2/f;

    .line 53
    .line 54
    invoke-direct {v0, p1}, Ly2/f;-><init>(Ljava/util/ArrayList;)V

    .line 55
    .line 56
    .line 57
    :cond_1
    if-nez v0, :cond_2

    .line 58
    .line 59
    new-instance p1, LQ2/a;

    .line 60
    .line 61
    const/4 p2, 0x5

    .line 62
    invoke-direct {p1, p2}, LQ2/a;-><init>(I)V

    .line 63
    .line 64
    .line 65
    return-object p1

    .line 66
    :cond_2
    return-object v0
.end method

.method public final setCallerContext(Ljava/lang/Object;)Lcom/facebook/drawee/interfaces/SimpleDraweeControllerBuilder;
    .locals 0

    .line 1
    iput-object p1, p0, LF2/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    return-object p0
.end method

.method public final setOldController(Lcom/facebook/drawee/interfaces/DraweeController;)Lcom/facebook/drawee/interfaces/SimpleDraweeControllerBuilder;
    .locals 0

    .line 1
    iput-object p1, p0, LF2/f;->f:Lcom/facebook/drawee/interfaces/DraweeController;

    .line 2
    .line 3
    return-object p0
.end method
