.class public abstract LF2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/drawee/interfaces/DraweeController;
.implements Lcom/facebook/drawee/components/DeferredReleaser$Releasable;
.implements Lcom/facebook/drawee/gestures/GestureDetector$ClickListener;


# static fields
.field public static final r:Ljava/util/Map;

.field public static final s:Ljava/util/Map;

.field public static final t:Ljava/lang/Class;


# instance fields
.field public final a:LE2/c;

.field public final b:LE2/a;

.field public final c:Lm2/d;

.field public d:Lcom/facebook/drawee/controller/ControllerListener;

.field public final e:LS2/g;

.field public f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

.field public g:LG2/a;

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/Object;

.field public j:Z

.field public k:Z

.field public l:Z

.field public m:Ljava/lang/String;

.field public n:Lcom/facebook/datasource/DataSource;

.field public o:Ljava/lang/Object;

.field public p:Z

.field public q:Landroid/graphics/drawable/Drawable;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    const-string v0, "component_tag"

    .line 2
    .line 3
    const-string v1, "drawee"

    .line 4
    .line 5
    invoke-static {v0, v1}, Lo2/d;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, LF2/c;->r:Ljava/util/Map;

    .line 10
    .line 11
    const-string v0, "origin"

    .line 12
    .line 13
    const-string v1, "memory_bitmap"

    .line 14
    .line 15
    const-string v2, "origin_sub"

    .line 16
    .line 17
    const-string/jumbo v3, "shortcut"

    .line 18
    .line 19
    .line 20
    invoke-static {v0, v1, v2, v3}, Lo2/d;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    sput-object v0, LF2/c;->s:Ljava/util/Map;

    .line 25
    .line 26
    const-class v0, LF2/c;

    .line 27
    .line 28
    sput-object v0, LF2/c;->t:Ljava/lang/Class;

    .line 29
    .line 30
    return-void
.end method

.method public constructor <init>(LE2/a;Lm2/d;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-boolean v0, LE2/c;->c:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    new-instance v0, LE2/c;

    .line 9
    .line 10
    invoke-direct {v0}, LE2/c;-><init>()V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    sget-object v0, LE2/c;->b:LE2/c;

    .line 15
    .line 16
    :goto_0
    iput-object v0, p0, LF2/c;->a:LE2/c;

    .line 17
    .line 18
    new-instance v0, LS2/g;

    .line 19
    .line 20
    invoke-direct {v0}, LS2/g;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, LF2/c;->e:LS2/g;

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    iput-boolean v0, p0, LF2/c;->p:Z

    .line 27
    .line 28
    iput-object p1, p0, LF2/c;->b:LE2/a;

    .line 29
    .line 30
    iput-object p2, p0, LF2/c;->c:Lm2/d;

    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    invoke-virtual {p0, p1, p1}, LF2/c;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method


# virtual methods
.method public final a(Lcom/facebook/drawee/controller/ControllerListener;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LF2/c;->d:Lcom/facebook/drawee/controller/ControllerListener;

    .line 5
    .line 6
    instance-of v1, v0, LF2/b;

    .line 7
    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    check-cast v0, LF2/b;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, LF2/h;->a(Lcom/facebook/drawee/controller/ControllerListener;)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    if-eqz v0, :cond_1

    .line 17
    .line 18
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 19
    .line 20
    .line 21
    new-instance v1, LF2/b;

    .line 22
    .line 23
    invoke-direct {v1}, LF2/h;-><init>()V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v1, v0}, LF2/h;->a(Lcom/facebook/drawee/controller/ControllerListener;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, p1}, LF2/h;->a(Lcom/facebook/drawee/controller/ControllerListener;)V

    .line 30
    .line 31
    .line 32
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 33
    .line 34
    .line 35
    iput-object v1, p0, LF2/c;->d:Lcom/facebook/drawee/controller/ControllerListener;

    .line 36
    .line 37
    return-void

    .line 38
    :cond_1
    iput-object p1, p0, LF2/c;->d:Lcom/facebook/drawee/controller/ControllerListener;

    .line 39
    .line 40
    return-void
.end method

.method public abstract b(Ljava/lang/Object;)Landroid/graphics/drawable/Drawable;
.end method

.method public final c()Lcom/facebook/drawee/controller/ControllerListener;
    .locals 1

    .line 1
    iget-object v0, p0, LF2/c;->d:Lcom/facebook/drawee/controller/ControllerListener;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    sget-object v0, LF2/g;->a:LF2/g;

    .line 6
    .line 7
    :cond_0
    return-object v0
.end method

.method public abstract d(Ljava/lang/Object;)Lcom/facebook/imagepipeline/image/ImageInfo;
.end method

.method public final e()Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;
    .locals 3

    .line 1
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 7
    .line 8
    new-instance v1, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    const-string v2, "mSettableDraweeHierarchy is null; Caller context: "

    .line 11
    .line 12
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v2, p0, LF2/c;->i:Ljava/lang/Object;

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    throw v0
.end method

.method public final declared-synchronized f(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, LF2/c;->a:LE2/c;

    .line 6
    .line 7
    sget-object v1, LE2/b;->f:LE2/b;

    .line 8
    .line 9
    invoke-virtual {v0, v1}, LE2/c;->a(LE2/b;)V

    .line 10
    .line 11
    .line 12
    iget-boolean v0, p0, LF2/c;->p:Z

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    iget-object v0, p0, LF2/c;->b:LE2/a;

    .line 17
    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-virtual {v0, p0}, LE2/a;->a(LF2/c;)V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :catchall_0
    move-exception p1

    .line 25
    goto :goto_2

    .line 26
    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 27
    iput-boolean v0, p0, LF2/c;->j:Z

    .line 28
    .line 29
    invoke-virtual {p0}, LF2/c;->m()V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, LF2/c;->d:Lcom/facebook/drawee/controller/ControllerListener;

    .line 33
    .line 34
    instance-of v1, v0, LF2/b;

    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    if-eqz v1, :cond_1

    .line 38
    .line 39
    check-cast v0, LF2/b;

    .line 40
    .line 41
    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 42
    :try_start_1
    iget-object v1, v0, LF2/h;->a:Ljava/util/ArrayList;

    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 45
    .line 46
    .line 47
    :try_start_2
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 48
    goto :goto_1

    .line 49
    :catchall_1
    move-exception p1

    .line 50
    :try_start_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 51
    :try_start_4
    throw p1

    .line 52
    :cond_1
    iput-object v2, p0, LF2/c;->d:Lcom/facebook/drawee/controller/ControllerListener;

    .line 53
    .line 54
    :goto_1
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 55
    .line 56
    if-eqz v0, :cond_2

    .line 57
    .line 58
    invoke-interface {v0}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->reset()V

    .line 59
    .line 60
    .line 61
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 62
    .line 63
    invoke-interface {v0, v2}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setControllerOverlay(Landroid/graphics/drawable/Drawable;)V

    .line 64
    .line 65
    .line 66
    iput-object v2, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 67
    .line 68
    :cond_2
    iput-object v2, p0, LF2/c;->g:LG2/a;

    .line 69
    .line 70
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 71
    .line 72
    const/4 v1, 0x2

    .line 73
    invoke-virtual {v0, v1}, Lp2/b;->isLoggable(I)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-eqz v0, :cond_3

    .line 78
    .line 79
    sget-object v0, LF2/c;->t:Ljava/lang/Class;

    .line 80
    .line 81
    const-string v1, "controller %x %s -> %s: initialize"

    .line 82
    .line 83
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 84
    .line 85
    .line 86
    move-result v2

    .line 87
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    iget-object v3, p0, LF2/c;->h:Ljava/lang/String;

    .line 92
    .line 93
    invoke-static {v0, v1, v2, v3, p2}, Lp2/a;->q(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    :cond_3
    iput-object p2, p0, LF2/c;->h:Ljava/lang/String;

    .line 97
    .line 98
    iput-object p1, p0, LF2/c;->i:Ljava/lang/Object;

    .line 99
    .line 100
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 101
    .line 102
    .line 103
    monitor-exit p0

    .line 104
    return-void

    .line 105
    :goto_2
    :try_start_5
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 106
    throw p1
.end method

.method public final g(Ljava/lang/String;Lcom/facebook/datasource/DataSource;)Z
    .locals 1

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    iget-object v0, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iget-object v0, p0, LF2/c;->h:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    if-eqz p1, :cond_1

    .line 15
    .line 16
    iget-object p1, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 17
    .line 18
    if-ne p2, p1, :cond_1

    .line 19
    .line 20
    iget-boolean p1, p0, LF2/c;->k:Z

    .line 21
    .line 22
    if-eqz p1, :cond_1

    .line 23
    .line 24
    :goto_0
    const/4 p1, 0x1

    .line 25
    return p1

    .line 26
    :cond_1
    const/4 p1, 0x0

    .line 27
    return p1
.end method

.method public final getAnimatable()Landroid/graphics/drawable/Animatable;
    .locals 2

    .line 1
    iget-object v0, p0, LF2/c;->q:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    instance-of v1, v0, Landroid/graphics/drawable/Animatable;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    check-cast v0, Landroid/graphics/drawable/Animatable;

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    return-object v0
.end method

.method public final getContentDescription()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, LF2/c;->m:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getHierarchy()Lcom/facebook/drawee/interfaces/DraweeHierarchy;
    .locals 1

    .line 1
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 2
    .line 3
    return-object v0
.end method

.method public final h(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 4

    .line 1
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-virtual {v0, v1}, Lp2/b;->isLoggable(I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v2, p0, LF2/c;->h:Ljava/lang/String;

    .line 19
    .line 20
    sget-object v3, Lp2/a;->a:Lp2/b;

    .line 21
    .line 22
    invoke-virtual {v3, v1}, Lp2/b;->isLoggable(I)Z

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    if-eqz v3, :cond_0

    .line 27
    .line 28
    sget-object v3, LF2/c;->t:Ljava/lang/Class;

    .line 29
    .line 30
    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    filled-new-array {v0, v2, p1, p2}, [Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    const/4 p2, 0x0

    .line 39
    const-string v0, "controller %x %s: %s: failure: %s"

    .line 40
    .line 41
    invoke-static {p2, v0, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-static {v1, v3, p1}, Lp2/b;->a(ILjava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    :cond_0
    return-void
.end method

.method public final i(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 5

    .line 1
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-virtual {v0, v1}, Lp2/b;->isLoggable(I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_2

    .line 9
    .line 10
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v2, p0, LF2/c;->h:Ljava/lang/String;

    .line 19
    .line 20
    if-eqz p1, :cond_0

    .line 21
    .line 22
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    const-string v3, "<null>"

    .line 32
    .line 33
    :goto_0
    check-cast p1, Lcom/facebook/common/references/CloseableReference;

    .line 34
    .line 35
    if-eqz p1, :cond_1

    .line 36
    .line 37
    invoke-virtual {p1}, Lcom/facebook/common/references/CloseableReference;->g()Z

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    if-eqz v4, :cond_1

    .line 42
    .line 43
    iget-object p1, p1, Lcom/facebook/common/references/CloseableReference;->b:Ls2/a;

    .line 44
    .line 45
    invoke-virtual {p1}, Ls2/a;->a()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-static {p1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    goto :goto_1

    .line 54
    :cond_1
    const/4 p1, 0x0

    .line 55
    :goto_1
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    filled-new-array {v0, v2, p2, v3, p1}, [Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    sget-object p2, Lp2/a;->a:Lp2/b;

    .line 64
    .line 65
    invoke-virtual {p2, v1}, Lp2/b;->isLoggable(I)Z

    .line 66
    .line 67
    .line 68
    move-result p2

    .line 69
    if-eqz p2, :cond_2

    .line 70
    .line 71
    sget-object p2, LF2/c;->t:Ljava/lang/Class;

    .line 72
    .line 73
    invoke-virtual {p2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object p2

    .line 77
    const/4 v0, 0x0

    .line 78
    const-string v2, "controller %x %s: %s: image: %s %x"

    .line 79
    .line 80
    invoke-static {v0, v2, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    invoke-static {v1, p2, p1}, Lp2/b;->a(ILjava/lang/String;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    :cond_2
    return-void
.end method

.method public final j(Ljava/util/Map;Ljava/util/Map;)LS2/d;
    .locals 5

    .line 1
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 2
    .line 3
    instance-of v1, v0, LI2/a;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_2

    .line 7
    .line 8
    check-cast v0, LI2/a;

    .line 9
    .line 10
    const/4 v1, 0x2

    .line 11
    invoke-virtual {v0, v1}, LI2/a;->e(I)Lcom/facebook/drawee/drawable/DrawableParent;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    instance-of v3, v3, Lcom/facebook/drawee/drawable/m;

    .line 16
    .line 17
    if-nez v3, :cond_0

    .line 18
    .line 19
    move-object v3, v2

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    invoke-virtual {v0, v1}, LI2/a;->f(I)Lcom/facebook/drawee/drawable/m;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    iget-object v3, v3, Lcom/facebook/drawee/drawable/m;->a:Lcom/facebook/drawee/drawable/ScalingUtils$ScaleType;

    .line 26
    .line 27
    :goto_0
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1}, LI2/a;->e(I)Lcom/facebook/drawee/drawable/DrawableParent;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    instance-of v3, v3, Lcom/facebook/drawee/drawable/m;

    .line 35
    .line 36
    if-nez v3, :cond_1

    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    invoke-virtual {v0, v1}, LI2/a;->f(I)Lcom/facebook/drawee/drawable/m;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    :cond_2
    :goto_1
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 47
    .line 48
    if-nez v0, :cond_3

    .line 49
    .line 50
    goto :goto_2

    .line 51
    :cond_3
    invoke-interface {v0}, Lcom/facebook/drawee/interfaces/DraweeHierarchy;->getBounds()Landroid/graphics/Rect;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    :goto_2
    iget-object v0, p0, LF2/c;->i:Ljava/lang/Object;

    .line 56
    .line 57
    sget-object v1, LF2/c;->r:Ljava/util/Map;

    .line 58
    .line 59
    const-string v3, "componentAttribution"

    .line 60
    .line 61
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    sget-object v3, LF2/c;->s:Ljava/util/Map;

    .line 65
    .line 66
    const-string/jumbo v4, "shortcutAttribution"

    .line 67
    .line 68
    .line 69
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    new-instance v4, LS2/d;

    .line 73
    .line 74
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 75
    .line 76
    .line 77
    if-eqz v2, :cond_4

    .line 78
    .line 79
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    .line 80
    .line 81
    .line 82
    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    .line 83
    .line 84
    .line 85
    :cond_4
    iput-object v0, v4, LS2/d;->e:Ljava/lang/Object;

    .line 86
    .line 87
    iput-object p1, v4, LS2/d;->c:Ljava/util/Map;

    .line 88
    .line 89
    iput-object p2, v4, LS2/d;->d:Ljava/util/Map;

    .line 90
    .line 91
    iput-object v3, v4, LS2/d;->b:Ljava/util/Map;

    .line 92
    .line 93
    iput-object v1, v4, LS2/d;->a:Ljava/util/Map;

    .line 94
    .line 95
    return-object v4
.end method

.method public final k(Ljava/lang/String;Lcom/facebook/datasource/DataSource;Ljava/lang/Throwable;Z)V
    .locals 1

    .line 1
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, LF2/c;->g(Ljava/lang/String;Lcom/facebook/datasource/DataSource;)Z

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    if-nez p1, :cond_0

    .line 9
    .line 10
    const-string p1, "ignore_old_datasource @ onFailure"

    .line 11
    .line 12
    invoke-virtual {p0, p1, p3}, LF2/c;->h(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 13
    .line 14
    .line 15
    invoke-interface {p2}, Lcom/facebook/datasource/DataSource;->close()Z

    .line 16
    .line 17
    .line 18
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    if-eqz p4, :cond_1

    .line 23
    .line 24
    sget-object p1, LE2/b;->v:LE2/b;

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_1
    sget-object p1, LE2/b;->w:LE2/b;

    .line 28
    .line 29
    :goto_0
    iget-object v0, p0, LF2/c;->a:LE2/c;

    .line 30
    .line 31
    invoke-virtual {v0, p1}, LE2/c;->a(LE2/b;)V

    .line 32
    .line 33
    .line 34
    iget-object p1, p0, LF2/c;->e:LS2/g;

    .line 35
    .line 36
    if-eqz p4, :cond_4

    .line 37
    .line 38
    const-string p4, "final_failed @ onFailure"

    .line 39
    .line 40
    invoke-virtual {p0, p4, p3}, LF2/c;->h(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 41
    .line 42
    .line 43
    const/4 p4, 0x0

    .line 44
    iput-object p4, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 45
    .line 46
    const/4 v0, 0x1

    .line 47
    iput-boolean v0, p0, LF2/c;->l:Z

    .line 48
    .line 49
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 50
    .line 51
    if-eqz v0, :cond_2

    .line 52
    .line 53
    invoke-interface {v0, p3}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setFailure(Ljava/lang/Throwable;)V

    .line 54
    .line 55
    .line 56
    :cond_2
    if-nez p2, :cond_3

    .line 57
    .line 58
    move-object p2, p4

    .line 59
    goto :goto_1

    .line 60
    :cond_3
    invoke-interface {p2}, Lcom/facebook/datasource/DataSource;->getExtras()Ljava/util/Map;

    .line 61
    .line 62
    .line 63
    move-result-object p2

    .line 64
    :goto_1
    invoke-virtual {p0, p2, p4}, LF2/c;->j(Ljava/util/Map;Ljava/util/Map;)LS2/d;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    invoke-virtual {p0}, LF2/c;->c()Lcom/facebook/drawee/controller/ControllerListener;

    .line 69
    .line 70
    .line 71
    move-result-object p4

    .line 72
    iget-object v0, p0, LF2/c;->h:Ljava/lang/String;

    .line 73
    .line 74
    invoke-interface {p4, v0, p3}, Lcom/facebook/drawee/controller/ControllerListener;->onFailure(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 75
    .line 76
    .line 77
    iget-object p4, p0, LF2/c;->h:Ljava/lang/String;

    .line 78
    .line 79
    invoke-virtual {p1, p4, p3, p2}, LS2/g;->onFailure(Ljava/lang/String;Ljava/lang/Throwable;LS2/d;)V

    .line 80
    .line 81
    .line 82
    goto :goto_2

    .line 83
    :cond_4
    const-string p2, "intermediate_failed @ onFailure"

    .line 84
    .line 85
    invoke-virtual {p0, p2, p3}, LF2/c;->h(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p0}, LF2/c;->c()Lcom/facebook/drawee/controller/ControllerListener;

    .line 89
    .line 90
    .line 91
    move-result-object p2

    .line 92
    iget-object p4, p0, LF2/c;->h:Ljava/lang/String;

    .line 93
    .line 94
    invoke-interface {p2, p4, p3}, Lcom/facebook/drawee/controller/ControllerListener;->onIntermediateImageFailed(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 95
    .line 96
    .line 97
    iget-object p2, p0, LF2/c;->h:Ljava/lang/String;

    .line 98
    .line 99
    invoke-virtual {p1, p2}, LS2/g;->onIntermediateImageFailed(Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    :goto_2
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 103
    .line 104
    .line 105
    return-void
.end method

.method public final l(Ljava/lang/String;Lcom/facebook/datasource/DataSource;Ljava/lang/Object;FZZZ)V
    .locals 6

    .line 1
    :try_start_0
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1, p2}, LF2/c;->g(Ljava/lang/String;Lcom/facebook/datasource/DataSource;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    const-string p1, "ignore_old_datasource @ onNewResult"

    .line 11
    .line 12
    invoke-virtual {p0, p3, p1}, LF2/c;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    check-cast p3, Lcom/facebook/common/references/CloseableReference;

    .line 16
    .line 17
    invoke-static {p3}, Lcom/facebook/common/references/CloseableReference;->d(Lcom/facebook/common/references/CloseableReference;)V

    .line 18
    .line 19
    .line 20
    invoke-interface {p2}, Lcom/facebook/datasource/DataSource;->close()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    .line 22
    .line 23
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :catchall_0
    move-exception p1

    .line 28
    goto/16 :goto_7

    .line 29
    .line 30
    :cond_0
    :try_start_1
    iget-object v0, p0, LF2/c;->a:LE2/c;

    .line 31
    .line 32
    if-eqz p5, :cond_1

    .line 33
    .line 34
    sget-object v1, LE2/b;->p:LE2/b;

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    sget-object v1, LE2/b;->t:LE2/b;

    .line 38
    .line 39
    :goto_0
    invoke-virtual {v0, v1}, LE2/c;->a(LE2/b;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 40
    .line 41
    .line 42
    :try_start_2
    invoke-virtual {p0, p3}, LF2/c;->b(Ljava/lang/Object;)Landroid/graphics/drawable/Drawable;

    .line 43
    .line 44
    .line 45
    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 46
    :try_start_3
    iget-object v1, p0, LF2/c;->o:Ljava/lang/Object;

    .line 47
    .line 48
    iget-object v2, p0, LF2/c;->q:Landroid/graphics/drawable/Drawable;

    .line 49
    .line 50
    iput-object p3, p0, LF2/c;->o:Ljava/lang/Object;

    .line 51
    .line 52
    iput-object v0, p0, LF2/c;->q:Landroid/graphics/drawable/Drawable;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 53
    .line 54
    const/4 v3, 0x0

    .line 55
    const-string v4, "release_previous_result @ onNewResult"

    .line 56
    .line 57
    const/high16 v5, 0x3f800000    # 1.0f

    .line 58
    .line 59
    if-eqz p5, :cond_4

    .line 60
    .line 61
    :try_start_4
    const-string/jumbo p4, "set_final_result @ onNewResult"

    .line 62
    .line 63
    .line 64
    invoke-virtual {p0, p3, p4}, LF2/c;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    iput-object v3, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 68
    .line 69
    invoke-virtual {p0}, LF2/c;->e()Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 70
    .line 71
    .line 72
    move-result-object p4

    .line 73
    invoke-interface {p4, v0, v5, p6}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setImage(Landroid/graphics/drawable/Drawable;FZ)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p0, p3}, LF2/c;->d(Ljava/lang/Object;)Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 77
    .line 78
    .line 79
    move-result-object p4

    .line 80
    invoke-virtual {p0}, LF2/c;->c()Lcom/facebook/drawee/controller/ControllerListener;

    .line 81
    .line 82
    .line 83
    move-result-object p5

    .line 84
    invoke-virtual {p0}, LF2/c;->getAnimatable()Landroid/graphics/drawable/Animatable;

    .line 85
    .line 86
    .line 87
    move-result-object p6

    .line 88
    invoke-interface {p5, p1, p4, p6}, Lcom/facebook/drawee/controller/ControllerListener;->onFinalImageSet(Ljava/lang/String;Ljava/lang/Object;Landroid/graphics/drawable/Animatable;)V

    .line 89
    .line 90
    .line 91
    move-object p5, p4

    .line 92
    check-cast p5, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 93
    .line 94
    if-nez p2, :cond_2

    .line 95
    .line 96
    move-object p2, v3

    .line 97
    goto :goto_1

    .line 98
    :cond_2
    invoke-interface {p2}, Lcom/facebook/datasource/DataSource;->getExtras()Ljava/util/Map;

    .line 99
    .line 100
    .line 101
    move-result-object p2

    .line 102
    :goto_1
    check-cast p5, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 103
    .line 104
    check-cast p5, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 105
    .line 106
    if-nez p5, :cond_3

    .line 107
    .line 108
    goto :goto_2

    .line 109
    :cond_3
    invoke-interface {p5}, Lcom/facebook/imagepipeline/image/HasImageMetadata;->getExtras()Ljava/util/Map;

    .line 110
    .line 111
    .line 112
    move-result-object v3

    .line 113
    :goto_2
    invoke-virtual {p0, p2, v3}, LF2/c;->j(Ljava/util/Map;Ljava/util/Map;)LS2/d;

    .line 114
    .line 115
    .line 116
    move-result-object p2

    .line 117
    iget-object p5, p0, LF2/c;->e:LS2/g;

    .line 118
    .line 119
    invoke-virtual {p5, p1, p4, p2}, LS2/g;->onFinalImageSet(Ljava/lang/String;Ljava/lang/Object;LS2/d;)V

    .line 120
    .line 121
    .line 122
    goto :goto_5

    .line 123
    :catchall_1
    move-exception p1

    .line 124
    goto/16 :goto_6

    .line 125
    .line 126
    :cond_4
    if-eqz p7, :cond_7

    .line 127
    .line 128
    const-string/jumbo p4, "set_temporary_result @ onNewResult"

    .line 129
    .line 130
    .line 131
    invoke-virtual {p0, p3, p4}, LF2/c;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {p0}, LF2/c;->e()Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 135
    .line 136
    .line 137
    move-result-object p4

    .line 138
    invoke-interface {p4, v0, v5, p6}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setImage(Landroid/graphics/drawable/Drawable;FZ)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {p0, p3}, LF2/c;->d(Ljava/lang/Object;)Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 142
    .line 143
    .line 144
    move-result-object p4

    .line 145
    invoke-virtual {p0}, LF2/c;->c()Lcom/facebook/drawee/controller/ControllerListener;

    .line 146
    .line 147
    .line 148
    move-result-object p5

    .line 149
    invoke-virtual {p0}, LF2/c;->getAnimatable()Landroid/graphics/drawable/Animatable;

    .line 150
    .line 151
    .line 152
    move-result-object p6

    .line 153
    invoke-interface {p5, p1, p4, p6}, Lcom/facebook/drawee/controller/ControllerListener;->onFinalImageSet(Ljava/lang/String;Ljava/lang/Object;Landroid/graphics/drawable/Animatable;)V

    .line 154
    .line 155
    .line 156
    move-object p5, p4

    .line 157
    check-cast p5, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 158
    .line 159
    if-nez p2, :cond_5

    .line 160
    .line 161
    move-object p2, v3

    .line 162
    goto :goto_3

    .line 163
    :cond_5
    invoke-interface {p2}, Lcom/facebook/datasource/DataSource;->getExtras()Ljava/util/Map;

    .line 164
    .line 165
    .line 166
    move-result-object p2

    .line 167
    :goto_3
    check-cast p5, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 168
    .line 169
    check-cast p5, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 170
    .line 171
    if-nez p5, :cond_6

    .line 172
    .line 173
    goto :goto_4

    .line 174
    :cond_6
    invoke-interface {p5}, Lcom/facebook/imagepipeline/image/HasImageMetadata;->getExtras()Ljava/util/Map;

    .line 175
    .line 176
    .line 177
    move-result-object v3

    .line 178
    :goto_4
    invoke-virtual {p0, p2, v3}, LF2/c;->j(Ljava/util/Map;Ljava/util/Map;)LS2/d;

    .line 179
    .line 180
    .line 181
    move-result-object p2

    .line 182
    iget-object p5, p0, LF2/c;->e:LS2/g;

    .line 183
    .line 184
    invoke-virtual {p5, p1, p4, p2}, LS2/g;->onFinalImageSet(Ljava/lang/String;Ljava/lang/Object;LS2/d;)V

    .line 185
    .line 186
    .line 187
    goto :goto_5

    .line 188
    :cond_7
    const-string/jumbo p2, "set_intermediate_result @ onNewResult"

    .line 189
    .line 190
    .line 191
    invoke-virtual {p0, p3, p2}, LF2/c;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {p0}, LF2/c;->e()Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 195
    .line 196
    .line 197
    move-result-object p2

    .line 198
    invoke-interface {p2, v0, p4, p6}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setImage(Landroid/graphics/drawable/Drawable;FZ)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {p0, p3}, LF2/c;->d(Ljava/lang/Object;)Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 202
    .line 203
    .line 204
    move-result-object p2

    .line 205
    invoke-virtual {p0}, LF2/c;->c()Lcom/facebook/drawee/controller/ControllerListener;

    .line 206
    .line 207
    .line 208
    move-result-object p4

    .line 209
    invoke-interface {p4, p1, p2}, Lcom/facebook/drawee/controller/ControllerListener;->onIntermediateImageSet(Ljava/lang/String;Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    iget-object p4, p0, LF2/c;->e:LS2/g;

    .line 213
    .line 214
    invoke-virtual {p4, p1, p2}, LS2/g;->onIntermediateImageSet(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 215
    .line 216
    .line 217
    :goto_5
    if-eqz v2, :cond_8

    .line 218
    .line 219
    if-eq v2, v0, :cond_8

    .line 220
    .line 221
    :try_start_5
    instance-of p1, v2, Lcom/facebook/drawable/base/DrawableWithCaches;

    .line 222
    .line 223
    if-eqz p1, :cond_8

    .line 224
    .line 225
    check-cast v2, Lcom/facebook/drawable/base/DrawableWithCaches;

    .line 226
    .line 227
    invoke-interface {v2}, Lcom/facebook/drawable/base/DrawableWithCaches;->dropCaches()V

    .line 228
    .line 229
    .line 230
    :cond_8
    if-eqz v1, :cond_9

    .line 231
    .line 232
    if-eq v1, p3, :cond_9

    .line 233
    .line 234
    invoke-virtual {p0, v1, v4}, LF2/c;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 235
    .line 236
    .line 237
    check-cast v1, Lcom/facebook/common/references/CloseableReference;

    .line 238
    .line 239
    invoke-static {v1}, Lcom/facebook/common/references/CloseableReference;->d(Lcom/facebook/common/references/CloseableReference;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 240
    .line 241
    .line 242
    :cond_9
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 243
    .line 244
    .line 245
    return-void

    .line 246
    :goto_6
    if-eqz v2, :cond_a

    .line 247
    .line 248
    if-eq v2, v0, :cond_a

    .line 249
    .line 250
    :try_start_6
    instance-of p2, v2, Lcom/facebook/drawable/base/DrawableWithCaches;

    .line 251
    .line 252
    if-eqz p2, :cond_a

    .line 253
    .line 254
    check-cast v2, Lcom/facebook/drawable/base/DrawableWithCaches;

    .line 255
    .line 256
    invoke-interface {v2}, Lcom/facebook/drawable/base/DrawableWithCaches;->dropCaches()V

    .line 257
    .line 258
    .line 259
    :cond_a
    if-eqz v1, :cond_b

    .line 260
    .line 261
    if-eq v1, p3, :cond_b

    .line 262
    .line 263
    invoke-virtual {p0, v1, v4}, LF2/c;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    check-cast v1, Lcom/facebook/common/references/CloseableReference;

    .line 267
    .line 268
    invoke-static {v1}, Lcom/facebook/common/references/CloseableReference;->d(Lcom/facebook/common/references/CloseableReference;)V

    .line 269
    .line 270
    .line 271
    :cond_b
    throw p1

    .line 272
    :catch_0
    move-exception p4

    .line 273
    const-string p6, "drawable_failed @ onNewResult"

    .line 274
    .line 275
    invoke-virtual {p0, p3, p6}, LF2/c;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 276
    .line 277
    .line 278
    check-cast p3, Lcom/facebook/common/references/CloseableReference;

    .line 279
    .line 280
    invoke-static {p3}, Lcom/facebook/common/references/CloseableReference;->d(Lcom/facebook/common/references/CloseableReference;)V

    .line 281
    .line 282
    .line 283
    invoke-virtual {p0, p1, p2, p4, p5}, LF2/c;->k(Ljava/lang/String;Lcom/facebook/datasource/DataSource;Ljava/lang/Throwable;Z)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 284
    .line 285
    .line 286
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 287
    .line 288
    .line 289
    return-void

    .line 290
    :goto_7
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 291
    .line 292
    .line 293
    throw p1
.end method

.method public final m()V
    .locals 6

    .line 1
    iget-boolean v0, p0, LF2/c;->k:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iput-boolean v1, p0, LF2/c;->k:Z

    .line 5
    .line 6
    iput-boolean v1, p0, LF2/c;->l:Z

    .line 7
    .line 8
    iget-object v1, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-interface {v1}, Lcom/facebook/datasource/DataSource;->getExtras()Ljava/util/Map;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    iget-object v3, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 18
    .line 19
    invoke-interface {v3}, Lcom/facebook/datasource/DataSource;->close()Z

    .line 20
    .line 21
    .line 22
    iput-object v2, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    move-object v1, v2

    .line 26
    :goto_0
    iget-object v3, p0, LF2/c;->q:Landroid/graphics/drawable/Drawable;

    .line 27
    .line 28
    if-eqz v3, :cond_1

    .line 29
    .line 30
    instance-of v4, v3, Lcom/facebook/drawable/base/DrawableWithCaches;

    .line 31
    .line 32
    if-eqz v4, :cond_1

    .line 33
    .line 34
    check-cast v3, Lcom/facebook/drawable/base/DrawableWithCaches;

    .line 35
    .line 36
    invoke-interface {v3}, Lcom/facebook/drawable/base/DrawableWithCaches;->dropCaches()V

    .line 37
    .line 38
    .line 39
    :cond_1
    iget-object v3, p0, LF2/c;->m:Ljava/lang/String;

    .line 40
    .line 41
    if-eqz v3, :cond_2

    .line 42
    .line 43
    iput-object v2, p0, LF2/c;->m:Ljava/lang/String;

    .line 44
    .line 45
    :cond_2
    iput-object v2, p0, LF2/c;->q:Landroid/graphics/drawable/Drawable;

    .line 46
    .line 47
    iget-object v3, p0, LF2/c;->o:Ljava/lang/Object;

    .line 48
    .line 49
    if-eqz v3, :cond_4

    .line 50
    .line 51
    invoke-virtual {p0, v3}, LF2/c;->d(Ljava/lang/Object;)Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    check-cast v3, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 56
    .line 57
    check-cast v3, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 58
    .line 59
    if-nez v3, :cond_3

    .line 60
    .line 61
    move-object v3, v2

    .line 62
    goto :goto_1

    .line 63
    :cond_3
    invoke-interface {v3}, Lcom/facebook/imagepipeline/image/HasImageMetadata;->getExtras()Ljava/util/Map;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    :goto_1
    const-string v4, "release"

    .line 68
    .line 69
    iget-object v5, p0, LF2/c;->o:Ljava/lang/Object;

    .line 70
    .line 71
    invoke-virtual {p0, v5, v4}, LF2/c;->i(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    iget-object v4, p0, LF2/c;->o:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast v4, Lcom/facebook/common/references/CloseableReference;

    .line 77
    .line 78
    invoke-static {v4}, Lcom/facebook/common/references/CloseableReference;->d(Lcom/facebook/common/references/CloseableReference;)V

    .line 79
    .line 80
    .line 81
    iput-object v2, p0, LF2/c;->o:Ljava/lang/Object;

    .line 82
    .line 83
    move-object v2, v3

    .line 84
    :cond_4
    if-eqz v0, :cond_5

    .line 85
    .line 86
    invoke-virtual {p0}, LF2/c;->c()Lcom/facebook/drawee/controller/ControllerListener;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    iget-object v3, p0, LF2/c;->h:Ljava/lang/String;

    .line 91
    .line 92
    invoke-interface {v0, v3}, Lcom/facebook/drawee/controller/ControllerListener;->onRelease(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    iget-object v0, p0, LF2/c;->h:Ljava/lang/String;

    .line 96
    .line 97
    invoke-virtual {p0, v1, v2}, LF2/c;->j(Ljava/util/Map;Ljava/util/Map;)LS2/d;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    iget-object v2, p0, LF2/c;->e:LS2/g;

    .line 102
    .line 103
    invoke-virtual {v2, v0, v1}, LS2/g;->onRelease(Ljava/lang/String;LS2/d;)V

    .line 104
    .line 105
    .line 106
    :cond_5
    return-void
.end method

.method public final n(Lcom/facebook/datasource/DataSource;Lcom/facebook/imagepipeline/image/ImageInfo;)V
    .locals 6

    .line 1
    invoke-virtual {p0}, LF2/c;->c()Lcom/facebook/drawee/controller/ControllerListener;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, LF2/c;->h:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v2, p0, LF2/c;->i:Ljava/lang/Object;

    .line 8
    .line 9
    invoke-interface {v0, v1, v2}, Lcom/facebook/drawee/controller/ControllerListener;->onSubmit(Ljava/lang/String;Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, LF2/c;->h:Ljava/lang/String;

    .line 13
    .line 14
    iget-object v1, p0, LF2/c;->i:Ljava/lang/Object;

    .line 15
    .line 16
    move-object v2, p0

    .line 17
    check-cast v2, LC2/a;

    .line 18
    .line 19
    iget-object v3, v2, LC2/a;->z:Lcom/facebook/imagepipeline/request/d;

    .line 20
    .line 21
    iget-object v2, v2, LC2/a;->A:Lcom/facebook/imagepipeline/request/d;

    .line 22
    .line 23
    sget-object v4, Lcom/facebook/imagepipeline/request/d;->REQUEST_TO_URI_FN:Lcom/facebook/common/internal/Fn;

    .line 24
    .line 25
    const-string v5, "requestToUri"

    .line 26
    .line 27
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const/4 v5, 0x0

    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    invoke-interface {v4, v3}, Lcom/facebook/common/internal/Fn;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    check-cast v3, Landroid/net/Uri;

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    move-object v3, v5

    .line 41
    :goto_0
    if-eqz v3, :cond_1

    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    if-eqz v2, :cond_2

    .line 45
    .line 46
    invoke-interface {v4, v2}, Lcom/facebook/common/internal/Fn;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    check-cast v2, Landroid/net/Uri;

    .line 51
    .line 52
    :cond_2
    :goto_1
    check-cast p2, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 53
    .line 54
    if-nez p1, :cond_3

    .line 55
    .line 56
    move-object p1, v5

    .line 57
    goto :goto_2

    .line 58
    :cond_3
    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->getExtras()Ljava/util/Map;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    :goto_2
    check-cast p2, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 63
    .line 64
    check-cast p2, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 65
    .line 66
    if-nez p2, :cond_4

    .line 67
    .line 68
    goto :goto_3

    .line 69
    :cond_4
    invoke-interface {p2}, Lcom/facebook/imagepipeline/image/HasImageMetadata;->getExtras()Ljava/util/Map;

    .line 70
    .line 71
    .line 72
    move-result-object v5

    .line 73
    :goto_3
    invoke-virtual {p0, p1, v5}, LF2/c;->j(Ljava/util/Map;Ljava/util/Map;)LS2/d;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    iget-object p2, p0, LF2/c;->e:LS2/g;

    .line 78
    .line 79
    invoke-virtual {p2, v0, v1, p1}, LS2/g;->onSubmit(Ljava/lang/String;Ljava/lang/Object;LS2/d;)V

    .line 80
    .line 81
    .line 82
    return-void
.end method

.method public final onAttach()V
    .locals 9

    .line 1
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 2
    .line 3
    .line 4
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 5
    .line 6
    const/4 v1, 0x2

    .line 7
    invoke-virtual {v0, v1}, Lp2/b;->isLoggable(I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iget-object v1, p0, LF2/c;->h:Ljava/lang/String;

    .line 22
    .line 23
    iget-boolean v2, p0, LF2/c;->k:Z

    .line 24
    .line 25
    if-eqz v2, :cond_0

    .line 26
    .line 27
    const-string v2, "request already submitted"

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_0
    const-string v2, "request needs submit"

    .line 31
    .line 32
    :goto_0
    sget-object v3, LF2/c;->t:Ljava/lang/Class;

    .line 33
    .line 34
    const-string v4, "controller %x %s: onAttach: %s"

    .line 35
    .line 36
    invoke-static {v3, v4, v0, v1, v2}, Lp2/a;->q(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    :cond_1
    sget-object v0, LE2/b;->g:LE2/b;

    .line 40
    .line 41
    iget-object v1, p0, LF2/c;->a:LE2/c;

    .line 42
    .line 43
    invoke-virtual {v1, v0}, LE2/c;->a(LE2/b;)V

    .line 44
    .line 45
    .line 46
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    iget-object v0, p0, LF2/c;->b:LE2/a;

    .line 52
    .line 53
    invoke-virtual {v0, p0}, LE2/a;->a(LF2/c;)V

    .line 54
    .line 55
    .line 56
    const/4 v0, 0x1

    .line 57
    iput-boolean v0, p0, LF2/c;->j:Z

    .line 58
    .line 59
    iget-boolean v0, p0, LF2/c;->k:Z

    .line 60
    .line 61
    if-nez v0, :cond_8

    .line 62
    .line 63
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 64
    .line 65
    .line 66
    move-object v1, p0

    .line 67
    check-cast v1, LC2/a;

    .line 68
    .line 69
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 70
    .line 71
    .line 72
    :try_start_0
    iget-object v0, v1, LC2/a;->v:Landroidx/work/impl/model/b;

    .line 73
    .line 74
    const/4 v2, 0x0

    .line 75
    if-eqz v0, :cond_3

    .line 76
    .line 77
    iget-object v3, v1, LC2/a;->w:Lcom/facebook/cache/common/CacheKey;

    .line 78
    .line 79
    if-nez v3, :cond_2

    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_2
    invoke-virtual {v0, v3}, Landroidx/work/impl/model/b;->get(Ljava/lang/Object;)Lcom/facebook/common/references/CloseableReference;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    if-eqz v0, :cond_4

    .line 87
    .line 88
    invoke-virtual {v0}, Lcom/facebook/common/references/CloseableReference;->f()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    check-cast v3, Lcom/facebook/imagepipeline/image/CloseableImage;

    .line 93
    .line 94
    invoke-interface {v3}, Lcom/facebook/imagepipeline/image/CloseableImage;->getQualityInfo()Lcom/facebook/imagepipeline/image/QualityInfo;

    .line 95
    .line 96
    .line 97
    move-result-object v3

    .line 98
    invoke-interface {v3}, Lcom/facebook/imagepipeline/image/QualityInfo;->isOfFullQuality()Z

    .line 99
    .line 100
    .line 101
    move-result v3

    .line 102
    if-nez v3, :cond_4

    .line 103
    .line 104
    invoke-virtual {v0}, Lcom/facebook/common/references/CloseableReference;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 105
    .line 106
    .line 107
    :cond_3
    :goto_1
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 108
    .line 109
    .line 110
    goto :goto_2

    .line 111
    :catchall_0
    move-exception v0

    .line 112
    move-object v4, p0

    .line 113
    goto/16 :goto_5

    .line 114
    .line 115
    :cond_4
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 116
    .line 117
    .line 118
    move-object v4, v0

    .line 119
    goto :goto_3

    .line 120
    :goto_2
    move-object v4, v2

    .line 121
    :goto_3
    const/4 v0, 0x0

    .line 122
    const/4 v3, 0x1

    .line 123
    if-eqz v4, :cond_5

    .line 124
    .line 125
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 126
    .line 127
    .line 128
    iput-object v2, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 129
    .line 130
    iput-boolean v3, p0, LF2/c;->k:Z

    .line 131
    .line 132
    iput-boolean v0, p0, LF2/c;->l:Z

    .line 133
    .line 134
    iget-object v0, p0, LF2/c;->a:LE2/c;

    .line 135
    .line 136
    sget-object v2, LE2/b;->L:LE2/b;

    .line 137
    .line 138
    invoke-virtual {v0, v2}, LE2/c;->a(LE2/b;)V

    .line 139
    .line 140
    .line 141
    iget-object v0, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 142
    .line 143
    invoke-virtual {p0, v4}, LF2/c;->d(Ljava/lang/Object;)Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    check-cast v2, Lcom/facebook/imagepipeline/image/ImageInfo;

    .line 148
    .line 149
    invoke-virtual {p0, v0, v2}, LF2/c;->n(Lcom/facebook/datasource/DataSource;Lcom/facebook/imagepipeline/image/ImageInfo;)V

    .line 150
    .line 151
    .line 152
    monitor-enter v1

    .line 153
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 154
    iget-object v2, p0, LF2/c;->h:Ljava/lang/String;

    .line 155
    .line 156
    iget-object v3, p0, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 157
    .line 158
    const/high16 v5, 0x3f800000    # 1.0f

    .line 159
    .line 160
    const/4 v6, 0x1

    .line 161
    const/4 v7, 0x1

    .line 162
    const/4 v8, 0x1

    .line 163
    move-object v1, p0

    .line 164
    invoke-virtual/range {v1 .. v8}, LF2/c;->l(Ljava/lang/String;Lcom/facebook/datasource/DataSource;Ljava/lang/Object;FZZZ)V

    .line 165
    .line 166
    .line 167
    move-object v4, v1

    .line 168
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 169
    .line 170
    .line 171
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 172
    .line 173
    .line 174
    goto/16 :goto_6

    .line 175
    .line 176
    :catchall_1
    move-exception v0

    .line 177
    move-object v4, p0

    .line 178
    :goto_4
    :try_start_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 179
    throw v0

    .line 180
    :catchall_2
    move-exception v0

    .line 181
    goto :goto_4

    .line 182
    :cond_5
    move-object v4, p0

    .line 183
    iget-object v5, v4, LF2/c;->a:LE2/c;

    .line 184
    .line 185
    sget-object v6, LE2/b;->o:LE2/b;

    .line 186
    .line 187
    invoke-virtual {v5, v6}, LE2/c;->a(LE2/b;)V

    .line 188
    .line 189
    .line 190
    iget-object v5, v4, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 191
    .line 192
    const/4 v6, 0x0

    .line 193
    invoke-interface {v5, v6, v3}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setProgress(FZ)V

    .line 194
    .line 195
    .line 196
    iput-boolean v3, v4, LF2/c;->k:Z

    .line 197
    .line 198
    iput-boolean v0, v4, LF2/c;->l:Z

    .line 199
    .line 200
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 201
    .line 202
    .line 203
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 204
    .line 205
    const/4 v3, 0x2

    .line 206
    invoke-virtual {v0, v3}, Lp2/b;->isLoggable(I)Z

    .line 207
    .line 208
    .line 209
    move-result v0

    .line 210
    if-eqz v0, :cond_6

    .line 211
    .line 212
    invoke-static {v1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 217
    .line 218
    .line 219
    move-result-object v0

    .line 220
    const-class v5, LC2/a;

    .line 221
    .line 222
    const-string v6, "controller %x: getDataSource"

    .line 223
    .line 224
    invoke-static {v5, v6, v0}, Lp2/a;->o(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V

    .line 225
    .line 226
    .line 227
    :cond_6
    iget-object v0, v1, LC2/a;->x:Lcom/facebook/common/internal/Supplier;

    .line 228
    .line 229
    invoke-interface {v0}, Lcom/facebook/common/internal/Supplier;->get()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    check-cast v0, Lcom/facebook/datasource/DataSource;

    .line 234
    .line 235
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 236
    .line 237
    .line 238
    iput-object v0, v4, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 239
    .line 240
    invoke-virtual {p0, v0, v2}, LF2/c;->n(Lcom/facebook/datasource/DataSource;Lcom/facebook/imagepipeline/image/ImageInfo;)V

    .line 241
    .line 242
    .line 243
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 244
    .line 245
    invoke-virtual {v0, v3}, Lp2/b;->isLoggable(I)Z

    .line 246
    .line 247
    .line 248
    move-result v0

    .line 249
    if-eqz v0, :cond_7

    .line 250
    .line 251
    sget-object v0, LF2/c;->t:Ljava/lang/Class;

    .line 252
    .line 253
    const-string v1, "controller %x %s: submitRequest: dataSource: %x"

    .line 254
    .line 255
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 256
    .line 257
    .line 258
    move-result v2

    .line 259
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 260
    .line 261
    .line 262
    move-result-object v2

    .line 263
    iget-object v3, v4, LF2/c;->h:Ljava/lang/String;

    .line 264
    .line 265
    iget-object v5, v4, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 266
    .line 267
    invoke-static {v5}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 268
    .line 269
    .line 270
    move-result v5

    .line 271
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 272
    .line 273
    .line 274
    move-result-object v5

    .line 275
    invoke-static {v0, v1, v2, v3, v5}, Lp2/a;->q(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 276
    .line 277
    .line 278
    :cond_7
    iget-object v0, v4, LF2/c;->h:Ljava/lang/String;

    .line 279
    .line 280
    iget-object v1, v4, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 281
    .line 282
    invoke-interface {v1}, Lcom/facebook/datasource/DataSource;->hasResult()Z

    .line 283
    .line 284
    .line 285
    move-result v1

    .line 286
    new-instance v2, LF2/a;

    .line 287
    .line 288
    invoke-direct {v2, p0, v0, v1}, LF2/a;-><init>(LF2/c;Ljava/lang/String;Z)V

    .line 289
    .line 290
    .line 291
    iget-object v0, v4, LF2/c;->n:Lcom/facebook/datasource/DataSource;

    .line 292
    .line 293
    iget-object v1, v4, LF2/c;->c:Lm2/d;

    .line 294
    .line 295
    invoke-interface {v0, v2, v1}, Lcom/facebook/datasource/DataSource;->subscribe(Lcom/facebook/datasource/DataSubscriber;Ljava/util/concurrent/Executor;)V

    .line 296
    .line 297
    .line 298
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 299
    .line 300
    .line 301
    goto :goto_6

    .line 302
    :goto_5
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 303
    .line 304
    .line 305
    throw v0

    .line 306
    :cond_8
    move-object v4, p0

    .line 307
    :goto_6
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 308
    .line 309
    .line 310
    return-void
.end method

.method public final onClick()Z
    .locals 4

    .line 1
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-virtual {v0, v1}, Lp2/b;->isLoggable(I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v1, p0, LF2/c;->h:Ljava/lang/String;

    .line 19
    .line 20
    sget-object v2, LF2/c;->t:Ljava/lang/Class;

    .line 21
    .line 22
    const-string v3, "controller %x %s: onClick"

    .line 23
    .line 24
    invoke-static {v2, v3, v0, v1}, Lp2/a;->p(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    const/4 v0, 0x0

    .line 28
    return v0
.end method

.method public final onDetach()V
    .locals 5

    .line 1
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 2
    .line 3
    .line 4
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 5
    .line 6
    const/4 v1, 0x2

    .line 7
    invoke-virtual {v0, v1}, Lp2/b;->isLoggable(I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    sget-object v0, LF2/c;->t:Ljava/lang/Class;

    .line 14
    .line 15
    const-string v1, "controller %x %s: onDetach"

    .line 16
    .line 17
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    iget-object v3, p0, LF2/c;->h:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {v0, v1, v2, v3}, Lp2/a;->p(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    :cond_0
    iget-object v0, p0, LF2/c;->a:LE2/c;

    .line 31
    .line 32
    sget-object v1, LE2/b;->i:LE2/b;

    .line 33
    .line 34
    invoke-virtual {v0, v1}, LE2/c;->a(LE2/b;)V

    .line 35
    .line 36
    .line 37
    const/4 v0, 0x0

    .line 38
    iput-boolean v0, p0, LF2/c;->j:Z

    .line 39
    .line 40
    iget-object v1, p0, LF2/c;->b:LE2/a;

    .line 41
    .line 42
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-virtual {v2}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    if-ne v2, v3, :cond_3

    .line 58
    .line 59
    iget-object v2, v1, LE2/a;->b:Ljava/lang/Object;

    .line 60
    .line 61
    monitor-enter v2

    .line 62
    :try_start_0
    iget-object v3, v1, LE2/a;->d:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast v3, Ljava/util/ArrayList;

    .line 65
    .line 66
    invoke-virtual {v3, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    if-eqz v3, :cond_1

    .line 71
    .line 72
    monitor-exit v2

    .line 73
    goto :goto_1

    .line 74
    :catchall_0
    move-exception v0

    .line 75
    goto :goto_0

    .line 76
    :cond_1
    iget-object v3, v1, LE2/a;->d:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v3, Ljava/util/ArrayList;

    .line 79
    .line 80
    invoke-virtual {v3, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    iget-object v3, v1, LE2/a;->d:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v3, Ljava/util/ArrayList;

    .line 86
    .line 87
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 88
    .line 89
    .line 90
    move-result v3

    .line 91
    const/4 v4, 0x1

    .line 92
    if-ne v3, v4, :cond_2

    .line 93
    .line 94
    move v0, v4

    .line 95
    :cond_2
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 96
    if-eqz v0, :cond_4

    .line 97
    .line 98
    iget-object v0, v1, LE2/a;->c:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v0, Landroid/os/Handler;

    .line 101
    .line 102
    iget-object v1, v1, LE2/a;->f:Ljava/lang/Object;

    .line 103
    .line 104
    check-cast v1, LB5/c;

    .line 105
    .line 106
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 107
    .line 108
    .line 109
    goto :goto_1

    .line 110
    :goto_0
    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 111
    throw v0

    .line 112
    :cond_3
    invoke-virtual {p0}, LF2/c;->release()V

    .line 113
    .line 114
    .line 115
    :cond_4
    :goto_1
    invoke-static {}, Lm3/a;->a()Lcom/facebook/imagepipeline/systrace/FrescoSystrace$Systrace;

    .line 116
    .line 117
    .line 118
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 4

    .line 1
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-virtual {v0, v1}, Lp2/b;->isLoggable(I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v1, p0, LF2/c;->h:Ljava/lang/String;

    .line 19
    .line 20
    sget-object v2, LF2/c;->t:Ljava/lang/Class;

    .line 21
    .line 22
    const-string v3, "controller %x %s: onTouchEvent %s"

    .line 23
    .line 24
    invoke-static {v2, v3, v0, v1, p1}, Lp2/a;->q(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    const/4 p1, 0x0

    .line 28
    return p1
.end method

.method public final onViewportVisibilityHint(Z)V
    .locals 0

    .line 1
    return-void
.end method

.method public final release()V
    .locals 2

    .line 1
    sget-object v0, LE2/b;->j:LE2/b;

    .line 2
    .line 3
    iget-object v1, p0, LF2/c;->a:LE2/c;

    .line 4
    .line 5
    invoke-virtual {v1, v0}, LE2/c;->a(LE2/b;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->reset()V

    .line 13
    .line 14
    .line 15
    :cond_0
    invoke-virtual {p0}, LF2/c;->m()V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final setContentDescription(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, LF2/c;->m:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public setHierarchy(Lcom/facebook/drawee/interfaces/DraweeHierarchy;)V
    .locals 4

    .line 1
    sget-object v0, Lp2/a;->a:Lp2/b;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-virtual {v0, v1}, Lp2/b;->isLoggable(I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v1, p0, LF2/c;->h:Ljava/lang/String;

    .line 19
    .line 20
    sget-object v2, LF2/c;->t:Ljava/lang/Class;

    .line 21
    .line 22
    const-string v3, "controller %x %s: setHierarchy: %s"

    .line 23
    .line 24
    invoke-static {v2, v3, v0, v1, p1}, Lp2/a;->q(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    :cond_0
    if-eqz p1, :cond_1

    .line 28
    .line 29
    sget-object v0, LE2/b;->a:LE2/b;

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    sget-object v0, LE2/b;->b:LE2/b;

    .line 33
    .line 34
    :goto_0
    iget-object v1, p0, LF2/c;->a:LE2/c;

    .line 35
    .line 36
    invoke-virtual {v1, v0}, LE2/c;->a(LE2/b;)V

    .line 37
    .line 38
    .line 39
    iget-boolean v0, p0, LF2/c;->k:Z

    .line 40
    .line 41
    if-eqz v0, :cond_2

    .line 42
    .line 43
    iget-object v0, p0, LF2/c;->b:LE2/a;

    .line 44
    .line 45
    invoke-virtual {v0, p0}, LE2/a;->a(LF2/c;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p0}, LF2/c;->release()V

    .line 49
    .line 50
    .line 51
    :cond_2
    iget-object v0, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 52
    .line 53
    if-eqz v0, :cond_3

    .line 54
    .line 55
    const/4 v1, 0x0

    .line 56
    invoke-interface {v0, v1}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setControllerOverlay(Landroid/graphics/drawable/Drawable;)V

    .line 57
    .line 58
    .line 59
    iput-object v1, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 60
    .line 61
    :cond_3
    if-eqz p1, :cond_5

    .line 62
    .line 63
    instance-of v0, p1, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 64
    .line 65
    if-eqz v0, :cond_4

    .line 66
    .line 67
    check-cast p1, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 68
    .line 69
    iput-object p1, p0, LF2/c;->f:Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;

    .line 70
    .line 71
    iget-object v0, p0, LF2/c;->g:LG2/a;

    .line 72
    .line 73
    invoke-interface {p1, v0}, Lcom/facebook/drawee/interfaces/SettableDraweeHierarchy;->setControllerOverlay(Landroid/graphics/drawable/Drawable;)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 78
    .line 79
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 80
    .line 81
    .line 82
    throw p1

    .line 83
    :cond_5
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    invoke-static {p0}, Lo2/e;->m(Ljava/lang/Object;)Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "isAttached"

    .line 6
    .line 7
    iget-boolean v2, p0, LF2/c;->j:Z

    .line 8
    .line 9
    invoke-virtual {v0, v1, v2}, Landroidx/camera/video/internal/c;->b(Ljava/lang/String;Z)V

    .line 10
    .line 11
    .line 12
    const-string v1, "isRequestSubmitted"

    .line 13
    .line 14
    iget-boolean v2, p0, LF2/c;->k:Z

    .line 15
    .line 16
    invoke-virtual {v0, v1, v2}, Landroidx/camera/video/internal/c;->b(Ljava/lang/String;Z)V

    .line 17
    .line 18
    .line 19
    const-string v1, "hasFetchFailed"

    .line 20
    .line 21
    iget-boolean v2, p0, LF2/c;->l:Z

    .line 22
    .line 23
    invoke-virtual {v0, v1, v2}, Landroidx/camera/video/internal/c;->b(Ljava/lang/String;Z)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, LF2/c;->o:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, Lcom/facebook/common/references/CloseableReference;

    .line 29
    .line 30
    if-eqz v1, :cond_0

    .line 31
    .line 32
    invoke-virtual {v1}, Lcom/facebook/common/references/CloseableReference;->g()Z

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    if-eqz v2, :cond_0

    .line 37
    .line 38
    iget-object v1, v1, Lcom/facebook/common/references/CloseableReference;->b:Ls2/a;

    .line 39
    .line 40
    invoke-virtual {v1}, Ls2/a;->a()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    invoke-static {v1}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    const/4 v1, 0x0

    .line 50
    :goto_0
    const-string v2, "fetchedImage"

    .line 51
    .line 52
    invoke-virtual {v0, v1, v2}, Landroidx/camera/video/internal/c;->a(ILjava/lang/String;)V

    .line 53
    .line 54
    .line 55
    iget-object v1, p0, LF2/c;->a:LE2/c;

    .line 56
    .line 57
    iget-object v1, v1, LE2/c;->a:Ljava/util/concurrent/ArrayBlockingQueue;

    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    const-string v2, "events"

    .line 64
    .line 65
    invoke-virtual {v0, v1, v2}, Landroidx/camera/video/internal/c;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0}, Landroidx/camera/video/internal/c;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    return-object v0
.end method
