.class public final LZ2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/imagepipeline/cache/CountingMemoryCache$EntryStateObserver;


# instance fields
.field public final synthetic a:LZ2/d;


# direct methods
.method public constructor <init>(LZ2/d;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LZ2/b;->a:LZ2/d;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onExclusivityChanged(Ljava/lang/Object;Z)V
    .locals 1

    .line 1
    check-cast p1, Lcom/facebook/cache/common/CacheKey;

    .line 2
    .line 3
    iget-object v0, p0, LZ2/b;->a:LZ2/d;

    .line 4
    .line 5
    monitor-enter v0

    .line 6
    if-eqz p2, :cond_0

    .line 7
    .line 8
    :try_start_0
    iget-object p2, v0, LZ2/d;->d:Ljava/util/LinkedHashSet;

    .line 9
    .line 10
    invoke-virtual {p2, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :catchall_0
    move-exception p1

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    iget-object p2, v0, LZ2/d;->d:Ljava/util/LinkedHashSet;

    .line 17
    .line 18
    invoke-virtual {p2, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    .line 20
    .line 21
    :goto_0
    monitor-exit v0

    .line 22
    return-void

    .line 23
    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 24
    throw p1
.end method
