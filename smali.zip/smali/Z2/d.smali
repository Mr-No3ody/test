.class public final LZ2/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LM2/a;

.field public final b:Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

.field public final c:LZ2/b;

.field public final d:Ljava/util/LinkedHashSet;


# direct methods
.method public constructor <init>(LM2/a;Lcom/facebook/imagepipeline/cache/CountingMemoryCache;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LZ2/d;->a:LM2/a;

    .line 5
    .line 6
    iput-object p2, p0, LZ2/d;->b:Lcom/facebook/imagepipeline/cache/CountingMemoryCache;

    .line 7
    .line 8
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, LZ2/d;->d:Ljava/util/LinkedHashSet;

    .line 14
    .line 15
    new-instance p1, LZ2/b;

    .line 16
    .line 17
    invoke-direct {p1, p0}, LZ2/b;-><init>(LZ2/d;)V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, LZ2/d;->c:LZ2/b;

    .line 21
    .line 22
    return-void
.end method
