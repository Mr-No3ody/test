.class public final LZ2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/cache/common/CacheKey;


# instance fields
.field public final a:LM2/a;

.field public final b:I


# direct methods
.method public constructor <init>(LM2/a;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LZ2/c;->a:LM2/a;

    .line 5
    .line 6
    iput p2, p0, LZ2/c;->b:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final containsUri(Landroid/net/Uri;)Z
    .locals 1

    .line 1
    iget-object v0, p0, LZ2/c;->a:LM2/a;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LM2/a;->containsUri(Landroid/net/Uri;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-ne p1, p0, :cond_0

    .line 2
    .line 3
    goto :goto_0

    .line 4
    :cond_0
    instance-of v0, p1, LZ2/c;

    .line 5
    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    check-cast p1, LZ2/c;

    .line 9
    .line 10
    iget v0, p1, LZ2/c;->b:I

    .line 11
    .line 12
    iget v1, p0, LZ2/c;->b:I

    .line 13
    .line 14
    if-ne v1, v0, :cond_1

    .line 15
    .line 16
    iget-object v0, p0, LZ2/c;->a:LM2/a;

    .line 17
    .line 18
    iget-object p1, p1, LZ2/c;->a:LM2/a;

    .line 19
    .line 20
    invoke-virtual {v0, p1}, LM2/a;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    if-eqz p1, :cond_1

    .line 25
    .line 26
    :goto_0
    const/4 p1, 0x1

    .line 27
    return p1

    .line 28
    :cond_1
    const/4 p1, 0x0

    .line 29
    return p1
.end method

.method public final getUriString()Ljava/lang/String;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, LZ2/c;->a:LM2/a;

    .line 2
    .line 3
    invoke-virtual {v0}, LM2/a;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit16 v0, v0, 0x3f5

    .line 8
    .line 9
    iget v1, p0, LZ2/c;->b:I

    .line 10
    .line 11
    add-int/2addr v0, v1

    .line 12
    return v0
.end method

.method public final isResourceIdForDebugging()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    invoke-static {p0}, Lo2/e;->m(Ljava/lang/Object;)Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, LZ2/c;->a:LM2/a;

    .line 6
    .line 7
    const-string v2, "imageCacheKey"

    .line 8
    .line 9
    invoke-virtual {v0, v1, v2}, Landroidx/camera/video/internal/c;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const-string v1, "frameIndex"

    .line 13
    .line 14
    iget v2, p0, LZ2/c;->b:I

    .line 15
    .line 16
    invoke-virtual {v0, v2, v1}, Landroidx/camera/video/internal/c;->a(ILjava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Landroidx/camera/video/internal/c;->toString()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    return-object v0
.end method
