.class public final LQ3/b;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:LQ3/c;

.field public final synthetic d:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;LQ3/c;Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;)V
    .locals 0

    .line 1
    iput-object p2, p0, LQ3/b;->c:LQ3/c;

    .line 2
    .line 3
    iput-object p3, p0, LQ3/b;->d:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;

    .line 4
    .line 5
    const/4 p2, 0x2

    .line 6
    invoke-direct {p0, p2, p1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance v0, LQ3/b;

    .line 2
    .line 3
    iget-object v1, p0, LQ3/b;->c:LQ3/c;

    .line 4
    .line 5
    iget-object v2, p0, LQ3/b;->d:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;

    .line 6
    .line 7
    invoke-direct {v0, p2, v1, v2}, LQ3/b;-><init>(Lkotlin/coroutines/Continuation;LQ3/c;Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;)V

    .line 8
    .line 9
    .line 10
    iput-object p1, v0, LQ3/b;->b:Ljava/lang/Object;

    .line 11
    .line 12
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LQ3/b;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LQ3/b;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LQ3/b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LQ3/b;->a:I

    .line 4
    .line 5
    iget-object v2, p0, LQ3/b;->c:LQ3/c;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    if-ne v1, v3, :cond_0

    .line 11
    .line 12
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :catchall_0
    move-exception p1

    .line 17
    goto :goto_1

    .line 18
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 19
    .line 20
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 21
    .line 22
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    throw p1

    .line 26
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object p1, p0, LQ3/b;->b:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 32
    .line 33
    :try_start_1
    sget-object p1, Lxf/q;->a:Lxf/o;

    .line 34
    .line 35
    sget-object p1, LJ3/b;->a:Lcom/flexibank/sdk/api/FlexiBankApiCashierService;

    .line 36
    .line 37
    iget-object v1, v2, LQ3/c;->B:LO3/k;

    .line 38
    .line 39
    iput v3, p0, LQ3/b;->a:I

    .line 40
    .line 41
    invoke-interface {p1, v1, p0}, Lcom/flexibank/sdk/api/FlexiBankApiCashierService;->checkCouponByVM(LO3/k;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    if-ne p1, v0, :cond_2

    .line 46
    .line 47
    return-object v0

    .line 48
    :cond_2
    :goto_0
    check-cast p1, LW3/f;

    .line 49
    .line 50
    sget-object v0, Lxf/q;->a:Lxf/o;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 51
    .line 52
    goto :goto_2

    .line 53
    :goto_1
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 54
    .line 55
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    :goto_2
    instance-of v0, p1, Lxf/p;

    .line 60
    .line 61
    iget-object v1, v2, LQ3/c;->C:Lxf/t;

    .line 62
    .line 63
    const/4 v4, 0x0

    .line 64
    const/16 v5, 0x8

    .line 65
    .line 66
    if-nez v0, :cond_7

    .line 67
    .line 68
    move-object v0, p1

    .line 69
    check-cast v0, LW3/f;

    .line 70
    .line 71
    check-cast v0, La4/e;

    .line 72
    .line 73
    sget v6, LQ3/c;->H:I

    .line 74
    .line 75
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    check-cast v6, Landroid/view/View;

    .line 80
    .line 81
    if-eqz v6, :cond_3

    .line 82
    .line 83
    invoke-virtual {v6, v5}, Landroid/view/View;->setVisibility(I)V

    .line 84
    .line 85
    .line 86
    :cond_3
    if-eqz v0, :cond_5

    .line 87
    .line 88
    invoke-virtual {v0}, LW3/f;->c()Z

    .line 89
    .line 90
    .line 91
    move-result v6

    .line 92
    if-ne v6, v3, :cond_5

    .line 93
    .line 94
    iget-object v0, v2, LQ3/c;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;

    .line 95
    .line 96
    if-eqz v0, :cond_4

    .line 97
    .line 98
    iget-object v3, p0, LQ3/b;->d:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;

    .line 99
    .line 100
    invoke-interface {v0, v3}, Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;->onCouponClick(Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;)V

    .line 101
    .line 102
    .line 103
    :cond_4
    invoke-virtual {v2}, Lr4/a;->dismiss()V

    .line 104
    .line 105
    .line 106
    goto :goto_4

    .line 107
    :cond_5
    if-eqz v0, :cond_6

    .line 108
    .line 109
    invoke-virtual {v0}, LW3/f;->b()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    goto :goto_3

    .line 114
    :cond_6
    const/4 v0, 0x0

    .line 115
    :goto_3
    new-array v2, v4, [Ljava/lang/Object;

    .line 116
    .line 117
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    :cond_7
    :goto_4
    invoke-static {p1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    if-eqz p1, :cond_9

    .line 125
    .line 126
    invoke-static {p1}, LD3/a;->x(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    sget v0, LQ3/c;->H:I

    .line 131
    .line 132
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    check-cast v0, Landroid/view/View;

    .line 137
    .line 138
    if-eqz v0, :cond_8

    .line 139
    .line 140
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    .line 141
    .line 142
    .line 143
    :cond_8
    new-array v0, v4, [Ljava/lang/Object;

    .line 144
    .line 145
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    :cond_9
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 149
    .line 150
    return-object p1
.end method
