.class public final LQ3/c;
.super Lr4/a;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroidx/lifecycle/LifecycleOwner;


# static fields
.field public static final synthetic H:I


# instance fields
.field public final A:Lxf/t;

.field public B:LO3/k;

.field public final C:Lxf/t;

.field public final g:Lxf/t;

.field public final i:Lxf/t;

.field public final j:Lxf/t;

.field public final o:Lxf/t;

.field public final p:Lxf/t;

.field public t:Ljava/util/List;

.field public v:J

.field public w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget v0, Lcom/flexibank/sdk/q;->fb_dialog_cashier_coupon_list:I

    .line 7
    .line 8
    invoke-direct {p0, p1, v0}, Lr4/a;-><init>(Landroid/content/Context;I)V

    .line 9
    .line 10
    .line 11
    new-instance p1, LQ3/a;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-direct {p1, p0, v0}, LQ3/a;-><init>(LQ3/c;I)V

    .line 15
    .line 16
    .line 17
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iput-object p1, p0, LQ3/c;->g:Lxf/t;

    .line 22
    .line 23
    new-instance p1, LQ3/a;

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    invoke-direct {p1, p0, v0}, LQ3/a;-><init>(LQ3/c;I)V

    .line 27
    .line 28
    .line 29
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iput-object p1, p0, LQ3/c;->i:Lxf/t;

    .line 34
    .line 35
    new-instance p1, LQ3/a;

    .line 36
    .line 37
    const/4 v0, 0x2

    .line 38
    invoke-direct {p1, p0, v0}, LQ3/a;-><init>(LQ3/c;I)V

    .line 39
    .line 40
    .line 41
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    iput-object p1, p0, LQ3/c;->j:Lxf/t;

    .line 46
    .line 47
    new-instance p1, LQ3/a;

    .line 48
    .line 49
    const/4 v0, 0x3

    .line 50
    invoke-direct {p1, p0, v0}, LQ3/a;-><init>(LQ3/c;I)V

    .line 51
    .line 52
    .line 53
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    iput-object p1, p0, LQ3/c;->o:Lxf/t;

    .line 58
    .line 59
    new-instance p1, LPa/b0;

    .line 60
    .line 61
    const/4 v0, 0x1

    .line 62
    invoke-direct {p1, v0}, LPa/b0;-><init>(I)V

    .line 63
    .line 64
    .line 65
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    iput-object p1, p0, LQ3/c;->p:Lxf/t;

    .line 70
    .line 71
    const-wide/16 v0, -0x1

    .line 72
    .line 73
    iput-wide v0, p0, LQ3/c;->v:J

    .line 74
    .line 75
    new-instance p1, LQ3/a;

    .line 76
    .line 77
    const/4 v0, 0x4

    .line 78
    invoke-direct {p1, p0, v0}, LQ3/a;-><init>(LQ3/c;I)V

    .line 79
    .line 80
    .line 81
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    iput-object p1, p0, LQ3/c;->A:Lxf/t;

    .line 86
    .line 87
    new-instance p1, LQ3/a;

    .line 88
    .line 89
    const/4 v0, 0x5

    .line 90
    invoke-direct {p1, p0, v0}, LQ3/a;-><init>(LQ3/c;I)V

    .line 91
    .line 92
    .line 93
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    iput-object p1, p0, LQ3/c;->C:Lxf/t;

    .line 98
    .line 99
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 6

    .line 1
    iget-object v0, p0, LQ3/c;->o:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Landroidx/recyclerview/widget/RecyclerView;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    new-instance v3, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 13
    .line 14
    iget-object v4, p0, Lo4/b;->a:Landroid/content/Context;

    .line 15
    .line 16
    const/4 v5, 0x1

    .line 17
    invoke-direct {v3, v4, v5, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    check-cast v1, Landroidx/recyclerview/widget/RecyclerView;

    .line 28
    .line 29
    if-eqz v1, :cond_1

    .line 30
    .line 31
    const/4 v3, 0x4

    .line 32
    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView;->setItemViewCacheSize(I)V

    .line 33
    .line 34
    .line 35
    :cond_1
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Landroidx/recyclerview/widget/RecyclerView;

    .line 40
    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    new-instance v3, Ln4/a;

    .line 44
    .line 45
    invoke-direct {v3}, Ln4/a;-><init>()V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView;->addItemDecoration(Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;)V

    .line 49
    .line 50
    .line 51
    :cond_2
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 56
    .line 57
    if-eqz v0, :cond_3

    .line 58
    .line 59
    invoke-virtual {p0}, LQ3/c;->c()LM3/a;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 64
    .line 65
    .line 66
    :cond_3
    const/4 v0, 0x0

    .line 67
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    if-nez v1, :cond_4

    .line 72
    .line 73
    iget-object v1, p0, LQ3/c;->j:Lxf/t;

    .line 74
    .line 75
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    check-cast v1, Landroid/widget/TextView;

    .line 80
    .line 81
    if-eqz v1, :cond_4

    .line 82
    .line 83
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 84
    .line 85
    .line 86
    :cond_4
    invoke-virtual {p0}, LQ3/c;->d()V

    .line 87
    .line 88
    .line 89
    invoke-virtual {p0}, LQ3/c;->c()LM3/a;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    if-eqz v1, :cond_5

    .line 94
    .line 95
    new-instance v3, LN8/a;

    .line 96
    .line 97
    const/16 v4, 0xa

    .line 98
    .line 99
    invoke-direct {v3, p0, v4}, LN8/a;-><init>(Ljava/lang/Object;I)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v1, v3}, LM1/j;->setOnItemChildClickListener(Lcom/chad/library/adapter/base/listener/OnItemChildClickListener;)V

    .line 103
    .line 104
    .line 105
    :cond_5
    new-instance v1, Lcom/flexibank/sdk/customview/model/FlexiBankModelEmptyView;

    .line 106
    .line 107
    iget-object v3, p0, Lo4/b;->a:Landroid/content/Context;

    .line 108
    .line 109
    invoke-direct {v1, v3, v0, v2}, Lcom/flexibank/sdk/customview/model/FlexiBankModelEmptyView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v1}, Lcom/flexibank/sdk/customview/model/FlexiBankModelEmptyView;->getMIv()Landroid/widget/ImageView;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    if-eqz v0, :cond_6

    .line 117
    .line 118
    sget v2, Lcom/flexibank/sdk/o;->fb_no_coupon_icon:I

    .line 119
    .line 120
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 121
    .line 122
    .line 123
    :cond_6
    invoke-virtual {v1}, Lcom/flexibank/sdk/customview/model/FlexiBankModelEmptyView;->getMTv()Landroid/widget/TextView;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    if-eqz v0, :cond_7

    .line 128
    .line 129
    sget v2, Lcom/flexibank/sdk/r;->fb_no_coupon_available:I

    .line 130
    .line 131
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(I)V

    .line 132
    .line 133
    .line 134
    :cond_7
    sget v0, LL6/b;->ppColorBackgroundLight:I

    .line 135
    .line 136
    iget-object v2, p0, Lo4/b;->a:Landroid/content/Context;

    .line 137
    .line 138
    if-nez v2, :cond_9

    .line 139
    .line 140
    sget-object v2, LK3/g;->c:LK3/f;

    .line 141
    .line 142
    invoke-virtual {v2}, LK3/f;->getContext()Landroid/content/Context;

    .line 143
    .line 144
    .line 145
    move-result-object v2

    .line 146
    if-eqz v2, :cond_8

    .line 147
    .line 148
    goto :goto_0

    .line 149
    :cond_8
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 150
    .line 151
    const-string v1, "Required value was null."

    .line 152
    .line 153
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    throw v0

    .line 157
    :cond_9
    :goto_0
    invoke-virtual {v2, v0}, Landroid/content/Context;->getColor(I)I

    .line 158
    .line 159
    .line 160
    move-result v0

    .line 161
    invoke-virtual {v1, v0}, Landroid/view/View;->setBackgroundColor(I)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {p0}, LQ3/c;->c()LM3/a;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    invoke-virtual {v0, v1}, LM1/j;->setEmptyView(Landroid/view/View;)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    invoke-static {p0, v0}, Lo4/b;->b(Lo4/b;Landroid/view/Window;)V

    .line 176
    .line 177
    .line 178
    iget-object v0, p0, LQ3/c;->i:Lxf/t;

    .line 179
    .line 180
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    check-cast v0, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 185
    .line 186
    if-eqz v0, :cond_a

    .line 187
    .line 188
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 189
    .line 190
    .line 191
    :cond_a
    iget-object v0, p0, LQ3/c;->A:Lxf/t;

    .line 192
    .line 193
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 198
    .line 199
    if-eqz v0, :cond_b

    .line 200
    .line 201
    invoke-virtual {v0, p0}, Lcom/palmpay/lib/ui/button/PpButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 202
    .line 203
    .line 204
    :cond_b
    iget-object v0, p0, LQ3/c;->g:Lxf/t;

    .line 205
    .line 206
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    check-cast v0, Landroid/view/View;

    .line 211
    .line 212
    if-eqz v0, :cond_c

    .line 213
    .line 214
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    if-eqz v0, :cond_c

    .line 219
    .line 220
    new-instance v1, LBe/c;

    .line 221
    .line 222
    const/4 v2, 0x3

    .line 223
    invoke-direct {v1, p0, v2}, LBe/c;-><init>(Ljava/lang/Object;I)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 227
    .line 228
    .line 229
    :cond_c
    return-void
.end method

.method public final c()LM3/a;
    .locals 1

    .line 1
    iget-object v0, p0, LQ3/c;->p:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LM3/a;

    .line 8
    .line 9
    return-object v0
.end method

.method public final d()V
    .locals 9

    .line 1
    iget-object v0, p0, LQ3/c;->t:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_3

    .line 4
    .line 5
    invoke-virtual {p0}, LQ3/c;->c()LM3/a;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, LQ3/c;->t:Ljava/util/List;

    .line 10
    .line 11
    const/4 v2, -0x1

    .line 12
    if-eqz v1, :cond_2

    .line 13
    .line 14
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const/4 v3, 0x0

    .line 19
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    if-eqz v4, :cond_2

    .line 24
    .line 25
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    check-cast v4, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;

    .line 30
    .line 31
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;->f()Ljava/lang/Long;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    iget-wide v5, p0, LQ3/c;->v:J

    .line 36
    .line 37
    if-nez v4, :cond_0

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 41
    .line 42
    .line 43
    move-result-wide v7

    .line 44
    cmp-long v4, v7, v5

    .line 45
    .line 46
    if-nez v4, :cond_1

    .line 47
    .line 48
    move v2, v3

    .line 49
    goto :goto_2

    .line 50
    :cond_1
    :goto_1
    add-int/lit8 v3, v3, 0x1

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_2
    :goto_2
    iput v2, v0, LM3/a;->b:I

    .line 54
    .line 55
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0}, LQ3/c;->c()LM3/a;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iget-object v1, p0, LQ3/c;->t:Ljava/util/List;

    .line 63
    .line 64
    check-cast v1, Ljava/util/Collection;

    .line 65
    .line 66
    invoke-virtual {v0, v1}, LM1/j;->setList(Ljava/util/Collection;)V

    .line 67
    .line 68
    .line 69
    :cond_3
    return-void
.end method

.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    const-string/jumbo v0, "v"

    .line 2
    .line 3
    .line 4
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    iget-object v0, p0, LQ3/c;->A:Lxf/t;

    .line 12
    .line 13
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 18
    .line 19
    if-eqz v0, :cond_d

    .line 20
    .line 21
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-ne p1, v0, :cond_d

    .line 26
    .line 27
    iget-object p1, p0, LQ3/c;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;

    .line 28
    .line 29
    if-eqz p1, :cond_e

    .line 30
    .line 31
    invoke-virtual {p0}, LQ3/c;->c()LM3/a;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    const/4 v0, 0x0

    .line 36
    if-eqz p1, :cond_0

    .line 37
    .line 38
    iget p1, p1, LM3/a;->b:I

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    move p1, v0

    .line 42
    :goto_0
    const/4 v1, 0x0

    .line 43
    if-ltz p1, :cond_b

    .line 44
    .line 45
    invoke-virtual {p0}, LQ3/c;->c()LM3/a;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    if-eqz p1, :cond_2

    .line 50
    .line 51
    invoke-virtual {p0}, LQ3/c;->c()LM3/a;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    if-eqz v2, :cond_1

    .line 56
    .line 57
    iget v2, v2, LM3/a;->b:I

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_1
    move v2, v0

    .line 61
    :goto_1
    invoke-virtual {p1, v2}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    check-cast p1, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;

    .line 66
    .line 67
    goto :goto_2

    .line 68
    :cond_2
    move-object p1, v1

    .line 69
    :goto_2
    if-eqz p1, :cond_3

    .line 70
    .line 71
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;->o()Ljava/lang/Boolean;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 76
    .line 77
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    if-eqz v2, :cond_3

    .line 82
    .line 83
    sget v2, Lcom/flexibank/sdk/r;->fb_msg_coupons_myself_only:I

    .line 84
    .line 85
    invoke-static {v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 86
    .line 87
    .line 88
    :cond_3
    iget-object v2, p0, LQ3/c;->B:LO3/k;

    .line 89
    .line 90
    if-eqz v2, :cond_9

    .line 91
    .line 92
    iget-object v2, p0, LQ3/c;->C:Lxf/t;

    .line 93
    .line 94
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    check-cast v2, Landroid/view/View;

    .line 99
    .line 100
    if-eqz v2, :cond_4

    .line 101
    .line 102
    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 103
    .line 104
    .line 105
    :cond_4
    iget-object v0, p0, LQ3/c;->B:LO3/k;

    .line 106
    .line 107
    if-eqz v0, :cond_6

    .line 108
    .line 109
    if-eqz p1, :cond_5

    .line 110
    .line 111
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;->f()Ljava/lang/Long;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    goto :goto_3

    .line 116
    :cond_5
    move-object v2, v1

    .line 117
    :goto_3
    invoke-virtual {v0, v2}, LO3/k;->d(Ljava/lang/Long;)V

    .line 118
    .line 119
    .line 120
    :cond_6
    iget-object v0, p0, LQ3/c;->B:LO3/k;

    .line 121
    .line 122
    if-eqz v0, :cond_8

    .line 123
    .line 124
    if-eqz p1, :cond_7

    .line 125
    .line 126
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;->m()Ljava/lang/Long;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    goto :goto_4

    .line 131
    :cond_7
    move-object v2, v1

    .line 132
    :goto_4
    invoke-virtual {v0, v2}, LO3/k;->c(Ljava/lang/Long;)V

    .line 133
    .line 134
    .line 135
    :cond_8
    invoke-static {p0}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    sget-object v2, LWf/I;->a:Lcg/f;

    .line 140
    .line 141
    sget-object v2, Lag/o;->a:LWf/p0;

    .line 142
    .line 143
    new-instance v3, LQ3/b;

    .line 144
    .line 145
    invoke-direct {v3, v1, p0, p1}, LQ3/b;-><init>(Lkotlin/coroutines/Continuation;LQ3/c;Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;)V

    .line 146
    .line 147
    .line 148
    const/4 p1, 0x2

    .line 149
    invoke-static {v0, v2, v1, v3, p1}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 150
    .line 151
    .line 152
    move-result-object p1

    .line 153
    invoke-virtual {p0, p1}, Lr4/a;->addJob(Lkotlinx/coroutines/Job;)V

    .line 154
    .line 155
    .line 156
    return-void

    .line 157
    :cond_9
    iget-object v0, p0, LQ3/c;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;

    .line 158
    .line 159
    if-eqz v0, :cond_a

    .line 160
    .line 161
    invoke-interface {v0, p1}, Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;->onCouponClick(Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;)V

    .line 162
    .line 163
    .line 164
    :cond_a
    invoke-virtual {p0}, Lr4/a;->dismiss()V

    .line 165
    .line 166
    .line 167
    return-void

    .line 168
    :cond_b
    iget-object p1, p0, LQ3/c;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;

    .line 169
    .line 170
    if-eqz p1, :cond_c

    .line 171
    .line 172
    invoke-interface {p1, v1}, Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;->onCouponClick(Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;)V

    .line 173
    .line 174
    .line 175
    :cond_c
    invoke-virtual {p0}, Lr4/a;->dismiss()V

    .line 176
    .line 177
    .line 178
    return-void

    .line 179
    :cond_d
    iget-object v0, p0, LQ3/c;->i:Lxf/t;

    .line 180
    .line 181
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    check-cast v0, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 186
    .line 187
    if-eqz v0, :cond_e

    .line 188
    .line 189
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 190
    .line 191
    .line 192
    move-result v0

    .line 193
    if-ne p1, v0, :cond_e

    .line 194
    .line 195
    invoke-virtual {p0}, Lr4/a;->dismiss()V

    .line 196
    .line 197
    .line 198
    :cond_e
    return-void
.end method

.method public final show()V
    .locals 0

    .line 1
    invoke-virtual {p0}, LQ3/c;->d()V

    .line 2
    .line 3
    .line 4
    invoke-super {p0}, Lr4/a;->show()V

    .line 5
    .line 6
    .line 7
    return-void
.end method
