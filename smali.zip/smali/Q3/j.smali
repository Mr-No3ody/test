.class public final synthetic LQ3/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LQ3/k;


# direct methods
.method public synthetic constructor <init>(LQ3/k;I)V
    .locals 0

    .line 1
    iput p2, p0, LQ3/j;->a:I

    iput-object p1, p0, LQ3/j;->b:LQ3/k;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LQ3/j;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget v0, Lcom/flexibank/sdk/p;->fb_cdpr_title_tv:I

    .line 7
    .line 8
    iget-object v1, p0, LQ3/j;->b:LQ3/k;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Landroid/widget/TextView;

    .line 15
    .line 16
    return-object v0

    .line 17
    :pswitch_0
    sget v0, Lcom/flexibank/sdk/p;->fb_cdpr_content_tv:I

    .line 18
    .line 19
    iget-object v1, p0, LQ3/j;->b:LQ3/k;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/widget/TextView;

    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_1
    sget v0, Lcom/flexibank/sdk/p;->fb_cdpr_iv:I

    .line 29
    .line 30
    iget-object v1, p0, LQ3/j;->b:LQ3/k;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroid/widget/ImageView;

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_2
    sget v0, Lcom/flexibank/sdk/p;->fb_cdpr_cancel_tv:I

    .line 40
    .line 41
    iget-object v1, p0, LQ3/j;->b:LQ3/k;

    .line 42
    .line 43
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Landroid/widget/TextView;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_3
    sget v0, Lcom/flexibank/sdk/p;->fb_cdpr_confirm_tv:I

    .line 51
    .line 52
    iget-object v1, p0, LQ3/j;->b:LQ3/k;

    .line 53
    .line 54
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 59
    .line 60
    return-object v0

    .line 61
    :pswitch_4
    sget v0, Lcom/flexibank/sdk/p;->fb_tvReward:I

    .line 62
    .line 63
    iget-object v1, p0, LQ3/j;->b:LQ3/k;

    .line 64
    .line 65
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Landroid/widget/TextView;

    .line 70
    .line 71
    return-object v0

    .line 72
    nop

    .line 73
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
