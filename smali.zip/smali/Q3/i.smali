.class public final LQ3/i;
.super Lo4/b;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final e:Lxf/t;

.field public final f:Lxf/t;

.field public final g:Lxf/t;

.field public final i:Lxf/t;

.field public final j:Lxf/t;

.field public o:J

.field public final p:Lxf/t;

.field public final t:Ljava/util/ArrayList;

.field public v:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

.field public w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    sget v0, Lcom/flexibank/sdk/s;->fb_BaseDialogTheme:I

    .line 2
    .line 3
    const-string v1, "context"

    .line 4
    .line 5
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-direct {p0, p1, v1, v0}, Lo4/b;-><init>(Landroid/content/Context;II)V

    .line 10
    .line 11
    .line 12
    new-instance v0, LQ3/g;

    .line 13
    .line 14
    invoke-direct {v0, p0, v1}, LQ3/g;-><init>(LQ3/i;I)V

    .line 15
    .line 16
    .line 17
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, p0, LQ3/i;->e:Lxf/t;

    .line 22
    .line 23
    new-instance v0, LQ3/g;

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    invoke-direct {v0, p0, v1}, LQ3/g;-><init>(LQ3/i;I)V

    .line 27
    .line 28
    .line 29
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iput-object v0, p0, LQ3/i;->f:Lxf/t;

    .line 34
    .line 35
    new-instance v0, LQ3/g;

    .line 36
    .line 37
    const/4 v1, 0x2

    .line 38
    invoke-direct {v0, p0, v1}, LQ3/g;-><init>(LQ3/i;I)V

    .line 39
    .line 40
    .line 41
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iput-object v0, p0, LQ3/i;->g:Lxf/t;

    .line 46
    .line 47
    new-instance v0, LHb/L;

    .line 48
    .line 49
    const/4 v1, 0x3

    .line 50
    invoke-direct {v0, v1, p0, p1}, LHb/L;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    iput-object p1, p0, LQ3/i;->i:Lxf/t;

    .line 58
    .line 59
    new-instance p1, LPa/b0;

    .line 60
    .line 61
    const/4 v0, 0x2

    .line 62
    invoke-direct {p1, v0}, LPa/b0;-><init>(I)V

    .line 63
    .line 64
    .line 65
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    iput-object p1, p0, LQ3/i;->j:Lxf/t;

    .line 70
    .line 71
    new-instance p1, LPa/b0;

    .line 72
    .line 73
    const/4 v0, 0x3

    .line 74
    invoke-direct {p1, v0}, LPa/b0;-><init>(I)V

    .line 75
    .line 76
    .line 77
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    iput-object p1, p0, LQ3/i;->p:Lxf/t;

    .line 82
    .line 83
    new-instance p1, Ljava/util/ArrayList;

    .line 84
    .line 85
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 86
    .line 87
    .line 88
    iput-object p1, p0, LQ3/i;->t:Ljava/util/ArrayList;

    .line 89
    .line 90
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 9

    .line 1
    sget v0, Lcom/flexibank/sdk/q;->fb_dialog_cashier_select_payment_method:I

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->setContentView(I)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    iget-object v2, p0, LQ3/i;->g:Lxf/t;

    .line 12
    .line 13
    if-nez v1, :cond_0

    .line 14
    .line 15
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Landroid/widget/TextView;

    .line 20
    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 24
    .line 25
    .line 26
    :cond_0
    iget-object v0, p0, LQ3/i;->i:Lxf/t;

    .line 27
    .line 28
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 33
    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    iget-object v0, v3, LM3/e;->f:Lxf/t;

    .line 48
    .line 49
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    move-object v4, v0

    .line 54
    check-cast v4, Lcom/flexibank/sdk/cashier/adapter/FlexiBankCashierPaymentMethodAdapter$CashierAddPaymentMethodItem;

    .line 55
    .line 56
    const/4 v7, 0x6

    .line 57
    const/4 v8, 0x0

    .line 58
    const/4 v5, 0x0

    .line 59
    const/4 v6, 0x0

    .line 60
    invoke-static/range {v3 .. v8}, LM1/j;->addFooterView$default(LM1/j;Landroid/view/View;IIILjava/lang/Object;)I

    .line 61
    .line 62
    .line 63
    iget-object v0, v3, LM3/e;->f:Lxf/t;

    .line 64
    .line 65
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    check-cast v1, Lcom/flexibank/sdk/cashier/adapter/FlexiBankCashierPaymentMethodAdapter$CashierAddPaymentMethodItem;

    .line 70
    .line 71
    const/4 v3, 0x0

    .line 72
    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    check-cast v0, Lcom/flexibank/sdk/cashier/adapter/FlexiBankCashierPaymentMethodAdapter$CashierAddPaymentMethodItem;

    .line 80
    .line 81
    invoke-virtual {v0}, Lcom/flexibank/sdk/cashier/adapter/FlexiBankCashierPaymentMethodAdapter$CashierAddPaymentMethodItem;->d()V

    .line 82
    .line 83
    .line 84
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    new-instance v1, LQ3/h;

    .line 89
    .line 90
    invoke-direct {v1, p0}, LQ3/h;-><init>(LQ3/i;)V

    .line 91
    .line 92
    .line 93
    iput-object v1, v0, LM3/e;->e:LQ3/h;

    .line 94
    .line 95
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    invoke-static {p0, v0}, Lo4/b;->b(Lo4/b;Landroid/view/Window;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    check-cast v0, Landroid/widget/TextView;

    .line 107
    .line 108
    if-eqz v0, :cond_2

    .line 109
    .line 110
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 111
    .line 112
    .line 113
    :cond_2
    iget-object v0, p0, LQ3/i;->f:Lxf/t;

    .line 114
    .line 115
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    check-cast v0, Landroid/widget/ImageView;

    .line 120
    .line 121
    if-eqz v0, :cond_3

    .line 122
    .line 123
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 124
    .line 125
    .line 126
    :cond_3
    iget-object v0, p0, LQ3/i;->e:Lxf/t;

    .line 127
    .line 128
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    check-cast v0, Landroid/view/View;

    .line 133
    .line 134
    if-eqz v0, :cond_4

    .line 135
    .line 136
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    if-eqz v0, :cond_4

    .line 141
    .line 142
    new-instance v1, LBe/c;

    .line 143
    .line 144
    const/4 v2, 0x4

    .line 145
    invoke-direct {v1, p0, v2}, LBe/c;-><init>(Ljava/lang/Object;I)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 149
    .line 150
    .line 151
    :cond_4
    return-void
.end method

.method public final c()LM3/e;
    .locals 1

    .line 1
    iget-object v0, p0, LQ3/i;->j:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LM3/e;

    .line 8
    .line 9
    return-object v0
.end method

.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    const-string/jumbo v0, "v"

    .line 2
    .line 3
    .line 4
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    sget v0, Lcom/flexibank/sdk/p;->fb_cdspm_close_iv:I

    .line 12
    .line 13
    if-ne p1, v0, :cond_0

    .line 14
    .line 15
    invoke-virtual {p0}, Lo4/b;->dismiss()V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public final show()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/app/Dialog;->show()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, LM1/j;->hasHeaderLayout()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    invoke-virtual {v0}, LM1/j;->removeAllHeaderView()V

    .line 15
    .line 16
    .line 17
    :cond_0
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iget-wide v1, p0, LQ3/i;->o:J

    .line 29
    .line 30
    iput-wide v1, v0, LM3/e;->c:J

    .line 31
    .line 32
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    iget-object v1, p0, LQ3/i;->p:Lxf/t;

    .line 37
    .line 38
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    check-cast v1, Ljava/util/List;

    .line 43
    .line 44
    check-cast v1, Ljava/util/Collection;

    .line 45
    .line 46
    invoke-virtual {v0, v1}, LM1/j;->setList(Ljava/util/Collection;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    iget-object v1, p0, LQ3/i;->t:Ljava/util/ArrayList;

    .line 54
    .line 55
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    const-string v2, "addablePaymentMethods"

    .line 59
    .line 60
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    iget-object v2, v0, LM3/e;->d:Ljava/util/ArrayList;

    .line 64
    .line 65
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 69
    .line 70
    .line 71
    iget-object v0, v0, LM3/e;->f:Lxf/t;

    .line 72
    .line 73
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    check-cast v0, Lcom/flexibank/sdk/cashier/adapter/FlexiBankCashierPaymentMethodAdapter$CashierAddPaymentMethodItem;

    .line 78
    .line 79
    invoke-virtual {v0}, Lcom/flexibank/sdk/cashier/adapter/FlexiBankCashierPaymentMethodAdapter$CashierAddPaymentMethodItem;->d()V

    .line 80
    .line 81
    .line 82
    iget-object v0, p0, LQ3/i;->v:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 83
    .line 84
    if-eqz v0, :cond_1

    .line 85
    .line 86
    invoke-virtual {p0}, LQ3/i;->c()LM3/e;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 91
    .line 92
    .line 93
    const-string/jumbo v2, "selectMethod"

    .line 94
    .line 95
    .line 96
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    iput-object v0, v1, LM3/e;->b:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 100
    .line 101
    :cond_1
    return-void
.end method
