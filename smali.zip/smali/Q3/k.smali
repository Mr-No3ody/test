.class public final LQ3/k;
.super Lo4/b;
.source "SourceFile"


# instance fields
.field public final e:Lxf/t;

.field public final f:Lxf/t;

.field public final g:Lxf/t;

.field public final i:Lxf/t;

.field public final j:Lxf/t;

.field public final o:Lxf/t;

.field public p:LSd/b;


# direct methods
.method public constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;)V
    .locals 2

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x6

    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-direct {p0, p1, v1, v0, v1}, Lo4/b;-><init>(Landroid/content/Context;III)V

    .line 9
    .line 10
    .line 11
    new-instance p1, LQ3/j;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-direct {p1, p0, v0}, LQ3/j;-><init>(LQ3/k;I)V

    .line 15
    .line 16
    .line 17
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iput-object p1, p0, LQ3/k;->e:Lxf/t;

    .line 22
    .line 23
    new-instance p1, LQ3/j;

    .line 24
    .line 25
    const/4 v0, 0x1

    .line 26
    invoke-direct {p1, p0, v0}, LQ3/j;-><init>(LQ3/k;I)V

    .line 27
    .line 28
    .line 29
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iput-object p1, p0, LQ3/k;->f:Lxf/t;

    .line 34
    .line 35
    new-instance p1, LQ3/j;

    .line 36
    .line 37
    const/4 v0, 0x2

    .line 38
    invoke-direct {p1, p0, v0}, LQ3/j;-><init>(LQ3/k;I)V

    .line 39
    .line 40
    .line 41
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    iput-object p1, p0, LQ3/k;->g:Lxf/t;

    .line 46
    .line 47
    new-instance p1, LQ3/j;

    .line 48
    .line 49
    const/4 v0, 0x3

    .line 50
    invoke-direct {p1, p0, v0}, LQ3/j;-><init>(LQ3/k;I)V

    .line 51
    .line 52
    .line 53
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    iput-object p1, p0, LQ3/k;->i:Lxf/t;

    .line 58
    .line 59
    new-instance p1, LQ3/j;

    .line 60
    .line 61
    const/4 v0, 0x4

    .line 62
    invoke-direct {p1, p0, v0}, LQ3/j;-><init>(LQ3/k;I)V

    .line 63
    .line 64
    .line 65
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    iput-object p1, p0, LQ3/k;->j:Lxf/t;

    .line 70
    .line 71
    new-instance p1, LQ3/j;

    .line 72
    .line 73
    const/4 v0, 0x5

    .line 74
    invoke-direct {p1, p0, v0}, LQ3/j;-><init>(LQ3/k;I)V

    .line 75
    .line 76
    .line 77
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    iput-object p1, p0, LQ3/k;->o:Lxf/t;

    .line 82
    .line 83
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    .line 1
    sget v0, Lcom/flexibank/sdk/q;->fb_dialog_payment_reward:I

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->setContentView(I)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    const/16 v1, 0x11

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/view/Window;->setGravity(I)V

    .line 15
    .line 16
    .line 17
    :cond_0
    if-eqz v0, :cond_1

    .line 18
    .line 19
    sget v1, Lcom/flexibank/sdk/s;->fb_dialog_bottom_in_out:I

    .line 20
    .line 21
    invoke-virtual {v0, v1}, Landroid/view/Window;->setWindowAnimations(I)V

    .line 22
    .line 23
    .line 24
    :cond_1
    if-eqz v0, :cond_2

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    goto :goto_0

    .line 31
    :cond_2
    const/4 v1, 0x0

    .line 32
    :goto_0
    if-eqz v1, :cond_3

    .line 33
    .line 34
    invoke-static {}, Lcom/transsnet/palmpay/util/ScreenUtils;->getScreenWidth()I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    const/high16 v3, 0x41f00000    # 30.0f

    .line 39
    .line 40
    invoke-static {v3}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    sub-int/2addr v2, v3

    .line 45
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 46
    .line 47
    :cond_3
    if-eqz v1, :cond_4

    .line 48
    .line 49
    const/4 v2, -0x2

    .line 50
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 51
    .line 52
    :cond_4
    if-eqz v0, :cond_5

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 55
    .line 56
    .line 57
    :cond_5
    new-instance v0, LNc/x;

    .line 58
    .line 59
    const/16 v1, 0xe

    .line 60
    .line 61
    invoke-direct {v0, p0, v1}, LNc/x;-><init>(Ljava/lang/Object;I)V

    .line 62
    .line 63
    .line 64
    iget-object v1, p0, LQ3/k;->g:Lxf/t;

    .line 65
    .line 66
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    const-string v2, "getValue(...)"

    .line 71
    .line 72
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    check-cast v1, Landroid/widget/TextView;

    .line 76
    .line 77
    invoke-virtual {v1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 78
    .line 79
    .line 80
    iget-object v1, p0, LQ3/k;->f:Lxf/t;

    .line 81
    .line 82
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    check-cast v1, Lcom/palmpay/lib/ui/button/PpButton;

    .line 90
    .line 91
    invoke-virtual {v1, v0}, Lcom/palmpay/lib/ui/button/PpButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 92
    .line 93
    .line 94
    iget-object v0, p0, LQ3/k;->o:Lxf/t;

    .line 95
    .line 96
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    check-cast v0, Landroid/widget/TextView;

    .line 104
    .line 105
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 106
    .line 107
    .line 108
    move-result-wide v1

    .line 109
    const/4 v3, 0x2

    .line 110
    int-to-long v3, v3

    .line 111
    rem-long/2addr v1, v3

    .line 112
    const-wide/16 v3, 0x0

    .line 113
    .line 114
    cmp-long v1, v1, v3

    .line 115
    .line 116
    if-nez v1, :cond_6

    .line 117
    .line 118
    sget v1, Lcom/flexibank/sdk/r;->fb_payment_not_complete:I

    .line 119
    .line 120
    goto :goto_1

    .line 121
    :cond_6
    sget v1, Lcom/flexibank/sdk/r;->fb_dont_miss_out:I

    .line 122
    .line 123
    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 124
    .line 125
    .line 126
    const/4 v0, 0x0

    .line 127
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 128
    .line 129
    .line 130
    return-void
.end method
