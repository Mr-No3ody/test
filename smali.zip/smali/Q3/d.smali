.class public final LQ3/d;
.super Lo4/b;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public e:Lx4/j;

.field public f:LP8/a;


# virtual methods
.method public final a()V
    .locals 12

    .line 1
    sget v0, Lcom/flexibank/sdk/p;->fb_viewRoot:I

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sget v1, Lcom/flexibank/sdk/p;->fb_feeList:I

    .line 8
    .line 9
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    move-object v5, v2

    .line 14
    check-cast v5, Landroidx/recyclerview/widget/RecyclerView;

    .line 15
    .line 16
    if-eqz v5, :cond_4

    .line 17
    .line 18
    sget v1, Lcom/flexibank/sdk/p;->fb_ivClose:I

    .line 19
    .line 20
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    move-object v6, v2

    .line 25
    check-cast v6, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 26
    .line 27
    if-eqz v6, :cond_4

    .line 28
    .line 29
    sget v1, Lcom/flexibank/sdk/p;->fb_tvConfirm:I

    .line 30
    .line 31
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    move-object v7, v2

    .line 36
    check-cast v7, Lcom/palmpay/lib/ui/button/PpButton;

    .line 37
    .line 38
    if-eqz v7, :cond_4

    .line 39
    .line 40
    sget v1, Lcom/flexibank/sdk/p;->fb_tvTitle:I

    .line 41
    .line 42
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    move-object v8, v2

    .line 47
    check-cast v8, Landroid/widget/TextView;

    .line 48
    .line 49
    if-eqz v8, :cond_4

    .line 50
    .line 51
    sget v1, Lcom/flexibank/sdk/p;->fb_tvTotalAmount:I

    .line 52
    .line 53
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    move-object v9, v2

    .line 58
    check-cast v9, Landroid/widget/TextView;

    .line 59
    .line 60
    if-eqz v9, :cond_4

    .line 61
    .line 62
    sget v1, Lcom/flexibank/sdk/p;->fb_tvTotalName:I

    .line 63
    .line 64
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    move-object v10, v2

    .line 69
    check-cast v10, Landroid/widget/TextView;

    .line 70
    .line 71
    if-eqz v10, :cond_4

    .line 72
    .line 73
    move-object v4, v0

    .line 74
    check-cast v4, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 75
    .line 76
    new-instance v3, Lx4/j;

    .line 77
    .line 78
    const/4 v11, 0x0

    .line 79
    invoke-direct/range {v3 .. v11}, Lx4/j;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/recyclerview/widget/RecyclerView;Lcom/mikepenz/iconics/view/IconicsImageView;Lcom/palmpay/lib/ui/button/PpButton;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;I)V

    .line 80
    .line 81
    .line 82
    iput-object v3, p0, LQ3/d;->e:Lx4/j;

    .line 83
    .line 84
    new-instance v0, LP8/a;

    .line 85
    .line 86
    sget v1, Lcom/flexibank/sdk/q;->fb_layout_fee_detail_item:I

    .line 87
    .line 88
    const/4 v2, 0x0

    .line 89
    const/4 v3, 0x1

    .line 90
    invoke-direct {v0, v1, v2, v3}, LP8/a;-><init>(ILjava/util/List;I)V

    .line 91
    .line 92
    .line 93
    iput-object v0, p0, LQ3/d;->f:LP8/a;

    .line 94
    .line 95
    iget-object v0, p0, LQ3/d;->e:Lx4/j;

    .line 96
    .line 97
    if-eqz v0, :cond_0

    .line 98
    .line 99
    iget-object v0, v0, Lx4/j;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 100
    .line 101
    new-instance v1, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 102
    .line 103
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    const/4 v3, 0x1

    .line 108
    const/4 v4, 0x0

    .line 109
    invoke-direct {v1, v2, v3, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 113
    .line 114
    .line 115
    :cond_0
    iget-object v0, p0, LQ3/d;->e:Lx4/j;

    .line 116
    .line 117
    if-eqz v0, :cond_1

    .line 118
    .line 119
    iget-object v0, v0, Lx4/j;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 120
    .line 121
    iget-object v1, p0, LQ3/d;->f:LP8/a;

    .line 122
    .line 123
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 124
    .line 125
    .line 126
    :cond_1
    iget-object v0, p0, LQ3/d;->e:Lx4/j;

    .line 127
    .line 128
    if-eqz v0, :cond_2

    .line 129
    .line 130
    iget-object v0, v0, Lx4/j;->d:Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 131
    .line 132
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 133
    .line 134
    .line 135
    :cond_2
    iget-object v0, p0, LQ3/d;->e:Lx4/j;

    .line 136
    .line 137
    if-eqz v0, :cond_3

    .line 138
    .line 139
    iget-object v0, v0, Lx4/j;->e:Lcom/palmpay/lib/ui/button/PpButton;

    .line 140
    .line 141
    invoke-virtual {v0, p0}, Lcom/palmpay/lib/ui/button/PpButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 142
    .line 143
    .line 144
    :cond_3
    return-void

    .line 145
    :cond_4
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    new-instance v1, Ljava/lang/NullPointerException;

    .line 154
    .line 155
    const-string v2, "Missing required view with ID: "

    .line 156
    .line 157
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    invoke-direct {v1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    throw v1
.end method
