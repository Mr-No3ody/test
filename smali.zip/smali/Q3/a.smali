.class public final synthetic LQ3/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LQ3/c;


# direct methods
.method public synthetic constructor <init>(LQ3/c;I)V
    .locals 0

    .line 1
    iput p2, p0, LQ3/a;->a:I

    iput-object p1, p0, LQ3/a;->b:LQ3/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LQ3/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget v0, Lcom/flexibank/sdk/p;->fb_loadingView:I

    .line 7
    .line 8
    iget-object v1, p0, LQ3/a;->b:LQ3/c;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0

    .line 15
    :pswitch_0
    sget v0, Lcom/flexibank/sdk/p;->fb_cdsc_confirm:I

    .line 16
    .line 17
    iget-object v1, p0, LQ3/a;->b:LQ3/c;

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 24
    .line 25
    return-object v0

    .line 26
    :pswitch_1
    sget v0, Lcom/flexibank/sdk/p;->fb_cdsc_rcv:I

    .line 27
    .line 28
    iget-object v1, p0, LQ3/a;->b:LQ3/c;

    .line 29
    .line 30
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 35
    .line 36
    return-object v0

    .line 37
    :pswitch_2
    sget v0, Lcom/flexibank/sdk/p;->fb_cdsc_title_tv:I

    .line 38
    .line 39
    iget-object v1, p0, LQ3/a;->b:LQ3/c;

    .line 40
    .line 41
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    check-cast v0, Landroid/widget/TextView;

    .line 46
    .line 47
    return-object v0

    .line 48
    :pswitch_3
    sget v0, Lcom/flexibank/sdk/p;->fb_cdsc_close_iv:I

    .line 49
    .line 50
    iget-object v1, p0, LQ3/a;->b:LQ3/c;

    .line 51
    .line 52
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    check-cast v0, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 57
    .line 58
    return-object v0

    .line 59
    :pswitch_4
    sget v0, Lcom/flexibank/sdk/p;->fb_viewRoot:I

    .line 60
    .line 61
    iget-object v1, p0, LQ3/a;->b:LQ3/c;

    .line 62
    .line 63
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    return-object v0

    .line 68
    nop

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
