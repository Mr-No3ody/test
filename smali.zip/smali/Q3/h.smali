.class public final LQ3/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/flexibank/sdk/cashier/adapter/FlexiBankCashierPaymentMethodAdapter$OnPaymentMethodClickListener;


# instance fields
.field public final synthetic a:LQ3/i;


# direct methods
.method public constructor <init>(LQ3/i;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LQ3/h;->a:LQ3/i;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onAddNewBankAccountClick()V
    .locals 2

    .line 1
    iget-object v0, p0, LQ3/h;->a:LQ3/i;

    .line 2
    .line 3
    iget-object v1, v0, LQ3/i;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    invoke-interface {v1}, Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;->onAddNewBankAccountClick()V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-virtual {v0}, Lo4/b;->dismiss()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onAddNewBankCardClick()V
    .locals 2

    .line 1
    iget-object v0, p0, LQ3/h;->a:LQ3/i;

    .line 2
    .line 3
    iget-object v1, v0, LQ3/i;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    invoke-interface {v1}, Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;->onAddNewBankCardClick()V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-virtual {v0}, Lo4/b;->dismiss()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onAddNewBankCardOrBankAccountClick()V
    .locals 2

    .line 1
    iget-object v0, p0, LQ3/h;->a:LQ3/i;

    .line 2
    .line 3
    iget-object v1, v0, LQ3/i;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    invoke-interface {v1}, Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;->onAddNewBankCardOrBankAccountClick()V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-virtual {v0}, Lo4/b;->dismiss()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onPaymentMethodClick(ILcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;)V
    .locals 4

    .line 1
    if-eqz p2, :cond_0

    .line 2
    .line 3
    invoke-virtual {p2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->e()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    const-wide/16 v0, 0x0

    .line 9
    .line 10
    :goto_0
    iget-object p1, p0, LQ3/h;->a:LQ3/i;

    .line 11
    .line 12
    iget-wide v2, p1, LQ3/i;->o:J

    .line 13
    .line 14
    cmp-long v0, v0, v2

    .line 15
    .line 16
    if-gez v0, :cond_1

    .line 17
    .line 18
    if-eqz p2, :cond_1

    .line 19
    .line 20
    invoke-virtual {p2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->u()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    const/4 v1, 0x1

    .line 25
    if-ne v0, v1, :cond_1

    .line 26
    .line 27
    invoke-virtual {p1}, Lo4/b;->dismiss()V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_1
    iget-object p1, p1, LQ3/i;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;

    .line 32
    .line 33
    if-eqz p1, :cond_2

    .line 34
    .line 35
    invoke-interface {p1, p2}, Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;->onPaymentMethodClick(Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;)V

    .line 36
    .line 37
    .line 38
    :cond_2
    return-void
.end method

.method public final onUseNewMobileWalletClick()V
    .locals 2

    .line 1
    iget-object v0, p0, LQ3/h;->a:LQ3/i;

    .line 2
    .line 3
    iget-object v1, v0, LQ3/i;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    invoke-interface {v1}, Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;->onUseNewMobileWalletClick()V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-virtual {v0}, Lo4/b;->dismiss()V

    .line 11
    .line 12
    .line 13
    return-void
.end method
