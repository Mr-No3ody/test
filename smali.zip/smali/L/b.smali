.class public final LL/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static cardview_dark_background:I = 0x7f06003f

.field public static cardview_light_background:I = 0x7f060040

.field public static cardview_shadow_end_color:I = 0x7f060041

.field public static cardview_shadow_start_color:I = 0x7f060042


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
