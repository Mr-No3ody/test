.class public final LL/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static cardBackgroundColor:I = 0x7f040116

.field public static cardCornerRadius:I = 0x7f040117

.field public static cardElevation:I = 0x7f040118

.field public static cardMaxElevation:I = 0x7f04011a

.field public static cardPreventCornerOverlap:I = 0x7f04011b

.field public static cardUseCompatPadding:I = 0x7f04011c

.field public static cardViewStyle:I = 0x7f04011d

.field public static contentPadding:I = 0x7f0401f0

.field public static contentPaddingBottom:I = 0x7f0401f1

.field public static contentPaddingLeft:I = 0x7f0401f3

.field public static contentPaddingRight:I = 0x7f0401f4

.field public static contentPaddingTop:I = 0x7f0401f6


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
