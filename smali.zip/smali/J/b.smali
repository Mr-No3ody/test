.class public abstract LJ/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static volatile a:Landroidx/camera/core/impl/y0;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    sget-object v0, Landroidx/camera/core/impl/v0;->c:Landroidx/camera/core/impl/v0;

    .line 2
    .line 3
    invoke-static {}, Lorg/chromium/support_lib_boundary/util/b;->u()Landroidx/camera/core/impl/utils/executor/a;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    new-instance v2, LJ/a;

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    invoke-direct {v2, v3}, LJ/a;-><init>(I)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    new-instance v3, Landroidx/camera/core/impl/u0;

    .line 17
    .line 18
    invoke-direct {v3, v2}, Landroidx/camera/core/impl/u0;-><init>(Landroidx/core/util/Consumer;)V

    .line 19
    .line 20
    .line 21
    iget-object v0, v0, Landroidx/camera/core/impl/v0;->a:Landroidx/camera/core/impl/n0;

    .line 22
    .line 23
    invoke-virtual {v0, v1, v3}, Landroidx/camera/core/impl/J0;->addObserver(Ljava/util/concurrent/Executor;Landroidx/camera/core/impl/Observable$Observer;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method
