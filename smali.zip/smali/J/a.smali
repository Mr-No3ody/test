.class public final synthetic LJ/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/core/util/Consumer;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LJ/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 17

    .line 1
    const/16 v0, 0x21

    .line 2
    .line 3
    const-string v1, "HUAWEI"

    .line 4
    .line 5
    const-string v2, "moto e5 play"

    .line 6
    .line 7
    const-string v3, "Samsung"

    .line 8
    .line 9
    const-string v4, "mha-l29"

    .line 10
    .line 11
    const-string v5, "Huawei"

    .line 12
    .line 13
    const-string v6, "motorola"

    .line 14
    .line 15
    const-string v7, "SAMSUNG"

    .line 16
    .line 17
    const-string v8, "DeviceQuirks"

    .line 18
    .line 19
    const/4 v10, 0x0

    .line 20
    move-object/from16 v11, p0

    .line 21
    .line 22
    iget v12, v11, LJ/a;->a:I

    .line 23
    .line 24
    packed-switch v12, :pswitch_data_0

    .line 25
    .line 26
    .line 27
    move-object/from16 v0, p1

    .line 28
    .line 29
    check-cast v0, Landroidx/camera/core/impl/t0;

    .line 30
    .line 31
    new-instance v1, Landroidx/camera/core/impl/y0;

    .line 32
    .line 33
    new-instance v12, Ljava/util/ArrayList;

    .line 34
    .line 35
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 36
    .line 37
    .line 38
    const-class v13, Landroidx/camera/video/internal/compat/quirk/MediaFormatMustNotUseFrameRateToFindEncoderQuirk;

    .line 39
    .line 40
    invoke-virtual {v0, v13, v10}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 41
    .line 42
    .line 43
    move-result v13

    .line 44
    if-eqz v13, :cond_0

    .line 45
    .line 46
    new-instance v13, Landroidx/camera/video/internal/compat/quirk/MediaFormatMustNotUseFrameRateToFindEncoderQuirk;

    .line 47
    .line 48
    invoke-direct {v13}, Landroidx/camera/video/internal/compat/quirk/MediaFormatMustNotUseFrameRateToFindEncoderQuirk;-><init>()V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    :cond_0
    sget-object v13, Landroidx/camera/video/internal/compat/quirk/MediaCodecInfoReportIncorrectInfoQuirk;->a:Ljava/util/List;

    .line 55
    .line 56
    sget-object v13, Landroid/os/Build;->BRAND:Ljava/lang/String;

    .line 57
    .line 58
    const-string v14, "Nokia"

    .line 59
    .line 60
    invoke-virtual {v14, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 61
    .line 62
    .line 63
    move-result v15

    .line 64
    const-string v9, "positivo"

    .line 65
    .line 66
    const-string/jumbo v10, "twist 2 pro"

    .line 67
    .line 68
    .line 69
    move-object/from16 v16, v8

    .line 70
    .line 71
    const-string v8, "moto c"

    .line 72
    .line 73
    const-string v11, "Nokia 1"

    .line 74
    .line 75
    if-eqz v15, :cond_1

    .line 76
    .line 77
    sget-object v15, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 78
    .line 79
    invoke-virtual {v11, v15}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 80
    .line 81
    .line 82
    move-result v15

    .line 83
    if-eqz v15, :cond_1

    .line 84
    .line 85
    :goto_0
    move-object/from16 p1, v1

    .line 86
    .line 87
    goto/16 :goto_1

    .line 88
    .line 89
    :cond_1
    invoke-virtual {v6, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 90
    .line 91
    .line 92
    move-result v15

    .line 93
    if-eqz v15, :cond_2

    .line 94
    .line 95
    sget-object v15, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 96
    .line 97
    invoke-virtual {v8, v15}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 98
    .line 99
    .line 100
    move-result v15

    .line 101
    if-eqz v15, :cond_2

    .line 102
    .line 103
    goto :goto_0

    .line 104
    :cond_2
    const-string v15, "infinix"

    .line 105
    .line 106
    invoke-virtual {v15, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 107
    .line 108
    .line 109
    move-result v15

    .line 110
    if-eqz v15, :cond_3

    .line 111
    .line 112
    const-string v15, "infinix x650"

    .line 113
    .line 114
    move-object/from16 p1, v1

    .line 115
    .line 116
    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 117
    .line 118
    invoke-virtual {v15, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    if-eqz v1, :cond_4

    .line 123
    .line 124
    goto :goto_1

    .line 125
    :cond_3
    move-object/from16 p1, v1

    .line 126
    .line 127
    :cond_4
    const-string v1, "LGE"

    .line 128
    .line 129
    invoke-virtual {v1, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 130
    .line 131
    .line 132
    move-result v1

    .line 133
    if-eqz v1, :cond_5

    .line 134
    .line 135
    const-string v1, "LG-X230"

    .line 136
    .line 137
    sget-object v15, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 138
    .line 139
    invoke-virtual {v1, v15}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    if-eqz v1, :cond_5

    .line 144
    .line 145
    goto :goto_1

    .line 146
    :cond_5
    invoke-virtual {v5, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    if-eqz v1, :cond_6

    .line 151
    .line 152
    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 153
    .line 154
    invoke-virtual {v4, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    if-eqz v1, :cond_6

    .line 159
    .line 160
    goto :goto_1

    .line 161
    :cond_6
    const-string v1, "Redmi"

    .line 162
    .line 163
    invoke-virtual {v1, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 164
    .line 165
    .line 166
    move-result v1

    .line 167
    if-eqz v1, :cond_7

    .line 168
    .line 169
    const-string v1, "Redmi Note 8 Pro"

    .line 170
    .line 171
    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 172
    .line 173
    invoke-virtual {v1, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 174
    .line 175
    .line 176
    move-result v1

    .line 177
    if-eqz v1, :cond_7

    .line 178
    .line 179
    goto :goto_1

    .line 180
    :cond_7
    invoke-virtual {v9, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 181
    .line 182
    .line 183
    move-result v1

    .line 184
    if-eqz v1, :cond_8

    .line 185
    .line 186
    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 187
    .line 188
    invoke-virtual {v10, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 189
    .line 190
    .line 191
    move-result v1

    .line 192
    if-eqz v1, :cond_8

    .line 193
    .line 194
    goto :goto_1

    .line 195
    :cond_8
    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 196
    .line 197
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 198
    .line 199
    invoke-virtual {v1, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object v1

    .line 203
    sget-object v4, Landroidx/camera/video/internal/compat/quirk/MediaCodecInfoReportIncorrectInfoQuirk;->a:Ljava/util/List;

    .line 204
    .line 205
    invoke-interface {v4, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    move-result v1

    .line 209
    if-eqz v1, :cond_9

    .line 210
    .line 211
    :goto_1
    const/4 v1, 0x1

    .line 212
    goto :goto_2

    .line 213
    :cond_9
    const/4 v1, 0x0

    .line 214
    :goto_2
    const-class v4, Landroidx/camera/video/internal/compat/quirk/MediaCodecInfoReportIncorrectInfoQuirk;

    .line 215
    .line 216
    invoke-virtual {v0, v4, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 217
    .line 218
    .line 219
    move-result v1

    .line 220
    if-eqz v1, :cond_a

    .line 221
    .line 222
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/MediaCodecInfoReportIncorrectInfoQuirk;

    .line 223
    .line 224
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/MediaCodecInfoReportIncorrectInfoQuirk;-><init>()V

    .line 225
    .line 226
    .line 227
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 228
    .line 229
    .line 230
    :cond_a
    const-class v1, Landroidx/camera/video/internal/compat/quirk/DeactivateEncoderSurfaceBeforeStopEncoderQuirk;

    .line 231
    .line 232
    const/4 v4, 0x0

    .line 233
    invoke-virtual {v0, v1, v4}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 234
    .line 235
    .line 236
    move-result v1

    .line 237
    if-eqz v1, :cond_b

    .line 238
    .line 239
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/DeactivateEncoderSurfaceBeforeStopEncoderQuirk;

    .line 240
    .line 241
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/DeactivateEncoderSurfaceBeforeStopEncoderQuirk;-><init>()V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 245
    .line 246
    .line 247
    :cond_b
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 248
    .line 249
    const/16 v4, 0x1f

    .line 250
    .line 251
    if-lt v1, v4, :cond_c

    .line 252
    .line 253
    sget-object v4, Landroidx/camera/video/internal/compat/quirk/CameraUseInconsistentTimebaseQuirk;->b:Ljava/util/HashSet;

    .line 254
    .line 255
    invoke-static {}, LU2/D;->A()Ljava/lang/String;

    .line 256
    .line 257
    .line 258
    move-result-object v5

    .line 259
    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 260
    .line 261
    .line 262
    move-result-object v5

    .line 263
    invoke-virtual {v4, v5}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    move-result v4

    .line 267
    if-eqz v4, :cond_d

    .line 268
    .line 269
    goto :goto_3

    .line 270
    :cond_c
    sget-object v4, Landroidx/camera/video/internal/compat/quirk/CameraUseInconsistentTimebaseQuirk;->a:Ljava/util/HashSet;

    .line 271
    .line 272
    :cond_d
    invoke-virtual {v7, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 273
    .line 274
    .line 275
    move-result v4

    .line 276
    if-eqz v4, :cond_e

    .line 277
    .line 278
    sget-object v4, Landroidx/camera/video/internal/compat/quirk/CameraUseInconsistentTimebaseQuirk;->a:Ljava/util/HashSet;

    .line 279
    .line 280
    sget-object v5, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    .line 281
    .line 282
    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 283
    .line 284
    .line 285
    move-result-object v5

    .line 286
    invoke-virtual {v4, v5}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 287
    .line 288
    .line 289
    move-result v4

    .line 290
    if-eqz v4, :cond_e

    .line 291
    .line 292
    goto :goto_3

    .line 293
    :cond_e
    sget-object v4, Landroidx/camera/video/internal/compat/quirk/CameraUseInconsistentTimebaseQuirk;->c:Ljava/util/HashSet;

    .line 294
    .line 295
    sget-object v5, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 296
    .line 297
    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v5

    .line 301
    invoke-virtual {v4, v5}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    move-result v4

    .line 305
    if-eqz v4, :cond_f

    .line 306
    .line 307
    :goto_3
    const/4 v4, 0x1

    .line 308
    goto :goto_4

    .line 309
    :cond_f
    const/4 v4, 0x0

    .line 310
    :goto_4
    const-class v5, Landroidx/camera/video/internal/compat/quirk/CameraUseInconsistentTimebaseQuirk;

    .line 311
    .line 312
    invoke-virtual {v0, v5, v4}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 313
    .line 314
    .line 315
    move-result v4

    .line 316
    if-eqz v4, :cond_10

    .line 317
    .line 318
    new-instance v4, Landroidx/camera/video/internal/compat/quirk/CameraUseInconsistentTimebaseQuirk;

    .line 319
    .line 320
    invoke-direct {v4}, Landroidx/camera/video/internal/compat/quirk/CameraUseInconsistentTimebaseQuirk;-><init>()V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 324
    .line 325
    .line 326
    :cond_10
    invoke-static {}, Landroidx/camera/video/internal/compat/quirk/ReportedVideoQualityNotSupportedQuirk;->a()Z

    .line 327
    .line 328
    .line 329
    move-result v4

    .line 330
    const-string/jumbo v5, "vivo 1820"

    .line 331
    .line 332
    .line 333
    if-nez v4, :cond_13

    .line 334
    .line 335
    invoke-static {}, Landroidx/camera/video/internal/compat/quirk/ReportedVideoQualityNotSupportedQuirk;->b()Z

    .line 336
    .line 337
    .line 338
    move-result v4

    .line 339
    if-nez v4, :cond_13

    .line 340
    .line 341
    const-string v4, "Vivo"

    .line 342
    .line 343
    invoke-virtual {v4, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 344
    .line 345
    .line 346
    move-result v4

    .line 347
    if-eqz v4, :cond_11

    .line 348
    .line 349
    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 350
    .line 351
    invoke-virtual {v5, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 352
    .line 353
    .line 354
    move-result v4

    .line 355
    if-eqz v4, :cond_11

    .line 356
    .line 357
    goto :goto_5

    .line 358
    :cond_11
    invoke-static {}, Landroidx/camera/video/internal/compat/quirk/ReportedVideoQualityNotSupportedQuirk;->c()Z

    .line 359
    .line 360
    .line 361
    move-result v4

    .line 362
    if-nez v4, :cond_13

    .line 363
    .line 364
    invoke-static {}, Landroidx/camera/video/internal/compat/quirk/ReportedVideoQualityNotSupportedQuirk;->d()Z

    .line 365
    .line 366
    .line 367
    move-result v4

    .line 368
    if-eqz v4, :cond_12

    .line 369
    .line 370
    goto :goto_5

    .line 371
    :cond_12
    const/4 v4, 0x0

    .line 372
    goto :goto_6

    .line 373
    :cond_13
    :goto_5
    const/4 v4, 0x1

    .line 374
    :goto_6
    const-class v7, Landroidx/camera/video/internal/compat/quirk/ReportedVideoQualityNotSupportedQuirk;

    .line 375
    .line 376
    invoke-virtual {v0, v7, v4}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 377
    .line 378
    .line 379
    move-result v4

    .line 380
    if-eqz v4, :cond_14

    .line 381
    .line 382
    new-instance v4, Landroidx/camera/video/internal/compat/quirk/ReportedVideoQualityNotSupportedQuirk;

    .line 383
    .line 384
    invoke-direct {v4}, Landroidx/camera/video/internal/compat/quirk/ReportedVideoQualityNotSupportedQuirk;-><init>()V

    .line 385
    .line 386
    .line 387
    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 388
    .line 389
    .line 390
    :cond_14
    sget-object v4, Landroidx/camera/video/internal/compat/quirk/EncoderNotUsePersistentInputSurfaceQuirk;->a:Ljava/util/List;

    .line 391
    .line 392
    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 393
    .line 394
    invoke-virtual {v4}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    .line 395
    .line 396
    .line 397
    move-result-object v7

    .line 398
    sget-object v15, Landroidx/camera/video/internal/compat/quirk/EncoderNotUsePersistentInputSurfaceQuirk;->a:Ljava/util/List;

    .line 399
    .line 400
    invoke-interface {v15, v7}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 401
    .line 402
    .line 403
    move-result v7

    .line 404
    const-class v15, Landroidx/camera/video/internal/compat/quirk/EncoderNotUsePersistentInputSurfaceQuirk;

    .line 405
    .line 406
    invoke-virtual {v0, v15, v7}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 407
    .line 408
    .line 409
    move-result v7

    .line 410
    if-eqz v7, :cond_15

    .line 411
    .line 412
    new-instance v7, Landroidx/camera/video/internal/compat/quirk/EncoderNotUsePersistentInputSurfaceQuirk;

    .line 413
    .line 414
    invoke-direct {v7}, Landroidx/camera/video/internal/compat/quirk/EncoderNotUsePersistentInputSurfaceQuirk;-><init>()V

    .line 415
    .line 416
    .line 417
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 418
    .line 419
    .line 420
    :cond_15
    invoke-virtual {v9, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 421
    .line 422
    .line 423
    move-result v7

    .line 424
    if-eqz v7, :cond_16

    .line 425
    .line 426
    invoke-virtual {v10, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 427
    .line 428
    .line 429
    move-result v7

    .line 430
    if-eqz v7, :cond_16

    .line 431
    .line 432
    const/4 v7, 0x1

    .line 433
    goto :goto_7

    .line 434
    :cond_16
    const/4 v7, 0x0

    .line 435
    :goto_7
    const-class v15, Landroidx/camera/video/internal/compat/quirk/VideoEncoderCrashQuirk;

    .line 436
    .line 437
    invoke-virtual {v0, v15, v7}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 438
    .line 439
    .line 440
    move-result v7

    .line 441
    if-eqz v7, :cond_17

    .line 442
    .line 443
    new-instance v7, Landroidx/camera/video/internal/compat/quirk/VideoEncoderCrashQuirk;

    .line 444
    .line 445
    invoke-direct {v7}, Landroidx/camera/video/internal/compat/quirk/VideoEncoderCrashQuirk;-><init>()V

    .line 446
    .line 447
    .line 448
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 449
    .line 450
    .line 451
    :cond_17
    invoke-virtual {v3, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 452
    .line 453
    .line 454
    move-result v7

    .line 455
    if-eqz v7, :cond_18

    .line 456
    .line 457
    const-string v7, "SM-J260F"

    .line 458
    .line 459
    invoke-virtual {v7, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 460
    .line 461
    .line 462
    move-result v7

    .line 463
    if-eqz v7, :cond_18

    .line 464
    .line 465
    goto :goto_8

    .line 466
    :cond_18
    invoke-virtual {v3, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 467
    .line 468
    .line 469
    move-result v7

    .line 470
    if-eqz v7, :cond_19

    .line 471
    .line 472
    const-string v7, "SM-J400G"

    .line 473
    .line 474
    invoke-virtual {v7, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 475
    .line 476
    .line 477
    move-result v7

    .line 478
    if-eqz v7, :cond_19

    .line 479
    .line 480
    goto :goto_8

    .line 481
    :cond_19
    invoke-virtual {v3, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 482
    .line 483
    .line 484
    move-result v7

    .line 485
    if-eqz v7, :cond_1a

    .line 486
    .line 487
    const-string v7, "SM-J530F"

    .line 488
    .line 489
    invoke-virtual {v7, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 490
    .line 491
    .line 492
    move-result v7

    .line 493
    if-eqz v7, :cond_1a

    .line 494
    .line 495
    goto :goto_8

    .line 496
    :cond_1a
    invoke-virtual {v3, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 497
    .line 498
    .line 499
    move-result v7

    .line 500
    if-eqz v7, :cond_1b

    .line 501
    .line 502
    const-string/jumbo v7, "sm-j600g"

    .line 503
    .line 504
    .line 505
    invoke-virtual {v7, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 506
    .line 507
    .line 508
    move-result v7

    .line 509
    if-eqz v7, :cond_1b

    .line 510
    .line 511
    goto :goto_8

    .line 512
    :cond_1b
    invoke-virtual {v3, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 513
    .line 514
    .line 515
    move-result v7

    .line 516
    if-eqz v7, :cond_1c

    .line 517
    .line 518
    const-string v7, "SM-J701F"

    .line 519
    .line 520
    invoke-virtual {v7, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 521
    .line 522
    .line 523
    move-result v7

    .line 524
    if-eqz v7, :cond_1c

    .line 525
    .line 526
    goto :goto_8

    .line 527
    :cond_1c
    invoke-static {}, Landroidx/camera/video/internal/compat/quirk/ExcludeStretchedVideoQualityQuirk;->b()Z

    .line 528
    .line 529
    .line 530
    move-result v7

    .line 531
    if-nez v7, :cond_1e

    .line 532
    .line 533
    invoke-static {}, Landroidx/camera/video/internal/compat/quirk/ExcludeStretchedVideoQualityQuirk;->a()Z

    .line 534
    .line 535
    .line 536
    move-result v7

    .line 537
    if-eqz v7, :cond_1d

    .line 538
    .line 539
    goto :goto_8

    .line 540
    :cond_1d
    const/4 v7, 0x0

    .line 541
    goto :goto_9

    .line 542
    :cond_1e
    :goto_8
    const/4 v7, 0x1

    .line 543
    :goto_9
    const-class v15, Landroidx/camera/video/internal/compat/quirk/ExcludeStretchedVideoQualityQuirk;

    .line 544
    .line 545
    invoke-virtual {v0, v15, v7}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 546
    .line 547
    .line 548
    move-result v7

    .line 549
    if-eqz v7, :cond_1f

    .line 550
    .line 551
    new-instance v7, Landroidx/camera/video/internal/compat/quirk/ExcludeStretchedVideoQualityQuirk;

    .line 552
    .line 553
    invoke-direct {v7}, Landroidx/camera/video/internal/compat/quirk/ExcludeStretchedVideoQualityQuirk;-><init>()V

    .line 554
    .line 555
    .line 556
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 557
    .line 558
    .line 559
    :cond_1f
    invoke-virtual {v9, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 560
    .line 561
    .line 562
    move-result v7

    .line 563
    if-eqz v7, :cond_20

    .line 564
    .line 565
    invoke-virtual {v10, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 566
    .line 567
    .line 568
    move-result v7

    .line 569
    if-eqz v7, :cond_20

    .line 570
    .line 571
    goto :goto_a

    .line 572
    :cond_20
    const-string v7, "itel"

    .line 573
    .line 574
    invoke-virtual {v7, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 575
    .line 576
    .line 577
    move-result v7

    .line 578
    if-eqz v7, :cond_21

    .line 579
    .line 580
    const-string v7, "itel w6004"

    .line 581
    .line 582
    invoke-virtual {v7, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 583
    .line 584
    .line 585
    move-result v7

    .line 586
    if-eqz v7, :cond_21

    .line 587
    .line 588
    :goto_a
    const/4 v7, 0x1

    .line 589
    goto :goto_b

    .line 590
    :cond_21
    const/4 v7, 0x0

    .line 591
    :goto_b
    const-class v9, Landroidx/camera/video/internal/compat/quirk/MediaStoreVideoCannotWrite;

    .line 592
    .line 593
    invoke-virtual {v0, v9, v7}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 594
    .line 595
    .line 596
    move-result v7

    .line 597
    if-eqz v7, :cond_22

    .line 598
    .line 599
    new-instance v7, Landroidx/camera/video/internal/compat/quirk/MediaStoreVideoCannotWrite;

    .line 600
    .line 601
    invoke-direct {v7}, Landroidx/camera/video/internal/compat/quirk/MediaStoreVideoCannotWrite;-><init>()V

    .line 602
    .line 603
    .line 604
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 605
    .line 606
    .line 607
    :cond_22
    const-string v7, "Sony"

    .line 608
    .line 609
    invoke-virtual {v7, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 610
    .line 611
    .line 612
    move-result v7

    .line 613
    if-eqz v7, :cond_23

    .line 614
    .line 615
    const-string v7, "G3125"

    .line 616
    .line 617
    invoke-virtual {v7, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 618
    .line 619
    .line 620
    move-result v7

    .line 621
    if-eqz v7, :cond_23

    .line 622
    .line 623
    const/4 v7, 0x1

    .line 624
    goto :goto_c

    .line 625
    :cond_23
    const/4 v7, 0x0

    .line 626
    :goto_c
    const-class v9, Landroidx/camera/video/internal/compat/quirk/AudioEncoderIgnoresInputTimestampQuirk;

    .line 627
    .line 628
    invoke-virtual {v0, v9, v7}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 629
    .line 630
    .line 631
    move-result v7

    .line 632
    if-eqz v7, :cond_24

    .line 633
    .line 634
    new-instance v7, Landroidx/camera/video/internal/compat/quirk/AudioEncoderIgnoresInputTimestampQuirk;

    .line 635
    .line 636
    invoke-direct {v7}, Landroidx/camera/video/internal/compat/quirk/AudioEncoderIgnoresInputTimestampQuirk;-><init>()V

    .line 637
    .line 638
    .line 639
    invoke-virtual {v12, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 640
    .line 641
    .line 642
    :cond_24
    invoke-virtual {v3, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 643
    .line 644
    .line 645
    move-result v3

    .line 646
    if-eqz v3, :cond_25

    .line 647
    .line 648
    const/16 v3, 0x1d

    .line 649
    .line 650
    if-ge v1, v3, :cond_25

    .line 651
    .line 652
    const/4 v3, 0x1

    .line 653
    goto :goto_d

    .line 654
    :cond_25
    const/4 v3, 0x0

    .line 655
    :goto_d
    const-class v7, Landroidx/camera/video/internal/compat/quirk/VideoEncoderSuspendDoesNotIncludeSuspendTimeQuirk;

    .line 656
    .line 657
    invoke-virtual {v0, v7, v3}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 658
    .line 659
    .line 660
    move-result v3

    .line 661
    if-eqz v3, :cond_26

    .line 662
    .line 663
    new-instance v3, Landroidx/camera/video/internal/compat/quirk/VideoEncoderSuspendDoesNotIncludeSuspendTimeQuirk;

    .line 664
    .line 665
    invoke-direct {v3}, Landroidx/camera/video/internal/compat/quirk/VideoEncoderSuspendDoesNotIncludeSuspendTimeQuirk;-><init>()V

    .line 666
    .line 667
    .line 668
    invoke-virtual {v12, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 669
    .line 670
    .line 671
    :cond_26
    const/16 v3, 0x22

    .line 672
    .line 673
    if-ge v1, v3, :cond_27

    .line 674
    .line 675
    const/4 v1, 0x1

    .line 676
    goto :goto_e

    .line 677
    :cond_27
    const/4 v1, 0x0

    .line 678
    :goto_e
    const-class v3, Landroidx/camera/video/internal/compat/quirk/NegativeLatLongSavesIncorrectlyQuirk;

    .line 679
    .line 680
    invoke-virtual {v0, v3, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 681
    .line 682
    .line 683
    move-result v1

    .line 684
    if-eqz v1, :cond_28

    .line 685
    .line 686
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/NegativeLatLongSavesIncorrectlyQuirk;

    .line 687
    .line 688
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/NegativeLatLongSavesIncorrectlyQuirk;-><init>()V

    .line 689
    .line 690
    .line 691
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 692
    .line 693
    .line 694
    :cond_28
    sget-object v1, Landroidx/camera/video/internal/compat/quirk/AudioTimestampFramePositionIncorrectQuirk;->a:Ljava/util/List;

    .line 695
    .line 696
    const-string v1, "oppo"

    .line 697
    .line 698
    invoke-virtual {v1, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 699
    .line 700
    .line 701
    move-result v1

    .line 702
    if-eqz v1, :cond_29

    .line 703
    .line 704
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 705
    .line 706
    invoke-virtual {v4, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 707
    .line 708
    .line 709
    move-result-object v1

    .line 710
    sget-object v3, Landroidx/camera/video/internal/compat/quirk/AudioTimestampFramePositionIncorrectQuirk;->a:Ljava/util/List;

    .line 711
    .line 712
    invoke-interface {v3, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 713
    .line 714
    .line 715
    move-result v1

    .line 716
    if-eqz v1, :cond_29

    .line 717
    .line 718
    goto :goto_f

    .line 719
    :cond_29
    const-string v1, "lge"

    .line 720
    .line 721
    invoke-virtual {v1, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 722
    .line 723
    .line 724
    move-result v1

    .line 725
    if-eqz v1, :cond_2a

    .line 726
    .line 727
    const-string v1, "lg-m250"

    .line 728
    .line 729
    invoke-virtual {v1, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 730
    .line 731
    .line 732
    move-result v1

    .line 733
    if-eqz v1, :cond_2a

    .line 734
    .line 735
    goto :goto_f

    .line 736
    :cond_2a
    invoke-virtual {v6, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 737
    .line 738
    .line 739
    move-result v1

    .line 740
    if-eqz v1, :cond_2b

    .line 741
    .line 742
    invoke-virtual {v8, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 743
    .line 744
    .line 745
    move-result v1

    .line 746
    if-eqz v1, :cond_2b

    .line 747
    .line 748
    goto :goto_f

    .line 749
    :cond_2b
    const-string v1, "realme"

    .line 750
    .line 751
    invoke-virtual {v1, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 752
    .line 753
    .line 754
    move-result v1

    .line 755
    if-eqz v1, :cond_2c

    .line 756
    .line 757
    const-string/jumbo v1, "rmx1941"

    .line 758
    .line 759
    .line 760
    invoke-virtual {v1, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 761
    .line 762
    .line 763
    move-result v1

    .line 764
    if-eqz v1, :cond_2c

    .line 765
    .line 766
    goto :goto_f

    .line 767
    :cond_2c
    const-string v1, "Xiaomi"

    .line 768
    .line 769
    invoke-virtual {v1, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 770
    .line 771
    .line 772
    move-result v1

    .line 773
    if-eqz v1, :cond_2d

    .line 774
    .line 775
    const-string v1, "Redmi 6A"

    .line 776
    .line 777
    invoke-virtual {v1, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 778
    .line 779
    .line 780
    move-result v1

    .line 781
    if-eqz v1, :cond_2d

    .line 782
    .line 783
    goto :goto_f

    .line 784
    :cond_2d
    const-string/jumbo v1, "vivo"

    .line 785
    .line 786
    .line 787
    invoke-virtual {v1, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 788
    .line 789
    .line 790
    move-result v3

    .line 791
    if-eqz v3, :cond_2e

    .line 792
    .line 793
    invoke-virtual {v5, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 794
    .line 795
    .line 796
    move-result v3

    .line 797
    if-eqz v3, :cond_2e

    .line 798
    .line 799
    goto :goto_f

    .line 800
    :cond_2e
    invoke-virtual {v1, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 801
    .line 802
    .line 803
    move-result v1

    .line 804
    if-eqz v1, :cond_2f

    .line 805
    .line 806
    const-string v1, "VIVO Y17"

    .line 807
    .line 808
    invoke-virtual {v1, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 809
    .line 810
    .line 811
    move-result v1

    .line 812
    if-eqz v1, :cond_2f

    .line 813
    .line 814
    :goto_f
    const/4 v1, 0x1

    .line 815
    goto :goto_10

    .line 816
    :cond_2f
    const/4 v1, 0x0

    .line 817
    :goto_10
    const-class v3, Landroidx/camera/video/internal/compat/quirk/AudioTimestampFramePositionIncorrectQuirk;

    .line 818
    .line 819
    invoke-virtual {v0, v3, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 820
    .line 821
    .line 822
    move-result v1

    .line 823
    if-eqz v1, :cond_30

    .line 824
    .line 825
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/AudioTimestampFramePositionIncorrectQuirk;

    .line 826
    .line 827
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/AudioTimestampFramePositionIncorrectQuirk;-><init>()V

    .line 828
    .line 829
    .line 830
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 831
    .line 832
    .line 833
    :cond_30
    invoke-virtual {v6, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 834
    .line 835
    .line 836
    move-result v1

    .line 837
    if-eqz v1, :cond_31

    .line 838
    .line 839
    invoke-virtual {v2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 840
    .line 841
    .line 842
    move-result v1

    .line 843
    if-eqz v1, :cond_31

    .line 844
    .line 845
    const/4 v1, 0x1

    .line 846
    goto :goto_11

    .line 847
    :cond_31
    const/4 v1, 0x0

    .line 848
    :goto_11
    const-class v3, Landroidx/camera/video/internal/compat/quirk/ExtraSupportedResolutionQuirk;

    .line 849
    .line 850
    invoke-virtual {v0, v3, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 851
    .line 852
    .line 853
    move-result v1

    .line 854
    if-eqz v1, :cond_32

    .line 855
    .line 856
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/ExtraSupportedResolutionQuirk;

    .line 857
    .line 858
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/ExtraSupportedResolutionQuirk;-><init>()V

    .line 859
    .line 860
    .line 861
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 862
    .line 863
    .line 864
    :cond_32
    invoke-virtual {v6, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 865
    .line 866
    .line 867
    move-result v1

    .line 868
    if-eqz v1, :cond_33

    .line 869
    .line 870
    invoke-virtual {v2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 871
    .line 872
    .line 873
    move-result v1

    .line 874
    if-eqz v1, :cond_33

    .line 875
    .line 876
    const/4 v1, 0x1

    .line 877
    goto :goto_12

    .line 878
    :cond_33
    const/4 v1, 0x0

    .line 879
    :goto_12
    const-class v2, Landroidx/camera/video/internal/compat/quirk/StretchedVideoResolutionQuirk;

    .line 880
    .line 881
    invoke-virtual {v0, v2, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 882
    .line 883
    .line 884
    move-result v1

    .line 885
    if-eqz v1, :cond_34

    .line 886
    .line 887
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/StretchedVideoResolutionQuirk;

    .line 888
    .line 889
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/StretchedVideoResolutionQuirk;-><init>()V

    .line 890
    .line 891
    .line 892
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 893
    .line 894
    .line 895
    :cond_34
    invoke-virtual {v14, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 896
    .line 897
    .line 898
    move-result v1

    .line 899
    if-eqz v1, :cond_35

    .line 900
    .line 901
    invoke-virtual {v11, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 902
    .line 903
    .line 904
    move-result v1

    .line 905
    if-eqz v1, :cond_35

    .line 906
    .line 907
    const/4 v1, 0x1

    .line 908
    goto :goto_13

    .line 909
    :cond_35
    const/4 v1, 0x0

    .line 910
    :goto_13
    const-class v2, Landroidx/camera/video/internal/compat/quirk/CodecStuckOnFlushQuirk;

    .line 911
    .line 912
    invoke-virtual {v0, v2, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 913
    .line 914
    .line 915
    move-result v1

    .line 916
    if-eqz v1, :cond_36

    .line 917
    .line 918
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/CodecStuckOnFlushQuirk;

    .line 919
    .line 920
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/CodecStuckOnFlushQuirk;-><init>()V

    .line 921
    .line 922
    .line 923
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 924
    .line 925
    .line 926
    :cond_36
    invoke-virtual {v6, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 927
    .line 928
    .line 929
    move-result v1

    .line 930
    if-eqz v1, :cond_37

    .line 931
    .line 932
    invoke-virtual {v8, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 933
    .line 934
    .line 935
    move-result v1

    .line 936
    if-eqz v1, :cond_37

    .line 937
    .line 938
    const/4 v1, 0x1

    .line 939
    goto :goto_14

    .line 940
    :cond_37
    const/4 v1, 0x0

    .line 941
    :goto_14
    const-class v2, Landroidx/camera/video/internal/compat/quirk/StopCodecAfterSurfaceRemovalCrashMediaServerQuirk;

    .line 942
    .line 943
    invoke-virtual {v0, v2, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 944
    .line 945
    .line 946
    move-result v1

    .line 947
    if-eqz v1, :cond_38

    .line 948
    .line 949
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/StopCodecAfterSurfaceRemovalCrashMediaServerQuirk;

    .line 950
    .line 951
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/StopCodecAfterSurfaceRemovalCrashMediaServerQuirk;-><init>()V

    .line 952
    .line 953
    .line 954
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 955
    .line 956
    .line 957
    :cond_38
    invoke-virtual {v6, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 958
    .line 959
    .line 960
    move-result v1

    .line 961
    if-eqz v1, :cond_39

    .line 962
    .line 963
    invoke-virtual {v8, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 964
    .line 965
    .line 966
    move-result v1

    .line 967
    if-eqz v1, :cond_39

    .line 968
    .line 969
    const/4 v1, 0x1

    .line 970
    goto :goto_15

    .line 971
    :cond_39
    const/4 v1, 0x0

    .line 972
    :goto_15
    const-class v2, Landroidx/camera/video/internal/compat/quirk/ExtraSupportedQualityQuirk;

    .line 973
    .line 974
    invoke-virtual {v0, v2, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 975
    .line 976
    .line 977
    move-result v1

    .line 978
    if-eqz v1, :cond_3a

    .line 979
    .line 980
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/ExtraSupportedQualityQuirk;

    .line 981
    .line 982
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/ExtraSupportedQualityQuirk;-><init>()V

    .line 983
    .line 984
    .line 985
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 986
    .line 987
    .line 988
    :cond_3a
    invoke-virtual {v14, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 989
    .line 990
    .line 991
    move-result v1

    .line 992
    if-eqz v1, :cond_3b

    .line 993
    .line 994
    invoke-virtual {v11, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 995
    .line 996
    .line 997
    move-result v1

    .line 998
    if-eqz v1, :cond_3b

    .line 999
    .line 1000
    const/4 v1, 0x1

    .line 1001
    goto :goto_16

    .line 1002
    :cond_3b
    const/4 v1, 0x0

    .line 1003
    :goto_16
    const-class v2, Landroidx/camera/video/internal/compat/quirk/SignalEosOutputBufferNotComeQuirk;

    .line 1004
    .line 1005
    invoke-virtual {v0, v2, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1006
    .line 1007
    .line 1008
    move-result v1

    .line 1009
    if-eqz v1, :cond_3c

    .line 1010
    .line 1011
    new-instance v1, Landroidx/camera/video/internal/compat/quirk/SignalEosOutputBufferNotComeQuirk;

    .line 1012
    .line 1013
    invoke-direct {v1}, Landroidx/camera/video/internal/compat/quirk/SignalEosOutputBufferNotComeQuirk;-><init>()V

    .line 1014
    .line 1015
    .line 1016
    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1017
    .line 1018
    .line 1019
    :cond_3c
    invoke-virtual {v6, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1020
    .line 1021
    .line 1022
    move-result v1

    .line 1023
    if-eqz v1, :cond_3d

    .line 1024
    .line 1025
    invoke-virtual {v8, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1026
    .line 1027
    .line 1028
    move-result v1

    .line 1029
    if-eqz v1, :cond_3d

    .line 1030
    .line 1031
    const/4 v9, 0x1

    .line 1032
    goto :goto_17

    .line 1033
    :cond_3d
    const/4 v9, 0x0

    .line 1034
    :goto_17
    const-class v1, Landroidx/camera/video/internal/compat/quirk/SizeCannotEncodeVideoQuirk;

    .line 1035
    .line 1036
    invoke-virtual {v0, v1, v9}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1037
    .line 1038
    .line 1039
    move-result v0

    .line 1040
    if-eqz v0, :cond_3e

    .line 1041
    .line 1042
    new-instance v0, Landroidx/camera/video/internal/compat/quirk/SizeCannotEncodeVideoQuirk;

    .line 1043
    .line 1044
    invoke-direct {v0}, Landroidx/camera/video/internal/compat/quirk/SizeCannotEncodeVideoQuirk;-><init>()V

    .line 1045
    .line 1046
    .line 1047
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1048
    .line 1049
    .line 1050
    :cond_3e
    move-object/from16 v0, p1

    .line 1051
    .line 1052
    invoke-direct {v0, v12}, Landroidx/camera/core/impl/y0;-><init>(Ljava/util/List;)V

    .line 1053
    .line 1054
    .line 1055
    sput-object v0, Landroidx/camera/video/internal/compat/quirk/a;->a:Landroidx/camera/core/impl/y0;

    .line 1056
    .line 1057
    sget-object v0, Landroidx/camera/video/internal/compat/quirk/a;->a:Landroidx/camera/core/impl/y0;

    .line 1058
    .line 1059
    invoke-static {v0}, Landroidx/camera/core/impl/y0;->d(Landroidx/camera/core/impl/y0;)V

    .line 1060
    .line 1061
    .line 1062
    invoke-static/range {v16 .. v16}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 1063
    .line 1064
    .line 1065
    return-void

    .line 1066
    :pswitch_0
    move-object/from16 v16, v8

    .line 1067
    .line 1068
    move-object/from16 v0, p1

    .line 1069
    .line 1070
    check-cast v0, Landroidx/camera/core/impl/t0;

    .line 1071
    .line 1072
    new-instance v2, Landroidx/camera/core/impl/y0;

    .line 1073
    .line 1074
    new-instance v4, Ljava/util/ArrayList;

    .line 1075
    .line 1076
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 1077
    .line 1078
    .line 1079
    sget-object v5, Landroid/os/Build;->BRAND:Ljava/lang/String;

    .line 1080
    .line 1081
    invoke-virtual {v1, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1082
    .line 1083
    .line 1084
    move-result v1

    .line 1085
    if-eqz v1, :cond_3f

    .line 1086
    .line 1087
    const-string v1, "SNE-LX1"

    .line 1088
    .line 1089
    sget-object v6, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 1090
    .line 1091
    invoke-virtual {v1, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1092
    .line 1093
    .line 1094
    move-result v1

    .line 1095
    if-eqz v1, :cond_3f

    .line 1096
    .line 1097
    goto :goto_18

    .line 1098
    :cond_3f
    const-string v1, "HONOR"

    .line 1099
    .line 1100
    invoke-virtual {v1, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1101
    .line 1102
    .line 1103
    move-result v1

    .line 1104
    if-eqz v1, :cond_40

    .line 1105
    .line 1106
    const-string v1, "STK-LX1"

    .line 1107
    .line 1108
    sget-object v6, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 1109
    .line 1110
    invoke-virtual {v1, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1111
    .line 1112
    .line 1113
    move-result v1

    .line 1114
    if-eqz v1, :cond_40

    .line 1115
    .line 1116
    :goto_18
    const/4 v1, 0x1

    .line 1117
    goto :goto_19

    .line 1118
    :cond_40
    sget-object v1, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    .line 1119
    .line 1120
    const-string v6, "generic"

    .line 1121
    .line 1122
    invoke-virtual {v1, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1123
    .line 1124
    .line 1125
    move-result v7

    .line 1126
    if-nez v7, :cond_42

    .line 1127
    .line 1128
    const-string/jumbo v7, "unknown"

    .line 1129
    .line 1130
    .line 1131
    invoke-virtual {v1, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1132
    .line 1133
    .line 1134
    move-result v1

    .line 1135
    if-nez v1, :cond_42

    .line 1136
    .line 1137
    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 1138
    .line 1139
    const-string v7, "google_sdk"

    .line 1140
    .line 1141
    invoke-virtual {v1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 1142
    .line 1143
    .line 1144
    move-result v8

    .line 1145
    if-nez v8, :cond_42

    .line 1146
    .line 1147
    const-string v8, "Emulator"

    .line 1148
    .line 1149
    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 1150
    .line 1151
    .line 1152
    move-result v8

    .line 1153
    if-nez v8, :cond_42

    .line 1154
    .line 1155
    const-string v8, "Cuttlefish"

    .line 1156
    .line 1157
    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 1158
    .line 1159
    .line 1160
    move-result v8

    .line 1161
    if-nez v8, :cond_42

    .line 1162
    .line 1163
    const-string v8, "Android SDK built for x86"

    .line 1164
    .line 1165
    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 1166
    .line 1167
    .line 1168
    move-result v1

    .line 1169
    if-nez v1, :cond_42

    .line 1170
    .line 1171
    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 1172
    .line 1173
    const-string v8, "Genymotion"

    .line 1174
    .line 1175
    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 1176
    .line 1177
    .line 1178
    move-result v1

    .line 1179
    if-nez v1, :cond_42

    .line 1180
    .line 1181
    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1182
    .line 1183
    .line 1184
    move-result v1

    .line 1185
    if-eqz v1, :cond_41

    .line 1186
    .line 1187
    sget-object v1, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 1188
    .line 1189
    invoke-virtual {v1, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1190
    .line 1191
    .line 1192
    move-result v1

    .line 1193
    if-nez v1, :cond_42

    .line 1194
    .line 1195
    :cond_41
    sget-object v1, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    .line 1196
    .line 1197
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1198
    .line 1199
    .line 1200
    move-result v1

    .line 1201
    if-nez v1, :cond_42

    .line 1202
    .line 1203
    sget-object v1, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    .line 1204
    .line 1205
    const-string v6, "ranchu"

    .line 1206
    .line 1207
    invoke-virtual {v1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 1208
    .line 1209
    .line 1210
    :cond_42
    const/4 v1, 0x0

    .line 1211
    :goto_19
    const-class v6, Landroidx/camera/core/internal/compat/quirk/ImageCaptureRotationOptionQuirk;

    .line 1212
    .line 1213
    invoke-virtual {v0, v6, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1214
    .line 1215
    .line 1216
    move-result v1

    .line 1217
    if-eqz v1, :cond_43

    .line 1218
    .line 1219
    new-instance v1, Landroidx/camera/core/internal/compat/quirk/ImageCaptureRotationOptionQuirk;

    .line 1220
    .line 1221
    invoke-direct {v1}, Landroidx/camera/core/internal/compat/quirk/ImageCaptureRotationOptionQuirk;-><init>()V

    .line 1222
    .line 1223
    .line 1224
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1225
    .line 1226
    .line 1227
    :cond_43
    const-class v1, Landroidx/camera/core/internal/compat/quirk/SurfaceOrderQuirk;

    .line 1228
    .line 1229
    const/4 v8, 0x1

    .line 1230
    invoke-virtual {v0, v1, v8}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1231
    .line 1232
    .line 1233
    move-result v1

    .line 1234
    if-eqz v1, :cond_44

    .line 1235
    .line 1236
    new-instance v1, Landroidx/camera/core/internal/compat/quirk/SurfaceOrderQuirk;

    .line 1237
    .line 1238
    invoke-direct {v1}, Landroidx/camera/core/internal/compat/quirk/SurfaceOrderQuirk;-><init>()V

    .line 1239
    .line 1240
    .line 1241
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1242
    .line 1243
    .line 1244
    :cond_44
    sget-object v1, Landroidx/camera/core/internal/compat/quirk/CaptureFailedRetryQuirk;->a:Ljava/util/HashSet;

    .line 1245
    .line 1246
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 1247
    .line 1248
    invoke-virtual {v5, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1249
    .line 1250
    .line 1251
    move-result-object v6

    .line 1252
    sget-object v7, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 1253
    .line 1254
    invoke-virtual {v7, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1255
    .line 1256
    .line 1257
    move-result-object v9

    .line 1258
    sget-object v10, Landroidx/camera/core/internal/compat/quirk/CaptureFailedRetryQuirk;->a:Ljava/util/HashSet;

    .line 1259
    .line 1260
    invoke-static {v6, v9}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 1261
    .line 1262
    .line 1263
    move-result-object v6

    .line 1264
    invoke-virtual {v10, v6}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 1265
    .line 1266
    .line 1267
    move-result v6

    .line 1268
    const-class v9, Landroidx/camera/core/internal/compat/quirk/CaptureFailedRetryQuirk;

    .line 1269
    .line 1270
    invoke-virtual {v0, v9, v6}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1271
    .line 1272
    .line 1273
    move-result v6

    .line 1274
    if-eqz v6, :cond_45

    .line 1275
    .line 1276
    new-instance v6, Landroidx/camera/core/internal/compat/quirk/CaptureFailedRetryQuirk;

    .line 1277
    .line 1278
    invoke-direct {v6}, Landroidx/camera/core/internal/compat/quirk/CaptureFailedRetryQuirk;-><init>()V

    .line 1279
    .line 1280
    .line 1281
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1282
    .line 1283
    .line 1284
    :cond_45
    sget-object v6, Landroidx/camera/core/internal/compat/quirk/LowMemoryQuirk;->a:Ljava/util/HashSet;

    .line 1285
    .line 1286
    invoke-virtual {v7, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1287
    .line 1288
    .line 1289
    move-result-object v7

    .line 1290
    invoke-virtual {v6, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 1291
    .line 1292
    .line 1293
    move-result v6

    .line 1294
    const-class v7, Landroidx/camera/core/internal/compat/quirk/LowMemoryQuirk;

    .line 1295
    .line 1296
    invoke-virtual {v0, v7, v6}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1297
    .line 1298
    .line 1299
    move-result v6

    .line 1300
    if-eqz v6, :cond_46

    .line 1301
    .line 1302
    new-instance v6, Landroidx/camera/core/internal/compat/quirk/LowMemoryQuirk;

    .line 1303
    .line 1304
    invoke-direct {v6}, Landroidx/camera/core/internal/compat/quirk/LowMemoryQuirk;-><init>()V

    .line 1305
    .line 1306
    .line 1307
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1308
    .line 1309
    .line 1310
    :cond_46
    sget-object v6, Landroidx/camera/core/internal/compat/quirk/LargeJpegImageQuirk;->a:Ljava/util/HashSet;

    .line 1311
    .line 1312
    invoke-virtual {v3, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1313
    .line 1314
    .line 1315
    move-result v6

    .line 1316
    if-nez v6, :cond_48

    .line 1317
    .line 1318
    invoke-static {}, Landroidx/camera/core/internal/compat/quirk/LargeJpegImageQuirk;->a()Z

    .line 1319
    .line 1320
    .line 1321
    move-result v6

    .line 1322
    if-eqz v6, :cond_47

    .line 1323
    .line 1324
    goto :goto_1a

    .line 1325
    :cond_47
    const/4 v6, 0x0

    .line 1326
    goto :goto_1b

    .line 1327
    :cond_48
    :goto_1a
    move v6, v8

    .line 1328
    :goto_1b
    const-class v7, Landroidx/camera/core/internal/compat/quirk/LargeJpegImageQuirk;

    .line 1329
    .line 1330
    invoke-virtual {v0, v7, v6}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1331
    .line 1332
    .line 1333
    move-result v6

    .line 1334
    if-eqz v6, :cond_49

    .line 1335
    .line 1336
    new-instance v6, Landroidx/camera/core/internal/compat/quirk/LargeJpegImageQuirk;

    .line 1337
    .line 1338
    invoke-direct {v6}, Landroidx/camera/core/internal/compat/quirk/LargeJpegImageQuirk;-><init>()V

    .line 1339
    .line 1340
    .line 1341
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1342
    .line 1343
    .line 1344
    :cond_49
    sget-object v6, Landroidx/camera/core/internal/compat/quirk/IncorrectJpegMetadataQuirk;->a:Ljava/util/HashSet;

    .line 1345
    .line 1346
    invoke-virtual {v3, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1347
    .line 1348
    .line 1349
    move-result v3

    .line 1350
    if-eqz v3, :cond_4a

    .line 1351
    .line 1352
    sget-object v3, Landroidx/camera/core/internal/compat/quirk/IncorrectJpegMetadataQuirk;->a:Ljava/util/HashSet;

    .line 1353
    .line 1354
    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 1355
    .line 1356
    invoke-virtual {v5, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1357
    .line 1358
    .line 1359
    move-result-object v1

    .line 1360
    invoke-virtual {v3, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 1361
    .line 1362
    .line 1363
    move-result v1

    .line 1364
    if-eqz v1, :cond_4a

    .line 1365
    .line 1366
    move v9, v8

    .line 1367
    goto :goto_1c

    .line 1368
    :cond_4a
    const/4 v9, 0x0

    .line 1369
    :goto_1c
    const-class v1, Landroidx/camera/core/internal/compat/quirk/IncorrectJpegMetadataQuirk;

    .line 1370
    .line 1371
    invoke-virtual {v0, v1, v9}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1372
    .line 1373
    .line 1374
    move-result v0

    .line 1375
    if-eqz v0, :cond_4b

    .line 1376
    .line 1377
    new-instance v0, Landroidx/camera/core/internal/compat/quirk/IncorrectJpegMetadataQuirk;

    .line 1378
    .line 1379
    invoke-direct {v0}, Landroidx/camera/core/internal/compat/quirk/IncorrectJpegMetadataQuirk;-><init>()V

    .line 1380
    .line 1381
    .line 1382
    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1383
    .line 1384
    .line 1385
    :cond_4b
    invoke-direct {v2, v4}, Landroidx/camera/core/impl/y0;-><init>(Ljava/util/List;)V

    .line 1386
    .line 1387
    .line 1388
    sput-object v2, Landroidx/camera/core/internal/compat/quirk/a;->a:Landroidx/camera/core/impl/y0;

    .line 1389
    .line 1390
    sget-object v0, Landroidx/camera/core/internal/compat/quirk/a;->a:Landroidx/camera/core/impl/y0;

    .line 1391
    .line 1392
    invoke-static {v0}, Landroidx/camera/core/impl/y0;->d(Landroidx/camera/core/impl/y0;)V

    .line 1393
    .line 1394
    .line 1395
    invoke-static/range {v16 .. v16}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 1396
    .line 1397
    .line 1398
    return-void

    .line 1399
    :pswitch_1
    move-object/from16 v16, v8

    .line 1400
    .line 1401
    const/4 v8, 0x1

    .line 1402
    move-object/from16 v3, p1

    .line 1403
    .line 1404
    check-cast v3, Landroidx/camera/core/impl/t0;

    .line 1405
    .line 1406
    new-instance v9, Landroidx/camera/core/impl/y0;

    .line 1407
    .line 1408
    new-instance v10, Ljava/util/ArrayList;

    .line 1409
    .line 1410
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 1411
    .line 1412
    .line 1413
    sget-object v11, Landroidx/camera/camera2/internal/compat/quirk/ImageCapturePixelHDRPlusQuirk;->a:Ljava/util/List;

    .line 1414
    .line 1415
    sget-object v12, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 1416
    .line 1417
    invoke-interface {v11, v12}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 1418
    .line 1419
    .line 1420
    move-result v11

    .line 1421
    const-string v13, "Google"

    .line 1422
    .line 1423
    if-eqz v11, :cond_4c

    .line 1424
    .line 1425
    sget-object v11, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 1426
    .line 1427
    invoke-virtual {v13, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1428
    .line 1429
    .line 1430
    move-result v11

    .line 1431
    if-eqz v11, :cond_4c

    .line 1432
    .line 1433
    sget v11, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1434
    .line 1435
    const/16 v14, 0x1a

    .line 1436
    .line 1437
    if-lt v11, v14, :cond_4c

    .line 1438
    .line 1439
    move v11, v8

    .line 1440
    goto :goto_1d

    .line 1441
    :cond_4c
    const/4 v11, 0x0

    .line 1442
    :goto_1d
    const-class v14, Landroidx/camera/camera2/internal/compat/quirk/ImageCapturePixelHDRPlusQuirk;

    .line 1443
    .line 1444
    invoke-virtual {v3, v14, v11}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1445
    .line 1446
    .line 1447
    move-result v11

    .line 1448
    if-eqz v11, :cond_4d

    .line 1449
    .line 1450
    new-instance v11, Landroidx/camera/camera2/internal/compat/quirk/ImageCapturePixelHDRPlusQuirk;

    .line 1451
    .line 1452
    invoke-direct {v11}, Landroidx/camera/camera2/internal/compat/quirk/ImageCapturePixelHDRPlusQuirk;-><init>()V

    .line 1453
    .line 1454
    .line 1455
    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1456
    .line 1457
    .line 1458
    :cond_4d
    invoke-static {}, Landroidx/camera/camera2/internal/compat/quirk/ExtraCroppingQuirk;->b()Z

    .line 1459
    .line 1460
    .line 1461
    move-result v11

    .line 1462
    const-class v14, Landroidx/camera/camera2/internal/compat/quirk/ExtraCroppingQuirk;

    .line 1463
    .line 1464
    invoke-virtual {v3, v14, v11}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1465
    .line 1466
    .line 1467
    move-result v11

    .line 1468
    if-eqz v11, :cond_4e

    .line 1469
    .line 1470
    new-instance v11, Landroidx/camera/camera2/internal/compat/quirk/ExtraCroppingQuirk;

    .line 1471
    .line 1472
    invoke-direct {v11}, Landroidx/camera/camera2/internal/compat/quirk/ExtraCroppingQuirk;-><init>()V

    .line 1473
    .line 1474
    .line 1475
    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1476
    .line 1477
    .line 1478
    :cond_4e
    sget-object v11, Landroidx/camera/camera2/internal/compat/quirk/Nexus4AndroidLTargetAspectRatioQuirk;->a:Ljava/util/List;

    .line 1479
    .line 1480
    sget-object v11, Landroid/os/Build;->BRAND:Ljava/lang/String;

    .line 1481
    .line 1482
    const-string v14, "GOOGLE"

    .line 1483
    .line 1484
    invoke-virtual {v14, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1485
    .line 1486
    .line 1487
    const-class v14, Landroidx/camera/camera2/internal/compat/quirk/Nexus4AndroidLTargetAspectRatioQuirk;

    .line 1488
    .line 1489
    const/4 v15, 0x0

    .line 1490
    invoke-virtual {v3, v14, v15}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1491
    .line 1492
    .line 1493
    move-result v14

    .line 1494
    if-eqz v14, :cond_4f

    .line 1495
    .line 1496
    new-instance v14, Landroidx/camera/camera2/internal/compat/quirk/Nexus4AndroidLTargetAspectRatioQuirk;

    .line 1497
    .line 1498
    invoke-direct {v14}, Landroidx/camera/camera2/internal/compat/quirk/Nexus4AndroidLTargetAspectRatioQuirk;-><init>()V

    .line 1499
    .line 1500
    .line 1501
    invoke-virtual {v10, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1502
    .line 1503
    .line 1504
    :cond_4f
    const-string v14, "OnePlus"

    .line 1505
    .line 1506
    invoke-virtual {v14, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1507
    .line 1508
    .line 1509
    move-result v15

    .line 1510
    if-eqz v15, :cond_50

    .line 1511
    .line 1512
    const-string v15, "OnePlus6"

    .line 1513
    .line 1514
    sget-object v8, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 1515
    .line 1516
    invoke-virtual {v15, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1517
    .line 1518
    .line 1519
    move-result v8

    .line 1520
    if-eqz v8, :cond_50

    .line 1521
    .line 1522
    goto :goto_1e

    .line 1523
    :cond_50
    invoke-virtual {v14, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1524
    .line 1525
    .line 1526
    move-result v8

    .line 1527
    if-eqz v8, :cond_51

    .line 1528
    .line 1529
    const-string v8, "OnePlus6T"

    .line 1530
    .line 1531
    sget-object v14, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 1532
    .line 1533
    invoke-virtual {v8, v14}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1534
    .line 1535
    .line 1536
    move-result v8

    .line 1537
    if-eqz v8, :cond_51

    .line 1538
    .line 1539
    goto :goto_1e

    .line 1540
    :cond_51
    invoke-virtual {v1, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1541
    .line 1542
    .line 1543
    move-result v1

    .line 1544
    if-eqz v1, :cond_52

    .line 1545
    .line 1546
    const-string v1, "HWANE"

    .line 1547
    .line 1548
    sget-object v8, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 1549
    .line 1550
    invoke-virtual {v1, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1551
    .line 1552
    .line 1553
    move-result v1

    .line 1554
    if-eqz v1, :cond_52

    .line 1555
    .line 1556
    goto :goto_1e

    .line 1557
    :cond_52
    invoke-static {}, Landroidx/camera/camera2/internal/compat/quirk/ExcludedSupportedSizesQuirk;->b()Z

    .line 1558
    .line 1559
    .line 1560
    move-result v1

    .line 1561
    if-nez v1, :cond_54

    .line 1562
    .line 1563
    invoke-static {}, Landroidx/camera/camera2/internal/compat/quirk/ExcludedSupportedSizesQuirk;->a()Z

    .line 1564
    .line 1565
    .line 1566
    move-result v1

    .line 1567
    if-nez v1, :cond_54

    .line 1568
    .line 1569
    const-string v1, "REDMI"

    .line 1570
    .line 1571
    invoke-virtual {v1, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1572
    .line 1573
    .line 1574
    move-result v1

    .line 1575
    if-eqz v1, :cond_53

    .line 1576
    .line 1577
    const-string v1, "joyeuse"

    .line 1578
    .line 1579
    sget-object v8, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 1580
    .line 1581
    invoke-virtual {v1, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1582
    .line 1583
    .line 1584
    move-result v1

    .line 1585
    if-eqz v1, :cond_53

    .line 1586
    .line 1587
    goto :goto_1e

    .line 1588
    :cond_53
    const/4 v1, 0x0

    .line 1589
    goto :goto_1f

    .line 1590
    :cond_54
    :goto_1e
    const/4 v1, 0x1

    .line 1591
    :goto_1f
    const-class v8, Landroidx/camera/camera2/internal/compat/quirk/ExcludedSupportedSizesQuirk;

    .line 1592
    .line 1593
    invoke-virtual {v3, v8, v1}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1594
    .line 1595
    .line 1596
    move-result v1

    .line 1597
    if-eqz v1, :cond_55

    .line 1598
    .line 1599
    new-instance v1, Landroidx/camera/camera2/internal/compat/quirk/ExcludedSupportedSizesQuirk;

    .line 1600
    .line 1601
    invoke-direct {v1}, Landroidx/camera/camera2/internal/compat/quirk/ExcludedSupportedSizesQuirk;-><init>()V

    .line 1602
    .line 1603
    .line 1604
    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1605
    .line 1606
    .line 1607
    :cond_55
    sget-object v1, Landroidx/camera/camera2/internal/compat/quirk/CrashWhenTakingPhotoWithAutoFlashAEModeQuirk;->a:Ljava/util/List;

    .line 1608
    .line 1609
    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 1610
    .line 1611
    invoke-virtual {v12, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1612
    .line 1613
    .line 1614
    move-result-object v8

    .line 1615
    sget-object v14, Landroidx/camera/camera2/internal/compat/quirk/CrashWhenTakingPhotoWithAutoFlashAEModeQuirk;->a:Ljava/util/List;

    .line 1616
    .line 1617
    invoke-interface {v14, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 1618
    .line 1619
    .line 1620
    move-result v8

    .line 1621
    const-class v14, Landroidx/camera/camera2/internal/compat/quirk/CrashWhenTakingPhotoWithAutoFlashAEModeQuirk;

    .line 1622
    .line 1623
    invoke-virtual {v3, v14, v8}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1624
    .line 1625
    .line 1626
    move-result v8

    .line 1627
    if-eqz v8, :cond_56

    .line 1628
    .line 1629
    new-instance v8, Landroidx/camera/camera2/internal/compat/quirk/CrashWhenTakingPhotoWithAutoFlashAEModeQuirk;

    .line 1630
    .line 1631
    invoke-direct {v8}, Landroidx/camera/camera2/internal/compat/quirk/CrashWhenTakingPhotoWithAutoFlashAEModeQuirk;-><init>()V

    .line 1632
    .line 1633
    .line 1634
    invoke-virtual {v10, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1635
    .line 1636
    .line 1637
    :cond_56
    sget-object v8, Landroidx/camera/camera2/internal/compat/quirk/PreviewPixelHDRnetQuirk;->a:Ljava/util/List;

    .line 1638
    .line 1639
    sget-object v8, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 1640
    .line 1641
    invoke-virtual {v13, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1642
    .line 1643
    .line 1644
    move-result v13

    .line 1645
    if-eqz v13, :cond_57

    .line 1646
    .line 1647
    sget-object v13, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 1648
    .line 1649
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 1650
    .line 1651
    .line 1652
    move-result-object v14

    .line 1653
    invoke-virtual {v13, v14}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1654
    .line 1655
    .line 1656
    move-result-object v13

    .line 1657
    sget-object v14, Landroidx/camera/camera2/internal/compat/quirk/PreviewPixelHDRnetQuirk;->a:Ljava/util/List;

    .line 1658
    .line 1659
    invoke-interface {v14, v13}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 1660
    .line 1661
    .line 1662
    move-result v13

    .line 1663
    if-eqz v13, :cond_57

    .line 1664
    .line 1665
    const/4 v13, 0x1

    .line 1666
    goto :goto_20

    .line 1667
    :cond_57
    const/4 v13, 0x0

    .line 1668
    :goto_20
    const-class v14, Landroidx/camera/camera2/internal/compat/quirk/PreviewPixelHDRnetQuirk;

    .line 1669
    .line 1670
    invoke-virtual {v3, v14, v13}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1671
    .line 1672
    .line 1673
    move-result v13

    .line 1674
    if-eqz v13, :cond_58

    .line 1675
    .line 1676
    new-instance v13, Landroidx/camera/camera2/internal/compat/quirk/PreviewPixelHDRnetQuirk;

    .line 1677
    .line 1678
    invoke-direct {v13}, Landroidx/camera/camera2/internal/compat/quirk/PreviewPixelHDRnetQuirk;-><init>()V

    .line 1679
    .line 1680
    .line 1681
    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1682
    .line 1683
    .line 1684
    :cond_58
    invoke-virtual {v8, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1685
    .line 1686
    .line 1687
    move-result-object v13

    .line 1688
    invoke-virtual {v7, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1689
    .line 1690
    .line 1691
    move-result v7

    .line 1692
    if-eqz v7, :cond_59

    .line 1693
    .line 1694
    invoke-virtual {v12, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1695
    .line 1696
    .line 1697
    move-result-object v7

    .line 1698
    const-string v13, "SM-A716"

    .line 1699
    .line 1700
    invoke-virtual {v7, v13}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1701
    .line 1702
    .line 1703
    move-result v7

    .line 1704
    if-eqz v7, :cond_59

    .line 1705
    .line 1706
    const/4 v7, 0x1

    .line 1707
    goto :goto_21

    .line 1708
    :cond_59
    const/4 v7, 0x0

    .line 1709
    :goto_21
    const-class v13, Landroidx/camera/camera2/internal/compat/quirk/StillCaptureFlashStopRepeatingQuirk;

    .line 1710
    .line 1711
    invoke-virtual {v3, v13, v7}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1712
    .line 1713
    .line 1714
    move-result v7

    .line 1715
    if-eqz v7, :cond_5a

    .line 1716
    .line 1717
    new-instance v7, Landroidx/camera/camera2/internal/compat/quirk/StillCaptureFlashStopRepeatingQuirk;

    .line 1718
    .line 1719
    invoke-direct {v7}, Landroidx/camera/camera2/internal/compat/quirk/StillCaptureFlashStopRepeatingQuirk;-><init>()V

    .line 1720
    .line 1721
    .line 1722
    invoke-virtual {v10, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1723
    .line 1724
    .line 1725
    :cond_5a
    sget-object v7, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedSurfaceCombinationsQuirk;->a:Landroidx/camera/core/impl/L0;

    .line 1726
    .line 1727
    sget-object v7, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 1728
    .line 1729
    const-string v13, "heroqltevzw"

    .line 1730
    .line 1731
    invoke-virtual {v13, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1732
    .line 1733
    .line 1734
    move-result v13

    .line 1735
    const-string v14, "google"

    .line 1736
    .line 1737
    if-nez v13, :cond_5e

    .line 1738
    .line 1739
    const-string v13, "heroqltetmo"

    .line 1740
    .line 1741
    invoke-virtual {v13, v7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1742
    .line 1743
    .line 1744
    move-result v7

    .line 1745
    if-eqz v7, :cond_5b

    .line 1746
    .line 1747
    goto :goto_23

    .line 1748
    :cond_5b
    invoke-virtual {v14, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1749
    .line 1750
    .line 1751
    move-result v7

    .line 1752
    if-nez v7, :cond_5c

    .line 1753
    .line 1754
    const/4 v7, 0x0

    .line 1755
    goto :goto_22

    .line 1756
    :cond_5c
    invoke-virtual {v12, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1757
    .line 1758
    .line 1759
    move-result-object v7

    .line 1760
    sget-object v13, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedSurfaceCombinationsQuirk;->c:Ljava/util/HashSet;

    .line 1761
    .line 1762
    invoke-virtual {v13, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 1763
    .line 1764
    .line 1765
    move-result v7

    .line 1766
    :goto_22
    if-nez v7, :cond_5e

    .line 1767
    .line 1768
    invoke-static {}, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedSurfaceCombinationsQuirk;->a()Z

    .line 1769
    .line 1770
    .line 1771
    move-result v7

    .line 1772
    if-eqz v7, :cond_5d

    .line 1773
    .line 1774
    goto :goto_23

    .line 1775
    :cond_5d
    const/4 v7, 0x0

    .line 1776
    goto :goto_24

    .line 1777
    :cond_5e
    :goto_23
    const/4 v7, 0x1

    .line 1778
    :goto_24
    const-class v13, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedSurfaceCombinationsQuirk;

    .line 1779
    .line 1780
    invoke-virtual {v3, v13, v7}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1781
    .line 1782
    .line 1783
    move-result v7

    .line 1784
    if-eqz v7, :cond_5f

    .line 1785
    .line 1786
    new-instance v7, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedSurfaceCombinationsQuirk;

    .line 1787
    .line 1788
    invoke-direct {v7}, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedSurfaceCombinationsQuirk;-><init>()V

    .line 1789
    .line 1790
    .line 1791
    invoke-virtual {v10, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1792
    .line 1793
    .line 1794
    :cond_5f
    sget-object v7, Landroidx/camera/camera2/internal/compat/quirk/FlashAvailabilityBufferUnderflowQuirk;->a:Ljava/util/HashSet;

    .line 1795
    .line 1796
    new-instance v13, Landroid/util/Pair;

    .line 1797
    .line 1798
    invoke-virtual {v8, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1799
    .line 1800
    .line 1801
    move-result-object v8

    .line 1802
    invoke-virtual {v12, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1803
    .line 1804
    .line 1805
    move-result-object v15

    .line 1806
    invoke-direct {v13, v8, v15}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1807
    .line 1808
    .line 1809
    invoke-virtual {v7, v13}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 1810
    .line 1811
    .line 1812
    move-result v7

    .line 1813
    const-class v8, Landroidx/camera/camera2/internal/compat/quirk/FlashAvailabilityBufferUnderflowQuirk;

    .line 1814
    .line 1815
    invoke-virtual {v3, v8, v7}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1816
    .line 1817
    .line 1818
    move-result v7

    .line 1819
    if-eqz v7, :cond_60

    .line 1820
    .line 1821
    new-instance v7, Landroidx/camera/camera2/internal/compat/quirk/FlashAvailabilityBufferUnderflowQuirk;

    .line 1822
    .line 1823
    invoke-direct {v7}, Landroidx/camera/camera2/internal/compat/quirk/FlashAvailabilityBufferUnderflowQuirk;-><init>()V

    .line 1824
    .line 1825
    .line 1826
    invoke-virtual {v10, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1827
    .line 1828
    .line 1829
    :cond_60
    invoke-virtual {v5, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1830
    .line 1831
    .line 1832
    move-result v5

    .line 1833
    if-eqz v5, :cond_61

    .line 1834
    .line 1835
    invoke-virtual {v4, v12}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1836
    .line 1837
    .line 1838
    move-result v4

    .line 1839
    if-eqz v4, :cond_61

    .line 1840
    .line 1841
    const/4 v4, 0x1

    .line 1842
    goto :goto_25

    .line 1843
    :cond_61
    const/4 v4, 0x0

    .line 1844
    :goto_25
    const-class v5, Landroidx/camera/camera2/internal/compat/quirk/RepeatingStreamConstraintForVideoRecordingQuirk;

    .line 1845
    .line 1846
    invoke-virtual {v3, v5, v4}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1847
    .line 1848
    .line 1849
    move-result v4

    .line 1850
    if-eqz v4, :cond_62

    .line 1851
    .line 1852
    new-instance v4, Landroidx/camera/camera2/internal/compat/quirk/RepeatingStreamConstraintForVideoRecordingQuirk;

    .line 1853
    .line 1854
    invoke-direct {v4}, Landroidx/camera/camera2/internal/compat/quirk/RepeatingStreamConstraintForVideoRecordingQuirk;-><init>()V

    .line 1855
    .line 1856
    .line 1857
    invoke-virtual {v10, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1858
    .line 1859
    .line 1860
    :cond_62
    const-class v4, Landroidx/camera/camera2/internal/compat/quirk/TextureViewIsClosedQuirk;

    .line 1861
    .line 1862
    const/4 v15, 0x0

    .line 1863
    invoke-virtual {v3, v4, v15}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1864
    .line 1865
    .line 1866
    move-result v4

    .line 1867
    if-eqz v4, :cond_63

    .line 1868
    .line 1869
    new-instance v4, Landroidx/camera/camera2/internal/compat/quirk/TextureViewIsClosedQuirk;

    .line 1870
    .line 1871
    invoke-direct {v4}, Landroidx/camera/camera2/internal/compat/quirk/TextureViewIsClosedQuirk;-><init>()V

    .line 1872
    .line 1873
    .line 1874
    invoke-virtual {v10, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1875
    .line 1876
    .line 1877
    :cond_63
    const-class v4, Landroidx/camera/camera2/internal/compat/quirk/CaptureSessionOnClosedNotCalledQuirk;

    .line 1878
    .line 1879
    invoke-virtual {v3, v4, v15}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1880
    .line 1881
    .line 1882
    move-result v4

    .line 1883
    if-eqz v4, :cond_64

    .line 1884
    .line 1885
    new-instance v4, Landroidx/camera/camera2/internal/compat/quirk/CaptureSessionOnClosedNotCalledQuirk;

    .line 1886
    .line 1887
    invoke-direct {v4}, Landroidx/camera/camera2/internal/compat/quirk/CaptureSessionOnClosedNotCalledQuirk;-><init>()V

    .line 1888
    .line 1889
    .line 1890
    invoke-virtual {v10, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1891
    .line 1892
    .line 1893
    :cond_64
    sget-object v4, Landroidx/camera/camera2/internal/compat/quirk/TorchIsClosedAfterImageCapturingQuirk;->a:Ljava/util/List;

    .line 1894
    .line 1895
    invoke-virtual {v12, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 1896
    .line 1897
    .line 1898
    move-result-object v4

    .line 1899
    sget-object v5, Landroidx/camera/camera2/internal/compat/quirk/TorchIsClosedAfterImageCapturingQuirk;->a:Ljava/util/List;

    .line 1900
    .line 1901
    invoke-interface {v5, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 1902
    .line 1903
    .line 1904
    move-result v4

    .line 1905
    const-class v5, Landroidx/camera/camera2/internal/compat/quirk/TorchIsClosedAfterImageCapturingQuirk;

    .line 1906
    .line 1907
    invoke-virtual {v3, v5, v4}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1908
    .line 1909
    .line 1910
    move-result v4

    .line 1911
    if-eqz v4, :cond_65

    .line 1912
    .line 1913
    new-instance v4, Landroidx/camera/camera2/internal/compat/quirk/TorchIsClosedAfterImageCapturingQuirk;

    .line 1914
    .line 1915
    invoke-direct {v4}, Landroidx/camera/camera2/internal/compat/quirk/TorchIsClosedAfterImageCapturingQuirk;-><init>()V

    .line 1916
    .line 1917
    .line 1918
    invoke-virtual {v10, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1919
    .line 1920
    .line 1921
    :cond_65
    sget-object v4, Landroidx/camera/camera2/internal/compat/quirk/ZslDisablerQuirk;->a:Ljava/util/List;

    .line 1922
    .line 1923
    const-string/jumbo v4, "samsung"

    .line 1924
    .line 1925
    .line 1926
    invoke-virtual {v4, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1927
    .line 1928
    .line 1929
    move-result v5

    .line 1930
    const-string/jumbo v7, "xiaomi"

    .line 1931
    .line 1932
    .line 1933
    if-eqz v5, :cond_66

    .line 1934
    .line 1935
    sget-object v5, Landroidx/camera/camera2/internal/compat/quirk/ZslDisablerQuirk;->a:Ljava/util/List;

    .line 1936
    .line 1937
    invoke-static {v5}, Landroidx/camera/camera2/internal/compat/quirk/ZslDisablerQuirk;->a(Ljava/util/List;)Z

    .line 1938
    .line 1939
    .line 1940
    move-result v5

    .line 1941
    if-eqz v5, :cond_66

    .line 1942
    .line 1943
    goto :goto_26

    .line 1944
    :cond_66
    invoke-virtual {v7, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1945
    .line 1946
    .line 1947
    move-result v5

    .line 1948
    if-eqz v5, :cond_67

    .line 1949
    .line 1950
    sget-object v5, Landroidx/camera/camera2/internal/compat/quirk/ZslDisablerQuirk;->b:Ljava/util/List;

    .line 1951
    .line 1952
    invoke-static {v5}, Landroidx/camera/camera2/internal/compat/quirk/ZslDisablerQuirk;->a(Ljava/util/List;)Z

    .line 1953
    .line 1954
    .line 1955
    move-result v5

    .line 1956
    if-eqz v5, :cond_67

    .line 1957
    .line 1958
    :goto_26
    const/4 v5, 0x1

    .line 1959
    goto :goto_27

    .line 1960
    :cond_67
    move v5, v15

    .line 1961
    :goto_27
    const-class v8, Landroidx/camera/camera2/internal/compat/quirk/ZslDisablerQuirk;

    .line 1962
    .line 1963
    invoke-virtual {v3, v8, v5}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1964
    .line 1965
    .line 1966
    move-result v5

    .line 1967
    if-eqz v5, :cond_68

    .line 1968
    .line 1969
    new-instance v5, Landroidx/camera/camera2/internal/compat/quirk/ZslDisablerQuirk;

    .line 1970
    .line 1971
    invoke-direct {v5}, Landroidx/camera/camera2/internal/compat/quirk/ZslDisablerQuirk;-><init>()V

    .line 1972
    .line 1973
    .line 1974
    invoke-virtual {v10, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1975
    .line 1976
    .line 1977
    :cond_68
    invoke-virtual {v6, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1978
    .line 1979
    .line 1980
    move-result v5

    .line 1981
    if-eqz v5, :cond_69

    .line 1982
    .line 1983
    invoke-virtual {v2, v12}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1984
    .line 1985
    .line 1986
    move-result v2

    .line 1987
    if-eqz v2, :cond_69

    .line 1988
    .line 1989
    const/4 v2, 0x1

    .line 1990
    goto :goto_28

    .line 1991
    :cond_69
    move v2, v15

    .line 1992
    :goto_28
    const-class v5, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedOutputSizeQuirk;

    .line 1993
    .line 1994
    invoke-virtual {v3, v5, v2}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 1995
    .line 1996
    .line 1997
    move-result v2

    .line 1998
    if-eqz v2, :cond_6a

    .line 1999
    .line 2000
    new-instance v2, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedOutputSizeQuirk;

    .line 2001
    .line 2002
    invoke-direct {v2}, Landroidx/camera/camera2/internal/compat/quirk/ExtraSupportedOutputSizeQuirk;-><init>()V

    .line 2003
    .line 2004
    .line 2005
    invoke-virtual {v10, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2006
    .line 2007
    .line 2008
    :cond_6a
    sget-object v2, Landroidx/camera/camera2/internal/compat/quirk/InvalidVideoProfilesQuirk;->a:Ljava/util/List;

    .line 2009
    .line 2010
    invoke-virtual {v4, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2011
    .line 2012
    .line 2013
    move-result v2

    .line 2014
    const-string/jumbo v4, "tp1a"

    .line 2015
    .line 2016
    .line 2017
    if-eqz v2, :cond_6b

    .line 2018
    .line 2019
    sget-object v2, Landroid/os/Build;->ID:Ljava/lang/String;

    .line 2020
    .line 2021
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 2022
    .line 2023
    invoke-virtual {v2, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2024
    .line 2025
    .line 2026
    move-result-object v2

    .line 2027
    invoke-virtual {v2, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 2028
    .line 2029
    .line 2030
    move-result v2

    .line 2031
    if-eqz v2, :cond_6b

    .line 2032
    .line 2033
    goto/16 :goto_2b

    .line 2034
    .line 2035
    :cond_6b
    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 2036
    .line 2037
    invoke-virtual {v12, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2038
    .line 2039
    .line 2040
    move-result-object v5

    .line 2041
    sget-object v6, Landroidx/camera/camera2/internal/compat/quirk/InvalidVideoProfilesQuirk;->a:Ljava/util/List;

    .line 2042
    .line 2043
    invoke-interface {v6, v5}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 2044
    .line 2045
    .line 2046
    move-result v5

    .line 2047
    if-eqz v5, :cond_6c

    .line 2048
    .line 2049
    sget-object v5, Landroid/os/Build;->ID:Ljava/lang/String;

    .line 2050
    .line 2051
    invoke-virtual {v5, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2052
    .line 2053
    .line 2054
    move-result-object v6

    .line 2055
    invoke-virtual {v6, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 2056
    .line 2057
    .line 2058
    move-result v6

    .line 2059
    if-nez v6, :cond_73

    .line 2060
    .line 2061
    invoke-virtual {v5, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2062
    .line 2063
    .line 2064
    move-result-object v5

    .line 2065
    const-string/jumbo v6, "td1a"

    .line 2066
    .line 2067
    .line 2068
    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 2069
    .line 2070
    .line 2071
    move-result v5

    .line 2072
    if-eqz v5, :cond_6c

    .line 2073
    .line 2074
    goto :goto_2b

    .line 2075
    :cond_6c
    const-string v5, "redmi"

    .line 2076
    .line 2077
    invoke-virtual {v5, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2078
    .line 2079
    .line 2080
    move-result v5

    .line 2081
    if-nez v5, :cond_6d

    .line 2082
    .line 2083
    invoke-virtual {v7, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2084
    .line 2085
    .line 2086
    move-result v5

    .line 2087
    if-eqz v5, :cond_6e

    .line 2088
    .line 2089
    :cond_6d
    sget-object v5, Landroid/os/Build;->ID:Ljava/lang/String;

    .line 2090
    .line 2091
    invoke-virtual {v5, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2092
    .line 2093
    .line 2094
    move-result-object v6

    .line 2095
    const-string/jumbo v7, "tkq1"

    .line 2096
    .line 2097
    .line 2098
    invoke-virtual {v6, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 2099
    .line 2100
    .line 2101
    move-result v6

    .line 2102
    if-nez v6, :cond_73

    .line 2103
    .line 2104
    invoke-virtual {v5, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2105
    .line 2106
    .line 2107
    move-result-object v5

    .line 2108
    invoke-virtual {v5, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 2109
    .line 2110
    .line 2111
    move-result v4

    .line 2112
    if-eqz v4, :cond_6e

    .line 2113
    .line 2114
    goto :goto_2b

    .line 2115
    :cond_6e
    invoke-virtual {v12, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2116
    .line 2117
    .line 2118
    move-result-object v4

    .line 2119
    sget-object v5, Landroidx/camera/camera2/internal/compat/quirk/InvalidVideoProfilesQuirk;->b:Ljava/util/List;

    .line 2120
    .line 2121
    invoke-interface {v5, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 2122
    .line 2123
    .line 2124
    move-result v4

    .line 2125
    if-eqz v4, :cond_70

    .line 2126
    .line 2127
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2128
    .line 2129
    if-ne v4, v0, :cond_6f

    .line 2130
    .line 2131
    const/4 v4, 0x1

    .line 2132
    goto :goto_29

    .line 2133
    :cond_6f
    move v4, v15

    .line 2134
    :goto_29
    if-eqz v4, :cond_70

    .line 2135
    .line 2136
    goto :goto_2b

    .line 2137
    :cond_70
    invoke-virtual {v12, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2138
    .line 2139
    .line 2140
    move-result-object v2

    .line 2141
    sget-object v4, Landroidx/camera/camera2/internal/compat/quirk/InvalidVideoProfilesQuirk;->c:Ljava/util/List;

    .line 2142
    .line 2143
    invoke-interface {v4, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 2144
    .line 2145
    .line 2146
    move-result v2

    .line 2147
    if-eqz v2, :cond_72

    .line 2148
    .line 2149
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2150
    .line 2151
    if-ne v2, v0, :cond_71

    .line 2152
    .line 2153
    const/4 v4, 0x1

    .line 2154
    goto :goto_2a

    .line 2155
    :cond_71
    move v4, v15

    .line 2156
    :goto_2a
    if-eqz v4, :cond_72

    .line 2157
    .line 2158
    goto :goto_2b

    .line 2159
    :cond_72
    move v4, v15

    .line 2160
    goto :goto_2c

    .line 2161
    :cond_73
    :goto_2b
    const/4 v4, 0x1

    .line 2162
    :goto_2c
    const-class v0, Landroidx/camera/camera2/internal/compat/quirk/InvalidVideoProfilesQuirk;

    .line 2163
    .line 2164
    invoke-virtual {v3, v0, v4}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 2165
    .line 2166
    .line 2167
    move-result v0

    .line 2168
    if-eqz v0, :cond_74

    .line 2169
    .line 2170
    new-instance v0, Landroidx/camera/camera2/internal/compat/quirk/InvalidVideoProfilesQuirk;

    .line 2171
    .line 2172
    invoke-direct {v0}, Landroidx/camera/camera2/internal/compat/quirk/InvalidVideoProfilesQuirk;-><init>()V

    .line 2173
    .line 2174
    .line 2175
    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2176
    .line 2177
    .line 2178
    :cond_74
    const-string/jumbo v0, "samsungexynos7870"

    .line 2179
    .line 2180
    .line 2181
    sget-object v2, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    .line 2182
    .line 2183
    invoke-virtual {v0, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2184
    .line 2185
    .line 2186
    move-result v0

    .line 2187
    const-class v2, Landroidx/camera/camera2/internal/compat/quirk/Preview3AThreadCrashQuirk;

    .line 2188
    .line 2189
    invoke-virtual {v3, v2, v0}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 2190
    .line 2191
    .line 2192
    move-result v0

    .line 2193
    if-eqz v0, :cond_75

    .line 2194
    .line 2195
    new-instance v0, Landroidx/camera/camera2/internal/compat/quirk/Preview3AThreadCrashQuirk;

    .line 2196
    .line 2197
    invoke-direct {v0}, Landroidx/camera/camera2/internal/compat/quirk/Preview3AThreadCrashQuirk;-><init>()V

    .line 2198
    .line 2199
    .line 2200
    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2201
    .line 2202
    .line 2203
    :cond_75
    sget-object v0, Landroidx/camera/camera2/internal/compat/quirk/SmallDisplaySizeQuirk;->a:Ljava/util/HashMap;

    .line 2204
    .line 2205
    invoke-virtual {v12, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 2206
    .line 2207
    .line 2208
    move-result-object v1

    .line 2209
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 2210
    .line 2211
    .line 2212
    move-result v0

    .line 2213
    const-class v1, Landroidx/camera/camera2/internal/compat/quirk/SmallDisplaySizeQuirk;

    .line 2214
    .line 2215
    invoke-virtual {v3, v1, v0}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 2216
    .line 2217
    .line 2218
    move-result v0

    .line 2219
    if-eqz v0, :cond_76

    .line 2220
    .line 2221
    new-instance v0, Landroidx/camera/camera2/internal/compat/quirk/SmallDisplaySizeQuirk;

    .line 2222
    .line 2223
    invoke-direct {v0}, Landroidx/camera/camera2/internal/compat/quirk/SmallDisplaySizeQuirk;-><init>()V

    .line 2224
    .line 2225
    .line 2226
    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2227
    .line 2228
    .line 2229
    :cond_76
    invoke-virtual {v14, v11}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2230
    .line 2231
    .line 2232
    move-result v0

    .line 2233
    if-eqz v0, :cond_77

    .line 2234
    .line 2235
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2236
    .line 2237
    const/16 v1, 0x23

    .line 2238
    .line 2239
    if-lt v0, v1, :cond_77

    .line 2240
    .line 2241
    const/4 v15, 0x1

    .line 2242
    :cond_77
    const-class v0, Landroidx/camera/camera2/internal/compat/quirk/CaptureSessionShouldUseMrirQuirk;

    .line 2243
    .line 2244
    invoke-virtual {v3, v0, v15}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 2245
    .line 2246
    .line 2247
    move-result v0

    .line 2248
    if-eqz v0, :cond_78

    .line 2249
    .line 2250
    new-instance v0, Landroidx/camera/camera2/internal/compat/quirk/CaptureSessionShouldUseMrirQuirk;

    .line 2251
    .line 2252
    invoke-direct {v0}, Landroidx/camera/camera2/internal/compat/quirk/CaptureSessionShouldUseMrirQuirk;-><init>()V

    .line 2253
    .line 2254
    .line 2255
    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2256
    .line 2257
    .line 2258
    :cond_78
    invoke-direct {v9, v10}, Landroidx/camera/core/impl/y0;-><init>(Ljava/util/List;)V

    .line 2259
    .line 2260
    .line 2261
    sput-object v9, Landroidx/camera/camera2/internal/compat/quirk/a;->a:Landroidx/camera/core/impl/y0;

    .line 2262
    .line 2263
    sget-object v0, Landroidx/camera/camera2/internal/compat/quirk/a;->a:Landroidx/camera/core/impl/y0;

    .line 2264
    .line 2265
    invoke-static {v0}, Landroidx/camera/core/impl/y0;->d(Landroidx/camera/core/impl/y0;)V

    .line 2266
    .line 2267
    .line 2268
    invoke-static/range {v16 .. v16}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 2269
    .line 2270
    .line 2271
    return-void

    .line 2272
    :pswitch_2
    move-object/from16 v16, v8

    .line 2273
    .line 2274
    move v15, v10

    .line 2275
    move-object/from16 v1, p1

    .line 2276
    .line 2277
    check-cast v1, Landroidx/camera/core/impl/t0;

    .line 2278
    .line 2279
    new-instance v2, Landroidx/camera/core/impl/y0;

    .line 2280
    .line 2281
    new-instance v3, Ljava/util/ArrayList;

    .line 2282
    .line 2283
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 2284
    .line 2285
    .line 2286
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2287
    .line 2288
    if-ge v4, v0, :cond_7c

    .line 2289
    .line 2290
    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 2291
    .line 2292
    invoke-virtual {v7, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2293
    .line 2294
    .line 2295
    move-result v4

    .line 2296
    if-eqz v4, :cond_79

    .line 2297
    .line 2298
    sget-object v4, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 2299
    .line 2300
    const-string v5, "F2Q"

    .line 2301
    .line 2302
    invoke-virtual {v5, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2303
    .line 2304
    .line 2305
    move-result v5

    .line 2306
    if-nez v5, :cond_7b

    .line 2307
    .line 2308
    const-string v5, "Q2Q"

    .line 2309
    .line 2310
    invoke-virtual {v5, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2311
    .line 2312
    .line 2313
    move-result v4

    .line 2314
    if-eqz v4, :cond_79

    .line 2315
    .line 2316
    goto :goto_2d

    .line 2317
    :cond_79
    const-string v4, "OPPO"

    .line 2318
    .line 2319
    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2320
    .line 2321
    .line 2322
    move-result v4

    .line 2323
    if-eqz v4, :cond_7a

    .line 2324
    .line 2325
    const-string v4, "OP4E75L1"

    .line 2326
    .line 2327
    sget-object v5, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 2328
    .line 2329
    invoke-virtual {v4, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2330
    .line 2331
    .line 2332
    move-result v4

    .line 2333
    if-eqz v4, :cond_7a

    .line 2334
    .line 2335
    goto :goto_2d

    .line 2336
    :cond_7a
    const-string v4, "LENOVO"

    .line 2337
    .line 2338
    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2339
    .line 2340
    .line 2341
    move-result v0

    .line 2342
    if-eqz v0, :cond_7c

    .line 2343
    .line 2344
    const-string v0, "Q706F"

    .line 2345
    .line 2346
    sget-object v4, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 2347
    .line 2348
    invoke-virtual {v0, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2349
    .line 2350
    .line 2351
    move-result v0

    .line 2352
    if-eqz v0, :cond_7c

    .line 2353
    .line 2354
    :cond_7b
    :goto_2d
    const/4 v4, 0x1

    .line 2355
    goto :goto_2e

    .line 2356
    :cond_7c
    move v4, v15

    .line 2357
    :goto_2e
    const-class v0, Landroidx/camera/view/internal/compat/quirk/SurfaceViewStretchedQuirk;

    .line 2358
    .line 2359
    invoke-virtual {v1, v0, v4}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 2360
    .line 2361
    .line 2362
    move-result v0

    .line 2363
    if-eqz v0, :cond_7d

    .line 2364
    .line 2365
    new-instance v0, Landroidx/camera/view/internal/compat/quirk/SurfaceViewStretchedQuirk;

    .line 2366
    .line 2367
    invoke-direct {v0}, Landroidx/camera/view/internal/compat/quirk/SurfaceViewStretchedQuirk;-><init>()V

    .line 2368
    .line 2369
    .line 2370
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2371
    .line 2372
    .line 2373
    :cond_7d
    const-string v0, "XIAOMI"

    .line 2374
    .line 2375
    sget-object v4, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 2376
    .line 2377
    invoke-virtual {v0, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2378
    .line 2379
    .line 2380
    move-result v0

    .line 2381
    if-eqz v0, :cond_7e

    .line 2382
    .line 2383
    const-string v0, "M2101K7AG"

    .line 2384
    .line 2385
    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 2386
    .line 2387
    invoke-virtual {v0, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 2388
    .line 2389
    .line 2390
    move-result v0

    .line 2391
    if-eqz v0, :cond_7e

    .line 2392
    .line 2393
    const/4 v9, 0x1

    .line 2394
    goto :goto_2f

    .line 2395
    :cond_7e
    move v9, v15

    .line 2396
    :goto_2f
    const-class v0, Landroidx/camera/view/internal/compat/quirk/SurfaceViewNotCroppedByParentQuirk;

    .line 2397
    .line 2398
    invoke-virtual {v1, v0, v9}, Landroidx/camera/core/impl/t0;->a(Ljava/lang/Class;Z)Z

    .line 2399
    .line 2400
    .line 2401
    move-result v0

    .line 2402
    if-eqz v0, :cond_7f

    .line 2403
    .line 2404
    new-instance v0, Landroidx/camera/view/internal/compat/quirk/SurfaceViewNotCroppedByParentQuirk;

    .line 2405
    .line 2406
    invoke-direct {v0}, Landroidx/camera/view/internal/compat/quirk/SurfaceViewNotCroppedByParentQuirk;-><init>()V

    .line 2407
    .line 2408
    .line 2409
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2410
    .line 2411
    .line 2412
    :cond_7f
    invoke-direct {v2, v3}, Landroidx/camera/core/impl/y0;-><init>(Ljava/util/List;)V

    .line 2413
    .line 2414
    .line 2415
    sput-object v2, LJ/b;->a:Landroidx/camera/core/impl/y0;

    .line 2416
    .line 2417
    sget-object v0, LJ/b;->a:Landroidx/camera/core/impl/y0;

    .line 2418
    .line 2419
    invoke-static {v0}, Landroidx/camera/core/impl/y0;->d(Landroidx/camera/core/impl/y0;)V

    .line 2420
    .line 2421
    .line 2422
    invoke-static/range {v16 .. v16}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 2423
    .line 2424
    .line 2425
    return-void

    .line 2426
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
