.class public final LG0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LG0/c;-><init>()V

    return-void
.end method


# virtual methods
.method public final obtain(Landroid/content/Context;)LG0/d;
    .locals 7
    .param p1    # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi",
            "ClassVerificationFailure"
        }
    .end annotation

    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    .line 8
    sget-object v2, Landroidx/privacysandbox/ads/adservices/internal/b;->a:Landroidx/privacysandbox/ads/adservices/internal/b;

    .line 9
    .line 10
    const/16 v3, 0x21

    .line 11
    .line 12
    if-lt v1, v3, :cond_0

    .line 13
    .line 14
    invoke-virtual {v2}, Landroidx/privacysandbox/ads/adservices/internal/b;->a()I

    .line 15
    .line 16
    .line 17
    :cond_0
    const/4 v4, 0x0

    .line 18
    if-lt v1, v3, :cond_1

    .line 19
    .line 20
    invoke-virtual {v2}, Landroidx/privacysandbox/ads/adservices/internal/b;->a()I

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    goto :goto_0

    .line 25
    :cond_1
    move v2, v4

    .line 26
    :goto_0
    const/4 v3, 0x5

    .line 27
    if-lt v2, v3, :cond_2

    .line 28
    .line 29
    new-instance v1, LG0/f;

    .line 30
    .line 31
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    invoke-static {}, LG0/e;->k()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    const-string v0, "context.getSystemService\u2026ementManager::class.java)"

    .line 43
    .line 44
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-static {p1}, LG0/e;->c(Ljava/lang/Object;)Landroid/adservices/measurement/MeasurementManager;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-direct {v1, p1}, LG0/i;-><init>(Landroid/adservices/measurement/MeasurementManager;)V

    .line 52
    .line 53
    .line 54
    return-object v1

    .line 55
    :cond_2
    sget-object v2, Landroidx/privacysandbox/ads/adservices/internal/a;->a:Landroidx/privacysandbox/ads/adservices/internal/a;

    .line 56
    .line 57
    const/16 v3, 0x20

    .line 58
    .line 59
    const/16 v5, 0x1f

    .line 60
    .line 61
    if-eq v1, v5, :cond_3

    .line 62
    .line 63
    if-ne v1, v3, :cond_4

    .line 64
    .line 65
    :cond_3
    invoke-virtual {v2}, Landroidx/privacysandbox/ads/adservices/internal/a;->a()I

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    :cond_4
    const/16 v1, 0x9

    .line 70
    .line 71
    const/4 v6, 0x0

    .line 72
    if-lt v4, v1, :cond_7

    .line 73
    .line 74
    new-instance v1, LG0/b;

    .line 75
    .line 76
    const/4 v4, 0x0

    .line 77
    invoke-direct {v1, p1, v4}, LG0/b;-><init>(Landroid/content/Context;I)V

    .line 78
    .line 79
    .line 80
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    const-string/jumbo v0, "tag"

    .line 84
    .line 85
    .line 86
    const-string v4, "MeasurementManager"

    .line 87
    .line 88
    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    const-string v0, "manager"

    .line 92
    .line 93
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    :try_start_0
    invoke-virtual {v1, p1}, LG0/b;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v6
    :try_end_0
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_0 .. :try_end_0} :catch_0

    .line 100
    goto :goto_1

    .line 101
    :catch_0
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 102
    .line 103
    if-eq p1, v5, :cond_5

    .line 104
    .line 105
    if-ne p1, v3, :cond_6

    .line 106
    .line 107
    :cond_5
    invoke-virtual {v2}, Landroidx/privacysandbox/ads/adservices/internal/a;->a()I

    .line 108
    .line 109
    .line 110
    :cond_6
    :goto_1
    check-cast v6, LG0/d;

    .line 111
    .line 112
    :cond_7
    return-object v6
.end method
