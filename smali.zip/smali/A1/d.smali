.class public final LA1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/graphics/ImageDecoder$OnHeaderDecodedListener;


# instance fields
.field public final a:Lcom/bumptech/glide/load/resource/bitmap/u;

.field public final b:I

.field public final c:I

.field public final d:Lcom/bumptech/glide/load/b;

.field public final e:Lcom/bumptech/glide/load/resource/bitmap/m;

.field public final f:Z

.field public final g:Lcom/bumptech/glide/load/i;


# direct methods
.method public constructor <init>(IILcom/bumptech/glide/load/h;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Lcom/bumptech/glide/load/resource/bitmap/u;->a()Lcom/bumptech/glide/load/resource/bitmap/u;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iput-object v0, p0, LA1/d;->a:Lcom/bumptech/glide/load/resource/bitmap/u;

    .line 9
    .line 10
    iput p1, p0, LA1/d;->b:I

    .line 11
    .line 12
    iput p2, p0, LA1/d;->c:I

    .line 13
    .line 14
    sget-object p1, Lcom/bumptech/glide/load/resource/bitmap/o;->f:Lcom/bumptech/glide/load/g;

    .line 15
    .line 16
    invoke-virtual {p3, p1}, Lcom/bumptech/glide/load/h;->a(Lcom/bumptech/glide/load/g;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    check-cast p1, Lcom/bumptech/glide/load/b;

    .line 21
    .line 22
    iput-object p1, p0, LA1/d;->d:Lcom/bumptech/glide/load/b;

    .line 23
    .line 24
    sget-object p1, Lcom/bumptech/glide/load/resource/bitmap/m;->g:Lcom/bumptech/glide/load/g;

    .line 25
    .line 26
    invoke-virtual {p3, p1}, Lcom/bumptech/glide/load/h;->a(Lcom/bumptech/glide/load/g;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    check-cast p1, Lcom/bumptech/glide/load/resource/bitmap/m;

    .line 31
    .line 32
    iput-object p1, p0, LA1/d;->e:Lcom/bumptech/glide/load/resource/bitmap/m;

    .line 33
    .line 34
    sget-object p1, Lcom/bumptech/glide/load/resource/bitmap/o;->i:Lcom/bumptech/glide/load/g;

    .line 35
    .line 36
    invoke-virtual {p3, p1}, Lcom/bumptech/glide/load/h;->a(Lcom/bumptech/glide/load/g;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p2

    .line 40
    if-eqz p2, :cond_0

    .line 41
    .line 42
    invoke-virtual {p3, p1}, Lcom/bumptech/glide/load/h;->a(Lcom/bumptech/glide/load/g;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    check-cast p1, Ljava/lang/Boolean;

    .line 47
    .line 48
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    if-eqz p1, :cond_0

    .line 53
    .line 54
    const/4 p1, 0x1

    .line 55
    goto :goto_0

    .line 56
    :cond_0
    const/4 p1, 0x0

    .line 57
    :goto_0
    iput-boolean p1, p0, LA1/d;->f:Z

    .line 58
    .line 59
    sget-object p1, Lcom/bumptech/glide/load/resource/bitmap/o;->g:Lcom/bumptech/glide/load/g;

    .line 60
    .line 61
    invoke-virtual {p3, p1}, Lcom/bumptech/glide/load/h;->a(Lcom/bumptech/glide/load/g;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    check-cast p1, Lcom/bumptech/glide/load/i;

    .line 66
    .line 67
    iput-object p1, p0, LA1/d;->g:Lcom/bumptech/glide/load/i;

    .line 68
    .line 69
    return-void
.end method


# virtual methods
.method public final onHeaderDecoded(Landroid/graphics/ImageDecoder;Landroid/graphics/ImageDecoder$ImageInfo;Landroid/graphics/ImageDecoder$Source;)V
    .locals 5

    .line 1
    iget-object p3, p0, LA1/d;->a:Lcom/bumptech/glide/load/resource/bitmap/u;

    .line 2
    .line 3
    iget v0, p0, LA1/d;->b:I

    .line 4
    .line 5
    iget v1, p0, LA1/d;->c:I

    .line 6
    .line 7
    iget-boolean v2, p0, LA1/d;->f:Z

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    invoke-virtual {p3, v0, v1, v2, v3}, Lcom/bumptech/glide/load/resource/bitmap/u;->c(IIZZ)Z

    .line 11
    .line 12
    .line 13
    move-result p3

    .line 14
    if-eqz p3, :cond_0

    .line 15
    .line 16
    invoke-static {p1}, LA1/a;->n(Landroid/graphics/ImageDecoder;)V

    .line 17
    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    invoke-static {p1}, LA1/a;->z(Landroid/graphics/ImageDecoder;)V

    .line 21
    .line 22
    .line 23
    :goto_0
    iget-object p3, p0, LA1/d;->d:Lcom/bumptech/glide/load/b;

    .line 24
    .line 25
    sget-object v0, Lcom/bumptech/glide/load/b;->b:Lcom/bumptech/glide/load/b;

    .line 26
    .line 27
    if-ne p3, v0, :cond_1

    .line 28
    .line 29
    invoke-static {p1}, LA1/a;->D(Landroid/graphics/ImageDecoder;)V

    .line 30
    .line 31
    .line 32
    :cond_1
    new-instance p3, LA1/c;

    .line 33
    .line 34
    invoke-direct {p3}, Ljava/lang/Object;-><init>()V

    .line 35
    .line 36
    .line 37
    invoke-static {p1, p3}, LA1/a;->p(Landroid/graphics/ImageDecoder;LA1/c;)V

    .line 38
    .line 39
    .line 40
    invoke-static {p2}, LA1/a;->k(Landroid/graphics/ImageDecoder$ImageInfo;)Landroid/util/Size;

    .line 41
    .line 42
    .line 43
    move-result-object p3

    .line 44
    iget v0, p0, LA1/d;->b:I

    .line 45
    .line 46
    const/high16 v1, -0x80000000

    .line 47
    .line 48
    if-ne v0, v1, :cond_2

    .line 49
    .line 50
    invoke-virtual {p3}, Landroid/util/Size;->getWidth()I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    :cond_2
    iget v2, p0, LA1/d;->c:I

    .line 55
    .line 56
    if-ne v2, v1, :cond_3

    .line 57
    .line 58
    invoke-virtual {p3}, Landroid/util/Size;->getHeight()I

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    :cond_3
    iget-object v1, p0, LA1/d;->e:Lcom/bumptech/glide/load/resource/bitmap/m;

    .line 63
    .line 64
    invoke-virtual {p3}, Landroid/util/Size;->getWidth()I

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    invoke-virtual {p3}, Landroid/util/Size;->getHeight()I

    .line 69
    .line 70
    .line 71
    move-result v4

    .line 72
    invoke-virtual {v1, v3, v4, v0, v2}, Lcom/bumptech/glide/load/resource/bitmap/m;->b(IIII)F

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    invoke-virtual {p3}, Landroid/util/Size;->getWidth()I

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    int-to-float v1, v1

    .line 81
    mul-float/2addr v1, v0

    .line 82
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    invoke-virtual {p3}, Landroid/util/Size;->getHeight()I

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    int-to-float v2, v2

    .line 91
    mul-float/2addr v0, v2

    .line 92
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    const-string v2, "ImageDecoder"

    .line 97
    .line 98
    const/4 v3, 0x2

    .line 99
    invoke-static {v2, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    if-eqz v2, :cond_4

    .line 104
    .line 105
    invoke-virtual {p3}, Landroid/util/Size;->getWidth()I

    .line 106
    .line 107
    .line 108
    invoke-virtual {p3}, Landroid/util/Size;->getHeight()I

    .line 109
    .line 110
    .line 111
    :cond_4
    invoke-static {p1, v1, v0}, LA1/a;->o(Landroid/graphics/ImageDecoder;II)V

    .line 112
    .line 113
    .line 114
    iget-object p3, p0, LA1/d;->g:Lcom/bumptech/glide/load/i;

    .line 115
    .line 116
    if-eqz p3, :cond_7

    .line 117
    .line 118
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 119
    .line 120
    const/16 v1, 0x1c

    .line 121
    .line 122
    if-lt v0, v1, :cond_6

    .line 123
    .line 124
    sget-object v0, Lcom/bumptech/glide/load/i;->a:Lcom/bumptech/glide/load/i;

    .line 125
    .line 126
    if-ne p3, v0, :cond_5

    .line 127
    .line 128
    invoke-static {p2}, LA1/a;->c(Landroid/graphics/ImageDecoder$ImageInfo;)Landroid/graphics/ColorSpace;

    .line 129
    .line 130
    .line 131
    move-result-object p3

    .line 132
    if-eqz p3, :cond_5

    .line 133
    .line 134
    invoke-static {p2}, LA1/a;->c(Landroid/graphics/ImageDecoder$ImageInfo;)Landroid/graphics/ColorSpace;

    .line 135
    .line 136
    .line 137
    move-result-object p2

    .line 138
    invoke-static {p2}, LA1/b;->w(Landroid/graphics/ColorSpace;)Z

    .line 139
    .line 140
    .line 141
    move-result p2

    .line 142
    if-eqz p2, :cond_5

    .line 143
    .line 144
    invoke-static {}, LA1/b;->e()Landroid/graphics/ColorSpace$Named;

    .line 145
    .line 146
    .line 147
    move-result-object p2

    .line 148
    goto :goto_1

    .line 149
    :cond_5
    invoke-static {}, LA1/b;->y()Landroid/graphics/ColorSpace$Named;

    .line 150
    .line 151
    .line 152
    move-result-object p2

    .line 153
    :goto_1
    invoke-static {p2}, LA1/b;->g(Landroid/graphics/ColorSpace$Named;)Landroid/graphics/ColorSpace;

    .line 154
    .line 155
    .line 156
    move-result-object p2

    .line 157
    invoke-static {p1, p2}, LA1/a;->q(Landroid/graphics/ImageDecoder;Landroid/graphics/ColorSpace;)V

    .line 158
    .line 159
    .line 160
    return-void

    .line 161
    :cond_6
    const/16 p2, 0x1a

    .line 162
    .line 163
    if-lt v0, p2, :cond_7

    .line 164
    .line 165
    invoke-static {}, LA1/b;->y()Landroid/graphics/ColorSpace$Named;

    .line 166
    .line 167
    .line 168
    invoke-static {}, LA1/b;->f()Landroid/graphics/ColorSpace;

    .line 169
    .line 170
    .line 171
    move-result-object p2

    .line 172
    invoke-static {p1, p2}, LA1/a;->q(Landroid/graphics/ImageDecoder;Landroid/graphics/ColorSpace;)V

    .line 173
    .line 174
    .line 175
    :cond_7
    return-void
.end method
