.class public abstract LB0/a;
.super Ljava/lang/Object;
.source "SourceFile"
