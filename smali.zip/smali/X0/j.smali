.class public final LX0/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlinx/coroutines/flow/Flow;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LX0/j;->a:I

    iput-object p1, p0, LX0/j;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final collect(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, LX0/j;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, LX0/i;

    .line 7
    .line 8
    const/4 v1, 0x3

    .line 9
    invoke-direct {v0, p1, v1}, LX0/i;-><init>(Lkotlinx/coroutines/flow/FlowCollector;I)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, LX0/j;->b:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p1, Lcom/palmpay/lib/webview/cache/match/impl/PreloadHtmlMatcher$downloadHtmlFile$$inlined$map$1;

    .line 15
    .line 16
    invoke-interface {p1, v0, p2}, Lkotlinx/coroutines/flow/Flow;->collect(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    sget-object p2, LEf/a;->a:LEf/a;

    .line 21
    .line 22
    if-ne p1, p2, :cond_0

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 26
    .line 27
    :goto_0
    return-object p1

    .line 28
    :pswitch_0
    new-instance v0, LX0/i;

    .line 29
    .line 30
    const/4 v1, 0x2

    .line 31
    invoke-direct {v0, p1, v1}, LX0/i;-><init>(Lkotlinx/coroutines/flow/FlowCollector;I)V

    .line 32
    .line 33
    .line 34
    iget-object p1, p0, LX0/j;->b:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Landroidx/slidingpanelayout/widget/b;

    .line 37
    .line 38
    invoke-virtual {p1, v0, p2}, Landroidx/slidingpanelayout/widget/b;->collect(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    sget-object p2, LEf/a;->a:LEf/a;

    .line 43
    .line 44
    if-ne p1, p2, :cond_1

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 48
    .line 49
    :goto_1
    return-object p1

    .line 50
    :pswitch_1
    iget-object v0, p0, LX0/j;->b:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v0, Ljava/io/Serializable;

    .line 53
    .line 54
    invoke-interface {p1, v0, p2}, Lkotlinx/coroutines/flow/FlowCollector;->emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    sget-object p2, LEf/a;->a:LEf/a;

    .line 59
    .line 60
    if-ne p1, p2, :cond_2

    .line 61
    .line 62
    goto :goto_2

    .line 63
    :cond_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 64
    .line 65
    :goto_2
    return-object p1

    .line 66
    :pswitch_2
    new-instance v0, LX0/i;

    .line 67
    .line 68
    const/4 v1, 0x1

    .line 69
    invoke-direct {v0, p1, v1}, LX0/i;-><init>(Lkotlinx/coroutines/flow/FlowCollector;I)V

    .line 70
    .line 71
    .line 72
    iget-object p1, p0, LX0/j;->b:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast p1, Lkotlinx/coroutines/flow/u;

    .line 75
    .line 76
    invoke-virtual {p1, v0, p2}, Lkotlinx/coroutines/flow/u;->collect(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    sget-object p2, LEf/a;->a:LEf/a;

    .line 81
    .line 82
    if-ne p1, p2, :cond_3

    .line 83
    .line 84
    goto :goto_3

    .line 85
    :cond_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 86
    .line 87
    :goto_3
    return-object p1

    .line 88
    :pswitch_3
    new-instance v2, LC0/t;

    .line 89
    .line 90
    iget-object v0, p0, LX0/j;->b:Ljava/lang/Object;

    .line 91
    .line 92
    move-object v1, v0

    .line 93
    check-cast v1, [Lkotlinx/coroutines/flow/Flow;

    .line 94
    .line 95
    const/16 v0, 0xe

    .line 96
    .line 97
    invoke-direct {v2, v1, v0}, LC0/t;-><init>(Ljava/lang/Object;I)V

    .line 98
    .line 99
    .line 100
    new-instance v3, LB6/V;

    .line 101
    .line 102
    const/4 v0, 0x3

    .line 103
    const/4 v4, 0x0

    .line 104
    invoke-direct {v3, v0, v4}, LB6/V;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 105
    .line 106
    .line 107
    new-instance v0, LZf/t;

    .line 108
    .line 109
    const/4 v5, 0x0

    .line 110
    move-object v4, p1

    .line 111
    invoke-direct/range {v0 .. v5}, LZf/t;-><init>([Lkotlinx/coroutines/flow/Flow;LC0/t;LB6/V;Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)V

    .line 112
    .line 113
    .line 114
    new-instance p1, LWf/u0;

    .line 115
    .line 116
    invoke-interface {p2}, Lkotlin/coroutines/Continuation;->getContext()Lkotlin/coroutines/CoroutineContext;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    const/4 v2, 0x1

    .line 121
    invoke-direct {p1, v1, p2, v2}, LWf/u0;-><init>(Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;I)V

    .line 122
    .line 123
    .line 124
    invoke-static {p1, p1, v0}, Lz5/l;->J(Lag/r;Lag/r;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    sget-object v0, LEf/a;->a:LEf/a;

    .line 129
    .line 130
    if-ne p1, v0, :cond_4

    .line 131
    .line 132
    const-string v1, "frame"

    .line 133
    .line 134
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    :cond_4
    if-ne p1, v0, :cond_5

    .line 138
    .line 139
    goto :goto_4

    .line 140
    :cond_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 141
    .line 142
    :goto_4
    if-ne p1, v0, :cond_6

    .line 143
    .line 144
    goto :goto_5

    .line 145
    :cond_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 146
    .line 147
    :goto_5
    return-object p1

    .line 148
    :pswitch_4
    move-object v4, p1

    .line 149
    new-instance p1, LZf/v;

    .line 150
    .line 151
    iget-object v0, p0, LX0/j;->b:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast v0, Lkotlinx/coroutines/flow/p;

    .line 154
    .line 155
    const/4 v1, 0x0

    .line 156
    invoke-direct {p1, v0, v4, v1}, LZf/v;-><init>(Lkotlinx/coroutines/flow/p;Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)V

    .line 157
    .line 158
    .line 159
    new-instance v0, LWf/u0;

    .line 160
    .line 161
    invoke-interface {p2}, Lkotlin/coroutines/Continuation;->getContext()Lkotlin/coroutines/CoroutineContext;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    const/4 v2, 0x1

    .line 166
    invoke-direct {v0, v1, p2, v2}, LWf/u0;-><init>(Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;I)V

    .line 167
    .line 168
    .line 169
    invoke-static {v0, v0, p1}, Lz5/l;->J(Lag/r;Lag/r;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    sget-object v0, LEf/a;->a:LEf/a;

    .line 174
    .line 175
    if-ne p1, v0, :cond_7

    .line 176
    .line 177
    const-string v1, "frame"

    .line 178
    .line 179
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 180
    .line 181
    .line 182
    :cond_7
    if-ne p1, v0, :cond_8

    .line 183
    .line 184
    goto :goto_6

    .line 185
    :cond_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 186
    .line 187
    :goto_6
    return-object p1

    .line 188
    :pswitch_5
    move-object v4, p1

    .line 189
    new-instance p1, LX0/i;

    .line 190
    .line 191
    const/4 v0, 0x0

    .line 192
    invoke-direct {p1, v4, v0}, LX0/i;-><init>(Lkotlinx/coroutines/flow/FlowCollector;I)V

    .line 193
    .line 194
    .line 195
    iget-object v0, p0, LX0/j;->b:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast v0, Lkotlinx/coroutines/flow/u;

    .line 198
    .line 199
    invoke-virtual {v0, p1, p2}, Lkotlinx/coroutines/flow/u;->collect(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    sget-object p2, LEf/a;->a:LEf/a;

    .line 204
    .line 205
    if-ne p1, p2, :cond_9

    .line 206
    .line 207
    goto :goto_7

    .line 208
    :cond_9
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 209
    .line 210
    :goto_7
    return-object p1

    .line 211
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
