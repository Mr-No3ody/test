.class public final LX0/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlinx/coroutines/flow/FlowCollector;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lkotlinx/coroutines/flow/FlowCollector;


# direct methods
.method public synthetic constructor <init>(Lkotlinx/coroutines/flow/FlowCollector;I)V
    .locals 0

    .line 1
    iput p2, p0, LX0/i;->a:I

    iput-object p1, p0, LX0/i;->b:Lkotlinx/coroutines/flow/FlowCollector;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p2, Lkotlinx/coroutines/flow/D;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lkotlinx/coroutines/flow/D;

    .line 7
    .line 8
    iget v1, v0, Lkotlinx/coroutines/flow/D;->c:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lkotlinx/coroutines/flow/D;->c:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lkotlinx/coroutines/flow/D;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/D;-><init>(LX0/i;Lkotlin/coroutines/Continuation;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lkotlinx/coroutines/flow/D;->a:Ljava/lang/Object;

    .line 26
    .line 27
    sget-object v1, LEf/a;->a:LEf/a;

    .line 28
    .line 29
    iget v2, v0, Lkotlinx/coroutines/flow/D;->c:I

    .line 30
    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz v2, :cond_2

    .line 33
    .line 34
    if-ne v2, v3, :cond_1

    .line 35
    .line 36
    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    goto :goto_2

    .line 40
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 41
    .line 42
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 43
    .line 44
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    throw p1

    .line 48
    :cond_2
    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    iput v3, v0, Lkotlinx/coroutines/flow/D;->c:I

    .line 52
    .line 53
    iget-object p2, p0, LX0/i;->b:Lkotlinx/coroutines/flow/FlowCollector;

    .line 54
    .line 55
    instance-of v2, p2, Lkotlinx/coroutines/flow/i0;

    .line 56
    .line 57
    if-nez v2, :cond_5

    .line 58
    .line 59
    invoke-interface {p1, p2, v0}, Lkotlinx/coroutines/flow/Flow;->collect(Lkotlinx/coroutines/flow/FlowCollector;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    if-ne p1, v1, :cond_3

    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 67
    .line 68
    :goto_1
    if-ne p1, v1, :cond_4

    .line 69
    .line 70
    return-object v1

    .line 71
    :cond_4
    :goto_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 72
    .line 73
    return-object p1

    .line 74
    :cond_5
    check-cast p2, Lkotlinx/coroutines/flow/i0;

    .line 75
    .line 76
    iget-object p1, p2, Lkotlinx/coroutines/flow/i0;->a:Ljava/lang/Throwable;

    .line 77
    .line 78
    throw p1
.end method

.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LX0/i;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    instance-of v0, p2, Lkotlinx/coroutines/flow/O;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    move-object v0, p2

    .line 11
    check-cast v0, Lkotlinx/coroutines/flow/O;

    .line 12
    .line 13
    iget v1, v0, Lkotlinx/coroutines/flow/O;->b:I

    .line 14
    .line 15
    const/high16 v2, -0x80000000

    .line 16
    .line 17
    and-int v3, v1, v2

    .line 18
    .line 19
    if-eqz v3, :cond_0

    .line 20
    .line 21
    sub-int/2addr v1, v2

    .line 22
    iput v1, v0, Lkotlinx/coroutines/flow/O;->b:I

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    new-instance v0, Lkotlinx/coroutines/flow/O;

    .line 26
    .line 27
    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/O;-><init>(LX0/i;Lkotlin/coroutines/Continuation;)V

    .line 28
    .line 29
    .line 30
    :goto_0
    iget-object p2, v0, Lkotlinx/coroutines/flow/O;->a:Ljava/lang/Object;

    .line 31
    .line 32
    sget-object v1, LEf/a;->a:LEf/a;

    .line 33
    .line 34
    iget v2, v0, Lkotlinx/coroutines/flow/O;->b:I

    .line 35
    .line 36
    const/4 v3, 0x1

    .line 37
    if-eqz v2, :cond_2

    .line 38
    .line 39
    if-ne v2, v3, :cond_1

    .line 40
    .line 41
    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 46
    .line 47
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 48
    .line 49
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw p1

    .line 53
    :cond_2
    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    if-eqz p1, :cond_3

    .line 57
    .line 58
    iput v3, v0, Lkotlinx/coroutines/flow/O;->b:I

    .line 59
    .line 60
    iget-object p2, p0, LX0/i;->b:Lkotlinx/coroutines/flow/FlowCollector;

    .line 61
    .line 62
    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/flow/FlowCollector;->emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    if-ne p1, v1, :cond_3

    .line 67
    .line 68
    goto :goto_2

    .line 69
    :cond_3
    :goto_1
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 70
    .line 71
    :goto_2
    return-object v1

    .line 72
    :pswitch_0
    check-cast p1, Lkotlinx/coroutines/flow/Flow;

    .line 73
    .line 74
    invoke-virtual {p0, p1, p2}, LX0/i;->a(Lkotlinx/coroutines/flow/Flow;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    return-object p1

    .line 79
    :pswitch_1
    instance-of v0, p2, Lj0/s;

    .line 80
    .line 81
    if-eqz v0, :cond_4

    .line 82
    .line 83
    move-object v0, p2

    .line 84
    check-cast v0, Lj0/s;

    .line 85
    .line 86
    iget v1, v0, Lj0/s;->b:I

    .line 87
    .line 88
    const/high16 v2, -0x80000000

    .line 89
    .line 90
    and-int v3, v1, v2

    .line 91
    .line 92
    if-eqz v3, :cond_4

    .line 93
    .line 94
    sub-int/2addr v1, v2

    .line 95
    iput v1, v0, Lj0/s;->b:I

    .line 96
    .line 97
    goto :goto_3

    .line 98
    :cond_4
    new-instance v0, Lj0/s;

    .line 99
    .line 100
    invoke-direct {v0, p0, p2}, Lj0/s;-><init>(LX0/i;Lkotlin/coroutines/Continuation;)V

    .line 101
    .line 102
    .line 103
    :goto_3
    iget-object p2, v0, Lj0/s;->a:Ljava/lang/Object;

    .line 104
    .line 105
    sget-object v1, LEf/a;->a:LEf/a;

    .line 106
    .line 107
    iget v2, v0, Lj0/s;->b:I

    .line 108
    .line 109
    const/4 v3, 0x1

    .line 110
    if-eqz v2, :cond_6

    .line 111
    .line 112
    if-ne v2, v3, :cond_5

    .line 113
    .line 114
    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    goto :goto_4

    .line 118
    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 119
    .line 120
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 121
    .line 122
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    throw p1

    .line 126
    :cond_6
    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    check-cast p1, Lj0/w0;

    .line 130
    .line 131
    instance-of p2, p1, Lj0/n0;

    .line 132
    .line 133
    if-nez p2, :cond_b

    .line 134
    .line 135
    instance-of p2, p1, Lj0/b;

    .line 136
    .line 137
    if-eqz p2, :cond_8

    .line 138
    .line 139
    check-cast p1, Lj0/b;

    .line 140
    .line 141
    iget-object p1, p1, Lj0/b;->b:Ljava/lang/Object;

    .line 142
    .line 143
    iput v3, v0, Lj0/s;->b:I

    .line 144
    .line 145
    iget-object p2, p0, LX0/i;->b:Lkotlinx/coroutines/flow/FlowCollector;

    .line 146
    .line 147
    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/flow/FlowCollector;->emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    if-ne p1, v1, :cond_7

    .line 152
    .line 153
    goto :goto_5

    .line 154
    :cond_7
    :goto_4
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 155
    .line 156
    :goto_5
    return-object v1

    .line 157
    :cond_8
    instance-of p2, p1, Lj0/a0;

    .line 158
    .line 159
    if-eqz p2, :cond_9

    .line 160
    .line 161
    goto :goto_6

    .line 162
    :cond_9
    instance-of v3, p1, Lj0/x0;

    .line 163
    .line 164
    :goto_6
    if-eqz v3, :cond_a

    .line 165
    .line 166
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 167
    .line 168
    const-string p2, "This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542"

    .line 169
    .line 170
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    throw p1

    .line 174
    :cond_a
    new-instance p1, Lxf/l;

    .line 175
    .line 176
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 177
    .line 178
    .line 179
    throw p1

    .line 180
    :cond_b
    check-cast p1, Lj0/n0;

    .line 181
    .line 182
    iget-object p1, p1, Lj0/n0;->b:Ljava/lang/Throwable;

    .line 183
    .line 184
    throw p1

    .line 185
    :pswitch_2
    instance-of v0, p2, LX0/h;

    .line 186
    .line 187
    if-eqz v0, :cond_c

    .line 188
    .line 189
    move-object v0, p2

    .line 190
    check-cast v0, LX0/h;

    .line 191
    .line 192
    iget v1, v0, LX0/h;->b:I

    .line 193
    .line 194
    const/high16 v2, -0x80000000

    .line 195
    .line 196
    and-int v3, v1, v2

    .line 197
    .line 198
    if-eqz v3, :cond_c

    .line 199
    .line 200
    sub-int/2addr v1, v2

    .line 201
    iput v1, v0, LX0/h;->b:I

    .line 202
    .line 203
    goto :goto_7

    .line 204
    :cond_c
    new-instance v0, LX0/h;

    .line 205
    .line 206
    invoke-direct {v0, p0, p2}, LX0/h;-><init>(LX0/i;Lkotlin/coroutines/Continuation;)V

    .line 207
    .line 208
    .line 209
    :goto_7
    iget-object p2, v0, LX0/h;->a:Ljava/lang/Object;

    .line 210
    .line 211
    sget-object v1, LEf/a;->a:LEf/a;

    .line 212
    .line 213
    iget v2, v0, LX0/h;->b:I

    .line 214
    .line 215
    const/4 v3, 0x1

    .line 216
    if-eqz v2, :cond_e

    .line 217
    .line 218
    if-ne v2, v3, :cond_d

    .line 219
    .line 220
    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 221
    .line 222
    .line 223
    goto :goto_8

    .line 224
    :cond_d
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 225
    .line 226
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 227
    .line 228
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    throw p1

    .line 232
    :cond_e
    invoke-static {p2}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 233
    .line 234
    .line 235
    instance-of p2, p1, Landroidx/work/impl/constraints/b;

    .line 236
    .line 237
    if-eqz p2, :cond_f

    .line 238
    .line 239
    iput v3, v0, LX0/h;->b:I

    .line 240
    .line 241
    iget-object p2, p0, LX0/i;->b:Lkotlinx/coroutines/flow/FlowCollector;

    .line 242
    .line 243
    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/flow/FlowCollector;->emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    if-ne p1, v1, :cond_f

    .line 248
    .line 249
    goto :goto_9

    .line 250
    :cond_f
    :goto_8
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 251
    .line 252
    :goto_9
    return-object v1

    .line 253
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
