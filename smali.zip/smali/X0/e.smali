.class public final LX0/e;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:Lcom/google/common/util/concurrent/ListenableFuture;

.field public b:LWf/t0;

.field public c:I

.field public synthetic d:Ljava/lang/Object;

.field public final synthetic e:LV0/B;

.field public final synthetic f:LF1/b;

.field public final synthetic g:Landroidx/work/impl/model/k;


# direct methods
.method public constructor <init>(LV0/B;LF1/b;Landroidx/work/impl/model/k;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LX0/e;->e:LV0/B;

    .line 2
    .line 3
    iput-object p2, p0, LX0/e;->f:LF1/b;

    .line 4
    .line 5
    iput-object p3, p0, LX0/e;->g:Landroidx/work/impl/model/k;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 4

    .line 1
    new-instance v0, LX0/e;

    .line 2
    .line 3
    iget-object v1, p0, LX0/e;->f:LF1/b;

    .line 4
    .line 5
    iget-object v2, p0, LX0/e;->g:Landroidx/work/impl/model/k;

    .line 6
    .line 7
    iget-object v3, p0, LX0/e;->e:LV0/B;

    .line 8
    .line 9
    invoke-direct {v0, v3, v1, v2, p2}, LX0/e;-><init>(LV0/B;LF1/b;Landroidx/work/impl/model/k;Lkotlin/coroutines/Continuation;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, v0, LX0/e;->d:Ljava/lang/Object;

    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LX0/e;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LX0/e;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LX0/e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LX0/e;->c:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/16 v3, -0x100

    .line 7
    .line 8
    iget-object v4, p0, LX0/e;->e:LV0/B;

    .line 9
    .line 10
    const/4 v5, 0x1

    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    if-ne v1, v5, :cond_0

    .line 14
    .line 15
    iget-object v1, p0, LX0/e;->b:LWf/t0;

    .line 16
    .line 17
    iget-object v6, p0, LX0/e;->a:Lcom/google/common/util/concurrent/ListenableFuture;

    .line 18
    .line 19
    iget-object v0, p0, LX0/e;->d:Ljava/lang/Object;

    .line 20
    .line 21
    move-object v7, v0

    .line 22
    check-cast v7, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 23
    .line 24
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :catchall_0
    move-exception v0

    .line 29
    move-object p1, v0

    .line 30
    goto :goto_2

    .line 31
    :catch_0
    move-exception v0

    .line 32
    move-object p1, v0

    .line 33
    goto :goto_3

    .line 34
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 35
    .line 36
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 37
    .line 38
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw p1

    .line 42
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object p1, p0, LX0/e;->d:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 48
    .line 49
    new-instance v9, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 50
    .line 51
    invoke-direct {v9, v3}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v4}, LV0/B;->b()Landroidx/concurrent/futures/m;

    .line 55
    .line 56
    .line 57
    move-result-object v10

    .line 58
    const-string v1, "delegate.startWork()"

    .line 59
    .line 60
    invoke-static {v10, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    new-instance v6, LX0/d;

    .line 64
    .line 65
    const/4 v11, 0x0

    .line 66
    iget-object v7, p0, LX0/e;->f:LF1/b;

    .line 67
    .line 68
    iget-object v8, p0, LX0/e;->g:Landroidx/work/impl/model/k;

    .line 69
    .line 70
    invoke-direct/range {v6 .. v11}, LX0/d;-><init>(LF1/b;Landroidx/work/impl/model/k;Ljava/util/concurrent/atomic/AtomicInteger;Lcom/google/common/util/concurrent/ListenableFuture;Lkotlin/coroutines/Continuation;)V

    .line 71
    .line 72
    .line 73
    const/4 v1, 0x3

    .line 74
    invoke-static {p1, v2, v2, v6, v1}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    :try_start_1
    iput-object v9, p0, LX0/e;->d:Ljava/lang/Object;

    .line 79
    .line 80
    iput-object v10, p0, LX0/e;->a:Lcom/google/common/util/concurrent/ListenableFuture;

    .line 81
    .line 82
    iput-object v1, p0, LX0/e;->b:LWf/t0;

    .line 83
    .line 84
    iput v5, p0, LX0/e;->c:I

    .line 85
    .line 86
    invoke-static {v10, p0}, LG8/a;->h(Lcom/google/common/util/concurrent/ListenableFuture;LFf/c;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p1
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 90
    if-ne p1, v0, :cond_2

    .line 91
    .line 92
    return-object v0

    .line 93
    :cond_2
    move-object v7, v9

    .line 94
    move-object v6, v10

    .line 95
    :goto_0
    :try_start_2
    check-cast p1, LV0/A;
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 96
    .line 97
    invoke-interface {v1, v2}, Lkotlinx/coroutines/Job;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 98
    .line 99
    .line 100
    return-object p1

    .line 101
    :goto_1
    move-object v7, v9

    .line 102
    move-object v6, v10

    .line 103
    goto :goto_3

    .line 104
    :catch_1
    move-exception v0

    .line 105
    move-object p1, v0

    .line 106
    goto :goto_1

    .line 107
    :goto_2
    :try_start_3
    sget-object v0, LX0/m;->a:Ljava/lang/String;

    .line 108
    .line 109
    invoke-static {}, LV0/C;->c()LV0/C;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 114
    .line 115
    .line 116
    move-result-object v3

    .line 117
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 121
    .line 122
    .line 123
    throw p1

    .line 124
    :catchall_1
    move-exception v0

    .line 125
    move-object p1, v0

    .line 126
    goto :goto_5

    .line 127
    :goto_3
    sget-object v0, LX0/m;->a:Ljava/lang/String;

    .line 128
    .line 129
    invoke-static {}, LV0/C;->c()LV0/C;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    .line 135
    .line 136
    move-result-object v4

    .line 137
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 141
    .line 142
    .line 143
    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 144
    .line 145
    .line 146
    move-result v0

    .line 147
    if-eq v0, v3, :cond_3

    .line 148
    .line 149
    goto :goto_4

    .line 150
    :cond_3
    const/4 v5, 0x0

    .line 151
    :goto_4
    invoke-interface {v6}, Ljava/util/concurrent/Future;->isCancelled()Z

    .line 152
    .line 153
    .line 154
    move-result v0

    .line 155
    if-eqz v0, :cond_4

    .line 156
    .line 157
    if-eqz v5, :cond_4

    .line 158
    .line 159
    new-instance p1, LX0/a;

    .line 160
    .line 161
    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 162
    .line 163
    .line 164
    move-result v0

    .line 165
    invoke-direct {p1, v0}, LX0/a;-><init>(I)V

    .line 166
    .line 167
    .line 168
    throw p1

    .line 169
    :cond_4
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 170
    :goto_5
    invoke-interface {v1, v2}, Lkotlinx/coroutines/Job;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 171
    .line 172
    .line 173
    throw p1
.end method
