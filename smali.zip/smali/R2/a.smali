.class public final LR2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/fresco/animation/frame/FrameScheduler;
.implements Lcom/facebook/common/time/MonotonicClock;


# instance fields
.field public a:J

.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lcom/facebook/common/time/Clock;)V
    .locals 2

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput-object p1, p0, LR2/a;->b:Ljava/lang/Object;

    .line 6
    invoke-interface {p1}, Lcom/facebook/common/time/Clock;->now()J

    move-result-wide v0

    iput-wide v0, p0, LR2/a;->a:J

    return-void
.end method

.method public constructor <init>(Lcom/facebook/fresco/animation/backend/AnimationBackend;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, -0x1

    .line 2
    iput-wide v0, p0, LR2/a;->a:J

    .line 3
    iput-object p1, p0, LR2/a;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public getFrameNumberToRender(JJ)I
    .locals 9

    .line 1
    invoke-virtual {p0}, LR2/a;->getLoopDurationMs()J

    .line 2
    .line 3
    .line 4
    move-result-wide p3

    .line 5
    const-wide/16 v0, 0x0

    .line 6
    .line 7
    cmp-long v2, p3, v0

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    iget-object v4, p0, LR2/a;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v4, Lcom/facebook/fresco/animation/backend/AnimationBackend;

    .line 13
    .line 14
    if-nez v2, :cond_1

    .line 15
    .line 16
    move-wide p1, v0

    .line 17
    :goto_0
    invoke-interface {v4, v3}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getFrameDurationMs(I)I

    .line 18
    .line 19
    .line 20
    move-result p3

    .line 21
    int-to-long p3, p3

    .line 22
    add-long/2addr p1, p3

    .line 23
    add-int/lit8 p3, v3, 0x1

    .line 24
    .line 25
    cmp-long p4, v0, p1

    .line 26
    .line 27
    if-gez p4, :cond_0

    .line 28
    .line 29
    return v3

    .line 30
    :cond_0
    move v3, p3

    .line 31
    goto :goto_0

    .line 32
    :cond_1
    invoke-virtual {p0}, LR2/a;->isInfiniteAnimation()Z

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    if-nez v2, :cond_2

    .line 37
    .line 38
    div-long v5, p1, p3

    .line 39
    .line 40
    invoke-interface {v4}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getLoopCount()I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    int-to-long v7, v2

    .line 45
    cmp-long v2, v5, v7

    .line 46
    .line 47
    if-ltz v2, :cond_2

    .line 48
    .line 49
    const/4 p1, -0x1

    .line 50
    return p1

    .line 51
    :cond_2
    rem-long/2addr p1, p3

    .line 52
    :goto_1
    invoke-interface {v4, v3}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getFrameDurationMs(I)I

    .line 53
    .line 54
    .line 55
    move-result p3

    .line 56
    int-to-long p3, p3

    .line 57
    add-long/2addr v0, p3

    .line 58
    add-int/lit8 p3, v3, 0x1

    .line 59
    .line 60
    cmp-long p4, p1, v0

    .line 61
    .line 62
    if-gez p4, :cond_3

    .line 63
    .line 64
    return v3

    .line 65
    :cond_3
    move v3, p3

    .line 66
    goto :goto_1
.end method

.method public getLoopDurationMs()J
    .locals 7

    .line 1
    iget-wide v0, p0, LR2/a;->a:J

    .line 2
    .line 3
    const-wide/16 v2, -0x1

    .line 4
    .line 5
    cmp-long v2, v0, v2

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    return-wide v0

    .line 10
    :cond_0
    const-wide/16 v0, 0x0

    .line 11
    .line 12
    iput-wide v0, p0, LR2/a;->a:J

    .line 13
    .line 14
    iget-object v0, p0, LR2/a;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lcom/facebook/fresco/animation/backend/AnimationBackend;

    .line 17
    .line 18
    invoke-interface {v0}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getFrameCount()I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    const/4 v2, 0x0

    .line 23
    :goto_0
    if-ge v2, v1, :cond_1

    .line 24
    .line 25
    iget-wide v3, p0, LR2/a;->a:J

    .line 26
    .line 27
    invoke-interface {v0, v2}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getFrameDurationMs(I)I

    .line 28
    .line 29
    .line 30
    move-result v5

    .line 31
    int-to-long v5, v5

    .line 32
    add-long/2addr v3, v5

    .line 33
    iput-wide v3, p0, LR2/a;->a:J

    .line 34
    .line 35
    add-int/lit8 v2, v2, 0x1

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_1
    iget-wide v0, p0, LR2/a;->a:J

    .line 39
    .line 40
    return-wide v0
.end method

.method public getTargetRenderTimeForNextFrameMs(J)J
    .locals 10

    .line 1
    invoke-virtual {p0}, LR2/a;->getLoopDurationMs()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    const-wide/16 v2, 0x0

    .line 6
    .line 7
    cmp-long v4, v0, v2

    .line 8
    .line 9
    if-nez v4, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {p0}, LR2/a;->isInfiniteAnimation()Z

    .line 13
    .line 14
    .line 15
    move-result v4

    .line 16
    iget-object v5, p0, LR2/a;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v5, Lcom/facebook/fresco/animation/backend/AnimationBackend;

    .line 19
    .line 20
    if-nez v4, :cond_1

    .line 21
    .line 22
    invoke-virtual {p0}, LR2/a;->getLoopDurationMs()J

    .line 23
    .line 24
    .line 25
    move-result-wide v6

    .line 26
    div-long v6, p1, v6

    .line 27
    .line 28
    invoke-interface {v5}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getLoopCount()I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    int-to-long v8, v4

    .line 33
    cmp-long v4, v6, v8

    .line 34
    .line 35
    if-ltz v4, :cond_1

    .line 36
    .line 37
    :goto_0
    const-wide/16 p1, -0x1

    .line 38
    .line 39
    return-wide p1

    .line 40
    :cond_1
    rem-long v0, p1, v0

    .line 41
    .line 42
    invoke-interface {v5}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getFrameCount()I

    .line 43
    .line 44
    .line 45
    move-result v4

    .line 46
    const/4 v6, 0x0

    .line 47
    :goto_1
    if-ge v6, v4, :cond_2

    .line 48
    .line 49
    cmp-long v7, v2, v0

    .line 50
    .line 51
    if-gtz v7, :cond_2

    .line 52
    .line 53
    invoke-interface {v5, v6}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getFrameDurationMs(I)I

    .line 54
    .line 55
    .line 56
    move-result v7

    .line 57
    int-to-long v7, v7

    .line 58
    add-long/2addr v2, v7

    .line 59
    add-int/lit8 v6, v6, 0x1

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    sub-long/2addr v2, v0

    .line 63
    add-long/2addr v2, p1

    .line 64
    return-wide v2
.end method

.method public getTargetRenderTimeMs(I)J
    .locals 5

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    :goto_0
    if-ge v2, p1, :cond_0

    .line 5
    .line 6
    iget-object v3, p0, LR2/a;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v3, Lcom/facebook/fresco/animation/backend/AnimationBackend;

    .line 9
    .line 10
    invoke-interface {v3, p1}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getFrameDurationMs(I)I

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    int-to-long v3, v3

    .line 15
    add-long/2addr v0, v3

    .line 16
    add-int/lit8 v2, v2, 0x1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    return-wide v0
.end method

.method public isInfiniteAnimation()Z
    .locals 1

    .line 1
    iget-object v0, p0, LR2/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/facebook/fresco/animation/backend/AnimationBackend;

    .line 4
    .line 5
    invoke-interface {v0}, Lcom/facebook/fresco/animation/backend/AnimationInformation;->getLoopCount()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    const/4 v0, 0x1

    .line 12
    return v0

    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    return v0
.end method

.method public now()J
    .locals 4

    .line 1
    iget-wide v0, p0, LR2/a;->a:J

    .line 2
    .line 3
    iget-object v2, p0, LR2/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v2, Lcom/facebook/common/time/Clock;

    .line 6
    .line 7
    invoke-interface {v2}, Lcom/facebook/common/time/Clock;->now()J

    .line 8
    .line 9
    .line 10
    move-result-wide v2

    .line 11
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(JJ)J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    iput-wide v0, p0, LR2/a;->a:J

    .line 16
    .line 17
    return-wide v0
.end method

.method public nowNanos()J
    .locals 3

    .line 1
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 2
    .line 3
    invoke-virtual {p0}, LR2/a;->now()J

    .line 4
    .line 5
    .line 6
    move-result-wide v1

    .line 7
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    .line 8
    .line 9
    .line 10
    move-result-wide v0

    .line 11
    return-wide v0
.end method
