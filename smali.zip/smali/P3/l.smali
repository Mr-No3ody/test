.class public final LP3/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/ui/activity/a;

.field public final synthetic c:Lcom/flexibank/sdk/cashier/ui/activity/a;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/a;Lcom/flexibank/sdk/cashier/ui/activity/a;I)V
    .locals 0

    .line 1
    iput p3, p0, LP3/l;->a:I

    iput-object p1, p0, LP3/l;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    iput-object p2, p0, LP3/l;->c:Lcom/flexibank/sdk/cashier/ui/activity/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    const-string v0, ""

    .line 2
    .line 3
    const-wide/16 v1, 0x0

    .line 4
    .line 5
    const/4 v3, 0x0

    .line 6
    iget-object v4, p0, LP3/l;->c:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 7
    .line 8
    iget-object v5, p0, LP3/l;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 9
    .line 10
    const-string v6, "it"

    .line 11
    .line 12
    const/4 v7, 0x0

    .line 13
    const/4 v8, 0x1

    .line 14
    iget v9, p0, LP3/l;->a:I

    .line 15
    .line 16
    packed-switch v9, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    check-cast p1, LK3/n;

    .line 20
    .line 21
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    instance-of v6, p1, LK3/l;

    .line 25
    .line 26
    if-eqz v6, :cond_0

    .line 27
    .line 28
    invoke-interface {v5, v8, v8}, Lcom/flexibank/sdk/base/FlexiBankLoadingDialogHost;->showLoadingDialog(ZZ)V

    .line 29
    .line 30
    .line 31
    goto/16 :goto_4

    .line 32
    .line 33
    :cond_0
    instance-of v6, p1, LK3/m;

    .line 34
    .line 35
    if-eqz v6, :cond_e

    .line 36
    .line 37
    invoke-interface {v5, v7, v8}, Lcom/flexibank/sdk/base/FlexiBankLoadingDialogHost;->showLoadingDialog(ZZ)V

    .line 38
    .line 39
    .line 40
    check-cast p1, LK3/m;

    .line 41
    .line 42
    iget-object p1, p1, LK3/m;->a:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast p1, LO3/d;

    .line 45
    .line 46
    if-eqz p1, :cond_b

    .line 47
    .line 48
    invoke-virtual {p1}, LW3/f;->c()Z

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    if-ne v5, v8, :cond_b

    .line 53
    .line 54
    invoke-virtual {p1}, LO3/d;->e()LO3/d$a;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    if-eqz v0, :cond_f

    .line 59
    .line 60
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/ui/activity/a;->q()V

    .line 61
    .line 62
    .line 63
    iget-object v5, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->A0:Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;

    .line 64
    .line 65
    if-eqz v5, :cond_5

    .line 66
    .line 67
    invoke-virtual {p1}, LO3/d;->e()LO3/d$a;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-eqz p1, :cond_4

    .line 72
    .line 73
    invoke-virtual {p1}, LO3/d$a;->a()Ljava/util/List;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    if-eqz p1, :cond_4

    .line 78
    .line 79
    check-cast p1, Ljava/lang/Iterable;

    .line 80
    .line 81
    instance-of v6, p1, Ljava/util/Collection;

    .line 82
    .line 83
    if-eqz v6, :cond_1

    .line 84
    .line 85
    move-object v6, p1

    .line 86
    check-cast v6, Ljava/util/Collection;

    .line 87
    .line 88
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 89
    .line 90
    .line 91
    move-result v6

    .line 92
    if-eqz v6, :cond_1

    .line 93
    .line 94
    goto :goto_1

    .line 95
    :cond_1
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    :cond_2
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 100
    .line 101
    .line 102
    move-result v6

    .line 103
    if-eqz v6, :cond_4

    .line 104
    .line 105
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v6

    .line 109
    check-cast v6, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;

    .line 110
    .line 111
    invoke-virtual {v6}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;->c()Ljava/lang/Boolean;

    .line 112
    .line 113
    .line 114
    move-result-object v6

    .line 115
    sget-object v9, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 116
    .line 117
    invoke-static {v6, v9}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    move-result v6

    .line 121
    if-eqz v6, :cond_2

    .line 122
    .line 123
    add-int/2addr v7, v8

    .line 124
    if-ltz v7, :cond_3

    .line 125
    .line 126
    goto :goto_0

    .line 127
    :cond_3
    invoke-static {}, Lkotlin/collections/q;->j()V

    .line 128
    .line 129
    .line 130
    throw v3

    .line 131
    :cond_4
    :goto_1
    invoke-virtual {v5, v7}, Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;->setMAvailableCouponCount(I)V

    .line 132
    .line 133
    .line 134
    :cond_5
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->C0:Lxf/t;

    .line 135
    .line 136
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v3

    .line 140
    check-cast v3, LQ3/c;

    .line 141
    .line 142
    iget-object v5, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 143
    .line 144
    if-eqz v5, :cond_6

    .line 145
    .line 146
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->u()I

    .line 147
    .line 148
    .line 149
    move-result v5

    .line 150
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 151
    .line 152
    .line 153
    move-result-object v5

    .line 154
    invoke-virtual {v5}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v5

    .line 158
    if-nez v5, :cond_7

    .line 159
    .line 160
    :cond_6
    const-string v5, "1"

    .line 161
    .line 162
    :cond_7
    invoke-virtual {v4, v5}, Lcom/flexibank/sdk/cashier/ui/activity/a;->i(Ljava/lang/String;)LO3/k;

    .line 163
    .line 164
    .line 165
    move-result-object v5

    .line 166
    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 167
    .line 168
    invoke-virtual {v5, v6}, LO3/k;->n(Ljava/lang/Boolean;)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v5}, LO3/k;->l()V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v5, v6}, LO3/k;->i(Ljava/lang/Boolean;)V

    .line 175
    .line 176
    .line 177
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 178
    .line 179
    invoke-virtual {v5, v6}, LO3/k;->m(Ljava/lang/Boolean;)V

    .line 180
    .line 181
    .line 182
    iput-object v5, v3, LQ3/c;->B:LO3/k;

    .line 183
    .line 184
    iget-object v3, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->t0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;

    .line 185
    .line 186
    if-eqz v3, :cond_9

    .line 187
    .line 188
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v4

    .line 192
    check-cast v4, LQ3/c;

    .line 193
    .line 194
    invoke-virtual {v3}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierCouponItem;->f()Ljava/lang/Long;

    .line 195
    .line 196
    .line 197
    move-result-object v3

    .line 198
    if-eqz v3, :cond_8

    .line 199
    .line 200
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 201
    .line 202
    .line 203
    move-result-wide v1

    .line 204
    :cond_8
    iput-wide v1, v4, LQ3/c;->v:J

    .line 205
    .line 206
    goto :goto_2

    .line 207
    :cond_9
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    check-cast v1, LQ3/c;

    .line 212
    .line 213
    const-wide/16 v2, -0x1

    .line 214
    .line 215
    iput-wide v2, v1, LQ3/c;->v:J

    .line 216
    .line 217
    :goto_2
    invoke-virtual {v0}, LO3/d$a;->a()Ljava/util/List;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    if-eqz v0, :cond_a

    .line 222
    .line 223
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v1

    .line 227
    check-cast v1, LQ3/c;

    .line 228
    .line 229
    iput-object v0, v1, LQ3/c;->t:Ljava/util/List;

    .line 230
    .line 231
    :cond_a
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object p1

    .line 235
    check-cast p1, LQ3/c;

    .line 236
    .line 237
    invoke-virtual {p1}, LQ3/c;->show()V

    .line 238
    .line 239
    .line 240
    goto :goto_4

    .line 241
    :cond_b
    if-eqz p1, :cond_d

    .line 242
    .line 243
    invoke-virtual {p1}, LW3/f;->b()Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    if-nez p1, :cond_c

    .line 248
    .line 249
    goto :goto_3

    .line 250
    :cond_c
    move-object v0, p1

    .line 251
    :cond_d
    :goto_3
    new-array p1, v7, [Ljava/lang/Object;

    .line 252
    .line 253
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 254
    .line 255
    .line 256
    goto :goto_4

    .line 257
    :cond_e
    instance-of v0, p1, LK3/k;

    .line 258
    .line 259
    if-eqz v0, :cond_10

    .line 260
    .line 261
    invoke-interface {v5, v7, v8}, Lcom/flexibank/sdk/base/FlexiBankLoadingDialogHost;->showLoadingDialog(ZZ)V

    .line 262
    .line 263
    .line 264
    check-cast p1, LK3/k;

    .line 265
    .line 266
    iget-object p1, p1, LK3/k;->a:Ljava/lang/String;

    .line 267
    .line 268
    new-array v0, v7, [Ljava/lang/Object;

    .line 269
    .line 270
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 271
    .line 272
    .line 273
    :cond_f
    :goto_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 274
    .line 275
    return-object p1

    .line 276
    :cond_10
    new-instance p1, Lxf/l;

    .line 277
    .line 278
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 279
    .line 280
    .line 281
    throw p1

    .line 282
    :pswitch_0
    check-cast p1, LK3/n;

    .line 283
    .line 284
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 285
    .line 286
    .line 287
    instance-of v6, p1, LK3/l;

    .line 288
    .line 289
    if-eqz v6, :cond_11

    .line 290
    .line 291
    invoke-interface {v5, v8, v8}, Lcom/flexibank/sdk/base/FlexiBankLoadingDialogHost;->showLoadingDialog(ZZ)V

    .line 292
    .line 293
    .line 294
    goto/16 :goto_c

    .line 295
    .line 296
    :cond_11
    instance-of v6, p1, LK3/m;

    .line 297
    .line 298
    if-eqz v6, :cond_2a

    .line 299
    .line 300
    invoke-interface {v5, v7, v8}, Lcom/flexibank/sdk/base/FlexiBankLoadingDialogHost;->showLoadingDialog(ZZ)V

    .line 301
    .line 302
    .line 303
    check-cast p1, LK3/m;

    .line 304
    .line 305
    iget-object p1, p1, LK3/m;->a:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast p1, LO3/g;

    .line 308
    .line 309
    invoke-virtual {p1}, LW3/f;->c()Z

    .line 310
    .line 311
    .line 312
    move-result v5

    .line 313
    if-eqz v5, :cond_22

    .line 314
    .line 315
    invoke-virtual {p1}, LO3/g;->e()LO3/g$b;

    .line 316
    .line 317
    .line 318
    move-result-object p1

    .line 319
    if-eqz p1, :cond_2b

    .line 320
    .line 321
    move-object v0, v4

    .line 322
    check-cast v0, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankCashierCommonPreviewActivity;

    .line 323
    .line 324
    iget-object v5, v0, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankCashierCommonPreviewActivity;->E0:Lxf/t;

    .line 325
    .line 326
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 327
    .line 328
    .line 329
    move-result-object v5

    .line 330
    check-cast v5, Ljava/lang/Boolean;

    .line 331
    .line 332
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 333
    .line 334
    .line 335
    move-result v5

    .line 336
    if-eqz v5, :cond_12

    .line 337
    .line 338
    sget v5, Lcom/flexibank/sdk/p;->fb_cl_cashier_preview:I

    .line 339
    .line 340
    invoke-virtual {v0, v5}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    if-eqz v0, :cond_12

    .line 345
    .line 346
    invoke-static {v0, v8}, Le4/a;->d(Landroid/view/View;Z)V

    .line 347
    .line 348
    .line 349
    :cond_12
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 350
    .line 351
    .line 352
    const-string v0, "data"

    .line 353
    .line 354
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 355
    .line 356
    .line 357
    invoke-virtual {p1}, LO3/g$b;->a()Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;

    .line 358
    .line 359
    .line 360
    move-result-object v5

    .line 361
    if-nez v5, :cond_13

    .line 362
    .line 363
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/ui/activity/a;->o()V

    .line 364
    .line 365
    .line 366
    goto/16 :goto_c

    .line 367
    .line 368
    :cond_13
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/ui/activity/a;->p()V

    .line 369
    .line 370
    .line 371
    invoke-virtual {p1}, LO3/g$b;->a()Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;

    .line 372
    .line 373
    .line 374
    move-result-object v5

    .line 375
    if-eqz v5, :cond_15

    .line 376
    .line 377
    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 378
    .line 379
    .line 380
    iput-object v5, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->s0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;

    .line 381
    .line 382
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;->c()Ljava/lang/String;

    .line 383
    .line 384
    .line 385
    move-result-object v0

    .line 386
    iput-object v0, v4, LP3/c;->Q:Ljava/lang/String;

    .line 387
    .line 388
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;->h()Ljava/lang/Long;

    .line 389
    .line 390
    .line 391
    move-result-object v0

    .line 392
    if-eqz v0, :cond_14

    .line 393
    .line 394
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 395
    .line 396
    .line 397
    move-result-wide v5

    .line 398
    goto :goto_5

    .line 399
    :cond_14
    move-wide v5, v1

    .line 400
    :goto_5
    iput-wide v5, v4, LP3/c;->M:J

    .line 401
    .line 402
    :cond_15
    invoke-virtual {p1}, LO3/g$b;->b()Ljava/util/List;

    .line 403
    .line 404
    .line 405
    move-result-object v0

    .line 406
    iget-object v5, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->k0:Ljava/util/ArrayList;

    .line 407
    .line 408
    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 409
    .line 410
    .line 411
    if-eqz v0, :cond_16

    .line 412
    .line 413
    check-cast v0, Ljava/util/Collection;

    .line 414
    .line 415
    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 416
    .line 417
    .line 418
    :cond_16
    invoke-virtual {p1}, LO3/g$b;->c()Ljava/util/List;

    .line 419
    .line 420
    .line 421
    move-result-object v0

    .line 422
    iget-object v6, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->p0:Ljava/util/ArrayList;

    .line 423
    .line 424
    invoke-virtual {v6}, Ljava/util/ArrayList;->clear()V

    .line 425
    .line 426
    .line 427
    iget-object v9, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->r0:Ljava/util/ArrayList;

    .line 428
    .line 429
    invoke-virtual {v9}, Ljava/util/ArrayList;->clear()V

    .line 430
    .line 431
    .line 432
    if-eqz v0, :cond_1b

    .line 433
    .line 434
    move-object v10, v0

    .line 435
    check-cast v10, Ljava/util/Collection;

    .line 436
    .line 437
    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    .line 438
    .line 439
    .line 440
    move-result v10

    .line 441
    if-nez v10, :cond_17

    .line 442
    .line 443
    goto :goto_6

    .line 444
    :cond_17
    move-object v0, v3

    .line 445
    :goto_6
    if-eqz v0, :cond_1b

    .line 446
    .line 447
    move-object v10, v0

    .line 448
    check-cast v10, Ljava/lang/Iterable;

    .line 449
    .line 450
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 451
    .line 452
    .line 453
    move-result-object v10

    .line 454
    :cond_18
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 455
    .line 456
    .line 457
    move-result v11

    .line 458
    if-eqz v11, :cond_19

    .line 459
    .line 460
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 461
    .line 462
    .line 463
    move-result-object v11

    .line 464
    move-object v12, v11

    .line 465
    check-cast v12, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 466
    .line 467
    invoke-virtual {v12}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->m()Z

    .line 468
    .line 469
    .line 470
    move-result v12

    .line 471
    if-ne v12, v8, :cond_18

    .line 472
    .line 473
    move-object v3, v11

    .line 474
    :cond_19
    check-cast v3, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 475
    .line 476
    if-eqz v3, :cond_1a

    .line 477
    .line 478
    iput-object v3, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 479
    .line 480
    :cond_1a
    check-cast v0, Ljava/util/Collection;

    .line 481
    .line 482
    invoke-virtual {v9, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 483
    .line 484
    .line 485
    :cond_1b
    new-instance v0, Ljava/util/ArrayList;

    .line 486
    .line 487
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 488
    .line 489
    .line 490
    invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 491
    .line 492
    .line 493
    move-result-object v3

    .line 494
    :cond_1c
    :goto_7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 495
    .line 496
    .line 497
    move-result v9

    .line 498
    if-eqz v9, :cond_1e

    .line 499
    .line 500
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 501
    .line 502
    .line 503
    move-result-object v9

    .line 504
    move-object v10, v9

    .line 505
    check-cast v10, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 506
    .line 507
    invoke-virtual {v10}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->m()Z

    .line 508
    .line 509
    .line 510
    move-result v11

    .line 511
    if-eq v11, v8, :cond_1d

    .line 512
    .line 513
    invoke-virtual {v10}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->v()Z

    .line 514
    .line 515
    .line 516
    move-result v10

    .line 517
    if-ne v10, v8, :cond_1c

    .line 518
    .line 519
    :cond_1d
    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 520
    .line 521
    .line 522
    goto :goto_7

    .line 523
    :cond_1e
    const/4 v3, 0x2

    .line 524
    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->U(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 525
    .line 526
    .line 527
    move-result-object v0

    .line 528
    check-cast v0, Ljava/util/Collection;

    .line 529
    .line 530
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 531
    .line 532
    .line 533
    move-result v3

    .line 534
    if-nez v3, :cond_1f

    .line 535
    .line 536
    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 537
    .line 538
    .line 539
    :cond_1f
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/ui/activity/a;->k()LM3/g;

    .line 540
    .line 541
    .line 542
    move-result-object v0

    .line 543
    new-instance v3, LP3/f;

    .line 544
    .line 545
    invoke-direct {v3, v4, v7}, LP3/f;-><init>(Lcom/flexibank/sdk/cashier/ui/activity/a;I)V

    .line 546
    .line 547
    .line 548
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 549
    .line 550
    .line 551
    const-string v7, "payAmount"

    .line 552
    .line 553
    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 554
    .line 555
    .line 556
    iput-object v3, v0, LM3/g;->e:Lkotlin/jvm/functions/Function0;

    .line 557
    .line 558
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/ui/activity/a;->k()LM3/g;

    .line 559
    .line 560
    .line 561
    move-result-object v0

    .line 562
    iget-object v3, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 563
    .line 564
    iput-object v3, v0, LM3/g;->d:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 565
    .line 566
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/ui/activity/a;->k()LM3/g;

    .line 567
    .line 568
    .line 569
    move-result-object v0

    .line 570
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 571
    .line 572
    .line 573
    const-string v3, "addablePaymentMethods"

    .line 574
    .line 575
    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 576
    .line 577
    .line 578
    iget-object v0, v0, LM3/g;->a:Ljava/util/ArrayList;

    .line 579
    .line 580
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 581
    .line 582
    .line 583
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 584
    .line 585
    .line 586
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/ui/activity/a;->k()LM3/g;

    .line 587
    .line 588
    .line 589
    move-result-object v0

    .line 590
    invoke-virtual {v0, v6}, LM3/g;->b(Ljava/util/List;)V

    .line 591
    .line 592
    .line 593
    invoke-virtual {p1}, LO3/g$b;->a()Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;

    .line 594
    .line 595
    .line 596
    move-result-object p1

    .line 597
    if-eqz p1, :cond_2b

    .line 598
    .line 599
    iget-object v0, v4, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 600
    .line 601
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;->i()Ljava/lang/Long;

    .line 602
    .line 603
    .line 604
    move-result-object v3

    .line 605
    if-eqz v0, :cond_21

    .line 606
    .line 607
    if-eqz v3, :cond_20

    .line 608
    .line 609
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 610
    .line 611
    .line 612
    move-result-wide v1

    .line 613
    :cond_20
    invoke-virtual {v0, v1, v2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->A(J)V

    .line 614
    .line 615
    .line 616
    :cond_21
    invoke-virtual {v4, p1, v8}, Lcom/flexibank/sdk/cashier/ui/activity/a;->v(Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;Z)V

    .line 617
    .line 618
    .line 619
    goto/16 :goto_c

    .line 620
    .line 621
    :cond_22
    invoke-virtual {p1}, LW3/f;->a()Ljava/lang/String;

    .line 622
    .line 623
    .line 624
    move-result-object v1

    .line 625
    invoke-virtual {p1}, LW3/f;->b()Ljava/lang/String;

    .line 626
    .line 627
    .line 628
    move-result-object p1

    .line 629
    const-string v2, "context"

    .line 630
    .line 631
    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 632
    .line 633
    .line 634
    if-eqz v1, :cond_2b

    .line 635
    .line 636
    const-string v2, "33000039"

    .line 637
    .line 638
    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 639
    .line 640
    .line 641
    move-result v2

    .line 642
    if-nez v2, :cond_24

    .line 643
    .line 644
    const-string v2, "33000040"

    .line 645
    .line 646
    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 647
    .line 648
    .line 649
    move-result v2

    .line 650
    if-nez v2, :cond_24

    .line 651
    .line 652
    const-string v2, "33000041"

    .line 653
    .line 654
    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 655
    .line 656
    .line 657
    move-result v2

    .line 658
    if-eqz v2, :cond_23

    .line 659
    .line 660
    goto :goto_8

    .line 661
    :cond_23
    move v8, v7

    .line 662
    :cond_24
    :goto_8
    if-eqz v8, :cond_26

    .line 663
    .line 664
    if-nez p1, :cond_25

    .line 665
    .line 666
    goto :goto_9

    .line 667
    :cond_25
    move-object v0, p1

    .line 668
    :goto_9
    invoke-static {v4, v1, v0}, Lj4/u;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 669
    .line 670
    .line 671
    goto :goto_c

    .line 672
    :cond_26
    const-string v2, "-1"

    .line 673
    .line 674
    invoke-virtual {v2, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 675
    .line 676
    .line 677
    move-result v1

    .line 678
    if-eqz v1, :cond_28

    .line 679
    .line 680
    if-nez p1, :cond_27

    .line 681
    .line 682
    goto :goto_a

    .line 683
    :cond_27
    move-object v0, p1

    .line 684
    :goto_a
    const-string p1, "CashierErrorInfo"

    .line 685
    .line 686
    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 687
    .line 688
    .line 689
    invoke-virtual {v4}, Landroid/app/Activity;->finish()V

    .line 690
    .line 691
    .line 692
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 693
    .line 694
    goto :goto_c

    .line 695
    :cond_28
    if-nez p1, :cond_29

    .line 696
    .line 697
    goto :goto_b

    .line 698
    :cond_29
    move-object v0, p1

    .line 699
    :goto_b
    new-array p1, v7, [Ljava/lang/Object;

    .line 700
    .line 701
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 702
    .line 703
    .line 704
    invoke-virtual {v4}, Landroid/app/Activity;->finish()V

    .line 705
    .line 706
    .line 707
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 708
    .line 709
    goto :goto_c

    .line 710
    :cond_2a
    instance-of v0, p1, LK3/k;

    .line 711
    .line 712
    if-eqz v0, :cond_2c

    .line 713
    .line 714
    invoke-interface {v5, v7, v8}, Lcom/flexibank/sdk/base/FlexiBankLoadingDialogHost;->showLoadingDialog(ZZ)V

    .line 715
    .line 716
    .line 717
    check-cast p1, LK3/k;

    .line 718
    .line 719
    iget-object p1, p1, LK3/k;->a:Ljava/lang/String;

    .line 720
    .line 721
    new-array v0, v7, [Ljava/lang/Object;

    .line 722
    .line 723
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 724
    .line 725
    .line 726
    invoke-virtual {v4}, Landroid/app/Activity;->finish()V

    .line 727
    .line 728
    .line 729
    :cond_2b
    :goto_c
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 730
    .line 731
    return-object p1

    .line 732
    :cond_2c
    new-instance p1, Lxf/l;

    .line 733
    .line 734
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 735
    .line 736
    .line 737
    throw p1

    .line 738
    nop

    .line 739
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
