.class public final synthetic LP3/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionItem$OnPromotionItemListener;
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;


# instance fields
.field public final synthetic a:Lcom/flexibank/sdk/cashier/ui/activity/a;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/a;)V
    .locals 0

    .line 1
    iput-object p1, p0, LP3/i;->a:Lcom/flexibank/sdk/cashier/ui/activity/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 3

    .line 1
    const-string v0, "adapter"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string/jumbo v0, "view"

    .line 7
    .line 8
    .line 9
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    const-string p2, "null cannot be cast to non-null type com.flexibank.sdk.cashier.bean.FlexiBankCashierPaymentMethodBean"

    .line 17
    .line 18
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    check-cast p1, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 22
    .line 23
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->e()J

    .line 24
    .line 25
    .line 26
    move-result-wide p2

    .line 27
    iget-object v0, p0, LP3/i;->a:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 28
    .line 29
    iget-wide v1, v0, LP3/c;->M:J

    .line 30
    .line 31
    cmp-long p2, p2, v1

    .line 32
    .line 33
    if-gez p2, :cond_1

    .line 34
    .line 35
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->x()Z

    .line 36
    .line 37
    .line 38
    move-result p2

    .line 39
    if-nez p2, :cond_0

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    return-void

    .line 43
    :cond_1
    :goto_0
    invoke-virtual {v0, p1}, Lcom/flexibank/sdk/cashier/ui/activity/a;->r(Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;)V

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public onPromotionItemClick()V
    .locals 8

    .line 1
    iget-object v0, p0, LP3/i;->a:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 2
    .line 3
    iget-object v1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->s0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;

    .line 4
    .line 5
    if-eqz v1, :cond_6

    .line 6
    .line 7
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 8
    .line 9
    .line 10
    move-result-wide v2

    .line 11
    sget-wide v4, LD3/a;->b:J

    .line 12
    .line 13
    sub-long v4, v2, v4

    .line 14
    .line 15
    const-wide/16 v6, 0x1f4

    .line 16
    .line 17
    cmp-long v4, v4, v6

    .line 18
    .line 19
    if-gez v4, :cond_0

    .line 20
    .line 21
    goto/16 :goto_2

    .line 22
    .line 23
    :cond_0
    sput-wide v2, LD3/a;->b:J

    .line 24
    .line 25
    iget-object v2, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 26
    .line 27
    if-nez v2, :cond_1

    .line 28
    .line 29
    sget v0, Lcom/flexibank/sdk/r;->fb_msg_select_payment_method:I

    .line 30
    .line 31
    invoke-static {v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_1
    new-instance v2, LO3/c;

    .line 36
    .line 37
    invoke-direct {v2}, LO3/c;-><init>()V

    .line 38
    .line 39
    .line 40
    iget-wide v3, v0, LP3/c;->H:J

    .line 41
    .line 42
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    invoke-virtual {v2, v3}, LO3/c;->c(Ljava/lang/Long;)V

    .line 47
    .line 48
    .line 49
    iget-object v3, v0, LP3/c;->B:Ljava/lang/String;

    .line 50
    .line 51
    invoke-virtual {v2, v3}, LO3/c;->f(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;->g()Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcPaymentFeeInfoBean;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    const-wide/16 v4, 0x0

    .line 59
    .line 60
    if-eqz v3, :cond_2

    .line 61
    .line 62
    invoke-virtual {v3}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcPaymentFeeInfoBean;->h()Ljava/lang/Long;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    if-eqz v3, :cond_2

    .line 67
    .line 68
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 69
    .line 70
    .line 71
    move-result-wide v6

    .line 72
    goto :goto_0

    .line 73
    :cond_2
    move-wide v6, v4

    .line 74
    :goto_0
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;->g()Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcPaymentFeeInfoBean;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    if-eqz v1, :cond_3

    .line 79
    .line 80
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcPaymentFeeInfoBean;->c()Ljava/lang/Long;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    if-eqz v1, :cond_3

    .line 85
    .line 86
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 87
    .line 88
    .line 89
    move-result-wide v4

    .line 90
    :cond_3
    add-long/2addr v6, v4

    .line 91
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    invoke-virtual {v2, v1}, LO3/c;->b(Ljava/lang/Long;)V

    .line 96
    .line 97
    .line 98
    iget-object v1, v0, LP3/c;->C:Ljava/lang/String;

    .line 99
    .line 100
    invoke-virtual {v2, v1}, LO3/c;->e(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    iget-object v1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 104
    .line 105
    const/4 v3, 0x0

    .line 106
    if-eqz v1, :cond_4

    .line 107
    .line 108
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->u()I

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    invoke-virtual {v1}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    goto :goto_1

    .line 121
    :cond_4
    move-object v1, v3

    .line 122
    :goto_1
    invoke-virtual {v2, v1}, LO3/c;->g(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    iget-object v1, v0, LP3/c;->A:Ljava/lang/String;

    .line 126
    .line 127
    invoke-virtual {v2, v1}, LO3/c;->d(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    iget-object v1, v0, LP3/c;->L:Ljava/lang/String;

    .line 131
    .line 132
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 133
    .line 134
    .line 135
    move-result v1

    .line 136
    if-nez v1, :cond_5

    .line 137
    .line 138
    iget-object v1, v0, LP3/c;->L:Ljava/lang/String;

    .line 139
    .line 140
    invoke-virtual {v2, v1}, LO3/c;->a(Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    :cond_5
    const-string v1, "req"

    .line 144
    .line 145
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v0}, LK3/d;->e()Lcom/flexibank/sdk/base/FlexiBankBaseViewModel;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    check-cast v0, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCoreCashierViewModel;

    .line 153
    .line 154
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    new-instance v1, LU3/k;

    .line 158
    .line 159
    invoke-direct {v1, v2, v3}, LU3/k;-><init>(LO3/c;Lkotlin/coroutines/Continuation;)V

    .line 160
    .line 161
    .line 162
    iget-object v2, v0, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCoreCashierViewModel;->e:LK3/j;

    .line 163
    .line 164
    invoke-static {v0, v1, v2}, Lhf/a;->A(Lcom/flexibank/sdk/base/FlexiBankBaseViewModel;Lkotlin/jvm/functions/Function1;LK3/j;)V

    .line 165
    .line 166
    .line 167
    :cond_6
    :goto_2
    return-void
.end method
