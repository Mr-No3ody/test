.class public final synthetic LP3/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/ui/activity/a;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/a;I)V
    .locals 0

    .line 1
    iput p2, p0, LP3/g;->a:I

    iput-object p1, p0, LP3/g;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    iget p1, p0, LP3/g;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LP3/g;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    sget-wide v2, LD3/a;->b:J

    .line 16
    .line 17
    sub-long v2, v0, v2

    .line 18
    .line 19
    const-wide/16 v4, 0x1f4

    .line 20
    .line 21
    cmp-long v2, v2, v4

    .line 22
    .line 23
    if-gez v2, :cond_0

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_0
    sput-wide v0, LD3/a;->b:J

    .line 27
    .line 28
    iget-object v0, p1, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 29
    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    sget p1, Lcom/flexibank/sdk/r;->fb_msg_select_payment_method:I

    .line 33
    .line 34
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    iget-wide v1, p1, LP3/c;->M:J

    .line 39
    .line 40
    const-string v3, "<this>"

    .line 41
    .line 42
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->u()I

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    const/4 v4, 0x1

    .line 50
    if-eq v3, v4, :cond_2

    .line 51
    .line 52
    const/16 v4, 0x1c

    .line 53
    .line 54
    if-eq v3, v4, :cond_2

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_2
    invoke-virtual {v0}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->e()J

    .line 58
    .line 59
    .line 60
    move-result-wide v3

    .line 61
    cmp-long v0, v3, v1

    .line 62
    .line 63
    if-ltz v0, :cond_6

    .line 64
    .line 65
    :goto_0
    iget-object v0, p1, Lcom/flexibank/sdk/cashier/ui/activity/a;->s0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;

    .line 66
    .line 67
    if-nez v0, :cond_3

    .line 68
    .line 69
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/ui/activity/a;->j()V

    .line 70
    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_3
    iget-object v0, p1, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 74
    .line 75
    if-eqz v0, :cond_4

    .line 76
    .line 77
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/ui/activity/a;->u()V

    .line 78
    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_4
    sget v0, Lcom/flexibank/sdk/p;->fb_cl_cashier_preview:I

    .line 82
    .line 83
    invoke-virtual {p1, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    if-eqz v0, :cond_5

    .line 88
    .line 89
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-nez v0, :cond_5

    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_5
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_6
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/ui/activity/a;->t()V

    .line 101
    .line 102
    .line 103
    :goto_1
    return-void

    .line 104
    :pswitch_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 105
    .line 106
    .line 107
    move-result-wide v0

    .line 108
    sget-wide v2, LD3/a;->b:J

    .line 109
    .line 110
    sub-long v2, v0, v2

    .line 111
    .line 112
    const-wide/16 v4, 0x1f4

    .line 113
    .line 114
    cmp-long p1, v2, v4

    .line 115
    .line 116
    if-gez p1, :cond_7

    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_7
    sput-wide v0, LD3/a;->b:J

    .line 120
    .line 121
    iget-object p1, p0, LP3/g;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 122
    .line 123
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 124
    .line 125
    .line 126
    :goto_2
    return-void

    .line 127
    :pswitch_1
    iget-object p1, p0, LP3/g;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 128
    .line 129
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/ui/activity/a;->t()V

    .line 130
    .line 131
    .line 132
    return-void

    .line 133
    :pswitch_2
    iget-object p1, p0, LP3/g;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 134
    .line 135
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 136
    .line 137
    .line 138
    return-void

    .line 139
    :pswitch_3
    iget-object p1, p0, LP3/g;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 140
    .line 141
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 142
    .line 143
    .line 144
    return-void

    .line 145
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
