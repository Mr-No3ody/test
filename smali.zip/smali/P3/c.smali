.class public abstract LP3/c;
.super LK3/d;
.source "SourceFile"

# interfaces
.implements Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;
.implements Lcom/flexibank/sdk/core/dialog/FlexiBankSelectBankDialogV2$CallBack;


# instance fields
.field public A:Ljava/lang/String;

.field public B:Ljava/lang/String;

.field public C:Ljava/lang/String;

.field public H:J

.field public L:Ljava/lang/String;

.field public M:J

.field public Q:Ljava/lang/String;

.field public final X:Lxf/t;

.field public final Y:Lxf/t;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    const-string/jumbo v0, "viewModelClass"

    .line 2
    .line 3
    .line 4
    const-class v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCoreCashierViewModel;

    .line 5
    .line 6
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    invoke-direct {p0, v1}, LK3/d;-><init>(Ljava/lang/Class;)V

    .line 10
    .line 11
    .line 12
    const-wide/16 v0, -0x1

    .line 13
    .line 14
    iput-wide v0, p0, LP3/c;->M:J

    .line 15
    .line 16
    new-instance v0, LP3/a;

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    invoke-direct {v0, p0, v1}, LP3/a;-><init>(LP3/c;I)V

    .line 20
    .line 21
    .line 22
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    iput-object v0, p0, LP3/c;->X:Lxf/t;

    .line 27
    .line 28
    new-instance v0, LP3/a;

    .line 29
    .line 30
    const/4 v1, 0x1

    .line 31
    invoke-direct {v0, p0, v1}, LP3/a;-><init>(LP3/c;I)V

    .line 32
    .line 33
    .line 34
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iput-object v0, p0, LP3/c;->Y:Lxf/t;

    .line 39
    .line 40
    return-void
.end method


# virtual methods
.method public abstract g(Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;)V
.end method

.method public final onAddNewBankAccountClick()V
    .locals 0

    .line 1
    return-void
.end method

.method public final onAddNewBankCardClick()V
    .locals 0

    .line 1
    return-void
.end method

.method public final onAddNewBankCardOrBankAccountClick()V
    .locals 0

    .line 1
    return-void
.end method

.method public final onChooseBankClick(Lcom/flexibank/sdk/core/bean/FlexiBankBankInfo;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onClickPayMethod(Lcom/flexibank/sdk/core/bean/FlexiBankPaymentMethod;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onUseNewMobileWalletClick()V
    .locals 0

    .line 1
    return-void
.end method
