.class public final synthetic LP3/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, LP3/o;->a:I

    iput-object p1, p0, LP3/o;->b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, LP3/o;->b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 2
    .line 3
    const-string v1, "msg"

    .line 4
    .line 5
    iget v2, p0, LP3/o;->a:I

    .line 6
    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    packed-switch v2, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget v2, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->Y:I

    .line 13
    .line 14
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0, p1}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->checkPayFail(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 21
    .line 22
    return-object p1

    .line 23
    :pswitch_0
    sget v2, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->Y:I

    .line 24
    .line 25
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0, p1}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->checkPayFail(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 32
    .line 33
    return-object p1

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
