.class public final synthetic LP3/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, LP3/n;->a:I

    iput-object p1, p0, LP3/n;->b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    const-string v0, ""

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x0

    .line 6
    iget-object v4, p0, LP3/n;->b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 7
    .line 8
    iget v5, p0, LP3/n;->a:I

    .line 9
    .line 10
    packed-switch v5, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    check-cast p1, Lkotlin/jvm/functions/Function1;

    .line 14
    .line 15
    check-cast p2, Lcom/flexibank/sdk/cashier/bean/a;

    .line 16
    .line 17
    sget p1, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->Y:I

    .line 18
    .line 19
    invoke-virtual {v4, v3}, LK3/d;->showLoadingDialog(Z)V

    .line 20
    .line 21
    .line 22
    if-eqz p2, :cond_0

    .line 23
    .line 24
    invoke-virtual {p2}, Lcom/flexibank/sdk/cashier/bean/a;->e()Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    :cond_0
    if-eqz p2, :cond_7

    .line 29
    .line 30
    invoke-virtual {p2}, LW3/f;->c()Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    if-ne p1, v1, :cond_7

    .line 35
    .line 36
    if-eqz v2, :cond_7

    .line 37
    .line 38
    invoke-virtual {v2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->f()Z

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    if-eqz p1, :cond_6

    .line 43
    .line 44
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 45
    .line 46
    if-eqz p1, :cond_1

    .line 47
    .line 48
    invoke-virtual {v2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->j()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p2

    .line 52
    invoke-virtual {p1, p2}, LO3/e;->r(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    :cond_1
    invoke-virtual {v2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->p()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    if-nez p1, :cond_2

    .line 64
    .line 65
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 66
    .line 67
    if-eqz p1, :cond_2

    .line 68
    .line 69
    invoke-virtual {v2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->p()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object p2

    .line 73
    invoke-virtual {p1, p2}, LO3/e;->u(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    :cond_2
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 77
    .line 78
    if-eqz p1, :cond_3

    .line 79
    .line 80
    invoke-virtual {v2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->q()Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object p2

    .line 84
    invoke-virtual {p1, p2}, LO3/e;->y(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    :cond_3
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 88
    .line 89
    if-eqz p1, :cond_4

    .line 90
    .line 91
    invoke-virtual {v2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->r()I

    .line 92
    .line 93
    .line 94
    move-result p2

    .line 95
    invoke-virtual {p1, p2}, LO3/e;->A(I)V

    .line 96
    .line 97
    .line 98
    :cond_4
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 99
    .line 100
    if-eqz p1, :cond_5

    .line 101
    .line 102
    invoke-virtual {p1}, LO3/e;->j()I

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    :cond_5
    invoke-virtual {v4, v3, v2}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->k(ILcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;)V

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :cond_6
    invoke-virtual {v4, p2}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->i(Lcom/flexibank/sdk/cashier/bean/a;)V

    .line 111
    .line 112
    .line 113
    goto :goto_0

    .line 114
    :cond_7
    if-eqz p2, :cond_8

    .line 115
    .line 116
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    if-eqz p1, :cond_8

    .line 121
    .line 122
    invoke-virtual {v4, v0, p1}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->j(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 123
    .line 124
    .line 125
    :cond_8
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 126
    .line 127
    return-object p1

    .line 128
    :pswitch_0
    check-cast p1, LO3/e;

    .line 129
    .line 130
    check-cast p2, Lcom/flexibank/sdk/cashier/bean/a;

    .line 131
    .line 132
    sget v5, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->Y:I

    .line 133
    .line 134
    if-eqz p2, :cond_22

    .line 135
    .line 136
    if-eqz p1, :cond_9

    .line 137
    .line 138
    invoke-virtual {p1}, LO3/e;->j()I

    .line 139
    .line 140
    .line 141
    move-result p1

    .line 142
    goto :goto_1

    .line 143
    :cond_9
    move p1, v3

    .line 144
    :goto_1
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 145
    .line 146
    .line 147
    const-string v5, "resp"

    .line 148
    .line 149
    invoke-static {p2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v4, v3}, LK3/d;->showLoadingDialog(Z)V

    .line 153
    .line 154
    .line 155
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 156
    .line 157
    .line 158
    move-result-object v5

    .line 159
    const/16 v6, 0x157

    .line 160
    .line 161
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 162
    .line 163
    .line 164
    move-result-object v6

    .line 165
    invoke-virtual {v5, v6}, Lorg/greenrobot/eventbus/c;->f(Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {p2}, Lcom/flexibank/sdk/cashier/bean/a;->e()Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;

    .line 169
    .line 170
    .line 171
    move-result-object v5

    .line 172
    invoke-virtual {p2}, LW3/f;->c()Z

    .line 173
    .line 174
    .line 175
    move-result v6

    .line 176
    if-eqz v6, :cond_14

    .line 177
    .line 178
    if-eqz v5, :cond_14

    .line 179
    .line 180
    invoke-virtual {v4}, Landroidx/fragment/app/E;->getSupportFragmentManager()Landroidx/fragment/app/Z;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    sget v0, Lcom/flexibank/sdk/p;->fb_apv_fragment_container:I

    .line 185
    .line 186
    invoke-virtual {p1, v0}, Landroidx/fragment/app/Z;->D(I)Landroidx/fragment/app/Fragment;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    if-eqz p1, :cond_a

    .line 191
    .line 192
    instance-of v0, p1, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankBaseVerifyFragment;

    .line 193
    .line 194
    if-eqz v0, :cond_a

    .line 195
    .line 196
    check-cast p1, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankBaseVerifyFragment;

    .line 197
    .line 198
    :cond_a
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->f()Z

    .line 199
    .line 200
    .line 201
    move-result p1

    .line 202
    if-nez p1, :cond_b

    .line 203
    .line 204
    invoke-virtual {v4, p2}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->i(Lcom/flexibank/sdk/cashier/bean/a;)V

    .line 205
    .line 206
    .line 207
    goto/16 :goto_5

    .line 208
    .line 209
    :cond_b
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 210
    .line 211
    if-eqz p1, :cond_c

    .line 212
    .line 213
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->j()Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object p2

    .line 217
    invoke-virtual {p1, p2}, LO3/e;->r(Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    :cond_c
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 221
    .line 222
    if-eqz p1, :cond_d

    .line 223
    .line 224
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->p()Ljava/lang/String;

    .line 225
    .line 226
    .line 227
    move-result-object p2

    .line 228
    invoke-virtual {p1, p2}, LO3/e;->u(Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    :cond_d
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 232
    .line 233
    if-eqz p1, :cond_e

    .line 234
    .line 235
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->q()Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object p2

    .line 239
    invoke-virtual {p1, p2}, LO3/e;->y(Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    :cond_e
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 243
    .line 244
    if-eqz p1, :cond_f

    .line 245
    .line 246
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->r()I

    .line 247
    .line 248
    .line 249
    move-result p2

    .line 250
    invoke-virtual {p1, p2}, LO3/e;->A(I)V

    .line 251
    .line 252
    .line 253
    :cond_f
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 254
    .line 255
    if-eqz p1, :cond_10

    .line 256
    .line 257
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->k()Ljava/lang/String;

    .line 258
    .line 259
    .line 260
    move-result-object p2

    .line 261
    invoke-virtual {p1, p2}, LO3/e;->s(Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    :cond_10
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 265
    .line 266
    if-eqz p1, :cond_11

    .line 267
    .line 268
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->i()Ljava/lang/String;

    .line 269
    .line 270
    .line 271
    move-result-object p2

    .line 272
    invoke-virtual {p1, p2}, LO3/e;->p(Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    :cond_11
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 276
    .line 277
    if-eqz p1, :cond_12

    .line 278
    .line 279
    invoke-virtual {v5}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->o()I

    .line 280
    .line 281
    .line 282
    move-result p2

    .line 283
    invoke-virtual {p1, p2}, LO3/e;->t(I)V

    .line 284
    .line 285
    .line 286
    :cond_12
    iget-object p1, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 287
    .line 288
    if-eqz p1, :cond_13

    .line 289
    .line 290
    invoke-virtual {p1}, LO3/e;->j()I

    .line 291
    .line 292
    .line 293
    move-result v3

    .line 294
    :cond_13
    invoke-virtual {v4, v3, v5}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->k(ILcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;)V

    .line 295
    .line 296
    .line 297
    goto/16 :goto_5

    .line 298
    .line 299
    :cond_14
    iget-object v5, v4, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->B:LO3/e;

    .line 300
    .line 301
    if-eqz v5, :cond_15

    .line 302
    .line 303
    invoke-virtual {v5}, LO3/e;->e()Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v5

    .line 307
    goto :goto_2

    .line 308
    :cond_15
    move-object v5, v2

    .line 309
    :goto_2
    const-string v6, "7"

    .line 310
    .line 311
    invoke-virtual {v6, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 312
    .line 313
    .line 314
    move-result v5

    .line 315
    if-eqz v5, :cond_16

    .line 316
    .line 317
    new-instance v5, LY3/a;

    .line 318
    .line 319
    const/16 v6, 0x121

    .line 320
    .line 321
    invoke-direct {v5, v6}, LY3/a;-><init>(I)V

    .line 322
    .line 323
    .line 324
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 325
    .line 326
    .line 327
    move-result-object v6

    .line 328
    invoke-virtual {v6, v5}, Lorg/greenrobot/eventbus/c;->f(Ljava/lang/Object;)V

    .line 329
    .line 330
    .line 331
    :cond_16
    invoke-virtual {v4}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->h()Landroidx/fragment/app/Fragment;

    .line 332
    .line 333
    .line 334
    move-result-object v5

    .line 335
    const/4 v6, 0x7

    .line 336
    if-eq p1, v6, :cond_1d

    .line 337
    .line 338
    const/16 v6, 0x8

    .line 339
    .line 340
    const-string v7, "VL000005"

    .line 341
    .line 342
    const-string v8, "VL000004"

    .line 343
    .line 344
    const-string v9, "VL000003"

    .line 345
    .line 346
    if-eq p1, v6, :cond_19

    .line 347
    .line 348
    const/16 v1, 0xa

    .line 349
    .line 350
    if-eq p1, v1, :cond_17

    .line 351
    .line 352
    const/16 v1, 0x10

    .line 353
    .line 354
    if-eq p1, v1, :cond_1d

    .line 355
    .line 356
    goto/16 :goto_3

    .line 357
    .line 358
    :cond_17
    instance-of p1, v5, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankAccountOtpFragment;

    .line 359
    .line 360
    if-eqz p1, :cond_20

    .line 361
    .line 362
    check-cast v5, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankAccountOtpFragment;

    .line 363
    .line 364
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 365
    .line 366
    .line 367
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 368
    .line 369
    .line 370
    move-result-object p1

    .line 371
    invoke-virtual {v9, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 372
    .line 373
    .line 374
    move-result v1

    .line 375
    if-nez v1, :cond_18

    .line 376
    .line 377
    invoke-virtual {v8, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 378
    .line 379
    .line 380
    move-result v1

    .line 381
    if-nez v1, :cond_18

    .line 382
    .line 383
    invoke-virtual {v7, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 384
    .line 385
    .line 386
    move-result p1

    .line 387
    if-eqz p1, :cond_20

    .line 388
    .line 389
    :cond_18
    iget-object p1, v5, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankAccountOtpFragment;->t:Landroid/widget/TextView;

    .line 390
    .line 391
    if-eqz p1, :cond_22

    .line 392
    .line 393
    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    .line 394
    .line 395
    .line 396
    goto/16 :goto_5

    .line 397
    .line 398
    :cond_19
    instance-of p1, v5, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayOtpFragment;

    .line 399
    .line 400
    if-eqz p1, :cond_20

    .line 401
    .line 402
    check-cast v5, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayOtpFragment;

    .line 403
    .line 404
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 405
    .line 406
    .line 407
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 408
    .line 409
    .line 410
    move-result-object p1

    .line 411
    invoke-virtual {v9, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 412
    .line 413
    .line 414
    move-result v2

    .line 415
    if-nez v2, :cond_1a

    .line 416
    .line 417
    invoke-virtual {v8, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 418
    .line 419
    .line 420
    move-result v2

    .line 421
    if-nez v2, :cond_1a

    .line 422
    .line 423
    invoke-virtual {v7, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 424
    .line 425
    .line 426
    move-result p1

    .line 427
    if-eqz p1, :cond_20

    .line 428
    .line 429
    :cond_1a
    iget-object p1, v5, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;->f:Landroidx/viewbinding/ViewBinding;

    .line 430
    .line 431
    check-cast p1, Lx4/i;

    .line 432
    .line 433
    if-eqz p1, :cond_1b

    .line 434
    .line 435
    iget-object p1, p1, Lx4/i;->c:Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;

    .line 436
    .line 437
    invoke-virtual {p1, v1}, Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;->setSendOtcButtonState(Z)V

    .line 438
    .line 439
    .line 440
    :cond_1b
    iget-object p1, v5, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;->f:Landroidx/viewbinding/ViewBinding;

    .line 441
    .line 442
    check-cast p1, Lx4/i;

    .line 443
    .line 444
    if-eqz p1, :cond_1c

    .line 445
    .line 446
    iget-object p1, p1, Lx4/i;->c:Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;

    .line 447
    .line 448
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 449
    .line 450
    .line 451
    move-result-object p2

    .line 452
    invoke-virtual {p1, p2}, Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;->setError(Ljava/lang/String;)V

    .line 453
    .line 454
    .line 455
    :cond_1c
    iget-object p1, v5, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;->f:Landroidx/viewbinding/ViewBinding;

    .line 456
    .line 457
    check-cast p1, Lx4/i;

    .line 458
    .line 459
    if-eqz p1, :cond_22

    .line 460
    .line 461
    iget-object p1, p1, Lx4/i;->c:Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;

    .line 462
    .line 463
    iget-object p1, p1, Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;->c:Lcom/flexibank/sdk/customview/FlexiBankPinEntryView;

    .line 464
    .line 465
    if-eqz p1, :cond_22

    .line 466
    .line 467
    invoke-virtual {p1, v0}, Lcom/flexibank/sdk/customview/FlexiBankPinEntryView;->setText(Ljava/lang/CharSequence;)V

    .line 468
    .line 469
    .line 470
    goto :goto_5

    .line 471
    :cond_1d
    instance-of p1, v5, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayPinFragment;

    .line 472
    .line 473
    if-eqz p1, :cond_20

    .line 474
    .line 475
    check-cast v5, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayPinFragment;

    .line 476
    .line 477
    iget-object p1, v5, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayPinFragment;->t:Lcom/flexibank/sdk/customview/FlexiBankPinEntryView;

    .line 478
    .line 479
    if-eqz p1, :cond_1e

    .line 480
    .line 481
    new-instance v1, Landroid/text/SpannableStringBuilder;

    .line 482
    .line 483
    invoke-direct {v1, v0}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 484
    .line 485
    .line 486
    invoke-virtual {p1, v1}, Lcom/flexibank/sdk/customview/FlexiBankPinEntryView;->setText(Landroid/text/Editable;)V

    .line 487
    .line 488
    .line 489
    :cond_1e
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 490
    .line 491
    .line 492
    move-result-object p1

    .line 493
    const-string v1, "MEMBER_0052"

    .line 494
    .line 495
    invoke-virtual {v1, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 496
    .line 497
    .line 498
    move-result v1

    .line 499
    if-eqz v1, :cond_1f

    .line 500
    .line 501
    new-instance p1, LO6/c;

    .line 502
    .line 503
    invoke-virtual {v5}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 504
    .line 505
    .line 506
    move-result-object v0

    .line 507
    invoke-direct {p1, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 508
    .line 509
    .line 510
    sget v0, Lcom/flexibank/sdk/r;->fb_failed_all_cap:I

    .line 511
    .line 512
    invoke-virtual {p1, v0}, LO6/c;->e(I)V

    .line 513
    .line 514
    .line 515
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 516
    .line 517
    .line 518
    move-result-object p2

    .line 519
    iput-object p2, p1, LO6/c;->d:Ljava/lang/CharSequence;

    .line 520
    .line 521
    sget p2, Lcom/flexibank/sdk/r;->fb_confirm:I

    .line 522
    .line 523
    invoke-virtual {p1, p2, v2}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 524
    .line 525
    .line 526
    invoke-virtual {p1}, LO6/c;->g()LO6/d;

    .line 527
    .line 528
    .line 529
    goto :goto_5

    .line 530
    :cond_1f
    const-string v1, "MEMBER_0051"

    .line 531
    .line 532
    invoke-virtual {v1, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 533
    .line 534
    .line 535
    move-result p1

    .line 536
    if-eqz p1, :cond_20

    .line 537
    .line 538
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 539
    .line 540
    .line 541
    move-result-object p1

    .line 542
    new-array p2, v3, [Ljava/lang/Object;

    .line 543
    .line 544
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 545
    .line 546
    .line 547
    goto :goto_5

    .line 548
    :cond_20
    :goto_3
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 549
    .line 550
    .line 551
    move-result-object p1

    .line 552
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 553
    .line 554
    .line 555
    move-result-object p2

    .line 556
    if-nez p2, :cond_21

    .line 557
    .line 558
    goto :goto_4

    .line 559
    :cond_21
    move-object v0, p2

    .line 560
    :goto_4
    invoke-virtual {v4, p1, v0}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->j(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 561
    .line 562
    .line 563
    :cond_22
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 564
    .line 565
    return-object p1

    .line 566
    nop

    .line 567
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
