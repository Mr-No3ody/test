.class public final synthetic LP3/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, LP3/m;->a:I

    iput-object p1, p0, LP3/m;->b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget-object p1, p0, LP3/m;->b:Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 2
    .line 3
    iget v0, p0, LP3/m;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v0, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->Y:I

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    sget v0, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->Y:I

    .line 15
    .line 16
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_1
    sget v0, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->Y:I

    .line 21
    .line 22
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    new-instance v1, LY3/a;

    .line 27
    .line 28
    const/16 v2, 0x182

    .line 29
    .line 30
    invoke-direct {v1, v2}, LY3/a;-><init>(I)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, v1}, Lorg/greenrobot/eventbus/c;->f(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    nop

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
