.class public final synthetic LP3/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LP3/c;


# direct methods
.method public synthetic constructor <init>(LP3/c;I)V
    .locals 0

    .line 1
    iput p2, p0, LP3/a;->a:I

    iput-object p1, p0, LP3/a;->b:LP3/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LP3/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, LQ3/f;

    .line 7
    .line 8
    const-string v1, "context"

    .line 9
    .line 10
    iget-object v2, p0, LP3/a;->b:LP3/c;

    .line 11
    .line 12
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    sget v1, Lcom/flexibank/sdk/q;->fb_layout_payment_tax_detail_dialog:I

    .line 16
    .line 17
    sget v3, Lcom/flexibank/sdk/s;->fb_BaseDialogTheme:I

    .line 18
    .line 19
    invoke-direct {v0, v2, v1, v3}, Lo4/b;-><init>(Landroid/content/Context;II)V

    .line 20
    .line 21
    .line 22
    return-object v0

    .line 23
    :pswitch_0
    new-instance v0, LQ3/d;

    .line 24
    .line 25
    const-string v1, "context"

    .line 26
    .line 27
    iget-object v2, p0, LP3/a;->b:LP3/c;

    .line 28
    .line 29
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    sget v1, Lcom/flexibank/sdk/q;->fb_layout_payment_fee_detail_dialog:I

    .line 33
    .line 34
    sget v3, Lcom/flexibank/sdk/s;->fb_BaseDialogTheme:I

    .line 35
    .line 36
    invoke-direct {v0, v2, v1, v3}, Lo4/b;-><init>(Landroid/content/Context;II)V

    .line 37
    .line 38
    .line 39
    return-object v0

    .line 40
    nop

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
