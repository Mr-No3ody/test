.class public final LP3/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationLauncher$PayVerificationResult;


# instance fields
.field public final synthetic a:Lcom/flexibank/sdk/cashier/ui/activity/a;


# direct methods
.method public constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LP3/k;->a:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onPayVerificationComplete()V
    .locals 1

    .line 1
    iget-object v0, p0, LP3/k;->a:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onPayVerificationFail(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "errorCode"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "errorMsg"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final onPayVerificationSuccess(Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;)V
    .locals 1

    .line 1
    iget-object v0, p0, LP3/k;->a:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LP3/c;->g(Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
