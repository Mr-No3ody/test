.class public final synthetic LP3/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/ui/activity/a;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/a;I)V
    .locals 0

    .line 1
    iput p2, p0, LP3/e;->a:I

    iput-object p1, p0, LP3/e;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LP3/e;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LO3/i;

    .line 7
    .line 8
    check-cast p2, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp;

    .line 9
    .line 10
    const-string/jumbo v0, "rsp"

    .line 11
    .line 12
    .line 13
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, LP3/e;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-virtual {p2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp;->e()Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {p2}, LW3/f;->c()Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    const/4 v3, 0x0

    .line 30
    const/4 v4, 0x1

    .line 31
    const/4 v5, 0x0

    .line 32
    const-string v6, ""

    .line 33
    .line 34
    if-eqz v2, :cond_9

    .line 35
    .line 36
    if-eqz v1, :cond_9

    .line 37
    .line 38
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->f()Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-eqz v2, :cond_6

    .line 43
    .line 44
    iget-object v2, v0, LP3/c;->A:Ljava/lang/String;

    .line 45
    .line 46
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->h()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v6

    .line 50
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-nez v2, :cond_2

    .line 55
    .line 56
    sget p1, Lcom/flexibank/sdk/r;->fb_fail_to_pay_order:I

    .line 57
    .line 58
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    sget p2, Lcom/flexibank/sdk/r;->fb_confirm:I

    .line 63
    .line 64
    invoke-virtual {v0, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    new-instance v1, LO6/c;

    .line 69
    .line 70
    invoke-direct {v1, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 71
    .line 72
    .line 73
    sget v2, Lcom/flexibank/sdk/r;->fb_title_error_info:I

    .line 74
    .line 75
    invoke-virtual {v1, v2}, LO6/c;->e(I)V

    .line 76
    .line 77
    .line 78
    iput-object p1, v1, LO6/c;->d:Ljava/lang/CharSequence;

    .line 79
    .line 80
    if-eqz p2, :cond_1

    .line 81
    .line 82
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    if-nez p1, :cond_0

    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_0
    iput-object p2, v1, LO6/c;->f:Ljava/lang/String;

    .line 90
    .line 91
    iput-object v3, v1, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 92
    .line 93
    :cond_1
    :goto_0
    invoke-virtual {v1}, LO6/c;->g()LO6/d;

    .line 94
    .line 95
    .line 96
    const-string p1, "orderNo not Match"

    .line 97
    .line 98
    iget-object p2, v0, LK3/d;->b:Ljava/lang/String;

    .line 99
    .line 100
    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 101
    .line 102
    .line 103
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 104
    .line 105
    .line 106
    goto/16 :goto_a

    .line 107
    .line 108
    :cond_2
    new-instance v2, LO3/e;

    .line 109
    .line 110
    invoke-direct {v2}, LO3/e;-><init>()V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->h()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v3

    .line 117
    invoke-virtual {v2, v3}, LO3/e;->o(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->j()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    invoke-virtual {v2, v3}, LO3/e;->r(Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->p()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    invoke-virtual {v2, v3}, LO3/e;->u(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->q()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v3

    .line 138
    invoke-virtual {v2, v3}, LO3/e;->y(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->r()I

    .line 142
    .line 143
    .line 144
    move-result v3

    .line 145
    invoke-virtual {v2, v3}, LO3/e;->A(I)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->k()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    invoke-virtual {v2, v3}, LO3/e;->s(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    iget-object v3, v0, LP3/c;->B:Ljava/lang/String;

    .line 156
    .line 157
    invoke-virtual {v2, v3}, LO3/e;->x(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->i()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    invoke-virtual {v2, v1}, LO3/e;->p(Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    if-eqz p1, :cond_3

    .line 168
    .line 169
    invoke-virtual {p1}, LO3/i;->a()J

    .line 170
    .line 171
    .line 172
    move-result-wide v6

    .line 173
    goto :goto_1

    .line 174
    :cond_3
    iget-wide v6, v0, LP3/c;->M:J

    .line 175
    .line 176
    :goto_1
    invoke-virtual {v2, v6, v7}, LO3/e;->q(J)V

    .line 177
    .line 178
    .line 179
    iget-wide v6, v0, LP3/c;->H:J

    .line 180
    .line 181
    invoke-virtual {v2, v6, v7}, LO3/e;->n(J)V

    .line 182
    .line 183
    .line 184
    if-eqz p1, :cond_4

    .line 185
    .line 186
    invoke-virtual {p1}, LO3/i;->b()J

    .line 187
    .line 188
    .line 189
    move-result-wide v6

    .line 190
    goto :goto_2

    .line 191
    :cond_4
    const-wide/16 v6, 0x0

    .line 192
    .line 193
    :goto_2
    invoke-virtual {v2, v6, v7}, LO3/e;->m(J)V

    .line 194
    .line 195
    .line 196
    iget-object p1, v0, LP3/c;->C:Ljava/lang/String;

    .line 197
    .line 198
    invoke-virtual {v2, p1}, LO3/e;->v(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    const-string p1, "checkPayReq"

    .line 202
    .line 203
    invoke-static {v2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    const-string v1, "context"

    .line 207
    .line 208
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    invoke-static {v2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    iget-object p1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 215
    .line 216
    new-instance v1, LP3/k;

    .line 217
    .line 218
    invoke-direct {v1, v0}, LP3/k;-><init>(Lcom/flexibank/sdk/cashier/ui/activity/a;)V

    .line 219
    .line 220
    .line 221
    const-string v3, "result"

    .line 222
    .line 223
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    const-string v3, "launcher"

    .line 227
    .line 228
    iget-object v6, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->Z:LV3/g;

    .line 229
    .line 230
    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 231
    .line 232
    .line 233
    new-instance v3, Landroid/content/Intent;

    .line 234
    .line 235
    const-class v7, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 236
    .line 237
    invoke-direct {v3, v0, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {p2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp;->e()Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;

    .line 241
    .line 242
    .line 243
    move-result-object p2

    .line 244
    const-string v0, "key_pay_response"

    .line 245
    .line 246
    invoke-virtual {v3, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 247
    .line 248
    .line 249
    if-eqz p1, :cond_5

    .line 250
    .line 251
    const-string p2, "payment_method"

    .line 252
    .line 253
    invoke-virtual {v3, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 254
    .line 255
    .line 256
    :cond_5
    const-string/jumbo p1, "verify_content"

    .line 257
    .line 258
    .line 259
    invoke-virtual {v3, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 260
    .line 261
    .line 262
    const-string p1, "FORCE_NO_NIGHT_MODE"

    .line 263
    .line 264
    invoke-virtual {v3, p1, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 265
    .line 266
    .line 267
    const-string p1, "key_extra_used_new_pay_check"

    .line 268
    .line 269
    invoke-virtual {v3, p1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 270
    .line 271
    .line 272
    new-instance p1, LN8/a;

    .line 273
    .line 274
    const/16 p2, 0x8

    .line 275
    .line 276
    invoke-direct {p1, v1, p2}, LN8/a;-><init>(Ljava/lang/Object;I)V

    .line 277
    .line 278
    .line 279
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 280
    .line 281
    .line 282
    const-string p2, "intent"

    .line 283
    .line 284
    invoke-static {v3, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 285
    .line 286
    .line 287
    const-string p2, "onActivityResult"

    .line 288
    .line 289
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 290
    .line 291
    .line 292
    new-instance p2, LG9/i;

    .line 293
    .line 294
    const/4 v0, 0x3

    .line 295
    invoke-direct {p2, p1, v0}, LG9/i;-><init>(Ljava/lang/Object;I)V

    .line 296
    .line 297
    .line 298
    invoke-virtual {v6, v3, p2}, LV3/d;->d(Ljava/lang/Object;Landroidx/activity/result/ActivityResultCallback;)V

    .line 299
    .line 300
    .line 301
    goto/16 :goto_a

    .line 302
    .line 303
    :cond_6
    invoke-virtual {v1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;->c()Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object p1

    .line 307
    if-nez p1, :cond_7

    .line 308
    .line 309
    goto :goto_3

    .line 310
    :cond_7
    move-object v6, p1

    .line 311
    :goto_3
    sget-object p1, Lj4/j;->b:Lj4/i;

    .line 312
    .line 313
    const-string v1, "payStatus"

    .line 314
    .line 315
    invoke-virtual {p1, v6, v1}, Lj4/i;->getJsonString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 316
    .line 317
    .line 318
    move-result-object p1

    .line 319
    const-string v1, "8"

    .line 320
    .line 321
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 322
    .line 323
    .line 324
    move-result p1

    .line 325
    if-eqz p1, :cond_8

    .line 326
    .line 327
    invoke-virtual {p2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp;->e()Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;

    .line 328
    .line 329
    .line 330
    move-result-object p1

    .line 331
    invoke-virtual {v0, p1}, LP3/c;->g(Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;)V

    .line 332
    .line 333
    .line 334
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 335
    .line 336
    .line 337
    goto/16 :goto_a

    .line 338
    .line 339
    :cond_8
    invoke-virtual {p2}, Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp;->e()Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;

    .line 340
    .line 341
    .line 342
    move-result-object p1

    .line 343
    invoke-virtual {v0, p1}, LP3/c;->g(Lcom/flexibank/sdk/cashier/bean/FlexiBankPayByOrderResp$DataBean;)V

    .line 344
    .line 345
    .line 346
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 347
    .line 348
    .line 349
    goto/16 :goto_a

    .line 350
    .line 351
    :cond_9
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 352
    .line 353
    .line 354
    move-result-object p1

    .line 355
    const-string v1, "CFRONT_300061"

    .line 356
    .line 357
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 358
    .line 359
    .line 360
    move-result p1

    .line 361
    if-eqz p1, :cond_b

    .line 362
    .line 363
    sget p1, Lcom/flexibank/sdk/p;->fb_cl_cashier_preview:I

    .line 364
    .line 365
    invoke-virtual {v0, p1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 366
    .line 367
    .line 368
    move-result-object p1

    .line 369
    if-eqz p1, :cond_a

    .line 370
    .line 371
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    .line 372
    .line 373
    .line 374
    move-result p1

    .line 375
    if-nez p1, :cond_a

    .line 376
    .line 377
    goto :goto_4

    .line 378
    :cond_a
    move v4, v5

    .line 379
    :goto_4
    if-nez v4, :cond_15

    .line 380
    .line 381
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 382
    .line 383
    .line 384
    goto/16 :goto_a

    .line 385
    .line 386
    :cond_b
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 387
    .line 388
    .line 389
    move-result-object p1

    .line 390
    const-string v1, "CFRONT_800107"

    .line 391
    .line 392
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 393
    .line 394
    .line 395
    move-result p1

    .line 396
    const-string v1, "dialog"

    .line 397
    .line 398
    if-eqz p1, :cond_c

    .line 399
    .line 400
    sget p1, Lcom/flexibank/sdk/r;->fb_tips:I

    .line 401
    .line 402
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 403
    .line 404
    .line 405
    move-result-object p2

    .line 406
    sget v2, Lcom/flexibank/sdk/r;->fb_add_bvn:I

    .line 407
    .line 408
    sget v6, Lcom/flexibank/sdk/r;->fb_confirm:I

    .line 409
    .line 410
    sget v7, LL6/i;->ppDefaultDialogTheme:I

    .line 411
    .line 412
    new-instance v8, LO6/c;

    .line 413
    .line 414
    invoke-direct {v8, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 415
    .line 416
    .line 417
    iput v4, v8, LO6/c;->u:I

    .line 418
    .line 419
    invoke-virtual {v8, p1}, LO6/c;->e(I)V

    .line 420
    .line 421
    .line 422
    iput-object p2, v8, LO6/c;->d:Ljava/lang/CharSequence;

    .line 423
    .line 424
    invoke-virtual {v8, v2, v3}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 425
    .line 426
    .line 427
    invoke-virtual {v8, v6, v3}, LO6/c;->c(ILandroid/view/View$OnClickListener;)V

    .line 428
    .line 429
    .line 430
    iput-boolean v5, v8, LO6/c;->k:Z

    .line 431
    .line 432
    iput v5, v8, LO6/c;->l:I

    .line 433
    .line 434
    iput v7, v8, LO6/c;->v:I

    .line 435
    .line 436
    invoke-virtual {v8}, LO6/c;->g()LO6/d;

    .line 437
    .line 438
    .line 439
    move-result-object p1

    .line 440
    invoke-virtual {p1, v5}, LO6/d;->setCancelable(Z)V

    .line 441
    .line 442
    .line 443
    invoke-virtual {p1, v5}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 444
    .line 445
    .line 446
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 447
    .line 448
    .line 449
    new-instance p2, LP3/h;

    .line 450
    .line 451
    const/4 v1, 0x0

    .line 452
    invoke-direct {p2, v0, v1}, LP3/h;-><init>(Lcom/flexibank/sdk/cashier/ui/activity/a;I)V

    .line 453
    .line 454
    .line 455
    invoke-virtual {p1, p2}, LO6/f;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 456
    .line 457
    .line 458
    goto/16 :goto_a

    .line 459
    .line 460
    :cond_c
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 461
    .line 462
    .line 463
    move-result-object p1

    .line 464
    const-string v2, "33000094"

    .line 465
    .line 466
    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 467
    .line 468
    .line 469
    move-result p1

    .line 470
    if-eqz p1, :cond_d

    .line 471
    .line 472
    sget p1, Lcom/flexibank/sdk/r;->fb_set_a_payment_pin:I

    .line 473
    .line 474
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 475
    .line 476
    .line 477
    move-result-object p2

    .line 478
    sget v2, Lcom/flexibank/sdk/r;->fb_confirm:I

    .line 479
    .line 480
    new-instance v3, LP3/g;

    .line 481
    .line 482
    const/4 v6, 0x1

    .line 483
    invoke-direct {v3, v0, v6}, LP3/g;-><init>(Lcom/flexibank/sdk/cashier/ui/activity/a;I)V

    .line 484
    .line 485
    .line 486
    sget v6, LL6/i;->ppDefaultDialogTheme:I

    .line 487
    .line 488
    new-instance v7, LO6/c;

    .line 489
    .line 490
    invoke-direct {v7, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 491
    .line 492
    .line 493
    iput v4, v7, LO6/c;->u:I

    .line 494
    .line 495
    invoke-virtual {v7, p1}, LO6/c;->e(I)V

    .line 496
    .line 497
    .line 498
    iput-object p2, v7, LO6/c;->d:Ljava/lang/CharSequence;

    .line 499
    .line 500
    invoke-virtual {v7, v2, v3}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 501
    .line 502
    .line 503
    iput-boolean v5, v7, LO6/c;->k:Z

    .line 504
    .line 505
    iput v5, v7, LO6/c;->l:I

    .line 506
    .line 507
    iput v6, v7, LO6/c;->v:I

    .line 508
    .line 509
    invoke-virtual {v7}, LO6/c;->g()LO6/d;

    .line 510
    .line 511
    .line 512
    move-result-object p1

    .line 513
    invoke-virtual {p1, v5}, LO6/d;->setCancelable(Z)V

    .line 514
    .line 515
    .line 516
    invoke-virtual {p1, v5}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 517
    .line 518
    .line 519
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 520
    .line 521
    .line 522
    new-instance p2, LP3/h;

    .line 523
    .line 524
    const/4 v1, 0x1

    .line 525
    invoke-direct {p2, v0, v1}, LP3/h;-><init>(Lcom/flexibank/sdk/cashier/ui/activity/a;I)V

    .line 526
    .line 527
    .line 528
    invoke-virtual {p1, p2}, LO6/f;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 529
    .line 530
    .line 531
    goto/16 :goto_a

    .line 532
    .line 533
    :cond_d
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 534
    .line 535
    .line 536
    move-result-object p1

    .line 537
    const-string v1, "33000039"

    .line 538
    .line 539
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 540
    .line 541
    .line 542
    move-result v1

    .line 543
    if-nez v1, :cond_13

    .line 544
    .line 545
    const-string v1, "33000040"

    .line 546
    .line 547
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 548
    .line 549
    .line 550
    move-result v1

    .line 551
    if-nez v1, :cond_13

    .line 552
    .line 553
    const-string v1, "33000041"

    .line 554
    .line 555
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 556
    .line 557
    .line 558
    move-result p1

    .line 559
    if-eqz p1, :cond_e

    .line 560
    .line 561
    goto :goto_8

    .line 562
    :cond_e
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 563
    .line 564
    .line 565
    move-result-object p1

    .line 566
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 567
    .line 568
    .line 569
    move-result-object p2

    .line 570
    if-nez p2, :cond_f

    .line 571
    .line 572
    goto :goto_5

    .line 573
    :cond_f
    move-object v6, p2

    .line 574
    :goto_5
    const-string p2, "code"

    .line 575
    .line 576
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 577
    .line 578
    .line 579
    const-string p2, "message"

    .line 580
    .line 581
    invoke-static {v6, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 582
    .line 583
    .line 584
    new-instance p2, LO6/c;

    .line 585
    .line 586
    invoke-direct {p2, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 587
    .line 588
    .line 589
    sget v1, Lcom/flexibank/sdk/r;->fb_title_error_info:I

    .line 590
    .line 591
    invoke-virtual {p2, v1}, LO6/c;->e(I)V

    .line 592
    .line 593
    .line 594
    iput-object v6, p2, LO6/c;->d:Ljava/lang/CharSequence;

    .line 595
    .line 596
    iput-boolean v4, p2, LO6/c;->k:Z

    .line 597
    .line 598
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 599
    .line 600
    .line 601
    move-result v1

    .line 602
    if-nez v1, :cond_10

    .line 603
    .line 604
    const-string v1, "CFRONT_TCE"

    .line 605
    .line 606
    invoke-static {p1, v1, v5}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 607
    .line 608
    .line 609
    move-result v1

    .line 610
    if-nez v1, :cond_12

    .line 611
    .line 612
    :cond_10
    const-string v1, "CFRONT_700013"

    .line 613
    .line 614
    invoke-virtual {v1, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 615
    .line 616
    .line 617
    move-result v1

    .line 618
    if-nez v1, :cond_12

    .line 619
    .line 620
    const-string v1, "CFRONT_700012"

    .line 621
    .line 622
    invoke-virtual {v1, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 623
    .line 624
    .line 625
    move-result p1

    .line 626
    if-eqz p1, :cond_11

    .line 627
    .line 628
    goto :goto_6

    .line 629
    :cond_11
    sget p1, Lcom/flexibank/sdk/r;->fb_confirm:I

    .line 630
    .line 631
    new-instance v1, LP3/b;

    .line 632
    .line 633
    const/4 v2, 0x1

    .line 634
    invoke-direct {v1, v0, v2}, LP3/b;-><init>(LP3/c;I)V

    .line 635
    .line 636
    .line 637
    invoke-virtual {p2, p1, v1}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 638
    .line 639
    .line 640
    goto :goto_7

    .line 641
    :cond_12
    :goto_6
    sget p1, Lcom/flexibank/sdk/r;->fb_confirm:I

    .line 642
    .line 643
    new-instance v1, LP3/b;

    .line 644
    .line 645
    const/4 v2, 0x0

    .line 646
    invoke-direct {v1, v0, v2}, LP3/b;-><init>(LP3/c;I)V

    .line 647
    .line 648
    .line 649
    invoke-virtual {p2, p1, v1}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 650
    .line 651
    .line 652
    :goto_7
    invoke-virtual {p2}, LO6/c;->a()LO6/d;

    .line 653
    .line 654
    .line 655
    move-result-object p1

    .line 656
    invoke-virtual {p1, v5}, LO6/d;->setCancelable(Z)V

    .line 657
    .line 658
    .line 659
    invoke-virtual {p1, v5}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 660
    .line 661
    .line 662
    invoke-virtual {p1}, LO6/d;->show()V

    .line 663
    .line 664
    .line 665
    goto :goto_a

    .line 666
    :cond_13
    :goto_8
    invoke-virtual {p2}, LW3/f;->a()Ljava/lang/String;

    .line 667
    .line 668
    .line 669
    move-result-object p1

    .line 670
    invoke-virtual {p2}, LW3/f;->b()Ljava/lang/String;

    .line 671
    .line 672
    .line 673
    move-result-object p2

    .line 674
    if-nez p2, :cond_14

    .line 675
    .line 676
    goto :goto_9

    .line 677
    :cond_14
    move-object v6, p2

    .line 678
    :goto_9
    invoke-static {v0, p1, v6}, Lj4/u;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 679
    .line 680
    .line 681
    :cond_15
    :goto_a
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 682
    .line 683
    return-object p1

    .line 684
    :pswitch_0
    check-cast p1, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 685
    .line 686
    check-cast p2, LO3/h;

    .line 687
    .line 688
    const-string/jumbo v0, "rsp"

    .line 689
    .line 690
    .line 691
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 692
    .line 693
    .line 694
    invoke-virtual {p2}, LW3/f;->c()Z

    .line 695
    .line 696
    .line 697
    move-result v0

    .line 698
    if-eqz v0, :cond_20

    .line 699
    .line 700
    iget-object v0, p0, LP3/e;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 701
    .line 702
    const/4 v1, 0x0

    .line 703
    const/4 v2, 0x1

    .line 704
    if-eqz p1, :cond_1a

    .line 705
    .line 706
    iput-object p1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 707
    .line 708
    iget-object v3, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->p0:Ljava/util/ArrayList;

    .line 709
    .line 710
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 711
    .line 712
    .line 713
    move-result-object v4

    .line 714
    :cond_16
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 715
    .line 716
    .line 717
    move-result v5

    .line 718
    if-eqz v5, :cond_17

    .line 719
    .line 720
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 721
    .line 722
    .line 723
    move-result-object v5

    .line 724
    move-object v6, v5

    .line 725
    check-cast v6, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 726
    .line 727
    invoke-static {p1, v6}, Lio/fastkv/n;->c(Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;)Z

    .line 728
    .line 729
    .line 730
    move-result v6

    .line 731
    if-eqz v6, :cond_16

    .line 732
    .line 733
    goto :goto_b

    .line 734
    :cond_17
    const/4 v5, 0x0

    .line 735
    :goto_b
    check-cast v5, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 736
    .line 737
    if-nez v5, :cond_19

    .line 738
    .line 739
    const-string v4, "<this>"

    .line 740
    .line 741
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 742
    .line 743
    .line 744
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 745
    .line 746
    .line 747
    move-result v4

    .line 748
    const/4 v5, 0x2

    .line 749
    if-ne v4, v5, :cond_18

    .line 750
    .line 751
    invoke-interface {v3, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 752
    .line 753
    .line 754
    :cond_18
    invoke-interface {v3, v1, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 755
    .line 756
    .line 757
    :cond_19
    invoke-virtual {v0}, Lcom/flexibank/sdk/cashier/ui/activity/a;->k()LM3/g;

    .line 758
    .line 759
    .line 760
    move-result-object p1

    .line 761
    iget-object v4, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 762
    .line 763
    iput-object v4, p1, LM3/g;->d:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 764
    .line 765
    invoke-virtual {v0}, Lcom/flexibank/sdk/cashier/ui/activity/a;->k()LM3/g;

    .line 766
    .line 767
    .line 768
    move-result-object p1

    .line 769
    invoke-virtual {p1, v3}, LM3/g;->b(Ljava/util/List;)V

    .line 770
    .line 771
    .line 772
    goto :goto_c

    .line 773
    :cond_1a
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 774
    .line 775
    .line 776
    :goto_c
    iget-object p1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->D0:Lxf/t;

    .line 777
    .line 778
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 779
    .line 780
    .line 781
    move-result-object p1

    .line 782
    check-cast p1, LQ3/i;

    .line 783
    .line 784
    if-eqz p1, :cond_1b

    .line 785
    .line 786
    invoke-virtual {p1}, Landroid/app/Dialog;->isShowing()Z

    .line 787
    .line 788
    .line 789
    move-result p1

    .line 790
    if-ne p1, v2, :cond_1b

    .line 791
    .line 792
    iget-object p1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->D0:Lxf/t;

    .line 793
    .line 794
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 795
    .line 796
    .line 797
    move-result-object p1

    .line 798
    check-cast p1, LQ3/i;

    .line 799
    .line 800
    if-eqz p1, :cond_1b

    .line 801
    .line 802
    invoke-virtual {p1}, Lo4/b;->dismiss()V

    .line 803
    .line 804
    .line 805
    :cond_1b
    invoke-virtual {p2}, LO3/h;->e()Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;

    .line 806
    .line 807
    .line 808
    move-result-object p1

    .line 809
    if-nez p1, :cond_1c

    .line 810
    .line 811
    invoke-virtual {v0}, Lcom/flexibank/sdk/cashier/ui/activity/a;->o()V

    .line 812
    .line 813
    .line 814
    goto :goto_e

    .line 815
    :cond_1c
    invoke-virtual {v0}, Lcom/flexibank/sdk/cashier/ui/activity/a;->p()V

    .line 816
    .line 817
    .line 818
    const-string p2, "data"

    .line 819
    .line 820
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 821
    .line 822
    .line 823
    iput-object p1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->s0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;

    .line 824
    .line 825
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;->c()Ljava/lang/String;

    .line 826
    .line 827
    .line 828
    move-result-object p2

    .line 829
    iput-object p2, v0, LP3/c;->Q:Ljava/lang/String;

    .line 830
    .line 831
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;->h()Ljava/lang/Long;

    .line 832
    .line 833
    .line 834
    move-result-object p2

    .line 835
    const-wide/16 v2, 0x0

    .line 836
    .line 837
    if-eqz p2, :cond_1d

    .line 838
    .line 839
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 840
    .line 841
    .line 842
    move-result-wide v4

    .line 843
    goto :goto_d

    .line 844
    :cond_1d
    move-wide v4, v2

    .line 845
    :goto_d
    iput-wide v4, v0, LP3/c;->M:J

    .line 846
    .line 847
    iget-object p2, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 848
    .line 849
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;->i()Ljava/lang/Long;

    .line 850
    .line 851
    .line 852
    move-result-object v4

    .line 853
    if-eqz p2, :cond_1f

    .line 854
    .line 855
    if-eqz v4, :cond_1e

    .line 856
    .line 857
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 858
    .line 859
    .line 860
    move-result-wide v2

    .line 861
    :cond_1e
    invoke-virtual {p2, v2, v3}, Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;->A(J)V

    .line 862
    .line 863
    .line 864
    :cond_1f
    invoke-virtual {v0, p1, v1}, Lcom/flexibank/sdk/cashier/ui/activity/a;->v(Lcom/flexibank/sdk/cashier/bean/FlexiBankCalcOfPaymentMethodResultBean;Z)V

    .line 865
    .line 866
    .line 867
    :cond_20
    :goto_e
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 868
    .line 869
    return-object p1

    .line 870
    nop

    .line 871
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
