.class public final synthetic LP3/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionItem$OnPromotionItemListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;

.field public final synthetic c:Lcom/flexibank/sdk/cashier/ui/activity/a;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;Lcom/flexibank/sdk/cashier/ui/activity/a;I)V
    .locals 0

    .line 1
    iput p3, p0, LP3/d;->a:I

    iput-object p1, p0, LP3/d;->b:Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;

    iput-object p2, p0, LP3/d;->c:Lcom/flexibank/sdk/cashier/ui/activity/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onPromotionItemClick()V
    .locals 4

    .line 1
    iget v0, p0, LP3/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LP3/d;->b:Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;

    .line 7
    .line 8
    iget-object v1, v0, Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;->f:Ljava/lang/Boolean;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 v1, 0x0

    .line 18
    :goto_0
    xor-int/lit8 v1, v1, 0x1

    .line 19
    .line 20
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const/16 v2, 0x3d

    .line 25
    .line 26
    const/4 v3, 0x0

    .line 27
    invoke-static {v0, v3, v1, v3, v2}, Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;->b(Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;I)V

    .line 28
    .line 29
    .line 30
    iget-object v0, p0, LP3/d;->c:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 31
    .line 32
    iget-object v1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 33
    .line 34
    if-eqz v1, :cond_1

    .line 35
    .line 36
    invoke-virtual {v0, v1}, Lcom/flexibank/sdk/cashier/ui/activity/a;->r(Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;)V

    .line 37
    .line 38
    .line 39
    :cond_1
    return-void

    .line 40
    :pswitch_0
    iget-object v0, p0, LP3/d;->b:Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;

    .line 41
    .line 42
    iget-object v1, v0, Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;->e:Ljava/lang/Boolean;

    .line 43
    .line 44
    if-eqz v1, :cond_2

    .line 45
    .line 46
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    goto :goto_1

    .line 51
    :cond_2
    const/4 v1, 0x0

    .line 52
    :goto_1
    xor-int/lit8 v1, v1, 0x1

    .line 53
    .line 54
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    const/16 v2, 0x3e

    .line 59
    .line 60
    const/4 v3, 0x0

    .line 61
    invoke-static {v0, v1, v3, v3, v2}, Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;->b(Lcom/flexibank/sdk/cashier/ui/view/FlexiBankModelPaymentPromotionLayout;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;I)V

    .line 62
    .line 63
    .line 64
    iget-object v0, p0, LP3/d;->c:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 65
    .line 66
    iget-object v1, v0, Lcom/flexibank/sdk/cashier/ui/activity/a;->u0:Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;

    .line 67
    .line 68
    if-eqz v1, :cond_3

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Lcom/flexibank/sdk/cashier/ui/activity/a;->r(Lcom/flexibank/sdk/cashier/bean/FlexiBankCashierPaymentMethodBean;)V

    .line 71
    .line 72
    .line 73
    :cond_3
    return-void

    .line 74
    nop

    .line 75
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
