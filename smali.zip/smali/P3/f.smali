.class public final synthetic LP3/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/ui/activity/a;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/ui/activity/a;I)V
    .locals 0

    .line 1
    iput p2, p0, LP3/f;->a:I

    iput-object p1, p0, LP3/f;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LP3/f;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, LQ3/i;

    .line 7
    .line 8
    iget-object v1, p0, LP3/f;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 9
    .line 10
    invoke-direct {v0, v1}, LQ3/i;-><init>(Landroid/content/Context;)V

    .line 11
    .line 12
    .line 13
    iput-object v1, v0, LQ3/i;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;

    .line 14
    .line 15
    return-object v0

    .line 16
    :pswitch_0
    new-instance v0, LQ3/c;

    .line 17
    .line 18
    iget-object v1, p0, LP3/f;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 19
    .line 20
    invoke-direct {v0, v1}, LQ3/c;-><init>(Landroid/content/Context;)V

    .line 21
    .line 22
    .line 23
    iput-object v1, v0, LQ3/c;->w:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierCouponListDialog$CallBack;

    .line 24
    .line 25
    return-object v0

    .line 26
    :pswitch_1
    new-instance v0, LM3/g;

    .line 27
    .line 28
    invoke-direct {v0}, LM3/g;-><init>()V

    .line 29
    .line 30
    .line 31
    const-string v1, "listener"

    .line 32
    .line 33
    iget-object v2, p0, LP3/f;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 34
    .line 35
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    iput-object v2, v0, LM3/g;->b:Lcom/flexibank/sdk/cashier/ui/dialog/FlexiBankCashierSelectPayMethodDialog$CallBack;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    iget-object v0, p0, LP3/f;->b:Lcom/flexibank/sdk/cashier/ui/activity/a;

    .line 42
    .line 43
    iget-wide v0, v0, LP3/c;->M:J

    .line 44
    .line 45
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    return-object v0

    .line 50
    nop

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
