.class public LD4/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/github/mikephil/charting/highlight/IHighlighter;


# instance fields
.field public final a:Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;

.field public final b:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LD4/b;->b:Ljava/util/ArrayList;

    .line 10
    .line 11
    iput-object p1, p0, LD4/b;->a:Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;

    .line 12
    .line 13
    return-void
.end method

.method public static d(Ljava/util/List;FLA4/g;)F
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 3
    .line 4
    .line 5
    move-result p2

    .line 6
    if-ge p1, p2, :cond_0

    .line 7
    .line 8
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p2

    .line 12
    check-cast p2, LD4/c;

    .line 13
    .line 14
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    add-int/lit8 p1, p1, 0x1

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const p0, 0x7f7fffff    # Float.MAX_VALUE

    .line 21
    .line 22
    .line 23
    return p0
.end method


# virtual methods
.method public a()V
    .locals 1

    .line 1
    iget-object v0, p0, LD4/b;->a:Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;

    .line 2
    .line 3
    invoke-interface {v0}, Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;->getData()LB4/b;

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final b(FFF)LD4/c;
    .locals 0

    .line 1
    invoke-virtual {p0}, LD4/b;->c()Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    if-eqz p2, :cond_0

    .line 10
    .line 11
    goto :goto_1

    .line 12
    :cond_0
    sget-object p2, LA4/g;->a:LA4/g;

    .line 13
    .line 14
    invoke-static {p1, p3, p2}, LD4/b;->d(Ljava/util/List;FLA4/g;)F

    .line 15
    .line 16
    .line 17
    sget-object p2, LA4/g;->b:LA4/g;

    .line 18
    .line 19
    invoke-static {p1, p3, p2}, LD4/b;->d(Ljava/util/List;FLA4/g;)F

    .line 20
    .line 21
    .line 22
    iget-object p2, p0, LD4/b;->a:Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;

    .line 23
    .line 24
    invoke-interface {p2}, Lcom/github/mikephil/charting/interfaces/dataprovider/ChartInterface;->getMaxHighlightDistance()F

    .line 25
    .line 26
    .line 27
    const/4 p2, 0x0

    .line 28
    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 29
    .line 30
    .line 31
    move-result p3

    .line 32
    if-ge p2, p3, :cond_1

    .line 33
    .line 34
    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p3

    .line 38
    check-cast p3, LD4/c;

    .line 39
    .line 40
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    add-int/lit8 p2, p2, 0x1

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    :goto_1
    const/4 p1, 0x0

    .line 47
    return-object p1
.end method

.method public c()Ljava/util/List;
    .locals 1

    .line 1
    iget-object v0, p0, LD4/b;->b:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LD4/b;->a()V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public getHighlight(FF)LD4/c;
    .locals 4

    .line 1
    sget-object v0, LA4/g;->a:LA4/g;

    .line 2
    .line 3
    iget-object v1, p0, LD4/b;->a:Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;

    .line 4
    .line 5
    invoke-interface {v1, v0}, Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;->getTransformer(LA4/g;)LG4/g;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    const-wide/16 v1, 0x0

    .line 13
    .line 14
    invoke-static {v1, v2, v1, v2}, LG4/c;->b(DD)LG4/c;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    invoke-virtual {v0, p1, p2, v1}, LG4/g;->a(FFLG4/c;)V

    .line 19
    .line 20
    .line 21
    iget-wide v2, v1, LG4/c;->b:D

    .line 22
    .line 23
    double-to-float v0, v2

    .line 24
    sget-object v2, LG4/c;->d:LG4/f;

    .line 25
    .line 26
    invoke-virtual {v2, v1}, LG4/f;->c(LG4/e;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0, v0, p1, p2}, LD4/b;->b(FFF)LD4/c;

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    return-object p1
.end method
