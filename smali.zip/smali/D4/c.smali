.class public abstract LD4/c;
.super Ljava/lang/Object;
.source "SourceFile"
