.class public final LD4/d;
.super LD4/a;
.source "SourceFile"


# virtual methods
.method public final getHighlight(FF)LD4/c;
    .locals 3

    .line 1
    iget-object v0, p0, LD4/b;->a:Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;

    .line 2
    .line 3
    check-cast v0, Lcom/github/mikephil/charting/interfaces/dataprovider/BarDataProvider;

    .line 4
    .line 5
    invoke-interface {v0}, Lcom/github/mikephil/charting/interfaces/dataprovider/BarDataProvider;->getBarData()LB4/a;

    .line 6
    .line 7
    .line 8
    sget-object v0, LA4/g;->a:LA4/g;

    .line 9
    .line 10
    iget-object v1, p0, LD4/b;->a:Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;

    .line 11
    .line 12
    invoke-interface {v1, v0}, Lcom/github/mikephil/charting/interfaces/dataprovider/BarLineScatterCandleBubbleDataProvider;->getTransformer(LA4/g;)LG4/g;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    const-wide/16 v1, 0x0

    .line 20
    .line 21
    invoke-static {v1, v2, v1, v2}, LG4/c;->b(DD)LG4/c;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {v0, p2, p1, v1}, LG4/g;->a(FFLG4/c;)V

    .line 26
    .line 27
    .line 28
    iget-wide v0, v1, LG4/c;->c:D

    .line 29
    .line 30
    double-to-float v0, v0

    .line 31
    invoke-virtual {p0, v0, p2, p1}, LD4/b;->b(FFF)LD4/c;

    .line 32
    .line 33
    .line 34
    const/4 p1, 0x0

    .line 35
    return-object p1
.end method
