.class public final Ll2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/common/disk/DiskTrimmableRegistry;
.implements Lio/reactivex/functions/Function;
.implements Landroidx/camera/core/processing/Operation;
.implements Lcom/bumptech/glide/manager/RequestManagerRetriever$RequestManagerFactory;
.implements Lcom/nimbusds/jose/shaded/gson/internal/ObjectConstructor;
.implements Lcom/didi/drouter/store/IRouterProxy;
.implements Lcom/facebook/imagepipeline/core/DiskStorageFactory;
.implements Lcom/airbnb/lottie/configurations/reducemotion/ReducedMotionOption;


# static fields
.field public static b:Ll2/a;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Ll2/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LG7/x;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Ll2/a;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iget-object p1, p1, LG7/x;->a:LG7/y;

    return-void
.end method

.method public static a(Ljava/io/File;Ljava/io/File;)Landroid/net/Uri;
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-virtual {p0, p1}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    if-eqz p0, :cond_1

    .line 15
    .line 16
    invoke-static {p1}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0

    .line 21
    :cond_1
    new-instance p0, LE/Q;

    .line 22
    .line 23
    new-instance v0, Ljava/lang/StringBuilder;

    .line 24
    .line 25
    const-string v1, "Failed to overwrite the file: "

    .line 26
    .line 27
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    const/4 v0, 0x0

    .line 42
    const/4 v1, 0x1

    .line 43
    invoke-direct {p0, v1, p1, v0}, LE/Q;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 44
    .line 45
    .line 46
    throw p0
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Ll2/a;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    move-object/from16 v0, p1

    .line 9
    .line 10
    check-cast v0, Landroidx/camera/core/imagecapture/d;

    .line 11
    .line 12
    iget-object v2, v0, Landroidx/camera/core/imagecapture/d;->a:Landroidx/camera/core/processing/b;

    .line 13
    .line 14
    iget-object v0, v0, Landroidx/camera/core/imagecapture/d;->b:Ls5/d;

    .line 15
    .line 16
    const/4 v3, 0x1

    .line 17
    :try_start_0
    iget-object v4, v0, Ls5/d;->b:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v4, Ljava/io/File;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 20
    .line 21
    const-string v5, "CameraX"

    .line 22
    .line 23
    if-eqz v4, :cond_1

    .line 24
    .line 25
    :try_start_1
    new-instance v6, Ljava/io/File;

    .line 26
    .line 27
    invoke-virtual {v4}, Ljava/io/File;->getParent()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v7

    .line 31
    new-instance v8, Ljava/lang/StringBuilder;

    .line 32
    .line 33
    invoke-direct {v8, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 37
    .line 38
    .line 39
    move-result-object v5

    .line 40
    invoke-virtual {v5}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    const/16 v5, 0x2e

    .line 52
    .line 53
    invoke-virtual {v4, v5}, Ljava/lang/String;->lastIndexOf(I)I

    .line 54
    .line 55
    .line 56
    move-result v5

    .line 57
    if-ltz v5, :cond_0

    .line 58
    .line 59
    invoke-virtual {v4, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    goto :goto_0

    .line 64
    :cond_0
    const-string v4, ""

    .line 65
    .line 66
    :goto_0
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v4

    .line 73
    invoke-direct {v6, v7, v4}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    goto :goto_1

    .line 77
    :catch_0
    move-exception v0

    .line 78
    goto/16 :goto_a

    .line 79
    .line 80
    :cond_1
    const-string v4, ".tmp"

    .line 81
    .line 82
    invoke-static {v5, v4}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 83
    .line 84
    .line 85
    move-result-object v6
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    .line 86
    :goto_1
    iget-object v4, v2, Landroidx/camera/core/processing/b;->a:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v4, [B

    .line 89
    .line 90
    :try_start_2
    new-instance v5, Ljava/io/FileOutputStream;

    .line 91
    .line 92
    invoke-direct {v5, v6}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_3

    .line 93
    .line 94
    .line 95
    :try_start_3
    new-instance v7, LPa/w;

    .line 96
    .line 97
    const/16 v8, 0xe

    .line 98
    .line 99
    invoke-direct {v7, v8}, LPa/w;-><init>(I)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v7, v4}, LPa/w;->k([B)I

    .line 103
    .line 104
    .line 105
    move-result v7

    .line 106
    const/4 v8, 0x0

    .line 107
    invoke-virtual {v5, v4, v8, v7}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 108
    .line 109
    .line 110
    :try_start_4
    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    .line 111
    .line 112
    .line 113
    iget-object v4, v2, Landroidx/camera/core/processing/b;->b:Landroidx/camera/core/impl/utils/e;

    .line 114
    .line 115
    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    :try_start_5
    invoke-virtual {v6}, Ljava/io/File;->toString()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v5

    .line 122
    new-instance v7, Landroidx/camera/core/impl/utils/e;

    .line 123
    .line 124
    new-instance v9, Lq0/g;

    .line 125
    .line 126
    invoke-direct {v9, v5}, Lq0/g;-><init>(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    invoke-direct {v7, v9}, Landroidx/camera/core/impl/utils/e;-><init>(Lq0/g;)V

    .line 130
    .line 131
    .line 132
    iget-object v5, v7, Landroidx/camera/core/impl/utils/e;->a:Lq0/g;

    .line 133
    .line 134
    invoke-virtual {v4, v7}, Landroidx/camera/core/impl/utils/e;->a(Landroidx/camera/core/impl/utils/e;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v7}, Landroidx/camera/core/impl/utils/e;->b()I

    .line 138
    .line 139
    .line 140
    move-result v4
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2

    .line 141
    const/4 v11, 0x6

    .line 142
    const/16 v12, 0x8

    .line 143
    .line 144
    const/4 v13, 0x2

    .line 145
    const/4 v14, 0x4

    .line 146
    const/4 v15, 0x7

    .line 147
    const/16 v16, 0x5

    .line 148
    .line 149
    const-string v10, "Orientation"

    .line 150
    .line 151
    if-nez v4, :cond_5

    .line 152
    .line 153
    iget v2, v2, Landroidx/camera/core/processing/b;->f:I

    .line 154
    .line 155
    if-eqz v2, :cond_5

    .line 156
    .line 157
    :try_start_6
    rem-int/lit8 v4, v2, 0x5a

    .line 158
    .line 159
    if-eqz v4, :cond_2

    .line 160
    .line 161
    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 162
    .line 163
    const-string v2, "e"

    .line 164
    .line 165
    invoke-static {v2}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    invoke-static {v8}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    invoke-virtual {v9, v10, v2}, Lq0/g;->F(Ljava/lang/String;Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    goto :goto_4

    .line 176
    :cond_2
    rem-int/lit16 v2, v2, 0x168

    .line 177
    .line 178
    invoke-virtual {v9, v8, v10}, Lq0/g;->e(ILjava/lang/String;)I

    .line 179
    .line 180
    .line 181
    move-result v4

    .line 182
    :goto_2
    if-gez v2, :cond_3

    .line 183
    .line 184
    add-int/lit8 v2, v2, 0x5a

    .line 185
    .line 186
    packed-switch v4, :pswitch_data_1

    .line 187
    .line 188
    .line 189
    move v4, v12

    .line 190
    goto :goto_2

    .line 191
    :pswitch_0
    move v4, v11

    .line 192
    goto :goto_2

    .line 193
    :pswitch_1
    move v4, v13

    .line 194
    goto :goto_2

    .line 195
    :pswitch_2
    move v4, v3

    .line 196
    goto :goto_2

    .line 197
    :pswitch_3
    move v4, v14

    .line 198
    goto :goto_2

    .line 199
    :pswitch_4
    move v4, v15

    .line 200
    goto :goto_2

    .line 201
    :pswitch_5
    move/from16 v4, v16

    .line 202
    .line 203
    goto :goto_2

    .line 204
    :cond_3
    :goto_3
    if-lez v2, :cond_4

    .line 205
    .line 206
    add-int/lit8 v2, v2, -0x5a

    .line 207
    .line 208
    packed-switch v4, :pswitch_data_2

    .line 209
    .line 210
    .line 211
    move v4, v11

    .line 212
    goto :goto_3

    .line 213
    :pswitch_6
    move v4, v3

    .line 214
    goto :goto_3

    .line 215
    :pswitch_7
    move v4, v14

    .line 216
    goto :goto_3

    .line 217
    :pswitch_8
    const/4 v4, 0x3

    .line 218
    goto :goto_3

    .line 219
    :pswitch_9
    move v4, v13

    .line 220
    goto :goto_3

    .line 221
    :pswitch_a
    move/from16 v4, v16

    .line 222
    .line 223
    goto :goto_3

    .line 224
    :pswitch_b
    move v4, v12

    .line 225
    goto :goto_3

    .line 226
    :pswitch_c
    move v4, v15

    .line 227
    goto :goto_3

    .line 228
    :cond_4
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 229
    .line 230
    .line 231
    move-result-object v2

    .line 232
    invoke-virtual {v9, v10, v2}, Lq0/g;->F(Ljava/lang/String;Ljava/lang/String;)V

    .line 233
    .line 234
    .line 235
    :cond_5
    :goto_4
    iget-object v2, v0, Ls5/d;->c:Ljava/lang/Object;

    .line 236
    .line 237
    check-cast v2, LE/N;

    .line 238
    .line 239
    iget-boolean v2, v2, LE/N;->b:Z

    .line 240
    .line 241
    if-eqz v2, :cond_6

    .line 242
    .line 243
    invoke-virtual {v5, v8, v10}, Lq0/g;->e(ILjava/lang/String;)I

    .line 244
    .line 245
    .line 246
    move-result v2

    .line 247
    packed-switch v2, :pswitch_data_3

    .line 248
    .line 249
    .line 250
    move v14, v13

    .line 251
    goto :goto_5

    .line 252
    :pswitch_d
    move v14, v15

    .line 253
    goto :goto_5

    .line 254
    :pswitch_e
    move v14, v12

    .line 255
    goto :goto_5

    .line 256
    :pswitch_f
    move/from16 v14, v16

    .line 257
    .line 258
    goto :goto_5

    .line 259
    :pswitch_10
    move v14, v11

    .line 260
    goto :goto_5

    .line 261
    :pswitch_11
    const/4 v14, 0x3

    .line 262
    goto :goto_5

    .line 263
    :pswitch_12
    move v14, v3

    .line 264
    :goto_5
    :pswitch_13
    invoke-static {v14}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v2

    .line 268
    invoke-virtual {v5, v10, v2}, Lq0/g;->F(Ljava/lang/String;Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    :cond_6
    invoke-virtual {v7}, Landroidx/camera/core/impl/utils/e;->c()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_2

    .line 272
    .line 273
    .line 274
    const/4 v2, 0x0

    .line 275
    :try_start_7
    iget-object v0, v0, Ls5/d;->b:Ljava/lang/Object;

    .line 276
    .line 277
    check-cast v0, Ljava/io/File;

    .line 278
    .line 279
    if-eqz v0, :cond_7

    .line 280
    .line 281
    invoke-static {v6, v0}, Ll2/a;->a(Ljava/io/File;Ljava/io/File;)Landroid/net/Uri;

    .line 282
    .line 283
    .line 284
    move-result-object v2
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_1
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 285
    goto :goto_6

    .line 286
    :catchall_0
    move-exception v0

    .line 287
    goto :goto_7

    .line 288
    :cond_7
    :goto_6
    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    .line 289
    .line 290
    .line 291
    new-instance v0, LE/O;

    .line 292
    .line 293
    invoke-direct {v0, v2}, LE/O;-><init>(Landroid/net/Uri;)V

    .line 294
    .line 295
    .line 296
    return-object v0

    .line 297
    :catch_1
    :try_start_8
    new-instance v0, LE/Q;

    .line 298
    .line 299
    const-string v4, "Failed to write to OutputStream."

    .line 300
    .line 301
    invoke-direct {v0, v3, v4, v2}, LE/Q;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 302
    .line 303
    .line 304
    throw v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 305
    :goto_7
    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    .line 306
    .line 307
    .line 308
    throw v0

    .line 309
    :catch_2
    move-exception v0

    .line 310
    new-instance v2, LE/Q;

    .line 311
    .line 312
    const-string v4, "Failed to update Exif data"

    .line 313
    .line 314
    invoke-direct {v2, v3, v4, v0}, LE/Q;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 315
    .line 316
    .line 317
    throw v2

    .line 318
    :catch_3
    move-exception v0

    .line 319
    goto :goto_9

    .line 320
    :catchall_1
    move-exception v0

    .line 321
    move-object v2, v0

    .line 322
    :try_start_9
    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    .line 323
    .line 324
    .line 325
    goto :goto_8

    .line 326
    :catchall_2
    move-exception v0

    .line 327
    :try_start_a
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 328
    .line 329
    .line 330
    :goto_8
    throw v2
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_3

    .line 331
    :goto_9
    new-instance v2, LE/Q;

    .line 332
    .line 333
    const-string v4, "Failed to write to temp file"

    .line 334
    .line 335
    invoke-direct {v2, v3, v4, v0}, LE/Q;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 336
    .line 337
    .line 338
    throw v2

    .line 339
    :goto_a
    new-instance v2, LE/Q;

    .line 340
    .line 341
    const-string v4, "Failed to create temp file."

    .line 342
    .line 343
    invoke-direct {v2, v3, v4, v0}, LE/Q;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    .line 344
    .line 345
    .line 346
    throw v2

    .line 347
    :pswitch_14
    move-object/from16 v0, p1

    .line 348
    .line 349
    check-cast v0, Ljava/util/List;

    .line 350
    .line 351
    sget-object v2, LS9/a;->a:Lorg/greenrobot/eventbus/f;

    .line 352
    .line 353
    iget-object v2, v2, Lorg/greenrobot/eventbus/f;->b:Ljava/lang/Object;

    .line 354
    .line 355
    check-cast v2, Lcom/transsnet/palmpay/contacts/api/ContactsApiService;

    .line 356
    .line 357
    invoke-interface {v2, v0}, Lcom/transsnet/palmpay/contacts/api/ContactsApiService;->queryMobileAndPalmPayContacts(Ljava/util/List;)Ldf/d;

    .line 358
    .line 359
    .line 360
    move-result-object v0

    .line 361
    return-object v0

    .line 362
    nop

    .line 363
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_14
    .end packed-switch

    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    :pswitch_data_1
    .packed-switch 0x2
        :pswitch_5
        :pswitch_0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    :pswitch_data_2
    .packed-switch 0x2
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
    .end packed-switch

    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    :pswitch_data_3
    .packed-switch 0x2
        :pswitch_12
        :pswitch_13
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
    .end packed-switch
.end method

.method public build(Lcom/bumptech/glide/b;Lcom/bumptech/glide/manager/Lifecycle;Lcom/bumptech/glide/manager/RequestManagerTreeNode;Landroid/content/Context;)Lcom/bumptech/glide/p;
    .locals 1

    .line 1
    new-instance v0, Loc/c;

    .line 2
    .line 3
    invoke-direct {v0, p1, p2, p3, p4}, Lcom/bumptech/glide/p;-><init>(Lcom/bumptech/glide/b;Lcom/bumptech/glide/manager/Lifecycle;Lcom/bumptech/glide/manager/RequestManagerTreeNode;Landroid/content/Context;)V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public callMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget p1, p0, Ll2/a;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance p1, LU2/B;

    .line 7
    .line 8
    const/16 p2, 0xb

    .line 9
    .line 10
    invoke-direct {p1, p2}, LU2/B;-><init>(I)V

    .line 11
    .line 12
    .line 13
    throw p1

    .line 14
    :pswitch_0
    new-instance p1, LU2/B;

    .line 15
    .line 16
    const/16 p2, 0xb

    .line 17
    .line 18
    invoke-direct {p1, p2}, LU2/B;-><init>(I)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :pswitch_1
    new-instance p1, LU2/B;

    .line 23
    .line 24
    const/16 p2, 0xb

    .line 25
    .line 26
    invoke-direct {p1, p2}, LU2/B;-><init>(I)V

    .line 27
    .line 28
    .line 29
    throw p1

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public construct()Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, Ljava/util/TreeMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/TreeMap;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public get(Lj2/b;)Lcom/facebook/cache/disk/DiskStorage;
    .locals 4

    .line 1
    new-instance v0, Lcom/facebook/cache/disk/g;

    .line 2
    .line 3
    iget v1, p1, Lj2/b;->a:I

    .line 4
    .line 5
    iget-object v2, p1, Lj2/b;->c:Lj2/a;

    .line 6
    .line 7
    iget-object v3, p1, Lj2/b;->b:Ljava/lang/String;

    .line 8
    .line 9
    iget-object p1, p1, Lj2/b;->h:Li2/d;

    .line 10
    .line 11
    invoke-direct {v0, v1, v2, v3, p1}, Lcom/facebook/cache/disk/g;-><init>(ILj2/a;Ljava/lang/String;Li2/d;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public getCurrentReducedMotionMode(Landroid/content/Context;)Ln1/a;
    .locals 2

    .line 1
    if-eqz p1, :cond_1

    .line 2
    .line 3
    sget-object v0, Lcom/airbnb/lottie/utils/i;->a:Landroid/graphics/Matrix;

    .line 4
    .line 5
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    const-string v0, "animator_duration_scale"

    .line 10
    .line 11
    const/high16 v1, 0x3f800000    # 1.0f

    .line 12
    .line 13
    invoke-static {p1, v0, v1}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    const/4 v0, 0x0

    .line 18
    cmpl-float p1, p1, v0

    .line 19
    .line 20
    if-eqz p1, :cond_0

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    sget-object p1, Ln1/a;->b:Ln1/a;

    .line 24
    .line 25
    return-object p1

    .line 26
    :cond_1
    :goto_0
    sget-object p1, Ln1/a;->a:Ln1/a;

    .line 27
    .line 28
    return-object p1
.end method

.method public newInstance(Landroid/content/Context;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget p1, p0, Ll2/a;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance p1, Lcom/transsnet/palmpay/core/rnbridge/bridge/UploadPhotoBridge;

    .line 7
    .line 8
    invoke-direct {p1}, Lcom/transsnet/palmpay/core/rnbridge/bridge/UploadPhotoBridge;-><init>()V

    .line 9
    .line 10
    .line 11
    return-object p1

    .line 12
    :pswitch_0
    new-instance p1, Lcom/transsnet/palmpay/core/rnbridge/bridge/MfbBankSdkManagerBridge;

    .line 13
    .line 14
    invoke-direct {p1}, Lcom/transsnet/palmpay/core/rnbridge/bridge/MfbBankSdkManagerBridge;-><init>()V

    .line 15
    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_1
    new-instance p1, Lcom/palmpay/lib/bridgewrapper/statusbar/StatusBarThemeBridge;

    .line 19
    .line 20
    invoke-direct {p1}, Lcom/palmpay/lib/bridgewrapper/statusbar/StatusBarThemeBridge;-><init>()V

    .line 21
    .line 22
    .line 23
    return-object p1

    .line 24
    nop

    .line 25
    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public registerDiskTrimmable(Lcom/facebook/common/disk/DiskTrimmable;)V
    .locals 0

    .line 1
    return-void
.end method

.method public unregisterDiskTrimmable(Lcom/facebook/common/disk/DiskTrimmable;)V
    .locals 0

    .line 1
    return-void
.end method
