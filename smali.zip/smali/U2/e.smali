.class public final enum LU2/e;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum a:LU2/e;

.field public static final synthetic b:[LU2/e;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    .line 1
    new-instance v0, LU2/e;

    .line 2
    .line 3
    const-string v1, "FULL"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    new-instance v1, LU2/e;

    .line 10
    .line 11
    const-string v2, "LONG"

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 15
    .line 16
    .line 17
    new-instance v2, LU2/e;

    .line 18
    .line 19
    const-string v3, "MEDIUM"

    .line 20
    .line 21
    const/4 v4, 0x2

    .line 22
    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 23
    .line 24
    .line 25
    new-instance v3, LU2/e;

    .line 26
    .line 27
    const-string v4, "SHORT"

    .line 28
    .line 29
    const/4 v5, 0x3

    .line 30
    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 31
    .line 32
    .line 33
    new-instance v4, LU2/e;

    .line 34
    .line 35
    const-string v5, "UNDEFINED"

    .line 36
    .line 37
    const/4 v6, 0x4

    .line 38
    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 39
    .line 40
    .line 41
    sput-object v4, LU2/e;->a:LU2/e;

    .line 42
    .line 43
    filled-new-array {v0, v1, v2, v3, v4}, [LU2/e;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sput-object v0, LU2/e;->b:[LU2/e;

    .line 48
    .line 49
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LU2/e;
    .locals 1

    .line 1
    const-class v0, LU2/e;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LU2/e;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[LU2/e;
    .locals 1

    .line 1
    sget-object v0, LU2/e;->b:[LU2/e;

    .line 2
    .line 3
    invoke-virtual {v0}, [LU2/e;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LU2/e;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    if-eq v0, v1, :cond_3

    .line 9
    .line 10
    const/4 v1, 0x2

    .line 11
    if-eq v0, v1, :cond_2

    .line 12
    .line 13
    const/4 v1, 0x3

    .line 14
    if-eq v0, v1, :cond_1

    .line 15
    .line 16
    const/4 v1, 0x4

    .line 17
    if-ne v0, v1, :cond_0

    .line 18
    .line 19
    const-string v0, ""

    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 23
    .line 24
    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 25
    .line 26
    .line 27
    throw v0

    .line 28
    :cond_1
    const-string/jumbo v0, "short"

    .line 29
    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_2
    const-string v0, "medium"

    .line 33
    .line 34
    return-object v0

    .line 35
    :cond_3
    const-string v0, "long"

    .line 36
    .line 37
    return-object v0

    .line 38
    :cond_4
    const-string v0, "full"

    .line 39
    .line 40
    return-object v0
.end method
