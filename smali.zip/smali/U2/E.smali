.class public abstract LU2/E;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LG/h;

.field public static final b:LG/h;

.field public static final c:LG/h;

.field public static final d:LG/h;

.field public static final e:LG/h;


# direct methods
.method static constructor <clinit>()V
    .locals 74

    .line 1
    new-instance v0, LG/h;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "ca"

    .line 7
    .line 8
    const-string v2, "calendar"

    .line 9
    .line 10
    invoke-virtual {v0, v1, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    const-string v3, "nu"

    .line 14
    .line 15
    const-string v4, "numbers"

    .line 16
    .line 17
    invoke-virtual {v0, v3, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    const-string v5, "hc"

    .line 21
    .line 22
    const-string v6, "hours"

    .line 23
    .line 24
    invoke-virtual {v0, v5, v6}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    const-string v7, "co"

    .line 28
    .line 29
    const-string v8, "collation"

    .line 30
    .line 31
    invoke-virtual {v0, v7, v8}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    const-string v9, "kn"

    .line 35
    .line 36
    const-string v10, "colnumeric"

    .line 37
    .line 38
    invoke-virtual {v0, v9, v10}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    const-string v11, "kf"

    .line 42
    .line 43
    const-string v12, "colcasefirst"

    .line 44
    .line 45
    invoke-virtual {v0, v11, v12}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    sput-object v0, LU2/E;->a:LG/h;

    .line 49
    .line 50
    new-instance v0, LG/h;

    .line 51
    .line 52
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v0, v2, v1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    invoke-virtual {v0, v4, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    invoke-virtual {v0, v6, v5}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v0, v8, v7}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0, v10, v9}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v0, v12, v11}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    sput-object v0, LU2/E;->b:LG/h;

    .line 74
    .line 75
    new-instance v0, LG/h;

    .line 76
    .line 77
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 78
    .line 79
    .line 80
    const-string v2, "dictionary"

    .line 81
    .line 82
    const-string v4, "dict"

    .line 83
    .line 84
    invoke-virtual {v0, v2, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    const-string v2, "phonebook"

    .line 88
    .line 89
    const-string v4, "phonebk"

    .line 90
    .line 91
    invoke-virtual {v0, v2, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    const-string/jumbo v2, "traditional"

    .line 95
    .line 96
    .line 97
    const-string/jumbo v4, "trad"

    .line 98
    .line 99
    .line 100
    invoke-virtual {v0, v2, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    const-string v4, "gb2312han"

    .line 104
    .line 105
    const-string v5, "gb2312"

    .line 106
    .line 107
    invoke-virtual {v0, v4, v5}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    sput-object v0, LU2/E;->c:LG/h;

    .line 111
    .line 112
    new-instance v0, LG/h;

    .line 113
    .line 114
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 115
    .line 116
    .line 117
    const-string v4, "gregorian"

    .line 118
    .line 119
    const-string v5, "gregory"

    .line 120
    .line 121
    invoke-virtual {v0, v4, v5}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    sput-object v0, LU2/E;->d:LG/h;

    .line 125
    .line 126
    new-instance v0, LG/h;

    .line 127
    .line 128
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 129
    .line 130
    .line 131
    const-string/jumbo v4, "traditio"

    .line 132
    .line 133
    .line 134
    invoke-virtual {v0, v2, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    sput-object v0, LU2/E;->e:LG/h;

    .line 138
    .line 139
    new-instance v0, LG/h;

    .line 140
    .line 141
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 142
    .line 143
    .line 144
    const-string/jumbo v72, "wara"

    .line 145
    .line 146
    .line 147
    const-string/jumbo v73, "wcho"

    .line 148
    .line 149
    .line 150
    const-string v8, "adlm"

    .line 151
    .line 152
    const-string v9, "ahom"

    .line 153
    .line 154
    const-string v10, "arab"

    .line 155
    .line 156
    const-string v11, "arabext"

    .line 157
    .line 158
    const-string v12, "bali"

    .line 159
    .line 160
    const-string v13, "beng"

    .line 161
    .line 162
    const-string v14, "bhks"

    .line 163
    .line 164
    const-string v15, "brah"

    .line 165
    .line 166
    const-string v16, "cakm"

    .line 167
    .line 168
    const-string v17, "cham"

    .line 169
    .line 170
    const-string v18, "deva"

    .line 171
    .line 172
    const-string v19, "diak"

    .line 173
    .line 174
    const-string v20, "fullwide"

    .line 175
    .line 176
    const-string v21, "gong"

    .line 177
    .line 178
    const-string v22, "gonm"

    .line 179
    .line 180
    const-string v23, "gujr"

    .line 181
    .line 182
    const-string v24, "guru"

    .line 183
    .line 184
    const-string v25, "hanidec"

    .line 185
    .line 186
    const-string v26, "hmng"

    .line 187
    .line 188
    const-string v27, "hmnp"

    .line 189
    .line 190
    const-string v28, "java"

    .line 191
    .line 192
    const-string v29, "kali"

    .line 193
    .line 194
    const-string v30, "khmr"

    .line 195
    .line 196
    const-string v31, "knda"

    .line 197
    .line 198
    const-string v32, "lana"

    .line 199
    .line 200
    const-string v33, "lanatham"

    .line 201
    .line 202
    const-string v34, "laoo"

    .line 203
    .line 204
    const-string v35, "latn"

    .line 205
    .line 206
    const-string v36, "lepc"

    .line 207
    .line 208
    const-string v37, "limb"

    .line 209
    .line 210
    const-string v38, "mathbold"

    .line 211
    .line 212
    const-string v39, "mathdbl"

    .line 213
    .line 214
    const-string v40, "mathmono"

    .line 215
    .line 216
    const-string v41, "mathsanb"

    .line 217
    .line 218
    const-string v42, "mathsans"

    .line 219
    .line 220
    const-string v43, "mlym"

    .line 221
    .line 222
    const-string v44, "modi"

    .line 223
    .line 224
    const-string v45, "mong"

    .line 225
    .line 226
    const-string v46, "mroo"

    .line 227
    .line 228
    const-string v47, "mtei"

    .line 229
    .line 230
    const-string v48, "mymr"

    .line 231
    .line 232
    const-string v49, "mymrshan"

    .line 233
    .line 234
    const-string v50, "mymrtlng"

    .line 235
    .line 236
    const-string v51, "newa"

    .line 237
    .line 238
    const-string v52, "nkoo"

    .line 239
    .line 240
    const-string v53, "olck"

    .line 241
    .line 242
    const-string v54, "orya"

    .line 243
    .line 244
    const-string v55, "osma"

    .line 245
    .line 246
    const-string/jumbo v56, "rohg"

    .line 247
    .line 248
    .line 249
    const-string/jumbo v57, "saur"

    .line 250
    .line 251
    .line 252
    const-string/jumbo v58, "segment"

    .line 253
    .line 254
    .line 255
    const-string/jumbo v59, "shrd"

    .line 256
    .line 257
    .line 258
    const-string/jumbo v60, "sind"

    .line 259
    .line 260
    .line 261
    const-string/jumbo v61, "sinh"

    .line 262
    .line 263
    .line 264
    const-string/jumbo v62, "sora"

    .line 265
    .line 266
    .line 267
    const-string/jumbo v63, "sund"

    .line 268
    .line 269
    .line 270
    const-string/jumbo v64, "takr"

    .line 271
    .line 272
    .line 273
    const-string/jumbo v65, "talu"

    .line 274
    .line 275
    .line 276
    const-string/jumbo v66, "tamldec"

    .line 277
    .line 278
    .line 279
    const-string/jumbo v67, "telu"

    .line 280
    .line 281
    .line 282
    const-string/jumbo v68, "thai"

    .line 283
    .line 284
    .line 285
    const-string/jumbo v69, "tibt"

    .line 286
    .line 287
    .line 288
    const-string/jumbo v70, "tirh"

    .line 289
    .line 290
    .line 291
    const-string/jumbo v71, "vaii"

    .line 292
    .line 293
    .line 294
    filled-new-array/range {v8 .. v73}, [Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object v2

    .line 298
    invoke-virtual {v0, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 299
    .line 300
    .line 301
    const-string/jumbo v23, "unihan"

    .line 302
    .line 303
    .line 304
    const-string/jumbo v24, "zhuyin"

    .line 305
    .line 306
    .line 307
    const-string v8, "big5han"

    .line 308
    .line 309
    const-string v9, "compat"

    .line 310
    .line 311
    const-string v10, "dict"

    .line 312
    .line 313
    const-string v11, "direct"

    .line 314
    .line 315
    const-string v12, "ducet"

    .line 316
    .line 317
    const-string v13, "emoji"

    .line 318
    .line 319
    const-string v14, "eor"

    .line 320
    .line 321
    const-string v15, "gb2312"

    .line 322
    .line 323
    const-string v16, "phonebk"

    .line 324
    .line 325
    const-string v17, "phonetic"

    .line 326
    .line 327
    const-string v18, "pinyin"

    .line 328
    .line 329
    const-string v19, "reformed"

    .line 330
    .line 331
    const-string/jumbo v20, "searchjl"

    .line 332
    .line 333
    .line 334
    const-string/jumbo v21, "stroke"

    .line 335
    .line 336
    .line 337
    const-string/jumbo v22, "trad"

    .line 338
    .line 339
    .line 340
    filled-new-array/range {v8 .. v24}, [Ljava/lang/String;

    .line 341
    .line 342
    .line 343
    move-result-object v2

    .line 344
    invoke-virtual {v0, v7, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    const-string v24, "persian"

    .line 348
    .line 349
    const-string/jumbo v25, "roc"

    .line 350
    .line 351
    .line 352
    const-string v8, "buddhist"

    .line 353
    .line 354
    const-string v9, "chinese"

    .line 355
    .line 356
    const-string v10, "coptic"

    .line 357
    .line 358
    const-string v11, "dangi"

    .line 359
    .line 360
    const-string v12, "ethioaa"

    .line 361
    .line 362
    const-string v13, "ethiopic"

    .line 363
    .line 364
    const-string v14, "gregory"

    .line 365
    .line 366
    const-string v15, "hebrew"

    .line 367
    .line 368
    const-string v16, "indian"

    .line 369
    .line 370
    const-string v17, "islamic"

    .line 371
    .line 372
    const-string v18, "islamic-umalqura"

    .line 373
    .line 374
    const-string v19, "islamic-tbla"

    .line 375
    .line 376
    const-string v20, "islamic-civil"

    .line 377
    .line 378
    const-string v21, "islamic-rgsa"

    .line 379
    .line 380
    const-string v22, "iso8601"

    .line 381
    .line 382
    const-string v23, "japanese"

    .line 383
    .line 384
    filled-new-array/range {v8 .. v25}, [Ljava/lang/String;

    .line 385
    .line 386
    .line 387
    move-result-object v2

    .line 388
    invoke-virtual {v0, v1, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 389
    .line 390
    .line 391
    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;LU2/C;)Z
    .locals 4

    .line 1
    invoke-virtual {p2}, LU2/C;->a()V

    .line 2
    .line 3
    .line 4
    iget-object p2, p2, LU2/C;->a:Landroid/icu/util/ULocale;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    new-array v1, v0, [Ljava/lang/String;

    .line 8
    .line 9
    const-string v2, "co"

    .line 10
    .line 11
    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    if-eqz v3, :cond_2

    .line 16
    .line 17
    const-string/jumbo p0, "standard"

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    if-nez p0, :cond_1

    .line 25
    .line 26
    const-string/jumbo p0, "search"

    .line 27
    .line 28
    .line 29
    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result p0

    .line 33
    if-eqz p0, :cond_0

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    invoke-static {v2, p2, v0}, Landroid/icu/text/Collator;->getKeywordValuesForLocale(Ljava/lang/String;Landroid/icu/util/ULocale;Z)[Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    :goto_0
    return v0

    .line 42
    :cond_2
    const-string v2, "ca"

    .line 43
    .line 44
    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    if-eqz v3, :cond_3

    .line 49
    .line 50
    invoke-static {v2, p2, v0}, Landroid/icu/util/Calendar;->getKeywordValuesForLocale(Ljava/lang/String;Landroid/icu/util/ULocale;Z)[Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    goto :goto_1

    .line 55
    :cond_3
    const-string p2, "nu"

    .line 56
    .line 57
    invoke-virtual {p0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result p0

    .line 61
    if-eqz p0, :cond_4

    .line 62
    .line 63
    invoke-static {}, Landroid/icu/text/NumberingSystem;->getAvailableNames()[Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    :cond_4
    :goto_1
    array-length p0, v1

    .line 68
    if-nez p0, :cond_5

    .line 69
    .line 70
    const/4 p0, 0x1

    .line 71
    return p0

    .line 72
    :cond_5
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 73
    .line 74
    .line 75
    move-result-object p0

    .line 76
    invoke-interface {p0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result p0

    .line 80
    return p0
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    sget-object v0, LU2/E;->c:LG/h;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_0
    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    check-cast p0, Ljava/lang/String;

    .line 15
    .line 16
    return-object p0
.end method

.method public static c(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .locals 2

    .line 1
    const-string v0, "ca"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    instance-of v0, p0, Ljava/lang/String;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    check-cast p0, Ljava/lang/String;

    .line 14
    .line 15
    sget-object p1, LU2/E;->d:LG/h;

    .line 16
    .line 17
    invoke-virtual {p1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    return-object p0

    .line 24
    :cond_0
    invoke-virtual {p1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    check-cast p0, Ljava/lang/String;

    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1
    const-string v0, "nu"

    .line 32
    .line 33
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_3

    .line 38
    .line 39
    instance-of v0, p0, Ljava/lang/String;

    .line 40
    .line 41
    if-eqz v0, :cond_3

    .line 42
    .line 43
    check-cast p0, Ljava/lang/String;

    .line 44
    .line 45
    sget-object p1, LU2/E;->e:LG/h;

    .line 46
    .line 47
    invoke-virtual {p1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_2

    .line 52
    .line 53
    return-object p0

    .line 54
    :cond_2
    invoke-virtual {p1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    check-cast p0, Ljava/lang/String;

    .line 59
    .line 60
    return-object p0

    .line 61
    :cond_3
    const-string v0, "co"

    .line 62
    .line 63
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_4

    .line 68
    .line 69
    instance-of v0, p0, Ljava/lang/String;

    .line 70
    .line 71
    if-eqz v0, :cond_4

    .line 72
    .line 73
    check-cast p0, Ljava/lang/String;

    .line 74
    .line 75
    invoke-static {p0}, LU2/E;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    return-object p0

    .line 80
    :cond_4
    const-string v0, "kn"

    .line 81
    .line 82
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    if-eqz v1, :cond_5

    .line 87
    .line 88
    instance-of v1, p0, Ljava/lang/String;

    .line 89
    .line 90
    if-eqz v1, :cond_5

    .line 91
    .line 92
    const-string/jumbo v1, "yes"

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    if-eqz v1, :cond_5

    .line 100
    .line 101
    const-string/jumbo p0, "true"

    .line 102
    .line 103
    .line 104
    return-object p0

    .line 105
    :cond_5
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-nez v0, :cond_6

    .line 110
    .line 111
    const-string v0, "kf"

    .line 112
    .line 113
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    move-result p1

    .line 117
    if-eqz p1, :cond_7

    .line 118
    .line 119
    :cond_6
    instance-of p1, p0, Ljava/lang/String;

    .line 120
    .line 121
    if-eqz p1, :cond_7

    .line 122
    .line 123
    const-string p1, "no"

    .line 124
    .line 125
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result p1

    .line 129
    if-eqz p1, :cond_7

    .line 130
    .line 131
    const-string p0, "false"

    .line 132
    .line 133
    :cond_7
    return-object p0
.end method
