.class public abstract LU2/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[Ljava/lang/String;

.field public static final b:[Ljava/lang/String;

.field public static final c:[Ljava/lang/String;

.field public static final d:[Ljava/lang/String;

.field public static final e:LU2/A;

.field public static final f:LU2/z;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 4

    .line 1
    const-string v0, "best fit"

    .line 2
    .line 3
    const-string v1, "lookup"

    .line 4
    .line 5
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, LU2/a;->a:[Ljava/lang/String;

    .line 10
    .line 11
    const-string v0, "case"

    .line 12
    .line 13
    const-string/jumbo v1, "variant"

    .line 14
    .line 15
    .line 16
    const-string v2, "base"

    .line 17
    .line 18
    const-string v3, "accent"

    .line 19
    .line 20
    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    sput-object v0, LU2/a;->b:[Ljava/lang/String;

    .line 25
    .line 26
    const-string v0, "lower"

    .line 27
    .line 28
    const-string v1, "false"

    .line 29
    .line 30
    const-string/jumbo v2, "upper"

    .line 31
    .line 32
    .line 33
    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    sput-object v0, LU2/a;->c:[Ljava/lang/String;

    .line 38
    .line 39
    const-string/jumbo v0, "sort"

    .line 40
    .line 41
    .line 42
    const-string/jumbo v1, "search"

    .line 43
    .line 44
    .line 45
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    sput-object v0, LU2/a;->d:[Ljava/lang/String;

    .line 50
    .line 51
    new-instance v0, LU2/A;

    .line 52
    .line 53
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 54
    .line 55
    .line 56
    sput-object v0, LU2/a;->e:LU2/A;

    .line 57
    .line 58
    new-instance v0, LU2/z;

    .line 59
    .line 60
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 61
    .line 62
    .line 63
    sput-object v0, LU2/a;->f:LU2/z;

    .line 64
    .line 65
    return-void
.end method

.method public static a(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 1
    :goto_0
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {v0, p0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, -0x1

    .line 10
    if-le v0, v1, :cond_0

    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_0
    const-string v0, "-"

    .line 14
    .line 15
    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-gez v0, :cond_1

    .line 20
    .line 21
    const-string p0, ""

    .line 22
    .line 23
    return-object p0

    .line 24
    :cond_1
    const/4 v1, 0x2

    .line 25
    if-lt v0, v1, :cond_2

    .line 26
    .line 27
    add-int/lit8 v1, v0, -0x2

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    const/16 v2, 0x2d

    .line 34
    .line 35
    if-ne v1, v2, :cond_2

    .line 36
    .line 37
    add-int/lit8 v0, v0, -0x2

    .line 38
    .line 39
    :cond_2
    const/4 v1, 0x0

    .line 40
    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    goto :goto_0
.end method

.method public static b(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Double;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    instance-of v0, p1, LU2/A;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object p4

    .line 6
    :cond_0
    instance-of p4, p1, Ljava/lang/Double;

    .line 7
    .line 8
    const-string v0, " value is invalid."

    .line 9
    .line 10
    if-eqz p4, :cond_2

    .line 11
    .line 12
    move-object p4, p1

    .line 13
    check-cast p4, Ljava/lang/Double;

    .line 14
    .line 15
    invoke-virtual {p4}, Ljava/lang/Double;->doubleValue()D

    .line 16
    .line 17
    .line 18
    move-result-wide v1

    .line 19
    invoke-static {v1, v2}, Ljava/lang/Double;->isNaN(D)Z

    .line 20
    .line 21
    .line 22
    move-result p4

    .line 23
    if-nez p4, :cond_1

    .line 24
    .line 25
    invoke-virtual {p3}, Ljava/lang/Double;->doubleValue()D

    .line 26
    .line 27
    .line 28
    move-result-wide p3

    .line 29
    cmpl-double p3, v1, p3

    .line 30
    .line 31
    if-gtz p3, :cond_1

    .line 32
    .line 33
    check-cast p2, Ljava/lang/Double;

    .line 34
    .line 35
    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    .line 36
    .line 37
    .line 38
    move-result-wide p2

    .line 39
    cmpg-double p2, v1, p2

    .line 40
    .line 41
    if-ltz p2, :cond_1

    .line 42
    .line 43
    return-object p1

    .line 44
    :cond_1
    new-instance p1, LU2/B;

    .line 45
    .line 46
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    const/4 p2, 0x0

    .line 51
    invoke-direct {p1, p0, p2}, LU2/B;-><init>(Ljava/lang/String;I)V

    .line 52
    .line 53
    .line 54
    throw p1

    .line 55
    :cond_2
    new-instance p1, LU2/B;

    .line 56
    .line 57
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    const/4 p2, 0x0

    .line 62
    invoke-direct {p1, p0, p2}, LU2/B;-><init>(Ljava/lang/String;I)V

    .line 63
    .line 64
    .line 65
    throw p1
.end method

.method public static c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {p1, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    invoke-virtual {p1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    if-nez p0, :cond_0

    .line 14
    .line 15
    sget-object p0, LU2/a;->f:LU2/z;

    .line 16
    .line 17
    :cond_0
    return-object p0

    .line 18
    :cond_1
    sget-object p0, LU2/a;->e:LU2/A;

    .line 19
    .line 20
    return-object p0
.end method

.method public static d(Ljava/util/Map;Ljava/lang/String;ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p1, p0}, LU2/a;->c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    instance-of p1, p0, LU2/A;

    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    return-object p4

    .line 10
    :cond_0
    instance-of p1, p0, LU2/z;

    .line 11
    .line 12
    if-eqz p1, :cond_1

    .line 13
    .line 14
    const-string p0, ""

    .line 15
    .line 16
    :cond_1
    const/4 p1, 0x1

    .line 17
    if-ne p2, p1, :cond_3

    .line 18
    .line 19
    instance-of p1, p0, Ljava/lang/Boolean;

    .line 20
    .line 21
    if-eqz p1, :cond_2

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_2
    new-instance p0, LU2/B;

    .line 25
    .line 26
    const-string p1, "Boolean option expected but not found"

    .line 27
    .line 28
    const/4 p2, 0x0

    .line 29
    invoke-direct {p0, p1, p2}, LU2/B;-><init>(Ljava/lang/String;I)V

    .line 30
    .line 31
    .line 32
    throw p0

    .line 33
    :cond_3
    :goto_0
    const/4 p1, 0x2

    .line 34
    const-string p4, "String option expected but not found"

    .line 35
    .line 36
    if-ne p2, p1, :cond_5

    .line 37
    .line 38
    instance-of p1, p0, Ljava/lang/String;

    .line 39
    .line 40
    if-eqz p1, :cond_4

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_4
    new-instance p0, LU2/B;

    .line 44
    .line 45
    const/4 p1, 0x0

    .line 46
    invoke-direct {p0, p4, p1}, LU2/B;-><init>(Ljava/lang/String;I)V

    .line 47
    .line 48
    .line 49
    throw p0

    .line 50
    :cond_5
    :goto_1
    instance-of p1, p3, LU2/A;

    .line 51
    .line 52
    if-nez p1, :cond_7

    .line 53
    .line 54
    check-cast p3, [Ljava/lang/Object;

    .line 55
    .line 56
    invoke-static {p3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-interface {p1, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    if-eqz p1, :cond_6

    .line 65
    .line 66
    return-object p0

    .line 67
    :cond_6
    new-instance p0, LU2/B;

    .line 68
    .line 69
    const/4 p1, 0x0

    .line 70
    invoke-direct {p0, p4, p1}, LU2/B;-><init>(Ljava/lang/String;I)V

    .line 71
    .line 72
    .line 73
    throw p0

    .line 74
    :cond_7
    return-object p0
.end method

.method public static e([Ljava/lang/String;)Lp1/d;
    .locals 8

    .line 1
    new-instance v0, Lp1/d;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lp1/d;-><init>(I)V

    .line 6
    .line 7
    .line 8
    array-length v1, p0

    .line 9
    const/4 v2, 0x0

    .line 10
    move v3, v2

    .line 11
    :goto_0
    if-ge v3, v1, :cond_2

    .line 12
    .line 13
    aget-object v4, p0, v3

    .line 14
    .line 15
    invoke-static {v4}, LU2/a;->g(Ljava/lang/String;)LU2/C;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    invoke-static {}, Landroid/icu/util/ULocale;->getAvailableLocales()[Landroid/icu/util/ULocale;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    invoke-virtual {v4}, LU2/C;->getLocaleWithoutExtensions()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v6

    .line 27
    check-cast v6, Landroid/icu/util/ULocale;

    .line 28
    .line 29
    filled-new-array {v6}, [Landroid/icu/util/ULocale;

    .line 30
    .line 31
    .line 32
    move-result-object v6

    .line 33
    const/4 v7, 0x1

    .line 34
    new-array v7, v7, [Z

    .line 35
    .line 36
    invoke-static {v6, v5, v7}, Landroid/icu/util/ULocale;->acceptLanguage([Landroid/icu/util/ULocale;[Landroid/icu/util/ULocale;[Z)Landroid/icu/util/ULocale;

    .line 37
    .line 38
    .line 39
    move-result-object v5

    .line 40
    aget-boolean v6, v7, v2

    .line 41
    .line 42
    if-nez v6, :cond_0

    .line 43
    .line 44
    if-eqz v5, :cond_0

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_0
    const/4 v5, 0x0

    .line 48
    :goto_1
    if-eqz v5, :cond_1

    .line 49
    .line 50
    new-instance p0, LU2/C;

    .line 51
    .line 52
    invoke-direct {p0, v5}, LU2/C;-><init>(Landroid/icu/util/ULocale;)V

    .line 53
    .line 54
    .line 55
    iput-object p0, v0, Lp1/d;->b:Ljava/lang/Object;

    .line 56
    .line 57
    invoke-virtual {v4}, LU2/C;->getUnicodeExtensions()Ljava/util/HashMap;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    iput-object p0, v0, Lp1/d;->c:Ljava/lang/Object;

    .line 62
    .line 63
    return-object v0

    .line 64
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_2
    new-instance p0, LU2/C;

    .line 68
    .line 69
    sget-object v1, Landroid/icu/util/ULocale$Category;->FORMAT:Landroid/icu/util/ULocale$Category;

    .line 70
    .line 71
    invoke-static {v1}, Landroid/icu/util/ULocale;->getDefault(Landroid/icu/util/ULocale$Category;)Landroid/icu/util/ULocale;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    invoke-direct {p0, v1}, LU2/C;-><init>(Landroid/icu/util/ULocale;)V

    .line 76
    .line 77
    .line 78
    iput-object p0, v0, Lp1/d;->b:Ljava/lang/Object;

    .line 79
    .line 80
    return-object v0
.end method

.method public static f([Ljava/lang/String;)[Ljava/lang/String;
    .locals 8

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    array-length v1, p0

    .line 7
    const/4 v2, 0x0

    .line 8
    move v3, v2

    .line 9
    :goto_0
    if-ge v3, v1, :cond_2

    .line 10
    .line 11
    aget-object v4, p0, v3

    .line 12
    .line 13
    invoke-static {v4}, LU2/a;->g(Ljava/lang/String;)LU2/C;

    .line 14
    .line 15
    .line 16
    move-result-object v5

    .line 17
    invoke-static {}, Landroid/icu/util/ULocale;->getAvailableLocales()[Landroid/icu/util/ULocale;

    .line 18
    .line 19
    .line 20
    move-result-object v6

    .line 21
    invoke-virtual {v5}, LU2/C;->getLocaleWithoutExtensions()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    check-cast v5, Landroid/icu/util/ULocale;

    .line 26
    .line 27
    filled-new-array {v5}, [Landroid/icu/util/ULocale;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    const/4 v7, 0x1

    .line 32
    new-array v7, v7, [Z

    .line 33
    .line 34
    invoke-static {v5, v6, v7}, Landroid/icu/util/ULocale;->acceptLanguage([Landroid/icu/util/ULocale;[Landroid/icu/util/ULocale;[Z)Landroid/icu/util/ULocale;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    aget-boolean v6, v7, v2

    .line 39
    .line 40
    if-nez v6, :cond_0

    .line 41
    .line 42
    if-eqz v5, :cond_0

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_0
    const/4 v5, 0x0

    .line 46
    :goto_1
    if-eqz v5, :cond_1

    .line 47
    .line 48
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 55
    .line 56
    .line 57
    move-result p0

    .line 58
    new-array p0, p0, [Ljava/lang/String;

    .line 59
    .line 60
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    check-cast p0, [Ljava/lang/String;

    .line 65
    .line 66
    return-object p0
.end method

.method public static g(Ljava/lang/String;)LU2/C;
    .locals 2

    .line 1
    new-instance v0, LU2/C;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    iput-object v1, v0, LU2/C;->a:Landroid/icu/util/ULocale;

    .line 8
    .line 9
    iput-object v1, v0, LU2/C;->b:Landroid/icu/util/ULocale$Builder;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    iput-boolean v1, v0, LU2/C;->c:Z

    .line 13
    .line 14
    new-instance v1, Landroid/icu/util/ULocale$Builder;

    .line 15
    .line 16
    invoke-direct {v1}, Landroid/icu/util/ULocale$Builder;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object v1, v0, LU2/C;->b:Landroid/icu/util/ULocale$Builder;

    .line 20
    .line 21
    :try_start_0
    invoke-virtual {v1, p0}, Landroid/icu/util/ULocale$Builder;->setLanguageTag(Ljava/lang/String;)Landroid/icu/util/ULocale$Builder;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    .line 23
    .line 24
    const/4 p0, 0x1

    .line 25
    iput-boolean p0, v0, LU2/C;->c:Z

    .line 26
    .line 27
    return-object v0

    .line 28
    :catch_0
    move-exception p0

    .line 29
    new-instance v0, LU2/B;

    .line 30
    .line 31
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    const/4 v1, 0x0

    .line 36
    invoke-direct {v0, p0, v1}, LU2/B;-><init>(Ljava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    throw v0
.end method

.method public static h()[Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Ljava/util/Locale;->getAvailableLocales()[Ljava/util/Locale;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    array-length v2, v1

    .line 11
    const/4 v3, 0x0

    .line 12
    :goto_0
    if-ge v3, v2, :cond_0

    .line 13
    .line 14
    aget-object v4, v1, v3

    .line 15
    .line 16
    invoke-virtual {v4}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    add-int/lit8 v3, v3, 0x1

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    new-array v1, v1, [Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, [Ljava/lang/String;

    .line 37
    .line 38
    return-object v0
.end method

.method public static i(IILjava/lang/CharSequence;II)Z
    .locals 3

    .line 1
    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-lt p1, v0, :cond_0

    .line 7
    .line 8
    goto :goto_3

    .line 9
    :cond_0
    sub-int v0, p1, p0

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    add-int/2addr v0, v2

    .line 13
    if-lt v0, p3, :cond_8

    .line 14
    .line 15
    if-le v0, p4, :cond_1

    .line 16
    .line 17
    goto :goto_3

    .line 18
    :cond_1
    :goto_0
    if-gt p0, p1, :cond_7

    .line 19
    .line 20
    invoke-interface {p2, p0}, Ljava/lang/CharSequence;->charAt(I)C

    .line 21
    .line 22
    .line 23
    move-result p3

    .line 24
    const/16 p4, 0x61

    .line 25
    .line 26
    if-lt p3, p4, :cond_2

    .line 27
    .line 28
    const/16 p4, 0x7a

    .line 29
    .line 30
    if-le p3, p4, :cond_3

    .line 31
    .line 32
    :cond_2
    const/16 p4, 0x41

    .line 33
    .line 34
    if-lt p3, p4, :cond_4

    .line 35
    .line 36
    const/16 p4, 0x5a

    .line 37
    .line 38
    if-gt p3, p4, :cond_4

    .line 39
    .line 40
    :cond_3
    const/4 p4, 0x1

    .line 41
    goto :goto_1

    .line 42
    :cond_4
    const/4 p4, 0x0

    .line 43
    :goto_1
    if-nez p4, :cond_6

    .line 44
    .line 45
    const/16 p4, 0x30

    .line 46
    .line 47
    if-lt p3, p4, :cond_5

    .line 48
    .line 49
    const/16 p4, 0x39

    .line 50
    .line 51
    if-gt p3, p4, :cond_5

    .line 52
    .line 53
    goto :goto_2

    .line 54
    :cond_5
    return v1

    .line 55
    :cond_6
    :goto_2
    add-int/lit8 p0, p0, 0x1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_7
    return v2

    .line 59
    :cond_8
    :goto_3
    return v1
.end method

.method public static j([Ljava/lang/String;)[Ljava/lang/String;
    .locals 6

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {}, LU2/a;->h()[Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    array-length v2, p0

    .line 11
    const/4 v3, 0x0

    .line 12
    :goto_0
    if-ge v3, v2, :cond_1

    .line 13
    .line 14
    aget-object v4, p0, v3

    .line 15
    .line 16
    invoke-static {v4}, LU2/a;->g(Ljava/lang/String;)LU2/C;

    .line 17
    .line 18
    .line 19
    move-result-object v5

    .line 20
    invoke-virtual {v5}, LU2/C;->toCanonicalTagWithoutExtensions()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    invoke-static {v5, v1}, LU2/a;->a(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v5

    .line 28
    if-eqz v5, :cond_0

    .line 29
    .line 30
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    if-nez v5, :cond_0

    .line 35
    .line 36
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    new-array p0, p0, [Ljava/lang/String;

    .line 47
    .line 48
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    check-cast p0, [Ljava/lang/String;

    .line 53
    .line 54
    return-object p0
.end method

.method public static k(Ljava/util/List;Ljava/util/HashMap;Ljava/util/List;)Ljava/util/HashMap;
    .locals 8

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "localeMatcher"

    .line 7
    .line 8
    invoke-static {v1, p1}, LU2/a;->c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, Ljava/lang/String;

    .line 13
    .line 14
    const-string v2, "lookup"

    .line 15
    .line 16
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_2

    .line 21
    .line 22
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    new-array v1, v1, [Ljava/lang/String;

    .line 27
    .line 28
    invoke-interface {p0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    check-cast p0, [Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {}, LU2/a;->h()[Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    new-instance v2, Lp1/d;

    .line 39
    .line 40
    const/16 v3, 0xc

    .line 41
    .line 42
    invoke-direct {v2, v3}, Lp1/d;-><init>(I)V

    .line 43
    .line 44
    .line 45
    array-length v3, p0

    .line 46
    const/4 v4, 0x0

    .line 47
    :goto_0
    if-ge v4, v3, :cond_1

    .line 48
    .line 49
    aget-object v5, p0, v4

    .line 50
    .line 51
    invoke-static {v5}, LU2/a;->g(Ljava/lang/String;)LU2/C;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    invoke-virtual {v5}, LU2/C;->toCanonicalTagWithoutExtensions()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v6

    .line 59
    invoke-static {v6, v1}, LU2/a;->a(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v6

    .line 63
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    .line 64
    .line 65
    .line 66
    move-result v7

    .line 67
    if-nez v7, :cond_0

    .line 68
    .line 69
    invoke-static {v6}, LU2/a;->g(Ljava/lang/String;)LU2/C;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    iput-object p0, v2, Lp1/d;->b:Ljava/lang/Object;

    .line 74
    .line 75
    invoke-virtual {v5}, LU2/C;->getUnicodeExtensions()Ljava/util/HashMap;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    iput-object p0, v2, Lp1/d;->c:Ljava/lang/Object;

    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 83
    .line 84
    goto :goto_0

    .line 85
    :cond_1
    new-instance p0, LU2/C;

    .line 86
    .line 87
    sget-object v1, Landroid/icu/util/ULocale$Category;->FORMAT:Landroid/icu/util/ULocale$Category;

    .line 88
    .line 89
    invoke-static {v1}, Landroid/icu/util/ULocale;->getDefault(Landroid/icu/util/ULocale$Category;)Landroid/icu/util/ULocale;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    invoke-direct {p0, v1}, LU2/C;-><init>(Landroid/icu/util/ULocale;)V

    .line 94
    .line 95
    .line 96
    iput-object p0, v2, Lp1/d;->b:Ljava/lang/Object;

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_2
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    new-array v1, v1, [Ljava/lang/String;

    .line 104
    .line 105
    invoke-interface {p0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object p0

    .line 109
    check-cast p0, [Ljava/lang/String;

    .line 110
    .line 111
    invoke-static {p0}, LU2/a;->e([Ljava/lang/String;)Lp1/d;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    :goto_1
    new-instance p0, Ljava/util/HashSet;

    .line 116
    .line 117
    invoke-direct {p0}, Ljava/util/HashSet;-><init>()V

    .line 118
    .line 119
    .line 120
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 121
    .line 122
    .line 123
    move-result-object p2

    .line 124
    :goto_2
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 125
    .line 126
    .line 127
    move-result v1

    .line 128
    if-eqz v1, :cond_9

    .line 129
    .line 130
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    check-cast v1, Ljava/lang/String;

    .line 135
    .line 136
    sget-object v3, LU2/a;->f:LU2/z;

    .line 137
    .line 138
    iget-object v4, v2, Lp1/d;->c:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast v4, Ljava/util/HashMap;

    .line 141
    .line 142
    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    .line 143
    .line 144
    .line 145
    move-result v4

    .line 146
    if-nez v4, :cond_4

    .line 147
    .line 148
    iget-object v4, v2, Lp1/d;->c:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v4, Ljava/util/HashMap;

    .line 151
    .line 152
    invoke-virtual {v4, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result v4

    .line 156
    if-eqz v4, :cond_4

    .line 157
    .line 158
    iget-object v4, v2, Lp1/d;->c:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v4, Ljava/util/HashMap;

    .line 161
    .line 162
    invoke-virtual {v4, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v4

    .line 166
    check-cast v4, Ljava/lang/String;

    .line 167
    .line 168
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    .line 169
    .line 170
    .line 171
    move-result v5

    .line 172
    if-nez v5, :cond_3

    .line 173
    .line 174
    goto :goto_3

    .line 175
    :cond_3
    const-string/jumbo v4, "true"

    .line 176
    .line 177
    .line 178
    :goto_3
    invoke-virtual {p0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 179
    .line 180
    .line 181
    goto :goto_4

    .line 182
    :cond_4
    move-object v4, v3

    .line 183
    :goto_4
    invoke-interface {p1, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 184
    .line 185
    .line 186
    move-result v5

    .line 187
    if-eqz v5, :cond_6

    .line 188
    .line 189
    invoke-static {v1, p1}, LU2/a;->c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v5

    .line 193
    instance-of v6, v5, Ljava/lang/String;

    .line 194
    .line 195
    if-eqz v6, :cond_5

    .line 196
    .line 197
    move-object v6, v5

    .line 198
    check-cast v6, Ljava/lang/String;

    .line 199
    .line 200
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    .line 201
    .line 202
    .line 203
    move-result v6

    .line 204
    if-eqz v6, :cond_5

    .line 205
    .line 206
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 207
    .line 208
    :cond_5
    instance-of v6, v5, LU2/A;

    .line 209
    .line 210
    if-nez v6, :cond_6

    .line 211
    .line 212
    invoke-virtual {v5, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result v6

    .line 216
    if-nez v6, :cond_6

    .line 217
    .line 218
    invoke-virtual {p0, v1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 219
    .line 220
    .line 221
    move-object v4, v5

    .line 222
    :cond_6
    nop

    .line 223
    instance-of v5, v4, LU2/z;

    .line 224
    .line 225
    if-nez v5, :cond_7

    .line 226
    .line 227
    invoke-static {v4, v1}, LU2/E;->c(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v4

    .line 231
    :cond_7
    instance-of v5, v4, Ljava/lang/String;

    .line 232
    .line 233
    if-eqz v5, :cond_8

    .line 234
    .line 235
    move-object v5, v4

    .line 236
    check-cast v5, Ljava/lang/String;

    .line 237
    .line 238
    iget-object v6, v2, Lp1/d;->b:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v6, LU2/C;

    .line 241
    .line 242
    invoke-static {v1, v5, v6}, LU2/E;->a(Ljava/lang/String;Ljava/lang/String;LU2/C;)Z

    .line 243
    .line 244
    .line 245
    move-result v5

    .line 246
    if-nez v5, :cond_8

    .line 247
    .line 248
    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    goto :goto_2

    .line 252
    :cond_8
    invoke-virtual {v0, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    goto/16 :goto_2

    .line 256
    .line 257
    :cond_9
    invoke-virtual {p0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 258
    .line 259
    .line 260
    move-result-object p0

    .line 261
    :goto_5
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 262
    .line 263
    .line 264
    move-result p1

    .line 265
    if-eqz p1, :cond_b

    .line 266
    .line 267
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    move-result-object p1

    .line 271
    check-cast p1, Ljava/lang/String;

    .line 272
    .line 273
    new-instance p2, Ljava/util/ArrayList;

    .line 274
    .line 275
    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 276
    .line 277
    .line 278
    iget-object v1, v2, Lp1/d;->c:Ljava/lang/Object;

    .line 279
    .line 280
    check-cast v1, Ljava/util/HashMap;

    .line 281
    .line 282
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v1

    .line 286
    check-cast v1, Ljava/lang/String;

    .line 287
    .line 288
    invoke-static {v1, p1}, LU2/E;->c(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v1

    .line 292
    check-cast v1, Ljava/lang/String;

    .line 293
    .line 294
    if-eqz v1, :cond_a

    .line 295
    .line 296
    iget-object v3, v2, Lp1/d;->b:Ljava/lang/Object;

    .line 297
    .line 298
    check-cast v3, LU2/C;

    .line 299
    .line 300
    invoke-static {p1, v1, v3}, LU2/E;->a(Ljava/lang/String;Ljava/lang/String;LU2/C;)Z

    .line 301
    .line 302
    .line 303
    move-result v3

    .line 304
    if-nez v3, :cond_a

    .line 305
    .line 306
    goto :goto_5

    .line 307
    :cond_a
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 308
    .line 309
    .line 310
    iget-object v1, v2, Lp1/d;->b:Ljava/lang/Object;

    .line 311
    .line 312
    check-cast v1, LU2/C;

    .line 313
    .line 314
    invoke-virtual {v1, p1, p2}, LU2/C;->setUnicodeExtensions(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 315
    .line 316
    .line 317
    goto :goto_5

    .line 318
    :cond_b
    iget-object p0, v2, Lp1/d;->b:Ljava/lang/Object;

    .line 319
    .line 320
    check-cast p0, LU2/C;

    .line 321
    .line 322
    const-string p1, "locale"

    .line 323
    .line 324
    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    return-object v0
.end method

.method public static l(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/Enum;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    instance-of v1, p1, LU2/A;

    .line 3
    .line 4
    if-eqz v1, :cond_0

    .line 5
    .line 6
    const-string p1, "UNDEFINED"

    .line 7
    .line 8
    invoke-static {p0, p1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0

    .line 13
    :cond_0
    instance-of v1, p1, LU2/z;

    .line 14
    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    return-object v0

    .line 18
    :cond_1
    check-cast p1, Ljava/lang/String;

    .line 19
    .line 20
    const-string v1, "2-digit"

    .line 21
    .line 22
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    const-string p1, "DIGIT2"

    .line 29
    .line 30
    invoke-static {p0, p1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    return-object p0

    .line 35
    :cond_2
    invoke-virtual {p0}, Ljava/lang/Class;->getEnumConstants()[Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    check-cast p0, [Ljava/lang/Enum;

    .line 40
    .line 41
    array-length v1, p0

    .line 42
    const/4 v2, 0x0

    .line 43
    :goto_0
    if-ge v2, v1, :cond_4

    .line 44
    .line 45
    aget-object v3, p0, v2

    .line 46
    .line 47
    invoke-virtual {v3}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-virtual {v4, p1}, Ljava/lang/String;->compareToIgnoreCase(Ljava/lang/String;)I

    .line 52
    .line 53
    .line 54
    move-result v4
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 55
    if-nez v4, :cond_3

    .line 56
    .line 57
    return-object v3

    .line 58
    :cond_3
    add-int/lit8 v2, v2, 0x1

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :catch_0
    :cond_4
    return-object v0
.end method
