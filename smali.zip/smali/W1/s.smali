.class public final LW1/s;
.super LW1/a;
.source "SourceFile"


# static fields
.field public static final synthetic B:Lorg/aspectj/runtime/reflect/b;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lorg/aspectj/runtime/reflect/a;

    .line 2
    .line 3
    const-string v1, "SubtitleMediaHeaderBox.java"

    .line 4
    .line 5
    const-class v2, LW1/s;

    .line 6
    .line 7
    invoke-direct {v0, v2, v1}, Lorg/aspectj/runtime/reflect/a;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "com.coremedia.iso.boxes.SubtitleMediaHeaderBox"

    .line 11
    .line 12
    const-string v5, "java.lang.String"

    .line 13
    .line 14
    const-string/jumbo v1, "toString"

    .line 15
    .line 16
    .line 17
    const-string v3, ""

    .line 18
    .line 19
    const-string v4, ""

    .line 20
    .line 21
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const/16 v2, 0x1e

    .line 26
    .line 27
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    sput-object v0, LW1/s;->B:Lorg/aspectj/runtime/reflect/b;

    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public final c()J
    .locals 2

    .line 1
    const-wide/16 v0, 0x4

    .line 2
    .line 3
    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    .line 1
    sget-object v0, LW1/s;->B:Lorg/aspectj/runtime/reflect/b;

    .line 2
    .line 3
    invoke-static {v0, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 8
    .line 9
    .line 10
    const-string v0, "SubtitleMediaHeaderBox"

    .line 11
    .line 12
    return-object v0
.end method
