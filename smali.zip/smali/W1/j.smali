.class public final LW1/j;
.super LP4/c;
.source "SourceFile"


# static fields
.field public static final synthetic A0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic B0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic C0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic D0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic E0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic F0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic G0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic t0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic u0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic v0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic w0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic x0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic y0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic z0:Lorg/aspectj/runtime/reflect/b;


# instance fields
.field public B:Ljava/util/Date;

.field public C:Ljava/util/Date;

.field public H:J

.field public L:J

.field public M:D

.field public Q:F

.field public X:LT4/e;

.field public Y:J

.field public Z:I

.field public k0:I

.field public p0:I

.field public q0:I

.field public r0:I

.field public s0:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lorg/aspectj/runtime/reflect/a;

    .line 2
    .line 3
    const-string v1, "MovieHeaderBox.java"

    .line 4
    .line 5
    const-class v2, LW1/j;

    .line 6
    .line 7
    invoke-direct {v0, v2, v1}, Lorg/aspectj/runtime/reflect/a;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 11
    .line 12
    const-string v5, "java.util.Date"

    .line 13
    .line 14
    const-string v1, "getCreationTime"

    .line 15
    .line 16
    const-string v3, ""

    .line 17
    .line 18
    const-string v4, ""

    .line 19
    .line 20
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const/16 v2, 0x3f

    .line 25
    .line 26
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    sput-object v1, LW1/j;->t0:Lorg/aspectj/runtime/reflect/b;

    .line 31
    .line 32
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 33
    .line 34
    const-string v5, "java.util.Date"

    .line 35
    .line 36
    const-string v1, "getModificationTime"

    .line 37
    .line 38
    const-string v3, ""

    .line 39
    .line 40
    const-string v4, ""

    .line 41
    .line 42
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const/16 v2, 0x43

    .line 47
    .line 48
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sput-object v1, LW1/j;->u0:Lorg/aspectj/runtime/reflect/b;

    .line 53
    .line 54
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 55
    .line 56
    const-string/jumbo v5, "void"

    .line 57
    .line 58
    .line 59
    const-string/jumbo v1, "setModificationTime"

    .line 60
    .line 61
    .line 62
    const-string v3, "java.util.Date"

    .line 63
    .line 64
    const-string v4, "modificationTime"

    .line 65
    .line 66
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    const/16 v2, 0xcb

    .line 71
    .line 72
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    sput-object v1, LW1/j;->C0:Lorg/aspectj/runtime/reflect/b;

    .line 77
    .line 78
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 79
    .line 80
    const-string/jumbo v5, "void"

    .line 81
    .line 82
    .line 83
    const-string/jumbo v1, "setTimescale"

    .line 84
    .line 85
    .line 86
    const-string v3, "long"

    .line 87
    .line 88
    const-string/jumbo v4, "timescale"

    .line 89
    .line 90
    .line 91
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    const/16 v2, 0xd3

    .line 96
    .line 97
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    sput-object v1, LW1/j;->D0:Lorg/aspectj/runtime/reflect/b;

    .line 102
    .line 103
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 104
    .line 105
    const-string/jumbo v5, "void"

    .line 106
    .line 107
    .line 108
    const-string/jumbo v1, "setDuration"

    .line 109
    .line 110
    .line 111
    const-string v3, "long"

    .line 112
    .line 113
    const-string v4, "duration"

    .line 114
    .line 115
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    const/16 v2, 0xd7

    .line 120
    .line 121
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    sput-object v1, LW1/j;->E0:Lorg/aspectj/runtime/reflect/b;

    .line 126
    .line 127
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 128
    .line 129
    const-string/jumbo v5, "void"

    .line 130
    .line 131
    .line 132
    const-string/jumbo v1, "setRate"

    .line 133
    .line 134
    .line 135
    const-string v3, "double"

    .line 136
    .line 137
    const-string v4, "rate"

    .line 138
    .line 139
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    const/16 v2, 0xde

    .line 144
    .line 145
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 146
    .line 147
    .line 148
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 149
    .line 150
    const-string/jumbo v5, "void"

    .line 151
    .line 152
    .line 153
    const-string/jumbo v1, "setVolume"

    .line 154
    .line 155
    .line 156
    const-string v3, "float"

    .line 157
    .line 158
    const-string/jumbo v4, "volume"

    .line 159
    .line 160
    .line 161
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    const/16 v2, 0xe2

    .line 166
    .line 167
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 168
    .line 169
    .line 170
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 171
    .line 172
    const-string/jumbo v5, "void"

    .line 173
    .line 174
    .line 175
    const-string/jumbo v1, "setMatrix"

    .line 176
    .line 177
    .line 178
    const-string v3, "com.googlecode.mp4parser.util.Matrix"

    .line 179
    .line 180
    const-string v4, "matrix"

    .line 181
    .line 182
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 183
    .line 184
    .line 185
    move-result-object v1

    .line 186
    const/16 v2, 0xe6

    .line 187
    .line 188
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    sput-object v1, LW1/j;->F0:Lorg/aspectj/runtime/reflect/b;

    .line 193
    .line 194
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 195
    .line 196
    const-string/jumbo v5, "void"

    .line 197
    .line 198
    .line 199
    const-string/jumbo v1, "setNextTrackId"

    .line 200
    .line 201
    .line 202
    const-string v3, "long"

    .line 203
    .line 204
    const-string v4, "nextTrackId"

    .line 205
    .line 206
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 207
    .line 208
    .line 209
    move-result-object v1

    .line 210
    const/16 v2, 0xea

    .line 211
    .line 212
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    sput-object v1, LW1/j;->G0:Lorg/aspectj/runtime/reflect/b;

    .line 217
    .line 218
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 219
    .line 220
    const-string v5, "int"

    .line 221
    .line 222
    const-string v1, "getPreviewTime"

    .line 223
    .line 224
    const-string v3, ""

    .line 225
    .line 226
    const-string v4, ""

    .line 227
    .line 228
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    const/16 v2, 0xee

    .line 233
    .line 234
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 235
    .line 236
    .line 237
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 238
    .line 239
    const-string/jumbo v5, "void"

    .line 240
    .line 241
    .line 242
    const-string/jumbo v1, "setPreviewTime"

    .line 243
    .line 244
    .line 245
    const-string v3, "int"

    .line 246
    .line 247
    const-string v4, "previewTime"

    .line 248
    .line 249
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 250
    .line 251
    .line 252
    move-result-object v1

    .line 253
    const/16 v2, 0xf2

    .line 254
    .line 255
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 256
    .line 257
    .line 258
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 259
    .line 260
    const-string v5, "int"

    .line 261
    .line 262
    const-string v1, "getPreviewDuration"

    .line 263
    .line 264
    const-string v3, ""

    .line 265
    .line 266
    const-string v4, ""

    .line 267
    .line 268
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 269
    .line 270
    .line 271
    move-result-object v1

    .line 272
    const/16 v2, 0xf6

    .line 273
    .line 274
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 275
    .line 276
    .line 277
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 278
    .line 279
    const-string v5, "long"

    .line 280
    .line 281
    const-string v1, "getTimescale"

    .line 282
    .line 283
    const-string v3, ""

    .line 284
    .line 285
    const-string v4, ""

    .line 286
    .line 287
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 288
    .line 289
    .line 290
    move-result-object v1

    .line 291
    const/16 v2, 0x47

    .line 292
    .line 293
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 294
    .line 295
    .line 296
    move-result-object v1

    .line 297
    sput-object v1, LW1/j;->v0:Lorg/aspectj/runtime/reflect/b;

    .line 298
    .line 299
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 300
    .line 301
    const-string/jumbo v5, "void"

    .line 302
    .line 303
    .line 304
    const-string/jumbo v1, "setPreviewDuration"

    .line 305
    .line 306
    .line 307
    const-string v3, "int"

    .line 308
    .line 309
    const-string v4, "previewDuration"

    .line 310
    .line 311
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 312
    .line 313
    .line 314
    move-result-object v1

    .line 315
    const/16 v2, 0xfa

    .line 316
    .line 317
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 318
    .line 319
    .line 320
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 321
    .line 322
    const-string v5, "int"

    .line 323
    .line 324
    const-string v1, "getPosterTime"

    .line 325
    .line 326
    const-string v3, ""

    .line 327
    .line 328
    const-string v4, ""

    .line 329
    .line 330
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 331
    .line 332
    .line 333
    move-result-object v1

    .line 334
    const/16 v2, 0xfe

    .line 335
    .line 336
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 337
    .line 338
    .line 339
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 340
    .line 341
    const-string/jumbo v5, "void"

    .line 342
    .line 343
    .line 344
    const-string/jumbo v1, "setPosterTime"

    .line 345
    .line 346
    .line 347
    const-string v3, "int"

    .line 348
    .line 349
    const-string v4, "posterTime"

    .line 350
    .line 351
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 352
    .line 353
    .line 354
    move-result-object v1

    .line 355
    const/16 v2, 0x102

    .line 356
    .line 357
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 358
    .line 359
    .line 360
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 361
    .line 362
    const-string v5, "int"

    .line 363
    .line 364
    const-string v1, "getSelectionTime"

    .line 365
    .line 366
    const-string v3, ""

    .line 367
    .line 368
    const-string v4, ""

    .line 369
    .line 370
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 371
    .line 372
    .line 373
    move-result-object v1

    .line 374
    const/16 v2, 0x106

    .line 375
    .line 376
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 377
    .line 378
    .line 379
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 380
    .line 381
    const-string/jumbo v5, "void"

    .line 382
    .line 383
    .line 384
    const-string/jumbo v1, "setSelectionTime"

    .line 385
    .line 386
    .line 387
    const-string v3, "int"

    .line 388
    .line 389
    const-string/jumbo v4, "selectionTime"

    .line 390
    .line 391
    .line 392
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 393
    .line 394
    .line 395
    move-result-object v1

    .line 396
    const/16 v2, 0x10a

    .line 397
    .line 398
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 399
    .line 400
    .line 401
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 402
    .line 403
    const-string v5, "int"

    .line 404
    .line 405
    const-string v1, "getSelectionDuration"

    .line 406
    .line 407
    const-string v3, ""

    .line 408
    .line 409
    const-string v4, ""

    .line 410
    .line 411
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 412
    .line 413
    .line 414
    move-result-object v1

    .line 415
    const/16 v2, 0x10e

    .line 416
    .line 417
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 418
    .line 419
    .line 420
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 421
    .line 422
    const-string/jumbo v5, "void"

    .line 423
    .line 424
    .line 425
    const-string/jumbo v1, "setSelectionDuration"

    .line 426
    .line 427
    .line 428
    const-string v3, "int"

    .line 429
    .line 430
    const-string/jumbo v4, "selectionDuration"

    .line 431
    .line 432
    .line 433
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 434
    .line 435
    .line 436
    move-result-object v1

    .line 437
    const/16 v2, 0x112

    .line 438
    .line 439
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 440
    .line 441
    .line 442
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 443
    .line 444
    const-string v5, "int"

    .line 445
    .line 446
    const-string v1, "getCurrentTime"

    .line 447
    .line 448
    const-string v3, ""

    .line 449
    .line 450
    const-string v4, ""

    .line 451
    .line 452
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 453
    .line 454
    .line 455
    move-result-object v1

    .line 456
    const/16 v2, 0x116

    .line 457
    .line 458
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 459
    .line 460
    .line 461
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 462
    .line 463
    const-string/jumbo v5, "void"

    .line 464
    .line 465
    .line 466
    const-string/jumbo v1, "setCurrentTime"

    .line 467
    .line 468
    .line 469
    const-string v3, "int"

    .line 470
    .line 471
    const-string v4, "currentTime"

    .line 472
    .line 473
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 474
    .line 475
    .line 476
    move-result-object v1

    .line 477
    const/16 v2, 0x11a

    .line 478
    .line 479
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 480
    .line 481
    .line 482
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 483
    .line 484
    const-string v5, "long"

    .line 485
    .line 486
    const-string v1, "getDuration"

    .line 487
    .line 488
    const-string v3, ""

    .line 489
    .line 490
    const-string v4, ""

    .line 491
    .line 492
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 493
    .line 494
    .line 495
    move-result-object v1

    .line 496
    const/16 v2, 0x4b

    .line 497
    .line 498
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 499
    .line 500
    .line 501
    move-result-object v1

    .line 502
    sput-object v1, LW1/j;->w0:Lorg/aspectj/runtime/reflect/b;

    .line 503
    .line 504
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 505
    .line 506
    const-string v5, "double"

    .line 507
    .line 508
    const-string v1, "getRate"

    .line 509
    .line 510
    const-string v3, ""

    .line 511
    .line 512
    const-string v4, ""

    .line 513
    .line 514
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 515
    .line 516
    .line 517
    move-result-object v1

    .line 518
    const/16 v2, 0x4f

    .line 519
    .line 520
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 521
    .line 522
    .line 523
    move-result-object v1

    .line 524
    sput-object v1, LW1/j;->x0:Lorg/aspectj/runtime/reflect/b;

    .line 525
    .line 526
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 527
    .line 528
    const-string v5, "float"

    .line 529
    .line 530
    const-string v1, "getVolume"

    .line 531
    .line 532
    const-string v3, ""

    .line 533
    .line 534
    const-string v4, ""

    .line 535
    .line 536
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 537
    .line 538
    .line 539
    move-result-object v1

    .line 540
    const/16 v2, 0x53

    .line 541
    .line 542
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 543
    .line 544
    .line 545
    move-result-object v1

    .line 546
    sput-object v1, LW1/j;->y0:Lorg/aspectj/runtime/reflect/b;

    .line 547
    .line 548
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 549
    .line 550
    const-string v5, "com.googlecode.mp4parser.util.Matrix"

    .line 551
    .line 552
    const-string v1, "getMatrix"

    .line 553
    .line 554
    const-string v3, ""

    .line 555
    .line 556
    const-string v4, ""

    .line 557
    .line 558
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 559
    .line 560
    .line 561
    move-result-object v1

    .line 562
    const/16 v2, 0x57

    .line 563
    .line 564
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 565
    .line 566
    .line 567
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 568
    .line 569
    const-string v5, "long"

    .line 570
    .line 571
    const-string v1, "getNextTrackId"

    .line 572
    .line 573
    const-string v3, ""

    .line 574
    .line 575
    const-string v4, ""

    .line 576
    .line 577
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 578
    .line 579
    .line 580
    move-result-object v1

    .line 581
    const/16 v2, 0x5b

    .line 582
    .line 583
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 584
    .line 585
    .line 586
    move-result-object v1

    .line 587
    sput-object v1, LW1/j;->z0:Lorg/aspectj/runtime/reflect/b;

    .line 588
    .line 589
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 590
    .line 591
    const-string v5, "java.lang.String"

    .line 592
    .line 593
    const-string/jumbo v1, "toString"

    .line 594
    .line 595
    .line 596
    const-string v3, ""

    .line 597
    .line 598
    const-string v4, ""

    .line 599
    .line 600
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 601
    .line 602
    .line 603
    move-result-object v1

    .line 604
    const/16 v2, 0x8b

    .line 605
    .line 606
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 607
    .line 608
    .line 609
    move-result-object v1

    .line 610
    sput-object v1, LW1/j;->A0:Lorg/aspectj/runtime/reflect/b;

    .line 611
    .line 612
    const-string v2, "com.coremedia.iso.boxes.MovieHeaderBox"

    .line 613
    .line 614
    const-string/jumbo v5, "void"

    .line 615
    .line 616
    .line 617
    const-string/jumbo v1, "setCreationTime"

    .line 618
    .line 619
    .line 620
    const-string v3, "java.util.Date"

    .line 621
    .line 622
    const-string v4, "creationTime"

    .line 623
    .line 624
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 625
    .line 626
    .line 627
    move-result-object v1

    .line 628
    const/16 v2, 0xc3

    .line 629
    .line 630
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 631
    .line 632
    .line 633
    move-result-object v0

    .line 634
    sput-object v0, LW1/j;->B0:Lorg/aspectj/runtime/reflect/b;

    .line 635
    .line 636
    return-void
.end method


# virtual methods
.method public final a(Ljava/nio/ByteBuffer;)V
    .locals 2

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->h(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x1

    .line 9
    if-ne v0, v1, :cond_0

    .line 10
    .line 11
    invoke-static {p1}, LV1/a;->k(Ljava/nio/ByteBuffer;)J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, LW1/j;->B:Ljava/util/Date;

    .line 20
    .line 21
    invoke-static {p1}, LV1/a;->k(Ljava/nio/ByteBuffer;)J

    .line 22
    .line 23
    .line 24
    move-result-wide v0

    .line 25
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, LW1/j;->C:Ljava/util/Date;

    .line 30
    .line 31
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 32
    .line 33
    .line 34
    move-result-wide v0

    .line 35
    iput-wide v0, p0, LW1/j;->H:J

    .line 36
    .line 37
    invoke-static {p1}, LV1/a;->k(Ljava/nio/ByteBuffer;)J

    .line 38
    .line 39
    .line 40
    move-result-wide v0

    .line 41
    iput-wide v0, p0, LW1/j;->L:J

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_0
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 45
    .line 46
    .line 47
    move-result-wide v0

    .line 48
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iput-object v0, p0, LW1/j;->B:Ljava/util/Date;

    .line 53
    .line 54
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 55
    .line 56
    .line 57
    move-result-wide v0

    .line 58
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iput-object v0, p0, LW1/j;->C:Ljava/util/Date;

    .line 63
    .line 64
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 65
    .line 66
    .line 67
    move-result-wide v0

    .line 68
    iput-wide v0, p0, LW1/j;->H:J

    .line 69
    .line 70
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 71
    .line 72
    .line 73
    move-result-wide v0

    .line 74
    iput-wide v0, p0, LW1/j;->L:J

    .line 75
    .line 76
    :goto_0
    invoke-static {p1}, LV1/a;->f(Ljava/nio/ByteBuffer;)D

    .line 77
    .line 78
    .line 79
    move-result-wide v0

    .line 80
    iput-wide v0, p0, LW1/j;->M:D

    .line 81
    .line 82
    invoke-static {p1}, LV1/a;->g(Ljava/nio/ByteBuffer;)F

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    iput v0, p0, LW1/j;->Q:F

    .line 87
    .line 88
    invoke-static {p1}, LV1/a;->h(Ljava/nio/ByteBuffer;)I

    .line 89
    .line 90
    .line 91
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 92
    .line 93
    .line 94
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 95
    .line 96
    .line 97
    invoke-static {p1}, LT4/e;->a(Ljava/nio/ByteBuffer;)LT4/e;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    iput-object v0, p0, LW1/j;->X:LT4/e;

    .line 102
    .line 103
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getInt()I

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    iput v0, p0, LW1/j;->Z:I

    .line 108
    .line 109
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getInt()I

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    iput v0, p0, LW1/j;->k0:I

    .line 114
    .line 115
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getInt()I

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    iput v0, p0, LW1/j;->p0:I

    .line 120
    .line 121
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getInt()I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    iput v0, p0, LW1/j;->q0:I

    .line 126
    .line 127
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getInt()I

    .line 128
    .line 129
    .line 130
    move-result v0

    .line 131
    iput v0, p0, LW1/j;->r0:I

    .line 132
    .line 133
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getInt()I

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    iput v0, p0, LW1/j;->s0:I

    .line 138
    .line 139
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 140
    .line 141
    .line 142
    move-result-wide v0

    .line 143
    iput-wide v0, p0, LW1/j;->Y:J

    .line 144
    .line 145
    return-void
.end method

.method public final b(Ljava/nio/ByteBuffer;)V
    .locals 2

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->i(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x1

    .line 9
    if-ne v0, v1, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, LW1/j;->B:Ljava/util/Date;

    .line 12
    .line 13
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 14
    .line 15
    .line 16
    move-result-wide v0

    .line 17
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, LW1/j;->C:Ljava/util/Date;

    .line 21
    .line 22
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 27
    .line 28
    .line 29
    iget-wide v0, p0, LW1/j;->H:J

    .line 30
    .line 31
    long-to-int v0, v0

    .line 32
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 33
    .line 34
    .line 35
    iget-wide v0, p0, LW1/j;->L:J

    .line 36
    .line 37
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    iget-object v0, p0, LW1/j;->B:Ljava/util/Date;

    .line 42
    .line 43
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 44
    .line 45
    .line 46
    move-result-wide v0

    .line 47
    long-to-int v0, v0

    .line 48
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 49
    .line 50
    .line 51
    iget-object v0, p0, LW1/j;->C:Ljava/util/Date;

    .line 52
    .line 53
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 54
    .line 55
    .line 56
    move-result-wide v0

    .line 57
    long-to-int v0, v0

    .line 58
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 59
    .line 60
    .line 61
    iget-wide v0, p0, LW1/j;->H:J

    .line 62
    .line 63
    long-to-int v0, v0

    .line 64
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 65
    .line 66
    .line 67
    iget-wide v0, p0, LW1/j;->L:J

    .line 68
    .line 69
    long-to-int v0, v0

    .line 70
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 71
    .line 72
    .line 73
    :goto_0
    iget-wide v0, p0, LW1/j;->M:D

    .line 74
    .line 75
    invoke-static {p1, v0, v1}, LV1/a;->o(Ljava/nio/ByteBuffer;D)V

    .line 76
    .line 77
    .line 78
    iget v0, p0, LW1/j;->Q:F

    .line 79
    .line 80
    float-to-double v0, v0

    .line 81
    invoke-static {p1, v0, v1}, LV1/a;->p(Ljava/nio/ByteBuffer;D)V

    .line 82
    .line 83
    .line 84
    const/4 v0, 0x0

    .line 85
    invoke-static {v0, p1}, LV1/a;->q(ILjava/nio/ByteBuffer;)V

    .line 86
    .line 87
    .line 88
    const-wide/16 v0, 0x0

    .line 89
    .line 90
    long-to-int v0, v0

    .line 91
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 92
    .line 93
    .line 94
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 95
    .line 96
    .line 97
    iget-object v0, p0, LW1/j;->X:LT4/e;

    .line 98
    .line 99
    invoke-virtual {v0, p1}, LT4/e;->b(Ljava/nio/ByteBuffer;)V

    .line 100
    .line 101
    .line 102
    iget v0, p0, LW1/j;->Z:I

    .line 103
    .line 104
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 105
    .line 106
    .line 107
    iget v0, p0, LW1/j;->k0:I

    .line 108
    .line 109
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 110
    .line 111
    .line 112
    iget v0, p0, LW1/j;->p0:I

    .line 113
    .line 114
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 115
    .line 116
    .line 117
    iget v0, p0, LW1/j;->q0:I

    .line 118
    .line 119
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 120
    .line 121
    .line 122
    iget v0, p0, LW1/j;->r0:I

    .line 123
    .line 124
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 125
    .line 126
    .line 127
    iget v0, p0, LW1/j;->s0:I

    .line 128
    .line 129
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 130
    .line 131
    .line 132
    iget-wide v0, p0, LW1/j;->Y:J

    .line 133
    .line 134
    long-to-int v0, v0

    .line 135
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 136
    .line 137
    .line 138
    return-void
.end method

.method public final c()J
    .locals 4

    .line 1
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    const-wide/16 v0, 0x20

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const-wide/16 v0, 0x14

    .line 12
    .line 13
    :goto_0
    const-wide/16 v2, 0x50

    .line 14
    .line 15
    add-long/2addr v0, v2

    .line 16
    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    sget-object v0, LW1/j;->A0:Lorg/aspectj/runtime/reflect/b;

    .line 2
    .line 3
    invoke-static {v0, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {}, LP4/f;->a()LP4/f;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {v0}, LP4/f;->b(Lorg/aspectj/runtime/reflect/c;)V

    .line 15
    .line 16
    .line 17
    new-instance v0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v1, "MovieHeaderBox[creationTime="

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    sget-object v1, LW1/j;->t0:Lorg/aspectj/runtime/reflect/b;

    .line 25
    .line 26
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 31
    .line 32
    .line 33
    iget-object v1, p0, LW1/j;->B:Ljava/util/Date;

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    const-string v1, ";modificationTime="

    .line 39
    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    sget-object v1, LW1/j;->u0:Lorg/aspectj/runtime/reflect/b;

    .line 44
    .line 45
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, LW1/j;->C:Ljava/util/Date;

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string v1, ";timescale="

    .line 58
    .line 59
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    sget-object v1, LW1/j;->v0:Lorg/aspectj/runtime/reflect/b;

    .line 63
    .line 64
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 69
    .line 70
    .line 71
    iget-wide v1, p0, LW1/j;->H:J

    .line 72
    .line 73
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string v1, ";duration="

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    sget-object v1, LW1/j;->w0:Lorg/aspectj/runtime/reflect/b;

    .line 82
    .line 83
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 88
    .line 89
    .line 90
    iget-wide v1, p0, LW1/j;->L:J

    .line 91
    .line 92
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string v1, ";rate="

    .line 96
    .line 97
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    sget-object v1, LW1/j;->x0:Lorg/aspectj/runtime/reflect/b;

    .line 101
    .line 102
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 107
    .line 108
    .line 109
    iget-wide v1, p0, LW1/j;->M:D

    .line 110
    .line 111
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    const-string v1, ";volume="

    .line 115
    .line 116
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    .line 118
    .line 119
    sget-object v1, LW1/j;->y0:Lorg/aspectj/runtime/reflect/b;

    .line 120
    .line 121
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 126
    .line 127
    .line 128
    iget v1, p0, LW1/j;->Q:F

    .line 129
    .line 130
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    const-string v1, ";matrix="

    .line 134
    .line 135
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    iget-object v1, p0, LW1/j;->X:LT4/e;

    .line 139
    .line 140
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 141
    .line 142
    .line 143
    const-string v1, ";nextTrackId="

    .line 144
    .line 145
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    sget-object v1, LW1/j;->z0:Lorg/aspectj/runtime/reflect/b;

    .line 149
    .line 150
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 155
    .line 156
    .line 157
    iget-wide v1, p0, LW1/j;->Y:J

    .line 158
    .line 159
    const-string v3, "]"

    .line 160
    .line 161
    invoke-static {v0, v3, v1, v2}, LN8/q0;->n(Ljava/lang/StringBuilder;Ljava/lang/String;J)Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    return-object v0
.end method
