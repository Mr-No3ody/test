.class public final LW1/i;
.super LP4/c;
.source "SourceFile"


# static fields
.field public static final synthetic Q:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic X:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic Y:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic Z:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic k0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic p0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic q0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic r0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic s0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic t0:Lorg/aspectj/runtime/reflect/b;


# instance fields
.field public B:Ljava/util/Date;

.field public C:Ljava/util/Date;

.field public H:J

.field public L:J

.field public M:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lorg/aspectj/runtime/reflect/a;

    .line 2
    .line 3
    const-string v1, "MediaHeaderBox.java"

    .line 4
    .line 5
    const-class v2, LW1/i;

    .line 6
    .line 7
    invoke-direct {v0, v2, v1}, Lorg/aspectj/runtime/reflect/a;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 11
    .line 12
    const-string v5, "java.util.Date"

    .line 13
    .line 14
    const-string v1, "getCreationTime"

    .line 15
    .line 16
    const-string v3, ""

    .line 17
    .line 18
    const-string v4, ""

    .line 19
    .line 20
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const/16 v2, 0x2e

    .line 25
    .line 26
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    sput-object v1, LW1/i;->Q:Lorg/aspectj/runtime/reflect/b;

    .line 31
    .line 32
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 33
    .line 34
    const-string v5, "java.util.Date"

    .line 35
    .line 36
    const-string v1, "getModificationTime"

    .line 37
    .line 38
    const-string v3, ""

    .line 39
    .line 40
    const-string v4, ""

    .line 41
    .line 42
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const/16 v2, 0x32

    .line 47
    .line 48
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sput-object v1, LW1/i;->X:Lorg/aspectj/runtime/reflect/b;

    .line 53
    .line 54
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 55
    .line 56
    const-string v5, "java.lang.String"

    .line 57
    .line 58
    const-string/jumbo v1, "toString"

    .line 59
    .line 60
    .line 61
    const-string v3, ""

    .line 62
    .line 63
    const-string v4, ""

    .line 64
    .line 65
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    const/16 v2, 0x76

    .line 70
    .line 71
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    sput-object v1, LW1/i;->t0:Lorg/aspectj/runtime/reflect/b;

    .line 76
    .line 77
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 78
    .line 79
    const-string v5, "long"

    .line 80
    .line 81
    const-string v1, "getTimescale"

    .line 82
    .line 83
    const-string v3, ""

    .line 84
    .line 85
    const-string v4, ""

    .line 86
    .line 87
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    const/16 v2, 0x36

    .line 92
    .line 93
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    sput-object v1, LW1/i;->Y:Lorg/aspectj/runtime/reflect/b;

    .line 98
    .line 99
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 100
    .line 101
    const-string v5, "long"

    .line 102
    .line 103
    const-string v1, "getDuration"

    .line 104
    .line 105
    const-string v3, ""

    .line 106
    .line 107
    const-string v4, ""

    .line 108
    .line 109
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    const/16 v2, 0x3a

    .line 114
    .line 115
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    sput-object v1, LW1/i;->Z:Lorg/aspectj/runtime/reflect/b;

    .line 120
    .line 121
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 122
    .line 123
    const-string v5, "java.lang.String"

    .line 124
    .line 125
    const-string v1, "getLanguage"

    .line 126
    .line 127
    const-string v3, ""

    .line 128
    .line 129
    const-string v4, ""

    .line 130
    .line 131
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    const/16 v2, 0x3e

    .line 136
    .line 137
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    sput-object v1, LW1/i;->k0:Lorg/aspectj/runtime/reflect/b;

    .line 142
    .line 143
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 144
    .line 145
    const-string/jumbo v5, "void"

    .line 146
    .line 147
    .line 148
    const-string/jumbo v1, "setCreationTime"

    .line 149
    .line 150
    .line 151
    const-string v3, "java.util.Date"

    .line 152
    .line 153
    const-string v4, "creationTime"

    .line 154
    .line 155
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    const/16 v2, 0x4f

    .line 160
    .line 161
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    sput-object v1, LW1/i;->p0:Lorg/aspectj/runtime/reflect/b;

    .line 166
    .line 167
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 168
    .line 169
    const-string/jumbo v5, "void"

    .line 170
    .line 171
    .line 172
    const-string/jumbo v1, "setModificationTime"

    .line 173
    .line 174
    .line 175
    const-string v3, "java.util.Date"

    .line 176
    .line 177
    const-string v4, "modificationTime"

    .line 178
    .line 179
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 180
    .line 181
    .line 182
    move-result-object v1

    .line 183
    const/16 v2, 0x53

    .line 184
    .line 185
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 186
    .line 187
    .line 188
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 189
    .line 190
    const-string/jumbo v5, "void"

    .line 191
    .line 192
    .line 193
    const-string/jumbo v1, "setTimescale"

    .line 194
    .line 195
    .line 196
    const-string v3, "long"

    .line 197
    .line 198
    const-string/jumbo v4, "timescale"

    .line 199
    .line 200
    .line 201
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 202
    .line 203
    .line 204
    move-result-object v1

    .line 205
    const/16 v2, 0x57

    .line 206
    .line 207
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    sput-object v1, LW1/i;->q0:Lorg/aspectj/runtime/reflect/b;

    .line 212
    .line 213
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 214
    .line 215
    const-string/jumbo v5, "void"

    .line 216
    .line 217
    .line 218
    const-string/jumbo v1, "setDuration"

    .line 219
    .line 220
    .line 221
    const-string v3, "long"

    .line 222
    .line 223
    const-string v4, "duration"

    .line 224
    .line 225
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 226
    .line 227
    .line 228
    move-result-object v1

    .line 229
    const/16 v2, 0x5b

    .line 230
    .line 231
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 232
    .line 233
    .line 234
    move-result-object v1

    .line 235
    sput-object v1, LW1/i;->r0:Lorg/aspectj/runtime/reflect/b;

    .line 236
    .line 237
    const-string v2, "com.coremedia.iso.boxes.MediaHeaderBox"

    .line 238
    .line 239
    const-string/jumbo v5, "void"

    .line 240
    .line 241
    .line 242
    const-string/jumbo v1, "setLanguage"

    .line 243
    .line 244
    .line 245
    const-string v3, "java.lang.String"

    .line 246
    .line 247
    const-string v4, "language"

    .line 248
    .line 249
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 250
    .line 251
    .line 252
    move-result-object v1

    .line 253
    const/16 v2, 0x5f

    .line 254
    .line 255
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    sput-object v0, LW1/i;->s0:Lorg/aspectj/runtime/reflect/b;

    .line 260
    .line 261
    return-void
.end method


# virtual methods
.method public final a(Ljava/nio/ByteBuffer;)V
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->h(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x1

    .line 9
    if-ne v0, v1, :cond_0

    .line 10
    .line 11
    invoke-static {p1}, LV1/a;->k(Ljava/nio/ByteBuffer;)J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, LW1/i;->B:Ljava/util/Date;

    .line 20
    .line 21
    invoke-static {p1}, LV1/a;->k(Ljava/nio/ByteBuffer;)J

    .line 22
    .line 23
    .line 24
    move-result-wide v0

    .line 25
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, LW1/i;->C:Ljava/util/Date;

    .line 30
    .line 31
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 32
    .line 33
    .line 34
    move-result-wide v0

    .line 35
    iput-wide v0, p0, LW1/i;->H:J

    .line 36
    .line 37
    invoke-static {p1}, LV1/a;->k(Ljava/nio/ByteBuffer;)J

    .line 38
    .line 39
    .line 40
    move-result-wide v0

    .line 41
    iput-wide v0, p0, LW1/i;->L:J

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_0
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 45
    .line 46
    .line 47
    move-result-wide v0

    .line 48
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iput-object v0, p0, LW1/i;->B:Ljava/util/Date;

    .line 53
    .line 54
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 55
    .line 56
    .line 57
    move-result-wide v0

    .line 58
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iput-object v0, p0, LW1/i;->C:Ljava/util/Date;

    .line 63
    .line 64
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 65
    .line 66
    .line 67
    move-result-wide v0

    .line 68
    iput-wide v0, p0, LW1/i;->H:J

    .line 69
    .line 70
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 71
    .line 72
    .line 73
    move-result-wide v0

    .line 74
    iput-wide v0, p0, LW1/i;->L:J

    .line 75
    .line 76
    :goto_0
    invoke-static {p1}, LV1/a;->h(Ljava/nio/ByteBuffer;)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    new-instance v1, Ljava/lang/StringBuilder;

    .line 81
    .line 82
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 83
    .line 84
    .line 85
    const/4 v2, 0x0

    .line 86
    :goto_1
    const/4 v3, 0x3

    .line 87
    if-lt v2, v3, :cond_1

    .line 88
    .line 89
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    iput-object v0, p0, LW1/i;->M:Ljava/lang/String;

    .line 94
    .line 95
    invoke-static {p1}, LV1/a;->h(Ljava/nio/ByteBuffer;)I

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :cond_1
    rsub-int/lit8 v3, v2, 0x2

    .line 100
    .line 101
    mul-int/lit8 v3, v3, 0x5

    .line 102
    .line 103
    shr-int v3, v0, v3

    .line 104
    .line 105
    and-int/lit8 v3, v3, 0x1f

    .line 106
    .line 107
    add-int/lit8 v3, v3, 0x60

    .line 108
    .line 109
    int-to-char v3, v3

    .line 110
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    add-int/lit8 v2, v2, 0x1

    .line 114
    .line 115
    goto :goto_1
.end method

.method public final b(Ljava/nio/ByteBuffer;)V
    .locals 7

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->i(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x1

    .line 9
    if-ne v0, v1, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, LW1/i;->B:Ljava/util/Date;

    .line 12
    .line 13
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 14
    .line 15
    .line 16
    move-result-wide v0

    .line 17
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, LW1/i;->C:Ljava/util/Date;

    .line 21
    .line 22
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 27
    .line 28
    .line 29
    iget-wide v0, p0, LW1/i;->H:J

    .line 30
    .line 31
    long-to-int v0, v0

    .line 32
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 33
    .line 34
    .line 35
    iget-wide v0, p0, LW1/i;->L:J

    .line 36
    .line 37
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    iget-object v0, p0, LW1/i;->B:Ljava/util/Date;

    .line 42
    .line 43
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 44
    .line 45
    .line 46
    move-result-wide v0

    .line 47
    long-to-int v0, v0

    .line 48
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 49
    .line 50
    .line 51
    iget-object v0, p0, LW1/i;->C:Ljava/util/Date;

    .line 52
    .line 53
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 54
    .line 55
    .line 56
    move-result-wide v0

    .line 57
    long-to-int v0, v0

    .line 58
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 59
    .line 60
    .line 61
    iget-wide v0, p0, LW1/i;->H:J

    .line 62
    .line 63
    long-to-int v0, v0

    .line 64
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 65
    .line 66
    .line 67
    iget-wide v0, p0, LW1/i;->L:J

    .line 68
    .line 69
    long-to-int v0, v0

    .line 70
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 71
    .line 72
    .line 73
    :goto_0
    iget-object v0, p0, LW1/i;->M:Ljava/lang/String;

    .line 74
    .line 75
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    array-length v1, v1

    .line 80
    const/4 v2, 0x3

    .line 81
    if-ne v1, v2, :cond_2

    .line 82
    .line 83
    const/4 v1, 0x0

    .line 84
    move v3, v1

    .line 85
    move v4, v3

    .line 86
    :goto_1
    if-lt v3, v2, :cond_1

    .line 87
    .line 88
    invoke-static {v4, p1}, LV1/a;->q(ILjava/nio/ByteBuffer;)V

    .line 89
    .line 90
    .line 91
    invoke-static {v1, p1}, LV1/a;->q(ILjava/nio/ByteBuffer;)V

    .line 92
    .line 93
    .line 94
    return-void

    .line 95
    :cond_1
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    .line 96
    .line 97
    .line 98
    move-result-object v5

    .line 99
    aget-byte v5, v5, v3

    .line 100
    .line 101
    add-int/lit8 v5, v5, -0x60

    .line 102
    .line 103
    rsub-int/lit8 v6, v3, 0x2

    .line 104
    .line 105
    mul-int/lit8 v6, v6, 0x5

    .line 106
    .line 107
    shl-int/2addr v5, v6

    .line 108
    add-int/2addr v4, v5

    .line 109
    add-int/lit8 v3, v3, 0x1

    .line 110
    .line 111
    goto :goto_1

    .line 112
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 113
    .line 114
    const-string v1, "\""

    .line 115
    .line 116
    const-string v2, "\" language string isn\'t exactly 3 characters long!"

    .line 117
    .line 118
    invoke-static {v1, v0, v2}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    throw p1
.end method

.method public final c()J
    .locals 4

    .line 1
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    const-wide/16 v0, 0x20

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const-wide/16 v0, 0x14

    .line 12
    .line 13
    :goto_0
    const-wide/16 v2, 0x4

    .line 14
    .line 15
    add-long/2addr v0, v2

    .line 16
    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    sget-object v0, LW1/i;->t0:Lorg/aspectj/runtime/reflect/b;

    .line 2
    .line 3
    invoke-static {v0, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {}, LP4/f;->a()LP4/f;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {v0}, LP4/f;->b(Lorg/aspectj/runtime/reflect/c;)V

    .line 15
    .line 16
    .line 17
    new-instance v0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v1, "MediaHeaderBox[creationTime="

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    sget-object v1, LW1/i;->Q:Lorg/aspectj/runtime/reflect/b;

    .line 25
    .line 26
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 31
    .line 32
    .line 33
    iget-object v1, p0, LW1/i;->B:Ljava/util/Date;

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    const-string v1, ";modificationTime="

    .line 39
    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    sget-object v1, LW1/i;->X:Lorg/aspectj/runtime/reflect/b;

    .line 44
    .line 45
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, LW1/i;->C:Ljava/util/Date;

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string v1, ";timescale="

    .line 58
    .line 59
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    sget-object v1, LW1/i;->Y:Lorg/aspectj/runtime/reflect/b;

    .line 63
    .line 64
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 69
    .line 70
    .line 71
    iget-wide v1, p0, LW1/i;->H:J

    .line 72
    .line 73
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string v1, ";duration="

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    sget-object v1, LW1/i;->Z:Lorg/aspectj/runtime/reflect/b;

    .line 82
    .line 83
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 88
    .line 89
    .line 90
    iget-wide v1, p0, LW1/i;->L:J

    .line 91
    .line 92
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string v1, ";language="

    .line 96
    .line 97
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    sget-object v1, LW1/i;->k0:Lorg/aspectj/runtime/reflect/b;

    .line 101
    .line 102
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 107
    .line 108
    .line 109
    iget-object v1, p0, LW1/i;->M:Ljava/lang/String;

    .line 110
    .line 111
    const-string v2, "]"

    .line 112
    .line 113
    invoke-static {v0, v1, v2}, LC0/G;->r(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    return-object v0
.end method
