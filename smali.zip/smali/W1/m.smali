.class public final LW1/m;
.super LP4/c;
.source "SourceFile"


# static fields
.field public static final synthetic L:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic M:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic Q:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic X:Lorg/aspectj/runtime/reflect/b;


# instance fields
.field public B:J

.field public C:[J

.field public H:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lorg/aspectj/runtime/reflect/a;

    .line 2
    .line 3
    const-string v1, "SampleSizeBox.java"

    .line 4
    .line 5
    const-class v2, LW1/m;

    .line 6
    .line 7
    invoke-direct {v0, v2, v1}, Lorg/aspectj/runtime/reflect/a;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "com.coremedia.iso.boxes.SampleSizeBox"

    .line 11
    .line 12
    const-string v5, "long"

    .line 13
    .line 14
    const-string v1, "getSampleSize"

    .line 15
    .line 16
    const-string v3, ""

    .line 17
    .line 18
    const-string v4, ""

    .line 19
    .line 20
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const/16 v2, 0x32

    .line 25
    .line 26
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    sput-object v1, LW1/m;->L:Lorg/aspectj/runtime/reflect/b;

    .line 31
    .line 32
    const-string v2, "com.coremedia.iso.boxes.SampleSizeBox"

    .line 33
    .line 34
    const-string/jumbo v5, "void"

    .line 35
    .line 36
    .line 37
    const-string/jumbo v1, "setSampleSize"

    .line 38
    .line 39
    .line 40
    const-string v3, "long"

    .line 41
    .line 42
    const-string/jumbo v4, "sampleSize"

    .line 43
    .line 44
    .line 45
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    const/16 v2, 0x36

    .line 50
    .line 51
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 52
    .line 53
    .line 54
    const-string v2, "com.coremedia.iso.boxes.SampleSizeBox"

    .line 55
    .line 56
    const-string v5, "long"

    .line 57
    .line 58
    const-string v1, "getSampleSizeAtIndex"

    .line 59
    .line 60
    const-string v3, "int"

    .line 61
    .line 62
    const-string v4, "index"

    .line 63
    .line 64
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    const/16 v2, 0x3b

    .line 69
    .line 70
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 71
    .line 72
    .line 73
    const-string v2, "com.coremedia.iso.boxes.SampleSizeBox"

    .line 74
    .line 75
    const-string v5, "long"

    .line 76
    .line 77
    const-string v1, "getSampleCount"

    .line 78
    .line 79
    const-string v3, ""

    .line 80
    .line 81
    const-string v4, ""

    .line 82
    .line 83
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    const/16 v2, 0x43

    .line 88
    .line 89
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    sput-object v1, LW1/m;->M:Lorg/aspectj/runtime/reflect/b;

    .line 94
    .line 95
    const-string v2, "com.coremedia.iso.boxes.SampleSizeBox"

    .line 96
    .line 97
    const-string v5, "[J"

    .line 98
    .line 99
    const-string v1, "getSampleSizes"

    .line 100
    .line 101
    const-string v3, ""

    .line 102
    .line 103
    const-string v4, ""

    .line 104
    .line 105
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    const/16 v2, 0x4c

    .line 110
    .line 111
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 112
    .line 113
    .line 114
    const-string v2, "com.coremedia.iso.boxes.SampleSizeBox"

    .line 115
    .line 116
    const-string/jumbo v5, "void"

    .line 117
    .line 118
    .line 119
    const-string/jumbo v1, "setSampleSizes"

    .line 120
    .line 121
    .line 122
    const-string v3, "[J"

    .line 123
    .line 124
    const-string/jumbo v4, "sampleSizes"

    .line 125
    .line 126
    .line 127
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    const/16 v2, 0x50

    .line 132
    .line 133
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    sput-object v1, LW1/m;->Q:Lorg/aspectj/runtime/reflect/b;

    .line 138
    .line 139
    const-string v2, "com.coremedia.iso.boxes.SampleSizeBox"

    .line 140
    .line 141
    const-string v5, "java.lang.String"

    .line 142
    .line 143
    const-string/jumbo v1, "toString"

    .line 144
    .line 145
    .line 146
    const-string v3, ""

    .line 147
    .line 148
    const-string v4, ""

    .line 149
    .line 150
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    const/16 v2, 0x77

    .line 155
    .line 156
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    sput-object v0, LW1/m;->X:Lorg/aspectj/runtime/reflect/b;

    .line 161
    .line 162
    return-void
.end method


# virtual methods
.method public final a(Ljava/nio/ByteBuffer;)V
    .locals 5

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->h(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    iput-wide v0, p0, LW1/m;->B:J

    .line 9
    .line 10
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    invoke-static {v0, v1}, Lj8/f;->r(J)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    iput v0, p0, LW1/m;->H:I

    .line 19
    .line 20
    iget-wide v1, p0, LW1/m;->B:J

    .line 21
    .line 22
    const-wide/16 v3, 0x0

    .line 23
    .line 24
    cmp-long v1, v1, v3

    .line 25
    .line 26
    if-nez v1, :cond_1

    .line 27
    .line 28
    new-array v0, v0, [J

    .line 29
    .line 30
    iput-object v0, p0, LW1/m;->C:[J

    .line 31
    .line 32
    const/4 v0, 0x0

    .line 33
    :goto_0
    iget v1, p0, LW1/m;->H:I

    .line 34
    .line 35
    if-lt v0, v1, :cond_0

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_0
    iget-object v1, p0, LW1/m;->C:[J

    .line 39
    .line 40
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 41
    .line 42
    .line 43
    move-result-wide v2

    .line 44
    aput-wide v2, v1, v0

    .line 45
    .line 46
    add-int/lit8 v0, v0, 0x1

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_1
    :goto_1
    return-void
.end method

.method public final b(Ljava/nio/ByteBuffer;)V
    .locals 5

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->i(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    iget-wide v0, p0, LW1/m;->B:J

    .line 5
    .line 6
    long-to-int v0, v0

    .line 7
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 8
    .line 9
    .line 10
    iget-wide v0, p0, LW1/m;->B:J

    .line 11
    .line 12
    const-wide/16 v2, 0x0

    .line 13
    .line 14
    cmp-long v0, v0, v2

    .line 15
    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    iget-object v0, p0, LW1/m;->C:[J

    .line 19
    .line 20
    array-length v0, v0

    .line 21
    int-to-long v0, v0

    .line 22
    long-to-int v0, v0

    .line 23
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, LW1/m;->C:[J

    .line 27
    .line 28
    array-length v1, v0

    .line 29
    const/4 v2, 0x0

    .line 30
    :goto_0
    if-lt v2, v1, :cond_0

    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    aget-wide v3, v0, v2

    .line 34
    .line 35
    long-to-int v3, v3

    .line 36
    invoke-virtual {p1, v3}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 37
    .line 38
    .line 39
    add-int/lit8 v2, v2, 0x1

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_1
    iget v0, p0, LW1/m;->H:I

    .line 43
    .line 44
    int-to-long v0, v0

    .line 45
    long-to-int v0, v0

    .line 46
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 47
    .line 48
    .line 49
    return-void
.end method

.method public final c()J
    .locals 4

    .line 1
    iget-wide v0, p0, LW1/m;->B:J

    .line 2
    .line 3
    const-wide/16 v2, 0x0

    .line 4
    .line 5
    cmp-long v0, v0, v2

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, LW1/m;->C:[J

    .line 10
    .line 11
    array-length v0, v0

    .line 12
    mul-int/lit8 v0, v0, 0x4

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    :goto_0
    add-int/lit8 v0, v0, 0xc

    .line 17
    .line 18
    int-to-long v0, v0

    .line 19
    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 5

    .line 1
    sget-object v0, LW1/m;->X:Lorg/aspectj/runtime/reflect/b;

    .line 2
    .line 3
    invoke-static {v0, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {}, LP4/f;->a()LP4/f;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {v0}, LP4/f;->b(Lorg/aspectj/runtime/reflect/c;)V

    .line 15
    .line 16
    .line 17
    new-instance v0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v1, "SampleSizeBox[sampleSize="

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    sget-object v1, LW1/m;->L:Lorg/aspectj/runtime/reflect/b;

    .line 25
    .line 26
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 31
    .line 32
    .line 33
    iget-wide v1, p0, LW1/m;->B:J

    .line 34
    .line 35
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    const-string v1, ";sampleCount="

    .line 39
    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    sget-object v1, LW1/m;->M:Lorg/aspectj/runtime/reflect/b;

    .line 44
    .line 45
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 50
    .line 51
    .line 52
    iget-wide v1, p0, LW1/m;->B:J

    .line 53
    .line 54
    const-wide/16 v3, 0x0

    .line 55
    .line 56
    cmp-long v1, v1, v3

    .line 57
    .line 58
    if-lez v1, :cond_0

    .line 59
    .line 60
    iget v1, p0, LW1/m;->H:I

    .line 61
    .line 62
    :goto_0
    int-to-long v1, v1

    .line 63
    goto :goto_1

    .line 64
    :cond_0
    iget-object v1, p0, LW1/m;->C:[J

    .line 65
    .line 66
    array-length v1, v1

    .line 67
    goto :goto_0

    .line 68
    :goto_1
    const-string v3, "]"

    .line 69
    .line 70
    invoke-static {v0, v3, v1, v2}, LN8/q0;->n(Ljava/lang/StringBuilder;Ljava/lang/String;J)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    return-object v0
.end method
