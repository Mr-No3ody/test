.class public abstract LW1/a;
.super LP4/c;
.source "SourceFile"
