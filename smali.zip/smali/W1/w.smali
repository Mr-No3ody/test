.class public final LW1/w;
.super LP4/c;
.source "SourceFile"


# static fields
.field public static final synthetic A0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic B0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic C0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic D0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic E0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic F0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic G0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic H0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic I0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic J0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic K0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic L0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic M0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic p0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic q0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic r0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic s0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic t0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic u0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic v0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic w0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic x0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic y0:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic z0:Lorg/aspectj/runtime/reflect/b;


# instance fields
.field public B:Ljava/util/Date;

.field public C:Ljava/util/Date;

.field public H:J

.field public L:J

.field public M:I

.field public Q:I

.field public X:F

.field public Y:LT4/e;

.field public Z:D

.field public k0:D


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lorg/aspectj/runtime/reflect/a;

    .line 2
    .line 3
    const-string v1, "TrackHeaderBox.java"

    .line 4
    .line 5
    const-class v2, LW1/w;

    .line 6
    .line 7
    invoke-direct {v0, v2, v1}, Lorg/aspectj/runtime/reflect/a;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 11
    .line 12
    const-string v5, "java.util.Date"

    .line 13
    .line 14
    const-string v1, "getCreationTime"

    .line 15
    .line 16
    const-string v3, ""

    .line 17
    .line 18
    const-string v4, ""

    .line 19
    .line 20
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const/16 v2, 0x3c

    .line 25
    .line 26
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    sput-object v1, LW1/w;->p0:Lorg/aspectj/runtime/reflect/b;

    .line 31
    .line 32
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 33
    .line 34
    const-string v5, "java.util.Date"

    .line 35
    .line 36
    const-string v1, "getModificationTime"

    .line 37
    .line 38
    const-string v3, ""

    .line 39
    .line 40
    const-string v4, ""

    .line 41
    .line 42
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const/16 v2, 0x40

    .line 47
    .line 48
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sput-object v1, LW1/w;->q0:Lorg/aspectj/runtime/reflect/b;

    .line 53
    .line 54
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 55
    .line 56
    const-string/jumbo v5, "void"

    .line 57
    .line 58
    .line 59
    const-string v1, "getContent"

    .line 60
    .line 61
    const-string v3, "java.nio.ByteBuffer"

    .line 62
    .line 63
    const-string v4, "byteBuffer"

    .line 64
    .line 65
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    const/16 v2, 0x8e

    .line 70
    .line 71
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    sput-object v1, LW1/w;->y0:Lorg/aspectj/runtime/reflect/b;

    .line 76
    .line 77
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 78
    .line 79
    const-string v5, "java.lang.String"

    .line 80
    .line 81
    const-string/jumbo v1, "toString"

    .line 82
    .line 83
    .line 84
    const-string v3, ""

    .line 85
    .line 86
    const-string v4, ""

    .line 87
    .line 88
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    const/16 v2, 0xaa

    .line 93
    .line 94
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    sput-object v1, LW1/w;->z0:Lorg/aspectj/runtime/reflect/b;

    .line 99
    .line 100
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 101
    .line 102
    const-string/jumbo v5, "void"

    .line 103
    .line 104
    .line 105
    const-string/jumbo v1, "setCreationTime"

    .line 106
    .line 107
    .line 108
    const-string v3, "java.util.Date"

    .line 109
    .line 110
    const-string v4, "creationTime"

    .line 111
    .line 112
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    const/16 v2, 0xc4

    .line 117
    .line 118
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    sput-object v1, LW1/w;->A0:Lorg/aspectj/runtime/reflect/b;

    .line 123
    .line 124
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 125
    .line 126
    const-string/jumbo v5, "void"

    .line 127
    .line 128
    .line 129
    const-string/jumbo v1, "setModificationTime"

    .line 130
    .line 131
    .line 132
    const-string v3, "java.util.Date"

    .line 133
    .line 134
    const-string v4, "modificationTime"

    .line 135
    .line 136
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    const/16 v2, 0xcb

    .line 141
    .line 142
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    sput-object v1, LW1/w;->B0:Lorg/aspectj/runtime/reflect/b;

    .line 147
    .line 148
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 149
    .line 150
    const-string/jumbo v5, "void"

    .line 151
    .line 152
    .line 153
    const-string/jumbo v1, "setTrackId"

    .line 154
    .line 155
    .line 156
    const-string v3, "long"

    .line 157
    .line 158
    const-string/jumbo v4, "trackId"

    .line 159
    .line 160
    .line 161
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    const/16 v2, 0xd3

    .line 166
    .line 167
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    sput-object v1, LW1/w;->C0:Lorg/aspectj/runtime/reflect/b;

    .line 172
    .line 173
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 174
    .line 175
    const-string/jumbo v5, "void"

    .line 176
    .line 177
    .line 178
    const-string/jumbo v1, "setDuration"

    .line 179
    .line 180
    .line 181
    const-string v3, "long"

    .line 182
    .line 183
    const-string v4, "duration"

    .line 184
    .line 185
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 186
    .line 187
    .line 188
    move-result-object v1

    .line 189
    const/16 v2, 0xd7

    .line 190
    .line 191
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    sput-object v1, LW1/w;->D0:Lorg/aspectj/runtime/reflect/b;

    .line 196
    .line 197
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 198
    .line 199
    const-string/jumbo v5, "void"

    .line 200
    .line 201
    .line 202
    const-string/jumbo v1, "setLayer"

    .line 203
    .line 204
    .line 205
    const-string v3, "int"

    .line 206
    .line 207
    const-string v4, "layer"

    .line 208
    .line 209
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 210
    .line 211
    .line 212
    move-result-object v1

    .line 213
    const/16 v2, 0xde

    .line 214
    .line 215
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    sput-object v1, LW1/w;->E0:Lorg/aspectj/runtime/reflect/b;

    .line 220
    .line 221
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 222
    .line 223
    const-string/jumbo v5, "void"

    .line 224
    .line 225
    .line 226
    const-string/jumbo v1, "setAlternateGroup"

    .line 227
    .line 228
    .line 229
    const-string v3, "int"

    .line 230
    .line 231
    const-string v4, "alternateGroup"

    .line 232
    .line 233
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 234
    .line 235
    .line 236
    move-result-object v1

    .line 237
    const/16 v2, 0xe2

    .line 238
    .line 239
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 240
    .line 241
    .line 242
    move-result-object v1

    .line 243
    sput-object v1, LW1/w;->F0:Lorg/aspectj/runtime/reflect/b;

    .line 244
    .line 245
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 246
    .line 247
    const-string/jumbo v5, "void"

    .line 248
    .line 249
    .line 250
    const-string/jumbo v1, "setVolume"

    .line 251
    .line 252
    .line 253
    const-string v3, "float"

    .line 254
    .line 255
    const-string/jumbo v4, "volume"

    .line 256
    .line 257
    .line 258
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 259
    .line 260
    .line 261
    move-result-object v1

    .line 262
    const/16 v2, 0xe6

    .line 263
    .line 264
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 265
    .line 266
    .line 267
    move-result-object v1

    .line 268
    sput-object v1, LW1/w;->G0:Lorg/aspectj/runtime/reflect/b;

    .line 269
    .line 270
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 271
    .line 272
    const-string/jumbo v5, "void"

    .line 273
    .line 274
    .line 275
    const-string/jumbo v1, "setMatrix"

    .line 276
    .line 277
    .line 278
    const-string v3, "com.googlecode.mp4parser.util.Matrix"

    .line 279
    .line 280
    const-string v4, "matrix"

    .line 281
    .line 282
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 283
    .line 284
    .line 285
    move-result-object v1

    .line 286
    const/16 v2, 0xea

    .line 287
    .line 288
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 289
    .line 290
    .line 291
    move-result-object v1

    .line 292
    sput-object v1, LW1/w;->H0:Lorg/aspectj/runtime/reflect/b;

    .line 293
    .line 294
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 295
    .line 296
    const-string v5, "long"

    .line 297
    .line 298
    const-string v1, "getTrackId"

    .line 299
    .line 300
    const-string v3, ""

    .line 301
    .line 302
    const-string v4, ""

    .line 303
    .line 304
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 305
    .line 306
    .line 307
    move-result-object v1

    .line 308
    const/16 v2, 0x44

    .line 309
    .line 310
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 311
    .line 312
    .line 313
    move-result-object v1

    .line 314
    sput-object v1, LW1/w;->r0:Lorg/aspectj/runtime/reflect/b;

    .line 315
    .line 316
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 317
    .line 318
    const-string/jumbo v5, "void"

    .line 319
    .line 320
    .line 321
    const-string/jumbo v1, "setWidth"

    .line 322
    .line 323
    .line 324
    const-string v3, "double"

    .line 325
    .line 326
    const-string/jumbo v4, "width"

    .line 327
    .line 328
    .line 329
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 330
    .line 331
    .line 332
    move-result-object v1

    .line 333
    const/16 v2, 0xee

    .line 334
    .line 335
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 336
    .line 337
    .line 338
    move-result-object v1

    .line 339
    sput-object v1, LW1/w;->I0:Lorg/aspectj/runtime/reflect/b;

    .line 340
    .line 341
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 342
    .line 343
    const-string/jumbo v5, "void"

    .line 344
    .line 345
    .line 346
    const-string/jumbo v1, "setHeight"

    .line 347
    .line 348
    .line 349
    const-string v3, "double"

    .line 350
    .line 351
    const-string v4, "height"

    .line 352
    .line 353
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 354
    .line 355
    .line 356
    move-result-object v1

    .line 357
    const/16 v2, 0xf2

    .line 358
    .line 359
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 360
    .line 361
    .line 362
    move-result-object v1

    .line 363
    sput-object v1, LW1/w;->J0:Lorg/aspectj/runtime/reflect/b;

    .line 364
    .line 365
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 366
    .line 367
    const-string v5, "boolean"

    .line 368
    .line 369
    const-string v1, "isEnabled"

    .line 370
    .line 371
    const-string v3, ""

    .line 372
    .line 373
    const-string v4, ""

    .line 374
    .line 375
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 376
    .line 377
    .line 378
    move-result-object v1

    .line 379
    const/16 v2, 0xf7

    .line 380
    .line 381
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 382
    .line 383
    .line 384
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 385
    .line 386
    const-string v5, "boolean"

    .line 387
    .line 388
    const-string v1, "isInMovie"

    .line 389
    .line 390
    const-string v3, ""

    .line 391
    .line 392
    const-string v4, ""

    .line 393
    .line 394
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 395
    .line 396
    .line 397
    move-result-object v1

    .line 398
    const/16 v2, 0xfb

    .line 399
    .line 400
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 401
    .line 402
    .line 403
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 404
    .line 405
    const-string v5, "boolean"

    .line 406
    .line 407
    const-string v1, "isInPreview"

    .line 408
    .line 409
    const-string v3, ""

    .line 410
    .line 411
    const-string v4, ""

    .line 412
    .line 413
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 414
    .line 415
    .line 416
    move-result-object v1

    .line 417
    const/16 v2, 0xff

    .line 418
    .line 419
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 420
    .line 421
    .line 422
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 423
    .line 424
    const-string v5, "boolean"

    .line 425
    .line 426
    const-string v1, "isInPoster"

    .line 427
    .line 428
    const-string v3, ""

    .line 429
    .line 430
    const-string v4, ""

    .line 431
    .line 432
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 433
    .line 434
    .line 435
    move-result-object v1

    .line 436
    const/16 v2, 0x103

    .line 437
    .line 438
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 439
    .line 440
    .line 441
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 442
    .line 443
    const-string/jumbo v5, "void"

    .line 444
    .line 445
    .line 446
    const-string/jumbo v1, "setEnabled"

    .line 447
    .line 448
    .line 449
    const-string v3, "boolean"

    .line 450
    .line 451
    const-string v4, "enabled"

    .line 452
    .line 453
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 454
    .line 455
    .line 456
    move-result-object v1

    .line 457
    const/16 v2, 0x107

    .line 458
    .line 459
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 460
    .line 461
    .line 462
    move-result-object v1

    .line 463
    sput-object v1, LW1/w;->K0:Lorg/aspectj/runtime/reflect/b;

    .line 464
    .line 465
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 466
    .line 467
    const-string/jumbo v5, "void"

    .line 468
    .line 469
    .line 470
    const-string/jumbo v1, "setInMovie"

    .line 471
    .line 472
    .line 473
    const-string v3, "boolean"

    .line 474
    .line 475
    const-string v4, "inMovie"

    .line 476
    .line 477
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 478
    .line 479
    .line 480
    move-result-object v1

    .line 481
    const/16 v2, 0x10f

    .line 482
    .line 483
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 484
    .line 485
    .line 486
    move-result-object v1

    .line 487
    sput-object v1, LW1/w;->L0:Lorg/aspectj/runtime/reflect/b;

    .line 488
    .line 489
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 490
    .line 491
    const-string/jumbo v5, "void"

    .line 492
    .line 493
    .line 494
    const-string/jumbo v1, "setInPreview"

    .line 495
    .line 496
    .line 497
    const-string v3, "boolean"

    .line 498
    .line 499
    const-string v4, "inPreview"

    .line 500
    .line 501
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 502
    .line 503
    .line 504
    move-result-object v1

    .line 505
    const/16 v2, 0x117

    .line 506
    .line 507
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 508
    .line 509
    .line 510
    move-result-object v1

    .line 511
    sput-object v1, LW1/w;->M0:Lorg/aspectj/runtime/reflect/b;

    .line 512
    .line 513
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 514
    .line 515
    const-string/jumbo v5, "void"

    .line 516
    .line 517
    .line 518
    const-string/jumbo v1, "setInPoster"

    .line 519
    .line 520
    .line 521
    const-string v3, "boolean"

    .line 522
    .line 523
    const-string v4, "inPoster"

    .line 524
    .line 525
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 526
    .line 527
    .line 528
    move-result-object v1

    .line 529
    const/16 v2, 0x11f

    .line 530
    .line 531
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 532
    .line 533
    .line 534
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 535
    .line 536
    const-string v5, "long"

    .line 537
    .line 538
    const-string v1, "getDuration"

    .line 539
    .line 540
    const-string v3, ""

    .line 541
    .line 542
    const-string v4, ""

    .line 543
    .line 544
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 545
    .line 546
    .line 547
    move-result-object v1

    .line 548
    const/16 v2, 0x48

    .line 549
    .line 550
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 551
    .line 552
    .line 553
    move-result-object v1

    .line 554
    sput-object v1, LW1/w;->s0:Lorg/aspectj/runtime/reflect/b;

    .line 555
    .line 556
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 557
    .line 558
    const-string v5, "int"

    .line 559
    .line 560
    const-string v1, "getLayer"

    .line 561
    .line 562
    const-string v3, ""

    .line 563
    .line 564
    const-string v4, ""

    .line 565
    .line 566
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 567
    .line 568
    .line 569
    move-result-object v1

    .line 570
    const/16 v2, 0x4c

    .line 571
    .line 572
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 573
    .line 574
    .line 575
    move-result-object v1

    .line 576
    sput-object v1, LW1/w;->t0:Lorg/aspectj/runtime/reflect/b;

    .line 577
    .line 578
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 579
    .line 580
    const-string v5, "int"

    .line 581
    .line 582
    const-string v1, "getAlternateGroup"

    .line 583
    .line 584
    const-string v3, ""

    .line 585
    .line 586
    const-string v4, ""

    .line 587
    .line 588
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 589
    .line 590
    .line 591
    move-result-object v1

    .line 592
    const/16 v2, 0x50

    .line 593
    .line 594
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 595
    .line 596
    .line 597
    move-result-object v1

    .line 598
    sput-object v1, LW1/w;->u0:Lorg/aspectj/runtime/reflect/b;

    .line 599
    .line 600
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 601
    .line 602
    const-string v5, "float"

    .line 603
    .line 604
    const-string v1, "getVolume"

    .line 605
    .line 606
    const-string v3, ""

    .line 607
    .line 608
    const-string v4, ""

    .line 609
    .line 610
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 611
    .line 612
    .line 613
    move-result-object v1

    .line 614
    const/16 v2, 0x54

    .line 615
    .line 616
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 617
    .line 618
    .line 619
    move-result-object v1

    .line 620
    sput-object v1, LW1/w;->v0:Lorg/aspectj/runtime/reflect/b;

    .line 621
    .line 622
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 623
    .line 624
    const-string v5, "com.googlecode.mp4parser.util.Matrix"

    .line 625
    .line 626
    const-string v1, "getMatrix"

    .line 627
    .line 628
    const-string v3, ""

    .line 629
    .line 630
    const-string v4, ""

    .line 631
    .line 632
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 633
    .line 634
    .line 635
    move-result-object v1

    .line 636
    const/16 v2, 0x58

    .line 637
    .line 638
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 639
    .line 640
    .line 641
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 642
    .line 643
    const-string v5, "double"

    .line 644
    .line 645
    const-string v1, "getWidth"

    .line 646
    .line 647
    const-string v3, ""

    .line 648
    .line 649
    const-string v4, ""

    .line 650
    .line 651
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 652
    .line 653
    .line 654
    move-result-object v1

    .line 655
    const/16 v2, 0x5c

    .line 656
    .line 657
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 658
    .line 659
    .line 660
    move-result-object v1

    .line 661
    sput-object v1, LW1/w;->w0:Lorg/aspectj/runtime/reflect/b;

    .line 662
    .line 663
    const-string v2, "com.coremedia.iso.boxes.TrackHeaderBox"

    .line 664
    .line 665
    const-string v5, "double"

    .line 666
    .line 667
    const-string v1, "getHeight"

    .line 668
    .line 669
    const-string v3, ""

    .line 670
    .line 671
    const-string v4, ""

    .line 672
    .line 673
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 674
    .line 675
    .line 676
    move-result-object v1

    .line 677
    const/16 v2, 0x60

    .line 678
    .line 679
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 680
    .line 681
    .line 682
    move-result-object v0

    .line 683
    sput-object v0, LW1/w;->x0:Lorg/aspectj/runtime/reflect/b;

    .line 684
    .line 685
    return-void
.end method


# virtual methods
.method public final a(Ljava/nio/ByteBuffer;)V
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->h(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v1, 0x1

    .line 9
    if-ne v0, v1, :cond_1

    .line 10
    .line 11
    invoke-static {p1}, LV1/a;->k(Ljava/nio/ByteBuffer;)J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, LW1/w;->B:Ljava/util/Date;

    .line 20
    .line 21
    invoke-static {p1}, LV1/a;->k(Ljava/nio/ByteBuffer;)J

    .line 22
    .line 23
    .line 24
    move-result-wide v0

    .line 25
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, LW1/w;->C:Ljava/util/Date;

    .line 30
    .line 31
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 32
    .line 33
    .line 34
    move-result-wide v0

    .line 35
    iput-wide v0, p0, LW1/w;->H:J

    .line 36
    .line 37
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 38
    .line 39
    .line 40
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->getLong()J

    .line 41
    .line 42
    .line 43
    move-result-wide v0

    .line 44
    iput-wide v0, p0, LW1/w;->L:J

    .line 45
    .line 46
    const-wide/16 v2, -0x1

    .line 47
    .line 48
    cmp-long v0, v0, v2

    .line 49
    .line 50
    if-ltz v0, :cond_0

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_0
    new-instance p1, Ljava/lang/RuntimeException;

    .line 54
    .line 55
    const-string v0, "The tracks duration is bigger than Long.MAX_VALUE"

    .line 56
    .line 57
    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    throw p1

    .line 61
    :cond_1
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 62
    .line 63
    .line 64
    move-result-wide v0

    .line 65
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    iput-object v0, p0, LW1/w;->B:Ljava/util/Date;

    .line 70
    .line 71
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 72
    .line 73
    .line 74
    move-result-wide v0

    .line 75
    invoke-static {v0, v1}, Lorg/chromium/support_lib_boundary/util/b;->q(J)Ljava/util/Date;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    iput-object v0, p0, LW1/w;->C:Ljava/util/Date;

    .line 80
    .line 81
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 82
    .line 83
    .line 84
    move-result-wide v0

    .line 85
    iput-wide v0, p0, LW1/w;->H:J

    .line 86
    .line 87
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 88
    .line 89
    .line 90
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 91
    .line 92
    .line 93
    move-result-wide v0

    .line 94
    iput-wide v0, p0, LW1/w;->L:J

    .line 95
    .line 96
    :goto_0
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 97
    .line 98
    .line 99
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 100
    .line 101
    .line 102
    invoke-static {p1}, LV1/a;->h(Ljava/nio/ByteBuffer;)I

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    iput v0, p0, LW1/w;->M:I

    .line 107
    .line 108
    invoke-static {p1}, LV1/a;->h(Ljava/nio/ByteBuffer;)I

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    iput v0, p0, LW1/w;->Q:I

    .line 113
    .line 114
    invoke-static {p1}, LV1/a;->g(Ljava/nio/ByteBuffer;)F

    .line 115
    .line 116
    .line 117
    move-result v0

    .line 118
    iput v0, p0, LW1/w;->X:F

    .line 119
    .line 120
    invoke-static {p1}, LV1/a;->h(Ljava/nio/ByteBuffer;)I

    .line 121
    .line 122
    .line 123
    invoke-static {p1}, LT4/e;->a(Ljava/nio/ByteBuffer;)LT4/e;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    iput-object v0, p0, LW1/w;->Y:LT4/e;

    .line 128
    .line 129
    invoke-static {p1}, LV1/a;->f(Ljava/nio/ByteBuffer;)D

    .line 130
    .line 131
    .line 132
    move-result-wide v0

    .line 133
    iput-wide v0, p0, LW1/w;->Z:D

    .line 134
    .line 135
    invoke-static {p1}, LV1/a;->f(Ljava/nio/ByteBuffer;)D

    .line 136
    .line 137
    .line 138
    move-result-wide v0

    .line 139
    iput-wide v0, p0, LW1/w;->k0:D

    .line 140
    .line 141
    return-void
.end method

.method public final b(Ljava/nio/ByteBuffer;)V
    .locals 4

    .line 1
    sget-object v0, LW1/w;->y0:Lorg/aspectj/runtime/reflect/b;

    .line 2
    .line 3
    invoke-static {v0, p0, p0, p1}, Lorg/aspectj/runtime/reflect/a;->c(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {}, LP4/f;->a()LP4/f;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {v0}, LP4/f;->b(Lorg/aspectj/runtime/reflect/c;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0, p1}, LP4/c;->i(Ljava/nio/ByteBuffer;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    const/4 v1, 0x1

    .line 25
    const-wide/16 v2, 0x0

    .line 26
    .line 27
    if-ne v0, v1, :cond_0

    .line 28
    .line 29
    iget-object v0, p0, LW1/w;->B:Ljava/util/Date;

    .line 30
    .line 31
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 32
    .line 33
    .line 34
    move-result-wide v0

    .line 35
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, LW1/w;->C:Ljava/util/Date;

    .line 39
    .line 40
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 41
    .line 42
    .line 43
    move-result-wide v0

    .line 44
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 45
    .line 46
    .line 47
    iget-wide v0, p0, LW1/w;->H:J

    .line 48
    .line 49
    long-to-int v0, v0

    .line 50
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 51
    .line 52
    .line 53
    long-to-int v0, v2

    .line 54
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 55
    .line 56
    .line 57
    iget-wide v0, p0, LW1/w;->L:J

    .line 58
    .line 59
    invoke-virtual {p1, v0, v1}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_0
    iget-object v0, p0, LW1/w;->B:Ljava/util/Date;

    .line 64
    .line 65
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 66
    .line 67
    .line 68
    move-result-wide v0

    .line 69
    long-to-int v0, v0

    .line 70
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 71
    .line 72
    .line 73
    iget-object v0, p0, LW1/w;->C:Ljava/util/Date;

    .line 74
    .line 75
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->p(Ljava/util/Date;)J

    .line 76
    .line 77
    .line 78
    move-result-wide v0

    .line 79
    long-to-int v0, v0

    .line 80
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 81
    .line 82
    .line 83
    iget-wide v0, p0, LW1/w;->H:J

    .line 84
    .line 85
    long-to-int v0, v0

    .line 86
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 87
    .line 88
    .line 89
    long-to-int v0, v2

    .line 90
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 91
    .line 92
    .line 93
    iget-wide v0, p0, LW1/w;->L:J

    .line 94
    .line 95
    long-to-int v0, v0

    .line 96
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 97
    .line 98
    .line 99
    :goto_0
    long-to-int v0, v2

    .line 100
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 101
    .line 102
    .line 103
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 104
    .line 105
    .line 106
    iget v0, p0, LW1/w;->M:I

    .line 107
    .line 108
    invoke-static {v0, p1}, LV1/a;->q(ILjava/nio/ByteBuffer;)V

    .line 109
    .line 110
    .line 111
    iget v0, p0, LW1/w;->Q:I

    .line 112
    .line 113
    invoke-static {v0, p1}, LV1/a;->q(ILjava/nio/ByteBuffer;)V

    .line 114
    .line 115
    .line 116
    iget v0, p0, LW1/w;->X:F

    .line 117
    .line 118
    float-to-double v0, v0

    .line 119
    invoke-static {p1, v0, v1}, LV1/a;->p(Ljava/nio/ByteBuffer;D)V

    .line 120
    .line 121
    .line 122
    const/4 v0, 0x0

    .line 123
    invoke-static {v0, p1}, LV1/a;->q(ILjava/nio/ByteBuffer;)V

    .line 124
    .line 125
    .line 126
    iget-object v0, p0, LW1/w;->Y:LT4/e;

    .line 127
    .line 128
    invoke-virtual {v0, p1}, LT4/e;->b(Ljava/nio/ByteBuffer;)V

    .line 129
    .line 130
    .line 131
    iget-wide v0, p0, LW1/w;->Z:D

    .line 132
    .line 133
    invoke-static {p1, v0, v1}, LV1/a;->o(Ljava/nio/ByteBuffer;D)V

    .line 134
    .line 135
    .line 136
    iget-wide v0, p0, LW1/w;->k0:D

    .line 137
    .line 138
    invoke-static {p1, v0, v1}, LV1/a;->o(Ljava/nio/ByteBuffer;D)V

    .line 139
    .line 140
    .line 141
    return-void
.end method

.method public final c()J
    .locals 4

    .line 1
    invoke-virtual {p0}, LP4/c;->getVersion()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    const-wide/16 v0, 0x24

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const-wide/16 v0, 0x18

    .line 12
    .line 13
    :goto_0
    const-wide/16 v2, 0x3c

    .line 14
    .line 15
    add-long/2addr v0, v2

    .line 16
    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    sget-object v0, LW1/w;->z0:Lorg/aspectj/runtime/reflect/b;

    .line 2
    .line 3
    invoke-static {v0, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {}, LP4/f;->a()LP4/f;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {v0}, LP4/f;->b(Lorg/aspectj/runtime/reflect/c;)V

    .line 15
    .line 16
    .line 17
    new-instance v0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v1, "TrackHeaderBox[creationTime="

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    sget-object v1, LW1/w;->p0:Lorg/aspectj/runtime/reflect/b;

    .line 25
    .line 26
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 31
    .line 32
    .line 33
    iget-object v1, p0, LW1/w;->B:Ljava/util/Date;

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    const-string v1, ";modificationTime="

    .line 39
    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    sget-object v1, LW1/w;->q0:Lorg/aspectj/runtime/reflect/b;

    .line 44
    .line 45
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, LW1/w;->C:Ljava/util/Date;

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string v1, ";trackId="

    .line 58
    .line 59
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    sget-object v1, LW1/w;->r0:Lorg/aspectj/runtime/reflect/b;

    .line 63
    .line 64
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 69
    .line 70
    .line 71
    iget-wide v1, p0, LW1/w;->H:J

    .line 72
    .line 73
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string v1, ";duration="

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    sget-object v1, LW1/w;->s0:Lorg/aspectj/runtime/reflect/b;

    .line 82
    .line 83
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 88
    .line 89
    .line 90
    iget-wide v1, p0, LW1/w;->L:J

    .line 91
    .line 92
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string v1, ";layer="

    .line 96
    .line 97
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    sget-object v1, LW1/w;->t0:Lorg/aspectj/runtime/reflect/b;

    .line 101
    .line 102
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 107
    .line 108
    .line 109
    iget v1, p0, LW1/w;->M:I

    .line 110
    .line 111
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    const-string v1, ";alternateGroup="

    .line 115
    .line 116
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    .line 118
    .line 119
    sget-object v1, LW1/w;->u0:Lorg/aspectj/runtime/reflect/b;

    .line 120
    .line 121
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 126
    .line 127
    .line 128
    iget v1, p0, LW1/w;->Q:I

    .line 129
    .line 130
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    const-string v1, ";volume="

    .line 134
    .line 135
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    sget-object v1, LW1/w;->v0:Lorg/aspectj/runtime/reflect/b;

    .line 139
    .line 140
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 145
    .line 146
    .line 147
    iget v1, p0, LW1/w;->X:F

    .line 148
    .line 149
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 150
    .line 151
    .line 152
    const-string v1, ";matrix="

    .line 153
    .line 154
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    iget-object v1, p0, LW1/w;->Y:LT4/e;

    .line 158
    .line 159
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 160
    .line 161
    .line 162
    const-string v1, ";width="

    .line 163
    .line 164
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 165
    .line 166
    .line 167
    sget-object v1, LW1/w;->w0:Lorg/aspectj/runtime/reflect/b;

    .line 168
    .line 169
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 174
    .line 175
    .line 176
    iget-wide v1, p0, LW1/w;->Z:D

    .line 177
    .line 178
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 179
    .line 180
    .line 181
    const-string v1, ";height="

    .line 182
    .line 183
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    sget-object v1, LW1/w;->x0:Lorg/aspectj/runtime/reflect/b;

    .line 187
    .line 188
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 193
    .line 194
    .line 195
    iget-wide v1, p0, LW1/w;->k0:D

    .line 196
    .line 197
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 198
    .line 199
    .line 200
    const-string v1, "]"

    .line 201
    .line 202
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    return-object v0
.end method
