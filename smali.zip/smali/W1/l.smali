.class public final LW1/l;
.super LP4/b;
.source "SourceFile"

# interfaces
.implements Lcom/coremedia/iso/boxes/FullBox;


# instance fields
.field public v:I

.field public w:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    const-string/jumbo v0, "stsd"

    .line 2
    .line 3
    .line 4
    invoke-direct {p0, v0}, LP4/b;-><init>(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final getBox(Ljava/nio/channels/WritableByteChannel;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, LP4/b;->d()Ljava/nio/ByteBuffer;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-interface {p1, v0}, Ljava/nio/channels/WritableByteChannel;->write(Ljava/nio/ByteBuffer;)I

    .line 6
    .line 7
    .line 8
    const/16 v0, 0x8

    .line 9
    .line 10
    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget v1, p0, LW1/l;->v:I

    .line 15
    .line 16
    invoke-static {v1, v0}, LV1/a;->s(ILjava/nio/ByteBuffer;)V

    .line 17
    .line 18
    .line 19
    iget v1, p0, LW1/l;->w:I

    .line 20
    .line 21
    invoke-static {v1, v0}, LV1/a;->r(ILjava/nio/ByteBuffer;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0}, LP4/e;->getBoxes()Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    int-to-long v1, v1

    .line 33
    long-to-int v1, v1

    .line 34
    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    check-cast v0, Ljava/nio/ByteBuffer;

    .line 42
    .line 43
    invoke-interface {p1, v0}, Ljava/nio/channels/WritableByteChannel;->write(Ljava/nio/ByteBuffer;)I

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, p1}, LP4/e;->writeContainer(Ljava/nio/channels/WritableByteChannel;)V

    .line 47
    .line 48
    .line 49
    return-void
.end method

.method public final getFlags()I
    .locals 1

    .line 1
    iget v0, p0, LW1/l;->w:I

    .line 2
    .line 3
    return v0
.end method

.method public final getSize()J
    .locals 6

    .line 1
    invoke-virtual {p0}, LP4/e;->b()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    const-wide/16 v2, 0x8

    .line 6
    .line 7
    add-long/2addr v2, v0

    .line 8
    iget-boolean v4, p0, LP4/b;->p:Z

    .line 9
    .line 10
    if-nez v4, :cond_1

    .line 11
    .line 12
    const-wide/16 v4, 0x10

    .line 13
    .line 14
    add-long/2addr v0, v4

    .line 15
    const-wide v4, 0x100000000L

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    cmp-long v0, v0, v4

    .line 21
    .line 22
    if-ltz v0, :cond_0

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const/16 v0, 0x8

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_1
    :goto_0
    const/16 v0, 0x10

    .line 29
    .line 30
    :goto_1
    int-to-long v0, v0

    .line 31
    add-long/2addr v2, v0

    .line 32
    return-wide v2
.end method

.method public final getVersion()I
    .locals 1

    .line 1
    iget v0, p0, LW1/l;->v:I

    .line 2
    .line 3
    return v0
.end method

.method public final parse(Lcom/googlecode/mp4parser/DataSource;Ljava/nio/ByteBuffer;JLcom/coremedia/iso/BoxParser;)V
    .locals 2

    .line 1
    const/16 p2, 0x8

    .line 2
    .line 3
    invoke-static {p2}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 4
    .line 5
    .line 6
    move-result-object p2

    .line 7
    invoke-interface {p1, p2}, Lcom/googlecode/mp4parser/DataSource;->read(Ljava/nio/ByteBuffer;)I

    .line 8
    .line 9
    .line 10
    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    .line 11
    .line 12
    .line 13
    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->get()B

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    invoke-static {v0}, LV1/a;->a(B)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    iput v0, p0, LW1/l;->v:I

    .line 22
    .line 23
    invoke-static {p2}, LV1/a;->i(Ljava/nio/ByteBuffer;)I

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    iput p2, p0, LW1/l;->w:I

    .line 28
    .line 29
    const-wide/16 v0, 0x8

    .line 30
    .line 31
    sub-long/2addr p3, v0

    .line 32
    invoke-virtual {p0, p1, p3, p4, p5}, LP4/b;->e(Lcom/googlecode/mp4parser/DataSource;JLcom/coremedia/iso/BoxParser;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final setFlags(I)V
    .locals 0

    .line 1
    iput p1, p0, LW1/l;->w:I

    .line 2
    .line 3
    return-void
.end method

.method public final setVersion(I)V
    .locals 0

    .line 1
    iput p1, p0, LW1/l;->v:I

    .line 2
    .line 3
    return-void
.end method
