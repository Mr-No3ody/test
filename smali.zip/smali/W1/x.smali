.class public final LW1/x;
.super LW1/a;
.source "SourceFile"


# static fields
.field public static final synthetic H:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic L:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic M:Lorg/aspectj/runtime/reflect/b;


# instance fields
.field public B:I

.field public C:[I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lorg/aspectj/runtime/reflect/a;

    .line 2
    .line 3
    const-string v1, "VideoMediaHeaderBox.java"

    .line 4
    .line 5
    const-class v2, LW1/x;

    .line 6
    .line 7
    invoke-direct {v0, v2, v1}, Lorg/aspectj/runtime/reflect/a;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "com.coremedia.iso.boxes.VideoMediaHeaderBox"

    .line 11
    .line 12
    const-string v5, "int"

    .line 13
    .line 14
    const-string v1, "getGraphicsmode"

    .line 15
    .line 16
    const-string v3, ""

    .line 17
    .line 18
    const-string v4, ""

    .line 19
    .line 20
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const/16 v2, 0x27

    .line 25
    .line 26
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    sput-object v1, LW1/x;->H:Lorg/aspectj/runtime/reflect/b;

    .line 31
    .line 32
    const-string v2, "com.coremedia.iso.boxes.VideoMediaHeaderBox"

    .line 33
    .line 34
    const-string v5, "[I"

    .line 35
    .line 36
    const-string v1, "getOpcolor"

    .line 37
    .line 38
    const-string v3, ""

    .line 39
    .line 40
    const-string v4, ""

    .line 41
    .line 42
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const/16 v2, 0x2b

    .line 47
    .line 48
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sput-object v1, LW1/x;->L:Lorg/aspectj/runtime/reflect/b;

    .line 53
    .line 54
    const-string v2, "com.coremedia.iso.boxes.VideoMediaHeaderBox"

    .line 55
    .line 56
    const-string v5, "java.lang.String"

    .line 57
    .line 58
    const-string/jumbo v1, "toString"

    .line 59
    .line 60
    .line 61
    const-string v3, ""

    .line 62
    .line 63
    const-string v4, ""

    .line 64
    .line 65
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    const/16 v2, 0x47

    .line 70
    .line 71
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    sput-object v1, LW1/x;->M:Lorg/aspectj/runtime/reflect/b;

    .line 76
    .line 77
    const-string v2, "com.coremedia.iso.boxes.VideoMediaHeaderBox"

    .line 78
    .line 79
    const-string/jumbo v5, "void"

    .line 80
    .line 81
    .line 82
    const-string/jumbo v1, "setOpcolor"

    .line 83
    .line 84
    .line 85
    const-string v3, "[I"

    .line 86
    .line 87
    const-string v4, "opcolor"

    .line 88
    .line 89
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    const/16 v2, 0x4b

    .line 94
    .line 95
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 96
    .line 97
    .line 98
    const-string v2, "com.coremedia.iso.boxes.VideoMediaHeaderBox"

    .line 99
    .line 100
    const-string/jumbo v5, "void"

    .line 101
    .line 102
    .line 103
    const-string/jumbo v1, "setGraphicsmode"

    .line 104
    .line 105
    .line 106
    const-string v3, "int"

    .line 107
    .line 108
    const-string v4, "graphicsmode"

    .line 109
    .line 110
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    const/16 v2, 0x4f

    .line 115
    .line 116
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 117
    .line 118
    .line 119
    return-void
.end method


# virtual methods
.method public final a(Ljava/nio/ByteBuffer;)V
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->h(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LV1/a;->h(Ljava/nio/ByteBuffer;)I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iput v0, p0, LW1/x;->B:I

    .line 9
    .line 10
    const/4 v0, 0x3

    .line 11
    new-array v1, v0, [I

    .line 12
    .line 13
    iput-object v1, p0, LW1/x;->C:[I

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    :goto_0
    if-lt v1, v0, :cond_0

    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    iget-object v2, p0, LW1/x;->C:[I

    .line 20
    .line 21
    invoke-static {p1}, LV1/a;->h(Ljava/nio/ByteBuffer;)I

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    aput v3, v2, v1

    .line 26
    .line 27
    add-int/lit8 v1, v1, 0x1

    .line 28
    .line 29
    goto :goto_0
.end method

.method public final b(Ljava/nio/ByteBuffer;)V
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->i(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    iget v0, p0, LW1/x;->B:I

    .line 5
    .line 6
    invoke-static {v0, p1}, LV1/a;->q(ILjava/nio/ByteBuffer;)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, LW1/x;->C:[I

    .line 10
    .line 11
    array-length v1, v0

    .line 12
    const/4 v2, 0x0

    .line 13
    :goto_0
    if-lt v2, v1, :cond_0

    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    aget v3, v0, v2

    .line 17
    .line 18
    invoke-static {v3, p1}, LV1/a;->q(ILjava/nio/ByteBuffer;)V

    .line 19
    .line 20
    .line 21
    add-int/lit8 v2, v2, 0x1

    .line 22
    .line 23
    goto :goto_0
.end method

.method public final c()J
    .locals 2

    .line 1
    const-wide/16 v0, 0xc

    .line 2
    .line 3
    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    sget-object v0, LW1/x;->M:Lorg/aspectj/runtime/reflect/b;

    .line 2
    .line 3
    invoke-static {v0, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {}, LP4/f;->a()LP4/f;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {v0}, LP4/f;->b(Lorg/aspectj/runtime/reflect/c;)V

    .line 15
    .line 16
    .line 17
    new-instance v0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v1, "VideoMediaHeaderBox[graphicsmode="

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    sget-object v1, LW1/x;->H:Lorg/aspectj/runtime/reflect/b;

    .line 25
    .line 26
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 31
    .line 32
    .line 33
    iget v1, p0, LW1/x;->B:I

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    const-string v1, ";opcolor0="

    .line 39
    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    sget-object v1, LW1/x;->L:Lorg/aspectj/runtime/reflect/b;

    .line 44
    .line 45
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-static {v2}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 50
    .line 51
    .line 52
    iget-object v2, p0, LW1/x;->C:[I

    .line 53
    .line 54
    const/4 v3, 0x0

    .line 55
    aget v2, v2, v3

    .line 56
    .line 57
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    const-string v2, ";opcolor1="

    .line 61
    .line 62
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    invoke-static {v2}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 70
    .line 71
    .line 72
    iget-object v2, p0, LW1/x;->C:[I

    .line 73
    .line 74
    const/4 v3, 0x1

    .line 75
    aget v2, v2, v3

    .line 76
    .line 77
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    const-string v2, ";opcolor2="

    .line 81
    .line 82
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    invoke-static {v1, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    invoke-static {v1}, Lcom/horcrux/svg/d0;->s(Lorg/aspectj/runtime/reflect/c;)V

    .line 90
    .line 91
    .line 92
    iget-object v1, p0, LW1/x;->C:[I

    .line 93
    .line 94
    const/4 v2, 0x2

    .line 95
    aget v1, v1, v2

    .line 96
    .line 97
    const-string v2, "]"

    .line 98
    .line 99
    invoke-static {v1, v2, v0}, LC0/G;->n(ILjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    return-object v0
.end method
