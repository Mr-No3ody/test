.class public final LW1/v;
.super LP4/c;
.source "SourceFile"


# static fields
.field public static final synthetic C:Lorg/aspectj/runtime/reflect/b;

.field public static final synthetic H:Lorg/aspectj/runtime/reflect/b;


# instance fields
.field public B:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lorg/aspectj/runtime/reflect/a;

    .line 2
    .line 3
    const-string v1, "TimeToSampleBox.java"

    .line 4
    .line 5
    const-class v2, LW1/v;

    .line 6
    .line 7
    invoke-direct {v0, v2, v1}, Lorg/aspectj/runtime/reflect/a;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "com.coremedia.iso.boxes.TimeToSampleBox"

    .line 11
    .line 12
    const-string v5, "java.util.List"

    .line 13
    .line 14
    const-string v1, "getEntries"

    .line 15
    .line 16
    const-string v3, ""

    .line 17
    .line 18
    const-string v4, ""

    .line 19
    .line 20
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    const/16 v2, 0x4f

    .line 25
    .line 26
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 27
    .line 28
    .line 29
    const-string v2, "com.coremedia.iso.boxes.TimeToSampleBox"

    .line 30
    .line 31
    const-string/jumbo v5, "void"

    .line 32
    .line 33
    .line 34
    const-string/jumbo v1, "setEntries"

    .line 35
    .line 36
    .line 37
    const-string v3, "java.util.List"

    .line 38
    .line 39
    const-string v4, "entries"

    .line 40
    .line 41
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    const/16 v2, 0x53

    .line 46
    .line 47
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    sput-object v1, LW1/v;->C:Lorg/aspectj/runtime/reflect/b;

    .line 52
    .line 53
    const-string v2, "com.coremedia.iso.boxes.TimeToSampleBox"

    .line 54
    .line 55
    const-string v5, "java.lang.String"

    .line 56
    .line 57
    const-string/jumbo v1, "toString"

    .line 58
    .line 59
    .line 60
    const-string v3, ""

    .line 61
    .line 62
    const-string v4, ""

    .line 63
    .line 64
    invoke-virtual/range {v0 .. v5}, Lorg/aspectj/runtime/reflect/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lj3/v;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    const/16 v2, 0x57

    .line 69
    .line 70
    invoke-virtual {v0, v1, v2}, Lorg/aspectj/runtime/reflect/a;->e(Lj3/v;I)Lorg/aspectj/runtime/reflect/b;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    sput-object v0, LW1/v;->H:Lorg/aspectj/runtime/reflect/b;

    .line 75
    .line 76
    new-instance v0, Ljava/util/WeakHashMap;

    .line 77
    .line 78
    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    .line 79
    .line 80
    .line 81
    return-void
.end method


# virtual methods
.method public final a(Ljava/nio/ByteBuffer;)V
    .locals 8

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->h(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    invoke-static {v0, v1}, Lj8/f;->r(J)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    new-instance v1, Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, LW1/v;->B:Ljava/util/List;

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    :goto_0
    if-lt v1, v0, :cond_0

    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    iget-object v2, p0, LW1/v;->B:Ljava/util/List;

    .line 24
    .line 25
    new-instance v3, LW1/u;

    .line 26
    .line 27
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 28
    .line 29
    .line 30
    move-result-wide v4

    .line 31
    invoke-static {p1}, LV1/a;->j(Ljava/nio/ByteBuffer;)J

    .line 32
    .line 33
    .line 34
    move-result-wide v6

    .line 35
    invoke-direct {v3, v4, v5, v6, v7}, LW1/u;-><init>(JJ)V

    .line 36
    .line 37
    .line 38
    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    add-int/lit8 v1, v1, 0x1

    .line 42
    .line 43
    goto :goto_0
.end method

.method public final b(Ljava/nio/ByteBuffer;)V
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, LP4/c;->i(Ljava/nio/ByteBuffer;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LW1/v;->B:Ljava/util/List;

    .line 5
    .line 6
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    int-to-long v0, v0

    .line 11
    long-to-int v0, v0

    .line 12
    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, LW1/v;->B:Ljava/util/List;

    .line 16
    .line 17
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-nez v1, :cond_0

    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, LW1/u;

    .line 33
    .line 34
    iget-wide v2, v1, LW1/u;->a:J

    .line 35
    .line 36
    long-to-int v2, v2

    .line 37
    invoke-virtual {p1, v2}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 38
    .line 39
    .line 40
    iget-wide v1, v1, LW1/u;->b:J

    .line 41
    .line 42
    long-to-int v1, v1

    .line 43
    invoke-virtual {p1, v1}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 44
    .line 45
    .line 46
    goto :goto_0
.end method

.method public final c()J
    .locals 2

    .line 1
    iget-object v0, p0, LW1/v;->B:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x8

    .line 8
    .line 9
    add-int/lit8 v0, v0, 0x8

    .line 10
    .line 11
    int-to-long v0, v0

    .line 12
    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    sget-object v0, LW1/v;->H:Lorg/aspectj/runtime/reflect/b;

    .line 2
    .line 3
    invoke-static {v0, p0, p0}, Lorg/aspectj/runtime/reflect/a;->b(Lorg/aspectj/lang/JoinPoint$StaticPart;Ljava/lang/Object;Ljava/lang/Object;)Lorg/aspectj/runtime/reflect/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {}, LP4/f;->a()LP4/f;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {v0}, LP4/f;->b(Lorg/aspectj/runtime/reflect/c;)V

    .line 15
    .line 16
    .line 17
    new-instance v0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v1, "TimeToSampleBox[entryCount="

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-object v1, p0, LW1/v;->B:Ljava/util/List;

    .line 25
    .line 26
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const-string v1, "]"

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    return-object v0
.end method
