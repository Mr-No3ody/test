.class public final Lr1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/content/Context;

.field public final synthetic c:Landroid/content/Intent;

.field public final synthetic d:Lcom/alibaba/android/arouter/facade/Postcard;

.field public final synthetic e:Lcom/alibaba/android/arouter/facade/callback/NavigationCallback;

.field public final synthetic f:Lr1/c;


# direct methods
.method public constructor <init>(Lr1/c;ILandroid/content/Context;Landroid/content/Intent;Lcom/alibaba/android/arouter/facade/Postcard;Lcom/alibaba/android/arouter/facade/callback/NavigationCallback;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lr1/a;->f:Lr1/c;

    .line 5
    .line 6
    iput p2, p0, Lr1/a;->a:I

    .line 7
    .line 8
    iput-object p3, p0, Lr1/a;->b:Landroid/content/Context;

    .line 9
    .line 10
    iput-object p4, p0, Lr1/a;->c:Landroid/content/Intent;

    .line 11
    .line 12
    iput-object p5, p0, Lr1/a;->d:Lcom/alibaba/android/arouter/facade/Postcard;

    .line 13
    .line 14
    iput-object p6, p0, Lr1/a;->e:Lcom/alibaba/android/arouter/facade/callback/NavigationCallback;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    .line 1
    iget-object v0, p0, Lr1/a;->f:Lr1/c;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget v0, p0, Lr1/a;->a:I

    .line 7
    .line 8
    iget-object v1, p0, Lr1/a;->b:Landroid/content/Context;

    .line 9
    .line 10
    iget-object v2, p0, Lr1/a;->c:Landroid/content/Intent;

    .line 11
    .line 12
    iget-object v3, p0, Lr1/a;->d:Lcom/alibaba/android/arouter/facade/Postcard;

    .line 13
    .line 14
    if-ltz v0, :cond_1

    .line 15
    .line 16
    instance-of v4, v1, Landroid/app/Activity;

    .line 17
    .line 18
    if-eqz v4, :cond_0

    .line 19
    .line 20
    move-object v4, v1

    .line 21
    check-cast v4, Landroid/app/Activity;

    .line 22
    .line 23
    invoke-virtual {v3}, Lcom/alibaba/android/arouter/facade/Postcard;->getOptionsBundle()Landroid/os/Bundle;

    .line 24
    .line 25
    .line 26
    move-result-object v5

    .line 27
    invoke-virtual {v4, v2, v0, v5}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;ILandroid/os/Bundle;)V

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    sget-object v0, Lr1/c;->a:Lcom/alibaba/android/arouter/facade/template/ILogger;

    .line 32
    .line 33
    const-string v2, "ARouter::"

    .line 34
    .line 35
    const-string v4, "Must use [navigation(activity, ...)] to support [startActivityForResult]"

    .line 36
    .line 37
    invoke-interface {v0, v2, v4}, Lcom/alibaba/android/arouter/facade/template/ILogger;->warning(Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    invoke-virtual {v3}, Lcom/alibaba/android/arouter/facade/Postcard;->getOptionsBundle()Landroid/os/Bundle;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;Landroid/os/Bundle;)V

    .line 46
    .line 47
    .line 48
    :goto_0
    invoke-virtual {v3}, Lcom/alibaba/android/arouter/facade/Postcard;->getEnterAnim()I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    const/4 v2, -0x1

    .line 53
    if-eq v2, v0, :cond_2

    .line 54
    .line 55
    invoke-virtual {v3}, Lcom/alibaba/android/arouter/facade/Postcard;->getExitAnim()I

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-eq v2, v0, :cond_2

    .line 60
    .line 61
    instance-of v0, v1, Landroid/app/Activity;

    .line 62
    .line 63
    if-eqz v0, :cond_2

    .line 64
    .line 65
    check-cast v1, Landroid/app/Activity;

    .line 66
    .line 67
    invoke-virtual {v3}, Lcom/alibaba/android/arouter/facade/Postcard;->getEnterAnim()I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    invoke-virtual {v3}, Lcom/alibaba/android/arouter/facade/Postcard;->getExitAnim()I

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    invoke-virtual {v1, v0, v2}, Landroid/app/Activity;->overridePendingTransition(II)V

    .line 76
    .line 77
    .line 78
    :cond_2
    iget-object v0, p0, Lr1/a;->e:Lcom/alibaba/android/arouter/facade/callback/NavigationCallback;

    .line 79
    .line 80
    if-eqz v0, :cond_3

    .line 81
    .line 82
    invoke-interface {v0, v3}, Lcom/alibaba/android/arouter/facade/callback/NavigationCallback;->onArrival(Lcom/alibaba/android/arouter/facade/Postcard;)V

    .line 83
    .line 84
    .line 85
    :cond_3
    return-void
.end method
