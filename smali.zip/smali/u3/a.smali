.class public final synthetic Lu3/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/facebook/react/jstasks/HeadlessJsTaskContext;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lcom/facebook/react/jstasks/HeadlessJsTaskContext;II)V
    .locals 0

    .line 1
    iput p3, p0, Lu3/a;->a:I

    iput-object p1, p0, Lu3/a;->b:Lcom/facebook/react/jstasks/HeadlessJsTaskContext;

    iput p2, p0, Lu3/a;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget v0, p0, Lu3/a;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lu3/a;->b:Lcom/facebook/react/jstasks/HeadlessJsTaskContext;

    iget v1, p0, Lu3/a;->c:I

    invoke-static {v0, v1}, Lcom/facebook/react/jstasks/HeadlessJsTaskContext;->a(Lcom/facebook/react/jstasks/HeadlessJsTaskContext;I)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lu3/a;->b:Lcom/facebook/react/jstasks/HeadlessJsTaskContext;

    iget v1, p0, Lu3/a;->c:I

    invoke-static {v0, v1}, Lcom/facebook/react/jstasks/HeadlessJsTaskContext;->c(Lcom/facebook/react/jstasks/HeadlessJsTaskContext;I)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
