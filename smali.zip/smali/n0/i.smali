.class public final Ln0/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/datastore/core/Serializer;


# static fields
.field public static final a:Ln0/i;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ln0/i;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Ln0/i;->a:Ln0/i;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final getDefaultValue()Ljava/lang/Object;
    .locals 2

    .line 1
    new-instance v0, Ln0/b;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Ln0/b;-><init>(Z)V

    .line 5
    .line 6
    .line 7
    return-object v0
.end method

.method public final readFrom(Ljava/io/InputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 6

    .line 1
    sget-object p2, Lm0/c;->a:Lm0/b;

    .line 2
    .line 3
    invoke-virtual {p2, p1}, Lm0/b;->readFrom(Ljava/io/InputStream;)Lm0/f;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    const/4 p2, 0x0

    .line 8
    new-array v0, p2, [Ln0/f;

    .line 9
    .line 10
    const-string v1, "pairs"

    .line 11
    .line 12
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    new-instance v2, Ln0/b;

    .line 16
    .line 17
    invoke-direct {v2, p2}, Ln0/b;-><init>(Z)V

    .line 18
    .line 19
    .line 20
    invoke-static {v0, p2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, [Ln0/f;

    .line 25
    .line 26
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v2}, Ln0/b;->b()V

    .line 30
    .line 31
    .line 32
    array-length v1, v0

    .line 33
    if-gtz v1, :cond_3

    .line 34
    .line 35
    invoke-virtual {p1}, Lm0/f;->getPreferencesMap()Ljava/util/Map;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    const-string v0, "preferencesProto.preferencesMap"

    .line 40
    .line 41
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_2

    .line 57
    .line 58
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    check-cast v0, Ljava/util/Map$Entry;

    .line 63
    .line 64
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    check-cast v1, Ljava/lang/String;

    .line 69
    .line 70
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    check-cast v0, Lm0/k;

    .line 75
    .line 76
    const-string v3, "name"

    .line 77
    .line 78
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    const-string/jumbo v4, "value"

    .line 82
    .line 83
    .line 84
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0}, Lm0/k;->getValueCase()Lm0/j;

    .line 88
    .line 89
    .line 90
    move-result-object v4

    .line 91
    if-nez v4, :cond_0

    .line 92
    .line 93
    const/4 v4, -0x1

    .line 94
    goto :goto_1

    .line 95
    :cond_0
    sget-object v5, Ln0/h;->a:[I

    .line 96
    .line 97
    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    .line 98
    .line 99
    .line 100
    move-result v4

    .line 101
    aget v4, v5, v4

    .line 102
    .line 103
    :goto_1
    const-string v5, "key"

    .line 104
    .line 105
    packed-switch v4, :pswitch_data_0

    .line 106
    .line 107
    .line 108
    :pswitch_0
    new-instance p1, Lxf/l;

    .line 109
    .line 110
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 111
    .line 112
    .line 113
    throw p1

    .line 114
    :pswitch_1
    new-instance p1, Lj0/a;

    .line 115
    .line 116
    const-string v0, "Value not set."

    .line 117
    .line 118
    invoke-direct {p1, v0, p2}, Lj0/a;-><init>(Ljava/lang/String;I)V

    .line 119
    .line 120
    .line 121
    throw p1

    .line 122
    :pswitch_2
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    new-instance v3, Ln0/e;

    .line 126
    .line 127
    invoke-direct {v3, v1}, Ln0/e;-><init>(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v0}, Lm0/k;->getBytes()Landroidx/datastore/preferences/protobuf/n;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    invoke-virtual {v0}, Landroidx/datastore/preferences/protobuf/n;->size()I

    .line 135
    .line 136
    .line 137
    move-result v1

    .line 138
    if-nez v1, :cond_1

    .line 139
    .line 140
    sget-object v0, Landroidx/datastore/preferences/protobuf/x1;->b:[B

    .line 141
    .line 142
    goto :goto_2

    .line 143
    :cond_1
    new-array v4, v1, [B

    .line 144
    .line 145
    invoke-virtual {v0, v1, v4}, Landroidx/datastore/preferences/protobuf/n;->e(I[B)V

    .line 146
    .line 147
    .line 148
    move-object v0, v4

    .line 149
    :goto_2
    const-string/jumbo v1, "value.bytes.toByteArray()"

    .line 150
    .line 151
    .line 152
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v2, v3, v0}, Ln0/b;->e(Ln0/e;Ljava/lang/Object;)V

    .line 159
    .line 160
    .line 161
    goto :goto_0

    .line 162
    :pswitch_3
    invoke-static {v1}, Lz5/l;->K(Ljava/lang/String;)Ln0/e;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    invoke-virtual {v0}, Lm0/k;->getStringSet()Lm0/h;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-virtual {v0}, Lm0/h;->getStringsList()Ljava/util/List;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    const-string/jumbo v3, "value.stringSet.stringsList"

    .line 175
    .line 176
    .line 177
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    check-cast v0, Ljava/lang/Iterable;

    .line 181
    .line 182
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->b0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v2, v1, v0}, Ln0/b;->e(Ln0/e;Ljava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    goto/16 :goto_0

    .line 193
    .line 194
    :pswitch_4
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    new-instance v3, Ln0/e;

    .line 198
    .line 199
    invoke-direct {v3, v1}, Ln0/e;-><init>(Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v0}, Lm0/k;->getString()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    const-string/jumbo v1, "value.string"

    .line 207
    .line 208
    .line 209
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 210
    .line 211
    .line 212
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {v2, v3, v0}, Ln0/b;->e(Ln0/e;Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    goto/16 :goto_0

    .line 219
    .line 220
    :pswitch_5
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 221
    .line 222
    .line 223
    new-instance v3, Ln0/e;

    .line 224
    .line 225
    invoke-direct {v3, v1}, Ln0/e;-><init>(Ljava/lang/String;)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {v0}, Lm0/k;->getLong()J

    .line 229
    .line 230
    .line 231
    move-result-wide v0

    .line 232
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 233
    .line 234
    .line 235
    move-result-object v0

    .line 236
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {v2, v3, v0}, Ln0/b;->e(Ln0/e;Ljava/lang/Object;)V

    .line 240
    .line 241
    .line 242
    goto/16 :goto_0

    .line 243
    .line 244
    :pswitch_6
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    new-instance v3, Ln0/e;

    .line 248
    .line 249
    invoke-direct {v3, v1}, Ln0/e;-><init>(Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v0}, Lm0/k;->getInteger()I

    .line 253
    .line 254
    .line 255
    move-result v0

    .line 256
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 257
    .line 258
    .line 259
    move-result-object v0

    .line 260
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    invoke-virtual {v2, v3, v0}, Ln0/b;->e(Ln0/e;Ljava/lang/Object;)V

    .line 264
    .line 265
    .line 266
    goto/16 :goto_0

    .line 267
    .line 268
    :pswitch_7
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    new-instance v3, Ln0/e;

    .line 272
    .line 273
    invoke-direct {v3, v1}, Ln0/e;-><init>(Ljava/lang/String;)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v0}, Lm0/k;->getDouble()D

    .line 277
    .line 278
    .line 279
    move-result-wide v0

    .line 280
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 285
    .line 286
    .line 287
    invoke-virtual {v2, v3, v0}, Ln0/b;->e(Ln0/e;Ljava/lang/Object;)V

    .line 288
    .line 289
    .line 290
    goto/16 :goto_0

    .line 291
    .line 292
    :pswitch_8
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 293
    .line 294
    .line 295
    new-instance v3, Ln0/e;

    .line 296
    .line 297
    invoke-direct {v3, v1}, Ln0/e;-><init>(Ljava/lang/String;)V

    .line 298
    .line 299
    .line 300
    invoke-virtual {v0}, Lm0/k;->getFloat()F

    .line 301
    .line 302
    .line 303
    move-result v0

    .line 304
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 305
    .line 306
    .line 307
    move-result-object v0

    .line 308
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 309
    .line 310
    .line 311
    invoke-virtual {v2, v3, v0}, Ln0/b;->e(Ln0/e;Ljava/lang/Object;)V

    .line 312
    .line 313
    .line 314
    goto/16 :goto_0

    .line 315
    .line 316
    :pswitch_9
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 317
    .line 318
    .line 319
    new-instance v3, Ln0/e;

    .line 320
    .line 321
    invoke-direct {v3, v1}, Ln0/e;-><init>(Ljava/lang/String;)V

    .line 322
    .line 323
    .line 324
    invoke-virtual {v0}, Lm0/k;->getBoolean()Z

    .line 325
    .line 326
    .line 327
    move-result v0

    .line 328
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 329
    .line 330
    .line 331
    move-result-object v0

    .line 332
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v2, v3, v0}, Ln0/b;->e(Ln0/e;Ljava/lang/Object;)V

    .line 336
    .line 337
    .line 338
    goto/16 :goto_0

    .line 339
    .line 340
    :pswitch_a
    new-instance p1, Lj0/a;

    .line 341
    .line 342
    const-string v0, "Value case is null."

    .line 343
    .line 344
    invoke-direct {p1, v0, p2}, Lj0/a;-><init>(Ljava/lang/String;I)V

    .line 345
    .line 346
    .line 347
    throw p1

    .line 348
    :cond_2
    new-instance p1, Ln0/b;

    .line 349
    .line 350
    invoke-virtual {v2}, Ln0/b;->a()Ljava/util/Map;

    .line 351
    .line 352
    .line 353
    move-result-object p2

    .line 354
    invoke-static {p2}, Lkotlin/collections/G;->l(Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 355
    .line 356
    .line 357
    move-result-object p2

    .line 358
    const/4 v0, 0x1

    .line 359
    invoke-direct {p1, p2, v0}, Ln0/b;-><init>(Ljava/util/LinkedHashMap;Z)V

    .line 360
    .line 361
    .line 362
    return-object p1

    .line 363
    :cond_3
    aget-object p1, v0, p2

    .line 364
    .line 365
    const/4 p1, 0x0

    .line 366
    throw p1

    .line 367
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_a
        :pswitch_0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public final writeTo(Ljava/lang/Object;Ljava/io/OutputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 5

    .line 1
    check-cast p1, Ln0/g;

    .line 2
    .line 3
    invoke-virtual {p1}, Ln0/g;->a()Ljava/util/Map;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {}, Lm0/f;->o()Lm0/d;

    .line 8
    .line 9
    .line 10
    move-result-object p3

    .line 11
    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_8

    .line 24
    .line 25
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Ljava/util/Map$Entry;

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    check-cast v1, Ln0/e;

    .line 36
    .line 37
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    iget-object v1, v1, Ln0/e;->a:Ljava/lang/String;

    .line 42
    .line 43
    instance-of v2, v0, Ljava/lang/Boolean;

    .line 44
    .line 45
    if-eqz v2, :cond_0

    .line 46
    .line 47
    invoke-static {}, Lm0/k;->w()Lm0/i;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    check-cast v0, Ljava/lang/Boolean;

    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 58
    .line 59
    .line 60
    iget-object v3, v2, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 61
    .line 62
    check-cast v3, Lm0/k;

    .line 63
    .line 64
    invoke-static {v3, v0}, Lm0/k;->s(Lm0/k;Z)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    const-string v2, "newBuilder().setBoolean(value).build()"

    .line 72
    .line 73
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    check-cast v0, Lm0/k;

    .line 77
    .line 78
    goto/16 :goto_1

    .line 79
    .line 80
    :cond_0
    instance-of v2, v0, Ljava/lang/Float;

    .line 81
    .line 82
    if-eqz v2, :cond_1

    .line 83
    .line 84
    invoke-static {}, Lm0/k;->w()Lm0/i;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    check-cast v0, Ljava/lang/Number;

    .line 89
    .line 90
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 95
    .line 96
    .line 97
    iget-object v3, v2, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 98
    .line 99
    check-cast v3, Lm0/k;

    .line 100
    .line 101
    invoke-static {v3, v0}, Lm0/k;->t(Lm0/k;F)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    const-string v2, "newBuilder().setFloat(value).build()"

    .line 109
    .line 110
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    check-cast v0, Lm0/k;

    .line 114
    .line 115
    goto/16 :goto_1

    .line 116
    .line 117
    :cond_1
    instance-of v2, v0, Ljava/lang/Double;

    .line 118
    .line 119
    if-eqz v2, :cond_2

    .line 120
    .line 121
    invoke-static {}, Lm0/k;->w()Lm0/i;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    check-cast v0, Ljava/lang/Number;

    .line 126
    .line 127
    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    .line 128
    .line 129
    .line 130
    move-result-wide v3

    .line 131
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 132
    .line 133
    .line 134
    iget-object v0, v2, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 135
    .line 136
    check-cast v0, Lm0/k;

    .line 137
    .line 138
    invoke-static {v0, v3, v4}, Lm0/k;->q(Lm0/k;D)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    const-string v2, "newBuilder().setDouble(value).build()"

    .line 146
    .line 147
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    check-cast v0, Lm0/k;

    .line 151
    .line 152
    goto/16 :goto_1

    .line 153
    .line 154
    :cond_2
    instance-of v2, v0, Ljava/lang/Integer;

    .line 155
    .line 156
    if-eqz v2, :cond_3

    .line 157
    .line 158
    invoke-static {}, Lm0/k;->w()Lm0/i;

    .line 159
    .line 160
    .line 161
    move-result-object v2

    .line 162
    check-cast v0, Ljava/lang/Number;

    .line 163
    .line 164
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 169
    .line 170
    .line 171
    iget-object v3, v2, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 172
    .line 173
    check-cast v3, Lm0/k;

    .line 174
    .line 175
    invoke-static {v3, v0}, Lm0/k;->u(Lm0/k;I)V

    .line 176
    .line 177
    .line 178
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    const-string v2, "newBuilder().setInteger(value).build()"

    .line 183
    .line 184
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    check-cast v0, Lm0/k;

    .line 188
    .line 189
    goto/16 :goto_1

    .line 190
    .line 191
    :cond_3
    instance-of v2, v0, Ljava/lang/Long;

    .line 192
    .line 193
    if-eqz v2, :cond_4

    .line 194
    .line 195
    invoke-static {}, Lm0/k;->w()Lm0/i;

    .line 196
    .line 197
    .line 198
    move-result-object v2

    .line 199
    check-cast v0, Ljava/lang/Number;

    .line 200
    .line 201
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 202
    .line 203
    .line 204
    move-result-wide v3

    .line 205
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 206
    .line 207
    .line 208
    iget-object v0, v2, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 209
    .line 210
    check-cast v0, Lm0/k;

    .line 211
    .line 212
    invoke-static {v0, v3, v4}, Lm0/k;->n(Lm0/k;J)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    const-string v2, "newBuilder().setLong(value).build()"

    .line 220
    .line 221
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    check-cast v0, Lm0/k;

    .line 225
    .line 226
    goto/16 :goto_1

    .line 227
    .line 228
    :cond_4
    instance-of v2, v0, Ljava/lang/String;

    .line 229
    .line 230
    if-eqz v2, :cond_5

    .line 231
    .line 232
    invoke-static {}, Lm0/k;->w()Lm0/i;

    .line 233
    .line 234
    .line 235
    move-result-object v2

    .line 236
    check-cast v0, Ljava/lang/String;

    .line 237
    .line 238
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 239
    .line 240
    .line 241
    iget-object v3, v2, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 242
    .line 243
    check-cast v3, Lm0/k;

    .line 244
    .line 245
    invoke-static {v0, v3}, Lm0/k;->o(Ljava/lang/String;Lm0/k;)V

    .line 246
    .line 247
    .line 248
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    const-string v2, "newBuilder().setString(value).build()"

    .line 253
    .line 254
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 255
    .line 256
    .line 257
    check-cast v0, Lm0/k;

    .line 258
    .line 259
    goto :goto_1

    .line 260
    :cond_5
    instance-of v2, v0, Ljava/util/Set;

    .line 261
    .line 262
    if-eqz v2, :cond_6

    .line 263
    .line 264
    invoke-static {}, Lm0/k;->w()Lm0/i;

    .line 265
    .line 266
    .line 267
    move-result-object v2

    .line 268
    invoke-static {}, Lm0/h;->p()Lm0/g;

    .line 269
    .line 270
    .line 271
    move-result-object v3

    .line 272
    const-string v4, "null cannot be cast to non-null type kotlin.collections.Set<kotlin.String>"

    .line 273
    .line 274
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    check-cast v0, Ljava/util/Set;

    .line 278
    .line 279
    invoke-virtual {v3}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 280
    .line 281
    .line 282
    iget-object v4, v3, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 283
    .line 284
    check-cast v4, Lm0/h;

    .line 285
    .line 286
    invoke-static {v4, v0}, Lm0/h;->n(Lm0/h;Ljava/util/Set;)V

    .line 287
    .line 288
    .line 289
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 290
    .line 291
    .line 292
    iget-object v0, v2, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 293
    .line 294
    check-cast v0, Lm0/k;

    .line 295
    .line 296
    invoke-virtual {v3}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 297
    .line 298
    .line 299
    move-result-object v3

    .line 300
    check-cast v3, Lm0/h;

    .line 301
    .line 302
    invoke-static {v0, v3}, Lm0/k;->p(Lm0/k;Lm0/h;)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 306
    .line 307
    .line 308
    move-result-object v0

    .line 309
    const-string v2, "newBuilder()\n           \u2026                 .build()"

    .line 310
    .line 311
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 312
    .line 313
    .line 314
    check-cast v0, Lm0/k;

    .line 315
    .line 316
    goto :goto_1

    .line 317
    :cond_6
    instance-of v2, v0, [B

    .line 318
    .line 319
    if-eqz v2, :cond_7

    .line 320
    .line 321
    invoke-static {}, Lm0/k;->w()Lm0/i;

    .line 322
    .line 323
    .line 324
    move-result-object v2

    .line 325
    check-cast v0, [B

    .line 326
    .line 327
    sget-object v3, Landroidx/datastore/preferences/protobuf/n;->b:Landroidx/datastore/preferences/protobuf/m;

    .line 328
    .line 329
    array-length v3, v0

    .line 330
    const/4 v4, 0x0

    .line 331
    invoke-static {v4, v3, v0}, Landroidx/datastore/preferences/protobuf/n;->c(II[B)Landroidx/datastore/preferences/protobuf/m;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 336
    .line 337
    .line 338
    iget-object v3, v2, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 339
    .line 340
    check-cast v3, Lm0/k;

    .line 341
    .line 342
    invoke-static {v3, v0}, Lm0/k;->r(Lm0/k;Landroidx/datastore/preferences/protobuf/m;)V

    .line 343
    .line 344
    .line 345
    invoke-virtual {v2}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 346
    .line 347
    .line 348
    move-result-object v0

    .line 349
    const-string v2, "newBuilder().setBytes(By\u2026.copyFrom(value)).build()"

    .line 350
    .line 351
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 352
    .line 353
    .line 354
    check-cast v0, Lm0/k;

    .line 355
    .line 356
    :goto_1
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 357
    .line 358
    .line 359
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 360
    .line 361
    .line 362
    invoke-virtual {p3}, Landroidx/datastore/preferences/protobuf/q1;->d()V

    .line 363
    .line 364
    .line 365
    iget-object v2, p3, Landroidx/datastore/preferences/protobuf/q1;->b:Landroidx/datastore/preferences/protobuf/u1;

    .line 366
    .line 367
    check-cast v2, Lm0/f;

    .line 368
    .line 369
    invoke-static {v2}, Lm0/f;->n(Lm0/f;)Landroidx/datastore/preferences/protobuf/K1;

    .line 370
    .line 371
    .line 372
    move-result-object v2

    .line 373
    invoke-virtual {v2, v1, v0}, Landroidx/datastore/preferences/protobuf/K1;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 374
    .line 375
    .line 376
    goto/16 :goto_0

    .line 377
    .line 378
    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 379
    .line 380
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 381
    .line 382
    .line 383
    move-result-object p2

    .line 384
    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 385
    .line 386
    .line 387
    move-result-object p2

    .line 388
    const-string p3, "PreferencesSerializer does not support type: "

    .line 389
    .line 390
    invoke-virtual {p3, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 391
    .line 392
    .line 393
    move-result-object p2

    .line 394
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 395
    .line 396
    .line 397
    throw p1

    .line 398
    :cond_8
    invoke-virtual {p3}, Landroidx/datastore/preferences/protobuf/q1;->b()Landroidx/datastore/preferences/protobuf/u1;

    .line 399
    .line 400
    .line 401
    move-result-object p1

    .line 402
    check-cast p1, Lm0/f;

    .line 403
    .line 404
    invoke-virtual {p1, p2}, Landroidx/datastore/preferences/protobuf/b;->writeTo(Ljava/io/OutputStream;)V

    .line 405
    .line 406
    .line 407
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 408
    .line 409
    return-object p1
.end method
