.class public abstract LF0/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LF0/i;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LF0/i;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LF0/i;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LF0/j;->a:LF0/i;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public abstract a()Lcom/google/common/util/concurrent/ListenableFuture;
.end method

.method public abstract b(Landroid/net/Uri;)Lcom/google/common/util/concurrent/ListenableFuture;
.end method
