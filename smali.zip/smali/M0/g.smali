.class public final LM0/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final f:LM0/f;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ljava/lang/String;

.field public final c:LM0/d;

.field public final d:Z

.field public final e:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LM0/f;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LM0/f;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LM0/g;->f:LM0/f;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;LM0/d;ZZ)V
    .locals 1

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "callback"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, LM0/g;->a:Landroid/content/Context;

    .line 15
    .line 16
    iput-object p2, p0, LM0/g;->b:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p3, p0, LM0/g;->c:LM0/d;

    .line 19
    .line 20
    iput-boolean p4, p0, LM0/g;->d:Z

    .line 21
    .line 22
    iput-boolean p5, p0, LM0/g;->e:Z

    .line 23
    .line 24
    return-void
.end method
