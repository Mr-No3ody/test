.class public final LV0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/concurrent/Executor;

.field public final b:LWf/s;

.field public final c:Ljava/util/concurrent/ExecutorService;

.field public final d:LV0/p;

.field public final e:LV0/p;

.field public final f:LV0/p;

.field public final g:Ld3/k;

.field public final h:Landroidx/core/util/Consumer;

.field public final i:Landroidx/core/util/Consumer;

.field public final j:I

.field public final k:I

.field public final l:I

.field public final m:I

.field public final n:Z

.field public final o:LV0/p;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LV0/b;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LV0/b;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Ls5/d;)V
    .locals 4

    .line 1
    const-string v0, "builder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-static {v0}, LV0/e;->a(Z)Ljava/util/concurrent/ExecutorService;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, LV0/c;->a:Ljava/util/concurrent/Executor;

    .line 15
    .line 16
    sget-object v0, LWf/I;->a:Lcg/f;

    .line 17
    .line 18
    iput-object v0, p0, LV0/c;->b:LWf/s;

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    invoke-static {v0}, LV0/e;->a(Z)Ljava/util/concurrent/ExecutorService;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    iput-object v1, p0, LV0/c;->c:Ljava/util/concurrent/ExecutorService;

    .line 26
    .line 27
    new-instance v1, LV0/p;

    .line 28
    .line 29
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object v1, p0, LV0/c;->d:LV0/p;

    .line 33
    .line 34
    sget-object v1, LV0/p;->a:LV0/p;

    .line 35
    .line 36
    iput-object v1, p0, LV0/c;->e:LV0/p;

    .line 37
    .line 38
    sget-object v1, LV0/p;->b:LV0/p;

    .line 39
    .line 40
    iput-object v1, p0, LV0/c;->f:LV0/p;

    .line 41
    .line 42
    new-instance v1, Ld3/k;

    .line 43
    .line 44
    const/16 v2, 0x10

    .line 45
    .line 46
    const/4 v3, 0x0

    .line 47
    invoke-direct {v1, v3, v2}, Ld3/k;-><init>(BI)V

    .line 48
    .line 49
    .line 50
    iput-object v1, p0, LV0/c;->g:Ld3/k;

    .line 51
    .line 52
    const/4 v1, 0x4

    .line 53
    iput v1, p0, LV0/c;->j:I

    .line 54
    .line 55
    const v1, 0x7fffffff

    .line 56
    .line 57
    .line 58
    iput v1, p0, LV0/c;->k:I

    .line 59
    .line 60
    const/16 v1, 0x14

    .line 61
    .line 62
    iput v1, p0, LV0/c;->m:I

    .line 63
    .line 64
    iget-object v1, p1, Ls5/d;->b:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v1, Landroidx/core/util/Consumer;

    .line 67
    .line 68
    iput-object v1, p0, LV0/c;->h:Landroidx/core/util/Consumer;

    .line 69
    .line 70
    iget-object p1, p1, Ls5/d;->c:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast p1, Landroidx/core/util/Consumer;

    .line 73
    .line 74
    iput-object p1, p0, LV0/c;->i:Landroidx/core/util/Consumer;

    .line 75
    .line 76
    const/16 p1, 0x8

    .line 77
    .line 78
    iput p1, p0, LV0/c;->l:I

    .line 79
    .line 80
    iput-boolean v0, p0, LV0/c;->n:Z

    .line 81
    .line 82
    new-instance p1, LV0/p;

    .line 83
    .line 84
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 85
    .line 86
    .line 87
    iput-object p1, p0, LV0/c;->o:LV0/p;

    .line 88
    .line 89
    return-void
.end method
