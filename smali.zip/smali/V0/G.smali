.class public final LV0/G;
.super LV0/X;
.source "SourceFile"


# static fields
.field public static final e:LV0/F;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LV0/F;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LV0/F;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LV0/G;->e:LV0/F;

    .line 8
    .line 9
    return-void
.end method
