.class public abstract LV0/U;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LV0/T;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LV0/T;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LV0/T;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LV0/U;->a:LV0/T;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public abstract a()Lp1/d;
.end method

.method public abstract b()Lp1/d;
.end method

.method public abstract c(LV0/M;)Landroidx/work/Operation;
.end method

.method public final d(Ljava/lang/String;LV0/G;)Landroidx/work/Operation;
    .locals 3

    .line 1
    sget-object v0, LV0/r;->b:LV0/r;

    .line 2
    .line 3
    const-string/jumbo v1, "uniqueWorkName"

    .line 4
    .line 5
    .line 6
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    const-string v1, "existingWorkPolicy"

    .line 10
    .line 11
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v1, "request"

    .line 15
    .line 16
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-static {p2}, Lkotlin/collections/p;->c(Ljava/lang/Object;)Ljava/util/List;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    move-object v1, p0

    .line 24
    check-cast v1, Landroidx/work/impl/s;

    .line 25
    .line 26
    new-instance v2, Landroidx/work/impl/n;

    .line 27
    .line 28
    invoke-direct {v2, v1, p1, v0, p2}, Landroidx/work/impl/n;-><init>(Landroidx/work/impl/s;Ljava/lang/String;LV0/r;Ljava/util/List;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v2}, Landroidx/work/impl/n;->E()Landroidx/work/Operation;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    return-object p1
.end method

.method public abstract e(Ljava/lang/String;)Landroidx/concurrent/futures/m;
.end method
