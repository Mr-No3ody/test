.class public abstract LV0/V;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, LV0/V;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;)V
    .locals 37

    move-object/from16 v0, p0

    const-string/jumbo v1, "workerClass"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    const-string v3, "randomUUID()"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v1, v0, LV0/V;->a:Ljava/lang/Object;

    .line 5
    new-instance v4, Landroidx/work/impl/model/k;

    iget-object v1, v0, LV0/V;->a:Ljava/lang/Object;

    check-cast v1, Ljava/util/UUID;

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v1, "id.toString()"

    invoke-static {v5, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v7

    const-string/jumbo v1, "workerClass.name"

    invoke-static {v7, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    const-string v3, "id"

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string/jumbo v3, "workerClassName_"

    invoke-static {v7, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v33, 0x0

    const v36, 0xfffffa

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const-wide/16 v20, 0x0

    const-wide/16 v22, 0x0

    const-wide/16 v24, 0x0

    const-wide/16 v26, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    .line 7
    invoke-direct/range {v4 .. v36}, Landroidx/work/impl/model/k;-><init>(Ljava/lang/String;LV0/Q;Ljava/lang/String;Ljava/lang/String;LV0/n;LV0/n;JJJLV0/h;ILV0/a;JJJJZLV0/K;IJIILjava/lang/String;I)V

    .line 8
    iput-object v4, v0, LV0/V;->b:Ljava/lang/Object;

    .line 9
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    filled-new-array {v2}, [Ljava/lang/String;

    move-result-object v1

    .line 10
    const-string v2, "elements"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    new-instance v2, Ljava/util/LinkedHashSet;

    const/4 v3, 0x1

    invoke-static {v3}, Lkotlin/collections/F;->a(I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/LinkedHashSet;-><init>(I)V

    const-string v3, "<this>"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "destination"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    .line 12
    aget-object v1, v1, v3

    .line 13
    invoke-interface {v2, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 14
    iput-object v2, v0, LV0/V;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a()LV0/X;
    .locals 40

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual {v0}, LV0/V;->b()LV0/X;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    iget-object v2, v0, LV0/V;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, Landroidx/work/impl/model/k;

    .line 10
    .line 11
    iget-object v2, v2, Landroidx/work/impl/model/k;->j:LV0/h;

    .line 12
    .line 13
    iget-object v3, v2, LV0/h;->i:Ljava/util/Set;

    .line 14
    .line 15
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    if-eqz v3, :cond_1

    .line 20
    .line 21
    iget-boolean v3, v2, LV0/h;->e:Z

    .line 22
    .line 23
    if-nez v3, :cond_1

    .line 24
    .line 25
    iget-boolean v3, v2, LV0/h;->c:Z

    .line 26
    .line 27
    if-nez v3, :cond_1

    .line 28
    .line 29
    iget-boolean v2, v2, LV0/h;->d:Z

    .line 30
    .line 31
    if-eqz v2, :cond_0

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const/4 v2, 0x0

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    :goto_0
    const/4 v2, 0x1

    .line 37
    :goto_1
    iget-object v3, v0, LV0/V;->b:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v3, Landroidx/work/impl/model/k;

    .line 40
    .line 41
    iget-boolean v4, v3, Landroidx/work/impl/model/k;->q:Z

    .line 42
    .line 43
    if-eqz v4, :cond_4

    .line 44
    .line 45
    if-nez v2, :cond_3

    .line 46
    .line 47
    iget-wide v4, v3, Landroidx/work/impl/model/k;->g:J

    .line 48
    .line 49
    const-wide/16 v6, 0x0

    .line 50
    .line 51
    cmp-long v2, v4, v6

    .line 52
    .line 53
    if-gtz v2, :cond_2

    .line 54
    .line 55
    goto :goto_2

    .line 56
    :cond_2
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 57
    .line 58
    const-string v2, "Expedited jobs cannot be delayed"

    .line 59
    .line 60
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    throw v1

    .line 64
    :cond_3
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 65
    .line 66
    const-string v2, "Expedited jobs only support network and storage constraints"

    .line 67
    .line 68
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    throw v1

    .line 72
    :cond_4
    :goto_2
    iget-object v2, v3, Landroidx/work/impl/model/k;->x:Ljava/lang/String;

    .line 73
    .line 74
    if-nez v2, :cond_5

    .line 75
    .line 76
    sget-object v2, LV0/X;->d:LV0/W;

    .line 77
    .line 78
    iget-object v4, v3, Landroidx/work/impl/model/k;->c:Ljava/lang/String;

    .line 79
    .line 80
    invoke-static {v2, v4}, LV0/W;->access$deriveTraceTagFromClassName(LV0/W;Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    iput-object v2, v3, Landroidx/work/impl/model/k;->x:Ljava/lang/String;

    .line 85
    .line 86
    :cond_5
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    const-string v3, "randomUUID()"

    .line 91
    .line 92
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    const-string v3, "id"

    .line 96
    .line 97
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    iput-object v2, v0, LV0/V;->a:Ljava/lang/Object;

    .line 101
    .line 102
    new-instance v4, Landroidx/work/impl/model/k;

    .line 103
    .line 104
    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v5

    .line 108
    const-string v2, "id.toString()"

    .line 109
    .line 110
    invoke-static {v5, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    iget-object v2, v0, LV0/V;->b:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v2, Landroidx/work/impl/model/k;

    .line 116
    .line 117
    const-string v3, "newId"

    .line 118
    .line 119
    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    const-string v3, "other"

    .line 123
    .line 124
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    iget-object v7, v2, Landroidx/work/impl/model/k;->c:Ljava/lang/String;

    .line 128
    .line 129
    iget-object v6, v2, Landroidx/work/impl/model/k;->b:LV0/Q;

    .line 130
    .line 131
    new-instance v9, LV0/n;

    .line 132
    .line 133
    iget-object v3, v2, Landroidx/work/impl/model/k;->e:LV0/n;

    .line 134
    .line 135
    invoke-direct {v9, v3}, LV0/n;-><init>(LV0/n;)V

    .line 136
    .line 137
    .line 138
    new-instance v10, LV0/n;

    .line 139
    .line 140
    iget-object v3, v2, Landroidx/work/impl/model/k;->f:LV0/n;

    .line 141
    .line 142
    invoke-direct {v10, v3}, LV0/n;-><init>(LV0/n;)V

    .line 143
    .line 144
    .line 145
    iget-wide v11, v2, Landroidx/work/impl/model/k;->g:J

    .line 146
    .line 147
    iget-wide v13, v2, Landroidx/work/impl/model/k;->h:J

    .line 148
    .line 149
    move-object v8, v4

    .line 150
    iget-wide v3, v2, Landroidx/work/impl/model/k;->i:J

    .line 151
    .line 152
    new-instance v15, LV0/h;

    .line 153
    .line 154
    move-object/from16 v37, v1

    .line 155
    .line 156
    iget-object v1, v2, Landroidx/work/impl/model/k;->j:LV0/h;

    .line 157
    .line 158
    invoke-direct {v15, v1}, LV0/h;-><init>(LV0/h;)V

    .line 159
    .line 160
    .line 161
    move-wide/from16 v16, v3

    .line 162
    .line 163
    iget-wide v3, v2, Landroidx/work/impl/model/k;->n:J

    .line 164
    .line 165
    iget-boolean v1, v2, Landroidx/work/impl/model/k;->q:Z

    .line 166
    .line 167
    move-wide/from16 v22, v3

    .line 168
    .line 169
    iget-wide v3, v2, Landroidx/work/impl/model/k;->u:J

    .line 170
    .line 171
    move/from16 v28, v1

    .line 172
    .line 173
    iget v1, v2, Landroidx/work/impl/model/k;->v:I

    .line 174
    .line 175
    move/from16 v33, v1

    .line 176
    .line 177
    iget-object v1, v2, Landroidx/work/impl/model/k;->x:Ljava/lang/String;

    .line 178
    .line 179
    move-wide/from16 v31, v3

    .line 180
    .line 181
    move-object v4, v8

    .line 182
    iget-object v8, v2, Landroidx/work/impl/model/k;->d:Ljava/lang/String;

    .line 183
    .line 184
    iget v3, v2, Landroidx/work/impl/model/k;->k:I

    .line 185
    .line 186
    move-object/from16 v35, v1

    .line 187
    .line 188
    iget-object v1, v2, Landroidx/work/impl/model/k;->l:LV0/a;

    .line 189
    .line 190
    move/from16 v19, v3

    .line 191
    .line 192
    move-object/from16 v18, v4

    .line 193
    .line 194
    iget-wide v3, v2, Landroidx/work/impl/model/k;->m:J

    .line 195
    .line 196
    move-wide/from16 v20, v3

    .line 197
    .line 198
    iget-wide v3, v2, Landroidx/work/impl/model/k;->o:J

    .line 199
    .line 200
    move-wide/from16 v24, v3

    .line 201
    .line 202
    iget-wide v3, v2, Landroidx/work/impl/model/k;->p:J

    .line 203
    .line 204
    move-object/from16 v26, v1

    .line 205
    .line 206
    iget-object v1, v2, Landroidx/work/impl/model/k;->r:LV0/K;

    .line 207
    .line 208
    move-object/from16 v29, v1

    .line 209
    .line 210
    iget v1, v2, Landroidx/work/impl/model/k;->s:I

    .line 211
    .line 212
    iget v2, v2, Landroidx/work/impl/model/k;->w:I

    .line 213
    .line 214
    const/high16 v36, 0x80000

    .line 215
    .line 216
    move-wide/from16 v38, v3

    .line 217
    .line 218
    move-object/from16 v4, v18

    .line 219
    .line 220
    move/from16 v18, v19

    .line 221
    .line 222
    move-object/from16 v19, v26

    .line 223
    .line 224
    move-wide/from16 v26, v38

    .line 225
    .line 226
    move-wide/from16 v38, v16

    .line 227
    .line 228
    move-object/from16 v17, v15

    .line 229
    .line 230
    move-wide/from16 v15, v38

    .line 231
    .line 232
    move/from16 v30, v1

    .line 233
    .line 234
    move/from16 v34, v2

    .line 235
    .line 236
    invoke-direct/range {v4 .. v36}, Landroidx/work/impl/model/k;-><init>(Ljava/lang/String;LV0/Q;Ljava/lang/String;Ljava/lang/String;LV0/n;LV0/n;JJJLV0/h;ILV0/a;JJJJZLV0/K;IJIILjava/lang/String;I)V

    .line 237
    .line 238
    .line 239
    iput-object v4, v0, LV0/V;->b:Ljava/lang/Object;

    .line 240
    .line 241
    return-object v37
.end method

.method public abstract b()LV0/X;
.end method

.method public c(Landroid/view/MenuItem;)Landroid/view/MenuItem;
    .locals 2

    .line 1
    instance-of v0, p1, Landroidx/core/internal/view/SupportMenuItem;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    check-cast p1, Landroidx/core/internal/view/SupportMenuItem;

    .line 6
    .line 7
    iget-object v0, p0, LV0/V;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, LM/n;

    .line 10
    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    new-instance v0, LM/n;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-direct {v0, v1}, LM/n;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, LV0/V;->b:Ljava/lang/Object;

    .line 20
    .line 21
    :cond_0
    iget-object v0, p0, LV0/V;->b:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, LM/n;

    .line 24
    .line 25
    invoke-virtual {v0, p1}, LM/n;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Landroid/view/MenuItem;

    .line 30
    .line 31
    if-nez v0, :cond_1

    .line 32
    .line 33
    new-instance v0, Landroidx/appcompat/view/menu/q;

    .line 34
    .line 35
    iget-object v1, p0, LV0/V;->a:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v1, Landroid/content/Context;

    .line 38
    .line 39
    invoke-direct {v0, v1, p1}, Landroidx/appcompat/view/menu/q;-><init>(Landroid/content/Context;Landroidx/core/internal/view/SupportMenuItem;)V

    .line 40
    .line 41
    .line 42
    iget-object v1, p0, LV0/V;->b:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v1, LM/n;

    .line 45
    .line 46
    invoke-virtual {v1, p1, v0}, LM/n;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    :cond_1
    return-object v0

    .line 50
    :cond_2
    return-object p1
.end method

.method public d(Landroid/view/SubMenu;)Landroid/view/SubMenu;
    .locals 2

    .line 1
    instance-of v0, p1, Landroidx/core/internal/view/SupportSubMenu;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    check-cast p1, Landroidx/core/internal/view/SupportSubMenu;

    .line 6
    .line 7
    iget-object v0, p0, LV0/V;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, LM/n;

    .line 10
    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    new-instance v0, LM/n;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-direct {v0, v1}, LM/n;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, LV0/V;->c:Ljava/lang/Object;

    .line 20
    .line 21
    :cond_0
    iget-object v0, p0, LV0/V;->c:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, LM/n;

    .line 24
    .line 25
    invoke-virtual {v0, p1}, LM/n;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Landroid/view/SubMenu;

    .line 30
    .line 31
    if-nez v0, :cond_1

    .line 32
    .line 33
    new-instance v0, Landroidx/appcompat/view/menu/x;

    .line 34
    .line 35
    iget-object v1, p0, LV0/V;->a:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v1, Landroid/content/Context;

    .line 38
    .line 39
    invoke-direct {v0, v1, p1}, Landroidx/appcompat/view/menu/x;-><init>(Landroid/content/Context;Landroidx/core/internal/view/SupportSubMenu;)V

    .line 40
    .line 41
    .line 42
    iget-object v1, p0, LV0/V;->c:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v1, LM/n;

    .line 45
    .line 46
    invoke-virtual {v1, p1, v0}, LM/n;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    :cond_1
    return-object v0

    .line 50
    :cond_2
    return-object p1
.end method
