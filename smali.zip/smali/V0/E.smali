.class public final LV0/E;
.super LV0/V;
.source "SourceFile"


# instance fields
.field public final synthetic d:I


# direct methods
.method public constructor <init>()V
    .locals 12

    const/4 v0, 0x1

    iput v0, p0, LV0/E;->d:I

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const-string/jumbo v1, "workerClass"

    const-class v2, Lcom/transsnet/palmpay/core/task/PeriodWakeUpWorker;

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "repeatIntervalTimeUnit"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "flexIntervalTimeUnit"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0, v2}, LV0/V;-><init>(Ljava/lang/Class;)V

    .line 4
    iget-object v1, p0, LV0/V;->b:Ljava/lang/Object;

    check-cast v1, Landroidx/work/impl/model/k;

    const-wide/16 v2, 0x1e

    .line 5
    invoke-virtual {v0, v2, v3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v2

    const-wide/16 v4, 0xa

    .line 6
    invoke-virtual {v0, v4, v5}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v6

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/32 v4, 0xdbba0

    cmp-long v0, v2, v4

    if-gez v0, :cond_0

    .line 8
    invoke-static {}, LV0/C;->c()LV0/C;

    move-result-object v8

    .line 9
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_0
    if-gez v0, :cond_1

    move-wide v2, v4

    .line 10
    :cond_1
    iput-wide v2, v1, Landroidx/work/impl/model/k;->h:J

    const-wide/32 v2, 0x493e0

    cmp-long v0, v6, v2

    if-gez v0, :cond_2

    .line 11
    invoke-static {}, LV0/C;->c()LV0/C;

    move-result-object v0

    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    :cond_2
    iget-wide v2, v1, Landroidx/work/impl/model/k;->h:J

    cmp-long v0, v6, v2

    if-lez v0, :cond_3

    .line 14
    invoke-static {}, LV0/C;->c()LV0/C;

    move-result-object v0

    .line 15
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_3
    const-wide/32 v8, 0x493e0

    .line 16
    iget-wide v10, v1, Landroidx/work/impl/model/k;->h:J

    invoke-static/range {v6 .. v11}, Lkotlin/ranges/b;->d(JJJ)J

    move-result-wide v2

    iput-wide v2, v1, Landroidx/work/impl/model/k;->i:J

    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LV0/E;->d:I

    const-string/jumbo v0, "workerClass"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    invoke-direct {p0, p1}, LV0/V;-><init>(Ljava/lang/Class;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Class;Z)V
    .locals 0

    .line 1
    const/4 p2, 0x0

    iput p2, p0, LV0/E;->d:I

    invoke-direct {p0, p1}, LV0/V;-><init>(Ljava/lang/Class;)V

    return-void
.end method


# virtual methods
.method public final b()LV0/X;
    .locals 4

    .line 1
    iget v0, p0, LV0/E;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LV0/V;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroidx/work/impl/model/k;

    .line 9
    .line 10
    iget-boolean v0, v0, Landroidx/work/impl/model/k;->q:Z

    .line 11
    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    new-instance v0, LV0/M;

    .line 15
    .line 16
    const-string v1, "builder"

    .line 17
    .line 18
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object v1, p0, LV0/V;->a:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v1, Ljava/util/UUID;

    .line 24
    .line 25
    iget-object v2, p0, LV0/V;->b:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v2, Landroidx/work/impl/model/k;

    .line 28
    .line 29
    iget-object v3, p0, LV0/V;->c:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v3, Ljava/util/Set;

    .line 32
    .line 33
    invoke-direct {v0, v1, v2, v3}, LV0/X;-><init>(Ljava/util/UUID;Landroidx/work/impl/model/k;Ljava/util/Set;)V

    .line 34
    .line 35
    .line 36
    return-object v0

    .line 37
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 38
    .line 39
    const-string v1, "PeriodicWorkRequests cannot be expedited"

    .line 40
    .line 41
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw v0

    .line 45
    :pswitch_0
    new-instance v0, LV0/G;

    .line 46
    .line 47
    const-string v1, "builder"

    .line 48
    .line 49
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, LV0/V;->a:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v1, Ljava/util/UUID;

    .line 55
    .line 56
    iget-object v2, p0, LV0/V;->b:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v2, Landroidx/work/impl/model/k;

    .line 59
    .line 60
    iget-object v3, p0, LV0/V;->c:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v3, Ljava/util/Set;

    .line 63
    .line 64
    invoke-direct {v0, v1, v2, v3}, LV0/X;-><init>(Ljava/util/UUID;Landroidx/work/impl/model/k;Ljava/util/Set;)V

    .line 65
    .line 66
    .line 67
    return-object v0

    .line 68
    nop

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
