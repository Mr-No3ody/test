.class public abstract LV0/A;
.super Ljava/lang/Object;
.source "SourceFile"
