.class public final LV0/N;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static enable_system_alarm_service_default:I = 0x7f050008

.field public static enable_system_foreground_service_default:I = 0x7f050009

.field public static enable_system_job_service_default:I = 0x7f05000a

.field public static workmanager_test_configuration:I = 0x7f05000d


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
