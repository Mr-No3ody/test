.class public final synthetic LV0/J;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;
.implements Lcom/google/android/gms/tasks/Continuation;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p6, p0, LV0/J;->a:I

    iput-object p1, p0, LV0/J;->b:Ljava/lang/Object;

    iput-object p2, p0, LV0/J;->c:Ljava/lang/Object;

    iput-object p3, p0, LV0/J;->d:Ljava/lang/Object;

    iput-object p4, p0, LV0/J;->e:Ljava/lang/Object;

    iput-object p5, p0, LV0/J;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public attachCompleter(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .locals 10

    .line 1
    iget v0, p0, LV0/J;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LV0/J;->b:Ljava/lang/Object;

    .line 7
    .line 8
    move-object v1, v0

    .line 9
    check-cast v1, Landroidx/camera/video/E;

    .line 10
    .line 11
    iget-object v0, p0, LV0/J;->c:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, LE/m0;

    .line 14
    .line 15
    iget-object v7, v0, LE/m0;->c:LE/v;

    .line 16
    .line 17
    iget-object v2, p0, LV0/J;->e:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Landroidx/camera/video/internal/d;

    .line 20
    .line 21
    iget-object v3, p0, LV0/J;->f:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v3, Landroidx/camera/video/e;

    .line 24
    .line 25
    invoke-static {v3, v7, v2}, Landroidx/camera/video/internal/config/b;->b(Landroidx/camera/video/e;LE/v;Landroidx/camera/video/internal/d;)Landroidx/camera/video/internal/config/a;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    move-object v4, v3

    .line 30
    iget-object v3, v2, Landroidx/camera/video/internal/config/a;->a:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v5, v4, Landroidx/camera/video/e;->a:Landroidx/camera/video/j;

    .line 33
    .line 34
    iget-object v6, v0, LE/m0;->b:Landroid/util/Size;

    .line 35
    .line 36
    iget-object v4, p0, LV0/J;->d:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v4, Landroidx/camera/core/impl/P0;

    .line 39
    .line 40
    iget-object v8, v0, LE/m0;->d:Landroid/util/Range;

    .line 41
    .line 42
    iget-object v2, v2, Landroidx/camera/video/internal/config/a;->c:Landroidx/camera/core/impl/f;

    .line 43
    .line 44
    if-eqz v2, :cond_0

    .line 45
    .line 46
    move-object v9, v8

    .line 47
    move-object v8, v7

    .line 48
    move-object v7, v2

    .line 49
    new-instance v2, Landroidx/appcompat/widget/m1;

    .line 50
    .line 51
    invoke-direct/range {v2 .. v9}, Landroidx/appcompat/widget/m1;-><init>(Ljava/lang/String;Landroidx/camera/core/impl/P0;Landroidx/camera/video/j;Landroid/util/Size;Landroidx/camera/core/impl/f;LE/v;Landroid/util/Range;)V

    .line 52
    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_0
    move-object v9, v8

    .line 56
    move-object v8, v7

    .line 57
    new-instance v2, Landroidx/camera/video/internal/config/c;

    .line 58
    .line 59
    move-object v8, v9

    .line 60
    invoke-direct/range {v2 .. v8}, Landroidx/camera/video/internal/config/c;-><init>(Ljava/lang/String;Landroidx/camera/core/impl/P0;Landroidx/camera/video/j;Landroid/util/Size;LE/v;Landroid/util/Range;)V

    .line 61
    .line 62
    .line 63
    :goto_0
    invoke-interface {v2}, Landroidx/core/util/Supplier;->get()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    check-cast v2, Landroidx/camera/video/internal/encoder/d;

    .line 68
    .line 69
    :try_start_0
    iget-object v3, v1, Landroidx/camera/video/E;->c:LB8/d;

    .line 70
    .line 71
    iget-object v4, v1, Landroidx/camera/video/E;->a:Ljava/util/concurrent/Executor;

    .line 72
    .line 73
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 74
    .line 75
    .line 76
    new-instance v3, Landroidx/camera/video/internal/encoder/v;

    .line 77
    .line 78
    invoke-direct {v3, v4, v2}, Landroidx/camera/video/internal/encoder/v;-><init>(Ljava/util/concurrent/Executor;Landroidx/camera/video/internal/encoder/EncoderConfig;)V

    .line 79
    .line 80
    .line 81
    iput-object v3, v1, Landroidx/camera/video/E;->d:Landroidx/camera/video/internal/encoder/Encoder;
    :try_end_0
    .catch Landroidx/camera/video/internal/encoder/x; {:try_start_0 .. :try_end_0} :catch_0

    .line 82
    .line 83
    iget-object v2, v3, Landroidx/camera/video/internal/encoder/v;->f:Landroidx/camera/video/internal/encoder/Encoder$EncoderInput;

    .line 84
    .line 85
    instance-of v3, v2, Landroidx/camera/video/internal/encoder/Encoder$SurfaceInput;

    .line 86
    .line 87
    if-nez v3, :cond_1

    .line 88
    .line 89
    new-instance v0, Ljava/lang/AssertionError;

    .line 90
    .line 91
    const-string v2, "The EncoderInput of video isn\'t a SurfaceInput."

    .line 92
    .line 93
    invoke-direct {v0, v2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/k;->d(Ljava/lang/Throwable;)Z

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_1
    check-cast v2, Landroidx/camera/video/internal/encoder/Encoder$SurfaceInput;

    .line 101
    .line 102
    new-instance v3, La;

    .line 103
    .line 104
    const/16 v4, 0x9

    .line 105
    .line 106
    invoke-direct {v3, v1, v4, p1, v0}, La;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    iget-object p1, v1, Landroidx/camera/video/E;->b:Landroidx/camera/core/impl/utils/executor/i;

    .line 110
    .line 111
    invoke-interface {v2, p1, v3}, Landroidx/camera/video/internal/encoder/Encoder$SurfaceInput;->setOnSurfaceUpdateListener(Ljava/util/concurrent/Executor;Landroidx/camera/video/internal/encoder/Encoder$SurfaceInput$OnSurfaceUpdateListener;)V

    .line 112
    .line 113
    .line 114
    goto :goto_1

    .line 115
    :catch_0
    move-exception v0

    .line 116
    const-string v2, "VideoEncoderSession"

    .line 117
    .line 118
    const-string v3, "Unable to initialize video encoder."

    .line 119
    .line 120
    invoke-static {v2, v3, v0}, Lj8/f;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {p1, v0}, Landroidx/concurrent/futures/k;->d(Ljava/lang/Throwable;)Z

    .line 124
    .line 125
    .line 126
    :goto_1
    new-instance p1, Ljava/lang/StringBuilder;

    .line 127
    .line 128
    const-string v0, "ConfigureVideoEncoderFuture "

    .line 129
    .line 130
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 134
    .line 135
    .line 136
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    return-object p1

    .line 141
    :pswitch_0
    const-string v0, "completer"

    .line 142
    .line 143
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    new-instance v1, LDa/a;

    .line 147
    .line 148
    iget-object v0, p0, LV0/J;->e:Ljava/lang/Object;

    .line 149
    .line 150
    move-object v4, v0

    .line 151
    check-cast v4, Lkotlin/jvm/functions/Function0;

    .line 152
    .line 153
    iget-object v0, p0, LV0/J;->f:Ljava/lang/Object;

    .line 154
    .line 155
    move-object v5, v0

    .line 156
    check-cast v5, Landroidx/lifecycle/F;

    .line 157
    .line 158
    iget-object v0, p0, LV0/J;->c:Ljava/lang/Object;

    .line 159
    .line 160
    move-object v2, v0

    .line 161
    check-cast v2, Landroidx/work/Tracer;

    .line 162
    .line 163
    iget-object v0, p0, LV0/J;->d:Ljava/lang/Object;

    .line 164
    .line 165
    move-object v3, v0

    .line 166
    check-cast v3, Ljava/lang/String;

    .line 167
    .line 168
    const/4 v7, 0x1

    .line 169
    move-object v6, p1

    .line 170
    invoke-direct/range {v1 .. v7}, LDa/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 171
    .line 172
    .line 173
    iget-object p1, p0, LV0/J;->b:Ljava/lang/Object;

    .line 174
    .line 175
    check-cast p1, Landroidx/work/impl/utils/taskexecutor/SerialExecutor;

    .line 176
    .line 177
    invoke-interface {p1, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 178
    .line 179
    .line 180
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 181
    .line 182
    return-object p1

    .line 183
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public then(Lcom/google/android/gms/tasks/Task;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v0, p0, LV0/J;->e:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Ljava/util/Date;

    iget-object v0, p0, LV0/J;->b:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;

    iget-object v0, p0, LV0/J;->c:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Lcom/google/android/gms/tasks/Task;

    iget-object v0, p0, LV0/J;->d:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lcom/google/android/gms/tasks/Task;

    iget-object v0, p0, LV0/J;->f:Ljava/lang/Object;

    move-object v5, v0

    check-cast v5, Ljava/util/Map;

    move-object v6, p1

    invoke-static/range {v1 .. v6}, Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;->a(Lcom/google/firebase/remoteconfig/internal/ConfigFetchHandler;Lcom/google/android/gms/tasks/Task;Lcom/google/android/gms/tasks/Task;Ljava/util/Date;Ljava/util/Map;Lcom/google/android/gms/tasks/Task;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    return-object p1
.end method
