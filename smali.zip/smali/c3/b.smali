.class public abstract Lc3/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(IILandroid/graphics/Bitmap$Config;)Lcom/facebook/common/references/CloseableReference;
.end method
