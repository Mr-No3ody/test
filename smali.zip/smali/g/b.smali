.class public abstract Lg/b;
.super Landroid/os/Binder;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/app/INotificationSideChannel;


# static fields
.field public static final synthetic a:I
