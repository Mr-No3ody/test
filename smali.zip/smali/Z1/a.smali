.class public abstract LZ1/a;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "SourceFile"

# interfaces
.implements Lcom/daimajia/swipe/interfaces/SwipeItemMangerInterface;
.implements Lcom/daimajia/swipe/interfaces/SwipeAdapterInterface;


# instance fields
.field public final a:La2/d;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, La2/d;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    sget-object v1, Lb2/a;->a:Lb2/a;

    .line 10
    .line 11
    iput-object v1, v0, La2/d;->a:Lb2/a;

    .line 12
    .line 13
    const/4 v1, -0x1

    .line 14
    iput v1, v0, La2/d;->b:I

    .line 15
    .line 16
    new-instance v1, Ljava/util/HashSet;

    .line 17
    .line 18
    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object v1, v0, La2/d;->c:Ljava/util/HashSet;

    .line 22
    .line 23
    new-instance v1, Ljava/util/HashSet;

    .line 24
    .line 25
    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object v1, v0, La2/d;->d:Ljava/util/HashSet;

    .line 29
    .line 30
    iput-object p0, v0, La2/d;->e:LZ1/a;

    .line 31
    .line 32
    iput-object v0, p0, LZ1/a;->a:La2/d;

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final closeAllExcept(Lcom/daimajia/swipe/SwipeLayout;)V
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La2/d;->closeAllExcept(Lcom/daimajia/swipe/SwipeLayout;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final closeAllItems()V
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0}, La2/d;->closeAllItems()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final closeItem(I)V
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La2/d;->closeItem(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final getMode()Lb2/a;
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    iget-object v0, v0, La2/d;->a:Lb2/a;

    .line 4
    .line 5
    return-object v0
.end method

.method public final getOpenItems()Ljava/util/List;
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0}, La2/d;->getOpenItems()Ljava/util/List;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final getOpenLayouts()Ljava/util/List;
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0}, La2/d;->getOpenLayouts()Ljava/util/List;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final isOpen(I)Z
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La2/d;->isOpen(I)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final openItem(I)V
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La2/d;->openItem(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final removeShownLayouts(Lcom/daimajia/swipe/SwipeLayout;)V
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La2/d;->removeShownLayouts(Lcom/daimajia/swipe/SwipeLayout;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final setMode(Lb2/a;)V
    .locals 1

    .line 1
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, La2/d;->setMode(Lb2/a;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
