.class public final synthetic Lm1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/airbnb/lottie/LottieOnCompositionLoadedListener;


# instance fields
.field public final synthetic a:Lcom/airbnb/lottie/LottieAnimationView;


# direct methods
.method public synthetic constructor <init>(Lcom/airbnb/lottie/LottieAnimationView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lm1/a;->a:Lcom/airbnb/lottie/LottieAnimationView;

    return-void
.end method


# virtual methods
.method public final onCompositionLoaded(Lcom/airbnb/lottie/k;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lm1/a;->a:Lcom/airbnb/lottie/LottieAnimationView;

    invoke-static {v0, p1}, Lcom/airbnb/android/react/lottie/LottieAnimationViewManager;->b(Lcom/airbnb/lottie/LottieAnimationView;Lcom/airbnb/lottie/k;)V

    return-void
.end method
