.class public final Lm1/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/animation/Animator$AnimatorListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/KeyEvent$Callback;


# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;I)V
    .locals 0

    .line 1
    iput p2, p0, Lm1/b;->a:I

    iput-object p1, p0, Lm1/b;->b:Landroid/view/KeyEvent$Callback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationCancel(Landroid/animation/Animator;)V
    .locals 1

    .line 1
    iget v0, p0, Lm1/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "p0"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    const-string v0, "animation"

    .line 13
    .line 14
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object p1, p0, Lm1/b;->b:Landroid/view/KeyEvent$Callback;

    .line 18
    .line 19
    check-cast p1, Lcom/airbnb/lottie/LottieAnimationView;

    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    invoke-static {p1, v0}, Lm1/e;->a(Lcom/airbnb/lottie/LottieAnimationView;Z)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    nop

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 12

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lm1/b;->b:Landroid/view/KeyEvent$Callback;

    .line 3
    .line 4
    iget v2, p0, Lm1/b;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    const-string v2, "p0"

    .line 10
    .line 11
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    sget-object p1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->q0:Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity$a;

    .line 15
    .line 16
    check-cast v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;

    .line 17
    .line 18
    invoke-virtual {v1}, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->o()Landroid/widget/ImageView;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    const-string v2, "jp_pickcard_result_title.webp"

    .line 23
    .line 24
    invoke-static {v2}, LPa/r0;->y0(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    sget v3, Lpc/c;->jp_pickcard_result_title:I

    .line 29
    .line 30
    invoke-static {p1, v2, v3}, LPa/r0;->h1(Landroid/widget/ImageView;Ljava/lang/String;I)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1}, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->o()Landroid/widget/ImageView;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    const/4 v2, 0x1

    .line 38
    invoke-static {p1, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 39
    .line 40
    .line 41
    iget-object p1, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->f:Lxf/t;

    .line 42
    .line 43
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    const-string v3, "getValue(...)"

    .line 48
    .line 49
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    check-cast p1, Landroid/widget/ImageView;

    .line 53
    .line 54
    invoke-static {p1, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 55
    .line 56
    .line 57
    iget-object p1, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->p0:Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp;

    .line 58
    .line 59
    if-eqz p1, :cond_a

    .line 60
    .line 61
    invoke-virtual {p1}, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp;->isDialog1Type()Z

    .line 62
    .line 63
    .line 64
    move-result v4

    .line 65
    iget-object v5, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->j:Lxf/t;

    .line 66
    .line 67
    iget-object v6, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->i:Lxf/t;

    .line 68
    .line 69
    const/4 v7, 0x2

    .line 70
    const/4 v8, 0x3

    .line 71
    if-eqz v4, :cond_4

    .line 72
    .line 73
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    check-cast v4, Landroid/widget/TextView;

    .line 81
    .line 82
    sget v6, Lpc/f;->jp_invite_now:I

    .line 83
    .line 84
    invoke-virtual {v1, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v6

    .line 88
    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    check-cast v4, Landroid/widget/LinearLayout;

    .line 99
    .line 100
    invoke-static {v4, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 101
    .line 102
    .line 103
    iget-object v4, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->C:Lxf/t;

    .line 104
    .line 105
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v4

    .line 109
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    check-cast v4, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 113
    .line 114
    invoke-static {v4, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 115
    .line 116
    .line 117
    iget-object p1, p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp;->cardContextDTOS:Ljava/util/List;

    .line 118
    .line 119
    if-eqz p1, :cond_3

    .line 120
    .line 121
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 122
    .line 123
    .line 124
    move-result v4

    .line 125
    if-ne v4, v8, :cond_3

    .line 126
    .line 127
    iget-object v4, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->B:Lxf/t;

    .line 128
    .line 129
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v4

    .line 133
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    check-cast v4, Landroid/widget/TextView;

    .line 137
    .line 138
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;

    .line 143
    .line 144
    iget-object v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;->middleValue:Ljava/lang/Long;

    .line 145
    .line 146
    const/4 v5, 0x0

    .line 147
    if-eqz v0, :cond_0

    .line 148
    .line 149
    invoke-virtual {v0}, Ljava/lang/Long;->toString()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    goto :goto_0

    .line 154
    :cond_0
    move-object v0, v5

    .line 155
    :goto_0
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 156
    .line 157
    .line 158
    iget-object v0, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->A:Lxf/t;

    .line 159
    .line 160
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    check-cast v0, Landroid/widget/TextView;

    .line 168
    .line 169
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v2

    .line 173
    check-cast v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;

    .line 174
    .line 175
    iget-object v2, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;->middleValue:Ljava/lang/Long;

    .line 176
    .line 177
    if-eqz v2, :cond_1

    .line 178
    .line 179
    invoke-virtual {v2}, Ljava/lang/Long;->toString()Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v2

    .line 183
    goto :goto_1

    .line 184
    :cond_1
    move-object v2, v5

    .line 185
    :goto_1
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 186
    .line 187
    .line 188
    iget-object v0, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->w:Lxf/t;

    .line 189
    .line 190
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    check-cast v0, Landroid/widget/TextView;

    .line 198
    .line 199
    invoke-interface {p1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    check-cast p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;

    .line 204
    .line 205
    iget-object p1, p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;->middleValue:Ljava/lang/Long;

    .line 206
    .line 207
    if-eqz p1, :cond_2

    .line 208
    .line 209
    invoke-virtual {p1}, Ljava/lang/Long;->toString()Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object v5

    .line 213
    :cond_2
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 214
    .line 215
    .line 216
    :cond_3
    invoke-virtual {v1}, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->q()V

    .line 217
    .line 218
    .line 219
    goto/16 :goto_4

    .line 220
    .line 221
    :cond_4
    invoke-virtual {p1}, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp;->isDialog2Type()Z

    .line 222
    .line 223
    .line 224
    move-result v4

    .line 225
    if-eqz v4, :cond_9

    .line 226
    .line 227
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v4

    .line 231
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    check-cast v4, Landroid/widget/TextView;

    .line 235
    .line 236
    sget v6, Lba/k;->core_claim_now:I

    .line 237
    .line 238
    invoke-virtual {v1, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object v6

    .line 242
    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    move-result-object v4

    .line 249
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    check-cast v4, Landroid/widget/LinearLayout;

    .line 253
    .line 254
    invoke-static {v4, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 255
    .line 256
    .line 257
    iget-object v4, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->v:Lxf/t;

    .line 258
    .line 259
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v4

    .line 263
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    check-cast v4, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 267
    .line 268
    invoke-static {v4, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 269
    .line 270
    .line 271
    iget-object p1, p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp;->cardContextDTOS:Ljava/util/List;

    .line 272
    .line 273
    if-eqz p1, :cond_8

    .line 274
    .line 275
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 276
    .line 277
    .line 278
    move-result v4

    .line 279
    if-ne v4, v8, :cond_8

    .line 280
    .line 281
    iget-object v4, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->t:Lxf/t;

    .line 282
    .line 283
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object v4

    .line 287
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 288
    .line 289
    .line 290
    check-cast v4, Landroid/widget/TextView;

    .line 291
    .line 292
    new-instance v5, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 293
    .line 294
    invoke-direct {v5}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 295
    .line 296
    .line 297
    sget v6, Lba/k;->core_currency_char_nig:I

    .line 298
    .line 299
    invoke-virtual {v1, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object v6

    .line 303
    invoke-virtual {v5, v6}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 304
    .line 305
    .line 306
    move-result-object v5

    .line 307
    const/high16 v6, 0x41900000    # 18.0f

    .line 308
    .line 309
    invoke-static {v6}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 310
    .line 311
    .line 312
    move-result v6

    .line 313
    invoke-virtual {v5, v6}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 314
    .line 315
    .line 316
    move-result-object v5

    .line 317
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;

    .line 322
    .line 323
    iget-object v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;->middleValue:Ljava/lang/Long;

    .line 324
    .line 325
    const-wide/16 v8, 0x0

    .line 326
    .line 327
    if-eqz v0, :cond_5

    .line 328
    .line 329
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 330
    .line 331
    .line 332
    move-result-wide v10

    .line 333
    goto :goto_2

    .line 334
    :cond_5
    move-wide v10, v8

    .line 335
    :goto_2
    invoke-static {v10, v11}, LPa/r0;->E(J)Ljava/lang/String;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 340
    .line 341
    .line 342
    move-result-object v0

    .line 343
    const/high16 v5, 0x42200000    # 40.0f

    .line 344
    .line 345
    invoke-static {v5}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 346
    .line 347
    .line 348
    move-result v5

    .line 349
    invoke-virtual {v0, v5}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 350
    .line 351
    .line 352
    move-result-object v0

    .line 353
    invoke-virtual {v0}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 354
    .line 355
    .line 356
    move-result-object v0

    .line 357
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 358
    .line 359
    .line 360
    iget-object v0, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->p:Lxf/t;

    .line 361
    .line 362
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 363
    .line 364
    .line 365
    move-result-object v0

    .line 366
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 367
    .line 368
    .line 369
    check-cast v0, Landroid/widget/TextView;

    .line 370
    .line 371
    new-instance v4, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 372
    .line 373
    invoke-direct {v4}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 374
    .line 375
    .line 376
    sget v5, Lba/k;->core_currency_char_nig:I

    .line 377
    .line 378
    invoke-virtual {v1, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v5

    .line 382
    invoke-virtual {v4, v5}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 383
    .line 384
    .line 385
    move-result-object v4

    .line 386
    const/high16 v5, 0x41200000    # 10.0f

    .line 387
    .line 388
    invoke-static {v5}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 389
    .line 390
    .line 391
    move-result v6

    .line 392
    invoke-virtual {v4, v6}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 393
    .line 394
    .line 395
    move-result-object v4

    .line 396
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v2

    .line 400
    check-cast v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;

    .line 401
    .line 402
    iget-object v2, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;->middleValue:Ljava/lang/Long;

    .line 403
    .line 404
    if-eqz v2, :cond_6

    .line 405
    .line 406
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 407
    .line 408
    .line 409
    move-result-wide v10

    .line 410
    goto :goto_3

    .line 411
    :cond_6
    move-wide v10, v8

    .line 412
    :goto_3
    invoke-static {v10, v11}, LPa/r0;->E(J)Ljava/lang/String;

    .line 413
    .line 414
    .line 415
    move-result-object v2

    .line 416
    invoke-virtual {v4, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 417
    .line 418
    .line 419
    move-result-object v2

    .line 420
    const/high16 v4, 0x41b00000    # 22.0f

    .line 421
    .line 422
    invoke-static {v4}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 423
    .line 424
    .line 425
    move-result v6

    .line 426
    invoke-virtual {v2, v6}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 427
    .line 428
    .line 429
    move-result-object v2

    .line 430
    invoke-virtual {v2}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 431
    .line 432
    .line 433
    move-result-object v2

    .line 434
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 435
    .line 436
    .line 437
    iget-object v0, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->o:Lxf/t;

    .line 438
    .line 439
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 440
    .line 441
    .line 442
    move-result-object v0

    .line 443
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    check-cast v0, Landroid/widget/TextView;

    .line 447
    .line 448
    new-instance v2, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 449
    .line 450
    invoke-direct {v2}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 451
    .line 452
    .line 453
    sget v3, Lba/k;->core_currency_char_nig:I

    .line 454
    .line 455
    invoke-virtual {v1, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 456
    .line 457
    .line 458
    move-result-object v3

    .line 459
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 460
    .line 461
    .line 462
    move-result-object v2

    .line 463
    invoke-static {v5}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 464
    .line 465
    .line 466
    move-result v3

    .line 467
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 468
    .line 469
    .line 470
    move-result-object v2

    .line 471
    invoke-interface {p1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 472
    .line 473
    .line 474
    move-result-object p1

    .line 475
    check-cast p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;

    .line 476
    .line 477
    iget-object p1, p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp$ReferEarnHomeCardBean;->middleValue:Ljava/lang/Long;

    .line 478
    .line 479
    if-eqz p1, :cond_7

    .line 480
    .line 481
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 482
    .line 483
    .line 484
    move-result-wide v8

    .line 485
    :cond_7
    invoke-static {v8, v9}, LPa/r0;->E(J)Ljava/lang/String;

    .line 486
    .line 487
    .line 488
    move-result-object p1

    .line 489
    invoke-virtual {v2, p1}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 490
    .line 491
    .line 492
    move-result-object p1

    .line 493
    invoke-static {v4}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 494
    .line 495
    .line 496
    move-result v2

    .line 497
    invoke-virtual {p1, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 498
    .line 499
    .line 500
    move-result-object p1

    .line 501
    invoke-virtual {p1}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 502
    .line 503
    .line 504
    move-result-object p1

    .line 505
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 506
    .line 507
    .line 508
    :cond_8
    invoke-virtual {v1}, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->q()V

    .line 509
    .line 510
    .line 511
    goto :goto_4

    .line 512
    :cond_9
    invoke-virtual {p1}, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnHomeResp;->isDialog3Type()Z

    .line 513
    .line 514
    .line 515
    move-result p1

    .line 516
    if-eqz p1, :cond_a

    .line 517
    .line 518
    iget-object p1, v1, Lcom/transsnet/palmpay/jara_packet/ui/activity/ReferEarnRewardDialogActivity;->e:Lxf/t;

    .line 519
    .line 520
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 521
    .line 522
    .line 523
    move-result-object p1

    .line 524
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 525
    .line 526
    .line 527
    check-cast p1, Landroid/widget/RelativeLayout;

    .line 528
    .line 529
    invoke-static {p1, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 530
    .line 531
    .line 532
    :cond_a
    :goto_4
    return-void

    .line 533
    :pswitch_0
    const-string v2, "animation"

    .line 534
    .line 535
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 536
    .line 537
    .line 538
    check-cast v1, Lcom/airbnb/lottie/LottieAnimationView;

    .line 539
    .line 540
    invoke-static {v1, v0}, Lm1/e;->a(Lcom/airbnb/lottie/LottieAnimationView;Z)V

    .line 541
    .line 542
    .line 543
    return-void

    .line 544
    nop

    .line 545
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final onAnimationRepeat(Landroid/animation/Animator;)V
    .locals 1

    .line 1
    iget v0, p0, Lm1/b;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    :pswitch_0
    const-string v0, "animation"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 1

    .line 1
    iget v0, p0, Lm1/b;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v0, "p0"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    :pswitch_0
    const-string v0, "animation"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
