.class public final synthetic Lm1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Z

.field public final synthetic b:I

.field public final synthetic c:I

.field public final synthetic d:Lcom/airbnb/lottie/LottieAnimationView;


# direct methods
.method public synthetic constructor <init>(ZIILcom/airbnb/lottie/LottieAnimationView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lm1/d;->a:Z

    iput p2, p0, Lm1/d;->b:I

    iput p3, p0, Lm1/d;->c:I

    iput-object p4, p0, Lm1/d;->d:Lcom/airbnb/lottie/LottieAnimationView;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget-boolean v0, p0, Lm1/d;->a:Z

    .line 2
    .line 3
    iget-object v1, p0, Lm1/d;->d:Lcom/airbnb/lottie/LottieAnimationView;

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    iget v2, p0, Lm1/d;->b:I

    .line 8
    .line 9
    iget v3, p0, Lm1/d;->c:I

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    if-le v2, v3, :cond_0

    .line 13
    .line 14
    iget-object v5, v1, Lcom/airbnb/lottie/LottieAnimationView;->e:Lcom/airbnb/lottie/y;

    .line 15
    .line 16
    invoke-virtual {v5, v3, v2}, Lcom/airbnb/lottie/y;->s(II)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v1}, Lcom/airbnb/lottie/LottieAnimationView;->getSpeed()F

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    cmpl-float v2, v2, v4

    .line 24
    .line 25
    if-lez v2, :cond_5

    .line 26
    .line 27
    iget-object v2, v1, Lcom/airbnb/lottie/LottieAnimationView;->e:Lcom/airbnb/lottie/y;

    .line 28
    .line 29
    iget-object v2, v2, Lcom/airbnb/lottie/y;->b:Lcom/airbnb/lottie/utils/e;

    .line 30
    .line 31
    iget v3, v2, Lcom/airbnb/lottie/utils/e;->d:F

    .line 32
    .line 33
    neg-float v3, v3

    .line 34
    iput v3, v2, Lcom/airbnb/lottie/utils/e;->d:F

    .line 35
    .line 36
    goto :goto_1

    .line 37
    :cond_0
    iget-object v5, v1, Lcom/airbnb/lottie/LottieAnimationView;->e:Lcom/airbnb/lottie/y;

    .line 38
    .line 39
    invoke-virtual {v5, v2, v3}, Lcom/airbnb/lottie/y;->s(II)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1}, Lcom/airbnb/lottie/LottieAnimationView;->getSpeed()F

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    cmpg-float v2, v2, v4

    .line 47
    .line 48
    if-gez v2, :cond_5

    .line 49
    .line 50
    iget-object v2, v1, Lcom/airbnb/lottie/LottieAnimationView;->e:Lcom/airbnb/lottie/y;

    .line 51
    .line 52
    iget-object v2, v2, Lcom/airbnb/lottie/y;->b:Lcom/airbnb/lottie/utils/e;

    .line 53
    .line 54
    iget v3, v2, Lcom/airbnb/lottie/utils/e;->d:F

    .line 55
    .line 56
    neg-float v3, v3

    .line 57
    iput v3, v2, Lcom/airbnb/lottie/utils/e;->d:F

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_1
    invoke-virtual {v1}, Lcom/airbnb/lottie/LottieAnimationView;->getComposition()Lcom/airbnb/lottie/k;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    const/4 v3, 0x0

    .line 65
    if-eqz v2, :cond_2

    .line 66
    .line 67
    iget v2, v2, Lcom/airbnb/lottie/k;->l:F

    .line 68
    .line 69
    float-to-int v2, v2

    .line 70
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    goto :goto_0

    .line 75
    :cond_2
    move-object v2, v3

    .line 76
    :goto_0
    invoke-virtual {v1}, Lcom/airbnb/lottie/LottieAnimationView;->getComposition()Lcom/airbnb/lottie/k;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    if-eqz v4, :cond_3

    .line 81
    .line 82
    iget v3, v4, Lcom/airbnb/lottie/k;->m:F

    .line 83
    .line 84
    float-to-int v3, v3

    .line 85
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 86
    .line 87
    .line 88
    move-result-object v3

    .line 89
    :cond_3
    invoke-virtual {v1}, Lcom/airbnb/lottie/LottieAnimationView;->getMinFrame()F

    .line 90
    .line 91
    .line 92
    move-result v4

    .line 93
    float-to-int v4, v4

    .line 94
    invoke-virtual {v1}, Lcom/airbnb/lottie/LottieAnimationView;->getMaxFrame()F

    .line 95
    .line 96
    .line 97
    move-result v5

    .line 98
    float-to-int v5, v5

    .line 99
    if-eqz v2, :cond_5

    .line 100
    .line 101
    if-eqz v3, :cond_5

    .line 102
    .line 103
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 104
    .line 105
    .line 106
    move-result v6

    .line 107
    if-ne v4, v6, :cond_4

    .line 108
    .line 109
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 110
    .line 111
    .line 112
    move-result v4

    .line 113
    if-eq v5, v4, :cond_5

    .line 114
    .line 115
    :cond_4
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 120
    .line 121
    .line 122
    move-result v3

    .line 123
    iget-object v4, v1, Lcom/airbnb/lottie/LottieAnimationView;->e:Lcom/airbnb/lottie/y;

    .line 124
    .line 125
    invoke-virtual {v4, v2, v3}, Lcom/airbnb/lottie/y;->s(II)V

    .line 126
    .line 127
    .line 128
    :cond_5
    :goto_1
    sget-object v2, Landroidx/core/view/N;->a:Ljava/util/WeakHashMap;

    .line 129
    .line 130
    invoke-virtual {v1}, Landroid/view/View;->isAttachedToWindow()Z

    .line 131
    .line 132
    .line 133
    move-result v2

    .line 134
    if-eqz v2, :cond_7

    .line 135
    .line 136
    if-eqz v0, :cond_6

    .line 137
    .line 138
    invoke-virtual {v1}, Lcom/airbnb/lottie/LottieAnimationView;->e()V

    .line 139
    .line 140
    .line 141
    return-void

    .line 142
    :cond_6
    sget-object v0, Lcom/airbnb/lottie/i;->f:Lcom/airbnb/lottie/i;

    .line 143
    .line 144
    iget-object v2, v1, Lcom/airbnb/lottie/LottieAnimationView;->p:Ljava/util/HashSet;

    .line 145
    .line 146
    invoke-virtual {v2, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 147
    .line 148
    .line 149
    iget-object v0, v1, Lcom/airbnb/lottie/LottieAnimationView;->e:Lcom/airbnb/lottie/y;

    .line 150
    .line 151
    invoke-virtual {v0}, Lcom/airbnb/lottie/y;->o()V

    .line 152
    .line 153
    .line 154
    return-void

    .line 155
    :cond_7
    new-instance v2, Lcom/chuanyi/ad/b;

    .line 156
    .line 157
    invoke-direct {v2, v1, v0}, Lcom/chuanyi/ad/b;-><init>(Lcom/airbnb/lottie/LottieAnimationView;Z)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v1, v2}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 161
    .line 162
    .line 163
    return-void
.end method
