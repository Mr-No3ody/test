.class public final Lm1/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/ref/WeakReference;

.field public b:Z

.field public c:Ljava/lang/String;

.field public d:Landroid/widget/ImageView$ScaleType;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/Boolean;

.field public g:Ljava/lang/Boolean;

.field public h:Lcom/facebook/react/bridge/ReadableArray;

.field public i:Lcom/facebook/react/bridge/ReadableArray;

.field public j:Lcom/airbnb/lottie/H;

.field public k:Ljava/lang/Integer;

.field public l:Ljava/lang/String;

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/String;

.field public o:Ljava/lang/Float;

.field public p:Ljava/lang/Boolean;

.field public q:Ljava/lang/Boolean;

.field public r:Ljava/lang/Float;


# direct methods
.method public constructor <init>(Lcom/airbnb/lottie/LottieAnimationView;)V
    .locals 1

    .line 1
    const-string/jumbo v0, "view"

    .line 2
    .line 3
    .line 4
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lm1/g;->a:Ljava/lang/ref/WeakReference;

    .line 16
    .line 17
    new-instance v0, Lm1/f;

    .line 18
    .line 19
    invoke-direct {v0, p1}, Lm1/f;-><init>(Lcom/airbnb/lottie/LottieAnimationView;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1, v0}, Lcom/airbnb/lottie/LottieAnimationView;->setFontAssetDelegate(Lcom/airbnb/lottie/b;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 10

    .line 1
    iget-object v0, p0, Lm1/g;->a:Ljava/lang/ref/WeakReference;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/airbnb/lottie/LottieAnimationView;

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    goto/16 :goto_b

    .line 12
    .line 13
    :cond_0
    iget-object v1, p0, Lm1/g;->i:Lcom/facebook/react/bridge/ReadableArray;

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    if-eqz v1, :cond_4

    .line 17
    .line 18
    invoke-interface {v1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    if-lez v3, :cond_4

    .line 23
    .line 24
    new-instance v3, Lcom/airbnb/lottie/J;

    .line 25
    .line 26
    invoke-direct {v3, v0}, Lcom/airbnb/lottie/J;-><init>(Lcom/airbnb/lottie/LottieAnimationView;)V

    .line 27
    .line 28
    .line 29
    invoke-interface {v1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    move v5, v2

    .line 34
    :goto_0
    if-ge v5, v4, :cond_3

    .line 35
    .line 36
    invoke-interface {v1, v5}, Lcom/facebook/react/bridge/ReadableArray;->getMap(I)Lcom/facebook/react/bridge/ReadableMap;

    .line 37
    .line 38
    .line 39
    move-result-object v6

    .line 40
    if-nez v6, :cond_1

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_1
    const-string v7, "find"

    .line 44
    .line 45
    invoke-interface {v6, v7}, Lcom/facebook/react/bridge/ReadableMap;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v7

    .line 49
    const-string v8, "replace"

    .line 50
    .line 51
    invoke-interface {v6, v8}, Lcom/facebook/react/bridge/ReadableMap;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v6

    .line 55
    iget-object v8, v3, Lcom/airbnb/lottie/J;->a:Ljava/util/HashMap;

    .line 56
    .line 57
    invoke-virtual {v8, v7, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    iget-object v6, v3, Lcom/airbnb/lottie/J;->b:Lcom/airbnb/lottie/LottieAnimationView;

    .line 61
    .line 62
    if-eqz v6, :cond_2

    .line 63
    .line 64
    invoke-virtual {v6}, Lcom/airbnb/lottie/LottieAnimationView;->invalidate()V

    .line 65
    .line 66
    .line 67
    :cond_2
    :goto_1
    add-int/lit8 v5, v5, 0x1

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_3
    invoke-virtual {v0, v3}, Lcom/airbnb/lottie/LottieAnimationView;->setTextDelegate(Lcom/airbnb/lottie/J;)V

    .line 71
    .line 72
    .line 73
    :cond_4
    iget-object v1, p0, Lm1/g;->l:Ljava/lang/String;

    .line 74
    .line 75
    const/4 v3, 0x0

    .line 76
    if-eqz v1, :cond_5

    .line 77
    .line 78
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 79
    .line 80
    .line 81
    move-result v4

    .line 82
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    new-instance v5, Ljava/io/ByteArrayInputStream;

    .line 87
    .line 88
    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    invoke-direct {v5, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v0, v5, v4}, Lcom/airbnb/lottie/LottieAnimationView;->f(Ljava/io/InputStream;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    iput-object v3, p0, Lm1/g;->l:Ljava/lang/String;

    .line 99
    .line 100
    :cond_5
    iget-object v1, p0, Lm1/g;->m:Ljava/lang/String;

    .line 101
    .line 102
    if-eqz v1, :cond_7

    .line 103
    .line 104
    new-instance v4, Ljava/io/File;

    .line 105
    .line 106
    invoke-direct {v4, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    .line 110
    .line 111
    .line 112
    move-result v5

    .line 113
    if-eqz v5, :cond_6

    .line 114
    .line 115
    new-instance v5, Ljava/io/FileInputStream;

    .line 116
    .line 117
    invoke-direct {v5, v4}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 121
    .line 122
    .line 123
    move-result v1

    .line 124
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-virtual {v0, v5, v1}, Lcom/airbnb/lottie/LottieAnimationView;->f(Ljava/io/InputStream;Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    goto :goto_2

    .line 132
    :cond_6
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 133
    .line 134
    .line 135
    move-result v4

    .line 136
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object v4

    .line 140
    invoke-virtual {v0, v1, v4}, Lcom/airbnb/lottie/LottieAnimationView;->h(Ljava/lang/String;Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    :goto_2
    iput-object v3, p0, Lm1/g;->m:Ljava/lang/String;

    .line 144
    .line 145
    :cond_7
    iget-object v1, p0, Lm1/g;->n:Ljava/lang/String;

    .line 146
    .line 147
    if-eqz v1, :cond_e

    .line 148
    .line 149
    new-instance v4, Ljava/io/File;

    .line 150
    .line 151
    invoke-direct {v4, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    .line 155
    .line 156
    .line 157
    move-result v5

    .line 158
    if-eqz v5, :cond_8

    .line 159
    .line 160
    new-instance v2, Ljava/util/zip/ZipInputStream;

    .line 161
    .line 162
    new-instance v5, Ljava/io/FileInputStream;

    .line 163
    .line 164
    invoke-direct {v5, v4}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 165
    .line 166
    .line 167
    invoke-direct {v2, v5}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 171
    .line 172
    .line 173
    move-result v1

    .line 174
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v1

    .line 178
    invoke-virtual {v0, v2, v1}, Lcom/airbnb/lottie/LottieAnimationView;->g(Ljava/util/zip/ZipInputStream;Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    iput-object v3, p0, Lm1/g;->n:Ljava/lang/String;

    .line 182
    .line 183
    return-void

    .line 184
    :cond_8
    :try_start_0
    sget-object v4, Lxf/q;->a:Lxf/o;

    .line 185
    .line 186
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 187
    .line 188
    .line 189
    move-result-object v4

    .line 190
    invoke-virtual {v4}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 194
    goto :goto_3

    .line 195
    :catchall_0
    move-exception v4

    .line 196
    sget-object v5, Lxf/q;->a:Lxf/o;

    .line 197
    .line 198
    invoke-static {v4}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 199
    .line 200
    .line 201
    move-result-object v4

    .line 202
    :goto_3
    instance-of v5, v4, Lxf/p;

    .line 203
    .line 204
    if-eqz v5, :cond_9

    .line 205
    .line 206
    move-object v4, v3

    .line 207
    :cond_9
    check-cast v4, Ljava/lang/String;

    .line 208
    .line 209
    if-eqz v4, :cond_c

    .line 210
    .line 211
    const-string v2, "file"

    .line 212
    .line 213
    invoke-virtual {v4, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 214
    .line 215
    .line 216
    move-result v2

    .line 217
    if-eqz v2, :cond_a

    .line 218
    .line 219
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 220
    .line 221
    .line 222
    move-result-object v2

    .line 223
    invoke-virtual {v2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object v2

    .line 227
    if-eqz v2, :cond_b

    .line 228
    .line 229
    new-instance v4, Ljava/io/File;

    .line 230
    .line 231
    invoke-direct {v4, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    new-instance v2, Ljava/util/zip/ZipInputStream;

    .line 235
    .line 236
    new-instance v5, Ljava/io/FileInputStream;

    .line 237
    .line 238
    invoke-direct {v5, v4}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 239
    .line 240
    .line 241
    invoke-direct {v2, v5}, Ljava/util/zip/ZipInputStream;-><init>(Ljava/io/InputStream;)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 245
    .line 246
    .line 247
    move-result v1

    .line 248
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v1

    .line 252
    invoke-virtual {v0, v2, v1}, Lcom/airbnb/lottie/LottieAnimationView;->g(Ljava/util/zip/ZipInputStream;Ljava/lang/String;)V

    .line 253
    .line 254
    .line 255
    goto :goto_4

    .line 256
    :cond_a
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setAnimationFromUrl(Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    :cond_b
    :goto_4
    iput-object v3, p0, Lm1/g;->n:Ljava/lang/String;

    .line 260
    .line 261
    return-void

    .line 262
    :cond_c
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 263
    .line 264
    .line 265
    move-result-object v4

    .line 266
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 267
    .line 268
    .line 269
    move-result-object v5

    .line 270
    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    move-result-object v5

    .line 274
    const-string v6, "raw"

    .line 275
    .line 276
    invoke-virtual {v4, v1, v6, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 277
    .line 278
    .line 279
    move-result v4

    .line 280
    if-nez v4, :cond_d

    .line 281
    .line 282
    new-instance v0, Ljava/lang/StringBuilder;

    .line 283
    .line 284
    const-string v2, "Animation for "

    .line 285
    .line 286
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 290
    .line 291
    .line 292
    const-string v1, " was not found in raw resources"

    .line 293
    .line 294
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 295
    .line 296
    .line 297
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    invoke-static {v0}, Lcom/facebook/react/util/RNLog;->e(Ljava/lang/String;)V

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :cond_d
    invoke-virtual {v0, v4}, Lcom/airbnb/lottie/LottieAnimationView;->setAnimation(I)V

    .line 306
    .line 307
    .line 308
    iput-boolean v2, p0, Lm1/g;->b:Z

    .line 309
    .line 310
    iput-object v3, p0, Lm1/g;->n:Ljava/lang/String;

    .line 311
    .line 312
    :cond_e
    iget-boolean v1, p0, Lm1/g;->b:Z

    .line 313
    .line 314
    if-eqz v1, :cond_f

    .line 315
    .line 316
    iget-object v1, p0, Lm1/g;->c:Ljava/lang/String;

    .line 317
    .line 318
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setAnimation(Ljava/lang/String;)V

    .line 319
    .line 320
    .line 321
    iput-boolean v2, p0, Lm1/g;->b:Z

    .line 322
    .line 323
    :cond_f
    iget-object v1, p0, Lm1/g;->o:Ljava/lang/Float;

    .line 324
    .line 325
    if-eqz v1, :cond_10

    .line 326
    .line 327
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 328
    .line 329
    .line 330
    move-result v1

    .line 331
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setProgress(F)V

    .line 332
    .line 333
    .line 334
    iput-object v3, p0, Lm1/g;->o:Ljava/lang/Float;

    .line 335
    .line 336
    :cond_10
    iget-object v1, p0, Lm1/g;->p:Ljava/lang/Boolean;

    .line 337
    .line 338
    if-eqz v1, :cond_12

    .line 339
    .line 340
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 341
    .line 342
    .line 343
    move-result v1

    .line 344
    if-eqz v1, :cond_11

    .line 345
    .line 346
    const/4 v1, -0x1

    .line 347
    goto :goto_5

    .line 348
    :cond_11
    move v1, v2

    .line 349
    :goto_5
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setRepeatCount(I)V

    .line 350
    .line 351
    .line 352
    iput-object v3, p0, Lm1/g;->p:Ljava/lang/Boolean;

    .line 353
    .line 354
    :cond_12
    iget-object v1, p0, Lm1/g;->q:Ljava/lang/Boolean;

    .line 355
    .line 356
    iget-object v4, v0, Lcom/airbnb/lottie/LottieAnimationView;->e:Lcom/airbnb/lottie/y;

    .line 357
    .line 358
    if-eqz v1, :cond_13

    .line 359
    .line 360
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 361
    .line 362
    .line 363
    move-result v1

    .line 364
    if-eqz v1, :cond_13

    .line 365
    .line 366
    invoke-virtual {v4}, Lcom/airbnb/lottie/y;->j()Z

    .line 367
    .line 368
    .line 369
    move-result v1

    .line 370
    if-nez v1, :cond_13

    .line 371
    .line 372
    invoke-virtual {v0}, Lcom/airbnb/lottie/LottieAnimationView;->e()V

    .line 373
    .line 374
    .line 375
    :cond_13
    iget-object v1, p0, Lm1/g;->r:Ljava/lang/Float;

    .line 376
    .line 377
    if-eqz v1, :cond_14

    .line 378
    .line 379
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 380
    .line 381
    .line 382
    move-result v1

    .line 383
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setSpeed(F)V

    .line 384
    .line 385
    .line 386
    iput-object v3, p0, Lm1/g;->r:Ljava/lang/Float;

    .line 387
    .line 388
    :cond_14
    iget-object v1, p0, Lm1/g;->d:Landroid/widget/ImageView$ScaleType;

    .line 389
    .line 390
    if-eqz v1, :cond_15

    .line 391
    .line 392
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 393
    .line 394
    .line 395
    iput-object v3, p0, Lm1/g;->d:Landroid/widget/ImageView$ScaleType;

    .line 396
    .line 397
    :cond_15
    iget-object v1, p0, Lm1/g;->j:Lcom/airbnb/lottie/H;

    .line 398
    .line 399
    if-eqz v1, :cond_16

    .line 400
    .line 401
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setRenderMode(Lcom/airbnb/lottie/H;)V

    .line 402
    .line 403
    .line 404
    iput-object v3, p0, Lm1/g;->j:Lcom/airbnb/lottie/H;

    .line 405
    .line 406
    :cond_16
    iget-object v1, p0, Lm1/g;->k:Ljava/lang/Integer;

    .line 407
    .line 408
    if-eqz v1, :cond_17

    .line 409
    .line 410
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 411
    .line 412
    .line 413
    move-result v1

    .line 414
    invoke-virtual {v0, v1, v3}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    .line 415
    .line 416
    .line 417
    :cond_17
    iget-object v1, p0, Lm1/g;->e:Ljava/lang/String;

    .line 418
    .line 419
    if-eqz v1, :cond_18

    .line 420
    .line 421
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setImageAssetsFolder(Ljava/lang/String;)V

    .line 422
    .line 423
    .line 424
    iput-object v3, p0, Lm1/g;->e:Ljava/lang/String;

    .line 425
    .line 426
    :cond_18
    iget-object v1, p0, Lm1/g;->f:Ljava/lang/Boolean;

    .line 427
    .line 428
    if-eqz v1, :cond_19

    .line 429
    .line 430
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 431
    .line 432
    .line 433
    move-result v1

    .line 434
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->c(Z)V

    .line 435
    .line 436
    .line 437
    iput-object v3, p0, Lm1/g;->f:Ljava/lang/Boolean;

    .line 438
    .line 439
    :cond_19
    iget-object v1, p0, Lm1/g;->g:Ljava/lang/Boolean;

    .line 440
    .line 441
    if-eqz v1, :cond_1a

    .line 442
    .line 443
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 444
    .line 445
    .line 446
    move-result v1

    .line 447
    invoke-virtual {v0, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setSafeMode(Z)V

    .line 448
    .line 449
    .line 450
    iput-object v3, p0, Lm1/g;->g:Ljava/lang/Boolean;

    .line 451
    .line 452
    :cond_1a
    iget-object v1, p0, Lm1/g;->h:Lcom/facebook/react/bridge/ReadableArray;

    .line 453
    .line 454
    if-eqz v1, :cond_20

    .line 455
    .line 456
    invoke-interface {v1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 457
    .line 458
    .line 459
    move-result v3

    .line 460
    if-lez v3, :cond_20

    .line 461
    .line 462
    invoke-interface {v1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 463
    .line 464
    .line 465
    move-result v3

    .line 466
    move v5, v2

    .line 467
    :goto_6
    if-ge v5, v3, :cond_20

    .line 468
    .line 469
    invoke-interface {v1, v5}, Lcom/facebook/react/bridge/ReadableArray;->getMap(I)Lcom/facebook/react/bridge/ReadableMap;

    .line 470
    .line 471
    .line 472
    move-result-object v6

    .line 473
    if-nez v6, :cond_1b

    .line 474
    .line 475
    goto/16 :goto_a

    .line 476
    .line 477
    :cond_1b
    const-string v7, "color"

    .line 478
    .line 479
    invoke-interface {v6, v7}, Lcom/facebook/react/bridge/ReadableMap;->getType(Ljava/lang/String;)Lcom/facebook/react/bridge/ReadableType;

    .line 480
    .line 481
    .line 482
    move-result-object v8

    .line 483
    sget-object v9, Lcom/facebook/react/bridge/ReadableType;->Map:Lcom/facebook/react/bridge/ReadableType;

    .line 484
    .line 485
    if-ne v8, v9, :cond_1d

    .line 486
    .line 487
    invoke-interface {v6, v7}, Lcom/facebook/react/bridge/ReadableMap;->getMap(Ljava/lang/String;)Lcom/facebook/react/bridge/ReadableMap;

    .line 488
    .line 489
    .line 490
    move-result-object v7

    .line 491
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 492
    .line 493
    .line 494
    move-result-object v8

    .line 495
    const-string v9, "getContext(...)"

    .line 496
    .line 497
    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 498
    .line 499
    .line 500
    invoke-static {v7, v8}, Lcom/facebook/react/bridge/ColorPropConverter;->getColor(Ljava/lang/Object;Landroid/content/Context;)Ljava/lang/Integer;

    .line 501
    .line 502
    .line 503
    move-result-object v7

    .line 504
    if-eqz v7, :cond_1c

    .line 505
    .line 506
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 507
    .line 508
    .line 509
    move-result v7

    .line 510
    goto :goto_7

    .line 511
    :cond_1c
    move v7, v2

    .line 512
    goto :goto_7

    .line 513
    :cond_1d
    invoke-interface {v6, v7}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 514
    .line 515
    .line 516
    move-result v7

    .line 517
    :goto_7
    const-string v8, "keypath"

    .line 518
    .line 519
    invoke-interface {v6, v8}, Lcom/facebook/react/bridge/ReadableMap;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 520
    .line 521
    .line 522
    move-result-object v6

    .line 523
    const-string v8, ".**"

    .line 524
    .line 525
    invoke-static {v6, v8}, LN8/q0;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 526
    .line 527
    .line 528
    move-result-object v6

    .line 529
    const-string v8, "."

    .line 530
    .line 531
    invoke-static {v8}, Ljava/util/regex/Pattern;->quote(Ljava/lang/String;)Ljava/lang/String;

    .line 532
    .line 533
    .line 534
    move-result-object v8

    .line 535
    const-string v9, "quote(...)"

    .line 536
    .line 537
    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 538
    .line 539
    .line 540
    new-instance v9, Lkotlin/text/Regex;

    .line 541
    .line 542
    invoke-direct {v9, v8}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    .line 543
    .line 544
    .line 545
    invoke-virtual {v9, v6}, Lkotlin/text/Regex;->c(Ljava/lang/CharSequence;)Ljava/util/List;

    .line 546
    .line 547
    .line 548
    move-result-object v6

    .line 549
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 550
    .line 551
    .line 552
    move-result v8

    .line 553
    if-nez v8, :cond_1f

    .line 554
    .line 555
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 556
    .line 557
    .line 558
    move-result v8

    .line 559
    invoke-interface {v6, v8}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 560
    .line 561
    .line 562
    move-result-object v8

    .line 563
    :goto_8
    invoke-interface {v8}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 564
    .line 565
    .line 566
    move-result v9

    .line 567
    if-eqz v9, :cond_1f

    .line 568
    .line 569
    invoke-interface {v8}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 570
    .line 571
    .line 572
    move-result-object v9

    .line 573
    check-cast v9, Ljava/lang/String;

    .line 574
    .line 575
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 576
    .line 577
    .line 578
    move-result v9

    .line 579
    if-nez v9, :cond_1e

    .line 580
    .line 581
    goto :goto_8

    .line 582
    :cond_1e
    check-cast v6, Ljava/lang/Iterable;

    .line 583
    .line 584
    invoke-interface {v8}, Ljava/util/ListIterator;->nextIndex()I

    .line 585
    .line 586
    .line 587
    move-result v8

    .line 588
    add-int/lit8 v8, v8, 0x1

    .line 589
    .line 590
    invoke-static {v6, v8}, Lkotlin/collections/CollectionsKt;->U(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 591
    .line 592
    .line 593
    move-result-object v6

    .line 594
    goto :goto_9

    .line 595
    :cond_1f
    sget-object v6, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 596
    .line 597
    :goto_9
    check-cast v6, Ljava/util/Collection;

    .line 598
    .line 599
    new-array v8, v2, [Ljava/lang/String;

    .line 600
    .line 601
    invoke-interface {v6, v8}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 602
    .line 603
    .line 604
    move-result-object v6

    .line 605
    check-cast v6, [Ljava/lang/String;

    .line 606
    .line 607
    new-instance v8, Lo1/e;

    .line 608
    .line 609
    array-length v9, v6

    .line 610
    invoke-static {v6, v9}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 611
    .line 612
    .line 613
    move-result-object v6

    .line 614
    check-cast v6, [Ljava/lang/String;

    .line 615
    .line 616
    invoke-direct {v8, v6}, Lo1/e;-><init>([Ljava/lang/String;)V

    .line 617
    .line 618
    .line 619
    new-instance v6, Lcom/airbnb/lottie/I;

    .line 620
    .line 621
    invoke-direct {v6, v7}, Lcom/airbnb/lottie/I;-><init>(I)V

    .line 622
    .line 623
    .line 624
    new-instance v7, Lq1/c;

    .line 625
    .line 626
    invoke-direct {v7, v6}, Lq1/c;-><init>(Lcom/airbnb/lottie/I;)V

    .line 627
    .line 628
    .line 629
    sget-object v6, Lcom/airbnb/lottie/LottieProperty;->I:Landroid/graphics/ColorFilter;

    .line 630
    .line 631
    invoke-virtual {v4, v8, v6, v7}, Lcom/airbnb/lottie/y;->a(Lo1/e;Landroid/graphics/ColorFilter;Lq1/c;)V

    .line 632
    .line 633
    .line 634
    :goto_a
    add-int/lit8 v5, v5, 0x1

    .line 635
    .line 636
    goto/16 :goto_6

    .line 637
    .line 638
    :cond_20
    :goto_b
    return-void
.end method
