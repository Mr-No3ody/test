.class public final synthetic LG/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/core/util/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LG/d;->a:I

    iput-object p2, p0, LG/d;->b:Ljava/lang/Object;

    iput-object p3, p0, LG/d;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget v0, p0, LG/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LE/h;

    .line 7
    .line 8
    iget-object p1, p0, LG/d;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast p1, Landroidx/camera/core/processing/f;

    .line 11
    .line 12
    iget-object v0, p0, LG/d;->c:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, Landroidx/camera/core/SurfaceOutput;

    .line 15
    .line 16
    invoke-interface {v0}, Landroidx/camera/core/SurfaceOutput;->close()V

    .line 17
    .line 18
    .line 19
    iget-object v1, p1, Landroidx/camera/core/processing/f;->h:Ljava/util/LinkedHashMap;

    .line 20
    .line 21
    invoke-interface {v1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/view/Surface;

    .line 26
    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    iget-object p1, p1, Landroidx/camera/core/processing/f;->a:Landroidx/camera/core/processing/h;

    .line 30
    .line 31
    iget-object v1, p1, Landroidx/camera/core/processing/h;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 32
    .line 33
    const/4 v2, 0x1

    .line 34
    invoke-static {v1, v2}, LH/j;->d(Ljava/util/concurrent/atomic/AtomicBoolean;Z)V

    .line 35
    .line 36
    .line 37
    iget-object v1, p1, Landroidx/camera/core/processing/h;->c:Ljava/lang/Thread;

    .line 38
    .line 39
    invoke-static {v1}, LH/j;->c(Ljava/lang/Thread;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {p1, v0, v2}, Landroidx/camera/core/processing/h;->i(Landroid/view/Surface;Z)V

    .line 43
    .line 44
    .line 45
    :cond_0
    return-void

    .line 46
    :pswitch_0
    check-cast p1, LE/i;

    .line 47
    .line 48
    iget-object p1, p0, LG/d;->b:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast p1, Landroid/view/Surface;

    .line 51
    .line 52
    invoke-virtual {p1}, Landroid/view/Surface;->release()V

    .line 53
    .line 54
    .line 55
    iget-object p1, p0, LG/d;->c:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast p1, Landroid/graphics/SurfaceTexture;

    .line 58
    .line 59
    invoke-virtual {p1}, Landroid/graphics/SurfaceTexture;->release()V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :pswitch_1
    check-cast p1, LE/h;

    .line 64
    .line 65
    iget-object p1, p0, LG/d;->b:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast p1, LG/f;

    .line 68
    .line 69
    iget-object v0, p0, LG/d;->c:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v0, Landroidx/camera/core/SurfaceOutput;

    .line 72
    .line 73
    invoke-interface {v0}, Landroidx/camera/core/SurfaceOutput;->close()V

    .line 74
    .line 75
    .line 76
    iget-object v1, p1, LG/f;->h:Ljava/util/LinkedHashMap;

    .line 77
    .line 78
    invoke-interface {v1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    check-cast v0, Landroid/view/Surface;

    .line 83
    .line 84
    if-eqz v0, :cond_1

    .line 85
    .line 86
    iget-object p1, p1, LG/f;->a:LG/c;

    .line 87
    .line 88
    iget-object v1, p1, Landroidx/camera/core/processing/h;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 89
    .line 90
    const/4 v2, 0x1

    .line 91
    invoke-static {v1, v2}, LH/j;->d(Ljava/util/concurrent/atomic/AtomicBoolean;Z)V

    .line 92
    .line 93
    .line 94
    iget-object v1, p1, Landroidx/camera/core/processing/h;->c:Ljava/lang/Thread;

    .line 95
    .line 96
    invoke-static {v1}, LH/j;->c(Ljava/lang/Thread;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p1, v0, v2}, Landroidx/camera/core/processing/h;->i(Landroid/view/Surface;Z)V

    .line 100
    .line 101
    .line 102
    :cond_1
    return-void

    .line 103
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
