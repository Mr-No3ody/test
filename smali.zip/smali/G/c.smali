.class public final LG/c;
.super Landroidx/camera/core/processing/h;
.source "SourceFile"


# instance fields
.field public n:I

.field public o:I

.field public final p:LE/U;

.field public final q:LE/U;


# direct methods
.method public constructor <init>(LE/U;LE/U;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroidx/camera/core/processing/h;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, LG/c;->n:I

    .line 6
    .line 7
    iput v0, p0, LG/c;->o:I

    .line 8
    .line 9
    iput-object p1, p0, LG/c;->p:LE/U;

    .line 10
    .line 11
    iput-object p2, p0, LG/c;->q:LE/U;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final e(LE/v;)LH/b;
    .locals 1

    .line 1
    sget-object v0, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 2
    .line 3
    invoke-super {p0, p1}, Landroidx/camera/core/processing/h;->e(LE/v;)LH/b;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {}, LH/j;->g()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iput v0, p0, LG/c;->n:I

    .line 12
    .line 13
    invoke-static {}, LH/j;->g()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    iput v0, p0, LG/c;->o:I

    .line 18
    .line 19
    return-object p1
.end method

.method public final l(JLandroid/view/Surface;Landroidx/camera/core/SurfaceOutput;Landroid/graphics/SurfaceTexture;Landroid/graphics/SurfaceTexture;)V
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/camera/core/processing/h;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, LH/j;->d(Ljava/util/concurrent/atomic/AtomicBoolean;Z)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Landroidx/camera/core/processing/h;->c:Ljava/lang/Thread;

    .line 8
    .line 9
    invoke-static {v0}, LH/j;->c(Ljava/lang/Thread;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Landroidx/camera/core/processing/h;->b:Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-virtual {v0, p3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    const-string v2, "The surface is not registered."

    .line 19
    .line 20
    invoke-static {v1, v2}, Lhf/a;->k(ZLjava/lang/String;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0, p3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    check-cast v1, LH/d;

    .line 28
    .line 29
    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    sget-object v2, LH/j;->j:LH/d;

    .line 33
    .line 34
    if-ne v1, v2, :cond_1

    .line 35
    .line 36
    invoke-virtual {p0, p3}, Landroidx/camera/core/processing/h;->b(Landroid/view/Surface;)LH/d;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    if-nez v1, :cond_0

    .line 41
    .line 42
    move-object v2, p0

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    invoke-virtual {v0, p3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    :cond_1
    move-object v3, v1

    .line 48
    iget-object v0, p0, Landroidx/camera/core/processing/h;->i:Landroid/view/Surface;

    .line 49
    .line 50
    iget-object v1, v3, LH/d;->a:Landroid/opengl/EGLSurface;

    .line 51
    .line 52
    if-eq p3, v0, :cond_2

    .line 53
    .line 54
    invoke-virtual {p0, v1}, Landroidx/camera/core/processing/h;->f(Landroid/opengl/EGLSurface;)V

    .line 55
    .line 56
    .line 57
    iput-object p3, p0, Landroidx/camera/core/processing/h;->i:Landroid/view/Surface;

    .line 58
    .line 59
    :cond_2
    const/high16 v0, 0x3f800000    # 1.0f

    .line 60
    .line 61
    const/4 v2, 0x0

    .line 62
    invoke-static {v2, v2, v2, v0}, Landroid/opengl/GLES20;->glClearColor(FFFF)V

    .line 63
    .line 64
    .line 65
    const/16 v0, 0x4000

    .line 66
    .line 67
    invoke-static {v0}, Landroid/opengl/GLES20;->glClear(I)V

    .line 68
    .line 69
    .line 70
    iget v7, p0, LG/c;->n:I

    .line 71
    .line 72
    iget-object v6, p0, LG/c;->p:LE/U;

    .line 73
    .line 74
    move-object v2, p0

    .line 75
    move-object v4, p4

    .line 76
    move-object v5, p5

    .line 77
    invoke-virtual/range {v2 .. v7}, LG/c;->m(LH/d;Landroidx/camera/core/SurfaceOutput;Landroid/graphics/SurfaceTexture;LE/U;I)V

    .line 78
    .line 79
    .line 80
    iget v7, v2, LG/c;->o:I

    .line 81
    .line 82
    iget-object v6, v2, LG/c;->q:LE/U;

    .line 83
    .line 84
    move-object v5, p6

    .line 85
    invoke-virtual/range {v2 .. v7}, LG/c;->m(LH/d;Landroidx/camera/core/SurfaceOutput;Landroid/graphics/SurfaceTexture;LE/U;I)V

    .line 86
    .line 87
    .line 88
    iget-object p4, v2, Landroidx/camera/core/processing/h;->d:Landroid/opengl/EGLDisplay;

    .line 89
    .line 90
    invoke-static {p4, v1, p1, p2}, Landroid/opengl/EGLExt;->eglPresentationTimeANDROID(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;J)Z

    .line 91
    .line 92
    .line 93
    iget-object p1, v2, Landroidx/camera/core/processing/h;->d:Landroid/opengl/EGLDisplay;

    .line 94
    .line 95
    invoke-static {p1, v1}, Landroid/opengl/EGL14;->eglSwapBuffers(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    .line 96
    .line 97
    .line 98
    move-result p1

    .line 99
    if-nez p1, :cond_3

    .line 100
    .line 101
    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    .line 102
    .line 103
    .line 104
    move-result p1

    .line 105
    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    const-string p1, "DualOpenGlRenderer"

    .line 109
    .line 110
    invoke-static {p1}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    const/4 p1, 0x0

    .line 114
    invoke-virtual {p0, p3, p1}, Landroidx/camera/core/processing/h;->i(Landroid/view/Surface;Z)V

    .line 115
    .line 116
    .line 117
    :cond_3
    :goto_0
    return-void
.end method

.method public final m(LH/d;Landroidx/camera/core/SurfaceOutput;Landroid/graphics/SurfaceTexture;LE/U;I)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move/from16 v2, p5

    .line 6
    .line 7
    invoke-virtual {v0, v2}, Landroidx/camera/core/processing/h;->k(I)V

    .line 8
    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    iget v3, v1, LH/d;->b:I

    .line 12
    .line 13
    iget v1, v1, LH/d;->c:I

    .line 14
    .line 15
    invoke-static {v2, v2, v3, v1}, Landroid/opengl/GLES20;->glViewport(IIII)V

    .line 16
    .line 17
    .line 18
    invoke-static {v2, v2, v3, v1}, Landroid/opengl/GLES20;->glScissor(IIII)V

    .line 19
    .line 20
    .line 21
    const/16 v4, 0x10

    .line 22
    .line 23
    new-array v5, v4, [F

    .line 24
    .line 25
    move-object/from16 v6, p3

    .line 26
    .line 27
    invoke-virtual {v6, v5}, Landroid/graphics/SurfaceTexture;->getTransformMatrix([F)V

    .line 28
    .line 29
    .line 30
    new-array v6, v4, [F

    .line 31
    .line 32
    const/4 v7, 0x1

    .line 33
    move-object/from16 v8, p2

    .line 34
    .line 35
    invoke-interface {v8, v6, v5, v7}, Landroidx/camera/core/SurfaceOutput;->updateTransformMatrix([F[FZ)V

    .line 36
    .line 37
    .line 38
    iget-object v5, v0, Landroidx/camera/core/processing/h;->k:LH/h;

    .line 39
    .line 40
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    instance-of v8, v5, LH/i;

    .line 44
    .line 45
    const-string v9, "glUniformMatrix4fv"

    .line 46
    .line 47
    if-eqz v8, :cond_0

    .line 48
    .line 49
    move-object v8, v5

    .line 50
    check-cast v8, LH/i;

    .line 51
    .line 52
    iget v8, v8, LH/i;->f:I

    .line 53
    .line 54
    invoke-static {v8, v7, v2, v6, v2}, Landroid/opengl/GLES20;->glUniformMatrix4fv(IIZ[FI)V

    .line 55
    .line 56
    .line 57
    invoke-static {v9}, LH/j;->b(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    :cond_0
    new-instance v6, Landroid/util/Size;

    .line 61
    .line 62
    int-to-float v8, v3

    .line 63
    invoke-virtual/range {p4 .. p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    const/high16 v10, 0x3f800000    # 1.0f

    .line 67
    .line 68
    mul-float/2addr v8, v10

    .line 69
    float-to-int v8, v8

    .line 70
    int-to-float v11, v1

    .line 71
    mul-float/2addr v11, v10

    .line 72
    float-to-int v11, v11

    .line 73
    invoke-direct {v6, v8, v11}, Landroid/util/Size;-><init>(II)V

    .line 74
    .line 75
    .line 76
    new-instance v8, Landroid/util/Size;

    .line 77
    .line 78
    invoke-direct {v8, v3, v1}, Landroid/util/Size;-><init>(II)V

    .line 79
    .line 80
    .line 81
    new-array v13, v4, [F

    .line 82
    .line 83
    invoke-static {v13, v2}, Landroid/opengl/Matrix;->setIdentityM([FI)V

    .line 84
    .line 85
    .line 86
    new-array v15, v4, [F

    .line 87
    .line 88
    invoke-static {v15, v2}, Landroid/opengl/Matrix;->setIdentityM([FI)V

    .line 89
    .line 90
    .line 91
    new-array v11, v4, [F

    .line 92
    .line 93
    invoke-static {v11, v2}, Landroid/opengl/Matrix;->setIdentityM([FI)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v6}, Landroid/util/Size;->getWidth()I

    .line 97
    .line 98
    .line 99
    move-result v1

    .line 100
    int-to-float v1, v1

    .line 101
    invoke-virtual {v8}, Landroid/util/Size;->getWidth()I

    .line 102
    .line 103
    .line 104
    move-result v3

    .line 105
    int-to-float v3, v3

    .line 106
    div-float/2addr v1, v3

    .line 107
    invoke-virtual {v6}, Landroid/util/Size;->getHeight()I

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    int-to-float v3, v3

    .line 112
    invoke-virtual {v8}, Landroid/util/Size;->getHeight()I

    .line 113
    .line 114
    .line 115
    move-result v4

    .line 116
    int-to-float v4, v4

    .line 117
    div-float/2addr v3, v4

    .line 118
    invoke-static {v13, v2, v1, v3, v10}, Landroid/opengl/Matrix;->scaleM([FIFFF)V

    .line 119
    .line 120
    .line 121
    const/4 v1, 0x0

    .line 122
    invoke-static {v15, v2, v1, v1, v1}, Landroid/opengl/Matrix;->translateM([FIFFF)V

    .line 123
    .line 124
    .line 125
    const/4 v12, 0x0

    .line 126
    const/4 v14, 0x0

    .line 127
    const/16 v16, 0x0

    .line 128
    .line 129
    invoke-static/range {v11 .. v16}, Landroid/opengl/Matrix;->multiplyMM([FI[FI[FI)V

    .line 130
    .line 131
    .line 132
    iget v1, v5, LH/h;->b:I

    .line 133
    .line 134
    invoke-static {v1, v7, v2, v11, v2}, Landroid/opengl/GLES20;->glUniformMatrix4fv(IIZ[FI)V

    .line 135
    .line 136
    .line 137
    invoke-static {v9}, LH/j;->b(Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    iget v1, v5, LH/h;->c:I

    .line 141
    .line 142
    invoke-static {v1, v10}, Landroid/opengl/GLES20;->glUniform1f(IF)V

    .line 143
    .line 144
    .line 145
    const-string v1, "glUniform1f"

    .line 146
    .line 147
    invoke-static {v1}, LH/j;->b(Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    const/16 v1, 0xbe2

    .line 151
    .line 152
    invoke-static {v1}, Landroid/opengl/GLES20;->glEnable(I)V

    .line 153
    .line 154
    .line 155
    const/16 v3, 0x302

    .line 156
    .line 157
    const/16 v4, 0x303

    .line 158
    .line 159
    invoke-static {v3, v4, v7, v4}, Landroid/opengl/GLES20;->glBlendFuncSeparate(IIII)V

    .line 160
    .line 161
    .line 162
    const/4 v3, 0x5

    .line 163
    const/4 v4, 0x4

    .line 164
    invoke-static {v3, v2, v4}, Landroid/opengl/GLES20;->glDrawArrays(III)V

    .line 165
    .line 166
    .line 167
    const-string v2, "glDrawArrays"

    .line 168
    .line 169
    invoke-static {v2}, LH/j;->b(Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    invoke-static {v1}, Landroid/opengl/GLES20;->glDisable(I)V

    .line 173
    .line 174
    .line 175
    return-void
.end method
