.class public final synthetic LG/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p7, p0, LG/g;->a:I

    iput-object p1, p0, LG/g;->b:Ljava/lang/Object;

    iput-object p2, p0, LG/g;->c:Ljava/lang/Object;

    iput-object p3, p0, LG/g;->d:Ljava/lang/Object;

    iput-object p4, p0, LG/g;->e:Ljava/lang/Object;

    iput-object p5, p0, LG/g;->f:Ljava/lang/Object;

    iput-object p6, p0, LG/g;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 1
    iget v0, p0, LG/g;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget-object v0, Lcom/transsnet/palmpay/ui/activity/HomeActivity;->H:Lcom/transsnet/palmpay/ui/activity/HomeActivity$a;

    .line 7
    .line 8
    const/16 v0, 0x6f

    .line 9
    .line 10
    iget-object v1, p0, LG/g;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Lcom/transsnet/palmpay/ui/activity/HomeActivity;

    .line 13
    .line 14
    iget-object v2, p0, LG/g;->c:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v2, Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;

    .line 17
    .line 18
    invoke-virtual {v1, v2, v0}, Lcom/transsnet/palmpay/ui/activity/HomeActivity;->showDialog(Landroid/app/Dialog;I)V

    .line 19
    .line 20
    .line 21
    if-eqz v2, :cond_0

    .line 22
    .line 23
    iget-object v0, p0, LG/g;->e:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v0, Ljava/lang/String;

    .line 26
    .line 27
    const-string v1, "UTF-8"

    .line 28
    .line 29
    invoke-static {v0, v1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iget-object v3, p0, LG/g;->f:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v3, Ljava/lang/String;

    .line 36
    .line 37
    invoke-static {v3, v1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    iget-object v3, p0, LG/g;->d:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v3, Ljava/lang/String;

    .line 44
    .line 45
    iget-object v4, p0, LG/g;->g:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v4, Ljava/lang/String;

    .line 48
    .line 49
    invoke-virtual {v2, v3, v0, v1, v4}, Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;->fillData(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    :cond_0
    return-void

    .line 53
    :pswitch_0
    iget-object v0, p0, LG/g;->b:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v0, Landroidx/camera/camera2/internal/J;

    .line 56
    .line 57
    iget-object v1, p0, LG/g;->c:Ljava/lang/Object;

    .line 58
    .line 59
    move-object v3, v1

    .line 60
    check-cast v3, Ljava/lang/String;

    .line 61
    .line 62
    iget-object v1, p0, LG/g;->d:Ljava/lang/Object;

    .line 63
    .line 64
    move-object v4, v1

    .line 65
    check-cast v4, Landroidx/camera/core/impl/H0;

    .line 66
    .line 67
    iget-object v1, p0, LG/g;->e:Ljava/lang/Object;

    .line 68
    .line 69
    move-object v5, v1

    .line 70
    check-cast v5, Landroidx/camera/core/impl/UseCaseConfig;

    .line 71
    .line 72
    iget-object v1, p0, LG/g;->f:Ljava/lang/Object;

    .line 73
    .line 74
    move-object v6, v1

    .line 75
    check-cast v6, Landroidx/camera/core/impl/n;

    .line 76
    .line 77
    iget-object v1, p0, LG/g;->g:Ljava/lang/Object;

    .line 78
    .line 79
    move-object v7, v1

    .line 80
    check-cast v7, Ljava/util/List;

    .line 81
    .line 82
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    new-instance v1, Ljava/lang/StringBuilder;

    .line 86
    .line 87
    const-string v2, "Use case "

    .line 88
    .line 89
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    const-string v2, " RESET"

    .line 96
    .line 97
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    invoke-virtual {v0, v1}, Landroidx/camera/camera2/internal/J;->f(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    iget-object v2, v0, Landroidx/camera/camera2/internal/J;->a:Lorg/greenrobot/eventbus/f;

    .line 108
    .line 109
    invoke-virtual/range {v2 .. v7}, Lorg/greenrobot/eventbus/f;->j(Ljava/lang/String;Landroidx/camera/core/impl/H0;Landroidx/camera/core/impl/UseCaseConfig;Landroidx/camera/core/impl/n;Ljava/util/List;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v0}, Landroidx/camera/camera2/internal/J;->a()V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v0}, Landroidx/camera/camera2/internal/J;->q()V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v0}, Landroidx/camera/camera2/internal/J;->x()V

    .line 119
    .line 120
    .line 121
    iget v1, v0, Landroidx/camera/camera2/internal/J;->B0:I

    .line 122
    .line 123
    const/16 v2, 0x9

    .line 124
    .line 125
    if-ne v1, v2, :cond_1

    .line 126
    .line 127
    invoke-virtual {v0}, Landroidx/camera/camera2/internal/J;->n()V

    .line 128
    .line 129
    .line 130
    :cond_1
    return-void

    .line 131
    :pswitch_1
    iget-object v0, p0, LG/g;->b:Ljava/lang/Object;

    .line 132
    .line 133
    move-object v1, v0

    .line 134
    check-cast v1, LE2/a;

    .line 135
    .line 136
    iget-object v0, p0, LG/g;->c:Ljava/lang/Object;

    .line 137
    .line 138
    move-object v2, v0

    .line 139
    check-cast v2, Landroidx/camera/core/impl/CameraInternal;

    .line 140
    .line 141
    iget-object v0, p0, LG/g;->d:Ljava/lang/Object;

    .line 142
    .line 143
    move-object v3, v0

    .line 144
    check-cast v3, Landroidx/camera/core/impl/CameraInternal;

    .line 145
    .line 146
    iget-object v0, p0, LG/g;->e:Ljava/lang/Object;

    .line 147
    .line 148
    move-object v4, v0

    .line 149
    check-cast v4, Landroidx/camera/core/processing/m;

    .line 150
    .line 151
    iget-object v0, p0, LG/g;->f:Ljava/lang/Object;

    .line 152
    .line 153
    move-object v5, v0

    .line 154
    check-cast v5, Landroidx/camera/core/processing/m;

    .line 155
    .line 156
    iget-object v0, p0, LG/g;->g:Ljava/lang/Object;

    .line 157
    .line 158
    move-object v6, v0

    .line 159
    check-cast v6, Ljava/util/Map$Entry;

    .line 160
    .line 161
    invoke-virtual/range {v1 .. v6}, LE2/a;->b(Landroidx/camera/core/impl/CameraInternal;Landroidx/camera/core/impl/CameraInternal;Landroidx/camera/core/processing/m;Landroidx/camera/core/processing/m;Ljava/util/Map$Entry;)V

    .line 162
    .line 163
    .line 164
    return-void

    .line 165
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
