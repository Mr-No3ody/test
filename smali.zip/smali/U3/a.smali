.class public final synthetic LU3/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;


# direct methods
.method public synthetic constructor <init>(Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;I)V
    .locals 0

    .line 1
    iput p2, p0, LU3/a;->a:I

    iput-object p1, p0, LU3/a;->b:Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LU3/a;->b:Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;

    .line 2
    .line 3
    iget v1, p0, LU3/a;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;->o:I

    .line 9
    .line 10
    sget v1, Lcom/flexibank/sdk/p;->fb_tv_cashier_item_top_up:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/TextView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;->o:I

    .line 20
    .line 21
    sget v1, Lcom/flexibank/sdk/p;->fb_iv_cashier_item_selected:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/ImageView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;->o:I

    .line 31
    .line 32
    sget v1, Lcom/flexibank/sdk/p;->fb_mbci_root:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0

    .line 39
    :pswitch_2
    sget v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;->o:I

    .line 40
    .line 41
    sget v1, Lcom/flexibank/sdk/p;->fb_tv_item_payment_method_activity_tips:I

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Landroid/widget/TextView;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_3
    sget v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;->o:I

    .line 51
    .line 52
    sget v1, Lcom/flexibank/sdk/p;->fb_tv_item_payment_method_normal_tips:I

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v0, Landroid/widget/TextView;

    .line 59
    .line 60
    return-object v0

    .line 61
    :pswitch_4
    sget v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;->o:I

    .line 62
    .line 63
    sget v1, Lcom/flexibank/sdk/p;->fb_tv_cashier_item_payment_balance:I

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Landroid/widget/TextView;

    .line 70
    .line 71
    return-object v0

    .line 72
    :pswitch_5
    sget v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;->o:I

    .line 73
    .line 74
    sget v1, Lcom/flexibank/sdk/p;->fb_tv_cashier_item_payment_method_name:I

    .line 75
    .line 76
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Landroid/widget/TextView;

    .line 81
    .line 82
    return-object v0

    .line 83
    :pswitch_6
    sget v1, Lcom/flexibank/sdk/cashier/viewmodel/FlexiBankCashierPayMethodItem;->o:I

    .line 84
    .line 85
    sget v1, Lcom/flexibank/sdk/p;->fb_iv_cashier_item_payment_method_icon:I

    .line 86
    .line 87
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    check-cast v0, Landroid/widget/ImageView;

    .line 92
    .line 93
    return-object v0

    .line 94
    nop

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
