.class public final Ld;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/manager/FileUploadManager$UploadListener;


# instance fields
.field public final synthetic a:LCommonFileUploadBridge;

.field public final synthetic b:Ljava/lang/String;


# direct methods
.method public constructor <init>(LCommonFileUploadBridge;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ld;->a:LCommonFileUploadBridge;

    .line 5
    .line 6
    iput-object p2, p0, Ld;->b:Ljava/lang/String;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onComplete(Ljava/lang/String;Ljava/io/File;)V
    .locals 2

    .line 1
    const-string/jumbo p2, "uploadFile onComplete >>> "

    .line 2
    .line 3
    .line 4
    invoke-static {p2, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object p2

    .line 8
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p2

    .line 12
    const/4 v0, 0x3

    .line 13
    const-string v1, "CommonFileUploadBridge"

    .line 14
    .line 15
    invoke-static {v1, v0, p2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    iget-object v0, p0, Ld;->a:LCommonFileUploadBridge;

    .line 23
    .line 24
    if-nez p2, :cond_0

    .line 25
    .line 26
    new-instance p2, LCommonFileUploadBridge$FileUploadEntity;

    .line 27
    .line 28
    iget-object v1, p0, Ld;->b:Ljava/lang/String;

    .line 29
    .line 30
    invoke-direct {p2, v1, p1}, LCommonFileUploadBridge$FileUploadEntity;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    const/4 p1, 0x2

    .line 34
    const/4 v1, 0x0

    .line 35
    invoke-static {v0, p2, v1, p1, v1}, Lcom/palmpay/lib/bridge/BaseBridge;->handleSuccess$default(Lcom/palmpay/lib/bridge/BaseBridge;Ljava/lang/Object;Ljava/lang/String;ILjava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_0
    const-string/jumbo p1, "uploadFile error, url is null"

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0, p1}, Lcom/palmpay/lib/bridge/BaseBridge;->handleReject(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method public final onError(Ljava/lang/Exception;)V
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_0

    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move-object v1, v0

    .line 14
    :goto_0
    if-eqz p1, :cond_1

    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    goto :goto_1

    .line 21
    :cond_1
    move-object v2, v0

    .line 22
    :goto_1
    const-string v3, "onError >>> uploadFile "

    .line 23
    .line 24
    const-string v4, ", "

    .line 25
    .line 26
    invoke-static {v3, v1, v4, v2}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    const-string v2, "CommonFileUploadBridge"

    .line 35
    .line 36
    invoke-static {v2, v1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    if-eqz p1, :cond_2

    .line 40
    .line 41
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    goto :goto_2

    .line 50
    :cond_2
    move-object v1, v0

    .line 51
    :goto_2
    if-eqz p1, :cond_3

    .line 52
    .line 53
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    :cond_3
    const-string/jumbo p1, "uploadFile error, "

    .line 58
    .line 59
    .line 60
    const-string v2, " "

    .line 61
    .line 62
    invoke-static {p1, v1, v2, v0}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    iget-object v0, p0, Ld;->a:LCommonFileUploadBridge;

    .line 67
    .line 68
    invoke-virtual {v0, p1}, Lcom/palmpay/lib/bridge/BaseBridge;->handleReject(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    return-void
.end method

.method public final onProgressChanged(JJ)V
    .locals 0

    .line 1
    const-string p1, "onProgressChanged >>>"

    .line 2
    .line 3
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    const/4 p2, 0x3

    .line 8
    const-string p3, "CommonFileUploadBridge"

    .line 9
    .line 10
    invoke-static {p3, p2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onStartSync(Ljava/lang/String;Ljava/io/File;)V
    .locals 0

    return-void
.end method
