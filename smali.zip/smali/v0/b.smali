.class public final Lv0/b;
.super Le1/a;
.source "SourceFile"


# instance fields
.field public final synthetic e:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Lv0/b;->e:I

    const/16 p1, 0x13

    invoke-direct {p0, p1}, Le1/a;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final o(Landroid/view/View;II)I
    .locals 0

    .line 1
    iget p3, p0, Lv0/b;->e:I

    .line 2
    .line 3
    packed-switch p3, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const/high16 p1, -0x80000000

    .line 7
    .line 8
    return p1

    .line 9
    :pswitch_0
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    .line 10
    .line 11
    .line 12
    move-result p2

    .line 13
    const/16 p3, 0x8

    .line 14
    .line 15
    if-ne p2, p3, :cond_0

    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getBaseline()I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    const/4 p2, -0x1

    .line 24
    if-ne p1, p2, :cond_1

    .line 25
    .line 26
    const/high16 p1, -0x80000000

    .line 27
    .line 28
    :cond_1
    :goto_0
    return p1

    .line 29
    :pswitch_1
    shr-int/lit8 p1, p2, 0x1

    .line 30
    .line 31
    return p1

    .line 32
    :pswitch_2
    return p2

    .line 33
    :pswitch_3
    const/4 p1, 0x0

    .line 34
    return p1

    .line 35
    :pswitch_4
    const/high16 p1, -0x80000000

    .line 36
    .line 37
    return p1

    .line 38
    nop

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public p()Lv0/g;
    .locals 1

    .line 1
    iget v0, p0, Lv0/b;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Le1/a;->p()Lv0/g;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Lv0/d;

    .line 12
    .line 13
    invoke-direct {v0}, Lv0/g;-><init>()V

    .line 14
    .line 15
    .line 16
    return-object v0

    .line 17
    :pswitch_data_0
    .packed-switch 0x4
        :pswitch_0
    .end packed-switch
.end method

.method public final r()Ljava/lang/String;
    .locals 1

    .line 1
    iget v0, p0, Lv0/b;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "FILL"

    .line 7
    .line 8
    return-object v0

    .line 9
    :pswitch_0
    const-string v0, "BASELINE"

    .line 10
    .line 11
    return-object v0

    .line 12
    :pswitch_1
    const-string v0, "CENTER"

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_2
    const-string v0, "TRAILING"

    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_3
    const-string v0, "LEADING"

    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_4
    const-string v0, "UNDEFINED"

    .line 22
    .line 23
    return-object v0

    .line 24
    nop

    .line 25
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final u(ILandroid/view/View;)I
    .locals 0

    .line 1
    iget p2, p0, Lv0/b;->e:I

    packed-switch p2, :pswitch_data_0

    const/4 p1, 0x0

    return p1

    :pswitch_0
    const/4 p1, 0x0

    return p1

    :pswitch_1
    shr-int/lit8 p1, p1, 0x1

    :pswitch_2
    return p1

    :pswitch_3
    const/4 p1, 0x0

    return p1

    :pswitch_4
    const/high16 p1, -0x80000000

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public z(II)I
    .locals 1

    .line 1
    iget v0, p0, Lv0/b;->e:I

    packed-switch v0, :pswitch_data_0

    return p1

    :pswitch_0
    return p2

    nop

    :pswitch_data_0
    .packed-switch 0x5
        :pswitch_0
    .end packed-switch
.end method
