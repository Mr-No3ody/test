.class public abstract LT2/b;
.super Ljava/lang/Object;
.source "SourceFile"
