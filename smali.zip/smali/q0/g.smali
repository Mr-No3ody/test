.class public final Lq0/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final A:[B

.field public static final B:[B

.field public static final C:[B

.field public static final D:[B

.field public static final E:[B

.field public static final F:[B

.field public static final G:[B

.field public static final H:[B

.field public static final I:[B

.field public static final J:[B

.field public static final K:[B

.field public static final L:[B

.field public static final M:[B

.field public static final N:[B

.field public static final O:[B

.field public static final P:[B

.field public static final Q:[B

.field public static final R:[Ljava/lang/String;

.field public static final S:[I

.field public static final T:[B

.field public static final U:Lq0/d;

.field public static final V:[[Lq0/d;

.field public static final W:[Lq0/d;

.field public static final X:[Ljava/util/HashMap;

.field public static final Y:[Ljava/util/HashMap;

.field public static final Z:Ljava/util/HashSet;

.field public static final a0:Ljava/util/HashMap;

.field public static final b0:Ljava/nio/charset/Charset;

.field public static final c0:[B

.field public static final d0:[B

.field public static final e0:Ljava/util/regex/Pattern;

.field public static final f0:Ljava/util/regex/Pattern;

.field public static final g0:Ljava/util/regex/Pattern;

.field public static final t:Z

.field public static final u:Ljava/util/List;

.field public static final v:Ljava/util/List;

.field public static final w:[I

.field public static final x:[I

.field public static final y:[B

.field public static final z:[B


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/io/FileDescriptor;

.field public final c:Landroid/content/res/AssetManager$AssetInputStream;

.field public d:I

.field public final e:[Ljava/util/HashMap;

.field public final f:Ljava/util/HashSet;

.field public g:Ljava/nio/ByteOrder;

.field public h:Z

.field public i:Z

.field public j:Z

.field public k:I

.field public l:I

.field public m:[B

.field public n:I

.field public o:I

.field public p:I

.field public q:I

.field public r:I

.field public s:Z


# direct methods
.method static constructor <clinit>()V
    .locals 145

    const/4 v0, 0x3

    .line 1
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    .line 2
    const-string v2, "ExifInterface"

    invoke-static {v2, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    sput-boolean v2, Lq0/g;->t:Z

    const/4 v2, 0x1

    .line 3
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x6

    .line 4
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/16 v6, 0x8

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    filled-new-array {v3, v5, v1, v7}, [Ljava/lang/Integer;

    move-result-object v5

    .line 5
    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    sput-object v5, Lq0/g;->u:Ljava/util/List;

    const/4 v5, 0x2

    .line 6
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v9, 0x7

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    const/4 v11, 0x4

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    const/4 v13, 0x5

    .line 7
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    filled-new-array {v8, v10, v12, v14}, [Ljava/lang/Integer;

    move-result-object v12

    .line 8
    invoke-static {v12}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v12

    sput-object v12, Lq0/g;->v:Ljava/util/List;

    .line 9
    filled-new-array {v6, v6, v6}, [I

    move-result-object v12

    sput-object v12, Lq0/g;->w:[I

    .line 10
    filled-new-array {v6}, [I

    move-result-object v12

    sput-object v12, Lq0/g;->x:[I

    .line 11
    new-array v12, v0, [B

    fill-array-data v12, :array_0

    sput-object v12, Lq0/g;->y:[B

    .line 12
    new-array v12, v11, [B

    fill-array-data v12, :array_1

    sput-object v12, Lq0/g;->z:[B

    .line 13
    new-array v12, v11, [B

    fill-array-data v12, :array_2

    sput-object v12, Lq0/g;->A:[B

    .line 14
    new-array v12, v11, [B

    fill-array-data v12, :array_3

    sput-object v12, Lq0/g;->B:[B

    .line 15
    new-array v15, v4, [B

    fill-array-data v15, :array_4

    sput-object v15, Lq0/g;->C:[B

    const/16 v15, 0xa

    .line 16
    new-array v12, v15, [B

    fill-array-data v12, :array_5

    sput-object v12, Lq0/g;->D:[B

    .line 17
    new-array v12, v6, [B

    fill-array-data v12, :array_6

    sput-object v12, Lq0/g;->E:[B

    .line 18
    new-array v12, v11, [B

    fill-array-data v12, :array_7

    sput-object v12, Lq0/g;->F:[B

    .line 19
    new-array v12, v11, [B

    fill-array-data v12, :array_8

    sput-object v12, Lq0/g;->G:[B

    .line 20
    new-array v12, v11, [B

    fill-array-data v12, :array_9

    sput-object v12, Lq0/g;->H:[B

    .line 21
    new-array v12, v11, [B

    fill-array-data v12, :array_a

    sput-object v12, Lq0/g;->I:[B

    .line 22
    new-array v12, v11, [B

    fill-array-data v12, :array_b

    sput-object v12, Lq0/g;->J:[B

    .line 23
    new-array v12, v11, [B

    fill-array-data v12, :array_c

    sput-object v12, Lq0/g;->K:[B

    .line 24
    new-array v12, v0, [B

    fill-array-data v12, :array_d

    sput-object v12, Lq0/g;->L:[B

    .line 25
    const-string v12, "VP8X"

    invoke-static {}, Ljava/nio/charset/Charset;->defaultCharset()Ljava/nio/charset/Charset;

    move-result-object v15

    invoke-virtual {v12, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v12

    sput-object v12, Lq0/g;->M:[B

    .line 26
    const-string v12, "VP8L"

    invoke-static {}, Ljava/nio/charset/Charset;->defaultCharset()Ljava/nio/charset/Charset;

    move-result-object v15

    invoke-virtual {v12, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v12

    sput-object v12, Lq0/g;->N:[B

    .line 27
    const-string v12, "VP8 "

    invoke-static {}, Ljava/nio/charset/Charset;->defaultCharset()Ljava/nio/charset/Charset;

    move-result-object v15

    invoke-virtual {v12, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v12

    sput-object v12, Lq0/g;->O:[B

    .line 28
    const-string v12, "ANIM"

    invoke-static {}, Ljava/nio/charset/Charset;->defaultCharset()Ljava/nio/charset/Charset;

    move-result-object v15

    invoke-virtual {v12, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v12

    sput-object v12, Lq0/g;->P:[B

    .line 29
    const-string v12, "ANMF"

    invoke-static {}, Ljava/nio/charset/Charset;->defaultCharset()Ljava/nio/charset/Charset;

    move-result-object v15

    invoke-virtual {v12, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v12

    sput-object v12, Lq0/g;->Q:[B

    .line 30
    const-string v27, "SRATIONAL"

    const-string v28, "SINGLE"

    const-string v17, ""

    const-string v18, "BYTE"

    const-string v19, "STRING"

    const-string v20, "USHORT"

    const-string v21, "ULONG"

    const-string v22, "URATIONAL"

    const-string v23, "SBYTE"

    const-string v24, "UNDEFINED"

    const-string v25, "SSHORT"

    const-string v26, "SLONG"

    const-string v29, "DOUBLE"

    const-string v30, "IFD"

    filled-new-array/range {v17 .. v30}, [Ljava/lang/String;

    move-result-object v12

    sput-object v12, Lq0/g;->R:[Ljava/lang/String;

    const/16 v12, 0xe

    .line 31
    new-array v15, v12, [I

    fill-array-data v15, :array_e

    sput-object v15, Lq0/g;->S:[I

    .line 32
    new-array v15, v6, [B

    fill-array-data v15, :array_f

    sput-object v15, Lq0/g;->T:[B

    .line 33
    new-instance v15, Lq0/d;

    const-string v12, "NewSubfileType"

    const/16 v6, 0xfe

    invoke-direct {v15, v12, v6, v11}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v6, Lq0/d;

    const-string v2, "SubfileType"

    const/16 v9, 0xff

    invoke-direct {v6, v2, v9, v11}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v9, Lq0/d;

    const-string v4, "ImageWidth"

    const/16 v13, 0x100

    invoke-direct {v9, v13, v0, v11, v4}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v4, Lq0/d;

    const-string v13, "ImageLength"

    const/16 v5, 0x101

    invoke-direct {v4, v5, v0, v11, v13}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v13, Lq0/d;

    const-string v5, "BitsPerSample"

    const/16 v11, 0x102

    invoke-direct {v13, v5, v11, v0}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v11, Lq0/d;

    move-object/from16 v20, v4

    const-string v4, "Compression"

    move-object/from16 v18, v6

    const/16 v6, 0x103

    invoke-direct {v11, v4, v6, v0}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v6, Lq0/d;

    move-object/from16 v19, v9

    const-string v9, "PhotometricInterpretation"

    move-object/from16 v22, v11

    const/16 v11, 0x106

    invoke-direct {v6, v9, v11, v0}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v11, Lq0/d;

    const-string v0, "ImageDescription"

    move-object/from16 v23, v6

    const/16 v6, 0x10e

    move-object/from16 v21, v13

    const/4 v13, 0x2

    invoke-direct {v11, v0, v6, v13}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v6, Lq0/d;

    move-object/from16 v24, v11

    const-string v11, "Make"

    move-object/from16 v17, v15

    const/16 v15, 0x10f

    invoke-direct {v6, v11, v15, v13}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v15, Lq0/d;

    move-object/from16 v25, v6

    const-string v6, "Model"

    move-object/from16 v64, v7

    const/16 v7, 0x110

    invoke-direct {v15, v6, v7, v13}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v7, Lq0/d;

    const-string v13, "StripOffsets"

    move-object/from16 v26, v15

    const/16 v15, 0x111

    move-object/from16 v66, v1

    move-object/from16 v65, v10

    const/4 v1, 0x4

    const/4 v10, 0x3

    invoke-direct {v7, v15, v10, v1, v13}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v1, Lq0/d;

    const-string v15, "Orientation"

    move-object/from16 v27, v7

    const/16 v7, 0x112

    invoke-direct {v1, v15, v7, v10}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v7, Lq0/d;

    const-string v15, "SamplesPerPixel"

    move-object/from16 v28, v1

    const/16 v1, 0x115

    invoke-direct {v7, v15, v1, v10}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "RowsPerStrip"

    move-object/from16 v29, v7

    const/16 v7, 0x116

    move-object/from16 v67, v8

    const/4 v8, 0x4

    invoke-direct {v1, v7, v10, v8, v15}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v7, Lq0/d;

    const-string v15, "StripByteCounts"

    move-object/from16 v30, v1

    const/16 v1, 0x117

    invoke-direct {v7, v1, v10, v8, v15}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v1, Lq0/d;

    const-string v8, "XResolution"

    const/16 v10, 0x11a

    const/4 v15, 0x5

    invoke-direct {v1, v8, v10, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v10, "YResolution"

    move-object/from16 v32, v1

    const/16 v1, 0x11b

    invoke-direct {v8, v10, v1, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v10, "PlanarConfiguration"

    const/16 v15, 0x11c

    move-object/from16 v31, v7

    const/4 v7, 0x3

    invoke-direct {v1, v10, v15, v7}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v10, Lq0/d;

    const-string v15, "ResolutionUnit"

    move-object/from16 v34, v1

    const/16 v1, 0x128

    invoke-direct {v10, v15, v1, v7}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "TransferFunction"

    move-object/from16 v33, v8

    const/16 v8, 0x12d

    invoke-direct {v1, v15, v8, v7}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v7, Lq0/d;

    const-string v8, "Software"

    const/16 v15, 0x131

    move-object/from16 v36, v1

    const/4 v1, 0x2

    invoke-direct {v7, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "DateTime"

    move-object/from16 v37, v7

    const/16 v7, 0x132

    invoke-direct {v8, v15, v7, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v7, Lq0/d;

    const-string v15, "Artist"

    move-object/from16 v38, v8

    const/16 v8, 0x13b

    invoke-direct {v7, v15, v8, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v8, "WhitePoint"

    const/16 v15, 0x13e

    move-object/from16 v39, v7

    const/4 v7, 0x5

    invoke-direct {v1, v8, v15, v7}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "PrimaryChromaticities"

    move-object/from16 v40, v1

    const/16 v1, 0x13f

    invoke-direct {v8, v15, v1, v7}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v7, "SubIFDPointer"

    const/16 v15, 0x14a

    move-object/from16 v41, v8

    const/4 v8, 0x4

    invoke-direct {v1, v7, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v15, Lq0/d;

    move-object/from16 v42, v1

    const-string v1, "JPEGInterchangeFormat"

    move-object/from16 v35, v10

    const/16 v10, 0x201

    invoke-direct {v15, v1, v10, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v10, "JPEGInterchangeFormatLength"

    move-object/from16 v43, v15

    const/16 v15, 0x202

    invoke-direct {v1, v10, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v10, "YCbCrCoefficients"

    const/16 v15, 0x211

    move-object/from16 v44, v1

    const/4 v1, 0x5

    invoke-direct {v8, v10, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v10, "YCbCrSubSampling"

    const/16 v15, 0x212

    move-object/from16 v45, v8

    const/4 v8, 0x3

    invoke-direct {v1, v10, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v10, Lq0/d;

    const-string v15, "YCbCrPositioning"

    move-object/from16 v46, v1

    const/16 v1, 0x213

    invoke-direct {v10, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v8, "ReferenceBlackWhite"

    const/16 v15, 0x214

    move-object/from16 v47, v10

    const/4 v10, 0x5

    invoke-direct {v1, v8, v15, v10}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v10, "Copyright"

    const v15, 0x8298

    move-object/from16 v48, v1

    const/4 v1, 0x2

    invoke-direct {v8, v10, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v10, "ExifIFDPointer"

    const v15, 0x8769

    move-object/from16 v49, v8

    const/4 v8, 0x4

    invoke-direct {v1, v10, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v15, Lq0/d;

    move-object/from16 v50, v1

    const-string v1, "GPSInfoIFDPointer"

    move-object/from16 v68, v3

    const v3, 0x8825

    invoke-direct {v15, v1, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    move-object/from16 v51, v15

    const-string v15, "SensorTopBorder"

    invoke-direct {v3, v15, v8, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v15, Lq0/d;

    move-object/from16 v52, v3

    const-string v3, "SensorLeftBorder"

    move-object/from16 v69, v14

    const/4 v14, 0x5

    invoke-direct {v15, v3, v14, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "SensorBottomBorder"

    move-object/from16 v53, v15

    const/4 v15, 0x6

    invoke-direct {v3, v14, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "SensorRightBorder"

    move-object/from16 v54, v3

    const/4 v3, 0x7

    invoke-direct {v14, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "ISO"

    const/16 v3, 0x17

    move-object/from16 v55, v14

    const/4 v14, 0x3

    invoke-direct {v8, v15, v3, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "JpgFromRaw"

    const/16 v15, 0x2e

    move-object/from16 v56, v8

    const/4 v8, 0x7

    invoke-direct {v3, v14, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v14, "Xmp"

    const/16 v15, 0x2bc

    move-object/from16 v57, v3

    const/4 v3, 0x1

    invoke-direct {v8, v14, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    move-object/from16 v58, v8

    filled-new-array/range {v17 .. v58}, [Lq0/d;

    move-result-object v70

    .line 34
    new-instance v3, Lq0/d;

    const-string v8, "ExposureTime"

    const v14, 0x829a

    const/4 v15, 0x5

    invoke-direct {v3, v8, v14, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v14, "FNumber"

    move-object/from16 v71, v3

    const v3, 0x829d

    invoke-direct {v8, v14, v3, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "ExposureProgram"

    const v15, 0x8822

    move-object/from16 v72, v8

    const/4 v8, 0x3

    invoke-direct {v3, v14, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "SpectralSensitivity"

    const v8, 0x8824

    move-object/from16 v73, v3

    const/4 v3, 0x2

    invoke-direct {v14, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "PhotographicSensitivity"

    const v15, 0x8827

    move-object/from16 v74, v14

    const/4 v14, 0x3

    invoke-direct {v3, v8, v15, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "OECF"

    const v14, 0x8828

    move-object/from16 v75, v3

    const/4 v3, 0x7

    invoke-direct {v8, v15, v14, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "SensitivityType"

    const v15, 0x8830

    move-object/from16 v76, v8

    const/4 v8, 0x3

    invoke-direct {v3, v14, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v14, "StandardOutputSensitivity"

    const v15, 0x8831

    move-object/from16 v77, v3

    const/4 v3, 0x4

    invoke-direct {v8, v14, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "RecommendedExposureIndex"

    move-object/from16 v78, v8

    const v8, 0x8832

    invoke-direct {v14, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "ISOSpeed"

    move-object/from16 v79, v14

    const v14, 0x8833

    invoke-direct {v8, v15, v14, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "ISOSpeedLatitudeyyy"

    move-object/from16 v80, v8

    const v8, 0x8834

    invoke-direct {v14, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "ISOSpeedLatitudezzz"

    move-object/from16 v81, v14

    const v14, 0x8835

    invoke-direct {v8, v15, v14, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "ExifVersion"

    const v15, 0x9000

    move-object/from16 v82, v8

    const/4 v8, 0x2

    invoke-direct {v3, v14, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "DateTimeOriginal"

    move-object/from16 v83, v3

    const v3, 0x9003

    invoke-direct {v14, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "DateTimeDigitized"

    move-object/from16 v84, v14

    const v14, 0x9004

    invoke-direct {v3, v15, v14, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "OffsetTime"

    move-object/from16 v85, v3

    const v3, 0x9010

    invoke-direct {v14, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "OffsetTimeOriginal"

    move-object/from16 v86, v14

    const v14, 0x9011

    invoke-direct {v3, v15, v14, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "OffsetTimeDigitized"

    move-object/from16 v87, v3

    const v3, 0x9012

    invoke-direct {v14, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "ComponentsConfiguration"

    const v15, 0x9101

    move-object/from16 v88, v14

    const/4 v14, 0x7

    invoke-direct {v3, v8, v15, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v14, "CompressedBitsPerPixel"

    const v15, 0x9102

    move-object/from16 v89, v3

    const/4 v3, 0x5

    invoke-direct {v8, v14, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "ShutterSpeedValue"

    const v3, 0x9201

    move-object/from16 v90, v8

    const/16 v8, 0xa

    invoke-direct {v14, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "ApertureValue"

    const v8, 0x9202

    move-object/from16 v91, v14

    const/4 v14, 0x5

    invoke-direct {v3, v15, v8, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v14, "BrightnessValue"

    const v15, 0x9203

    move-object/from16 v92, v3

    const/16 v3, 0xa

    invoke-direct {v8, v14, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "ExposureBiasValue"

    move-object/from16 v93, v8

    const v8, 0x9204

    invoke-direct {v14, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "MaxApertureValue"

    const v15, 0x9205

    move-object/from16 v94, v14

    const/4 v14, 0x5

    invoke-direct {v3, v8, v15, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "SubjectDistance"

    move-object/from16 v95, v3

    const v3, 0x9206

    invoke-direct {v8, v15, v3, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "MeteringMode"

    const v15, 0x9207

    move-object/from16 v96, v8

    const/4 v8, 0x3

    invoke-direct {v3, v14, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "LightSource"

    move-object/from16 v97, v3

    const v3, 0x9208

    invoke-direct {v14, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "Flash"

    move-object/from16 v98, v14

    const v14, 0x9209

    invoke-direct {v3, v15, v14, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "FocalLength"

    const v8, 0x920a

    move-object/from16 v99, v3

    const/4 v3, 0x5

    invoke-direct {v14, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "SubjectArea"

    const v15, 0x9214

    move-object/from16 v100, v14

    const/4 v14, 0x3

    invoke-direct {v3, v8, v15, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v14, "MakerNote"

    const v15, 0x927c

    move-object/from16 v101, v3

    const/4 v3, 0x7

    invoke-direct {v8, v14, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "UserComment"

    move-object/from16 v102, v8

    const v8, 0x9286

    invoke-direct {v14, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "SubSecTime"

    const v15, 0x9290

    move-object/from16 v103, v14

    const/4 v14, 0x2

    invoke-direct {v3, v8, v15, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "SubSecTimeOriginal"

    move-object/from16 v104, v3

    const v3, 0x9291

    invoke-direct {v8, v15, v3, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "SubSecTimeDigitized"

    move-object/from16 v105, v8

    const v8, 0x9292

    invoke-direct {v3, v15, v8, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v14, "FlashpixVersion"

    const v15, 0xa000

    move-object/from16 v106, v3

    const/4 v3, 0x7

    invoke-direct {v8, v14, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "ColorSpace"

    const v15, 0xa001

    move-object/from16 v107, v8

    const/4 v8, 0x3

    invoke-direct {v3, v14, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "PixelXDimension"

    move-object/from16 v108, v3

    const v3, 0xa002

    move-object/from16 v17, v1

    const/4 v1, 0x4

    invoke-direct {v14, v3, v8, v1, v15}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v3, Lq0/d;

    const-string v15, "PixelYDimension"

    move-object/from16 v109, v14

    const v14, 0xa003

    invoke-direct {v3, v14, v8, v1, v15}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v8, Lq0/d;

    const-string v14, "RelatedSoundFile"

    const v15, 0xa004

    const/4 v1, 0x2

    invoke-direct {v8, v14, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v14, "InteroperabilityIFDPointer"

    const v15, 0xa005

    move-object/from16 v110, v3

    const/4 v3, 0x4

    invoke-direct {v1, v14, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "FlashEnergy"

    const v15, 0xa20b

    move-object/from16 v112, v1

    const/4 v1, 0x5

    invoke-direct {v3, v14, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "SpatialFrequencyResponse"

    const v1, 0xa20c

    move-object/from16 v113, v3

    const/4 v3, 0x7

    invoke-direct {v14, v15, v1, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v3, "FocalPlaneXResolution"

    const v15, 0xa20e

    move-object/from16 v111, v8

    const/4 v8, 0x5

    invoke-direct {v1, v3, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "FocalPlaneYResolution"

    move-object/from16 v115, v1

    const v1, 0xa20f

    invoke-direct {v3, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v8, "FocalPlaneResolutionUnit"

    const v15, 0xa210

    move-object/from16 v116, v3

    const/4 v3, 0x3

    invoke-direct {v1, v8, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "SubjectLocation"

    move-object/from16 v117, v1

    const v1, 0xa214

    invoke-direct {v8, v15, v1, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "ExposureIndex"

    const v3, 0xa215

    move-object/from16 v118, v8

    const/4 v8, 0x5

    invoke-direct {v1, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "SensingMethod"

    const v15, 0xa217

    move-object/from16 v119, v1

    const/4 v1, 0x3

    invoke-direct {v3, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v8, "FileSource"

    const v15, 0xa300

    move-object/from16 v120, v3

    const/4 v3, 0x7

    invoke-direct {v1, v8, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "SceneType"

    move-object/from16 v121, v1

    const v1, 0xa301

    invoke-direct {v8, v15, v1, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "CFAPattern"

    move-object/from16 v122, v8

    const v8, 0xa302

    invoke-direct {v1, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "CustomRendered"

    const v15, 0xa401

    move-object/from16 v123, v1

    const/4 v1, 0x3

    invoke-direct {v3, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "ExposureMode"

    move-object/from16 v124, v3

    const v3, 0xa402

    invoke-direct {v8, v15, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "WhiteBalance"

    move-object/from16 v125, v8

    const v8, 0xa403

    invoke-direct {v3, v15, v8, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "DigitalZoomRatio"

    const v1, 0xa404

    move-object/from16 v126, v3

    const/4 v3, 0x5

    invoke-direct {v8, v15, v1, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v3, "FocalLengthIn35mmFilm"

    const v15, 0xa405

    move-object/from16 v127, v8

    const/4 v8, 0x3

    invoke-direct {v1, v3, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "SceneCaptureType"

    move-object/from16 v128, v1

    const v1, 0xa406

    invoke-direct {v3, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "GainControl"

    move-object/from16 v129, v3

    const v3, 0xa407

    invoke-direct {v1, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "Contrast"

    move-object/from16 v130, v1

    const v1, 0xa408

    invoke-direct {v3, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "Saturation"

    move-object/from16 v131, v3

    const v3, 0xa409

    invoke-direct {v1, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "Sharpness"

    move-object/from16 v132, v1

    const v1, 0xa40a

    invoke-direct {v3, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "DeviceSettingDescription"

    const v8, 0xa40b

    move-object/from16 v133, v3

    const/4 v3, 0x7

    invoke-direct {v1, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "SubjectDistanceRange"

    const v15, 0xa40c

    move-object/from16 v134, v1

    const/4 v1, 0x3

    invoke-direct {v3, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v8, "ImageUniqueID"

    const v15, 0xa420

    move-object/from16 v135, v3

    const/4 v3, 0x2

    invoke-direct {v1, v8, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "CameraOwnerName"

    move-object/from16 v136, v1

    const v1, 0xa430

    invoke-direct {v8, v15, v1, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "BodySerialNumber"

    move-object/from16 v137, v8

    const v8, 0xa431

    invoke-direct {v1, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "LensSpecification"

    const v3, 0xa432

    move-object/from16 v138, v1

    const/4 v1, 0x5

    invoke-direct {v8, v15, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v3, "LensMake"

    const v15, 0xa433

    move-object/from16 v139, v8

    const/4 v8, 0x2

    invoke-direct {v1, v3, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "LensModel"

    move-object/from16 v140, v1

    const v1, 0xa434

    invoke-direct {v3, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v8, "Gamma"

    const v15, 0xa500

    move-object/from16 v141, v3

    const/4 v3, 0x5

    invoke-direct {v1, v8, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "DNGVersion"

    const v15, 0xc612

    move-object/from16 v142, v1

    const/4 v1, 0x1

    invoke-direct {v3, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "DefaultCropSize"

    const v1, 0xc620

    move-object/from16 v143, v3

    move-object/from16 v114, v14

    const/4 v3, 0x3

    const/4 v14, 0x4

    invoke-direct {v8, v1, v3, v14, v15}, Lq0/d;-><init>(IIILjava/lang/String;)V

    move-object/from16 v144, v8

    filled-new-array/range {v71 .. v144}, [Lq0/d;

    move-result-object v71

    .line 35
    new-instance v1, Lq0/d;

    const-string v3, "GPSVersionID"

    const/4 v8, 0x1

    const/4 v14, 0x0

    invoke-direct {v1, v3, v14, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v14, "GPSLatitudeRef"

    const/4 v15, 0x2

    invoke-direct {v3, v14, v8, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v14, "GPSLatitude"

    move-object/from16 v18, v1

    move-object/from16 v19, v3

    const/4 v1, 0x5

    const/16 v3, 0xa

    invoke-direct {v8, v15, v1, v3, v14}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v14, Lq0/d;

    const-string v1, "GPSLongitudeRef"

    const/4 v3, 0x3

    invoke-direct {v14, v1, v3, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v3, "GPSLongitude"

    move-object/from16 v20, v8

    move-object/from16 v21, v14

    const/4 v8, 0x5

    const/16 v14, 0xa

    const/4 v15, 0x4

    invoke-direct {v1, v15, v8, v14, v3}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v3, Lq0/d;

    const-string v14, "GPSAltitudeRef"

    const/4 v15, 0x1

    invoke-direct {v3, v14, v8, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "GPSAltitude"

    move-object/from16 v22, v1

    const/4 v1, 0x6

    invoke-direct {v14, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "GPSTimeStamp"

    move-object/from16 v23, v3

    const/4 v3, 0x7

    invoke-direct {v1, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "GPSSatellites"

    move-object/from16 v25, v1

    const/4 v1, 0x2

    const/16 v15, 0x8

    invoke-direct {v3, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "GPSStatus"

    move-object/from16 v26, v3

    const/16 v3, 0x9

    invoke-direct {v8, v15, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "GPSMeasureMode"

    move-object/from16 v27, v8

    const/16 v8, 0xa

    invoke-direct {v3, v15, v8, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "GPSDOP"

    const/16 v1, 0xb

    move-object/from16 v28, v3

    const/4 v3, 0x5

    invoke-direct {v8, v15, v1, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "GPSSpeedRef"

    const/16 v3, 0xc

    move-object/from16 v29, v8

    const/4 v8, 0x2

    invoke-direct {v1, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "GPSSpeed"

    move-object/from16 v30, v1

    const/16 v1, 0xd

    const/4 v8, 0x5

    invoke-direct {v3, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "GPSTrackRef"

    move-object/from16 v31, v3

    const/16 v3, 0xe

    const/4 v8, 0x2

    invoke-direct {v1, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "GPSTrack"

    const/16 v8, 0xf

    move-object/from16 v32, v1

    const/4 v1, 0x5

    invoke-direct {v3, v15, v8, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "GPSImgDirectionRef"

    const/16 v1, 0x10

    move-object/from16 v33, v3

    const/4 v3, 0x2

    invoke-direct {v8, v15, v1, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "GPSImgDirection"

    const/16 v3, 0x11

    move-object/from16 v34, v8

    const/4 v8, 0x5

    invoke-direct {v1, v15, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "GPSMapDatum"

    const/16 v15, 0x12

    move-object/from16 v35, v1

    const/4 v1, 0x2

    invoke-direct {v3, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "GPSDestLatitudeRef"

    move-object/from16 v36, v3

    const/16 v3, 0x13

    invoke-direct {v8, v15, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "GPSDestLatitude"

    const/16 v1, 0x14

    move-object/from16 v37, v8

    const/4 v8, 0x5

    invoke-direct {v3, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "GPSDestLongitudeRef"

    const/16 v8, 0x15

    move-object/from16 v38, v3

    const/4 v3, 0x2

    invoke-direct {v1, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "GPSDestLongitude"

    const/16 v3, 0x16

    move-object/from16 v39, v1

    const/4 v1, 0x5

    invoke-direct {v8, v15, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v15, "GPSDestBearingRef"

    const/16 v1, 0x17

    move-object/from16 v40, v8

    const/4 v8, 0x2

    invoke-direct {v3, v15, v1, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "GPSDestBearing"

    const/16 v8, 0x18

    move-object/from16 v41, v3

    const/4 v3, 0x5

    invoke-direct {v1, v15, v8, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "GPSDestDistanceRef"

    const/16 v3, 0x19

    move-object/from16 v42, v1

    const/4 v1, 0x2

    invoke-direct {v8, v15, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v3, "GPSDestDistance"

    move-object/from16 v43, v8

    const/16 v8, 0x1a

    const/4 v15, 0x5

    invoke-direct {v1, v3, v8, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "GPSProcessingMethod"

    const/16 v15, 0x1b

    move-object/from16 v44, v1

    const/4 v1, 0x7

    invoke-direct {v3, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const-string v15, "GPSAreaInformation"

    move-object/from16 v45, v3

    const/16 v3, 0x1c

    invoke-direct {v8, v15, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v3, "GPSDateStamp"

    const/16 v15, 0x1d

    move-object/from16 v46, v8

    const/4 v8, 0x2

    invoke-direct {v1, v3, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v8, "GPSDifferential"

    const/16 v15, 0x1e

    move-object/from16 v47, v1

    const/4 v1, 0x3

    invoke-direct {v3, v8, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v8, "GPSHPositioningError"

    const/16 v15, 0x1f

    move-object/from16 v48, v3

    const/4 v3, 0x5

    invoke-direct {v1, v8, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    move-object/from16 v49, v1

    move-object/from16 v24, v14

    filled-new-array/range {v18 .. v49}, [Lq0/d;

    move-result-object v72

    .line 36
    new-instance v1, Lq0/d;

    const-string v3, "InteroperabilityIndex"

    const/4 v8, 0x1

    const/4 v14, 0x2

    invoke-direct {v1, v3, v8, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    filled-new-array {v1}, [Lq0/d;

    move-result-object v73

    .line 37
    new-instance v1, Lq0/d;

    const/16 v3, 0xfe

    const/4 v8, 0x4

    invoke-direct {v1, v12, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const/16 v12, 0xff

    invoke-direct {v3, v2, v12, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const-string v12, "ThumbnailImageWidth"

    const/4 v14, 0x3

    const/16 v15, 0x100

    invoke-direct {v2, v15, v14, v8, v12}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v12, Lq0/d;

    const-string v15, "ThumbnailImageLength"

    move-object/from16 v18, v1

    const/16 v1, 0x101

    invoke-direct {v12, v1, v14, v8, v15}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v1, Lq0/d;

    const/16 v8, 0x102

    invoke-direct {v1, v5, v8, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v5, Lq0/d;

    const/16 v8, 0x103

    invoke-direct {v5, v4, v8, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v4, Lq0/d;

    const/16 v8, 0x106

    invoke-direct {v4, v9, v8, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v8, Lq0/d;

    const/16 v9, 0x10e

    const/4 v15, 0x2

    invoke-direct {v8, v0, v9, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const/16 v9, 0x10f

    invoke-direct {v0, v11, v9, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v9, Lq0/d;

    const/16 v11, 0x110

    invoke-direct {v9, v6, v11, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v6, Lq0/d;

    const/16 v11, 0x111

    const/4 v15, 0x4

    invoke-direct {v6, v11, v14, v15, v13}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v11, Lq0/d;

    const-string v15, "ThumbnailOrientation"

    move-object/from16 v26, v0

    const/16 v0, 0x112

    invoke-direct {v11, v15, v0, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const-string v15, "SamplesPerPixel"

    move-object/from16 v22, v1

    const/16 v1, 0x115

    invoke-direct {v0, v15, v1, v14}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "RowsPerStrip"

    move-object/from16 v30, v0

    const/16 v0, 0x116

    move-object/from16 v20, v2

    const/4 v2, 0x4

    invoke-direct {v1, v0, v14, v2, v15}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v0, Lq0/d;

    const-string v15, "StripByteCounts"

    move-object/from16 v31, v1

    const/16 v1, 0x117

    invoke-direct {v0, v1, v14, v2, v15}, Lq0/d;-><init>(IIILjava/lang/String;)V

    new-instance v1, Lq0/d;

    const-string v2, "XResolution"

    const/16 v14, 0x11a

    const/4 v15, 0x5

    invoke-direct {v1, v2, v14, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const-string v14, "YResolution"

    move-object/from16 v32, v0

    const/16 v0, 0x11b

    invoke-direct {v2, v14, v0, v15}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const-string v14, "PlanarConfiguration"

    const/16 v15, 0x11c

    move-object/from16 v33, v1

    const/4 v1, 0x3

    invoke-direct {v0, v14, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v14, Lq0/d;

    const-string v15, "ResolutionUnit"

    move-object/from16 v35, v0

    const/16 v0, 0x128

    invoke-direct {v14, v15, v0, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const-string v15, "TransferFunction"

    move-object/from16 v34, v2

    const/16 v2, 0x12d

    invoke-direct {v0, v15, v2, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v2, "Software"

    const/16 v15, 0x131

    move-object/from16 v37, v0

    const/4 v0, 0x2

    invoke-direct {v1, v2, v15, v0}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const-string v15, "DateTime"

    move-object/from16 v38, v1

    const/16 v1, 0x132

    invoke-direct {v2, v15, v1, v0}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v15, "Artist"

    move-object/from16 v39, v2

    const/16 v2, 0x13b

    invoke-direct {v1, v15, v2, v0}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const-string v2, "WhitePoint"

    const/16 v15, 0x13e

    move-object/from16 v40, v1

    const/4 v1, 0x5

    invoke-direct {v0, v2, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const-string v15, "PrimaryChromaticities"

    move-object/from16 v41, v0

    const/16 v0, 0x13f

    invoke-direct {v2, v15, v0, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const/4 v1, 0x4

    const/16 v15, 0x14a

    invoke-direct {v0, v7, v15, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v15, Lq0/d;

    move-object/from16 v43, v0

    const-string v0, "JPEGInterchangeFormat"

    move-object/from16 v42, v2

    const/16 v2, 0x201

    invoke-direct {v15, v0, v2, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const-string v2, "JPEGInterchangeFormatLength"

    move-object/from16 v19, v3

    const/16 v3, 0x202

    invoke-direct {v0, v2, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v2, "YCbCrCoefficients"

    const/16 v3, 0x211

    move-object/from16 v45, v0

    const/4 v0, 0x5

    invoke-direct {v1, v2, v3, v0}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const-string v2, "YCbCrSubSampling"

    const/16 v3, 0x212

    move-object/from16 v46, v1

    const/4 v1, 0x3

    invoke-direct {v0, v2, v3, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const-string v3, "YCbCrPositioning"

    move-object/from16 v47, v0

    const/16 v0, 0x213

    invoke-direct {v2, v3, v0, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const-string v1, "ReferenceBlackWhite"

    const/16 v3, 0x214

    move-object/from16 v48, v2

    const/4 v2, 0x5

    invoke-direct {v0, v1, v3, v2}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v2, "Copyright"

    const v3, 0x8298

    move-object/from16 v49, v0

    const/4 v0, 0x2

    invoke-direct {v1, v2, v3, v0}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const v2, 0x8769

    const/4 v3, 0x4

    invoke-direct {v0, v10, v2, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    move-object/from16 v51, v0

    move-object/from16 v50, v1

    move-object/from16 v0, v17

    const v1, 0x8825

    invoke-direct {v2, v0, v1, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lq0/d;

    const-string v3, "DNGVersion"

    move-object/from16 v52, v2

    const v2, 0xc612

    move-object/from16 v24, v4

    const/4 v4, 0x1

    invoke-direct {v1, v3, v2, v4}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const-string v3, "DefaultCropSize"

    const v4, 0xc620

    move-object/from16 v53, v1

    move-object/from16 v23, v5

    const/4 v1, 0x3

    const/4 v5, 0x4

    invoke-direct {v2, v4, v1, v5, v3}, Lq0/d;-><init>(IIILjava/lang/String;)V

    move-object/from16 v54, v2

    move-object/from16 v28, v6

    move-object/from16 v25, v8

    move-object/from16 v27, v9

    move-object/from16 v29, v11

    move-object/from16 v21, v12

    move-object/from16 v36, v14

    move-object/from16 v44, v15

    filled-new-array/range {v18 .. v54}, [Lq0/d;

    move-result-object v74

    .line 38
    new-instance v2, Lq0/d;

    const/16 v11, 0x111

    invoke-direct {v2, v13, v11, v1}, Lq0/d;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lq0/g;->U:Lq0/d;

    .line 39
    new-instance v1, Lq0/d;

    const-string v2, "ThumbnailImage"

    const/4 v3, 0x7

    const/16 v15, 0x100

    invoke-direct {v1, v2, v15, v3}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const-string v3, "CameraSettingsIFDPointer"

    const/16 v4, 0x2020

    invoke-direct {v2, v3, v4, v5}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const-string v4, "ImageProcessingIFDPointer"

    const/16 v6, 0x2040

    invoke-direct {v3, v4, v6, v5}, Lq0/d;-><init>(Ljava/lang/String;II)V

    filled-new-array {v1, v2, v3}, [Lq0/d;

    move-result-object v76

    .line 40
    new-instance v1, Lq0/d;

    const-string v2, "PreviewImageStart"

    const/16 v3, 0x101

    invoke-direct {v1, v2, v3, v5}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const-string v3, "PreviewImageLength"

    const/16 v8, 0x102

    invoke-direct {v2, v3, v8, v5}, Lq0/d;-><init>(Ljava/lang/String;II)V

    filled-new-array {v1, v2}, [Lq0/d;

    move-result-object v77

    .line 41
    new-instance v1, Lq0/d;

    const-string v2, "AspectFrame"

    const/16 v3, 0x1113

    const/4 v8, 0x3

    invoke-direct {v1, v2, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    filled-new-array {v1}, [Lq0/d;

    move-result-object v78

    .line 42
    new-instance v1, Lq0/d;

    const-string v2, "ColorSpace"

    const/16 v3, 0x37

    invoke-direct {v1, v2, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    filled-new-array {v1}, [Lq0/d;

    move-result-object v79

    move-object/from16 v75, v70

    .line 43
    filled-new-array/range {v70 .. v79}, [[Lq0/d;

    move-result-object v1

    sput-object v1, Lq0/g;->V:[[Lq0/d;

    .line 44
    new-instance v1, Lq0/d;

    const/4 v8, 0x4

    const/16 v15, 0x14a

    invoke-direct {v1, v7, v15, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v2, Lq0/d;

    const v3, 0x8769

    invoke-direct {v2, v10, v3, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v3, Lq0/d;

    const v4, 0x8825

    invoke-direct {v3, v0, v4, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v0, Lq0/d;

    const-string v4, "InteroperabilityIFDPointer"

    const v5, 0xa005

    invoke-direct {v0, v4, v5, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v4, Lq0/d;

    const-string v5, "CameraSettingsIFDPointer"

    const/16 v6, 0x2020

    const/4 v8, 0x1

    invoke-direct {v4, v5, v6, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    new-instance v5, Lq0/d;

    const-string v6, "ImageProcessingIFDPointer"

    const/16 v7, 0x2040

    invoke-direct {v5, v6, v7, v8}, Lq0/d;-><init>(Ljava/lang/String;II)V

    move-object/from16 v20, v0

    move-object/from16 v17, v1

    move-object/from16 v18, v2

    move-object/from16 v19, v3

    move-object/from16 v21, v4

    move-object/from16 v22, v5

    filled-new-array/range {v17 .. v22}, [Lq0/d;

    move-result-object v0

    sput-object v0, Lq0/g;->W:[Lq0/d;

    const/16 v3, 0xa

    .line 45
    new-array v0, v3, [Ljava/util/HashMap;

    sput-object v0, Lq0/g;->X:[Ljava/util/HashMap;

    .line 46
    new-array v0, v3, [Ljava/util/HashMap;

    sput-object v0, Lq0/g;->Y:[Ljava/util/HashMap;

    .line 47
    new-instance v0, Ljava/util/HashSet;

    const-string v1, "DigitalZoomRatio"

    const-string v2, "ExposureTime"

    const-string v3, "FNumber"

    const-string v4, "SubjectDistance"

    const-string v5, "GPSTimeStamp"

    filled-new-array {v3, v1, v2, v4, v5}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    sput-object v0, Lq0/g;->Z:Ljava/util/HashSet;

    .line 48
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lq0/g;->a0:Ljava/util/HashMap;

    .line 49
    const-string v0, "US-ASCII"

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    sput-object v0, Lq0/g;->b0:Ljava/nio/charset/Charset;

    .line 50
    const-string v1, "Exif\u0000\u0000"

    invoke-virtual {v1, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    sput-object v1, Lq0/g;->c0:[B

    .line 51
    const-string v1, "http://ns.adobe.com/xap/1.0/\u0000"

    .line 52
    invoke-virtual {v1, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    sput-object v0, Lq0/g;->d0:[B

    .line 53
    new-instance v0, Ljava/text/SimpleDateFormat;

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string/jumbo v2, "yyyy:MM:dd HH:mm:ss"

    invoke-direct {v0, v2, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 54
    const-string v2, "UTC"

    invoke-static {v2}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 55
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string/jumbo v2, "yyyy-MM-dd HH:mm:ss"

    invoke-direct {v0, v2, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 56
    const-string v1, "UTC"

    invoke-static {v1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    const/4 v14, 0x0

    .line 57
    :goto_0
    sget-object v0, Lq0/g;->V:[[Lq0/d;

    array-length v1, v0

    if-ge v14, v1, :cond_1

    .line 58
    sget-object v1, Lq0/g;->X:[Ljava/util/HashMap;

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    aput-object v2, v1, v14

    .line 59
    sget-object v1, Lq0/g;->Y:[Ljava/util/HashMap;

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    aput-object v2, v1, v14

    .line 60
    aget-object v0, v0, v14

    array-length v1, v0

    const/4 v2, 0x0

    :goto_1
    if-ge v2, v1, :cond_0

    aget-object v3, v0, v2

    .line 61
    sget-object v4, Lq0/g;->X:[Ljava/util/HashMap;

    aget-object v4, v4, v14

    iget v5, v3, Lq0/d;->a:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    sget-object v4, Lq0/g;->Y:[Ljava/util/HashMap;

    aget-object v4, v4, v14

    iget-object v5, v3, Lq0/d;->b:Ljava/lang/String;

    invoke-virtual {v4, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v59, 0x1

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_0
    const/16 v59, 0x1

    add-int/lit8 v14, v14, 0x1

    goto :goto_0

    :cond_1
    const/16 v59, 0x1

    .line 63
    sget-object v0, Lq0/g;->a0:Ljava/util/HashMap;

    sget-object v1, Lq0/g;->W:[Lq0/d;

    const/16 v16, 0x0

    aget-object v2, v1, v16

    iget v2, v2, Lq0/d;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v69

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    aget-object v2, v1, v59

    iget v2, v2, Lq0/d;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v68

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v61, 0x2

    .line 65
    aget-object v2, v1, v61

    iget v2, v2, Lq0/d;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v67

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v63, 0x3

    .line 66
    aget-object v2, v1, v63

    iget v2, v2, Lq0/d;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v66

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v62, 0x4

    .line 67
    aget-object v2, v1, v62

    iget v2, v2, Lq0/d;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v65

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v60, 0x5

    .line 68
    aget-object v1, v1, v60

    iget v1, v1, Lq0/d;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v64

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    const-string v0, ".*[1-9].*"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 70
    const-string v0, "^(\\d{2}):(\\d{2}):(\\d{2})$"

    .line 71
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lq0/g;->e0:Ljava/util/regex/Pattern;

    .line 72
    const-string v0, "^(\\d{4}):(\\d{2}):(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$"

    .line 73
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lq0/g;->f0:Ljava/util/regex/Pattern;

    .line 74
    const-string v0, "^(\\d{4})-(\\d{2})-(\\d{2})\\s(\\d{2}):(\\d{2}):(\\d{2})$"

    .line 75
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lq0/g;->g0:Ljava/util/regex/Pattern;

    return-void

    nop

    :array_0
    .array-data 1
        -0x1t
        -0x28t
        -0x1t
    .end array-data

    :array_1
    .array-data 1
        0x66t
        0x74t
        0x79t
        0x70t
    .end array-data

    :array_2
    .array-data 1
        0x6dt
        0x69t
        0x66t
        0x31t
    .end array-data

    :array_3
    .array-data 1
        0x68t
        0x65t
        0x69t
        0x63t
    .end array-data

    :array_4
    .array-data 1
        0x4ft
        0x4ct
        0x59t
        0x4dt
        0x50t
        0x0t
    .end array-data

    nop

    :array_5
    .array-data 1
        0x4ft
        0x4ct
        0x59t
        0x4dt
        0x50t
        0x55t
        0x53t
        0x0t
        0x49t
        0x49t
    .end array-data

    nop

    :array_6
    .array-data 1
        -0x77t
        0x50t
        0x4et
        0x47t
        0xdt
        0xat
        0x1at
        0xat
    .end array-data

    :array_7
    .array-data 1
        0x65t
        0x58t
        0x49t
        0x66t
    .end array-data

    :array_8
    .array-data 1
        0x49t
        0x48t
        0x44t
        0x52t
    .end array-data

    :array_9
    .array-data 1
        0x49t
        0x45t
        0x4et
        0x44t
    .end array-data

    :array_a
    .array-data 1
        0x52t
        0x49t
        0x46t
        0x46t
    .end array-data

    :array_b
    .array-data 1
        0x57t
        0x45t
        0x42t
        0x50t
    .end array-data

    :array_c
    .array-data 1
        0x45t
        0x58t
        0x49t
        0x46t
    .end array-data

    :array_d
    .array-data 1
        -0x63t
        0x1t
        0x2at
    .end array-data

    :array_e
    .array-data 4
        0x0
        0x1
        0x1
        0x2
        0x4
        0x8
        0x1
        0x1
        0x2
        0x4
        0x8
        0x4
        0x8
        0x1
    .end array-data

    :array_f
    .array-data 1
        0x41t
        0x53t
        0x43t
        0x49t
        0x49t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method

.method public constructor <init>(Ljava/io/FileDescriptor;)V
    .locals 5

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    sget-object v0, Lq0/g;->V:[[Lq0/d;

    array-length v1, v0

    new-array v1, v1, [Ljava/util/HashMap;

    iput-object v1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 18
    new-instance v1, Ljava/util/HashSet;

    array-length v0, v0

    invoke-direct {v1, v0}, Ljava/util/HashSet;-><init>(I)V

    iput-object v1, p0, Lq0/g;->f:Ljava/util/HashSet;

    .line 19
    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    iput-object v0, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    if-eqz p1, :cond_2

    const/4 v0, 0x0

    .line 20
    iput-object v0, p0, Lq0/g;->c:Landroid/content/res/AssetManager$AssetInputStream;

    .line 21
    iput-object v0, p0, Lq0/g;->a:Ljava/lang/String;

    .line 22
    :try_start_0
    sget v1, Landroid/system/OsConstants;->SEEK_CUR:I

    const-wide/16 v2, 0x0

    invoke-static {p1, v2, v3, v1}, Lq0/h;->c(Ljava/io/FileDescriptor;JI)J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 23
    iput-object p1, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 24
    :try_start_1
    invoke-static {p1}, Lq0/h;->b(Ljava/io/FileDescriptor;)Ljava/io/FileDescriptor;

    move-result-object p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v1, 0x1

    goto :goto_0

    :catch_0
    move-exception p1

    .line 25
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Failed to duplicate file descriptor"

    invoke-direct {v0, v1, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    .line 26
    :catch_1
    iput-object v0, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    const/4 v1, 0x0

    .line 27
    :goto_0
    :try_start_2
    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 28
    :try_start_3
    invoke-virtual {p0, v2}, Lq0/g;->t(Ljava/io/InputStream;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 29
    invoke-static {v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    if-eqz v1, :cond_0

    .line 30
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->f(Ljava/io/FileDescriptor;)V

    :cond_0
    return-void

    :catchall_0
    move-exception v0

    goto :goto_1

    :catchall_1
    move-exception v2

    move-object v4, v2

    move-object v2, v0

    move-object v0, v4

    .line 31
    :goto_1
    invoke-static {v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    if-eqz v1, :cond_1

    .line 32
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->f(Ljava/io/FileDescriptor;)V

    .line 33
    :cond_1
    throw v0

    .line 34
    :cond_2
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "fileDescriptor cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 6

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 36
    sget-object v0, Lq0/g;->V:[[Lq0/d;

    array-length v1, v0

    new-array v1, v1, [Ljava/util/HashMap;

    iput-object v1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 37
    new-instance v1, Ljava/util/HashSet;

    array-length v0, v0

    invoke-direct {v1, v0}, Ljava/util/HashSet;-><init>(I)V

    iput-object v1, p0, Lq0/g;->f:Ljava/util/HashSet;

    .line 38
    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    iput-object v0, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    if-eqz p1, :cond_2

    const/4 v0, 0x0

    .line 39
    iput-object v0, p0, Lq0/g;->a:Ljava/lang/String;

    .line 40
    instance-of v1, p1, Landroid/content/res/AssetManager$AssetInputStream;

    if-eqz v1, :cond_0

    .line 41
    move-object v1, p1

    check-cast v1, Landroid/content/res/AssetManager$AssetInputStream;

    iput-object v1, p0, Lq0/g;->c:Landroid/content/res/AssetManager$AssetInputStream;

    .line 42
    iput-object v0, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    goto :goto_0

    .line 43
    :cond_0
    instance-of v1, p1, Ljava/io/FileInputStream;

    if-eqz v1, :cond_1

    move-object v1, p1

    check-cast v1, Ljava/io/FileInputStream;

    .line 44
    invoke-virtual {v1}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v2

    .line 45
    :try_start_0
    sget v3, Landroid/system/OsConstants;->SEEK_CUR:I

    const-wide/16 v4, 0x0

    invoke-static {v2, v4, v5, v3}, Lq0/h;->c(Ljava/io/FileDescriptor;JI)J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 46
    iput-object v0, p0, Lq0/g;->c:Landroid/content/res/AssetManager$AssetInputStream;

    .line 47
    invoke-virtual {v1}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v0

    iput-object v0, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    goto :goto_0

    .line 48
    :catch_0
    :cond_1
    iput-object v0, p0, Lq0/g;->c:Landroid/content/res/AssetManager$AssetInputStream;

    .line 49
    iput-object v0, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 50
    :goto_0
    invoke-virtual {p0, p1}, Lq0/g;->t(Ljava/io/InputStream;)V

    return-void

    .line 51
    :cond_2
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "inputStream cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, Lq0/g;->V:[[Lq0/d;

    array-length v1, v0

    new-array v1, v1, [Ljava/util/HashMap;

    iput-object v1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 3
    new-instance v1, Ljava/util/HashSet;

    array-length v0, v0

    invoke-direct {v1, v0}, Ljava/util/HashSet;-><init>(I)V

    iput-object v1, p0, Lq0/g;->f:Ljava/util/HashSet;

    .line 4
    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    iput-object v0, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    if-eqz p1, :cond_1

    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lq0/g;->c:Landroid/content/res/AssetManager$AssetInputStream;

    .line 6
    iput-object p1, p0, Lq0/g;->a:Ljava/lang/String;

    .line 7
    :try_start_0
    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 8
    :try_start_1
    invoke-virtual {v1}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 9
    :try_start_2
    sget v2, Landroid/system/OsConstants;->SEEK_CUR:I

    const-wide/16 v3, 0x0

    invoke-static {p1, v3, v4, v2}, Lq0/h;->c(Ljava/io/FileDescriptor;JI)J
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 p1, 0x1

    goto :goto_1

    :goto_0
    move-object v0, v1

    goto :goto_3

    :catch_0
    const/4 p1, 0x0

    :goto_1
    if-eqz p1, :cond_0

    .line 10
    :try_start_3
    invoke-virtual {v1}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object p1

    iput-object p1, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    goto :goto_2

    :catchall_0
    move-exception p1

    goto :goto_0

    .line 11
    :cond_0
    iput-object v0, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 12
    :goto_2
    invoke-virtual {p0, v1}, Lq0/g;->t(Ljava/io/InputStream;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 13
    invoke-static {v1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    return-void

    :catchall_1
    move-exception p1

    :goto_3
    invoke-static {v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 14
    throw p1

    .line 15
    :cond_1
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "filename cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)D
    .locals 11

    .line 1
    const-string v0, "/"

    .line 2
    .line 3
    :try_start_0
    const-string v1, ","

    .line 4
    .line 5
    const/4 v2, -0x1

    .line 6
    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    const/4 v1, 0x0

    .line 11
    aget-object v3, p0, v1

    .line 12
    .line 13
    invoke-virtual {v3, v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    aget-object v4, v3, v1

    .line 18
    .line 19
    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    invoke-static {v4}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 24
    .line 25
    .line 26
    move-result-wide v4

    .line 27
    const/4 v6, 0x1

    .line 28
    aget-object v3, v3, v6

    .line 29
    .line 30
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    invoke-static {v3}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 35
    .line 36
    .line 37
    move-result-wide v7

    .line 38
    div-double/2addr v4, v7

    .line 39
    aget-object v3, p0, v6

    .line 40
    .line 41
    invoke-virtual {v3, v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    aget-object v7, v3, v1

    .line 46
    .line 47
    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v7

    .line 51
    invoke-static {v7}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 52
    .line 53
    .line 54
    move-result-wide v7

    .line 55
    aget-object v3, v3, v6

    .line 56
    .line 57
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    invoke-static {v3}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 62
    .line 63
    .line 64
    move-result-wide v9

    .line 65
    div-double/2addr v7, v9

    .line 66
    const/4 v3, 0x2

    .line 67
    aget-object p0, p0, v3

    .line 68
    .line 69
    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    aget-object v0, p0, v1

    .line 74
    .line 75
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 80
    .line 81
    .line 82
    move-result-wide v0

    .line 83
    aget-object p0, p0, v6

    .line 84
    .line 85
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 90
    .line 91
    .line 92
    move-result-wide v2

    .line 93
    div-double/2addr v0, v2

    .line 94
    const-wide/high16 v2, 0x404e000000000000L    # 60.0

    .line 95
    .line 96
    div-double/2addr v7, v2

    .line 97
    add-double/2addr v7, v4

    .line 98
    const-wide v2, 0x40ac200000000000L    # 3600.0

    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    div-double/2addr v0, v2

    .line 104
    add-double/2addr v0, v7

    .line 105
    const-string p0, "S"

    .line 106
    .line 107
    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result p0

    .line 111
    if-nez p0, :cond_3

    .line 112
    .line 113
    const-string p0, "W"

    .line 114
    .line 115
    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result p0

    .line 119
    if-eqz p0, :cond_0

    .line 120
    .line 121
    goto :goto_1

    .line 122
    :cond_0
    const-string p0, "N"

    .line 123
    .line 124
    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result p0

    .line 128
    if-nez p0, :cond_2

    .line 129
    .line 130
    const-string p0, "E"

    .line 131
    .line 132
    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result p0

    .line 136
    if-eqz p0, :cond_1

    .line 137
    .line 138
    goto :goto_0

    .line 139
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 140
    .line 141
    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 142
    .line 143
    .line 144
    throw p0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    .line 145
    :cond_2
    :goto_0
    return-wide v0

    .line 146
    :cond_3
    :goto_1
    neg-double p0, v0

    .line 147
    return-wide p0

    .line 148
    :catch_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 149
    .line 150
    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 151
    .line 152
    .line 153
    throw p0
.end method

.method public static c(Lq0/b;Landroidx/camera/core/impl/utils/c;[B[B)V
    .locals 4

    .line 1
    :cond_0
    const/4 v0, 0x4

    .line 2
    new-array v1, v0, [B

    .line 3
    .line 4
    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    .line 5
    .line 6
    .line 7
    move-result v2

    .line 8
    if-eq v2, v0, :cond_2

    .line 9
    .line 10
    new-instance p0, Ljava/io/IOException;

    .line 11
    .line 12
    new-instance p1, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v0, "Encountered invalid length while copying WebP chunks up tochunk type "

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    new-instance v0, Ljava/lang/String;

    .line 20
    .line 21
    sget-object v1, Lq0/g;->b0:Ljava/nio/charset/Charset;

    .line 22
    .line 23
    invoke-direct {v0, p2, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    if-nez p3, :cond_1

    .line 30
    .line 31
    const-string p2, ""

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    new-instance p2, Ljava/lang/String;

    .line 35
    .line 36
    invoke-direct {p2, p3, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 37
    .line 38
    .line 39
    const-string p3, " or "

    .line 40
    .line 41
    invoke-virtual {p3, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p2

    .line 45
    :goto_0
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    throw p0

    .line 56
    :cond_2
    invoke-virtual {p0}, Lq0/b;->readInt()I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    invoke-virtual {p1, v1}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 64
    .line 65
    .line 66
    rem-int/lit8 v2, v0, 0x2

    .line 67
    .line 68
    const/4 v3, 0x1

    .line 69
    if-ne v2, v3, :cond_3

    .line 70
    .line 71
    add-int/lit8 v0, v0, 0x1

    .line 72
    .line 73
    :cond_3
    invoke-static {p0, p1, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->k(Lq0/b;Landroidx/camera/core/impl/utils/c;I)V

    .line 74
    .line 75
    .line 76
    invoke-static {v1, p2}, Ljava/util/Arrays;->equals([B[B)Z

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    if-nez v0, :cond_4

    .line 81
    .line 82
    if-eqz p3, :cond_0

    .line 83
    .line 84
    invoke-static {v1, p3}, Ljava/util/Arrays;->equals([B[B)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-eqz v0, :cond_0

    .line 89
    .line 90
    :cond_4
    return-void
.end method

.method public static q(Ljava/lang/String;)Landroid/util/Pair;
    .locals 10

    .line 1
    const-string v0, ","

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    const/4 v4, 0x2

    .line 10
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 11
    .line 12
    .line 13
    move-result-object v5

    .line 14
    const/4 v6, -0x1

    .line 15
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object v7

    .line 19
    if-eqz v1, :cond_9

    .line 20
    .line 21
    invoke-virtual {p0, v0, v6}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    aget-object v0, p0, v2

    .line 26
    .line 27
    invoke-static {v0}, Lq0/g;->q(Ljava/lang/String;)Landroid/util/Pair;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v1, Ljava/lang/Integer;

    .line 34
    .line 35
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-ne v1, v4, :cond_0

    .line 40
    .line 41
    return-object v0

    .line 42
    :cond_0
    :goto_0
    array-length v1, p0

    .line 43
    if-ge v3, v1, :cond_8

    .line 44
    .line 45
    aget-object v1, p0, v3

    .line 46
    .line 47
    invoke-static {v1}, Lq0/g;->q(Ljava/lang/String;)Landroid/util/Pair;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    iget-object v2, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v2, Ljava/lang/Integer;

    .line 54
    .line 55
    iget-object v4, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 56
    .line 57
    invoke-virtual {v2, v4}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    if-nez v2, :cond_2

    .line 62
    .line 63
    iget-object v2, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v2, Ljava/lang/Integer;

    .line 66
    .line 67
    iget-object v4, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 68
    .line 69
    invoke-virtual {v2, v4}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    if-eqz v2, :cond_1

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_1
    move v2, v6

    .line 77
    goto :goto_2

    .line 78
    :cond_2
    :goto_1
    iget-object v2, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v2, Ljava/lang/Integer;

    .line 81
    .line 82
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    :goto_2
    iget-object v4, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v4, Ljava/lang/Integer;

    .line 89
    .line 90
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    if-eq v4, v6, :cond_4

    .line 95
    .line 96
    iget-object v4, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v4, Ljava/lang/Integer;

    .line 99
    .line 100
    iget-object v8, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 101
    .line 102
    invoke-virtual {v4, v8}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    move-result v4

    .line 106
    if-nez v4, :cond_3

    .line 107
    .line 108
    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v1, Ljava/lang/Integer;

    .line 111
    .line 112
    iget-object v4, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 113
    .line 114
    invoke-virtual {v1, v4}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    if-eqz v1, :cond_4

    .line 119
    .line 120
    :cond_3
    iget-object v1, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 121
    .line 122
    check-cast v1, Ljava/lang/Integer;

    .line 123
    .line 124
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 125
    .line 126
    .line 127
    move-result v1

    .line 128
    goto :goto_3

    .line 129
    :cond_4
    move v1, v6

    .line 130
    :goto_3
    if-ne v2, v6, :cond_5

    .line 131
    .line 132
    if-ne v1, v6, :cond_5

    .line 133
    .line 134
    new-instance p0, Landroid/util/Pair;

    .line 135
    .line 136
    invoke-direct {p0, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    return-object p0

    .line 140
    :cond_5
    if-ne v2, v6, :cond_6

    .line 141
    .line 142
    new-instance v0, Landroid/util/Pair;

    .line 143
    .line 144
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    invoke-direct {v0, v1, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    goto :goto_4

    .line 152
    :cond_6
    if-ne v1, v6, :cond_7

    .line 153
    .line 154
    new-instance v0, Landroid/util/Pair;

    .line 155
    .line 156
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 157
    .line 158
    .line 159
    move-result-object v1

    .line 160
    invoke-direct {v0, v1, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    :cond_7
    :goto_4
    add-int/lit8 v3, v3, 0x1

    .line 164
    .line 165
    goto :goto_0

    .line 166
    :cond_8
    return-object v0

    .line 167
    :cond_9
    const-string v0, "/"

    .line 168
    .line 169
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 170
    .line 171
    .line 172
    move-result v1

    .line 173
    const-wide/16 v8, 0x0

    .line 174
    .line 175
    if-eqz v1, :cond_f

    .line 176
    .line 177
    invoke-virtual {p0, v0, v6}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object p0

    .line 181
    array-length v0, p0

    .line 182
    if-ne v0, v4, :cond_e

    .line 183
    .line 184
    :try_start_0
    aget-object v0, p0, v2

    .line 185
    .line 186
    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 187
    .line 188
    .line 189
    move-result-wide v0

    .line 190
    double-to-long v0, v0

    .line 191
    aget-object p0, p0, v3

    .line 192
    .line 193
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 194
    .line 195
    .line 196
    move-result-wide v2

    .line 197
    double-to-long v2, v2

    .line 198
    cmp-long p0, v0, v8

    .line 199
    .line 200
    const/16 v4, 0xa

    .line 201
    .line 202
    if-ltz p0, :cond_d

    .line 203
    .line 204
    cmp-long p0, v2, v8

    .line 205
    .line 206
    if-gez p0, :cond_a

    .line 207
    .line 208
    goto :goto_6

    .line 209
    :cond_a
    const-wide/32 v8, 0x7fffffff

    .line 210
    .line 211
    .line 212
    cmp-long p0, v0, v8

    .line 213
    .line 214
    const/4 v0, 0x5

    .line 215
    if-gtz p0, :cond_c

    .line 216
    .line 217
    cmp-long p0, v2, v8

    .line 218
    .line 219
    if-lez p0, :cond_b

    .line 220
    .line 221
    goto :goto_5

    .line 222
    :cond_b
    new-instance p0, Landroid/util/Pair;

    .line 223
    .line 224
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 225
    .line 226
    .line 227
    move-result-object v1

    .line 228
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 229
    .line 230
    .line 231
    move-result-object v0

    .line 232
    invoke-direct {p0, v1, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 233
    .line 234
    .line 235
    return-object p0

    .line 236
    :cond_c
    :goto_5
    new-instance p0, Landroid/util/Pair;

    .line 237
    .line 238
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    invoke-direct {p0, v0, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 243
    .line 244
    .line 245
    return-object p0

    .line 246
    :cond_d
    :goto_6
    new-instance p0, Landroid/util/Pair;

    .line 247
    .line 248
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    invoke-direct {p0, v0, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 253
    .line 254
    .line 255
    return-object p0

    .line 256
    :catch_0
    :cond_e
    new-instance p0, Landroid/util/Pair;

    .line 257
    .line 258
    invoke-direct {p0, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 259
    .line 260
    .line 261
    return-object p0

    .line 262
    :cond_f
    :try_start_1
    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 263
    .line 264
    .line 265
    move-result-wide v0

    .line 266
    cmp-long v2, v0, v8

    .line 267
    .line 268
    const/4 v3, 0x4

    .line 269
    if-ltz v2, :cond_10

    .line 270
    .line 271
    const-wide/32 v8, 0xffff

    .line 272
    .line 273
    .line 274
    cmp-long v0, v0, v8

    .line 275
    .line 276
    if-gtz v0, :cond_10

    .line 277
    .line 278
    new-instance v0, Landroid/util/Pair;

    .line 279
    .line 280
    const/4 v1, 0x3

    .line 281
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 282
    .line 283
    .line 284
    move-result-object v1

    .line 285
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 286
    .line 287
    .line 288
    move-result-object v2

    .line 289
    invoke-direct {v0, v1, v2}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 290
    .line 291
    .line 292
    return-object v0

    .line 293
    :cond_10
    if-gez v2, :cond_11

    .line 294
    .line 295
    new-instance v0, Landroid/util/Pair;

    .line 296
    .line 297
    const/16 v1, 0x9

    .line 298
    .line 299
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 300
    .line 301
    .line 302
    move-result-object v1

    .line 303
    invoke-direct {v0, v1, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 304
    .line 305
    .line 306
    return-object v0

    .line 307
    :cond_11
    new-instance v0, Landroid/util/Pair;

    .line 308
    .line 309
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 310
    .line 311
    .line 312
    move-result-object v1

    .line 313
    invoke-direct {v0, v1, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    .line 314
    .line 315
    .line 316
    return-object v0

    .line 317
    :catch_1
    :try_start_2
    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 318
    .line 319
    .line 320
    new-instance p0, Landroid/util/Pair;

    .line 321
    .line 322
    const/16 v0, 0xc

    .line 323
    .line 324
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    invoke-direct {p0, v0, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_2

    .line 329
    .line 330
    .line 331
    return-object p0

    .line 332
    :catch_2
    new-instance p0, Landroid/util/Pair;

    .line 333
    .line 334
    invoke-direct {p0, v5, v7}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 335
    .line 336
    .line 337
    return-object p0
.end method

.method public static w(Lq0/b;)Ljava/nio/ByteOrder;
    .locals 3

    .line 1
    invoke-virtual {p0}, Lq0/b;->readShort()S

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const/16 v0, 0x4949

    .line 6
    .line 7
    if-eq p0, v0, :cond_1

    .line 8
    .line 9
    const/16 v0, 0x4d4d

    .line 10
    .line 11
    if-ne p0, v0, :cond_0

    .line 12
    .line 13
    sget-object p0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 14
    .line 15
    return-object p0

    .line 16
    :cond_0
    new-instance v0, Ljava/io/IOException;

    .line 17
    .line 18
    new-instance v1, Ljava/lang/StringBuilder;

    .line 19
    .line 20
    const-string v2, "Invalid byte order: "

    .line 21
    .line 22
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    throw v0

    .line 40
    :cond_1
    sget-object p0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 41
    .line 42
    return-object p0
.end method


# virtual methods
.method public final A(ILjava/lang/String;Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 2
    .line 3
    aget-object v1, v0, p1

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/HashMap;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-nez v1, :cond_0

    .line 10
    .line 11
    aget-object v1, v0, p1

    .line 12
    .line 13
    invoke-virtual {v1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    aget-object v1, v0, p1

    .line 20
    .line 21
    invoke-virtual {v1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    invoke-virtual {v1, p3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    aget-object p1, v0, p1

    .line 29
    .line 30
    invoke-virtual {p1, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    :cond_0
    return-void
.end method

.method public final B()V
    .locals 14

    .line 1
    const-string v0, "Failed to save new file. Original file is stored in "

    .line 2
    .line 3
    iget v1, p0, Lq0/g;->d:I

    .line 4
    .line 5
    const/16 v2, 0xe

    .line 6
    .line 7
    const/16 v3, 0xd

    .line 8
    .line 9
    const/4 v4, 0x4

    .line 10
    if-eq v1, v4, :cond_1

    .line 11
    .line 12
    if-eq v1, v3, :cond_1

    .line 13
    .line 14
    if-ne v1, v2, :cond_0

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    new-instance v0, Ljava/io/IOException;

    .line 18
    .line 19
    const-string v1, "ExifInterface only supports saving attributes for JPEG, PNG, and WebP formats."

    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    throw v0

    .line 25
    :cond_1
    :goto_0
    iget-object v1, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 26
    .line 27
    if-nez v1, :cond_3

    .line 28
    .line 29
    iget-object v1, p0, Lq0/g;->a:Ljava/lang/String;

    .line 30
    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    goto :goto_1

    .line 34
    :cond_2
    new-instance v0, Ljava/io/IOException;

    .line 35
    .line 36
    const-string v1, "ExifInterface does not support saving attributes for the current input."

    .line 37
    .line 38
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw v0

    .line 42
    :cond_3
    :goto_1
    iget-boolean v1, p0, Lq0/g;->h:Z

    .line 43
    .line 44
    if-eqz v1, :cond_5

    .line 45
    .line 46
    iget-boolean v1, p0, Lq0/g;->i:Z

    .line 47
    .line 48
    if-eqz v1, :cond_5

    .line 49
    .line 50
    iget-boolean v1, p0, Lq0/g;->j:Z

    .line 51
    .line 52
    if-eqz v1, :cond_4

    .line 53
    .line 54
    goto :goto_2

    .line 55
    :cond_4
    new-instance v0, Ljava/io/IOException;

    .line 56
    .line 57
    const-string v1, "ExifInterface does not support saving attributes when the image file has non-consecutive thumbnail strips"

    .line 58
    .line 59
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    throw v0

    .line 63
    :cond_5
    :goto_2
    iget v1, p0, Lq0/g;->n:I

    .line 64
    .line 65
    const/4 v5, 0x6

    .line 66
    const/4 v6, 0x0

    .line 67
    if-eq v1, v5, :cond_7

    .line 68
    .line 69
    const/4 v5, 0x7

    .line 70
    if-ne v1, v5, :cond_6

    .line 71
    .line 72
    goto :goto_3

    .line 73
    :cond_6
    move-object v1, v6

    .line 74
    goto :goto_4

    .line 75
    :cond_7
    :goto_3
    invoke-virtual {p0}, Lq0/g;->o()[B

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    :goto_4
    iput-object v1, p0, Lq0/g;->m:[B

    .line 80
    .line 81
    :try_start_0
    const-string/jumbo v1, "temp"

    .line 82
    .line 83
    .line 84
    const-string/jumbo v5, "tmp"

    .line 85
    .line 86
    .line 87
    invoke-static {v1, v5}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    iget-object v5, p0, Lq0/g;->a:Ljava/lang/String;

    .line 92
    .line 93
    const-wide/16 v7, 0x0

    .line 94
    .line 95
    if-eqz v5, :cond_8

    .line 96
    .line 97
    new-instance v5, Ljava/io/FileInputStream;

    .line 98
    .line 99
    iget-object v9, p0, Lq0/g;->a:Ljava/lang/String;

    .line 100
    .line 101
    invoke-direct {v5, v9}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    goto :goto_5

    .line 105
    :catchall_0
    move-exception v0

    .line 106
    move-object v9, v6

    .line 107
    goto/16 :goto_14

    .line 108
    .line 109
    :catch_0
    move-exception v0

    .line 110
    move-object v9, v6

    .line 111
    goto/16 :goto_13

    .line 112
    .line 113
    :cond_8
    iget-object v5, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 114
    .line 115
    sget v9, Landroid/system/OsConstants;->SEEK_SET:I

    .line 116
    .line 117
    invoke-static {v5, v7, v8, v9}, Lq0/h;->c(Ljava/io/FileDescriptor;JI)J

    .line 118
    .line 119
    .line 120
    new-instance v5, Ljava/io/FileInputStream;

    .line 121
    .line 122
    iget-object v9, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 123
    .line 124
    invoke-direct {v5, v9}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 125
    .line 126
    .line 127
    :goto_5
    :try_start_1
    new-instance v9, Ljava/io/FileOutputStream;

    .line 128
    .line 129
    invoke-direct {v9, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_9
    .catchall {:try_start_1 .. :try_end_1} :catchall_7

    .line 130
    .line 131
    .line 132
    :try_start_2
    invoke-static {v5, v9}, Lcom/palmpay/lib/apm/launchcounter/util/d;->j(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_8
    .catchall {:try_start_2 .. :try_end_2} :catchall_6

    .line 133
    .line 134
    .line 135
    invoke-static {v5}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 136
    .line 137
    .line 138
    invoke-static {v9}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 139
    .line 140
    .line 141
    const/4 v5, 0x0

    .line 142
    :try_start_3
    new-instance v9, Ljava/io/FileInputStream;

    .line 143
    .line 144
    invoke-direct {v9, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_5
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 145
    .line 146
    .line 147
    :try_start_4
    iget-object v10, p0, Lq0/g;->a:Ljava/lang/String;

    .line 148
    .line 149
    if-eqz v10, :cond_9

    .line 150
    .line 151
    new-instance v10, Ljava/io/FileOutputStream;

    .line 152
    .line 153
    iget-object v11, p0, Lq0/g;->a:Ljava/lang/String;

    .line 154
    .line 155
    invoke-direct {v10, v11}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    goto :goto_8

    .line 159
    :catchall_1
    move-exception v0

    .line 160
    move-object v12, v6

    .line 161
    goto/16 :goto_10

    .line 162
    .line 163
    :catch_1
    move-exception v2

    .line 164
    move-object v10, v6

    .line 165
    move-object v11, v10

    .line 166
    :goto_6
    move-object v12, v11

    .line 167
    :goto_7
    move-object v6, v9

    .line 168
    goto :goto_b

    .line 169
    :cond_9
    iget-object v10, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 170
    .line 171
    sget v11, Landroid/system/OsConstants;->SEEK_SET:I

    .line 172
    .line 173
    invoke-static {v10, v7, v8, v11}, Lq0/h;->c(Ljava/io/FileDescriptor;JI)J

    .line 174
    .line 175
    .line 176
    new-instance v10, Ljava/io/FileOutputStream;

    .line 177
    .line 178
    iget-object v11, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 179
    .line 180
    invoke-direct {v10, v11}, Ljava/io/FileOutputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 181
    .line 182
    .line 183
    :goto_8
    :try_start_5
    new-instance v11, Ljava/io/BufferedInputStream;

    .line 184
    .line 185
    invoke-direct {v11, v9}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_4
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 186
    .line 187
    .line 188
    :try_start_6
    new-instance v12, Ljava/io/BufferedOutputStream;

    .line 189
    .line 190
    invoke-direct {v12, v10}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 191
    .line 192
    .line 193
    :try_start_7
    iget v13, p0, Lq0/g;->d:I

    .line 194
    .line 195
    if-ne v13, v4, :cond_a

    .line 196
    .line 197
    invoke-virtual {p0, v11, v12}, Lq0/g;->C(Ljava/io/BufferedInputStream;Ljava/io/BufferedOutputStream;)V

    .line 198
    .line 199
    .line 200
    goto :goto_a

    .line 201
    :goto_9
    move-object v6, v11

    .line 202
    goto/16 :goto_10

    .line 203
    .line 204
    :cond_a
    if-ne v13, v3, :cond_b

    .line 205
    .line 206
    invoke-virtual {p0, v11, v12}, Lq0/g;->D(Ljava/io/BufferedInputStream;Ljava/io/BufferedOutputStream;)V

    .line 207
    .line 208
    .line 209
    goto :goto_a

    .line 210
    :cond_b
    if-ne v13, v2, :cond_c

    .line 211
    .line 212
    invoke-virtual {p0, v11, v12}, Lq0/g;->E(Ljava/io/BufferedInputStream;Ljava/io/BufferedOutputStream;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_2
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 213
    .line 214
    .line 215
    :cond_c
    :goto_a
    invoke-static {v11}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 216
    .line 217
    .line 218
    invoke-static {v12}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    .line 222
    .line 223
    .line 224
    iput-object v6, p0, Lq0/g;->m:[B

    .line 225
    .line 226
    return-void

    .line 227
    :catchall_2
    move-exception v0

    .line 228
    goto :goto_9

    .line 229
    :catch_2
    move-exception v2

    .line 230
    goto :goto_7

    .line 231
    :catchall_3
    move-exception v0

    .line 232
    move-object v12, v6

    .line 233
    goto :goto_9

    .line 234
    :catch_3
    move-exception v2

    .line 235
    move-object v12, v6

    .line 236
    goto :goto_7

    .line 237
    :catch_4
    move-exception v2

    .line 238
    move-object v11, v6

    .line 239
    goto :goto_6

    .line 240
    :catch_5
    move-exception v2

    .line 241
    move-object v10, v6

    .line 242
    move-object v11, v10

    .line 243
    move-object v12, v11

    .line 244
    :goto_b
    :try_start_8
    new-instance v3, Ljava/io/FileInputStream;

    .line 245
    .line 246
    invoke-direct {v3, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_7
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    .line 247
    .line 248
    .line 249
    :try_start_9
    iget-object v4, p0, Lq0/g;->a:Ljava/lang/String;

    .line 250
    .line 251
    if-nez v4, :cond_d

    .line 252
    .line 253
    iget-object v4, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 254
    .line 255
    sget v6, Landroid/system/OsConstants;->SEEK_SET:I

    .line 256
    .line 257
    invoke-static {v4, v7, v8, v6}, Lq0/h;->c(Ljava/io/FileDescriptor;JI)J

    .line 258
    .line 259
    .line 260
    new-instance v4, Ljava/io/FileOutputStream;

    .line 261
    .line 262
    iget-object v6, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 263
    .line 264
    invoke-direct {v4, v6}, Ljava/io/FileOutputStream;-><init>(Ljava/io/FileDescriptor;)V

    .line 265
    .line 266
    .line 267
    :goto_c
    move-object v10, v4

    .line 268
    goto :goto_d

    .line 269
    :catchall_4
    move-exception v0

    .line 270
    move-object v6, v3

    .line 271
    goto :goto_f

    .line 272
    :catch_6
    move-exception v2

    .line 273
    move-object v6, v3

    .line 274
    goto :goto_e

    .line 275
    :cond_d
    new-instance v4, Ljava/io/FileOutputStream;

    .line 276
    .line 277
    iget-object v6, p0, Lq0/g;->a:Ljava/lang/String;

    .line 278
    .line 279
    invoke-direct {v4, v6}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    .line 280
    .line 281
    .line 282
    goto :goto_c

    .line 283
    :goto_d
    invoke-static {v3, v10}, Lcom/palmpay/lib/apm/launchcounter/util/d;->j(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_6
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 284
    .line 285
    .line 286
    :try_start_a
    invoke-static {v3}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 287
    .line 288
    .line 289
    invoke-static {v10}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 290
    .line 291
    .line 292
    new-instance v0, Ljava/io/IOException;

    .line 293
    .line 294
    const-string v3, "Failed to save new file"

    .line 295
    .line 296
    invoke-direct {v0, v3, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 297
    .line 298
    .line 299
    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .line 300
    :catchall_5
    move-exception v0

    .line 301
    goto :goto_f

    .line 302
    :catch_7
    move-exception v2

    .line 303
    :goto_e
    const/4 v5, 0x1

    .line 304
    :try_start_b
    new-instance v3, Ljava/io/IOException;

    .line 305
    .line 306
    new-instance v4, Ljava/lang/StringBuilder;

    .line 307
    .line 308
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 309
    .line 310
    .line 311
    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 316
    .line 317
    .line 318
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 319
    .line 320
    .line 321
    move-result-object v0

    .line 322
    invoke-direct {v3, v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 323
    .line 324
    .line 325
    throw v3
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 326
    :goto_f
    :try_start_c
    invoke-static {v6}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 327
    .line 328
    .line 329
    invoke-static {v10}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 330
    .line 331
    .line 332
    throw v0
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_2

    .line 333
    :goto_10
    invoke-static {v6}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 334
    .line 335
    .line 336
    invoke-static {v12}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 337
    .line 338
    .line 339
    if-nez v5, :cond_e

    .line 340
    .line 341
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    .line 342
    .line 343
    .line 344
    :cond_e
    throw v0

    .line 345
    :catchall_6
    move-exception v0

    .line 346
    :goto_11
    move-object v6, v5

    .line 347
    goto :goto_14

    .line 348
    :catch_8
    move-exception v0

    .line 349
    :goto_12
    move-object v6, v5

    .line 350
    goto :goto_13

    .line 351
    :catchall_7
    move-exception v0

    .line 352
    move-object v9, v6

    .line 353
    goto :goto_11

    .line 354
    :catch_9
    move-exception v0

    .line 355
    move-object v9, v6

    .line 356
    goto :goto_12

    .line 357
    :goto_13
    :try_start_d
    new-instance v1, Ljava/io/IOException;

    .line 358
    .line 359
    const-string v2, "Failed to copy original file to temp file"

    .line 360
    .line 361
    invoke-direct {v1, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 362
    .line 363
    .line 364
    throw v1
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_8

    .line 365
    :catchall_8
    move-exception v0

    .line 366
    :goto_14
    invoke-static {v6}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 367
    .line 368
    .line 369
    invoke-static {v9}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 370
    .line 371
    .line 372
    throw v0
.end method

.method public final C(Ljava/io/BufferedInputStream;Ljava/io/BufferedOutputStream;)V
    .locals 12

    .line 1
    sget-boolean v0, Lq0/g;->t:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    invoke-static {p2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    :cond_0
    new-instance v0, Lq0/b;

    .line 12
    .line 13
    invoke-direct {v0, p1}, Lq0/b;-><init>(Ljava/io/InputStream;)V

    .line 14
    .line 15
    .line 16
    new-instance p1, Landroidx/camera/core/impl/utils/c;

    .line 17
    .line 18
    sget-object v1, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 19
    .line 20
    invoke-direct {p1, p2, v1}, Landroidx/camera/core/impl/utils/c;-><init>(Ljava/io/OutputStream;Ljava/nio/ByteOrder;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, Lq0/b;->readByte()B

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    const-string v1, "Invalid marker"

    .line 28
    .line 29
    const/4 v2, -0x1

    .line 30
    if-ne p2, v2, :cond_d

    .line 31
    .line 32
    invoke-virtual {p1, v2}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0}, Lq0/b;->readByte()B

    .line 36
    .line 37
    .line 38
    move-result p2

    .line 39
    const/16 v3, -0x28

    .line 40
    .line 41
    if-ne p2, v3, :cond_c

    .line 42
    .line 43
    invoke-virtual {p1, v3}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 44
    .line 45
    .line 46
    const-string p2, "Xmp"

    .line 47
    .line 48
    invoke-virtual {p0, p2}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    iget-object v4, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 53
    .line 54
    const/4 v5, 0x0

    .line 55
    if-eqz v3, :cond_1

    .line 56
    .line 57
    iget-boolean v3, p0, Lq0/g;->s:Z

    .line 58
    .line 59
    if-eqz v3, :cond_1

    .line 60
    .line 61
    aget-object v3, v4, v5

    .line 62
    .line 63
    invoke-virtual {v3, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    check-cast v3, Lq0/c;

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_1
    const/4 v3, 0x0

    .line 71
    :goto_0
    invoke-virtual {p1, v2}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 72
    .line 73
    .line 74
    const/16 v6, -0x1f

    .line 75
    .line 76
    invoke-virtual {p1, v6}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {p0, p1}, Lq0/g;->K(Landroidx/camera/core/impl/utils/c;)V

    .line 80
    .line 81
    .line 82
    if-eqz v3, :cond_2

    .line 83
    .line 84
    aget-object v4, v4, v5

    .line 85
    .line 86
    invoke-virtual {v4, p2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    :cond_2
    const/16 p2, 0x1000

    .line 90
    .line 91
    new-array v3, p2, [B

    .line 92
    .line 93
    :cond_3
    :goto_1
    invoke-virtual {v0}, Lq0/b;->readByte()B

    .line 94
    .line 95
    .line 96
    move-result v4

    .line 97
    if-ne v4, v2, :cond_b

    .line 98
    .line 99
    invoke-virtual {v0}, Lq0/b;->readByte()B

    .line 100
    .line 101
    .line 102
    move-result v4

    .line 103
    const/16 v7, -0x27

    .line 104
    .line 105
    if-eq v4, v7, :cond_a

    .line 106
    .line 107
    const/16 v7, -0x26

    .line 108
    .line 109
    if-eq v4, v7, :cond_a

    .line 110
    .line 111
    const-string v7, "Invalid length"

    .line 112
    .line 113
    if-eq v4, v6, :cond_5

    .line 114
    .line 115
    invoke-virtual {p1, v2}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {p1, v4}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v0}, Lq0/b;->readUnsignedShort()I

    .line 122
    .line 123
    .line 124
    move-result v4

    .line 125
    int-to-short v8, v4

    .line 126
    invoke-virtual {p1, v8}, Landroidx/camera/core/impl/utils/c;->c(S)V

    .line 127
    .line 128
    .line 129
    add-int/lit8 v4, v4, -0x2

    .line 130
    .line 131
    if-ltz v4, :cond_4

    .line 132
    .line 133
    :goto_2
    if-lez v4, :cond_3

    .line 134
    .line 135
    invoke-static {v4, p2}, Ljava/lang/Math;->min(II)I

    .line 136
    .line 137
    .line 138
    move-result v7

    .line 139
    invoke-virtual {v0, v3, v5, v7}, Lq0/b;->read([BII)I

    .line 140
    .line 141
    .line 142
    move-result v7

    .line 143
    if-ltz v7, :cond_3

    .line 144
    .line 145
    invoke-virtual {p1, v3, v5, v7}, Landroidx/camera/core/impl/utils/c;->write([BII)V

    .line 146
    .line 147
    .line 148
    sub-int/2addr v4, v7

    .line 149
    goto :goto_2

    .line 150
    :cond_4
    new-instance p1, Ljava/io/IOException;

    .line 151
    .line 152
    invoke-direct {p1, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    throw p1

    .line 156
    :cond_5
    invoke-virtual {v0}, Lq0/b;->readUnsignedShort()I

    .line 157
    .line 158
    .line 159
    move-result v8

    .line 160
    add-int/lit8 v9, v8, -0x2

    .line 161
    .line 162
    if-ltz v9, :cond_9

    .line 163
    .line 164
    const/4 v7, 0x6

    .line 165
    new-array v10, v7, [B

    .line 166
    .line 167
    if-lt v9, v7, :cond_7

    .line 168
    .line 169
    invoke-virtual {v0, v10}, Ljava/io/InputStream;->read([B)I

    .line 170
    .line 171
    .line 172
    move-result v11

    .line 173
    if-ne v11, v7, :cond_6

    .line 174
    .line 175
    sget-object v11, Lq0/g;->c0:[B

    .line 176
    .line 177
    invoke-static {v10, v11}, Ljava/util/Arrays;->equals([B[B)Z

    .line 178
    .line 179
    .line 180
    move-result v11

    .line 181
    if-eqz v11, :cond_7

    .line 182
    .line 183
    add-int/lit8 v8, v8, -0x8

    .line 184
    .line 185
    invoke-virtual {v0, v8}, Lq0/b;->a(I)V

    .line 186
    .line 187
    .line 188
    goto :goto_1

    .line 189
    :cond_6
    new-instance p1, Ljava/io/IOException;

    .line 190
    .line 191
    const-string p2, "Invalid exif"

    .line 192
    .line 193
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    throw p1

    .line 197
    :cond_7
    invoke-virtual {p1, v2}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {p1, v4}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 201
    .line 202
    .line 203
    int-to-short v4, v8

    .line 204
    invoke-virtual {p1, v4}, Landroidx/camera/core/impl/utils/c;->c(S)V

    .line 205
    .line 206
    .line 207
    if-lt v9, v7, :cond_8

    .line 208
    .line 209
    add-int/lit8 v9, v8, -0x8

    .line 210
    .line 211
    invoke-virtual {p1, v10}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 212
    .line 213
    .line 214
    :cond_8
    :goto_3
    if-lez v9, :cond_3

    .line 215
    .line 216
    invoke-static {v9, p2}, Ljava/lang/Math;->min(II)I

    .line 217
    .line 218
    .line 219
    move-result v4

    .line 220
    invoke-virtual {v0, v3, v5, v4}, Lq0/b;->read([BII)I

    .line 221
    .line 222
    .line 223
    move-result v4

    .line 224
    if-ltz v4, :cond_3

    .line 225
    .line 226
    invoke-virtual {p1, v3, v5, v4}, Landroidx/camera/core/impl/utils/c;->write([BII)V

    .line 227
    .line 228
    .line 229
    sub-int/2addr v9, v4

    .line 230
    goto :goto_3

    .line 231
    :cond_9
    new-instance p1, Ljava/io/IOException;

    .line 232
    .line 233
    invoke-direct {p1, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    throw p1

    .line 237
    :cond_a
    invoke-virtual {p1, v2}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {p1, v4}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 241
    .line 242
    .line 243
    invoke-static {v0, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->j(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    .line 244
    .line 245
    .line 246
    return-void

    .line 247
    :cond_b
    new-instance p1, Ljava/io/IOException;

    .line 248
    .line 249
    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    throw p1

    .line 253
    :cond_c
    new-instance p1, Ljava/io/IOException;

    .line 254
    .line 255
    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    throw p1

    .line 259
    :cond_d
    new-instance p1, Ljava/io/IOException;

    .line 260
    .line 261
    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    throw p1
.end method

.method public final D(Ljava/io/BufferedInputStream;Ljava/io/BufferedOutputStream;)V
    .locals 5

    .line 1
    sget-boolean v0, Lq0/g;->t:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    invoke-static {p2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    :cond_0
    new-instance v0, Lq0/b;

    .line 12
    .line 13
    invoke-direct {v0, p1}, Lq0/b;-><init>(Ljava/io/InputStream;)V

    .line 14
    .line 15
    .line 16
    new-instance p1, Landroidx/camera/core/impl/utils/c;

    .line 17
    .line 18
    sget-object v1, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 19
    .line 20
    invoke-direct {p1, p2, v1}, Landroidx/camera/core/impl/utils/c;-><init>(Ljava/io/OutputStream;Ljava/nio/ByteOrder;)V

    .line 21
    .line 22
    .line 23
    sget-object p2, Lq0/g;->E:[B

    .line 24
    .line 25
    array-length v2, p2

    .line 26
    invoke-static {v0, p1, v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->k(Lq0/b;Landroidx/camera/core/impl/utils/c;I)V

    .line 27
    .line 28
    .line 29
    iget v2, p0, Lq0/g;->o:I

    .line 30
    .line 31
    if-nez v2, :cond_1

    .line 32
    .line 33
    invoke-virtual {v0}, Lq0/b;->readInt()I

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    invoke-virtual {p1, p2}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 38
    .line 39
    .line 40
    add-int/lit8 p2, p2, 0x8

    .line 41
    .line 42
    invoke-static {v0, p1, p2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->k(Lq0/b;Landroidx/camera/core/impl/utils/c;I)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    array-length p2, p2

    .line 47
    sub-int/2addr v2, p2

    .line 48
    add-int/lit8 v2, v2, -0x8

    .line 49
    .line 50
    invoke-static {v0, p1, v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->k(Lq0/b;Landroidx/camera/core/impl/utils/c;I)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0}, Lq0/b;->readInt()I

    .line 54
    .line 55
    .line 56
    move-result p2

    .line 57
    add-int/lit8 p2, p2, 0x8

    .line 58
    .line 59
    invoke-virtual {v0, p2}, Lq0/b;->a(I)V

    .line 60
    .line 61
    .line 62
    :goto_0
    const/4 p2, 0x0

    .line 63
    :try_start_0
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    .line 64
    .line 65
    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 66
    .line 67
    .line 68
    :try_start_1
    new-instance p2, Landroidx/camera/core/impl/utils/c;

    .line 69
    .line 70
    invoke-direct {p2, v2, v1}, Landroidx/camera/core/impl/utils/c;-><init>(Ljava/io/OutputStream;Ljava/nio/ByteOrder;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p0, p2}, Lq0/g;->K(Landroidx/camera/core/impl/utils/c;)V

    .line 74
    .line 75
    .line 76
    iget-object p2, p2, Landroidx/camera/core/impl/utils/c;->b:Ljava/io/OutputStream;

    .line 77
    .line 78
    check-cast p2, Ljava/io/ByteArrayOutputStream;

    .line 79
    .line 80
    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 81
    .line 82
    .line 83
    move-result-object p2

    .line 84
    invoke-virtual {p1, p2}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 85
    .line 86
    .line 87
    new-instance v1, Ljava/util/zip/CRC32;

    .line 88
    .line 89
    invoke-direct {v1}, Ljava/util/zip/CRC32;-><init>()V

    .line 90
    .line 91
    .line 92
    array-length v3, p2

    .line 93
    const/4 v4, 0x4

    .line 94
    sub-int/2addr v3, v4

    .line 95
    invoke-virtual {v1, p2, v4, v3}, Ljava/util/zip/CRC32;->update([BII)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v1}, Ljava/util/zip/CRC32;->getValue()J

    .line 99
    .line 100
    .line 101
    move-result-wide v3

    .line 102
    long-to-int p2, v3

    .line 103
    invoke-virtual {p1, p2}, Landroidx/camera/core/impl/utils/c;->b(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 104
    .line 105
    .line 106
    invoke-static {v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 107
    .line 108
    .line 109
    invoke-static {v0, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->j(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    .line 110
    .line 111
    .line 112
    return-void

    .line 113
    :catchall_0
    move-exception p1

    .line 114
    move-object p2, v2

    .line 115
    goto :goto_1

    .line 116
    :catchall_1
    move-exception p1

    .line 117
    :goto_1
    invoke-static {p2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 118
    .line 119
    .line 120
    throw p1
.end method

.method public final E(Ljava/io/BufferedInputStream;Ljava/io/BufferedOutputStream;)V
    .locals 22

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    sget-boolean v2, Lq0/g;->t:Z

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    invoke-static/range {p2 .. p2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    :cond_0
    new-instance v2, Lq0/b;

    .line 16
    .line 17
    sget-object v3, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 18
    .line 19
    invoke-direct {v2, v0, v3}, Lq0/b;-><init>(Ljava/io/InputStream;Ljava/nio/ByteOrder;)V

    .line 20
    .line 21
    .line 22
    new-instance v4, Landroidx/camera/core/impl/utils/c;

    .line 23
    .line 24
    move-object/from16 v5, p2

    .line 25
    .line 26
    invoke-direct {v4, v5, v3}, Landroidx/camera/core/impl/utils/c;-><init>(Ljava/io/OutputStream;Ljava/nio/ByteOrder;)V

    .line 27
    .line 28
    .line 29
    sget-object v5, Lq0/g;->I:[B

    .line 30
    .line 31
    array-length v6, v5

    .line 32
    invoke-static {v2, v4, v6}, Lcom/palmpay/lib/apm/launchcounter/util/d;->k(Lq0/b;Landroidx/camera/core/impl/utils/c;I)V

    .line 33
    .line 34
    .line 35
    sget-object v6, Lq0/g;->J:[B

    .line 36
    .line 37
    array-length v7, v6

    .line 38
    const/4 v8, 0x4

    .line 39
    add-int/2addr v7, v8

    .line 40
    invoke-virtual {v2, v7}, Lq0/b;->a(I)V

    .line 41
    .line 42
    .line 43
    const/4 v7, 0x0

    .line 44
    :try_start_0
    new-instance v9, Ljava/io/ByteArrayOutputStream;

    .line 45
    .line 46
    invoke-direct {v9}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_5
    .catchall {:try_start_0 .. :try_end_0} :catchall_5

    .line 47
    .line 48
    .line 49
    :try_start_1
    new-instance v10, Landroidx/camera/core/impl/utils/c;

    .line 50
    .line 51
    invoke-direct {v10, v9, v3}, Landroidx/camera/core/impl/utils/c;-><init>(Ljava/io/OutputStream;Ljava/nio/ByteOrder;)V

    .line 52
    .line 53
    .line 54
    iget v3, v1, Lq0/g;->o:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    .line 55
    .line 56
    const/16 v11, 0x8

    .line 57
    .line 58
    if-eqz v3, :cond_3

    .line 59
    .line 60
    :try_start_2
    array-length v0, v5

    .line 61
    add-int/2addr v0, v8

    .line 62
    array-length v5, v6

    .line 63
    add-int/2addr v0, v5

    .line 64
    sub-int/2addr v3, v0

    .line 65
    sub-int/2addr v3, v11

    .line 66
    invoke-static {v2, v10, v3}, Lcom/palmpay/lib/apm/launchcounter/util/d;->k(Lq0/b;Landroidx/camera/core/impl/utils/c;I)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v2, v8}, Lq0/b;->a(I)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v2}, Lq0/b;->readInt()I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    rem-int/lit8 v3, v0, 0x2

    .line 77
    .line 78
    if-eqz v3, :cond_1

    .line 79
    .line 80
    add-int/lit8 v0, v0, 0x1

    .line 81
    .line 82
    :cond_1
    invoke-virtual {v2, v0}, Lq0/b;->a(I)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v1, v10}, Lq0/g;->K(Landroidx/camera/core/impl/utils/c;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 86
    .line 87
    .line 88
    :cond_2
    :goto_0
    move-object/from16 v17, v4

    .line 89
    .line 90
    move-object/from16 v16, v9

    .line 91
    .line 92
    goto/16 :goto_8

    .line 93
    .line 94
    :catchall_0
    move-exception v0

    .line 95
    move-object v7, v9

    .line 96
    goto/16 :goto_c

    .line 97
    .line 98
    :catch_0
    move-exception v0

    .line 99
    move-object v7, v9

    .line 100
    goto/16 :goto_b

    .line 101
    .line 102
    :cond_3
    :try_start_3
    new-array v3, v8, [B

    .line 103
    .line 104
    invoke-virtual {v2, v3}, Ljava/io/InputStream;->read([B)I

    .line 105
    .line 106
    .line 107
    move-result v5

    .line 108
    if-ne v5, v8, :cond_14

    .line 109
    .line 110
    sget-object v5, Lq0/g;->M:[B

    .line 111
    .line 112
    invoke-static {v3, v5}, Ljava/util/Arrays;->equals([B[B)Z

    .line 113
    .line 114
    .line 115
    move-result v12
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    .line 116
    const/4 v13, 0x1

    .line 117
    sget-object v14, Lq0/g;->O:[B

    .line 118
    .line 119
    sget-object v15, Lq0/g;->N:[B

    .line 120
    .line 121
    const/16 v16, 0x0

    .line 122
    .line 123
    if-eqz v12, :cond_9

    .line 124
    .line 125
    :try_start_4
    invoke-virtual {v2}, Lq0/b;->readInt()I

    .line 126
    .line 127
    .line 128
    move-result v3

    .line 129
    rem-int/lit8 v12, v3, 0x2

    .line 130
    .line 131
    if-ne v12, v13, :cond_4

    .line 132
    .line 133
    add-int/lit8 v12, v3, 0x1

    .line 134
    .line 135
    goto :goto_1

    .line 136
    :cond_4
    move v12, v3

    .line 137
    :goto_1
    new-array v12, v12, [B

    .line 138
    .line 139
    invoke-virtual {v2, v12}, Ljava/io/InputStream;->read([B)I

    .line 140
    .line 141
    .line 142
    aget-byte v17, v12, v16

    .line 143
    .line 144
    or-int/lit8 v11, v17, 0x8

    .line 145
    .line 146
    int-to-byte v11, v11

    .line 147
    aput-byte v11, v12, v16

    .line 148
    .line 149
    shr-int/2addr v11, v13

    .line 150
    and-int/2addr v11, v13

    .line 151
    if-ne v11, v13, :cond_5

    .line 152
    .line 153
    move/from16 v16, v13

    .line 154
    .line 155
    :cond_5
    invoke-virtual {v10, v5}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v10, v3}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 159
    .line 160
    .line 161
    invoke-virtual {v10, v12}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 162
    .line 163
    .line 164
    if-eqz v16, :cond_8

    .line 165
    .line 166
    sget-object v3, Lq0/g;->P:[B

    .line 167
    .line 168
    invoke-static {v2, v10, v3, v7}, Lq0/g;->c(Lq0/b;Landroidx/camera/core/impl/utils/c;[B[B)V

    .line 169
    .line 170
    .line 171
    :goto_2
    new-array v3, v8, [B

    .line 172
    .line 173
    invoke-virtual {v0, v3}, Ljava/io/InputStream;->read([B)I

    .line 174
    .line 175
    .line 176
    sget-object v5, Lq0/g;->Q:[B

    .line 177
    .line 178
    invoke-static {v3, v5}, Ljava/util/Arrays;->equals([B[B)Z

    .line 179
    .line 180
    .line 181
    move-result v5

    .line 182
    if-nez v5, :cond_6

    .line 183
    .line 184
    invoke-virtual {v1, v10}, Lq0/g;->K(Landroidx/camera/core/impl/utils/c;)V

    .line 185
    .line 186
    .line 187
    goto :goto_0

    .line 188
    :cond_6
    invoke-virtual {v2}, Lq0/b;->readInt()I

    .line 189
    .line 190
    .line 191
    move-result v5

    .line 192
    invoke-virtual {v10, v3}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v10, v5}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 196
    .line 197
    .line 198
    rem-int/lit8 v3, v5, 0x2

    .line 199
    .line 200
    if-ne v3, v13, :cond_7

    .line 201
    .line 202
    add-int/lit8 v5, v5, 0x1

    .line 203
    .line 204
    :cond_7
    invoke-static {v2, v10, v5}, Lcom/palmpay/lib/apm/launchcounter/util/d;->k(Lq0/b;Landroidx/camera/core/impl/utils/c;I)V

    .line 205
    .line 206
    .line 207
    goto :goto_2

    .line 208
    :cond_8
    invoke-static {v2, v10, v14, v15}, Lq0/g;->c(Lq0/b;Landroidx/camera/core/impl/utils/c;[B[B)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v1, v10}, Lq0/g;->K(Landroidx/camera/core/impl/utils/c;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 212
    .line 213
    .line 214
    goto :goto_0

    .line 215
    :cond_9
    :try_start_5
    invoke-static {v3, v14}, Ljava/util/Arrays;->equals([B[B)Z

    .line 216
    .line 217
    .line 218
    move-result v0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_4
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 219
    if-nez v0, :cond_a

    .line 220
    .line 221
    :try_start_6
    invoke-static {v3, v15}, Ljava/util/Arrays;->equals([B[B)Z

    .line 222
    .line 223
    .line 224
    move-result v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 225
    if-eqz v0, :cond_2

    .line 226
    .line 227
    :cond_a
    :try_start_7
    invoke-virtual {v2}, Lq0/b;->readInt()I

    .line 228
    .line 229
    .line 230
    move-result v0

    .line 231
    rem-int/lit8 v7, v0, 0x2

    .line 232
    .line 233
    if-ne v7, v13, :cond_b

    .line 234
    .line 235
    add-int/lit8 v7, v0, 0x1

    .line 236
    .line 237
    goto :goto_3

    .line 238
    :cond_b
    move v7, v0

    .line 239
    :goto_3
    const/4 v12, 0x3

    .line 240
    move/from16 p2, v8

    .line 241
    .line 242
    new-array v8, v12, [B

    .line 243
    .line 244
    invoke-static {v3, v14}, Ljava/util/Arrays;->equals([B[B)Z

    .line 245
    .line 246
    .line 247
    move-result v17
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_4
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 248
    move/from16 v18, v11

    .line 249
    .line 250
    move/from16 v19, v13

    .line 251
    .line 252
    sget-object v13, Lq0/g;->L:[B

    .line 253
    .line 254
    if-eqz v17, :cond_d

    .line 255
    .line 256
    :try_start_8
    invoke-virtual {v2, v8}, Ljava/io/InputStream;->read([B)I

    .line 257
    .line 258
    .line 259
    new-array v11, v12, [B

    .line 260
    .line 261
    move/from16 v17, v7

    .line 262
    .line 263
    invoke-virtual {v2, v11}, Ljava/io/InputStream;->read([B)I

    .line 264
    .line 265
    .line 266
    move-result v7

    .line 267
    if-ne v7, v12, :cond_c

    .line 268
    .line 269
    invoke-static {v13, v11}, Ljava/util/Arrays;->equals([B[B)Z

    .line 270
    .line 271
    .line 272
    move-result v7

    .line 273
    if-eqz v7, :cond_c

    .line 274
    .line 275
    invoke-virtual {v2}, Lq0/b;->readInt()I

    .line 276
    .line 277
    .line 278
    move-result v7

    .line 279
    shl-int/lit8 v11, v7, 0x12

    .line 280
    .line 281
    shr-int/lit8 v11, v11, 0x12

    .line 282
    .line 283
    shl-int/lit8 v12, v7, 0x2

    .line 284
    .line 285
    shr-int/lit8 v12, v12, 0x12

    .line 286
    .line 287
    add-int/lit8 v17, v17, -0xa

    .line 288
    .line 289
    move/from16 v19, v12

    .line 290
    .line 291
    move v12, v11

    .line 292
    move/from16 v11, v17

    .line 293
    .line 294
    move/from16 v17, v19

    .line 295
    .line 296
    move/from16 v19, v16

    .line 297
    .line 298
    goto :goto_5

    .line 299
    :cond_c
    new-instance v0, Ljava/io/IOException;

    .line 300
    .line 301
    const-string v2, "Encountered error while checking VP8 signature"

    .line 302
    .line 303
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    throw v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 307
    :cond_d
    move/from16 v17, v7

    .line 308
    .line 309
    :try_start_9
    invoke-static {v3, v15}, Ljava/util/Arrays;->equals([B[B)Z

    .line 310
    .line 311
    .line 312
    move-result v7
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 313
    if-eqz v7, :cond_10

    .line 314
    .line 315
    :try_start_a
    invoke-virtual {v2}, Lq0/b;->readByte()B

    .line 316
    .line 317
    .line 318
    move-result v7

    .line 319
    const/16 v11, 0x2f

    .line 320
    .line 321
    if-ne v7, v11, :cond_f

    .line 322
    .line 323
    invoke-virtual {v2}, Lq0/b;->readInt()I

    .line 324
    .line 325
    .line 326
    move-result v7

    .line 327
    and-int/lit16 v11, v7, 0x3fff

    .line 328
    .line 329
    add-int/lit8 v11, v11, 0x1

    .line 330
    .line 331
    const v12, 0xfffc000

    .line 332
    .line 333
    .line 334
    and-int/2addr v12, v7

    .line 335
    ushr-int/lit8 v12, v12, 0xe

    .line 336
    .line 337
    add-int/lit8 v12, v12, 0x1

    .line 338
    .line 339
    const/high16 v20, 0x10000000

    .line 340
    .line 341
    and-int v20, v7, v20

    .line 342
    .line 343
    if-eqz v20, :cond_e

    .line 344
    .line 345
    goto :goto_4

    .line 346
    :cond_e
    move/from16 v19, v16

    .line 347
    .line 348
    :goto_4
    add-int/lit8 v17, v17, -0x5

    .line 349
    .line 350
    move/from16 v21, v12

    .line 351
    .line 352
    move v12, v11

    .line 353
    move/from16 v11, v17

    .line 354
    .line 355
    move/from16 v17, v21

    .line 356
    .line 357
    goto :goto_5

    .line 358
    :cond_f
    new-instance v0, Ljava/io/IOException;

    .line 359
    .line 360
    const-string v2, "Encountered error while checking VP8L signature"

    .line 361
    .line 362
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 363
    .line 364
    .line 365
    throw v0
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_0
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    .line 366
    :cond_10
    move/from16 v7, v16

    .line 367
    .line 368
    move v12, v7

    .line 369
    move/from16 v19, v12

    .line 370
    .line 371
    move/from16 v11, v17

    .line 372
    .line 373
    move/from16 v17, v19

    .line 374
    .line 375
    :goto_5
    :try_start_b
    invoke-virtual {v10, v5}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 376
    .line 377
    .line 378
    const/16 v5, 0xa

    .line 379
    .line 380
    invoke-virtual {v10, v5}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 381
    .line 382
    .line 383
    new-array v5, v5, [B
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_4
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 384
    .line 385
    if-eqz v19, :cond_11

    .line 386
    .line 387
    :try_start_c
    aget-byte v19, v5, v16

    .line 388
    .line 389
    move/from16 v20, v12

    .line 390
    .line 391
    or-int/lit8 v12, v19, 0x10

    .line 392
    .line 393
    int-to-byte v12, v12

    .line 394
    aput-byte v12, v5, v16
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_0
    .catchall {:try_start_c .. :try_end_c} :catchall_0

    .line 395
    .line 396
    goto :goto_6

    .line 397
    :cond_11
    move/from16 v20, v12

    .line 398
    .line 399
    :goto_6
    :try_start_d
    aget-byte v12, v5, v16

    .line 400
    .line 401
    or-int/lit8 v12, v12, 0x8

    .line 402
    .line 403
    int-to-byte v12, v12

    .line 404
    aput-byte v12, v5, v16
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_4
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    .line 405
    .line 406
    add-int/lit8 v12, v20, -0x1

    .line 407
    .line 408
    move-object/from16 v16, v9

    .line 409
    .line 410
    add-int/lit8 v9, v17, -0x1

    .line 411
    .line 412
    move-object/from16 v17, v4

    .line 413
    .line 414
    int-to-byte v4, v12

    .line 415
    :try_start_e
    aput-byte v4, v5, p2

    .line 416
    .line 417
    shr-int/lit8 v4, v12, 0x8

    .line 418
    .line 419
    int-to-byte v4, v4

    .line 420
    const/16 v19, 0x5

    .line 421
    .line 422
    aput-byte v4, v5, v19

    .line 423
    .line 424
    shr-int/lit8 v4, v12, 0x10

    .line 425
    .line 426
    int-to-byte v4, v4

    .line 427
    const/4 v12, 0x6

    .line 428
    aput-byte v4, v5, v12

    .line 429
    .line 430
    const/4 v4, 0x7

    .line 431
    int-to-byte v12, v9

    .line 432
    aput-byte v12, v5, v4

    .line 433
    .line 434
    shr-int/lit8 v4, v9, 0x8

    .line 435
    .line 436
    int-to-byte v4, v4

    .line 437
    aput-byte v4, v5, v18

    .line 438
    .line 439
    shr-int/lit8 v4, v9, 0x10

    .line 440
    .line 441
    int-to-byte v4, v4

    .line 442
    const/16 v9, 0x9

    .line 443
    .line 444
    aput-byte v4, v5, v9

    .line 445
    .line 446
    invoke-virtual {v10, v5}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 447
    .line 448
    .line 449
    invoke-virtual {v10, v3}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 450
    .line 451
    .line 452
    invoke-virtual {v10, v0}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 453
    .line 454
    .line 455
    invoke-static {v3, v14}, Ljava/util/Arrays;->equals([B[B)Z

    .line 456
    .line 457
    .line 458
    move-result v0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_3
    .catchall {:try_start_e .. :try_end_e} :catchall_3

    .line 459
    if-eqz v0, :cond_12

    .line 460
    .line 461
    :try_start_f
    invoke-virtual {v10, v8}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 462
    .line 463
    .line 464
    invoke-virtual {v10, v13}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 465
    .line 466
    .line 467
    invoke-virtual {v10, v7}, Landroidx/camera/core/impl/utils/c;->b(I)V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_1
    .catchall {:try_start_f .. :try_end_f} :catchall_1

    .line 468
    .line 469
    .line 470
    goto :goto_7

    .line 471
    :catchall_1
    move-exception v0

    .line 472
    move-object/from16 v7, v16

    .line 473
    .line 474
    goto :goto_c

    .line 475
    :catch_1
    move-exception v0

    .line 476
    move-object/from16 v7, v16

    .line 477
    .line 478
    goto :goto_b

    .line 479
    :cond_12
    :try_start_10
    invoke-static {v3, v15}, Ljava/util/Arrays;->equals([B[B)Z

    .line 480
    .line 481
    .line 482
    move-result v0
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_3
    .catchall {:try_start_10 .. :try_end_10} :catchall_3

    .line 483
    if-eqz v0, :cond_13

    .line 484
    .line 485
    const/16 v0, 0x2f

    .line 486
    .line 487
    :try_start_11
    invoke-virtual {v10, v0}, Ljava/io/OutputStream;->write(I)V

    .line 488
    .line 489
    .line 490
    invoke-virtual {v10, v7}, Landroidx/camera/core/impl/utils/c;->b(I)V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_1
    .catchall {:try_start_11 .. :try_end_11} :catchall_1

    .line 491
    .line 492
    .line 493
    :cond_13
    :goto_7
    :try_start_12
    invoke-static {v2, v10, v11}, Lcom/palmpay/lib/apm/launchcounter/util/d;->k(Lq0/b;Landroidx/camera/core/impl/utils/c;I)V

    .line 494
    .line 495
    .line 496
    invoke-virtual {v1, v10}, Lq0/g;->K(Landroidx/camera/core/impl/utils/c;)V

    .line 497
    .line 498
    .line 499
    :goto_8
    invoke-static {v2, v10}, Lcom/palmpay/lib/apm/launchcounter/util/d;->j(Ljava/io/InputStream;Ljava/io/OutputStream;)V

    .line 500
    .line 501
    .line 502
    invoke-virtual/range {v16 .. v16}, Ljava/io/ByteArrayOutputStream;->size()I

    .line 503
    .line 504
    .line 505
    move-result v0

    .line 506
    array-length v2, v6

    .line 507
    add-int/2addr v0, v2

    .line 508
    move-object/from16 v2, v17

    .line 509
    .line 510
    invoke-virtual {v2, v0}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 511
    .line 512
    .line 513
    invoke-virtual {v2, v6}, Landroidx/camera/core/impl/utils/c;->write([B)V
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_3
    .catchall {:try_start_12 .. :try_end_12} :catchall_3

    .line 514
    .line 515
    .line 516
    move-object/from16 v3, v16

    .line 517
    .line 518
    :try_start_13
    invoke-virtual {v3, v2}, Ljava/io/ByteArrayOutputStream;->writeTo(Ljava/io/OutputStream;)V
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_13} :catch_2
    .catchall {:try_start_13 .. :try_end_13} :catchall_2

    .line 519
    .line 520
    .line 521
    invoke-static {v3}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 522
    .line 523
    .line 524
    return-void

    .line 525
    :catchall_2
    move-exception v0

    .line 526
    :goto_9
    move-object v7, v3

    .line 527
    goto :goto_c

    .line 528
    :catch_2
    move-exception v0

    .line 529
    :goto_a
    move-object v7, v3

    .line 530
    goto :goto_b

    .line 531
    :catchall_3
    move-exception v0

    .line 532
    move-object/from16 v3, v16

    .line 533
    .line 534
    goto :goto_9

    .line 535
    :catch_3
    move-exception v0

    .line 536
    move-object/from16 v3, v16

    .line 537
    .line 538
    goto :goto_a

    .line 539
    :catchall_4
    move-exception v0

    .line 540
    move-object v3, v9

    .line 541
    goto :goto_9

    .line 542
    :catch_4
    move-exception v0

    .line 543
    move-object v3, v9

    .line 544
    goto :goto_a

    .line 545
    :cond_14
    move-object v3, v9

    .line 546
    :try_start_14
    new-instance v0, Ljava/io/IOException;

    .line 547
    .line 548
    const-string v2, "Encountered invalid length while parsing WebP chunk type"

    .line 549
    .line 550
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 551
    .line 552
    .line 553
    throw v0
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_2
    .catchall {:try_start_14 .. :try_end_14} :catchall_2

    .line 554
    :catchall_5
    move-exception v0

    .line 555
    goto :goto_c

    .line 556
    :catch_5
    move-exception v0

    .line 557
    :goto_b
    :try_start_15
    new-instance v2, Ljava/io/IOException;

    .line 558
    .line 559
    const-string v3, "Failed to save WebP file"

    .line 560
    .line 561
    invoke-direct {v2, v3, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 562
    .line 563
    .line 564
    throw v2
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_5

    .line 565
    :goto_c
    invoke-static {v7}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 566
    .line 567
    .line 568
    throw v0
.end method

.method public final F(Ljava/lang/String;Ljava/lang/String;)V
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x1

    .line 9
    const-string v5, "DateTime"

    .line 10
    .line 11
    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v5

    .line 15
    if-nez v5, :cond_0

    .line 16
    .line 17
    const-string v5, "DateTimeOriginal"

    .line 18
    .line 19
    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    if-nez v5, :cond_0

    .line 24
    .line 25
    const-string v5, "DateTimeDigitized"

    .line 26
    .line 27
    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v5

    .line 31
    if-eqz v5, :cond_2

    .line 32
    .line 33
    :cond_0
    if-eqz v2, :cond_2

    .line 34
    .line 35
    sget-object v5, Lq0/g;->f0:Ljava/util/regex/Pattern;

    .line 36
    .line 37
    invoke-virtual {v5, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 38
    .line 39
    .line 40
    move-result-object v5

    .line 41
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->find()Z

    .line 42
    .line 43
    .line 44
    move-result v5

    .line 45
    sget-object v6, Lq0/g;->g0:Ljava/util/regex/Pattern;

    .line 46
    .line 47
    invoke-virtual {v6, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    invoke-virtual {v6}, Ljava/util/regex/Matcher;->find()Z

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 56
    .line 57
    .line 58
    move-result v7

    .line 59
    const/16 v8, 0x13

    .line 60
    .line 61
    if-ne v7, v8, :cond_1d

    .line 62
    .line 63
    if-nez v5, :cond_1

    .line 64
    .line 65
    if-nez v6, :cond_1

    .line 66
    .line 67
    goto/16 :goto_11

    .line 68
    .line 69
    :cond_1
    if-eqz v6, :cond_2

    .line 70
    .line 71
    const-string v5, "-"

    .line 72
    .line 73
    const-string v6, ":"

    .line 74
    .line 75
    invoke-virtual {v2, v5, v6}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    :cond_2
    const-string v5, "ISOSpeedRatings"

    .line 80
    .line 81
    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v5

    .line 85
    if-eqz v5, :cond_3

    .line 86
    .line 87
    const-string v1, "PhotographicSensitivity"

    .line 88
    .line 89
    :cond_3
    const-string v5, "/"

    .line 90
    .line 91
    const/4 v6, 0x2

    .line 92
    if-eqz v2, :cond_7

    .line 93
    .line 94
    sget-object v7, Lq0/g;->Z:Ljava/util/HashSet;

    .line 95
    .line 96
    invoke-virtual {v7, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v7

    .line 100
    if-eqz v7, :cond_7

    .line 101
    .line 102
    const-string v7, "GPSTimeStamp"

    .line 103
    .line 104
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v7

    .line 108
    if-eqz v7, :cond_5

    .line 109
    .line 110
    sget-object v7, Lq0/g;->e0:Ljava/util/regex/Pattern;

    .line 111
    .line 112
    invoke-virtual {v7, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 113
    .line 114
    .line 115
    move-result-object v2

    .line 116
    invoke-virtual {v2}, Ljava/util/regex/Matcher;->find()Z

    .line 117
    .line 118
    .line 119
    move-result v7

    .line 120
    if-nez v7, :cond_4

    .line 121
    .line 122
    goto/16 :goto_11

    .line 123
    .line 124
    :cond_4
    new-instance v7, Ljava/lang/StringBuilder;

    .line 125
    .line 126
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v2, v4}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v8

    .line 133
    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 134
    .line 135
    .line 136
    move-result v8

    .line 137
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 138
    .line 139
    .line 140
    const-string v8, "/1,"

    .line 141
    .line 142
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    invoke-virtual {v2, v6}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v9

    .line 149
    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 150
    .line 151
    .line 152
    move-result v9

    .line 153
    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 154
    .line 155
    .line 156
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 157
    .line 158
    .line 159
    const/4 v8, 0x3

    .line 160
    invoke-virtual {v2, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v2

    .line 164
    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    const-string v2, "/1"

    .line 172
    .line 173
    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 174
    .line 175
    .line 176
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v2

    .line 180
    goto :goto_0

    .line 181
    :cond_5
    :try_start_0
    invoke-static {v2}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 182
    .line 183
    .line 184
    move-result-wide v7

    .line 185
    const-wide v9, 0x40c3880000000000L    # 10000.0

    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    mul-double/2addr v7, v9

    .line 191
    double-to-long v7, v7

    .line 192
    const-wide/16 v9, 0x2710

    .line 193
    .line 194
    const-wide/16 v11, 0x0

    .line 195
    .line 196
    cmp-long v2, v9, v11

    .line 197
    .line 198
    if-nez v2, :cond_6

    .line 199
    .line 200
    const-wide/16 v9, 0x1

    .line 201
    .line 202
    move-wide v7, v11

    .line 203
    :cond_6
    new-instance v2, Ljava/lang/StringBuilder;

    .line 204
    .line 205
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 206
    .line 207
    .line 208
    invoke-virtual {v2, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 209
    .line 210
    .line 211
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 212
    .line 213
    .line 214
    invoke-virtual {v2, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 215
    .line 216
    .line 217
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object v2
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 221
    :cond_7
    :goto_0
    move v7, v3

    .line 222
    :goto_1
    sget-object v8, Lq0/g;->V:[[Lq0/d;

    .line 223
    .line 224
    array-length v8, v8

    .line 225
    if-ge v7, v8, :cond_1d

    .line 226
    .line 227
    const/4 v8, 0x4

    .line 228
    if-ne v7, v8, :cond_9

    .line 229
    .line 230
    iget-boolean v8, v0, Lq0/g;->h:Z

    .line 231
    .line 232
    if-nez v8, :cond_9

    .line 233
    .line 234
    :cond_8
    :goto_2
    move v6, v4

    .line 235
    move v4, v3

    .line 236
    goto/16 :goto_10

    .line 237
    .line 238
    :cond_9
    sget-object v8, Lq0/g;->Y:[Ljava/util/HashMap;

    .line 239
    .line 240
    aget-object v8, v8, v7

    .line 241
    .line 242
    invoke-virtual {v8, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v8

    .line 246
    check-cast v8, Lq0/d;

    .line 247
    .line 248
    if-eqz v8, :cond_8

    .line 249
    .line 250
    iget-object v9, v0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 251
    .line 252
    if-nez v2, :cond_a

    .line 253
    .line 254
    aget-object v8, v9, v7

    .line 255
    .line 256
    invoke-virtual {v8, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    goto :goto_2

    .line 260
    :cond_a
    invoke-static {v2}, Lq0/g;->q(Ljava/lang/String;)Landroid/util/Pair;

    .line 261
    .line 262
    .line 263
    move-result-object v10

    .line 264
    iget-object v11, v10, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 265
    .line 266
    check-cast v11, Ljava/lang/Integer;

    .line 267
    .line 268
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 269
    .line 270
    .line 271
    move-result v11

    .line 272
    const/4 v12, -0x1

    .line 273
    iget v13, v8, Lq0/d;->c:I

    .line 274
    .line 275
    if-eq v13, v11, :cond_11

    .line 276
    .line 277
    iget-object v11, v10, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 278
    .line 279
    check-cast v11, Ljava/lang/Integer;

    .line 280
    .line 281
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 282
    .line 283
    .line 284
    move-result v11

    .line 285
    if-ne v13, v11, :cond_b

    .line 286
    .line 287
    goto :goto_4

    .line 288
    :cond_b
    iget v8, v8, Lq0/d;->d:I

    .line 289
    .line 290
    if-eq v8, v12, :cond_d

    .line 291
    .line 292
    iget-object v11, v10, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 293
    .line 294
    check-cast v11, Ljava/lang/Integer;

    .line 295
    .line 296
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 297
    .line 298
    .line 299
    move-result v11

    .line 300
    if-eq v8, v11, :cond_c

    .line 301
    .line 302
    iget-object v11, v10, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 303
    .line 304
    check-cast v11, Ljava/lang/Integer;

    .line 305
    .line 306
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 307
    .line 308
    .line 309
    move-result v11

    .line 310
    if-ne v8, v11, :cond_d

    .line 311
    .line 312
    :cond_c
    move v13, v8

    .line 313
    goto :goto_4

    .line 314
    :cond_d
    if-eq v13, v4, :cond_11

    .line 315
    .line 316
    const/4 v11, 0x7

    .line 317
    if-eq v13, v11, :cond_11

    .line 318
    .line 319
    if-ne v13, v6, :cond_e

    .line 320
    .line 321
    goto :goto_4

    .line 322
    :cond_e
    sget-boolean v9, Lq0/g;->t:Z

    .line 323
    .line 324
    if-eqz v9, :cond_8

    .line 325
    .line 326
    sget-object v9, Lq0/g;->R:[Ljava/lang/String;

    .line 327
    .line 328
    aget-object v11, v9, v13

    .line 329
    .line 330
    if-ne v8, v12, :cond_f

    .line 331
    .line 332
    goto :goto_3

    .line 333
    :cond_f
    aget-object v8, v9, v8

    .line 334
    .line 335
    :goto_3
    iget-object v8, v10, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 336
    .line 337
    check-cast v8, Ljava/lang/Integer;

    .line 338
    .line 339
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 340
    .line 341
    .line 342
    move-result v8

    .line 343
    aget-object v8, v9, v8

    .line 344
    .line 345
    iget-object v8, v10, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 346
    .line 347
    check-cast v8, Ljava/lang/Integer;

    .line 348
    .line 349
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 350
    .line 351
    .line 352
    move-result v8

    .line 353
    if-ne v8, v12, :cond_10

    .line 354
    .line 355
    goto :goto_2

    .line 356
    :cond_10
    iget-object v8, v10, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 357
    .line 358
    check-cast v8, Ljava/lang/Integer;

    .line 359
    .line 360
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 361
    .line 362
    .line 363
    move-result v8

    .line 364
    aget-object v8, v9, v8

    .line 365
    .line 366
    goto/16 :goto_2

    .line 367
    .line 368
    :cond_11
    :goto_4
    sget-object v8, Lq0/g;->S:[I

    .line 369
    .line 370
    const-string v10, ","

    .line 371
    .line 372
    packed-switch v13, :pswitch_data_0

    .line 373
    .line 374
    .line 375
    :pswitch_0
    goto/16 :goto_2

    .line 376
    .line 377
    :pswitch_1
    invoke-virtual {v2, v10, v12}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object v10

    .line 381
    array-length v11, v10

    .line 382
    new-array v12, v11, [D

    .line 383
    .line 384
    move v13, v3

    .line 385
    :goto_5
    array-length v14, v10

    .line 386
    if-ge v13, v14, :cond_12

    .line 387
    .line 388
    aget-object v14, v10, v13

    .line 389
    .line 390
    invoke-static {v14}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 391
    .line 392
    .line 393
    move-result-wide v14

    .line 394
    aput-wide v14, v12, v13

    .line 395
    .line 396
    add-int/2addr v13, v4

    .line 397
    goto :goto_5

    .line 398
    :cond_12
    aget-object v9, v9, v7

    .line 399
    .line 400
    iget-object v10, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 401
    .line 402
    const/16 v13, 0xc

    .line 403
    .line 404
    aget v8, v8, v13

    .line 405
    .line 406
    mul-int/2addr v8, v11

    .line 407
    new-array v8, v8, [B

    .line 408
    .line 409
    invoke-static {v8}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 410
    .line 411
    .line 412
    move-result-object v8

    .line 413
    invoke-virtual {v8, v10}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 414
    .line 415
    .line 416
    move v10, v3

    .line 417
    :goto_6
    if-ge v10, v11, :cond_13

    .line 418
    .line 419
    aget-wide v14, v12, v10

    .line 420
    .line 421
    invoke-virtual {v8, v14, v15}, Ljava/nio/ByteBuffer;->putDouble(D)Ljava/nio/ByteBuffer;

    .line 422
    .line 423
    .line 424
    add-int/2addr v10, v4

    .line 425
    goto :goto_6

    .line 426
    :cond_13
    new-instance v10, Lq0/c;

    .line 427
    .line 428
    invoke-virtual {v8}, Ljava/nio/ByteBuffer;->array()[B

    .line 429
    .line 430
    .line 431
    move-result-object v8

    .line 432
    invoke-direct {v10, v13, v11, v8}, Lq0/c;-><init>(II[B)V

    .line 433
    .line 434
    .line 435
    invoke-virtual {v9, v1, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 436
    .line 437
    .line 438
    goto/16 :goto_2

    .line 439
    .line 440
    :pswitch_2
    invoke-virtual {v2, v10, v12}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 441
    .line 442
    .line 443
    move-result-object v10

    .line 444
    array-length v11, v10

    .line 445
    new-array v13, v11, [Lq0/e;

    .line 446
    .line 447
    move v14, v3

    .line 448
    :goto_7
    array-length v15, v10

    .line 449
    if-ge v14, v15, :cond_14

    .line 450
    .line 451
    aget-object v15, v10, v14

    .line 452
    .line 453
    invoke-virtual {v15, v5, v12}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 454
    .line 455
    .line 456
    move-result-object v15

    .line 457
    new-instance v6, Lq0/e;

    .line 458
    .line 459
    aget-object v16, v15, v3

    .line 460
    .line 461
    move/from16 v17, v3

    .line 462
    .line 463
    move/from16 v18, v4

    .line 464
    .line 465
    invoke-static/range {v16 .. v16}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 466
    .line 467
    .line 468
    move-result-wide v3

    .line 469
    double-to-long v3, v3

    .line 470
    aget-object v15, v15, v18

    .line 471
    .line 472
    move-object/from16 v16, v13

    .line 473
    .line 474
    invoke-static {v15}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 475
    .line 476
    .line 477
    move-result-wide v12

    .line 478
    double-to-long v12, v12

    .line 479
    invoke-direct {v6, v3, v4, v12, v13}, Lq0/e;-><init>(JJ)V

    .line 480
    .line 481
    .line 482
    aput-object v6, v16, v14

    .line 483
    .line 484
    add-int/lit8 v14, v14, 0x1

    .line 485
    .line 486
    move-object/from16 v13, v16

    .line 487
    .line 488
    move/from16 v3, v17

    .line 489
    .line 490
    move/from16 v4, v18

    .line 491
    .line 492
    const/4 v6, 0x2

    .line 493
    const/4 v12, -0x1

    .line 494
    goto :goto_7

    .line 495
    :cond_14
    move/from16 v17, v3

    .line 496
    .line 497
    move/from16 v18, v4

    .line 498
    .line 499
    move-object/from16 v16, v13

    .line 500
    .line 501
    aget-object v3, v9, v7

    .line 502
    .line 503
    iget-object v4, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 504
    .line 505
    const/16 v6, 0xa

    .line 506
    .line 507
    aget v8, v8, v6

    .line 508
    .line 509
    mul-int/2addr v8, v11

    .line 510
    new-array v8, v8, [B

    .line 511
    .line 512
    invoke-static {v8}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 513
    .line 514
    .line 515
    move-result-object v8

    .line 516
    invoke-virtual {v8, v4}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 517
    .line 518
    .line 519
    move/from16 v4, v17

    .line 520
    .line 521
    :goto_8
    if-ge v4, v11, :cond_15

    .line 522
    .line 523
    aget-object v9, v16, v4

    .line 524
    .line 525
    iget-wide v12, v9, Lq0/e;->a:J

    .line 526
    .line 527
    long-to-int v10, v12

    .line 528
    invoke-virtual {v8, v10}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 529
    .line 530
    .line 531
    iget-wide v9, v9, Lq0/e;->b:J

    .line 532
    .line 533
    long-to-int v9, v9

    .line 534
    invoke-virtual {v8, v9}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 535
    .line 536
    .line 537
    add-int/lit8 v4, v4, 0x1

    .line 538
    .line 539
    goto :goto_8

    .line 540
    :cond_15
    new-instance v4, Lq0/c;

    .line 541
    .line 542
    invoke-virtual {v8}, Ljava/nio/ByteBuffer;->array()[B

    .line 543
    .line 544
    .line 545
    move-result-object v8

    .line 546
    invoke-direct {v4, v6, v11, v8}, Lq0/c;-><init>(II[B)V

    .line 547
    .line 548
    .line 549
    invoke-virtual {v3, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 550
    .line 551
    .line 552
    :goto_9
    move/from16 v4, v17

    .line 553
    .line 554
    move/from16 v6, v18

    .line 555
    .line 556
    goto/16 :goto_10

    .line 557
    .line 558
    :pswitch_3
    move/from16 v17, v3

    .line 559
    .line 560
    move/from16 v18, v4

    .line 561
    .line 562
    move v3, v12

    .line 563
    invoke-virtual {v2, v10, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 564
    .line 565
    .line 566
    move-result-object v3

    .line 567
    array-length v4, v3

    .line 568
    new-array v6, v4, [I

    .line 569
    .line 570
    move/from16 v10, v17

    .line 571
    .line 572
    :goto_a
    array-length v11, v3

    .line 573
    if-ge v10, v11, :cond_16

    .line 574
    .line 575
    aget-object v11, v3, v10

    .line 576
    .line 577
    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 578
    .line 579
    .line 580
    move-result v11

    .line 581
    aput v11, v6, v10

    .line 582
    .line 583
    add-int/lit8 v10, v10, 0x1

    .line 584
    .line 585
    goto :goto_a

    .line 586
    :cond_16
    aget-object v3, v9, v7

    .line 587
    .line 588
    iget-object v9, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 589
    .line 590
    const/16 v10, 0x9

    .line 591
    .line 592
    aget v8, v8, v10

    .line 593
    .line 594
    mul-int/2addr v8, v4

    .line 595
    new-array v8, v8, [B

    .line 596
    .line 597
    invoke-static {v8}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 598
    .line 599
    .line 600
    move-result-object v8

    .line 601
    invoke-virtual {v8, v9}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 602
    .line 603
    .line 604
    move/from16 v9, v17

    .line 605
    .line 606
    :goto_b
    if-ge v9, v4, :cond_17

    .line 607
    .line 608
    aget v11, v6, v9

    .line 609
    .line 610
    invoke-virtual {v8, v11}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 611
    .line 612
    .line 613
    add-int/lit8 v9, v9, 0x1

    .line 614
    .line 615
    goto :goto_b

    .line 616
    :cond_17
    new-instance v6, Lq0/c;

    .line 617
    .line 618
    invoke-virtual {v8}, Ljava/nio/ByteBuffer;->array()[B

    .line 619
    .line 620
    .line 621
    move-result-object v8

    .line 622
    invoke-direct {v6, v10, v4, v8}, Lq0/c;-><init>(II[B)V

    .line 623
    .line 624
    .line 625
    invoke-virtual {v3, v1, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 626
    .line 627
    .line 628
    goto :goto_9

    .line 629
    :pswitch_4
    move/from16 v17, v3

    .line 630
    .line 631
    move/from16 v18, v4

    .line 632
    .line 633
    move v3, v12

    .line 634
    invoke-virtual {v2, v10, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 635
    .line 636
    .line 637
    move-result-object v4

    .line 638
    array-length v6, v4

    .line 639
    new-array v6, v6, [Lq0/e;

    .line 640
    .line 641
    move/from16 v8, v17

    .line 642
    .line 643
    :goto_c
    array-length v10, v4

    .line 644
    if-ge v8, v10, :cond_18

    .line 645
    .line 646
    aget-object v10, v4, v8

    .line 647
    .line 648
    invoke-virtual {v10, v5, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 649
    .line 650
    .line 651
    move-result-object v10

    .line 652
    new-instance v3, Lq0/e;

    .line 653
    .line 654
    aget-object v11, v10, v17

    .line 655
    .line 656
    invoke-static {v11}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 657
    .line 658
    .line 659
    move-result-wide v11

    .line 660
    double-to-long v11, v11

    .line 661
    aget-object v10, v10, v18

    .line 662
    .line 663
    invoke-static {v10}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 664
    .line 665
    .line 666
    move-result-wide v13

    .line 667
    double-to-long v13, v13

    .line 668
    invoke-direct {v3, v11, v12, v13, v14}, Lq0/e;-><init>(JJ)V

    .line 669
    .line 670
    .line 671
    aput-object v3, v6, v8

    .line 672
    .line 673
    add-int/lit8 v8, v8, 0x1

    .line 674
    .line 675
    const/4 v3, -0x1

    .line 676
    goto :goto_c

    .line 677
    :cond_18
    aget-object v3, v9, v7

    .line 678
    .line 679
    iget-object v4, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 680
    .line 681
    invoke-static {v6, v4}, Lq0/c;->d([Lq0/e;Ljava/nio/ByteOrder;)Lq0/c;

    .line 682
    .line 683
    .line 684
    move-result-object v4

    .line 685
    invoke-virtual {v3, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 686
    .line 687
    .line 688
    goto/16 :goto_9

    .line 689
    .line 690
    :pswitch_5
    move/from16 v17, v3

    .line 691
    .line 692
    move/from16 v18, v4

    .line 693
    .line 694
    move v3, v12

    .line 695
    invoke-virtual {v2, v10, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 696
    .line 697
    .line 698
    move-result-object v3

    .line 699
    array-length v4, v3

    .line 700
    new-array v4, v4, [J

    .line 701
    .line 702
    move/from16 v6, v17

    .line 703
    .line 704
    :goto_d
    array-length v8, v3

    .line 705
    if-ge v6, v8, :cond_19

    .line 706
    .line 707
    aget-object v8, v3, v6

    .line 708
    .line 709
    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 710
    .line 711
    .line 712
    move-result-wide v10

    .line 713
    aput-wide v10, v4, v6

    .line 714
    .line 715
    add-int/lit8 v6, v6, 0x1

    .line 716
    .line 717
    goto :goto_d

    .line 718
    :cond_19
    aget-object v3, v9, v7

    .line 719
    .line 720
    iget-object v6, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 721
    .line 722
    invoke-static {v4, v6}, Lq0/c;->c([JLjava/nio/ByteOrder;)Lq0/c;

    .line 723
    .line 724
    .line 725
    move-result-object v4

    .line 726
    invoke-virtual {v3, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 727
    .line 728
    .line 729
    goto/16 :goto_9

    .line 730
    .line 731
    :pswitch_6
    move/from16 v17, v3

    .line 732
    .line 733
    move/from16 v18, v4

    .line 734
    .line 735
    move v3, v12

    .line 736
    invoke-virtual {v2, v10, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 737
    .line 738
    .line 739
    move-result-object v3

    .line 740
    array-length v4, v3

    .line 741
    new-array v4, v4, [I

    .line 742
    .line 743
    move/from16 v6, v17

    .line 744
    .line 745
    :goto_e
    array-length v8, v3

    .line 746
    if-ge v6, v8, :cond_1a

    .line 747
    .line 748
    aget-object v8, v3, v6

    .line 749
    .line 750
    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 751
    .line 752
    .line 753
    move-result v8

    .line 754
    aput v8, v4, v6

    .line 755
    .line 756
    add-int/lit8 v6, v6, 0x1

    .line 757
    .line 758
    goto :goto_e

    .line 759
    :cond_1a
    aget-object v3, v9, v7

    .line 760
    .line 761
    iget-object v6, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 762
    .line 763
    invoke-static {v4, v6}, Lq0/c;->f([ILjava/nio/ByteOrder;)Lq0/c;

    .line 764
    .line 765
    .line 766
    move-result-object v4

    .line 767
    invoke-virtual {v3, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 768
    .line 769
    .line 770
    goto/16 :goto_9

    .line 771
    .line 772
    :pswitch_7
    move/from16 v17, v3

    .line 773
    .line 774
    move/from16 v18, v4

    .line 775
    .line 776
    aget-object v3, v9, v7

    .line 777
    .line 778
    invoke-static {v2}, Lq0/c;->a(Ljava/lang/String;)Lq0/c;

    .line 779
    .line 780
    .line 781
    move-result-object v4

    .line 782
    invoke-virtual {v3, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 783
    .line 784
    .line 785
    goto/16 :goto_9

    .line 786
    .line 787
    :pswitch_8
    move/from16 v17, v3

    .line 788
    .line 789
    move/from16 v18, v4

    .line 790
    .line 791
    aget-object v3, v9, v7

    .line 792
    .line 793
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 794
    .line 795
    .line 796
    move-result v4

    .line 797
    move/from16 v6, v18

    .line 798
    .line 799
    if-ne v4, v6, :cond_1b

    .line 800
    .line 801
    move/from16 v4, v17

    .line 802
    .line 803
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    .line 804
    .line 805
    .line 806
    move-result v8

    .line 807
    const/16 v9, 0x30

    .line 808
    .line 809
    if-lt v8, v9, :cond_1c

    .line 810
    .line 811
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    .line 812
    .line 813
    .line 814
    move-result v8

    .line 815
    const/16 v10, 0x31

    .line 816
    .line 817
    if-gt v8, v10, :cond_1c

    .line 818
    .line 819
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    .line 820
    .line 821
    .line 822
    move-result v8

    .line 823
    sub-int/2addr v8, v9

    .line 824
    int-to-byte v8, v8

    .line 825
    new-array v9, v6, [B

    .line 826
    .line 827
    aput-byte v8, v9, v4

    .line 828
    .line 829
    new-instance v8, Lq0/c;

    .line 830
    .line 831
    invoke-direct {v8, v6, v6, v9}, Lq0/c;-><init>(II[B)V

    .line 832
    .line 833
    .line 834
    goto :goto_f

    .line 835
    :cond_1b
    move/from16 v4, v17

    .line 836
    .line 837
    :cond_1c
    sget-object v8, Lq0/g;->b0:Ljava/nio/charset/Charset;

    .line 838
    .line 839
    invoke-virtual {v2, v8}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 840
    .line 841
    .line 842
    move-result-object v8

    .line 843
    new-instance v9, Lq0/c;

    .line 844
    .line 845
    array-length v10, v8

    .line 846
    invoke-direct {v9, v6, v10, v8}, Lq0/c;-><init>(II[B)V

    .line 847
    .line 848
    .line 849
    move-object v8, v9

    .line 850
    :goto_f
    invoke-virtual {v3, v1, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 851
    .line 852
    .line 853
    :goto_10
    add-int/2addr v7, v6

    .line 854
    move v3, v4

    .line 855
    move v4, v6

    .line 856
    const/4 v6, 0x2

    .line 857
    goto/16 :goto_1

    .line 858
    .line 859
    :catch_0
    :cond_1d
    :goto_11
    return-void

    .line 860
    nop

    .line 861
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_0
        :pswitch_7
        :pswitch_0
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public final G(Lq0/b;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 6
    .line 7
    const/4 v3, 0x4

    .line 8
    aget-object v2, v2, v3

    .line 9
    .line 10
    const-string v3, "Compression"

    .line 11
    .line 12
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    check-cast v3, Lq0/c;

    .line 17
    .line 18
    const/4 v4, 0x6

    .line 19
    if-eqz v3, :cond_f

    .line 20
    .line 21
    iget-object v5, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 22
    .line 23
    invoke-virtual {v3, v5}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    iput v3, v0, Lq0/g;->n:I

    .line 28
    .line 29
    const/4 v5, 0x1

    .line 30
    if-eq v3, v5, :cond_1

    .line 31
    .line 32
    if-eq v3, v4, :cond_0

    .line 33
    .line 34
    const/4 v6, 0x7

    .line 35
    if-eq v3, v6, :cond_1

    .line 36
    .line 37
    goto/16 :goto_3

    .line 38
    .line 39
    :cond_0
    invoke-virtual {v0, v1, v2}, Lq0/g;->r(Lq0/b;Ljava/util/HashMap;)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :cond_1
    const-string v3, "BitsPerSample"

    .line 44
    .line 45
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    check-cast v3, Lq0/c;

    .line 50
    .line 51
    if-eqz v3, :cond_e

    .line 52
    .line 53
    iget-object v6, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 54
    .line 55
    invoke-virtual {v3, v6}, Lq0/c;->j(Ljava/nio/ByteOrder;)Ljava/io/Serializable;

    .line 56
    .line 57
    .line 58
    move-result-object v3

    .line 59
    check-cast v3, [I

    .line 60
    .line 61
    sget-object v6, Lq0/g;->w:[I

    .line 62
    .line 63
    invoke-static {v6, v3}, Ljava/util/Arrays;->equals([I[I)Z

    .line 64
    .line 65
    .line 66
    move-result v7

    .line 67
    if-eqz v7, :cond_2

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_2
    iget v7, v0, Lq0/g;->d:I

    .line 71
    .line 72
    const/4 v8, 0x3

    .line 73
    if-ne v7, v8, :cond_e

    .line 74
    .line 75
    const-string v7, "PhotometricInterpretation"

    .line 76
    .line 77
    invoke-virtual {v2, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v7

    .line 81
    check-cast v7, Lq0/c;

    .line 82
    .line 83
    if-eqz v7, :cond_e

    .line 84
    .line 85
    iget-object v8, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 86
    .line 87
    invoke-virtual {v7, v8}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 88
    .line 89
    .line 90
    move-result v7

    .line 91
    if-ne v7, v5, :cond_3

    .line 92
    .line 93
    sget-object v8, Lq0/g;->x:[I

    .line 94
    .line 95
    invoke-static {v3, v8}, Ljava/util/Arrays;->equals([I[I)Z

    .line 96
    .line 97
    .line 98
    move-result v8

    .line 99
    if-nez v8, :cond_4

    .line 100
    .line 101
    :cond_3
    if-ne v7, v4, :cond_e

    .line 102
    .line 103
    invoke-static {v3, v6}, Ljava/util/Arrays;->equals([I[I)Z

    .line 104
    .line 105
    .line 106
    move-result v3

    .line 107
    if-eqz v3, :cond_e

    .line 108
    .line 109
    :cond_4
    :goto_0
    const-string v3, "StripOffsets"

    .line 110
    .line 111
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v3

    .line 115
    check-cast v3, Lq0/c;

    .line 116
    .line 117
    const-string v4, "StripByteCounts"

    .line 118
    .line 119
    invoke-virtual {v2, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    check-cast v2, Lq0/c;

    .line 124
    .line 125
    if-eqz v3, :cond_e

    .line 126
    .line 127
    if-eqz v2, :cond_e

    .line 128
    .line 129
    iget-object v4, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 130
    .line 131
    invoke-virtual {v3, v4}, Lq0/c;->j(Ljava/nio/ByteOrder;)Ljava/io/Serializable;

    .line 132
    .line 133
    .line 134
    move-result-object v3

    .line 135
    invoke-static {v3}, Lcom/palmpay/lib/apm/launchcounter/util/d;->i(Ljava/io/Serializable;)[J

    .line 136
    .line 137
    .line 138
    move-result-object v3

    .line 139
    iget-object v4, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 140
    .line 141
    invoke-virtual {v2, v4}, Lq0/c;->j(Ljava/nio/ByteOrder;)Ljava/io/Serializable;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    invoke-static {v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->i(Ljava/io/Serializable;)[J

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    if-eqz v3, :cond_e

    .line 150
    .line 151
    array-length v4, v3

    .line 152
    if-nez v4, :cond_5

    .line 153
    .line 154
    goto/16 :goto_3

    .line 155
    .line 156
    :cond_5
    if-eqz v2, :cond_e

    .line 157
    .line 158
    array-length v4, v2

    .line 159
    if-nez v4, :cond_6

    .line 160
    .line 161
    goto/16 :goto_3

    .line 162
    .line 163
    :cond_6
    array-length v4, v3

    .line 164
    array-length v6, v2

    .line 165
    if-eq v4, v6, :cond_7

    .line 166
    .line 167
    goto :goto_3

    .line 168
    :cond_7
    array-length v4, v2

    .line 169
    const/4 v6, 0x0

    .line 170
    const-wide/16 v7, 0x0

    .line 171
    .line 172
    move v9, v6

    .line 173
    :goto_1
    if-ge v9, v4, :cond_8

    .line 174
    .line 175
    aget-wide v10, v2, v9

    .line 176
    .line 177
    add-long/2addr v7, v10

    .line 178
    add-int/lit8 v9, v9, 0x1

    .line 179
    .line 180
    goto :goto_1

    .line 181
    :cond_8
    long-to-int v4, v7

    .line 182
    new-array v7, v4, [B

    .line 183
    .line 184
    iput-boolean v5, v0, Lq0/g;->j:Z

    .line 185
    .line 186
    iput-boolean v5, v0, Lq0/g;->i:Z

    .line 187
    .line 188
    iput-boolean v5, v0, Lq0/g;->h:Z

    .line 189
    .line 190
    move v8, v6

    .line 191
    move v9, v8

    .line 192
    move v10, v9

    .line 193
    :goto_2
    array-length v11, v3

    .line 194
    if-ge v8, v11, :cond_d

    .line 195
    .line 196
    aget-wide v11, v3, v8

    .line 197
    .line 198
    long-to-int v11, v11

    .line 199
    aget-wide v12, v2, v8

    .line 200
    .line 201
    long-to-int v12, v12

    .line 202
    array-length v13, v3

    .line 203
    sub-int/2addr v13, v5

    .line 204
    if-ge v8, v13, :cond_9

    .line 205
    .line 206
    add-int v13, v11, v12

    .line 207
    .line 208
    int-to-long v13, v13

    .line 209
    add-int/lit8 v15, v8, 0x1

    .line 210
    .line 211
    aget-wide v15, v3, v15

    .line 212
    .line 213
    cmp-long v13, v13, v15

    .line 214
    .line 215
    if-eqz v13, :cond_9

    .line 216
    .line 217
    iput-boolean v6, v0, Lq0/g;->j:Z

    .line 218
    .line 219
    :cond_9
    sub-int/2addr v11, v9

    .line 220
    if-gez v11, :cond_a

    .line 221
    .line 222
    goto :goto_3

    .line 223
    :cond_a
    int-to-long v13, v11

    .line 224
    invoke-virtual {v1, v13, v14}, Ljava/io/InputStream;->skip(J)J

    .line 225
    .line 226
    .line 227
    move-result-wide v15

    .line 228
    cmp-long v13, v15, v13

    .line 229
    .line 230
    if-eqz v13, :cond_b

    .line 231
    .line 232
    goto :goto_3

    .line 233
    :cond_b
    add-int/2addr v9, v11

    .line 234
    new-array v11, v12, [B

    .line 235
    .line 236
    invoke-virtual {v1, v11}, Ljava/io/InputStream;->read([B)I

    .line 237
    .line 238
    .line 239
    move-result v13

    .line 240
    if-eq v13, v12, :cond_c

    .line 241
    .line 242
    goto :goto_3

    .line 243
    :cond_c
    add-int/2addr v9, v12

    .line 244
    invoke-static {v11, v6, v7, v10, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 245
    .line 246
    .line 247
    add-int/2addr v10, v12

    .line 248
    add-int/lit8 v8, v8, 0x1

    .line 249
    .line 250
    goto :goto_2

    .line 251
    :cond_d
    iput-object v7, v0, Lq0/g;->m:[B

    .line 252
    .line 253
    iget-boolean v1, v0, Lq0/g;->j:Z

    .line 254
    .line 255
    if-eqz v1, :cond_e

    .line 256
    .line 257
    aget-wide v1, v3, v6

    .line 258
    .line 259
    long-to-int v1, v1

    .line 260
    iput v1, v0, Lq0/g;->k:I

    .line 261
    .line 262
    iput v4, v0, Lq0/g;->l:I

    .line 263
    .line 264
    :cond_e
    :goto_3
    return-void

    .line 265
    :cond_f
    iput v4, v0, Lq0/g;->n:I

    .line 266
    .line 267
    invoke-virtual {v0, v1, v2}, Lq0/g;->r(Lq0/b;Ljava/util/HashMap;)V

    .line 268
    .line 269
    .line 270
    return-void
.end method

.method public final H(II)V
    .locals 6

    .line 1
    iget-object v0, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 2
    .line 3
    aget-object v1, v0, p1

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/HashMap;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-nez v1, :cond_3

    .line 10
    .line 11
    aget-object v1, v0, p2

    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/util/HashMap;->isEmpty()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    aget-object v1, v0, p1

    .line 21
    .line 22
    const-string v2, "ImageLength"

    .line 23
    .line 24
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    check-cast v1, Lq0/c;

    .line 29
    .line 30
    aget-object v3, v0, p1

    .line 31
    .line 32
    const-string v4, "ImageWidth"

    .line 33
    .line 34
    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    check-cast v3, Lq0/c;

    .line 39
    .line 40
    aget-object v5, v0, p2

    .line 41
    .line 42
    invoke-virtual {v5, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    check-cast v2, Lq0/c;

    .line 47
    .line 48
    aget-object v5, v0, p2

    .line 49
    .line 50
    invoke-virtual {v5, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    check-cast v4, Lq0/c;

    .line 55
    .line 56
    if-eqz v1, :cond_3

    .line 57
    .line 58
    if-nez v3, :cond_1

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_1
    if-eqz v2, :cond_3

    .line 62
    .line 63
    if-nez v4, :cond_2

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_2
    iget-object v5, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 67
    .line 68
    invoke-virtual {v1, v5}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    iget-object v5, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 73
    .line 74
    invoke-virtual {v3, v5}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 75
    .line 76
    .line 77
    move-result v3

    .line 78
    iget-object v5, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 79
    .line 80
    invoke-virtual {v2, v5}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 81
    .line 82
    .line 83
    move-result v2

    .line 84
    iget-object v5, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 85
    .line 86
    invoke-virtual {v4, v5}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    if-ge v1, v2, :cond_3

    .line 91
    .line 92
    if-ge v3, v4, :cond_3

    .line 93
    .line 94
    aget-object v1, v0, p1

    .line 95
    .line 96
    aget-object v2, v0, p2

    .line 97
    .line 98
    aput-object v2, v0, p1

    .line 99
    .line 100
    aput-object v1, v0, p2

    .line 101
    .line 102
    :cond_3
    :goto_0
    return-void
.end method

.method public final I(Lq0/f;I)V
    .locals 8

    .line 1
    iget-object v0, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 2
    .line 3
    aget-object v1, v0, p2

    .line 4
    .line 5
    const-string v2, "DefaultCropSize"

    .line 6
    .line 7
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    check-cast v1, Lq0/c;

    .line 12
    .line 13
    aget-object v2, v0, p2

    .line 14
    .line 15
    const-string v3, "SensorTopBorder"

    .line 16
    .line 17
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    check-cast v2, Lq0/c;

    .line 22
    .line 23
    aget-object v3, v0, p2

    .line 24
    .line 25
    const-string v4, "SensorLeftBorder"

    .line 26
    .line 27
    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    check-cast v3, Lq0/c;

    .line 32
    .line 33
    aget-object v4, v0, p2

    .line 34
    .line 35
    const-string v5, "SensorBottomBorder"

    .line 36
    .line 37
    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v4

    .line 41
    check-cast v4, Lq0/c;

    .line 42
    .line 43
    aget-object v5, v0, p2

    .line 44
    .line 45
    const-string v6, "SensorRightBorder"

    .line 46
    .line 47
    invoke-virtual {v5, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    check-cast v5, Lq0/c;

    .line 52
    .line 53
    const-string v6, "ImageLength"

    .line 54
    .line 55
    const-string v7, "ImageWidth"

    .line 56
    .line 57
    if-eqz v1, :cond_5

    .line 58
    .line 59
    iget p1, v1, Lq0/c;->a:I

    .line 60
    .line 61
    const/4 v2, 0x5

    .line 62
    const/4 v3, 0x1

    .line 63
    const/4 v4, 0x0

    .line 64
    const/4 v5, 0x2

    .line 65
    if-ne p1, v2, :cond_2

    .line 66
    .line 67
    iget-object p1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 68
    .line 69
    invoke-virtual {v1, p1}, Lq0/c;->j(Ljava/nio/ByteOrder;)Ljava/io/Serializable;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    check-cast p1, [Lq0/e;

    .line 74
    .line 75
    if-eqz p1, :cond_1

    .line 76
    .line 77
    array-length v1, p1

    .line 78
    if-eq v1, v5, :cond_0

    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_0
    aget-object v1, p1, v4

    .line 82
    .line 83
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 84
    .line 85
    filled-new-array {v1}, [Lq0/e;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    invoke-static {v1, v2}, Lq0/c;->d([Lq0/e;Ljava/nio/ByteOrder;)Lq0/c;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    aget-object p1, p1, v3

    .line 94
    .line 95
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 96
    .line 97
    filled-new-array {p1}, [Lq0/e;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    invoke-static {p1, v2}, Lq0/c;->d([Lq0/e;Ljava/nio/ByteOrder;)Lq0/c;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    goto :goto_1

    .line 106
    :cond_1
    :goto_0
    invoke-static {p1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    return-void

    .line 110
    :cond_2
    iget-object p1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 111
    .line 112
    invoke-virtual {v1, p1}, Lq0/c;->j(Ljava/nio/ByteOrder;)Ljava/io/Serializable;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    check-cast p1, [I

    .line 117
    .line 118
    if-eqz p1, :cond_4

    .line 119
    .line 120
    array-length v1, p1

    .line 121
    if-eq v1, v5, :cond_3

    .line 122
    .line 123
    goto :goto_2

    .line 124
    :cond_3
    aget v1, p1, v4

    .line 125
    .line 126
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 127
    .line 128
    invoke-static {v1, v2}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    aget p1, p1, v3

    .line 133
    .line 134
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 135
    .line 136
    invoke-static {p1, v2}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    :goto_1
    aget-object v2, v0, p2

    .line 141
    .line 142
    invoke-virtual {v2, v7, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    aget-object p2, v0, p2

    .line 146
    .line 147
    invoke-virtual {p2, v6, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    return-void

    .line 151
    :cond_4
    :goto_2
    invoke-static {p1}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    return-void

    .line 155
    :cond_5
    if-eqz v2, :cond_6

    .line 156
    .line 157
    if-eqz v3, :cond_6

    .line 158
    .line 159
    if-eqz v4, :cond_6

    .line 160
    .line 161
    if-eqz v5, :cond_6

    .line 162
    .line 163
    iget-object p1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 164
    .line 165
    invoke-virtual {v2, p1}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 166
    .line 167
    .line 168
    move-result p1

    .line 169
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 170
    .line 171
    invoke-virtual {v4, v1}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 172
    .line 173
    .line 174
    move-result v1

    .line 175
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 176
    .line 177
    invoke-virtual {v5, v2}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 178
    .line 179
    .line 180
    move-result v2

    .line 181
    iget-object v4, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 182
    .line 183
    invoke-virtual {v3, v4}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 184
    .line 185
    .line 186
    move-result v3

    .line 187
    if-le v1, p1, :cond_8

    .line 188
    .line 189
    if-le v2, v3, :cond_8

    .line 190
    .line 191
    sub-int/2addr v1, p1

    .line 192
    sub-int/2addr v2, v3

    .line 193
    iget-object p1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 194
    .line 195
    invoke-static {v1, p1}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 196
    .line 197
    .line 198
    move-result-object p1

    .line 199
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 200
    .line 201
    invoke-static {v2, v1}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 202
    .line 203
    .line 204
    move-result-object v1

    .line 205
    aget-object v2, v0, p2

    .line 206
    .line 207
    invoke-virtual {v2, v6, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    aget-object p1, v0, p2

    .line 211
    .line 212
    invoke-virtual {p1, v7, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    return-void

    .line 216
    :cond_6
    aget-object v1, v0, p2

    .line 217
    .line 218
    invoke-virtual {v1, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v1

    .line 222
    check-cast v1, Lq0/c;

    .line 223
    .line 224
    aget-object v2, v0, p2

    .line 225
    .line 226
    invoke-virtual {v2, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v2

    .line 230
    check-cast v2, Lq0/c;

    .line 231
    .line 232
    if-eqz v1, :cond_7

    .line 233
    .line 234
    if-nez v2, :cond_8

    .line 235
    .line 236
    :cond_7
    aget-object v1, v0, p2

    .line 237
    .line 238
    const-string v2, "JPEGInterchangeFormat"

    .line 239
    .line 240
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v1

    .line 244
    check-cast v1, Lq0/c;

    .line 245
    .line 246
    aget-object v0, v0, p2

    .line 247
    .line 248
    const-string v2, "JPEGInterchangeFormatLength"

    .line 249
    .line 250
    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    check-cast v0, Lq0/c;

    .line 255
    .line 256
    if-eqz v1, :cond_8

    .line 257
    .line 258
    if-eqz v0, :cond_8

    .line 259
    .line 260
    iget-object v0, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 261
    .line 262
    invoke-virtual {v1, v0}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 263
    .line 264
    .line 265
    move-result v0

    .line 266
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 267
    .line 268
    invoke-virtual {v1, v2}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 269
    .line 270
    .line 271
    move-result v1

    .line 272
    int-to-long v2, v0

    .line 273
    invoke-virtual {p1, v2, v3}, Lq0/f;->b(J)V

    .line 274
    .line 275
    .line 276
    new-array v1, v1, [B

    .line 277
    .line 278
    invoke-virtual {p1, v1}, Ljava/io/InputStream;->read([B)I

    .line 279
    .line 280
    .line 281
    new-instance p1, Lq0/b;

    .line 282
    .line 283
    invoke-direct {p1, v1}, Lq0/b;-><init>([B)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {p0, p1, v0, p2}, Lq0/g;->h(Lq0/b;II)V

    .line 287
    .line 288
    .line 289
    :cond_8
    return-void
.end method

.method public final J()V
    .locals 9

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x5

    .line 3
    invoke-virtual {p0, v0, v1}, Lq0/g;->H(II)V

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x4

    .line 7
    invoke-virtual {p0, v0, v2}, Lq0/g;->H(II)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v1, v2}, Lq0/g;->H(II)V

    .line 11
    .line 12
    .line 13
    iget-object v3, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 14
    .line 15
    const/4 v4, 0x1

    .line 16
    aget-object v5, v3, v4

    .line 17
    .line 18
    const-string v6, "PixelXDimension"

    .line 19
    .line 20
    invoke-virtual {v5, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v5

    .line 24
    check-cast v5, Lq0/c;

    .line 25
    .line 26
    aget-object v4, v3, v4

    .line 27
    .line 28
    const-string v6, "PixelYDimension"

    .line 29
    .line 30
    invoke-virtual {v4, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    check-cast v4, Lq0/c;

    .line 35
    .line 36
    const-string v6, "ImageLength"

    .line 37
    .line 38
    const-string v7, "ImageWidth"

    .line 39
    .line 40
    if-eqz v5, :cond_0

    .line 41
    .line 42
    if-eqz v4, :cond_0

    .line 43
    .line 44
    aget-object v8, v3, v0

    .line 45
    .line 46
    invoke-virtual {v8, v7, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    aget-object v5, v3, v0

    .line 50
    .line 51
    invoke-virtual {v5, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    :cond_0
    aget-object v4, v3, v2

    .line 55
    .line 56
    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    .line 57
    .line 58
    .line 59
    move-result v4

    .line 60
    if-eqz v4, :cond_1

    .line 61
    .line 62
    aget-object v4, v3, v1

    .line 63
    .line 64
    invoke-virtual {p0, v4}, Lq0/g;->s(Ljava/util/HashMap;)Z

    .line 65
    .line 66
    .line 67
    move-result v4

    .line 68
    if-eqz v4, :cond_1

    .line 69
    .line 70
    aget-object v4, v3, v1

    .line 71
    .line 72
    aput-object v4, v3, v2

    .line 73
    .line 74
    new-instance v4, Ljava/util/HashMap;

    .line 75
    .line 76
    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 77
    .line 78
    .line 79
    aput-object v4, v3, v1

    .line 80
    .line 81
    :cond_1
    aget-object v3, v3, v2

    .line 82
    .line 83
    invoke-virtual {p0, v3}, Lq0/g;->s(Ljava/util/HashMap;)Z

    .line 84
    .line 85
    .line 86
    const-string v3, "ThumbnailOrientation"

    .line 87
    .line 88
    const-string v4, "Orientation"

    .line 89
    .line 90
    invoke-virtual {p0, v0, v3, v4}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    const-string v5, "ThumbnailImageLength"

    .line 94
    .line 95
    invoke-virtual {p0, v0, v5, v6}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    const-string v8, "ThumbnailImageWidth"

    .line 99
    .line 100
    invoke-virtual {p0, v0, v8, v7}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {p0, v1, v3, v4}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {p0, v1, v5, v6}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {p0, v1, v8, v7}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {p0, v2, v4, v3}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {p0, v2, v6, v5}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {p0, v2, v7, v8}, Lq0/g;->A(ILjava/lang/String;Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    return-void
.end method

.method public final K(Landroidx/camera/core/impl/utils/c;)V
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    sget-object v2, Lq0/g;->V:[[Lq0/d;

    .line 6
    .line 7
    array-length v3, v2

    .line 8
    new-array v3, v3, [I

    .line 9
    .line 10
    array-length v4, v2

    .line 11
    new-array v4, v4, [I

    .line 12
    .line 13
    sget-object v5, Lq0/g;->W:[Lq0/d;

    .line 14
    .line 15
    array-length v6, v5

    .line 16
    const/4 v8, 0x0

    .line 17
    :goto_0
    if-ge v8, v6, :cond_0

    .line 18
    .line 19
    aget-object v9, v5, v8

    .line 20
    .line 21
    iget-object v9, v9, Lq0/d;->b:Ljava/lang/String;

    .line 22
    .line 23
    invoke-virtual {v0, v9}, Lq0/g;->z(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    add-int/lit8 v8, v8, 0x1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    iget-boolean v6, v0, Lq0/g;->h:Z

    .line 30
    .line 31
    const-string v8, "JPEGInterchangeFormatLength"

    .line 32
    .line 33
    const-string v9, "StripByteCounts"

    .line 34
    .line 35
    const-string v10, "JPEGInterchangeFormat"

    .line 36
    .line 37
    const-string v11, "StripOffsets"

    .line 38
    .line 39
    if-eqz v6, :cond_2

    .line 40
    .line 41
    iget-boolean v6, v0, Lq0/g;->i:Z

    .line 42
    .line 43
    if-eqz v6, :cond_1

    .line 44
    .line 45
    invoke-virtual {v0, v11}, Lq0/g;->z(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v0, v9}, Lq0/g;->z(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_1
    invoke-virtual {v0, v10}, Lq0/g;->z(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v0, v8}, Lq0/g;->z(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    :cond_2
    :goto_1
    const/4 v6, 0x0

    .line 59
    :goto_2
    array-length v12, v2

    .line 60
    iget-object v13, v0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 61
    .line 62
    if-ge v6, v12, :cond_5

    .line 63
    .line 64
    aget-object v12, v13, v6

    .line 65
    .line 66
    invoke-virtual {v12}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 67
    .line 68
    .line 69
    move-result-object v12

    .line 70
    invoke-interface {v12}, Ljava/util/Set;->toArray()[Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v12

    .line 74
    array-length v14, v12

    .line 75
    const/4 v15, 0x0

    .line 76
    :goto_3
    if-ge v15, v14, :cond_4

    .line 77
    .line 78
    aget-object v16, v12, v15

    .line 79
    .line 80
    check-cast v16, Ljava/util/Map$Entry;

    .line 81
    .line 82
    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v17

    .line 86
    if-nez v17, :cond_3

    .line 87
    .line 88
    const/16 v17, 0x0

    .line 89
    .line 90
    aget-object v7, v13, v6

    .line 91
    .line 92
    move-object/from16 v18, v3

    .line 93
    .line 94
    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v3

    .line 98
    invoke-virtual {v7, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    goto :goto_4

    .line 102
    :cond_3
    move-object/from16 v18, v3

    .line 103
    .line 104
    const/16 v17, 0x0

    .line 105
    .line 106
    :goto_4
    add-int/lit8 v15, v15, 0x1

    .line 107
    .line 108
    move-object/from16 v3, v18

    .line 109
    .line 110
    goto :goto_3

    .line 111
    :cond_4
    move-object/from16 v18, v3

    .line 112
    .line 113
    const/16 v17, 0x0

    .line 114
    .line 115
    add-int/lit8 v6, v6, 0x1

    .line 116
    .line 117
    goto :goto_2

    .line 118
    :cond_5
    move-object/from16 v18, v3

    .line 119
    .line 120
    const/16 v17, 0x0

    .line 121
    .line 122
    const/4 v3, 0x1

    .line 123
    aget-object v6, v13, v3

    .line 124
    .line 125
    invoke-virtual {v6}, Ljava/util/HashMap;->isEmpty()Z

    .line 126
    .line 127
    .line 128
    move-result v6

    .line 129
    const-wide/16 v14, 0x0

    .line 130
    .line 131
    if-nez v6, :cond_6

    .line 132
    .line 133
    aget-object v6, v13, v17

    .line 134
    .line 135
    aget-object v7, v5, v3

    .line 136
    .line 137
    iget-object v7, v7, Lq0/d;->b:Ljava/lang/String;

    .line 138
    .line 139
    iget-object v12, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 140
    .line 141
    invoke-static {v14, v15, v12}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 142
    .line 143
    .line 144
    move-result-object v12

    .line 145
    invoke-virtual {v6, v7, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    :cond_6
    const/4 v6, 0x2

    .line 149
    aget-object v7, v13, v6

    .line 150
    .line 151
    invoke-virtual {v7}, Ljava/util/HashMap;->isEmpty()Z

    .line 152
    .line 153
    .line 154
    move-result v7

    .line 155
    if-nez v7, :cond_7

    .line 156
    .line 157
    aget-object v7, v13, v17

    .line 158
    .line 159
    aget-object v12, v5, v6

    .line 160
    .line 161
    iget-object v12, v12, Lq0/d;->b:Ljava/lang/String;

    .line 162
    .line 163
    move/from16 v16, v6

    .line 164
    .line 165
    iget-object v6, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 166
    .line 167
    invoke-static {v14, v15, v6}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 168
    .line 169
    .line 170
    move-result-object v6

    .line 171
    invoke-virtual {v7, v12, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    goto :goto_5

    .line 175
    :cond_7
    move/from16 v16, v6

    .line 176
    .line 177
    :goto_5
    const/4 v6, 0x3

    .line 178
    aget-object v7, v13, v6

    .line 179
    .line 180
    invoke-virtual {v7}, Ljava/util/HashMap;->isEmpty()Z

    .line 181
    .line 182
    .line 183
    move-result v7

    .line 184
    if-nez v7, :cond_8

    .line 185
    .line 186
    aget-object v7, v13, v3

    .line 187
    .line 188
    aget-object v12, v5, v6

    .line 189
    .line 190
    iget-object v12, v12, Lq0/d;->b:Ljava/lang/String;

    .line 191
    .line 192
    move/from16 v19, v6

    .line 193
    .line 194
    iget-object v6, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 195
    .line 196
    invoke-static {v14, v15, v6}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 197
    .line 198
    .line 199
    move-result-object v6

    .line 200
    invoke-virtual {v7, v12, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    goto :goto_6

    .line 204
    :cond_8
    move/from16 v19, v6

    .line 205
    .line 206
    :goto_6
    iget-boolean v6, v0, Lq0/g;->h:Z

    .line 207
    .line 208
    const/4 v7, 0x4

    .line 209
    if-eqz v6, :cond_9

    .line 210
    .line 211
    iget-boolean v6, v0, Lq0/g;->i:Z

    .line 212
    .line 213
    if-eqz v6, :cond_a

    .line 214
    .line 215
    aget-object v6, v13, v7

    .line 216
    .line 217
    iget-object v8, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 218
    .line 219
    move/from16 v12, v17

    .line 220
    .line 221
    invoke-static {v12, v8}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 222
    .line 223
    .line 224
    move-result-object v8

    .line 225
    invoke-virtual {v6, v11, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    aget-object v6, v13, v7

    .line 229
    .line 230
    iget v8, v0, Lq0/g;->l:I

    .line 231
    .line 232
    iget-object v12, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 233
    .line 234
    invoke-static {v8, v12}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 235
    .line 236
    .line 237
    move-result-object v8

    .line 238
    invoke-virtual {v6, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    :cond_9
    move/from16 v20, v3

    .line 242
    .line 243
    move-object v12, v4

    .line 244
    goto :goto_7

    .line 245
    :cond_a
    aget-object v6, v13, v7

    .line 246
    .line 247
    iget-object v9, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 248
    .line 249
    invoke-static {v14, v15, v9}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 250
    .line 251
    .line 252
    move-result-object v9

    .line 253
    invoke-virtual {v6, v10, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    aget-object v6, v13, v7

    .line 257
    .line 258
    iget v9, v0, Lq0/g;->l:I

    .line 259
    .line 260
    move/from16 v20, v3

    .line 261
    .line 262
    move-object v12, v4

    .line 263
    int-to-long v3, v9

    .line 264
    iget-object v9, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 265
    .line 266
    invoke-static {v3, v4, v9}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 267
    .line 268
    .line 269
    move-result-object v3

    .line 270
    invoke-virtual {v6, v8, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    :goto_7
    const/4 v3, 0x0

    .line 274
    :goto_8
    array-length v4, v2

    .line 275
    sget-object v6, Lq0/g;->S:[I

    .line 276
    .line 277
    if-ge v3, v4, :cond_d

    .line 278
    .line 279
    aget-object v4, v13, v3

    .line 280
    .line 281
    invoke-virtual {v4}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 282
    .line 283
    .line 284
    move-result-object v4

    .line 285
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 286
    .line 287
    .line 288
    move-result-object v4

    .line 289
    const/4 v8, 0x0

    .line 290
    :goto_9
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 291
    .line 292
    .line 293
    move-result v9

    .line 294
    if-eqz v9, :cond_c

    .line 295
    .line 296
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v9

    .line 300
    check-cast v9, Ljava/util/Map$Entry;

    .line 301
    .line 302
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object v9

    .line 306
    check-cast v9, Lq0/c;

    .line 307
    .line 308
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 309
    .line 310
    .line 311
    iget v14, v9, Lq0/c;->a:I

    .line 312
    .line 313
    aget v14, v6, v14

    .line 314
    .line 315
    iget v9, v9, Lq0/c;->b:I

    .line 316
    .line 317
    mul-int/2addr v14, v9

    .line 318
    if-le v14, v7, :cond_b

    .line 319
    .line 320
    add-int/2addr v8, v14

    .line 321
    :cond_b
    const-wide/16 v14, 0x0

    .line 322
    .line 323
    goto :goto_9

    .line 324
    :cond_c
    aget v4, v12, v3

    .line 325
    .line 326
    add-int/2addr v4, v8

    .line 327
    aput v4, v12, v3

    .line 328
    .line 329
    add-int/lit8 v3, v3, 0x1

    .line 330
    .line 331
    const-wide/16 v14, 0x0

    .line 332
    .line 333
    goto :goto_8

    .line 334
    :cond_d
    const/16 v3, 0x8

    .line 335
    .line 336
    const/4 v4, 0x0

    .line 337
    :goto_a
    array-length v8, v2

    .line 338
    if-ge v4, v8, :cond_f

    .line 339
    .line 340
    aget-object v8, v13, v4

    .line 341
    .line 342
    invoke-virtual {v8}, Ljava/util/HashMap;->isEmpty()Z

    .line 343
    .line 344
    .line 345
    move-result v8

    .line 346
    if-nez v8, :cond_e

    .line 347
    .line 348
    aput v3, v18, v4

    .line 349
    .line 350
    aget-object v8, v13, v4

    .line 351
    .line 352
    invoke-virtual {v8}, Ljava/util/HashMap;->size()I

    .line 353
    .line 354
    .line 355
    move-result v8

    .line 356
    mul-int/lit8 v8, v8, 0xc

    .line 357
    .line 358
    add-int/lit8 v8, v8, 0x6

    .line 359
    .line 360
    aget v9, v12, v4

    .line 361
    .line 362
    add-int/2addr v8, v9

    .line 363
    add-int/2addr v8, v3

    .line 364
    move v3, v8

    .line 365
    :cond_e
    add-int/lit8 v4, v4, 0x1

    .line 366
    .line 367
    goto :goto_a

    .line 368
    :cond_f
    iget-boolean v4, v0, Lq0/g;->h:Z

    .line 369
    .line 370
    if-eqz v4, :cond_11

    .line 371
    .line 372
    iget-boolean v4, v0, Lq0/g;->i:Z

    .line 373
    .line 374
    if-eqz v4, :cond_10

    .line 375
    .line 376
    aget-object v4, v13, v7

    .line 377
    .line 378
    iget-object v8, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 379
    .line 380
    invoke-static {v3, v8}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 381
    .line 382
    .line 383
    move-result-object v8

    .line 384
    invoke-virtual {v4, v11, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 385
    .line 386
    .line 387
    goto :goto_b

    .line 388
    :cond_10
    aget-object v4, v13, v7

    .line 389
    .line 390
    int-to-long v8, v3

    .line 391
    iget-object v11, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 392
    .line 393
    invoke-static {v8, v9, v11}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 394
    .line 395
    .line 396
    move-result-object v8

    .line 397
    invoke-virtual {v4, v10, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 398
    .line 399
    .line 400
    :goto_b
    iput v3, v0, Lq0/g;->k:I

    .line 401
    .line 402
    iget v4, v0, Lq0/g;->l:I

    .line 403
    .line 404
    add-int/2addr v3, v4

    .line 405
    :cond_11
    iget v4, v0, Lq0/g;->d:I

    .line 406
    .line 407
    if-ne v4, v7, :cond_12

    .line 408
    .line 409
    add-int/lit8 v3, v3, 0x8

    .line 410
    .line 411
    :cond_12
    sget-boolean v4, Lq0/g;->t:Z

    .line 412
    .line 413
    if-eqz v4, :cond_13

    .line 414
    .line 415
    const/4 v4, 0x0

    .line 416
    :goto_c
    array-length v8, v2

    .line 417
    if-ge v4, v8, :cond_13

    .line 418
    .line 419
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 420
    .line 421
    .line 422
    move-result-object v8

    .line 423
    aget v9, v18, v4

    .line 424
    .line 425
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 426
    .line 427
    .line 428
    move-result-object v9

    .line 429
    aget-object v10, v13, v4

    .line 430
    .line 431
    invoke-virtual {v10}, Ljava/util/HashMap;->size()I

    .line 432
    .line 433
    .line 434
    move-result v10

    .line 435
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 436
    .line 437
    .line 438
    move-result-object v10

    .line 439
    aget v11, v12, v4

    .line 440
    .line 441
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 442
    .line 443
    .line 444
    move-result-object v11

    .line 445
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 446
    .line 447
    .line 448
    move-result-object v14

    .line 449
    filled-new-array {v8, v9, v10, v11, v14}, [Ljava/lang/Object;

    .line 450
    .line 451
    .line 452
    move-result-object v8

    .line 453
    const-string v9, "index: %d, offsets: %d, tag count: %d, data sizes: %d, total size: %d"

    .line 454
    .line 455
    invoke-static {v9, v8}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 456
    .line 457
    .line 458
    add-int/lit8 v4, v4, 0x1

    .line 459
    .line 460
    goto :goto_c

    .line 461
    :cond_13
    aget-object v4, v13, v20

    .line 462
    .line 463
    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    .line 464
    .line 465
    .line 466
    move-result v4

    .line 467
    if-nez v4, :cond_14

    .line 468
    .line 469
    const/16 v17, 0x0

    .line 470
    .line 471
    aget-object v4, v13, v17

    .line 472
    .line 473
    aget-object v8, v5, v20

    .line 474
    .line 475
    iget-object v8, v8, Lq0/d;->b:Ljava/lang/String;

    .line 476
    .line 477
    aget v9, v18, v20

    .line 478
    .line 479
    int-to-long v9, v9

    .line 480
    iget-object v11, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 481
    .line 482
    invoke-static {v9, v10, v11}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 483
    .line 484
    .line 485
    move-result-object v9

    .line 486
    invoke-virtual {v4, v8, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 487
    .line 488
    .line 489
    :cond_14
    aget-object v4, v13, v16

    .line 490
    .line 491
    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    .line 492
    .line 493
    .line 494
    move-result v4

    .line 495
    if-nez v4, :cond_15

    .line 496
    .line 497
    const/16 v17, 0x0

    .line 498
    .line 499
    aget-object v4, v13, v17

    .line 500
    .line 501
    aget-object v8, v5, v16

    .line 502
    .line 503
    iget-object v8, v8, Lq0/d;->b:Ljava/lang/String;

    .line 504
    .line 505
    aget v9, v18, v16

    .line 506
    .line 507
    int-to-long v9, v9

    .line 508
    iget-object v11, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 509
    .line 510
    invoke-static {v9, v10, v11}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 511
    .line 512
    .line 513
    move-result-object v9

    .line 514
    invoke-virtual {v4, v8, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 515
    .line 516
    .line 517
    :cond_15
    aget-object v4, v13, v19

    .line 518
    .line 519
    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    .line 520
    .line 521
    .line 522
    move-result v4

    .line 523
    if-nez v4, :cond_16

    .line 524
    .line 525
    aget-object v4, v13, v20

    .line 526
    .line 527
    aget-object v5, v5, v19

    .line 528
    .line 529
    iget-object v5, v5, Lq0/d;->b:Ljava/lang/String;

    .line 530
    .line 531
    aget v8, v18, v19

    .line 532
    .line 533
    int-to-long v8, v8

    .line 534
    iget-object v10, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 535
    .line 536
    invoke-static {v8, v9, v10}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 537
    .line 538
    .line 539
    move-result-object v8

    .line 540
    invoke-virtual {v4, v5, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 541
    .line 542
    .line 543
    :cond_16
    iget v4, v0, Lq0/g;->d:I

    .line 544
    .line 545
    const/16 v5, 0xe

    .line 546
    .line 547
    if-eq v4, v7, :cond_19

    .line 548
    .line 549
    const/16 v8, 0xd

    .line 550
    .line 551
    if-eq v4, v8, :cond_18

    .line 552
    .line 553
    if-eq v4, v5, :cond_17

    .line 554
    .line 555
    goto :goto_d

    .line 556
    :cond_17
    sget-object v4, Lq0/g;->K:[B

    .line 557
    .line 558
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 559
    .line 560
    .line 561
    invoke-virtual {v1, v3}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 562
    .line 563
    .line 564
    goto :goto_d

    .line 565
    :cond_18
    invoke-virtual {v1, v3}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 566
    .line 567
    .line 568
    sget-object v4, Lq0/g;->F:[B

    .line 569
    .line 570
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 571
    .line 572
    .line 573
    goto :goto_d

    .line 574
    :cond_19
    int-to-short v4, v3

    .line 575
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->c(S)V

    .line 576
    .line 577
    .line 578
    sget-object v4, Lq0/g;->c0:[B

    .line 579
    .line 580
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 581
    .line 582
    .line 583
    :goto_d
    iget-object v4, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 584
    .line 585
    sget-object v8, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 586
    .line 587
    if-ne v4, v8, :cond_1a

    .line 588
    .line 589
    const/16 v4, 0x4d4d

    .line 590
    .line 591
    goto :goto_e

    .line 592
    :cond_1a
    const/16 v4, 0x4949

    .line 593
    .line 594
    :goto_e
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->c(S)V

    .line 595
    .line 596
    .line 597
    iget-object v4, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 598
    .line 599
    iput-object v4, v1, Landroidx/camera/core/impl/utils/c;->c:Ljava/nio/ByteOrder;

    .line 600
    .line 601
    const/16 v4, 0x2a

    .line 602
    .line 603
    int-to-short v4, v4

    .line 604
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->c(S)V

    .line 605
    .line 606
    .line 607
    const-wide/16 v8, 0x8

    .line 608
    .line 609
    long-to-int v4, v8

    .line 610
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 611
    .line 612
    .line 613
    const/4 v12, 0x0

    .line 614
    :goto_f
    array-length v4, v2

    .line 615
    if-ge v12, v4, :cond_22

    .line 616
    .line 617
    aget-object v4, v13, v12

    .line 618
    .line 619
    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    .line 620
    .line 621
    .line 622
    move-result v4

    .line 623
    if-nez v4, :cond_20

    .line 624
    .line 625
    aget-object v4, v13, v12

    .line 626
    .line 627
    invoke-virtual {v4}, Ljava/util/HashMap;->size()I

    .line 628
    .line 629
    .line 630
    move-result v4

    .line 631
    int-to-short v4, v4

    .line 632
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->c(S)V

    .line 633
    .line 634
    .line 635
    aget v4, v18, v12

    .line 636
    .line 637
    add-int/lit8 v4, v4, 0x2

    .line 638
    .line 639
    aget-object v8, v13, v12

    .line 640
    .line 641
    invoke-virtual {v8}, Ljava/util/HashMap;->size()I

    .line 642
    .line 643
    .line 644
    move-result v8

    .line 645
    mul-int/lit8 v8, v8, 0xc

    .line 646
    .line 647
    add-int/2addr v8, v4

    .line 648
    add-int/2addr v8, v7

    .line 649
    aget-object v4, v13, v12

    .line 650
    .line 651
    invoke-virtual {v4}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 652
    .line 653
    .line 654
    move-result-object v4

    .line 655
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 656
    .line 657
    .line 658
    move-result-object v4

    .line 659
    :cond_1b
    :goto_10
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 660
    .line 661
    .line 662
    move-result v9

    .line 663
    if-eqz v9, :cond_1d

    .line 664
    .line 665
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 666
    .line 667
    .line 668
    move-result-object v9

    .line 669
    check-cast v9, Ljava/util/Map$Entry;

    .line 670
    .line 671
    sget-object v10, Lq0/g;->Y:[Ljava/util/HashMap;

    .line 672
    .line 673
    aget-object v10, v10, v12

    .line 674
    .line 675
    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 676
    .line 677
    .line 678
    move-result-object v11

    .line 679
    invoke-virtual {v10, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 680
    .line 681
    .line 682
    move-result-object v10

    .line 683
    check-cast v10, Lq0/d;

    .line 684
    .line 685
    iget v10, v10, Lq0/d;->a:I

    .line 686
    .line 687
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 688
    .line 689
    .line 690
    move-result-object v9

    .line 691
    check-cast v9, Lq0/c;

    .line 692
    .line 693
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 694
    .line 695
    .line 696
    iget v11, v9, Lq0/c;->a:I

    .line 697
    .line 698
    aget v14, v6, v11

    .line 699
    .line 700
    iget v15, v9, Lq0/c;->b:I

    .line 701
    .line 702
    mul-int/2addr v14, v15

    .line 703
    int-to-short v10, v10

    .line 704
    invoke-virtual {v1, v10}, Landroidx/camera/core/impl/utils/c;->c(S)V

    .line 705
    .line 706
    .line 707
    int-to-short v10, v11

    .line 708
    invoke-virtual {v1, v10}, Landroidx/camera/core/impl/utils/c;->c(S)V

    .line 709
    .line 710
    .line 711
    invoke-virtual {v1, v15}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 712
    .line 713
    .line 714
    if-le v14, v7, :cond_1c

    .line 715
    .line 716
    int-to-long v9, v8

    .line 717
    long-to-int v9, v9

    .line 718
    invoke-virtual {v1, v9}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 719
    .line 720
    .line 721
    add-int/2addr v8, v14

    .line 722
    goto :goto_10

    .line 723
    :cond_1c
    iget-object v9, v9, Lq0/c;->d:[B

    .line 724
    .line 725
    invoke-virtual {v1, v9}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 726
    .line 727
    .line 728
    if-ge v14, v7, :cond_1b

    .line 729
    .line 730
    :goto_11
    if-ge v14, v7, :cond_1b

    .line 731
    .line 732
    const/4 v9, 0x0

    .line 733
    invoke-virtual {v1, v9}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 734
    .line 735
    .line 736
    add-int/lit8 v14, v14, 0x1

    .line 737
    .line 738
    goto :goto_11

    .line 739
    :cond_1d
    if-nez v12, :cond_1e

    .line 740
    .line 741
    aget-object v4, v13, v7

    .line 742
    .line 743
    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    .line 744
    .line 745
    .line 746
    move-result v4

    .line 747
    if-nez v4, :cond_1e

    .line 748
    .line 749
    aget v4, v18, v7

    .line 750
    .line 751
    int-to-long v8, v4

    .line 752
    long-to-int v4, v8

    .line 753
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 754
    .line 755
    .line 756
    const-wide/16 v8, 0x0

    .line 757
    .line 758
    goto :goto_12

    .line 759
    :cond_1e
    const-wide/16 v8, 0x0

    .line 760
    .line 761
    long-to-int v4, v8

    .line 762
    invoke-virtual {v1, v4}, Landroidx/camera/core/impl/utils/c;->b(I)V

    .line 763
    .line 764
    .line 765
    :goto_12
    aget-object v4, v13, v12

    .line 766
    .line 767
    invoke-virtual {v4}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 768
    .line 769
    .line 770
    move-result-object v4

    .line 771
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 772
    .line 773
    .line 774
    move-result-object v4

    .line 775
    :cond_1f
    :goto_13
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 776
    .line 777
    .line 778
    move-result v10

    .line 779
    if-eqz v10, :cond_21

    .line 780
    .line 781
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 782
    .line 783
    .line 784
    move-result-object v10

    .line 785
    check-cast v10, Ljava/util/Map$Entry;

    .line 786
    .line 787
    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 788
    .line 789
    .line 790
    move-result-object v10

    .line 791
    check-cast v10, Lq0/c;

    .line 792
    .line 793
    iget-object v10, v10, Lq0/c;->d:[B

    .line 794
    .line 795
    array-length v11, v10

    .line 796
    if-le v11, v7, :cond_1f

    .line 797
    .line 798
    array-length v11, v10

    .line 799
    const/4 v14, 0x0

    .line 800
    invoke-virtual {v1, v10, v14, v11}, Landroidx/camera/core/impl/utils/c;->write([BII)V

    .line 801
    .line 802
    .line 803
    goto :goto_13

    .line 804
    :cond_20
    const-wide/16 v8, 0x0

    .line 805
    .line 806
    :cond_21
    add-int/lit8 v12, v12, 0x1

    .line 807
    .line 808
    goto/16 :goto_f

    .line 809
    .line 810
    :cond_22
    iget-boolean v2, v0, Lq0/g;->h:Z

    .line 811
    .line 812
    if-eqz v2, :cond_23

    .line 813
    .line 814
    invoke-virtual {v0}, Lq0/g;->o()[B

    .line 815
    .line 816
    .line 817
    move-result-object v2

    .line 818
    invoke-virtual {v1, v2}, Landroidx/camera/core/impl/utils/c;->write([B)V

    .line 819
    .line 820
    .line 821
    :cond_23
    iget v2, v0, Lq0/g;->d:I

    .line 822
    .line 823
    if-ne v2, v5, :cond_24

    .line 824
    .line 825
    rem-int/lit8 v3, v3, 0x2

    .line 826
    .line 827
    move/from16 v2, v20

    .line 828
    .line 829
    if-ne v3, v2, :cond_24

    .line 830
    .line 831
    const/4 v14, 0x0

    .line 832
    invoke-virtual {v1, v14}, Landroidx/camera/core/impl/utils/c;->a(I)V

    .line 833
    .line 834
    .line 835
    :cond_24
    sget-object v2, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 836
    .line 837
    iput-object v2, v1, Landroidx/camera/core/impl/utils/c;->c:Ljava/nio/ByteOrder;

    .line 838
    .line 839
    return-void
.end method

.method public final a()V
    .locals 7

    .line 1
    const-string v0, "DateTimeOriginal"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    const-string v3, "DateTime"

    .line 13
    .line 14
    invoke-virtual {p0, v3}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    if-nez v4, :cond_0

    .line 19
    .line 20
    aget-object v4, v1, v2

    .line 21
    .line 22
    invoke-static {v0}, Lq0/c;->a(Ljava/lang/String;)Lq0/c;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {v4, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    :cond_0
    const-string v0, "ImageWidth"

    .line 30
    .line 31
    invoke-virtual {p0, v0}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    const-wide/16 v4, 0x0

    .line 36
    .line 37
    if-nez v3, :cond_1

    .line 38
    .line 39
    aget-object v3, v1, v2

    .line 40
    .line 41
    iget-object v6, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 42
    .line 43
    invoke-static {v4, v5, v6}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    invoke-virtual {v3, v0, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    :cond_1
    const-string v0, "ImageLength"

    .line 51
    .line 52
    invoke-virtual {p0, v0}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    if-nez v3, :cond_2

    .line 57
    .line 58
    aget-object v3, v1, v2

    .line 59
    .line 60
    iget-object v6, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 61
    .line 62
    invoke-static {v4, v5, v6}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    invoke-virtual {v3, v0, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    :cond_2
    const-string v0, "Orientation"

    .line 70
    .line 71
    invoke-virtual {p0, v0}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    if-nez v3, :cond_3

    .line 76
    .line 77
    aget-object v2, v1, v2

    .line 78
    .line 79
    iget-object v3, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 80
    .line 81
    invoke-static {v4, v5, v3}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    invoke-virtual {v2, v0, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    :cond_3
    const-string v0, "LightSource"

    .line 89
    .line 90
    invoke-virtual {p0, v0}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    if-nez v2, :cond_4

    .line 95
    .line 96
    const/4 v2, 0x1

    .line 97
    aget-object v1, v1, v2

    .line 98
    .line 99
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 100
    .line 101
    invoke-static {v4, v5, v2}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    invoke-virtual {v1, v0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    :cond_4
    return-void
.end method

.method public final d(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 1
    if-eqz p1, :cond_6

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lq0/g;->f(Ljava/lang/String;)Lq0/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_5

    .line 9
    .line 10
    sget-object v2, Lq0/g;->Z:Ljava/util/HashSet;

    .line 11
    .line 12
    invoke-virtual {v2, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-nez v2, :cond_0

    .line 17
    .line 18
    iget-object p1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 19
    .line 20
    invoke-virtual {v0, p1}, Lq0/c;->i(Ljava/nio/ByteOrder;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    return-object p1

    .line 25
    :cond_0
    const-string v2, "GPSTimeStamp"

    .line 26
    .line 27
    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_4

    .line 32
    .line 33
    const/4 p1, 0x5

    .line 34
    iget v2, v0, Lq0/c;->a:I

    .line 35
    .line 36
    if-eq v2, p1, :cond_1

    .line 37
    .line 38
    const/16 p1, 0xa

    .line 39
    .line 40
    if-eq v2, p1, :cond_1

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_1
    iget-object p1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 44
    .line 45
    invoke-virtual {v0, p1}, Lq0/c;->j(Ljava/nio/ByteOrder;)Ljava/io/Serializable;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    check-cast p1, [Lq0/e;

    .line 50
    .line 51
    if-eqz p1, :cond_3

    .line 52
    .line 53
    array-length v0, p1

    .line 54
    const/4 v2, 0x3

    .line 55
    if-eq v0, v2, :cond_2

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_2
    const/4 v0, 0x0

    .line 59
    aget-object v0, p1, v0

    .line 60
    .line 61
    iget-wide v1, v0, Lq0/e;->a:J

    .line 62
    .line 63
    long-to-float v1, v1

    .line 64
    iget-wide v2, v0, Lq0/e;->b:J

    .line 65
    .line 66
    long-to-float v0, v2

    .line 67
    div-float/2addr v1, v0

    .line 68
    float-to-int v0, v1

    .line 69
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    const/4 v1, 0x1

    .line 74
    aget-object v1, p1, v1

    .line 75
    .line 76
    iget-wide v2, v1, Lq0/e;->a:J

    .line 77
    .line 78
    long-to-float v2, v2

    .line 79
    iget-wide v3, v1, Lq0/e;->b:J

    .line 80
    .line 81
    long-to-float v1, v3

    .line 82
    div-float/2addr v2, v1

    .line 83
    float-to-int v1, v2

    .line 84
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    const/4 v2, 0x2

    .line 89
    aget-object p1, p1, v2

    .line 90
    .line 91
    iget-wide v2, p1, Lq0/e;->a:J

    .line 92
    .line 93
    long-to-float v2, v2

    .line 94
    iget-wide v3, p1, Lq0/e;->b:J

    .line 95
    .line 96
    long-to-float p1, v3

    .line 97
    div-float/2addr v2, p1

    .line 98
    float-to-int p1, v2

    .line 99
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    filled-new-array {v0, v1, p1}, [Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    const-string v0, "%02d:%02d:%02d"

    .line 108
    .line 109
    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    return-object p1

    .line 114
    :cond_3
    :goto_0
    invoke-static {p1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    return-object v1

    .line 118
    :cond_4
    :try_start_0
    iget-object p1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 119
    .line 120
    invoke-virtual {v0, p1}, Lq0/c;->g(Ljava/nio/ByteOrder;)D

    .line 121
    .line 122
    .line 123
    move-result-wide v2

    .line 124
    invoke-static {v2, v3}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 128
    return-object p1

    .line 129
    :catch_0
    :cond_5
    :goto_1
    return-object v1

    .line 130
    :cond_6
    new-instance p1, Ljava/lang/NullPointerException;

    .line 131
    .line 132
    const-string/jumbo v0, "tag shouldn\'t be null"

    .line 133
    .line 134
    .line 135
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    throw p1
.end method

.method public final e(ILjava/lang/String;)I
    .locals 1

    .line 1
    invoke-virtual {p0, p2}, Lq0/g;->f(Ljava/lang/String;)Lq0/c;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    if-nez p2, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    :try_start_0
    iget-object v0, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 9
    .line 10
    invoke-virtual {p2, v0}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 11
    .line 12
    .line 13
    move-result p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 14
    :catch_0
    :goto_0
    return p1
.end method

.method public final f(Ljava/lang/String;)Lq0/c;
    .locals 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    const-string v0, "ISOSpeedRatings"

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    const-string p1, "PhotographicSensitivity"

    .line 12
    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    :goto_0
    sget-object v1, Lq0/g;->V:[[Lq0/d;

    .line 15
    .line 16
    array-length v1, v1

    .line 17
    if-ge v0, v1, :cond_2

    .line 18
    .line 19
    iget-object v1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 20
    .line 21
    aget-object v1, v1, v0

    .line 22
    .line 23
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    check-cast v1, Lq0/c;

    .line 28
    .line 29
    if-eqz v1, :cond_1

    .line 30
    .line 31
    return-object v1

    .line 32
    :cond_1
    add-int/lit8 v0, v0, 0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_2
    const/4 p1, 0x0

    .line 36
    return-object p1

    .line 37
    :cond_3
    new-instance p1, Ljava/lang/NullPointerException;

    .line 38
    .line 39
    const-string/jumbo v0, "tag shouldn\'t be null"

    .line 40
    .line 41
    .line 42
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1
.end method

.method public final g(Lq0/f;)V
    .locals 11

    .line 1
    const-string/jumbo v0, "yes"

    .line 2
    .line 3
    .line 4
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const/16 v2, 0x1c

    .line 7
    .line 8
    if-lt v1, v2, :cond_d

    .line 9
    .line 10
    new-instance v1, Landroid/media/MediaMetadataRetriever;

    .line 11
    .line 12
    invoke-direct {v1}, Landroid/media/MediaMetadataRetriever;-><init>()V

    .line 13
    .line 14
    .line 15
    :try_start_0
    new-instance v2, Lq0/a;

    .line 16
    .line 17
    invoke-direct {v2, p1}, Lq0/a;-><init>(Lq0/f;)V

    .line 18
    .line 19
    .line 20
    invoke-static {v1, v2}, Lq0/i;->a(Landroid/media/MediaMetadataRetriever;Landroid/media/MediaDataSource;)V

    .line 21
    .line 22
    .line 23
    const/16 v2, 0x21

    .line 24
    .line 25
    invoke-virtual {v1, v2}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    const/16 v3, 0x22

    .line 30
    .line 31
    invoke-virtual {v1, v3}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    const/16 v4, 0x1a

    .line 36
    .line 37
    invoke-virtual {v1, v4}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v4

    .line 41
    const/16 v5, 0x11

    .line 42
    .line 43
    invoke-virtual {v1, v5}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v5

    .line 47
    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v4

    .line 51
    if-eqz v4, :cond_0

    .line 52
    .line 53
    const/16 v0, 0x1d

    .line 54
    .line 55
    invoke-virtual {v1, v0}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    const/16 v4, 0x1e

    .line 60
    .line 61
    invoke-virtual {v1, v4}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v4

    .line 65
    const/16 v5, 0x1f

    .line 66
    .line 67
    invoke-virtual {v1, v5}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v5

    .line 71
    goto :goto_0

    .line 72
    :catchall_0
    move-exception p1

    .line 73
    goto/16 :goto_3

    .line 74
    .line 75
    :cond_0
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_1

    .line 80
    .line 81
    const/16 v0, 0x12

    .line 82
    .line 83
    invoke-virtual {v1, v0}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    const/16 v4, 0x13

    .line 88
    .line 89
    invoke-virtual {v1, v4}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v4

    .line 93
    const/16 v5, 0x18

    .line 94
    .line 95
    invoke-virtual {v1, v5}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v5
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 99
    goto :goto_0

    .line 100
    :cond_1
    const/4 v0, 0x0

    .line 101
    move-object v4, v0

    .line 102
    move-object v5, v4

    .line 103
    :goto_0
    iget-object v6, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 104
    .line 105
    const/4 v7, 0x0

    .line 106
    if-eqz v0, :cond_2

    .line 107
    .line 108
    :try_start_1
    aget-object v8, v6, v7

    .line 109
    .line 110
    const-string v9, "ImageWidth"

    .line 111
    .line 112
    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    iget-object v10, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 117
    .line 118
    invoke-static {v0, v10}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    invoke-virtual {v8, v9, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    :cond_2
    if-eqz v4, :cond_3

    .line 126
    .line 127
    aget-object v0, v6, v7

    .line 128
    .line 129
    const-string v8, "ImageLength"

    .line 130
    .line 131
    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 132
    .line 133
    .line 134
    move-result v4

    .line 135
    iget-object v9, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 136
    .line 137
    invoke-static {v4, v9}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 138
    .line 139
    .line 140
    move-result-object v4

    .line 141
    invoke-virtual {v0, v8, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    :cond_3
    const/4 v0, 0x6

    .line 145
    if-eqz v5, :cond_7

    .line 146
    .line 147
    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 148
    .line 149
    .line 150
    move-result v4

    .line 151
    const/16 v5, 0x5a

    .line 152
    .line 153
    if-eq v4, v5, :cond_6

    .line 154
    .line 155
    const/16 v5, 0xb4

    .line 156
    .line 157
    if-eq v4, v5, :cond_5

    .line 158
    .line 159
    const/16 v5, 0x10e

    .line 160
    .line 161
    if-eq v4, v5, :cond_4

    .line 162
    .line 163
    const/4 v4, 0x1

    .line 164
    goto :goto_1

    .line 165
    :cond_4
    const/16 v4, 0x8

    .line 166
    .line 167
    goto :goto_1

    .line 168
    :cond_5
    const/4 v4, 0x3

    .line 169
    goto :goto_1

    .line 170
    :cond_6
    move v4, v0

    .line 171
    :goto_1
    aget-object v5, v6, v7

    .line 172
    .line 173
    const-string v6, "Orientation"

    .line 174
    .line 175
    iget-object v8, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 176
    .line 177
    invoke-static {v4, v8}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 178
    .line 179
    .line 180
    move-result-object v4

    .line 181
    invoke-virtual {v5, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    :cond_7
    if-eqz v2, :cond_c

    .line 185
    .line 186
    if-eqz v3, :cond_c

    .line 187
    .line 188
    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 189
    .line 190
    .line 191
    move-result v2

    .line 192
    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 193
    .line 194
    .line 195
    move-result v3

    .line 196
    if-le v3, v0, :cond_b

    .line 197
    .line 198
    int-to-long v4, v2

    .line 199
    invoke-virtual {p1, v4, v5}, Lq0/f;->b(J)V

    .line 200
    .line 201
    .line 202
    new-array v4, v0, [B

    .line 203
    .line 204
    invoke-virtual {p1, v4}, Ljava/io/InputStream;->read([B)I

    .line 205
    .line 206
    .line 207
    move-result v5

    .line 208
    if-ne v5, v0, :cond_a

    .line 209
    .line 210
    add-int/2addr v2, v0

    .line 211
    add-int/lit8 v3, v3, -0x6

    .line 212
    .line 213
    sget-object v0, Lq0/g;->c0:[B

    .line 214
    .line 215
    invoke-static {v4, v0}, Ljava/util/Arrays;->equals([B[B)Z

    .line 216
    .line 217
    .line 218
    move-result v0

    .line 219
    if-eqz v0, :cond_9

    .line 220
    .line 221
    new-array v0, v3, [B

    .line 222
    .line 223
    invoke-virtual {p1, v0}, Ljava/io/InputStream;->read([B)I

    .line 224
    .line 225
    .line 226
    move-result p1

    .line 227
    if-ne p1, v3, :cond_8

    .line 228
    .line 229
    iput v2, p0, Lq0/g;->o:I

    .line 230
    .line 231
    invoke-virtual {p0, v7, v0}, Lq0/g;->x(I[B)V

    .line 232
    .line 233
    .line 234
    goto :goto_2

    .line 235
    :cond_8
    new-instance p1, Ljava/io/IOException;

    .line 236
    .line 237
    const-string v0, "Can\'t read exif"

    .line 238
    .line 239
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    throw p1

    .line 243
    :cond_9
    new-instance p1, Ljava/io/IOException;

    .line 244
    .line 245
    const-string v0, "Invalid identifier"

    .line 246
    .line 247
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    throw p1

    .line 251
    :cond_a
    new-instance p1, Ljava/io/IOException;

    .line 252
    .line 253
    const-string v0, "Can\'t read identifier"

    .line 254
    .line 255
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    throw p1

    .line 259
    :cond_b
    new-instance p1, Ljava/io/IOException;

    .line 260
    .line 261
    const-string v0, "Invalid exif length"

    .line 262
    .line 263
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    throw p1
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 267
    :cond_c
    :goto_2
    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V

    .line 268
    .line 269
    .line 270
    return-void

    .line 271
    :catch_0
    :try_start_2
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 272
    .line 273
    const-string v0, "Failed to read EXIF from HEIF file. Given stream is either malformed or unsupported."

    .line 274
    .line 275
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 276
    .line 277
    .line 278
    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 279
    :goto_3
    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V

    .line 280
    .line 281
    .line 282
    throw p1

    .line 283
    :cond_d
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 284
    .line 285
    const-string v0, "Reading EXIF from HEIF files is supported from SDK 28 and above"

    .line 286
    .line 287
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 288
    .line 289
    .line 290
    throw p1
.end method

.method public final h(Lq0/b;II)V
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move/from16 v2, p3

    .line 6
    .line 7
    sget-boolean v3, Lq0/g;->t:Z

    .line 8
    .line 9
    if-eqz v3, :cond_0

    .line 10
    .line 11
    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    :cond_0
    sget-object v4, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 15
    .line 16
    iput-object v4, v1, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 17
    .line 18
    invoke-virtual {v1}, Lq0/b;->readByte()B

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    const-string v5, "Invalid marker: "

    .line 23
    .line 24
    const/4 v6, -0x1

    .line 25
    if-ne v4, v6, :cond_18

    .line 26
    .line 27
    invoke-virtual {v1}, Lq0/b;->readByte()B

    .line 28
    .line 29
    .line 30
    move-result v7

    .line 31
    const/16 v8, -0x28

    .line 32
    .line 33
    if-ne v7, v8, :cond_17

    .line 34
    .line 35
    const/4 v4, 0x2

    .line 36
    :goto_0
    invoke-virtual {v1}, Lq0/b;->readByte()B

    .line 37
    .line 38
    .line 39
    move-result v5

    .line 40
    if-ne v5, v6, :cond_16

    .line 41
    .line 42
    invoke-virtual {v1}, Lq0/b;->readByte()B

    .line 43
    .line 44
    .line 45
    move-result v5

    .line 46
    if-eqz v3, :cond_1

    .line 47
    .line 48
    and-int/lit16 v7, v5, 0xff

    .line 49
    .line 50
    invoke-static {v7}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    :cond_1
    const/16 v7, -0x27

    .line 54
    .line 55
    if-eq v5, v7, :cond_15

    .line 56
    .line 57
    const/16 v7, -0x26

    .line 58
    .line 59
    if-ne v5, v7, :cond_2

    .line 60
    .line 61
    goto/16 :goto_9

    .line 62
    .line 63
    :cond_2
    invoke-virtual {v1}, Lq0/b;->readUnsignedShort()I

    .line 64
    .line 65
    .line 66
    move-result v7

    .line 67
    add-int/lit8 v8, v7, -0x2

    .line 68
    .line 69
    const/4 v9, 0x4

    .line 70
    add-int/2addr v4, v9

    .line 71
    if-eqz v3, :cond_3

    .line 72
    .line 73
    and-int/lit16 v10, v5, 0xff

    .line 74
    .line 75
    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    :cond_3
    const-string v10, "Invalid length"

    .line 79
    .line 80
    if-ltz v8, :cond_14

    .line 81
    .line 82
    iget-object v11, v0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 83
    .line 84
    const/4 v12, 0x0

    .line 85
    const/4 v13, 0x1

    .line 86
    const/16 v14, -0x1f

    .line 87
    .line 88
    if-eq v5, v14, :cond_9

    .line 89
    .line 90
    const/4 v14, -0x2

    .line 91
    if-eq v5, v14, :cond_6

    .line 92
    .line 93
    packed-switch v5, :pswitch_data_0

    .line 94
    .line 95
    .line 96
    packed-switch v5, :pswitch_data_1

    .line 97
    .line 98
    .line 99
    packed-switch v5, :pswitch_data_2

    .line 100
    .line 101
    .line 102
    packed-switch v5, :pswitch_data_3

    .line 103
    .line 104
    .line 105
    goto/16 :goto_8

    .line 106
    .line 107
    :pswitch_0
    invoke-virtual {v1, v13}, Lq0/b;->a(I)V

    .line 108
    .line 109
    .line 110
    aget-object v5, v11, v2

    .line 111
    .line 112
    if-eq v2, v9, :cond_4

    .line 113
    .line 114
    const-string v8, "ImageLength"

    .line 115
    .line 116
    goto :goto_1

    .line 117
    :cond_4
    const-string v8, "ThumbnailImageLength"

    .line 118
    .line 119
    :goto_1
    invoke-virtual {v1}, Lq0/b;->readUnsignedShort()I

    .line 120
    .line 121
    .line 122
    move-result v12

    .line 123
    int-to-long v12, v12

    .line 124
    iget-object v14, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 125
    .line 126
    invoke-static {v12, v13, v14}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 127
    .line 128
    .line 129
    move-result-object v12

    .line 130
    invoke-virtual {v5, v8, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    aget-object v5, v11, v2

    .line 134
    .line 135
    if-eq v2, v9, :cond_5

    .line 136
    .line 137
    const-string v8, "ImageWidth"

    .line 138
    .line 139
    goto :goto_2

    .line 140
    :cond_5
    const-string v8, "ThumbnailImageWidth"

    .line 141
    .line 142
    :goto_2
    invoke-virtual {v1}, Lq0/b;->readUnsignedShort()I

    .line 143
    .line 144
    .line 145
    move-result v9

    .line 146
    int-to-long v11, v9

    .line 147
    iget-object v9, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 148
    .line 149
    invoke-static {v11, v12, v9}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 150
    .line 151
    .line 152
    move-result-object v9

    .line 153
    invoke-virtual {v5, v8, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    add-int/lit8 v8, v7, -0x7

    .line 157
    .line 158
    goto/16 :goto_8

    .line 159
    .line 160
    :cond_6
    new-array v5, v8, [B

    .line 161
    .line 162
    invoke-virtual {v1, v5}, Ljava/io/InputStream;->read([B)I

    .line 163
    .line 164
    .line 165
    move-result v7

    .line 166
    if-ne v7, v8, :cond_8

    .line 167
    .line 168
    const-string v7, "UserComment"

    .line 169
    .line 170
    invoke-virtual {v0, v7}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v8

    .line 174
    if-nez v8, :cond_7

    .line 175
    .line 176
    aget-object v8, v11, v13

    .line 177
    .line 178
    new-instance v9, Ljava/lang/String;

    .line 179
    .line 180
    sget-object v11, Lq0/g;->b0:Ljava/nio/charset/Charset;

    .line 181
    .line 182
    invoke-direct {v9, v5, v11}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 183
    .line 184
    .line 185
    invoke-static {v9}, Lq0/c;->a(Ljava/lang/String;)Lq0/c;

    .line 186
    .line 187
    .line 188
    move-result-object v5

    .line 189
    invoke-virtual {v8, v7, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    :cond_7
    :goto_3
    move v8, v12

    .line 193
    goto/16 :goto_8

    .line 194
    .line 195
    :cond_8
    new-instance v1, Ljava/io/IOException;

    .line 196
    .line 197
    const-string v2, "Invalid exif"

    .line 198
    .line 199
    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    throw v1

    .line 203
    :cond_9
    new-array v5, v8, [B

    .line 204
    .line 205
    invoke-virtual {v1, v5}, Lq0/b;->readFully([B)V

    .line 206
    .line 207
    .line 208
    add-int v7, v4, v8

    .line 209
    .line 210
    sget-object v9, Lq0/g;->c0:[B

    .line 211
    .line 212
    if-nez v9, :cond_a

    .line 213
    .line 214
    goto :goto_5

    .line 215
    :cond_a
    array-length v14, v9

    .line 216
    if-ge v8, v14, :cond_b

    .line 217
    .line 218
    goto :goto_5

    .line 219
    :cond_b
    move v14, v12

    .line 220
    :goto_4
    array-length v15, v9

    .line 221
    if-ge v14, v15, :cond_11

    .line 222
    .line 223
    aget-byte v15, v5, v14

    .line 224
    .line 225
    aget-byte v6, v9, v14

    .line 226
    .line 227
    if-eq v15, v6, :cond_10

    .line 228
    .line 229
    :goto_5
    sget-object v6, Lq0/g;->d0:[B

    .line 230
    .line 231
    if-nez v6, :cond_c

    .line 232
    .line 233
    goto :goto_7

    .line 234
    :cond_c
    array-length v9, v6

    .line 235
    if-ge v8, v9, :cond_d

    .line 236
    .line 237
    goto :goto_7

    .line 238
    :cond_d
    move v9, v12

    .line 239
    :goto_6
    array-length v14, v6

    .line 240
    if-ge v9, v14, :cond_f

    .line 241
    .line 242
    aget-byte v14, v5, v9

    .line 243
    .line 244
    aget-byte v15, v6, v9

    .line 245
    .line 246
    if-eq v14, v15, :cond_e

    .line 247
    .line 248
    goto :goto_7

    .line 249
    :cond_e
    add-int/lit8 v9, v9, 0x1

    .line 250
    .line 251
    goto :goto_6

    .line 252
    :cond_f
    array-length v9, v6

    .line 253
    add-int/2addr v4, v9

    .line 254
    array-length v6, v6

    .line 255
    invoke-static {v5, v6, v8}, Ljava/util/Arrays;->copyOfRange([BII)[B

    .line 256
    .line 257
    .line 258
    move-result-object v5

    .line 259
    const-string v6, "Xmp"

    .line 260
    .line 261
    invoke-virtual {v0, v6}, Lq0/g;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 262
    .line 263
    .line 264
    move-result-object v8

    .line 265
    if-nez v8, :cond_12

    .line 266
    .line 267
    aget-object v8, v11, v12

    .line 268
    .line 269
    new-instance v16, Lq0/c;

    .line 270
    .line 271
    array-length v9, v5

    .line 272
    int-to-long v14, v4

    .line 273
    const/16 v20, 0x1

    .line 274
    .line 275
    move-object/from16 v19, v5

    .line 276
    .line 277
    move/from16 v21, v9

    .line 278
    .line 279
    move-wide/from16 v17, v14

    .line 280
    .line 281
    invoke-direct/range {v16 .. v21}, Lq0/c;-><init>(J[BII)V

    .line 282
    .line 283
    .line 284
    move-object/from16 v4, v16

    .line 285
    .line 286
    invoke-virtual {v8, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    iput-boolean v13, v0, Lq0/g;->s:Z

    .line 290
    .line 291
    goto :goto_7

    .line 292
    :cond_10
    add-int/lit8 v14, v14, 0x1

    .line 293
    .line 294
    const/4 v6, -0x1

    .line 295
    goto :goto_4

    .line 296
    :cond_11
    array-length v6, v9

    .line 297
    invoke-static {v5, v6, v8}, Ljava/util/Arrays;->copyOfRange([BII)[B

    .line 298
    .line 299
    .line 300
    move-result-object v5

    .line 301
    add-int v4, p2, v4

    .line 302
    .line 303
    array-length v6, v9

    .line 304
    add-int/2addr v4, v6

    .line 305
    iput v4, v0, Lq0/g;->o:I

    .line 306
    .line 307
    invoke-virtual {v0, v2, v5}, Lq0/g;->x(I[B)V

    .line 308
    .line 309
    .line 310
    new-instance v4, Lq0/b;

    .line 311
    .line 312
    invoke-direct {v4, v5}, Lq0/b;-><init>([B)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {v0, v4}, Lq0/g;->G(Lq0/b;)V

    .line 316
    .line 317
    .line 318
    :cond_12
    :goto_7
    move v4, v7

    .line 319
    goto :goto_3

    .line 320
    :goto_8
    if-ltz v8, :cond_13

    .line 321
    .line 322
    invoke-virtual {v1, v8}, Lq0/b;->a(I)V

    .line 323
    .line 324
    .line 325
    add-int/2addr v4, v8

    .line 326
    const/4 v6, -0x1

    .line 327
    goto/16 :goto_0

    .line 328
    .line 329
    :cond_13
    new-instance v1, Ljava/io/IOException;

    .line 330
    .line 331
    invoke-direct {v1, v10}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 332
    .line 333
    .line 334
    throw v1

    .line 335
    :cond_14
    new-instance v1, Ljava/io/IOException;

    .line 336
    .line 337
    invoke-direct {v1, v10}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 338
    .line 339
    .line 340
    throw v1

    .line 341
    :cond_15
    :goto_9
    iget-object v2, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 342
    .line 343
    iput-object v2, v1, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 344
    .line 345
    return-void

    .line 346
    :cond_16
    new-instance v1, Ljava/io/IOException;

    .line 347
    .line 348
    new-instance v2, Ljava/lang/StringBuilder;

    .line 349
    .line 350
    const-string v3, "Invalid marker:"

    .line 351
    .line 352
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 353
    .line 354
    .line 355
    and-int/lit16 v3, v5, 0xff

    .line 356
    .line 357
    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 358
    .line 359
    .line 360
    move-result-object v3

    .line 361
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 362
    .line 363
    .line 364
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 365
    .line 366
    .line 367
    move-result-object v2

    .line 368
    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 369
    .line 370
    .line 371
    throw v1

    .line 372
    :cond_17
    new-instance v1, Ljava/io/IOException;

    .line 373
    .line 374
    new-instance v2, Ljava/lang/StringBuilder;

    .line 375
    .line 376
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 377
    .line 378
    .line 379
    and-int/lit16 v3, v4, 0xff

    .line 380
    .line 381
    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 382
    .line 383
    .line 384
    move-result-object v3

    .line 385
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 386
    .line 387
    .line 388
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 389
    .line 390
    .line 391
    move-result-object v2

    .line 392
    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 393
    .line 394
    .line 395
    throw v1

    .line 396
    :cond_18
    new-instance v1, Ljava/io/IOException;

    .line 397
    .line 398
    new-instance v2, Ljava/lang/StringBuilder;

    .line 399
    .line 400
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 401
    .line 402
    .line 403
    and-int/lit16 v3, v4, 0xff

    .line 404
    .line 405
    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 406
    .line 407
    .line 408
    move-result-object v3

    .line 409
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 410
    .line 411
    .line 412
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 413
    .line 414
    .line 415
    move-result-object v2

    .line 416
    invoke-direct {v1, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 417
    .line 418
    .line 419
    throw v1

    .line 420
    nop

    .line 421
    :pswitch_data_0
    .packed-switch -0x40
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    :pswitch_data_1
    .packed-switch -0x3b
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    :pswitch_data_2
    .packed-switch -0x37
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch

    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    :pswitch_data_3
    .packed-switch -0x33
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public final i(Ljava/io/BufferedInputStream;)I
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    const/16 v2, 0x1388

    .line 6
    .line 7
    invoke-virtual {v0, v2}, Ljava/io/BufferedInputStream;->mark(I)V

    .line 8
    .line 9
    .line 10
    new-array v3, v2, [B

    .line 11
    .line 12
    invoke-virtual {v0, v3}, Ljava/io/InputStream;->read([B)I

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/io/BufferedInputStream;->reset()V

    .line 16
    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    move v4, v0

    .line 20
    :goto_0
    sget-object v5, Lq0/g;->y:[B

    .line 21
    .line 22
    array-length v6, v5

    .line 23
    const/4 v7, 0x4

    .line 24
    if-ge v4, v6, :cond_21

    .line 25
    .line 26
    aget-byte v6, v3, v4

    .line 27
    .line 28
    aget-byte v5, v5, v4

    .line 29
    .line 30
    if-eq v6, v5, :cond_20

    .line 31
    .line 32
    const-string v4, "FUJIFILMCCD-RAW"

    .line 33
    .line 34
    invoke-static {}, Ljava/nio/charset/Charset;->defaultCharset()Ljava/nio/charset/Charset;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    invoke-virtual {v4, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    move v5, v0

    .line 43
    :goto_1
    array-length v6, v4

    .line 44
    if-ge v5, v6, :cond_1f

    .line 45
    .line 46
    aget-byte v6, v3, v5

    .line 47
    .line 48
    aget-byte v8, v4, v5

    .line 49
    .line 50
    if-eq v6, v8, :cond_1e

    .line 51
    .line 52
    :try_start_0
    new-instance v6, Lq0/b;

    .line 53
    .line 54
    invoke-direct {v6, v3}, Lq0/b;-><init>([B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 55
    .line 56
    .line 57
    :try_start_1
    invoke-virtual {v6}, Lq0/b;->readInt()I

    .line 58
    .line 59
    .line 60
    move-result v8

    .line 61
    int-to-long v8, v8

    .line 62
    new-array v10, v7, [B

    .line 63
    .line 64
    invoke-virtual {v6, v10}, Ljava/io/InputStream;->read([B)I

    .line 65
    .line 66
    .line 67
    sget-object v11, Lq0/g;->z:[B

    .line 68
    .line 69
    invoke-static {v10, v11}, Ljava/util/Arrays;->equals([B[B)Z

    .line 70
    .line 71
    .line 72
    move-result v10
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 73
    if-nez v10, :cond_1

    .line 74
    .line 75
    :cond_0
    :goto_2
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    .line 76
    .line 77
    .line 78
    goto/16 :goto_8

    .line 79
    .line 80
    :cond_1
    const-wide/16 v10, 0x1

    .line 81
    .line 82
    cmp-long v12, v8, v10

    .line 83
    .line 84
    const-wide/16 v13, 0x8

    .line 85
    .line 86
    if-nez v12, :cond_2

    .line 87
    .line 88
    :try_start_2
    invoke-virtual {v6}, Lq0/b;->readLong()J

    .line 89
    .line 90
    .line 91
    move-result-wide v8

    .line 92
    const-wide/16 v15, 0x10

    .line 93
    .line 94
    cmp-long v12, v8, v15

    .line 95
    .line 96
    if-gez v12, :cond_3

    .line 97
    .line 98
    goto :goto_2

    .line 99
    :catchall_0
    move-exception v0

    .line 100
    move-object v5, v6

    .line 101
    goto :goto_6

    .line 102
    :cond_2
    move-wide v15, v13

    .line 103
    :cond_3
    int-to-long v4, v2

    .line 104
    cmp-long v2, v8, v4

    .line 105
    .line 106
    if-lez v2, :cond_4

    .line 107
    .line 108
    move-wide v8, v4

    .line 109
    :cond_4
    sub-long/2addr v8, v15

    .line 110
    cmp-long v2, v8, v13

    .line 111
    .line 112
    if-gez v2, :cond_5

    .line 113
    .line 114
    goto :goto_2

    .line 115
    :cond_5
    new-array v2, v7, [B

    .line 116
    .line 117
    const-wide/16 v4, 0x0

    .line 118
    .line 119
    move v13, v0

    .line 120
    move v14, v13

    .line 121
    :goto_3
    const-wide/16 v15, 0x4

    .line 122
    .line 123
    div-long v15, v8, v15

    .line 124
    .line 125
    cmp-long v15, v4, v15

    .line 126
    .line 127
    if-gez v15, :cond_0

    .line 128
    .line 129
    invoke-virtual {v6, v2}, Ljava/io/InputStream;->read([B)I

    .line 130
    .line 131
    .line 132
    move-result v15

    .line 133
    if-eq v15, v7, :cond_6

    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_6
    cmp-long v15, v4, v10

    .line 137
    .line 138
    if-nez v15, :cond_7

    .line 139
    .line 140
    goto :goto_5

    .line 141
    :cond_7
    sget-object v15, Lq0/g;->A:[B

    .line 142
    .line 143
    invoke-static {v2, v15}, Ljava/util/Arrays;->equals([B[B)Z

    .line 144
    .line 145
    .line 146
    move-result v15

    .line 147
    if-eqz v15, :cond_8

    .line 148
    .line 149
    const/4 v13, 0x1

    .line 150
    goto :goto_4

    .line 151
    :cond_8
    sget-object v15, Lq0/g;->B:[B

    .line 152
    .line 153
    invoke-static {v2, v15}, Ljava/util/Arrays;->equals([B[B)Z

    .line 154
    .line 155
    .line 156
    move-result v15
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 157
    if-eqz v15, :cond_9

    .line 158
    .line 159
    const/4 v14, 0x1

    .line 160
    :cond_9
    :goto_4
    if-eqz v13, :cond_a

    .line 161
    .line 162
    if-eqz v14, :cond_a

    .line 163
    .line 164
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    .line 165
    .line 166
    .line 167
    const/16 v0, 0xc

    .line 168
    .line 169
    return v0

    .line 170
    :cond_a
    :goto_5
    add-long/2addr v4, v10

    .line 171
    goto :goto_3

    .line 172
    :catchall_1
    move-exception v0

    .line 173
    const/4 v5, 0x0

    .line 174
    goto :goto_6

    .line 175
    :catch_0
    const/4 v6, 0x0

    .line 176
    goto :goto_7

    .line 177
    :goto_6
    if-eqz v5, :cond_b

    .line 178
    .line 179
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .line 180
    .line 181
    .line 182
    :cond_b
    throw v0

    .line 183
    :catch_1
    :goto_7
    if-eqz v6, :cond_c

    .line 184
    .line 185
    goto :goto_2

    .line 186
    :cond_c
    :goto_8
    :try_start_3
    new-instance v2, Lq0/b;

    .line 187
    .line 188
    invoke-direct {v2, v3}, Lq0/b;-><init>([B)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 189
    .line 190
    .line 191
    :try_start_4
    invoke-static {v2}, Lq0/g;->w(Lq0/b;)Ljava/nio/ByteOrder;

    .line 192
    .line 193
    .line 194
    move-result-object v4

    .line 195
    iput-object v4, v1, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 196
    .line 197
    iput-object v4, v2, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 198
    .line 199
    invoke-virtual {v2}, Lq0/b;->readShort()S

    .line 200
    .line 201
    .line 202
    move-result v4
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 203
    const/16 v5, 0x4f52

    .line 204
    .line 205
    if-eq v4, v5, :cond_e

    .line 206
    .line 207
    const/16 v5, 0x5352

    .line 208
    .line 209
    if-ne v4, v5, :cond_d

    .line 210
    .line 211
    goto :goto_9

    .line 212
    :cond_d
    move v4, v0

    .line 213
    goto :goto_a

    .line 214
    :cond_e
    :goto_9
    const/4 v4, 0x1

    .line 215
    :goto_a
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    .line 216
    .line 217
    .line 218
    goto :goto_d

    .line 219
    :catchall_2
    move-exception v0

    .line 220
    move-object v5, v2

    .line 221
    goto :goto_b

    .line 222
    :catchall_3
    move-exception v0

    .line 223
    const/4 v5, 0x0

    .line 224
    goto :goto_b

    .line 225
    :catch_2
    const/4 v2, 0x0

    .line 226
    goto :goto_c

    .line 227
    :goto_b
    if-eqz v5, :cond_f

    .line 228
    .line 229
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .line 230
    .line 231
    .line 232
    :cond_f
    throw v0

    .line 233
    :catch_3
    :goto_c
    if-eqz v2, :cond_10

    .line 234
    .line 235
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    .line 236
    .line 237
    .line 238
    :cond_10
    move v4, v0

    .line 239
    :goto_d
    if-eqz v4, :cond_11

    .line 240
    .line 241
    const/4 v0, 0x7

    .line 242
    return v0

    .line 243
    :cond_11
    :try_start_5
    new-instance v2, Lq0/b;

    .line 244
    .line 245
    invoke-direct {v2, v3}, Lq0/b;-><init>([B)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 246
    .line 247
    .line 248
    :try_start_6
    invoke-static {v2}, Lq0/g;->w(Lq0/b;)Ljava/nio/ByteOrder;

    .line 249
    .line 250
    .line 251
    move-result-object v4

    .line 252
    iput-object v4, v1, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 253
    .line 254
    iput-object v4, v2, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 255
    .line 256
    invoke-virtual {v2}, Lq0/b;->readShort()S

    .line 257
    .line 258
    .line 259
    move-result v4
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 260
    const/16 v5, 0x55

    .line 261
    .line 262
    if-ne v4, v5, :cond_12

    .line 263
    .line 264
    const/4 v4, 0x1

    .line 265
    goto :goto_e

    .line 266
    :cond_12
    move v4, v0

    .line 267
    :goto_e
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    .line 268
    .line 269
    .line 270
    goto :goto_11

    .line 271
    :catchall_4
    move-exception v0

    .line 272
    move-object v5, v2

    .line 273
    goto :goto_f

    .line 274
    :catch_4
    move-object v5, v2

    .line 275
    goto :goto_10

    .line 276
    :catchall_5
    move-exception v0

    .line 277
    const/4 v5, 0x0

    .line 278
    goto :goto_f

    .line 279
    :catch_5
    const/4 v5, 0x0

    .line 280
    goto :goto_10

    .line 281
    :goto_f
    if-eqz v5, :cond_13

    .line 282
    .line 283
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .line 284
    .line 285
    .line 286
    :cond_13
    throw v0

    .line 287
    :goto_10
    if-eqz v5, :cond_14

    .line 288
    .line 289
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .line 290
    .line 291
    .line 292
    :cond_14
    move v4, v0

    .line 293
    :goto_11
    if-eqz v4, :cond_15

    .line 294
    .line 295
    const/16 v0, 0xa

    .line 296
    .line 297
    return v0

    .line 298
    :cond_15
    move v2, v0

    .line 299
    :goto_12
    sget-object v4, Lq0/g;->E:[B

    .line 300
    .line 301
    array-length v5, v4

    .line 302
    if-ge v2, v5, :cond_17

    .line 303
    .line 304
    aget-byte v5, v3, v2

    .line 305
    .line 306
    aget-byte v4, v4, v2

    .line 307
    .line 308
    if-eq v5, v4, :cond_16

    .line 309
    .line 310
    move v2, v0

    .line 311
    goto :goto_13

    .line 312
    :cond_16
    add-int/lit8 v2, v2, 0x1

    .line 313
    .line 314
    goto :goto_12

    .line 315
    :cond_17
    const/4 v2, 0x1

    .line 316
    :goto_13
    if-eqz v2, :cond_18

    .line 317
    .line 318
    const/16 v0, 0xd

    .line 319
    .line 320
    return v0

    .line 321
    :cond_18
    move v2, v0

    .line 322
    :goto_14
    sget-object v4, Lq0/g;->I:[B

    .line 323
    .line 324
    array-length v5, v4

    .line 325
    if-ge v2, v5, :cond_1a

    .line 326
    .line 327
    aget-byte v5, v3, v2

    .line 328
    .line 329
    aget-byte v4, v4, v2

    .line 330
    .line 331
    if-eq v5, v4, :cond_19

    .line 332
    .line 333
    :goto_15
    move v4, v0

    .line 334
    goto :goto_17

    .line 335
    :cond_19
    add-int/lit8 v2, v2, 0x1

    .line 336
    .line 337
    goto :goto_14

    .line 338
    :cond_1a
    move v2, v0

    .line 339
    :goto_16
    sget-object v5, Lq0/g;->J:[B

    .line 340
    .line 341
    array-length v6, v5

    .line 342
    if-ge v2, v6, :cond_1c

    .line 343
    .line 344
    array-length v6, v4

    .line 345
    add-int/2addr v6, v2

    .line 346
    add-int/2addr v6, v7

    .line 347
    aget-byte v6, v3, v6

    .line 348
    .line 349
    aget-byte v5, v5, v2

    .line 350
    .line 351
    if-eq v6, v5, :cond_1b

    .line 352
    .line 353
    goto :goto_15

    .line 354
    :cond_1b
    add-int/lit8 v2, v2, 0x1

    .line 355
    .line 356
    goto :goto_16

    .line 357
    :cond_1c
    const/4 v4, 0x1

    .line 358
    :goto_17
    if-eqz v4, :cond_1d

    .line 359
    .line 360
    const/16 v0, 0xe

    .line 361
    .line 362
    :cond_1d
    return v0

    .line 363
    :cond_1e
    add-int/lit8 v5, v5, 0x1

    .line 364
    .line 365
    goto/16 :goto_1

    .line 366
    .line 367
    :cond_1f
    const/16 v0, 0x9

    .line 368
    .line 369
    return v0

    .line 370
    :cond_20
    add-int/lit8 v4, v4, 0x1

    .line 371
    .line 372
    goto/16 :goto_0

    .line 373
    .line 374
    :cond_21
    return v7
.end method

.method public final j(Lq0/f;)V
    .locals 6

    .line 1
    invoke-virtual {p0, p1}, Lq0/g;->m(Lq0/f;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    aget-object v1, p1, v0

    .line 8
    .line 9
    const-string v2, "MakerNote"

    .line 10
    .line 11
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lq0/c;

    .line 16
    .line 17
    if-eqz v1, :cond_6

    .line 18
    .line 19
    new-instance v2, Lq0/f;

    .line 20
    .line 21
    iget-object v1, v1, Lq0/c;->d:[B

    .line 22
    .line 23
    invoke-direct {v2, v1}, Lq0/f;-><init>([B)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 27
    .line 28
    iput-object v1, v2, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 29
    .line 30
    sget-object v1, Lq0/g;->C:[B

    .line 31
    .line 32
    array-length v3, v1

    .line 33
    new-array v3, v3, [B

    .line 34
    .line 35
    invoke-virtual {v2, v3}, Lq0/b;->readFully([B)V

    .line 36
    .line 37
    .line 38
    const-wide/16 v4, 0x0

    .line 39
    .line 40
    invoke-virtual {v2, v4, v5}, Lq0/f;->b(J)V

    .line 41
    .line 42
    .line 43
    sget-object v4, Lq0/g;->D:[B

    .line 44
    .line 45
    array-length v5, v4

    .line 46
    new-array v5, v5, [B

    .line 47
    .line 48
    invoke-virtual {v2, v5}, Lq0/b;->readFully([B)V

    .line 49
    .line 50
    .line 51
    invoke-static {v3, v1}, Ljava/util/Arrays;->equals([B[B)Z

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    if-eqz v1, :cond_0

    .line 56
    .line 57
    const-wide/16 v3, 0x8

    .line 58
    .line 59
    invoke-virtual {v2, v3, v4}, Lq0/f;->b(J)V

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_0
    invoke-static {v5, v4}, Ljava/util/Arrays;->equals([B[B)Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    if-eqz v1, :cond_1

    .line 68
    .line 69
    const-wide/16 v3, 0xc

    .line 70
    .line 71
    invoke-virtual {v2, v3, v4}, Lq0/f;->b(J)V

    .line 72
    .line 73
    .line 74
    :cond_1
    :goto_0
    const/4 v1, 0x6

    .line 75
    invoke-virtual {p0, v2, v1}, Lq0/g;->y(Lq0/f;I)V

    .line 76
    .line 77
    .line 78
    const/4 v1, 0x7

    .line 79
    aget-object v2, p1, v1

    .line 80
    .line 81
    const-string v3, "PreviewImageStart"

    .line 82
    .line 83
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    check-cast v2, Lq0/c;

    .line 88
    .line 89
    aget-object v1, p1, v1

    .line 90
    .line 91
    const-string v3, "PreviewImageLength"

    .line 92
    .line 93
    invoke-virtual {v1, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    check-cast v1, Lq0/c;

    .line 98
    .line 99
    if-eqz v2, :cond_2

    .line 100
    .line 101
    if-eqz v1, :cond_2

    .line 102
    .line 103
    const/4 v3, 0x5

    .line 104
    aget-object v4, p1, v3

    .line 105
    .line 106
    const-string v5, "JPEGInterchangeFormat"

    .line 107
    .line 108
    invoke-virtual {v4, v5, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    aget-object v2, p1, v3

    .line 112
    .line 113
    const-string v3, "JPEGInterchangeFormatLength"

    .line 114
    .line 115
    invoke-virtual {v2, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    :cond_2
    const/16 v1, 0x8

    .line 119
    .line 120
    aget-object v1, p1, v1

    .line 121
    .line 122
    const-string v2, "AspectFrame"

    .line 123
    .line 124
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    check-cast v1, Lq0/c;

    .line 129
    .line 130
    if-eqz v1, :cond_6

    .line 131
    .line 132
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 133
    .line 134
    invoke-virtual {v1, v2}, Lq0/c;->j(Ljava/nio/ByteOrder;)Ljava/io/Serializable;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    check-cast v1, [I

    .line 139
    .line 140
    if-eqz v1, :cond_5

    .line 141
    .line 142
    array-length v2, v1

    .line 143
    const/4 v3, 0x4

    .line 144
    if-eq v2, v3, :cond_3

    .line 145
    .line 146
    goto :goto_1

    .line 147
    :cond_3
    const/4 v2, 0x2

    .line 148
    aget v2, v1, v2

    .line 149
    .line 150
    const/4 v3, 0x0

    .line 151
    aget v4, v1, v3

    .line 152
    .line 153
    if-le v2, v4, :cond_6

    .line 154
    .line 155
    const/4 v5, 0x3

    .line 156
    aget v5, v1, v5

    .line 157
    .line 158
    aget v1, v1, v0

    .line 159
    .line 160
    if-le v5, v1, :cond_6

    .line 161
    .line 162
    sub-int/2addr v2, v4

    .line 163
    add-int/2addr v2, v0

    .line 164
    sub-int/2addr v5, v1

    .line 165
    add-int/2addr v5, v0

    .line 166
    if-ge v2, v5, :cond_4

    .line 167
    .line 168
    add-int/2addr v2, v5

    .line 169
    sub-int v5, v2, v5

    .line 170
    .line 171
    sub-int/2addr v2, v5

    .line 172
    :cond_4
    iget-object v0, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 173
    .line 174
    invoke-static {v2, v0}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 179
    .line 180
    invoke-static {v5, v1}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 181
    .line 182
    .line 183
    move-result-object v1

    .line 184
    aget-object v2, p1, v3

    .line 185
    .line 186
    const-string v4, "ImageWidth"

    .line 187
    .line 188
    invoke-virtual {v2, v4, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    aget-object p1, p1, v3

    .line 192
    .line 193
    const-string v0, "ImageLength"

    .line 194
    .line 195
    invoke-virtual {p1, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    return-void

    .line 199
    :cond_5
    :goto_1
    invoke-static {v1}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    :cond_6
    return-void
.end method

.method public final k(Lq0/b;)V
    .locals 5

    .line 1
    sget-boolean v0, Lq0/g;->t:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    :cond_0
    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 9
    .line 10
    iput-object v0, p1, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 11
    .line 12
    sget-object v0, Lq0/g;->E:[B

    .line 13
    .line 14
    array-length v1, v0

    .line 15
    invoke-virtual {p1, v1}, Lq0/b;->a(I)V

    .line 16
    .line 17
    .line 18
    array-length v0, v0

    .line 19
    :goto_0
    :try_start_0
    invoke-virtual {p1}, Lq0/b;->readInt()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    const/4 v2, 0x4

    .line 24
    new-array v3, v2, [B

    .line 25
    .line 26
    invoke-virtual {p1, v3}, Ljava/io/InputStream;->read([B)I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-ne v4, v2, :cond_7

    .line 31
    .line 32
    add-int/lit8 v0, v0, 0x8

    .line 33
    .line 34
    const/16 v2, 0x10

    .line 35
    .line 36
    if-ne v0, v2, :cond_2

    .line 37
    .line 38
    sget-object v2, Lq0/g;->G:[B

    .line 39
    .line 40
    invoke-static {v3, v2}, Ljava/util/Arrays;->equals([B[B)Z

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    if-eqz v2, :cond_1

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    new-instance p1, Ljava/io/IOException;

    .line 48
    .line 49
    const-string v0, "Encountered invalid PNG file--IHDR chunk should appearas the first chunk"

    .line 50
    .line 51
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    throw p1

    .line 55
    :cond_2
    :goto_1
    sget-object v2, Lq0/g;->H:[B

    .line 56
    .line 57
    invoke-static {v3, v2}, Ljava/util/Arrays;->equals([B[B)Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    if-eqz v2, :cond_3

    .line 62
    .line 63
    return-void

    .line 64
    :cond_3
    sget-object v2, Lq0/g;->F:[B

    .line 65
    .line 66
    invoke-static {v3, v2}, Ljava/util/Arrays;->equals([B[B)Z

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    if-eqz v2, :cond_6

    .line 71
    .line 72
    new-array v2, v1, [B

    .line 73
    .line 74
    invoke-virtual {p1, v2}, Ljava/io/InputStream;->read([B)I

    .line 75
    .line 76
    .line 77
    move-result v4

    .line 78
    if-ne v4, v1, :cond_5

    .line 79
    .line 80
    invoke-virtual {p1}, Lq0/b;->readInt()I

    .line 81
    .line 82
    .line 83
    move-result p1

    .line 84
    new-instance v1, Ljava/util/zip/CRC32;

    .line 85
    .line 86
    invoke-direct {v1}, Ljava/util/zip/CRC32;-><init>()V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v1, v3}, Ljava/util/zip/CRC32;->update([B)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v1, v2}, Ljava/util/zip/CRC32;->update([B)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1}, Ljava/util/zip/CRC32;->getValue()J

    .line 96
    .line 97
    .line 98
    move-result-wide v3

    .line 99
    long-to-int v3, v3

    .line 100
    if-ne v3, p1, :cond_4

    .line 101
    .line 102
    iput v0, p0, Lq0/g;->o:I

    .line 103
    .line 104
    const/4 p1, 0x0

    .line 105
    invoke-virtual {p0, p1, v2}, Lq0/g;->x(I[B)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p0}, Lq0/g;->J()V

    .line 109
    .line 110
    .line 111
    new-instance p1, Lq0/b;

    .line 112
    .line 113
    invoke-direct {p1, v2}, Lq0/b;-><init>([B)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {p0, p1}, Lq0/g;->G(Lq0/b;)V

    .line 117
    .line 118
    .line 119
    return-void

    .line 120
    :cond_4
    new-instance v0, Ljava/io/IOException;

    .line 121
    .line 122
    new-instance v2, Ljava/lang/StringBuilder;

    .line 123
    .line 124
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 125
    .line 126
    .line 127
    const-string v3, "Encountered invalid CRC value for PNG-EXIF chunk.\n recorded CRC value: "

    .line 128
    .line 129
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 130
    .line 131
    .line 132
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 133
    .line 134
    .line 135
    const-string p1, ", calculated CRC value: "

    .line 136
    .line 137
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 138
    .line 139
    .line 140
    invoke-virtual {v1}, Ljava/util/zip/CRC32;->getValue()J

    .line 141
    .line 142
    .line 143
    move-result-wide v3

    .line 144
    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 145
    .line 146
    .line 147
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    throw v0

    .line 155
    :cond_5
    new-instance p1, Ljava/io/IOException;

    .line 156
    .line 157
    new-instance v0, Ljava/lang/StringBuilder;

    .line 158
    .line 159
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 160
    .line 161
    .line 162
    const-string v1, "Failed to read given length for given PNG chunk type: "

    .line 163
    .line 164
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 165
    .line 166
    .line 167
    invoke-static {v3}, Lcom/palmpay/lib/apm/launchcounter/util/d;->c([B)Ljava/lang/String;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    throw p1

    .line 182
    :cond_6
    add-int/lit8 v1, v1, 0x4

    .line 183
    .line 184
    invoke-virtual {p1, v1}, Lq0/b;->a(I)V

    .line 185
    .line 186
    .line 187
    add-int/2addr v0, v1

    .line 188
    goto/16 :goto_0

    .line 189
    .line 190
    :cond_7
    new-instance p1, Ljava/io/IOException;

    .line 191
    .line 192
    const-string v0, "Encountered invalid length while parsing PNG chunktype"

    .line 193
    .line 194
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    throw p1
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 198
    :catch_0
    new-instance p1, Ljava/io/IOException;

    .line 199
    .line 200
    const-string v0, "Encountered corrupt PNG file."

    .line 201
    .line 202
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 203
    .line 204
    .line 205
    throw p1
.end method

.method public final l(Lq0/b;)V
    .locals 6

    .line 1
    sget-boolean v0, Lq0/g;->t:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    :cond_0
    const/16 v0, 0x54

    .line 9
    .line 10
    invoke-virtual {p1, v0}, Lq0/b;->a(I)V

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x4

    .line 14
    new-array v1, v0, [B

    .line 15
    .line 16
    new-array v2, v0, [B

    .line 17
    .line 18
    new-array v0, v0, [B

    .line 19
    .line 20
    invoke-virtual {p1, v1}, Ljava/io/InputStream;->read([B)I

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1, v2}, Ljava/io/InputStream;->read([B)I

    .line 24
    .line 25
    .line 26
    invoke-virtual {p1, v0}, Ljava/io/InputStream;->read([B)I

    .line 27
    .line 28
    .line 29
    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->getInt()I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    invoke-static {v2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->getInt()I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getInt()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    new-array v2, v2, [B

    .line 54
    .line 55
    iget v3, p1, Lq0/b;->c:I

    .line 56
    .line 57
    sub-int v3, v1, v3

    .line 58
    .line 59
    invoke-virtual {p1, v3}, Lq0/b;->a(I)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1, v2}, Ljava/io/InputStream;->read([B)I

    .line 63
    .line 64
    .line 65
    new-instance v3, Lq0/b;

    .line 66
    .line 67
    invoke-direct {v3, v2}, Lq0/b;-><init>([B)V

    .line 68
    .line 69
    .line 70
    const/4 v2, 0x5

    .line 71
    invoke-virtual {p0, v3, v1, v2}, Lq0/g;->h(Lq0/b;II)V

    .line 72
    .line 73
    .line 74
    iget v1, p1, Lq0/b;->c:I

    .line 75
    .line 76
    sub-int/2addr v0, v1

    .line 77
    invoke-virtual {p1, v0}, Lq0/b;->a(I)V

    .line 78
    .line 79
    .line 80
    sget-object v0, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 81
    .line 82
    iput-object v0, p1, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 83
    .line 84
    invoke-virtual {p1}, Lq0/b;->readInt()I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    const/4 v1, 0x0

    .line 89
    move v2, v1

    .line 90
    :goto_0
    if-ge v2, v0, :cond_2

    .line 91
    .line 92
    invoke-virtual {p1}, Lq0/b;->readUnsignedShort()I

    .line 93
    .line 94
    .line 95
    move-result v3

    .line 96
    invoke-virtual {p1}, Lq0/b;->readUnsignedShort()I

    .line 97
    .line 98
    .line 99
    move-result v4

    .line 100
    sget-object v5, Lq0/g;->U:Lq0/d;

    .line 101
    .line 102
    iget v5, v5, Lq0/d;->a:I

    .line 103
    .line 104
    if-ne v3, v5, :cond_1

    .line 105
    .line 106
    invoke-virtual {p1}, Lq0/b;->readShort()S

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    invoke-virtual {p1}, Lq0/b;->readShort()S

    .line 111
    .line 112
    .line 113
    move-result p1

    .line 114
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 115
    .line 116
    invoke-static {v0, v2}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 121
    .line 122
    invoke-static {p1, v2}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    iget-object v2, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 127
    .line 128
    aget-object v3, v2, v1

    .line 129
    .line 130
    const-string v4, "ImageLength"

    .line 131
    .line 132
    invoke-virtual {v3, v4, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    aget-object v0, v2, v1

    .line 136
    .line 137
    const-string v1, "ImageWidth"

    .line 138
    .line 139
    invoke-virtual {v0, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    return-void

    .line 143
    :cond_1
    invoke-virtual {p1, v4}, Lq0/b;->a(I)V

    .line 144
    .line 145
    .line 146
    add-int/lit8 v2, v2, 0x1

    .line 147
    .line 148
    goto :goto_0

    .line 149
    :cond_2
    return-void
.end method

.method public final m(Lq0/f;)V
    .locals 3

    .line 1
    invoke-virtual {p0, p1}, Lq0/g;->u(Lq0/f;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-virtual {p0, p1, v0}, Lq0/g;->y(Lq0/f;I)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, p1, v0}, Lq0/g;->I(Lq0/f;I)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x5

    .line 12
    invoke-virtual {p0, p1, v0}, Lq0/g;->I(Lq0/f;I)V

    .line 13
    .line 14
    .line 15
    const/4 v0, 0x4

    .line 16
    invoke-virtual {p0, p1, v0}, Lq0/g;->I(Lq0/f;I)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Lq0/g;->J()V

    .line 20
    .line 21
    .line 22
    iget p1, p0, Lq0/g;->d:I

    .line 23
    .line 24
    const/16 v0, 0x8

    .line 25
    .line 26
    if-ne p1, v0, :cond_0

    .line 27
    .line 28
    iget-object p1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 29
    .line 30
    const/4 v0, 0x1

    .line 31
    aget-object v1, p1, v0

    .line 32
    .line 33
    const-string v2, "MakerNote"

    .line 34
    .line 35
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    check-cast v1, Lq0/c;

    .line 40
    .line 41
    if-eqz v1, :cond_0

    .line 42
    .line 43
    new-instance v2, Lq0/f;

    .line 44
    .line 45
    iget-object v1, v1, Lq0/c;->d:[B

    .line 46
    .line 47
    invoke-direct {v2, v1}, Lq0/f;-><init>([B)V

    .line 48
    .line 49
    .line 50
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 51
    .line 52
    iput-object v1, v2, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 53
    .line 54
    const/4 v1, 0x6

    .line 55
    invoke-virtual {v2, v1}, Lq0/b;->a(I)V

    .line 56
    .line 57
    .line 58
    const/16 v1, 0x9

    .line 59
    .line 60
    invoke-virtual {p0, v2, v1}, Lq0/g;->y(Lq0/f;I)V

    .line 61
    .line 62
    .line 63
    aget-object v1, p1, v1

    .line 64
    .line 65
    const-string v2, "ColorSpace"

    .line 66
    .line 67
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    check-cast v1, Lq0/c;

    .line 72
    .line 73
    if-eqz v1, :cond_0

    .line 74
    .line 75
    aget-object p1, p1, v0

    .line 76
    .line 77
    invoke-virtual {p1, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    :cond_0
    return-void
.end method

.method public final n(Lq0/f;)V
    .locals 5

    .line 1
    sget-boolean v0, Lq0/g;->t:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    :cond_0
    invoke-virtual {p0, p1}, Lq0/g;->m(Lq0/f;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    aget-object v1, p1, v0

    .line 15
    .line 16
    const-string v2, "JpgFromRaw"

    .line 17
    .line 18
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lq0/c;

    .line 23
    .line 24
    if-eqz v1, :cond_1

    .line 25
    .line 26
    new-instance v2, Lq0/b;

    .line 27
    .line 28
    iget-object v3, v1, Lq0/c;->d:[B

    .line 29
    .line 30
    invoke-direct {v2, v3}, Lq0/b;-><init>([B)V

    .line 31
    .line 32
    .line 33
    iget-wide v3, v1, Lq0/c;->c:J

    .line 34
    .line 35
    long-to-int v1, v3

    .line 36
    const/4 v3, 0x5

    .line 37
    invoke-virtual {p0, v2, v1, v3}, Lq0/g;->h(Lq0/b;II)V

    .line 38
    .line 39
    .line 40
    :cond_1
    aget-object v0, p1, v0

    .line 41
    .line 42
    const-string v1, "ISO"

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    check-cast v0, Lq0/c;

    .line 49
    .line 50
    const/4 v1, 0x1

    .line 51
    aget-object v2, p1, v1

    .line 52
    .line 53
    const-string v3, "PhotographicSensitivity"

    .line 54
    .line 55
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    check-cast v2, Lq0/c;

    .line 60
    .line 61
    if-eqz v0, :cond_2

    .line 62
    .line 63
    if-nez v2, :cond_2

    .line 64
    .line 65
    aget-object p1, p1, v1

    .line 66
    .line 67
    invoke-virtual {p1, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    :cond_2
    return-void
.end method

.method public final o()[B
    .locals 8

    .line 1
    iget-boolean v0, p0, Lq0/g;->h:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    goto/16 :goto_5

    .line 7
    .line 8
    :cond_0
    iget-object v0, p0, Lq0/g;->m:[B

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    return-object v0

    .line 13
    :cond_1
    :try_start_0
    iget-object v0, p0, Lq0/g;->c:Landroid/content/res/AssetManager$AssetInputStream;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 14
    .line 15
    if-eqz v0, :cond_3

    .line 16
    .line 17
    :try_start_1
    invoke-virtual {v0}, Ljava/io/InputStream;->markSupported()Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_2

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/io/InputStream;->reset()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 24
    .line 25
    .line 26
    :goto_0
    move-object v2, v1

    .line 27
    goto :goto_1

    .line 28
    :catchall_0
    move-exception v2

    .line 29
    move-object v7, v1

    .line 30
    move-object v1, v0

    .line 31
    move-object v0, v2

    .line 32
    move-object v2, v7

    .line 33
    goto/16 :goto_3

    .line 34
    .line 35
    :catch_0
    move-object v2, v1

    .line 36
    goto/16 :goto_4

    .line 37
    .line 38
    :cond_2
    invoke-static {v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 39
    .line 40
    .line 41
    return-object v1

    .line 42
    :cond_3
    :try_start_2
    iget-object v0, p0, Lq0/g;->a:Ljava/lang/String;

    .line 43
    .line 44
    if-eqz v0, :cond_4

    .line 45
    .line 46
    new-instance v0, Ljava/io/FileInputStream;

    .line 47
    .line 48
    iget-object v2, p0, Lq0/g;->a:Ljava/lang/String;

    .line 49
    .line 50
    invoke-direct {v0, v2}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :catchall_1
    move-exception v2

    .line 55
    move-object v0, v2

    .line 56
    move-object v2, v1

    .line 57
    goto/16 :goto_3

    .line 58
    .line 59
    :catch_1
    move-object v0, v1

    .line 60
    move-object v2, v0

    .line 61
    goto/16 :goto_4

    .line 62
    .line 63
    :cond_4
    iget-object v0, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 64
    .line 65
    invoke-static {v0}, Lq0/h;->b(Ljava/io/FileDescriptor;)Ljava/io/FileDescriptor;

    .line 66
    .line 67
    .line 68
    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 69
    :try_start_3
    sget v2, Landroid/system/OsConstants;->SEEK_SET:I

    .line 70
    .line 71
    const-wide/16 v3, 0x0

    .line 72
    .line 73
    invoke-static {v0, v3, v4, v2}, Lq0/h;->c(Ljava/io/FileDescriptor;JI)J

    .line 74
    .line 75
    .line 76
    new-instance v2, Ljava/io/FileInputStream;

    .line 77
    .line 78
    invoke-direct {v2, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 79
    .line 80
    .line 81
    move-object v7, v2

    .line 82
    move-object v2, v0

    .line 83
    move-object v0, v7

    .line 84
    :goto_1
    :try_start_4
    iget v3, p0, Lq0/g;->k:I

    .line 85
    .line 86
    iget v4, p0, Lq0/g;->o:I

    .line 87
    .line 88
    add-int/2addr v3, v4

    .line 89
    int-to-long v3, v3

    .line 90
    invoke-virtual {v0, v3, v4}, Ljava/io/InputStream;->skip(J)J

    .line 91
    .line 92
    .line 93
    move-result-wide v3

    .line 94
    iget v5, p0, Lq0/g;->k:I

    .line 95
    .line 96
    iget v6, p0, Lq0/g;->o:I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 97
    .line 98
    add-int/2addr v5, v6

    .line 99
    int-to-long v5, v5

    .line 100
    cmp-long v3, v3, v5

    .line 101
    .line 102
    const-string v4, "Corrupted image"

    .line 103
    .line 104
    if-nez v3, :cond_7

    .line 105
    .line 106
    :try_start_5
    iget v3, p0, Lq0/g;->l:I

    .line 107
    .line 108
    new-array v3, v3, [B

    .line 109
    .line 110
    invoke-virtual {v0, v3}, Ljava/io/InputStream;->read([B)I

    .line 111
    .line 112
    .line 113
    move-result v5

    .line 114
    iget v6, p0, Lq0/g;->l:I

    .line 115
    .line 116
    if-ne v5, v6, :cond_6

    .line 117
    .line 118
    iput-object v3, p0, Lq0/g;->m:[B
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 119
    .line 120
    invoke-static {v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 121
    .line 122
    .line 123
    if-eqz v2, :cond_5

    .line 124
    .line 125
    invoke-static {v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->f(Ljava/io/FileDescriptor;)V

    .line 126
    .line 127
    .line 128
    :cond_5
    return-object v3

    .line 129
    :catchall_2
    move-exception v1

    .line 130
    move-object v7, v1

    .line 131
    move-object v1, v0

    .line 132
    :goto_2
    move-object v0, v7

    .line 133
    goto :goto_3

    .line 134
    :cond_6
    :try_start_6
    new-instance v3, Ljava/io/IOException;

    .line 135
    .line 136
    invoke-direct {v3, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    throw v3

    .line 140
    :cond_7
    new-instance v3, Ljava/io/IOException;

    .line 141
    .line 142
    invoke-direct {v3, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    throw v3
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 146
    :catchall_3
    move-exception v2

    .line 147
    move-object v7, v2

    .line 148
    move-object v2, v0

    .line 149
    goto :goto_2

    .line 150
    :catch_2
    move-object v2, v0

    .line 151
    move-object v0, v1

    .line 152
    goto :goto_4

    .line 153
    :goto_3
    invoke-static {v1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 154
    .line 155
    .line 156
    if-eqz v2, :cond_8

    .line 157
    .line 158
    invoke-static {v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->f(Ljava/io/FileDescriptor;)V

    .line 159
    .line 160
    .line 161
    :cond_8
    throw v0

    .line 162
    :catch_3
    :goto_4
    invoke-static {v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->h(Ljava/io/Closeable;)V

    .line 163
    .line 164
    .line 165
    if-eqz v2, :cond_9

    .line 166
    .line 167
    invoke-static {v2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->f(Ljava/io/FileDescriptor;)V

    .line 168
    .line 169
    .line 170
    :cond_9
    :goto_5
    return-object v1
.end method

.method public final p(Lq0/b;)V
    .locals 5

    .line 1
    sget-boolean v0, Lq0/g;->t:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    :cond_0
    sget-object v0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 9
    .line 10
    iput-object v0, p1, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 11
    .line 12
    sget-object v0, Lq0/g;->I:[B

    .line 13
    .line 14
    array-length v0, v0

    .line 15
    invoke-virtual {p1, v0}, Lq0/b;->a(I)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p1}, Lq0/b;->readInt()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    add-int/lit8 v0, v0, 0x8

    .line 23
    .line 24
    sget-object v1, Lq0/g;->J:[B

    .line 25
    .line 26
    array-length v2, v1

    .line 27
    invoke-virtual {p1, v2}, Lq0/b;->a(I)V

    .line 28
    .line 29
    .line 30
    array-length v1, v1

    .line 31
    add-int/lit8 v1, v1, 0x8

    .line 32
    .line 33
    :goto_0
    const/4 v2, 0x4

    .line 34
    :try_start_0
    new-array v3, v2, [B

    .line 35
    .line 36
    invoke-virtual {p1, v3}, Ljava/io/InputStream;->read([B)I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    if-ne v4, v2, :cond_6

    .line 41
    .line 42
    invoke-virtual {p1}, Lq0/b;->readInt()I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    add-int/lit8 v1, v1, 0x8

    .line 47
    .line 48
    sget-object v4, Lq0/g;->K:[B

    .line 49
    .line 50
    invoke-static {v4, v3}, Ljava/util/Arrays;->equals([B[B)Z

    .line 51
    .line 52
    .line 53
    move-result v4

    .line 54
    if-eqz v4, :cond_2

    .line 55
    .line 56
    new-array v0, v2, [B

    .line 57
    .line 58
    invoke-virtual {p1, v0}, Ljava/io/InputStream;->read([B)I

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    if-ne p1, v2, :cond_1

    .line 63
    .line 64
    iput v1, p0, Lq0/g;->o:I

    .line 65
    .line 66
    const/4 p1, 0x0

    .line 67
    invoke-virtual {p0, p1, v0}, Lq0/g;->x(I[B)V

    .line 68
    .line 69
    .line 70
    new-instance p1, Lq0/b;

    .line 71
    .line 72
    invoke-direct {p1, v0}, Lq0/b;-><init>([B)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0, p1}, Lq0/g;->G(Lq0/b;)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :cond_1
    new-instance p1, Ljava/io/IOException;

    .line 80
    .line 81
    new-instance v0, Ljava/lang/StringBuilder;

    .line 82
    .line 83
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 84
    .line 85
    .line 86
    const-string v1, "Failed to read given length for given PNG chunk type: "

    .line 87
    .line 88
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    invoke-static {v3}, Lcom/palmpay/lib/apm/launchcounter/util/d;->c([B)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    throw p1

    .line 106
    :cond_2
    rem-int/lit8 v3, v2, 0x2

    .line 107
    .line 108
    const/4 v4, 0x1

    .line 109
    if-ne v3, v4, :cond_3

    .line 110
    .line 111
    add-int/lit8 v2, v2, 0x1

    .line 112
    .line 113
    :cond_3
    add-int/2addr v1, v2

    .line 114
    if-ne v1, v0, :cond_4

    .line 115
    .line 116
    return-void

    .line 117
    :cond_4
    if-gt v1, v0, :cond_5

    .line 118
    .line 119
    invoke-virtual {p1, v2}, Lq0/b;->a(I)V

    .line 120
    .line 121
    .line 122
    goto :goto_0

    .line 123
    :cond_5
    new-instance p1, Ljava/io/IOException;

    .line 124
    .line 125
    const-string v0, "Encountered WebP file with invalid chunk size"

    .line 126
    .line 127
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    throw p1

    .line 131
    :cond_6
    new-instance p1, Ljava/io/IOException;

    .line 132
    .line 133
    const-string v0, "Encountered invalid length while parsing WebP chunktype"

    .line 134
    .line 135
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    throw p1
    :try_end_0
    .catch Ljava/io/EOFException; {:try_start_0 .. :try_end_0} :catch_0

    .line 139
    :catch_0
    new-instance p1, Ljava/io/IOException;

    .line 140
    .line 141
    const-string v0, "Encountered corrupt WebP file."

    .line 142
    .line 143
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    throw p1
.end method

.method public final r(Lq0/b;Ljava/util/HashMap;)V
    .locals 4

    .line 1
    const-string v0, "JPEGInterchangeFormat"

    .line 2
    .line 3
    invoke-virtual {p2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lq0/c;

    .line 8
    .line 9
    const-string v1, "JPEGInterchangeFormatLength"

    .line 10
    .line 11
    invoke-virtual {p2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p2

    .line 15
    check-cast p2, Lq0/c;

    .line 16
    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    if-eqz p2, :cond_2

    .line 20
    .line 21
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 28
    .line 29
    invoke-virtual {p2, v1}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 30
    .line 31
    .line 32
    move-result p2

    .line 33
    iget v1, p0, Lq0/g;->d:I

    .line 34
    .line 35
    const/4 v2, 0x7

    .line 36
    if-ne v1, v2, :cond_0

    .line 37
    .line 38
    iget v1, p0, Lq0/g;->p:I

    .line 39
    .line 40
    add-int/2addr v0, v1

    .line 41
    :cond_0
    if-lez v0, :cond_2

    .line 42
    .line 43
    if-lez p2, :cond_2

    .line 44
    .line 45
    const/4 v1, 0x1

    .line 46
    iput-boolean v1, p0, Lq0/g;->h:Z

    .line 47
    .line 48
    iget-object v1, p0, Lq0/g;->a:Ljava/lang/String;

    .line 49
    .line 50
    if-nez v1, :cond_1

    .line 51
    .line 52
    iget-object v1, p0, Lq0/g;->c:Landroid/content/res/AssetManager$AssetInputStream;

    .line 53
    .line 54
    if-nez v1, :cond_1

    .line 55
    .line 56
    iget-object v1, p0, Lq0/g;->b:Ljava/io/FileDescriptor;

    .line 57
    .line 58
    if-nez v1, :cond_1

    .line 59
    .line 60
    new-array v1, p2, [B

    .line 61
    .line 62
    int-to-long v2, v0

    .line 63
    invoke-virtual {p1, v2, v3}, Ljava/io/InputStream;->skip(J)J

    .line 64
    .line 65
    .line 66
    invoke-virtual {p1, v1}, Ljava/io/InputStream;->read([B)I

    .line 67
    .line 68
    .line 69
    iput-object v1, p0, Lq0/g;->m:[B

    .line 70
    .line 71
    :cond_1
    iput v0, p0, Lq0/g;->k:I

    .line 72
    .line 73
    iput p2, p0, Lq0/g;->l:I

    .line 74
    .line 75
    :cond_2
    return-void
.end method

.method public final s(Ljava/util/HashMap;)Z
    .locals 2

    .line 1
    const-string v0, "ImageLength"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lq0/c;

    .line 8
    .line 9
    const-string v1, "ImageWidth"

    .line 10
    .line 11
    invoke-virtual {p1, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Lq0/c;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    if-eqz p1, :cond_0

    .line 20
    .line 21
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    iget-object v1, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 28
    .line 29
    invoke-virtual {p1, v1}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    const/16 v1, 0x200

    .line 34
    .line 35
    if-gt v0, v1, :cond_0

    .line 36
    .line 37
    if-gt p1, v1, :cond_0

    .line 38
    .line 39
    const/4 p1, 0x1

    .line 40
    return p1

    .line 41
    :cond_0
    const/4 p1, 0x0

    .line 42
    return p1
.end method

.method public final t(Ljava/io/InputStream;)V
    .locals 7

    .line 1
    sget-boolean v0, Lq0/g;->t:Z

    .line 2
    .line 3
    if-eqz p1, :cond_c

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    move v2, v1

    .line 7
    :goto_0
    :try_start_0
    sget-object v3, Lq0/g;->V:[[Lq0/d;

    .line 8
    .line 9
    array-length v3, v3

    .line 10
    if-ge v2, v3, :cond_0

    .line 11
    .line 12
    iget-object v3, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 13
    .line 14
    new-instance v4, Ljava/util/HashMap;

    .line 15
    .line 16
    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 17
    .line 18
    .line 19
    aput-object v4, v3, v2

    .line 20
    .line 21
    add-int/lit8 v2, v2, 0x1

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :catchall_0
    move-exception p1

    .line 25
    goto/16 :goto_4

    .line 26
    .line 27
    :cond_0
    new-instance v2, Ljava/io/BufferedInputStream;

    .line 28
    .line 29
    const/16 v3, 0x1388

    .line 30
    .line 31
    invoke-direct {v2, p1, v3}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;I)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p0, v2}, Lq0/g;->i(Ljava/io/BufferedInputStream;)I

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    iput p1, p0, Lq0/g;->d:I

    .line 39
    .line 40
    const/16 v3, 0xe

    .line 41
    .line 42
    const/16 v4, 0xd

    .line 43
    .line 44
    const/16 v5, 0x9

    .line 45
    .line 46
    const/4 v6, 0x4

    .line 47
    if-eq p1, v6, :cond_5

    .line 48
    .line 49
    if-eq p1, v5, :cond_5

    .line 50
    .line 51
    if-eq p1, v4, :cond_5

    .line 52
    .line 53
    if-ne p1, v3, :cond_1

    .line 54
    .line 55
    goto :goto_2

    .line 56
    :cond_1
    new-instance p1, Lq0/f;

    .line 57
    .line 58
    invoke-direct {p1, v2}, Lq0/f;-><init>(Ljava/io/InputStream;)V

    .line 59
    .line 60
    .line 61
    iget v1, p0, Lq0/g;->d:I

    .line 62
    .line 63
    const/16 v2, 0xc

    .line 64
    .line 65
    if-ne v1, v2, :cond_2

    .line 66
    .line 67
    invoke-virtual {p0, p1}, Lq0/g;->g(Lq0/f;)V

    .line 68
    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_2
    const/4 v2, 0x7

    .line 72
    if-ne v1, v2, :cond_3

    .line 73
    .line 74
    invoke-virtual {p0, p1}, Lq0/g;->j(Lq0/f;)V

    .line 75
    .line 76
    .line 77
    goto :goto_1

    .line 78
    :cond_3
    const/16 v2, 0xa

    .line 79
    .line 80
    if-ne v1, v2, :cond_4

    .line 81
    .line 82
    invoke-virtual {p0, p1}, Lq0/g;->n(Lq0/f;)V

    .line 83
    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_4
    invoke-virtual {p0, p1}, Lq0/g;->m(Lq0/f;)V

    .line 87
    .line 88
    .line 89
    :goto_1
    iget v1, p0, Lq0/g;->o:I

    .line 90
    .line 91
    int-to-long v1, v1

    .line 92
    invoke-virtual {p1, v1, v2}, Lq0/f;->b(J)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0, p1}, Lq0/g;->G(Lq0/b;)V

    .line 96
    .line 97
    .line 98
    goto :goto_3

    .line 99
    :cond_5
    :goto_2
    new-instance p1, Lq0/b;

    .line 100
    .line 101
    invoke-direct {p1, v2}, Lq0/b;-><init>(Ljava/io/InputStream;)V

    .line 102
    .line 103
    .line 104
    iget v2, p0, Lq0/g;->d:I

    .line 105
    .line 106
    if-ne v2, v6, :cond_6

    .line 107
    .line 108
    invoke-virtual {p0, p1, v1, v1}, Lq0/g;->h(Lq0/b;II)V

    .line 109
    .line 110
    .line 111
    goto :goto_3

    .line 112
    :cond_6
    if-ne v2, v4, :cond_7

    .line 113
    .line 114
    invoke-virtual {p0, p1}, Lq0/g;->k(Lq0/b;)V

    .line 115
    .line 116
    .line 117
    goto :goto_3

    .line 118
    :cond_7
    if-ne v2, v5, :cond_8

    .line 119
    .line 120
    invoke-virtual {p0, p1}, Lq0/g;->l(Lq0/b;)V

    .line 121
    .line 122
    .line 123
    goto :goto_3

    .line 124
    :cond_8
    if-ne v2, v3, :cond_9

    .line 125
    .line 126
    invoke-virtual {p0, p1}, Lq0/g;->p(Lq0/b;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 127
    .line 128
    .line 129
    :cond_9
    :goto_3
    invoke-virtual {p0}, Lq0/g;->a()V

    .line 130
    .line 131
    .line 132
    if-eqz v0, :cond_b

    .line 133
    .line 134
    invoke-virtual {p0}, Lq0/g;->v()V

    .line 135
    .line 136
    .line 137
    return-void

    .line 138
    :goto_4
    invoke-virtual {p0}, Lq0/g;->a()V

    .line 139
    .line 140
    .line 141
    if-eqz v0, :cond_a

    .line 142
    .line 143
    invoke-virtual {p0}, Lq0/g;->v()V

    .line 144
    .line 145
    .line 146
    :cond_a
    throw p1

    .line 147
    :catch_0
    invoke-virtual {p0}, Lq0/g;->a()V

    .line 148
    .line 149
    .line 150
    if-eqz v0, :cond_b

    .line 151
    .line 152
    invoke-virtual {p0}, Lq0/g;->v()V

    .line 153
    .line 154
    .line 155
    :cond_b
    return-void

    .line 156
    :cond_c
    new-instance p1, Ljava/lang/NullPointerException;

    .line 157
    .line 158
    const-string v0, "inputstream shouldn\'t be null"

    .line 159
    .line 160
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    throw p1
.end method

.method public final u(Lq0/f;)V
    .locals 3

    .line 1
    invoke-static {p1}, Lq0/g;->w(Lq0/b;)Ljava/nio/ByteOrder;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 6
    .line 7
    iput-object v0, p1, Lq0/b;->b:Ljava/nio/ByteOrder;

    .line 8
    .line 9
    invoke-virtual {p1}, Lq0/b;->readUnsignedShort()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    iget v1, p0, Lq0/g;->d:I

    .line 14
    .line 15
    const/4 v2, 0x7

    .line 16
    if-eq v1, v2, :cond_1

    .line 17
    .line 18
    const/16 v2, 0xa

    .line 19
    .line 20
    if-eq v1, v2, :cond_1

    .line 21
    .line 22
    const/16 v1, 0x2a

    .line 23
    .line 24
    if-ne v0, v1, :cond_0

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    new-instance p1, Ljava/io/IOException;

    .line 28
    .line 29
    new-instance v1, Ljava/lang/StringBuilder;

    .line 30
    .line 31
    const-string v2, "Invalid start code: "

    .line 32
    .line 33
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw p1

    .line 51
    :cond_1
    :goto_0
    invoke-virtual {p1}, Lq0/b;->readInt()I

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    const/16 v1, 0x8

    .line 56
    .line 57
    if-lt v0, v1, :cond_3

    .line 58
    .line 59
    add-int/lit8 v0, v0, -0x8

    .line 60
    .line 61
    if-lez v0, :cond_2

    .line 62
    .line 63
    invoke-virtual {p1, v0}, Lq0/b;->a(I)V

    .line 64
    .line 65
    .line 66
    :cond_2
    return-void

    .line 67
    :cond_3
    new-instance p1, Ljava/io/IOException;

    .line 68
    .line 69
    const-string v1, "Invalid first Ifd offset: "

    .line 70
    .line 71
    invoke-static {v0, v1}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    throw p1
.end method

.method public final v()V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 3
    .line 4
    array-length v2, v1

    .line 5
    if-ge v0, v2, :cond_1

    .line 6
    .line 7
    aget-object v2, v1, v0

    .line 8
    .line 9
    invoke-virtual {v2}, Ljava/util/HashMap;->size()I

    .line 10
    .line 11
    .line 12
    aget-object v1, v1, v0

    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-eqz v2, :cond_0

    .line 27
    .line 28
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    check-cast v2, Ljava/util/Map$Entry;

    .line 33
    .line 34
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    check-cast v3, Lq0/c;

    .line 39
    .line 40
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    check-cast v2, Ljava/lang/String;

    .line 45
    .line 46
    invoke-virtual {v3}, Lq0/c;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    iget-object v2, p0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 50
    .line 51
    invoke-virtual {v3, v2}, Lq0/c;->i(Ljava/nio/ByteOrder;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    return-void
.end method

.method public final x(I[B)V
    .locals 1

    .line 1
    new-instance v0, Lq0/f;

    .line 2
    .line 3
    invoke-direct {v0, p2}, Lq0/f;-><init>([B)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lq0/g;->u(Lq0/f;)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, v0, p1}, Lq0/g;->y(Lq0/f;I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final y(Lq0/f;I)V
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move/from16 v2, p2

    .line 6
    .line 7
    iget v3, v1, Lq0/b;->c:I

    .line 8
    .line 9
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object v3

    .line 13
    iget-object v4, v0, Lq0/g;->f:Ljava/util/HashSet;

    .line 14
    .line 15
    invoke-virtual {v4, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1}, Lq0/b;->readShort()S

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    if-gtz v3, :cond_0

    .line 23
    .line 24
    goto/16 :goto_12

    .line 25
    .line 26
    :cond_0
    const/4 v6, 0x0

    .line 27
    :goto_0
    iget-object v7, v0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 28
    .line 29
    sget-boolean v8, Lq0/g;->t:Z

    .line 30
    .line 31
    if-ge v6, v3, :cond_24

    .line 32
    .line 33
    invoke-virtual {v1}, Lq0/b;->readUnsignedShort()I

    .line 34
    .line 35
    .line 36
    move-result v12

    .line 37
    invoke-virtual {v1}, Lq0/b;->readUnsignedShort()I

    .line 38
    .line 39
    .line 40
    move-result v13

    .line 41
    invoke-virtual {v1}, Lq0/b;->readInt()I

    .line 42
    .line 43
    .line 44
    move-result v14

    .line 45
    iget v15, v1, Lq0/b;->c:I

    .line 46
    .line 47
    move/from16 v20, v6

    .line 48
    .line 49
    int-to-long v5, v15

    .line 50
    const-wide/16 v15, 0x4

    .line 51
    .line 52
    add-long/2addr v5, v15

    .line 53
    sget-object v17, Lq0/g;->X:[Ljava/util/HashMap;

    .line 54
    .line 55
    const-wide/16 v18, 0x0

    .line 56
    .line 57
    aget-object v9, v17, v2

    .line 58
    .line 59
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 60
    .line 61
    .line 62
    move-result-object v10

    .line 63
    invoke-virtual {v9, v10}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v9

    .line 67
    check-cast v9, Lq0/d;

    .line 68
    .line 69
    if-eqz v8, :cond_2

    .line 70
    .line 71
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 72
    .line 73
    .line 74
    move-result-object v10

    .line 75
    move-wide/from16 v21, v15

    .line 76
    .line 77
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 78
    .line 79
    .line 80
    move-result-object v15

    .line 81
    if-eqz v9, :cond_1

    .line 82
    .line 83
    iget-object v11, v9, Lq0/d;->b:Ljava/lang/String;

    .line 84
    .line 85
    :goto_1
    move/from16 v23, v3

    .line 86
    .line 87
    goto :goto_2

    .line 88
    :cond_1
    const/4 v11, 0x0

    .line 89
    goto :goto_1

    .line 90
    :goto_2
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 91
    .line 92
    .line 93
    move-result-object v3

    .line 94
    move-object/from16 v24, v7

    .line 95
    .line 96
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 97
    .line 98
    .line 99
    move-result-object v7

    .line 100
    filled-new-array {v10, v15, v11, v3, v7}, [Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v3

    .line 104
    const-string v7, "ifdType: %d, tagNumber: %d, tagName: %s, dataFormat: %d, numberOfComponents: %d"

    .line 105
    .line 106
    invoke-static {v7, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    goto :goto_3

    .line 110
    :cond_2
    move/from16 v23, v3

    .line 111
    .line 112
    move-object/from16 v24, v7

    .line 113
    .line 114
    move-wide/from16 v21, v15

    .line 115
    .line 116
    :goto_3
    const/4 v10, 0x3

    .line 117
    const/4 v11, 0x7

    .line 118
    if-nez v9, :cond_4

    .line 119
    .line 120
    :cond_3
    :goto_4
    move-object/from16 v25, v4

    .line 121
    .line 122
    goto/16 :goto_a

    .line 123
    .line 124
    :cond_4
    if-lez v13, :cond_3

    .line 125
    .line 126
    sget-object v15, Lq0/g;->S:[I

    .line 127
    .line 128
    array-length v7, v15

    .line 129
    if-lt v13, v7, :cond_5

    .line 130
    .line 131
    goto :goto_4

    .line 132
    :cond_5
    iget v7, v9, Lq0/d;->c:I

    .line 133
    .line 134
    if-eq v7, v11, :cond_a

    .line 135
    .line 136
    if-ne v13, v11, :cond_6

    .line 137
    .line 138
    goto :goto_6

    .line 139
    :cond_6
    if-eq v7, v13, :cond_a

    .line 140
    .line 141
    iget v11, v9, Lq0/d;->d:I

    .line 142
    .line 143
    if-ne v11, v13, :cond_7

    .line 144
    .line 145
    goto :goto_6

    .line 146
    :cond_7
    const/4 v3, 0x4

    .line 147
    if-eq v7, v3, :cond_9

    .line 148
    .line 149
    if-ne v11, v3, :cond_8

    .line 150
    .line 151
    goto :goto_5

    .line 152
    :cond_8
    const/16 v3, 0x9

    .line 153
    .line 154
    goto :goto_7

    .line 155
    :cond_9
    :goto_5
    if-ne v13, v10, :cond_8

    .line 156
    .line 157
    :cond_a
    :goto_6
    const/4 v3, 0x7

    .line 158
    goto :goto_8

    .line 159
    :goto_7
    if-eq v7, v3, :cond_b

    .line 160
    .line 161
    if-ne v11, v3, :cond_c

    .line 162
    .line 163
    :cond_b
    const/16 v3, 0x8

    .line 164
    .line 165
    if-ne v13, v3, :cond_c

    .line 166
    .line 167
    goto :goto_6

    .line 168
    :cond_c
    const/16 v3, 0xc

    .line 169
    .line 170
    if-eq v7, v3, :cond_d

    .line 171
    .line 172
    if-ne v11, v3, :cond_e

    .line 173
    .line 174
    :cond_d
    const/16 v3, 0xb

    .line 175
    .line 176
    if-ne v13, v3, :cond_e

    .line 177
    .line 178
    goto :goto_6

    .line 179
    :cond_e
    if-eqz v8, :cond_3

    .line 180
    .line 181
    sget-object v3, Lq0/g;->R:[Ljava/lang/String;

    .line 182
    .line 183
    aget-object v3, v3, v13

    .line 184
    .line 185
    goto :goto_4

    .line 186
    :goto_8
    if-ne v13, v3, :cond_f

    .line 187
    .line 188
    move v13, v7

    .line 189
    :cond_f
    int-to-long v10, v14

    .line 190
    aget v7, v15, v13

    .line 191
    .line 192
    move-object/from16 v25, v4

    .line 193
    .line 194
    int-to-long v3, v7

    .line 195
    mul-long/2addr v10, v3

    .line 196
    cmp-long v3, v10, v18

    .line 197
    .line 198
    if-ltz v3, :cond_11

    .line 199
    .line 200
    const-wide/32 v3, 0x7fffffff

    .line 201
    .line 202
    .line 203
    cmp-long v3, v10, v3

    .line 204
    .line 205
    if-lez v3, :cond_10

    .line 206
    .line 207
    goto :goto_9

    .line 208
    :cond_10
    const/4 v3, 0x1

    .line 209
    goto :goto_b

    .line 210
    :cond_11
    :goto_9
    const/4 v3, 0x0

    .line 211
    goto :goto_b

    .line 212
    :goto_a
    move-wide/from16 v10, v18

    .line 213
    .line 214
    goto :goto_9

    .line 215
    :goto_b
    if-nez v3, :cond_12

    .line 216
    .line 217
    invoke-virtual {v1, v5, v6}, Lq0/f;->b(J)V

    .line 218
    .line 219
    .line 220
    move-object/from16 v8, v25

    .line 221
    .line 222
    goto/16 :goto_11

    .line 223
    .line 224
    :cond_12
    cmp-long v3, v10, v21

    .line 225
    .line 226
    const-string v4, "Compression"

    .line 227
    .line 228
    if-lez v3, :cond_15

    .line 229
    .line 230
    invoke-virtual {v1}, Lq0/b;->readInt()I

    .line 231
    .line 232
    .line 233
    move-result v3

    .line 234
    iget v7, v0, Lq0/g;->d:I

    .line 235
    .line 236
    const/4 v15, 0x7

    .line 237
    if-ne v7, v15, :cond_13

    .line 238
    .line 239
    iget-object v7, v9, Lq0/d;->b:Ljava/lang/String;

    .line 240
    .line 241
    const-string v15, "MakerNote"

    .line 242
    .line 243
    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 244
    .line 245
    .line 246
    move-result v7

    .line 247
    if-eqz v7, :cond_14

    .line 248
    .line 249
    iput v3, v0, Lq0/g;->p:I

    .line 250
    .line 251
    :cond_13
    move/from16 v22, v8

    .line 252
    .line 253
    move/from16 v17, v14

    .line 254
    .line 255
    goto :goto_c

    .line 256
    :cond_14
    const/4 v7, 0x6

    .line 257
    if-ne v2, v7, :cond_13

    .line 258
    .line 259
    iget-object v15, v9, Lq0/d;->b:Ljava/lang/String;

    .line 260
    .line 261
    const-string v7, "ThumbnailImage"

    .line 262
    .line 263
    invoke-virtual {v7, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    move-result v7

    .line 267
    if-eqz v7, :cond_13

    .line 268
    .line 269
    iput v3, v0, Lq0/g;->q:I

    .line 270
    .line 271
    iput v14, v0, Lq0/g;->r:I

    .line 272
    .line 273
    iget-object v7, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 274
    .line 275
    const/4 v15, 0x6

    .line 276
    invoke-static {v15, v7}, Lq0/c;->e(ILjava/nio/ByteOrder;)Lq0/c;

    .line 277
    .line 278
    .line 279
    move-result-object v7

    .line 280
    iget v15, v0, Lq0/g;->q:I

    .line 281
    .line 282
    move/from16 v17, v14

    .line 283
    .line 284
    int-to-long v14, v15

    .line 285
    iget-object v2, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 286
    .line 287
    invoke-static {v14, v15, v2}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 288
    .line 289
    .line 290
    move-result-object v2

    .line 291
    iget v14, v0, Lq0/g;->r:I

    .line 292
    .line 293
    int-to-long v14, v14

    .line 294
    move/from16 v22, v8

    .line 295
    .line 296
    iget-object v8, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 297
    .line 298
    invoke-static {v14, v15, v8}, Lq0/c;->b(JLjava/nio/ByteOrder;)Lq0/c;

    .line 299
    .line 300
    .line 301
    move-result-object v8

    .line 302
    const/16 v16, 0x4

    .line 303
    .line 304
    aget-object v14, v24, v16

    .line 305
    .line 306
    invoke-virtual {v14, v4, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    aget-object v7, v24, v16

    .line 310
    .line 311
    const-string v14, "JPEGInterchangeFormat"

    .line 312
    .line 313
    invoke-virtual {v7, v14, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 314
    .line 315
    .line 316
    aget-object v2, v24, v16

    .line 317
    .line 318
    const-string v7, "JPEGInterchangeFormatLength"

    .line 319
    .line 320
    invoke-virtual {v2, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    :goto_c
    int-to-long v2, v3

    .line 324
    invoke-virtual {v1, v2, v3}, Lq0/f;->b(J)V

    .line 325
    .line 326
    .line 327
    goto :goto_d

    .line 328
    :cond_15
    move/from16 v22, v8

    .line 329
    .line 330
    move/from16 v17, v14

    .line 331
    .line 332
    :goto_d
    sget-object v2, Lq0/g;->a0:Ljava/util/HashMap;

    .line 333
    .line 334
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 335
    .line 336
    .line 337
    move-result-object v3

    .line 338
    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 339
    .line 340
    .line 341
    move-result-object v2

    .line 342
    check-cast v2, Ljava/lang/Integer;

    .line 343
    .line 344
    if-eqz v2, :cond_1d

    .line 345
    .line 346
    const/4 v3, 0x3

    .line 347
    if-eq v13, v3, :cond_19

    .line 348
    .line 349
    const/4 v3, 0x4

    .line 350
    if-eq v13, v3, :cond_18

    .line 351
    .line 352
    const/16 v3, 0x8

    .line 353
    .line 354
    if-eq v13, v3, :cond_17

    .line 355
    .line 356
    const/16 v3, 0x9

    .line 357
    .line 358
    if-eq v13, v3, :cond_16

    .line 359
    .line 360
    const/16 v3, 0xd

    .line 361
    .line 362
    if-eq v13, v3, :cond_16

    .line 363
    .line 364
    const-wide/16 v3, -0x1

    .line 365
    .line 366
    goto :goto_f

    .line 367
    :cond_16
    invoke-virtual {v1}, Lq0/b;->readInt()I

    .line 368
    .line 369
    .line 370
    move-result v3

    .line 371
    :goto_e
    int-to-long v3, v3

    .line 372
    goto :goto_f

    .line 373
    :cond_17
    invoke-virtual {v1}, Lq0/b;->readShort()S

    .line 374
    .line 375
    .line 376
    move-result v3

    .line 377
    goto :goto_e

    .line 378
    :cond_18
    invoke-virtual {v1}, Lq0/b;->readInt()I

    .line 379
    .line 380
    .line 381
    move-result v3

    .line 382
    int-to-long v3, v3

    .line 383
    const-wide v7, 0xffffffffL

    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    and-long/2addr v3, v7

    .line 389
    goto :goto_f

    .line 390
    :cond_19
    invoke-virtual {v1}, Lq0/b;->readUnsignedShort()I

    .line 391
    .line 392
    .line 393
    move-result v3

    .line 394
    goto :goto_e

    .line 395
    :goto_f
    if-eqz v22, :cond_1a

    .line 396
    .line 397
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 398
    .line 399
    .line 400
    move-result-object v7

    .line 401
    iget-object v8, v9, Lq0/d;->b:Ljava/lang/String;

    .line 402
    .line 403
    filled-new-array {v7, v8}, [Ljava/lang/Object;

    .line 404
    .line 405
    .line 406
    move-result-object v7

    .line 407
    const-string v8, "Offset: %d, tagName: %s"

    .line 408
    .line 409
    invoke-static {v8, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 410
    .line 411
    .line 412
    :cond_1a
    cmp-long v7, v3, v18

    .line 413
    .line 414
    if-lez v7, :cond_1b

    .line 415
    .line 416
    long-to-int v7, v3

    .line 417
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 418
    .line 419
    .line 420
    move-result-object v7

    .line 421
    move-object/from16 v8, v25

    .line 422
    .line 423
    invoke-virtual {v8, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 424
    .line 425
    .line 426
    move-result v7

    .line 427
    if-nez v7, :cond_1c

    .line 428
    .line 429
    invoke-virtual {v1, v3, v4}, Lq0/f;->b(J)V

    .line 430
    .line 431
    .line 432
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 433
    .line 434
    .line 435
    move-result v2

    .line 436
    invoke-virtual {v0, v1, v2}, Lq0/g;->y(Lq0/f;I)V

    .line 437
    .line 438
    .line 439
    goto :goto_10

    .line 440
    :cond_1b
    move-object/from16 v8, v25

    .line 441
    .line 442
    :cond_1c
    :goto_10
    invoke-virtual {v1, v5, v6}, Lq0/f;->b(J)V

    .line 443
    .line 444
    .line 445
    goto :goto_11

    .line 446
    :cond_1d
    move-object/from16 v8, v25

    .line 447
    .line 448
    iget v2, v1, Lq0/b;->c:I

    .line 449
    .line 450
    iget v7, v0, Lq0/g;->o:I

    .line 451
    .line 452
    add-int/2addr v2, v7

    .line 453
    long-to-int v7, v10

    .line 454
    new-array v7, v7, [B

    .line 455
    .line 456
    invoke-virtual {v1, v7}, Lq0/b;->readFully([B)V

    .line 457
    .line 458
    .line 459
    new-instance v14, Lq0/c;

    .line 460
    .line 461
    int-to-long v10, v2

    .line 462
    move-wide v15, v10

    .line 463
    move/from16 v18, v13

    .line 464
    .line 465
    move/from16 v19, v17

    .line 466
    .line 467
    move-object/from16 v17, v7

    .line 468
    .line 469
    invoke-direct/range {v14 .. v19}, Lq0/c;-><init>(J[BII)V

    .line 470
    .line 471
    .line 472
    aget-object v2, v24, p2

    .line 473
    .line 474
    iget-object v7, v9, Lq0/d;->b:Ljava/lang/String;

    .line 475
    .line 476
    invoke-virtual {v2, v7, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    iget-object v2, v9, Lq0/d;->b:Ljava/lang/String;

    .line 480
    .line 481
    const-string v7, "DNGVersion"

    .line 482
    .line 483
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 484
    .line 485
    .line 486
    move-result v7

    .line 487
    if-eqz v7, :cond_1e

    .line 488
    .line 489
    const/4 v3, 0x3

    .line 490
    iput v3, v0, Lq0/g;->d:I

    .line 491
    .line 492
    :cond_1e
    const-string v3, "Make"

    .line 493
    .line 494
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 495
    .line 496
    .line 497
    move-result v3

    .line 498
    if-nez v3, :cond_1f

    .line 499
    .line 500
    const-string v3, "Model"

    .line 501
    .line 502
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 503
    .line 504
    .line 505
    move-result v3

    .line 506
    if-eqz v3, :cond_20

    .line 507
    .line 508
    :cond_1f
    iget-object v3, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 509
    .line 510
    invoke-virtual {v14, v3}, Lq0/c;->i(Ljava/nio/ByteOrder;)Ljava/lang/String;

    .line 511
    .line 512
    .line 513
    move-result-object v3

    .line 514
    const-string v7, "PENTAX"

    .line 515
    .line 516
    invoke-virtual {v3, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 517
    .line 518
    .line 519
    move-result v3

    .line 520
    if-nez v3, :cond_21

    .line 521
    .line 522
    :cond_20
    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 523
    .line 524
    .line 525
    move-result v2

    .line 526
    if-eqz v2, :cond_22

    .line 527
    .line 528
    iget-object v2, v0, Lq0/g;->g:Ljava/nio/ByteOrder;

    .line 529
    .line 530
    invoke-virtual {v14, v2}, Lq0/c;->h(Ljava/nio/ByteOrder;)I

    .line 531
    .line 532
    .line 533
    move-result v2

    .line 534
    const v3, 0xffff

    .line 535
    .line 536
    .line 537
    if-ne v2, v3, :cond_22

    .line 538
    .line 539
    :cond_21
    const/16 v3, 0x8

    .line 540
    .line 541
    iput v3, v0, Lq0/g;->d:I

    .line 542
    .line 543
    :cond_22
    iget v2, v1, Lq0/b;->c:I

    .line 544
    .line 545
    int-to-long v2, v2

    .line 546
    cmp-long v2, v2, v5

    .line 547
    .line 548
    if-eqz v2, :cond_23

    .line 549
    .line 550
    invoke-virtual {v1, v5, v6}, Lq0/f;->b(J)V

    .line 551
    .line 552
    .line 553
    :cond_23
    :goto_11
    add-int/lit8 v6, v20, 0x1

    .line 554
    .line 555
    int-to-short v6, v6

    .line 556
    move/from16 v2, p2

    .line 557
    .line 558
    move-object v4, v8

    .line 559
    move/from16 v3, v23

    .line 560
    .line 561
    goto/16 :goto_0

    .line 562
    .line 563
    :cond_24
    move-object/from16 v24, v7

    .line 564
    .line 565
    move/from16 v22, v8

    .line 566
    .line 567
    const-wide/16 v18, 0x0

    .line 568
    .line 569
    move-object v8, v4

    .line 570
    invoke-virtual {v1}, Lq0/b;->readInt()I

    .line 571
    .line 572
    .line 573
    move-result v2

    .line 574
    if-eqz v22, :cond_25

    .line 575
    .line 576
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 577
    .line 578
    .line 579
    move-result-object v3

    .line 580
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 581
    .line 582
    .line 583
    move-result-object v3

    .line 584
    const-string v4, "nextIfdOffset: %d"

    .line 585
    .line 586
    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 587
    .line 588
    .line 589
    :cond_25
    int-to-long v3, v2

    .line 590
    cmp-long v5, v3, v18

    .line 591
    .line 592
    if-lez v5, :cond_27

    .line 593
    .line 594
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 595
    .line 596
    .line 597
    move-result-object v2

    .line 598
    invoke-virtual {v8, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 599
    .line 600
    .line 601
    move-result v2

    .line 602
    if-nez v2, :cond_27

    .line 603
    .line 604
    invoke-virtual {v1, v3, v4}, Lq0/f;->b(J)V

    .line 605
    .line 606
    .line 607
    const/4 v3, 0x4

    .line 608
    aget-object v2, v24, v3

    .line 609
    .line 610
    invoke-virtual {v2}, Ljava/util/HashMap;->isEmpty()Z

    .line 611
    .line 612
    .line 613
    move-result v2

    .line 614
    if-eqz v2, :cond_26

    .line 615
    .line 616
    invoke-virtual {v0, v1, v3}, Lq0/g;->y(Lq0/f;I)V

    .line 617
    .line 618
    .line 619
    return-void

    .line 620
    :cond_26
    const/4 v2, 0x5

    .line 621
    aget-object v3, v24, v2

    .line 622
    .line 623
    invoke-virtual {v3}, Ljava/util/HashMap;->isEmpty()Z

    .line 624
    .line 625
    .line 626
    move-result v3

    .line 627
    if-eqz v3, :cond_27

    .line 628
    .line 629
    invoke-virtual {v0, v1, v2}, Lq0/g;->y(Lq0/f;I)V

    .line 630
    .line 631
    .line 632
    :cond_27
    :goto_12
    return-void
.end method

.method public final z(Ljava/lang/String;)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    sget-object v1, Lq0/g;->V:[[Lq0/d;

    .line 3
    .line 4
    array-length v1, v1

    .line 5
    if-ge v0, v1, :cond_0

    .line 6
    .line 7
    iget-object v1, p0, Lq0/g;->e:[Ljava/util/HashMap;

    .line 8
    .line 9
    aget-object v1, v1, v0

    .line 10
    .line 11
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    add-int/lit8 v0, v0, 0x1

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    return-void
.end method
