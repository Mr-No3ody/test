.class public final LO2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/fresco/animation/bitmap/BitmapFrameRenderer;
.implements Lokhttp3/Callback;
.implements Landroidx/work/impl/model/SystemIdInfoDao;
.implements Landroidx/work/impl/model/WorkProgressDao;
.implements Lkotlinx/coroutines/selects/SelectClause2;
.implements Landroidx/appcompat/view/ActionMode$Callback;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/graphics/Typeface;Landroidx/emoji2/text/flatbuffer/b;)V
    .locals 6

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 36
    iput-object p1, p0, LO2/a;->d:Ljava/lang/Object;

    .line 37
    iput-object p2, p0, LO2/a;->a:Ljava/lang/Object;

    .line 38
    new-instance p1, Landroidx/emoji2/text/t;

    const/16 v0, 0x400

    invoke-direct {p1, v0}, Landroidx/emoji2/text/t;-><init>(I)V

    iput-object p1, p0, LO2/a;->c:Ljava/lang/Object;

    const/4 p1, 0x6

    .line 39
    invoke-virtual {p2, p1}, LAf/h;->a(I)I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 40
    iget v2, p2, LAf/h;->a:I

    add-int/2addr v0, v2

    .line 41
    iget-object v2, p2, LAf/h;->d:Ljava/lang/Object;

    check-cast v2, Ljava/nio/ByteBuffer;

    invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v2

    add-int/2addr v2, v0

    .line 42
    iget-object v0, p2, LAf/h;->d:Ljava/lang/Object;

    check-cast v0, Ljava/nio/ByteBuffer;

    invoke-virtual {v0, v2}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v0

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    mul-int/lit8 v0, v0, 0x2

    .line 43
    new-array v0, v0, [C

    iput-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    .line 44
    invoke-virtual {p2, p1}, LAf/h;->a(I)I

    move-result p1

    if-eqz p1, :cond_1

    .line 45
    iget v0, p2, LAf/h;->a:I

    add-int/2addr p1, v0

    .line 46
    iget-object v0, p2, LAf/h;->d:Ljava/lang/Object;

    check-cast v0, Ljava/nio/ByteBuffer;

    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v0

    add-int/2addr v0, p1

    .line 47
    iget-object p1, p2, LAf/h;->d:Ljava/lang/Object;

    check-cast p1, Ljava/nio/ByteBuffer;

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result p1

    goto :goto_1

    :cond_1
    move p1, v1

    :goto_1
    move p2, v1

    :goto_2
    if-ge p2, p1, :cond_6

    .line 48
    new-instance v0, Landroidx/emoji2/text/w;

    invoke-direct {v0, p0, p2}, Landroidx/emoji2/text/w;-><init>(LO2/a;I)V

    .line 49
    invoke-virtual {v0}, Landroidx/emoji2/text/w;->b()Landroidx/emoji2/text/flatbuffer/a;

    move-result-object v2

    const/4 v3, 0x4

    .line 50
    invoke-virtual {v2, v3}, LAf/h;->a(I)I

    move-result v3

    if-eqz v3, :cond_2

    iget-object v4, v2, LAf/h;->d:Ljava/lang/Object;

    check-cast v4, Ljava/nio/ByteBuffer;

    iget v2, v2, LAf/h;->a:I

    add-int/2addr v3, v2

    invoke-virtual {v4, v3}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v2

    goto :goto_3

    :cond_2
    move v2, v1

    :goto_3
    mul-int/lit8 v3, p2, 0x2

    .line 51
    iget-object v4, p0, LO2/a;->b:Ljava/lang/Object;

    check-cast v4, [C

    invoke-static {v2, v4, v3}, Ljava/lang/Character;->toChars(I[CI)I

    .line 52
    invoke-virtual {v0}, Landroidx/emoji2/text/w;->b()Landroidx/emoji2/text/flatbuffer/a;

    move-result-object v2

    const/16 v3, 0x10

    .line 53
    invoke-virtual {v2, v3}, LAf/h;->a(I)I

    move-result v4

    if-eqz v4, :cond_3

    .line 54
    iget v5, v2, LAf/h;->a:I

    add-int/2addr v4, v5

    .line 55
    iget-object v5, v2, LAf/h;->d:Ljava/lang/Object;

    check-cast v5, Ljava/nio/ByteBuffer;

    invoke-virtual {v5, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v5

    add-int/2addr v5, v4

    .line 56
    iget-object v2, v2, LAf/h;->d:Ljava/lang/Object;

    check-cast v2, Ljava/nio/ByteBuffer;

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v2

    goto :goto_4

    :cond_3
    move v2, v1

    :goto_4
    const/4 v4, 0x1

    if-lez v2, :cond_4

    move v2, v4

    goto :goto_5

    :cond_4
    move v2, v1

    .line 57
    :goto_5
    const-string v5, "invalid metadata codepoint length"

    invoke-static {v2, v5}, Lhf/a;->g(ZLjava/lang/String;)V

    .line 58
    invoke-virtual {v0}, Landroidx/emoji2/text/w;->b()Landroidx/emoji2/text/flatbuffer/a;

    move-result-object v2

    .line 59
    invoke-virtual {v2, v3}, LAf/h;->a(I)I

    move-result v3

    if-eqz v3, :cond_5

    .line 60
    iget v5, v2, LAf/h;->a:I

    add-int/2addr v3, v5

    .line 61
    iget-object v5, v2, LAf/h;->d:Ljava/lang/Object;

    check-cast v5, Ljava/nio/ByteBuffer;

    invoke-virtual {v5, v3}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v5

    add-int/2addr v5, v3

    .line 62
    iget-object v2, v2, LAf/h;->d:Ljava/lang/Object;

    check-cast v2, Ljava/nio/ByteBuffer;

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v2

    goto :goto_6

    :cond_5
    move v2, v1

    :goto_6
    sub-int/2addr v2, v4

    .line 63
    iget-object v3, p0, LO2/a;->c:Ljava/lang/Object;

    check-cast v3, Landroidx/emoji2/text/t;

    invoke-virtual {v3, v0, v1, v2}, Landroidx/emoji2/text/t;->a(Landroidx/emoji2/text/w;II)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_2

    :cond_6
    return-void
.end method

.method public constructor <init>(Landroid/view/View;I)V
    .locals 1

    packed-switch p2, :pswitch_data_0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LO2/a;->a:Ljava/lang/Object;

    const/4 p2, 0x0

    if-eqz p1, :cond_0

    .line 2
    sget v0, LAc/e;->ivLion:I

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/airbnb/lottie/LottieAnimationView;

    goto :goto_0

    :cond_0
    move-object v0, p2

    :goto_0
    iput-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    if-eqz p1, :cond_1

    .line 3
    sget v0, LAc/e;->cslTask:I

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    goto :goto_1

    :cond_1
    move-object v0, p2

    :goto_1
    iput-object v0, p0, LO2/a;->c:Ljava/lang/Object;

    if-eqz p1, :cond_2

    .line 4
    sget p2, LAc/e;->tvTask:I

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    move-object p2, p1

    check-cast p2, Landroid/widget/TextView;

    :cond_2
    iput-object p2, p0, LO2/a;->d:Ljava/lang/Object;

    return-void

    .line 5
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    const-string p2, "com.transsnet.palmpay.action.notification.common"

    iput-object p2, p0, LO2/a;->d:Ljava/lang/Object;

    const/4 p2, 0x0

    if-eqz p1, :cond_3

    .line 7
    sget v0, LAc/e;->ivIcon:I

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    goto :goto_2

    :cond_3
    move-object v0, p2

    :goto_2
    iput-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    if-eqz p1, :cond_4

    .line 8
    sget v0, LAc/e;->tvCount:I

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    goto :goto_3

    :cond_4
    move-object v0, p2

    :goto_3
    iput-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    if-eqz p1, :cond_5

    .line 9
    sget p2, LAc/e;->tvType:I

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    :cond_5
    iput-object p2, p0, LO2/a;->c:Ljava/lang/Object;

    if-eqz p1, :cond_6

    .line 10
    new-instance p2, Lld/o;

    const/4 v0, 0x7

    invoke-direct {p2, p0, v0}, Lld/o;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_6
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0xa
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Landroidx/work/impl/WorkDatabase_Impl;I)V
    .locals 1

    packed-switch p2, :pswitch_data_0

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    iput-object p1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 13
    new-instance p2, LTd/a;

    .line 14
    const-string v0, "database"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x3

    .line 15
    invoke-direct {p2, p1, v0}, LTd/a;-><init>(Landroidx/room/G;I)V

    .line 16
    iput-object p2, p0, LO2/a;->b:Ljava/lang/Object;

    .line 17
    new-instance p2, LTd/c;

    const/4 v0, 0x2

    .line 18
    invoke-direct {p2, p1, v0}, LTd/c;-><init>(Landroidx/room/G;I)V

    .line 19
    iput-object p2, p0, LO2/a;->c:Ljava/lang/Object;

    .line 20
    new-instance p2, LTd/c;

    const/4 v0, 0x3

    .line 21
    invoke-direct {p2, p1, v0}, LTd/c;-><init>(Landroidx/room/G;I)V

    .line 22
    iput-object p2, p0, LO2/a;->d:Ljava/lang/Object;

    return-void

    .line 23
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    iput-object p1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 25
    new-instance p2, LTd/a;

    .line 26
    const-string v0, "database"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x5

    .line 27
    invoke-direct {p2, p1, v0}, LTd/a;-><init>(Landroidx/room/G;I)V

    .line 28
    iput-object p2, p0, LO2/a;->b:Ljava/lang/Object;

    .line 29
    new-instance p2, LTd/c;

    const/4 v0, 0x4

    .line 30
    invoke-direct {p2, p1, v0}, LTd/c;-><init>(Landroidx/room/G;I)V

    .line 31
    iput-object p2, p0, LO2/a;->c:Ljava/lang/Object;

    .line 32
    new-instance p2, LTd/c;

    const/4 v0, 0x5

    .line 33
    invoke-direct {p2, p1, v0}, LTd/c;-><init>(Landroidx/room/G;I)V

    .line 34
    iput-object p2, p0, LO2/a;->d:Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Ljava/lang/Object;Lkotlin/jvm/functions/Function3;Lkotlin/jvm/functions/Function3;LUc/t0;)V
    .locals 0

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 65
    iput-object p1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 66
    check-cast p2, Lkotlin/jvm/internal/m;

    iput-object p2, p0, LO2/a;->b:Ljava/lang/Object;

    .line 67
    check-cast p3, Lkotlin/jvm/internal/m;

    iput-object p3, p0, LO2/a;->c:Ljava/lang/Object;

    .line 68
    iput-object p4, p0, LO2/a;->d:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public declared-synchronized a(Lcom/bumptech/glide/load/Key;Lcom/bumptech/glide/load/engine/s;)V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    new-instance v0, Lcom/bumptech/glide/load/engine/a;

    .line 3
    .line 4
    iget-object v1, p0, LO2/a;->c:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v1, Ljava/lang/ref/ReferenceQueue;

    .line 7
    .line 8
    invoke-direct {v0, p1, p2, v1}, Lcom/bumptech/glide/load/engine/a;-><init>(Lcom/bumptech/glide/load/Key;Lcom/bumptech/glide/load/engine/s;Ljava/lang/ref/ReferenceQueue;)V

    .line 9
    .line 10
    .line 11
    iget-object p2, p0, LO2/a;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p2, Ljava/util/HashMap;

    .line 14
    .line 15
    invoke-virtual {p2, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    check-cast p1, Lcom/bumptech/glide/load/engine/a;

    .line 20
    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    const/4 p2, 0x0

    .line 24
    iput-object p2, p1, Lcom/bumptech/glide/load/engine/a;->c:Lcom/bumptech/glide/load/engine/Resource;

    .line 25
    .line 26
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    .line 28
    .line 29
    :cond_0
    monitor-exit p0

    .line 30
    return-void

    .line 31
    :catchall_0
    move-exception p1

    .line 32
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 33
    throw p1
.end method

.method public b(Lcom/bumptech/glide/load/engine/a;)V
    .locals 7

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v0, Ljava/util/HashMap;

    .line 5
    .line 6
    iget-object v1, p1, Lcom/bumptech/glide/load/engine/a;->a:Lcom/bumptech/glide/load/Key;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    iget-boolean v0, p1, Lcom/bumptech/glide/load/engine/a;->b:Z

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    iget-object v2, p1, Lcom/bumptech/glide/load/engine/a;->c:Lcom/bumptech/glide/load/engine/Resource;

    .line 16
    .line 17
    if-nez v2, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    new-instance v1, Lcom/bumptech/glide/load/engine/s;

    .line 22
    .line 23
    iget-object v5, p1, Lcom/bumptech/glide/load/engine/a;->a:Lcom/bumptech/glide/load/Key;

    .line 24
    .line 25
    iget-object v0, p0, LO2/a;->d:Ljava/lang/Object;

    .line 26
    .line 27
    move-object v6, v0

    .line 28
    check-cast v6, Lcom/bumptech/glide/load/engine/m;

    .line 29
    .line 30
    const/4 v3, 0x1

    .line 31
    const/4 v4, 0x0

    .line 32
    invoke-direct/range {v1 .. v6}, Lcom/bumptech/glide/load/engine/s;-><init>(Lcom/bumptech/glide/load/engine/Resource;ZZLcom/bumptech/glide/load/Key;Lcom/bumptech/glide/load/engine/m;)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, LO2/a;->d:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v0, Lcom/bumptech/glide/load/engine/m;

    .line 38
    .line 39
    iget-object p1, p1, Lcom/bumptech/glide/load/engine/a;->a:Lcom/bumptech/glide/load/Key;

    .line 40
    .line 41
    invoke-virtual {v0, p1, v1}, Lcom/bumptech/glide/load/engine/m;->onResourceReleased(Lcom/bumptech/glide/load/Key;Lcom/bumptech/glide/load/engine/s;)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :catchall_0
    move-exception v0

    .line 46
    move-object p1, v0

    .line 47
    goto :goto_1

    .line 48
    :cond_1
    :goto_0
    :try_start_1
    monitor-exit p0

    .line 49
    return-void

    .line 50
    :goto_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 51
    throw p1
.end method

.method public c(LFf/c;)Ljava/lang/Object;
    .locals 6

    .line 1
    instance-of v0, p1, Lj0/j;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lj0/j;

    .line 7
    .line 8
    iget v1, v0, Lj0/j;->d:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lj0/j;->d:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lj0/j;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, Lj0/j;-><init>(LO2/a;LFf/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, Lj0/j;->b:Ljava/lang/Object;

    .line 26
    .line 27
    sget-object v1, LEf/a;->a:LEf/a;

    .line 28
    .line 29
    iget v2, v0, Lj0/j;->d:I

    .line 30
    .line 31
    const/4 v3, 0x2

    .line 32
    const/4 v4, 0x1

    .line 33
    if-eqz v2, :cond_3

    .line 34
    .line 35
    if-eq v2, v4, :cond_2

    .line 36
    .line 37
    if-ne v2, v3, :cond_1

    .line 38
    .line 39
    iget-object v0, v0, Lj0/j;->a:LO2/a;

    .line 40
    .line 41
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 46
    .line 47
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 48
    .line 49
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw p1

    .line 53
    :cond_2
    iget-object v0, v0, Lj0/j;->a:LO2/a;

    .line 54
    .line 55
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    goto :goto_4

    .line 59
    :cond_3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    iget-object p1, p0, LO2/a;->c:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast p1, Ljava/util/List;

    .line 65
    .line 66
    iget-object v2, p0, LO2/a;->d:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v2, Lj0/O;

    .line 69
    .line 70
    if-eqz p1, :cond_6

    .line 71
    .line 72
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 73
    .line 74
    .line 75
    move-result p1

    .line 76
    if-eqz p1, :cond_4

    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_4
    invoke-virtual {v2}, Lj0/O;->f()Landroidx/datastore/core/InterProcessCoordinator;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    new-instance v4, Lj0/m;

    .line 84
    .line 85
    const/4 v5, 0x0

    .line 86
    invoke-direct {v4, v2, p0, v5}, Lj0/m;-><init>(Lj0/O;LO2/a;Lkotlin/coroutines/Continuation;)V

    .line 87
    .line 88
    .line 89
    iput-object p0, v0, Lj0/j;->a:LO2/a;

    .line 90
    .line 91
    iput v3, v0, Lj0/j;->d:I

    .line 92
    .line 93
    invoke-interface {p1, v4, v0}, Landroidx/datastore/core/InterProcessCoordinator;->lock(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    if-ne p1, v1, :cond_5

    .line 98
    .line 99
    goto :goto_3

    .line 100
    :cond_5
    move-object v0, p0

    .line 101
    :goto_1
    check-cast p1, Lj0/b;

    .line 102
    .line 103
    goto :goto_5

    .line 104
    :cond_6
    :goto_2
    iput-object p0, v0, Lj0/j;->a:LO2/a;

    .line 105
    .line 106
    iput v4, v0, Lj0/j;->d:I

    .line 107
    .line 108
    const/4 p1, 0x0

    .line 109
    invoke-static {v2, p1, v0}, Lj0/O;->e(Lj0/O;ZLFf/c;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    if-ne p1, v1, :cond_7

    .line 114
    .line 115
    :goto_3
    return-object v1

    .line 116
    :cond_7
    move-object v0, p0

    .line 117
    :goto_4
    check-cast p1, Lj0/b;

    .line 118
    .line 119
    :goto_5
    iget-object v0, v0, LO2/a;->d:Ljava/lang/Object;

    .line 120
    .line 121
    check-cast v0, Lj0/O;

    .line 122
    .line 123
    iget-object v0, v0, Lj0/O;->h:LSd/b;

    .line 124
    .line 125
    invoke-virtual {v0, p1}, LSd/b;->e(Lj0/w0;)V

    .line 126
    .line 127
    .line 128
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 129
    .line 130
    return-object p1
.end method

.method public d(Lcom/transsnet/palmpay/main/export/bean/rsp/QuerySavingTaskModuleResp;)V
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-object v1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v1, Landroid/view/View;

    .line 5
    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    move v2, v0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v2, 0x0

    .line 13
    :goto_0
    invoke-static {v1, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 14
    .line 15
    .line 16
    :cond_1
    if-eqz p1, :cond_6

    .line 17
    .line 18
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    new-instance v2, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;

    .line 23
    .line 24
    const-string v3, "FinanceTab_AI_View"

    .line 25
    .line 26
    invoke-direct {v2, v3}, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    iget-object v3, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QuerySavingTaskModuleResp;->id:Ljava/lang/Integer;

    .line 30
    .line 31
    if-eqz v3, :cond_2

    .line 32
    .line 33
    invoke-virtual {v3}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    if-nez v3, :cond_3

    .line 38
    .line 39
    :cond_2
    const-string v3, ""

    .line 40
    .line 41
    :cond_3
    const-string v4, "element_name"

    .line 42
    .line 43
    invoke-virtual {v2, v4, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    check-cast v2, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;

    .line 48
    .line 49
    invoke-virtual {v1, v2}, LPa/n0;->u(Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, LO2/a;->d:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v1, Landroid/widget/TextView;

    .line 55
    .line 56
    if-eqz v1, :cond_4

    .line 57
    .line 58
    iget-object v2, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QuerySavingTaskModuleResp;->content:Ljava/lang/String;

    .line 59
    .line 60
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 61
    .line 62
    .line 63
    :cond_4
    iget-object v1, p0, LO2/a;->c:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 66
    .line 67
    if-eqz v1, :cond_5

    .line 68
    .line 69
    new-instance v2, LGb/T;

    .line 70
    .line 71
    const/4 v3, 0x7

    .line 72
    invoke-direct {v2, v3, p1, p0}, LGb/T;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 76
    .line 77
    .line 78
    :cond_5
    iget-object p1, p0, LO2/a;->b:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast p1, Lcom/airbnb/lottie/LottieAnimationView;

    .line 81
    .line 82
    if-eqz p1, :cond_6

    .line 83
    .line 84
    const/4 v1, -0x1

    .line 85
    invoke-virtual {p1, v1}, Lcom/airbnb/lottie/LottieAnimationView;->setRepeatCount(I)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p1, v0}, Lcom/airbnb/lottie/LottieAnimationView;->setRepeatMode(I)V

    .line 89
    .line 90
    .line 91
    sget v0, LAc/g;->main_saving_task_lion:I

    .line 92
    .line 93
    invoke-virtual {p1, v0}, Lcom/airbnb/lottie/LottieAnimationView;->setAnimation(I)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {p1}, Lcom/airbnb/lottie/LottieAnimationView;->e()V

    .line 97
    .line 98
    .line 99
    :cond_6
    return-void
.end method

.method public delete(Ljava/lang/String;)V
    .locals 4

    .line 1
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LO2/a;->c:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, LTd/c;

    .line 11
    .line 12
    invoke-virtual {v1}, Landroidx/room/P;->a()Landroidx/sqlite/db/SupportSQLiteStatement;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x1

    .line 17
    invoke-interface {v2, v3, p1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    :try_start_0
    invoke-virtual {v0}, Landroidx/room/G;->beginTransaction()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    .line 22
    .line 23
    :try_start_1
    invoke-interface {v2}, Landroidx/sqlite/db/SupportSQLiteStatement;->executeUpdateDelete()I

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0}, Landroidx/room/G;->setTransactionSuccessful()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 27
    .line 28
    .line 29
    :try_start_2
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1, v2}, Landroidx/room/P;->c(Landroidx/sqlite/db/SupportSQLiteStatement;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :catchall_0
    move-exception p1

    .line 37
    goto :goto_0

    .line 38
    :catchall_1
    move-exception p1

    .line 39
    :try_start_3
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V

    .line 40
    .line 41
    .line 42
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 43
    :goto_0
    invoke-virtual {v1, v2}, Landroidx/room/P;->c(Landroidx/sqlite/db/SupportSQLiteStatement;)V

    .line 44
    .line 45
    .line 46
    throw p1
.end method

.method public deleteAll()V
    .locals 4

    .line 1
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LO2/a;->d:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, LTd/c;

    .line 11
    .line 12
    invoke-virtual {v1}, Landroidx/room/P;->a()Landroidx/sqlite/db/SupportSQLiteStatement;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    :try_start_0
    invoke-virtual {v0}, Landroidx/room/G;->beginTransaction()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    .line 18
    .line 19
    :try_start_1
    invoke-interface {v2}, Landroidx/sqlite/db/SupportSQLiteStatement;->executeUpdateDelete()I

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0}, Landroidx/room/G;->setTransactionSuccessful()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 23
    .line 24
    .line 25
    :try_start_2
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1, v2}, Landroidx/room/P;->c(Landroidx/sqlite/db/SupportSQLiteStatement;)V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :catchall_0
    move-exception v0

    .line 33
    goto :goto_0

    .line 34
    :catchall_1
    move-exception v3

    .line 35
    :try_start_3
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V

    .line 36
    .line 37
    .line 38
    throw v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 39
    :goto_0
    invoke-virtual {v1, v2}, Landroidx/room/P;->c(Landroidx/sqlite/db/SupportSQLiteStatement;)V

    .line 40
    .line 41
    .line 42
    throw v0
.end method

.method public e(Lx/a;)Lx/c;
    .locals 5

    .line 1
    iget-object v0, p0, LO2/a;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    :goto_0
    if-ge v2, v1, :cond_1

    .line 11
    .line 12
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    check-cast v3, Lx/c;

    .line 17
    .line 18
    if-eqz v3, :cond_0

    .line 19
    .line 20
    iget-object v4, v3, Lx/c;->b:Lx/a;

    .line 21
    .line 22
    if-ne v4, p1, :cond_0

    .line 23
    .line 24
    return-object v3

    .line 25
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_1
    new-instance v1, Lx/c;

    .line 29
    .line 30
    iget-object v2, p0, LO2/a;->b:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v2, Landroid/content/Context;

    .line 33
    .line 34
    invoke-direct {v1, v2, p1}, Lx/c;-><init>(Landroid/content/Context;Lx/a;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    return-object v1
.end method

.method public f(I)[Landroid/util/Size;
    .locals 3

    .line 1
    iget-object v0, p0, LO2/a;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashMap;

    .line 4
    .line 5
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_1

    .line 14
    .line 15
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    check-cast v1, [Landroid/util/Size;

    .line 24
    .line 25
    if-nez v1, :cond_0

    .line 26
    .line 27
    const/4 p1, 0x0

    .line 28
    return-object p1

    .line 29
    :cond_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    check-cast p1, [Landroid/util/Size;

    .line 38
    .line 39
    invoke-virtual {p1}, [Landroid/util/Size;->clone()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    check-cast p1, [Landroid/util/Size;

    .line 44
    .line 45
    return-object p1

    .line 46
    :cond_1
    iget-object v1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v1, Landroidx/camera/camera2/internal/compat/n;

    .line 49
    .line 50
    iget-object v1, v1, Landroidx/camera/camera2/internal/compat/n;->a:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v1, Landroid/hardware/camera2/params/StreamConfigurationMap;

    .line 53
    .line 54
    invoke-virtual {v1, p1}, Landroid/hardware/camera2/params/StreamConfigurationMap;->getOutputSizes(I)[Landroid/util/Size;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    if-eqz v1, :cond_3

    .line 59
    .line 60
    array-length v2, v1

    .line 61
    if-nez v2, :cond_2

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_2
    iget-object v2, p0, LO2/a;->b:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v2, Lp1/d;

    .line 67
    .line 68
    invoke-virtual {v2, v1, p1}, Lp1/d;->a([Landroid/util/Size;I)[Landroid/util/Size;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    invoke-virtual {v0, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    invoke-virtual {v1}, [Landroid/util/Size;->clone()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    check-cast p1, [Landroid/util/Size;

    .line 84
    .line 85
    return-object p1

    .line 86
    :cond_3
    :goto_0
    const-string p1, "StreamConfigurationMapCompat"

    .line 87
    .line 88
    invoke-static {p1}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    return-object v1
.end method

.method public g(III)V
    .locals 1

    .line 1
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/widget/ImageView;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 8
    .line 9
    .line 10
    :cond_0
    iget-object p1, p0, LO2/a;->c:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p1, Landroid/widget/TextView;

    .line 13
    .line 14
    if-eqz p1, :cond_1

    .line 15
    .line 16
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(I)V

    .line 17
    .line 18
    .line 19
    :cond_1
    const/4 p1, 0x1

    .line 20
    if-eq p3, p1, :cond_3

    .line 21
    .line 22
    const/4 p1, 0x2

    .line 23
    if-eq p3, p1, :cond_2

    .line 24
    .line 25
    return-void

    .line 26
    :cond_2
    const-string p1, "com.transsnet.palmpay.action.notification.common"

    .line 27
    .line 28
    iput-object p1, p0, LO2/a;->d:Ljava/lang/Object;

    .line 29
    .line 30
    return-void

    .line 31
    :cond_3
    const-string p1, "com.transsnet.palmpay.action.notification.payment"

    .line 32
    .line 33
    iput-object p1, p0, LO2/a;->d:Ljava/lang/Object;

    .line 34
    .line 35
    return-void
.end method

.method public getClauseObject()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    .line 2
    .line 3
    return-object v0
.end method

.method public getIntrinsicHeight()I
    .locals 1

    .line 1
    iget-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;

    .line 4
    .line 5
    invoke-interface {v0}, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;->getHeight()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 1

    .line 1
    iget-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;

    .line 4
    .line 5
    invoke-interface {v0}, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;->getWidth()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public getOnCancellationConstructor()Lkotlin/jvm/functions/Function3;
    .locals 1

    .line 1
    iget-object v0, p0, LO2/a;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LUc/t0;

    .line 4
    .line 5
    return-object v0
.end method

.method public getProcessResFunc()Lkotlin/jvm/functions/Function3;
    .locals 1

    .line 1
    iget-object v0, p0, LO2/a;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lkotlin/jvm/internal/m;

    .line 4
    .line 5
    return-object v0
.end method

.method public getProgressForWorkSpecId(Ljava/lang/String;)LV0/n;
    .locals 4

    .line 1
    sget-object v0, Landroidx/room/L;->j:Landroidx/room/K;

    .line 2
    .line 3
    const-string v1, "SELECT progress FROM WorkProgress WHERE work_spec_id=?"

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    invoke-virtual {v0, v1, v2}, Landroidx/room/K;->acquire(Ljava/lang/String;I)Landroidx/room/L;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-virtual {v0, v2, p1}, Landroidx/room/L;->bindString(ILjava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p1, Landroidx/work/impl/WorkDatabase_Impl;

    .line 16
    .line 17
    invoke-virtual {p1}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-static {p1, v0, v1}, Lcom/facebook/imagepipeline/nativecode/b;->K(Landroidx/room/G;Landroidx/sqlite/db/SupportSQLiteQuery;Z)Landroid/database/Cursor;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    :try_start_0
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    const/4 v3, 0x0

    .line 30
    if-eqz v2, :cond_2

    .line 31
    .line 32
    invoke-interface {p1, v1}, Landroid/database/Cursor;->isNull(I)Z

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    if-eqz v2, :cond_0

    .line 37
    .line 38
    move-object v1, v3

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    :goto_0
    if-nez v1, :cond_1

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    sget-object v2, LV0/n;->b:LV0/l;

    .line 48
    .line 49
    invoke-virtual {v2, v1}, LV0/l;->fromByteArray([B)LV0/n;

    .line 50
    .line 51
    .line 52
    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 53
    goto :goto_1

    .line 54
    :catchall_0
    move-exception v1

    .line 55
    goto :goto_2

    .line 56
    :cond_2
    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0}, Landroidx/room/L;->release()V

    .line 60
    .line 61
    .line 62
    return-object v3

    .line 63
    :goto_2
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0}, Landroidx/room/L;->release()V

    .line 67
    .line 68
    .line 69
    throw v1
.end method

.method public getRegFunc()Lkotlin/jvm/functions/Function3;
    .locals 1

    .line 1
    iget-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lkotlin/jvm/internal/m;

    .line 4
    .line 5
    return-object v0
.end method

.method public getSystemIdInfo(Ljava/lang/String;I)Landroidx/work/impl/model/d;
    .locals 4

    .line 1
    sget-object v0, Landroidx/room/L;->j:Landroidx/room/K;

    .line 2
    .line 3
    const-string v1, "SELECT * FROM SystemIdInfo WHERE work_spec_id=? AND generation=?"

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    invoke-virtual {v0, v1, v2}, Landroidx/room/K;->acquire(Ljava/lang/String;I)Landroidx/room/L;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const/4 v1, 0x1

    .line 11
    invoke-virtual {v0, v1, p1}, Landroidx/room/L;->bindString(ILjava/lang/String;)V

    .line 12
    .line 13
    .line 14
    int-to-long p1, p2

    .line 15
    invoke-virtual {v0, v2, p1, p2}, Landroidx/room/L;->bindLong(IJ)V

    .line 16
    .line 17
    .line 18
    iget-object p1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p1, Landroidx/work/impl/WorkDatabase_Impl;

    .line 21
    .line 22
    invoke-virtual {p1}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 23
    .line 24
    .line 25
    const/4 p2, 0x0

    .line 26
    invoke-static {p1, v0, p2}, Lcom/facebook/imagepipeline/nativecode/b;->K(Landroidx/room/G;Landroidx/sqlite/db/SupportSQLiteQuery;Z)Landroid/database/Cursor;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    :try_start_0
    const-string/jumbo p2, "work_spec_id"

    .line 31
    .line 32
    .line 33
    invoke-static {p1, p2}, Landroidx/camera/core/impl/utils/executor/g;->k(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    const-string v1, "generation"

    .line 38
    .line 39
    invoke-static {p1, v1}, Landroidx/camera/core/impl/utils/executor/g;->k(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    const-string/jumbo v2, "system_id"

    .line 44
    .line 45
    .line 46
    invoke-static {p1, v2}, Landroidx/camera/core/impl/utils/executor/g;->k(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    if-eqz v3, :cond_0

    .line 55
    .line 56
    invoke-interface {p1, p2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p2

    .line 60
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    invoke-interface {p1, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    new-instance v3, Landroidx/work/impl/model/d;

    .line 69
    .line 70
    invoke-direct {v3, p2, v1, v2}, Landroidx/work/impl/model/d;-><init>(Ljava/lang/String;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 71
    .line 72
    .line 73
    goto :goto_0

    .line 74
    :catchall_0
    move-exception p2

    .line 75
    goto :goto_1

    .line 76
    :cond_0
    const/4 v3, 0x0

    .line 77
    :goto_0
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0}, Landroidx/room/L;->release()V

    .line 81
    .line 82
    .line 83
    return-object v3

    .line 84
    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0}, Landroidx/room/L;->release()V

    .line 88
    .line 89
    .line 90
    throw p2
.end method

.method public getWorkSpecIds()Ljava/util/List;
    .locals 5

    .line 1
    sget-object v0, Landroidx/room/L;->j:Landroidx/room/K;

    .line 2
    .line 3
    const-string v1, "SELECT DISTINCT work_spec_id FROM SystemIdInfo"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-virtual {v0, v1, v2}, Landroidx/room/K;->acquire(Ljava/lang/String;I)Landroidx/room/L;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-object v1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Landroidx/work/impl/WorkDatabase_Impl;

    .line 13
    .line 14
    invoke-virtual {v1}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 15
    .line 16
    .line 17
    invoke-static {v1, v0, v2}, Lcom/facebook/imagepipeline/nativecode/b;->K(Landroidx/room/G;Landroidx/sqlite/db/SupportSQLiteQuery;Z)Landroid/database/Cursor;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    :try_start_0
    new-instance v3, Ljava/util/ArrayList;

    .line 22
    .line 23
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 28
    .line 29
    .line 30
    :goto_0
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-eqz v4, :cond_0

    .line 35
    .line 36
    invoke-interface {v1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :catchall_0
    move-exception v2

    .line 45
    goto :goto_1

    .line 46
    :cond_0
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, Landroidx/room/L;->release()V

    .line 50
    .line 51
    .line 52
    return-object v3

    .line 53
    :goto_1
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v0}, Landroidx/room/L;->release()V

    .line 57
    .line 58
    .line 59
    throw v2
.end method

.method public h(LFf/c;)Ljava/lang/Object;
    .locals 6

    .line 1
    instance-of v0, p1, Lj0/o0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lj0/o0;

    .line 7
    .line 8
    iget v1, v0, Lj0/o0;->e:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lj0/o0;->e:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lj0/o0;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, Lj0/o0;-><init>(LO2/a;LFf/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, Lj0/o0;->c:Ljava/lang/Object;

    .line 26
    .line 27
    sget-object v1, LEf/a;->a:LEf/a;

    .line 28
    .line 29
    iget v2, v0, Lj0/o0;->e:I

    .line 30
    .line 31
    const/4 v3, 0x2

    .line 32
    const/4 v4, 0x1

    .line 33
    const/4 v5, 0x0

    .line 34
    if-eqz v2, :cond_3

    .line 35
    .line 36
    if-eq v2, v4, :cond_2

    .line 37
    .line 38
    if-ne v2, v3, :cond_1

    .line 39
    .line 40
    iget-object v1, v0, Lj0/o0;->b:Lkotlinx/coroutines/sync/Mutex;

    .line 41
    .line 42
    iget-object v0, v0, Lj0/o0;->a:LO2/a;

    .line 43
    .line 44
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 45
    .line 46
    .line 47
    goto :goto_3

    .line 48
    :catchall_0
    move-exception p1

    .line 49
    goto :goto_4

    .line 50
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 51
    .line 52
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 53
    .line 54
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    throw p1

    .line 58
    :cond_2
    iget-object v2, v0, Lj0/o0;->b:Lkotlinx/coroutines/sync/Mutex;

    .line 59
    .line 60
    iget-object v4, v0, Lj0/o0;->a:LO2/a;

    .line 61
    .line 62
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    move-object p1, v2

    .line 66
    goto :goto_1

    .line 67
    :cond_3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    iget-object p1, p0, LO2/a;->b:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast p1, LWf/m;

    .line 73
    .line 74
    invoke-virtual {p1}, LWf/n0;->isCompleted()Z

    .line 75
    .line 76
    .line 77
    move-result p1

    .line 78
    if-eqz p1, :cond_4

    .line 79
    .line 80
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 81
    .line 82
    return-object p1

    .line 83
    :cond_4
    iput-object p0, v0, Lj0/o0;->a:LO2/a;

    .line 84
    .line 85
    iget-object p1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast p1, Leg/e;

    .line 88
    .line 89
    iput-object p1, v0, Lj0/o0;->b:Lkotlinx/coroutines/sync/Mutex;

    .line 90
    .line 91
    iput v4, v0, Lj0/o0;->e:I

    .line 92
    .line 93
    invoke-virtual {p1, v5, v0}, Leg/e;->lock(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    if-ne v2, v1, :cond_5

    .line 98
    .line 99
    goto :goto_2

    .line 100
    :cond_5
    move-object v4, p0

    .line 101
    :goto_1
    :try_start_1
    iget-object v2, v4, LO2/a;->b:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v2, LWf/m;

    .line 104
    .line 105
    invoke-virtual {v2}, LWf/n0;->isCompleted()Z

    .line 106
    .line 107
    .line 108
    move-result v2

    .line 109
    if-eqz v2, :cond_6

    .line 110
    .line 111
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 112
    .line 113
    invoke-interface {p1, v5}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    return-object v0

    .line 117
    :catchall_1
    move-exception v0

    .line 118
    move-object v1, p1

    .line 119
    move-object p1, v0

    .line 120
    goto :goto_4

    .line 121
    :cond_6
    :try_start_2
    iput-object v4, v0, Lj0/o0;->a:LO2/a;

    .line 122
    .line 123
    iput-object p1, v0, Lj0/o0;->b:Lkotlinx/coroutines/sync/Mutex;

    .line 124
    .line 125
    iput v3, v0, Lj0/o0;->e:I

    .line 126
    .line 127
    invoke-virtual {v4, v0}, LO2/a;->c(LFf/c;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 131
    if-ne v0, v1, :cond_7

    .line 132
    .line 133
    :goto_2
    return-object v1

    .line 134
    :cond_7
    move-object v1, p1

    .line 135
    move-object v0, v4

    .line 136
    :goto_3
    :try_start_3
    iget-object p1, v0, LO2/a;->b:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast p1, LWf/m;

    .line 139
    .line 140
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 141
    .line 142
    invoke-virtual {p1, v0}, LWf/n0;->v(Ljava/lang/Object;)Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 143
    .line 144
    .line 145
    invoke-interface {v1, v5}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    return-object v0

    .line 149
    :goto_4
    invoke-interface {v1, v5}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    throw p1
.end method

.method public i(I)V
    .locals 2

    .line 1
    iget-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/widget/TextView;

    .line 4
    .line 5
    if-gtz p1, :cond_0

    .line 6
    .line 7
    if-eqz v0, :cond_4

    .line 8
    .line 9
    invoke-static {v0}, Loa/h;->c(Landroid/view/View;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    const/16 v1, 0x63

    .line 14
    .line 15
    if-le p1, v1, :cond_2

    .line 16
    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    const-string p1, "99+"

    .line 20
    .line 21
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 22
    .line 23
    .line 24
    :cond_1
    if-eqz v0, :cond_4

    .line 25
    .line 26
    invoke-static {v0}, Loa/h;->C(Landroid/view/View;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_2
    if-eqz v0, :cond_3

    .line 31
    .line 32
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 37
    .line 38
    .line 39
    :cond_3
    if-eqz v0, :cond_4

    .line 40
    .line 41
    invoke-static {v0}, Loa/h;->C(Landroid/view/View;)V

    .line 42
    .line 43
    .line 44
    :cond_4
    return-void
.end method

.method public insert(Landroidx/work/impl/model/g;)V
    .locals 2

    .line 1
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Landroidx/room/G;->beginTransaction()V

    .line 9
    .line 10
    .line 11
    :try_start_0
    iget-object v1, p0, LO2/a;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, LTd/a;

    .line 14
    .line 15
    invoke-virtual {v1, p1}, Landroidx/room/o;->e(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Landroidx/room/G;->setTransactionSuccessful()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :catchall_0
    move-exception p1

    .line 26
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V

    .line 27
    .line 28
    .line 29
    throw p1
.end method

.method public insertSystemIdInfo(Landroidx/work/impl/model/d;)V
    .locals 2

    .line 1
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Landroidx/room/G;->beginTransaction()V

    .line 9
    .line 10
    .line 11
    :try_start_0
    iget-object v1, p0, LO2/a;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, LTd/a;

    .line 14
    .line 15
    invoke-virtual {v1, p1}, Landroidx/room/o;->e(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Landroidx/room/G;->setTransactionSuccessful()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :catchall_0
    move-exception p1

    .line 26
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V

    .line 27
    .line 28
    .line 29
    throw p1
.end method

.method public onActionItemClicked(Lx/a;Landroid/view/MenuItem;)Z
    .locals 2

    .line 1
    invoke-virtual {p0, p1}, LO2/a;->e(Lx/a;)Lx/c;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    new-instance v0, Landroidx/appcompat/view/menu/q;

    .line 6
    .line 7
    iget-object v1, p0, LO2/a;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Landroid/content/Context;

    .line 10
    .line 11
    check-cast p2, Landroidx/core/internal/view/SupportMenuItem;

    .line 12
    .line 13
    invoke-direct {v0, v1, p2}, Landroidx/appcompat/view/menu/q;-><init>(Landroid/content/Context;Landroidx/core/internal/view/SupportMenuItem;)V

    .line 14
    .line 15
    .line 16
    iget-object p2, p0, LO2/a;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p2, Landroid/view/ActionMode$Callback;

    .line 19
    .line 20
    invoke-interface {p2, p1, v0}, Landroid/view/ActionMode$Callback;->onActionItemClicked(Landroid/view/ActionMode;Landroid/view/MenuItem;)Z

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    return p1
.end method

.method public onCreateActionMode(Lx/a;Landroid/view/Menu;)Z
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, LO2/a;->e(Lx/a;)Lx/c;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p0, LO2/a;->d:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, LM/n;

    .line 8
    .line 9
    invoke-virtual {v0, p2}, LM/n;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Landroid/view/Menu;

    .line 14
    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    new-instance v1, Landroidx/appcompat/view/menu/u;

    .line 18
    .line 19
    iget-object v2, p0, LO2/a;->b:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v2, Landroid/content/Context;

    .line 22
    .line 23
    move-object v3, p2

    .line 24
    check-cast v3, Landroidx/core/internal/view/SupportMenu;

    .line 25
    .line 26
    invoke-direct {v1, v2, v3}, Landroidx/appcompat/view/menu/u;-><init>(Landroid/content/Context;Landroidx/core/internal/view/SupportMenu;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0, p2, v1}, LM/n;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    :cond_0
    iget-object p2, p0, LO2/a;->a:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p2, Landroid/view/ActionMode$Callback;

    .line 35
    .line 36
    invoke-interface {p2, p1, v1}, Landroid/view/ActionMode$Callback;->onCreateActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    return p1
.end method

.method public onDestroyActionMode(Lx/a;)V
    .locals 1

    .line 1
    invoke-virtual {p0, p1}, LO2/a;->e(Lx/a;)Lx/c;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Landroid/view/ActionMode$Callback;

    .line 8
    .line 9
    invoke-interface {v0, p1}, Landroid/view/ActionMode$Callback;->onDestroyActionMode(Landroid/view/ActionMode;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public onFailure(Lokhttp3/Call;Ljava/io/IOException;)V
    .locals 1

    .line 1
    const-string v0, "call"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "e"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Ljava/util/ArrayList;

    .line 14
    .line 15
    monitor-enter p1

    .line 16
    :try_start_0
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    .line 18
    .line 19
    monitor-exit p1

    .line 20
    iget-object p1, p0, LO2/a;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast p1, Ljava/util/concurrent/CountDownLatch;

    .line 23
    .line 24
    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :catchall_0
    move-exception p2

    .line 29
    monitor-exit p1

    .line 30
    throw p2
.end method

.method public onPrepareActionMode(Lx/a;Landroid/view/Menu;)Z
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, LO2/a;->e(Lx/a;)Lx/c;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p0, LO2/a;->d:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, LM/n;

    .line 8
    .line 9
    invoke-virtual {v0, p2}, LM/n;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Landroid/view/Menu;

    .line 14
    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    new-instance v1, Landroidx/appcompat/view/menu/u;

    .line 18
    .line 19
    iget-object v2, p0, LO2/a;->b:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v2, Landroid/content/Context;

    .line 22
    .line 23
    move-object v3, p2

    .line 24
    check-cast v3, Landroidx/core/internal/view/SupportMenu;

    .line 25
    .line 26
    invoke-direct {v1, v2, v3}, Landroidx/appcompat/view/menu/u;-><init>(Landroid/content/Context;Landroidx/core/internal/view/SupportMenu;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0, p2, v1}, LM/n;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    :cond_0
    iget-object p2, p0, LO2/a;->a:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p2, Landroid/view/ActionMode$Callback;

    .line 35
    .line 36
    invoke-interface {p2, p1, v1}, Landroid/view/ActionMode$Callback;->onPrepareActionMode(Landroid/view/ActionMode;Landroid/view/Menu;)Z

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    return p1
.end method

.method public onResponse(Lokhttp3/Call;Lokhttp3/e0;)V
    .locals 2

    .line 1
    const-string v0, "call"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "response"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, LO2/a;->c:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Ljava/lang/String;

    .line 14
    .line 15
    iget-object v0, p0, LO2/a;->d:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Ljava/util/ArrayList;

    .line 18
    .line 19
    iget-object v1, p0, LO2/a;->a:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v1, Ljava/util/ArrayList;

    .line 22
    .line 23
    invoke-static {p2, p1, v0, v1}, LCg/d;->b(Lokhttp3/e0;Ljava/lang/String;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    .line 24
    .line 25
    .line 26
    iget-object p1, p0, LO2/a;->b:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p1, Ljava/util/concurrent/CountDownLatch;

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public removeSystemIdInfo(Ljava/lang/String;)V
    .locals 4

    .line 14
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    invoke-virtual {v0}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 15
    iget-object v1, p0, LO2/a;->d:Ljava/lang/Object;

    check-cast v1, LTd/c;

    invoke-virtual {v1}, Landroidx/room/P;->a()Landroidx/sqlite/db/SupportSQLiteStatement;

    move-result-object v2

    const/4 v3, 0x1

    .line 16
    invoke-interface {v2, v3, p1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 17
    :try_start_0
    invoke-virtual {v0}, Landroidx/room/G;->beginTransaction()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    :try_start_1
    invoke-interface {v2}, Landroidx/sqlite/db/SupportSQLiteStatement;->executeUpdateDelete()I

    .line 19
    invoke-virtual {v0}, Landroidx/room/G;->setTransactionSuccessful()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 20
    :try_start_2
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 21
    invoke-virtual {v1, v2}, Landroidx/room/P;->c(Landroidx/sqlite/db/SupportSQLiteStatement;)V

    return-void

    :catchall_0
    move-exception p1

    goto :goto_0

    :catchall_1
    move-exception p1

    .line 22
    :try_start_3
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V

    .line 23
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 24
    :goto_0
    invoke-virtual {v1, v2}, Landroidx/room/P;->c(Landroidx/sqlite/db/SupportSQLiteStatement;)V

    .line 25
    throw p1
.end method

.method public removeSystemIdInfo(Ljava/lang/String;I)V
    .locals 5

    .line 1
    iget-object v0, p0, LO2/a;->a:Ljava/lang/Object;

    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    invoke-virtual {v0}, Landroidx/room/G;->assertNotSuspendingTransaction()V

    .line 2
    iget-object v1, p0, LO2/a;->c:Ljava/lang/Object;

    check-cast v1, LTd/c;

    invoke-virtual {v1}, Landroidx/room/P;->a()Landroidx/sqlite/db/SupportSQLiteStatement;

    move-result-object v2

    const/4 v3, 0x1

    .line 3
    invoke-interface {v2, v3, p1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    const/4 p1, 0x2

    int-to-long v3, p2

    .line 4
    invoke-interface {v2, p1, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 5
    :try_start_0
    invoke-virtual {v0}, Landroidx/room/G;->beginTransaction()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 6
    :try_start_1
    invoke-interface {v2}, Landroidx/sqlite/db/SupportSQLiteStatement;->executeUpdateDelete()I

    .line 7
    invoke-virtual {v0}, Landroidx/room/G;->setTransactionSuccessful()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 8
    :try_start_2
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 9
    invoke-virtual {v1, v2}, Landroidx/room/P;->c(Landroidx/sqlite/db/SupportSQLiteStatement;)V

    return-void

    :catchall_0
    move-exception p1

    goto :goto_0

    :catchall_1
    move-exception p1

    .line 10
    :try_start_3
    invoke-virtual {v0}, Landroidx/room/G;->endTransaction()V

    .line 11
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 12
    :goto_0
    invoke-virtual {v1, v2}, Landroidx/room/P;->c(Landroidx/sqlite/db/SupportSQLiteStatement;)V

    .line 13
    throw p1
.end method

.method public renderFrame(ILandroid/graphics/Bitmap;)Z
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    iget-object v1, p0, LO2/a;->c:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v1, Lub/k0;

    .line 5
    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    new-instance v2, Landroid/graphics/Canvas;

    .line 10
    .line 11
    invoke-direct {v2, p2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 12
    .line 13
    .line 14
    sget-object p2, Landroid/graphics/PorterDuff$Mode;->SRC:Landroid/graphics/PorterDuff$Mode;

    .line 15
    .line 16
    invoke-virtual {v2, v0, p2}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    .line 17
    .line 18
    .line 19
    iget-object p2, v1, Lub/k0;->b:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p2, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    if-nez p1, :cond_0

    .line 25
    .line 26
    invoke-interface {p2, p1}, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;->getFrameInfo(I)LX2/a;

    .line 27
    .line 28
    .line 29
    throw v1

    .line 30
    :cond_0
    invoke-interface {p2, p1}, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;->getFrameInfo(I)LX2/a;

    .line 31
    .line 32
    .line 33
    add-int/lit8 v2, p1, -0x1

    .line 34
    .line 35
    invoke-interface {p2, v2}, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;->getFrameInfo(I)LX2/a;

    .line 36
    .line 37
    .line 38
    throw v1
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 39
    :catch_0
    move-exception p2

    .line 40
    sget-object v1, Lp2/a;->a:Lp2/b;

    .line 41
    .line 42
    const/4 v2, 0x6

    .line 43
    invoke-virtual {v1, v2}, Lp2/b;->isLoggable(I)Z

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    if-eqz v2, :cond_1

    .line 48
    .line 49
    const-class v2, LO2/a;

    .line 50
    .line 51
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    new-instance v3, Ljava/lang/StringBuilder;

    .line 56
    .line 57
    const-string v4, "Rendering of frame unsuccessful. Frame number: "

    .line 58
    .line 59
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-virtual {v1, v2, p1, p2}, Lp2/b;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 70
    .line 71
    .line 72
    :cond_1
    return v0
.end method

.method public setBounds(Landroid/graphics/Rect;)V
    .locals 2

    .line 1
    iget-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;->forNewBounds(Landroid/graphics/Rect;)Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iget-object v0, p0, LO2/a;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;

    .line 12
    .line 13
    if-eq p1, v0, :cond_0

    .line 14
    .line 15
    iput-object p1, p0, LO2/a;->b:Ljava/lang/Object;

    .line 16
    .line 17
    new-instance v0, Lub/k0;

    .line 18
    .line 19
    iget-object v1, p0, LO2/a;->d:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v1, LOe/a;

    .line 22
    .line 23
    invoke-direct {v0, p1, v1}, Lub/k0;-><init>(Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;LOe/a;)V

    .line 24
    .line 25
    .line 26
    iput-object v0, p0, LO2/a;->c:Ljava/lang/Object;

    .line 27
    .line 28
    :cond_0
    return-void
.end method
