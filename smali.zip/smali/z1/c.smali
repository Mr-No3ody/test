.class public final Lz1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/bumptech/glide/load/model/ModelLoader;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 0

    iput p2, p0, Lz1/c;->a:I

    packed-switch p2, :pswitch_data_0

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lz1/c;->b:Ljava/lang/Object;

    return-void

    .line 5
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lz1/c;->b:Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Lcom/bumptech/glide/load/model/ModelLoader;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lz1/c;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lz1/c;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final buildLoadData(Ljava/lang/Object;IILcom/bumptech/glide/load/h;)Lcom/bumptech/glide/load/model/t;
    .locals 3

    .line 1
    iget v0, p0, Lz1/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/net/URL;

    .line 7
    .line 8
    new-instance v0, Lcom/bumptech/glide/load/model/l;

    .line 9
    .line 10
    invoke-direct {v0, p1}, Lcom/bumptech/glide/load/model/l;-><init>(Ljava/net/URL;)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, Lz1/c;->b:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p1, Lcom/bumptech/glide/load/model/ModelLoader;

    .line 16
    .line 17
    invoke-interface {p1, v0, p2, p3, p4}, Lcom/bumptech/glide/load/model/ModelLoader;->buildLoadData(Ljava/lang/Object;IILcom/bumptech/glide/load/h;)Lcom/bumptech/glide/load/model/t;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    return-object p1

    .line 22
    :pswitch_0
    check-cast p1, Landroid/net/Uri;

    .line 23
    .line 24
    const/high16 v0, -0x80000000

    .line 25
    .line 26
    if-eq p2, v0, :cond_0

    .line 27
    .line 28
    if-eq p3, v0, :cond_0

    .line 29
    .line 30
    const/16 v0, 0x200

    .line 31
    .line 32
    if-gt p2, v0, :cond_0

    .line 33
    .line 34
    const/16 p2, 0x180

    .line 35
    .line 36
    if-gt p3, p2, :cond_0

    .line 37
    .line 38
    sget-object p2, Lcom/bumptech/glide/load/resource/bitmap/G;->d:Lcom/bumptech/glide/load/g;

    .line 39
    .line 40
    invoke-virtual {p4, p2}, Lcom/bumptech/glide/load/h;->a(Lcom/bumptech/glide/load/g;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p2

    .line 44
    check-cast p2, Ljava/lang/Long;

    .line 45
    .line 46
    if-eqz p2, :cond_0

    .line 47
    .line 48
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 49
    .line 50
    .line 51
    move-result-wide p2

    .line 52
    const-wide/16 v0, -0x1

    .line 53
    .line 54
    cmp-long p2, p2, v0

    .line 55
    .line 56
    if-nez p2, :cond_0

    .line 57
    .line 58
    new-instance p2, Lcom/bumptech/glide/load/model/t;

    .line 59
    .line 60
    new-instance p3, LI1/d;

    .line 61
    .line 62
    invoke-direct {p3, p1}, LI1/d;-><init>(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    new-instance p4, Lcom/bumptech/glide/load/data/mediastore/a;

    .line 66
    .line 67
    iget-object v0, p0, Lz1/c;->b:Ljava/lang/Object;

    .line 68
    .line 69
    check-cast v0, Landroid/content/Context;

    .line 70
    .line 71
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    const/4 v2, 0x1

    .line 76
    invoke-direct {p4, v1, v2}, Lcom/bumptech/glide/load/data/mediastore/a;-><init>(Landroid/content/ContentResolver;I)V

    .line 77
    .line 78
    .line 79
    invoke-static {v0, p1, p4}, Lcom/bumptech/glide/load/data/mediastore/b;->a(Landroid/content/Context;Landroid/net/Uri;Lcom/bumptech/glide/load/data/mediastore/ThumbnailQuery;)Lcom/bumptech/glide/load/data/mediastore/b;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    invoke-direct {p2, p3, p1}, Lcom/bumptech/glide/load/model/t;-><init>(Lcom/bumptech/glide/load/Key;Lcom/bumptech/glide/load/data/DataFetcher;)V

    .line 84
    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_0
    const/4 p2, 0x0

    .line 88
    :goto_0
    return-object p2

    .line 89
    :pswitch_1
    check-cast p1, Landroid/net/Uri;

    .line 90
    .line 91
    const/high16 p4, -0x80000000

    .line 92
    .line 93
    if-eq p2, p4, :cond_1

    .line 94
    .line 95
    if-eq p3, p4, :cond_1

    .line 96
    .line 97
    const/16 p4, 0x200

    .line 98
    .line 99
    if-gt p2, p4, :cond_1

    .line 100
    .line 101
    const/16 p2, 0x180

    .line 102
    .line 103
    if-gt p3, p2, :cond_1

    .line 104
    .line 105
    new-instance p2, Lcom/bumptech/glide/load/model/t;

    .line 106
    .line 107
    new-instance p3, LI1/d;

    .line 108
    .line 109
    invoke-direct {p3, p1}, LI1/d;-><init>(Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    new-instance p4, Lcom/bumptech/glide/load/data/mediastore/a;

    .line 113
    .line 114
    iget-object v0, p0, Lz1/c;->b:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast v0, Landroid/content/Context;

    .line 117
    .line 118
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    const/4 v2, 0x0

    .line 123
    invoke-direct {p4, v1, v2}, Lcom/bumptech/glide/load/data/mediastore/a;-><init>(Landroid/content/ContentResolver;I)V

    .line 124
    .line 125
    .line 126
    invoke-static {v0, p1, p4}, Lcom/bumptech/glide/load/data/mediastore/b;->a(Landroid/content/Context;Landroid/net/Uri;Lcom/bumptech/glide/load/data/mediastore/ThumbnailQuery;)Lcom/bumptech/glide/load/data/mediastore/b;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    invoke-direct {p2, p3, p1}, Lcom/bumptech/glide/load/model/t;-><init>(Lcom/bumptech/glide/load/Key;Lcom/bumptech/glide/load/data/DataFetcher;)V

    .line 131
    .line 132
    .line 133
    goto :goto_1

    .line 134
    :cond_1
    const/4 p2, 0x0

    .line 135
    :goto_1
    return-object p2

    .line 136
    nop

    .line 137
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final handles(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    iget v0, p0, Lz1/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/net/URL;

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    return p1

    .line 10
    :pswitch_0
    check-cast p1, Landroid/net/Uri;

    .line 11
    .line 12
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->y(Landroid/net/Uri;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {p1}, Landroid/net/Uri;->getPathSegments()Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    const-string/jumbo v0, "video"

    .line 23
    .line 24
    .line 25
    invoke-interface {p1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    if-eqz p1, :cond_0

    .line 30
    .line 31
    const/4 p1, 0x1

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    const/4 p1, 0x0

    .line 34
    :goto_0
    return p1

    .line 35
    :pswitch_1
    check-cast p1, Landroid/net/Uri;

    .line 36
    .line 37
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->y(Landroid/net/Uri;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    invoke-virtual {p1}, Landroid/net/Uri;->getPathSegments()Ljava/util/List;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    const-string/jumbo v0, "video"

    .line 48
    .line 49
    .line 50
    invoke-interface {p1, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    if-nez p1, :cond_1

    .line 55
    .line 56
    const/4 p1, 0x1

    .line 57
    goto :goto_1

    .line 58
    :cond_1
    const/4 p1, 0x0

    .line 59
    :goto_1
    return p1

    .line 60
    nop

    .line 61
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
