.class public final Lz1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/bumptech/glide/load/model/ModelLoader;


# static fields
.field public static final b:Lcom/bumptech/glide/load/g;


# instance fields
.field public final a:Lcom/bumptech/glide/load/model/s;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const/16 v0, 0x9c4

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "com.bumptech.glide.load.model.stream.HttpGlideUrlLoader.Timeout"

    .line 8
    .line 9
    invoke-static {v0, v1}, Lcom/bumptech/glide/load/g;->a(Ljava/lang/Object;Ljava/lang/String;)Lcom/bumptech/glide/load/g;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, Lz1/a;->b:Lcom/bumptech/glide/load/g;

    .line 14
    .line 15
    return-void
.end method

.method public constructor <init>(Lcom/bumptech/glide/load/model/s;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lz1/a;->a:Lcom/bumptech/glide/load/model/s;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final buildLoadData(Ljava/lang/Object;IILcom/bumptech/glide/load/h;)Lcom/bumptech/glide/load/model/t;
    .locals 3

    .line 1
    check-cast p1, Lcom/bumptech/glide/load/model/l;

    .line 2
    .line 3
    iget-object p2, p0, Lz1/a;->a:Lcom/bumptech/glide/load/model/s;

    .line 4
    .line 5
    if-eqz p2, :cond_1

    .line 6
    .line 7
    const/4 p3, 0x0

    .line 8
    invoke-static {p3, p3, p1}, Lcom/bumptech/glide/load/model/r;->a(IILjava/lang/Object;)Lcom/bumptech/glide/load/model/r;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object v1, p2, Lcom/bumptech/glide/load/model/s;->a:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Lcom/bumptech/glide/load/model/q;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, LJ1/k;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    sget-object v2, Lcom/bumptech/glide/load/model/r;->d:Ljava/util/ArrayDeque;

    .line 21
    .line 22
    monitor-enter v2

    .line 23
    :try_start_0
    invoke-virtual {v2, v0}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    check-cast v1, Lcom/bumptech/glide/load/model/l;

    .line 28
    .line 29
    if-nez v1, :cond_0

    .line 30
    .line 31
    invoke-static {p3, p3, p1}, Lcom/bumptech/glide/load/model/r;->a(IILjava/lang/Object;)Lcom/bumptech/glide/load/model/r;

    .line 32
    .line 33
    .line 34
    move-result-object p3

    .line 35
    iget-object p2, p2, Lcom/bumptech/glide/load/model/s;->a:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p2, Lcom/bumptech/glide/load/model/q;

    .line 38
    .line 39
    invoke-virtual {p2, p3, p1}, LJ1/k;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_0
    move-object p1, v1

    .line 44
    goto :goto_0

    .line 45
    :catchall_0
    move-exception p1

    .line 46
    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 47
    throw p1

    .line 48
    :cond_1
    :goto_0
    sget-object p2, Lz1/a;->b:Lcom/bumptech/glide/load/g;

    .line 49
    .line 50
    invoke-virtual {p4, p2}, Lcom/bumptech/glide/load/h;->a(Lcom/bumptech/glide/load/g;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    check-cast p2, Ljava/lang/Integer;

    .line 55
    .line 56
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 57
    .line 58
    .line 59
    move-result p2

    .line 60
    new-instance p3, Lcom/bumptech/glide/load/model/t;

    .line 61
    .line 62
    new-instance p4, Lcom/bumptech/glide/load/data/i;

    .line 63
    .line 64
    invoke-direct {p4, p1, p2}, Lcom/bumptech/glide/load/data/i;-><init>(Lcom/bumptech/glide/load/model/l;I)V

    .line 65
    .line 66
    .line 67
    invoke-direct {p3, p1, p4}, Lcom/bumptech/glide/load/model/t;-><init>(Lcom/bumptech/glide/load/Key;Lcom/bumptech/glide/load/data/DataFetcher;)V

    .line 68
    .line 69
    .line 70
    return-object p3
.end method

.method public final bridge synthetic handles(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    check-cast p1, Lcom/bumptech/glide/load/model/l;

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    return p1
.end method
