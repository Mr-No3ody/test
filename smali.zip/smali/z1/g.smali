.class public final Lz1/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/bumptech/glide/load/model/ModelLoaderFactory;


# virtual methods
.method public final build(Lcom/bumptech/glide/load/model/x;)Lcom/bumptech/glide/load/model/ModelLoader;
    .locals 3

    .line 1
    new-instance v0, Lz1/c;

    .line 2
    .line 3
    const-class v1, Lcom/bumptech/glide/load/model/l;

    .line 4
    .line 5
    const-class v2, Ljava/io/InputStream;

    .line 6
    .line 7
    invoke-virtual {p1, v1, v2}, Lcom/bumptech/glide/load/model/x;->c(Ljava/lang/Class;Ljava/lang/Class;)Lcom/bumptech/glide/load/model/ModelLoader;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-direct {v0, p1}, Lz1/c;-><init>(Lcom/bumptech/glide/load/model/ModelLoader;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public final teardown()V
    .locals 0

    .line 1
    return-void
.end method
