.class public final LN0/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/sqlite/db/SupportSQLiteOpenHelper$Factory;


# virtual methods
.method public final create(LM0/g;)Landroidx/sqlite/db/SupportSQLiteOpenHelper;
    .locals 7

    .line 1
    const-string v0, "configuration"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v1, LN0/l;

    .line 7
    .line 8
    iget-object v2, p1, LM0/g;->a:Landroid/content/Context;

    .line 9
    .line 10
    iget-object v3, p1, LM0/g;->b:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v4, p1, LM0/g;->c:LM0/d;

    .line 13
    .line 14
    iget-boolean v5, p1, LM0/g;->d:Z

    .line 15
    .line 16
    iget-boolean v6, p1, LM0/g;->e:Z

    .line 17
    .line 18
    invoke-direct/range {v1 .. v6}, LN0/l;-><init>(Landroid/content/Context;Ljava/lang/String;LM0/d;ZZ)V

    .line 19
    .line 20
    .line 21
    return-object v1
.end method
