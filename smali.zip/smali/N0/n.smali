.class public LN0/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/sqlite/db/SupportSQLiteProgram;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/io/Closeable;


# direct methods
.method public constructor <init>(Landroid/database/sqlite/SQLiteProgram;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LN0/n;->a:I

    const-string v0, "delegate"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, LN0/n;->b:Ljava/io/Closeable;

    return-void
.end method

.method public constructor <init>(Landroidx/room/L;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LN0/n;->a:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LN0/n;->b:Ljava/io/Closeable;

    return-void
.end method


# virtual methods
.method public final bindBlob(I[B)V
    .locals 1

    .line 1
    iget v0, p0, LN0/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string/jumbo v0, "value"

    .line 7
    .line 8
    .line 9
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 13
    .line 14
    check-cast v0, Landroidx/room/L;

    .line 15
    .line 16
    invoke-virtual {v0, p1, p2}, Landroidx/room/L;->bindBlob(I[B)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_0
    const-string/jumbo v0, "value"

    .line 21
    .line 22
    .line 23
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 27
    .line 28
    check-cast v0, Landroid/database/sqlite/SQLiteProgram;

    .line 29
    .line 30
    invoke-virtual {v0, p1, p2}, Landroid/database/sqlite/SQLiteProgram;->bindBlob(I[B)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final bindDouble(ID)V
    .locals 1

    .line 1
    iget v0, p0, LN0/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 7
    .line 8
    check-cast v0, Landroidx/room/L;

    .line 9
    .line 10
    invoke-virtual {v0, p1, p2, p3}, Landroidx/room/L;->bindDouble(ID)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 15
    .line 16
    check-cast v0, Landroid/database/sqlite/SQLiteProgram;

    .line 17
    .line 18
    invoke-virtual {v0, p1, p2, p3}, Landroid/database/sqlite/SQLiteProgram;->bindDouble(ID)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final bindLong(IJ)V
    .locals 1

    .line 1
    iget v0, p0, LN0/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 7
    .line 8
    check-cast v0, Landroidx/room/L;

    .line 9
    .line 10
    invoke-virtual {v0, p1, p2, p3}, Landroidx/room/L;->bindLong(IJ)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 15
    .line 16
    check-cast v0, Landroid/database/sqlite/SQLiteProgram;

    .line 17
    .line 18
    invoke-virtual {v0, p1, p2, p3}, Landroid/database/sqlite/SQLiteProgram;->bindLong(IJ)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final bindNull(I)V
    .locals 1

    .line 1
    iget v0, p0, LN0/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 7
    .line 8
    check-cast v0, Landroidx/room/L;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, Landroidx/room/L;->bindNull(I)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 15
    .line 16
    check-cast v0, Landroid/database/sqlite/SQLiteProgram;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, Landroid/database/sqlite/SQLiteProgram;->bindNull(I)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final bindString(ILjava/lang/String;)V
    .locals 1

    .line 1
    iget v0, p0, LN0/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string/jumbo v0, "value"

    .line 7
    .line 8
    .line 9
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 13
    .line 14
    check-cast v0, Landroidx/room/L;

    .line 15
    .line 16
    invoke-virtual {v0, p1, p2}, Landroidx/room/L;->bindString(ILjava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_0
    const-string/jumbo v0, "value"

    .line 21
    .line 22
    .line 23
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 27
    .line 28
    check-cast v0, Landroid/database/sqlite/SQLiteProgram;

    .line 29
    .line 30
    invoke-virtual {v0, p1, p2}, Landroid/database/sqlite/SQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final clearBindings()V
    .locals 1

    .line 1
    iget v0, p0, LN0/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 7
    .line 8
    check-cast v0, Landroidx/room/L;

    .line 9
    .line 10
    invoke-virtual {v0}, Landroidx/room/L;->clearBindings()V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 15
    .line 16
    check-cast v0, Landroid/database/sqlite/SQLiteProgram;

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteProgram;->clearBindings()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final close()V
    .locals 1

    .line 1
    iget v0, p0, LN0/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 7
    .line 8
    check-cast v0, Landroidx/room/L;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, LN0/n;->b:Ljava/io/Closeable;

    .line 15
    .line 16
    check-cast v0, Landroid/database/sqlite/SQLiteProgram;

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteClosable;->close()V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
