.class public abstract LA/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LA/c;)V
.end method
