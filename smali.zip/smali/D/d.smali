.class public final LD/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z

.field public b:Z

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;

.field public final e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LGg/i;Lokhttp3/y;LGg/e;Lokhttp3/internal/http/ExchangeCodec;)V
    .locals 1

    const-string v0, "call"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "eventListener"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "finder"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "codec"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, LD/d;->c:Ljava/lang/Object;

    .line 3
    iput-object p2, p0, LD/d;->d:Ljava/lang/Object;

    .line 4
    iput-object p3, p0, LD/d;->e:Ljava/lang/Object;

    .line 5
    iput-object p4, p0, LD/d;->f:Ljava/lang/Object;

    .line 6
    invoke-interface {p4}, Lokhttp3/internal/http/ExchangeCodec;->getConnection()LGg/n;

    move-result-object p1

    iput-object p1, p0, LD/d;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/camera/camera2/internal/o;Landroidx/camera/core/impl/utils/executor/i;)V
    .locals 1

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 8
    iput-boolean v0, p0, LD/d;->a:Z

    .line 9
    iput-boolean v0, p0, LD/d;->b:Z

    .line 10
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LD/d;->e:Ljava/lang/Object;

    .line 11
    new-instance v0, Landroidx/camera/camera2/impl/a;

    invoke-direct {v0}, Landroidx/camera/camera2/impl/a;-><init>()V

    iput-object v0, p0, LD/d;->f:Ljava/lang/Object;

    .line 12
    iput-object p1, p0, LD/d;->c:Ljava/lang/Object;

    .line 13
    iput-object p2, p0, LD/d;->d:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a(JZZLjava/io/IOException;)Ljava/io/IOException;
    .locals 2

    .line 1
    if-eqz p5, :cond_0

    .line 2
    .line 3
    invoke-virtual {p0, p5}, LD/d;->f(Ljava/io/IOException;)V

    .line 4
    .line 5
    .line 6
    :cond_0
    iget-object v0, p0, LD/d;->d:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lokhttp3/y;

    .line 9
    .line 10
    iget-object v1, p0, LD/d;->c:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, LGg/i;

    .line 13
    .line 14
    if-eqz p4, :cond_2

    .line 15
    .line 16
    if-eqz p5, :cond_1

    .line 17
    .line 18
    invoke-virtual {v0, v1, p5}, Lokhttp3/y;->requestFailed(Lokhttp3/Call;Ljava/io/IOException;)V

    .line 19
    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_1
    invoke-virtual {v0, v1, p1, p2}, Lokhttp3/y;->requestBodyEnd(Lokhttp3/Call;J)V

    .line 23
    .line 24
    .line 25
    :cond_2
    :goto_0
    if-eqz p3, :cond_4

    .line 26
    .line 27
    if-eqz p5, :cond_3

    .line 28
    .line 29
    invoke-virtual {v0, v1, p5}, Lokhttp3/y;->responseFailed(Lokhttp3/Call;Ljava/io/IOException;)V

    .line 30
    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_3
    invoke-virtual {v0, v1, p1, p2}, Lokhttp3/y;->responseBodyEnd(Lokhttp3/Call;J)V

    .line 34
    .line 35
    .line 36
    :cond_4
    :goto_1
    invoke-virtual {v1, p0, p4, p3, p5}, LGg/i;->f(LD/d;ZZLjava/io/IOException;)Ljava/io/IOException;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    return-object p1
.end method

.method public b(Lokhttp3/Y;Z)LGg/c;
    .locals 3

    .line 1
    const-string v0, "request"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iput-boolean p2, p0, LD/d;->a:Z

    .line 7
    .line 8
    iget-object p2, p1, Lokhttp3/Y;->d:Lokhttp3/c0;

    .line 9
    .line 10
    invoke-static {p2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p2}, Lokhttp3/c0;->contentLength()J

    .line 14
    .line 15
    .line 16
    move-result-wide v0

    .line 17
    iget-object p2, p0, LD/d;->d:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p2, Lokhttp3/y;

    .line 20
    .line 21
    iget-object v2, p0, LD/d;->c:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v2, LGg/i;

    .line 24
    .line 25
    invoke-virtual {p2, v2}, Lokhttp3/y;->requestBodyStart(Lokhttp3/Call;)V

    .line 26
    .line 27
    .line 28
    iget-object p2, p0, LD/d;->f:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast p2, Lokhttp3/internal/http/ExchangeCodec;

    .line 31
    .line 32
    invoke-interface {p2, p1, v0, v1}, Lokhttp3/internal/http/ExchangeCodec;->createRequestBody(Lokhttp3/Y;J)Lokio/Sink;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    new-instance p2, LGg/c;

    .line 37
    .line 38
    invoke-direct {p2, p0, p1, v0, v1}, LGg/c;-><init>(LD/d;Lokio/Sink;J)V

    .line 39
    .line 40
    .line 41
    return-object p2
.end method

.method public c()LGg/m;
    .locals 5

    .line 1
    iget-object v0, p0, LD/d;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LGg/i;

    .line 4
    .line 5
    iget-boolean v1, v0, LGg/i;->p:Z

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    iput-boolean v1, v0, LGg/i;->p:Z

    .line 11
    .line 12
    iget-object v0, v0, LGg/i;->f:LGg/h;

    .line 13
    .line 14
    invoke-virtual {v0}, LPg/f;->exit()Z

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, LD/d;->f:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Lokhttp3/internal/http/ExchangeCodec;

    .line 20
    .line 21
    invoke-interface {v0}, Lokhttp3/internal/http/ExchangeCodec;->getConnection()LGg/n;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    const-string v1, "exchange"

    .line 29
    .line 30
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget-object v1, v0, LGg/n;->d:Ljava/net/Socket;

    .line 34
    .line 35
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object v2, v0, LGg/n;->h:LPg/x;

    .line 39
    .line 40
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    iget-object v3, v0, LGg/n;->i:LPg/w;

    .line 44
    .line 45
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    const/4 v4, 0x0

    .line 49
    invoke-virtual {v1, v4}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0}, LGg/n;->k()V

    .line 53
    .line 54
    .line 55
    new-instance v0, LGg/m;

    .line 56
    .line 57
    invoke-direct {v0, v2, v3, p0}, LGg/m;-><init>(LPg/x;LPg/w;LD/d;)V

    .line 58
    .line 59
    .line 60
    return-object v0

    .line 61
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 62
    .line 63
    const-string v1, "Check failed."

    .line 64
    .line 65
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    throw v0
.end method

.method public d(Lokhttp3/e0;)LHg/g;
    .locals 4

    .line 1
    iget-object v0, p0, LD/d;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lokhttp3/internal/http/ExchangeCodec;

    .line 4
    .line 5
    const-string v1, "response"

    .line 6
    .line 7
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    :try_start_0
    const-string v1, "Content-Type"

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-virtual {p1, v1, v2}, Lokhttp3/e0;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-interface {v0, p1}, Lokhttp3/internal/http/ExchangeCodec;->reportedContentLength(Lokhttp3/e0;)J

    .line 18
    .line 19
    .line 20
    move-result-wide v2

    .line 21
    invoke-interface {v0, p1}, Lokhttp3/internal/http/ExchangeCodec;->openResponseBodySource(Lokhttp3/e0;)Lokio/Source;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    new-instance v0, LGg/d;

    .line 26
    .line 27
    invoke-direct {v0, p0, p1, v2, v3}, LGg/d;-><init>(LD/d;Lokio/Source;J)V

    .line 28
    .line 29
    .line 30
    new-instance p1, LHg/g;

    .line 31
    .line 32
    invoke-static {v0}, LPg/b;->c(Lokio/Source;)LPg/x;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-direct {p1, v1, v2, v3, v0}, LHg/g;-><init>(Ljava/lang/String;JLPg/x;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 37
    .line 38
    .line 39
    return-object p1

    .line 40
    :catch_0
    move-exception p1

    .line 41
    iget-object v0, p0, LD/d;->d:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v0, Lokhttp3/y;

    .line 44
    .line 45
    iget-object v1, p0, LD/d;->c:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v1, LGg/i;

    .line 48
    .line 49
    invoke-virtual {v0, v1, p1}, Lokhttp3/y;->responseFailed(Lokhttp3/Call;Ljava/io/IOException;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0, p1}, LD/d;->f(Ljava/io/IOException;)V

    .line 53
    .line 54
    .line 55
    throw p1
.end method

.method public e(Z)Lokhttp3/d0;
    .locals 2

    .line 1
    :try_start_0
    iget-object v0, p0, LD/d;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lokhttp3/internal/http/ExchangeCodec;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Lokhttp3/internal/http/ExchangeCodec;->readResponseHeaders(Z)Lokhttp3/d0;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    const-string v0, "deferredTrailers"

    .line 12
    .line 13
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iput-object p0, p1, Lokhttp3/d0;->m:LD/d;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    .line 18
    :cond_0
    return-object p1

    .line 19
    :catch_0
    move-exception p1

    .line 20
    iget-object v0, p0, LD/d;->d:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, Lokhttp3/y;

    .line 23
    .line 24
    iget-object v1, p0, LD/d;->c:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v1, LGg/i;

    .line 27
    .line 28
    invoke-virtual {v0, v1, p1}, Lokhttp3/y;->responseFailed(Lokhttp3/Call;Ljava/io/IOException;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0, p1}, LD/d;->f(Ljava/io/IOException;)V

    .line 32
    .line 33
    .line 34
    throw p1
.end method

.method public f(Ljava/io/IOException;)V
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, LD/d;->b:Z

    .line 3
    .line 4
    iget-object v1, p0, LD/d;->e:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v1, LGg/e;

    .line 7
    .line 8
    invoke-virtual {v1, p1}, LGg/e;->c(Ljava/io/IOException;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, LD/d;->f:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Lokhttp3/internal/http/ExchangeCodec;

    .line 14
    .line 15
    invoke-interface {v1}, Lokhttp3/internal/http/ExchangeCodec;->getConnection()LGg/n;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    iget-object v2, p0, LD/d;->c:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v2, LGg/i;

    .line 22
    .line 23
    monitor-enter v1

    .line 24
    :try_start_0
    const-string v3, "call"

    .line 25
    .line 26
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    instance-of v3, p1, Lokhttp3/internal/http2/L;

    .line 30
    .line 31
    if-eqz v3, :cond_2

    .line 32
    .line 33
    move-object v3, p1

    .line 34
    check-cast v3, Lokhttp3/internal/http2/L;

    .line 35
    .line 36
    iget-object v3, v3, Lokhttp3/internal/http2/L;->a:Lokhttp3/internal/http2/c;

    .line 37
    .line 38
    sget-object v4, Lokhttp3/internal/http2/c;->g:Lokhttp3/internal/http2/c;

    .line 39
    .line 40
    if-ne v3, v4, :cond_0

    .line 41
    .line 42
    iget p1, v1, LGg/n;->n:I

    .line 43
    .line 44
    add-int/2addr p1, v0

    .line 45
    iput p1, v1, LGg/n;->n:I

    .line 46
    .line 47
    if-le p1, v0, :cond_5

    .line 48
    .line 49
    iput-boolean v0, v1, LGg/n;->j:Z

    .line 50
    .line 51
    iget p1, v1, LGg/n;->l:I

    .line 52
    .line 53
    add-int/2addr p1, v0

    .line 54
    iput p1, v1, LGg/n;->l:I

    .line 55
    .line 56
    goto :goto_1

    .line 57
    :catchall_0
    move-exception p1

    .line 58
    goto :goto_2

    .line 59
    :cond_0
    check-cast p1, Lokhttp3/internal/http2/L;

    .line 60
    .line 61
    iget-object p1, p1, Lokhttp3/internal/http2/L;->a:Lokhttp3/internal/http2/c;

    .line 62
    .line 63
    sget-object v3, Lokhttp3/internal/http2/c;->i:Lokhttp3/internal/http2/c;

    .line 64
    .line 65
    if-ne p1, v3, :cond_1

    .line 66
    .line 67
    iget-boolean p1, v2, LGg/i;->B:Z

    .line 68
    .line 69
    if-nez p1, :cond_5

    .line 70
    .line 71
    :cond_1
    iput-boolean v0, v1, LGg/n;->j:Z

    .line 72
    .line 73
    iget p1, v1, LGg/n;->l:I

    .line 74
    .line 75
    add-int/2addr p1, v0

    .line 76
    iput p1, v1, LGg/n;->l:I

    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_2
    iget-object v3, v1, LGg/n;->g:Lokhttp3/internal/http2/u;

    .line 80
    .line 81
    if-eqz v3, :cond_3

    .line 82
    .line 83
    move v3, v0

    .line 84
    goto :goto_0

    .line 85
    :cond_3
    const/4 v3, 0x0

    .line 86
    :goto_0
    if-eqz v3, :cond_4

    .line 87
    .line 88
    instance-of v3, p1, Lokhttp3/internal/http2/a;

    .line 89
    .line 90
    if-eqz v3, :cond_5

    .line 91
    .line 92
    :cond_4
    iput-boolean v0, v1, LGg/n;->j:Z

    .line 93
    .line 94
    iget v3, v1, LGg/n;->m:I

    .line 95
    .line 96
    if-nez v3, :cond_5

    .line 97
    .line 98
    iget-object v2, v2, LGg/i;->a:Lokhttp3/U;

    .line 99
    .line 100
    iget-object v3, v1, LGg/n;->b:Lokhttp3/i0;

    .line 101
    .line 102
    invoke-static {v2, v3, p1}, LGg/n;->d(Lokhttp3/U;Lokhttp3/i0;Ljava/io/IOException;)V

    .line 103
    .line 104
    .line 105
    iget p1, v1, LGg/n;->l:I

    .line 106
    .line 107
    add-int/2addr p1, v0

    .line 108
    iput p1, v1, LGg/n;->l:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 109
    .line 110
    :cond_5
    :goto_1
    monitor-exit v1

    .line 111
    return-void

    .line 112
    :goto_2
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 113
    throw p1
.end method
