.class public final synthetic LD/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Z

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ZI)V
    .locals 0

    .line 1
    iput p3, p0, LD/b;->a:I

    iput-object p1, p0, LD/b;->c:Ljava/lang/Object;

    iput-boolean p2, p0, LD/b;->b:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ZLjava/lang/Object;I)V
    .locals 0

    .line 2
    iput p3, p0, LD/b;->a:I

    iput-boolean p1, p0, LD/b;->b:Z

    iput-object p2, p0, LD/b;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget v2, p0, LD/b;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;

    .line 12
    .line 13
    iget-boolean v1, p0, LD/b;->b:Z

    .line 14
    .line 15
    invoke-static {v0, v1}, Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;->a(Lcom/flexibank/sdk/core/viewmodel/FlexiBankOneTimeCodeView;Z)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_0
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v0, Lcom/transsnet/adsdk/widgets/Interstitial/InterstitialAdView;

    .line 22
    .line 23
    iget-boolean v1, p0, LD/b;->b:Z

    .line 24
    .line 25
    invoke-static {v1, v0}, Lcom/transsnet/adsdk/widgets/Interstitial/InterstitialAdView;->a(ZLcom/transsnet/adsdk/widgets/Interstitial/InterstitialAdView;)V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_1
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lcom/transsnet/adsdk/data/local/entity/AdEntity;

    .line 32
    .line 33
    iget-boolean v1, p0, LD/b;->b:Z

    .line 34
    .line 35
    invoke-static {v0, v1}, Lcom/transsnet/adsdk/AdManager;->b(Lcom/transsnet/adsdk/data/local/entity/AdEntity;Z)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_2
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v0, Landroid/view/View;

    .line 42
    .line 43
    iget-boolean v1, p0, LD/b;->b:Z

    .line 44
    .line 45
    invoke-static {v0, v1}, Lcom/google/android/material/internal/ViewUtils;->a(Landroid/view/View;Z)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_3
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v0, Landroid/app/Activity;

    .line 52
    .line 53
    iget-boolean v1, p0, LD/b;->b:Z

    .line 54
    .line 55
    invoke-static {v0, v1}, Lcom/facebook/react/modules/statusbar/StatusBarModule;->a(Landroid/app/Activity;Z)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :pswitch_4
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast v0, Lcom/facebook/react/modules/core/JavaTimerManager;

    .line 62
    .line 63
    iget-boolean v1, p0, LD/b;->b:Z

    .line 64
    .line 65
    invoke-static {v0, v1}, Lcom/facebook/react/modules/core/JavaTimerManager;->c(Lcom/facebook/react/modules/core/JavaTimerManager;Z)V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :pswitch_5
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v0, Lcom/facebook/react/devsupport/DebugOverlayController;

    .line 72
    .line 73
    iget-boolean v1, p0, LD/b;->b:Z

    .line 74
    .line 75
    invoke-static {v1, v0}, Lcom/facebook/react/devsupport/DebugOverlayController;->a(ZLcom/facebook/react/devsupport/DebugOverlayController;)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :pswitch_6
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v0, Landroidx/camera/camera2/internal/J;

    .line 82
    .line 83
    iget-boolean v2, p0, LD/b;->b:Z

    .line 84
    .line 85
    iput-boolean v2, v0, Landroidx/camera/camera2/internal/J;->w0:Z

    .line 86
    .line 87
    if-eqz v2, :cond_0

    .line 88
    .line 89
    iget v2, v0, Landroidx/camera/camera2/internal/J;->B0:I

    .line 90
    .line 91
    const/4 v3, 0x4

    .line 92
    if-ne v2, v3, :cond_0

    .line 93
    .line 94
    invoke-virtual {v0, v1}, Landroidx/camera/camera2/internal/J;->v(Z)V

    .line 95
    .line 96
    .line 97
    :cond_0
    return-void

    .line 98
    :pswitch_7
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeView;

    .line 101
    .line 102
    iget-boolean v1, p0, LD/b;->b:Z

    .line 103
    .line 104
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeView;->a(Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeView;Z)V

    .line 105
    .line 106
    .line 107
    return-void

    .line 108
    :pswitch_8
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 111
    .line 112
    iget-boolean v1, p0, LD/b;->b:Z

    .line 113
    .line 114
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->c(Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;Z)V

    .line 115
    .line 116
    .line 117
    return-void

    .line 118
    :pswitch_9
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;

    .line 121
    .line 122
    iget-boolean v1, p0, LD/b;->b:Z

    .line 123
    .line 124
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;->c(Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV4View;Z)V

    .line 125
    .line 126
    .line 127
    return-void

    .line 128
    :pswitch_a
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 129
    .line 130
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;

    .line 131
    .line 132
    iget-boolean v1, p0, LD/b;->b:Z

    .line 133
    .line 134
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;->a(Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV3View;Z)V

    .line 135
    .line 136
    .line 137
    return-void

    .line 138
    :pswitch_b
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV2View;

    .line 141
    .line 142
    iget-boolean v1, p0, LD/b;->b:Z

    .line 143
    .line 144
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV2View;->a(Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV2View;Z)V

    .line 145
    .line 146
    .line 147
    return-void

    .line 148
    :pswitch_c
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 149
    .line 150
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeSimpleView;

    .line 151
    .line 152
    iget-boolean v1, p0, LD/b;->b:Z

    .line 153
    .line 154
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeSimpleView;->a(Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeSimpleView;Z)V

    .line 155
    .line 156
    .line 157
    return-void

    .line 158
    :pswitch_d
    iget-object v2, p0, LD/b;->c:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;

    .line 161
    .line 162
    iget-boolean v3, p0, LD/b;->b:Z

    .line 163
    .line 164
    if-eqz v3, :cond_1

    .line 165
    .line 166
    iget-object v3, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->c:Landroid/widget/EditText;

    .line 167
    .line 168
    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 169
    .line 170
    .line 171
    move-result-object v3

    .line 172
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v3

    .line 176
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 177
    .line 178
    .line 179
    move-result v3

    .line 180
    if-nez v3, :cond_1

    .line 181
    .line 182
    iget-object v3, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->g:Landroid/widget/ImageView;

    .line 183
    .line 184
    invoke-virtual {v3, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 185
    .line 186
    .line 187
    iget-object v1, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->i:Landroid/widget/ImageView;

    .line 188
    .line 189
    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 190
    .line 191
    .line 192
    iget-object v1, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->d:Landroid/widget/ImageView;

    .line 193
    .line 194
    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 195
    .line 196
    .line 197
    goto :goto_0

    .line 198
    :cond_1
    iget-object v3, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->g:Landroid/widget/ImageView;

    .line 199
    .line 200
    invoke-virtual {v3, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 201
    .line 202
    .line 203
    iget-object v3, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->i:Landroid/widget/ImageView;

    .line 204
    .line 205
    invoke-virtual {v3, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 206
    .line 207
    .line 208
    iget-object v3, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->d:Landroid/widget/ImageView;

    .line 209
    .line 210
    invoke-virtual {v3, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 211
    .line 212
    .line 213
    :goto_0
    iget-boolean v1, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->o:Z

    .line 214
    .line 215
    if-eqz v1, :cond_2

    .line 216
    .line 217
    iget-object v1, v2, Lcom/transsnet/palmpay/core/viewmodel/ModelEnterPhoneNumber1;->i:Landroid/widget/ImageView;

    .line 218
    .line 219
    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 220
    .line 221
    .line 222
    :cond_2
    return-void

    .line 223
    :pswitch_e
    iget-object v0, p0, LD/b;->c:Ljava/lang/Object;

    .line 224
    .line 225
    check-cast v0, Landroidx/core/view/w0;

    .line 226
    .line 227
    iget-boolean v1, p0, LD/b;->b:Z

    .line 228
    .line 229
    iget-object v0, v0, Landroidx/core/view/w0;->a:Lorg/chromium/support_lib_boundary/util/b;

    .line 230
    .line 231
    const/4 v2, 0x1

    .line 232
    if-eqz v1, :cond_3

    .line 233
    .line 234
    invoke-virtual {v0, v2}, Lorg/chromium/support_lib_boundary/util/b;->G(I)V

    .line 235
    .line 236
    .line 237
    goto :goto_1

    .line 238
    :cond_3
    invoke-virtual {v0, v2}, Lorg/chromium/support_lib_boundary/util/b;->k0(I)V

    .line 239
    .line 240
    .line 241
    :goto_1
    return-void

    .line 242
    :pswitch_f
    sget-object v0, Lcom/swmansion/rnscreens/ScreenFragment;->i:Lcom/swmansion/rnscreens/ScreenFragment$a;

    .line 243
    .line 244
    iget-boolean v0, p0, LD/b;->b:Z

    .line 245
    .line 246
    iget-object v2, p0, LD/b;->c:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast v2, Lcom/swmansion/rnscreens/ScreenFragment;

    .line 249
    .line 250
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 251
    .line 252
    .line 253
    if-eqz v0, :cond_4

    .line 254
    .line 255
    sget-object v0, LM7/v;->a:LM7/v;

    .line 256
    .line 257
    invoke-virtual {v2, v0, v2}, Lcom/swmansion/rnscreens/ScreenFragment;->dispatchLifecycleEvent(LM7/v;Lcom/swmansion/rnscreens/ScreenFragmentWrapper;)V

    .line 258
    .line 259
    .line 260
    const/high16 v0, 0x3f800000    # 1.0f

    .line 261
    .line 262
    invoke-virtual {v2, v0, v1}, Lcom/swmansion/rnscreens/ScreenFragment;->dispatchTransitionProgressEvent(FZ)V

    .line 263
    .line 264
    .line 265
    goto :goto_2

    .line 266
    :cond_4
    sget-object v0, LM7/v;->b:LM7/v;

    .line 267
    .line 268
    invoke-virtual {v2, v0, v2}, Lcom/swmansion/rnscreens/ScreenFragment;->dispatchLifecycleEvent(LM7/v;Lcom/swmansion/rnscreens/ScreenFragmentWrapper;)V

    .line 269
    .line 270
    .line 271
    const/4 v0, 0x0

    .line 272
    invoke-virtual {v2, v0, v1}, Lcom/swmansion/rnscreens/ScreenFragment;->dispatchTransitionProgressEvent(FZ)V

    .line 273
    .line 274
    .line 275
    :goto_2
    return-void

    .line 276
    :pswitch_10
    iget-object v2, p0, LD/b;->c:Ljava/lang/Object;

    .line 277
    .line 278
    check-cast v2, LD/d;

    .line 279
    .line 280
    iget-boolean v3, v2, LD/d;->a:Z

    .line 281
    .line 282
    iget-boolean v4, p0, LD/b;->b:Z

    .line 283
    .line 284
    if-ne v3, v4, :cond_5

    .line 285
    .line 286
    goto :goto_3

    .line 287
    :cond_5
    iput-boolean v4, v2, LD/d;->a:Z

    .line 288
    .line 289
    if-eqz v4, :cond_6

    .line 290
    .line 291
    iget-boolean v3, v2, LD/d;->b:Z

    .line 292
    .line 293
    if-eqz v3, :cond_7

    .line 294
    .line 295
    iget-object v3, v2, LD/d;->c:Ljava/lang/Object;

    .line 296
    .line 297
    check-cast v3, Landroidx/camera/camera2/internal/o;

    .line 298
    .line 299
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 300
    .line 301
    .line 302
    new-instance v4, Landroidx/camera/camera2/internal/k;

    .line 303
    .line 304
    invoke-direct {v4, v3, v1}, Landroidx/camera/camera2/internal/k;-><init>(Ljava/lang/Object;I)V

    .line 305
    .line 306
    .line 307
    invoke-static {v4}, LE/c;->y(Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;)Landroidx/concurrent/futures/m;

    .line 308
    .line 309
    .line 310
    move-result-object v3

    .line 311
    invoke-static {v3}, Landroidx/camera/core/impl/utils/futures/j;->e(Lcom/google/common/util/concurrent/ListenableFuture;)Lcom/google/common/util/concurrent/ListenableFuture;

    .line 312
    .line 313
    .line 314
    move-result-object v3

    .line 315
    new-instance v4, LAe/n;

    .line 316
    .line 317
    invoke-direct {v4, v2, v0}, LAe/n;-><init>(Ljava/lang/Object;I)V

    .line 318
    .line 319
    .line 320
    iget-object v0, v2, LD/d;->d:Ljava/lang/Object;

    .line 321
    .line 322
    check-cast v0, Landroidx/camera/core/impl/utils/executor/i;

    .line 323
    .line 324
    invoke-interface {v3, v4, v0}, Lcom/google/common/util/concurrent/ListenableFuture;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 325
    .line 326
    .line 327
    iput-boolean v1, v2, LD/d;->b:Z

    .line 328
    .line 329
    goto :goto_3

    .line 330
    :cond_6
    new-instance v0, LE/k;

    .line 331
    .line 332
    const-string v1, "The camera control has became inactive."

    .line 333
    .line 334
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 335
    .line 336
    .line 337
    iget-object v1, v2, LD/d;->g:Ljava/lang/Object;

    .line 338
    .line 339
    check-cast v1, Landroidx/concurrent/futures/k;

    .line 340
    .line 341
    if-eqz v1, :cond_7

    .line 342
    .line 343
    invoke-virtual {v1, v0}, Landroidx/concurrent/futures/k;->d(Ljava/lang/Throwable;)Z

    .line 344
    .line 345
    .line 346
    const/4 v0, 0x0

    .line 347
    iput-object v0, v2, LD/d;->g:Ljava/lang/Object;

    .line 348
    .line 349
    :cond_7
    :goto_3
    return-void

    .line 350
    nop

    .line 351
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
