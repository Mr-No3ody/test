.class public final LD/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/camera/core/ExtendableBuilder;


# instance fields
.field public final a:Landroidx/camera/core/impl/m0;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Landroidx/camera/core/impl/m0;->b()Landroidx/camera/core/impl/m0;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iput-object v0, p0, LD/e;->a:Landroidx/camera/core/impl/m0;

    .line 9
    .line 10
    return-void
.end method

.method public static b(Landroidx/camera/core/impl/Config;)LD/e;
    .locals 3

    .line 1
    new-instance v0, LD/e;

    .line 2
    .line 3
    invoke-direct {v0}, LD/e;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, LAd/c0;

    .line 7
    .line 8
    const/4 v2, 0x2

    .line 9
    invoke-direct {v1, v2, v0, p0}, LAd/c0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    const-string v2, "camera2.captureRequest.option."

    .line 13
    .line 14
    invoke-interface {p0, v2, v1}, Landroidx/camera/core/impl/Config;->findOptions(Ljava/lang/String;Landroidx/camera/core/impl/Config$OptionMatcher;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method


# virtual methods
.method public final a()Lorg/greenrobot/eventbus/f;
    .locals 3

    .line 1
    new-instance v0, Lorg/greenrobot/eventbus/f;

    .line 2
    .line 3
    iget-object v1, p0, LD/e;->a:Landroidx/camera/core/impl/m0;

    .line 4
    .line 5
    invoke-static {v1}, Landroidx/camera/core/impl/q0;->a(Landroidx/camera/core/impl/Config;)Landroidx/camera/core/impl/q0;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x2

    .line 10
    invoke-direct {v0, v1, v2}, Lorg/greenrobot/eventbus/f;-><init>(Ljava/lang/Object;I)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final bridge synthetic build()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, LD/e;->a()Lorg/greenrobot/eventbus/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final getMutableConfig()Landroidx/camera/core/impl/MutableConfig;
    .locals 1

    .line 1
    iget-object v0, p0, LD/e;->a:Landroidx/camera/core/impl/m0;

    .line 2
    .line 3
    return-object v0
.end method
