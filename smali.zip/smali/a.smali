.class public final synthetic La;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/callback/Argument2Callback;
.implements Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;
.implements Lcom/google/android/datatransport/runtime/synchronization/SynchronizationGuard$CriticalSection;
.implements Lcom/transsnet/palmpay/custom_view/interfac/OnItemClickListener;
.implements Landroidx/camera/video/internal/encoder/Encoder$SurfaceInput$OnSurfaceUpdateListener;
.implements Lcom/facebook/react/views/modal/ReactModalHostView$OnRequestCloseListener;
.implements Lcom/google/android/gms/tasks/Continuation;
.implements Lcom/google/android/gms/tasks/OnSuccessListener;
.implements Lcom/permissionx/guolindev/callback/RequestCallback;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LG/f;LE/v;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, La;->a:I

    sget-object v0, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La;->b:Ljava/lang/Object;

    iput-object p2, p0, La;->c:Ljava/lang/Object;

    iput-object v0, p0, La;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Landroid/app/Activity;Lcom/palmpay/lib/liveness/model/AuthenticationRequest;Lcom/palmpay/lib/liveness/LiveID$ILiveIDListener;)V
    .locals 1

    .line 2
    const/16 v0, 0x10

    iput v0, p0, La;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La;->c:Ljava/lang/Object;

    iput-object p2, p0, La;->b:Ljava/lang/Object;

    iput-object p3, p0, La;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Landroidx/camera/core/processing/f;LE/v;)V
    .locals 1

    .line 3
    const/16 v0, 0x8

    iput v0, p0, La;->a:I

    sget-object v0, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La;->b:Ljava/lang/Object;

    iput-object p2, p0, La;->c:Ljava/lang/Object;

    iput-object v0, p0, La;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Landroidx/concurrent/futures/m;Landroidx/camera/core/impl/utils/executor/i;Ljava/util/List;)V
    .locals 1

    .line 4
    const/4 v0, 0x7

    iput v0, p0, La;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La;->b:Ljava/lang/Object;

    iput-object p2, p0, La;->c:Ljava/lang/Object;

    check-cast p3, Ljava/util/List;

    iput-object p3, p0, La;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 5
    iput p2, p0, La;->a:I

    iput-object p1, p0, La;->b:Ljava/lang/Object;

    iput-object p3, p0, La;->c:Ljava/lang/Object;

    iput-object p4, p0, La;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public attachCompleter(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, La;->a:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroidx/camera/core/processing/f;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v1, LDa/g;

    .line 14
    .line 15
    sget-object v2, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 16
    .line 17
    iget-object v2, p0, La;->c:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, LE/v;

    .line 20
    .line 21
    invoke-direct {v1, v0, v2, p1}, LDa/g;-><init>(Landroidx/camera/core/processing/f;LE/v;Landroidx/concurrent/futures/k;)V

    .line 22
    .line 23
    .line 24
    new-instance p1, Landroidx/camera/camera2/internal/h;

    .line 25
    .line 26
    const/4 v2, 0x0

    .line 27
    invoke-direct {p1, v2}, Landroidx/camera/camera2/internal/h;-><init>(I)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1, p1}, Landroidx/camera/core/processing/f;->b(Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    .line 31
    .line 32
    .line 33
    const-string p1, "Init GlRenderer"

    .line 34
    .line 35
    return-object p1

    .line 36
    :sswitch_0
    new-instance v0, LW8/o;

    .line 37
    .line 38
    iget-object v1, p0, La;->b:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v1, Landroidx/concurrent/futures/m;

    .line 41
    .line 42
    const/16 v2, 0xf

    .line 43
    .line 44
    invoke-direct {v0, v1, v2}, LW8/o;-><init>(Ljava/lang/Object;I)V

    .line 45
    .line 46
    .line 47
    iget-object v2, p0, La;->c:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v2, Landroidx/camera/core/impl/utils/executor/i;

    .line 50
    .line 51
    invoke-virtual {p1, v0, v2}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 52
    .line 53
    .line 54
    new-instance v0, Lm6/j;

    .line 55
    .line 56
    const/16 v3, 0xb

    .line 57
    .line 58
    invoke-direct {v0, p1, v3}, Lm6/j;-><init>(Ljava/lang/Object;I)V

    .line 59
    .line 60
    .line 61
    new-instance p1, Landroidx/camera/core/impl/utils/futures/i;

    .line 62
    .line 63
    const/4 v3, 0x0

    .line 64
    invoke-direct {p1, v3, v1, v0}, Landroidx/camera/core/impl/utils/futures/i;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v1, p1, v2}, Landroidx/concurrent/futures/m;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 68
    .line 69
    .line 70
    new-instance p1, Ljava/lang/StringBuilder;

    .line 71
    .line 72
    const-string/jumbo v0, "surfaceList["

    .line 73
    .line 74
    .line 75
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    iget-object v0, p0, La;->d:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, Ljava/util/List;

    .line 81
    .line 82
    const-string v1, "]"

    .line 83
    .line 84
    invoke-static {p1, v0, v1}, LN8/q0;->o(Ljava/lang/StringBuilder;Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    return-object p1

    .line 89
    :sswitch_1
    const-string v0, "completer"

    .line 90
    .line 91
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 95
    .line 96
    const/4 v1, 0x0

    .line 97
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 98
    .line 99
    .line 100
    new-instance v1, LV0/u;

    .line 101
    .line 102
    const/4 v2, 0x0

    .line 103
    invoke-direct {v1, v0, v2}, LV0/u;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;I)V

    .line 104
    .line 105
    .line 106
    sget-object v2, LV0/q;->a:LV0/q;

    .line 107
    .line 108
    invoke-virtual {p1, v1, v2}, Landroidx/concurrent/futures/k;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 109
    .line 110
    .line 111
    new-instance v1, LDa/h;

    .line 112
    .line 113
    iget-object v2, p0, La;->d:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v2, Lkotlin/jvm/functions/Function0;

    .line 116
    .line 117
    const/16 v3, 0xc

    .line 118
    .line 119
    invoke-direct {v1, v0, v3, p1, v2}, LDa/h;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    iget-object p1, p0, La;->b:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast p1, Landroidx/work/impl/utils/taskexecutor/SerialExecutor;

    .line 125
    .line 126
    invoke-interface {p1, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 127
    .line 128
    .line 129
    iget-object p1, p0, La;->c:Ljava/lang/Object;

    .line 130
    .line 131
    check-cast p1, Ljava/lang/String;

    .line 132
    .line 133
    return-object p1

    .line 134
    :sswitch_2
    iget-object v0, p0, La;->b:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast v0, LG/f;

    .line 137
    .line 138
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 139
    .line 140
    .line 141
    new-instance v1, LDa/g;

    .line 142
    .line 143
    sget-object v2, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 144
    .line 145
    iget-object v2, p0, La;->c:Ljava/lang/Object;

    .line 146
    .line 147
    check-cast v2, LE/v;

    .line 148
    .line 149
    invoke-direct {v1, v0, v2, p1}, LDa/g;-><init>(LG/f;LE/v;Landroidx/concurrent/futures/k;)V

    .line 150
    .line 151
    .line 152
    new-instance p1, Landroidx/camera/camera2/internal/h;

    .line 153
    .line 154
    const/4 v2, 0x0

    .line 155
    invoke-direct {p1, v2}, Landroidx/camera/camera2/internal/h;-><init>(I)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v0, v1, p1}, LG/f;->b(Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    .line 159
    .line 160
    .line 161
    const-string p1, "Init GlRenderer"

    .line 162
    .line 163
    return-object p1

    .line 164
    nop

    .line 165
    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_2
        0x6 -> :sswitch_1
        0x7 -> :sswitch_0
    .end sparse-switch
.end method

.method public execute()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, La;->c:Ljava/lang/Object;

    check-cast v0, Lcom/google/android/datatransport/runtime/TransportContext;

    iget-object v1, p0, La;->b:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/datatransport/runtime/scheduling/DefaultScheduler;

    iget-object v2, p0, La;->d:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/datatransport/runtime/EventInternal;

    invoke-static {v1, v0, v2}, Lcom/google/android/datatransport/runtime/scheduling/DefaultScheduler;->a(Lcom/google/android/datatransport/runtime/scheduling/DefaultScheduler;Lcom/google/android/datatransport/runtime/TransportContext;Lcom/google/android/datatransport/runtime/EventInternal;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 6

    .line 1
    iget v0, p0, La;->a:I

    .line 2
    .line 3
    check-cast p1, Ljava/lang/Integer;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    move-object v3, p2

    .line 13
    check-cast v3, Landroid/content/Intent;

    .line 14
    .line 15
    iget-object p2, p0, La;->c:Ljava/lang/Object;

    .line 16
    .line 17
    move-object v4, p2

    .line 18
    check-cast v4, Ljava/lang/ref/WeakReference;

    .line 19
    .line 20
    const/4 p2, -0x1

    .line 21
    if-ne p1, p2, :cond_0

    .line 22
    .line 23
    iget-object p1, p0, La;->b:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast p1, Ljava/lang/ref/WeakReference;

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    move-object v2, p1

    .line 32
    check-cast v2, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 33
    .line 34
    if-eqz v2, :cond_1

    .line 35
    .line 36
    const/4 p1, -0x4

    .line 37
    invoke-static {p1}, LPa/T;->b(I)Ljava/util/concurrent/ExecutorService;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    new-instance v0, LDa/g;

    .line 42
    .line 43
    iget-object p2, p0, La;->d:Ljava/lang/Object;

    .line 44
    .line 45
    move-object v1, p2

    .line 46
    check-cast v1, Ljava/io/File;

    .line 47
    .line 48
    const/4 v5, 0x4

    .line 49
    invoke-direct/range {v0 .. v5}, LDa/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 50
    .line 51
    .line 52
    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 53
    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_0
    invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    check-cast p1, Lkotlin/jvm/functions/Function1;

    .line 61
    .line 62
    if-eqz p1, :cond_1

    .line 63
    .line 64
    const/4 p2, 0x0

    .line 65
    invoke-interface {p1, p2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    :cond_1
    :goto_0
    return-void

    .line 69
    :pswitch_0
    check-cast p2, Landroid/content/Intent;

    .line 70
    .line 71
    iget-object v0, p0, La;->b:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v0, LCommonFileUploadBridge;

    .line 74
    .line 75
    iget-object v1, p0, La;->c:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v1, Landroid/app/Activity;

    .line 78
    .line 79
    iget-object v2, p0, La;->d:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v2, LCommonFileUploadBridge$FileUploadParam;

    .line 82
    .line 83
    invoke-static {v0, v1, v2, p1, p2}, LCommonFileUploadBridge;->c(LCommonFileUploadBridge;Landroid/app/Activity;LCommonFileUploadBridge$FileUploadParam;ILandroid/content/Intent;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 4

    .line 1
    const-string v0, "<unused var>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    iget-object p1, p0, La;->b:Ljava/lang/Object;

    check-cast p1, Lda/c0;

    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    move-result-object p2

    check-cast p2, Ljava/util/Collection;

    invoke-interface {p2}, Ljava/util/Collection;->size()I

    move-result p2

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    if-ge v1, p2, :cond_1

    .line 3
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    if-ne v1, p3, :cond_0

    const/4 v3, 0x1

    goto :goto_1

    :cond_0
    move v3, v0

    .line 4
    :goto_1
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->setSelected(Z)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 5
    :cond_1
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 6
    iget-object p1, p0, La;->c:Ljava/lang/Object;

    check-cast p1, LGe/e;

    iget-object p2, p1, LGe/e;->a:LHe/x;

    if-eqz p2, :cond_2

    .line 7
    iget-object p1, p1, LGe/e;->b:Ljava/util/ArrayList;

    .line 8
    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    invoke-virtual {p2, p1}, LHe/x;->onItemSelect(Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;)V

    .line 9
    :cond_2
    iget-object p1, p0, La;->d:Ljava/lang/Object;

    check-cast p1, LGe/f;

    invoke-virtual {p1}, Landroid/widget/PopupWindow;->dismiss()V

    return-void
.end method

.method public onItemClick(Ljava/lang/Object;)V
    .locals 4

    check-cast p1, Lcom/transsnet/palmpay/managemoney/bean/PayoutOption;

    .line 10
    iget-object v0, p0, La;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;

    iput-object p1, v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;->Q:Lcom/transsnet/palmpay/managemoney/bean/PayoutOption;

    .line 11
    const-string v1, "KEY_IS_SHOW_CASHBOX_NEWER_AGREE"

    const-string v2, "key"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    invoke-static {v1}, Le1/a;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance(Ljava/lang/String;)Lcom/transsnet/palmpay/util/SPUtils;

    move-result-object v2

    invoke-static {}, Lya/a;->d()Lya/a;

    move-result-object v3

    invoke-virtual {v3, v1}, Lya/a;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lcom/transsnet/palmpay/util/SPUtils;->getBoolean(Ljava/lang/String;)Z

    move-result v1

    .line 13
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/PayoutOption;->getType()I

    move-result v2

    const/4 v3, 0x2

    if-ne v2, v3, :cond_0

    iget-object v2, v0, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;->L:Ljava/lang/Boolean;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    if-nez v1, :cond_0

    .line 14
    new-instance p1, LM7/s;

    const/4 v1, 0x7

    invoke-direct {p1, v0, v1}, LM7/s;-><init>(Ljava/lang/Object;I)V

    iget-object v0, p0, La;->c:Ljava/lang/Object;

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    const-wide/16 v1, 0xfa

    invoke-virtual {v0, p1, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 15
    :cond_0
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    move-result-object v1

    instance-of v1, v1, Lcom/transsnet/palmpay/core/base/BaseActivity;

    if-eqz v1, :cond_1

    .line 16
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type com.transsnet.palmpay.core.base.BaseActivity"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Lcom/transsnet/palmpay/core/base/BaseActivity;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 17
    iget-object v1, p0, La;->d:Ljava/lang/Object;

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/4 v2, 0x4

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 18
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseMvvmDialogFragment;->j()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    move-result-object v0

    check-cast v0, Lcom/transsnet/palmpay/managemoney/ui/viewmodel/CashBoxViewModel;

    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/PayoutOption;->getType()I

    move-result p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    new-instance v1, LQc/K;

    const/4 v2, 0x0

    invoke-direct {v1, p1, v2}, LQc/K;-><init>(ILkotlin/coroutines/Continuation;)V

    const/4 p1, 0x0

    const/16 v2, 0x1c

    iget-object v3, v0, Lcom/transsnet/palmpay/managemoney/ui/viewmodel/CashBoxViewModel;->p0:Lcom/transsnet/palmpay/core/base/l;

    invoke-static {v0, v1, v3, p1, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    :cond_1
    return-void
.end method

.method public onRequestClose(Landroid/content/DialogInterface;)V
    .locals 3

    .line 1
    iget-object v0, p0, La;->d:Ljava/lang/Object;

    check-cast v0, Lcom/facebook/react/views/modal/ReactModalHostView;

    iget-object v1, p0, La;->b:Ljava/lang/Object;

    check-cast v1, Lcom/facebook/react/uimanager/events/EventDispatcher;

    iget-object v2, p0, La;->c:Ljava/lang/Object;

    check-cast v2, Lcom/facebook/react/uimanager/ThemedReactContext;

    invoke-static {v1, v2, v0, p1}, Lcom/facebook/react/views/modal/ReactModalHostManager;->b(Lcom/facebook/react/uimanager/events/EventDispatcher;Lcom/facebook/react/uimanager/ThemedReactContext;Lcom/facebook/react/views/modal/ReactModalHostView;Landroid/content/DialogInterface;)V

    return-void
.end method

.method public onResult(ZLjava/util/List;Ljava/util/List;)V
    .locals 8

    .line 1
    iget-object v0, p0, La;->c:Ljava/lang/Object;

    .line 2
    .line 3
    iget-object v1, p0, La;->d:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, La;->b:Ljava/lang/Object;

    .line 6
    .line 7
    iget v3, p0, La;->a:I

    .line 8
    .line 9
    packed-switch v3, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    const-string v3, "<unused var>"

    .line 13
    .line 14
    invoke-static {p2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-static {p3, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    check-cast v2, Lcom/palmpay/lib/liveness/model/AuthenticationRequest;

    .line 21
    .line 22
    check-cast v1, Lcom/palmpay/lib/liveness/LiveID$ILiveIDListener;

    .line 23
    .line 24
    if-eqz p1, :cond_0

    .line 25
    .line 26
    sget-object p1, Lp6/p;->a:Lp6/p;

    .line 27
    .line 28
    check-cast v0, Landroid/app/Activity;

    .line 29
    .line 30
    invoke-static {v0, v2, v1}, Lp6/p;->b(Landroid/app/Activity;Lcom/palmpay/lib/liveness/model/AuthenticationRequest;Lcom/palmpay/lib/liveness/LiveID$ILiveIDListener;)V

    .line 31
    .line 32
    .line 33
    goto :goto_1

    .line 34
    :cond_0
    sget-object p1, LD6/f;->f:LD6/f;

    .line 35
    .line 36
    iget-object p2, p1, LD6/f;->a:Ljava/lang/String;

    .line 37
    .line 38
    const/4 p3, 0x0

    .line 39
    iget-object v0, p1, LD6/f;->b:Ljava/lang/String;

    .line 40
    .line 41
    invoke-interface {v1, p2, v0, p3}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDListener;->onInterrupted(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    sget-object p2, Lp6/p;->d:Lr6/a;

    .line 45
    .line 46
    if-eqz p2, :cond_2

    .line 47
    .line 48
    iget-object p2, p2, Lr6/a;->e:Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;

    .line 49
    .line 50
    if-eqz p2, :cond_2

    .line 51
    .line 52
    sget-object p3, Lv6/e;->g:Lv6/d;

    .line 53
    .line 54
    iget-object v1, p3, Lv6/d;->a:Ljava/lang/String;

    .line 55
    .line 56
    new-instance v3, Lkotlin/Pair;

    .line 57
    .line 58
    iget-object p3, p3, Lv6/d;->b:Ljava/lang/String;

    .line 59
    .line 60
    const-string v4, "event_desc"

    .line 61
    .line 62
    invoke-direct {v3, v4, p3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v2}, Lcom/palmpay/lib/liveness/model/AuthenticationRequest;->getScene()Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object p3

    .line 69
    if-eqz p3, :cond_1

    .line 70
    .line 71
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 72
    .line 73
    .line 74
    move-result p3

    .line 75
    goto :goto_0

    .line 76
    :cond_1
    const/4 p3, -0x1

    .line 77
    :goto_0
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 78
    .line 79
    .line 80
    move-result-object p3

    .line 81
    new-instance v2, Lkotlin/Pair;

    .line 82
    .line 83
    const-string/jumbo v4, "scene"

    .line 84
    .line 85
    .line 86
    invoke-direct {v2, v4, p3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    new-instance p3, Lkotlin/Pair;

    .line 90
    .line 91
    iget-object p1, p1, LD6/f;->a:Ljava/lang/String;

    .line 92
    .line 93
    const-string v4, "code"

    .line 94
    .line 95
    invoke-direct {p3, v4, p1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    new-instance p1, Lkotlin/Pair;

    .line 99
    .line 100
    const-string v4, "msg"

    .line 101
    .line 102
    invoke-direct {p1, v4, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    filled-new-array {v3, v2, p3, p1}, [Lkotlin/Pair;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    invoke-static {p1}, Lkotlin/collections/G;->h([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-interface {p2, v1, p1}, Lcom/palmpay/lib/liveness/LiveID$ILiveIDMonitor;->report(Ljava/lang/String;Ljava/util/Map;)V

    .line 114
    .line 115
    .line 116
    :cond_2
    :goto_1
    return-void

    .line 117
    :pswitch_0
    move-object v3, v0

    .line 118
    check-cast v3, Landroidx/appcompat/app/o;

    .line 119
    .line 120
    check-cast v2, Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge;

    .line 121
    .line 122
    move-object v4, v1

    .line 123
    check-cast v4, Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge$PhotoUploadParam;

    .line 124
    .line 125
    move v5, p1

    .line 126
    move-object v6, p2

    .line 127
    move-object v7, p3

    .line 128
    invoke-static/range {v2 .. v7}, Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge;->g(Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge;Landroidx/appcompat/app/o;Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge$PhotoUploadParam;ZLjava/util/List;Ljava/util/List;)V

    .line 129
    .line 130
    .line 131
    return-void

    .line 132
    nop

    .line 133
    :pswitch_data_0
    .packed-switch 0xf
        :pswitch_0
    .end packed-switch
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Lcom/google/firebase/remoteconfig/internal/ConfigContainer;

    iget-object v0, p0, La;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/internal/rollouts/RolloutsStateSubscriptionsHandler;

    iget-object v1, p0, La;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/tasks/Task;

    iget-object v2, p0, La;->d:Ljava/lang/Object;

    check-cast v2, Lcom/google/firebase/remoteconfig/interop/rollouts/RolloutsStateSubscriber;

    invoke-static {v0, v1, v2, p1}, Lcom/google/firebase/remoteconfig/internal/rollouts/RolloutsStateSubscriptionsHandler;->a(Lcom/google/firebase/remoteconfig/internal/rollouts/RolloutsStateSubscriptionsHandler;Lcom/google/android/gms/tasks/Task;Lcom/google/firebase/remoteconfig/interop/rollouts/RolloutsStateSubscriber;Lcom/google/firebase/remoteconfig/internal/ConfigContainer;)V

    return-void
.end method

.method public onSurfaceUpdate(Landroid/view/Surface;)V
    .locals 7

    .line 1
    iget-object v0, p0, La;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/camera/video/E;

    .line 4
    .line 5
    iget v1, v0, Landroidx/camera/video/E;->i:I

    .line 6
    .line 7
    invoke-static {v1}, Landroidx/camera/camera2/internal/F;->i(I)I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    iget-object v2, p0, La;->c:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v2, Landroidx/concurrent/futures/k;

    .line 14
    .line 15
    const/4 v3, 0x0

    .line 16
    const-string v4, "VideoEncoderSession"

    .line 17
    .line 18
    if-eqz v1, :cond_5

    .line 19
    .line 20
    const/4 v5, 0x1

    .line 21
    const/4 v6, 0x4

    .line 22
    if-eq v1, v5, :cond_3

    .line 23
    .line 24
    const/4 v5, 0x2

    .line 25
    if-eq v1, v5, :cond_5

    .line 26
    .line 27
    const/4 v5, 0x3

    .line 28
    if-eq v1, v5, :cond_1

    .line 29
    .line 30
    if-ne v1, v6, :cond_0

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 34
    .line 35
    new-instance v1, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    const-string v2, "State "

    .line 38
    .line 39
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    iget v0, v0, Landroidx/camera/video/E;->i:I

    .line 43
    .line 44
    invoke-static {v0}, Landroidx/camera/video/u;->z(I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    const-string v0, " is not handled"

    .line 52
    .line 53
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    throw p1

    .line 64
    :cond_1
    iget-object v1, v0, Landroidx/camera/video/E;->h:Landroidx/camera/video/o;

    .line 65
    .line 66
    if-eqz v1, :cond_2

    .line 67
    .line 68
    iget-object v1, v0, Landroidx/camera/video/E;->g:Landroidx/camera/core/impl/utils/executor/i;

    .line 69
    .line 70
    if-eqz v1, :cond_2

    .line 71
    .line 72
    new-instance v2, Landroidx/biometric/g;

    .line 73
    .line 74
    const/16 v3, 0x1a

    .line 75
    .line 76
    invoke-direct {v2, v3, v0, p1}, Landroidx/biometric/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v1, v2}, Landroidx/camera/core/impl/utils/executor/i;->execute(Ljava/lang/Runnable;)V

    .line 80
    .line 81
    .line 82
    :cond_2
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    invoke-static {v4}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :cond_3
    iget-object v1, p0, La;->d:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast v1, LE/m0;

    .line 92
    .line 93
    invoke-virtual {v1}, LE/m0;->a()Z

    .line 94
    .line 95
    .line 96
    move-result v5

    .line 97
    if-eqz v5, :cond_4

    .line 98
    .line 99
    const-string p1, "EMPTY"

    .line 100
    .line 101
    invoke-static {v1, p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    invoke-static {v4}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    invoke-virtual {v2, v3}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    invoke-virtual {v0}, Landroidx/camera/video/E;->a()V

    .line 111
    .line 112
    .line 113
    return-void

    .line 114
    :cond_4
    iput-object p1, v0, Landroidx/camera/video/E;->e:Landroid/view/Surface;

    .line 115
    .line 116
    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    invoke-static {v4}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    new-instance v3, Landroidx/camera/core/processing/o;

    .line 123
    .line 124
    const/4 v4, 0x1

    .line 125
    invoke-direct {v3, v0, v4}, Landroidx/camera/core/processing/o;-><init>(Ljava/lang/Object;I)V

    .line 126
    .line 127
    .line 128
    iget-object v4, v0, Landroidx/camera/video/E;->b:Landroidx/camera/core/impl/utils/executor/i;

    .line 129
    .line 130
    invoke-virtual {v1, p1, v4, v3}, LE/m0;->b(Landroid/view/Surface;Ljava/util/concurrent/Executor;Landroidx/core/util/Consumer;)V

    .line 131
    .line 132
    .line 133
    iput v6, v0, Landroidx/camera/video/E;->i:I

    .line 134
    .line 135
    iget-object p1, v0, Landroidx/camera/video/E;->d:Landroidx/camera/video/internal/encoder/Encoder;

    .line 136
    .line 137
    invoke-virtual {v2, p1}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    return-void

    .line 141
    :cond_5
    :goto_0
    invoke-static {v4}, Lj8/f;->G(Ljava/lang/String;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    invoke-virtual {v2, v3}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Object;)Z

    .line 145
    .line 146
    .line 147
    return-void
.end method

.method public then(Lcom/google/android/gms/tasks/Task;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, La;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, La;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/internal/ConfigRealtimeHttpClient;

    iget-object v1, p0, La;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/tasks/Task;

    iget-object v2, p0, La;->d:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/tasks/Task;

    invoke-static {v0, v1, v2, p1}, Lcom/google/firebase/remoteconfig/internal/ConfigRealtimeHttpClient;->b(Lcom/google/firebase/remoteconfig/internal/ConfigRealtimeHttpClient;Lcom/google/android/gms/tasks/Task;Lcom/google/android/gms/tasks/Task;Lcom/google/android/gms/tasks/Task;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    return-object p1

    :pswitch_0
    iget-object v0, p0, La;->b:Ljava/lang/Object;

    check-cast v0, Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;

    iget-object v1, p0, La;->c:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/tasks/Task;

    iget-object v2, p0, La;->d:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/tasks/Task;

    invoke-static {v0, v1, v2, p1}, Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;->i(Lcom/google/firebase/remoteconfig/FirebaseRemoteConfig;Lcom/google/android/gms/tasks/Task;Lcom/google/android/gms/tasks/Task;Lcom/google/android/gms/tasks/Task;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    return-object p1

    :pswitch_1
    iget-object v0, p0, La;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    iget-object v1, p0, La;->d:Ljava/lang/Object;

    check-cast v1, Lcom/google/android/gms/tasks/CancellationTokenSource;

    iget-object v2, p0, La;->b:Ljava/lang/Object;

    check-cast v2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-static {v2, v0, v1, p1}, Lcom/google/firebase/crashlytics/internal/concurrency/CrashlyticsTasks;->a(Lcom/google/android/gms/tasks/TaskCompletionSource;Ljava/util/concurrent/atomic/AtomicBoolean;Lcom/google/android/gms/tasks/CancellationTokenSource;Lcom/google/android/gms/tasks/Task;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    return-object p1

    :pswitch_data_0
    .packed-switch 0xb
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
