.class public final LF4/m;
.super LF4/g;
.source "SourceFile"


# instance fields
.field public g:Landroid/graphics/Paint;

.field public h:Landroid/graphics/Paint;

.field public i:Landroid/text/TextPaint;

.field public j:Landroid/graphics/Paint;

.field public k:Ljava/lang/ref/WeakReference;

.field public l:Landroid/graphics/Canvas;


# virtual methods
.method public final D()V
    .locals 0

    .line 1
    return-void
.end method
