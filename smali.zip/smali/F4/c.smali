.class public abstract LF4/c;
.super LF4/g;
.source "SourceFile"
