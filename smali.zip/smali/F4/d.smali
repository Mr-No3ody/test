.class public final LF4/d;
.super LF4/c;
.source "SourceFile"


# virtual methods
.method public final D()V
    .locals 0

    .line 1
    return-void
.end method
