.class public final LF4/n;
.super LF4/k;
.source "SourceFile"


# virtual methods
.method public final D()V
    .locals 0

    .line 1
    return-void
.end method
