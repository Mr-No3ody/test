.class public final LF4/e;
.super LF4/l;
.source "SourceFile"


# instance fields
.field public final synthetic g:I


# direct methods
.method public synthetic constructor <init>(Ly4/a;LG4/j;I)V
    .locals 0

    .line 1
    iput p3, p0, LF4/e;->g:I

    invoke-direct {p0, p1, p2}, LF4/l;-><init>(Ly4/a;LG4/j;)V

    return-void
.end method

.method private final E()V
    .locals 0

    .line 1
    return-void
.end method

.method private final F()V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final D()V
    .locals 1

    .line 1
    iget v0, p0, LF4/e;->g:I

    return-void
.end method
