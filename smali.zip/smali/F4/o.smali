.class public LF4/o;
.super LF4/a;
.source "SourceFile"


# direct methods
.method public constructor <init>(LG4/j;LA4/f;LG4/g;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p3, p2}, LF4/a;-><init>(LG4/j;LG4/g;LA4/a;)V

    .line 2
    .line 3
    .line 4
    new-instance p1, Landroid/graphics/Path;

    .line 5
    .line 6
    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    .line 7
    .line 8
    .line 9
    new-instance p1, Landroid/graphics/RectF;

    .line 10
    .line 11
    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    .line 12
    .line 13
    .line 14
    new-instance p1, Landroid/graphics/RectF;

    .line 15
    .line 16
    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    .line 17
    .line 18
    .line 19
    new-instance p1, Landroid/graphics/Path;

    .line 20
    .line 21
    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    .line 22
    .line 23
    .line 24
    iget-object p1, p0, LF4/a;->d:Landroid/graphics/Paint;

    .line 25
    .line 26
    const/high16 p2, -0x1000000

    .line 27
    .line 28
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 29
    .line 30
    .line 31
    iget-object p1, p0, LF4/a;->d:Landroid/graphics/Paint;

    .line 32
    .line 33
    sget-object p2, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    .line 34
    .line 35
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 36
    .line 37
    .line 38
    iget-object p1, p0, LF4/a;->d:Landroid/graphics/Paint;

    .line 39
    .line 40
    const/high16 p2, 0x41200000    # 10.0f

    .line 41
    .line 42
    invoke-static {p2}, LG4/i;->b(F)F

    .line 43
    .line 44
    .line 45
    move-result p2

    .line 46
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 47
    .line 48
    .line 49
    return-void
.end method
