.class public final LF4/j;
.super LF4/k;
.source "SourceFile"


# instance fields
.field public g:Ljava/lang/ref/WeakReference;

.field public h:Landroid/graphics/Canvas;


# virtual methods
.method public final D()V
    .locals 0

    .line 1
    return-void
.end method
