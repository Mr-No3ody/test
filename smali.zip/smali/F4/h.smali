.class public final LF4/h;
.super LF4/b;
.source "SourceFile"


# virtual methods
.method public final D()V
    .locals 1

    .line 1
    iget-object v0, p0, LF4/b;->g:Lcom/github/mikephil/charting/charts/BarChart;

    .line 2
    .line 3
    invoke-interface {v0}, Lcom/github/mikephil/charting/interfaces/dataprovider/BarDataProvider;->getBarData()LB4/a;

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    throw v0
.end method
