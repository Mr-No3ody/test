.class public final LF4/r;
.super LF4/q;
.source "SourceFile"


# direct methods
.method public constructor <init>(LG4/j;LA4/h;LG4/g;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2, p3}, LF4/q;-><init>(LG4/j;LA4/h;LG4/g;)V

    .line 2
    .line 3
    .line 4
    new-instance p1, Landroid/graphics/Path;

    .line 5
    .line 6
    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    .line 7
    .line 8
    .line 9
    new-instance p1, Landroid/graphics/Path;

    .line 10
    .line 11
    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    .line 12
    .line 13
    .line 14
    iget-object p1, p0, LF4/a;->e:Landroid/graphics/Paint;

    .line 15
    .line 16
    sget-object p2, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method
