.class public abstract LF4/l;
.super LF4/c;
.source "SourceFile"


# direct methods
.method public constructor <init>(Ly4/a;LG4/j;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LF4/g;-><init>(Ly4/a;LG4/j;)V

    .line 2
    .line 3
    .line 4
    new-instance p1, Landroid/graphics/Path;

    .line 5
    .line 6
    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method
