.class public final LM2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/fresco/animation/bitmap/BitmapFrameCache;


# virtual methods
.method public final clear()V
    .locals 0

    .line 1
    return-void
.end method

.method public final contains(I)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public final getBitmapToReuseForFrame(III)Lcom/facebook/common/references/CloseableReference;
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return-object p1
.end method

.method public final getCachedFrame(I)Lcom/facebook/common/references/CloseableReference;
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return-object p1
.end method

.method public final getFallbackFrame(I)Lcom/facebook/common/references/CloseableReference;
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return-object p1
.end method

.method public final getSizeInBytes()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final onFramePrepared(ILcom/facebook/common/references/CloseableReference;I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onFrameRendered(ILcom/facebook/common/references/CloseableReference;I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final setFrameCacheListener(Lcom/facebook/fresco/animation/bitmap/BitmapFrameCache$FrameCacheListener;)V
    .locals 0

    .line 1
    return-void
.end method
