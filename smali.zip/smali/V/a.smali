.class public final LV/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static coordinatorLayoutStyle:I = 0x7f0401fa

.field public static keylines:I = 0x7f0405a6

.field public static layout_anchor:I = 0x7f0405bc

.field public static layout_anchorGravity:I = 0x7f0405bd

.field public static layout_behavior:I = 0x7f0405be

.field public static layout_dodgeInsetEdges:I = 0x7f0405f2

.field public static layout_insetEdge:I = 0x7f040600

.field public static layout_keyline:I = 0x7f040601

.field public static statusBarBackground:I = 0x7f0408ed


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
