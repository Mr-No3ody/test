.class public final LV/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static Widget_Support_CoordinatorLayout:I = 0x7f1505cb


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
