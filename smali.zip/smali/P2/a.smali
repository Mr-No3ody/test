.class public final LP2/a;
.super Landroid/graphics/drawable/Drawable;
.source "SourceFile"

# interfaces
.implements Landroid/graphics/drawable/Animatable;
.implements Lcom/facebook/drawable/base/DrawableWithCaches;


# static fields
.field public static final B:LZ4/a;


# instance fields
.field public final A:LB5/c;

.field public final a:LK2/a;

.field public final b:LR2/a;

.field public volatile c:Z

.field public d:J

.field public e:J

.field public f:J

.field public g:I

.field public i:J

.field public j:J

.field public o:I

.field public final p:J

.field public t:I

.field public volatile v:Lcom/facebook/fresco/animation/drawable/AnimationListener;

.field public w:Lcom/facebook/drawee/drawable/d;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LZ4/a;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, v1}, LZ4/a;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LP2/a;->B:LZ4/a;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(LK2/a;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 2
    .line 3
    .line 4
    const-wide/16 v0, 0x8

    .line 5
    .line 6
    iput-wide v0, p0, LP2/a;->p:J

    .line 7
    .line 8
    sget-object v0, LP2/a;->B:LZ4/a;

    .line 9
    .line 10
    iput-object v0, p0, LP2/a;->v:Lcom/facebook/fresco/animation/drawable/AnimationListener;

    .line 11
    .line 12
    new-instance v0, LB5/c;

    .line 13
    .line 14
    const/16 v1, 0xf

    .line 15
    .line 16
    invoke-direct {v0, p0, v1}, LB5/c;-><init>(Ljava/lang/Object;I)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, LP2/a;->A:LB5/c;

    .line 20
    .line 21
    iput-object p1, p0, LP2/a;->a:LK2/a;

    .line 22
    .line 23
    new-instance v0, LR2/a;

    .line 24
    .line 25
    invoke-direct {v0, p1}, LR2/a;-><init>(Lcom/facebook/fresco/animation/backend/AnimationBackend;)V

    .line 26
    .line 27
    .line 28
    iput-object v0, p0, LP2/a;->b:LR2/a;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .locals 8

    .line 1
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    iget-object v0, p0, LP2/a;->b:LR2/a;

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    goto/16 :goto_3

    .line 10
    .line 11
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    iget-boolean v2, p0, LP2/a;->c:Z

    .line 16
    .line 17
    if-eqz v2, :cond_1

    .line 18
    .line 19
    iget-wide v2, p0, LP2/a;->d:J

    .line 20
    .line 21
    sub-long v2, v0, v2

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    iget-wide v2, p0, LP2/a;->e:J

    .line 25
    .line 26
    const-wide/16 v4, 0x0

    .line 27
    .line 28
    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(JJ)J

    .line 29
    .line 30
    .line 31
    move-result-wide v2

    .line 32
    :goto_0
    iget-object v4, p0, LP2/a;->b:LR2/a;

    .line 33
    .line 34
    iget-wide v5, p0, LP2/a;->e:J

    .line 35
    .line 36
    invoke-virtual {v4, v2, v3, v5, v6}, LR2/a;->getFrameNumberToRender(JJ)I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    const/4 v5, 0x0

    .line 41
    const/4 v6, -0x1

    .line 42
    if-ne v4, v6, :cond_2

    .line 43
    .line 44
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 45
    .line 46
    iget-object v0, v0, LK2/a;->a:LL2/a;

    .line 47
    .line 48
    invoke-virtual {v0}, LL2/a;->getFrameCount()I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    add-int/lit8 v4, v0, -0x1

    .line 53
    .line 54
    iget-object v0, p0, LP2/a;->v:Lcom/facebook/fresco/animation/drawable/AnimationListener;

    .line 55
    .line 56
    invoke-interface {v0, p0}, Lcom/facebook/fresco/animation/drawable/AnimationListener;->onAnimationStop(LP2/a;)V

    .line 57
    .line 58
    .line 59
    iput-boolean v5, p0, LP2/a;->c:Z

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    if-nez v4, :cond_3

    .line 63
    .line 64
    iget v7, p0, LP2/a;->g:I

    .line 65
    .line 66
    if-eq v7, v6, :cond_3

    .line 67
    .line 68
    iget-wide v6, p0, LP2/a;->f:J

    .line 69
    .line 70
    cmp-long v0, v0, v6

    .line 71
    .line 72
    if-ltz v0, :cond_3

    .line 73
    .line 74
    iget-object v0, p0, LP2/a;->v:Lcom/facebook/fresco/animation/drawable/AnimationListener;

    .line 75
    .line 76
    invoke-interface {v0, p0}, Lcom/facebook/fresco/animation/drawable/AnimationListener;->onAnimationRepeat(LP2/a;)V

    .line 77
    .line 78
    .line 79
    :cond_3
    :goto_1
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 80
    .line 81
    invoke-virtual {v0, p0, p1, v4}, LK2/a;->drawFrame(Landroid/graphics/drawable/Drawable;Landroid/graphics/Canvas;I)Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-eqz p1, :cond_4

    .line 86
    .line 87
    iget-object v0, p0, LP2/a;->v:Lcom/facebook/fresco/animation/drawable/AnimationListener;

    .line 88
    .line 89
    invoke-interface {v0, p0, v4}, Lcom/facebook/fresco/animation/drawable/AnimationListener;->onAnimationFrame(LP2/a;I)V

    .line 90
    .line 91
    .line 92
    iput v4, p0, LP2/a;->g:I

    .line 93
    .line 94
    :cond_4
    if-nez p1, :cond_5

    .line 95
    .line 96
    iget p1, p0, LP2/a;->t:I

    .line 97
    .line 98
    add-int/lit8 p1, p1, 0x1

    .line 99
    .line 100
    iput p1, p0, LP2/a;->t:I

    .line 101
    .line 102
    sget-object p1, Lp2/a;->a:Lp2/b;

    .line 103
    .line 104
    const/4 v0, 0x2

    .line 105
    invoke-virtual {p1, v0}, Lp2/b;->isLoggable(I)Z

    .line 106
    .line 107
    .line 108
    move-result p1

    .line 109
    if-eqz p1, :cond_5

    .line 110
    .line 111
    iget p1, p0, LP2/a;->t:I

    .line 112
    .line 113
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    const-class v0, LP2/a;

    .line 118
    .line 119
    const-string v1, "Dropped a frame. Count: %s"

    .line 120
    .line 121
    invoke-static {v0, v1, p1}, Lp2/a;->o(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    :cond_5
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 125
    .line 126
    .line 127
    move-result-wide v0

    .line 128
    iget-boolean p1, p0, LP2/a;->c:Z

    .line 129
    .line 130
    if-eqz p1, :cond_7

    .line 131
    .line 132
    iget-object p1, p0, LP2/a;->b:LR2/a;

    .line 133
    .line 134
    iget-wide v6, p0, LP2/a;->d:J

    .line 135
    .line 136
    sub-long/2addr v0, v6

    .line 137
    invoke-virtual {p1, v0, v1}, LR2/a;->getTargetRenderTimeForNextFrameMs(J)J

    .line 138
    .line 139
    .line 140
    move-result-wide v0

    .line 141
    const-wide/16 v6, -0x1

    .line 142
    .line 143
    cmp-long p1, v0, v6

    .line 144
    .line 145
    if-eqz p1, :cond_6

    .line 146
    .line 147
    iget-wide v4, p0, LP2/a;->p:J

    .line 148
    .line 149
    add-long/2addr v0, v4

    .line 150
    iget-wide v4, p0, LP2/a;->d:J

    .line 151
    .line 152
    add-long/2addr v4, v0

    .line 153
    iput-wide v4, p0, LP2/a;->f:J

    .line 154
    .line 155
    iget-object p1, p0, LP2/a;->A:LB5/c;

    .line 156
    .line 157
    invoke-virtual {p0, p1, v4, v5}, Landroid/graphics/drawable/Drawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    .line 158
    .line 159
    .line 160
    goto :goto_2

    .line 161
    :cond_6
    iget-object p1, p0, LP2/a;->v:Lcom/facebook/fresco/animation/drawable/AnimationListener;

    .line 162
    .line 163
    invoke-interface {p1, p0}, Lcom/facebook/fresco/animation/drawable/AnimationListener;->onAnimationStop(LP2/a;)V

    .line 164
    .line 165
    .line 166
    iput-boolean v5, p0, LP2/a;->c:Z

    .line 167
    .line 168
    :cond_7
    :goto_2
    iput-wide v2, p0, LP2/a;->e:J

    .line 169
    .line 170
    :cond_8
    :goto_3
    return-void
.end method

.method public final dropCaches()V
    .locals 1

    .line 1
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, LK2/a;->clear()V

    .line 6
    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public final getIntrinsicHeight()I
    .locals 1

    .line 1
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, v0, LK2/a;->a:LL2/a;

    .line 11
    .line 12
    iget v0, v0, LL2/a;->o:I

    .line 13
    .line 14
    return v0
.end method

.method public final getIntrinsicWidth()I
    .locals 1

    .line 1
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    iget-object v0, v0, LK2/a;->a:LL2/a;

    .line 11
    .line 12
    iget v0, v0, LL2/a;->j:I

    .line 13
    .line 14
    return v0
.end method

.method public final getOpacity()I
    .locals 1

    .line 1
    const/4 v0, -0x3

    .line 2
    return v0
.end method

.method public final isRunning()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LP2/a;->c:Z

    .line 2
    .line 3
    return v0
.end method

.method public final onBoundsChange(Landroid/graphics/Rect;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->onBoundsChange(Landroid/graphics/Rect;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0, p1}, LK2/a;->setBounds(Landroid/graphics/Rect;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-void
.end method

.method public final onLevelChange(I)Z
    .locals 4

    .line 1
    iget-boolean v0, p0, LP2/a;->c:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    iget-wide v0, p0, LP2/a;->e:J

    .line 7
    .line 8
    int-to-long v2, p1

    .line 9
    cmp-long p1, v0, v2

    .line 10
    .line 11
    if-eqz p1, :cond_1

    .line 12
    .line 13
    iput-wide v2, p0, LP2/a;->e:J

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 16
    .line 17
    .line 18
    const/4 p1, 0x1

    .line 19
    return p1

    .line 20
    :cond_1
    :goto_0
    const/4 p1, 0x0

    .line 21
    return p1
.end method

.method public final setAlpha(I)V
    .locals 1

    .line 1
    iget-object v0, p0, LP2/a;->w:Lcom/facebook/drawee/drawable/d;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/drawee/drawable/d;

    .line 6
    .line 7
    invoke-direct {v0}, Lcom/facebook/drawee/drawable/d;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, LP2/a;->w:Lcom/facebook/drawee/drawable/d;

    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, LP2/a;->w:Lcom/facebook/drawee/drawable/d;

    .line 13
    .line 14
    iput p1, v0, Lcom/facebook/drawee/drawable/d;->a:I

    .line 15
    .line 16
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-virtual {v0, p1}, LK2/a;->setAlpha(I)V

    .line 21
    .line 22
    .line 23
    :cond_1
    return-void
.end method

.method public final setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 2

    .line 1
    iget-object v0, p0, LP2/a;->w:Lcom/facebook/drawee/drawable/d;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Lcom/facebook/drawee/drawable/d;

    .line 6
    .line 7
    invoke-direct {v0}, Lcom/facebook/drawee/drawable/d;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, LP2/a;->w:Lcom/facebook/drawee/drawable/d;

    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, LP2/a;->w:Lcom/facebook/drawee/drawable/d;

    .line 13
    .line 14
    iput-object p1, v0, Lcom/facebook/drawee/drawable/d;->c:Landroid/graphics/ColorFilter;

    .line 15
    .line 16
    if-eqz p1, :cond_1

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    goto :goto_0

    .line 20
    :cond_1
    const/4 v1, 0x0

    .line 21
    :goto_0
    iput-boolean v1, v0, Lcom/facebook/drawee/drawable/d;->b:Z

    .line 22
    .line 23
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 24
    .line 25
    if-eqz v0, :cond_2

    .line 26
    .line 27
    invoke-virtual {v0, p1}, LK2/a;->setColorFilter(Landroid/graphics/ColorFilter;)V

    .line 28
    .line 29
    .line 30
    :cond_2
    return-void
.end method

.method public final start()V
    .locals 4

    .line 1
    iget-boolean v0, p0, LP2/a;->c:Z

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, LP2/a;->a:LK2/a;

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    iget-object v0, v0, LK2/a;->a:LL2/a;

    .line 10
    .line 11
    invoke-virtual {v0}, LL2/a;->getFrameCount()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/4 v1, 0x1

    .line 16
    if-gt v0, v1, :cond_0

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    iput-boolean v1, p0, LP2/a;->c:Z

    .line 20
    .line 21
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 22
    .line 23
    .line 24
    move-result-wide v0

    .line 25
    iget-wide v2, p0, LP2/a;->i:J

    .line 26
    .line 27
    sub-long v2, v0, v2

    .line 28
    .line 29
    iput-wide v2, p0, LP2/a;->d:J

    .line 30
    .line 31
    iput-wide v2, p0, LP2/a;->f:J

    .line 32
    .line 33
    iget-wide v2, p0, LP2/a;->j:J

    .line 34
    .line 35
    sub-long/2addr v0, v2

    .line 36
    iput-wide v0, p0, LP2/a;->e:J

    .line 37
    .line 38
    iget v0, p0, LP2/a;->o:I

    .line 39
    .line 40
    iput v0, p0, LP2/a;->g:I

    .line 41
    .line 42
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 43
    .line 44
    .line 45
    iget-object v0, p0, LP2/a;->v:Lcom/facebook/fresco/animation/drawable/AnimationListener;

    .line 46
    .line 47
    invoke-interface {v0, p0}, Lcom/facebook/fresco/animation/drawable/AnimationListener;->onAnimationStart(LP2/a;)V

    .line 48
    .line 49
    .line 50
    :cond_1
    :goto_0
    return-void
.end method

.method public final stop()V
    .locals 4

    .line 1
    iget-boolean v0, p0, LP2/a;->c:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    iget-wide v2, p0, LP2/a;->d:J

    .line 11
    .line 12
    sub-long v2, v0, v2

    .line 13
    .line 14
    iput-wide v2, p0, LP2/a;->i:J

    .line 15
    .line 16
    iget-wide v2, p0, LP2/a;->e:J

    .line 17
    .line 18
    sub-long/2addr v0, v2

    .line 19
    iput-wide v0, p0, LP2/a;->j:J

    .line 20
    .line 21
    iget v0, p0, LP2/a;->g:I

    .line 22
    .line 23
    iput v0, p0, LP2/a;->o:I

    .line 24
    .line 25
    const/4 v0, 0x0

    .line 26
    iput-boolean v0, p0, LP2/a;->c:Z

    .line 27
    .line 28
    const-wide/16 v0, 0x0

    .line 29
    .line 30
    iput-wide v0, p0, LP2/a;->d:J

    .line 31
    .line 32
    iput-wide v0, p0, LP2/a;->f:J

    .line 33
    .line 34
    const-wide/16 v0, -0x1

    .line 35
    .line 36
    iput-wide v0, p0, LP2/a;->e:J

    .line 37
    .line 38
    const/4 v0, -0x1

    .line 39
    iput v0, p0, LP2/a;->g:I

    .line 40
    .line 41
    iget-object v0, p0, LP2/a;->A:LB5/c;

    .line 42
    .line 43
    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->unscheduleSelf(Ljava/lang/Runnable;)V

    .line 44
    .line 45
    .line 46
    iget-object v0, p0, LP2/a;->v:Lcom/facebook/fresco/animation/drawable/AnimationListener;

    .line 47
    .line 48
    invoke-interface {v0, p0}, Lcom/facebook/fresco/animation/drawable/AnimationListener;->onAnimationStop(LP2/a;)V

    .line 49
    .line 50
    .line 51
    return-void
.end method
