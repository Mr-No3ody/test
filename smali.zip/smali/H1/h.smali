.class public final LH1/h;
.super LH1/c;
.source "SourceFile"


# instance fields
.field public final a:Landroid/widget/RemoteViews;

.field public final b:Landroid/content/Context;

.field public final c:I

.field public final d:Landroid/app/Notification;

.field public final e:I


# direct methods
.method public constructor <init>(Landroid/content/Context;ILandroid/widget/RemoteViews;Landroid/app/Notification;I)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, LH1/c;-><init>(I)V

    .line 3
    .line 4
    .line 5
    const-string v0, "Context must not be null!"

    .line 6
    .line 7
    invoke-static {p1, v0}, LJ1/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, LH1/h;->b:Landroid/content/Context;

    .line 11
    .line 12
    const-string p1, "Notification object can not be null!"

    .line 13
    .line 14
    invoke-static {p4, p1}, LJ1/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iput-object p4, p0, LH1/h;->d:Landroid/app/Notification;

    .line 18
    .line 19
    iput-object p3, p0, LH1/h;->a:Landroid/widget/RemoteViews;

    .line 20
    .line 21
    iput p2, p0, LH1/h;->e:I

    .line 22
    .line 23
    iput p5, p0, LH1/h;->c:I

    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Bitmap;)V
    .locals 3

    .line 1
    iget-object v0, p0, LH1/h;->a:Landroid/widget/RemoteViews;

    .line 2
    .line 3
    iget v1, p0, LH1/h;->e:I

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, LH1/h;->b:Landroid/content/Context;

    .line 9
    .line 10
    const-string v0, "notification"

    .line 11
    .line 12
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, Landroid/app/NotificationManager;

    .line 17
    .line 18
    const-string v0, "Argument must not be null"

    .line 19
    .line 20
    invoke-static {p1, v0}, LJ1/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    const/4 v0, 0x0

    .line 24
    iget v1, p0, LH1/h;->c:I

    .line 25
    .line 26
    iget-object v2, p0, LH1/h;->d:Landroid/app/Notification;

    .line 27
    .line 28
    invoke-virtual {p1, v0, v1, v2}, Landroid/app/NotificationManager;->notify(Ljava/lang/String;ILandroid/app/Notification;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public final onLoadCleared(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    invoke-virtual {p0, p1}, LH1/h;->a(Landroid/graphics/Bitmap;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method public final onResourceReady(Ljava/lang/Object;Lcom/bumptech/glide/request/transition/Transition;)V
    .locals 0

    .line 1
    check-cast p1, Landroid/graphics/Bitmap;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, LH1/h;->a(Landroid/graphics/Bitmap;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
