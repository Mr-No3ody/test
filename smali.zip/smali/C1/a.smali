.class public final LC1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/bumptech/glide/load/ResourceDecoder;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LC1/a;->a:I

    iput-object p1, p0, LC1/a;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final decode(Ljava/lang/Object;IILcom/bumptech/glide/load/h;)Lcom/bumptech/glide/load/engine/Resource;
    .locals 1

    .line 1
    iget v0, p0, LC1/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/bumptech/glide/gifdecoder/GifDecoder;

    .line 7
    .line 8
    invoke-interface {p1}, Lcom/bumptech/glide/gifdecoder/GifDecoder;->getNextFrame()Landroid/graphics/Bitmap;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    iget-object p2, p0, LC1/a;->b:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p2, Lcom/bumptech/glide/load/engine/bitmap_recycle/BitmapPool;

    .line 15
    .line 16
    invoke-static {p2, p1}, Lcom/bumptech/glide/load/resource/bitmap/c;->a(Lcom/bumptech/glide/load/engine/bitmap_recycle/BitmapPool;Landroid/graphics/Bitmap;)Lcom/bumptech/glide/load/resource/bitmap/c;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    return-object p1

    .line 21
    :pswitch_0
    check-cast p1, Ljava/io/InputStream;

    .line 22
    .line 23
    invoke-static {p1}, LJ1/c;->b(Ljava/io/InputStream;)Ljava/nio/ByteBuffer;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-static {p1}, Landroidx/core/view/i;->f(Ljava/nio/ByteBuffer;)Landroid/graphics/ImageDecoder$Source;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-static {p1, p2, p3, p4}, LC1/b;->a(Landroid/graphics/ImageDecoder$Source;IILcom/bumptech/glide/load/h;)LB1/b;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    return-object p1

    .line 36
    :pswitch_1
    check-cast p1, Ljava/nio/ByteBuffer;

    .line 37
    .line 38
    invoke-static {p1}, Landroidx/core/view/i;->f(Ljava/nio/ByteBuffer;)Landroid/graphics/ImageDecoder$Source;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-static {p1, p2, p3, p4}, LC1/b;->a(Landroid/graphics/ImageDecoder$Source;IILcom/bumptech/glide/load/h;)LB1/b;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    return-object p1

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final handles(Ljava/lang/Object;Lcom/bumptech/glide/load/h;)Z
    .locals 1

    .line 1
    iget p2, p0, LC1/a;->a:I

    .line 2
    .line 3
    packed-switch p2, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/bumptech/glide/gifdecoder/GifDecoder;

    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    return p1

    .line 10
    :pswitch_0
    check-cast p1, Ljava/io/InputStream;

    .line 11
    .line 12
    iget-object p2, p0, LC1/a;->b:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p2, LC1/b;

    .line 15
    .line 16
    iget-object v0, p2, LC1/b;->a:Ljava/util/ArrayList;

    .line 17
    .line 18
    iget-object p2, p2, LC1/b;->b:Lcom/bumptech/glide/load/engine/bitmap_recycle/f;

    .line 19
    .line 20
    invoke-static {v0, p1, p2}, Lcom/bumptech/glide/load/e;->b(Ljava/util/ArrayList;Ljava/io/InputStream;Lcom/bumptech/glide/load/engine/bitmap_recycle/f;)Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    sget-object p2, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->ANIMATED_WEBP:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    .line 25
    .line 26
    if-eq p1, p2, :cond_1

    .line 27
    .line 28
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 29
    .line 30
    const/16 v0, 0x1f

    .line 31
    .line 32
    if-lt p2, v0, :cond_0

    .line 33
    .line 34
    sget-object p2, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->ANIMATED_AVIF:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    .line 35
    .line 36
    if-ne p1, p2, :cond_0

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    const/4 p1, 0x0

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    :goto_0
    const/4 p1, 0x1

    .line 42
    :goto_1
    return p1

    .line 43
    :pswitch_1
    check-cast p1, Ljava/nio/ByteBuffer;

    .line 44
    .line 45
    iget-object p2, p0, LC1/a;->b:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p2, LC1/b;

    .line 48
    .line 49
    iget-object p2, p2, LC1/b;->a:Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-static {p2, p1}, Lcom/bumptech/glide/load/e;->c(Ljava/util/ArrayList;Ljava/nio/ByteBuffer;)Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    sget-object p2, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->ANIMATED_WEBP:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    .line 56
    .line 57
    if-eq p1, p2, :cond_3

    .line 58
    .line 59
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 60
    .line 61
    const/16 v0, 0x1f

    .line 62
    .line 63
    if-lt p2, v0, :cond_2

    .line 64
    .line 65
    sget-object p2, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->ANIMATED_AVIF:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    .line 66
    .line 67
    if-ne p1, p2, :cond_2

    .line 68
    .line 69
    goto :goto_2

    .line 70
    :cond_2
    const/4 p1, 0x0

    .line 71
    goto :goto_3

    .line 72
    :cond_3
    :goto_2
    const/4 p1, 0x1

    .line 73
    :goto_3
    return p1

    .line 74
    nop

    .line 75
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
