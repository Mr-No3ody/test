.class public final LV3/f;
.super LV3/d;
.source "SourceFile"


# instance fields
.field public final f:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckWithFaceRecognitionFragment;

.field public final g:LV3/c;


# direct methods
.method public constructor <init>(Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckWithFaceRecognitionFragment;)V
    .locals 3

    .line 1
    const-string v0, "caller"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v1, LV3/a;

    .line 7
    .line 8
    const/4 v2, 0x4

    .line 9
    invoke-direct {v1, v2}, LV3/a;-><init>(I)V

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-direct {p0, p1, v1, v2}, LV3/d;-><init>(Landroidx/activity/result/ActivityResultCaller;Lm/b;I)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, LV3/f;->f:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckWithFaceRecognitionFragment;

    .line 17
    .line 18
    new-instance v1, LV3/c;

    .line 19
    .line 20
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    new-instance v0, LV3/a;

    .line 24
    .line 25
    const/4 v2, 0x0

    .line 26
    invoke-direct {v0, v2}, LV3/a;-><init>(I)V

    .line 27
    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    invoke-direct {v1, p1, v0, v2}, LV3/d;-><init>(Landroidx/activity/result/ActivityResultCaller;Lm/b;I)V

    .line 31
    .line 32
    .line 33
    iput-object v1, p0, LV3/f;->g:LV3/c;

    .line 34
    .line 35
    return-void
.end method
