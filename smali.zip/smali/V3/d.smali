.class public abstract LV3/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/permissionx/guolindev/request/ChainTask;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroidx/activity/result/ActivityResultCaller;Landroidx/activity/result/h;Ljava/lang/String;Lm/l;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LV3/d;->a:I

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 19
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    if-nez p2, :cond_0

    goto :goto_0

    .line 20
    :cond_0
    new-instance p1, Lca/b;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v0}, Lca/b;-><init>(LV3/d;I)V

    invoke-virtual {p2, p3, p4, p1}, Landroidx/activity/result/h;->d(Ljava/lang/String;Lm/b;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/g;

    move-result-object p1

    iput-object p1, p0, LV3/d;->b:Ljava/lang/Object;

    goto :goto_1

    .line 21
    :cond_1
    :goto_0
    new-instance p2, Lca/b;

    const/4 p3, 0x0

    invoke-direct {p2, p0, p3}, Lca/b;-><init>(LV3/d;I)V

    invoke-interface {p1, p4, p2}, Landroidx/activity/result/ActivityResultCaller;->registerForActivityResult(Lm/b;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/a;

    move-result-object p1

    iput-object p1, p0, LV3/d;->b:Ljava/lang/Object;

    :goto_1
    return-void
.end method

.method public constructor <init>(Landroidx/activity/result/ActivityResultCaller;Lm/b;I)V
    .locals 1

    iput p3, p0, LV3/d;->a:I

    packed-switch p3, :pswitch_data_0

    const-string p3, "caller"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p3, "contract"

    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 3
    new-instance p3, LG9/i;

    const/4 v0, 0x2

    invoke-direct {p3, p0, v0}, LG9/i;-><init>(Ljava/lang/Object;I)V

    invoke-interface {p1, p2, p3}, Landroidx/activity/result/ActivityResultCaller;->registerForActivityResult(Lm/b;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/a;

    move-result-object p1

    iput-object p1, p0, LV3/d;->b:Ljava/lang/Object;

    return-void

    .line 4
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput-object p1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 6
    new-instance p3, Lca/b;

    const/4 v0, 0x1

    invoke-direct {p3, p0, v0}, Lca/b;-><init>(LV3/d;I)V

    invoke-interface {p1, p2, p3}, Landroidx/activity/result/ActivityResultCaller;->registerForActivityResult(Lm/b;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/a;

    move-result-object p1

    iput-object p1, p0, LV3/d;->b:Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Lo7/h;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LV3/d;->a:I

    const-string v0, "pb"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 13
    new-instance v0, Lo7/a;

    invoke-direct {v0, p1, p0}, Lo7/a;-><init>(Lo7/h;LV3/d;)V

    iput-object v0, p0, LV3/d;->c:Ljava/lang/Object;

    .line 14
    new-instance v0, Lo7/b;

    invoke-direct {v0, p1, p0}, Lo7/b;-><init>(Lo7/h;LV3/d;)V

    iput-object v0, p0, LV3/d;->d:Ljava/lang/Object;

    .line 15
    new-instance v0, Lo7/a;

    invoke-direct {v0, p1, p0}, Lo7/a;-><init>(Lo7/h;LV3/d;)V

    iput-object v0, p0, LV3/d;->c:Ljava/lang/Object;

    .line 16
    new-instance v0, Lo7/b;

    invoke-direct {v0, p1, p0}, Lo7/b;-><init>(Lo7/h;LV3/d;)V

    iput-object v0, p0, LV3/d;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>([Ljava/lang/String;Lta/p;)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, LV3/d;->a:I

    const-string v0, "requiredPermissions"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    array-length v0, p1

    if-eqz v0, :cond_0

    .line 9
    iput-object p1, p0, LV3/d;->c:Ljava/lang/Object;

    .line 10
    iput-object p2, p0, LV3/d;->d:Ljava/lang/Object;

    return-void

    .line 11
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "You cannot create PermissionProvider without any permission required."

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public a()Landroid/app/Activity;
    .locals 3

    .line 1
    iget-object v0, p0, LV3/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 4
    .line 5
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const/4 v1, 0x0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    return-object v1

    .line 16
    :cond_0
    iget-object v0, p0, LV3/d;->e:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 19
    .line 20
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    check-cast v0, Lsa/a;

    .line 31
    .line 32
    iget-object v2, v0, Lsa/a;->b:Ljava/lang/ref/WeakReference;

    .line 33
    .line 34
    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    check-cast v2, Landroid/app/Activity;

    .line 39
    .line 40
    if-nez v2, :cond_2

    .line 41
    .line 42
    iget-object v0, v0, Lsa/a;->c:Ljava/lang/ref/WeakReference;

    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    check-cast v0, Landroidx/fragment/app/Fragment;

    .line 49
    .line 50
    if-eqz v0, :cond_1

    .line 51
    .line 52
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    return-object v0

    .line 57
    :cond_1
    return-object v1

    .line 58
    :cond_2
    return-object v2
.end method

.method public b()Landroidx/fragment/app/Fragment;
    .locals 1

    .line 1
    iget-object v0, p0, LV3/d;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 4
    .line 5
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    return-object v0

    .line 16
    :cond_0
    iget-object v0, p0, LV3/d;->e:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 19
    .line 20
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    check-cast v0, Lsa/a;

    .line 31
    .line 32
    iget-object v0, v0, Lsa/a;->c:Ljava/lang/ref/WeakReference;

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroidx/fragment/app/Fragment;

    .line 39
    .line 40
    return-object v0
.end method

.method public c(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LV3/d;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/activity/result/ActivityResultCallback;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-interface {v0, p1}, Landroidx/activity/result/ActivityResultCallback;->onActivityResult(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    iput-object p1, p0, LV3/d;->c:Ljava/lang/Object;

    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    iget-object v0, p0, LV3/d;->d:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Landroidx/lifecycle/F;

    .line 17
    .line 18
    if-nez v0, :cond_1

    .line 19
    .line 20
    new-instance v0, Landroidx/lifecycle/F;

    .line 21
    .line 22
    invoke-direct {v0}, Landroidx/lifecycle/B;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, LV3/d;->d:Ljava/lang/Object;

    .line 26
    .line 27
    :cond_1
    iget-object v0, p0, LV3/d;->d:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v0, Landroidx/lifecycle/F;

    .line 30
    .line 31
    invoke-virtual {v0, p1}, Landroidx/lifecycle/B;->k(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public d(Ljava/lang/Object;Landroidx/activity/result/ActivityResultCallback;)V
    .locals 1

    .line 1
    iget v0, p0, LV3/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iput-object p2, p0, LV3/d;->c:Ljava/lang/Object;

    .line 7
    .line 8
    :try_start_0
    iget-object p2, p0, LV3/d;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast p2, Landroidx/activity/result/a;

    .line 11
    .line 12
    invoke-virtual {p2, p1}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :catch_0
    move-exception p1

    .line 17
    const-string p2, "launch: "

    .line 18
    .line 19
    filled-new-array {p2, p1}, [Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    const-string p2, "ActivityLauncher"

    .line 24
    .line 25
    invoke-static {p2, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    :goto_0
    return-void

    .line 29
    :pswitch_0
    const-string v0, "callback"

    .line 30
    .line 31
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    iput-object p2, p0, LV3/d;->c:Ljava/lang/Object;

    .line 38
    .line 39
    iget-object p2, p0, LV3/d;->b:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast p2, Landroidx/activity/result/a;

    .line 42
    .line 43
    invoke-virtual {p2, p1}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public abstract e()Z
.end method

.method public finish()V
    .locals 7

    .line 1
    iget-object v0, p0, LV3/d;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LV3/d;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-interface {v0}, Lcom/permissionx/guolindev/request/ChainTask;->request()V

    .line 8
    .line 9
    .line 10
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    :goto_0
    if-nez v0, :cond_12

    .line 15
    .line 16
    new-instance v0, Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 19
    .line 20
    .line 21
    iget-object v1, p0, LV3/d;->e:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v1, Lo7/h;

    .line 24
    .line 25
    iget-object v2, v1, Lo7/h;->g:Ljava/util/LinkedHashSet;

    .line 26
    .line 27
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 28
    .line 29
    .line 30
    iget-object v2, v1, Lo7/h;->h:Ljava/util/LinkedHashSet;

    .line 31
    .line 32
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 33
    .line 34
    .line 35
    iget-object v2, v1, Lo7/h;->e:Ljava/util/LinkedHashSet;

    .line 36
    .line 37
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 38
    .line 39
    .line 40
    iget-object v2, v1, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 41
    .line 42
    const-string v3, "android.permission.ACCESS_BACKGROUND_LOCATION"

    .line 43
    .line 44
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    if-eqz v2, :cond_2

    .line 49
    .line 50
    invoke-virtual {v1}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-static {v2, v3}, Landroidx/core/content/d;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-nez v2, :cond_1

    .line 59
    .line 60
    iget-object v2, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 61
    .line 62
    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_1
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    :cond_2
    :goto_1
    iget-object v2, v1, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 70
    .line 71
    const-string v3, "android.permission.SYSTEM_ALERT_WINDOW"

    .line 72
    .line 73
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v2

    .line 77
    const/16 v4, 0x17

    .line 78
    .line 79
    if-eqz v2, :cond_4

    .line 80
    .line 81
    invoke-virtual {v1}, Lo7/h;->d()I

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    if-lt v2, v4, :cond_4

    .line 86
    .line 87
    invoke-virtual {v1}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    invoke-static {v2}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    if-eqz v2, :cond_3

    .line 96
    .line 97
    iget-object v2, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 98
    .line 99
    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    goto :goto_2

    .line 103
    :cond_3
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    :cond_4
    :goto_2
    iget-object v2, v1, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 107
    .line 108
    const-string v3, "android.permission.WRITE_SETTINGS"

    .line 109
    .line 110
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result v2

    .line 114
    if-eqz v2, :cond_6

    .line 115
    .line 116
    invoke-virtual {v1}, Lo7/h;->d()I

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    if-lt v2, v4, :cond_6

    .line 121
    .line 122
    invoke-virtual {v1}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 123
    .line 124
    .line 125
    move-result-object v2

    .line 126
    invoke-static {v2}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    .line 127
    .line 128
    .line 129
    move-result v2

    .line 130
    if-eqz v2, :cond_5

    .line 131
    .line 132
    iget-object v2, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 133
    .line 134
    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    goto :goto_3

    .line 138
    :cond_5
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    :cond_6
    :goto_3
    iget-object v2, v1, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 142
    .line 143
    const-string v3, "android.permission.MANAGE_EXTERNAL_STORAGE"

    .line 144
    .line 145
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result v2

    .line 149
    if-eqz v2, :cond_8

    .line 150
    .line 151
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 152
    .line 153
    const/16 v4, 0x1e

    .line 154
    .line 155
    if-lt v2, v4, :cond_7

    .line 156
    .line 157
    invoke-static {}, Lcom/google/android/material/color/a;->o()Z

    .line 158
    .line 159
    .line 160
    move-result v2

    .line 161
    if-eqz v2, :cond_7

    .line 162
    .line 163
    iget-object v2, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 164
    .line 165
    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 166
    .line 167
    .line 168
    goto :goto_4

    .line 169
    :cond_7
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 170
    .line 171
    .line 172
    :cond_8
    :goto_4
    iget-object v2, v1, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 173
    .line 174
    const-string v3, "android.permission.REQUEST_INSTALL_PACKAGES"

    .line 175
    .line 176
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 177
    .line 178
    .line 179
    move-result v2

    .line 180
    const/16 v4, 0x1a

    .line 181
    .line 182
    if-eqz v2, :cond_b

    .line 183
    .line 184
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 185
    .line 186
    if-lt v2, v4, :cond_a

    .line 187
    .line 188
    invoke-virtual {v1}, Lo7/h;->d()I

    .line 189
    .line 190
    .line 191
    move-result v2

    .line 192
    if-lt v2, v4, :cond_a

    .line 193
    .line 194
    invoke-virtual {v1}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 195
    .line 196
    .line 197
    move-result-object v2

    .line 198
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 199
    .line 200
    .line 201
    move-result-object v2

    .line 202
    invoke-static {v2}, Lcom/horcrux/svg/Z;->z(Landroid/content/pm/PackageManager;)Z

    .line 203
    .line 204
    .line 205
    move-result v2

    .line 206
    if-eqz v2, :cond_9

    .line 207
    .line 208
    iget-object v2, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 209
    .line 210
    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 211
    .line 212
    .line 213
    goto :goto_5

    .line 214
    :cond_9
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    goto :goto_5

    .line 218
    :cond_a
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 219
    .line 220
    .line 221
    :cond_b
    :goto_5
    iget-object v2, v1, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 222
    .line 223
    const-string v3, "android.permission.POST_NOTIFICATIONS"

    .line 224
    .line 225
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 226
    .line 227
    .line 228
    move-result v2

    .line 229
    if-eqz v2, :cond_d

    .line 230
    .line 231
    invoke-virtual {v1}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 232
    .line 233
    .line 234
    move-result-object v2

    .line 235
    new-instance v5, Landroidx/core/app/M;

    .line 236
    .line 237
    invoke-direct {v5, v2}, Landroidx/core/app/M;-><init>(Landroid/content/Context;)V

    .line 238
    .line 239
    .line 240
    iget-object v2, v5, Landroidx/core/app/M;->b:Landroid/app/NotificationManager;

    .line 241
    .line 242
    invoke-virtual {v2}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    .line 243
    .line 244
    .line 245
    move-result v2

    .line 246
    if-eqz v2, :cond_c

    .line 247
    .line 248
    iget-object v2, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 249
    .line 250
    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 251
    .line 252
    .line 253
    goto :goto_6

    .line 254
    :cond_c
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 255
    .line 256
    .line 257
    :cond_d
    :goto_6
    iget-object v2, v1, Lo7/h;->d:Ljava/util/LinkedHashSet;

    .line 258
    .line 259
    const-string v3, "android.permission.BODY_SENSORS_BACKGROUND"

    .line 260
    .line 261
    invoke-interface {v2, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 262
    .line 263
    .line 264
    move-result v2

    .line 265
    if-eqz v2, :cond_f

    .line 266
    .line 267
    invoke-virtual {v1}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 268
    .line 269
    .line 270
    move-result-object v2

    .line 271
    invoke-static {v2, v3}, Landroidx/core/content/d;->a(Landroid/content/Context;Ljava/lang/String;)I

    .line 272
    .line 273
    .line 274
    move-result v2

    .line 275
    if-nez v2, :cond_e

    .line 276
    .line 277
    iget-object v2, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 278
    .line 279
    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 280
    .line 281
    .line 282
    goto :goto_7

    .line 283
    :cond_e
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 284
    .line 285
    .line 286
    :cond_f
    :goto_7
    iget-object v2, v1, Lo7/h;->j:Lcom/permissionx/guolindev/callback/RequestCallback;

    .line 287
    .line 288
    if-eqz v2, :cond_10

    .line 289
    .line 290
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 291
    .line 292
    .line 293
    move-result v3

    .line 294
    new-instance v5, Ljava/util/ArrayList;

    .line 295
    .line 296
    iget-object v6, v1, Lo7/h;->f:Ljava/util/LinkedHashSet;

    .line 297
    .line 298
    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 299
    .line 300
    .line 301
    invoke-interface {v2, v3, v5, v0}, Lcom/permissionx/guolindev/callback/RequestCallback;->onResult(ZLjava/util/List;Ljava/util/List;)V

    .line 302
    .line 303
    .line 304
    :cond_10
    invoke-virtual {v1}, Lo7/h;->b()Landroidx/fragment/app/Z;

    .line 305
    .line 306
    .line 307
    move-result-object v0

    .line 308
    const-string v2, "InvisibleFragment"

    .line 309
    .line 310
    invoke-virtual {v0, v2}, Landroidx/fragment/app/Z;->E(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    .line 311
    .line 312
    .line 313
    move-result-object v0

    .line 314
    if-eqz v0, :cond_11

    .line 315
    .line 316
    invoke-virtual {v1}, Lo7/h;->b()Landroidx/fragment/app/Z;

    .line 317
    .line 318
    .line 319
    move-result-object v2

    .line 320
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 321
    .line 322
    .line 323
    new-instance v3, Landroidx/fragment/app/a;

    .line 324
    .line 325
    invoke-direct {v3, v2}, Landroidx/fragment/app/a;-><init>(Landroidx/fragment/app/Z;)V

    .line 326
    .line 327
    .line 328
    invoke-virtual {v3, v0}, Landroidx/fragment/app/a;->m(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a;

    .line 329
    .line 330
    .line 331
    invoke-virtual {v3}, Landroidx/fragment/app/a;->j()V

    .line 332
    .line 333
    .line 334
    :cond_11
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 335
    .line 336
    if-eq v0, v4, :cond_12

    .line 337
    .line 338
    invoke-virtual {v1}, Lo7/h;->a()Landroidx/fragment/app/E;

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    iget v1, v1, Lo7/h;->b:I

    .line 343
    .line 344
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 345
    .line 346
    .line 347
    :cond_12
    return-void
.end method

.method public getExplainScope()Lo7/a;
    .locals 1

    .line 1
    iget-object v0, p0, LV3/d;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo7/a;

    .line 4
    .line 5
    return-object v0
.end method

.method public getForwardScope()Lo7/b;
    .locals 1

    .line 1
    iget-object v0, p0, LV3/d;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo7/b;

    .line 4
    .line 5
    return-object v0
.end method
