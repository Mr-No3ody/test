.class public final synthetic LV3/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/activity/result/ActivityResultCallback;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p5, p0, LV3/e;->a:I

    iput-object p1, p0, LV3/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LV3/e;->c:Ljava/lang/Object;

    iput-object p3, p0, LV3/e;->d:Ljava/lang/Object;

    iput-object p4, p0, LV3/e;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onActivityResult(Ljava/lang/Object;)V
    .locals 4

    .line 1
    iget v0, p0, LV3/e;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Landroidx/activity/result/ActivityResult;

    .line 7
    .line 8
    iget-object v0, p0, LV3/e;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Ljava/io/File;

    .line 11
    .line 12
    iget-object v1, p0, LV3/e;->c:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge;

    .line 15
    .line 16
    iget-object v2, p0, LV3/e;->d:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v2, Landroidx/appcompat/app/o;

    .line 19
    .line 20
    iget-object v3, p0, LV3/e;->e:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v3, Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge$PhotoUploadParam;

    .line 23
    .line 24
    invoke-static {v0, v1, v2, v3, p1}, Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge;->e(Ljava/io/File;Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge;Landroidx/appcompat/app/o;Lcom/palmpay/lib/bridgewrapper/photo/upload/PhotoUploadBridge$PhotoUploadParam;Landroidx/activity/result/ActivityResult;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    if-eqz p1, :cond_0

    .line 35
    .line 36
    iget-object p1, p0, LV3/e;->b:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, LPa/c0;

    .line 39
    .line 40
    invoke-virtual {p1}, LPa/c0;->invoke()V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_0
    iget-object p1, p0, LV3/e;->c:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p1, Lca/d;

    .line 47
    .line 48
    iget-object v0, p1, Lca/d;->f:Landroidx/activity/result/ActivityResultCaller;

    .line 49
    .line 50
    const-string v1, "android.permission.CAMERA"

    .line 51
    .line 52
    invoke-static {v0, v1}, LD3/a;->G(Landroidx/activity/result/ActivityResultCaller;Ljava/lang/String;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    iget-object v1, p0, LV3/e;->e:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v1, LPa/c0;

    .line 59
    .line 60
    if-eqz v0, :cond_1

    .line 61
    .line 62
    iget-object p1, p0, LV3/e;->d:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast p1, LPa/c0;

    .line 65
    .line 66
    invoke-virtual {p1}, LPa/c0;->invoke()V

    .line 67
    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_1
    iget-object p1, p1, Lca/d;->g:Lca/a;

    .line 71
    .line 72
    invoke-virtual {v1, p1}, LPa/c0;->invoke(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    :goto_0
    return-void

    .line 76
    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    .line 77
    .line 78
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    if-eqz p1, :cond_2

    .line 83
    .line 84
    iget-object p1, p0, LV3/e;->b:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast p1, Lj4/q;

    .line 87
    .line 88
    invoke-virtual {p1}, Lj4/q;->invoke()V

    .line 89
    .line 90
    .line 91
    goto :goto_2

    .line 92
    :cond_2
    iget-object p1, p0, LV3/e;->c:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast p1, LV3/f;

    .line 95
    .line 96
    iget-object v0, p1, LV3/f;->f:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckWithFaceRecognitionFragment;

    .line 97
    .line 98
    const-string v1, "<this>"

    .line 99
    .line 100
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    const-string v1, "android.permission.CAMERA"

    .line 104
    .line 105
    const-string v2, "permission"

    .line 106
    .line 107
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    if-eqz v0, :cond_3

    .line 111
    .line 112
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    invoke-static {v0, v1}, Landroidx/core/app/a;->h(Landroid/app/Activity;Ljava/lang/String;)Z

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    goto :goto_1

    .line 121
    :cond_3
    const/4 v0, 0x0

    .line 122
    :goto_1
    iget-object v1, p0, LV3/e;->e:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast v1, Lj4/q;

    .line 125
    .line 126
    if-eqz v0, :cond_4

    .line 127
    .line 128
    iget-object p1, p0, LV3/e;->d:Ljava/lang/Object;

    .line 129
    .line 130
    check-cast p1, Lj4/q;

    .line 131
    .line 132
    invoke-virtual {p1}, Lj4/q;->invoke()V

    .line 133
    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_4
    iget-object p1, p1, LV3/f;->g:LV3/c;

    .line 137
    .line 138
    invoke-virtual {v1, p1}, Lj4/q;->invoke(Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    :goto_2
    return-void

    .line 142
    nop

    .line 143
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
