.class public final LV3/g;
.super LV3/d;
.source "SourceFile"


# direct methods
.method public constructor <init>(LK3/d;)V
    .locals 2

    .line 1
    const-string v0, "caller"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Lm/l;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-direct {p0, p1, v0, v1}, LV3/d;-><init>(Landroidx/activity/result/ActivityResultCaller;Lm/b;I)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
