.class public abstract LA4/a;
.super LA4/b;
.source "SourceFile"


# instance fields
.field public d:LC4/a;

.field public final e:[F

.field public final f:Z

.field public final g:F

.field public final h:F

.field public final i:F


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, LA4/b;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    new-array v0, v0, [F

    .line 6
    .line 7
    iput-object v0, p0, LA4/a;->e:[F

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    iput-boolean v0, p0, LA4/a;->f:Z

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    iput v0, p0, LA4/a;->g:F

    .line 14
    .line 15
    iput v0, p0, LA4/a;->h:F

    .line 16
    .line 17
    iput v0, p0, LA4/a;->i:F

    .line 18
    .line 19
    const/high16 v0, 0x41200000    # 10.0f

    .line 20
    .line 21
    invoke-static {v0}, LG4/i;->b(F)F

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    iput v0, p0, LA4/b;->c:F

    .line 26
    .line 27
    const/high16 v0, 0x40a00000    # 5.0f

    .line 28
    .line 29
    invoke-static {v0}, LG4/i;->b(F)F

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    iput v1, p0, LA4/b;->a:F

    .line 34
    .line 35
    invoke-static {v0}, LG4/i;->b(F)F

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    iput v0, p0, LA4/b;->b:F

    .line 40
    .line 41
    new-instance v0, Ljava/util/ArrayList;

    .line 42
    .line 43
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 44
    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .locals 9

    .line 1
    const-string v0, ""

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    move-object v3, v0

    .line 5
    move v2, v1

    .line 6
    :goto_0
    iget-object v4, p0, LA4/a;->e:[F

    .line 7
    .line 8
    array-length v5, v4

    .line 9
    if-ge v2, v5, :cond_7

    .line 10
    .line 11
    if-ltz v2, :cond_5

    .line 12
    .line 13
    array-length v4, v4

    .line 14
    if-lt v2, v4, :cond_0

    .line 15
    .line 16
    goto :goto_2

    .line 17
    :cond_0
    iget-object v4, p0, LA4/a;->d:LC4/a;

    .line 18
    .line 19
    if-eqz v4, :cond_1

    .line 20
    .line 21
    iget v4, v4, LC4/a;->b:I

    .line 22
    .line 23
    if-eqz v4, :cond_4

    .line 24
    .line 25
    :cond_1
    new-instance v4, LC4/a;

    .line 26
    .line 27
    const/4 v5, 0x0

    .line 28
    const/4 v6, 0x0

    .line 29
    const/4 v7, 0x0

    .line 30
    invoke-direct {v4, v6, v7}, LC4/a;-><init>(IZ)V

    .line 31
    .line 32
    .line 33
    iput v5, v4, LC4/a;->b:I

    .line 34
    .line 35
    new-instance v5, Ljava/lang/StringBuffer;

    .line 36
    .line 37
    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    .line 38
    .line 39
    .line 40
    move v6, v1

    .line 41
    :goto_1
    if-gez v6, :cond_3

    .line 42
    .line 43
    if-nez v6, :cond_2

    .line 44
    .line 45
    const-string v7, "."

    .line 46
    .line 47
    invoke-virtual {v5, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 48
    .line 49
    .line 50
    :cond_2
    const-string v7, "0"

    .line 51
    .line 52
    invoke-virtual {v5, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 53
    .line 54
    .line 55
    add-int/lit8 v6, v6, 0x1

    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_3
    new-instance v6, Ljava/text/DecimalFormat;

    .line 59
    .line 60
    new-instance v7, Ljava/lang/StringBuilder;

    .line 61
    .line 62
    const-string v8, "###,###,###,##0"

    .line 63
    .line 64
    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v5

    .line 71
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    invoke-direct {v6, v5}, Ljava/text/DecimalFormat;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    iput-object v6, v4, LC4/a;->c:Ljava/lang/Object;

    .line 82
    .line 83
    iput-object v4, p0, LA4/a;->d:LC4/a;

    .line 84
    .line 85
    :cond_4
    iget-object v4, p0, LA4/a;->d:LC4/a;

    .line 86
    .line 87
    iget-object v5, p0, LA4/a;->e:[F

    .line 88
    .line 89
    aget v5, v5, v2

    .line 90
    .line 91
    invoke-virtual {v4, v5, p0}, LC4/a;->getFormattedValue(FLA4/a;)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    goto :goto_3

    .line 96
    :cond_5
    :goto_2
    move-object v4, v0

    .line 97
    :goto_3
    if-eqz v4, :cond_6

    .line 98
    .line 99
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 100
    .line 101
    .line 102
    move-result v5

    .line 103
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 104
    .line 105
    .line 106
    move-result v6

    .line 107
    if-ge v5, v6, :cond_6

    .line 108
    .line 109
    move-object v3, v4

    .line 110
    :cond_6
    add-int/lit8 v2, v2, 0x1

    .line 111
    .line 112
    goto :goto_0

    .line 113
    :cond_7
    return-object v3
.end method
