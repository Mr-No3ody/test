.class public abstract LA4/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:F

.field public b:F

.field public c:F


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/high16 v0, 0x40a00000    # 5.0f

    .line 5
    .line 6
    iput v0, p0, LA4/b;->a:F

    .line 7
    .line 8
    iput v0, p0, LA4/b;->b:F

    .line 9
    .line 10
    const/high16 v0, 0x41200000    # 10.0f

    .line 11
    .line 12
    invoke-static {v0}, LG4/i;->b(F)F

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iput v0, p0, LA4/b;->c:F

    .line 17
    .line 18
    return-void
.end method
