.class public final LW2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/imageformat/ImageFormat$FormatChecker;


# static fields
.field public static final b:LW2/a;

.field public static final c:[B

.field public static final d:I

.field public static final e:[B

.field public static final f:I

.field public static final g:[B

.field public static final h:[B

.field public static final i:[B

.field public static final j:I

.field public static final k:[B

.field public static final l:I

.field public static final m:[B

.field public static final n:[[B

.field public static final o:[B

.field public static final p:[B

.field public static final q:I

.field public static final r:[B

.field public static final s:[B

.field public static final t:[B


# instance fields
.field public final a:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    .line 1
    new-instance v0, LW2/a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LW2/a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LW2/b;->b:LW2/a;

    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    new-array v1, v0, [B

    .line 11
    .line 12
    fill-array-data v1, :array_0

    .line 13
    .line 14
    .line 15
    sput-object v1, LW2/b;->c:[B

    .line 16
    .line 17
    sput v0, LW2/b;->d:I

    .line 18
    .line 19
    const/16 v0, 0x8

    .line 20
    .line 21
    new-array v1, v0, [B

    .line 22
    .line 23
    fill-array-data v1, :array_1

    .line 24
    .line 25
    .line 26
    sput-object v1, LW2/b;->e:[B

    .line 27
    .line 28
    sput v0, LW2/b;->f:I

    .line 29
    .line 30
    const-string v0, "GIF87a"

    .line 31
    .line 32
    invoke-static {v0}, Le1/a;->c(Ljava/lang/String;)[B

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    sput-object v0, LW2/b;->g:[B

    .line 37
    .line 38
    const-string v0, "GIF89a"

    .line 39
    .line 40
    invoke-static {v0}, Le1/a;->c(Ljava/lang/String;)[B

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    sput-object v0, LW2/b;->h:[B

    .line 45
    .line 46
    const-string v0, "BM"

    .line 47
    .line 48
    invoke-static {v0}, Le1/a;->c(Ljava/lang/String;)[B

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    sput-object v0, LW2/b;->i:[B

    .line 53
    .line 54
    array-length v0, v0

    .line 55
    sput v0, LW2/b;->j:I

    .line 56
    .line 57
    const/4 v0, 0x4

    .line 58
    new-array v1, v0, [B

    .line 59
    .line 60
    fill-array-data v1, :array_2

    .line 61
    .line 62
    .line 63
    sput-object v1, LW2/b;->k:[B

    .line 64
    .line 65
    sput v0, LW2/b;->l:I

    .line 66
    .line 67
    const-string v1, "ftyp"

    .line 68
    .line 69
    invoke-static {v1}, Le1/a;->c(Ljava/lang/String;)[B

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    sput-object v2, LW2/b;->m:[B

    .line 74
    .line 75
    const-string v2, "heic"

    .line 76
    .line 77
    invoke-static {v2}, Le1/a;->c(Ljava/lang/String;)[B

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    const-string v2, "heix"

    .line 82
    .line 83
    invoke-static {v2}, Le1/a;->c(Ljava/lang/String;)[B

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    const-string v2, "hevc"

    .line 88
    .line 89
    invoke-static {v2}, Le1/a;->c(Ljava/lang/String;)[B

    .line 90
    .line 91
    .line 92
    move-result-object v5

    .line 93
    const-string v2, "hevx"

    .line 94
    .line 95
    invoke-static {v2}, Le1/a;->c(Ljava/lang/String;)[B

    .line 96
    .line 97
    .line 98
    move-result-object v6

    .line 99
    const-string v2, "mif1"

    .line 100
    .line 101
    invoke-static {v2}, Le1/a;->c(Ljava/lang/String;)[B

    .line 102
    .line 103
    .line 104
    move-result-object v7

    .line 105
    const-string v2, "msf1"

    .line 106
    .line 107
    invoke-static {v2}, Le1/a;->c(Ljava/lang/String;)[B

    .line 108
    .line 109
    .line 110
    move-result-object v8

    .line 111
    filled-new-array/range {v3 .. v8}, [[B

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    sput-object v2, LW2/b;->n:[[B

    .line 116
    .line 117
    new-array v2, v0, [B

    .line 118
    .line 119
    fill-array-data v2, :array_3

    .line 120
    .line 121
    .line 122
    sput-object v2, LW2/b;->o:[B

    .line 123
    .line 124
    new-array v2, v0, [B

    .line 125
    .line 126
    fill-array-data v2, :array_4

    .line 127
    .line 128
    .line 129
    sput-object v2, LW2/b;->p:[B

    .line 130
    .line 131
    sput v0, LW2/b;->q:I

    .line 132
    .line 133
    new-array v0, v0, [B

    .line 134
    .line 135
    fill-array-data v0, :array_5

    .line 136
    .line 137
    .line 138
    sput-object v0, LW2/b;->r:[B

    .line 139
    .line 140
    invoke-static {v1}, Le1/a;->c(Ljava/lang/String;)[B

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    sput-object v0, LW2/b;->s:[B

    .line 145
    .line 146
    const-string v0, "avif"

    .line 147
    .line 148
    invoke-static {v0}, Le1/a;->c(Ljava/lang/String;)[B

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    sput-object v0, LW2/b;->t:[B

    .line 153
    .line 154
    return-void

    .line 155
    :array_0
    .array-data 1
        -0x1t
        -0x28t
        -0x1t
    .end array-data

    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    :array_1
    .array-data 1
        -0x77t
        0x50t
        0x4et
        0x47t
        0xdt
        0xat
        0x1at
        0xat
    .end array-data

    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    :array_2
    .array-data 1
        0x0t
        0x0t
        0x1t
        0x0t
    .end array-data

    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    :array_3
    .array-data 1
        0x49t
        0x49t
        0x2at
        0x0t
    .end array-data

    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    :array_4
    .array-data 1
        0x4dt
        0x4dt
        0x0t
        0x2at
    .end array-data

    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    :array_5
    .array-data 1
        0x3t
        0x0t
        0x8t
        0x0t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 11

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/16 v0, 0x15

    .line 5
    .line 6
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const/16 v0, 0x14

    .line 11
    .line 12
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    sget v0, LW2/b;->d:I

    .line 17
    .line 18
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    sget v0, LW2/b;->f:I

    .line 23
    .line 24
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    const/4 v0, 0x6

    .line 29
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object v5

    .line 33
    sget v0, LW2/b;->j:I

    .line 34
    .line 35
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 36
    .line 37
    .line 38
    move-result-object v6

    .line 39
    sget v0, LW2/b;->l:I

    .line 40
    .line 41
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 42
    .line 43
    .line 44
    move-result-object v7

    .line 45
    const/16 v0, 0xc

    .line 46
    .line 47
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 48
    .line 49
    .line 50
    move-result-object v8

    .line 51
    const/4 v0, 0x4

    .line 52
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 53
    .line 54
    .line 55
    move-result-object v9

    .line 56
    move-object v10, v8

    .line 57
    filled-new-array/range {v1 .. v10}, [Ljava/lang/Integer;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    check-cast v0, [Ljava/lang/Comparable;

    .line 62
    .line 63
    const-string v1, "<this>"

    .line 64
    .line 65
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    array-length v2, v0

    .line 69
    if-nez v2, :cond_0

    .line 70
    .line 71
    const/4 v0, 0x0

    .line 72
    goto :goto_1

    .line 73
    :cond_0
    const/4 v2, 0x0

    .line 74
    aget-object v2, v0, v2

    .line 75
    .line 76
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    array-length v1, v0

    .line 80
    const/4 v3, 0x1

    .line 81
    sub-int/2addr v1, v3

    .line 82
    if-gt v3, v1, :cond_2

    .line 83
    .line 84
    :goto_0
    aget-object v4, v0, v3

    .line 85
    .line 86
    invoke-interface {v2, v4}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I

    .line 87
    .line 88
    .line 89
    move-result v5

    .line 90
    if-gez v5, :cond_1

    .line 91
    .line 92
    move-object v2, v4

    .line 93
    :cond_1
    if-eq v3, v1, :cond_2

    .line 94
    .line 95
    add-int/lit8 v3, v3, 0x1

    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_2
    move-object v0, v2

    .line 99
    :goto_1
    if-eqz v0, :cond_3

    .line 100
    .line 101
    check-cast v0, Ljava/lang/Number;

    .line 102
    .line 103
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    iput v0, p0, LW2/b;->a:I

    .line 108
    .line 109
    return-void

    .line 110
    :cond_3
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 111
    .line 112
    const-string v1, "Required value was null."

    .line 113
    .line 114
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    throw v0
.end method


# virtual methods
.method public final determineFormat([BI)LW2/e;
    .locals 3

    .line 1
    const-string v0, "headerBytes"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/16 v0, 0x14

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-lt p2, v0, :cond_0

    .line 10
    .line 11
    sget-object v0, Lx2/a;->c:[B

    .line 12
    .line 13
    invoke-static {v1, p1, v0}, Lx2/a;->b(I[B[B)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    const/16 v0, 0x8

    .line 20
    .line 21
    sget-object v2, Lx2/a;->d:[B

    .line 22
    .line 23
    invoke-static {v0, p1, v2}, Lx2/a;->b(I[B[B)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    sget-object v0, Lx2/a;->a:Lcom/facebook/common/webp/WebpBitmapFactory;

    .line 32
    .line 33
    :cond_1
    :goto_0
    sget-object v0, LW2/b;->b:LW2/a;

    .line 34
    .line 35
    if-eqz v1, :cond_2

    .line 36
    .line 37
    invoke-static {v0, p1, p2}, LW2/a;->access$getWebpFormat(LW2/a;[BI)LW2/e;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    return-object p1

    .line 42
    :cond_2
    invoke-static {v0, p1, p2}, LW2/a;->access$isJpegHeader(LW2/a;[BI)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_3

    .line 47
    .line 48
    sget-object p1, LW2/c;->a:LW2/e;

    .line 49
    .line 50
    return-object p1

    .line 51
    :cond_3
    invoke-static {v0, p1, p2}, LW2/a;->access$isPngHeader(LW2/a;[BI)Z

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    if-eqz v1, :cond_4

    .line 56
    .line 57
    sget-object p1, LW2/c;->b:LW2/e;

    .line 58
    .line 59
    return-object p1

    .line 60
    :cond_4
    invoke-static {v0, p1, p2}, LW2/a;->access$isGifHeader(LW2/a;[BI)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_5

    .line 65
    .line 66
    sget-object p1, LW2/c;->c:LW2/e;

    .line 67
    .line 68
    return-object p1

    .line 69
    :cond_5
    invoke-static {v0, p1, p2}, LW2/a;->access$isBmpHeader(LW2/a;[BI)Z

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-eqz v1, :cond_6

    .line 74
    .line 75
    sget-object p1, LW2/c;->d:LW2/e;

    .line 76
    .line 77
    return-object p1

    .line 78
    :cond_6
    invoke-static {v0, p1, p2}, LW2/a;->access$isIcoHeader(LW2/a;[BI)Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    if-eqz v1, :cond_7

    .line 83
    .line 84
    sget-object p1, LW2/c;->e:LW2/e;

    .line 85
    .line 86
    return-object p1

    .line 87
    :cond_7
    invoke-static {v0, p1, p2}, LW2/a;->access$isAvifHeader(LW2/a;[BI)Z

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    if-eqz v1, :cond_8

    .line 92
    .line 93
    sget-object p1, LW2/c;->n:LW2/e;

    .line 94
    .line 95
    return-object p1

    .line 96
    :cond_8
    invoke-static {v0, p1, p2}, LW2/a;->access$isHeifHeader(LW2/a;[BI)Z

    .line 97
    .line 98
    .line 99
    move-result v1

    .line 100
    if-eqz v1, :cond_9

    .line 101
    .line 102
    sget-object p1, LW2/c;->k:LW2/e;

    .line 103
    .line 104
    return-object p1

    .line 105
    :cond_9
    invoke-static {v0, p1, p2}, LW2/a;->access$isBinaryXmlHeader(LW2/a;[BI)Z

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    if-eqz v1, :cond_a

    .line 110
    .line 111
    sget-object p1, LW2/c;->m:LW2/e;

    .line 112
    .line 113
    return-object p1

    .line 114
    :cond_a
    invoke-static {v0, p1, p2}, LW2/a;->access$isDngHeader(LW2/a;[BI)Z

    .line 115
    .line 116
    .line 117
    move-result p1

    .line 118
    if-eqz p1, :cond_b

    .line 119
    .line 120
    sget-object p1, LW2/c;->l:LW2/e;

    .line 121
    .line 122
    return-object p1

    .line 123
    :cond_b
    sget-object p1, LW2/e;->c:LW2/e;

    .line 124
    .line 125
    return-object p1
.end method

.method public final getHeaderSize()I
    .locals 1

    .line 1
    iget v0, p0, LW2/b;->a:I

    .line 2
    .line 3
    return v0
.end method
