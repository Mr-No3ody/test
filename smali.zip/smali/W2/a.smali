.class public final LW2/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LW2/a;-><init>()V

    return-void
.end method

.method public static final synthetic access$getWebpFormat(LW2/a;[BI)LW2/e;
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->getWebpFormat([BI)LW2/e;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static final synthetic access$isAvifHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isAvifHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$isBinaryXmlHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isBinaryXmlHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$isBmpHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isBmpHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$isDngHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isDngHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$isGifHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isGifHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$isHeifHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isHeifHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$isIcoHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isIcoHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$isJpegHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isJpegHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public static final synthetic access$isPngHeader(LW2/a;[BI)Z
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LW2/a;->isPngHeader([BI)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method private final getBoxLength([B)I
    .locals 2

    .line 1
    array-length v0, p1

    .line 2
    const/4 v1, 0x4

    .line 3
    if-ge v0, v1, :cond_0

    .line 4
    .line 5
    const/4 p1, -0x1

    .line 6
    return p1

    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    aget-byte v0, p1, v0

    .line 9
    .line 10
    and-int/lit16 v0, v0, 0xff

    .line 11
    .line 12
    shl-int/lit8 v0, v0, 0x18

    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    aget-byte v1, p1, v1

    .line 16
    .line 17
    and-int/lit16 v1, v1, 0xff

    .line 18
    .line 19
    shl-int/lit8 v1, v1, 0x10

    .line 20
    .line 21
    or-int/2addr v0, v1

    .line 22
    const/4 v1, 0x2

    .line 23
    aget-byte v1, p1, v1

    .line 24
    .line 25
    and-int/lit16 v1, v1, 0xff

    .line 26
    .line 27
    shl-int/lit8 v1, v1, 0x8

    .line 28
    .line 29
    or-int/2addr v0, v1

    .line 30
    const/4 v1, 0x3

    .line 31
    aget-byte p1, p1, v1

    .line 32
    .line 33
    and-int/lit16 p1, p1, 0xff

    .line 34
    .line 35
    or-int/2addr p1, v0

    .line 36
    return p1
.end method

.method private final getWebpFormat([BI)LW2/e;
    .locals 7

    .line 1
    const/16 v0, 0x14

    .line 2
    .line 3
    if-lt p2, v0, :cond_7

    .line 4
    .line 5
    sget-object v1, Lx2/a;->c:[B

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-static {v2, p1, v1}, Lx2/a;->b(I[B[B)Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_8

    .line 13
    .line 14
    const/16 v1, 0x8

    .line 15
    .line 16
    sget-object v3, Lx2/a;->d:[B

    .line 17
    .line 18
    invoke-static {v1, p1, v3}, Lx2/a;->b(I[B[B)Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-eqz v1, :cond_8

    .line 23
    .line 24
    sget-object v1, Lx2/a;->e:[B

    .line 25
    .line 26
    const/16 v3, 0xc

    .line 27
    .line 28
    invoke-static {v3, p1, v1}, Lx2/a;->b(I[B[B)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_0

    .line 33
    .line 34
    sget-object p1, LW2/c;->f:LW2/e;

    .line 35
    .line 36
    return-object p1

    .line 37
    :cond_0
    sget-object v1, Lx2/a;->f:[B

    .line 38
    .line 39
    invoke-static {v3, p1, v1}, Lx2/a;->b(I[B[B)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_1

    .line 44
    .line 45
    sget-object p1, LW2/c;->g:LW2/e;

    .line 46
    .line 47
    return-object p1

    .line 48
    :cond_1
    const/16 v1, 0x15

    .line 49
    .line 50
    if-lt p2, v1, :cond_6

    .line 51
    .line 52
    sget-object p2, Lx2/a;->g:[B

    .line 53
    .line 54
    invoke-static {v3, p1, p2}, Lx2/a;->b(I[B[B)Z

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    if-eqz v1, :cond_6

    .line 59
    .line 60
    invoke-static {v3, p1, p2}, Lx2/a;->b(I[B[B)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    aget-byte v4, p1, v0

    .line 65
    .line 66
    const/4 v5, 0x2

    .line 67
    and-int/2addr v4, v5

    .line 68
    const/4 v6, 0x1

    .line 69
    if-ne v4, v5, :cond_2

    .line 70
    .line 71
    move v4, v6

    .line 72
    goto :goto_0

    .line 73
    :cond_2
    move v4, v2

    .line 74
    :goto_0
    if-eqz v1, :cond_3

    .line 75
    .line 76
    if-eqz v4, :cond_3

    .line 77
    .line 78
    sget-object p1, LW2/c;->j:LW2/e;

    .line 79
    .line 80
    return-object p1

    .line 81
    :cond_3
    invoke-static {v3, p1, p2}, Lx2/a;->b(I[B[B)Z

    .line 82
    .line 83
    .line 84
    move-result p2

    .line 85
    aget-byte p1, p1, v0

    .line 86
    .line 87
    const/16 v0, 0x10

    .line 88
    .line 89
    and-int/2addr p1, v0

    .line 90
    if-ne p1, v0, :cond_4

    .line 91
    .line 92
    move v2, v6

    .line 93
    :cond_4
    if-eqz p2, :cond_5

    .line 94
    .line 95
    if-eqz v2, :cond_5

    .line 96
    .line 97
    sget-object p1, LW2/c;->i:LW2/e;

    .line 98
    .line 99
    return-object p1

    .line 100
    :cond_5
    sget-object p1, LW2/c;->h:LW2/e;

    .line 101
    .line 102
    return-object p1

    .line 103
    :cond_6
    sget-object p1, LW2/e;->c:LW2/e;

    .line 104
    .line 105
    return-object p1

    .line 106
    :cond_7
    sget-object p1, Lx2/a;->a:Lcom/facebook/common/webp/WebpBitmapFactory;

    .line 107
    .line 108
    :cond_8
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 109
    .line 110
    const-string p2, "Check failed."

    .line 111
    .line 112
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    throw p1
.end method

.method private final isAvifHeader([BI)Z
    .locals 2

    .line 1
    const/16 v0, 0xc

    .line 2
    .line 3
    if-ge p2, v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    invoke-direct {p0, p1}, LW2/a;->getBoxLength([B)I

    .line 7
    .line 8
    .line 9
    move-result p2

    .line 10
    const/16 v0, 0x8

    .line 11
    .line 12
    if-ge p2, v0, :cond_1

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_1
    sget-object p2, LW2/b;->s:[B

    .line 16
    .line 17
    const/4 v1, 0x4

    .line 18
    invoke-static {v1, p1, p2}, Le1/a;->M(I[B[B)Z

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    if-nez p2, :cond_2

    .line 23
    .line 24
    :goto_0
    const/4 p1, 0x0

    .line 25
    return p1

    .line 26
    :cond_2
    sget-object p2, LW2/b;->t:[B

    .line 27
    .line 28
    invoke-static {v0, p1, p2}, Le1/a;->M(I[B[B)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    return p1
.end method

.method private final isBinaryXmlHeader([BI)Z
    .locals 1

    .line 1
    const/4 v0, 0x4

    .line 2
    if-lt p2, v0, :cond_0

    .line 3
    .line 4
    sget-object p2, LW2/b;->r:[B

    .line 5
    .line 6
    invoke-static {p1, p2}, Le1/a;->a0([B[B)Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    const/4 p1, 0x1

    .line 13
    return p1

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    return p1
.end method

.method private final isBmpHeader([BI)Z
    .locals 2

    .line 1
    sget-object v0, LW2/b;->i:[B

    .line 2
    .line 3
    array-length v1, v0

    .line 4
    if-ge p2, v1, :cond_0

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    return p1

    .line 8
    :cond_0
    invoke-static {p1, v0}, Le1/a;->a0([B[B)Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    return p1
.end method

.method private final isDngHeader([BI)Z
    .locals 1

    .line 1
    sget v0, LW2/b;->q:I

    .line 2
    .line 3
    if-lt p2, v0, :cond_1

    .line 4
    .line 5
    sget-object p2, LW2/b;->o:[B

    .line 6
    .line 7
    invoke-static {p1, p2}, Le1/a;->a0([B[B)Z

    .line 8
    .line 9
    .line 10
    move-result p2

    .line 11
    if-nez p2, :cond_0

    .line 12
    .line 13
    sget-object p2, LW2/b;->p:[B

    .line 14
    .line 15
    invoke-static {p1, p2}, Le1/a;->a0([B[B)Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    if-eqz p1, :cond_1

    .line 20
    .line 21
    :cond_0
    const/4 p1, 0x1

    .line 22
    return p1

    .line 23
    :cond_1
    const/4 p1, 0x0

    .line 24
    return p1
.end method

.method private final isGifHeader([BI)Z
    .locals 1

    .line 1
    const/4 v0, 0x6

    .line 2
    if-ge p2, v0, :cond_0

    .line 3
    .line 4
    goto :goto_0

    .line 5
    :cond_0
    sget-object p2, LW2/b;->g:[B

    .line 6
    .line 7
    invoke-static {p1, p2}, Le1/a;->a0([B[B)Z

    .line 8
    .line 9
    .line 10
    move-result p2

    .line 11
    if-nez p2, :cond_2

    .line 12
    .line 13
    sget-object p2, LW2/b;->h:[B

    .line 14
    .line 15
    invoke-static {p1, p2}, Le1/a;->a0([B[B)Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    if-eqz p1, :cond_1

    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_1
    :goto_0
    const/4 p1, 0x0

    .line 23
    return p1

    .line 24
    :cond_2
    :goto_1
    const/4 p1, 0x1

    .line 25
    return p1
.end method

.method private final isHeifHeader([BI)Z
    .locals 5

    .line 1
    const/16 v0, 0xc

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-ge p2, v0, :cond_0

    .line 5
    .line 6
    goto :goto_1

    .line 7
    :cond_0
    const/4 p2, 0x3

    .line 8
    aget-byte p2, p1, p2

    .line 9
    .line 10
    const/16 v0, 0x8

    .line 11
    .line 12
    if-ge p2, v0, :cond_1

    .line 13
    .line 14
    goto :goto_1

    .line 15
    :cond_1
    sget-object p2, LW2/b;->m:[B

    .line 16
    .line 17
    const/4 v2, 0x4

    .line 18
    invoke-static {v2, p1, p2}, Le1/a;->M(I[B[B)Z

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    if-nez p2, :cond_2

    .line 23
    .line 24
    goto :goto_1

    .line 25
    :cond_2
    sget-object p2, LW2/b;->n:[[B

    .line 26
    .line 27
    array-length v2, p2

    .line 28
    move v3, v1

    .line 29
    :goto_0
    if-ge v3, v2, :cond_4

    .line 30
    .line 31
    aget-object v4, p2, v3

    .line 32
    .line 33
    invoke-static {v0, p1, v4}, Le1/a;->M(I[B[B)Z

    .line 34
    .line 35
    .line 36
    move-result v4

    .line 37
    if-eqz v4, :cond_3

    .line 38
    .line 39
    const/4 p1, 0x1

    .line 40
    return p1

    .line 41
    :cond_3
    add-int/lit8 v3, v3, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_4
    :goto_1
    return v1
.end method

.method private final isIcoHeader([BI)Z
    .locals 2

    .line 1
    sget-object v0, LW2/b;->k:[B

    .line 2
    .line 3
    array-length v1, v0

    .line 4
    if-ge p2, v1, :cond_0

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    return p1

    .line 8
    :cond_0
    invoke-static {p1, v0}, Le1/a;->a0([B[B)Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    return p1
.end method

.method private final isJpegHeader([BI)Z
    .locals 2

    .line 1
    sget-object v0, LW2/b;->c:[B

    .line 2
    .line 3
    array-length v1, v0

    .line 4
    if-lt p2, v1, :cond_0

    .line 5
    .line 6
    invoke-static {p1, v0}, Le1/a;->a0([B[B)Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    const/4 p1, 0x1

    .line 13
    return p1

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    return p1
.end method

.method private final isPngHeader([BI)Z
    .locals 2

    .line 1
    sget-object v0, LW2/b;->e:[B

    .line 2
    .line 3
    array-length v1, v0

    .line 4
    if-lt p2, v1, :cond_0

    .line 5
    .line 6
    invoke-static {p1, v0}, Le1/a;->a0([B[B)Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    const/4 p1, 0x1

    .line 13
    return p1

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    return p1
.end method
