.class public final LW2/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final d:LW2/f;

.field public static final e:Ljava/lang/Object;


# instance fields
.field public final a:I

.field public final b:LW2/b;

.field public c:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, LW2/f;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LW2/f;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LW2/g;->d:LW2/f;

    .line 8
    .line 9
    sget-object v0, Lxf/k;->a:Lxf/k;

    .line 10
    .line 11
    new-instance v1, LPa/b0;

    .line 12
    .line 13
    const/16 v2, 0x17

    .line 14
    .line 15
    invoke-direct {v1, v2}, LPa/b0;-><init>(I)V

    .line 16
    .line 17
    .line 18
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    sput-object v0, LW2/g;->e:Ljava/lang/Object;

    .line 23
    .line 24
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, LW2/b;

    .line 5
    .line 6
    invoke-direct {v0}, LW2/b;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LW2/g;->b:LW2/b;

    .line 10
    .line 11
    iget v0, v0, LW2/b;->a:I

    .line 12
    .line 13
    iput v0, p0, LW2/g;->a:I

    .line 14
    .line 15
    return-void
.end method
