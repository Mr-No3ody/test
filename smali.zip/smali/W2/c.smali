.class public abstract LW2/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LW2/e;

.field public static final b:LW2/e;

.field public static final c:LW2/e;

.field public static final d:LW2/e;

.field public static final e:LW2/e;

.field public static final f:LW2/e;

.field public static final g:LW2/e;

.field public static final h:LW2/e;

.field public static final i:LW2/e;

.field public static final j:LW2/e;

.field public static final k:LW2/e;

.field public static final l:LW2/e;

.field public static final m:LW2/e;

.field public static final n:LW2/e;

.field public static final o:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .locals 15

    .line 1
    new-instance v0, LW2/e;

    .line 2
    .line 3
    const-string v1, "JPEG"

    .line 4
    .line 5
    const-string v2, "jpeg"

    .line 6
    .line 7
    invoke-direct {v0, v1, v2}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    sput-object v0, LW2/c;->a:LW2/e;

    .line 11
    .line 12
    new-instance v1, LW2/e;

    .line 13
    .line 14
    const-string v2, "PNG"

    .line 15
    .line 16
    const-string v3, "png"

    .line 17
    .line 18
    invoke-direct {v1, v2, v3}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    sput-object v1, LW2/c;->b:LW2/e;

    .line 22
    .line 23
    new-instance v2, LW2/e;

    .line 24
    .line 25
    const-string v3, "GIF"

    .line 26
    .line 27
    const-string v4, "gif"

    .line 28
    .line 29
    invoke-direct {v2, v3, v4}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    sput-object v2, LW2/c;->c:LW2/e;

    .line 33
    .line 34
    new-instance v3, LW2/e;

    .line 35
    .line 36
    const-string v4, "BMP"

    .line 37
    .line 38
    const-string v5, "bmp"

    .line 39
    .line 40
    invoke-direct {v3, v4, v5}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    sput-object v3, LW2/c;->d:LW2/e;

    .line 44
    .line 45
    new-instance v4, LW2/e;

    .line 46
    .line 47
    const-string v5, "ICO"

    .line 48
    .line 49
    const-string v6, "ico"

    .line 50
    .line 51
    invoke-direct {v4, v5, v6}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    sput-object v4, LW2/c;->e:LW2/e;

    .line 55
    .line 56
    new-instance v5, LW2/e;

    .line 57
    .line 58
    const-string v6, "WEBP_SIMPLE"

    .line 59
    .line 60
    const-string/jumbo v7, "webp"

    .line 61
    .line 62
    .line 63
    invoke-direct {v5, v6, v7}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    sput-object v5, LW2/c;->f:LW2/e;

    .line 67
    .line 68
    new-instance v6, LW2/e;

    .line 69
    .line 70
    const-string v8, "WEBP_LOSSLESS"

    .line 71
    .line 72
    invoke-direct {v6, v8, v7}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    sput-object v6, LW2/c;->g:LW2/e;

    .line 76
    .line 77
    move-object v8, v7

    .line 78
    new-instance v7, LW2/e;

    .line 79
    .line 80
    const-string v9, "WEBP_EXTENDED"

    .line 81
    .line 82
    invoke-direct {v7, v9, v8}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    sput-object v7, LW2/c;->h:LW2/e;

    .line 86
    .line 87
    move-object v9, v8

    .line 88
    new-instance v8, LW2/e;

    .line 89
    .line 90
    const-string v10, "WEBP_EXTENDED_WITH_ALPHA"

    .line 91
    .line 92
    invoke-direct {v8, v10, v9}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    sput-object v8, LW2/c;->i:LW2/e;

    .line 96
    .line 97
    move-object v10, v9

    .line 98
    new-instance v9, LW2/e;

    .line 99
    .line 100
    const-string v11, "WEBP_ANIMATED"

    .line 101
    .line 102
    invoke-direct {v9, v11, v10}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    sput-object v9, LW2/c;->j:LW2/e;

    .line 106
    .line 107
    new-instance v10, LW2/e;

    .line 108
    .line 109
    const-string v11, "HEIF"

    .line 110
    .line 111
    const-string v12, "heif"

    .line 112
    .line 113
    invoke-direct {v10, v11, v12}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    sput-object v10, LW2/c;->k:LW2/e;

    .line 117
    .line 118
    new-instance v11, LW2/e;

    .line 119
    .line 120
    const-string v12, "DNG"

    .line 121
    .line 122
    const-string v13, "dng"

    .line 123
    .line 124
    invoke-direct {v11, v12, v13}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    sput-object v11, LW2/c;->l:LW2/e;

    .line 128
    .line 129
    new-instance v11, LW2/e;

    .line 130
    .line 131
    const-string v12, "BINARY_XML"

    .line 132
    .line 133
    const-string/jumbo v13, "xml"

    .line 134
    .line 135
    .line 136
    invoke-direct {v11, v12, v13}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    sput-object v11, LW2/c;->m:LW2/e;

    .line 140
    .line 141
    new-instance v12, LW2/e;

    .line 142
    .line 143
    const-string v13, "AVIF"

    .line 144
    .line 145
    const-string v14, "avif"

    .line 146
    .line 147
    invoke-direct {v12, v13, v14}, LW2/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    sput-object v12, LW2/c;->n:LW2/e;

    .line 151
    .line 152
    filled-new-array/range {v0 .. v12}, [LW2/e;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    invoke-static {v0}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 157
    .line 158
    .line 159
    move-result-object v0

    .line 160
    sput-object v0, LW2/c;->o:Ljava/util/List;

    .line 161
    .line 162
    return-void
.end method
