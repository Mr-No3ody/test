.class public final Lbe/c;
.super LLa/F;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/teller/ui/mvp/contract/BettingConfirmPaymentOrderContract$Presenter;


# virtual methods
.method public final bettingWithdrawRedeemCodePay(Lcom/transsnet/palmpay/teller/bean/BettingWithdrawRedeemPayReq;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/teller/ui/mvp/contract/BettingConfirmPaymentOrderContract$View;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 7
    .line 8
    .line 9
    sget-object v0, LQd/a;->a:LSd/b;

    .line 10
    .line 11
    iget-object v0, v0, LSd/b;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/teller/business/IApiTellerService;

    .line 14
    .line 15
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/teller/business/IApiTellerService;->bettingWithdrawRedeemCodePay(Lcom/transsnet/palmpay/teller/bean/BettingWithdrawRedeemPayReq;)Ldf/d;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 20
    .line 21
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    new-instance v0, Lbe/b;

    .line 34
    .line 35
    invoke-direct {v0, p0}, Lbe/b;-><init>(Lbe/c;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final queryBettingDefaultPayMethod(Lcom/transsnet/palmpay/core/bean/req/DefaultPayMethodReq;)V
    .locals 1

    .line 1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 2
    .line 3
    iget-object v0, v0, Landroidx/camera/video/internal/c;->d:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 6
    .line 7
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/core/network/api/AccountApiService;->queryDefaultMethod(Lcom/transsnet/palmpay/core/bean/req/DefaultPayMethodReq;)Ldf/d;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 12
    .line 13
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    new-instance v0, Lbe/a;

    .line 26
    .line 27
    invoke-direct {v0, p0}, Lbe/a;-><init>(Lbe/c;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method
