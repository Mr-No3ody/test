.class public final Lbe/a;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lbe/c;


# direct methods
.method public constructor <init>(Lbe/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbe/a;->f:Lbe/c;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lbe/a;->f:Lbe/c;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/j;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lbe/a;->f:Lbe/c;

    .line 2
    .line 3
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/teller/ui/mvp/contract/BettingConfirmPaymentOrderContract$View;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 9
    .line 10
    .line 11
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 2
    .line 3
    iget-object v0, p0, Lbe/a;->f:Lbe/c;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 6
    .line 7
    check-cast v1, Lcom/transsnet/palmpay/teller/ui/mvp/contract/BettingConfirmPaymentOrderContract$View;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 20
    .line 21
    check-cast v0, Lcom/transsnet/palmpay/teller/ui/mvp/contract/BettingConfirmPaymentOrderContract$View;

    .line 22
    .line 23
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast p1, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;

    .line 26
    .line 27
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/DefaultPayMethodResp;->paymentMethod:Lcom/transsnet/palmpay/core/bean/PaymentMethod;

    .line 28
    .line 29
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/teller/ui/mvp/contract/BettingConfirmPaymentOrderContract$View;->handleBettingDefaultPaymentOrder(Lcom/transsnet/palmpay/core/bean/PaymentMethod;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method
