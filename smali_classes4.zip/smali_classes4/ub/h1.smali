.class public final synthetic Lub/h1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Lub/h1;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 10

    .line 1
    const-string p1, "AgreementCommonPage"

    .line 2
    .line 3
    const-string v0, "agreementTypes"

    .line 4
    .line 5
    const-string v1, "title"

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    const-string v3, "showTitle"

    .line 9
    .line 10
    const-string v4, "LoanAgreementHelper"

    .line 11
    .line 12
    const/4 v5, 0x3

    .line 13
    const-string v6, "loanProduct"

    .line 14
    .line 15
    const-string v7, "OK_CARD"

    .line 16
    .line 17
    const/4 v8, 0x0

    .line 18
    iget v9, p0, Lub/h1;->a:I

    .line 19
    .line 20
    packed-switch v9, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    sget p1, Lcom/transsnet/palmpay/credit/ui/fragment/OcMainFragment;->B0:I

    .line 24
    .line 25
    const-string p1, "/credit_score/oc_setting_activity"

    .line 26
    .line 27
    invoke-static {p1}, LN8/q0;->u(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :pswitch_0
    sget p1, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideDoubleOpenFragment;->r0:I

    .line 32
    .line 33
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    const-string v0, "BusinessLoanCreditLoanPageClick"

    .line 38
    .line 39
    const-string v1, "module_name"

    .line 40
    .line 41
    const-string v2, "Apply"

    .line 42
    .line 43
    invoke-static {v0, v1, v2}, LC0/G;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 48
    .line 49
    const-string v1, "source"

    .line 50
    .line 51
    const-string v2, "guide"

    .line 52
    .line 53
    invoke-virtual {v0, v1, v2}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    check-cast v0, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 58
    .line 59
    invoke-virtual {p1, v0}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 60
    .line 61
    .line 62
    const-string p1, "BusinessLoanPre"

    .line 63
    .line 64
    invoke-static {v8, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :pswitch_1
    sget-object p1, Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideCashOpenFragment;->s0:Lcom/transsnet/palmpay/credit/ui/fragment/OcGuideCashOpenFragment$a;

    .line 69
    .line 70
    const-string p1, "LoanFlexi"

    .line 71
    .line 72
    invoke-static {v8, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :pswitch_2
    sget-object p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeGuestFragment;->o:Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeGuestFragment$a;

    .line 77
    .line 78
    invoke-static {v8, v8}, LPa/i0;->K(Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    return-void

    .line 82
    :pswitch_3
    sget-object p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeGuestFragment;->o:Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeGuestFragment$a;

    .line 83
    .line 84
    const-string p1, "/h5/help/service"

    .line 85
    .line 86
    invoke-static {p1}, LPa/i0;->b0(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    return-void

    .line 90
    :pswitch_4
    sget p1, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->j1:I

    .line 91
    .line 92
    const-string p1, "/h5/help/service?entryType=cashapphome"

    .line 93
    .line 94
    invoke-static {p1}, Lcom/transsnet/palmpay/core/config/d;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    invoke-static {p1}, LPa/i0;->b0(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    return-void

    .line 102
    :pswitch_5
    const-string p1, "/credit_score/oc_feedback_activity"

    .line 103
    .line 104
    invoke-static {p1}, LN8/q0;->u(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    return-void

    .line 108
    :pswitch_6
    sget p1, Lcom/transsnet/palmpay/send_money/ui/activity/settings/TransferSettingsActivity;->d:I

    .line 109
    .line 110
    invoke-static {}, LPa/r0;->U0()Z

    .line 111
    .line 112
    .line 113
    move-result p1

    .line 114
    if-eqz p1, :cond_0

    .line 115
    .line 116
    goto :goto_0

    .line 117
    :cond_0
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    const-string v0, "Transfer_TransferSettings_NotificationSettings_Click"

    .line 122
    .line 123
    invoke-virtual {p1, v0}, LPa/n0;->l(Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    const-string v0, "/sm/transfer_notification_settings"

    .line 131
    .line 132
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    :goto_0
    return-void

    .line 140
    :pswitch_7
    sget p1, Lcom/transsnet/palmpay/send_money/ui/activity/settings/TransferSettingsActivity;->d:I

    .line 141
    .line 142
    invoke-static {}, LPa/r0;->U0()Z

    .line 143
    .line 144
    .line 145
    move-result p1

    .line 146
    if-eqz p1, :cond_1

    .line 147
    .line 148
    goto :goto_1

    .line 149
    :cond_1
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 150
    .line 151
    .line 152
    move-result-object p1

    .line 153
    const-string v0, "Transfer_TransferSettings_LimitSettings_Click"

    .line 154
    .line 155
    invoke-virtual {p1, v0}, LPa/n0;->l(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    const-string v0, "/sm/transfer_limit_settings"

    .line 163
    .line 164
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    :goto_1
    return-void

    .line 172
    :pswitch_8
    sget p1, Lcom/transsnet/palmpay/send_money/ui/activity/settings/TransferNotificationSettingsActivity;->d:I

    .line 173
    .line 174
    invoke-static {}, LPa/r0;->U0()Z

    .line 175
    .line 176
    .line 177
    move-result p1

    .line 178
    if-eqz p1, :cond_2

    .line 179
    .line 180
    goto :goto_2

    .line 181
    :cond_2
    const-string p1, "EmailAlertSettings"

    .line 182
    .line 183
    invoke-static {v8, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    :goto_2
    return-void

    .line 187
    :pswitch_9
    sget p1, Lcom/transsnet/palmpay/send_money/ui/activity/settings/TransferNotificationSettingsActivity;->d:I

    .line 188
    .line 189
    invoke-static {}, LPa/r0;->U0()Z

    .line 190
    .line 191
    .line 192
    move-result p1

    .line 193
    if-eqz p1, :cond_3

    .line 194
    .line 195
    goto :goto_3

    .line 196
    :cond_3
    const-string p1, "/single-page/sms-alert-subscribe/home"

    .line 197
    .line 198
    invoke-static {p1}, LPa/i0;->b0(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    :goto_3
    return-void

    .line 202
    :pswitch_a
    sget p1, Lcom/transsnet/palmpay/send_money/ui/activity/schedule_transfer/ScheduleTransferOrderDetailActivity;->p:I

    .line 203
    .line 204
    return-void

    .line 205
    :pswitch_b
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;->t:I

    .line 206
    .line 207
    const-string p1, "/credit_score/oc_overpayment_activity"

    .line 208
    .line 209
    invoke-static {p1}, LN8/q0;->u(Ljava/lang/String;)V

    .line 210
    .line 211
    .line 212
    return-void

    .line 213
    :pswitch_c
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;->t:I

    .line 214
    .line 215
    const-string p1, "FinanceManager"

    .line 216
    .line 217
    invoke-static {v8, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    return-void

    .line 221
    :pswitch_d
    sget v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;->t:I

    .line 222
    .line 223
    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    const-string v8, "gotoPrivacyPolicy >>> loanProduct=OK_CARD"

    .line 227
    .line 228
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v8

    .line 232
    invoke-static {v4, v5, v8}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 233
    .line 234
    .line 235
    new-instance v4, Landroid/os/Bundle;

    .line 236
    .line 237
    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    .line 238
    .line 239
    .line 240
    invoke-virtual {v4, v3, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 241
    .line 242
    .line 243
    const-string v2, "Privacy Policy"

    .line 244
    .line 245
    invoke-virtual {v4, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 246
    .line 247
    .line 248
    invoke-virtual {v4, v6, v7}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 249
    .line 250
    .line 251
    const-string v1, "PRIVACY_AGREEMENT"

    .line 252
    .line 253
    filled-new-array {v1}, [Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    invoke-virtual {v4, v0, v1}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    invoke-static {v4, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    return-void

    .line 264
    :pswitch_e
    sget v8, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;->t:I

    .line 265
    .line 266
    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 267
    .line 268
    .line 269
    const-string v8, "gotoTermsAndConditions >>> loanProduct=OK_CARD"

    .line 270
    .line 271
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 272
    .line 273
    .line 274
    move-result-object v8

    .line 275
    invoke-static {v4, v5, v8}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 276
    .line 277
    .line 278
    new-instance v4, Landroid/os/Bundle;

    .line 279
    .line 280
    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    .line 281
    .line 282
    .line 283
    invoke-virtual {v4, v3, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 284
    .line 285
    .line 286
    const-string v2, "Terms And Conditions"

    .line 287
    .line 288
    invoke-virtual {v4, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 289
    .line 290
    .line 291
    invoke-virtual {v4, v6, v7}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 292
    .line 293
    .line 294
    const-string v1, "TERMS_AND_CONDITIONS"

    .line 295
    .line 296
    filled-new-array {v1}, [Ljava/lang/String;

    .line 297
    .line 298
    .line 299
    move-result-object v1

    .line 300
    invoke-virtual {v4, v0, v1}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 301
    .line 302
    .line 303
    invoke-static {v4, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    return-void

    .line 307
    :pswitch_f
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;->t:I

    .line 308
    .line 309
    const-string p1, "LoanAutomaticallyRepayment"

    .line 310
    .line 311
    invoke-static {v8, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 312
    .line 313
    .line 314
    return-void

    .line 315
    :pswitch_10
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 316
    .line 317
    invoke-static {v8}, LPa/i0;->H(Ljava/lang/String;)V

    .line 318
    .line 319
    .line 320
    return-void

    .line 321
    :pswitch_11
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 322
    .line 323
    const-string p1, "/credit_score/unfreeze_activity"

    .line 324
    .line 325
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->F(Ljava/lang/String;)V

    .line 326
    .line 327
    .line 328
    return-void

    .line 329
    :pswitch_12
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->Y:I

    .line 330
    .line 331
    const-string p1, "flexihome"

    .line 332
    .line 333
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->w(Ljava/lang/String;)V

    .line 334
    .line 335
    .line 336
    return-void

    .line 337
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
