.class public final Lub/N;
.super Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lub/N;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 2
    .line 3
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onItemRangeRemoved(II)V
    .locals 2

    .line 1
    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$AdapterDataObserver;->onItemRangeRemoved(II)V

    .line 2
    .line 3
    .line 4
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 5
    .line 6
    iget-object p1, p0, Lub/N;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 7
    .line 8
    iget-object p2, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->f:Lxf/t;

    .line 9
    .line 10
    invoke-virtual {p2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    const-string v0, "getValue(...)"

    .line 15
    .line 16
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    check-cast p2, Landroid/widget/TextView;

    .line 20
    .line 21
    sget v0, LYa/g;->cs_max_screen:I

    .line 22
    .line 23
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->w:Lyb/z;

    .line 24
    .line 25
    if-eqz v1, :cond_0

    .line 26
    .line 27
    iget-object v1, v1, Lyb/z;->b:Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :cond_0
    const-string p1, "mSelectedImgAdapter"

    .line 50
    .line 51
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const/4 p1, 0x0

    .line 55
    throw p1
.end method
