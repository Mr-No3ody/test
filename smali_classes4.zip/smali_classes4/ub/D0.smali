.class public final synthetic Lub/D0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/D0;->a:I

    iput-object p1, p0, Lub/D0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/D0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/D0;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget-object v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->H:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity$a;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->n()V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 14
    .line 15
    return-object v0

    .line 16
    :pswitch_0
    sget-object v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->H:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity$a;

    .line 17
    .line 18
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->n()V

    .line 19
    .line 20
    .line 21
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_1
    sget-object v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->H:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity$a;

    .line 25
    .line 26
    sget v1, LYa/e;->protocol_mtb:I

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 33
    .line 34
    return-object v0

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
