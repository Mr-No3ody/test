.class public final synthetic Lub/l0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/l0;->a:I

    iput-object p1, p0, Lub/l0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 11

    .line 1
    const-string p1, "OcMediaActivity_element_click"

    .line 2
    .line 3
    const-string v0, ""

    .line 4
    .line 5
    iget-object v1, p0, Lub/l0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;

    .line 6
    .line 7
    iget v2, p0, Lub/l0;->a:I

    .line 8
    .line 9
    packed-switch v2, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->y0:I

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 16
    .line 17
    .line 18
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->x0:Lyb/s;

    .line 19
    .line 20
    const/4 v3, 0x0

    .line 21
    const-string v4, "mSocialLabelAdapter"

    .line 22
    .line 23
    if-eqz v2, :cond_8

    .line 24
    .line 25
    iget v2, v2, Lyb/s;->g:I

    .line 26
    .line 27
    const/4 v5, -0x1

    .line 28
    if-eq v2, v5, :cond_2

    .line 29
    .line 30
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->y()Landroid/widget/EditText;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-nez v2, :cond_2

    .line 43
    .line 44
    new-instance v2, Lcom/transsnet/palmpay/credit/bean/req/SocialMediaInfo;

    .line 45
    .line 46
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->y()Landroid/widget/EditText;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    iget-object v6, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->w0:Ljava/util/ArrayList;

    .line 59
    .line 60
    if-eqz v6, :cond_1

    .line 61
    .line 62
    iget-object v7, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->x0:Lyb/s;

    .line 63
    .line 64
    if-eqz v7, :cond_0

    .line 65
    .line 66
    iget v4, v7, Lyb/s;->g:I

    .line 67
    .line 68
    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v4

    .line 72
    check-cast v4, Lcom/transsnet/palmpay/credit/bean/other/OcContactSocialLabelBean;

    .line 73
    .line 74
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/other/OcContactSocialLabelBean;->getName()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v4

    .line 78
    invoke-direct {v2, v5, v4}, Lcom/transsnet/palmpay/credit/bean/req/SocialMediaInfo;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    move-object v7, v2

    .line 82
    goto :goto_0

    .line 83
    :cond_0
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    throw v3

    .line 87
    :cond_1
    const-string p1, "mSocialLabelData"

    .line 88
    .line 89
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    throw v3

    .line 93
    :cond_2
    move-object v7, v3

    .line 94
    :goto_0
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->v0:Ljava/lang/String;

    .line 95
    .line 96
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    if-eqz v2, :cond_6

    .line 101
    .line 102
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->C:Ljava/lang/String;

    .line 103
    .line 104
    const-string v4, "oc_use_type_router"

    .line 105
    .line 106
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v2

    .line 110
    const-string v4, "OK_CARD"

    .line 111
    .line 112
    if-eqz v2, :cond_4

    .line 113
    .line 114
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 115
    .line 116
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    if-eqz v2, :cond_3

    .line 121
    .line 122
    const-string v2, "OK_CARD_APPLY"

    .line 123
    .line 124
    goto :goto_1

    .line 125
    :cond_3
    const-string v2, "CASH_LOAN_APPLY"

    .line 126
    .line 127
    goto :goto_1

    .line 128
    :cond_4
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 129
    .line 130
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v2

    .line 134
    if-eqz v2, :cond_5

    .line 135
    .line 136
    const-string v2, "OK_CARD_RAISE"

    .line 137
    .line 138
    goto :goto_1

    .line 139
    :cond_5
    const-string v2, "CASH_LOAN_RAISE"

    .line 140
    .line 141
    :goto_1
    iput-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->v0:Ljava/lang/String;

    .line 142
    .line 143
    :cond_6
    new-instance v4, Lcom/transsnet/palmpay/credit/bean/req/OcAddContactReq;

    .line 144
    .line 145
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 146
    .line 147
    if-eqz v2, :cond_7

    .line 148
    .line 149
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplyId()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    :cond_7
    move-object v5, v3

    .line 154
    iget-object v8, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 155
    .line 156
    iget-object v9, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->v0:Ljava/lang/String;

    .line 157
    .line 158
    const/4 v10, 0x0

    .line 159
    const/4 v6, 0x0

    .line 160
    invoke-direct/range {v4 .. v10}, Lcom/transsnet/palmpay/credit/bean/req/OcAddContactReq;-><init>(Ljava/lang/String;Ljava/util/List;Lcom/transsnet/palmpay/credit/bean/req/SocialMediaInfo;Ljava/lang/String;Ljava/lang/String;Lcom/transsnet/palmpay/credit/bean/req/PersonalInfo;)V

    .line 161
    .line 162
    .line 163
    sget-object v2, Lob/c;->a:Lob/a;

    .line 164
    .line 165
    invoke-virtual {v2}, Lob/a;->getInstance()Lob/c;

    .line 166
    .line 167
    .line 168
    move-result-object v2

    .line 169
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    .line 171
    .line 172
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    invoke-interface {v2, v4}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->addContact(Lcom/transsnet/palmpay/credit/bean/req/OcAddContactReq;)Ldf/d;

    .line 177
    .line 178
    .line 179
    move-result-object v2

    .line 180
    sget-object v3, Ltf/f;->b:Ldf/i;

    .line 181
    .line 182
    invoke-virtual {v2, v3}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 183
    .line 184
    .line 185
    move-result-object v2

    .line 186
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 187
    .line 188
    .line 189
    move-result-object v3

    .line 190
    invoke-virtual {v2, v3}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 191
    .line 192
    .line 193
    move-result-object v2

    .line 194
    new-instance v3, Ltb/q;

    .line 195
    .line 196
    const/16 v4, 0x13

    .line 197
    .line 198
    invoke-direct {v3, v1, v4}, Ltb/q;-><init>(Ljava/lang/Object;I)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {v2, v3}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 202
    .line 203
    .line 204
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 205
    .line 206
    .line 207
    move-result-object v1

    .line 208
    const-string v2, "contact_next_bt"

    .line 209
    .line 210
    invoke-virtual {v1, p1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    return-void

    .line 214
    :cond_8
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    throw v3

    .line 218
    :pswitch_0
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->y0:I

    .line 219
    .line 220
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->r()V

    .line 221
    .line 222
    .line 223
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 224
    .line 225
    .line 226
    move-result-object v1

    .line 227
    const-string v2, "router_right_tv"

    .line 228
    .line 229
    invoke-virtual {v1, p1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    return-void

    .line 233
    :pswitch_1
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->y0:I

    .line 234
    .line 235
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v()V

    .line 236
    .line 237
    .line 238
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 239
    .line 240
    .line 241
    move-result-object v1

    .line 242
    const-string v2, "router_close_img"

    .line 243
    .line 244
    invoke-virtual {v1, p1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    return-void

    .line 248
    :pswitch_2
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMediaActivity;->y0:I

    .line 249
    .line 250
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->onBackPressed()V

    .line 251
    .line 252
    .line 253
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    const-string v2, "router_back_img"

    .line 258
    .line 259
    invoke-virtual {v1, p1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    return-void

    .line 263
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
