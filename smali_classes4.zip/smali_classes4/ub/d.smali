.class public final synthetic Lub/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALiFaceGuideActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALiFaceGuideActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/d;->a:I

    iput-object p1, p0, Lub/d;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALiFaceGuideActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    const-string p1, "OcALiFaceGuideActivity_element_click"

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    iget-object v1, p0, Lub/d;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALiFaceGuideActivity;

    .line 5
    .line 6
    iget v2, p0, Lub/d;->a:I

    .line 7
    .line 8
    packed-switch v2, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALiFaceGuideActivity;->t0:I

    .line 12
    .line 13
    const/4 v2, 0x1

    .line 14
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALiFaceGuideActivity;->y(Z)V

    .line 15
    .line 16
    .line 17
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 22
    .line 23
    if-eqz v1, :cond_0

    .line 24
    .line 25
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    :cond_0
    const-string v1, "take_photo_guide_img"

    .line 30
    .line 31
    invoke-virtual {v2, p1, v1, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :pswitch_0
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALiFaceGuideActivity;->t0:I

    .line 36
    .line 37
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v()V

    .line 38
    .line 39
    .line 40
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 45
    .line 46
    if-eqz v1, :cond_1

    .line 47
    .line 48
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    :cond_1
    const-string v1, "router_close_img"

    .line 53
    .line 54
    invoke-virtual {v2, p1, v1, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :pswitch_1
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALiFaceGuideActivity;->t0:I

    .line 59
    .line 60
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->onBackPressed()V

    .line 61
    .line 62
    .line 63
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 68
    .line 69
    if-eqz v1, :cond_2

    .line 70
    .line 71
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    :cond_2
    const-string v1, "router_back_img"

    .line 76
    .line 77
    invoke-virtual {v2, p1, v1, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    return-void

    .line 81
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
