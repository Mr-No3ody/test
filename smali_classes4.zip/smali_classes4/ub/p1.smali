.class public final Lub/p1;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/p1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/p1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 5

    .line 1
    const-string v0, "message"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/p1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;

    .line 7
    .line 8
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->s0:Landroid/os/Handler;

    .line 9
    .line 10
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->o()Ljava/lang/Runnable;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    iget-wide v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->r0:J

    .line 15
    .line 16
    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 17
    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 21
    .line 22
    .line 23
    new-array v0, v1, [Ljava/lang/Object;

    .line 24
    .line 25
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 7

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    iget-object v1, p0, Lub/p1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;

    .line 5
    .line 6
    if-eqz p1, :cond_3

    .line 7
    .line 8
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    const/4 v3, 0x1

    .line 13
    if-ne v2, v3, :cond_3

    .line 14
    .line 15
    iget-object v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp;->data:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;

    .line 16
    .line 17
    if-eqz v2, :cond_3

    .line 18
    .line 19
    iget p1, v2, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->status:I

    .line 20
    .line 21
    const-string v4, "data"

    .line 22
    .line 23
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v4, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->s0:Landroid/os/Handler;

    .line 27
    .line 28
    if-eq p1, v3, :cond_2

    .line 29
    .line 30
    const/4 v5, 0x2

    .line 31
    if-eq p1, v5, :cond_0

    .line 32
    .line 33
    const/4 v5, 0x3

    .line 34
    if-eq p1, v5, :cond_2

    .line 35
    .line 36
    const/4 v5, 0x6

    .line 37
    if-eq p1, v5, :cond_2

    .line 38
    .line 39
    const/4 v2, 0x7

    .line 40
    if-eq p1, v2, :cond_0

    .line 41
    .line 42
    iput-boolean v3, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->Y:Z

    .line 43
    .line 44
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->o()Ljava/lang/Runnable;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    iget-wide v5, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->r0:J

    .line 49
    .line 50
    invoke-virtual {v4, p1, v5, v6}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 51
    .line 52
    .line 53
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->n()Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    iget-object v0, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->k0:Ljava/lang/String;

    .line 58
    .line 59
    iget-wide v4, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->p0:J

    .line 60
    .line 61
    invoke-virtual {p1, v4, v5, v0}, Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;->e(JLjava/lang/String;)V

    .line 62
    .line 63
    .line 64
    iget-boolean p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->Z:Z

    .line 65
    .line 66
    if-nez p1, :cond_1

    .line 67
    .line 68
    iput-boolean v3, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->Z:Z

    .line 69
    .line 70
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->p()V

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :cond_0
    iput-boolean v0, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->Y:Z

    .line 75
    .line 76
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->o()Ljava/lang/Runnable;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    invoke-virtual {v4, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->n()Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    sget v0, LYa/g;->cs_top_up_result_failed:I

    .line 88
    .line 89
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;->d(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    iget-boolean p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->Z:Z

    .line 97
    .line 98
    if-nez p1, :cond_1

    .line 99
    .line 100
    iput-boolean v3, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->Z:Z

    .line 101
    .line 102
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->p()V

    .line 103
    .line 104
    .line 105
    :cond_1
    return-void

    .line 106
    :cond_2
    iput-boolean v0, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->Y:Z

    .line 107
    .line 108
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->o()Ljava/lang/Runnable;

    .line 109
    .line 110
    .line 111
    move-result-object p1

    .line 112
    invoke-virtual {v4, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 113
    .line 114
    .line 115
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->C:Lxf/t;

    .line 116
    .line 117
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    const-string v0, "getValue(...)"

    .line 122
    .line 123
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    check-cast p1, Lcom/transsnet/palmpay/custom_view/model/ModelPreviewItem;

    .line 127
    .line 128
    iget v3, v2, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->payType:I

    .line 129
    .line 130
    iget-object v4, v2, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->bankName:Ljava/lang/String;

    .line 131
    .line 132
    iget-object v2, v2, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->bankCard:Ljava/lang/String;

    .line 133
    .line 134
    invoke-static {v3, v4, v2}, LPa/r0;->r0(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v2

    .line 138
    invoke-virtual {p1, v2}, Lcom/transsnet/palmpay/custom_view/model/ModelPreviewItem;->setContent(Ljava/lang/CharSequence;)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->n()Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    sget v2, LYa/g;->cs_top_up_result_success:I

    .line 146
    .line 147
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v2

    .line 151
    invoke-virtual {p1, v2}, Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;->g(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    sget-object p1, Lob/c;->a:Lob/a;

    .line 155
    .line 156
    invoke-static {p1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->X:Ljava/lang/String;

    .line 161
    .line 162
    invoke-interface {p1, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->getBillInsRepaymentPlan(Ljava/lang/String;)Ldf/d;

    .line 163
    .line 164
    .line 165
    move-result-object p1

    .line 166
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 167
    .line 168
    invoke-virtual {p1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    invoke-virtual {p1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 177
    .line 178
    .line 179
    move-result-object p1

    .line 180
    new-instance v2, Ltb/q;

    .line 181
    .line 182
    const/16 v3, 0x1a

    .line 183
    .line 184
    invoke-direct {v2, v1, v3}, Ltb/q;-><init>(Ljava/lang/Object;I)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {p1, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 188
    .line 189
    .line 190
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->o:Lxf/t;

    .line 191
    .line 192
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object p1

    .line 196
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    check-cast p1, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 200
    .line 201
    sget v2, LYa/g;->oc_repay_result_top_slot_id:I

    .line 202
    .line 203
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v2

    .line 207
    invoke-virtual {p1, v2}, Lcom/transsnet/adsdk/widgets/SingleAdView;->setSlotId(Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->j:Lxf/t;

    .line 211
    .line 212
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object p1

    .line 216
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    check-cast p1, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 220
    .line 221
    sget v2, LYa/g;->oc_repay_result_middle_first_slot_id:I

    .line 222
    .line 223
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object v2

    .line 227
    invoke-virtual {p1, v2}, Lcom/transsnet/adsdk/widgets/SingleAdView;->setSlotId(Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->i:Lxf/t;

    .line 231
    .line 232
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object p1

    .line 236
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    check-cast p1, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 240
    .line 241
    sget v2, LYa/g;->oc_repay_result_middle_second_slot_id:I

    .line 242
    .line 243
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object v2

    .line 247
    invoke-virtual {p1, v2}, Lcom/transsnet/adsdk/widgets/SingleAdView;->setSlotId(Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->g:Lxf/t;

    .line 251
    .line 252
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object p1

    .line 256
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    check-cast p1, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 260
    .line 261
    sget v2, LYa/g;->oc_repay_result_middle_third_slot_id:I

    .line 262
    .line 263
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 264
    .line 265
    .line 266
    move-result-object v2

    .line 267
    invoke-virtual {p1, v2}, Lcom/transsnet/adsdk/widgets/SingleAdView;->setSlotId(Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->f:Lxf/t;

    .line 271
    .line 272
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object p1

    .line 276
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 277
    .line 278
    .line 279
    check-cast p1, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 280
    .line 281
    sget v0, LYa/g;->oc_repay_result_bottom_slot_id:I

    .line 282
    .line 283
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    invoke-virtual {p1, v0}, Lcom/transsnet/adsdk/widgets/SingleAdView;->setSlotId(Ljava/lang/String;)V

    .line 288
    .line 289
    .line 290
    return-void

    .line 291
    :cond_3
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->s0:Landroid/os/Handler;

    .line 292
    .line 293
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->o()Ljava/lang/Runnable;

    .line 294
    .line 295
    .line 296
    move-result-object v3

    .line 297
    iget-wide v4, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->r0:J

    .line 298
    .line 299
    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 300
    .line 301
    .line 302
    if-eqz p1, :cond_4

    .line 303
    .line 304
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 305
    .line 306
    .line 307
    move-result-object p1

    .line 308
    goto :goto_0

    .line 309
    :cond_4
    const/4 p1, 0x0

    .line 310
    :goto_0
    new-array v0, v0, [Ljava/lang/Object;

    .line 311
    .line 312
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 313
    .line 314
    .line 315
    return-void
.end method
