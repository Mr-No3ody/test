.class public final synthetic Lub/Y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/Y;->a:I

    iput-object p1, p0, Lub/Y;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    const/4 p1, 0x1

    .line 2
    const/4 v0, 0x4

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, Lub/Y;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;

    .line 6
    .line 7
    iget v4, p0, Lub/Y;->a:I

    .line 8
    .line 9
    packed-switch v4, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->s0:I

    .line 13
    .line 14
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    check-cast p1, Lcom/transsnet/palmpay/credit/viewmodel/OcGoldCardUpgradeViewModel;

    .line 19
    .line 20
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 21
    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getCardNo()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    move-object v0, v2

    .line 30
    :goto_0
    iget-object v3, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->r0:Lcom/transsnet/palmpay/credit/bean/resp/OcRepaymentDate;

    .line 31
    .line 32
    if-eqz v3, :cond_1

    .line 33
    .line 34
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcRepaymentDate;->getDay()Ljava/lang/Integer;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    goto :goto_1

    .line 39
    :cond_1
    move-object v3, v2

    .line 40
    :goto_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    new-instance v4, LJb/l;

    .line 44
    .line 45
    invoke-direct {v4, v3, v0, v2}, LJb/l;-><init>(Ljava/lang/Integer;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 46
    .line 47
    .line 48
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/viewmodel/OcGoldCardUpgradeViewModel;->e:Lcom/transsnet/palmpay/core/base/l;

    .line 49
    .line 50
    const/16 v2, 0x1c

    .line 51
    .line 52
    invoke-static {p1, v4, v0, v1, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :pswitch_0
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->s0:I

    .line 57
    .line 58
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    const-string v0, "/airtime/top_up_airtime"

    .line 63
    .line 64
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 72
    .line 73
    .line 74
    return-void

    .line 75
    :pswitch_1
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 76
    .line 77
    if-eqz v2, :cond_3

    .line 78
    .line 79
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getAccountStatus()Ljava/lang/Integer;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    if-nez v2, :cond_2

    .line 84
    .line 85
    goto :goto_2

    .line 86
    :cond_2
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    if-ne v2, v0, :cond_3

    .line 91
    .line 92
    goto :goto_7

    .line 93
    :cond_3
    :goto_2
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 94
    .line 95
    if-eqz v2, :cond_5

    .line 96
    .line 97
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getAccountStatus()Ljava/lang/Integer;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    if-nez v2, :cond_4

    .line 102
    .line 103
    goto :goto_3

    .line 104
    :cond_4
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 105
    .line 106
    .line 107
    move-result v2

    .line 108
    const/4 v4, 0x5

    .line 109
    if-ne v2, v4, :cond_5

    .line 110
    .line 111
    goto :goto_7

    .line 112
    :cond_5
    :goto_3
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 113
    .line 114
    if-eqz v2, :cond_7

    .line 115
    .line 116
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getAccountStatus()Ljava/lang/Integer;

    .line 117
    .line 118
    .line 119
    move-result-object v2

    .line 120
    if-nez v2, :cond_6

    .line 121
    .line 122
    goto :goto_4

    .line 123
    :cond_6
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 124
    .line 125
    .line 126
    move-result v2

    .line 127
    const/4 v4, 0x2

    .line 128
    if-ne v2, v4, :cond_7

    .line 129
    .line 130
    goto :goto_7

    .line 131
    :cond_7
    :goto_4
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 132
    .line 133
    if-eqz v2, :cond_9

    .line 134
    .line 135
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getAccountStatus()Ljava/lang/Integer;

    .line 136
    .line 137
    .line 138
    move-result-object v2

    .line 139
    if-nez v2, :cond_8

    .line 140
    .line 141
    goto :goto_5

    .line 142
    :cond_8
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 143
    .line 144
    .line 145
    move-result v2

    .line 146
    if-ne v2, p1, :cond_9

    .line 147
    .line 148
    goto :goto_7

    .line 149
    :cond_9
    :goto_5
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 150
    .line 151
    if-eqz p1, :cond_a

    .line 152
    .line 153
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getExistInstallment()Ljava/lang/Boolean;

    .line 154
    .line 155
    .line 156
    move-result-object p1

    .line 157
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 158
    .line 159
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v1

    .line 163
    :cond_a
    if-eqz v1, :cond_c

    .line 164
    .line 165
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 166
    .line 167
    const-wide/16 v1, 0x0

    .line 168
    .line 169
    if-eqz p1, :cond_b

    .line 170
    .line 171
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getOutstandingAmount()Ljava/lang/Long;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    if-eqz p1, :cond_b

    .line 176
    .line 177
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 178
    .line 179
    .line 180
    move-result-wide v4

    .line 181
    goto :goto_6

    .line 182
    :cond_b
    move-wide v4, v1

    .line 183
    :goto_6
    cmp-long p1, v4, v1

    .line 184
    .line 185
    if-lez p1, :cond_c

    .line 186
    .line 187
    :goto_7
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    const-string v0, "/credit_score/oc_gold_card_upgard_break_activity"

    .line 192
    .line 193
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 194
    .line 195
    .line 196
    move-result-object p1

    .line 197
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    iget-object v1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 202
    .line 203
    iget-object v0, v0, LPa/w;->b:Ljava/lang/Object;

    .line 204
    .line 205
    check-cast v0, Lcom/google/gson/Gson;

    .line 206
    .line 207
    invoke-virtual {v0, v1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object v0

    .line 211
    const-string v1, "oc_gold_level_data"

    .line 212
    .line 213
    invoke-virtual {p1, v1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 214
    .line 215
    .line 216
    move-result-object p1

    .line 217
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 221
    .line 222
    .line 223
    goto :goto_8

    .line 224
    :cond_c
    new-instance p1, Lcom/transsnet/palmpay/credit/ui/dialog/OcGoldCardUpgradeConfirmDialog;

    .line 225
    .line 226
    iget-object v1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->r0:Lcom/transsnet/palmpay/credit/bean/resp/OcRepaymentDate;

    .line 227
    .line 228
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 229
    .line 230
    invoke-direct {p1, v3, v1, v2}, Lcom/transsnet/palmpay/credit/ui/dialog/OcGoldCardUpgradeConfirmDialog;-><init>(Landroid/content/Context;Lcom/transsnet/palmpay/credit/bean/resp/OcRepaymentDate;Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;)V

    .line 231
    .line 232
    .line 233
    iput-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->p0:Lcom/transsnet/palmpay/credit/ui/dialog/OcGoldCardUpgradeConfirmDialog;

    .line 234
    .line 235
    new-instance v1, Lub/Y;

    .line 236
    .line 237
    invoke-direct {v1, v3, v0}, Lub/Y;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;I)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/credit/ui/dialog/OcGoldCardUpgradeConfirmDialog;->setAgreeBtListener(Landroid/view/View$OnClickListener;)V

    .line 241
    .line 242
    .line 243
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->p0:Lcom/transsnet/palmpay/credit/ui/dialog/OcGoldCardUpgradeConfirmDialog;

    .line 244
    .line 245
    if-eqz p1, :cond_d

    .line 246
    .line 247
    invoke-virtual {p1}, LO6/f;->show()V

    .line 248
    .line 249
    .line 250
    :cond_d
    :goto_8
    return-void

    .line 251
    :pswitch_2
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 252
    .line 253
    if-eqz v0, :cond_e

    .line 254
    .line 255
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getBillDayItemList()Ljava/util/List;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    if-eqz v0, :cond_e

    .line 260
    .line 261
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object p1

    .line 265
    move-object v2, p1

    .line 266
    check-cast v2, Lcom/transsnet/palmpay/credit/bean/resp/OcRepaymentDate;

    .line 267
    .line 268
    :cond_e
    iput-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->r0:Lcom/transsnet/palmpay/credit/bean/resp/OcRepaymentDate;

    .line 269
    .line 270
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->q0:Landroid/widget/LinearLayout;

    .line 271
    .line 272
    if-eqz p1, :cond_f

    .line 273
    .line 274
    sget v0, LYa/d;->cs_oc_repayment_date_unselect_bg:I

    .line 275
    .line 276
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    .line 277
    .line 278
    .line 279
    :cond_f
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->p()Landroid/widget/TextView;

    .line 280
    .line 281
    .line 282
    move-result-object p1

    .line 283
    sget v0, LL6/b;->ppColorTextPrimary:I

    .line 284
    .line 285
    invoke-virtual {v3, v0}, Landroid/content/Context;->getColor(I)I

    .line 286
    .line 287
    .line 288
    move-result v0

    .line 289
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 290
    .line 291
    .line 292
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->o()Landroid/widget/TextView;

    .line 293
    .line 294
    .line 295
    move-result-object p1

    .line 296
    sget v0, LL6/b;->ppColorTextPrimary:I

    .line 297
    .line 298
    invoke-virtual {v3, v0}, Landroid/content/Context;->getColor(I)I

    .line 299
    .line 300
    .line 301
    move-result v0

    .line 302
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->q()Landroid/widget/LinearLayout;

    .line 306
    .line 307
    .line 308
    move-result-object p1

    .line 309
    if-eqz p1, :cond_10

    .line 310
    .line 311
    sget v0, LYa/d;->cs_oc_repayment_date_bg:I

    .line 312
    .line 313
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    .line 314
    .line 315
    .line 316
    :cond_10
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->s()Landroid/widget/TextView;

    .line 317
    .line 318
    .line 319
    move-result-object p1

    .line 320
    sget v0, LYa/b;->cs_oc_main_color:I

    .line 321
    .line 322
    invoke-virtual {v3, v0}, Landroid/content/Context;->getColor(I)I

    .line 323
    .line 324
    .line 325
    move-result v0

    .line 326
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 327
    .line 328
    .line 329
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->r()Landroid/widget/TextView;

    .line 330
    .line 331
    .line 332
    move-result-object p1

    .line 333
    sget v0, LYa/b;->cs_oc_main_color:I

    .line 334
    .line 335
    invoke-virtual {v3, v0}, Landroid/content/Context;->getColor(I)I

    .line 336
    .line 337
    .line 338
    move-result v0

    .line 339
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 340
    .line 341
    .line 342
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->q()Landroid/widget/LinearLayout;

    .line 343
    .line 344
    .line 345
    move-result-object p1

    .line 346
    iput-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->q0:Landroid/widget/LinearLayout;

    .line 347
    .line 348
    return-void

    .line 349
    :pswitch_3
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->k0:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 350
    .line 351
    if-eqz p1, :cond_11

    .line 352
    .line 353
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getBillDayItemList()Ljava/util/List;

    .line 354
    .line 355
    .line 356
    move-result-object p1

    .line 357
    if-eqz p1, :cond_11

    .line 358
    .line 359
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 360
    .line 361
    .line 362
    move-result-object p1

    .line 363
    move-object v2, p1

    .line 364
    check-cast v2, Lcom/transsnet/palmpay/credit/bean/resp/OcRepaymentDate;

    .line 365
    .line 366
    :cond_11
    iput-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->r0:Lcom/transsnet/palmpay/credit/bean/resp/OcRepaymentDate;

    .line 367
    .line 368
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->q0:Landroid/widget/LinearLayout;

    .line 369
    .line 370
    if-eqz p1, :cond_12

    .line 371
    .line 372
    sget v0, LYa/d;->cs_oc_repayment_date_unselect_bg:I

    .line 373
    .line 374
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    .line 375
    .line 376
    .line 377
    :cond_12
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->s()Landroid/widget/TextView;

    .line 378
    .line 379
    .line 380
    move-result-object p1

    .line 381
    sget v0, LL6/b;->ppColorTextPrimary:I

    .line 382
    .line 383
    invoke-virtual {v3, v0}, Landroid/content/Context;->getColor(I)I

    .line 384
    .line 385
    .line 386
    move-result v0

    .line 387
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 388
    .line 389
    .line 390
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->r()Landroid/widget/TextView;

    .line 391
    .line 392
    .line 393
    move-result-object p1

    .line 394
    sget v0, LL6/b;->ppColorTextPrimary:I

    .line 395
    .line 396
    invoke-virtual {v3, v0}, Landroid/content/Context;->getColor(I)I

    .line 397
    .line 398
    .line 399
    move-result v0

    .line 400
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 401
    .line 402
    .line 403
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->n()Landroid/widget/LinearLayout;

    .line 404
    .line 405
    .line 406
    move-result-object p1

    .line 407
    if-eqz p1, :cond_13

    .line 408
    .line 409
    sget v0, LYa/d;->cs_oc_repayment_date_bg:I

    .line 410
    .line 411
    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    .line 412
    .line 413
    .line 414
    :cond_13
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->p()Landroid/widget/TextView;

    .line 415
    .line 416
    .line 417
    move-result-object p1

    .line 418
    sget v0, LYa/b;->cs_oc_main_color:I

    .line 419
    .line 420
    invoke-virtual {v3, v0}, Landroid/content/Context;->getColor(I)I

    .line 421
    .line 422
    .line 423
    move-result v0

    .line 424
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 425
    .line 426
    .line 427
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->o()Landroid/widget/TextView;

    .line 428
    .line 429
    .line 430
    move-result-object p1

    .line 431
    sget v0, LYa/b;->cs_oc_main_color:I

    .line 432
    .line 433
    invoke-virtual {v3, v0}, Landroid/content/Context;->getColor(I)I

    .line 434
    .line 435
    .line 436
    move-result v0

    .line 437
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 438
    .line 439
    .line 440
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->n()Landroid/widget/LinearLayout;

    .line 441
    .line 442
    .line 443
    move-result-object p1

    .line 444
    iput-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeActivity;->q0:Landroid/widget/LinearLayout;

    .line 445
    .line 446
    return-void

    .line 447
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
