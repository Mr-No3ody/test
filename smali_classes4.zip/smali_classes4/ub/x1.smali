.class public final synthetic Lub/x1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/x1;->a:I

    iput-object p1, p0, Lub/x1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    const/4 p1, 0x0

    .line 2
    iget-object v0, p0, Lub/x1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

    .line 3
    .line 4
    iget v1, p0, Lub/x1;->a:I

    .line 5
    .line 6
    packed-switch v1, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 10
    .line 11
    new-instance v1, Landroid/os/Bundle;

    .line 12
    .line 13
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 14
    .line 15
    .line 16
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->k0:Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 17
    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCurrentCashLoanBill()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_0

    .line 25
    .line 26
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;->getLoanNo()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    :cond_0
    const-string v0, "loanNo"

    .line 31
    .line 32
    invoke-virtual {v1, v0, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    const-string p1, "LoanOverview"

    .line 36
    .line 37
    invoke-static {v1, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 42
    .line 43
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    const-string v2, "/credit_score/oc_all_bill_activity"

    .line 48
    .line 49
    invoke-virtual {v1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->Z:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 54
    .line 55
    if-eqz v0, :cond_1

    .line 56
    .line 57
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getCardNo()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    :cond_1
    const-string v0, "oc_card_no"

    .line 62
    .line 63
    invoke-virtual {v1, v0, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    const-string v0, "oc_bill_list_type"

    .line 68
    .line 69
    const-string v1, "oc_all_bill"

    .line 70
    .line 71
    invoke-virtual {p1, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
