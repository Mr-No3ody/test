.class public final synthetic Lub/C;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/C;->a:I

    iput-object p1, p0, Lub/C;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/C;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/C;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 9
    .line 10
    sget v1, LYa/e;->contact_next_bt:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/Button;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 20
    .line 21
    sget v1, LYa/e;->tvDeclinedMsg:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/TextView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 31
    .line 32
    sget v1, LYa/e;->contact_nsv:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroidx/core/widget/NestedScrollView;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 42
    .line 43
    sget v1, LYa/e;->router_back_img:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Landroid/widget/ImageView;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 53
    .line 54
    sget v1, LYa/e;->router_progress_view:I

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Lcom/transsnet/palmpay/credit/view/OpenAccountRouterProgressViewV2;

    .line 61
    .line 62
    return-object v0

    .line 63
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 64
    .line 65
    sget v1, LYa/e;->first_select_ll:I

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Landroid/widget/LinearLayout;

    .line 72
    .line 73
    return-object v0

    .line 74
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 75
    .line 76
    sget v1, LYa/e;->first_contact_name_tv:I

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    check-cast v0, Landroid/widget/TextView;

    .line 83
    .line 84
    return-object v0

    .line 85
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 86
    .line 87
    sget v1, LYa/e;->oc_second_category_tv:I

    .line 88
    .line 89
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    check-cast v0, Landroid/widget/TextView;

    .line 94
    .line 95
    return-object v0

    .line 96
    :pswitch_7
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 97
    .line 98
    sget v1, LYa/e;->first_contact_number_tv:I

    .line 99
    .line 100
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    check-cast v0, Landroid/widget/TextView;

    .line 105
    .line 106
    return-object v0

    .line 107
    :pswitch_8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 108
    .line 109
    sget v1, LYa/e;->first_select_error_tips_tv:I

    .line 110
    .line 111
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    check-cast v0, Landroid/widget/TextView;

    .line 116
    .line 117
    return-object v0

    .line 118
    :pswitch_9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 119
    .line 120
    sget v1, LYa/e;->first_contact_last_name_et:I

    .line 121
    .line 122
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    check-cast v0, Landroid/widget/EditText;

    .line 127
    .line 128
    return-object v0

    .line 129
    :pswitch_a
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 130
    .line 131
    sget v1, LYa/e;->first_name_tips_tv:I

    .line 132
    .line 133
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    check-cast v0, Landroid/widget/TextView;

    .line 138
    .line 139
    return-object v0

    .line 140
    :pswitch_b
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 141
    .line 142
    sget v1, LYa/e;->clear_first_name_img:I

    .line 143
    .line 144
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    check-cast v0, Landroid/widget/ImageView;

    .line 149
    .line 150
    return-object v0

    .line 151
    :pswitch_c
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 152
    .line 153
    sget v1, LYa/e;->first_contact_phone_et:I

    .line 154
    .line 155
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    check-cast v0, Landroid/widget/EditText;

    .line 160
    .line 161
    return-object v0

    .line 162
    :pswitch_d
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 163
    .line 164
    sget v1, LYa/e;->clear_first_phone_img:I

    .line 165
    .line 166
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    check-cast v0, Landroid/widget/ImageView;

    .line 171
    .line 172
    return-object v0

    .line 173
    :pswitch_e
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 174
    .line 175
    sget v1, LYa/e;->router_close_img:I

    .line 176
    .line 177
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    check-cast v0, Landroid/widget/ImageView;

    .line 182
    .line 183
    return-object v0

    .line 184
    :pswitch_f
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 185
    .line 186
    sget v1, LYa/e;->phone_num_one_tv:I

    .line 187
    .line 188
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    check-cast v0, Landroid/widget/TextView;

    .line 193
    .line 194
    return-object v0

    .line 195
    :pswitch_10
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 196
    .line 197
    sget v1, LYa/e;->first_error_tips_tv:I

    .line 198
    .line 199
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    check-cast v0, Landroid/widget/TextView;

    .line 204
    .line 205
    return-object v0

    .line 206
    :pswitch_11
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 207
    .line 208
    sget v1, LYa/e;->second_contact_rv:I

    .line 209
    .line 210
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 215
    .line 216
    return-object v0

    .line 217
    :pswitch_12
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 218
    .line 219
    sget v1, LYa/e;->first_manual_input_group:I

    .line 220
    .line 221
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 222
    .line 223
    .line 224
    move-result-object v0

    .line 225
    check-cast v0, Landroidx/constraintlayout/widget/Group;

    .line 226
    .line 227
    return-object v0

    .line 228
    :pswitch_13
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 229
    .line 230
    sget v1, LYa/e;->oc_first_category_tv:I

    .line 231
    .line 232
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 233
    .line 234
    .line 235
    move-result-object v0

    .line 236
    check-cast v0, Landroid/widget/TextView;

    .line 237
    .line 238
    return-object v0

    .line 239
    :pswitch_14
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 240
    .line 241
    sget v1, LYa/e;->first_contact_rv:I

    .line 242
    .line 243
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 244
    .line 245
    .line 246
    move-result-object v0

    .line 247
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 248
    .line 249
    return-object v0

    .line 250
    :pswitch_15
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 251
    .line 252
    sget v1, LYa/e;->first_category_tips_tv:I

    .line 253
    .line 254
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 255
    .line 256
    .line 257
    move-result-object v0

    .line 258
    check-cast v0, Landroid/widget/TextView;

    .line 259
    .line 260
    return-object v0

    .line 261
    :pswitch_16
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 262
    .line 263
    sget v1, LYa/e;->second_select_ll:I

    .line 264
    .line 265
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 266
    .line 267
    .line 268
    move-result-object v0

    .line 269
    check-cast v0, Landroid/widget/LinearLayout;

    .line 270
    .line 271
    return-object v0

    .line 272
    :pswitch_17
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 273
    .line 274
    sget v1, LYa/e;->second_contact_name_tv:I

    .line 275
    .line 276
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 277
    .line 278
    .line 279
    move-result-object v0

    .line 280
    check-cast v0, Landroid/widget/TextView;

    .line 281
    .line 282
    return-object v0

    .line 283
    :pswitch_18
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 284
    .line 285
    sget v1, LYa/e;->second_contact_number_tv:I

    .line 286
    .line 287
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 288
    .line 289
    .line 290
    move-result-object v0

    .line 291
    check-cast v0, Landroid/widget/TextView;

    .line 292
    .line 293
    return-object v0

    .line 294
    :pswitch_19
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 295
    .line 296
    sget v1, LYa/e;->second_select_error_tips_tv:I

    .line 297
    .line 298
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 299
    .line 300
    .line 301
    move-result-object v0

    .line 302
    check-cast v0, Landroid/widget/TextView;

    .line 303
    .line 304
    return-object v0

    .line 305
    :pswitch_1a
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 306
    .line 307
    sget v1, LYa/e;->router_title_tv:I

    .line 308
    .line 309
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 310
    .line 311
    .line 312
    move-result-object v0

    .line 313
    check-cast v0, Landroid/widget/TextView;

    .line 314
    .line 315
    return-object v0

    .line 316
    :pswitch_1b
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 317
    .line 318
    sget v1, LYa/e;->second_contact_last_name_et:I

    .line 319
    .line 320
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 321
    .line 322
    .line 323
    move-result-object v0

    .line 324
    check-cast v0, Landroid/widget/EditText;

    .line 325
    .line 326
    return-object v0

    .line 327
    :pswitch_1c
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 328
    .line 329
    sget v1, LYa/e;->router_right_tv:I

    .line 330
    .line 331
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    check-cast v0, Landroid/widget/TextView;

    .line 336
    .line 337
    return-object v0

    .line 338
    nop

    .line 339
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
