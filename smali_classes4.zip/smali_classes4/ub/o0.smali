.class public final synthetic Lub/o0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/o0;->a:I

    iput-object p1, p0, Lub/o0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 5

    .line 1
    const/4 p1, 0x0

    .line 2
    iget-object v0, p0, Lub/o0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;

    .line 3
    .line 4
    iget v1, p0, Lub/o0;->a:I

    .line 5
    .line 6
    packed-switch v1, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;->L:I

    .line 10
    .line 11
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const-string v2, "/credit_score/oc_repay_activity"

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;->B:Lcom/transsnet/palmpay/credit/bean/rsp/OcOfflineInstallmentBillData;

    .line 22
    .line 23
    if-eqz v2, :cond_0

    .line 24
    .line 25
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/OcOfflineInstallmentBillData;->getCardNo()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    move-object v2, p1

    .line 31
    :goto_0
    const-string v3, "oc_repay_card_no"

    .line 32
    .line 33
    invoke-virtual {v1, v3, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const-string v2, "oc_repay_bill_id"

    .line 38
    .line 39
    const-wide/16 v3, 0x0

    .line 40
    .line 41
    invoke-virtual {v1, v2, v3, v4}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;->B:Lcom/transsnet/palmpay/credit/bean/rsp/OcOfflineInstallmentBillData;

    .line 46
    .line 47
    if-eqz v2, :cond_1

    .line 48
    .line 49
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/OcOfflineInstallmentBillData;->getOrderNo()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    :cond_1
    const-string v2, "oc_repay_order_no"

    .line 54
    .line 55
    invoke-virtual {v1, v2, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    const-string v1, "oc_repay_operate_type"

    .line 60
    .line 61
    const-string v2, "17"

    .line 62
    .line 63
    invoke-virtual {p1, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    const-string v1, "oc_repay_query_ins_type"

    .line 68
    .line 69
    const/4 v2, 0x1

    .line 70
    invoke-virtual {p1, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;->L:I

    .line 79
    .line 80
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    const-string v2, "/credit_score/oc_repay_order_detail_activity"

    .line 85
    .line 86
    invoke-virtual {v1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    const-string v2, "orderType"

    .line 91
    .line 92
    const-string v3, "g7"

    .line 93
    .line 94
    invoke-virtual {v1, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOfflineInstallmentDetailActivity;->B:Lcom/transsnet/palmpay/credit/bean/rsp/OcOfflineInstallmentBillData;

    .line 99
    .line 100
    if-eqz v0, :cond_2

    .line 101
    .line 102
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/OcOfflineInstallmentBillData;->getPayId()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    :cond_2
    const-string v0, "orderNo"

    .line 107
    .line 108
    invoke-virtual {v1, v0, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 109
    .line 110
    .line 111
    move-result-object p1

    .line 112
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    return-void

    .line 116
    nop

    .line 117
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
