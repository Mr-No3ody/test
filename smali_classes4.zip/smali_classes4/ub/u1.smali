.class public final synthetic Lub/u1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/u1;->a:I

    iput-object p1, p0, Lub/u1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget-object p1, p0, Lub/u1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;

    .line 2
    .line 3
    iget v0, p0, Lub/u1;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;->t:I

    .line 9
    .line 10
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-string v1, "/credit_score/oc_set_default_pay_method_activity"

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v0, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;->t:I

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 28
    .line 29
    .line 30
    sget-object v0, Lob/c;->a:Lob/a;

    .line 31
    .line 32
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    const-string v1, "1"

    .line 44
    .line 45
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->okCardMainPage(Ljava/lang/String;)Ldf/d;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 50
    .line 51
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    new-instance v1, Ltb/q;

    .line 64
    .line 65
    const/16 v2, 0x1b

    .line 66
    .line 67
    invoke-direct {v1, p1, v2}, Ltb/q;-><init>(Ljava/lang/Object;I)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :pswitch_1
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSettingActivity;->t:I

    .line 75
    .line 76
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    const-string v1, "/credit_score/oc_bill_history_activity"

    .line 81
    .line 82
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-virtual {v0, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    return-void

    .line 90
    nop

    .line 91
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
