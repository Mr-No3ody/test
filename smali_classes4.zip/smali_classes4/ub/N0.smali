.class public final Lub/N0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewpager/widget/ViewPager$OnPageChangeListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnHistoryActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnHistoryActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/N0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnHistoryActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onPageScrollStateChanged(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onPageScrolled(IFI)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onPageSelected(I)V
    .locals 1

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    goto :goto_0

    .line 5
    :cond_0
    const/4 p1, 0x0

    .line 6
    :goto_0
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnHistoryActivity;->i:I

    .line 7
    .line 8
    iget-object v0, p0, Lub/N0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnHistoryActivity;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnHistoryActivity;->p(Z)V

    .line 11
    .line 12
    .line 13
    return-void
.end method
