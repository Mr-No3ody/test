.class public final synthetic Lub/E;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/E;->a:I

    iput-object p1, p0, Lub/E;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 12

    const-string p1, "/credit_score/oc_phone_temp_activity"

    const-string v0, "Can\'t select contact"

    const/4 v1, 0x0

    const-string v2, ""

    const/4 v3, 0x0

    const-string v4, "OcContactActivity_element_click"

    iget-object v5, p0, Lub/E;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;

    iget v6, p0, Lub/E;->a:I

    packed-switch v6, :pswitch_data_0

    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 1
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->r()V

    return-void

    .line 2
    :pswitch_0
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    const/16 p1, 0x3e9

    .line 3
    :try_start_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->j1:Ljava/lang/Integer;

    .line 4
    iget-object p1, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->k1:Landroidx/activity/result/a;

    .line 5
    invoke-virtual {p1, v3}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 6
    :catch_0
    new-array p1, v1, [Ljava/lang/Object;

    invoke-static {v0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 7
    :goto_0
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "second_select_ll"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 8
    :pswitch_1
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    const/16 p1, 0x3e8

    .line 9
    :try_start_1
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->j1:Ljava/lang/Integer;

    .line 10
    iget-object p1, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->k1:Landroidx/activity/result/a;

    .line 11
    invoke-virtual {p1, v3}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    .line 12
    :catch_1
    new-array p1, v1, [Ljava/lang/Object;

    invoke-static {v0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 13
    :goto_1
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "first_select_ll"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 14
    :pswitch_2
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 15
    new-instance p1, LO6/c;

    invoke-direct {p1, v5}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 16
    iput-boolean v1, p1, LO6/c;->k:Z

    .line 17
    sget v0, LYa/g;->cs_oc_filling_out_contacts:I

    invoke-virtual {v5, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 18
    invoke-static {v0}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p1, LO6/c;->b:Ljava/lang/CharSequence;

    .line 19
    sget v0, LYa/g;->cs_oc_skip_contact_content:I

    invoke-virtual {v5, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 20
    iput-object v0, p1, LO6/c;->d:Ljava/lang/CharSequence;

    .line 21
    sget v0, LYa/g;->cs_oc_exit:I

    invoke-virtual {v5, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lub/E;

    const/16 v6, 0xd

    invoke-direct {v1, v5, v6}, Lub/E;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;I)V

    .line 22
    iput-object v0, p1, LO6/c;->g:Ljava/lang/String;

    .line 23
    iput-object v1, p1, LO6/c;->i:Landroid/view/View$OnClickListener;

    .line 24
    sget v0, Lba/k;->core_continue:I

    invoke-virtual {v5, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 25
    iput-object v0, p1, LO6/c;->f:Ljava/lang/String;

    .line 26
    iput-object v3, p1, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 27
    invoke-virtual {p1}, LO6/c;->a()LO6/d;

    move-result-object p1

    .line 28
    invoke-virtual {p1}, LO6/d;->show()V

    .line 29
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "router_right_tv"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 30
    :pswitch_3
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 31
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v()V

    .line 32
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    .line 33
    iget-object v0, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    if-eqz v0, :cond_0

    .line 34
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    move-result-object v3

    .line 35
    :cond_0
    const-string v0, "router_close_img"

    invoke-virtual {p1, v4, v0, v3}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 36
    :pswitch_4
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 37
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    move-result-object p1

    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    move-result-object p1

    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/db/entity/User;->getPhoneNumber()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, LPa/r0;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 38
    iget-object v0, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->d1:Lyb/K;

    if-eqz v0, :cond_2f

    .line 39
    iget v0, v0, Lyb/K;->g:I

    .line 40
    const-string v2, "getValue(...)"

    const/4 v6, -0x1

    const/4 v7, 0x1

    if-ne v0, v6, :cond_1

    .line 41
    iget-object v0, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K0:Lxf/t;

    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    move-result-object v8

    invoke-static {v8, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v8, Landroid/widget/TextView;

    .line 42
    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 43
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/widget/TextView;

    .line 44
    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    move v8, v1

    move v0, v7

    goto :goto_2

    :cond_1
    move v0, v1

    move v8, v7

    .line 45
    :goto_2
    iget v9, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->g1:I

    const/4 v10, 0x2

    const-string v11, "getText(...)"

    if-ge v9, v10, :cond_8

    .line 46
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->F()Landroid/widget/EditText;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v9

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_3

    .line 47
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->L()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_input_full_name:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 48
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->L()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 49
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->F()Landroid/widget/EditText;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_2

    .line 50
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->L()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    :goto_3
    move v8, v1

    move v0, v7

    goto :goto_4

    :cond_2
    move v8, v1

    goto :goto_4

    .line 51
    :cond_3
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->F()Landroid/widget/EditText;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v9

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    move-result v9

    if-ge v9, v10, :cond_4

    .line 52
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->L()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_name_more_than_two_char:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 53
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->L()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 54
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->F()Landroid/widget/EditText;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_2

    .line 55
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->L()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto :goto_3

    .line 56
    :cond_4
    :goto_4
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v9

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_6

    .line 57
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_oc_please_input_phone_number:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 58
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 59
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_5

    .line 60
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    :goto_5
    move v8, v1

    move v0, v7

    goto/16 :goto_8

    :cond_5
    move v8, v1

    goto/16 :goto_8

    .line 61
    :cond_6
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->z(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_7

    .line 62
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_oc_input_correct_number:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 63
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 64
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_5

    .line 65
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto :goto_5

    .line 66
    :cond_7
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {p1, v9}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_e

    .line 67
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_oc_not_use_own_phone_number:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 68
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 69
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_5

    .line 70
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_5

    .line 71
    :cond_8
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->G()Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_a

    .line 72
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_input_full_name:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 73
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 74
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->G()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_9

    .line 75
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    :goto_6
    move v8, v1

    move v0, v7

    goto :goto_7

    :cond_9
    move v8, v1

    goto :goto_7

    .line 76
    :cond_a
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->G()Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    move-result v9

    if-ge v9, v10, :cond_b

    .line 77
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_name_more_than_two_char:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 78
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 79
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->N()Landroid/widget/LinearLayout;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_9

    .line 80
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->L()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto :goto_6

    .line 81
    :cond_b
    :goto_7
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->H()Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_c

    .line 82
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_oc_please_input_phone_number:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 83
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 84
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->N()Landroid/widget/LinearLayout;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_5

    .line 85
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_5

    .line 86
    :cond_c
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->H()Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->z(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_d

    .line 87
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_oc_input_correct_number:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 88
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 89
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->N()Landroid/widget/LinearLayout;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_5

    .line 90
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_5

    .line 91
    :cond_d
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->H()Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {p1, v9}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_e

    .line 92
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    sget v9, LYa/g;->cs_oc_not_use_own_phone_number:I

    invoke-virtual {v5, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 93
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    .line 94
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->N()Landroid/widget/LinearLayout;

    move-result-object v8

    sget v9, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_5

    .line 95
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->M()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_5

    .line 96
    :cond_e
    :goto_8
    iget-object v9, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->f1:Lyb/K;

    if-eqz v9, :cond_2e

    .line 97
    iget v9, v9, Lyb/K;->g:I

    if-ne v9, v6, :cond_10

    .line 98
    iget-object v6, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->v0:Lxf/t;

    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    move-result-object v8

    invoke-static {v8, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v8, Landroid/widget/TextView;

    .line 99
    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    if-nez v0, :cond_f

    .line 100
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/widget/TextView;

    .line 101
    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    move v8, v1

    move v0, v7

    goto :goto_9

    :cond_f
    move v8, v1

    .line 102
    :cond_10
    :goto_9
    iget v2, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->g1:I

    if-ge v2, v10, :cond_17

    .line 103
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_12

    .line 104
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_input_full_name:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 105
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 106
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_11

    .line 107
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    :goto_a
    move v8, v1

    move v0, v7

    goto :goto_b

    :cond_11
    move v8, v1

    goto :goto_b

    .line 108
    :cond_12
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-ge v2, v10, :cond_13

    .line 109
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_name_more_than_two_char:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 110
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 111
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_11

    .line 112
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto :goto_a

    .line 113
    :cond_13
    :goto_b
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_15

    .line 114
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_oc_please_input_phone_number:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 115
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 116
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_14

    .line 117
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    :goto_c
    move v8, v1

    move v0, v7

    goto/16 :goto_f

    :cond_14
    move v8, v1

    goto/16 :goto_f

    .line 118
    :cond_15
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->z(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_16

    .line 119
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_oc_input_correct_number:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 120
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 121
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_14

    .line 122
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto :goto_c

    .line 123
    :cond_16
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1d

    .line 124
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_oc_not_use_own_phone_number:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 125
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 126
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_14

    .line 127
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_c

    .line 128
    :cond_17
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->P()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_19

    .line 129
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_input_full_name:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 130
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 131
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->W()Landroid/widget/LinearLayout;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_18

    .line 132
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    :goto_d
    move v8, v1

    move v0, v7

    goto :goto_e

    :cond_18
    move v8, v1

    goto :goto_e

    .line 133
    :cond_19
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->P()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-ge v2, v10, :cond_1a

    .line 134
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_name_more_than_two_char:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 135
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 136
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->W()Landroid/widget/LinearLayout;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_18

    .line 137
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto :goto_d

    .line 138
    :cond_1a
    :goto_e
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Q()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1b

    .line 139
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_oc_please_input_phone_number:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 140
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 141
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->W()Landroid/widget/LinearLayout;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_14

    .line 142
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_c

    .line 143
    :cond_1b
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Q()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->z(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1c

    .line 144
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_oc_input_correct_number:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 145
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 146
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->W()Landroid/widget/LinearLayout;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_14

    .line 147
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_c

    .line 148
    :cond_1c
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Q()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1d

    .line 149
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_oc_not_use_own_phone_number:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 150
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 151
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->W()Landroid/widget/LinearLayout;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_14

    .line 152
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_c

    .line 153
    :cond_1d
    :goto_f
    iget v2, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->g1:I

    if-ge v2, v10, :cond_22

    .line 154
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->F()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1f

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1f

    .line 155
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->F()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1f

    .line 156
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_same_name_warn:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 157
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 158
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_1e

    .line 159
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    move v8, v1

    move v0, v7

    goto :goto_10

    :cond_1e
    move v8, v1

    .line 160
    :cond_1f
    :goto_10
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_21

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_21

    .line 161
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_21

    .line 162
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_same_phone_num_warn:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 163
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 164
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_20

    .line 165
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    :goto_11
    move v8, v1

    goto/16 :goto_13

    :cond_20
    move v7, v0

    goto :goto_11

    :cond_21
    move v7, v0

    goto/16 :goto_13

    .line 166
    :cond_22
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->G()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_24

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->P()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_24

    .line 167
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->G()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->P()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_24

    .line 168
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_same_name_warn:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 169
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 170
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->W()Landroid/widget/LinearLayout;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_23

    .line 171
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    move v8, v1

    move v0, v7

    goto :goto_12

    :cond_23
    move v8, v1

    .line 172
    :cond_24
    :goto_12
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->H()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_21

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Q()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_21

    .line 173
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->H()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Q()Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_21

    .line 174
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    sget v6, LYa/g;->cs_same_phone_num_warn:I

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 175
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 176
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->W()Landroid/widget/LinearLayout;

    move-result-object v2

    sget v6, LYa/d;->cs_oc_contact_et_bg:I

    invoke-virtual {v2, v6}, Landroid/view/View;->setBackgroundResource(I)V

    if-nez v0, :cond_20

    .line 177
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->V()Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_11

    .line 178
    :goto_13
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Y()Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-static {v0, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_25

    .line 179
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    goto/16 :goto_15

    .line 180
    :cond_25
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Y()Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->z(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_27

    .line 181
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    sget v0, LYa/g;->cs_oc_input_correct_number:I

    invoke-virtual {v5, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 182
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    if-nez v7, :cond_26

    .line 183
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {v5, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    :cond_26
    :goto_14
    move v8, v1

    goto/16 :goto_15

    .line 184
    :cond_27
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Y()Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_28

    .line 185
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    sget v0, LYa/g;->cs_oc_not_use_own_phone_number:I

    invoke-virtual {v5, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 186
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    if-nez v7, :cond_26

    .line 187
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {v5, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto :goto_14

    .line 188
    :cond_28
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Y()Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_29

    .line 189
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Y()Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2a

    .line 190
    :cond_29
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    sget v0, LYa/g;->cs_same_phone_num_warn:I

    invoke-virtual {v5, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 191
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    if-nez v7, :cond_26

    .line 192
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {v5, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->b0(Landroid/widget/TextView;)V

    goto/16 :goto_14

    :cond_2a
    :goto_15
    if-eqz v8, :cond_2c

    .line 193
    iget p1, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->g1:I

    if-ge p1, v10, :cond_2b

    .line 194
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_16

    .line 195
    :cond_2b
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->H()Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 196
    :goto_16
    invoke-virtual {v5, v1, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->a0(ILjava/lang/String;)V

    .line 197
    :cond_2c
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    .line 198
    iget-object v0, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    if-eqz v0, :cond_2d

    .line 199
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    move-result-object v3

    .line 200
    :cond_2d
    const-string v0, "contact_next_bt"

    invoke-virtual {p1, v4, v0, v3}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 201
    :cond_2e
    const-string p1, "mSecondLabelAdapter"

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    throw v3

    .line 202
    :cond_2f
    const-string p1, "mFirstLabelAdapter"

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    throw v3

    .line 203
    :pswitch_5
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 204
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->Y()Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 205
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "clear_self_phone_img"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 206
    :pswitch_6
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 207
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 208
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "clear_second_phone_img"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 209
    :pswitch_7
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 210
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 211
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "clear_second_name_img"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 212
    :pswitch_8
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 213
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 214
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "clear_first_phone_img"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 215
    :pswitch_9
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 216
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->F()Landroid/widget/EditText;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 217
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "clear_first_name_img"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 218
    :pswitch_a
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 219
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    move-result-object v0

    .line 220
    invoke-virtual {v0, p1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    move-result-object p1

    .line 221
    invoke-virtual {p1, v5}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 222
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "phone_num_two_tv"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 223
    :pswitch_b
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 224
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    move-result-object v0

    .line 225
    invoke-virtual {v0, p1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    move-result-object p1

    .line 226
    invoke-virtual {p1, v5}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 227
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    const-string v0, "phone_num_one_tv"

    invoke-virtual {p1, v4, v0, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 228
    :pswitch_c
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 229
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->onBackPressed()V

    .line 230
    invoke-static {}, LPa/n0;->g()LPa/n0;

    move-result-object p1

    .line 231
    iget-object v0, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    if-eqz v0, :cond_30

    .line 232
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    move-result-object v3

    .line 233
    :cond_30
    const-string v0, "router_back_img"

    invoke-virtual {p1, v4, v0, v3}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
