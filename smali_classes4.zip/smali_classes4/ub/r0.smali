.class public final synthetic Lub/r0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lub/s0;


# direct methods
.method public synthetic constructor <init>(Lub/s0;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/r0;->a:I

    iput-object p1, p0, Lub/r0;->b:Lub/s0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget p1, p0, Lub/r0;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lub/r0;->b:Lub/s0;

    .line 7
    .line 8
    iget-object p1, p1, Lub/s0;->f:Lub/t0;

    .line 9
    .line 10
    iget-object v0, p1, Lub/t0;->a:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 13
    .line 14
    const-string v1, "SKIP"

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->x(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object p1, p1, Lub/t0;->a:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 22
    .line 23
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->r()V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :pswitch_0
    iget-object p1, p0, Lub/r0;->b:Lub/s0;

    .line 28
    .line 29
    iget-object p1, p1, Lub/s0;->f:Lub/t0;

    .line 30
    .line 31
    iget-object p1, p1, Lub/t0;->a:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 34
    .line 35
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 36
    .line 37
    sget v1, LYa/g;->cs_oc_too_many_otp_requests:I

    .line 38
    .line 39
    invoke-virtual {p1, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    invoke-static {v0, p1}, Lub/v0;->a(Lub/v0;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
