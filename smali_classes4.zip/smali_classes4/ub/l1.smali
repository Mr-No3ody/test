.class public final Lub/l1;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/l1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/l1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    const-string v0, "message"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/l1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 10
    .line 11
    .line 12
    new-array v0, v1, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 10

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp;

    .line 2
    .line 3
    iget-object v1, p0, Lub/l1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 4
    .line 5
    const/4 v6, 0x0

    .line 6
    invoke-virtual {v1, v6}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 7
    .line 8
    .line 9
    const/4 v7, 0x0

    .line 10
    if-eqz p1, :cond_9

    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v8, 0x1

    .line 17
    if-ne v0, v8, :cond_9

    .line 18
    .line 19
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp;->data:Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;

    .line 20
    .line 21
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->o:I

    .line 22
    .line 23
    if-eqz p1, :cond_8

    .line 24
    .line 25
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->r()Landroid/widget/LinearLayout;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->s()Landroid/widget/LinearLayout;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 40
    .line 41
    .line 42
    move-result-object v9

    .line 43
    sget-object v0, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->A:Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;

    .line 44
    .line 45
    iget-object v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->orderStatusDesc:Ljava/lang/String;

    .line 46
    .line 47
    const/4 v5, 0x0

    .line 48
    const/4 v3, 0x0

    .line 49
    const/4 v4, 0x4

    .line 50
    invoke-static/range {v0 .. v5}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;->getOrderStatusIconByDes$default(Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;Landroid/content/Context;Ljava/lang/String;FILjava/lang/Object;)Landroid/graphics/drawable/Drawable;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-virtual {v9, v0}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->l(Landroid/graphics/drawable/Drawable;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    iget-object v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->merchantName:Ljava/lang/String;

    .line 62
    .line 63
    new-instance v3, Ljava/lang/StringBuilder;

    .line 64
    .line 65
    const-string v4, "To "

    .line 66
    .line 67
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->o(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    iget-wide v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->payAmount:J

    .line 85
    .line 86
    invoke-static {v2, v3, v6}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->c(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    sget v2, LYa/d;->cv_cl_cash_loan_repay:I

    .line 98
    .line 99
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->d(I)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    iget v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->orderStatus:I

    .line 107
    .line 108
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->o(I)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->k(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusArrow()Landroid/widget/ImageView;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    iget-object v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 124
    .line 125
    if-nez v2, :cond_0

    .line 126
    .line 127
    const/16 v2, 0x8

    .line 128
    .line 129
    goto :goto_0

    .line 130
    :cond_0
    move v2, v6

    .line 131
    :goto_0
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusLayout()Landroid/widget/LinearLayout;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    iget-object v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 143
    .line 144
    if-eqz v2, :cond_1

    .line 145
    .line 146
    move v6, v8

    .line 147
    :cond_1
    invoke-virtual {v0, v6}, Landroid/view/View;->setEnabled(Z)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusLayout()Landroid/widget/LinearLayout;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    new-instance v2, Ltb/W;

    .line 159
    .line 160
    const/4 v3, 0x6

    .line 161
    invoke-direct {v2, v3, v1, p1}, Ltb/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    invoke-static {v2, v0}, Loa/h;->l(Landroid/view/View$OnClickListener;Landroid/view/View;)V

    .line 165
    .line 166
    .line 167
    sget v0, Lba/k;->core_receipt_transaction_type:I

    .line 168
    .line 169
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    sget v2, LYa/g;->cs_auto_deduct:I

    .line 174
    .line 175
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v2

    .line 179
    const/16 v3, 0x3ea

    .line 180
    .line 181
    invoke-virtual {v1, v2, v3, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->q(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    sget v2, LYa/d;->cs_oc_interest_question_icon:I

    .line 186
    .line 187
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;->i(I)V

    .line 188
    .line 189
    .line 190
    new-instance v2, Lsc/x;

    .line 191
    .line 192
    const/16 v4, 0x1a

    .line 193
    .line 194
    invoke-direct {v2, v1, v4}, Lsc/x;-><init>(Ljava/lang/Object;I)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 198
    .line 199
    .line 200
    iget v0, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->payerAccountType:I

    .line 201
    .line 202
    if-eq v0, v8, :cond_5

    .line 203
    .line 204
    const/4 v2, 0x2

    .line 205
    if-eq v0, v2, :cond_2

    .line 206
    .line 207
    const-string v0, ""

    .line 208
    .line 209
    goto :goto_2

    .line 210
    :cond_2
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->bankName:Ljava/lang/String;

    .line 211
    .line 212
    iget-object v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->bankCard:Ljava/lang/String;

    .line 213
    .line 214
    invoke-static {v0, v2}, LPa/i0;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    if-eqz v0, :cond_4

    .line 219
    .line 220
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 221
    .line 222
    .line 223
    move-result v2

    .line 224
    if-nez v2, :cond_3

    .line 225
    .line 226
    goto :goto_1

    .line 227
    :cond_3
    move-object v0, v7

    .line 228
    :goto_1
    if-eqz v0, :cond_4

    .line 229
    .line 230
    goto :goto_2

    .line 231
    :cond_4
    sget v0, Lba/k;->core_bank_card:I

    .line 232
    .line 233
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    const-string v2, "run(...)"

    .line 238
    .line 239
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    goto :goto_2

    .line 243
    :cond_5
    sget v0, Lba/k;->core_palmpay_payment_balance:I

    .line 244
    .line 245
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object v0

    .line 249
    const-string v2, "getString(...)"

    .line 250
    .line 251
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 252
    .line 253
    .line 254
    :goto_2
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 255
    .line 256
    .line 257
    move-result v2

    .line 258
    if-nez v2, :cond_6

    .line 259
    .line 260
    move-object v7, v0

    .line 261
    :cond_6
    if-eqz v7, :cond_7

    .line 262
    .line 263
    sget v0, Lba/k;->core_payment_method:I

    .line 264
    .line 265
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 266
    .line 267
    .line 268
    move-result-object v0

    .line 269
    invoke-virtual {v1, v7, v3, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->q(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 270
    .line 271
    .line 272
    :cond_7
    sget v0, Lba/k;->core_reference_no_2:I

    .line 273
    .line 274
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object v0

    .line 278
    iget-object v2, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->orderNo:Ljava/lang/String;

    .line 279
    .line 280
    const/16 v4, 0x3eb

    .line 281
    .line 282
    invoke-virtual {v1, v2, v4, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->q(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 283
    .line 284
    .line 285
    sget v0, Lba/k;->core_completion_time:I

    .line 286
    .line 287
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 288
    .line 289
    .line 290
    move-result-object v0

    .line 291
    iget-wide v4, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoDeductOrderDetailRsp$DataBean;->updateTime:J

    .line 292
    .line 293
    invoke-static {v4, v5}, LPa/r0;->R(J)Ljava/lang/String;

    .line 294
    .line 295
    .line 296
    move-result-object p1

    .line 297
    invoke-virtual {v1, p1, v3, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->q(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 298
    .line 299
    .line 300
    :cond_8
    return-void

    .line 301
    :cond_9
    if-eqz p1, :cond_a

    .line 302
    .line 303
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v7

    .line 307
    :cond_a
    new-array p1, v6, [Ljava/lang/Object;

    .line 308
    .line 309
    invoke-static {v7, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 310
    .line 311
    .line 312
    return-void
.end method
