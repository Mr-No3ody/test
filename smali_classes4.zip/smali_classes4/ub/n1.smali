.class public final Lub/n1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/model/OrderResultCustomerServiceModel$OnCustomerServiceModelListener;


# virtual methods
.method public final onLeftClick(Landroid/view/View;)V
    .locals 1

    .line 1
    const-string v0, "v"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "flexihome"

    .line 7
    .line 8
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->w(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final onRightClick(Landroid/view/View;)V
    .locals 1

    .line 1
    const-string v0, "v"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "/h5/help/main?phone=#phone#"

    .line 7
    .line 8
    invoke-static {p1}, Lcom/transsnet/palmpay/core/config/d;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-static {p1}, LPa/i0;->c0(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method
