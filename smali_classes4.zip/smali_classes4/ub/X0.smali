.class public final Lub/X0;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/X0;->f:I

    iput-object p1, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/X0;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_0
    const-string v0, "d"

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :pswitch_1
    const-string v0, "d"

    .line 29
    .line 30
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 34
    .line 35
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_2
    const-string v0, "d"

    .line 40
    .line 41
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 45
    .line 46
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :pswitch_3
    const-string v0, "d"

    .line 51
    .line 52
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 56
    .line 57
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget v0, p0, Lub/X0;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 10
    .line 11
    .line 12
    new-array v0, v1, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 22
    .line 23
    .line 24
    new-array v0, v1, [Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_1
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 31
    .line 32
    const/4 v1, 0x0

    .line 33
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 34
    .line 35
    .line 36
    new-array v0, v1, [Ljava/lang/Object;

    .line 37
    .line 38
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :pswitch_2
    const-string v0, "message"

    .line 43
    .line 44
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    const/4 v0, 0x0

    .line 48
    new-array v0, v0, [Ljava/lang/Object;

    .line 49
    .line 50
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :pswitch_3
    iget-object v0, p0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 55
    .line 56
    const/4 v1, 0x0

    .line 57
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 58
    .line 59
    .line 60
    new-array v0, v1, [Ljava/lang/Object;

    .line 61
    .line 62
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    return-void

    .line 66
    nop

    .line 67
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/16 v2, 0x8

    .line 5
    .line 6
    const-string v3, "getValue(...)"

    .line 7
    .line 8
    const/4 v6, 0x0

    .line 9
    const/4 v7, 0x1

    .line 10
    const/4 v8, 0x0

    .line 11
    iget-object v9, v0, Lub/X0;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 12
    .line 13
    iget v10, v0, Lub/X0;->f:I

    .line 14
    .line 15
    packed-switch v10, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    move-object/from16 v1, p1

    .line 19
    .line 20
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/CLFamilyAndFriendPayResp;

    .line 21
    .line 22
    invoke-virtual {v9, v8}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 23
    .line 24
    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    if-ne v2, v7, :cond_2

    .line 32
    .line 33
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLFamilyAndFriendPayResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/FamilyAndFriendsPayData;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    if-eqz v2, :cond_2

    .line 38
    .line 39
    new-instance v2, Landroid/os/Bundle;

    .line 40
    .line 41
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 42
    .line 43
    .line 44
    const-string v3, "paymentLinkAccountType"

    .line 45
    .line 46
    const-string v4, "single"

    .line 47
    .line 48
    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    iget-object v3, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->c1:Ljava/lang/String;

    .line 52
    .line 53
    const-string v4, "cardNo"

    .line 54
    .line 55
    invoke-virtual {v2, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLFamilyAndFriendPayResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/FamilyAndFriendsPayData;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/FamilyAndFriendsPayData;->getExistPaymentLink()Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    if-nez v1, :cond_0

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_0
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    if-ne v1, v7, :cond_1

    .line 77
    .line 78
    const-string v1, "LoanFamilyFriendsShare"

    .line 79
    .line 80
    invoke-static {v2, v1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_1
    :goto_0
    const-string v1, "LoanFamilyFriends"

    .line 85
    .line 86
    invoke-static {v2, v1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_2
    if-eqz v1, :cond_3

    .line 91
    .line 92
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v6

    .line 96
    :cond_3
    new-array v1, v8, [Ljava/lang/Object;

    .line 97
    .line 98
    invoke-static {v6, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    :goto_1
    return-void

    .line 102
    :pswitch_0
    move-object/from16 v1, p1

    .line 103
    .line 104
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillDetailResp;

    .line 105
    .line 106
    invoke-virtual {v9, v8}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 107
    .line 108
    .line 109
    if-eqz v1, :cond_c

    .line 110
    .line 111
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 112
    .line 113
    .line 114
    move-result v2

    .line 115
    if-ne v2, v7, :cond_c

    .line 116
    .line 117
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillDetailResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    if-eqz v2, :cond_c

    .line 122
    .line 123
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillDetailResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;

    .line 124
    .line 125
    .line 126
    move-result-object v1

    .line 127
    iput-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->h1:Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;

    .line 128
    .line 129
    iget-object v1, v9, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 130
    .line 131
    const-string v2, "updateViewForPalmPayCard >>>"

    .line 132
    .line 133
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    const/4 v6, 0x3

    .line 138
    invoke-static {v1, v6, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    iget-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->h1:Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;

    .line 142
    .line 143
    if-eqz v1, :cond_e

    .line 144
    .line 145
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;->getUnpaidAmount()Ljava/lang/Long;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    if-eqz v2, :cond_4

    .line 150
    .line 151
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 152
    .line 153
    .line 154
    move-result-wide v10

    .line 155
    goto :goto_2

    .line 156
    :cond_4
    const-wide/16 v10, 0x0

    .line 157
    .line 158
    :goto_2
    iput-wide v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->f1:J

    .line 159
    .line 160
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;->getUnpaidAmount()Ljava/lang/Long;

    .line 161
    .line 162
    .line 163
    move-result-object v2

    .line 164
    if-eqz v2, :cond_5

    .line 165
    .line 166
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 167
    .line 168
    .line 169
    move-result-wide v10

    .line 170
    goto :goto_3

    .line 171
    :cond_5
    const-wide/16 v10, 0x0

    .line 172
    .line 173
    :goto_3
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;->getUnpaidPrincipal()Ljava/lang/Long;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    if-eqz v2, :cond_6

    .line 178
    .line 179
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 180
    .line 181
    .line 182
    move-result-wide v12

    .line 183
    goto :goto_4

    .line 184
    :cond_6
    const-wide/16 v12, 0x0

    .line 185
    .line 186
    :goto_4
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;->getUnpaidPenalty()Ljava/lang/Long;

    .line 187
    .line 188
    .line 189
    move-result-object v2

    .line 190
    if-eqz v2, :cond_7

    .line 191
    .line 192
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 193
    .line 194
    .line 195
    move-result-wide v14

    .line 196
    goto :goto_5

    .line 197
    :cond_7
    const-wide/16 v14, 0x0

    .line 198
    .line 199
    :goto_5
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;->getUnpaidInterest()Ljava/lang/Long;

    .line 200
    .line 201
    .line 202
    move-result-object v2

    .line 203
    if-eqz v2, :cond_8

    .line 204
    .line 205
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 206
    .line 207
    .line 208
    move-result-wide v16

    .line 209
    move-wide/from16 v4, v16

    .line 210
    .line 211
    :goto_6
    const-wide/16 v16, 0x0

    .line 212
    .line 213
    goto :goto_7

    .line 214
    :cond_8
    const-wide/16 v4, 0x0

    .line 215
    .line 216
    goto :goto_6

    .line 217
    :goto_7
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/PalmPayCardBillData;->getUnpaidServiceFee()Ljava/lang/Long;

    .line 218
    .line 219
    .line 220
    move-result-object v1

    .line 221
    if-eqz v1, :cond_9

    .line 222
    .line 223
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 224
    .line 225
    .line 226
    move-result-wide v1

    .line 227
    goto :goto_8

    .line 228
    :cond_9
    move-wide/from16 v1, v16

    .line 229
    .line 230
    :goto_8
    iget-object v6, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->w0:Lxf/t;

    .line 231
    .line 232
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object v6

    .line 236
    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    check-cast v6, Landroid/widget/TextView;

    .line 240
    .line 241
    sget v8, LYa/g;->cs_oc_overdue_interest:I

    .line 242
    .line 243
    invoke-virtual {v9, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object v8

    .line 247
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 248
    .line 249
    .line 250
    iget-object v6, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->t0:Lxf/t;

    .line 251
    .line 252
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v6

    .line 256
    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    check-cast v6, Landroid/widget/LinearLayout;

    .line 260
    .line 261
    cmp-long v8, v4, v16

    .line 262
    .line 263
    if-lez v8, :cond_a

    .line 264
    .line 265
    move v8, v7

    .line 266
    goto :goto_9

    .line 267
    :cond_a
    const/4 v8, 0x0

    .line 268
    :goto_9
    invoke-static {v6, v8}, Loa/h;->s(Landroid/view/View;Z)V

    .line 269
    .line 270
    .line 271
    iget-object v6, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->r0:Lxf/t;

    .line 272
    .line 273
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object v6

    .line 277
    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 278
    .line 279
    .line 280
    check-cast v6, Landroid/widget/LinearLayout;

    .line 281
    .line 282
    cmp-long v8, v1, v16

    .line 283
    .line 284
    if-lez v8, :cond_b

    .line 285
    .line 286
    move v8, v7

    .line 287
    goto :goto_a

    .line 288
    :cond_b
    const/4 v8, 0x0

    .line 289
    :goto_a
    invoke-static {v6, v8}, Loa/h;->s(Landroid/view/View;Z)V

    .line 290
    .line 291
    .line 292
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 293
    .line 294
    .line 295
    move-result-object v6

    .line 296
    new-instance v8, Landroid/text/SpannableStringBuilder;

    .line 297
    .line 298
    invoke-static {v10, v11}, LPa/r0;->A(J)Ljava/lang/String;

    .line 299
    .line 300
    .line 301
    move-result-object v10

    .line 302
    invoke-direct {v8, v10}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 306
    .line 307
    .line 308
    iget-object v6, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->y0:Lxf/t;

    .line 309
    .line 310
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 311
    .line 312
    .line 313
    move-result-object v6

    .line 314
    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 315
    .line 316
    .line 317
    check-cast v6, Landroid/widget/TextView;

    .line 318
    .line 319
    invoke-static {v12, v13, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 320
    .line 321
    .line 322
    move-result-object v8

    .line 323
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 324
    .line 325
    .line 326
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->y()Landroid/widget/TextView;

    .line 327
    .line 328
    .line 329
    move-result-object v6

    .line 330
    invoke-static {v14, v15, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 331
    .line 332
    .line 333
    move-result-object v8

    .line 334
    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 335
    .line 336
    .line 337
    iget-object v6, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->s0:Lxf/t;

    .line 338
    .line 339
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 340
    .line 341
    .line 342
    move-result-object v6

    .line 343
    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 344
    .line 345
    .line 346
    check-cast v6, Landroid/widget/TextView;

    .line 347
    .line 348
    invoke-static {v4, v5, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object v4

    .line 352
    invoke-virtual {v6, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 353
    .line 354
    .line 355
    iget-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->q0:Lxf/t;

    .line 356
    .line 357
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 358
    .line 359
    .line 360
    move-result-object v4

    .line 361
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 362
    .line 363
    .line 364
    check-cast v4, Landroid/widget/TextView;

    .line 365
    .line 366
    invoke-static {v1, v2, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 367
    .line 368
    .line 369
    move-result-object v1

    .line 370
    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 371
    .line 372
    .line 373
    goto :goto_b

    .line 374
    :cond_c
    if-eqz v1, :cond_d

    .line 375
    .line 376
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 377
    .line 378
    .line 379
    move-result-object v6

    .line 380
    :cond_d
    const/4 v4, 0x0

    .line 381
    new-array v1, v4, [Ljava/lang/Object;

    .line 382
    .line 383
    invoke-static {v6, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 384
    .line 385
    .line 386
    :cond_e
    :goto_b
    return-void

    .line 387
    :pswitch_1
    move v4, v8

    .line 388
    const-wide/16 v16, 0x0

    .line 389
    .line 390
    move-object/from16 v5, p1

    .line 391
    .line 392
    check-cast v5, Lcom/transsnet/palmpay/credit/bean/resp/OcRepayBillResp;

    .line 393
    .line 394
    invoke-virtual {v9, v4}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 395
    .line 396
    .line 397
    if-eqz v5, :cond_3f

    .line 398
    .line 399
    invoke-virtual {v5}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 400
    .line 401
    .line 402
    move-result v4

    .line 403
    if-ne v4, v7, :cond_3f

    .line 404
    .line 405
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/OcRepayBillResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 406
    .line 407
    .line 408
    move-result-object v4

    .line 409
    if-eqz v4, :cond_3f

    .line 410
    .line 411
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/OcRepayBillResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 412
    .line 413
    .line 414
    move-result-object v4

    .line 415
    iput-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 416
    .line 417
    if-eqz v4, :cond_41

    .line 418
    .line 419
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->D()Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 420
    .line 421
    .line 422
    move-result-object v5

    .line 423
    invoke-static {v5}, LEb/a;->q(Lcom/transsnet/palmpay/credit/bean/WaiverInfo;)Z

    .line 424
    .line 425
    .line 426
    move-result v8

    .line 427
    if-eqz v8, :cond_11

    .line 428
    .line 429
    if-eqz v5, :cond_f

    .line 430
    .line 431
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getCurrentOutstandingAmount()Ljava/lang/Long;

    .line 432
    .line 433
    .line 434
    move-result-object v10

    .line 435
    if-eqz v10, :cond_f

    .line 436
    .line 437
    :goto_c
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 438
    .line 439
    .line 440
    move-result-wide v10

    .line 441
    goto :goto_d

    .line 442
    :cond_f
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getOutstandingAmount()Ljava/lang/Long;

    .line 443
    .line 444
    .line 445
    move-result-object v10

    .line 446
    if-eqz v10, :cond_10

    .line 447
    .line 448
    goto :goto_c

    .line 449
    :cond_10
    move-wide/from16 v10, v16

    .line 450
    .line 451
    goto :goto_d

    .line 452
    :cond_11
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getOutstandingAmount()Ljava/lang/Long;

    .line 453
    .line 454
    .line 455
    move-result-object v10

    .line 456
    if-eqz v10, :cond_10

    .line 457
    .line 458
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 459
    .line 460
    .line 461
    move-result-wide v10

    .line 462
    :goto_d
    iput-wide v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->f1:J

    .line 463
    .line 464
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 465
    .line 466
    .line 467
    move-result-object v12

    .line 468
    new-instance v13, Landroid/text/SpannableStringBuilder;

    .line 469
    .line 470
    invoke-static {v10, v11}, LPa/r0;->A(J)Ljava/lang/String;

    .line 471
    .line 472
    .line 473
    move-result-object v10

    .line 474
    invoke-direct {v13, v10}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 475
    .line 476
    .line 477
    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 478
    .line 479
    .line 480
    iget-object v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->y0:Lxf/t;

    .line 481
    .line 482
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 483
    .line 484
    .line 485
    move-result-object v10

    .line 486
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 487
    .line 488
    .line 489
    check-cast v10, Landroid/widget/TextView;

    .line 490
    .line 491
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getUnpaidPrincipal()Ljava/lang/Long;

    .line 492
    .line 493
    .line 494
    move-result-object v11

    .line 495
    if-eqz v11, :cond_12

    .line 496
    .line 497
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    .line 498
    .line 499
    .line 500
    move-result-wide v11

    .line 501
    goto :goto_e

    .line 502
    :cond_12
    move-wide/from16 v11, v16

    .line 503
    .line 504
    :goto_e
    invoke-static {v11, v12, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 505
    .line 506
    .line 507
    move-result-object v11

    .line 508
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 509
    .line 510
    .line 511
    iget-object v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->K0:Lxf/t;

    .line 512
    .line 513
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 514
    .line 515
    .line 516
    move-result-object v10

    .line 517
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 518
    .line 519
    .line 520
    check-cast v10, Landroid/widget/TextView;

    .line 521
    .line 522
    sget v11, LYa/g;->cs_oc_before_day:I

    .line 523
    .line 524
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getBeginTimeStamp()Ljava/lang/Long;

    .line 525
    .line 526
    .line 527
    move-result-object v12

    .line 528
    if-eqz v12, :cond_13

    .line 529
    .line 530
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 531
    .line 532
    .line 533
    move-result-wide v12

    .line 534
    goto :goto_f

    .line 535
    :cond_13
    move-wide/from16 v12, v16

    .line 536
    .line 537
    :goto_f
    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 538
    .line 539
    .line 540
    move-result-object v12

    .line 541
    const-string v13, "dd MMM"

    .line 542
    .line 543
    invoke-static {v12, v13}, LPa/r0;->X1(Ljava/lang/Long;Ljava/lang/String;)Ljava/lang/String;

    .line 544
    .line 545
    .line 546
    move-result-object v12

    .line 547
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getEndTimeStamp()Ljava/lang/Long;

    .line 548
    .line 549
    .line 550
    move-result-object v14

    .line 551
    if-eqz v14, :cond_14

    .line 552
    .line 553
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    .line 554
    .line 555
    .line 556
    move-result-wide v14

    .line 557
    goto :goto_10

    .line 558
    :cond_14
    move-wide/from16 v14, v16

    .line 559
    .line 560
    :goto_10
    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 561
    .line 562
    .line 563
    move-result-object v14

    .line 564
    invoke-static {v14, v13}, LPa/r0;->X1(Ljava/lang/Long;Ljava/lang/String;)Ljava/lang/String;

    .line 565
    .line 566
    .line 567
    move-result-object v13

    .line 568
    filled-new-array {v12, v13}, [Ljava/lang/Object;

    .line 569
    .line 570
    .line 571
    move-result-object v12

    .line 572
    invoke-virtual {v9, v11, v12}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 573
    .line 574
    .line 575
    move-result-object v11

    .line 576
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 577
    .line 578
    .line 579
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getStauts()Ljava/lang/Integer;

    .line 580
    .line 581
    .line 582
    move-result-object v10

    .line 583
    iget-object v11, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x0:Lxf/t;

    .line 584
    .line 585
    if-nez v10, :cond_15

    .line 586
    .line 587
    goto/16 :goto_13

    .line 588
    .line 589
    :cond_15
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 590
    .line 591
    .line 592
    move-result v10

    .line 593
    if-ne v10, v1, :cond_19

    .line 594
    .line 595
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getOverdueDays()Ljava/lang/Integer;

    .line 596
    .line 597
    .line 598
    move-result-object v10

    .line 599
    if-eqz v10, :cond_16

    .line 600
    .line 601
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 602
    .line 603
    .line 604
    move-result v10

    .line 605
    goto :goto_11

    .line 606
    :cond_16
    const/4 v10, 0x0

    .line 607
    :goto_11
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->y()Landroid/widget/TextView;

    .line 608
    .line 609
    .line 610
    move-result-object v12

    .line 611
    if-le v10, v7, :cond_17

    .line 612
    .line 613
    sget v13, LYa/g;->cs_oc_day_overdue:I

    .line 614
    .line 615
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 616
    .line 617
    .line 618
    move-result-object v10

    .line 619
    const-string v14, "s"

    .line 620
    .line 621
    filled-new-array {v10, v14}, [Ljava/lang/Object;

    .line 622
    .line 623
    .line 624
    move-result-object v10

    .line 625
    invoke-virtual {v9, v13, v10}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 626
    .line 627
    .line 628
    move-result-object v10

    .line 629
    goto :goto_12

    .line 630
    :cond_17
    sget v13, LYa/g;->cs_oc_day_overdue:I

    .line 631
    .line 632
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 633
    .line 634
    .line 635
    move-result-object v10

    .line 636
    const-string v14, ""

    .line 637
    .line 638
    filled-new-array {v10, v14}, [Ljava/lang/Object;

    .line 639
    .line 640
    .line 641
    move-result-object v10

    .line 642
    invoke-virtual {v9, v13, v10}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 643
    .line 644
    .line 645
    move-result-object v10

    .line 646
    :goto_12
    invoke-virtual {v12, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 647
    .line 648
    .line 649
    invoke-virtual {v11}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 650
    .line 651
    .line 652
    move-result-object v10

    .line 653
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 654
    .line 655
    .line 656
    check-cast v10, Landroid/widget/LinearLayout;

    .line 657
    .line 658
    const/4 v11, 0x0

    .line 659
    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    .line 660
    .line 661
    .line 662
    iget-wide v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->d1:J

    .line 663
    .line 664
    cmp-long v10, v10, v16

    .line 665
    .line 666
    iget-object v11, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->o:Lxf/t;

    .line 667
    .line 668
    iget-object v12, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v0:Lxf/t;

    .line 669
    .line 670
    if-nez v10, :cond_18

    .line 671
    .line 672
    iget-object v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->e1:Ljava/lang/String;

    .line 673
    .line 674
    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 675
    .line 676
    .line 677
    move-result v10

    .line 678
    if-eqz v10, :cond_18

    .line 679
    .line 680
    invoke-virtual {v12}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 681
    .line 682
    .line 683
    move-result-object v10

    .line 684
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 685
    .line 686
    .line 687
    check-cast v10, Landroid/widget/ImageView;

    .line 688
    .line 689
    const/4 v12, 0x0

    .line 690
    invoke-virtual {v10, v12}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 691
    .line 692
    .line 693
    invoke-virtual {v11}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 694
    .line 695
    .line 696
    move-result-object v10

    .line 697
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 698
    .line 699
    .line 700
    check-cast v10, Landroid/widget/TextView;

    .line 701
    .line 702
    invoke-virtual {v10, v12}, Landroid/view/View;->setVisibility(I)V

    .line 703
    .line 704
    .line 705
    goto :goto_14

    .line 706
    :cond_18
    invoke-virtual {v12}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 707
    .line 708
    .line 709
    move-result-object v10

    .line 710
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 711
    .line 712
    .line 713
    check-cast v10, Landroid/widget/ImageView;

    .line 714
    .line 715
    invoke-virtual {v10, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 716
    .line 717
    .line 718
    invoke-virtual {v11}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 719
    .line 720
    .line 721
    move-result-object v10

    .line 722
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 723
    .line 724
    .line 725
    check-cast v10, Landroid/widget/TextView;

    .line 726
    .line 727
    invoke-virtual {v10, v2}, Landroid/view/View;->setVisibility(I)V

    .line 728
    .line 729
    .line 730
    goto :goto_14

    .line 731
    :cond_19
    :goto_13
    invoke-virtual {v11}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 732
    .line 733
    .line 734
    move-result-object v10

    .line 735
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 736
    .line 737
    .line 738
    check-cast v10, Landroid/widget/LinearLayout;

    .line 739
    .line 740
    invoke-virtual {v10, v2}, Landroid/view/View;->setVisibility(I)V

    .line 741
    .line 742
    .line 743
    :goto_14
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getUnpaidPenalty()Ljava/lang/Long;

    .line 744
    .line 745
    .line 746
    move-result-object v10

    .line 747
    if-eqz v10, :cond_1a

    .line 748
    .line 749
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 750
    .line 751
    .line 752
    move-result-wide v10

    .line 753
    goto :goto_15

    .line 754
    :cond_1a
    move-wide/from16 v10, v16

    .line 755
    .line 756
    :goto_15
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getUnpaidInterest()Ljava/lang/Long;

    .line 757
    .line 758
    .line 759
    move-result-object v12

    .line 760
    if-eqz v12, :cond_1b

    .line 761
    .line 762
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 763
    .line 764
    .line 765
    move-result-wide v12

    .line 766
    goto :goto_16

    .line 767
    :cond_1b
    move-wide/from16 v12, v16

    .line 768
    .line 769
    :goto_16
    add-long/2addr v10, v12

    .line 770
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getUnpaidInstallmentServiceFee()Ljava/lang/Long;

    .line 771
    .line 772
    .line 773
    move-result-object v12

    .line 774
    if-eqz v12, :cond_1c

    .line 775
    .line 776
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 777
    .line 778
    .line 779
    move-result-wide v12

    .line 780
    goto :goto_17

    .line 781
    :cond_1c
    move-wide/from16 v12, v16

    .line 782
    .line 783
    :goto_17
    add-long/2addr v10, v12

    .line 784
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getUnpaidSpreadServiceFee()Ljava/lang/Long;

    .line 785
    .line 786
    .line 787
    move-result-object v12

    .line 788
    if-eqz v12, :cond_1d

    .line 789
    .line 790
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 791
    .line 792
    .line 793
    move-result-wide v12

    .line 794
    goto :goto_18

    .line 795
    :cond_1d
    move-wide/from16 v12, v16

    .line 796
    .line 797
    :goto_18
    add-long/2addr v10, v12

    .line 798
    cmp-long v12, v10, v16

    .line 799
    .line 800
    iget-object v13, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->t0:Lxf/t;

    .line 801
    .line 802
    if-lez v12, :cond_1e

    .line 803
    .line 804
    iget-object v14, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->s0:Lxf/t;

    .line 805
    .line 806
    invoke-virtual {v14}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 807
    .line 808
    .line 809
    move-result-object v14

    .line 810
    invoke-static {v14, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 811
    .line 812
    .line 813
    check-cast v14, Landroid/widget/TextView;

    .line 814
    .line 815
    invoke-static {v10, v11, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 816
    .line 817
    .line 818
    move-result-object v15

    .line 819
    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 820
    .line 821
    .line 822
    invoke-virtual {v13}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 823
    .line 824
    .line 825
    move-result-object v13

    .line 826
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 827
    .line 828
    .line 829
    check-cast v13, Landroid/widget/LinearLayout;

    .line 830
    .line 831
    const/4 v14, 0x0

    .line 832
    invoke-virtual {v13, v14}, Landroid/view/View;->setVisibility(I)V

    .line 833
    .line 834
    .line 835
    goto :goto_19

    .line 836
    :cond_1e
    invoke-virtual {v13}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 837
    .line 838
    .line 839
    move-result-object v13

    .line 840
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 841
    .line 842
    .line 843
    check-cast v13, Landroid/widget/LinearLayout;

    .line 844
    .line 845
    invoke-virtual {v13, v2}, Landroid/view/View;->setVisibility(I)V

    .line 846
    .line 847
    .line 848
    :goto_19
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionTag()Ljava/lang/Integer;

    .line 849
    .line 850
    .line 851
    move-result-object v13

    .line 852
    if-nez v13, :cond_1f

    .line 853
    .line 854
    goto/16 :goto_22

    .line 855
    .line 856
    :cond_1f
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 857
    .line 858
    .line 859
    move-result v13

    .line 860
    if-ne v13, v7, :cond_28

    .line 861
    .line 862
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->r()Landroid/widget/LinearLayout;

    .line 863
    .line 864
    .line 865
    move-result-object v13

    .line 866
    const/4 v14, 0x0

    .line 867
    invoke-virtual {v13, v14}, Landroid/view/View;->setVisibility(I)V

    .line 868
    .line 869
    .line 870
    iget-object v13, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->X:Lxf/t;

    .line 871
    .line 872
    invoke-virtual {v13}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 873
    .line 874
    .line 875
    move-result-object v13

    .line 876
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 877
    .line 878
    .line 879
    check-cast v13, Landroid/widget/TextView;

    .line 880
    .line 881
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 882
    .line 883
    .line 884
    move-result-object v14

    .line 885
    if-eqz v14, :cond_20

    .line 886
    .line 887
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    .line 888
    .line 889
    .line 890
    move-result-wide v14

    .line 891
    goto :goto_1a

    .line 892
    :cond_20
    move-wide/from16 v14, v16

    .line 893
    .line 894
    :goto_1a
    invoke-static {v14, v15, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 895
    .line 896
    .line 897
    move-result-object v14

    .line 898
    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 899
    .line 900
    .line 901
    iget-object v13, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->Q:Lxf/t;

    .line 902
    .line 903
    invoke-virtual {v13}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 904
    .line 905
    .line 906
    move-result-object v13

    .line 907
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 908
    .line 909
    .line 910
    check-cast v13, Landroid/widget/TextView;

    .line 911
    .line 912
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 913
    .line 914
    .line 915
    move-result-object v14

    .line 916
    if-eqz v14, :cond_21

    .line 917
    .line 918
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    .line 919
    .line 920
    .line 921
    move-result-wide v14

    .line 922
    goto :goto_1b

    .line 923
    :cond_21
    move-wide/from16 v14, v16

    .line 924
    .line 925
    :goto_1b
    invoke-static {v14, v15, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 926
    .line 927
    .line 928
    move-result-object v14

    .line 929
    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 930
    .line 931
    .line 932
    iget-object v13, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->C:Lxf/t;

    .line 933
    .line 934
    invoke-virtual {v13}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 935
    .line 936
    .line 937
    move-result-object v13

    .line 938
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 939
    .line 940
    .line 941
    check-cast v13, Landroid/widget/TextView;

    .line 942
    .line 943
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionDownPaymentPrincipal()Ljava/lang/Long;

    .line 944
    .line 945
    .line 946
    move-result-object v14

    .line 947
    if-eqz v14, :cond_22

    .line 948
    .line 949
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    .line 950
    .line 951
    .line 952
    move-result-wide v14

    .line 953
    goto :goto_1c

    .line 954
    :cond_22
    move-wide/from16 v14, v16

    .line 955
    .line 956
    :goto_1c
    invoke-static {v14, v15, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 957
    .line 958
    .line 959
    move-result-object v14

    .line 960
    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 961
    .line 962
    .line 963
    iget-object v13, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->B:Lxf/t;

    .line 964
    .line 965
    invoke-virtual {v13}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 966
    .line 967
    .line 968
    move-result-object v13

    .line 969
    invoke-static {v13, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 970
    .line 971
    .line 972
    check-cast v13, Landroid/widget/TextView;

    .line 973
    .line 974
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionServiceFee()Ljava/lang/Long;

    .line 975
    .line 976
    .line 977
    move-result-object v14

    .line 978
    if-eqz v14, :cond_23

    .line 979
    .line 980
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    .line 981
    .line 982
    .line 983
    move-result-wide v14

    .line 984
    goto :goto_1d

    .line 985
    :cond_23
    move-wide/from16 v14, v16

    .line 986
    .line 987
    :goto_1d
    invoke-static {v14, v15, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 988
    .line 989
    .line 990
    move-result-object v14

    .line 991
    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 992
    .line 993
    .line 994
    iget-object v13, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->H:Lxf/t;

    .line 995
    .line 996
    if-lez v12, :cond_24

    .line 997
    .line 998
    iget-object v12, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->L:Lxf/t;

    .line 999
    .line 1000
    invoke-virtual {v12}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1001
    .line 1002
    .line 1003
    move-result-object v12

    .line 1004
    invoke-static {v12, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1005
    .line 1006
    .line 1007
    check-cast v12, Landroid/widget/TextView;

    .line 1008
    .line 1009
    invoke-static {v10, v11, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 1010
    .line 1011
    .line 1012
    move-result-object v10

    .line 1013
    invoke-virtual {v12, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1014
    .line 1015
    .line 1016
    invoke-virtual {v13}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1017
    .line 1018
    .line 1019
    move-result-object v10

    .line 1020
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1021
    .line 1022
    .line 1023
    check-cast v10, Landroidx/constraintlayout/widget/Group;

    .line 1024
    .line 1025
    const/4 v14, 0x0

    .line 1026
    invoke-virtual {v10, v14}, Landroidx/constraintlayout/widget/Group;->setVisibility(I)V

    .line 1027
    .line 1028
    .line 1029
    goto :goto_1e

    .line 1030
    :cond_24
    invoke-virtual {v13}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1031
    .line 1032
    .line 1033
    move-result-object v10

    .line 1034
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1035
    .line 1036
    .line 1037
    check-cast v10, Landroidx/constraintlayout/widget/Group;

    .line 1038
    .line 1039
    invoke-virtual {v10, v2}, Landroidx/constraintlayout/widget/Group;->setVisibility(I)V

    .line 1040
    .line 1041
    .line 1042
    :goto_1e
    iget-object v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->A:Lxf/t;

    .line 1043
    .line 1044
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1045
    .line 1046
    .line 1047
    move-result-object v10

    .line 1048
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1049
    .line 1050
    .line 1051
    check-cast v10, Landroid/widget/TextView;

    .line 1052
    .line 1053
    sget v11, LYa/g;->cs_oc_mini_repayment_explain:I

    .line 1054
    .line 1055
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 1056
    .line 1057
    .line 1058
    move-result-object v12

    .line 1059
    if-eqz v12, :cond_25

    .line 1060
    .line 1061
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 1062
    .line 1063
    .line 1064
    move-result-wide v12

    .line 1065
    goto :goto_1f

    .line 1066
    :cond_25
    move-wide/from16 v12, v16

    .line 1067
    .line 1068
    :goto_1f
    invoke-static {v12, v13, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 1069
    .line 1070
    .line 1071
    move-result-object v12

    .line 1072
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionLastPrincipal()Ljava/lang/Long;

    .line 1073
    .line 1074
    .line 1075
    move-result-object v13

    .line 1076
    if-eqz v13, :cond_26

    .line 1077
    .line 1078
    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    .line 1079
    .line 1080
    .line 1081
    move-result-wide v13

    .line 1082
    goto :goto_20

    .line 1083
    :cond_26
    move-wide/from16 v13, v16

    .line 1084
    .line 1085
    :goto_20
    invoke-static {v13, v14, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 1086
    .line 1087
    .line 1088
    move-result-object v13

    .line 1089
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionLastRepaymentDateStamp()Ljava/lang/Long;

    .line 1090
    .line 1091
    .line 1092
    move-result-object v14

    .line 1093
    if-eqz v14, :cond_27

    .line 1094
    .line 1095
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    .line 1096
    .line 1097
    .line 1098
    move-result-wide v14

    .line 1099
    goto :goto_21

    .line 1100
    :cond_27
    move-wide/from16 v14, v16

    .line 1101
    .line 1102
    :goto_21
    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1103
    .line 1104
    .line 1105
    move-result-object v14

    .line 1106
    const-string v15, "MMM dd"

    .line 1107
    .line 1108
    invoke-static {v14, v15}, LPa/r0;->X1(Ljava/lang/Long;Ljava/lang/String;)Ljava/lang/String;

    .line 1109
    .line 1110
    .line 1111
    move-result-object v14

    .line 1112
    filled-new-array {v12, v13, v14}, [Ljava/lang/Object;

    .line 1113
    .line 1114
    .line 1115
    move-result-object v12

    .line 1116
    invoke-virtual {v9, v11, v12}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1117
    .line 1118
    .line 1119
    move-result-object v11

    .line 1120
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1121
    .line 1122
    .line 1123
    goto :goto_23

    .line 1124
    :cond_28
    :goto_22
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->r()Landroid/widget/LinearLayout;

    .line 1125
    .line 1126
    .line 1127
    move-result-object v10

    .line 1128
    invoke-virtual {v10, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1129
    .line 1130
    .line 1131
    iget-object v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g:Lxf/t;

    .line 1132
    .line 1133
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1134
    .line 1135
    .line 1136
    move-result-object v10

    .line 1137
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1138
    .line 1139
    .line 1140
    check-cast v10, Landroid/view/View;

    .line 1141
    .line 1142
    invoke-virtual {v10, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1143
    .line 1144
    .line 1145
    :goto_23
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getSpreadTag()Ljava/lang/Integer;

    .line 1146
    .line 1147
    .line 1148
    move-result-object v10

    .line 1149
    if-nez v10, :cond_29

    .line 1150
    .line 1151
    goto/16 :goto_26

    .line 1152
    .line 1153
    :cond_29
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 1154
    .line 1155
    .line 1156
    move-result v10

    .line 1157
    if-ne v10, v7, :cond_2c

    .line 1158
    .line 1159
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->A()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 1160
    .line 1161
    .line 1162
    move-result-object v10

    .line 1163
    const/4 v14, 0x0

    .line 1164
    invoke-virtual {v10, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1165
    .line 1166
    .line 1167
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->s()Landroid/widget/TextView;

    .line 1168
    .line 1169
    .line 1170
    move-result-object v10

    .line 1171
    invoke-virtual {v10, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1172
    .line 1173
    .line 1174
    iget-object v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v:Lxf/t;

    .line 1175
    .line 1176
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1177
    .line 1178
    .line 1179
    move-result-object v10

    .line 1180
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1181
    .line 1182
    .line 1183
    check-cast v10, Landroid/widget/TextView;

    .line 1184
    .line 1185
    const-string v11, "Pay in up to"

    .line 1186
    .line 1187
    invoke-static {v11}, LC0/G;->i(Ljava/lang/String;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1188
    .line 1189
    .line 1190
    move-result-object v11

    .line 1191
    sget v12, LL6/b;->ppColorTextPrimary:I

    .line 1192
    .line 1193
    invoke-virtual {v9, v12}, Landroid/content/Context;->getColor(I)I

    .line 1194
    .line 1195
    .line 1196
    move-result v12

    .line 1197
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1198
    .line 1199
    .line 1200
    move-result-object v11

    .line 1201
    iget-object v12, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 1202
    .line 1203
    if-eqz v12, :cond_2a

    .line 1204
    .line 1205
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getSpreadMaxTerm()Ljava/lang/Integer;

    .line 1206
    .line 1207
    .line 1208
    move-result-object v12

    .line 1209
    goto :goto_24

    .line 1210
    :cond_2a
    move-object v12, v6

    .line 1211
    :goto_24
    new-instance v13, Ljava/lang/StringBuilder;

    .line 1212
    .line 1213
    const-string v14, " "

    .line 1214
    .line 1215
    invoke-direct {v13, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1216
    .line 1217
    .line 1218
    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1219
    .line 1220
    .line 1221
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1222
    .line 1223
    .line 1224
    move-result-object v12

    .line 1225
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1226
    .line 1227
    .line 1228
    move-result-object v11

    .line 1229
    sget v12, LYa/b;->cs_oc_main_color:I

    .line 1230
    .line 1231
    invoke-virtual {v9, v12}, Landroid/content/Context;->getColor(I)I

    .line 1232
    .line 1233
    .line 1234
    move-result v12

    .line 1235
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1236
    .line 1237
    .line 1238
    move-result-object v11

    .line 1239
    const-string v12, " installment"

    .line 1240
    .line 1241
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1242
    .line 1243
    .line 1244
    move-result-object v11

    .line 1245
    sget v12, LL6/b;->ppColorTextPrimary:I

    .line 1246
    .line 1247
    invoke-virtual {v9, v12}, Landroid/content/Context;->getColor(I)I

    .line 1248
    .line 1249
    .line 1250
    move-result v12

    .line 1251
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1252
    .line 1253
    .line 1254
    move-result-object v11

    .line 1255
    invoke-virtual {v11}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 1256
    .line 1257
    .line 1258
    move-result-object v11

    .line 1259
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1260
    .line 1261
    .line 1262
    iget-object v10, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->t:Lxf/t;

    .line 1263
    .line 1264
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1265
    .line 1266
    .line 1267
    move-result-object v10

    .line 1268
    invoke-static {v10, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1269
    .line 1270
    .line 1271
    check-cast v10, Landroid/widget/TextView;

    .line 1272
    .line 1273
    const-string v11, "Only"

    .line 1274
    .line 1275
    invoke-static {v11}, LC0/G;->i(Ljava/lang/String;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1276
    .line 1277
    .line 1278
    move-result-object v11

    .line 1279
    sget v12, LL6/b;->ppColorTextPrimary:I

    .line 1280
    .line 1281
    invoke-virtual {v9, v12}, Landroid/content/Context;->getColor(I)I

    .line 1282
    .line 1283
    .line 1284
    move-result v12

    .line 1285
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1286
    .line 1287
    .line 1288
    move-result-object v11

    .line 1289
    iget-object v12, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 1290
    .line 1291
    if-eqz v12, :cond_2b

    .line 1292
    .line 1293
    invoke-virtual {v12}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getPredictEveryTermSpreadAmount()Ljava/lang/Long;

    .line 1294
    .line 1295
    .line 1296
    move-result-object v12

    .line 1297
    if-eqz v12, :cond_2b

    .line 1298
    .line 1299
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 1300
    .line 1301
    .line 1302
    move-result-wide v12

    .line 1303
    goto :goto_25

    .line 1304
    :cond_2b
    move-wide/from16 v12, v16

    .line 1305
    .line 1306
    :goto_25
    invoke-static {v12, v13, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 1307
    .line 1308
    .line 1309
    move-result-object v12

    .line 1310
    invoke-static {v14, v12, v11}, Lcom/horcrux/svg/d0;->j(Ljava/lang/String;Ljava/lang/String;Lcom/transsnet/palmpay/util/SpanUtils;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1311
    .line 1312
    .line 1313
    move-result-object v11

    .line 1314
    sget v12, LYa/b;->cs_oc_main_color:I

    .line 1315
    .line 1316
    invoke-virtual {v9, v12}, Landroid/content/Context;->getColor(I)I

    .line 1317
    .line 1318
    .line 1319
    move-result v12

    .line 1320
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1321
    .line 1322
    .line 1323
    move-result-object v11

    .line 1324
    const-string v12, " needed to repay in each period"

    .line 1325
    .line 1326
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1327
    .line 1328
    .line 1329
    move-result-object v11

    .line 1330
    sget v12, LL6/b;->ppColorTextPrimary:I

    .line 1331
    .line 1332
    invoke-virtual {v9, v12}, Landroid/content/Context;->getColor(I)I

    .line 1333
    .line 1334
    .line 1335
    move-result v12

    .line 1336
    invoke-virtual {v11, v12}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 1337
    .line 1338
    .line 1339
    move-result-object v11

    .line 1340
    invoke-virtual {v11}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 1341
    .line 1342
    .line 1343
    move-result-object v11

    .line 1344
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1345
    .line 1346
    .line 1347
    goto :goto_27

    .line 1348
    :cond_2c
    :goto_26
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->A()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 1349
    .line 1350
    .line 1351
    move-result-object v10

    .line 1352
    invoke-virtual {v10, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1353
    .line 1354
    .line 1355
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getSpreadPromptType()Ljava/lang/Integer;

    .line 1356
    .line 1357
    .line 1358
    move-result-object v10

    .line 1359
    if-eqz v10, :cond_2d

    .line 1360
    .line 1361
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->s()Landroid/widget/TextView;

    .line 1362
    .line 1363
    .line 1364
    move-result-object v10

    .line 1365
    const/4 v14, 0x0

    .line 1366
    invoke-virtual {v10, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1367
    .line 1368
    .line 1369
    goto :goto_27

    .line 1370
    :cond_2d
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->s()Landroid/widget/TextView;

    .line 1371
    .line 1372
    .line 1373
    move-result-object v10

    .line 1374
    invoke-virtual {v10, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1375
    .line 1376
    .line 1377
    :goto_27
    if-eqz v8, :cond_36

    .line 1378
    .line 1379
    if-eqz v5, :cond_36

    .line 1380
    .line 1381
    iput-boolean v7, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u1:Z

    .line 1382
    .line 1383
    iput-object v5, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->s1:Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 1384
    .line 1385
    iget-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->O0:Lxf/t;

    .line 1386
    .line 1387
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1388
    .line 1389
    .line 1390
    move-result-object v4

    .line 1391
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1392
    .line 1393
    .line 1394
    check-cast v4, Landroid/widget/ImageView;

    .line 1395
    .line 1396
    const/4 v14, 0x0

    .line 1397
    invoke-virtual {v4, v14}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 1398
    .line 1399
    .line 1400
    iget-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->P0:Lxf/t;

    .line 1401
    .line 1402
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1403
    .line 1404
    .line 1405
    move-result-object v4

    .line 1406
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1407
    .line 1408
    .line 1409
    check-cast v4, Landroid/view/View;

    .line 1410
    .line 1411
    invoke-virtual {v4, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1412
    .line 1413
    .line 1414
    iget-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->N0:Lxf/t;

    .line 1415
    .line 1416
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1417
    .line 1418
    .line 1419
    move-result-object v4

    .line 1420
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1421
    .line 1422
    .line 1423
    check-cast v4, Landroid/widget/LinearLayout;

    .line 1424
    .line 1425
    sget v8, Lcom/transsnet/palmpay/custom_view/p;->transparent:I

    .line 1426
    .line 1427
    invoke-virtual {v9, v8}, Landroid/content/Context;->getColor(I)I

    .line 1428
    .line 1429
    .line 1430
    move-result v8

    .line 1431
    invoke-virtual {v4, v8}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1432
    .line 1433
    .line 1434
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getBadgeText()Ljava/lang/String;

    .line 1435
    .line 1436
    .line 1437
    move-result-object v4

    .line 1438
    new-instance v8, Lub/W0;

    .line 1439
    .line 1440
    const/4 v14, 0x0

    .line 1441
    invoke-direct {v8, v9, v14}, Lub/W0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V

    .line 1442
    .line 1443
    .line 1444
    new-instance v10, Lub/T0;

    .line 1445
    .line 1446
    const/4 v11, 0x5

    .line 1447
    invoke-direct {v10, v9, v11}, Lub/T0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V

    .line 1448
    .line 1449
    .line 1450
    invoke-static {v4, v8, v10}, LEb/a;->g(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V

    .line 1451
    .line 1452
    .line 1453
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getSummaryText()Ljava/lang/String;

    .line 1454
    .line 1455
    .line 1456
    move-result-object v4

    .line 1457
    new-instance v8, Lub/W0;

    .line 1458
    .line 1459
    invoke-direct {v8, v9, v7}, Lub/W0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V

    .line 1460
    .line 1461
    .line 1462
    new-instance v10, Lub/T0;

    .line 1463
    .line 1464
    const/4 v11, 0x7

    .line 1465
    invoke-direct {v10, v9, v11}, Lub/T0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V

    .line 1466
    .line 1467
    .line 1468
    invoke-static {v4, v8, v10}, LEb/a;->g(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V

    .line 1469
    .line 1470
    .line 1471
    iget-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->T0:Lxf/t;

    .line 1472
    .line 1473
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1474
    .line 1475
    .line 1476
    move-result-object v4

    .line 1477
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1478
    .line 1479
    .line 1480
    check-cast v4, Landroid/widget/ImageView;

    .line 1481
    .line 1482
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getWaiverType()Ljava/lang/String;

    .line 1483
    .line 1484
    .line 1485
    move-result-object v8

    .line 1486
    const-string v10, "FULL"

    .line 1487
    .line 1488
    invoke-static {v8, v10}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1489
    .line 1490
    .line 1491
    move-result v8

    .line 1492
    if-eqz v8, :cond_2e

    .line 1493
    .line 1494
    sget v8, LYa/d;->cs_cl_loan_repayment_fully_date_bj_item1:I

    .line 1495
    .line 1496
    goto :goto_28

    .line 1497
    :cond_2e
    sget v8, LYa/d;->cs_cl_loan_repayment_fully_date_bj_item2:I

    .line 1498
    .line 1499
    :goto_28
    invoke-virtual {v4, v8}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 1500
    .line 1501
    .line 1502
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getAmountLabel()Ljava/lang/String;

    .line 1503
    .line 1504
    .line 1505
    move-result-object v4

    .line 1506
    new-instance v8, Lub/W0;

    .line 1507
    .line 1508
    invoke-direct {v8, v9, v1}, Lub/W0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V

    .line 1509
    .line 1510
    .line 1511
    new-instance v1, Lub/T0;

    .line 1512
    .line 1513
    invoke-direct {v1, v9, v2}, Lub/T0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V

    .line 1514
    .line 1515
    .line 1516
    invoke-static {v4, v8, v1}, LEb/a;->g(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V

    .line 1517
    .line 1518
    .line 1519
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getWaiverAmount()Ljava/lang/Long;

    .line 1520
    .line 1521
    .line 1522
    move-result-object v1

    .line 1523
    invoke-static {v1}, LEb/a;->l(Ljava/lang/Long;)Ljava/lang/String;

    .line 1524
    .line 1525
    .line 1526
    move-result-object v1

    .line 1527
    iget-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->V0:Lxf/t;

    .line 1528
    .line 1529
    if-eqz v1, :cond_30

    .line 1530
    .line 1531
    invoke-static {v1}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 1532
    .line 1533
    .line 1534
    move-result v8

    .line 1535
    if-eqz v8, :cond_2f

    .line 1536
    .line 1537
    goto :goto_29

    .line 1538
    :cond_2f
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1539
    .line 1540
    .line 1541
    move-result-object v4

    .line 1542
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1543
    .line 1544
    .line 1545
    check-cast v4, Landroid/view/View;

    .line 1546
    .line 1547
    const/4 v14, 0x0

    .line 1548
    invoke-virtual {v4, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1549
    .line 1550
    .line 1551
    iget-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->W0:Lxf/t;

    .line 1552
    .line 1553
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1554
    .line 1555
    .line 1556
    move-result-object v4

    .line 1557
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1558
    .line 1559
    .line 1560
    check-cast v4, Landroid/widget/TextView;

    .line 1561
    .line 1562
    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1563
    .line 1564
    .line 1565
    goto :goto_2a

    .line 1566
    :cond_30
    :goto_29
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1567
    .line 1568
    .line 1569
    move-result-object v1

    .line 1570
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1571
    .line 1572
    .line 1573
    check-cast v1, Landroid/view/View;

    .line 1574
    .line 1575
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1576
    .line 1577
    .line 1578
    :goto_2a
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v()Landroid/widget/Button;

    .line 1579
    .line 1580
    .line 1581
    move-result-object v1

    .line 1582
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getCtaText()Ljava/lang/String;

    .line 1583
    .line 1584
    .line 1585
    move-result-object v4

    .line 1586
    if-eqz v4, :cond_32

    .line 1587
    .line 1588
    invoke-static {v4}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 1589
    .line 1590
    .line 1591
    move-result v8

    .line 1592
    if-nez v8, :cond_31

    .line 1593
    .line 1594
    goto :goto_2b

    .line 1595
    :cond_31
    move-object v4, v6

    .line 1596
    :goto_2b
    if-eqz v4, :cond_32

    .line 1597
    .line 1598
    goto :goto_2c

    .line 1599
    :cond_32
    sget v4, LYa/g;->cs_cl_waiver_activate_default:I

    .line 1600
    .line 1601
    invoke-virtual {v9, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1602
    .line 1603
    .line 1604
    move-result-object v4

    .line 1605
    const-string v8, "getString(...)"

    .line 1606
    .line 1607
    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1608
    .line 1609
    .line 1610
    :goto_2c
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1611
    .line 1612
    .line 1613
    iget-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->d:Lxf/t;

    .line 1614
    .line 1615
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1616
    .line 1617
    .line 1618
    move-result-object v1

    .line 1619
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1620
    .line 1621
    .line 1622
    check-cast v1, Landroid/widget/TextView;

    .line 1623
    .line 1624
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1625
    .line 1626
    .line 1627
    iget-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->f:Lxf/t;

    .line 1628
    .line 1629
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1630
    .line 1631
    .line 1632
    move-result-object v1

    .line 1633
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1634
    .line 1635
    .line 1636
    check-cast v1, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 1637
    .line 1638
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1639
    .line 1640
    .line 1641
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->r()Landroid/widget/LinearLayout;

    .line 1642
    .line 1643
    .line 1644
    move-result-object v1

    .line 1645
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1646
    .line 1647
    .line 1648
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->A()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 1649
    .line 1650
    .line 1651
    move-result-object v1

    .line 1652
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1653
    .line 1654
    .line 1655
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->s()Landroid/widget/TextView;

    .line 1656
    .line 1657
    .line 1658
    move-result-object v1

    .line 1659
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1660
    .line 1661
    .line 1662
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getWaiverType()Ljava/lang/String;

    .line 1663
    .line 1664
    .line 1665
    move-result-object v1

    .line 1666
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1667
    .line 1668
    .line 1669
    move-result v1

    .line 1670
    if-eqz v1, :cond_33

    .line 1671
    .line 1672
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u()Landroid/widget/TextView;

    .line 1673
    .line 1674
    .line 1675
    move-result-object v1

    .line 1676
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1677
    .line 1678
    .line 1679
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->z()Landroid/widget/TextView;

    .line 1680
    .line 1681
    .line 1682
    move-result-object v1

    .line 1683
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1684
    .line 1685
    .line 1686
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->q()Landroid/widget/ImageView;

    .line 1687
    .line 1688
    .line 1689
    move-result-object v1

    .line 1690
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 1691
    .line 1692
    .line 1693
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 1694
    .line 1695
    .line 1696
    move-result-object v1

    .line 1697
    const/4 v14, 0x0

    .line 1698
    invoke-virtual {v1, v14}, Landroid/view/View;->setFocusable(Z)V

    .line 1699
    .line 1700
    .line 1701
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 1702
    .line 1703
    .line 1704
    move-result-object v1

    .line 1705
    invoke-virtual {v1, v14}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 1706
    .line 1707
    .line 1708
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->t()Landroid/widget/TextView;

    .line 1709
    .line 1710
    .line 1711
    move-result-object v1

    .line 1712
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1713
    .line 1714
    .line 1715
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->p()V

    .line 1716
    .line 1717
    .line 1718
    goto :goto_2d

    .line 1719
    :cond_33
    const/4 v14, 0x0

    .line 1720
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u()Landroid/widget/TextView;

    .line 1721
    .line 1722
    .line 1723
    move-result-object v1

    .line 1724
    invoke-virtual {v1, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1725
    .line 1726
    .line 1727
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->z()Landroid/widget/TextView;

    .line 1728
    .line 1729
    .line 1730
    move-result-object v1

    .line 1731
    invoke-virtual {v1, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1732
    .line 1733
    .line 1734
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->q()Landroid/widget/ImageView;

    .line 1735
    .line 1736
    .line 1737
    move-result-object v1

    .line 1738
    invoke-virtual {v1, v14}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 1739
    .line 1740
    .line 1741
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 1742
    .line 1743
    .line 1744
    move-result-object v1

    .line 1745
    invoke-virtual {v1, v7}, Landroid/view/View;->setFocusable(Z)V

    .line 1746
    .line 1747
    .line 1748
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 1749
    .line 1750
    .line 1751
    move-result-object v1

    .line 1752
    invoke-virtual {v1, v7}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 1753
    .line 1754
    .line 1755
    :goto_2d
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getValidUntil()Ljava/lang/Long;

    .line 1756
    .line 1757
    .line 1758
    move-result-object v1

    .line 1759
    iget-object v4, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->X0:Lxf/t;

    .line 1760
    .line 1761
    if-eqz v1, :cond_35

    .line 1762
    .line 1763
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1764
    .line 1765
    .line 1766
    move-result-object v2

    .line 1767
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1768
    .line 1769
    .line 1770
    check-cast v2, Landroid/widget/LinearLayout;

    .line 1771
    .line 1772
    const/4 v14, 0x0

    .line 1773
    invoke-virtual {v2, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1774
    .line 1775
    .line 1776
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 1777
    .line 1778
    .line 1779
    move-result-wide v2

    .line 1780
    invoke-virtual {v9, v2, v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->C(J)V

    .line 1781
    .line 1782
    .line 1783
    iget-object v2, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->t1:LEb/n;

    .line 1784
    .line 1785
    if-eqz v2, :cond_34

    .line 1786
    .line 1787
    invoke-virtual {v2}, LEb/n;->b()V

    .line 1788
    .line 1789
    .line 1790
    :cond_34
    iput-object v6, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->t1:LEb/n;

    .line 1791
    .line 1792
    new-instance v2, LEb/n;

    .line 1793
    .line 1794
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 1795
    .line 1796
    .line 1797
    move-result-wide v3

    .line 1798
    new-instance v5, LHb/L;

    .line 1799
    .line 1800
    const/16 v6, 0x1d

    .line 1801
    .line 1802
    invoke-direct {v5, v6, v9, v1}, LHb/L;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 1803
    .line 1804
    .line 1805
    new-instance v1, Lub/T0;

    .line 1806
    .line 1807
    const/16 v6, 0x9

    .line 1808
    .line 1809
    invoke-direct {v1, v9, v6}, Lub/T0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V

    .line 1810
    .line 1811
    .line 1812
    invoke-direct {v2, v3, v4, v5, v1}, LEb/n;-><init>(JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 1813
    .line 1814
    .line 1815
    invoke-virtual {v2}, LEb/n;->a()V

    .line 1816
    .line 1817
    .line 1818
    iput-object v2, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->t1:LEb/n;

    .line 1819
    .line 1820
    goto/16 :goto_35

    .line 1821
    .line 1822
    :cond_35
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 1823
    .line 1824
    .line 1825
    move-result-object v1

    .line 1826
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1827
    .line 1828
    .line 1829
    check-cast v1, Landroid/widget/LinearLayout;

    .line 1830
    .line 1831
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1832
    .line 1833
    .line 1834
    goto/16 :goto_35

    .line 1835
    .line 1836
    :cond_36
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->B()V

    .line 1837
    .line 1838
    .line 1839
    iget-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 1840
    .line 1841
    if-eqz v1, :cond_37

    .line 1842
    .line 1843
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getWaiverInfo()Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 1844
    .line 1845
    .line 1846
    move-result-object v6

    .line 1847
    :cond_37
    if-nez v6, :cond_39

    .line 1848
    .line 1849
    iget-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->r1:Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 1850
    .line 1851
    if-eqz v1, :cond_38

    .line 1852
    .line 1853
    goto :goto_2e

    .line 1854
    :cond_38
    const/4 v7, 0x0

    .line 1855
    :cond_39
    :goto_2e
    iget-boolean v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u1:Z

    .line 1856
    .line 1857
    if-nez v1, :cond_3b

    .line 1858
    .line 1859
    if-nez v7, :cond_3b

    .line 1860
    .line 1861
    iget-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->e1:Ljava/lang/String;

    .line 1862
    .line 1863
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1864
    .line 1865
    .line 1866
    move-result v1

    .line 1867
    if-eqz v1, :cond_3c

    .line 1868
    .line 1869
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getOutstandingAmount()Ljava/lang/Long;

    .line 1870
    .line 1871
    .line 1872
    move-result-object v1

    .line 1873
    if-eqz v1, :cond_3a

    .line 1874
    .line 1875
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 1876
    .line 1877
    .line 1878
    move-result-wide v5

    .line 1879
    goto :goto_2f

    .line 1880
    :cond_3a
    move-wide/from16 v5, v16

    .line 1881
    .line 1882
    :goto_2f
    const-wide/16 v7, 0x2710

    .line 1883
    .line 1884
    cmp-long v1, v5, v7

    .line 1885
    .line 1886
    if-lez v1, :cond_3c

    .line 1887
    .line 1888
    iget-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->l1:Ljava/lang/String;

    .line 1889
    .line 1890
    const-string v3, "oc_repay_all"

    .line 1891
    .line 1892
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1893
    .line 1894
    .line 1895
    move-result v1

    .line 1896
    if-eqz v1, :cond_3b

    .line 1897
    .line 1898
    goto :goto_30

    .line 1899
    :cond_3b
    const/4 v14, 0x0

    .line 1900
    goto :goto_32

    .line 1901
    :cond_3c
    :goto_30
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getOutstandingAmount()Ljava/lang/Long;

    .line 1902
    .line 1903
    .line 1904
    move-result-object v1

    .line 1905
    if-eqz v1, :cond_3d

    .line 1906
    .line 1907
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 1908
    .line 1909
    .line 1910
    move-result-wide v5

    .line 1911
    goto :goto_31

    .line 1912
    :cond_3d
    move-wide/from16 v5, v16

    .line 1913
    .line 1914
    :goto_31
    cmp-long v1, v5, v16

    .line 1915
    .line 1916
    if-lez v1, :cond_3b

    .line 1917
    .line 1918
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u()Landroid/widget/TextView;

    .line 1919
    .line 1920
    .line 1921
    move-result-object v1

    .line 1922
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1923
    .line 1924
    .line 1925
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->z()Landroid/widget/TextView;

    .line 1926
    .line 1927
    .line 1928
    move-result-object v1

    .line 1929
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1930
    .line 1931
    .line 1932
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->q()Landroid/widget/ImageView;

    .line 1933
    .line 1934
    .line 1935
    move-result-object v1

    .line 1936
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 1937
    .line 1938
    .line 1939
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 1940
    .line 1941
    .line 1942
    move-result-object v1

    .line 1943
    const/4 v14, 0x0

    .line 1944
    invoke-virtual {v1, v14}, Landroid/view/View;->setFocusable(Z)V

    .line 1945
    .line 1946
    .line 1947
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 1948
    .line 1949
    .line 1950
    move-result-object v1

    .line 1951
    invoke-virtual {v1, v14}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 1952
    .line 1953
    .line 1954
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->r()Landroid/widget/LinearLayout;

    .line 1955
    .line 1956
    .line 1957
    move-result-object v1

    .line 1958
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1959
    .line 1960
    .line 1961
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->A()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 1962
    .line 1963
    .line 1964
    move-result-object v1

    .line 1965
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1966
    .line 1967
    .line 1968
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->n()V

    .line 1969
    .line 1970
    .line 1971
    goto :goto_33

    .line 1972
    :goto_32
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u()Landroid/widget/TextView;

    .line 1973
    .line 1974
    .line 1975
    move-result-object v1

    .line 1976
    invoke-virtual {v1, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1977
    .line 1978
    .line 1979
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->z()Landroid/widget/TextView;

    .line 1980
    .line 1981
    .line 1982
    move-result-object v1

    .line 1983
    invoke-virtual {v1, v14}, Landroid/view/View;->setVisibility(I)V

    .line 1984
    .line 1985
    .line 1986
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->q()Landroid/widget/ImageView;

    .line 1987
    .line 1988
    .line 1989
    move-result-object v1

    .line 1990
    invoke-virtual {v1, v14}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 1991
    .line 1992
    .line 1993
    :goto_33
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getOutstandingAmount()Ljava/lang/Long;

    .line 1994
    .line 1995
    .line 1996
    move-result-object v1

    .line 1997
    if-eqz v1, :cond_3e

    .line 1998
    .line 1999
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 2000
    .line 2001
    .line 2002
    move-result-wide v1

    .line 2003
    goto :goto_34

    .line 2004
    :cond_3e
    move-wide/from16 v1, v16

    .line 2005
    .line 2006
    :goto_34
    cmp-long v1, v1, v16

    .line 2007
    .line 2008
    if-nez v1, :cond_41

    .line 2009
    .line 2010
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->o()V

    .line 2011
    .line 2012
    .line 2013
    goto :goto_35

    .line 2014
    :cond_3f
    if-eqz v5, :cond_40

    .line 2015
    .line 2016
    invoke-virtual {v5}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 2017
    .line 2018
    .line 2019
    move-result-object v6

    .line 2020
    :cond_40
    const/4 v14, 0x0

    .line 2021
    new-array v1, v14, [Ljava/lang/Object;

    .line 2022
    .line 2023
    invoke-static {v6, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 2024
    .line 2025
    .line 2026
    :cond_41
    :goto_35
    return-void

    .line 2027
    :pswitch_2
    move-object/from16 v1, p1

    .line 2028
    .line 2029
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/OcRepayExitResp;

    .line 2030
    .line 2031
    if-eqz v1, :cond_42

    .line 2032
    .line 2033
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 2034
    .line 2035
    .line 2036
    move-result v2

    .line 2037
    if-ne v2, v7, :cond_42

    .line 2038
    .line 2039
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRepayExitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRepayExitData;

    .line 2040
    .line 2041
    .line 2042
    move-result-object v1

    .line 2043
    iput-object v1, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->p1:Lcom/transsnet/palmpay/credit/bean/resp/OcRepayExitData;

    .line 2044
    .line 2045
    :cond_42
    return-void

    .line 2046
    :pswitch_3
    move-object/from16 v1, p1

    .line 2047
    .line 2048
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderRsp;

    .line 2049
    .line 2050
    if-eqz v1, :cond_45

    .line 2051
    .line 2052
    const/4 v14, 0x0

    .line 2053
    invoke-virtual {v9, v14}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 2054
    .line 2055
    .line 2056
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 2057
    .line 2058
    .line 2059
    move-result v2

    .line 2060
    if-eqz v2, :cond_44

    .line 2061
    .line 2062
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 2063
    .line 2064
    .line 2065
    move-result-object v2

    .line 2066
    const-string v3, "/credit_score/oc_repay_preview_activity"

    .line 2067
    .line 2068
    invoke-virtual {v2, v3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 2069
    .line 2070
    .line 2071
    move-result-object v2

    .line 2072
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 2073
    .line 2074
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 2075
    .line 2076
    .line 2077
    move-result-object v3

    .line 2078
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/AmountEditText;->getLong()J

    .line 2079
    .line 2080
    .line 2081
    move-result-wide v3

    .line 2082
    const-string v5, "ok_card_repay_amount"

    .line 2083
    .line 2084
    invoke-virtual {v2, v5, v3, v4}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 2085
    .line 2086
    .line 2087
    move-result-object v2

    .line 2088
    iget-object v3, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->c1:Ljava/lang/String;

    .line 2089
    .line 2090
    const-string v4, "ok_card_repay_card_no"

    .line 2091
    .line 2092
    invoke-virtual {v2, v4, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 2093
    .line 2094
    .line 2095
    move-result-object v2

    .line 2096
    iget-wide v3, v9, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->d1:J

    .line 2097
    .line 2098
    const-string v5, "ok_card_repay_bill_id"

    .line 2099
    .line 2100
    invoke-virtual {v2, v5, v3, v4}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 2101
    .line 2102
    .line 2103
    move-result-object v2

    .line 2104
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderRsp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOrderData;

    .line 2105
    .line 2106
    .line 2107
    move-result-object v1

    .line 2108
    if-eqz v1, :cond_43

    .line 2109
    .line 2110
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderData;->getOrderId()Ljava/lang/String;

    .line 2111
    .line 2112
    .line 2113
    move-result-object v6

    .line 2114
    :cond_43
    const-string v1, "ok_card_repay_order_no"

    .line 2115
    .line 2116
    invoke-virtual {v2, v1, v6}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 2117
    .line 2118
    .line 2119
    move-result-object v1

    .line 2120
    invoke-virtual {v1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 2121
    .line 2122
    .line 2123
    goto :goto_36

    .line 2124
    :cond_44
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 2125
    .line 2126
    .line 2127
    move-result-object v1

    .line 2128
    const/4 v14, 0x0

    .line 2129
    new-array v2, v14, [Ljava/lang/Object;

    .line 2130
    .line 2131
    invoke-static {v1, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 2132
    .line 2133
    .line 2134
    :cond_45
    :goto_36
    return-void

    .line 2135
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
