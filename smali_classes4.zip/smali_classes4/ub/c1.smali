.class public final Lub/c1;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/c1;->f:I

    iput-object p1, p0, Lub/c1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/c1;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lub/c1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_0
    const-string v0, "d"

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lub/c1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    nop

    .line 29
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget v0, p0, Lub/c1;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/c1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 10
    .line 11
    .line 12
    new-array v0, v1, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    iget-object v0, p0, Lub/c1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 22
    .line 23
    .line 24
    new-array v0, v1, [Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 11

    .line 1
    iget v0, p0, Lub/c1;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillResp;

    .line 7
    .line 8
    iget-object v0, p0, Lub/c1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 12
    .line 13
    .line 14
    if-eqz p1, :cond_d

    .line 15
    .line 16
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    const/4 v3, 0x1

    .line 21
    if-ne v2, v3, :cond_d

    .line 22
    .line 23
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    if-eqz v2, :cond_d

    .line 28
    .line 29
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iput-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 34
    .line 35
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->i:Lxf/t;

    .line 36
    .line 37
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    const-string v2, "getValue(...)"

    .line 42
    .line 43
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    check-cast p1, Landroid/widget/TextView;

    .line 47
    .line 48
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 49
    .line 50
    const-wide/16 v5, 0x0

    .line 51
    .line 52
    if-eqz v4, :cond_0

    .line 53
    .line 54
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionDownPaymentPrincipal()Ljava/lang/Long;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    if-eqz v4, :cond_0

    .line 59
    .line 60
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 61
    .line 62
    .line 63
    move-result-wide v7

    .line 64
    goto :goto_0

    .line 65
    :cond_0
    move-wide v7, v5

    .line 66
    :goto_0
    invoke-static {v7, v8, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 71
    .line 72
    .line 73
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->o:Lxf/t;

    .line 74
    .line 75
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    check-cast p1, Landroid/widget/TextView;

    .line 83
    .line 84
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 85
    .line 86
    if-eqz v4, :cond_1

    .line 87
    .line 88
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 89
    .line 90
    .line 91
    move-result-object v4

    .line 92
    if-eqz v4, :cond_1

    .line 93
    .line 94
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 95
    .line 96
    .line 97
    move-result-wide v7

    .line 98
    goto :goto_1

    .line 99
    :cond_1
    move-wide v7, v5

    .line 100
    :goto_1
    invoke-static {v7, v8}, LPa/r0;->A(J)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 105
    .line 106
    .line 107
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->g:Lxf/t;

    .line 108
    .line 109
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    check-cast p1, Landroid/widget/TextView;

    .line 117
    .line 118
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 119
    .line 120
    if-eqz v4, :cond_2

    .line 121
    .line 122
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getPenalty()Ljava/lang/Long;

    .line 123
    .line 124
    .line 125
    move-result-object v4

    .line 126
    if-eqz v4, :cond_2

    .line 127
    .line 128
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 129
    .line 130
    .line 131
    move-result-wide v7

    .line 132
    goto :goto_2

    .line 133
    :cond_2
    move-wide v7, v5

    .line 134
    :goto_2
    invoke-static {v7, v8, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v4

    .line 138
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 139
    .line 140
    .line 141
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->f:Lxf/t;

    .line 142
    .line 143
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object p1

    .line 147
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    check-cast p1, Landroid/widget/TextView;

    .line 151
    .line 152
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 153
    .line 154
    if-eqz v4, :cond_3

    .line 155
    .line 156
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionServiceFee()Ljava/lang/Long;

    .line 157
    .line 158
    .line 159
    move-result-object v4

    .line 160
    if-eqz v4, :cond_3

    .line 161
    .line 162
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 163
    .line 164
    .line 165
    move-result-wide v7

    .line 166
    goto :goto_3

    .line 167
    :cond_3
    move-wide v7, v5

    .line 168
    :goto_3
    invoke-static {v7, v8, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v4

    .line 172
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 173
    .line 174
    .line 175
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->d:Lxf/t;

    .line 176
    .line 177
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v4

    .line 181
    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    check-cast v4, Landroid/widget/Button;

    .line 185
    .line 186
    iget-object v7, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 187
    .line 188
    if-eqz v7, :cond_5

    .line 189
    .line 190
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionTag()Ljava/lang/Integer;

    .line 191
    .line 192
    .line 193
    move-result-object v7

    .line 194
    if-nez v7, :cond_4

    .line 195
    .line 196
    goto :goto_4

    .line 197
    :cond_4
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 198
    .line 199
    .line 200
    move-result v7

    .line 201
    if-ne v7, v3, :cond_5

    .line 202
    .line 203
    move v7, v3

    .line 204
    goto :goto_5

    .line 205
    :cond_5
    :goto_4
    move v7, v1

    .line 206
    :goto_5
    invoke-virtual {v4, v7}, Landroid/view/View;->setEnabled(Z)V

    .line 207
    .line 208
    .line 209
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object p1

    .line 213
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 214
    .line 215
    .line 216
    check-cast p1, Landroid/widget/Button;

    .line 217
    .line 218
    sget v4, LYa/g;->cs_pay_extension_fee:I

    .line 219
    .line 220
    iget-object v7, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 221
    .line 222
    if-eqz v7, :cond_6

    .line 223
    .line 224
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 225
    .line 226
    .line 227
    move-result-object v7

    .line 228
    if-eqz v7, :cond_6

    .line 229
    .line 230
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    .line 231
    .line 232
    .line 233
    move-result-wide v7

    .line 234
    goto :goto_6

    .line 235
    :cond_6
    move-wide v7, v5

    .line 236
    :goto_6
    invoke-static {v7, v8, v1}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v7

    .line 240
    filled-new-array {v7}, [Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v7

    .line 244
    invoke-virtual {v0, v4, v7}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v4

    .line 248
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 249
    .line 250
    .line 251
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->e:Lxf/t;

    .line 252
    .line 253
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object p1

    .line 257
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    check-cast p1, Landroid/widget/TextView;

    .line 261
    .line 262
    sget v4, LYa/g;->cs_oc_mini_repayment_explain:I

    .line 263
    .line 264
    iget-object v7, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 265
    .line 266
    if-eqz v7, :cond_7

    .line 267
    .line 268
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 269
    .line 270
    .line 271
    move-result-object v7

    .line 272
    if-eqz v7, :cond_7

    .line 273
    .line 274
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    .line 275
    .line 276
    .line 277
    move-result-wide v7

    .line 278
    goto :goto_7

    .line 279
    :cond_7
    move-wide v7, v5

    .line 280
    :goto_7
    invoke-static {v7, v8, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v7

    .line 284
    iget-object v8, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 285
    .line 286
    if-eqz v8, :cond_8

    .line 287
    .line 288
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionLastPrincipal()Ljava/lang/Long;

    .line 289
    .line 290
    .line 291
    move-result-object v8

    .line 292
    if-eqz v8, :cond_8

    .line 293
    .line 294
    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    .line 295
    .line 296
    .line 297
    move-result-wide v8

    .line 298
    goto :goto_8

    .line 299
    :cond_8
    move-wide v8, v5

    .line 300
    :goto_8
    invoke-static {v8, v9, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 301
    .line 302
    .line 303
    move-result-object v8

    .line 304
    iget-object v9, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 305
    .line 306
    if-eqz v9, :cond_9

    .line 307
    .line 308
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionLastRepaymentDateStamp()Ljava/lang/Long;

    .line 309
    .line 310
    .line 311
    move-result-object v9

    .line 312
    if-eqz v9, :cond_9

    .line 313
    .line 314
    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    .line 315
    .line 316
    .line 317
    move-result-wide v9

    .line 318
    goto :goto_9

    .line 319
    :cond_9
    move-wide v9, v5

    .line 320
    :goto_9
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 321
    .line 322
    .line 323
    move-result-object v9

    .line 324
    const-string v10, "MMM dd"

    .line 325
    .line 326
    invoke-static {v9, v10}, LPa/r0;->X1(Ljava/lang/Long;Ljava/lang/String;)Ljava/lang/String;

    .line 327
    .line 328
    .line 329
    move-result-object v9

    .line 330
    filled-new-array {v7, v8, v9}, [Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object v7

    .line 334
    invoke-virtual {v0, v4, v7}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object v4

    .line 338
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 339
    .line 340
    .line 341
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 342
    .line 343
    if-eqz p1, :cond_f

    .line 344
    .line 345
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getStampDutyPromptInfo()Lcom/transsnet/palmpay/credit/bean/resp/StampDutyPromptInfo;

    .line 346
    .line 347
    .line 348
    move-result-object p1

    .line 349
    if-eqz p1, :cond_f

    .line 350
    .line 351
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 352
    .line 353
    if-eqz v4, :cond_a

    .line 354
    .line 355
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 356
    .line 357
    .line 358
    move-result-object v4

    .line 359
    if-eqz v4, :cond_a

    .line 360
    .line 361
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 362
    .line 363
    .line 364
    move-result-wide v5

    .line 365
    :cond_a
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/StampDutyPromptInfo;->getThresholdAmount()Ljava/lang/Long;

    .line 366
    .line 367
    .line 368
    move-result-object v4

    .line 369
    if-eqz v4, :cond_b

    .line 370
    .line 371
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 372
    .line 373
    .line 374
    move-result-wide v7

    .line 375
    goto :goto_a

    .line 376
    :cond_b
    const-wide/32 v7, 0xf4240

    .line 377
    .line 378
    .line 379
    :goto_a
    cmp-long v4, v5, v7

    .line 380
    .line 381
    if-ltz v4, :cond_c

    .line 382
    .line 383
    move v1, v3

    .line 384
    :cond_c
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->v:Lxf/t;

    .line 385
    .line 386
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 387
    .line 388
    .line 389
    move-result-object v0

    .line 390
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 391
    .line 392
    .line 393
    check-cast v0, Lcom/transsnet/palmpay/credit/view/RepayStampDutyView;

    .line 394
    .line 395
    invoke-virtual {v0, v1, p1}, Lcom/transsnet/palmpay/credit/view/RepayStampDutyView;->d(ZLcom/transsnet/palmpay/credit/bean/resp/StampDutyPromptInfo;)V

    .line 396
    .line 397
    .line 398
    goto :goto_c

    .line 399
    :cond_d
    if-eqz p1, :cond_e

    .line 400
    .line 401
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object p1

    .line 405
    goto :goto_b

    .line 406
    :cond_e
    const/4 p1, 0x0

    .line 407
    :goto_b
    new-array v0, v1, [Ljava/lang/Object;

    .line 408
    .line 409
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 410
    .line 411
    .line 412
    :cond_f
    :goto_c
    return-void

    .line 413
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderRsp;

    .line 414
    .line 415
    if-eqz p1, :cond_15

    .line 416
    .line 417
    iget-object v0, p0, Lub/c1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    .line 418
    .line 419
    const/4 v1, 0x0

    .line 420
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 421
    .line 422
    .line 423
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 424
    .line 425
    .line 426
    move-result v2

    .line 427
    if-eqz v2, :cond_14

    .line 428
    .line 429
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 430
    .line 431
    .line 432
    move-result-object v1

    .line 433
    const-string v2, "/credit_score/oc_repay_extend_preview_activity"

    .line 434
    .line 435
    invoke-virtual {v1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 436
    .line 437
    .line 438
    move-result-object v1

    .line 439
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 440
    .line 441
    const-wide/16 v3, 0x0

    .line 442
    .line 443
    if-eqz v2, :cond_10

    .line 444
    .line 445
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 446
    .line 447
    .line 448
    move-result-object v2

    .line 449
    if-eqz v2, :cond_10

    .line 450
    .line 451
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 452
    .line 453
    .line 454
    move-result-wide v5

    .line 455
    goto :goto_d

    .line 456
    :cond_10
    move-wide v5, v3

    .line 457
    :goto_d
    const-string v2, "ok_card_repay_amount"

    .line 458
    .line 459
    invoke-virtual {v1, v2, v5, v6}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 460
    .line 461
    .line 462
    move-result-object v1

    .line 463
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 464
    .line 465
    const/4 v5, 0x0

    .line 466
    if-eqz v2, :cond_11

    .line 467
    .line 468
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getCardNo()Ljava/lang/String;

    .line 469
    .line 470
    .line 471
    move-result-object v2

    .line 472
    goto :goto_e

    .line 473
    :cond_11
    move-object v2, v5

    .line 474
    :goto_e
    const-string v6, "ok_card_repay_card_no"

    .line 475
    .line 476
    invoke-virtual {v1, v6, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 477
    .line 478
    .line 479
    move-result-object v1

    .line 480
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->w:Ljava/lang/Long;

    .line 481
    .line 482
    if-eqz v0, :cond_12

    .line 483
    .line 484
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 485
    .line 486
    .line 487
    move-result-wide v3

    .line 488
    :cond_12
    const-string v0, "ok_card_repay_bill_id"

    .line 489
    .line 490
    invoke-virtual {v1, v0, v3, v4}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 491
    .line 492
    .line 493
    move-result-object v0

    .line 494
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderRsp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOrderData;

    .line 495
    .line 496
    .line 497
    move-result-object p1

    .line 498
    if-eqz p1, :cond_13

    .line 499
    .line 500
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderData;->getOrderId()Ljava/lang/String;

    .line 501
    .line 502
    .line 503
    move-result-object v5

    .line 504
    :cond_13
    const-string p1, "ok_card_repay_order_no"

    .line 505
    .line 506
    invoke-virtual {v0, p1, v5}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 507
    .line 508
    .line 509
    move-result-object p1

    .line 510
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 511
    .line 512
    .line 513
    goto :goto_f

    .line 514
    :cond_14
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 515
    .line 516
    .line 517
    move-result-object p1

    .line 518
    new-array v0, v1, [Ljava/lang/Object;

    .line 519
    .line 520
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 521
    .line 522
    .line 523
    :cond_15
    :goto_f
    return-void

    .line 524
    nop

    .line 525
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
