.class public final synthetic Lub/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/k;->a:I

    iput-object p1, p0, Lub/k;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 13

    .line 1
    const/4 p1, 0x0

    .line 2
    iget-object v0, p0, Lub/k;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;

    .line 3
    .line 4
    iget v1, p0, Lub/k;->a:I

    .line 5
    .line 6
    packed-switch v1, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->C:I

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const-string v2, "CORE_FROM"

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v2, "BasePreviewActivity"

    .line 22
    .line 23
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    const/16 v2, 0x1c

    .line 28
    .line 29
    const/4 v3, 0x0

    .line 30
    const/4 v4, 0x1

    .line 31
    if-eqz v1, :cond_0

    .line 32
    .line 33
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/viewmodel/OcApplyLiteViewModel;

    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    new-instance v1, LDb/n;

    .line 43
    .line 44
    invoke-direct {v1, v4, v3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 45
    .line 46
    .line 47
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/viewmodel/OcApplyLiteViewModel;->g:Lcom/transsnet/palmpay/core/base/l;

    .line 48
    .line 49
    invoke-static {v0, v1, v3, p1, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 50
    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_0
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->showLoadingDialog(Z)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/viewmodel/OcApplyLiteViewModel;

    .line 61
    .line 62
    new-instance v4, Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;

    .line 63
    .line 64
    sget-object v9, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 65
    .line 66
    const-string v8, ""

    .line 67
    .line 68
    const/4 v10, 0x0

    .line 69
    const-string v5, "CASHIER_PAGE"

    .line 70
    .line 71
    const-string v6, "OK_CARD"

    .line 72
    .line 73
    iget v7, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->B:I

    .line 74
    .line 75
    const/16 v11, 0x20

    .line 76
    .line 77
    const/4 v12, 0x0

    .line 78
    invoke-direct/range {v4 .. v12}, Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;-><init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 82
    .line 83
    .line 84
    const-string v0, "req"

    .line 85
    .line 86
    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    new-instance v0, LDb/m;

    .line 90
    .line 91
    invoke-direct {v0, v4, v3}, LDb/m;-><init>(Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;Lkotlin/coroutines/Continuation;)V

    .line 92
    .line 93
    .line 94
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/viewmodel/OcApplyLiteViewModel;->f:Lcom/transsnet/palmpay/core/base/l;

    .line 95
    .line 96
    invoke-static {v1, v0, v3, p1, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 97
    .line 98
    .line 99
    :goto_0
    return-void

    .line 100
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->C:I

    .line 101
    .line 102
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->showLoadingDialog(Z)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 106
    .line 107
    .line 108
    return-void

    .line 109
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->C:I

    .line 110
    .line 111
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->showLoadingDialog(Z)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 115
    .line 116
    .line 117
    return-void

    .line 118
    nop

    .line 119
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
