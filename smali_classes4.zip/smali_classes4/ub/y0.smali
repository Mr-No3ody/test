.class public final synthetic Lub/y0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/y0;->a:I

    iput-object p1, p0, Lub/y0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    const-string p1, "OcOtpVerifyActivity_element_click"

    .line 2
    .line 3
    const-string v0, ""

    .line 4
    .line 5
    iget-object v1, p0, Lub/y0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    .line 6
    .line 7
    iget v2, p0, Lub/y0;->a:I

    .line 8
    .line 9
    packed-switch v2, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->v0:I

    .line 13
    .line 14
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v()V

    .line 15
    .line 16
    .line 17
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v2, "router_close_img"

    .line 22
    .line 23
    invoke-virtual {v1, p1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :pswitch_0
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->v0:I

    .line 28
    .line 29
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->onBackPressed()V

    .line 30
    .line 31
    .line 32
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    const-string v2, "router_back_img"

    .line 37
    .line 38
    invoke-virtual {v1, p1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :pswitch_1
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->v0:I

    .line 43
    .line 44
    const-string p1, "flexihome"

    .line 45
    .line 46
    invoke-static {p1}, Lcom/transsnet/palmpay/core/config/d;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    invoke-static {p1}, LPa/i0;->c0(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    const-string v2, "_element_click"

    .line 66
    .line 67
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    const-string v2, "contact_us_tv"

    .line 72
    .line 73
    invoke-virtual {p1, v1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
