.class public final synthetic Lub/b1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/b1;->a:I

    iput-object p1, p0, Lub/b1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 12

    .line 1
    const/4 p1, 0x0

    .line 2
    iget-object v0, p0, Lub/b1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;

    .line 3
    .line 4
    iget v1, p0, Lub/b1;->a:I

    .line 5
    .line 6
    packed-switch v1, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->C:I

    .line 10
    .line 11
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 12
    .line 13
    const-string v2, "createOrder >>>"

    .line 14
    .line 15
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const/4 v3, 0x3

    .line 20
    invoke-static {v1, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    const/4 v1, 0x1

    .line 24
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 25
    .line 26
    .line 27
    new-instance v2, Lcom/transsnet/palmpay/credit/bean/req/OcOrderReq;

    .line 28
    .line 29
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    if-eqz v1, :cond_0

    .line 33
    .line 34
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionAmount()Ljava/lang/Long;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    move-object v1, v3

    .line 40
    :goto_0
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 41
    .line 42
    if-eqz v4, :cond_1

    .line 43
    .line 44
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getCardNo()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    goto :goto_1

    .line 49
    :cond_1
    move-object v4, v3

    .line 50
    :goto_1
    iget-object v5, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->w:Ljava/lang/Long;

    .line 51
    .line 52
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v5

    .line 56
    iget-object v6, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->B:Ljava/lang/String;

    .line 57
    .line 58
    if-eqz v6, :cond_2

    .line 59
    .line 60
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 61
    .line 62
    .line 63
    move-result v6

    .line 64
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    move-object v7, v6

    .line 69
    goto :goto_2

    .line 70
    :cond_2
    move-object v7, v3

    .line 71
    :goto_2
    iget-object v6, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 72
    .line 73
    if-eqz v6, :cond_3

    .line 74
    .line 75
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getOrderNo()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    :cond_3
    move-object v8, v3

    .line 80
    const/16 v10, 0x40

    .line 81
    .line 82
    const/4 v11, 0x0

    .line 83
    const-string v6, "l4"

    .line 84
    .line 85
    const/4 v9, 0x0

    .line 86
    move-object v3, v1

    .line 87
    invoke-direct/range {v2 .. v11}, Lcom/transsnet/palmpay/credit/bean/req/OcOrderReq;-><init>(Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 88
    .line 89
    .line 90
    sget-object v1, Lob/c;->a:Lob/a;

    .line 91
    .line 92
    invoke-virtual {v1}, Lob/a;->getInstance()Lob/c;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->createOcOrderV2(Lcom/transsnet/palmpay/credit/bean/req/OcOrderReq;)Ldf/d;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 108
    .line 109
    invoke-virtual {v1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 114
    .line 115
    .line 116
    move-result-object v2

    .line 117
    invoke-virtual {v1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 118
    .line 119
    .line 120
    move-result-object v1

    .line 121
    new-instance v2, Lub/c1;

    .line 122
    .line 123
    invoke-direct {v2, v0, p1}, Lub/c1;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;I)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v1, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 127
    .line 128
    .line 129
    return-void

    .line 130
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->C:I

    .line 131
    .line 132
    new-instance v1, Ljava/text/DecimalFormat;

    .line 133
    .line 134
    const-string v2, "0.00%"

    .line 135
    .line 136
    invoke-direct {v1, v2}, Ljava/text/DecimalFormat;-><init>(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    new-instance v2, Lkotlin/jvm/internal/F;

    .line 140
    .line 141
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 142
    .line 143
    .line 144
    new-instance v3, LO6/c;

    .line 145
    .line 146
    invoke-direct {v3, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 147
    .line 148
    .line 149
    iput-boolean p1, v3, LO6/c;->k:Z

    .line 150
    .line 151
    sget p1, LYa/g;->cs_initial_dialog_title:I

    .line 152
    .line 153
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object p1

    .line 157
    invoke-static {p1}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    iput-object p1, v3, LO6/c;->b:Ljava/lang/CharSequence;

    .line 162
    .line 163
    const p1, 0x800003

    .line 164
    .line 165
    .line 166
    iput p1, v3, LO6/c;->l:I

    .line 167
    .line 168
    sget p1, LYa/g;->cs_initial_payment_total_amount:I

    .line 169
    .line 170
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendActivity;->A:Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;

    .line 171
    .line 172
    if-eqz v4, :cond_4

    .line 173
    .line 174
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/OcExtendBillData;->getExtensionDownPaymentRatio()Ljava/lang/Double;

    .line 175
    .line 176
    .line 177
    move-result-object v4

    .line 178
    if-eqz v4, :cond_4

    .line 179
    .line 180
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 181
    .line 182
    .line 183
    move-result-wide v4

    .line 184
    goto :goto_3

    .line 185
    :cond_4
    const-wide/16 v4, 0x0

    .line 186
    .line 187
    :goto_3
    invoke-virtual {v1, v4, v5}, Ljava/text/NumberFormat;->format(D)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object p1

    .line 199
    iput-object p1, v3, LO6/c;->d:Ljava/lang/CharSequence;

    .line 200
    .line 201
    sget p1, Lba/k;->core_got_it:I

    .line 202
    .line 203
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    new-instance v0, LAb/l;

    .line 208
    .line 209
    const/4 v1, 0x7

    .line 210
    invoke-direct {v0, v2, v1}, LAb/l;-><init>(Lkotlin/jvm/internal/F;I)V

    .line 211
    .line 212
    .line 213
    iput-object p1, v3, LO6/c;->f:Ljava/lang/String;

    .line 214
    .line 215
    iput-object v0, v3, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 216
    .line 217
    invoke-virtual {v3}, LO6/c;->a()LO6/d;

    .line 218
    .line 219
    .line 220
    move-result-object p1

    .line 221
    iput-object p1, v2, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 222
    .line 223
    invoke-virtual {p1}, LO6/d;->show()V

    .line 224
    .line 225
    .line 226
    return-void

    .line 227
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
