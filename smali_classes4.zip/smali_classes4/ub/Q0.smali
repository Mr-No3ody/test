.class public final Lub/Q0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/interfac/OnRvItemClickListener;
.implements Lcom/transsnet/palmpay/credit/ui/dialog/AgentAutoRepaymentDialogListener;


# instance fields
.field public final synthetic a:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lub/Q0;->a:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCancel()V
    .locals 0

    .line 1
    return-void
.end method

.method public onConfirm()V
    .locals 4

    .line 1
    sget v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->j1:I

    .line 2
    .line 3
    iget-object v0, p0, Lub/Q0;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;

    .line 6
    .line 7
    sget-object v1, Lob/c;->a:Lob/a;

    .line 8
    .line 9
    invoke-static {v1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    new-instance v2, Lcom/transsnet/palmpay/credit/bean/req/SignInstallmentWithdrawReq;

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    invoke-direct {v2, v3}, Lcom/transsnet/palmpay/credit/bean/req/SignInstallmentWithdrawReq;-><init>(Ljava/lang/Integer;)V

    .line 21
    .line 22
    .line 23
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->signInstallmentLoanWithdrawPreCheck(Lcom/transsnet/palmpay/credit/bean/req/SignInstallmentWithdrawReq;)Ldf/d;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 28
    .line 29
    invoke-virtual {v1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    invoke-virtual {v1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    new-instance v2, Lzb/g;

    .line 42
    .line 43
    const/4 v3, 0x2

    .line 44
    invoke-direct {v2, v0, v3}, Lzb/g;-><init>(Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;I)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v1, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 48
    .line 49
    .line 50
    return-void
.end method

.method public onItemClick(Landroid/view/View;I)V
    .locals 2

    .line 1
    const-string v0, "itemView"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lub/Q0;->a:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;

    .line 9
    .line 10
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepaidListActivity;->g:Ljava/util/ArrayList;

    .line 11
    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    const-string p2, "get(...)"

    .line 19
    .line 20
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListDetail;

    .line 24
    .line 25
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    const-string v0, "/credit_score/oc_repay_order_detail_activity"

    .line 30
    .line 31
    invoke-virtual {p2, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    const-string v0, "orderType"

    .line 36
    .line 37
    const-string v1, "g7"

    .line 38
    .line 39
    invoke-virtual {p2, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    const-string v0, "orderNo"

    .line 44
    .line 45
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OcRepaidListDetail;->getPayId()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-virtual {p2, v0, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :cond_0
    const-string p1, "mData"

    .line 58
    .line 59
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    const/4 p1, 0x0

    .line 63
    throw p1
.end method
