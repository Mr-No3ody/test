.class public final Lub/Q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/core/manager/FileUploadManager$UploadListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

.field public final synthetic b:I


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/Q;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 5
    .line 6
    iput p2, p0, Lub/Q;->b:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onComplete(Ljava/lang/String;Ljava/io/File;)V
    .locals 2

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    iget-object v0, p0, Lub/Q;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 6
    .line 7
    if-nez p2, :cond_2

    .line 8
    .line 9
    iget-object p2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->A:Ljava/lang/StringBuilder;

    .line 10
    .line 11
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    iget p1, p0, Lub/Q;->b:I

    .line 15
    .line 16
    add-int/lit8 p1, p1, 0x1

    .line 17
    .line 18
    iget-object p2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->v:Ljava/util/ArrayList;

    .line 19
    .line 20
    if-eqz p2, :cond_1

    .line 21
    .line 22
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    .line 23
    .line 24
    .line 25
    move-result p2

    .line 26
    if-lt p1, p2, :cond_0

    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->n()V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :cond_0
    iget-object p2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->A:Ljava/lang/StringBuilder;

    .line 33
    .line 34
    const-string v1, ","

    .line 35
    .line 36
    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->q(I)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :cond_1
    const-string p1, "mSelectedImgData"

    .line 44
    .line 45
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    const/4 p1, 0x0

    .line 49
    throw p1

    .line 50
    :cond_2
    const/4 p1, 0x0

    .line 51
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 52
    .line 53
    .line 54
    const-string p2, "upload images failed, please try again"

    .line 55
    .line 56
    new-array p1, p1, [Ljava/lang/Object;

    .line 57
    .line 58
    invoke-static {p2, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    return-void
.end method

.method public final onError(Ljava/lang/Exception;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lub/Q;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 5
    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    :goto_0
    new-array v1, v1, [Ljava/lang/Object;

    .line 16
    .line 17
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    if-eqz p1, :cond_1

    .line 21
    .line 22
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 23
    .line 24
    .line 25
    :cond_1
    return-void
.end method

.method public final onProgressChanged(JJ)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onStartSync(Ljava/lang/String;Ljava/io/File;)V
    .locals 0

    .line 1
    return-void
.end method
