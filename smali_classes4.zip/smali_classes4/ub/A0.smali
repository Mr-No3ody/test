.class public final synthetic Lub/A0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/A0;->a:I

    iput-object p1, p0, Lub/A0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/A0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/A0;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;->v:I

    .line 9
    .line 10
    sget v1, LYa/e;->overpayment_amount_tv:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/TextView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;->v:I

    .line 20
    .line 21
    sget v1, LYa/e;->overpayment_content_tv:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/TextView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;->v:I

    .line 31
    .line 32
    sget v1, LYa/e;->overpayment_divider_view:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0

    .line 39
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;->v:I

    .line 40
    .line 41
    sget v1, LYa/e;->overpayment_receive_acc_ll:I

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Landroid/widget/LinearLayout;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;->v:I

    .line 51
    .line 52
    sget v1, LYa/e;->overpayment_receive_acc_tv:I

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v0, Landroid/widget/TextView;

    .line 59
    .line 60
    return-object v0

    .line 61
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOverpaymentActivity;->v:I

    .line 62
    .line 63
    sget v1, LYa/e;->overpayment_receive_time_ll:I

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Landroid/widget/LinearLayout;

    .line 70
    .line 71
    return-object v0

    .line 72
    nop

    .line 73
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
