.class public final synthetic Lub/G0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRePayPreviewActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRePayPreviewActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/G0;->a:I

    iput-object p1, p0, Lub/G0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRePayPreviewActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget-object p1, p0, Lub/G0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRePayPreviewActivity;

    .line 2
    .line 3
    iget v0, p0, Lub/G0;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRePayPreviewActivity;->w0:I

    .line 9
    .line 10
    new-instance v0, Lcom/transsnet/palmpay/credit/ui/dialog/OcRepaymentCouponTipsDialog;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Lcom/transsnet/palmpay/credit/ui/dialog/OcRepaymentCouponTipsDialog;-><init>(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, LO6/f;->show()V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_0
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRePayPreviewActivity;->v0:Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 20
    .line 21
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/ui/activity/m;->F(Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :pswitch_1
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRePayPreviewActivity;->w0:I

    .line 26
    .line 27
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/ui/activity/m;->L()V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :pswitch_2
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRePayPreviewActivity;->w0:I

    .line 32
    .line 33
    iget-object v0, p1, Lcom/transsnet/palmpay/core/ui/activity/m;->d:Lcom/transsnet/palmpay/core/bean/PaymentMethod;

    .line 34
    .line 35
    const/4 v1, 0x0

    .line 36
    if-nez v0, :cond_0

    .line 37
    .line 38
    const-string p1, "please select a payment method"

    .line 39
    .line 40
    new-array v0, v1, [Ljava/lang/Object;

    .line 41
    .line 42
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    iget-object v0, p1, Lcom/transsnet/palmpay/core/ui/activity/m;->i:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_1

    .line 53
    .line 54
    new-array v0, v1, [Ljava/lang/Object;

    .line 55
    .line 56
    const-string v1, "orderNo id is null"

    .line 57
    .line 58
    invoke-static {v1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 62
    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/ui/activity/m;->E()V

    .line 66
    .line 67
    .line 68
    :goto_0
    return-void

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
