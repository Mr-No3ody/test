.class public final synthetic Lub/c0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/c0;->a:I

    iput-object p1, p0, Lub/c0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/c0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/c0;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 9
    .line 10
    sget v1, LYa/e;->selected_pay_in_tv:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/TextView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 20
    .line 21
    sget v1, LYa/e;->oc_ins_count_rv:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 31
    .line 32
    sget v1, LYa/e;->oc_ins_next_bt:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/widget/Button;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 42
    .line 43
    sget v1, LYa/e;->repayment_plan_cl:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 53
    .line 54
    sget v1, LYa/e;->cur_plan_content_tv:I

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Landroid/widget/TextView;

    .line 61
    .line 62
    return-object v0

    .line 63
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 64
    .line 65
    sget v1, LYa/e;->cur_plan_interest_tv:I

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Landroid/widget/TextView;

    .line 72
    .line 73
    return-object v0

    .line 74
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 75
    .line 76
    sget v1, LYa/e;->repayment_date_divider_view:I

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    return-object v0

    .line 83
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 84
    .line 85
    sget v1, LYa/e;->overdue_item_ll:I

    .line 86
    .line 87
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    check-cast v0, Landroid/widget/LinearLayout;

    .line 92
    .line 93
    return-object v0

    .line 94
    :pswitch_7
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 95
    .line 96
    sget v1, LYa/e;->overdue_interest_tv:I

    .line 97
    .line 98
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    check-cast v0, Landroid/widget/TextView;

    .line 103
    .line 104
    return-object v0

    .line 105
    :pswitch_8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 106
    .line 107
    sget v1, LYa/e;->oc_ins_cur_repay_amount:I

    .line 108
    .line 109
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    check-cast v0, Landroid/widget/TextView;

    .line 114
    .line 115
    return-object v0

    .line 116
    :pswitch_9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 117
    .line 118
    sget v1, LYa/e;->oc_ins_proto_cb:I

    .line 119
    .line 120
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    check-cast v0, Landroid/widget/CheckBox;

    .line 125
    .line 126
    return-object v0

    .line 127
    :pswitch_a
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 128
    .line 129
    sget v1, LYa/e;->spread_proto_tv:I

    .line 130
    .line 131
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    check-cast v0, Landroid/widget/TextView;

    .line 136
    .line 137
    return-object v0

    .line 138
    :pswitch_b
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 139
    .line 140
    sget v1, LYa/e;->repayStampDutyView:I

    .line 141
    .line 142
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    check-cast v0, Lcom/transsnet/palmpay/credit/view/RepayStampDutyView;

    .line 147
    .line 148
    return-object v0

    .line 149
    :pswitch_c
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 150
    .line 151
    sget v1, LYa/e;->repay_ins_back_siv:I

    .line 152
    .line 153
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    check-cast v0, Landroid/widget/ImageView;

    .line 158
    .line 159
    return-object v0

    .line 160
    :pswitch_d
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 161
    .line 162
    sget v1, LYa/e;->oc_bill_date_tv:I

    .line 163
    .line 164
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    check-cast v0, Landroid/widget/TextView;

    .line 169
    .line 170
    return-object v0

    .line 171
    :pswitch_e
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 172
    .line 173
    sget v1, LYa/e;->server_img:I

    .line 174
    .line 175
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    check-cast v0, Landroid/widget/ImageView;

    .line 180
    .line 181
    return-object v0

    .line 182
    :pswitch_f
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 183
    .line 184
    sget v1, LYa/e;->oc_ins_title_tv:I

    .line 185
    .line 186
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    check-cast v0, Landroid/widget/TextView;

    .line 191
    .line 192
    return-object v0

    .line 193
    :pswitch_10
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 194
    .line 195
    sget v1, LYa/e;->oc_ins_symbol_tv:I

    .line 196
    .line 197
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    check-cast v0, Landroid/widget/TextView;

    .line 202
    .line 203
    return-object v0

    .line 204
    :pswitch_11
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 205
    .line 206
    sget v1, LYa/e;->oc_ins_input_amount_et:I

    .line 207
    .line 208
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    check-cast v0, Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 213
    .line 214
    return-object v0

    .line 215
    :pswitch_12
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 216
    .line 217
    sget v1, LYa/e;->oc_ins_detail_ll:I

    .line 218
    .line 219
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 220
    .line 221
    .line 222
    move-result-object v0

    .line 223
    check-cast v0, Landroid/widget/LinearLayout;

    .line 224
    .line 225
    return-object v0

    .line 226
    nop

    .line 227
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
