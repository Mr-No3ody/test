.class public final Lub/P;
.super Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;
.source "SourceFile"


# virtual methods
.method public final getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V
    .locals 1

    .line 1
    const-string v0, "outRect"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "view"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "parent"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "state"

    .line 17
    .line 18
    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-super {p0, p1, p2, p3, p4}, Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;->getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$State;)V

    .line 22
    .line 23
    .line 24
    const/high16 p2, 0x41000000    # 8.0f

    .line 25
    .line 26
    invoke-static {p2}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 27
    .line 28
    .line 29
    move-result p3

    .line 30
    iput p3, p1, Landroid/graphics/Rect;->left:I

    .line 31
    .line 32
    invoke-static {p2}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 33
    .line 34
    .line 35
    move-result p3

    .line 36
    iput p3, p1, Landroid/graphics/Rect;->right:I

    .line 37
    .line 38
    invoke-static {p2}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 39
    .line 40
    .line 41
    move-result p3

    .line 42
    iput p3, p1, Landroid/graphics/Rect;->top:I

    .line 43
    .line 44
    invoke-static {p2}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 45
    .line 46
    .line 47
    move-result p2

    .line 48
    iput p2, p1, Landroid/graphics/Rect;->bottom:I

    .line 49
    .line 50
    return-void
.end method
