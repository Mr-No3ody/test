.class public final Lub/i0;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lm6/j;


# direct methods
.method public constructor <init>(Lm6/j;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/i0;->f:Lm6/j;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/i0;->f:Lm6/j;

    .line 2
    .line 3
    iget-object v0, v0, Lm6/j;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lub/i0;->f:Lm6/j;

    .line 2
    .line 3
    iget-object v0, v0, Lm6/j;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 9
    .line 10
    .line 11
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 5

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;

    .line 2
    .line 3
    iget-object v0, p0, Lub/i0;->f:Lm6/j;

    .line 4
    .line 5
    iget-object v1, v0, Lm6/j;->b:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    iget-object v0, v0, Lm6/j;->b:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 20
    .line 21
    const-string v3, "#EC2424"

    .line 22
    .line 23
    if-eqz v1, :cond_1

    .line 24
    .line 25
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;->isLoginOK()Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-eqz v1, :cond_0

    .line 30
    .line 31
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->r()V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_0
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->v0:Lub/k0;

    .line 36
    .line 37
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;->data:Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;

    .line 38
    .line 39
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;->statusMessage:Ljava/lang/String;

    .line 40
    .line 41
    iget-object v0, v0, Lub/k0;->b:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 44
    .line 45
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->s0:Landroid/view/View;

    .line 46
    .line 47
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 52
    .line 53
    .line 54
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->t0:Landroid/widget/TextView;

    .line 55
    .line 56
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 57
    .line 58
    .line 59
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->t0:Landroid/widget/TextView;

    .line 60
    .line 61
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :cond_1
    const-string v1, "00100005"

    .line 66
    .line 67
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v4

    .line 71
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    if-eqz v1, :cond_2

    .line 76
    .line 77
    sget p1, LYa/g;->cs_str_session_invalid_info:I

    .line 78
    .line 79
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :cond_2
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->v0:Lub/k0;

    .line 88
    .line 89
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    iget-object v0, v0, Lub/k0;->b:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 96
    .line 97
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->s0:Landroid/view/View;

    .line 98
    .line 99
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 100
    .line 101
    .line 102
    move-result v3

    .line 103
    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 104
    .line 105
    .line 106
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->t0:Landroid/widget/TextView;

    .line 107
    .line 108
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 109
    .line 110
    .line 111
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->t0:Landroid/widget/TextView;

    .line 112
    .line 113
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 114
    .line 115
    .line 116
    return-void
.end method
