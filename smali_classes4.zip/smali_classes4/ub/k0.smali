.class public Lub/k0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/interfac/OnRvItemClickListener;
.implements Landroidx/camera/core/impl/utils/futures/FutureCallback;
.implements Lcom/facebook/soloader/recovery/RecoveryStrategy;
.implements Landroidx/recyclerview/widget/ListUpdateCallback;
.implements Lio/reactivex/ObservableTransformer;
.implements Lcom/facebook/imagepipeline/decoder/ImageDecoder;
.implements Lcom/facebook/hermes/intl/IPlatformCollator;
.implements Lcom/transsnet/palmpay/contacts/ui/adapter/PalmPayNewContactListAdapter$ItemViewOnClickListener;
.implements Landroidx/camera/core/impl/utils/futures/AsyncFunction;
.implements Landroidx/core/view/DifferentialMotionFlingTarget;
.implements Lcom/bumptech/glide/Glide$RequestOptionsFactory;
.implements Lcom/facebook/soloader/SoFileLoader;
.implements Lcom/nimbusds/jose/shaded/gson/internal/ObjectConstructor;
.implements Lio/reactivex/Observer;
.implements Lcom/abedelazizshe/lightcompressorlibrary/CompressionProgressListener;
.implements Lcom/transsnet/palmpay/custom_view/input/OnNumberInputListener;
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;
.implements Lcom/transsnet/palmpay/core/callback/ResultCallback;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    iput p1, p0, Lub/k0;->a:I

    sparse-switch p1, :sswitch_data_0

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    return-void

    .line 8
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    :try_start_0
    new-instance p1, LHe/a;

    const/16 v0, 0x9

    invoke-direct {p1, v0}, LHe/a;-><init>(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 10
    const-string v0, "WindowHelper"

    invoke-static {v0, p1}, Ln5/h;->b(Ljava/lang/String;Ljava/lang/Exception;)V

    const/4 p1, 0x0

    .line 11
    :goto_0
    iput-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    return-void

    .line 12
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    return-void

    :sswitch_data_0
    .sparse-switch
        0x9 -> :sswitch_1
        0x1c -> :sswitch_0
    .end sparse-switch
.end method

.method public synthetic constructor <init>(IZ)V
    .locals 0

    .line 1
    iput p1, p0, Lub/k0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LM1/j;)V
    .locals 1

    const/4 v0, 0x5

    iput v0, p0, Lub/k0;->a:I

    const-string v0, "mAdapter"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/widget/TextView;)V
    .locals 1

    const/16 v0, 0x19

    iput v0, p0, Lub/k0;->a:I

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    new-instance v0, Lp0/g;

    invoke-direct {v0, p1}, Lp0/g;-><init>(Landroid/widget/TextView;)V

    iput-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/camera/core/impl/y0;)V
    .locals 1

    const/16 v0, 0xc

    iput v0, p0, Lub/k0;->a:I

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    const-class v0, Landroidx/camera/camera2/internal/compat/quirk/CaptureSessionOnClosedNotCalledQuirk;

    .line 16
    invoke-virtual {p1, v0}, Landroidx/camera/core/impl/y0;->b(Ljava/lang/Class;)Landroidx/camera/core/impl/Quirk;

    move-result-object p1

    check-cast p1, Landroidx/camera/camera2/internal/compat/quirk/CaptureSessionOnClosedNotCalledQuirk;

    iput-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/facebook/imagepipeline/animated/base/AnimatedDrawableBackend;LOe/a;)V
    .locals 1

    const/16 p2, 0xb

    iput p2, p0, Lub/k0;->a:I

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 19
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    const/4 p2, 0x0

    .line 20
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 21
    sget-object p2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 22
    new-instance p2, Landroid/graphics/PorterDuffXfermode;

    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {p2, v0}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;)V
    .locals 1

    const/16 v0, 0x15

    iput v0, p0, Lub/k0;->a:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    new-instance v0, Le2/a;

    invoke-direct {v0, p1}, Le2/a;-><init>(Ljava/lang/Class;)V

    iput-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p2, p0, Lub/k0;->a:I

    iput-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static b()Ljava/util/ArrayList;
    .locals 13

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v1, Ls5/a;->a:Ls5/b;

    .line 7
    .line 8
    invoke-virtual {v1}, Ls5/b;->x()Landroid/app/Activity;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-nez v1, :cond_0

    .line 13
    .line 14
    goto/16 :goto_5

    .line 15
    .line 16
    :cond_0
    new-instance v2, Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 19
    .line 20
    .line 21
    sget-object v3, Lu5/f;->a:Lub/k0;

    .line 22
    .line 23
    iget-object v3, v3, Lub/k0;->b:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v3, LHe/a;

    .line 26
    .line 27
    const/4 v4, 0x0

    .line 28
    const-string v5, "WindowHelper"

    .line 29
    .line 30
    if-eqz v3, :cond_2

    .line 31
    .line 32
    :try_start_0
    iget-boolean v6, v3, LHe/a;->b:Z

    .line 33
    .line 34
    iget-object v7, v3, LHe/a;->c:Ljava/lang/Object;

    .line 35
    .line 36
    iget-object v3, v3, LHe/a;->d:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v3, Ljava/lang/reflect/Field;

    .line 39
    .line 40
    if-eqz v6, :cond_1

    .line 41
    .line 42
    invoke-virtual {v3, v7}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    check-cast v3, Ljava/util/ArrayList;

    .line 47
    .line 48
    new-array v6, v4, [Landroid/view/View;

    .line 49
    .line 50
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    check-cast v3, [Landroid/view/View;

    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_1
    invoke-virtual {v3, v7}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    check-cast v3, [Landroid/view/View;
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :catch_0
    move-exception v3

    .line 65
    invoke-static {v5, v3}, Ln5/h;->b(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 66
    .line 67
    .line 68
    :cond_2
    sget-object v3, Ls5/a;->a:Ls5/b;

    .line 69
    .line 70
    invoke-virtual {v3}, Ls5/b;->x()Landroid/app/Activity;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    if-eqz v3, :cond_3

    .line 75
    .line 76
    :try_start_1
    invoke-virtual {v3}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 81
    .line 82
    .line 83
    move-result-object v3
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 84
    goto :goto_0

    .line 85
    :catch_1
    move-exception v3

    .line 86
    invoke-static {v5, v3}, Ln5/h;->b(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 87
    .line 88
    .line 89
    :cond_3
    const/4 v3, 0x0

    .line 90
    :goto_0
    if-eqz v3, :cond_4

    .line 91
    .line 92
    filled-new-array {v3}, [Landroid/view/View;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    goto :goto_1

    .line 97
    :cond_4
    new-array v3, v4, [Landroid/view/View;

    .line 98
    .line 99
    :goto_1
    array-length v5, v3

    .line 100
    move v6, v4

    .line 101
    :goto_2
    const/4 v7, 0x1

    .line 102
    if-ge v6, v5, :cond_6

    .line 103
    .line 104
    aget-object v8, v3, v6

    .line 105
    .line 106
    const/4 v9, 0x2

    .line 107
    new-array v9, v9, [I

    .line 108
    .line 109
    invoke-virtual {v8, v9}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 110
    .line 111
    .line 112
    aget v10, v9, v4

    .line 113
    .line 114
    aget v7, v9, v7

    .line 115
    .line 116
    new-instance v9, Landroid/graphics/Rect;

    .line 117
    .line 118
    invoke-virtual {v8}, Landroid/view/View;->getWidth()I

    .line 119
    .line 120
    .line 121
    move-result v11

    .line 122
    add-int/2addr v11, v10

    .line 123
    invoke-virtual {v8}, Landroid/view/View;->getHeight()I

    .line 124
    .line 125
    .line 126
    move-result v12

    .line 127
    add-int/2addr v12, v7

    .line 128
    invoke-direct {v9, v10, v7, v11, v12}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 132
    .line 133
    .line 134
    move-result-object v7

    .line 135
    instance-of v7, v7, Landroid/view/WindowManager$LayoutParams;

    .line 136
    .line 137
    if-eqz v7, :cond_5

    .line 138
    .line 139
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 140
    .line 141
    .line 142
    move-result-object v7

    .line 143
    check-cast v7, Landroid/view/WindowManager$LayoutParams;

    .line 144
    .line 145
    new-instance v10, Lu5/a;

    .line 146
    .line 147
    invoke-direct {v10, v8, v9, v7}, Lu5/a;-><init>(Landroid/view/View;Landroid/graphics/Rect;Landroid/view/WindowManager$LayoutParams;)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    :cond_5
    add-int/lit8 v6, v6, 0x1

    .line 154
    .line 155
    goto :goto_2

    .line 156
    :cond_6
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    :cond_7
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 161
    .line 162
    .line 163
    move-result v3

    .line 164
    if-eqz v3, :cond_a

    .line 165
    .line 166
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object v3

    .line 170
    check-cast v3, Lu5/a;

    .line 171
    .line 172
    iget-object v5, v3, Lu5/a;->a:Landroid/view/View;

    .line 173
    .line 174
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 175
    .line 176
    .line 177
    move-result-object v6

    .line 178
    invoke-virtual {v6}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 179
    .line 180
    .line 181
    move-result-object v6

    .line 182
    if-eq v5, v6, :cond_9

    .line 183
    .line 184
    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 185
    .line 186
    .line 187
    move-result-object v5

    .line 188
    if-ne v5, v1, :cond_8

    .line 189
    .line 190
    goto :goto_4

    .line 191
    :cond_8
    if-eqz v4, :cond_7

    .line 192
    .line 193
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 194
    .line 195
    .line 196
    goto :goto_3

    .line 197
    :cond_9
    :goto_4
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 198
    .line 199
    .line 200
    move v4, v7

    .line 201
    goto :goto_3

    .line 202
    :cond_a
    :goto_5
    return-object v0
.end method

.method private final c()V
    .locals 0

    .line 1
    return-void
.end method

.method private final d(Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public varargs a([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Le2/a;

    .line 4
    .line 5
    iget-object v1, v0, Le2/a;->a:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x0

    .line 16
    if-eqz v2, :cond_d

    .line 17
    .line 18
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    check-cast v2, Lf2/b;

    .line 23
    .line 24
    iget-object v4, v2, Lf2/b;->g:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v5, v0, Le2/a;->c:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    if-eqz v4, :cond_0

    .line 33
    .line 34
    iget-object v4, v2, Lf2/b;->b:Ljava/lang/Class;

    .line 35
    .line 36
    if-nez v4, :cond_1

    .line 37
    .line 38
    goto :goto_2

    .line 39
    :cond_1
    sget-object v5, Le2/a;->d:Ljava/util/concurrent/ConcurrentHashMap;

    .line 40
    .line 41
    invoke-virtual {v5, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    if-nez v6, :cond_2

    .line 46
    .line 47
    sget-object v7, Le2/a;->e:Ljava/util/concurrent/ConcurrentHashMap;

    .line 48
    .line 49
    invoke-virtual {v7, v4}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v8

    .line 53
    if-eqz v8, :cond_2

    .line 54
    .line 55
    invoke-virtual {v7, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v6

    .line 59
    check-cast v6, Ljava/lang/ref/WeakReference;

    .line 60
    .line 61
    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v6

    .line 65
    :cond_2
    if-nez v6, :cond_8

    .line 66
    .line 67
    const-class v7, Le2/a;

    .line 68
    .line 69
    monitor-enter v7

    .line 70
    :try_start_0
    invoke-virtual {v5, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    if-nez v5, :cond_3

    .line 75
    .line 76
    sget-object v6, Le2/a;->e:Ljava/util/concurrent/ConcurrentHashMap;

    .line 77
    .line 78
    invoke-virtual {v6, v4}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v8

    .line 82
    if-eqz v8, :cond_3

    .line 83
    .line 84
    invoke-virtual {v6, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    check-cast v5, Ljava/lang/ref/WeakReference;

    .line 89
    .line 90
    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v5

    .line 94
    goto :goto_0

    .line 95
    :catchall_0
    move-exception p1

    .line 96
    goto :goto_1

    .line 97
    :cond_3
    :goto_0
    if-nez v5, :cond_6

    .line 98
    .line 99
    array-length v5, p1

    .line 100
    if-nez v5, :cond_4

    .line 101
    .line 102
    iget-object v2, v2, Lf2/b;->c:Lcom/didi/drouter/store/IRouterProxy;

    .line 103
    .line 104
    if-eqz v2, :cond_4

    .line 105
    .line 106
    invoke-interface {v2, v3}, Lcom/didi/drouter/store/IRouterProxy;->newInstance(Landroid/content/Context;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    :cond_4
    if-nez v3, :cond_5

    .line 111
    .line 112
    invoke-static {v4, p1}, Lg2/c;->b(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v2

    .line 116
    move-object v3, v2

    .line 117
    :cond_5
    if-eqz v3, :cond_7

    .line 118
    .line 119
    monitor-exit v7

    .line 120
    goto :goto_2

    .line 121
    :cond_6
    move-object v3, v5

    .line 122
    :cond_7
    monitor-exit v7

    .line 123
    goto :goto_2

    .line 124
    :goto_1
    monitor-exit v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 125
    throw p1

    .line 126
    :cond_8
    move-object v3, v6

    .line 127
    :goto_2
    if-eqz v3, :cond_0

    .line 128
    .line 129
    iget-object p1, v0, Le2/a;->b:Ljava/lang/Class;

    .line 130
    .line 131
    const-class v1, Lcom/didi/drouter/service/ICallService;

    .line 132
    .line 133
    if-ne p1, v1, :cond_b

    .line 134
    .line 135
    instance-of v1, v3, Lcom/didi/drouter/service/ICallService$Type0;

    .line 136
    .line 137
    if-nez v1, :cond_9

    .line 138
    .line 139
    instance-of v1, v3, Lcom/didi/drouter/service/ICallService$Type1;

    .line 140
    .line 141
    if-nez v1, :cond_9

    .line 142
    .line 143
    instance-of v1, v3, Lcom/didi/drouter/service/ICallService$Type2;

    .line 144
    .line 145
    if-nez v1, :cond_9

    .line 146
    .line 147
    instance-of v1, v3, Lcom/didi/drouter/service/ICallService$Type3;

    .line 148
    .line 149
    if-nez v1, :cond_9

    .line 150
    .line 151
    instance-of v1, v3, Lcom/didi/drouter/service/ICallService$Type4;

    .line 152
    .line 153
    if-nez v1, :cond_9

    .line 154
    .line 155
    instance-of v1, v3, Lcom/didi/drouter/service/ICallService$Type5;

    .line 156
    .line 157
    if-nez v1, :cond_9

    .line 158
    .line 159
    instance-of v1, v3, Lcom/didi/drouter/service/ICallService$TypeN;

    .line 160
    .line 161
    if-eqz v1, :cond_b

    .line 162
    .line 163
    :cond_9
    const-string v1, "[Local] Get ICallService \"%s\" with impl \"%s\""

    .line 164
    .line 165
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    .line 171
    .line 172
    move-result-object v2

    .line 173
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    filled-new-array {p1, v2}, [Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    invoke-static {}, Lg2/c;->c()Z

    .line 182
    .line 183
    .line 184
    move-result v2

    .line 185
    if-eqz v2, :cond_a

    .line 186
    .line 187
    invoke-static {v1, p1}, Lg2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    :cond_a
    const-class p1, Le2/a;

    .line 191
    .line 192
    invoke-virtual {p1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 193
    .line 194
    .line 195
    move-result-object p1

    .line 196
    iget-object v0, v0, Le2/a;->b:Ljava/lang/Class;

    .line 197
    .line 198
    filled-new-array {v0}, [Ljava/lang/Class;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    new-instance v1, Lcom/didi/drouter/service/a;

    .line 203
    .line 204
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 205
    .line 206
    .line 207
    iput-object v3, v1, Lcom/didi/drouter/service/a;->a:Ljava/lang/Object;

    .line 208
    .line 209
    invoke-static {p1, v0, v1}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object p1

    .line 213
    return-object p1

    .line 214
    :cond_b
    const-string v0, "[Local] Get service \"%s\" with impl \"%s\""

    .line 215
    .line 216
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object p1

    .line 220
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 221
    .line 222
    .line 223
    move-result-object v1

    .line 224
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 225
    .line 226
    .line 227
    move-result-object v1

    .line 228
    filled-new-array {p1, v1}, [Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object p1

    .line 232
    invoke-static {}, Lg2/c;->c()Z

    .line 233
    .line 234
    .line 235
    move-result v1

    .line 236
    if-eqz v1, :cond_c

    .line 237
    .line 238
    invoke-static {v0, p1}, Lg2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    :cond_c
    return-object v3

    .line 242
    :cond_d
    const-string p1, "[Local] Get service \"%s\" fail with default \"%s\""

    .line 243
    .line 244
    iget-object v0, v0, Le2/a;->b:Ljava/lang/Class;

    .line 245
    .line 246
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    filled-new-array {v0, v3}, [Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    invoke-static {}, Lg2/c;->c()Z

    .line 255
    .line 256
    .line 257
    move-result v1

    .line 258
    if-eqz v1, :cond_e

    .line 259
    .line 260
    invoke-static {p1, v0}, Lg2/c;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    :cond_e
    return-object v3
.end method

.method public apply(Ljava/lang/Object;)Lcom/google/common/util/concurrent/ListenableFuture;
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    check-cast v0, Landroidx/arch/core/util/Function;

    invoke-interface {v0, p1}, Landroidx/arch/core/util/Function;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Landroidx/camera/core/impl/utils/futures/j;->d(Ljava/lang/Object;)Landroidx/camera/core/impl/utils/futures/l;

    move-result-object p1

    return-object p1
.end method

.method public apply(Ldf/d;)Lio/reactivex/ObservableSource;
    .locals 4

    .line 2
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 3
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    move-result-object p1

    new-instance v0, Lp1/c;

    const/4 v1, 0x6

    invoke-direct {v0, p0, v1}, Lp1/c;-><init>(Ljava/lang/Object;I)V

    .line 4
    sget-object v1, Ljf/a;->d:Lretrofit2/adapter/rxjava2/d;

    sget-object v2, Ljf/a;->c:Lr2/c;

    .line 5
    new-instance v3, Lio/reactivex/internal/operators/observable/k;

    invoke-direct {v3, p1, v0, v1, v2}, Lio/reactivex/internal/operators/observable/k;-><init>(Ldf/d;Lio/reactivex/functions/Consumer;Lio/reactivex/functions/Consumer;Lio/reactivex/functions/Action;)V

    return-object v3
.end method

.method public build()LG1/d;
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LG1/d;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    return-object v0

    .line 8
    :cond_0
    new-instance v0, LG1/d;

    .line 9
    .line 10
    invoke-direct {v0}, LG1/a;-><init>()V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public compare(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/icu/text/RuleBasedCollator;

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, Landroid/icu/text/RuleBasedCollator;->compare(Ljava/lang/String;Ljava/lang/String;)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    return p1
.end method

.method public configure(Lcom/facebook/hermes/intl/ILocaleObject;)Lcom/facebook/hermes/intl/IPlatformCollator;
    .locals 1

    .line 1
    check-cast p1, LU2/C;

    .line 2
    .line 3
    invoke-virtual {p1}, LU2/C;->a()V

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, LU2/C;->a:Landroid/icu/util/ULocale;

    .line 7
    .line 8
    invoke-static {p1}, Landroid/icu/text/Collator;->getInstance(Landroid/icu/util/ULocale;)Landroid/icu/text/Collator;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 13
    .line 14
    iput-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 15
    .line 16
    const/16 v0, 0x11

    .line 17
    .line 18
    invoke-virtual {p1, v0}, Landroid/icu/text/RuleBasedCollator;->setDecomposition(I)V

    .line 19
    .line 20
    .line 21
    return-object p0
.end method

.method public construct()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/reflect/Type;

    .line 4
    .line 5
    instance-of v1, v0, Ljava/lang/reflect/ParameterizedType;

    .line 6
    .line 7
    const-string v2, "Invalid EnumMap type: "

    .line 8
    .line 9
    if-eqz v1, :cond_1

    .line 10
    .line 11
    move-object v1, v0

    .line 12
    check-cast v1, Ljava/lang/reflect/ParameterizedType;

    .line 13
    .line 14
    invoke-interface {v1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const/4 v3, 0x0

    .line 19
    aget-object v1, v1, v3

    .line 20
    .line 21
    instance-of v3, v1, Ljava/lang/Class;

    .line 22
    .line 23
    if-eqz v3, :cond_0

    .line 24
    .line 25
    new-instance v0, Ljava/util/EnumMap;

    .line 26
    .line 27
    check-cast v1, Ljava/lang/Class;

    .line 28
    .line 29
    invoke-direct {v0, v1}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    .line 30
    .line 31
    .line 32
    return-object v0

    .line 33
    :cond_0
    new-instance v1, Lcom/nimbusds/jose/shaded/gson/p;

    .line 34
    .line 35
    new-instance v3, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    const/16 v2, 0xa

    .line 52
    .line 53
    const/4 v3, 0x0

    .line 54
    invoke-direct {v1, v0, v2, v3}, LP0/c;-><init>(Ljava/lang/String;IZ)V

    .line 55
    .line 56
    .line 57
    throw v1

    .line 58
    :cond_1
    new-instance v1, Lcom/nimbusds/jose/shaded/gson/p;

    .line 59
    .line 60
    new-instance v3, Ljava/lang/StringBuilder;

    .line 61
    .line 62
    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    const/16 v2, 0xa

    .line 77
    .line 78
    const/4 v3, 0x0

    .line 79
    invoke-direct {v1, v0, v2, v3}, LP0/c;-><init>(Ljava/lang/String;IZ)V

    .line 80
    .line 81
    .line 82
    throw v1
.end method

.method public decode(Lh3/e;ILcom/facebook/imagepipeline/image/QualityInfo;Lcom/facebook/imagepipeline/common/c;)Lcom/facebook/imagepipeline/image/CloseableImage;
    .locals 2

    .line 1
    iget-object p2, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p2, Lcom/facebook/fresco/animation/factory/AnimatedFactoryV2Impl;

    .line 4
    .line 5
    iget-object p3, p2, Lcom/facebook/fresco/animation/factory/AnimatedFactoryV2Impl;->e:LY2/a;

    .line 6
    .line 7
    if-nez p3, :cond_0

    .line 8
    .line 9
    new-instance p3, LPa/w;

    .line 10
    .line 11
    const/16 v0, 0x8

    .line 12
    .line 13
    invoke-direct {p3, p2, v0}, LPa/w;-><init>(Ljava/lang/Object;I)V

    .line 14
    .line 15
    .line 16
    new-instance v0, LY2/a;

    .line 17
    .line 18
    iget-object v1, p2, Lcom/facebook/fresco/animation/factory/AnimatedFactoryV2Impl;->a:Lc3/b;

    .line 19
    .line 20
    invoke-direct {v0, p3, v1}, LY2/a;-><init>(LPa/w;Lc3/b;)V

    .line 21
    .line 22
    .line 23
    iput-object v0, p2, Lcom/facebook/fresco/animation/factory/AnimatedFactoryV2Impl;->e:LY2/a;

    .line 24
    .line 25
    :cond_0
    iget-object p2, p2, Lcom/facebook/fresco/animation/factory/AnimatedFactoryV2Impl;->e:LY2/a;

    .line 26
    .line 27
    iget-object p3, p4, Lcom/facebook/imagepipeline/common/c;->b:Landroid/graphics/Bitmap$Config;

    .line 28
    .line 29
    invoke-virtual {p2, p1, p4, p3}, LY2/a;->decodeGif(Lh3/e;Lcom/facebook/imagepipeline/common/c;Landroid/graphics/Bitmap$Config;)Lcom/facebook/imagepipeline/image/CloseableImage;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    return-object p1
.end method

.method public e(Ljava/util/HashMap;)V
    .locals 9

    .line 1
    const/4 v0, 0x1

    .line 2
    const-string v1, "values"

    .line 3
    .line 4
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_16

    .line 20
    .line 21
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    check-cast v1, Ljava/util/Map$Entry;

    .line 26
    .line 27
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    check-cast v2, Ljava/lang/String;

    .line 32
    .line 33
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const-string v3, "key"

    .line 38
    .line 39
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    iget-object v3, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v3, Ljava/util/LinkedHashMap;

    .line 45
    .line 46
    if-nez v1, :cond_0

    .line 47
    .line 48
    const/4 v1, 0x0

    .line 49
    goto/16 :goto_14

    .line 50
    .line 51
    :cond_0
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    invoke-static {v4}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 56
    .line 57
    .line 58
    move-result-object v4

    .line 59
    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 60
    .line 61
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v5

    .line 69
    if-eqz v5, :cond_1

    .line 70
    .line 71
    move v5, v0

    .line 72
    goto :goto_1

    .line 73
    :cond_1
    sget-object v5, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    .line 74
    .line 75
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 76
    .line 77
    .line 78
    move-result-object v5

    .line 79
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    :goto_1
    if-eqz v5, :cond_2

    .line 84
    .line 85
    move v5, v0

    .line 86
    goto :goto_2

    .line 87
    :cond_2
    sget-object v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 88
    .line 89
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 90
    .line 91
    .line 92
    move-result-object v5

    .line 93
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v5

    .line 97
    :goto_2
    if-eqz v5, :cond_3

    .line 98
    .line 99
    move v5, v0

    .line 100
    goto :goto_3

    .line 101
    :cond_3
    sget-object v5, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    .line 102
    .line 103
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 104
    .line 105
    .line 106
    move-result-object v5

    .line 107
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v5

    .line 111
    :goto_3
    if-eqz v5, :cond_4

    .line 112
    .line 113
    move v5, v0

    .line 114
    goto :goto_4

    .line 115
    :cond_4
    sget-object v5, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    .line 116
    .line 117
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 118
    .line 119
    .line 120
    move-result-object v5

    .line 121
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 122
    .line 123
    .line 124
    move-result v5

    .line 125
    :goto_4
    if-eqz v5, :cond_5

    .line 126
    .line 127
    move v5, v0

    .line 128
    goto :goto_5

    .line 129
    :cond_5
    sget-object v5, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    .line 130
    .line 131
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 132
    .line 133
    .line 134
    move-result-object v5

    .line 135
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v5

    .line 139
    :goto_5
    if-eqz v5, :cond_6

    .line 140
    .line 141
    move v5, v0

    .line 142
    goto :goto_6

    .line 143
    :cond_6
    const-class v5, Ljava/lang/String;

    .line 144
    .line 145
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 146
    .line 147
    .line 148
    move-result-object v5

    .line 149
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 150
    .line 151
    .line 152
    move-result v5

    .line 153
    :goto_6
    if-eqz v5, :cond_7

    .line 154
    .line 155
    move v5, v0

    .line 156
    goto :goto_7

    .line 157
    :cond_7
    const-class v5, [Ljava/lang/Boolean;

    .line 158
    .line 159
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 160
    .line 161
    .line 162
    move-result-object v5

    .line 163
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 164
    .line 165
    .line 166
    move-result v5

    .line 167
    :goto_7
    if-eqz v5, :cond_8

    .line 168
    .line 169
    move v5, v0

    .line 170
    goto :goto_8

    .line 171
    :cond_8
    const-class v5, [Ljava/lang/Byte;

    .line 172
    .line 173
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 174
    .line 175
    .line 176
    move-result-object v5

    .line 177
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 178
    .line 179
    .line 180
    move-result v5

    .line 181
    :goto_8
    if-eqz v5, :cond_9

    .line 182
    .line 183
    move v5, v0

    .line 184
    goto :goto_9

    .line 185
    :cond_9
    const-class v5, [Ljava/lang/Integer;

    .line 186
    .line 187
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 188
    .line 189
    .line 190
    move-result-object v5

    .line 191
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v5

    .line 195
    :goto_9
    if-eqz v5, :cond_a

    .line 196
    .line 197
    move v5, v0

    .line 198
    goto :goto_a

    .line 199
    :cond_a
    const-class v5, [Ljava/lang/Long;

    .line 200
    .line 201
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 202
    .line 203
    .line 204
    move-result-object v5

    .line 205
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    move-result v5

    .line 209
    :goto_a
    if-eqz v5, :cond_b

    .line 210
    .line 211
    move v5, v0

    .line 212
    goto :goto_b

    .line 213
    :cond_b
    const-class v5, [Ljava/lang/Float;

    .line 214
    .line 215
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 216
    .line 217
    .line 218
    move-result-object v5

    .line 219
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v5

    .line 223
    :goto_b
    if-eqz v5, :cond_c

    .line 224
    .line 225
    move v5, v0

    .line 226
    goto :goto_c

    .line 227
    :cond_c
    const-class v5, [Ljava/lang/Double;

    .line 228
    .line 229
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 230
    .line 231
    .line 232
    move-result-object v5

    .line 233
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 234
    .line 235
    .line 236
    move-result v5

    .line 237
    :goto_c
    if-eqz v5, :cond_d

    .line 238
    .line 239
    move v5, v0

    .line 240
    goto :goto_d

    .line 241
    :cond_d
    const-class v5, [Ljava/lang/String;

    .line 242
    .line 243
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 244
    .line 245
    .line 246
    move-result-object v5

    .line 247
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result v5

    .line 251
    :goto_d
    if-eqz v5, :cond_e

    .line 252
    .line 253
    goto/16 :goto_14

    .line 254
    .line 255
    :cond_e
    const-class v5, [Z

    .line 256
    .line 257
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 258
    .line 259
    .line 260
    move-result-object v5

    .line 261
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 262
    .line 263
    .line 264
    move-result v5

    .line 265
    const/4 v6, 0x0

    .line 266
    if-eqz v5, :cond_10

    .line 267
    .line 268
    check-cast v1, [Z

    .line 269
    .line 270
    sget-object v4, LV0/o;->a:Ljava/lang/String;

    .line 271
    .line 272
    array-length v4, v1

    .line 273
    new-array v5, v4, [Ljava/lang/Boolean;

    .line 274
    .line 275
    :goto_e
    if-ge v6, v4, :cond_f

    .line 276
    .line 277
    aget-boolean v7, v1, v6

    .line 278
    .line 279
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 280
    .line 281
    .line 282
    move-result-object v7

    .line 283
    aput-object v7, v5, v6

    .line 284
    .line 285
    add-int/2addr v6, v0

    .line 286
    goto :goto_e

    .line 287
    :cond_f
    move-object v1, v5

    .line 288
    goto/16 :goto_14

    .line 289
    .line 290
    :cond_10
    const-class v5, [B

    .line 291
    .line 292
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 293
    .line 294
    .line 295
    move-result-object v5

    .line 296
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 297
    .line 298
    .line 299
    move-result v5

    .line 300
    if-eqz v5, :cond_11

    .line 301
    .line 302
    check-cast v1, [B

    .line 303
    .line 304
    sget-object v4, LV0/o;->a:Ljava/lang/String;

    .line 305
    .line 306
    array-length v4, v1

    .line 307
    new-array v5, v4, [Ljava/lang/Byte;

    .line 308
    .line 309
    :goto_f
    if-ge v6, v4, :cond_f

    .line 310
    .line 311
    aget-byte v7, v1, v6

    .line 312
    .line 313
    invoke-static {v7}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 314
    .line 315
    .line 316
    move-result-object v7

    .line 317
    aput-object v7, v5, v6

    .line 318
    .line 319
    add-int/2addr v6, v0

    .line 320
    goto :goto_f

    .line 321
    :cond_11
    const-class v5, [I

    .line 322
    .line 323
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 324
    .line 325
    .line 326
    move-result-object v5

    .line 327
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 328
    .line 329
    .line 330
    move-result v5

    .line 331
    if-eqz v5, :cond_12

    .line 332
    .line 333
    check-cast v1, [I

    .line 334
    .line 335
    sget-object v4, LV0/o;->a:Ljava/lang/String;

    .line 336
    .line 337
    array-length v4, v1

    .line 338
    new-array v5, v4, [Ljava/lang/Integer;

    .line 339
    .line 340
    :goto_10
    if-ge v6, v4, :cond_f

    .line 341
    .line 342
    aget v7, v1, v6

    .line 343
    .line 344
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 345
    .line 346
    .line 347
    move-result-object v7

    .line 348
    aput-object v7, v5, v6

    .line 349
    .line 350
    add-int/2addr v6, v0

    .line 351
    goto :goto_10

    .line 352
    :cond_12
    const-class v5, [J

    .line 353
    .line 354
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 355
    .line 356
    .line 357
    move-result-object v5

    .line 358
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 359
    .line 360
    .line 361
    move-result v5

    .line 362
    if-eqz v5, :cond_13

    .line 363
    .line 364
    check-cast v1, [J

    .line 365
    .line 366
    sget-object v4, LV0/o;->a:Ljava/lang/String;

    .line 367
    .line 368
    array-length v4, v1

    .line 369
    new-array v5, v4, [Ljava/lang/Long;

    .line 370
    .line 371
    :goto_11
    if-ge v6, v4, :cond_f

    .line 372
    .line 373
    aget-wide v7, v1, v6

    .line 374
    .line 375
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 376
    .line 377
    .line 378
    move-result-object v7

    .line 379
    aput-object v7, v5, v6

    .line 380
    .line 381
    add-int/2addr v6, v0

    .line 382
    goto :goto_11

    .line 383
    :cond_13
    const-class v5, [F

    .line 384
    .line 385
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 386
    .line 387
    .line 388
    move-result-object v5

    .line 389
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 390
    .line 391
    .line 392
    move-result v5

    .line 393
    if-eqz v5, :cond_14

    .line 394
    .line 395
    check-cast v1, [F

    .line 396
    .line 397
    sget-object v4, LV0/o;->a:Ljava/lang/String;

    .line 398
    .line 399
    array-length v4, v1

    .line 400
    new-array v5, v4, [Ljava/lang/Float;

    .line 401
    .line 402
    :goto_12
    if-ge v6, v4, :cond_f

    .line 403
    .line 404
    aget v7, v1, v6

    .line 405
    .line 406
    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 407
    .line 408
    .line 409
    move-result-object v7

    .line 410
    aput-object v7, v5, v6

    .line 411
    .line 412
    add-int/2addr v6, v0

    .line 413
    goto :goto_12

    .line 414
    :cond_14
    const-class v5, [D

    .line 415
    .line 416
    invoke-static {v5}, Lkotlin/jvm/internal/G;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/h;

    .line 417
    .line 418
    .line 419
    move-result-object v5

    .line 420
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/h;->equals(Ljava/lang/Object;)Z

    .line 421
    .line 422
    .line 423
    move-result v5

    .line 424
    if-eqz v5, :cond_15

    .line 425
    .line 426
    check-cast v1, [D

    .line 427
    .line 428
    sget-object v4, LV0/o;->a:Ljava/lang/String;

    .line 429
    .line 430
    array-length v4, v1

    .line 431
    new-array v5, v4, [Ljava/lang/Double;

    .line 432
    .line 433
    :goto_13
    if-ge v6, v4, :cond_f

    .line 434
    .line 435
    aget-wide v7, v1, v6

    .line 436
    .line 437
    invoke-static {v7, v8}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 438
    .line 439
    .line 440
    move-result-object v7

    .line 441
    aput-object v7, v5, v6

    .line 442
    .line 443
    add-int/2addr v6, v0

    .line 444
    goto :goto_13

    .line 445
    :goto_14
    invoke-interface {v3, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 446
    .line 447
    .line 448
    goto/16 :goto_0

    .line 449
    .line 450
    :cond_15
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 451
    .line 452
    new-instance v0, Ljava/lang/StringBuilder;

    .line 453
    .line 454
    const-string v1, "Key "

    .line 455
    .line 456
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 457
    .line 458
    .line 459
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 460
    .line 461
    .line 462
    const-string v1, " has invalid type "

    .line 463
    .line 464
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 465
    .line 466
    .line 467
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 468
    .line 469
    .line 470
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 471
    .line 472
    .line 473
    move-result-object v0

    .line 474
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 475
    .line 476
    .line 477
    throw p1

    .line 478
    :cond_16
    return-void
.end method

.method public f(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;->setForceDark(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public g()V
    .locals 2

    .line 1
    const/4 v0, 0x2

    .line 2
    iget-object v1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v1, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;

    .line 5
    .line 6
    invoke-interface {v1, v0}, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;->setForceDarkBehavior(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public getAvailableLocales()[Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Landroid/icu/util/ULocale;->getAvailableLocales()[Landroid/icu/util/ULocale;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    array-length v2, v1

    .line 11
    const/4 v3, 0x0

    .line 12
    :goto_0
    if-ge v3, v2, :cond_0

    .line 13
    .line 14
    aget-object v4, v1, v3

    .line 15
    .line 16
    invoke-virtual {v4}, Landroid/icu/util/ULocale;->toLanguageTag()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    add-int/lit8 v3, v3, 0x1

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    new-array v1, v1, [Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, [Ljava/lang/String;

    .line 37
    .line 38
    return-object v0
.end method

.method public getScaledScrollFactor()F
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/core/widget/NestedScrollView;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/core/widget/NestedScrollView;->getVerticalScrollFactorCompat()F

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    neg-float v0, v0

    .line 10
    return v0
.end method

.method public getSensitivity()LU2/c;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/icu/text/RuleBasedCollator;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    sget-object v0, LU2/c;->e:LU2/c;

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_0
    invoke-virtual {v0}, Landroid/icu/text/RuleBasedCollator;->getStrength()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_2

    .line 15
    .line 16
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, Landroid/icu/text/RuleBasedCollator;

    .line 19
    .line 20
    invoke-virtual {v0}, Landroid/icu/text/RuleBasedCollator;->isCaseLevel()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    sget-object v0, LU2/c;->c:LU2/c;

    .line 27
    .line 28
    return-object v0

    .line 29
    :cond_1
    sget-object v0, LU2/c;->a:LU2/c;

    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_2
    const/4 v1, 0x1

    .line 33
    if-ne v0, v1, :cond_3

    .line 34
    .line 35
    sget-object v0, LU2/c;->b:LU2/c;

    .line 36
    .line 37
    return-object v0

    .line 38
    :cond_3
    sget-object v0, LU2/c;->d:LU2/c;

    .line 39
    .line 40
    return-object v0
.end method

.method public h(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;->setPaymentRequestEnabled(Z)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public load(Ljava/lang/String;I)V
    .locals 6

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LZ4/a;

    .line 4
    .line 5
    sget-object v1, LE3/a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    check-cast v1, [Lcom/facebook/soloader/observer/Observer;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    array-length v2, v1

    .line 16
    const/4 v3, 0x0

    .line 17
    :goto_0
    if-ge v3, v2, :cond_0

    .line 18
    .line 19
    aget-object v4, v1, v3

    .line 20
    .line 21
    const-string v5, "load"

    .line 22
    .line 23
    invoke-interface {v4, v0, v5, p2}, Lcom/facebook/soloader/observer/Observer;->onSoFileLoaderLoadStart(Lcom/facebook/soloader/SoFileLoader;Ljava/lang/String;I)V

    .line 24
    .line 25
    .line 26
    add-int/lit8 v3, v3, 0x1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    :try_start_0
    invoke-static {p1}, Ljava/lang/System;->load(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    invoke-static {p1}, LE3/a;->a(Ljava/lang/Throwable;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :catchall_0
    move-exception p1

    .line 38
    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 39
    :catchall_1
    move-exception p2

    .line 40
    invoke-static {p1}, LE3/a;->a(Ljava/lang/Throwable;)V

    .line 41
    .line 42
    .line 43
    throw p2
.end method

.method public loadBytes(Ljava/lang/String;Lcom/facebook/soloader/ElfByteChannel;I)V
    .locals 6

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LZ4/a;

    .line 4
    .line 5
    sget-object v1, LE3/a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    check-cast v1, [Lcom/facebook/soloader/observer/Observer;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    array-length v2, v1

    .line 16
    const/4 v3, 0x0

    .line 17
    :goto_0
    if-ge v3, v2, :cond_0

    .line 18
    .line 19
    aget-object v4, v1, v3

    .line 20
    .line 21
    const-string v5, "loadBytes"

    .line 22
    .line 23
    invoke-interface {v4, v0, v5, p3}, Lcom/facebook/soloader/observer/Observer;->onSoFileLoaderLoadStart(Lcom/facebook/soloader/SoFileLoader;Ljava/lang/String;I)V

    .line 24
    .line 25
    .line 26
    add-int/lit8 v3, v3, 0x1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    :try_start_0
    invoke-virtual {v0, p1, p2, p3}, LZ4/a;->loadBytes(Ljava/lang/String;Lcom/facebook/soloader/ElfByteChannel;I)V

    .line 30
    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    throw p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 34
    :catchall_0
    move-exception p1

    .line 35
    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 36
    :catchall_1
    move-exception p2

    .line 37
    invoke-static {p1}, LE3/a;->a(Ljava/lang/Throwable;)V

    .line 38
    .line 39
    .line 40
    throw p2
.end method

.method public onChanged(IILjava/lang/Object;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LM1/j;

    .line 4
    .line 5
    invoke-virtual {v0}, LM1/j;->getHeaderLayoutCount()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    add-int/2addr v1, p1

    .line 10
    invoke-virtual {v0, v1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemRangeChanged(IILjava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public onComplete()V
    .locals 1

    iget v0, p0, Lub/k0;->a:I

    packed-switch v0, :pswitch_data_0

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    check-cast v0, Lio/reactivex/Observer;

    invoke-interface {v0}, Lio/reactivex/Observer;->onComplete()V

    :pswitch_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x14
        :pswitch_0
    .end packed-switch
.end method

.method public onComplete(Ljava/lang/Object;)V
    .locals 0

    .line 2
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 3
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    check-cast p1, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToCommonAccountActivity;

    invoke-static {p1}, Lcom/transsnet/palmpay/send_money/ui/activity/TransferToCommonAccountActivity;->x(Lcom/transsnet/palmpay/send_money/ui/activity/TransferToCommonAccountActivity;)V

    :cond_0
    return-void
.end method

.method public onDeleteViewOnClick(Lcom/transsnet/palmpay/core/db/entity/RequestContact;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/contacts/ui/activity/PalmPayNewContactsListActivity;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/transsnet/palmpay/contacts/ui/activity/PalmPayNewContactsListActivity;->c:LW9/G;

    .line 6
    .line 7
    iget-object v2, v1, LW9/G;->c:Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemRemoved(I)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    sub-int/2addr v2, v3

    .line 24
    invoke-virtual {v1, v3, v2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemRangeChanged(II)V

    .line 25
    .line 26
    .line 27
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/i;->a:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 28
    .line 29
    check-cast v0, LU9/g;

    .line 30
    .line 31
    invoke-virtual {v0, p1}, LU9/g;->deleteContact(Lcom/transsnet/palmpay/core/db/entity/RequestContact;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 2

    .line 1
    iget v0, p0, Lub/k0;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lio/reactivex/Observer;

    .line 9
    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    :try_start_0
    new-instance p1, Lretrofit2/adapter/rxjava2/d;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-direct {p1, v1}, Lretrofit2/adapter/rxjava2/d;-><init>(I)V

    .line 16
    .line 17
    .line 18
    invoke-interface {v0, p1}, Lio/reactivex/Observer;->onNext(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    .line 20
    .line 21
    invoke-interface {v0}, Lio/reactivex/Observer;->onComplete()V

    .line 22
    .line 23
    .line 24
    goto :goto_1

    .line 25
    :catchall_0
    move-exception p1

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    :try_start_1
    new-instance p1, Ljava/lang/NullPointerException;

    .line 28
    .line 29
    const-string v1, "error == null"

    .line 30
    .line 31
    invoke-direct {p1, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 35
    :goto_0
    :try_start_2
    invoke-interface {v0, p1}, Lio/reactivex/Observer;->onError(Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :catchall_1
    move-exception v0

    .line 40
    invoke-static {v0}, LD3/a;->H(Ljava/lang/Throwable;)V

    .line 41
    .line 42
    .line 43
    new-instance v1, Lhf/b;

    .line 44
    .line 45
    filled-new-array {p1, v0}, [Ljava/lang/Throwable;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-direct {v1, p1}, Lhf/b;-><init>([Ljava/lang/Throwable;)V

    .line 50
    .line 51
    .line 52
    invoke-static {v1}, Lorg/chromium/support_lib_boundary/util/b;->V(Ljava/lang/Throwable;)V

    .line 53
    .line 54
    .line 55
    :goto_1
    :pswitch_0
    return-void

    .line 56
    nop

    .line 57
    :pswitch_data_0
    .packed-switch 0x14
        :pswitch_0
    .end packed-switch
.end method

.method public onFailure(Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, Landroidx/camera/core/ImageProxy;

    .line 4
    .line 5
    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->close()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public onInserted(II)V
    .locals 2

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LM1/j;

    .line 4
    .line 5
    invoke-virtual {v0}, LM1/j;->getHeaderLayoutCount()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    add-int/2addr v1, p1

    .line 10
    invoke-virtual {v0, v1, p2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemRangeInserted(II)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 1

    const-string v0, "<unused var>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    check-cast p1, Lcom/transsnet/palmpay/airtime/ui/fragment/ScheduleTopUpTaskListFragment;

    invoke-virtual {p1}, Lcom/transsnet/palmpay/airtime/ui/fragment/ScheduleTopUpTaskListFragment;->u()Lk9/n;

    move-result-object p2

    .line 17
    invoke-virtual {p2, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/transsnet/palmpay/airtime/bean/ScheduleTopUpFAQBean;

    .line 18
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    .line 19
    invoke-virtual {p2}, Lcom/transsnet/palmpay/airtime/bean/ScheduleTopUpFAQBean;->getUrl()Ljava/lang/String;

    move-result-object p2

    .line 20
    invoke-static {p1, p2}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    .line 21
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onItemClick(Landroid/view/View;I)V
    .locals 6

    const-string v0, "itemView"

    iget v1, p0, Lub/k0;->a:I

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    packed-switch v1, :pswitch_data_0

    .line 1
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;

    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcBillHistoryActivity;->e:Ljava/util/ArrayList;

    if-eqz v0, :cond_2

    .line 2
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    const-string v0, "get(...)"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p2, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListDetail;

    .line 3
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    move-result-object v0

    .line 4
    const-string v1, "/credit_score/oc_bill_detail_activity"

    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    move-result-object v0

    .line 5
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListDetail;->getId()Ljava/lang/Long;

    move-result-object v1

    const-wide/16 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    goto :goto_0

    :cond_0
    move-wide v4, v2

    :goto_0
    const-string v1, "oc_bill_id"

    invoke-virtual {v0, v1, v4, v5}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    move-result-object v0

    .line 6
    const-string v1, "oc_card_no"

    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListDetail;->getCardNo()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v1, v4}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    move-result-object v0

    .line 7
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/resp/OcHistoryBillListDetail;->getRepaymentDateStamp()Ljava/lang/Long;

    move-result-object p2

    if-eqz p2, :cond_1

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    :cond_1
    const-string p2, "oc_future_repayment_date"

    invoke-virtual {v0, p2, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    move-result-object p2

    .line 8
    invoke-virtual {p2, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    return-void

    .line 9
    :cond_2
    const-string p1, "mData"

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1

    .line 10
    :pswitch_0
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;

    iput p2, p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->o1:I

    .line 11
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->r1:Ljava/util/ArrayList;

    .line 12
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 13
    iput-object p2, p1, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLBorrowBaseFragment;->p1:Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 14
    sget p2, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->M1:I

    .line 15
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/fragment/cashloan/CLInstallmentBorrowFragment;->q0()V

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public onItemViewOnClick(Lcom/transsnet/palmpay/core/db/entity/RequestContact;)V
    .locals 5

    .line 1
    sget v0, Lcom/transsnet/palmpay/contacts/ui/activity/PalmPayNewContactsListActivity;->d:I

    .line 2
    .line 3
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/contacts/ui/activity/PalmPayNewContactsListActivity;

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 9
    .line 10
    .line 11
    new-instance v1, Lcom/transsnet/palmpay/core/bean/req/QueryContactReq;

    .line 12
    .line 13
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/req/QueryContactReq;-><init>()V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getContactsMemberId()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/bean/req/QueryContactReq;->setContactsMemberId(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    sget-object v2, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 24
    .line 25
    iget-object v2, v2, Landroidx/camera/video/internal/c;->c:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v2, Lcom/transsnet/palmpay/core/network/api/MemberApiService;

    .line 28
    .line 29
    invoke-interface {v2, v1}, Lcom/transsnet/palmpay/core/network/api/MemberApiService;->queryMemberContact(Lcom/transsnet/palmpay/core/bean/req/QueryContactReq;)Ldf/d;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 34
    .line 35
    invoke-virtual {v1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    invoke-virtual {v1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    new-instance v2, LN8/r;

    .line 48
    .line 49
    const/4 v3, 0x6

    .line 50
    const/4 v4, 0x0

    .line 51
    invoke-direct {v2, v0, v3, p1, v4}, LN8/r;-><init>(Ljava/lang/Object;ILjava/lang/Object;Z)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public onMoved(II)V
    .locals 2

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LM1/j;

    .line 4
    .line 5
    invoke-virtual {v0}, LM1/j;->getHeaderLayoutCount()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    add-int/2addr v1, p1

    .line 10
    invoke-virtual {v0}, LM1/j;->getHeaderLayoutCount()I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    add-int/2addr p1, p2

    .line 15
    invoke-virtual {v0, v1, p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemMoved(II)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public onNext(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/k0;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lretrofit2/K;

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    new-instance p1, Lretrofit2/adapter/rxjava2/d;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-direct {p1, v0}, Lretrofit2/adapter/rxjava2/d;-><init>(I)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, Lio/reactivex/Observer;

    .line 19
    .line 20
    invoke-interface {v0, p1}, Lio/reactivex/Observer;->onNext(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    new-instance p1, Ljava/lang/NullPointerException;

    .line 25
    .line 26
    const-string v0, "response == null"

    .line 27
    .line 28
    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1

    .line 32
    :pswitch_0
    check-cast p1, Ljava/lang/Long;

    .line 33
    .line 34
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast p1, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;

    .line 37
    .line 38
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    nop

    .line 43
    :pswitch_data_0
    .packed-switch 0x14
        :pswitch_0
    .end packed-switch
.end method

.method public onNumberEditComplete(Ljava/lang/String;)V
    .locals 4

    .line 1
    sget v0, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;->x0:I

    .line 2
    .line 3
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;

    .line 6
    .line 7
    iget-object v1, v0, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;->B:Ljava/util/List;

    .line 8
    .line 9
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    check-cast p1, Lcom/transsnet/palmpay/airtime/viewmodel/AirTimeTopupViewModel;

    .line 20
    .line 21
    if-eqz p1, :cond_1

    .line 22
    .line 23
    invoke-virtual {p1}, Lcom/transsnet/palmpay/airtime/viewmodel/AirTimeTopupViewModel;->f()V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;->A(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :cond_1
    :goto_0
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 31
    .line 32
    check-cast p1, LRd/H;

    .line 33
    .line 34
    const-string v1, ""

    .line 35
    .line 36
    if-eqz p1, :cond_2

    .line 37
    .line 38
    iget-object p1, p1, LRd/H;->g:Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 39
    .line 40
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->getPhoneNumber()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    if-nez p1, :cond_3

    .line 45
    .line 46
    :cond_2
    move-object p1, v1

    .line 47
    :cond_3
    invoke-static {p1}, LPa/r0;->b1(Ljava/lang/String;)Z

    .line 48
    .line 49
    .line 50
    move-result v2

    .line 51
    if-eqz v2, :cond_6

    .line 52
    .line 53
    const-string v2, "0234"

    .line 54
    .line 55
    const/4 v3, 0x0

    .line 56
    invoke-static {p1, v2, v3}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    if-nez v2, :cond_5

    .line 61
    .line 62
    const-string v2, "234"

    .line 63
    .line 64
    invoke-static {p1, v2, v3}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 65
    .line 66
    .line 67
    move-result p1

    .line 68
    if-eqz p1, :cond_4

    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_4
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 72
    .line 73
    check-cast p1, LRd/H;

    .line 74
    .line 75
    if-eqz p1, :cond_7

    .line 76
    .line 77
    iget-object p1, p1, LRd/H;->g:Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 78
    .line 79
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->setError(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    goto :goto_2

    .line 83
    :cond_5
    :goto_1
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 84
    .line 85
    check-cast p1, LRd/H;

    .line 86
    .line 87
    if-eqz p1, :cond_7

    .line 88
    .line 89
    iget-object p1, p1, LRd/H;->g:Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 90
    .line 91
    sget v1, Lba/k;->core_check_number:I

    .line 92
    .line 93
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->setError(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    goto :goto_2

    .line 101
    :cond_6
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 102
    .line 103
    check-cast p1, LRd/H;

    .line 104
    .line 105
    if-eqz p1, :cond_7

    .line 106
    .line 107
    iget-object p1, p1, LRd/H;->g:Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 108
    .line 109
    sget v1, Lba/k;->core_please_enter_11_digit_phone_number:I

    .line 110
    .line 111
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->setError(Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    :cond_7
    :goto_2
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 119
    .line 120
    check-cast p1, LRd/H;

    .line 121
    .line 122
    if-eqz p1, :cond_8

    .line 123
    .line 124
    iget-object p1, p1, LRd/H;->g:Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 125
    .line 126
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->getPhoneNumberEdit()Landroidx/appcompat/widget/AppCompatAutoCompleteTextView;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    goto :goto_3

    .line 131
    :cond_8
    const/4 p1, 0x0

    .line 132
    :goto_3
    invoke-static {p1}, Lcom/transsnet/palmpay/util/KeyboardUtils;->hideSoftInput(Landroid/view/View;)V

    .line 133
    .line 134
    .line 135
    return-void
.end method

.method public onNumberEditing(Ljava/lang/String;)V
    .locals 3

    .line 1
    sget-object v0, Lcom/transsnet/palmpay/util/PhoneBaseNumberUtils;->INSTANCE:Lcom/transsnet/palmpay/util/PhoneBaseNumberUtils;

    .line 2
    .line 3
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-virtual {v0, p1, v1, v2}, Lcom/transsnet/palmpay/util/PhoneBaseNumberUtils;->isValidMobileNumber(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    if-nez p1, :cond_0

    .line 13
    .line 14
    sget p1, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;->x0:I

    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public onProgressCancelled(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/palmpay/lib/bridgewrapper/video/VideoUploadBridge$compressVideo$1$2;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Lcom/abedelazizshe/lightcompressorlibrary/CompressionListener;->onCancelled(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public onProgressChanged(IF)V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/palmpay/lib/bridgewrapper/video/VideoUploadBridge$compressVideo$1$2;

    .line 4
    .line 5
    invoke-interface {v0, p1, p2}, Lcom/abedelazizshe/lightcompressorlibrary/CompressionListener;->onProgress(IF)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public onRemoved(II)V
    .locals 3

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LM1/j;

    .line 4
    .line 5
    invoke-virtual {v0}, LM1/j;->getMLoadMoreModule$com_github_CymChad_brvah()LS1/c;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-nez v1, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {v1}, LS1/c;->d()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/4 v2, 0x1

    .line 17
    if-ne v1, v2, :cond_1

    .line 18
    .line 19
    invoke-virtual {v0}, LM1/j;->getItemCount()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-nez v1, :cond_1

    .line 24
    .line 25
    invoke-virtual {v0}, LM1/j;->getHeaderLayoutCount()I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    add-int/2addr v1, p1

    .line 30
    add-int/2addr p2, v2

    .line 31
    invoke-virtual {v0, v1, p2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemRangeRemoved(II)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_1
    :goto_0
    invoke-virtual {v0}, LM1/j;->getHeaderLayoutCount()I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    add-int/2addr v1, p1

    .line 40
    invoke-virtual {v0, v1, p2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemRangeRemoved(II)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public onSelectNumber(Lcom/transsnet/palmpay/custom_view/input/InputMobileImpl;)V
    .locals 6

    .line 1
    const-string v0, "item"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget v0, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;->x0:I

    .line 7
    .line 8
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;

    .line 11
    .line 12
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 13
    .line 14
    check-cast v1, LRd/H;

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    iget-object v1, v1, LRd/H;->g:Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 19
    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    const/4 v2, 0x2

    .line 23
    const/4 v3, 0x0

    .line 24
    const/4 v4, 0x1

    .line 25
    const/4 v5, 0x0

    .line 26
    invoke-static {v1, v4, v5, v2, v3}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->showContactIv$default(Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;ZZILjava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    :cond_0
    invoke-interface {p1}, Lcom/transsnet/palmpay/custom_view/input/InputMobileImpl;->getPhoneName()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-nez v1, :cond_1

    .line 38
    .line 39
    invoke-interface {p1}, Lcom/transsnet/palmpay/custom_view/input/InputMobileImpl;->getPhoneName()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    :cond_1
    return-void
.end method

.method public onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/k0;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lio/reactivex/Observer;

    .line 9
    .line 10
    invoke-interface {v0, p1}, Lio/reactivex/Observer;->onSubscribe(Lio/reactivex/disposables/Disposable;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x14
        :pswitch_0
    .end packed-switch
.end method

.method public bridge synthetic onSuccess(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Void;

    .line 2
    .line 3
    return-void
.end method

.method public recover(Ljava/lang/UnsatisfiedLinkError;[Lcom/facebook/soloader/x;)Z
    .locals 10

    .line 1
    instance-of p1, p1, Lcom/facebook/soloader/w;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    if-nez p1, :cond_0

    .line 5
    .line 6
    goto/16 :goto_4

    .line 7
    .line 8
    :cond_0
    const-string p1, "Checking /data/app missing libraries."

    .line 9
    .line 10
    const-string v1, "SoLoader"

    .line 11
    .line 12
    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 13
    .line 14
    .line 15
    new-instance p1, Ljava/io/File;

    .line 16
    .line 17
    iget-object v2, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Landroid/content/Context;

    .line 20
    .line 21
    invoke-virtual {v2}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->nativeLibraryDir:Ljava/lang/String;

    .line 26
    .line 27
    invoke-direct {p1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-nez v2, :cond_1

    .line 35
    .line 36
    new-instance p2, Ljava/lang/StringBuilder;

    .line 37
    .line 38
    const-string v2, "Native library directory "

    .line 39
    .line 40
    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    const-string p1, " does not exist, exiting /data/app recovery."

    .line 47
    .line 48
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 56
    .line 57
    .line 58
    return v0

    .line 59
    :cond_1
    new-instance v2, Ljava/util/ArrayList;

    .line 60
    .line 61
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 62
    .line 63
    .line 64
    array-length v3, p2

    .line 65
    move v4, v0

    .line 66
    :goto_0
    if-ge v4, v3, :cond_6

    .line 67
    .line 68
    aget-object v5, p2, v4

    .line 69
    .line 70
    instance-of v6, v5, Lcom/facebook/soloader/b;

    .line 71
    .line 72
    if-nez v6, :cond_2

    .line 73
    .line 74
    add-int/lit8 v4, v4, 0x1

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_2
    check-cast v5, Lcom/facebook/soloader/b;

    .line 78
    .line 79
    :try_start_0
    invoke-virtual {v5}, Lcom/facebook/soloader/b;->g()[Lcom/facebook/soloader/B;

    .line 80
    .line 81
    .line 82
    move-result-object v3

    .line 83
    array-length v4, v3

    .line 84
    move v6, v0

    .line 85
    :goto_1
    if-ge v6, v4, :cond_4

    .line 86
    .line 87
    aget-object v7, v3, v6

    .line 88
    .line 89
    new-instance v8, Ljava/io/File;

    .line 90
    .line 91
    iget-object v9, v7, Lcom/facebook/soloader/B;->a:Ljava/lang/String;

    .line 92
    .line 93
    invoke-direct {v8, p1, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    .line 97
    .line 98
    .line 99
    move-result v8

    .line 100
    if-eqz v8, :cond_3

    .line 101
    .line 102
    goto :goto_2

    .line 103
    :cond_3
    iget-object v7, v7, Lcom/facebook/soloader/B;->a:Ljava/lang/String;

    .line 104
    .line 105
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    :goto_2
    add-int/lit8 v6, v6, 0x1

    .line 109
    .line 110
    goto :goto_1

    .line 111
    :catch_0
    move-exception p1

    .line 112
    goto :goto_3

    .line 113
    :cond_4
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 114
    .line 115
    .line 116
    move-result v3

    .line 117
    if-eqz v3, :cond_5

    .line 118
    .line 119
    new-instance p2, Ljava/lang/StringBuilder;

    .line 120
    .line 121
    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 122
    .line 123
    .line 124
    const-string v2, "No libraries missing from "

    .line 125
    .line 126
    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 127
    .line 128
    .line 129
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 130
    .line 131
    .line 132
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 137
    .line 138
    .line 139
    return v0

    .line 140
    :cond_5
    new-instance v3, Ljava/lang/StringBuilder;

    .line 141
    .line 142
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 143
    .line 144
    .line 145
    const-string v4, "Missing libraries from "

    .line 146
    .line 147
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 151
    .line 152
    .line 153
    const-string p1, ": "

    .line 154
    .line 155
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    .line 157
    .line 158
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 163
    .line 164
    .line 165
    const-string p1, ", will run prepare on tbe backup so source"

    .line 166
    .line 167
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 168
    .line 169
    .line 170
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object p1

    .line 174
    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 175
    .line 176
    .line 177
    invoke-virtual {v5, v0}, Lcom/facebook/soloader/b;->d(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 178
    .line 179
    .line 180
    goto :goto_5

    .line 181
    :goto_3
    const-string p2, "Encountered an exception while recovering from /data/app failure "

    .line 182
    .line 183
    invoke-static {v1, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 184
    .line 185
    .line 186
    :goto_4
    return v0

    .line 187
    :cond_6
    :goto_5
    array-length p1, p2

    .line 188
    :goto_6
    const/4 v2, 0x1

    .line 189
    if-ge v0, p1, :cond_9

    .line 190
    .line 191
    aget-object v3, p2, v0

    .line 192
    .line 193
    instance-of v4, v3, Lcom/facebook/soloader/e;

    .line 194
    .line 195
    if-nez v4, :cond_7

    .line 196
    .line 197
    goto :goto_7

    .line 198
    :cond_7
    instance-of v4, v3, Lcom/facebook/soloader/b;

    .line 199
    .line 200
    if-eqz v4, :cond_8

    .line 201
    .line 202
    goto :goto_7

    .line 203
    :cond_8
    check-cast v3, Lcom/facebook/soloader/e;

    .line 204
    .line 205
    iget v4, v3, Lcom/facebook/soloader/e;->b:I

    .line 206
    .line 207
    or-int/2addr v2, v4

    .line 208
    iput v2, v3, Lcom/facebook/soloader/e;->b:I

    .line 209
    .line 210
    :goto_7
    add-int/lit8 v0, v0, 0x1

    .line 211
    .line 212
    goto :goto_6

    .line 213
    :cond_9
    const-string p1, "Successfully recovered from /data/app disk failure."

    .line 214
    .line 215
    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 216
    .line 217
    .line 218
    return v2
.end method

.method public setCaseFirstAttribute(LU2/b;)Lcom/facebook/hermes/intl/IPlatformCollator;
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/4 v0, 0x1

    .line 6
    if-eqz p1, :cond_1

    .line 7
    .line 8
    if-eq p1, v0, :cond_0

    .line 9
    .line 10
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 13
    .line 14
    invoke-virtual {p1}, Landroid/icu/text/RuleBasedCollator;->setCaseFirstDefault()V

    .line 15
    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_0
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 21
    .line 22
    invoke-virtual {p1, v0}, Landroid/icu/text/RuleBasedCollator;->setLowerCaseFirst(Z)V

    .line 23
    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_1
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 29
    .line 30
    invoke-virtual {p1, v0}, Landroid/icu/text/RuleBasedCollator;->setUpperCaseFirst(Z)V

    .line 31
    .line 32
    .line 33
    return-object p0
.end method

.method public setIgnorePunctuation(Z)Lcom/facebook/hermes/intl/IPlatformCollator;
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    invoke-virtual {p1, v0}, Landroid/icu/text/RuleBasedCollator;->setAlternateHandlingShifted(Z)V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-object p0
.end method

.method public setNumericAttribute(Z)Lcom/facebook/hermes/intl/IPlatformCollator;
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 6
    .line 7
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-virtual {p1, v0}, Landroid/icu/text/RuleBasedCollator;->setNumericCollation(Z)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-object p0
.end method

.method public setSensitivity(LU2/c;)Lcom/facebook/hermes/intl/IPlatformCollator;
    .locals 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/4 v0, 0x0

    .line 6
    if-eqz p1, :cond_3

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    if-eq p1, v1, :cond_2

    .line 10
    .line 11
    const/4 v2, 0x2

    .line 12
    if-eq p1, v2, :cond_1

    .line 13
    .line 14
    const/4 v0, 0x3

    .line 15
    if-eq p1, v0, :cond_0

    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_0
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 21
    .line 22
    invoke-virtual {p1, v2}, Landroid/icu/text/RuleBasedCollator;->setStrength(I)V

    .line 23
    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_1
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 29
    .line 30
    invoke-virtual {p1, v0}, Landroid/icu/text/RuleBasedCollator;->setStrength(I)V

    .line 31
    .line 32
    .line 33
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 36
    .line 37
    invoke-virtual {p1, v1}, Landroid/icu/text/RuleBasedCollator;->setCaseLevel(Z)V

    .line 38
    .line 39
    .line 40
    return-object p0

    .line 41
    :cond_2
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 44
    .line 45
    invoke-virtual {p1, v1}, Landroid/icu/text/RuleBasedCollator;->setStrength(I)V

    .line 46
    .line 47
    .line 48
    return-object p0

    .line 49
    :cond_3
    iget-object p1, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p1, Landroid/icu/text/RuleBasedCollator;

    .line 52
    .line 53
    invoke-virtual {p1, v0}, Landroid/icu/text/RuleBasedCollator;->setStrength(I)V

    .line 54
    .line 55
    .line 56
    return-object p0
.end method

.method public startDifferentialMotionFling(F)Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    cmpl-float v0, p1, v0

    .line 3
    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    return p1

    .line 8
    :cond_0
    invoke-virtual {p0}, Lub/k0;->stopDifferentialMotionFling()V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Landroidx/core/widget/NestedScrollView;

    .line 14
    .line 15
    float-to-int p1, p1

    .line 16
    invoke-virtual {v0, p1}, Landroidx/core/widget/NestedScrollView;->d(I)V

    .line 17
    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    return p1
.end method

.method public stopDifferentialMotionFling()V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/k0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/core/widget/NestedScrollView;

    .line 4
    .line 5
    iget-object v0, v0, Landroidx/core/widget/NestedScrollView;->d:Landroid/widget/OverScroller;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/widget/OverScroller;->abortAnimation()V

    .line 8
    .line 9
    .line 10
    return-void
.end method
