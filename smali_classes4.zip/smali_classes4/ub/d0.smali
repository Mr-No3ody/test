.class public final synthetic Lub/d0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/d0;->a:I

    iput-object p1, p0, Lub/d0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 12

    .line 1
    const/4 p1, 0x0

    .line 2
    const-string v0, "get(...)"

    .line 3
    .line 4
    iget-object v1, p0, Lub/d0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;

    .line 5
    .line 6
    iget v2, p0, Lub/d0;->a:I

    .line 7
    .line 8
    packed-switch v2, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    iget p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->q0:I

    .line 12
    .line 13
    if-gez p1, :cond_0

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 p1, 0x1

    .line 17
    invoke-virtual {v1, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 18
    .line 19
    .line 20
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->r0:Ljava/util/ArrayList;

    .line 21
    .line 22
    iget v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->q0:I

    .line 23
    .line 24
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/SpreadInfoDto;

    .line 32
    .line 33
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/SpreadInfoDto;->getMiniRepayAmount()Ljava/lang/Long;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    new-instance v0, Lcom/transsnet/palmpay/credit/bean/other/OcInstallmentRepayExtensionBean;

    .line 38
    .line 39
    invoke-direct {v0, p1}, Lcom/transsnet/palmpay/credit/bean/other/OcInstallmentRepayExtensionBean;-><init>(Lcom/transsnet/palmpay/credit/bean/resp/SpreadInfoDto;)V

    .line 40
    .line 41
    .line 42
    new-instance v2, Lcom/transsnet/palmpay/credit/bean/req/OcOrderReq;

    .line 43
    .line 44
    iget-object v4, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->Z:Ljava/lang/String;

    .line 45
    .line 46
    iget-wide v5, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->k0:J

    .line 47
    .line 48
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    const-string p1, "21"

    .line 53
    .line 54
    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 59
    .line 60
    .line 61
    move-result-object v7

    .line 62
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    iget-object p1, p1, LPa/w;->b:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast p1, Lcom/google/gson/Gson;

    .line 69
    .line 70
    invoke-virtual {p1, v0}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v8

    .line 74
    const-string v6, "g7"

    .line 75
    .line 76
    const/4 v9, 0x0

    .line 77
    const/16 v10, 0x40

    .line 78
    .line 79
    const/4 v11, 0x0

    .line 80
    invoke-direct/range {v2 .. v11}, Lcom/transsnet/palmpay/credit/bean/req/OcOrderReq;-><init>(Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 81
    .line 82
    .line 83
    sget-object p1, Lob/c;->a:Lob/a;

    .line 84
    .line 85
    invoke-virtual {p1}, Lob/a;->getInstance()Lob/c;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    .line 91
    .line 92
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    invoke-interface {p1, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->createOcOrderV2(Lcom/transsnet/palmpay/credit/bean/req/OcOrderReq;)Ldf/d;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 101
    .line 102
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    new-instance v0, LN8/r;

    .line 115
    .line 116
    const/16 v2, 0xe

    .line 117
    .line 118
    invoke-direct {v0, v2, v1, v3}, LN8/r;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 122
    .line 123
    .line 124
    :goto_0
    return-void

    .line 125
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 126
    .line 127
    new-instance v0, LO6/c;

    .line 128
    .line 129
    invoke-direct {v0, v1}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 130
    .line 131
    .line 132
    sget v2, LYa/g;->cs_spread_dialog_title:I

    .line 133
    .line 134
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v2

    .line 138
    invoke-static {v2}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    iput-object v2, v0, LO6/c;->b:Ljava/lang/CharSequence;

    .line 143
    .line 144
    iput-boolean p1, v0, LO6/c;->k:Z

    .line 145
    .line 146
    const p1, 0x800003

    .line 147
    .line 148
    .line 149
    iput p1, v0, LO6/c;->l:I

    .line 150
    .line 151
    sget p1, LYa/g;->cs_spread_dialog_content:I

    .line 152
    .line 153
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object p1

    .line 157
    iput-object p1, v0, LO6/c;->d:Ljava/lang/CharSequence;

    .line 158
    .line 159
    sget p1, Lba/k;->core_got_it:I

    .line 160
    .line 161
    const/4 v1, 0x0

    .line 162
    invoke-virtual {v0, p1, v1}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v0}, LO6/c;->a()LO6/d;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    invoke-virtual {p1}, LO6/d;->show()V

    .line 170
    .line 171
    .line 172
    return-void

    .line 173
    :pswitch_1
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 174
    .line 175
    invoke-virtual {v1}, Landroid/app/Activity;->finish()V

    .line 176
    .line 177
    .line 178
    return-void

    .line 179
    :pswitch_2
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->t0:I

    .line 180
    .line 181
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->n()Landroidx/recyclerview/widget/RecyclerView;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 186
    .line 187
    .line 188
    move-result v0

    .line 189
    const/16 v2, 0x8

    .line 190
    .line 191
    if-ne v0, v2, :cond_1

    .line 192
    .line 193
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->p()Landroid/widget/TextView;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    sget v2, LYa/d;->cs_oc_ins_up_arrow:I

    .line 198
    .line 199
    invoke-virtual {v0, p1, p1, v2, p1}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->n()Landroidx/recyclerview/widget/RecyclerView;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 207
    .line 208
    .line 209
    goto :goto_1

    .line 210
    :cond_1
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->p()Landroid/widget/TextView;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    sget v3, LYa/d;->cs_oc_ins_down_arrow:I

    .line 215
    .line 216
    invoke-virtual {v0, p1, p1, v3, p1}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    .line 217
    .line 218
    .line 219
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->n()Landroidx/recyclerview/widget/RecyclerView;

    .line 220
    .line 221
    .line 222
    move-result-object p1

    .line 223
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 224
    .line 225
    .line 226
    :goto_1
    return-void

    .line 227
    :pswitch_3
    iget p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->q0:I

    .line 228
    .line 229
    if-ltz p1, :cond_2

    .line 230
    .line 231
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->r0:Ljava/util/ArrayList;

    .line 232
    .line 233
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 234
    .line 235
    .line 236
    move-result v3

    .line 237
    if-ge p1, v3, :cond_2

    .line 238
    .line 239
    new-instance p1, Lcom/transsnet/palmpay/credit/ui/dialog/OcRepaymentPlanDialog;

    .line 240
    .line 241
    iget v3, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentRepayActivity;->q0:I

    .line 242
    .line 243
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v2

    .line 247
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    check-cast v2, Lcom/transsnet/palmpay/credit/bean/resp/SpreadInfoDto;

    .line 251
    .line 252
    invoke-direct {p1, v1, v2}, Lcom/transsnet/palmpay/credit/ui/dialog/OcRepaymentPlanDialog;-><init>(Landroid/content/Context;Lcom/transsnet/palmpay/credit/bean/resp/SpreadInfoDto;)V

    .line 253
    .line 254
    .line 255
    invoke-virtual {p1}, LO6/f;->show()V

    .line 256
    .line 257
    .line 258
    :cond_2
    return-void

    .line 259
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
