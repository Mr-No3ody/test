.class public final synthetic Lub/J;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/J;->a:I

    iput-object p1, p0, Lub/J;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 8

    .line 1
    iget-object v0, p0, Lub/J;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/J;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 9
    .line 10
    sget v1, LYa/e;->feedback_phone_et:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/EditText;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 20
    .line 21
    sget v1, LYa/e;->feedback_et:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/EditText;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 31
    .line 32
    sget v1, LYa/e;->max_input_tip_tv:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/widget/TextView;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 42
    .line 43
    sget v1, LYa/e;->max_screen_tip_tv:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Landroid/widget/TextView;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 53
    .line 54
    sget v1, LYa/e;->selected_img_rv:I

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 61
    .line 62
    return-object v0

    .line 63
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 64
    .line 65
    sget v1, LYa/e;->feedback_submit_bt:I

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Landroid/widget/Button;

    .line 72
    .line 73
    return-object v0

    .line 74
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 75
    .line 76
    sget v1, Lba/k;->core_add:I

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    const-string v2, "getString(...)"

    .line 83
    .line 84
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    const-string v2, "context"

    .line 88
    .line 89
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    const-string v2, "doneStr"

    .line 93
    .line 94
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    new-instance v2, Lcom/luck/picture/lib/style/PictureSelectorStyle;

    .line 98
    .line 99
    invoke-direct {v2}, Lcom/luck/picture/lib/style/PictureSelectorStyle;-><init>()V

    .line 100
    .line 101
    .line 102
    new-instance v3, Lcom/luck/picture/lib/style/SelectMainStyle;

    .line 103
    .line 104
    invoke-direct {v3}, Lcom/luck/picture/lib/style/SelectMainStyle;-><init>()V

    .line 105
    .line 106
    .line 107
    const/4 v4, 0x1

    .line 108
    invoke-virtual {v3, v4}, Lcom/luck/picture/lib/style/SelectMainStyle;->setSelectNumberStyle(Z)V

    .line 109
    .line 110
    .line 111
    const/4 v5, 0x0

    .line 112
    invoke-virtual {v3, v5}, Lcom/luck/picture/lib/style/SelectMainStyle;->setPreviewSelectNumberStyle(Z)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v3, v4}, Lcom/luck/picture/lib/style/SelectMainStyle;->setPreviewDisplaySelectGallery(Z)V

    .line 116
    .line 117
    .line 118
    sget v6, Lcom/luck/picture/lib/R$drawable;->ps_default_num_selector:I

    .line 119
    .line 120
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setSelectBackground(I)V

    .line 121
    .line 122
    .line 123
    sget v6, Lcom/luck/picture/lib/R$drawable;->ps_preview_checkbox_selector:I

    .line 124
    .line 125
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setPreviewSelectBackground(I)V

    .line 126
    .line 127
    .line 128
    sget v6, Lba/d;->core_shape_rect_corner_4_purple_padding:I

    .line 129
    .line 130
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setSelectNormalBackgroundResources(I)V

    .line 131
    .line 132
    .line 133
    sget v6, Lcom/transsnet/palmpay/custom_view/p;->md_white_1000:I

    .line 134
    .line 135
    invoke-virtual {v0, v6}, Landroid/content/Context;->getColor(I)I

    .line 136
    .line 137
    .line 138
    move-result v6

    .line 139
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setSelectNormalTextColor(I)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v3, v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->setSelectNormalText(Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    sget v6, Lba/k;->core_select:I

    .line 146
    .line 147
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setPreviewSelectText(I)V

    .line 148
    .line 149
    .line 150
    const/16 v6, 0xe

    .line 151
    .line 152
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setPreviewSelectTextSize(I)V

    .line 153
    .line 154
    .line 155
    sget v6, Lcom/transsnet/palmpay/custom_view/p;->md_white_1000:I

    .line 156
    .line 157
    invoke-virtual {v0, v6}, Landroid/content/Context;->getColor(I)I

    .line 158
    .line 159
    .line 160
    move-result v6

    .line 161
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setPreviewSelectTextColor(I)V

    .line 162
    .line 163
    .line 164
    const/high16 v6, 0x40c00000    # 6.0f

    .line 165
    .line 166
    invoke-static {v0, v6}, Lcom/luck/picture/lib/utils/DensityUtil;->dip2px(Landroid/content/Context;F)I

    .line 167
    .line 168
    .line 169
    move-result v6

    .line 170
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setPreviewSelectMarginRight(I)V

    .line 171
    .line 172
    .line 173
    sget v6, Lba/d;->core_shape_rect_corner_4_purple_padding:I

    .line 174
    .line 175
    invoke-virtual {v3, v6}, Lcom/luck/picture/lib/style/SelectMainStyle;->setSelectBackgroundResources(I)V

    .line 176
    .line 177
    .line 178
    invoke-virtual {v3, v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->setSelectText(Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    sget v1, Lcom/transsnet/palmpay/custom_view/p;->md_white_1000:I

    .line 182
    .line 183
    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    .line 184
    .line 185
    .line 186
    move-result v1

    .line 187
    invoke-virtual {v3, v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->setSelectTextColor(I)V

    .line 188
    .line 189
    .line 190
    sget v1, LL6/b;->ppColorTextPrimary:I

    .line 191
    .line 192
    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    .line 193
    .line 194
    .line 195
    move-result v1

    .line 196
    invoke-virtual {v3, v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->setMainListBackgroundColor(I)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v3, v4}, Lcom/luck/picture/lib/style/SelectMainStyle;->setCompleteSelectRelativeTop(Z)V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v3, v4}, Lcom/luck/picture/lib/style/SelectMainStyle;->setPreviewSelectRelativeBottom(Z)V

    .line 203
    .line 204
    .line 205
    invoke-virtual {v3, v5}, Lcom/luck/picture/lib/style/SelectMainStyle;->setAdapterItemIncludeEdge(Z)V

    .line 206
    .line 207
    .line 208
    new-instance v1, Lcom/luck/picture/lib/style/TitleBarStyle;

    .line 209
    .line 210
    invoke-direct {v1}, Lcom/luck/picture/lib/style/TitleBarStyle;-><init>()V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v1, v4}, Lcom/luck/picture/lib/style/TitleBarStyle;->setHideCancelButton(Z)V

    .line 214
    .line 215
    .line 216
    invoke-virtual {v1, v4}, Lcom/luck/picture/lib/style/TitleBarStyle;->setAlbumTitleRelativeLeft(Z)V

    .line 217
    .line 218
    .line 219
    sget v6, Lcom/transsnet/palmpay/custom_view/r;->cv_arrow_down_black:I

    .line 220
    .line 221
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/style/TitleBarStyle;->setTitleDrawableRightResource(I)V

    .line 222
    .line 223
    .line 224
    new-instance v6, Lcom/luck/picture/lib/style/BottomNavBarStyle;

    .line 225
    .line 226
    invoke-direct {v6}, Lcom/luck/picture/lib/style/BottomNavBarStyle;-><init>()V

    .line 227
    .line 228
    .line 229
    sget v7, Lcom/transsnet/palmpay/custom_view/p;->transparent_60:I

    .line 230
    .line 231
    invoke-virtual {v0, v7}, Landroid/content/Context;->getColor(I)I

    .line 232
    .line 233
    .line 234
    move-result v7

    .line 235
    invoke-virtual {v6, v7}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->setBottomPreviewNarBarBackgroundColor(I)V

    .line 236
    .line 237
    .line 238
    const/16 v7, 0x10

    .line 239
    .line 240
    invoke-virtual {v6, v7}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->setBottomPreviewNormalTextSize(I)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v6, v5}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->setCompleteCountTips(Z)V

    .line 244
    .line 245
    .line 246
    invoke-virtual {v6, v4}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->setBottomNarBarHeight(I)V

    .line 247
    .line 248
    .line 249
    const-string v4, "  "

    .line 250
    .line 251
    invoke-virtual {v6, v4}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->setBottomPreviewNormalText(Ljava/lang/String;)V

    .line 252
    .line 253
    .line 254
    sget v5, Lcom/transsnet/palmpay/custom_view/p;->transparent:I

    .line 255
    .line 256
    invoke-virtual {v0, v5}, Landroid/content/Context;->getColor(I)I

    .line 257
    .line 258
    .line 259
    move-result v5

    .line 260
    invoke-virtual {v6, v5}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->setBottomPreviewNormalTextColor(I)V

    .line 261
    .line 262
    .line 263
    invoke-virtual {v6, v4}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->setBottomPreviewSelectText(Ljava/lang/String;)V

    .line 264
    .line 265
    .line 266
    sget v4, Lcom/transsnet/palmpay/custom_view/p;->transparent:I

    .line 267
    .line 268
    invoke-virtual {v0, v4}, Landroid/content/Context;->getColor(I)I

    .line 269
    .line 270
    .line 271
    move-result v0

    .line 272
    invoke-virtual {v6, v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->setBottomPreviewSelectTextColor(I)V

    .line 273
    .line 274
    .line 275
    invoke-virtual {v2, v1}, Lcom/luck/picture/lib/style/PictureSelectorStyle;->setTitleBarStyle(Lcom/luck/picture/lib/style/TitleBarStyle;)V

    .line 276
    .line 277
    .line 278
    invoke-virtual {v2, v6}, Lcom/luck/picture/lib/style/PictureSelectorStyle;->setBottomBarStyle(Lcom/luck/picture/lib/style/BottomNavBarStyle;)V

    .line 279
    .line 280
    .line 281
    invoke-virtual {v2, v3}, Lcom/luck/picture/lib/style/PictureSelectorStyle;->setSelectMainStyle(Lcom/luck/picture/lib/style/SelectMainStyle;)V

    .line 282
    .line 283
    .line 284
    return-object v2

    .line 285
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 286
    .line 287
    sget v1, LYa/e;->oc_feedback_mtb:I

    .line 288
    .line 289
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 290
    .line 291
    .line 292
    move-result-object v0

    .line 293
    check-cast v0, Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 294
    .line 295
    return-object v0

    .line 296
    nop

    .line 297
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
