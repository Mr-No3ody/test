.class public final Lub/m1;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/m1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/m1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    const-string v0, "message"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/m1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 10
    .line 11
    .line 12
    new-array v0, v1, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 18

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    check-cast v2, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp;

    .line 6
    .line 7
    move-object/from16 v3, p0

    .line 8
    .line 9
    iget-object v4, v3, Lub/m1;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 10
    .line 11
    invoke-virtual {v4, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 12
    .line 13
    .line 14
    if-nez v2, :cond_0

    .line 15
    .line 16
    sget v0, LYa/g;->cs_cl_service_busy:I

    .line 17
    .line 18
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    new-array v1, v1, [Ljava/lang/Object;

    .line 23
    .line 24
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    if-eqz v5, :cond_31

    .line 33
    .line 34
    iget-object v5, v2, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp;->data:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;

    .line 35
    .line 36
    if-eqz v5, :cond_31

    .line 37
    .line 38
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->o:I

    .line 39
    .line 40
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->r()Landroid/widget/LinearLayout;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    invoke-virtual {v2}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->s()Landroid/widget/LinearLayout;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    invoke-virtual {v2}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    iget v6, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->status:I

    .line 59
    .line 60
    const/4 v7, 0x0

    .line 61
    const/4 v8, 0x7

    .line 62
    const/4 v9, 0x6

    .line 63
    const/4 v10, 0x2

    .line 64
    const/4 v11, 0x3

    .line 65
    const/4 v12, 0x0

    .line 66
    if-eq v6, v0, :cond_2

    .line 67
    .line 68
    if-eq v6, v10, :cond_1

    .line 69
    .line 70
    if-eq v6, v11, :cond_2

    .line 71
    .line 72
    if-eq v6, v9, :cond_2

    .line 73
    .line 74
    if-eq v6, v8, :cond_1

    .line 75
    .line 76
    sget-object v6, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->A:Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;

    .line 77
    .line 78
    invoke-static {v6, v4, v12, v10, v7}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;->processingIcon$default(Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;Landroid/content/Context;FILjava/lang/Object;)Landroid/graphics/drawable/Drawable;

    .line 79
    .line 80
    .line 81
    move-result-object v6

    .line 82
    goto :goto_0

    .line 83
    :cond_1
    sget-object v6, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->A:Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;

    .line 84
    .line 85
    invoke-static {v6, v4, v12, v10, v7}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;->failIcon$default(Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;Landroid/content/Context;FILjava/lang/Object;)Landroid/graphics/drawable/Drawable;

    .line 86
    .line 87
    .line 88
    move-result-object v6

    .line 89
    goto :goto_0

    .line 90
    :cond_2
    sget-object v6, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->A:Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;

    .line 91
    .line 92
    invoke-static {v6, v4, v12, v10, v7}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;->successIcon$default(Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel$a;Landroid/content/Context;FILjava/lang/Object;)Landroid/graphics/drawable/Drawable;

    .line 93
    .line 94
    .line 95
    move-result-object v6

    .line 96
    :goto_0
    invoke-virtual {v2, v6}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->l(Landroid/graphics/drawable/Drawable;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    iget-object v6, v4, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->i:Ljava/lang/String;

    .line 104
    .line 105
    const-string v12, "g7"

    .line 106
    .line 107
    const-string v13, "j7"

    .line 108
    .line 109
    const/16 v14, 0xd0d

    .line 110
    .line 111
    const/16 v15, 0xd0c

    .line 112
    .line 113
    const/16 v7, 0xcb0

    .line 114
    .line 115
    const-string v1, "getString(...)"

    .line 116
    .line 117
    const-string v8, "j6"

    .line 118
    .line 119
    if-eqz v6, :cond_9

    .line 120
    .line 121
    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    .line 122
    .line 123
    .line 124
    move-result v9

    .line 125
    if-eq v9, v7, :cond_7

    .line 126
    .line 127
    if-eq v9, v15, :cond_5

    .line 128
    .line 129
    if-eq v9, v14, :cond_3

    .line 130
    .line 131
    goto :goto_1

    .line 132
    :cond_3
    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v6

    .line 136
    if-nez v6, :cond_4

    .line 137
    .line 138
    goto :goto_1

    .line 139
    :cond_4
    sget v6, Lba/k;->core_cl_repay:I

    .line 140
    .line 141
    invoke-virtual {v4, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v6

    .line 145
    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    goto :goto_2

    .line 149
    :cond_5
    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 150
    .line 151
    .line 152
    move-result v6

    .line 153
    if-nez v6, :cond_6

    .line 154
    .line 155
    goto :goto_1

    .line 156
    :cond_6
    sget v6, Lba/k;->core_cl_disbursement:I

    .line 157
    .line 158
    invoke-virtual {v4, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v6

    .line 162
    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    goto :goto_2

    .line 166
    :cond_7
    invoke-virtual {v6, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result v6

    .line 170
    if-nez v6, :cond_8

    .line 171
    .line 172
    goto :goto_1

    .line 173
    :cond_8
    sget v6, Lba/k;->core_oc_repay:I

    .line 174
    .line 175
    invoke-virtual {v4, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v6

    .line 179
    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 180
    .line 181
    .line 182
    goto :goto_2

    .line 183
    :cond_9
    :goto_1
    sget v6, Lba/k;->core_oc_cl_repay:I

    .line 184
    .line 185
    invoke-virtual {v4, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 186
    .line 187
    .line 188
    move-result-object v6

    .line 189
    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    :goto_2
    invoke-virtual {v2, v6}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->o(Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 196
    .line 197
    .line 198
    move-result-object v2

    .line 199
    iget-object v6, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 200
    .line 201
    iget-wide v10, v6, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->transAmount:J

    .line 202
    .line 203
    invoke-static {v10, v11, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v6

    .line 207
    invoke-virtual {v2, v6}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->c(Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 211
    .line 212
    .line 213
    move-result-object v2

    .line 214
    iget-object v6, v4, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->i:Ljava/lang/String;

    .line 215
    .line 216
    if-eqz v6, :cond_10

    .line 217
    .line 218
    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    .line 219
    .line 220
    .line 221
    move-result v10

    .line 222
    if-eq v10, v7, :cond_e

    .line 223
    .line 224
    if-eq v10, v15, :cond_c

    .line 225
    .line 226
    if-eq v10, v14, :cond_a

    .line 227
    .line 228
    goto :goto_3

    .line 229
    :cond_a
    invoke-virtual {v6, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 230
    .line 231
    .line 232
    move-result v6

    .line 233
    if-nez v6, :cond_b

    .line 234
    .line 235
    goto :goto_3

    .line 236
    :cond_b
    sget v6, LYa/d;->cv_cl_cash_loan_repay:I

    .line 237
    .line 238
    goto :goto_4

    .line 239
    :cond_c
    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 240
    .line 241
    .line 242
    move-result v6

    .line 243
    if-nez v6, :cond_d

    .line 244
    .line 245
    goto :goto_3

    .line 246
    :cond_d
    sget v6, LYa/d;->cv_cl_cash_loan_borrow:I

    .line 247
    .line 248
    goto :goto_4

    .line 249
    :cond_e
    invoke-virtual {v6, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 250
    .line 251
    .line 252
    move-result v6

    .line 253
    if-nez v6, :cond_f

    .line 254
    .line 255
    goto :goto_3

    .line 256
    :cond_f
    sget v6, Lcom/transsnet/palmpay/custom_view/r;->cv_ok_card_icon:I

    .line 257
    .line 258
    goto :goto_4

    .line 259
    :cond_10
    :goto_3
    sget v6, Lcom/transsnet/palmpay/custom_view/r;->cv_ok_card_icon:I

    .line 260
    .line 261
    :goto_4
    invoke-virtual {v2, v6}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->d(I)V

    .line 262
    .line 263
    .line 264
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 265
    .line 266
    .line 267
    move-result-object v2

    .line 268
    iget v6, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->status:I

    .line 269
    .line 270
    if-eq v6, v0, :cond_12

    .line 271
    .line 272
    const/4 v9, 0x2

    .line 273
    if-eq v6, v9, :cond_11

    .line 274
    .line 275
    const/4 v7, 0x3

    .line 276
    if-eq v6, v7, :cond_12

    .line 277
    .line 278
    const/4 v7, 0x6

    .line 279
    if-eq v6, v7, :cond_12

    .line 280
    .line 281
    const/4 v7, 0x7

    .line 282
    if-eq v6, v7, :cond_11

    .line 283
    .line 284
    sget v6, Lba/k;->core_pending:I

    .line 285
    .line 286
    invoke-virtual {v4, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 287
    .line 288
    .line 289
    move-result-object v6

    .line 290
    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 291
    .line 292
    .line 293
    goto :goto_5

    .line 294
    :cond_11
    sget v6, Lba/k;->core_failed:I

    .line 295
    .line 296
    invoke-virtual {v4, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 297
    .line 298
    .line 299
    move-result-object v6

    .line 300
    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 301
    .line 302
    .line 303
    goto :goto_5

    .line 304
    :cond_12
    sget v6, Lba/k;->core_successful:I

    .line 305
    .line 306
    invoke-virtual {v4, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 307
    .line 308
    .line 309
    move-result-object v6

    .line 310
    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    :goto_5
    invoke-virtual {v2, v6}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->k(Ljava/lang/String;)V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 317
    .line 318
    .line 319
    move-result-object v1

    .line 320
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusArrow()Landroid/widget/ImageView;

    .line 321
    .line 322
    .line 323
    move-result-object v1

    .line 324
    iget-object v2, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 325
    .line 326
    if-nez v2, :cond_13

    .line 327
    .line 328
    const/16 v2, 0x8

    .line 329
    .line 330
    goto :goto_6

    .line 331
    :cond_13
    const/4 v2, 0x0

    .line 332
    :goto_6
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 336
    .line 337
    .line 338
    move-result-object v1

    .line 339
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusLayout()Landroid/widget/LinearLayout;

    .line 340
    .line 341
    .line 342
    move-result-object v1

    .line 343
    iget-object v2, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 344
    .line 345
    if-eqz v2, :cond_14

    .line 346
    .line 347
    move v2, v0

    .line 348
    goto :goto_7

    .line 349
    :cond_14
    const/4 v2, 0x0

    .line 350
    :goto_7
    invoke-virtual {v1, v2}, Landroid/view/View;->setEnabled(Z)V

    .line 351
    .line 352
    .line 353
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 354
    .line 355
    .line 356
    move-result-object v1

    .line 357
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->getOrderStatusLayout()Landroid/widget/LinearLayout;

    .line 358
    .line 359
    .line 360
    move-result-object v1

    .line 361
    new-instance v2, Lub/k1;

    .line 362
    .line 363
    const/4 v6, 0x0

    .line 364
    invoke-direct {v2, v4, v5, v6}, Lub/k1;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;I)V

    .line 365
    .line 366
    .line 367
    invoke-static {v2, v1}, Loa/h;->l(Landroid/view/View$OnClickListener;Landroid/view/View;)V

    .line 368
    .line 369
    .line 370
    iget-object v1, v4, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 371
    .line 372
    iget-object v2, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->transType:Ljava/lang/String;

    .line 373
    .line 374
    const-string v6, "transType = "

    .line 375
    .line 376
    invoke-static {v6, v2}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 377
    .line 378
    .line 379
    move-result-object v2

    .line 380
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 381
    .line 382
    .line 383
    move-result-object v2

    .line 384
    const/4 v7, 0x3

    .line 385
    invoke-static {v1, v7, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 386
    .line 387
    .line 388
    iget-object v1, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->transType:Ljava/lang/String;

    .line 389
    .line 390
    invoke-static {v1, v8}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 391
    .line 392
    .line 393
    move-result v1

    .line 394
    const/16 v2, 0x3ea

    .line 395
    .line 396
    const/16 v6, 0x3eb

    .line 397
    .line 398
    const-string v7, "- "

    .line 399
    .line 400
    const-wide/16 v8, 0x0

    .line 401
    .line 402
    if-eqz v1, :cond_1d

    .line 403
    .line 404
    sget v1, Lcom/transsnet/palmpay/custom_view/v;->cv_loan_amount:I

    .line 405
    .line 406
    invoke-virtual {v4, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 407
    .line 408
    .line 409
    move-result-object v1

    .line 410
    iget-object v10, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 411
    .line 412
    if-eqz v10, :cond_15

    .line 413
    .line 414
    iget-wide v10, v10, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->amount:J

    .line 415
    .line 416
    goto :goto_8

    .line 417
    :cond_15
    move-wide v10, v8

    .line 418
    :goto_8
    invoke-static {v10, v11, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 419
    .line 420
    .line 421
    move-result-object v10

    .line 422
    invoke-static {v10}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 423
    .line 424
    .line 425
    move-result-object v10

    .line 426
    const/4 v11, 0x0

    .line 427
    const/4 v12, 0x0

    .line 428
    invoke-virtual {v4, v1, v10, v12, v11}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->n(Ljava/lang/String;Ljava/lang/CharSequence;ZLandroid/view/View$OnClickListener;)Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle1;

    .line 429
    .line 430
    .line 431
    iget-wide v10, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->stampDuty:J

    .line 432
    .line 433
    cmp-long v1, v10, v8

    .line 434
    .line 435
    if-lez v1, :cond_16

    .line 436
    .line 437
    invoke-static {v10, v11, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 438
    .line 439
    .line 440
    move-result-object v1

    .line 441
    sget v10, LYa/g;->cs_cl_stamp_duty_title:I

    .line 442
    .line 443
    invoke-virtual {v4, v10}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 444
    .line 445
    .line 446
    move-result-object v10

    .line 447
    invoke-static {v7, v1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v1

    .line 451
    new-instance v11, Lub/k1;

    .line 452
    .line 453
    invoke-direct {v11, v4, v5, v0}, Lub/k1;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;I)V

    .line 454
    .line 455
    .line 456
    invoke-virtual {v4, v10, v1, v0, v11}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->n(Ljava/lang/String;Ljava/lang/CharSequence;ZLandroid/view/View$OnClickListener;)Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle1;

    .line 457
    .line 458
    .line 459
    :cond_16
    iget-object v1, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 460
    .line 461
    if-eqz v1, :cond_17

    .line 462
    .line 463
    iget-wide v10, v1, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->couponAmount:J

    .line 464
    .line 465
    goto :goto_9

    .line 466
    :cond_17
    move-wide v10, v8

    .line 467
    :goto_9
    cmp-long v1, v10, v8

    .line 468
    .line 469
    if-lez v1, :cond_19

    .line 470
    .line 471
    sget v1, Lba/k;->core_coupon:I

    .line 472
    .line 473
    invoke-virtual {v4, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 474
    .line 475
    .line 476
    move-result-object v1

    .line 477
    iget-object v10, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 478
    .line 479
    if-eqz v10, :cond_18

    .line 480
    .line 481
    iget-wide v10, v10, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->couponAmount:J

    .line 482
    .line 483
    goto :goto_a

    .line 484
    :cond_18
    move-wide v10, v8

    .line 485
    :goto_a
    invoke-static {v10, v11, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 486
    .line 487
    .line 488
    move-result-object v10

    .line 489
    invoke-static {v7, v10}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 490
    .line 491
    .line 492
    move-result-object v10

    .line 493
    const/4 v11, 0x0

    .line 494
    const/4 v12, 0x0

    .line 495
    invoke-virtual {v4, v1, v10, v12, v11}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->n(Ljava/lang/String;Ljava/lang/CharSequence;ZLandroid/view/View$OnClickListener;)Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle1;

    .line 496
    .line 497
    .line 498
    :cond_19
    iget-object v1, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->extensionInfo:Ljava/lang/String;

    .line 499
    .line 500
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 501
    .line 502
    .line 503
    move-result v1

    .line 504
    if-nez v1, :cond_1a

    .line 505
    .line 506
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 507
    .line 508
    .line 509
    move-result-object v1

    .line 510
    iget-object v10, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->extensionInfo:Ljava/lang/String;

    .line 511
    .line 512
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 513
    .line 514
    .line 515
    const-class v1, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$ExtensionInfo;

    .line 516
    .line 517
    invoke-static {v10, v1}, LPa/w;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 518
    .line 519
    .line 520
    move-result-object v1

    .line 521
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$ExtensionInfo;

    .line 522
    .line 523
    if-eqz v1, :cond_1a

    .line 524
    .line 525
    iget-boolean v10, v1, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$ExtensionInfo;->whetherManagementFee:Z

    .line 526
    .line 527
    if-ne v10, v0, :cond_1a

    .line 528
    .line 529
    iget-wide v10, v1, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$ExtensionInfo;->managementFee:J

    .line 530
    .line 531
    sget v1, Lcom/transsnet/palmpay/custom_view/v;->cv_management_fee:I

    .line 532
    .line 533
    invoke-virtual {v4, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 534
    .line 535
    .line 536
    move-result-object v1

    .line 537
    invoke-static {v10, v11, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 538
    .line 539
    .line 540
    move-result-object v12

    .line 541
    invoke-static {v7, v12}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 542
    .line 543
    .line 544
    move-result-object v7

    .line 545
    const/4 v12, 0x0

    .line 546
    const/4 v13, 0x0

    .line 547
    invoke-virtual {v4, v1, v7, v13, v12}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->n(Ljava/lang/String;Ljava/lang/CharSequence;ZLandroid/view/View$OnClickListener;)Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle1;

    .line 548
    .line 549
    .line 550
    goto :goto_b

    .line 551
    :cond_1a
    move-wide v10, v8

    .line 552
    :goto_b
    invoke-static {v10, v11}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 553
    .line 554
    .line 555
    move-result-object v1

    .line 556
    iget-wide v10, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->stampDuty:J

    .line 557
    .line 558
    invoke-static {v10, v11}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 559
    .line 560
    .line 561
    move-result-object v7

    .line 562
    invoke-static {v1, v7}, LPa/r0;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/math/BigDecimal;

    .line 563
    .line 564
    .line 565
    move-result-object v1

    .line 566
    sget v7, Lba/k;->core_receive_amount:I

    .line 567
    .line 568
    invoke-virtual {v4, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 569
    .line 570
    .line 571
    move-result-object v7

    .line 572
    iget-object v10, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 573
    .line 574
    if-eqz v10, :cond_1b

    .line 575
    .line 576
    iget-wide v10, v10, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->transAmount:J

    .line 577
    .line 578
    goto :goto_c

    .line 579
    :cond_1b
    move-wide v10, v8

    .line 580
    :goto_c
    invoke-static {v10, v11}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 581
    .line 582
    .line 583
    move-result-object v10

    .line 584
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 585
    .line 586
    .line 587
    move-result-object v11

    .line 588
    invoke-static {v10, v11}, LPa/r0;->U1(Ljava/lang/String;Ljava/lang/String;)Ljava/math/BigDecimal;

    .line 589
    .line 590
    .line 591
    move-result-object v10

    .line 592
    invoke-virtual {v10}, Ljava/math/BigDecimal;->longValueExact()J

    .line 593
    .line 594
    .line 595
    move-result-wide v10

    .line 596
    invoke-static {v10, v11, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 597
    .line 598
    .line 599
    move-result-object v10

    .line 600
    new-instance v11, Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle2;

    .line 601
    .line 602
    invoke-direct {v11, v4, v7, v10}, Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle2;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 603
    .line 604
    .line 605
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->s()Landroid/widget/LinearLayout;

    .line 606
    .line 607
    .line 608
    move-result-object v7

    .line 609
    invoke-virtual {v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 610
    .line 611
    .line 612
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->t()Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;

    .line 613
    .line 614
    .line 615
    move-result-object v7

    .line 616
    iget-object v10, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 617
    .line 618
    if-eqz v10, :cond_1c

    .line 619
    .line 620
    iget-wide v8, v10, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->transAmount:J

    .line 621
    .line 622
    :cond_1c
    invoke-static {v8, v9}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 623
    .line 624
    .line 625
    move-result-object v8

    .line 626
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 627
    .line 628
    .line 629
    move-result-object v1

    .line 630
    invoke-static {v8, v1}, LPa/r0;->U1(Ljava/lang/String;Ljava/lang/String;)Ljava/math/BigDecimal;

    .line 631
    .line 632
    .line 633
    move-result-object v1

    .line 634
    invoke-virtual {v1}, Ljava/math/BigDecimal;->longValueExact()J

    .line 635
    .line 636
    .line 637
    move-result-wide v8

    .line 638
    invoke-static {v8, v9, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 639
    .line 640
    .line 641
    move-result-object v0

    .line 642
    invoke-virtual {v7, v0}, Lcom/transsnet/palmpay/custom_view/model/OrderResultHeaderModel;->c(Ljava/lang/String;)V

    .line 643
    .line 644
    .line 645
    sget v0, Lba/k;->core_receipt_transaction_type:I

    .line 646
    .line 647
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 648
    .line 649
    .line 650
    move-result-object v0

    .line 651
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->v()Ljava/lang/String;

    .line 652
    .line 653
    .line 654
    move-result-object v1

    .line 655
    invoke-virtual {v4, v1, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->p(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 656
    .line 657
    .line 658
    sget v0, Lba/k;->core_receive_account:I

    .line 659
    .line 660
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 661
    .line 662
    .line 663
    move-result-object v0

    .line 664
    sget v1, Lba/k;->core_palmpay_payment_balance:I

    .line 665
    .line 666
    invoke-virtual {v4, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 667
    .line 668
    .line 669
    move-result-object v1

    .line 670
    invoke-virtual {v4, v1, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->p(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 671
    .line 672
    .line 673
    sget v0, Lba/k;->core_reference_no_2:I

    .line 674
    .line 675
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 676
    .line 677
    .line 678
    move-result-object v0

    .line 679
    iget-object v1, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->orderId:Ljava/lang/String;

    .line 680
    .line 681
    invoke-virtual {v4, v1, v6, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->p(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 682
    .line 683
    .line 684
    sget v0, Lba/k;->core_completion_time:I

    .line 685
    .line 686
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 687
    .line 688
    .line 689
    move-result-object v0

    .line 690
    iget-wide v5, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->updateTime:J

    .line 691
    .line 692
    invoke-static {v5, v6}, LPa/r0;->R(J)Ljava/lang/String;

    .line 693
    .line 694
    .line 695
    move-result-object v1

    .line 696
    invoke-virtual {v4, v1, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->p(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 697
    .line 698
    .line 699
    :goto_d
    const/4 v15, 0x0

    .line 700
    goto/16 :goto_17

    .line 701
    .line 702
    :cond_1d
    iget-object v1, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 703
    .line 704
    if-eqz v1, :cond_1e

    .line 705
    .line 706
    iget-wide v10, v1, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->couponAmount:J

    .line 707
    .line 708
    goto :goto_e

    .line 709
    :cond_1e
    move-wide v10, v8

    .line 710
    :goto_e
    iget-wide v12, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->payerStampDuty:J

    .line 711
    .line 712
    cmp-long v1, v12, v8

    .line 713
    .line 714
    if-gtz v1, :cond_20

    .line 715
    .line 716
    iget-wide v12, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->payeeStampDuty:J

    .line 717
    .line 718
    cmp-long v1, v12, v8

    .line 719
    .line 720
    if-lez v1, :cond_1f

    .line 721
    .line 722
    goto :goto_f

    .line 723
    :cond_1f
    const/4 v1, 0x0

    .line 724
    goto :goto_10

    .line 725
    :cond_20
    :goto_f
    move v1, v0

    .line 726
    :goto_10
    cmp-long v12, v10, v8

    .line 727
    .line 728
    if-gtz v12, :cond_24

    .line 729
    .line 730
    if-eqz v1, :cond_21

    .line 731
    .line 732
    goto :goto_12

    .line 733
    :cond_21
    sget v0, Lba/k;->core_receipt_transaction_type:I

    .line 734
    .line 735
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 736
    .line 737
    .line 738
    move-result-object v0

    .line 739
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->v()Ljava/lang/String;

    .line 740
    .line 741
    .line 742
    move-result-object v1

    .line 743
    invoke-virtual {v4, v1, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->q(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 744
    .line 745
    .line 746
    invoke-virtual {v4, v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->u(Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;)Ljava/lang/String;

    .line 747
    .line 748
    .line 749
    move-result-object v11

    .line 750
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 751
    .line 752
    .line 753
    move-result v0

    .line 754
    if-nez v0, :cond_22

    .line 755
    .line 756
    goto :goto_11

    .line 757
    :cond_22
    const/4 v11, 0x0

    .line 758
    :goto_11
    if-eqz v11, :cond_23

    .line 759
    .line 760
    sget v0, Lba/k;->core_payment_method:I

    .line 761
    .line 762
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 763
    .line 764
    .line 765
    move-result-object v0

    .line 766
    invoke-virtual {v4, v11, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->q(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 767
    .line 768
    .line 769
    :cond_23
    sget v0, Lba/k;->core_reference_no_2:I

    .line 770
    .line 771
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 772
    .line 773
    .line 774
    move-result-object v0

    .line 775
    iget-object v1, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->orderId:Ljava/lang/String;

    .line 776
    .line 777
    invoke-virtual {v4, v1, v6, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->q(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 778
    .line 779
    .line 780
    sget v0, Lba/k;->core_completion_time:I

    .line 781
    .line 782
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 783
    .line 784
    .line 785
    move-result-object v0

    .line 786
    iget-wide v5, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->updateTime:J

    .line 787
    .line 788
    invoke-static {v5, v6}, LPa/r0;->R(J)Ljava/lang/String;

    .line 789
    .line 790
    .line 791
    move-result-object v1

    .line 792
    invoke-virtual {v4, v1, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->q(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 793
    .line 794
    .line 795
    goto :goto_d

    .line 796
    :cond_24
    :goto_12
    sget v13, Lcom/transsnet/palmpay/custom_view/v;->cv_amount:I

    .line 797
    .line 798
    invoke-virtual {v4, v13}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 799
    .line 800
    .line 801
    move-result-object v13

    .line 802
    iget-object v14, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 803
    .line 804
    if-eqz v14, :cond_25

    .line 805
    .line 806
    iget-wide v14, v14, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->amount:J

    .line 807
    .line 808
    goto :goto_13

    .line 809
    :cond_25
    move-wide v14, v8

    .line 810
    :goto_13
    invoke-static {v14, v15, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 811
    .line 812
    .line 813
    move-result-object v14

    .line 814
    invoke-static {v14}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 815
    .line 816
    .line 817
    move-result-object v14

    .line 818
    move-wide/from16 v16, v8

    .line 819
    .line 820
    const/4 v8, 0x0

    .line 821
    const/4 v15, 0x0

    .line 822
    invoke-virtual {v4, v13, v14, v8, v15}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->n(Ljava/lang/String;Ljava/lang/CharSequence;ZLandroid/view/View$OnClickListener;)Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle1;

    .line 823
    .line 824
    .line 825
    if-lez v12, :cond_26

    .line 826
    .line 827
    sget v9, Lba/k;->core_coupon:I

    .line 828
    .line 829
    invoke-virtual {v4, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 830
    .line 831
    .line 832
    move-result-object v9

    .line 833
    invoke-static {v10, v11, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 834
    .line 835
    .line 836
    move-result-object v10

    .line 837
    invoke-static {v7, v10}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 838
    .line 839
    .line 840
    move-result-object v7

    .line 841
    invoke-virtual {v4, v9, v7, v8, v15}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->n(Ljava/lang/String;Ljava/lang/CharSequence;ZLandroid/view/View$OnClickListener;)Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle1;

    .line 842
    .line 843
    .line 844
    :cond_26
    if-eqz v1, :cond_29

    .line 845
    .line 846
    iget-wide v7, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->payerStampDuty:J

    .line 847
    .line 848
    invoke-static {v7, v8, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 849
    .line 850
    .line 851
    move-result-object v1

    .line 852
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->payerStampDutyText:Ljava/lang/String;

    .line 853
    .line 854
    if-nez v7, :cond_27

    .line 855
    .line 856
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->payeeStampDutyText:Ljava/lang/String;

    .line 857
    .line 858
    :cond_27
    iget-wide v8, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->payeeStampDuty:J

    .line 859
    .line 860
    cmp-long v10, v8, v16

    .line 861
    .line 862
    if-lez v10, :cond_28

    .line 863
    .line 864
    invoke-static {v8, v9, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 865
    .line 866
    .line 867
    move-result-object v8

    .line 868
    new-instance v9, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 869
    .line 870
    invoke-direct {v9}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 871
    .line 872
    .line 873
    invoke-virtual {v9, v8}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 874
    .line 875
    .line 876
    move-result-object v8

    .line 877
    invoke-virtual {v8}, Lcom/transsnet/palmpay/util/SpanUtils;->setStrikethrough()Lcom/transsnet/palmpay/util/SpanUtils;

    .line 878
    .line 879
    .line 880
    move-result-object v8

    .line 881
    const-string v9, "  "

    .line 882
    .line 883
    invoke-virtual {v8, v9}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 884
    .line 885
    .line 886
    move-result-object v8

    .line 887
    invoke-virtual {v8, v1}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 888
    .line 889
    .line 890
    move-result-object v1

    .line 891
    invoke-virtual {v1}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 892
    .line 893
    .line 894
    move-result-object v1

    .line 895
    const-string v8, "create(...)"

    .line 896
    .line 897
    invoke-static {v1, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 898
    .line 899
    .line 900
    sget v8, LYa/g;->cs_cl_stamp_duty_title:I

    .line 901
    .line 902
    invoke-virtual {v4, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 903
    .line 904
    .line 905
    move-result-object v8

    .line 906
    new-instance v9, Lub/j1;

    .line 907
    .line 908
    invoke-direct {v9, v4, v7, v0}, Lub/j1;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;Ljava/lang/String;I)V

    .line 909
    .line 910
    .line 911
    invoke-virtual {v4, v8, v1, v0, v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->n(Ljava/lang/String;Ljava/lang/CharSequence;ZLandroid/view/View$OnClickListener;)Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle1;

    .line 912
    .line 913
    .line 914
    goto :goto_14

    .line 915
    :cond_28
    sget v8, LYa/g;->cs_cl_stamp_duty_title:I

    .line 916
    .line 917
    invoke-virtual {v4, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 918
    .line 919
    .line 920
    move-result-object v8

    .line 921
    new-instance v9, Lub/j1;

    .line 922
    .line 923
    const/4 v12, 0x0

    .line 924
    invoke-direct {v9, v4, v7, v12}, Lub/j1;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;Ljava/lang/String;I)V

    .line 925
    .line 926
    .line 927
    invoke-virtual {v4, v8, v1, v0, v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->n(Ljava/lang/String;Ljava/lang/CharSequence;ZLandroid/view/View$OnClickListener;)Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle1;

    .line 928
    .line 929
    .line 930
    :cond_29
    :goto_14
    sget v1, Lba/k;->core_total:I

    .line 931
    .line 932
    invoke-virtual {v4, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 933
    .line 934
    .line 935
    move-result-object v1

    .line 936
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->amountInfo:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;

    .line 937
    .line 938
    if-eqz v7, :cond_2a

    .line 939
    .line 940
    iget-wide v8, v7, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean$AmountInfoBean;->transAmount:J

    .line 941
    .line 942
    goto :goto_15

    .line 943
    :cond_2a
    move-wide/from16 v8, v16

    .line 944
    .line 945
    :goto_15
    invoke-static {v8, v9, v0}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 946
    .line 947
    .line 948
    move-result-object v0

    .line 949
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 950
    .line 951
    .line 952
    move-result-object v0

    .line 953
    new-instance v7, Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle2;

    .line 954
    .line 955
    invoke-direct {v7, v4, v1, v0}, Lcom/transsnet/palmpay/custom_view/model/OrderResultAmountStyle2;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    .line 956
    .line 957
    .line 958
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->s()Landroid/widget/LinearLayout;

    .line 959
    .line 960
    .line 961
    move-result-object v0

    .line 962
    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 963
    .line 964
    .line 965
    sget v0, Lba/k;->core_receipt_transaction_type:I

    .line 966
    .line 967
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 968
    .line 969
    .line 970
    move-result-object v0

    .line 971
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->v()Ljava/lang/String;

    .line 972
    .line 973
    .line 974
    move-result-object v1

    .line 975
    invoke-virtual {v4, v1, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->p(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 976
    .line 977
    .line 978
    invoke-virtual {v4, v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->u(Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;)Ljava/lang/String;

    .line 979
    .line 980
    .line 981
    move-result-object v11

    .line 982
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 983
    .line 984
    .line 985
    move-result v0

    .line 986
    if-nez v0, :cond_2b

    .line 987
    .line 988
    goto :goto_16

    .line 989
    :cond_2b
    move-object v11, v15

    .line 990
    :goto_16
    if-eqz v11, :cond_2c

    .line 991
    .line 992
    sget v0, Lba/k;->core_payment_method:I

    .line 993
    .line 994
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 995
    .line 996
    .line 997
    move-result-object v0

    .line 998
    invoke-virtual {v4, v11, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->p(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 999
    .line 1000
    .line 1001
    :cond_2c
    sget v0, Lba/k;->core_reference_no_2:I

    .line 1002
    .line 1003
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1004
    .line 1005
    .line 1006
    move-result-object v0

    .line 1007
    iget-object v1, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->orderId:Ljava/lang/String;

    .line 1008
    .line 1009
    invoke-virtual {v4, v1, v6, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->p(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 1010
    .line 1011
    .line 1012
    sget v0, Lba/k;->core_completion_time:I

    .line 1013
    .line 1014
    invoke-virtual {v4, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1015
    .line 1016
    .line 1017
    move-result-object v0

    .line 1018
    iget-wide v5, v5, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->updateTime:J

    .line 1019
    .line 1020
    invoke-static {v5, v6}, LPa/r0;->R(J)Ljava/lang/String;

    .line 1021
    .line 1022
    .line 1023
    move-result-object v1

    .line 1024
    invoke-virtual {v4, v1, v2, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->p(Ljava/lang/CharSequence;ILjava/lang/String;)Lcom/transsnet/palmpay/custom_view/model/OrderResultItemModel;

    .line 1025
    .line 1026
    .line 1027
    :goto_17
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->r()Landroid/widget/LinearLayout;

    .line 1028
    .line 1029
    .line 1030
    move-result-object v0

    .line 1031
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 1032
    .line 1033
    .line 1034
    move-result v0

    .line 1035
    if-nez v0, :cond_30

    .line 1036
    .line 1037
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->s()Landroid/widget/LinearLayout;

    .line 1038
    .line 1039
    .line 1040
    move-result-object v0

    .line 1041
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v0

    .line 1045
    instance-of v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 1046
    .line 1047
    if-eqz v1, :cond_2d

    .line 1048
    .line 1049
    move-object v11, v0

    .line 1050
    check-cast v11, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 1051
    .line 1052
    goto :goto_18

    .line 1053
    :cond_2d
    move-object v11, v15

    .line 1054
    :goto_18
    if-eqz v11, :cond_2e

    .line 1055
    .line 1056
    const/4 v12, 0x0

    .line 1057
    iput v12, v11, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 1058
    .line 1059
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->s()Landroid/widget/LinearLayout;

    .line 1060
    .line 1061
    .line 1062
    move-result-object v0

    .line 1063
    invoke-virtual {v0, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1064
    .line 1065
    .line 1066
    :cond_2e
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->r()Landroid/widget/LinearLayout;

    .line 1067
    .line 1068
    .line 1069
    move-result-object v0

    .line 1070
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 1071
    .line 1072
    .line 1073
    move-result-object v0

    .line 1074
    instance-of v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 1075
    .line 1076
    if-eqz v1, :cond_2f

    .line 1077
    .line 1078
    move-object v7, v0

    .line 1079
    check-cast v7, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 1080
    .line 1081
    goto :goto_19

    .line 1082
    :cond_2f
    move-object v7, v15

    .line 1083
    :goto_19
    if-eqz v7, :cond_30

    .line 1084
    .line 1085
    const/4 v12, 0x0

    .line 1086
    iput v12, v7, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 1087
    .line 1088
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->r()Landroid/widget/LinearLayout;

    .line 1089
    .line 1090
    .line 1091
    move-result-object v0

    .line 1092
    invoke-virtual {v0, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1093
    .line 1094
    .line 1095
    :cond_30
    return-void

    .line 1096
    :cond_31
    move v12, v1

    .line 1097
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 1098
    .line 1099
    .line 1100
    move-result-object v0

    .line 1101
    new-array v1, v12, [Ljava/lang/Object;

    .line 1102
    .line 1103
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1104
    .line 1105
    .line 1106
    return-void
.end method
