.class public final Lub/u;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/u;->f:I

    iput-object p1, p0, Lub/u;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/u;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lub/u;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_0
    const-string v0, "d"

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lub/u;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    nop

    .line 29
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/u;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "message"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    new-array v0, v0, [Ljava/lang/Object;

    .line 19
    .line 20
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-void

    .line 24
    :pswitch_0
    const-string v0, "message"

    .line 25
    .line 26
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    new-array v0, v0, [Ljava/lang/Object;

    .line 31
    .line 32
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 13

    .line 1
    const/4 v0, 0x0

    .line 2
    const-string v1, "getValue(...)"

    .line 3
    .line 4
    const/4 v2, 0x1

    .line 5
    iget-object v3, p0, Lub/u;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;

    .line 6
    .line 7
    iget v4, p0, Lub/u;->f:I

    .line 8
    .line 9
    packed-switch v4, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp;

    .line 13
    .line 14
    sget v4, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 15
    .line 16
    if-eqz p1, :cond_1c

    .line 17
    .line 18
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    if-ne v4, v2, :cond_1c

    .line 23
    .line 24
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp;->getData()Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    if-eqz v4, :cond_1c

    .line 29
    .line 30
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp;->getData()Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    const-wide/16 v5, 0x0

    .line 35
    .line 36
    if-eqz v4, :cond_0

    .line 37
    .line 38
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;->getDeduceDateStamp()Ljava/lang/Long;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    if-eqz v4, :cond_0

    .line 43
    .line 44
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 45
    .line 46
    .line 47
    move-result-wide v7

    .line 48
    goto :goto_0

    .line 49
    :cond_0
    move-wide v7, v5

    .line 50
    :goto_0
    cmp-long v4, v7, v5

    .line 51
    .line 52
    const/4 v7, 0x0

    .line 53
    if-lez v4, :cond_1

    .line 54
    .line 55
    move v4, v2

    .line 56
    goto :goto_1

    .line 57
    :cond_1
    move v4, v7

    .line 58
    :goto_1
    iget-object v8, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->t:Lxf/t;

    .line 59
    .line 60
    invoke-virtual {v8}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v9

    .line 64
    invoke-static {v9, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    check-cast v9, Landroid/widget/TextView;

    .line 68
    .line 69
    new-instance v10, Ljava/util/Date;

    .line 70
    .line 71
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp;->getData()Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;

    .line 72
    .line 73
    .line 74
    move-result-object v11

    .line 75
    if-eqz v11, :cond_2

    .line 76
    .line 77
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;->getDeduceDateStamp()Ljava/lang/Long;

    .line 78
    .line 79
    .line 80
    move-result-object v11

    .line 81
    if-eqz v11, :cond_2

    .line 82
    .line 83
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    .line 84
    .line 85
    .line 86
    move-result-wide v11

    .line 87
    goto :goto_2

    .line 88
    :cond_2
    move-wide v11, v5

    .line 89
    :goto_2
    invoke-direct {v10, v11, v12}, Ljava/util/Date;-><init>(J)V

    .line 90
    .line 91
    .line 92
    new-instance v11, Ljava/text/SimpleDateFormat;

    .line 93
    .line 94
    const-string v12, "d"

    .line 95
    .line 96
    invoke-direct {v11, v12}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v11, v10}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v10

    .line 103
    invoke-static {v10}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 107
    .line 108
    .line 109
    move-result v11

    .line 110
    rem-int/lit8 v12, v11, 0xa

    .line 111
    .line 112
    if-ne v12, v2, :cond_3

    .line 113
    .line 114
    const/16 v2, 0xb

    .line 115
    .line 116
    if-eq v11, v2, :cond_3

    .line 117
    .line 118
    const-string v2, "st"

    .line 119
    .line 120
    goto :goto_3

    .line 121
    :cond_3
    const/4 v2, 0x2

    .line 122
    if-ne v12, v2, :cond_4

    .line 123
    .line 124
    const/16 v2, 0xc

    .line 125
    .line 126
    if-eq v11, v2, :cond_4

    .line 127
    .line 128
    const-string v2, "nd"

    .line 129
    .line 130
    goto :goto_3

    .line 131
    :cond_4
    const/4 v2, 0x3

    .line 132
    if-ne v12, v2, :cond_5

    .line 133
    .line 134
    const/16 v2, 0xd

    .line 135
    .line 136
    if-eq v11, v2, :cond_5

    .line 137
    .line 138
    const-string v2, "rd"

    .line 139
    .line 140
    goto :goto_3

    .line 141
    :cond_5
    const-string v2, "th"

    .line 142
    .line 143
    :goto_3
    invoke-virtual {v10, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp;->getData()Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;

    .line 148
    .line 149
    .line 150
    move-result-object v10

    .line 151
    if-eqz v10, :cond_6

    .line 152
    .line 153
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;->getDeduceDateStamp()Ljava/lang/Long;

    .line 154
    .line 155
    .line 156
    move-result-object v10

    .line 157
    if-eqz v10, :cond_6

    .line 158
    .line 159
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 160
    .line 161
    .line 162
    move-result-wide v5

    .line 163
    :cond_6
    new-instance v10, Ljava/text/SimpleDateFormat;

    .line 164
    .line 165
    const-string v11, "   MMM "

    .line 166
    .line 167
    sget-object v12, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 168
    .line 169
    invoke-direct {v10, v11, v12}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 170
    .line 171
    .line 172
    invoke-static {v5, v6, v10}, Lcom/transsnet/palmpay/util/TimeUtils;->millis2String(JLjava/text/DateFormat;)Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v5

    .line 176
    new-instance v6, Ljava/lang/StringBuilder;

    .line 177
    .line 178
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 179
    .line 180
    .line 181
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 182
    .line 183
    .line 184
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 185
    .line 186
    .line 187
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v2

    .line 191
    invoke-virtual {v9, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 192
    .line 193
    .line 194
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->v:Lxf/t;

    .line 195
    .line 196
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v2

    .line 200
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 201
    .line 202
    .line 203
    check-cast v2, Landroid/widget/TextView;

    .line 204
    .line 205
    const/16 v5, 0x8

    .line 206
    .line 207
    if-eqz v4, :cond_7

    .line 208
    .line 209
    move v6, v7

    .line 210
    goto :goto_4

    .line 211
    :cond_7
    move v6, v5

    .line 212
    :goto_4
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {v8}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v2

    .line 219
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    check-cast v2, Landroid/widget/TextView;

    .line 223
    .line 224
    if-eqz v4, :cond_8

    .line 225
    .line 226
    move v6, v7

    .line 227
    goto :goto_5

    .line 228
    :cond_8
    move v6, v5

    .line 229
    :goto_5
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 230
    .line 231
    .line 232
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->o:Lxf/t;

    .line 233
    .line 234
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v2

    .line 238
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 239
    .line 240
    .line 241
    check-cast v2, Landroid/widget/TextView;

    .line 242
    .line 243
    if-eqz v4, :cond_9

    .line 244
    .line 245
    move v6, v5

    .line 246
    goto :goto_6

    .line 247
    :cond_9
    move v6, v7

    .line 248
    :goto_6
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 249
    .line 250
    .line 251
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->p:Lxf/t;

    .line 252
    .line 253
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v2

    .line 257
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    check-cast v2, Landroid/view/View;

    .line 261
    .line 262
    if-eqz v4, :cond_a

    .line 263
    .line 264
    move v6, v5

    .line 265
    goto :goto_7

    .line 266
    :cond_a
    move v6, v7

    .line 267
    :goto_7
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 268
    .line 269
    .line 270
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->j:Lxf/t;

    .line 271
    .line 272
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v2

    .line 276
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 277
    .line 278
    .line 279
    check-cast v2, Lcom/palmpay/lib/ui/button/PpButton;

    .line 280
    .line 281
    if-nez v4, :cond_14

    .line 282
    .line 283
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp;->getData()Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;

    .line 284
    .line 285
    .line 286
    move-result-object v6

    .line 287
    if-eqz v6, :cond_b

    .line 288
    .line 289
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;->getCreditCardList()Ljava/util/List;

    .line 290
    .line 291
    .line 292
    move-result-object v6

    .line 293
    goto :goto_8

    .line 294
    :cond_b
    move-object v6, v0

    .line 295
    :goto_8
    if-eqz v6, :cond_14

    .line 296
    .line 297
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 298
    .line 299
    .line 300
    move-result v8

    .line 301
    if-eqz v8, :cond_c

    .line 302
    .line 303
    goto/16 :goto_d

    .line 304
    .line 305
    :cond_c
    check-cast v6, Ljava/lang/Iterable;

    .line 306
    .line 307
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 308
    .line 309
    .line 310
    move-result-object v8

    .line 311
    :cond_d
    :goto_9
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 312
    .line 313
    .line 314
    move-result v9

    .line 315
    if-eqz v9, :cond_f

    .line 316
    .line 317
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    move-result-object v9

    .line 321
    move-object v10, v9

    .line 322
    check-cast v10, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;

    .line 323
    .line 324
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getAccountType()Ljava/lang/Integer;

    .line 325
    .line 326
    .line 327
    move-result-object v11

    .line 328
    if-nez v11, :cond_e

    .line 329
    .line 330
    goto :goto_9

    .line 331
    :cond_e
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 332
    .line 333
    .line 334
    move-result v11

    .line 335
    const/4 v12, 0x7

    .line 336
    if-ne v11, v12, :cond_d

    .line 337
    .line 338
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getCardNo()Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v11

    .line 342
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 343
    .line 344
    .line 345
    move-result v11

    .line 346
    if-nez v11, :cond_d

    .line 347
    .line 348
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getAccountId()Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object v10

    .line 352
    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 353
    .line 354
    .line 355
    move-result v10

    .line 356
    if-nez v10, :cond_d

    .line 357
    .line 358
    goto :goto_a

    .line 359
    :cond_f
    move-object v9, v0

    .line 360
    :goto_a
    if-nez v9, :cond_13

    .line 361
    .line 362
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 363
    .line 364
    .line 365
    move-result-object v6

    .line 366
    :cond_10
    :goto_b
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 367
    .line 368
    .line 369
    move-result v8

    .line 370
    if-eqz v8, :cond_12

    .line 371
    .line 372
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 373
    .line 374
    .line 375
    move-result-object v8

    .line 376
    move-object v9, v8

    .line 377
    check-cast v9, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;

    .line 378
    .line 379
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getAccountType()Ljava/lang/Integer;

    .line 380
    .line 381
    .line 382
    move-result-object v10

    .line 383
    if-nez v10, :cond_11

    .line 384
    .line 385
    goto :goto_b

    .line 386
    :cond_11
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 387
    .line 388
    .line 389
    move-result v10

    .line 390
    const/16 v11, 0x9

    .line 391
    .line 392
    if-ne v10, v11, :cond_10

    .line 393
    .line 394
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getCardNo()Ljava/lang/String;

    .line 395
    .line 396
    .line 397
    move-result-object v10

    .line 398
    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 399
    .line 400
    .line 401
    move-result v10

    .line 402
    if-nez v10, :cond_10

    .line 403
    .line 404
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getAccountId()Ljava/lang/String;

    .line 405
    .line 406
    .line 407
    move-result-object v9

    .line 408
    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 409
    .line 410
    .line 411
    move-result v9

    .line 412
    if-nez v9, :cond_10

    .line 413
    .line 414
    goto :goto_c

    .line 415
    :cond_12
    move-object v8, v0

    .line 416
    :goto_c
    if-eqz v8, :cond_14

    .line 417
    .line 418
    :cond_13
    move v6, v7

    .line 419
    goto :goto_e

    .line 420
    :cond_14
    :goto_d
    move v6, v5

    .line 421
    :goto_e
    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    .line 422
    .line 423
    .line 424
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->i:Lxf/t;

    .line 425
    .line 426
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 427
    .line 428
    .line 429
    move-result-object v2

    .line 430
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 431
    .line 432
    .line 433
    check-cast v2, Lcom/palmpay/lib/ui/button/PpButton;

    .line 434
    .line 435
    if-nez v4, :cond_1a

    .line 436
    .line 437
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp;->getData()Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;

    .line 438
    .line 439
    .line 440
    move-result-object p1

    .line 441
    if-eqz p1, :cond_15

    .line 442
    .line 443
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/UserDeduceDateResp$Data;->getCreditCardList()Ljava/util/List;

    .line 444
    .line 445
    .line 446
    move-result-object p1

    .line 447
    goto :goto_f

    .line 448
    :cond_15
    move-object p1, v0

    .line 449
    :goto_f
    if-eqz p1, :cond_1a

    .line 450
    .line 451
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    .line 452
    .line 453
    .line 454
    move-result v6

    .line 455
    if-eqz v6, :cond_16

    .line 456
    .line 457
    goto :goto_11

    .line 458
    :cond_16
    check-cast p1, Ljava/lang/Iterable;

    .line 459
    .line 460
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 461
    .line 462
    .line 463
    move-result-object p1

    .line 464
    :cond_17
    :goto_10
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 465
    .line 466
    .line 467
    move-result v6

    .line 468
    if-eqz v6, :cond_19

    .line 469
    .line 470
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 471
    .line 472
    .line 473
    move-result-object v6

    .line 474
    move-object v8, v6

    .line 475
    check-cast v8, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;

    .line 476
    .line 477
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getAccountType()Ljava/lang/Integer;

    .line 478
    .line 479
    .line 480
    move-result-object v9

    .line 481
    if-nez v9, :cond_18

    .line 482
    .line 483
    goto :goto_10

    .line 484
    :cond_18
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 485
    .line 486
    .line 487
    move-result v9

    .line 488
    const/4 v10, 0x6

    .line 489
    if-ne v9, v10, :cond_17

    .line 490
    .line 491
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getCardNo()Ljava/lang/String;

    .line 492
    .line 493
    .line 494
    move-result-object v9

    .line 495
    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 496
    .line 497
    .line 498
    move-result v9

    .line 499
    if-nez v9, :cond_17

    .line 500
    .line 501
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getAccountId()Ljava/lang/String;

    .line 502
    .line 503
    .line 504
    move-result-object v8

    .line 505
    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 506
    .line 507
    .line 508
    move-result v8

    .line 509
    if-nez v8, :cond_17

    .line 510
    .line 511
    move-object v0, v6

    .line 512
    :cond_19
    if-eqz v0, :cond_1a

    .line 513
    .line 514
    goto :goto_12

    .line 515
    :cond_1a
    :goto_11
    move v7, v5

    .line 516
    :goto_12
    invoke-virtual {v2, v7}, Landroid/view/View;->setVisibility(I)V

    .line 517
    .line 518
    .line 519
    sget-object p1, LPa/h;->a:LPa/g;

    .line 520
    .line 521
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->g:Lxf/t;

    .line 522
    .line 523
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 524
    .line 525
    .line 526
    move-result-object v0

    .line 527
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 528
    .line 529
    .line 530
    check-cast v0, Landroid/widget/TextView;

    .line 531
    .line 532
    if-eqz v4, :cond_1b

    .line 533
    .line 534
    sget v1, LYa/g;->cs_with_wait_repay_tips:I

    .line 535
    .line 536
    :goto_13
    invoke-virtual {v3, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 537
    .line 538
    .line 539
    move-result-object v1

    .line 540
    goto :goto_14

    .line 541
    :cond_1b
    sget v1, LYa/g;->cs_without_wait_repay_tips:I

    .line 542
    .line 543
    goto :goto_13

    .line 544
    :goto_14
    new-instance v2, LOc/c;

    .line 545
    .line 546
    const/16 v4, 0x12

    .line 547
    .line 548
    invoke-direct {v2, v3, v4}, LOc/c;-><init>(Ljava/lang/Object;I)V

    .line 549
    .line 550
    .line 551
    const-string v3, "on or after due date"

    .line 552
    .line 553
    invoke-virtual {p1, v0, v1, v3, v2}, LPa/g;->richText(Landroid/widget/TextView;Ljava/lang/String;Ljava/lang/String;Landroid/text/style/CharacterStyle;)V

    .line 554
    .line 555
    .line 556
    :cond_1c
    return-void

    .line 557
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoRepaymentListResp;

    .line 558
    .line 559
    const-string v4, "mBankCardData"

    .line 560
    .line 561
    if-eqz p1, :cond_21

    .line 562
    .line 563
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 564
    .line 565
    .line 566
    move-result v5

    .line 567
    if-ne v5, v2, :cond_21

    .line 568
    .line 569
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoRepaymentListResp;->getData()Ljava/util/List;

    .line 570
    .line 571
    .line 572
    move-result-object v2

    .line 573
    if-eqz v2, :cond_21

    .line 574
    .line 575
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoRepaymentListResp;->getData()Ljava/util/List;

    .line 576
    .line 577
    .line 578
    move-result-object v2

    .line 579
    check-cast v2, Ljava/util/Collection;

    .line 580
    .line 581
    if-eqz v2, :cond_21

    .line 582
    .line 583
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 584
    .line 585
    .line 586
    move-result v2

    .line 587
    if-eqz v2, :cond_1d

    .line 588
    .line 589
    goto :goto_15

    .line 590
    :cond_1d
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->w:Ljava/util/ArrayList;

    .line 591
    .line 592
    if-eqz v2, :cond_20

    .line 593
    .line 594
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 595
    .line 596
    .line 597
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->w:Ljava/util/ArrayList;

    .line 598
    .line 599
    if-eqz v2, :cond_1f

    .line 600
    .line 601
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcAutoRepaymentListResp;->getData()Ljava/util/List;

    .line 602
    .line 603
    .line 604
    move-result-object p1

    .line 605
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 606
    .line 607
    .line 608
    check-cast p1, Ljava/util/Collection;

    .line 609
    .line 610
    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 611
    .line 612
    .line 613
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->A:Lyb/h;

    .line 614
    .line 615
    if-eqz p1, :cond_1e

    .line 616
    .line 617
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 618
    .line 619
    .line 620
    goto :goto_15

    .line 621
    :cond_1e
    const-string p1, "mBankCardAdapter"

    .line 622
    .line 623
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 624
    .line 625
    .line 626
    throw v0

    .line 627
    :cond_1f
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 628
    .line 629
    .line 630
    throw v0

    .line 631
    :cond_20
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 632
    .line 633
    .line 634
    throw v0

    .line 635
    :cond_21
    :goto_15
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->w:Ljava/util/ArrayList;

    .line 636
    .line 637
    if-eqz p1, :cond_23

    .line 638
    .line 639
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 640
    .line 641
    .line 642
    move-result p1

    .line 643
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->e:Lxf/t;

    .line 644
    .line 645
    if-eqz p1, :cond_22

    .line 646
    .line 647
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 648
    .line 649
    .line 650
    move-result-object p1

    .line 651
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 652
    .line 653
    .line 654
    check-cast p1, Landroid/widget/TextView;

    .line 655
    .line 656
    sget v0, LYa/g;->cs_oc_your_unbound_bank_cards:I

    .line 657
    .line 658
    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 659
    .line 660
    .line 661
    move-result-object v0

    .line 662
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 663
    .line 664
    .line 665
    goto :goto_16

    .line 666
    :cond_22
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 667
    .line 668
    .line 669
    move-result-object p1

    .line 670
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 671
    .line 672
    .line 673
    check-cast p1, Landroid/widget/TextView;

    .line 674
    .line 675
    sget v0, LYa/g;->cs_oc_your_bound_bank_cards:I

    .line 676
    .line 677
    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 678
    .line 679
    .line 680
    move-result-object v0

    .line 681
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 682
    .line 683
    .line 684
    :goto_16
    return-void

    .line 685
    :cond_23
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 686
    .line 687
    .line 688
    throw v0

    .line 689
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
