.class public final synthetic Lub/k1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

.field public final synthetic c:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;I)V
    .locals 0

    .line 1
    iput p3, p0, Lub/k1;->a:I

    iput-object p1, p0, Lub/k1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    iput-object p2, p0, Lub/k1;->c:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget-object p1, p0, Lub/k1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;

    .line 2
    .line 3
    iget-object v0, p0, Lub/k1;->c:Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;

    .line 4
    .line 5
    iget v1, p0, Lub/k1;->a:I

    .line 6
    .line 7
    packed-switch v1, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->o:I

    .line 11
    .line 12
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->stampDutyText:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->w(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailInPalmPayActivity;->o:I

    .line 19
    .line 20
    new-instance v1, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;

    .line 21
    .line 22
    invoke-direct {v1, p1}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;-><init>(Landroid/content/Context;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1}, LO6/f;->show()V

    .line 26
    .line 27
    .line 28
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/bean/resp/TopUpOrderDetailRsp$DataBean;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 29
    .line 30
    invoke-virtual {v1, p1}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;->fillData(Lcom/transsnet/palmpay/core/bean/BillProcessDetail;)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
