.class public final synthetic Lub/T0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/T0;->a:I

    iput-object p1, p0, Lub/T0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 11

    .line 1
    const-string v0, "getValue(...)"

    .line 2
    .line 3
    const/16 v1, 0x8

    .line 4
    .line 5
    iget-object v2, p0, Lub/T0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 6
    .line 7
    iget v3, p0, Lub/T0;->a:I

    .line 8
    .line 9
    packed-switch v3, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 13
    .line 14
    sget v0, LYa/e;->extend_amount_tv:I

    .line 15
    .line 16
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, Landroid/widget/TextView;

    .line 21
    .line 22
    return-object v0

    .line 23
    :pswitch_0
    const/4 v0, 0x1

    .line 24
    iput-boolean v0, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u1:Z

    .line 25
    .line 26
    iget-object v3, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->s1:Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 27
    .line 28
    const-wide/16 v4, 0x0

    .line 29
    .line 30
    const/4 v6, 0x0

    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getOriginalOutstandingAmount()Ljava/lang/Long;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    if-eqz v3, :cond_0

    .line 38
    .line 39
    :goto_0
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 40
    .line 41
    .line 42
    move-result-wide v7

    .line 43
    goto :goto_2

    .line 44
    :cond_0
    iget-object v3, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 45
    .line 46
    if-eqz v3, :cond_1

    .line 47
    .line 48
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getOutstandingAmount()Ljava/lang/Long;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    goto :goto_1

    .line 53
    :cond_1
    move-object v3, v6

    .line 54
    :goto_1
    if-eqz v3, :cond_2

    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_2
    move-wide v7, v4

    .line 58
    :goto_2
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->B()V

    .line 59
    .line 60
    .line 61
    iput-object v6, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->r1:Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 62
    .line 63
    iput-wide v7, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->f1:J

    .line 64
    .line 65
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    new-instance v6, Landroid/text/SpannableStringBuilder;

    .line 70
    .line 71
    invoke-static {v7, v8}, LPa/r0;->A(J)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v9

    .line 75
    invoke-direct {v6, v9}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    invoke-virtual {v3, v0}, Landroid/view/View;->setFocusable(Z)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    invoke-virtual {v3, v0}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u()Landroid/widget/TextView;

    .line 96
    .line 97
    .line 98
    move-result-object v3

    .line 99
    const/4 v6, 0x0

    .line 100
    invoke-virtual {v3, v6}, Landroid/view/View;->setVisibility(I)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->z()Landroid/widget/TextView;

    .line 104
    .line 105
    .line 106
    move-result-object v3

    .line 107
    invoke-virtual {v3, v6}, Landroid/view/View;->setVisibility(I)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->q()Landroid/widget/ImageView;

    .line 111
    .line 112
    .line 113
    move-result-object v3

    .line 114
    invoke-virtual {v3, v6}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 115
    .line 116
    .line 117
    iget-object v3, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 118
    .line 119
    if-eqz v3, :cond_7

    .line 120
    .line 121
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->r()Landroid/widget/LinearLayout;

    .line 122
    .line 123
    .line 124
    move-result-object v9

    .line 125
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionTag()Ljava/lang/Integer;

    .line 126
    .line 127
    .line 128
    move-result-object v10

    .line 129
    if-nez v10, :cond_3

    .line 130
    .line 131
    goto :goto_3

    .line 132
    :cond_3
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 133
    .line 134
    .line 135
    move-result v10

    .line 136
    if-ne v10, v0, :cond_4

    .line 137
    .line 138
    move v10, v6

    .line 139
    goto :goto_4

    .line 140
    :cond_4
    :goto_3
    move v10, v1

    .line 141
    :goto_4
    invoke-virtual {v9, v10}, Landroid/view/View;->setVisibility(I)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->A()Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 145
    .line 146
    .line 147
    move-result-object v9

    .line 148
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getSpreadTag()Ljava/lang/Integer;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    if-nez v3, :cond_5

    .line 153
    .line 154
    goto :goto_5

    .line 155
    :cond_5
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 156
    .line 157
    .line 158
    move-result v3

    .line 159
    if-ne v3, v0, :cond_6

    .line 160
    .line 161
    move v1, v6

    .line 162
    :cond_6
    :goto_5
    invoke-virtual {v9, v1}, Landroid/view/View;->setVisibility(I)V

    .line 163
    .line 164
    .line 165
    :cond_7
    cmp-long v0, v7, v4

    .line 166
    .line 167
    if-nez v0, :cond_8

    .line 168
    .line 169
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->o()V

    .line 170
    .line 171
    .line 172
    goto :goto_6

    .line 173
    :cond_8
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->p()V

    .line 174
    .line 175
    .line 176
    :goto_6
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 177
    .line 178
    return-object v0

    .line 179
    :pswitch_1
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 180
    .line 181
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->w()Landroid/widget/TextView;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 186
    .line 187
    .line 188
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 189
    .line 190
    return-object v0

    .line 191
    :pswitch_2
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 192
    .line 193
    iget-object v2, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->S0:Lxf/t;

    .line 194
    .line 195
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v2

    .line 199
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    check-cast v2, Landroid/view/View;

    .line 203
    .line 204
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 205
    .line 206
    .line 207
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 208
    .line 209
    return-object v0

    .line 210
    :pswitch_3
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 211
    .line 212
    sget v0, LYa/e;->init_payment_tv:I

    .line 213
    .line 214
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    check-cast v0, Landroid/widget/TextView;

    .line 219
    .line 220
    return-object v0

    .line 221
    :pswitch_4
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 222
    .line 223
    iget-object v2, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->Q0:Lxf/t;

    .line 224
    .line 225
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v2

    .line 229
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    check-cast v2, Landroid/widget/TextView;

    .line 233
    .line 234
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 235
    .line 236
    .line 237
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 238
    .line 239
    return-object v0

    .line 240
    :pswitch_5
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 241
    .line 242
    sget v0, LYa/e;->extend_penalty_tv:I

    .line 243
    .line 244
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    check-cast v0, Landroid/widget/TextView;

    .line 249
    .line 250
    return-object v0

    .line 251
    :pswitch_6
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 252
    .line 253
    sget v0, LYa/e;->extend_interest_group:I

    .line 254
    .line 255
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    check-cast v0, Landroidx/constraintlayout/widget/Group;

    .line 260
    .line 261
    return-object v0

    .line 262
    :pswitch_7
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 263
    .line 264
    sget v0, LYa/e;->spread_second_tv:I

    .line 265
    .line 266
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    check-cast v0, Landroid/widget/TextView;

    .line 271
    .line 272
    return-object v0

    .line 273
    :pswitch_8
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 274
    .line 275
    sget v0, LYa/e;->ins_unavailable_tv:I

    .line 276
    .line 277
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 278
    .line 279
    .line 280
    move-result-object v0

    .line 281
    check-cast v0, Landroid/widget/TextView;

    .line 282
    .line 283
    return-object v0

    .line 284
    :pswitch_9
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 285
    .line 286
    sget v0, LYa/e;->settlement_order_tv:I

    .line 287
    .line 288
    invoke-virtual {v2, v0}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    check-cast v0, Landroid/widget/TextView;

    .line 293
    .line 294
    return-object v0

    .line 295
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
