.class public final Lub/s1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;

.field public final synthetic c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;I)V
    .locals 0

    .line 1
    iput p3, p0, Lub/s1;->a:I

    iput-object p1, p0, Lub/s1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;

    iput-object p2, p0, Lub/s1;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, Lub/s1;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 14
    .line 15
    iget-object v1, p0, Lub/s1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 25
    .line 26
    iget-object v3, p0, Lub/s1;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;

    .line 27
    .line 28
    const/4 v4, 0x0

    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 32
    .line 33
    .line 34
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 35
    .line 36
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 39
    .line 40
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    sget p1, LYa/g;->cs_set_successfully:I

    .line 47
    .line 48
    invoke-virtual {v3, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    invoke-static {p1}, Landroidx/camera/core/impl/utils/n;->w(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    check-cast p1, Lcom/transsnet/palmpay/credit/viewmodel/OcSetDefaultPayMethodViewModel;

    .line 60
    .line 61
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    new-instance v0, LJb/A;

    .line 65
    .line 66
    const/4 v1, 0x0

    .line 67
    invoke-direct {v0, v2, v1}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 68
    .line 69
    .line 70
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/viewmodel/OcSetDefaultPayMethodViewModel;->e:Lcom/transsnet/palmpay/core/base/l;

    .line 71
    .line 72
    const/16 v2, 0x1c

    .line 73
    .line 74
    invoke-static {p1, v0, v1, v4, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 75
    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    new-array v0, v4, [Ljava/lang/Object;

    .line 83
    .line 84
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    goto :goto_0

    .line 88
    :cond_2
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 89
    .line 90
    if-eqz v0, :cond_3

    .line 91
    .line 92
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 93
    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_3
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 97
    .line 98
    if-eqz v0, :cond_4

    .line 99
    .line 100
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 101
    .line 102
    .line 103
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 104
    .line 105
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 106
    .line 107
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 108
    .line 109
    .line 110
    new-array v0, v4, [Ljava/lang/Object;

    .line 111
    .line 112
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 116
    .line 117
    return-object p1

    .line 118
    :cond_4
    new-instance p1, Lxf/l;

    .line 119
    .line 120
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 121
    .line 122
    .line 123
    throw p1

    .line 124
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 125
    .line 126
    const-string v0, "it"

    .line 127
    .line 128
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 132
    .line 133
    iget-object v1, p0, Lub/s1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;

    .line 134
    .line 135
    const/4 v2, 0x1

    .line 136
    if-eqz v0, :cond_5

    .line 137
    .line 138
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 139
    .line 140
    .line 141
    goto/16 :goto_1

    .line 142
    .line 143
    :cond_5
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 144
    .line 145
    iget-object v3, p0, Lub/s1;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;

    .line 146
    .line 147
    const/4 v4, 0x0

    .line 148
    if-eqz v0, :cond_9

    .line 149
    .line 150
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 151
    .line 152
    .line 153
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 154
    .line 155
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 156
    .line 157
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcDefaultPayMethodStatusResp;

    .line 158
    .line 159
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-eqz v0, :cond_8

    .line 164
    .line 165
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcDefaultPayMethodStatusResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcDefaultPayMethodStatusData;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    if-eqz v0, :cond_8

    .line 170
    .line 171
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcDefaultPayMethodStatusResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcDefaultPayMethodStatusData;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    iput-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;->i:Lcom/transsnet/palmpay/credit/bean/resp/OcDefaultPayMethodStatusData;

    .line 176
    .line 177
    if-eqz p1, :cond_6

    .line 178
    .line 179
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcDefaultPayMethodStatusData;->getFlexiFlag()Ljava/lang/Boolean;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 184
    .line 185
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    move-result v4

    .line 189
    :cond_6
    const-string p1, "getValue(...)"

    .line 190
    .line 191
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;->f:Lxf/t;

    .line 192
    .line 193
    iget-object v1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcSetDefaultPayMethodActivity;->g:Lxf/t;

    .line 194
    .line 195
    if-eqz v4, :cond_7

    .line 196
    .line 197
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v1

    .line 201
    invoke-static {v1, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 202
    .line 203
    .line 204
    check-cast v1, Landroid/widget/TextView;

    .line 205
    .line 206
    sget v2, LYa/g;->cs_you_have_selected:I

    .line 207
    .line 208
    invoke-virtual {v3, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v2

    .line 212
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    check-cast v0, Landroid/widget/TextView;

    .line 223
    .line 224
    sget p1, LYa/g;->cs_oc_pay_with_flexi_now:I

    .line 225
    .line 226
    invoke-virtual {v3, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 227
    .line 228
    .line 229
    move-result-object p1

    .line 230
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 231
    .line 232
    .line 233
    goto :goto_1

    .line 234
    :cond_7
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v1

    .line 238
    invoke-static {v1, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 239
    .line 240
    .line 241
    check-cast v1, Landroid/widget/TextView;

    .line 242
    .line 243
    sget v2, LYa/g;->cs_we_recommend_that_set:I

    .line 244
    .line 245
    invoke-virtual {v3, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object v2

    .line 249
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v0

    .line 256
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    check-cast v0, Landroid/widget/TextView;

    .line 260
    .line 261
    sget p1, LYa/g;->cs_oc_set_now:I

    .line 262
    .line 263
    invoke-virtual {v3, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 264
    .line 265
    .line 266
    move-result-object p1

    .line 267
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 268
    .line 269
    .line 270
    goto :goto_1

    .line 271
    :cond_8
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 272
    .line 273
    .line 274
    move-result-object p1

    .line 275
    new-array v0, v4, [Ljava/lang/Object;

    .line 276
    .line 277
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 278
    .line 279
    .line 280
    goto :goto_1

    .line 281
    :cond_9
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 282
    .line 283
    if-eqz v0, :cond_a

    .line 284
    .line 285
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 286
    .line 287
    .line 288
    goto :goto_1

    .line 289
    :cond_a
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 290
    .line 291
    if-eqz v0, :cond_b

    .line 292
    .line 293
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 294
    .line 295
    .line 296
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 297
    .line 298
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 299
    .line 300
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 301
    .line 302
    .line 303
    new-array v0, v4, [Ljava/lang/Object;

    .line 304
    .line 305
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 306
    .line 307
    .line 308
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 309
    .line 310
    return-object p1

    .line 311
    :cond_b
    new-instance p1, Lxf/l;

    .line 312
    .line 313
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 314
    .line 315
    .line 316
    throw p1

    .line 317
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
