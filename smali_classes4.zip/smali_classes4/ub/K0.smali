.class public final Lub/K0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/credit/ui/dialog/OcInviteDiscoverDialog$OcInviteDiscoverListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/K0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final confirm(Z)V
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    iget-object p1, p0, Lub/K0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;

    .line 4
    .line 5
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 6
    .line 7
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/i;->a:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 8
    .line 9
    check-cast p1, Lpb/p;

    .line 10
    .line 11
    invoke-virtual {p1}, Lpb/p;->queryReferEarnHome()V

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
.end method
