.class public final Lub/V;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/credit/ui/dialog/CLNoPermissionDialog$NoPermissionDialogInterface;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/V;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final negativeClick()V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/V;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final positiveClick()V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/V;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;

    .line 2
    .line 3
    invoke-static {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;->y(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGetInstallmentCreditActivity;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
