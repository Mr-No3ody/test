.class public final synthetic Lub/e0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInviteActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInviteActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/e0;->a:I

    iput-object p1, p0, Lub/e0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInviteActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/e0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInviteActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/e0;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInviteActivity;->f:I

    .line 9
    .line 10
    sget v1, LYa/e;->invite_code_pev:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/transsnet/palmpay/custom_view/PinEntryView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInviteActivity;->f:I

    .line 20
    .line 21
    sget v1, LYa/e;->invite_bt:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/Button;

    .line 28
    .line 29
    return-object v0

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
