.class public final synthetic Lub/g0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcLastProtocolActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcLastProtocolActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/g0;->a:I

    iput-object p1, p0, Lub/g0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcLastProtocolActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lub/g0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcLastProtocolActivity;

    .line 4
    .line 5
    iget v2, v0, Lub/g0;->a:I

    .line 6
    .line 7
    packed-switch v2, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcLastProtocolActivity;->r0:I

    .line 11
    .line 12
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->goBackToHome()V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_0
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcLastProtocolActivity;->r0:I

    .line 17
    .line 18
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcLastProtocolActivity;->p0:Lxf/t;

    .line 19
    .line 20
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    const-string v4, "getValue(...)"

    .line 25
    .line 26
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    check-cast v3, Landroid/widget/CheckBox;

    .line 30
    .line 31
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    const/16 v5, 0x8

    .line 36
    .line 37
    const/4 v6, 0x0

    .line 38
    if-eq v3, v5, :cond_1

    .line 39
    .line 40
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    check-cast v3, Landroid/widget/CheckBox;

    .line 48
    .line 49
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    if-nez v3, :cond_0

    .line 54
    .line 55
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    check-cast v2, Landroid/widget/CheckBox;

    .line 63
    .line 64
    invoke-virtual {v2}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    if-eqz v2, :cond_0

    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_0
    sget v2, LYa/g;->cs_oc_consent_agreement:I

    .line 72
    .line 73
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    new-array v2, v6, [Ljava/lang/Object;

    .line 78
    .line 79
    invoke-static {v1, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    goto/16 :goto_a

    .line 83
    .line 84
    :cond_1
    :goto_0
    sget v2, LYa/g;->cs_overdraft_calculating:I

    .line 85
    .line 86
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    const/4 v3, 0x1

    .line 91
    invoke-virtual {v1, v3, v2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(ZLjava/lang/String;)V

    .line 92
    .line 93
    .line 94
    const/4 v2, 0x0

    .line 95
    :try_start_0
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 96
    .line 97
    .line 98
    move-result-object v4

    .line 99
    if-eqz v4, :cond_2

    .line 100
    .line 101
    invoke-virtual {v4, v6}, Landroid/content/pm/PackageManager;->getInstalledPackages(I)Ljava/util/List;

    .line 102
    .line 103
    .line 104
    move-result-object v4

    .line 105
    goto :goto_1

    .line 106
    :cond_2
    move-object v4, v2

    .line 107
    :goto_1
    move-object v5, v4

    .line 108
    check-cast v5, Ljava/util/Collection;

    .line 109
    .line 110
    if-eqz v5, :cond_4

    .line 111
    .line 112
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    .line 113
    .line 114
    .line 115
    move-result v5

    .line 116
    if-eqz v5, :cond_3

    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_3
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 120
    .line 121
    .line 122
    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 123
    goto :goto_3

    .line 124
    :catchall_0
    :cond_4
    :goto_2
    move v4, v6

    .line 125
    :goto_3
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 126
    .line 127
    .line 128
    move-result-object v5

    .line 129
    check-cast v5, Lcom/transsnet/palmpay/credit/viewmodel/OcApplyBaseViewModel;

    .line 130
    .line 131
    new-instance v7, Lcom/transsnet/palmpay/credit/bean/req/OcApplyReq;

    .line 132
    .line 133
    iget-object v8, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 134
    .line 135
    if-eqz v8, :cond_5

    .line 136
    .line 137
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplyEnterPoint()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    goto :goto_4

    .line 142
    :cond_5
    move-object v8, v2

    .line 143
    :goto_4
    iget-object v9, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 144
    .line 145
    if-eqz v9, :cond_6

    .line 146
    .line 147
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplySource()Ljava/lang/Integer;

    .line 148
    .line 149
    .line 150
    move-result-object v9

    .line 151
    goto :goto_5

    .line 152
    :cond_6
    move-object v9, v2

    .line 153
    :goto_5
    iget-object v10, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 154
    .line 155
    if-eqz v10, :cond_7

    .line 156
    .line 157
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getDeviceTag()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v10

    .line 161
    goto :goto_6

    .line 162
    :cond_7
    move-object v10, v2

    .line 163
    :goto_6
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 164
    .line 165
    .line 166
    move-result-object v11

    .line 167
    iget-object v4, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 168
    .line 169
    if-eqz v4, :cond_8

    .line 170
    .line 171
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getPlIsActive()Z

    .line 172
    .line 173
    .line 174
    move-result v4

    .line 175
    move v12, v4

    .line 176
    goto :goto_7

    .line 177
    :cond_8
    move v12, v3

    .line 178
    :goto_7
    iget-object v4, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 179
    .line 180
    if-eqz v4, :cond_9

    .line 181
    .line 182
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getPlIsInstall()Z

    .line 183
    .line 184
    .line 185
    move-result v3

    .line 186
    :cond_9
    move v13, v3

    .line 187
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 188
    .line 189
    if-eqz v3, :cond_a

    .line 190
    .line 191
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplyId()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v3

    .line 195
    move-object v14, v3

    .line 196
    goto :goto_8

    .line 197
    :cond_a
    move-object v14, v2

    .line 198
    :goto_8
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 199
    .line 200
    if-eqz v1, :cond_b

    .line 201
    .line 202
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getRouterTag()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v1

    .line 206
    move-object v15, v1

    .line 207
    goto :goto_9

    .line 208
    :cond_b
    move-object v15, v2

    .line 209
    :goto_9
    const/16 v21, 0x0

    .line 210
    .line 211
    const/16 v22, 0x0

    .line 212
    .line 213
    const/16 v16, 0x0

    .line 214
    .line 215
    const/16 v17, 0x0

    .line 216
    .line 217
    const/16 v18, 0x0

    .line 218
    .line 219
    const/16 v19, 0x0

    .line 220
    .line 221
    const/16 v20, 0x0

    .line 222
    .line 223
    const/16 v23, 0x7f00

    .line 224
    .line 225
    const/16 v24, 0x0

    .line 226
    .line 227
    invoke-direct/range {v7 .. v24}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyReq;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 228
    .line 229
    .line 230
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 231
    .line 232
    .line 233
    const-string v1, "req"

    .line 234
    .line 235
    invoke-static {v7, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    new-instance v1, LJb/c;

    .line 239
    .line 240
    invoke-direct {v1, v7, v2}, LJb/c;-><init>(Lcom/transsnet/palmpay/credit/bean/req/OcApplyReq;Lkotlin/coroutines/Continuation;)V

    .line 241
    .line 242
    .line 243
    iget-object v2, v5, Lcom/transsnet/palmpay/credit/viewmodel/OcApplyBaseViewModel;->e:Lcom/transsnet/palmpay/core/base/l;

    .line 244
    .line 245
    const/16 v3, 0x1c

    .line 246
    .line 247
    invoke-static {v5, v1, v2, v6, v3}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 248
    .line 249
    .line 250
    :goto_a
    return-void

    .line 251
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
