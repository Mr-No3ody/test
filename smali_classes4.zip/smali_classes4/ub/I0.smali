.class public final synthetic Lub/I0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/I0;->a:I

    iput-object p1, p0, Lub/I0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/I0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/I0;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 9
    .line 10
    sget v1, LYa/e;->viewContainer:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 20
    .line 21
    sget v1, LYa/e;->tvWithdraw:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/TextView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 31
    .line 32
    sget v1, LYa/e;->tvCashSchedule:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/widget/TextView;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 42
    .line 43
    sget v1, LYa/e;->tvMoreInvite:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Landroid/widget/TextView;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 53
    .line 54
    sget v1, LYa/e;->recycler_view:I

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 61
    .line 62
    return-object v0

    .line 63
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 64
    .line 65
    sget v1, LYa/e;->tvMore:I

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Landroid/widget/TextView;

    .line 72
    .line 73
    return-object v0

    .line 74
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 75
    .line 76
    sget v1, LYa/e;->inviteAll:I

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    check-cast v0, Landroid/widget/RelativeLayout;

    .line 83
    .line 84
    return-object v0

    .line 85
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 86
    .line 87
    sget v1, LYa/e;->topBg:I

    .line 88
    .line 89
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    check-cast v0, Landroid/widget/ImageView;

    .line 94
    .line 95
    return-object v0

    .line 96
    :pswitch_7
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 97
    .line 98
    sget v1, LYa/e;->cs_my_cash_webview:I

    .line 99
    .line 100
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/ScrollActivityWebView;

    .line 105
    .line 106
    return-object v0

    .line 107
    :pswitch_8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 108
    .line 109
    sget v1, LYa/e;->title_bar:I

    .line 110
    .line 111
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    check-cast v0, Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 116
    .line 117
    return-object v0

    .line 118
    nop

    .line 119
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
