.class public final synthetic Lub/g1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/g1;->a:I

    iput-object p1, p0, Lub/g1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 10

    .line 1
    const/4 p1, 0x1

    .line 2
    iget-object v0, p0, Lub/g1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;

    .line 3
    .line 4
    iget v1, p0, Lub/g1;->a:I

    .line 5
    .line 6
    packed-switch v1, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->Y:I

    .line 10
    .line 11
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    const-string v1, "/credit_score/oc_offline_installment_detail_activity"

    .line 16
    .line 17
    invoke-virtual {p1, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->X:Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailResp;

    .line 22
    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailData;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailData;->getInstallmentOrderNo()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    const/4 v0, 0x0

    .line 37
    :goto_0
    const-string v1, "oc_installment_order_id"

    .line 38
    .line 39
    invoke-virtual {p1, v1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->Y:I

    .line 48
    .line 49
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->q()Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    iget-object v1, v1, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;->t:Landroid/widget/ImageView;

    .line 54
    .line 55
    const/4 v2, 0x4

    .line 56
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 57
    .line 58
    .line 59
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->M:Ljava/lang/String;

    .line 60
    .line 61
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->q()Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    sget v3, LYa/e;->scrollView:I

    .line 66
    .line 67
    invoke-virtual {v0, v3}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v3

    .line 71
    const/4 v4, 0x2

    .line 72
    new-array v4, v4, [Landroid/view/View;

    .line 73
    .line 74
    const/4 v5, 0x0

    .line 75
    aput-object v2, v4, v5

    .line 76
    .line 77
    aput-object v3, v4, p1

    .line 78
    .line 79
    invoke-static {v1, v0, v4}, LPa/r0;->L1(Ljava/lang/String;Lcom/transsnet/palmpay/core/callback/CompleteCallback;[Landroid/view/View;)V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :pswitch_1
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->X:Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailResp;

    .line 84
    .line 85
    if-eqz v1, :cond_6

    .line 86
    .line 87
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailData;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    if-eqz v1, :cond_6

    .line 92
    .line 93
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailData;->getSettleStatus()Ljava/lang/Integer;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    const-string v3, "oc_future_repayment_date"

    .line 98
    .line 99
    const-string v4, "oc_card_no"

    .line 100
    .line 101
    const-string v5, "oc_bill_id"

    .line 102
    .line 103
    const-wide/16 v6, 0x0

    .line 104
    .line 105
    if-nez v2, :cond_1

    .line 106
    .line 107
    goto :goto_2

    .line 108
    :cond_1
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    if-nez v2, :cond_3

    .line 113
    .line 114
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    const-string v2, "/credit_score/oc_bill_detail_activity"

    .line 119
    .line 120
    invoke-virtual {p1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailData;->getBillId()Ljava/lang/Long;

    .line 125
    .line 126
    .line 127
    move-result-object v2

    .line 128
    if-eqz v2, :cond_2

    .line 129
    .line 130
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 131
    .line 132
    .line 133
    move-result-wide v8

    .line 134
    goto :goto_1

    .line 135
    :cond_2
    move-wide v8, v6

    .line 136
    :goto_1
    invoke-virtual {p1, v5, v8, v9}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailData;->getCardNo()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    invoke-virtual {p1, v4, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    invoke-virtual {p1, v3, v6, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 149
    .line 150
    .line 151
    move-result-object p1

    .line 152
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    goto :goto_4

    .line 156
    :cond_3
    :goto_2
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailData;->getSettleStatus()Ljava/lang/Integer;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    if-nez v2, :cond_4

    .line 161
    .line 162
    goto :goto_4

    .line 163
    :cond_4
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 164
    .line 165
    .line 166
    move-result v2

    .line 167
    if-ne v2, p1, :cond_6

    .line 168
    .line 169
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    const-string v2, "/credit_score/oc_bill_activity"

    .line 174
    .line 175
    invoke-virtual {p1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayOrderDetailActivity;->Q:Ljava/lang/String;

    .line 180
    .line 181
    invoke-virtual {p1, v4, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOrderDetailData;->getBillId()Ljava/lang/Long;

    .line 186
    .line 187
    .line 188
    move-result-object v1

    .line 189
    if-eqz v1, :cond_5

    .line 190
    .line 191
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 192
    .line 193
    .line 194
    move-result-wide v1

    .line 195
    goto :goto_3

    .line 196
    :cond_5
    move-wide v1, v6

    .line 197
    :goto_3
    invoke-virtual {p1, v5, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    invoke-virtual {p1, v3, v6, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    :cond_6
    :goto_4
    return-void

    .line 209
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
