.class public final Lub/b0;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/b0;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/b0;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    const-string v0, "message"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/b0;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 10
    .line 11
    .line 12
    new-array v0, v1, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 14

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp;

    .line 2
    .line 3
    iget-object v0, p0, Lub/b0;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 7
    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz p1, :cond_58

    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    const/4 v4, 0x1

    .line 17
    if-ne v3, v4, :cond_58

    .line 18
    .line 19
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    iput-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 24
    .line 25
    if-eqz p1, :cond_57

    .line 26
    .line 27
    invoke-static {v0}, LPa/i0;->W(Landroid/app/Activity;)Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-nez p1, :cond_0

    .line 32
    .line 33
    goto/16 :goto_3a

    .line 34
    .line 35
    :cond_0
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 36
    .line 37
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->i:Lcom/transsnet/palmpay/custom_view/model/ModelCopyableText;

    .line 38
    .line 39
    if-eqz v3, :cond_56

    .line 40
    .line 41
    iget-object v5, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->d:Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v3, v5}, Lcom/transsnet/palmpay/custom_view/model/ModelCopyableText;->setMessage(Ljava/lang/CharSequence;)V

    .line 44
    .line 45
    .line 46
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->j:Landroid/widget/TextView;

    .line 47
    .line 48
    if-eqz v3, :cond_55

    .line 49
    .line 50
    sget v5, Lba/k;->core_transaction_date:I

    .line 51
    .line 52
    const-wide/16 v6, 0x0

    .line 53
    .line 54
    if-eqz p1, :cond_1

    .line 55
    .line 56
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getCreateTime()Ljava/lang/Long;

    .line 57
    .line 58
    .line 59
    move-result-object v8

    .line 60
    if-eqz v8, :cond_1

    .line 61
    .line 62
    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    .line 63
    .line 64
    .line 65
    move-result-wide v8

    .line 66
    goto :goto_0

    .line 67
    :cond_1
    move-wide v8, v6

    .line 68
    :goto_0
    invoke-static {v8, v9}, LPa/r0;->Q(J)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v8

    .line 72
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v8

    .line 76
    invoke-virtual {v0, v5, v8}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v5

    .line 80
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 81
    .line 82
    .line 83
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->o:Landroid/widget/TextView;

    .line 84
    .line 85
    if-eqz v3, :cond_54

    .line 86
    .line 87
    sget v5, Lba/k;->core_post_date:I

    .line 88
    .line 89
    if-eqz p1, :cond_2

    .line 90
    .line 91
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getUpdateTime()Ljava/lang/Long;

    .line 92
    .line 93
    .line 94
    move-result-object v8

    .line 95
    if-eqz v8, :cond_2

    .line 96
    .line 97
    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    .line 98
    .line 99
    .line 100
    move-result-wide v8

    .line 101
    goto :goto_1

    .line 102
    :cond_2
    move-wide v8, v6

    .line 103
    :goto_1
    invoke-static {v8, v9}, LPa/r0;->Q(J)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v8

    .line 107
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v8

    .line 111
    invoke-virtual {v0, v5, v8}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v5

    .line 115
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 116
    .line 117
    .line 118
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->f:Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;

    .line 119
    .line 120
    const-string v5, "mItemPayMethod"

    .line 121
    .line 122
    if-eqz v3, :cond_53

    .line 123
    .line 124
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 125
    .line 126
    .line 127
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->f:Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;

    .line 128
    .line 129
    if-eqz v3, :cond_52

    .line 130
    .line 131
    if-eqz p1, :cond_3

    .line 132
    .line 133
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getPayerAccountType()Ljava/lang/Integer;

    .line 134
    .line 135
    .line 136
    move-result-object v8

    .line 137
    if-eqz v8, :cond_3

    .line 138
    .line 139
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 140
    .line 141
    .line 142
    move-result v8

    .line 143
    goto :goto_2

    .line 144
    :cond_3
    move v8, v1

    .line 145
    :goto_2
    if-eqz p1, :cond_4

    .line 146
    .line 147
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getBankName()Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v9

    .line 151
    goto :goto_3

    .line 152
    :cond_4
    move-object v9, v2

    .line 153
    :goto_3
    if-eqz p1, :cond_5

    .line 154
    .line 155
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getBankUrl()Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v10

    .line 159
    goto :goto_4

    .line 160
    :cond_5
    move-object v10, v2

    .line 161
    :goto_4
    if-eqz p1, :cond_6

    .line 162
    .line 163
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getPayerCardNo()Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object v11

    .line 167
    goto :goto_5

    .line 168
    :cond_6
    move-object v11, v2

    .line 169
    :goto_5
    invoke-static {v3, v8, v9, v10, v11}, LPa/r0;->S1(Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->o()Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;

    .line 173
    .line 174
    .line 175
    move-result-object v3

    .line 176
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;->i:Landroid/widget/ImageView;

    .line 177
    .line 178
    if-eqz p1, :cond_7

    .line 179
    .line 180
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->isMemberType()Z

    .line 181
    .line 182
    .line 183
    move-result v8

    .line 184
    if-ne v8, v4, :cond_7

    .line 185
    .line 186
    sget v8, Lcom/transsnet/palmpay/custom_view/r;->cv_bill_installment:I

    .line 187
    .line 188
    goto :goto_6

    .line 189
    :cond_7
    sget v8, Lcom/transsnet/palmpay/custom_view/r;->cv_bill_installment2:I

    .line 190
    .line 191
    :goto_6
    invoke-virtual {v3, v8}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->o()Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;

    .line 195
    .line 196
    .line 197
    move-result-object v3

    .line 198
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;->d:Landroid/widget/TextView;

    .line 199
    .line 200
    if-eqz p1, :cond_8

    .line 201
    .line 202
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->symbolAmount()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v8

    .line 206
    goto :goto_7

    .line 207
    :cond_8
    move-object v8, v2

    .line 208
    :goto_7
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 209
    .line 210
    .line 211
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 212
    .line 213
    if-eqz v3, :cond_9

    .line 214
    .line 215
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getCouponAmount()Ljava/lang/Long;

    .line 216
    .line 217
    .line 218
    move-result-object v3

    .line 219
    if-eqz v3, :cond_9

    .line 220
    .line 221
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 222
    .line 223
    .line 224
    move-result-wide v8

    .line 225
    goto :goto_8

    .line 226
    :cond_9
    move-wide v8, v6

    .line 227
    :goto_8
    cmp-long v3, v8, v6

    .line 228
    .line 229
    const-string v8, "- "

    .line 230
    .line 231
    const/16 v9, 0x8

    .line 232
    .line 233
    if-lez v3, :cond_b

    .line 234
    .line 235
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 236
    .line 237
    .line 238
    move-result-object v3

    .line 239
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->o:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 240
    .line 241
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 245
    .line 246
    .line 247
    move-result-object v3

    .line 248
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->o:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 249
    .line 250
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 251
    .line 252
    if-eqz v10, :cond_a

    .line 253
    .line 254
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getCouponAmount()Ljava/lang/Long;

    .line 255
    .line 256
    .line 257
    move-result-object v10

    .line 258
    if-eqz v10, :cond_a

    .line 259
    .line 260
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 261
    .line 262
    .line 263
    move-result-wide v10

    .line 264
    goto :goto_9

    .line 265
    :cond_a
    move-wide v10, v6

    .line 266
    :goto_9
    invoke-static {v10, v11, v4}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v10

    .line 270
    new-instance v11, Ljava/lang/StringBuilder;

    .line 271
    .line 272
    invoke-direct {v11, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 276
    .line 277
    .line 278
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v10

    .line 282
    invoke-virtual {v3, v10}, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->setContent(Ljava/lang/String;)V

    .line 283
    .line 284
    .line 285
    goto :goto_a

    .line 286
    :cond_b
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 287
    .line 288
    .line 289
    move-result-object v3

    .line 290
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->o:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 291
    .line 292
    invoke-virtual {v3, v9}, Landroid/view/View;->setVisibility(I)V

    .line 293
    .line 294
    .line 295
    :goto_a
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 296
    .line 297
    if-eqz v3, :cond_c

    .line 298
    .line 299
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getDiscountAmount()Ljava/lang/Long;

    .line 300
    .line 301
    .line 302
    move-result-object v3

    .line 303
    if-eqz v3, :cond_c

    .line 304
    .line 305
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 306
    .line 307
    .line 308
    move-result-wide v10

    .line 309
    goto :goto_b

    .line 310
    :cond_c
    move-wide v10, v6

    .line 311
    :goto_b
    cmp-long v3, v10, v6

    .line 312
    .line 313
    if-lez v3, :cond_e

    .line 314
    .line 315
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 316
    .line 317
    .line 318
    move-result-object v3

    .line 319
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->p:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 320
    .line 321
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 322
    .line 323
    .line 324
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 325
    .line 326
    .line 327
    move-result-object v3

    .line 328
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->p:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 329
    .line 330
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 331
    .line 332
    if-eqz v10, :cond_d

    .line 333
    .line 334
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getDiscountAmount()Ljava/lang/Long;

    .line 335
    .line 336
    .line 337
    move-result-object v10

    .line 338
    if-eqz v10, :cond_d

    .line 339
    .line 340
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 341
    .line 342
    .line 343
    move-result-wide v10

    .line 344
    goto :goto_c

    .line 345
    :cond_d
    move-wide v10, v6

    .line 346
    :goto_c
    invoke-static {v10, v11, v4}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object v10

    .line 350
    new-instance v11, Ljava/lang/StringBuilder;

    .line 351
    .line 352
    invoke-direct {v11, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 353
    .line 354
    .line 355
    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 356
    .line 357
    .line 358
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object v10

    .line 362
    invoke-virtual {v3, v10}, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->setContent(Ljava/lang/String;)V

    .line 363
    .line 364
    .line 365
    goto :goto_d

    .line 366
    :cond_e
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 367
    .line 368
    .line 369
    move-result-object v3

    .line 370
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->p:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 371
    .line 372
    invoke-virtual {v3, v9}, Landroid/view/View;->setVisibility(I)V

    .line 373
    .line 374
    .line 375
    :goto_d
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 376
    .line 377
    .line 378
    move-result-object v3

    .line 379
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->c:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 380
    .line 381
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->d:Landroid/widget/TextView;

    .line 382
    .line 383
    if-eqz p1, :cond_f

    .line 384
    .line 385
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getOrderAmount()Ljava/lang/Long;

    .line 386
    .line 387
    .line 388
    move-result-object v10

    .line 389
    if-eqz v10, :cond_f

    .line 390
    .line 391
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 392
    .line 393
    .line 394
    move-result-wide v10

    .line 395
    goto :goto_e

    .line 396
    :cond_f
    move-wide v10, v6

    .line 397
    :goto_e
    invoke-static {v10, v11, v1}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 398
    .line 399
    .line 400
    move-result-object v10

    .line 401
    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 402
    .line 403
    .line 404
    if-eqz p1, :cond_10

    .line 405
    .line 406
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getLoyaltyPoint()Ljava/lang/Long;

    .line 407
    .line 408
    .line 409
    move-result-object v3

    .line 410
    if-eqz v3, :cond_10

    .line 411
    .line 412
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 413
    .line 414
    .line 415
    move-result-wide v10

    .line 416
    goto :goto_f

    .line 417
    :cond_10
    move-wide v10, v6

    .line 418
    :goto_f
    cmp-long v3, v10, v6

    .line 419
    .line 420
    if-lez v3, :cond_12

    .line 421
    .line 422
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 423
    .line 424
    .line 425
    move-result-object v3

    .line 426
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->f:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 427
    .line 428
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 429
    .line 430
    .line 431
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 432
    .line 433
    .line 434
    move-result-object v3

    .line 435
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->f:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 436
    .line 437
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->d:Landroid/widget/TextView;

    .line 438
    .line 439
    if-eqz p1, :cond_11

    .line 440
    .line 441
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getLoyaltyPoint()Ljava/lang/Long;

    .line 442
    .line 443
    .line 444
    move-result-object v10

    .line 445
    goto :goto_10

    .line 446
    :cond_11
    move-object v10, v2

    .line 447
    :goto_10
    new-instance v11, Ljava/lang/StringBuilder;

    .line 448
    .line 449
    const-string v12, "- P "

    .line 450
    .line 451
    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 452
    .line 453
    .line 454
    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 455
    .line 456
    .line 457
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 458
    .line 459
    .line 460
    move-result-object v10

    .line 461
    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 462
    .line 463
    .line 464
    goto :goto_11

    .line 465
    :cond_12
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 466
    .line 467
    .line 468
    move-result-object v3

    .line 469
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->f:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 470
    .line 471
    invoke-virtual {v3, v9}, Landroid/view/View;->setVisibility(I)V

    .line 472
    .line 473
    .line 474
    :goto_11
    if-eqz p1, :cond_13

    .line 475
    .line 476
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getReturnPoint()Ljava/lang/Long;

    .line 477
    .line 478
    .line 479
    move-result-object v3

    .line 480
    if-eqz v3, :cond_13

    .line 481
    .line 482
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 483
    .line 484
    .line 485
    move-result-wide v10

    .line 486
    goto :goto_12

    .line 487
    :cond_13
    move-wide v10, v6

    .line 488
    :goto_12
    cmp-long v3, v10, v6

    .line 489
    .line 490
    if-lez v3, :cond_15

    .line 491
    .line 492
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 493
    .line 494
    .line 495
    move-result-object v3

    .line 496
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->g:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 497
    .line 498
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 499
    .line 500
    .line 501
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 502
    .line 503
    .line 504
    move-result-object v3

    .line 505
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->g:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 506
    .line 507
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->d:Landroid/widget/TextView;

    .line 508
    .line 509
    if-eqz p1, :cond_14

    .line 510
    .line 511
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getReturnPoint()Ljava/lang/Long;

    .line 512
    .line 513
    .line 514
    move-result-object v10

    .line 515
    goto :goto_13

    .line 516
    :cond_14
    move-object v10, v2

    .line 517
    :goto_13
    new-instance v11, Ljava/lang/StringBuilder;

    .line 518
    .line 519
    const-string v12, "P "

    .line 520
    .line 521
    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 522
    .line 523
    .line 524
    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 525
    .line 526
    .line 527
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 528
    .line 529
    .line 530
    move-result-object v10

    .line 531
    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 532
    .line 533
    .line 534
    goto :goto_14

    .line 535
    :cond_15
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 536
    .line 537
    .line 538
    move-result-object v3

    .line 539
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->g:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 540
    .line 541
    invoke-virtual {v3, v9}, Landroid/view/View;->setVisibility(I)V

    .line 542
    .line 543
    .line 544
    :goto_14
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 545
    .line 546
    if-eqz v3, :cond_16

    .line 547
    .line 548
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getBusinessDiscountAmount()J

    .line 549
    .line 550
    .line 551
    move-result-wide v10

    .line 552
    goto :goto_15

    .line 553
    :cond_16
    move-wide v10, v6

    .line 554
    :goto_15
    cmp-long v3, v10, v6

    .line 555
    .line 556
    const-string v10, "mItemPayShopCoupon"

    .line 557
    .line 558
    if-lez v3, :cond_18

    .line 559
    .line 560
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 561
    .line 562
    .line 563
    move-result-object v3

    .line 564
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->v:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 565
    .line 566
    invoke-static {v3, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 567
    .line 568
    .line 569
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 570
    .line 571
    .line 572
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 573
    .line 574
    .line 575
    move-result-object v3

    .line 576
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->v:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 577
    .line 578
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 579
    .line 580
    if-eqz v10, :cond_17

    .line 581
    .line 582
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getBusinessDiscountAmount()J

    .line 583
    .line 584
    .line 585
    move-result-wide v10

    .line 586
    goto :goto_16

    .line 587
    :cond_17
    move-wide v10, v6

    .line 588
    :goto_16
    invoke-static {v10, v11, v4}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 589
    .line 590
    .line 591
    move-result-object v10

    .line 592
    new-instance v11, Ljava/lang/StringBuilder;

    .line 593
    .line 594
    invoke-direct {v11, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 595
    .line 596
    .line 597
    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 598
    .line 599
    .line 600
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 601
    .line 602
    .line 603
    move-result-object v8

    .line 604
    invoke-virtual {v3, v8}, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->setContent(Ljava/lang/String;)V

    .line 605
    .line 606
    .line 607
    goto :goto_17

    .line 608
    :cond_18
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 609
    .line 610
    .line 611
    move-result-object v3

    .line 612
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->v:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 613
    .line 614
    invoke-static {v3, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 615
    .line 616
    .line 617
    invoke-static {v3}, Loa/h;->c(Landroid/view/View;)V

    .line 618
    .line 619
    .line 620
    :goto_17
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 621
    .line 622
    .line 623
    move-result-object v3

    .line 624
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->j:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 625
    .line 626
    if-eqz p1, :cond_19

    .line 627
    .line 628
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getGrantAwardValue()J

    .line 629
    .line 630
    .line 631
    move-result-wide v10

    .line 632
    goto :goto_18

    .line 633
    :cond_19
    move-wide v10, v6

    .line 634
    :goto_18
    cmp-long v8, v10, v6

    .line 635
    .line 636
    if-lez v8, :cond_1a

    .line 637
    .line 638
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 639
    .line 640
    .line 641
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 642
    .line 643
    .line 644
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->d:Landroid/widget/TextView;

    .line 645
    .line 646
    new-instance v8, Ljava/lang/StringBuilder;

    .line 647
    .line 648
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 649
    .line 650
    .line 651
    invoke-virtual {v8, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 652
    .line 653
    .line 654
    const-string v10, "MB"

    .line 655
    .line 656
    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 657
    .line 658
    .line 659
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 660
    .line 661
    .line 662
    move-result-object v8

    .line 663
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 664
    .line 665
    .line 666
    const-string v8, "#FFAA0C"

    .line 667
    .line 668
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 669
    .line 670
    .line 671
    move-result v8

    .line 672
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 673
    .line 674
    .line 675
    goto :goto_19

    .line 676
    :cond_1a
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 677
    .line 678
    .line 679
    invoke-static {v3}, Loa/h;->c(Landroid/view/View;)V

    .line 680
    .line 681
    .line 682
    :goto_19
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 683
    .line 684
    .line 685
    move-result-object v3

    .line 686
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->e:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 687
    .line 688
    invoke-virtual {v3, v9}, Landroid/view/View;->setVisibility(I)V

    .line 689
    .line 690
    .line 691
    if-eqz p1, :cond_1b

    .line 692
    .line 693
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getPayFee()Ljava/lang/Long;

    .line 694
    .line 695
    .line 696
    move-result-object v3

    .line 697
    if-eqz v3, :cond_1b

    .line 698
    .line 699
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 700
    .line 701
    .line 702
    move-result-wide v10

    .line 703
    goto :goto_1a

    .line 704
    :cond_1b
    move-wide v10, v6

    .line 705
    :goto_1a
    if-eqz p1, :cond_1c

    .line 706
    .line 707
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getTaxFee()Ljava/lang/Long;

    .line 708
    .line 709
    .line 710
    move-result-object v3

    .line 711
    if-eqz v3, :cond_1c

    .line 712
    .line 713
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 714
    .line 715
    .line 716
    move-result-wide v12

    .line 717
    goto :goto_1b

    .line 718
    :cond_1c
    move-wide v12, v6

    .line 719
    :goto_1b
    add-long/2addr v10, v12

    .line 720
    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 721
    .line 722
    .line 723
    move-result-object v3

    .line 724
    cmp-long v8, v10, v6

    .line 725
    .line 726
    if-lez v8, :cond_1d

    .line 727
    .line 728
    goto :goto_1c

    .line 729
    :cond_1d
    move-object v3, v2

    .line 730
    :goto_1c
    if-eqz v3, :cond_1f

    .line 731
    .line 732
    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    .line 733
    .line 734
    .line 735
    move-result-wide v10

    .line 736
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 737
    .line 738
    .line 739
    move-result-object v3

    .line 740
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->e:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 741
    .line 742
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 743
    .line 744
    .line 745
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 746
    .line 747
    .line 748
    move-result-object v3

    .line 749
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->e:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 750
    .line 751
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->d:Landroid/widget/TextView;

    .line 752
    .line 753
    invoke-static {v10, v11, v1}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 754
    .line 755
    .line 756
    move-result-object v8

    .line 757
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 758
    .line 759
    .line 760
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 761
    .line 762
    .line 763
    move-result-object v3

    .line 764
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->e:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 765
    .line 766
    if-eqz p1, :cond_1e

    .line 767
    .line 768
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getTaxFee()Ljava/lang/Long;

    .line 769
    .line 770
    .line 771
    move-result-object v8

    .line 772
    if-eqz v8, :cond_1e

    .line 773
    .line 774
    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    .line 775
    .line 776
    .line 777
    move-result-wide v10

    .line 778
    goto :goto_1d

    .line 779
    :cond_1e
    move-wide v10, v6

    .line 780
    :goto_1d
    invoke-static {v0, v10, v11}, LPa/r0;->W(Landroid/content/Context;J)Ljava/lang/String;

    .line 781
    .line 782
    .line 783
    move-result-object v8

    .line 784
    invoke-virtual {v3, v8}, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->setTips(Ljava/lang/String;)V

    .line 785
    .line 786
    .line 787
    :cond_1f
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 788
    .line 789
    .line 790
    move-result-object v3

    .line 791
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->w:Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;

    .line 792
    .line 793
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTextItem1;->d:Landroid/widget/TextView;

    .line 794
    .line 795
    if-eqz p1, :cond_20

    .line 796
    .line 797
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getPayAmount()Ljava/lang/Long;

    .line 798
    .line 799
    .line 800
    move-result-object v8

    .line 801
    if-eqz v8, :cond_20

    .line 802
    .line 803
    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    .line 804
    .line 805
    .line 806
    move-result-wide v10

    .line 807
    goto :goto_1e

    .line 808
    :cond_20
    move-wide v10, v6

    .line 809
    :goto_1e
    invoke-static {v10, v11, v1}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 810
    .line 811
    .line 812
    move-result-object v8

    .line 813
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 814
    .line 815
    .line 816
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->o()Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;

    .line 817
    .line 818
    .line 819
    move-result-object v3

    .line 820
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;->e:Landroid/widget/TextView;

    .line 821
    .line 822
    if-eqz p1, :cond_21

    .line 823
    .line 824
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getOrderStatusDesc()Ljava/lang/String;

    .line 825
    .line 826
    .line 827
    move-result-object v8

    .line 828
    goto :goto_1f

    .line 829
    :cond_21
    move-object v8, v2

    .line 830
    :goto_1f
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 831
    .line 832
    .line 833
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->o()Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;

    .line 834
    .line 835
    .line 836
    move-result-object v3

    .line 837
    iget-object v3, v3, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;->e:Landroid/widget/TextView;

    .line 838
    .line 839
    const/4 v8, -0x1

    .line 840
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 841
    .line 842
    .line 843
    if-eqz p1, :cond_22

    .line 844
    .line 845
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getErrorMsg()Ljava/lang/String;

    .line 846
    .line 847
    .line 848
    move-result-object v3

    .line 849
    goto :goto_20

    .line 850
    :cond_22
    move-object v3, v2

    .line 851
    :goto_20
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 852
    .line 853
    .line 854
    move-result v3

    .line 855
    if-nez v3, :cond_26

    .line 856
    .line 857
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->v:Landroid/widget/LinearLayout;

    .line 858
    .line 859
    if-eqz v3, :cond_25

    .line 860
    .line 861
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 862
    .line 863
    .line 864
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->A:Landroid/widget/TextView;

    .line 865
    .line 866
    if-eqz v3, :cond_24

    .line 867
    .line 868
    if-eqz p1, :cond_23

    .line 869
    .line 870
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getErrorMsg()Ljava/lang/String;

    .line 871
    .line 872
    .line 873
    move-result-object v8

    .line 874
    goto :goto_21

    .line 875
    :cond_23
    move-object v8, v2

    .line 876
    :goto_21
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 877
    .line 878
    .line 879
    goto :goto_22

    .line 880
    :cond_24
    const-string p1, "mErrorReasonTv"

    .line 881
    .line 882
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 883
    .line 884
    .line 885
    throw v2

    .line 886
    :cond_25
    const-string p1, "mErrorReasonArea"

    .line 887
    .line 888
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 889
    .line 890
    .line 891
    throw v2

    .line 892
    :cond_26
    :goto_22
    if-eqz p1, :cond_27

    .line 893
    .line 894
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getOrderStatus()Ljava/lang/Integer;

    .line 895
    .line 896
    .line 897
    move-result-object v3

    .line 898
    goto :goto_23

    .line 899
    :cond_27
    move-object v3, v2

    .line 900
    :goto_23
    if-nez v3, :cond_28

    .line 901
    .line 902
    goto :goto_24

    .line 903
    :cond_28
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 904
    .line 905
    .line 906
    move-result v8

    .line 907
    if-eqz v8, :cond_35

    .line 908
    .line 909
    :goto_24
    if-nez v3, :cond_29

    .line 910
    .line 911
    goto :goto_25

    .line 912
    :cond_29
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 913
    .line 914
    .line 915
    move-result v8

    .line 916
    const/4 v10, 0x5

    .line 917
    if-eq v8, v10, :cond_35

    .line 918
    .line 919
    :goto_25
    if-nez v3, :cond_2a

    .line 920
    .line 921
    goto :goto_26

    .line 922
    :cond_2a
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 923
    .line 924
    .line 925
    move-result v8

    .line 926
    if-eq v8, v9, :cond_35

    .line 927
    .line 928
    :goto_26
    if-nez v3, :cond_2b

    .line 929
    .line 930
    goto :goto_27

    .line 931
    :cond_2b
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 932
    .line 933
    .line 934
    move-result v8

    .line 935
    const/16 v10, 0x9

    .line 936
    .line 937
    if-eq v8, v10, :cond_35

    .line 938
    .line 939
    :goto_27
    if-nez v3, :cond_2c

    .line 940
    .line 941
    goto :goto_28

    .line 942
    :cond_2c
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 943
    .line 944
    .line 945
    move-result v8

    .line 946
    const/16 v10, 0xa

    .line 947
    .line 948
    if-eq v8, v10, :cond_35

    .line 949
    .line 950
    :goto_28
    if-nez v3, :cond_2d

    .line 951
    .line 952
    goto :goto_29

    .line 953
    :cond_2d
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 954
    .line 955
    .line 956
    move-result v8

    .line 957
    const/16 v10, 0xb

    .line 958
    .line 959
    if-ne v8, v10, :cond_2e

    .line 960
    .line 961
    goto :goto_2d

    .line 962
    :cond_2e
    :goto_29
    if-nez v3, :cond_2f

    .line 963
    .line 964
    goto :goto_2a

    .line 965
    :cond_2f
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 966
    .line 967
    .line 968
    move-result v8

    .line 969
    if-eq v8, v4, :cond_36

    .line 970
    .line 971
    :goto_2a
    if-nez v3, :cond_30

    .line 972
    .line 973
    goto :goto_2b

    .line 974
    :cond_30
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 975
    .line 976
    .line 977
    move-result v8

    .line 978
    const/4 v10, 0x7

    .line 979
    if-ne v8, v10, :cond_31

    .line 980
    .line 981
    goto :goto_2e

    .line 982
    :cond_31
    :goto_2b
    if-nez v3, :cond_32

    .line 983
    .line 984
    goto :goto_2c

    .line 985
    :cond_32
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 986
    .line 987
    .line 988
    move-result v8

    .line 989
    const/4 v10, 0x3

    .line 990
    if-eq v8, v10, :cond_34

    .line 991
    .line 992
    :goto_2c
    if-nez v3, :cond_33

    .line 993
    .line 994
    goto :goto_2e

    .line 995
    :cond_33
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 996
    .line 997
    .line 998
    move-result v3

    .line 999
    const/4 v8, 0x6

    .line 1000
    if-ne v3, v8, :cond_36

    .line 1001
    .line 1002
    :cond_34
    sget v3, Lba/e;->lhtidp_root:I

    .line 1003
    .line 1004
    invoke-virtual {v0, v3}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 1005
    .line 1006
    .line 1007
    move-result-object v3

    .line 1008
    invoke-virtual {v3, v9}, Landroid/view/View;->setVisibility(I)V

    .line 1009
    .line 1010
    .line 1011
    goto :goto_2e

    .line 1012
    :cond_35
    :goto_2d
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->f:Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;

    .line 1013
    .line 1014
    if-eqz v3, :cond_51

    .line 1015
    .line 1016
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;->d()V

    .line 1017
    .line 1018
    .line 1019
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->g:Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;

    .line 1020
    .line 1021
    if-eqz v3, :cond_50

    .line 1022
    .line 1023
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;->d()V

    .line 1024
    .line 1025
    .line 1026
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->n()Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;

    .line 1027
    .line 1028
    .line 1029
    move-result-object v3

    .line 1030
    invoke-virtual {v3}, Lcom/transsnet/palmpay/custom_view/model/ModelAmountList;->d()V

    .line 1031
    .line 1032
    .line 1033
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->w:Landroid/widget/RelativeLayout;

    .line 1034
    .line 1035
    if-eqz v3, :cond_4f

    .line 1036
    .line 1037
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1038
    .line 1039
    .line 1040
    :cond_36
    :goto_2e
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->L:Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;

    .line 1041
    .line 1042
    if-eqz v3, :cond_4e

    .line 1043
    .line 1044
    sget v8, Lba/k;->core_email_title:I

    .line 1045
    .line 1046
    invoke-virtual {v0, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1047
    .line 1048
    .line 1049
    move-result-object v8

    .line 1050
    const-string v9, "getString(...)"

    .line 1051
    .line 1052
    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1053
    .line 1054
    .line 1055
    new-instance v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;

    .line 1056
    .line 1057
    invoke-direct {v9}, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;-><init>()V

    .line 1058
    .line 1059
    .line 1060
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1061
    .line 1062
    if-eqz v10, :cond_44

    .line 1063
    .line 1064
    sget v10, Lba/k;->core_instalment:I

    .line 1065
    .line 1066
    invoke-virtual {v0, v10}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1067
    .line 1068
    .line 1069
    move-result-object v10

    .line 1070
    iput-object v10, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->paymentType:Ljava/lang/String;

    .line 1071
    .line 1072
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1073
    .line 1074
    if-eqz v10, :cond_37

    .line 1075
    .line 1076
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getUpdateTime()Ljava/lang/Long;

    .line 1077
    .line 1078
    .line 1079
    move-result-object v10

    .line 1080
    if-eqz v10, :cond_37

    .line 1081
    .line 1082
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 1083
    .line 1084
    .line 1085
    move-result-wide v10

    .line 1086
    goto :goto_2f

    .line 1087
    :cond_37
    move-wide v10, v6

    .line 1088
    :goto_2f
    iput-wide v10, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->time:J

    .line 1089
    .line 1090
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1091
    .line 1092
    if-eqz v10, :cond_38

    .line 1093
    .line 1094
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getPayAmount()Ljava/lang/Long;

    .line 1095
    .line 1096
    .line 1097
    move-result-object v10

    .line 1098
    if-eqz v10, :cond_38

    .line 1099
    .line 1100
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 1101
    .line 1102
    .line 1103
    move-result-wide v10

    .line 1104
    goto :goto_30

    .line 1105
    :cond_38
    move-wide v10, v6

    .line 1106
    :goto_30
    iput-wide v10, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->amount:J

    .line 1107
    .line 1108
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1109
    .line 1110
    if-eqz v10, :cond_39

    .line 1111
    .line 1112
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getPayFee()Ljava/lang/Long;

    .line 1113
    .line 1114
    .line 1115
    move-result-object v10

    .line 1116
    if-eqz v10, :cond_39

    .line 1117
    .line 1118
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 1119
    .line 1120
    .line 1121
    move-result-wide v10

    .line 1122
    goto :goto_31

    .line 1123
    :cond_39
    move-wide v10, v6

    .line 1124
    :goto_31
    iput-wide v10, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->fee:J

    .line 1125
    .line 1126
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1127
    .line 1128
    const-string v11, ""

    .line 1129
    .line 1130
    if-eqz v10, :cond_3a

    .line 1131
    .line 1132
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getOrderNo()Ljava/lang/String;

    .line 1133
    .line 1134
    .line 1135
    move-result-object v10

    .line 1136
    if-nez v10, :cond_3b

    .line 1137
    .line 1138
    :cond_3a
    move-object v10, v11

    .line 1139
    :cond_3b
    iput-object v10, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->orderNumber:Ljava/lang/String;

    .line 1140
    .line 1141
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1142
    .line 1143
    if-eqz v10, :cond_3c

    .line 1144
    .line 1145
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getOrderStatusDesc()Ljava/lang/String;

    .line 1146
    .line 1147
    .line 1148
    move-result-object v10

    .line 1149
    if-nez v10, :cond_3d

    .line 1150
    .line 1151
    :cond_3c
    move-object v10, v11

    .line 1152
    :cond_3d
    iput-object v10, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->orderStatus:Ljava/lang/String;

    .line 1153
    .line 1154
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1155
    .line 1156
    if-eqz v10, :cond_3e

    .line 1157
    .line 1158
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getTaxFee()Ljava/lang/Long;

    .line 1159
    .line 1160
    .line 1161
    move-result-object v10

    .line 1162
    if-eqz v10, :cond_3e

    .line 1163
    .line 1164
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 1165
    .line 1166
    .line 1167
    move-result-wide v12

    .line 1168
    goto :goto_32

    .line 1169
    :cond_3e
    move-wide v12, v6

    .line 1170
    :goto_32
    iput-wide v12, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->vat:J

    .line 1171
    .line 1172
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1173
    .line 1174
    if-eqz v10, :cond_3f

    .line 1175
    .line 1176
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getLoyaltyPoint()Ljava/lang/Long;

    .line 1177
    .line 1178
    .line 1179
    move-result-object v10

    .line 1180
    if-eqz v10, :cond_3f

    .line 1181
    .line 1182
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 1183
    .line 1184
    .line 1185
    move-result-wide v12

    .line 1186
    goto :goto_33

    .line 1187
    :cond_3f
    move-wide v12, v6

    .line 1188
    :goto_33
    iput-wide v12, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->pointsUsed:J

    .line 1189
    .line 1190
    iget-object v10, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1191
    .line 1192
    if-eqz v10, :cond_40

    .line 1193
    .line 1194
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getReturnPoint()Ljava/lang/Long;

    .line 1195
    .line 1196
    .line 1197
    move-result-object v10

    .line 1198
    if-eqz v10, :cond_40

    .line 1199
    .line 1200
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    .line 1201
    .line 1202
    .line 1203
    move-result-wide v6

    .line 1204
    :cond_40
    iput-wide v6, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->pointsEarned:J

    .line 1205
    .line 1206
    iget-object v6, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->M:Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;

    .line 1207
    .line 1208
    if-eqz v6, :cond_42

    .line 1209
    .line 1210
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getFaqLink()Ljava/lang/String;

    .line 1211
    .line 1212
    .line 1213
    move-result-object v6

    .line 1214
    if-nez v6, :cond_41

    .line 1215
    .line 1216
    goto :goto_34

    .line 1217
    :cond_41
    move-object v11, v6

    .line 1218
    :cond_42
    :goto_34
    iput-object v11, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->faqUrl:Ljava/lang/String;

    .line 1219
    .line 1220
    const-string v6, "o1"

    .line 1221
    .line 1222
    iput-object v6, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->transType:Ljava/lang/String;

    .line 1223
    .line 1224
    iget-object v6, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->f:Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;

    .line 1225
    .line 1226
    if-eqz v6, :cond_43

    .line 1227
    .line 1228
    iget-object v5, v6, Lcom/transsnet/palmpay/custom_view/model/ModelTitleContentImg;->d:Landroid/widget/TextView;

    .line 1229
    .line 1230
    invoke-virtual {v5}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 1231
    .line 1232
    .line 1233
    move-result-object v5

    .line 1234
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1235
    .line 1236
    .line 1237
    move-result-object v5

    .line 1238
    iput-object v5, v9, Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;->paymentMethod:Ljava/lang/String;

    .line 1239
    .line 1240
    goto :goto_35

    .line 1241
    :cond_43
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1242
    .line 1243
    .line 1244
    throw v2

    .line 1245
    :cond_44
    :goto_35
    invoke-virtual {v3, v8, v9}, Lcom/transsnet/palmpay/core/viewmodel/ReportTransactionItem;->a(Ljava/lang/String;Lcom/transsnet/palmpay/core/bean/OrderInfoForCustomerService;)V

    .line 1246
    .line 1247
    .line 1248
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->p:Landroid/view/View;

    .line 1249
    .line 1250
    if-eqz v3, :cond_4d

    .line 1251
    .line 1252
    if-eqz p1, :cond_45

    .line 1253
    .line 1254
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getPayerAccountType()Ljava/lang/Integer;

    .line 1255
    .line 1256
    .line 1257
    move-result-object v5

    .line 1258
    if-eqz v5, :cond_45

    .line 1259
    .line 1260
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 1261
    .line 1262
    .line 1263
    move-result v5

    .line 1264
    goto :goto_36

    .line 1265
    :cond_45
    move v5, v1

    .line 1266
    :goto_36
    const/16 v6, 0x24

    .line 1267
    .line 1268
    if-ne v5, v6, :cond_47

    .line 1269
    .line 1270
    if-eqz p1, :cond_46

    .line 1271
    .line 1272
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->isCustomerType()Z

    .line 1273
    .line 1274
    .line 1275
    move-result v5

    .line 1276
    if-ne v5, v4, :cond_46

    .line 1277
    .line 1278
    move v5, v4

    .line 1279
    goto :goto_37

    .line 1280
    :cond_46
    move v5, v1

    .line 1281
    :goto_37
    if-eqz v5, :cond_47

    .line 1282
    .line 1283
    move v5, v4

    .line 1284
    goto :goto_38

    .line 1285
    :cond_47
    move v5, v1

    .line 1286
    :goto_38
    invoke-static {v3, v5}, Loa/h;->s(Landroid/view/View;Z)V

    .line 1287
    .line 1288
    .line 1289
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->H:Landroid/widget/TextView;

    .line 1290
    .line 1291
    if-eqz v3, :cond_4c

    .line 1292
    .line 1293
    sget v5, LYa/g;->cs_pay_in_s:I

    .line 1294
    .line 1295
    if-eqz p1, :cond_48

    .line 1296
    .line 1297
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getInstallmentsNumber()Ljava/lang/String;

    .line 1298
    .line 1299
    .line 1300
    move-result-object v2

    .line 1301
    :cond_48
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 1302
    .line 1303
    .line 1304
    move-result-object v2

    .line 1305
    invoke-virtual {v0, v5, v2}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1306
    .line 1307
    .line 1308
    move-result-object v2

    .line 1309
    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1310
    .line 1311
    .line 1312
    if-eqz p1, :cond_49

    .line 1313
    .line 1314
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->isCustomerType()Z

    .line 1315
    .line 1316
    .line 1317
    move-result v2

    .line 1318
    if-ne v2, v4, :cond_49

    .line 1319
    .line 1320
    move v2, v4

    .line 1321
    goto :goto_39

    .line 1322
    :cond_49
    move v2, v1

    .line 1323
    :goto_39
    if-eqz v2, :cond_4a

    .line 1324
    .line 1325
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->o()Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;

    .line 1326
    .line 1327
    .line 1328
    move-result-object v1

    .line 1329
    iget-object v1, v1, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;->c:Landroid/widget/TextView;

    .line 1330
    .line 1331
    sget v2, Lba/k;->core_to:I

    .line 1332
    .line 1333
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getMerchantName()Ljava/lang/String;

    .line 1334
    .line 1335
    .line 1336
    move-result-object p1

    .line 1337
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 1338
    .line 1339
    .line 1340
    move-result-object p1

    .line 1341
    invoke-virtual {v0, v2, p1}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1342
    .line 1343
    .line 1344
    move-result-object p1

    .line 1345
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1346
    .line 1347
    .line 1348
    return-void

    .line 1349
    :cond_4a
    if-eqz p1, :cond_4b

    .line 1350
    .line 1351
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->isMemberType()Z

    .line 1352
    .line 1353
    .line 1354
    move-result v2

    .line 1355
    if-ne v2, v4, :cond_4b

    .line 1356
    .line 1357
    move v1, v4

    .line 1358
    :cond_4b
    if-eqz v1, :cond_57

    .line 1359
    .line 1360
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcInstallmentBillDetailActivity;->o()Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;

    .line 1361
    .line 1362
    .line 1363
    move-result-object v1

    .line 1364
    iget-object v1, v1, Lcom/transsnet/palmpay/custom_view/model/ModelBillDetailTitle;->c:Landroid/widget/TextView;

    .line 1365
    .line 1366
    sget v2, Lba/k;->core_received_from:I

    .line 1367
    .line 1368
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentQRBillDetailResp$OcInstallmentQRBillDetailData;->getMemberName()Ljava/lang/String;

    .line 1369
    .line 1370
    .line 1371
    move-result-object p1

    .line 1372
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 1373
    .line 1374
    .line 1375
    move-result-object p1

    .line 1376
    invoke-virtual {v0, v2, p1}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1377
    .line 1378
    .line 1379
    move-result-object p1

    .line 1380
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1381
    .line 1382
    .line 1383
    return-void

    .line 1384
    :cond_4c
    const-string p1, "mPaymentPlanNum"

    .line 1385
    .line 1386
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1387
    .line 1388
    .line 1389
    throw v2

    .line 1390
    :cond_4d
    const-string p1, "mPaymentPlanView"

    .line 1391
    .line 1392
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1393
    .line 1394
    .line 1395
    throw v2

    .line 1396
    :cond_4e
    const-string p1, "mReportItem"

    .line 1397
    .line 1398
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1399
    .line 1400
    .line 1401
    throw v2

    .line 1402
    :cond_4f
    const-string p1, "mContactServiceArea"

    .line 1403
    .line 1404
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1405
    .line 1406
    .line 1407
    throw v2

    .line 1408
    :cond_50
    const-string p1, "mItemBillType"

    .line 1409
    .line 1410
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1411
    .line 1412
    .line 1413
    throw v2

    .line 1414
    :cond_51
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1415
    .line 1416
    .line 1417
    throw v2

    .line 1418
    :cond_52
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1419
    .line 1420
    .line 1421
    throw v2

    .line 1422
    :cond_53
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1423
    .line 1424
    .line 1425
    throw v2

    .line 1426
    :cond_54
    const-string p1, "mPostedDateTv"

    .line 1427
    .line 1428
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1429
    .line 1430
    .line 1431
    throw v2

    .line 1432
    :cond_55
    const-string p1, "mOrderDateTv"

    .line 1433
    .line 1434
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1435
    .line 1436
    .line 1437
    throw v2

    .line 1438
    :cond_56
    const-string p1, "mTradingNumberTv"

    .line 1439
    .line 1440
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 1441
    .line 1442
    .line 1443
    throw v2

    .line 1444
    :cond_57
    :goto_3a
    return-void

    .line 1445
    :cond_58
    if-eqz p1, :cond_59

    .line 1446
    .line 1447
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 1448
    .line 1449
    .line 1450
    move-result-object v2

    .line 1451
    :cond_59
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showErrorMessageDialog(Ljava/lang/String;)V

    .line 1452
    .line 1453
    .line 1454
    return-void
.end method
