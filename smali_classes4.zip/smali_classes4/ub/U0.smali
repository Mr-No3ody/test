.class public final synthetic Lub/U0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

.field public final synthetic c:Lcom/transsnet/palmpay/credit/ui/dialog/OcRepayExitDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;Lcom/transsnet/palmpay/credit/ui/dialog/OcRepayExitDialog;I)V
    .locals 0

    .line 1
    iput p3, p0, Lub/U0;->a:I

    iput-object p1, p0, Lub/U0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    iput-object p2, p0, Lub/U0;->c:Lcom/transsnet/palmpay/credit/ui/dialog/OcRepayExitDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    iget-object p1, p0, Lub/U0;->c:Lcom/transsnet/palmpay/credit/ui/dialog/OcRepayExitDialog;

    .line 2
    .line 3
    iget-object v0, p0, Lub/U0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 4
    .line 5
    iget v1, p0, Lub/U0;->a:I

    .line 6
    .line 7
    packed-switch v1, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 11
    .line 12
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->D()Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const/4 v2, 0x0

    .line 26
    if-eqz v1, :cond_0

    .line 27
    .line 28
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getWaiverType()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    move-object v1, v2

    .line 34
    :goto_0
    const-string v3, "FULL"

    .line 35
    .line 36
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-eqz v1, :cond_1

    .line 41
    .line 42
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->o()V

    .line 43
    .line 44
    .line 45
    const/4 v1, 0x1

    .line 46
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 47
    .line 48
    .line 49
    invoke-static {v0}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    new-instance v3, Lub/Z0;

    .line 54
    .line 55
    invoke-direct {v3, v0, v2}, Lub/Z0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;Lkotlin/coroutines/Continuation;)V

    .line 56
    .line 57
    .line 58
    const/4 v0, 0x3

    .line 59
    invoke-static {v1, v2, v2, v3, v0}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 60
    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_1
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->n()V

    .line 64
    .line 65
    .line 66
    :goto_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    nop

    .line 71
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
