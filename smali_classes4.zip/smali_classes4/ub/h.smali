.class public final Lub/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

.field public final synthetic c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;I)V
    .locals 0

    .line 1
    iput p3, p0, Lub/h;->a:I

    iput-object p1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    iput-object p2, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    iget v0, p0, Lub/h;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 14
    .line 15
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 21
    .line 22
    .line 23
    goto/16 :goto_2

    .line 24
    .line 25
    :cond_0
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 26
    .line 27
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 28
    .line 29
    const/4 v4, 0x0

    .line 30
    if-eqz v0, :cond_6

    .line 31
    .line 32
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 33
    .line 34
    .line 35
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 36
    .line 37
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusResp;

    .line 40
    .line 41
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_5

    .line 46
    .line 47
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusData;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    if-eqz v0, :cond_5

    .line 52
    .line 53
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusData;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    if-eqz p1, :cond_2

    .line 58
    .line 59
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusData;->getType()Ljava/lang/Integer;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    if-nez p1, :cond_1

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_1
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    if-nez p1, :cond_2

    .line 71
    .line 72
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->u()V

    .line 73
    .line 74
    .line 75
    goto :goto_2

    .line 76
    :cond_2
    :goto_0
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 77
    .line 78
    if-eqz p1, :cond_4

    .line 79
    .line 80
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getSceneType()Ljava/lang/Integer;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    if-nez p1, :cond_3

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_3
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 88
    .line 89
    .line 90
    move-result p1

    .line 91
    if-ne p1, v2, :cond_4

    .line 92
    .line 93
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->u()V

    .line 94
    .line 95
    .line 96
    goto :goto_2

    .line 97
    :cond_4
    :goto_1
    const/4 p1, 0x0

    .line 98
    const-string v0, "/credit_score/cl_last_protocol_activity"

    .line 99
    .line 100
    invoke-virtual {v3, v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->s(Ljava/lang/String;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    goto :goto_2

    .line 104
    :cond_5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    goto :goto_2

    .line 112
    :cond_6
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 113
    .line 114
    if-eqz v0, :cond_7

    .line 115
    .line 116
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 117
    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_7
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 121
    .line 122
    if-eqz v0, :cond_8

    .line 123
    .line 124
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 125
    .line 126
    .line 127
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 128
    .line 129
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 130
    .line 131
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    :goto_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 135
    .line 136
    return-object p1

    .line 137
    :cond_8
    new-instance p1, Lxf/l;

    .line 138
    .line 139
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 140
    .line 141
    .line 142
    throw p1

    .line 143
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 144
    .line 145
    const-string v0, "it"

    .line 146
    .line 147
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 151
    .line 152
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 153
    .line 154
    const/4 v2, 0x1

    .line 155
    if-eqz v0, :cond_9

    .line 156
    .line 157
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 158
    .line 159
    .line 160
    goto :goto_3

    .line 161
    :cond_9
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 162
    .line 163
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 164
    .line 165
    const/4 v4, 0x0

    .line 166
    if-eqz v0, :cond_b

    .line 167
    .line 168
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 169
    .line 170
    .line 171
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 172
    .line 173
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 174
    .line 175
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcSkipOneLoopResp;

    .line 176
    .line 177
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    if-eqz v0, :cond_a

    .line 182
    .line 183
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->i:Lcom/transsnet/palmpay/credit/ui/activity/okcard/b;

    .line 184
    .line 185
    if-eqz v0, :cond_d

    .line 186
    .line 187
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/b;->onSuccess(Lcom/transsnet/palmpay/credit/bean/resp/OcSkipOneLoopResp;)V

    .line 188
    .line 189
    .line 190
    goto :goto_3

    .line 191
    :cond_a
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    invoke-static {v3, v0}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->i:Lcom/transsnet/palmpay/credit/ui/activity/okcard/b;

    .line 199
    .line 200
    if-eqz v0, :cond_d

    .line 201
    .line 202
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object p1

    .line 206
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/b;->onFailed(Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    goto :goto_3

    .line 210
    :cond_b
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 211
    .line 212
    if-eqz v0, :cond_c

    .line 213
    .line 214
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 215
    .line 216
    .line 217
    goto :goto_3

    .line 218
    :cond_c
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 219
    .line 220
    if-eqz v0, :cond_e

    .line 221
    .line 222
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 223
    .line 224
    .line 225
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 226
    .line 227
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 228
    .line 229
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->i:Lcom/transsnet/palmpay/credit/ui/activity/okcard/b;

    .line 233
    .line 234
    if-eqz v0, :cond_d

    .line 235
    .line 236
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/b;->onFailed(Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    :cond_d
    :goto_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 240
    .line 241
    return-object p1

    .line 242
    :cond_e
    new-instance p1, Lxf/l;

    .line 243
    .line 244
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 245
    .line 246
    .line 247
    throw p1

    .line 248
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 249
    .line 250
    const-string v0, "it"

    .line 251
    .line 252
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 253
    .line 254
    .line 255
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 256
    .line 257
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 258
    .line 259
    const/4 v2, 0x1

    .line 260
    if-eqz v0, :cond_f

    .line 261
    .line 262
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 263
    .line 264
    .line 265
    goto/16 :goto_4

    .line 266
    .line 267
    :cond_f
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 268
    .line 269
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 270
    .line 271
    const/4 v4, 0x0

    .line 272
    if-eqz v0, :cond_13

    .line 273
    .line 274
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 275
    .line 276
    .line 277
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 278
    .line 279
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 280
    .line 281
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 282
    .line 283
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 284
    .line 285
    .line 286
    move-result v0

    .line 287
    if-eqz v0, :cond_11

    .line 288
    .line 289
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 290
    .line 291
    .line 292
    move-result-object p1

    .line 293
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 294
    .line 295
    .line 296
    move-result-object p1

    .line 297
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->M:Ljava/lang/String;

    .line 298
    .line 299
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 300
    .line 301
    .line 302
    move-result p1

    .line 303
    if-nez p1, :cond_10

    .line 304
    .line 305
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 306
    .line 307
    .line 308
    move-result-object p1

    .line 309
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 310
    .line 311
    .line 312
    move-result-object p1

    .line 313
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->Q:Ljava/lang/String;

    .line 314
    .line 315
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 316
    .line 317
    .line 318
    move-result p1

    .line 319
    if-nez p1, :cond_10

    .line 320
    .line 321
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 322
    .line 323
    add-int/2addr p1, v2

    .line 324
    iput p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 325
    .line 326
    :cond_10
    new-instance p1, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceSuccessDialog;

    .line 327
    .line 328
    invoke-direct {p1, v3}, Lcom/transsnet/palmpay/credit/ui/dialog/OcALiFaceSuccessDialog;-><init>(Landroid/content/Context;)V

    .line 329
    .line 330
    .line 331
    new-instance v0, LCe/T;

    .line 332
    .line 333
    const/16 v1, 0xa

    .line 334
    .line 335
    invoke-direct {v0, v3, v1}, LCe/T;-><init>(Ljava/lang/Object;I)V

    .line 336
    .line 337
    .line 338
    invoke-virtual {p1, v0}, LO6/f;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 339
    .line 340
    .line 341
    invoke-virtual {p1}, LO6/f;->show()V

    .line 342
    .line 343
    .line 344
    goto :goto_4

    .line 345
    :cond_11
    const-string v0, "LOAN0000051"

    .line 346
    .line 347
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 348
    .line 349
    .line 350
    move-result-object v1

    .line 351
    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 352
    .line 353
    .line 354
    move-result v0

    .line 355
    if-eqz v0, :cond_12

    .line 356
    .line 357
    new-instance v0, LO6/c;

    .line 358
    .line 359
    invoke-direct {v0, v3}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 360
    .line 361
    .line 362
    sget v1, LYa/d;->cs_failed_sorry_icon:I

    .line 363
    .line 364
    iput v1, v0, LO6/c;->m:I

    .line 365
    .line 366
    const-string v1, "Sorry"

    .line 367
    .line 368
    invoke-static {v1}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 369
    .line 370
    .line 371
    move-result-object v1

    .line 372
    iput-object v1, v0, LO6/c;->b:Ljava/lang/CharSequence;

    .line 373
    .line 374
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 375
    .line 376
    .line 377
    move-result-object p1

    .line 378
    iput-object p1, v0, LO6/c;->d:Ljava/lang/CharSequence;

    .line 379
    .line 380
    sget p1, LYa/g;->cs_confirm:I

    .line 381
    .line 382
    const/4 v1, 0x0

    .line 383
    invoke-virtual {v0, p1, v1}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 384
    .line 385
    .line 386
    invoke-virtual {v0}, LO6/c;->g()LO6/d;

    .line 387
    .line 388
    .line 389
    goto :goto_4

    .line 390
    :cond_12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 391
    .line 392
    .line 393
    move-result-object v0

    .line 394
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 395
    .line 396
    .line 397
    move-result v0

    .line 398
    if-nez v0, :cond_15

    .line 399
    .line 400
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 401
    .line 402
    .line 403
    move-result-object p1

    .line 404
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 405
    .line 406
    .line 407
    goto :goto_4

    .line 408
    :cond_13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 409
    .line 410
    if-eqz v0, :cond_14

    .line 411
    .line 412
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 413
    .line 414
    .line 415
    goto :goto_4

    .line 416
    :cond_14
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 417
    .line 418
    if-eqz v0, :cond_16

    .line 419
    .line 420
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 421
    .line 422
    .line 423
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 424
    .line 425
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 426
    .line 427
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 428
    .line 429
    .line 430
    :cond_15
    :goto_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 431
    .line 432
    return-object p1

    .line 433
    :cond_16
    new-instance p1, Lxf/l;

    .line 434
    .line 435
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 436
    .line 437
    .line 438
    throw p1

    .line 439
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 440
    .line 441
    const-string v0, "it"

    .line 442
    .line 443
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 447
    .line 448
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 449
    .line 450
    const/4 v2, 0x1

    .line 451
    if-eqz v0, :cond_17

    .line 452
    .line 453
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 454
    .line 455
    .line 456
    goto :goto_5

    .line 457
    :cond_17
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 458
    .line 459
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 460
    .line 461
    const/4 v4, 0x0

    .line 462
    if-eqz v0, :cond_19

    .line 463
    .line 464
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 465
    .line 466
    .line 467
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 468
    .line 469
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 470
    .line 471
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopDataResp;

    .line 472
    .line 473
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 474
    .line 475
    .line 476
    move-result v0

    .line 477
    if-eqz v0, :cond_18

    .line 478
    .line 479
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/h;

    .line 480
    .line 481
    if-eqz v0, :cond_1b

    .line 482
    .line 483
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopDataResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopData;

    .line 484
    .line 485
    .line 486
    move-result-object p1

    .line 487
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/h;->onSuccess(Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopData;)V

    .line 488
    .line 489
    .line 490
    goto :goto_5

    .line 491
    :cond_18
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 492
    .line 493
    .line 494
    move-result-object v0

    .line 495
    invoke-static {v3, v0}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 496
    .line 497
    .line 498
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/h;

    .line 499
    .line 500
    if-eqz v0, :cond_1b

    .line 501
    .line 502
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 503
    .line 504
    .line 505
    move-result-object p1

    .line 506
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/h;->onFailed(Ljava/lang/String;)V

    .line 507
    .line 508
    .line 509
    goto :goto_5

    .line 510
    :cond_19
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 511
    .line 512
    if-eqz v0, :cond_1a

    .line 513
    .line 514
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 515
    .line 516
    .line 517
    goto :goto_5

    .line 518
    :cond_1a
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 519
    .line 520
    if-eqz v0, :cond_1c

    .line 521
    .line 522
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 523
    .line 524
    .line 525
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 526
    .line 527
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 528
    .line 529
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 530
    .line 531
    .line 532
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/h;

    .line 533
    .line 534
    if-eqz v0, :cond_1b

    .line 535
    .line 536
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/h;->onFailed(Ljava/lang/String;)V

    .line 537
    .line 538
    .line 539
    :cond_1b
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 540
    .line 541
    return-object p1

    .line 542
    :cond_1c
    new-instance p1, Lxf/l;

    .line 543
    .line 544
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 545
    .line 546
    .line 547
    throw p1

    .line 548
    :pswitch_3
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 549
    .line 550
    const-string v0, "it"

    .line 551
    .line 552
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 553
    .line 554
    .line 555
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 556
    .line 557
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 558
    .line 559
    const/4 v2, 0x1

    .line 560
    if-eqz v0, :cond_1d

    .line 561
    .line 562
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 563
    .line 564
    .line 565
    goto :goto_6

    .line 566
    :cond_1d
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 567
    .line 568
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 569
    .line 570
    const/4 v4, 0x0

    .line 571
    if-eqz v0, :cond_1f

    .line 572
    .line 573
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 574
    .line 575
    .line 576
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 577
    .line 578
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 579
    .line 580
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;

    .line 581
    .line 582
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 583
    .line 584
    .line 585
    move-result v0

    .line 586
    if-eqz v0, :cond_1e

    .line 587
    .line 588
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity$VerifyInfoCallback;

    .line 589
    .line 590
    if-eqz v0, :cond_21

    .line 591
    .line 592
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;

    .line 593
    .line 594
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity$VerifyInfoCallback;->verifySuccess(Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;)V

    .line 595
    .line 596
    .line 597
    goto :goto_6

    .line 598
    :cond_1e
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 599
    .line 600
    .line 601
    move-result-object v0

    .line 602
    invoke-static {v3, v0}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 603
    .line 604
    .line 605
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity$VerifyInfoCallback;

    .line 606
    .line 607
    if-eqz v0, :cond_21

    .line 608
    .line 609
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 610
    .line 611
    .line 612
    move-result-object p1

    .line 613
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity$VerifyInfoCallback;->verifyFailed(Ljava/lang/String;)V

    .line 614
    .line 615
    .line 616
    goto :goto_6

    .line 617
    :cond_1f
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 618
    .line 619
    if-eqz v0, :cond_20

    .line 620
    .line 621
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 622
    .line 623
    .line 624
    goto :goto_6

    .line 625
    :cond_20
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 626
    .line 627
    if-eqz v0, :cond_22

    .line 628
    .line 629
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 630
    .line 631
    .line 632
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 633
    .line 634
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 635
    .line 636
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 637
    .line 638
    .line 639
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity$VerifyInfoCallback;

    .line 640
    .line 641
    if-eqz v0, :cond_21

    .line 642
    .line 643
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity$VerifyInfoCallback;->verifyFailed(Ljava/lang/String;)V

    .line 644
    .line 645
    .line 646
    :cond_21
    :goto_6
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 647
    .line 648
    return-object p1

    .line 649
    :cond_22
    new-instance p1, Lxf/l;

    .line 650
    .line 651
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 652
    .line 653
    .line 654
    throw p1

    .line 655
    :pswitch_4
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 656
    .line 657
    const-string v0, "it"

    .line 658
    .line 659
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 660
    .line 661
    .line 662
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 663
    .line 664
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 665
    .line 666
    const/4 v2, 0x1

    .line 667
    if-eqz v0, :cond_23

    .line 668
    .line 669
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 670
    .line 671
    .line 672
    goto/16 :goto_7

    .line 673
    .line 674
    :cond_23
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 675
    .line 676
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 677
    .line 678
    const/4 v4, 0x0

    .line 679
    if-eqz v0, :cond_25

    .line 680
    .line 681
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 682
    .line 683
    .line 684
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 685
    .line 686
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 687
    .line 688
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/CLInstallmentLoanMainPageResp;

    .line 689
    .line 690
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 691
    .line 692
    .line 693
    move-result v0

    .line 694
    if-nez v0, :cond_24

    .line 695
    .line 696
    invoke-static {v3, p1}, Loa/h;->w(Landroid/content/Context;Lcom/transsnet/palmpay/core/bean/CommonResult;)V

    .line 697
    .line 698
    .line 699
    goto :goto_7

    .line 700
    :cond_24
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 701
    .line 702
    .line 703
    move-result-object v0

    .line 704
    const-string v1, "/credit_score/ol_upgrade_installment_result_activity"

    .line 705
    .line 706
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 707
    .line 708
    .line 709
    move-result-object v0

    .line 710
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 711
    .line 712
    .line 713
    move-result-object v1

    .line 714
    iget-object v1, v1, LPa/w;->b:Ljava/lang/Object;

    .line 715
    .line 716
    check-cast v1, Lcom/google/gson/Gson;

    .line 717
    .line 718
    invoke-virtual {v1, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 719
    .line 720
    .line 721
    move-result-object p1

    .line 722
    const-string v1, "extra_data"

    .line 723
    .line 724
    invoke-virtual {v0, v1, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 725
    .line 726
    .line 727
    move-result-object p1

    .line 728
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 729
    .line 730
    .line 731
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 732
    .line 733
    .line 734
    goto :goto_7

    .line 735
    :cond_25
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 736
    .line 737
    if-eqz v0, :cond_26

    .line 738
    .line 739
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 740
    .line 741
    .line 742
    goto :goto_7

    .line 743
    :cond_26
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 744
    .line 745
    if-eqz v0, :cond_29

    .line 746
    .line 747
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 748
    .line 749
    .line 750
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 751
    .line 752
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 753
    .line 754
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 755
    .line 756
    const-string v1, "INSTALLMENT_RAISE_AMOUNT"

    .line 757
    .line 758
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 759
    .line 760
    .line 761
    move-result v1

    .line 762
    if-eqz v1, :cond_27

    .line 763
    .line 764
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 765
    .line 766
    .line 767
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 768
    .line 769
    .line 770
    goto :goto_7

    .line 771
    :cond_27
    const-string p1, "CASH_INSTALLMENT_RAISE_AMOUNT"

    .line 772
    .line 773
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 774
    .line 775
    .line 776
    move-result p1

    .line 777
    if-eqz p1, :cond_28

    .line 778
    .line 779
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 780
    .line 781
    add-int/lit8 p1, p1, -0x1

    .line 782
    .line 783
    iput p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 784
    .line 785
    :cond_28
    :goto_7
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 786
    .line 787
    return-object p1

    .line 788
    :cond_29
    new-instance p1, Lxf/l;

    .line 789
    .line 790
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 791
    .line 792
    .line 793
    throw p1

    .line 794
    :pswitch_5
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 795
    .line 796
    const-string v0, "it"

    .line 797
    .line 798
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 799
    .line 800
    .line 801
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 802
    .line 803
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 804
    .line 805
    const/4 v2, 0x1

    .line 806
    if-eqz v0, :cond_2a

    .line 807
    .line 808
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 809
    .line 810
    .line 811
    goto/16 :goto_8

    .line 812
    .line 813
    :cond_2a
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 814
    .line 815
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 816
    .line 817
    const-string v4, "INSTALLMENT_RAISE_AMOUNT"

    .line 818
    .line 819
    const-string v5, "CASH_INSTALLMENT_RAISE_AMOUNT"

    .line 820
    .line 821
    const/4 v6, 0x0

    .line 822
    if-eqz v0, :cond_2e

    .line 823
    .line 824
    invoke-interface {v1, v6, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 825
    .line 826
    .line 827
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 828
    .line 829
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 830
    .line 831
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentRaiseAmountRsp;

    .line 832
    .line 833
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 834
    .line 835
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 836
    .line 837
    .line 838
    move-result v1

    .line 839
    if-eqz v1, :cond_2c

    .line 840
    .line 841
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 842
    .line 843
    .line 844
    move-result v0

    .line 845
    if-nez v0, :cond_2b

    .line 846
    .line 847
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 848
    .line 849
    .line 850
    move-result-object p1

    .line 851
    sget v0, Lba/k;->core_confirm:I

    .line 852
    .line 853
    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 854
    .line 855
    .line 856
    move-result-object v0

    .line 857
    new-instance v1, Lma/e;

    .line 858
    .line 859
    const/16 v2, 0x10

    .line 860
    .line 861
    invoke-direct {v1, v3, v2}, Lma/e;-><init>(Ljava/lang/Object;I)V

    .line 862
    .line 863
    .line 864
    invoke-virtual {v3, p1, v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showErrorMessageDialog(Ljava/lang/String;Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 865
    .line 866
    .line 867
    goto/16 :goto_8

    .line 868
    .line 869
    :cond_2b
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 870
    .line 871
    .line 872
    move-result-object p1

    .line 873
    new-instance v0, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;

    .line 874
    .line 875
    const/16 v1, 0x181

    .line 876
    .line 877
    invoke-direct {v0, v1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;-><init>(I)V

    .line 878
    .line 879
    .line 880
    invoke-virtual {p1, v0}, Lorg/greenrobot/eventbus/c;->f(Ljava/lang/Object;)V

    .line 881
    .line 882
    .line 883
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 884
    .line 885
    .line 886
    goto :goto_8

    .line 887
    :cond_2c
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 888
    .line 889
    .line 890
    move-result v0

    .line 891
    if-eqz v0, :cond_31

    .line 892
    .line 893
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 894
    .line 895
    .line 896
    move-result v0

    .line 897
    if-nez v0, :cond_2d

    .line 898
    .line 899
    invoke-static {v3, p1}, Loa/h;->w(Landroid/content/Context;Lcom/transsnet/palmpay/core/bean/CommonResult;)V

    .line 900
    .line 901
    .line 902
    goto :goto_8

    .line 903
    :cond_2d
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 904
    .line 905
    .line 906
    move-result-object v0

    .line 907
    const-string v1, "/credit_score/ol_open_result_activity"

    .line 908
    .line 909
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 910
    .line 911
    .line 912
    move-result-object v0

    .line 913
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 914
    .line 915
    .line 916
    move-result-object v1

    .line 917
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentRaiseAmountRsp;->data:Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 918
    .line 919
    iget-object v1, v1, LPa/w;->b:Ljava/lang/Object;

    .line 920
    .line 921
    check-cast v1, Lcom/google/gson/Gson;

    .line 922
    .line 923
    invoke-virtual {v1, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 924
    .line 925
    .line 926
    move-result-object p1

    .line 927
    const-string v1, "cl_open_result"

    .line 928
    .line 929
    invoke-virtual {v0, v1, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 930
    .line 931
    .line 932
    move-result-object p1

    .line 933
    const-string v0, "cl_loan_product_type"

    .line 934
    .line 935
    invoke-virtual {p1, v0, v5}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 936
    .line 937
    .line 938
    move-result-object p1

    .line 939
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 940
    .line 941
    .line 942
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 943
    .line 944
    .line 945
    goto :goto_8

    .line 946
    :cond_2e
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 947
    .line 948
    if-eqz v0, :cond_2f

    .line 949
    .line 950
    invoke-interface {v1, v6, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 951
    .line 952
    .line 953
    goto :goto_8

    .line 954
    :cond_2f
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 955
    .line 956
    if-eqz v0, :cond_32

    .line 957
    .line 958
    invoke-interface {v1, v6, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 959
    .line 960
    .line 961
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 962
    .line 963
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 964
    .line 965
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 966
    .line 967
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 968
    .line 969
    .line 970
    move-result v1

    .line 971
    if-eqz v1, :cond_30

    .line 972
    .line 973
    invoke-static {v3, p1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 974
    .line 975
    .line 976
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 977
    .line 978
    .line 979
    goto :goto_8

    .line 980
    :cond_30
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 981
    .line 982
    .line 983
    move-result p1

    .line 984
    if-eqz p1, :cond_31

    .line 985
    .line 986
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 987
    .line 988
    add-int/lit8 p1, p1, -0x1

    .line 989
    .line 990
    iput p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 991
    .line 992
    :cond_31
    :goto_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 993
    .line 994
    return-object p1

    .line 995
    :cond_32
    new-instance p1, Lxf/l;

    .line 996
    .line 997
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 998
    .line 999
    .line 1000
    throw p1

    .line 1001
    :pswitch_6
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 1002
    .line 1003
    const-string v0, "it"

    .line 1004
    .line 1005
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1006
    .line 1007
    .line 1008
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 1009
    .line 1010
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 1011
    .line 1012
    const/4 v2, 0x1

    .line 1013
    if-eqz v0, :cond_33

    .line 1014
    .line 1015
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 1016
    .line 1017
    .line 1018
    goto/16 :goto_e

    .line 1019
    .line 1020
    :cond_33
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 1021
    .line 1022
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 1023
    .line 1024
    const/4 v4, 0x0

    .line 1025
    if-eqz v0, :cond_3e

    .line 1026
    .line 1027
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 1028
    .line 1029
    .line 1030
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 1031
    .line 1032
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 1033
    .line 1034
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;

    .line 1035
    .line 1036
    iget-object v0, v3, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 1037
    .line 1038
    const-string v1, "openCashLoanRsp >>>"

    .line 1039
    .line 1040
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 1041
    .line 1042
    .line 1043
    move-result-object v1

    .line 1044
    const/4 v5, 0x3

    .line 1045
    invoke-static {v0, v5, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1046
    .line 1047
    .line 1048
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 1049
    .line 1050
    .line 1051
    move-result v0

    .line 1052
    if-nez v0, :cond_35

    .line 1053
    .line 1054
    instance-of v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/cashloan/CLLastProtocolActivity;

    .line 1055
    .line 1056
    if-eqz v0, :cond_34

    .line 1057
    .line 1058
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 1059
    .line 1060
    .line 1061
    :cond_34
    invoke-static {v3, p1}, Loa/h;->w(Landroid/content/Context;Lcom/transsnet/palmpay/core/bean/CommonResult;)V

    .line 1062
    .line 1063
    .line 1064
    goto/16 :goto_c

    .line 1065
    .line 1066
    :cond_35
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 1067
    .line 1068
    .line 1069
    move-result-object v0

    .line 1070
    if-eqz v0, :cond_3d

    .line 1071
    .line 1072
    iget-object v0, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 1073
    .line 1074
    const/4 v1, 0x0

    .line 1075
    if-eqz v0, :cond_37

    .line 1076
    .line 1077
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getSceneType()Ljava/lang/Integer;

    .line 1078
    .line 1079
    .line 1080
    move-result-object v0

    .line 1081
    if-nez v0, :cond_36

    .line 1082
    .line 1083
    goto :goto_9

    .line 1084
    :cond_36
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 1085
    .line 1086
    .line 1087
    move-result v0

    .line 1088
    if-ne v0, v2, :cond_37

    .line 1089
    .line 1090
    const-string p1, "CreditBindSuccess"

    .line 1091
    .line 1092
    invoke-static {v1, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 1093
    .line 1094
    .line 1095
    goto/16 :goto_c

    .line 1096
    .line 1097
    :cond_37
    :goto_9
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 1098
    .line 1099
    .line 1100
    move-result-object p1

    .line 1101
    sget-object v0, Ljb/o;->z:Ljb/j;

    .line 1102
    .line 1103
    invoke-virtual {v0}, Ljb/j;->getInstance()Ljb/o;

    .line 1104
    .line 1105
    .line 1106
    move-result-object v2

    .line 1107
    iget-object v2, v2, Ljb/o;->n:Ljava/lang/Boolean;

    .line 1108
    .line 1109
    iget-object v6, v3, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 1110
    .line 1111
    iget-object v7, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 1112
    .line 1113
    new-instance v8, Ljava/lang/StringBuilder;

    .line 1114
    .line 1115
    const-string v9, "gotoApplyResultPage >>> mBusinessType="

    .line 1116
    .line 1117
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1118
    .line 1119
    .line 1120
    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1121
    .line 1122
    .line 1123
    const-string v7, ", jumpRnApplyResult="

    .line 1124
    .line 1125
    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1126
    .line 1127
    .line 1128
    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1129
    .line 1130
    .line 1131
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1132
    .line 1133
    .line 1134
    move-result-object v2

    .line 1135
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 1136
    .line 1137
    .line 1138
    move-result-object v2

    .line 1139
    invoke-static {v6, v5, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1140
    .line 1141
    .line 1142
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 1143
    .line 1144
    const-string v6, "PALMPAY_CARD"

    .line 1145
    .line 1146
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1147
    .line 1148
    .line 1149
    move-result v2

    .line 1150
    if-eqz v2, :cond_3b

    .line 1151
    .line 1152
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 1153
    .line 1154
    if-eqz p1, :cond_38

    .line 1155
    .line 1156
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplyId()Ljava/lang/String;

    .line 1157
    .line 1158
    .line 1159
    move-result-object v1

    .line 1160
    :cond_38
    invoke-virtual {v0}, Ljb/j;->getInstance()Ljb/o;

    .line 1161
    .line 1162
    .line 1163
    move-result-object p1

    .line 1164
    iget-object p1, p1, Ljb/o;->s:Ljava/lang/String;

    .line 1165
    .line 1166
    const-string v2, "gotoApplyResultPage >>> pendingUrl="

    .line 1167
    .line 1168
    invoke-static {v2, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1169
    .line 1170
    .line 1171
    move-result-object v2

    .line 1172
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 1173
    .line 1174
    .line 1175
    move-result-object v2

    .line 1176
    const-string v6, "CreditRouterManager"

    .line 1177
    .line 1178
    invoke-static {v6, v5, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1179
    .line 1180
    .line 1181
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1182
    .line 1183
    .line 1184
    move-result v2

    .line 1185
    if-nez v2, :cond_3a

    .line 1186
    .line 1187
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1188
    .line 1189
    .line 1190
    move-result v2

    .line 1191
    if-eqz v2, :cond_39

    .line 1192
    .line 1193
    goto :goto_a

    .line 1194
    :cond_39
    invoke-static {p1}, Lcom/transsnet/palmpay/core/config/d;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 1195
    .line 1196
    .line 1197
    move-result-object p1

    .line 1198
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1199
    .line 1200
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 1201
    .line 1202
    .line 1203
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1204
    .line 1205
    .line 1206
    const-string p1, "&applyId="

    .line 1207
    .line 1208
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1209
    .line 1210
    .line 1211
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1212
    .line 1213
    .line 1214
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1215
    .line 1216
    .line 1217
    move-result-object p1

    .line 1218
    invoke-static {p1}, LPa/i0;->c0(Ljava/lang/String;)V

    .line 1219
    .line 1220
    .line 1221
    invoke-virtual {v0}, Ljb/j;->getInstance()Ljb/o;

    .line 1222
    .line 1223
    .line 1224
    move-result-object p1

    .line 1225
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1226
    .line 1227
    .line 1228
    invoke-static {}, Ljb/o;->d()V

    .line 1229
    .line 1230
    .line 1231
    goto :goto_b

    .line 1232
    :cond_3a
    :goto_a
    const-string v0, "Service error, applyId="

    .line 1233
    .line 1234
    const-string v2, ", pendingUrl="

    .line 1235
    .line 1236
    invoke-static {v0, v1, v2, p1}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1237
    .line 1238
    .line 1239
    move-result-object p1

    .line 1240
    new-array v0, v4, [Ljava/lang/Object;

    .line 1241
    .line 1242
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1243
    .line 1244
    .line 1245
    goto :goto_b

    .line 1246
    :cond_3b
    new-instance v2, Landroid/os/Bundle;

    .line 1247
    .line 1248
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 1249
    .line 1250
    .line 1251
    iget-object v4, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 1252
    .line 1253
    if-eqz v4, :cond_3c

    .line 1254
    .line 1255
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplyId()Ljava/lang/String;

    .line 1256
    .line 1257
    .line 1258
    move-result-object v1

    .line 1259
    :cond_3c
    const-string v4, "creditApplyId"

    .line 1260
    .line 1261
    invoke-virtual {v2, v4, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1262
    .line 1263
    .line 1264
    const-string v1, "loanProduct"

    .line 1265
    .line 1266
    iget-object v4, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->w:Ljava/lang/String;

    .line 1267
    .line 1268
    invoke-virtual {v2, v1, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1269
    .line 1270
    .line 1271
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 1272
    .line 1273
    .line 1274
    move-result-object v1

    .line 1275
    iget-object v1, v1, LPa/w;->b:Ljava/lang/Object;

    .line 1276
    .line 1277
    check-cast v1, Lcom/google/gson/Gson;

    .line 1278
    .line 1279
    invoke-virtual {v1, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 1280
    .line 1281
    .line 1282
    move-result-object p1

    .line 1283
    const-string v1, "submitData"

    .line 1284
    .line 1285
    invoke-virtual {v2, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1286
    .line 1287
    .line 1288
    invoke-virtual {v0}, Ljb/j;->getInstance()Ljb/o;

    .line 1289
    .line 1290
    .line 1291
    move-result-object p1

    .line 1292
    iget-object p1, p1, Ljb/o;->r:Ljava/lang/String;

    .line 1293
    .line 1294
    const-string v1, "successUrl"

    .line 1295
    .line 1296
    invoke-virtual {v2, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1297
    .line 1298
    .line 1299
    invoke-virtual {v0}, Ljb/j;->getInstance()Ljb/o;

    .line 1300
    .line 1301
    .line 1302
    move-result-object p1

    .line 1303
    iget-object p1, p1, Ljb/o;->q:Ljava/lang/String;

    .line 1304
    .line 1305
    const-string v1, "errorUrl"

    .line 1306
    .line 1307
    invoke-virtual {v2, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1308
    .line 1309
    .line 1310
    invoke-virtual {v0}, Ljb/j;->getInstance()Ljb/o;

    .line 1311
    .line 1312
    .line 1313
    move-result-object p1

    .line 1314
    iget-object p1, p1, Ljb/o;->s:Ljava/lang/String;

    .line 1315
    .line 1316
    const-string v0, "pendingUrl"

    .line 1317
    .line 1318
    invoke-virtual {v2, v0, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1319
    .line 1320
    .line 1321
    const-string p1, "LoanCreditResult"

    .line 1322
    .line 1323
    invoke-static {v2, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 1324
    .line 1325
    .line 1326
    :goto_b
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 1327
    .line 1328
    .line 1329
    :cond_3d
    :goto_c
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 1330
    .line 1331
    :goto_d
    add-int/lit8 p1, p1, -0x1

    .line 1332
    .line 1333
    iput p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 1334
    .line 1335
    goto :goto_e

    .line 1336
    :cond_3e
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 1337
    .line 1338
    if-eqz v0, :cond_3f

    .line 1339
    .line 1340
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 1341
    .line 1342
    .line 1343
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 1344
    .line 1345
    goto :goto_d

    .line 1346
    :cond_3f
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 1347
    .line 1348
    if-eqz v0, :cond_41

    .line 1349
    .line 1350
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 1351
    .line 1352
    .line 1353
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 1354
    .line 1355
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 1356
    .line 1357
    new-array v0, v4, [Ljava/lang/Object;

    .line 1358
    .line 1359
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1360
    .line 1361
    .line 1362
    instance-of p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/cashloan/CLLastProtocolActivity;

    .line 1363
    .line 1364
    if-eqz p1, :cond_40

    .line 1365
    .line 1366
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 1367
    .line 1368
    .line 1369
    :cond_40
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 1370
    .line 1371
    goto :goto_d

    .line 1372
    :goto_e
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1373
    .line 1374
    return-object p1

    .line 1375
    :cond_41
    new-instance p1, Lxf/l;

    .line 1376
    .line 1377
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 1378
    .line 1379
    .line 1380
    throw p1

    .line 1381
    :pswitch_7
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 1382
    .line 1383
    const-string v0, "it"

    .line 1384
    .line 1385
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1386
    .line 1387
    .line 1388
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 1389
    .line 1390
    iget-object v1, p0, Lub/h;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 1391
    .line 1392
    const/4 v2, 0x1

    .line 1393
    if-eqz v0, :cond_42

    .line 1394
    .line 1395
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 1396
    .line 1397
    .line 1398
    goto/16 :goto_14

    .line 1399
    .line 1400
    :cond_42
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 1401
    .line 1402
    iget-object v3, p0, Lub/h;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 1403
    .line 1404
    const/4 v4, 0x0

    .line 1405
    if-eqz v0, :cond_48

    .line 1406
    .line 1407
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 1408
    .line 1409
    .line 1410
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 1411
    .line 1412
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 1413
    .line 1414
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultResp;

    .line 1415
    .line 1416
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 1417
    .line 1418
    .line 1419
    move-result v0

    .line 1420
    const-string v1, "oc_apply_result"

    .line 1421
    .line 1422
    const-string v2, "/credit_score/oc_apply_result_activity"

    .line 1423
    .line 1424
    if-eqz v0, :cond_46

    .line 1425
    .line 1426
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;

    .line 1427
    .line 1428
    .line 1429
    move-result-object v0

    .line 1430
    if-eqz v0, :cond_44

    .line 1431
    .line 1432
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;->getApplyStatus()Ljava/lang/Integer;

    .line 1433
    .line 1434
    .line 1435
    move-result-object v0

    .line 1436
    if-nez v0, :cond_43

    .line 1437
    .line 1438
    goto :goto_f

    .line 1439
    :cond_43
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 1440
    .line 1441
    .line 1442
    move-result v0

    .line 1443
    if-nez v0, :cond_44

    .line 1444
    .line 1445
    sget v0, LYa/g;->cs_oc_activiting_tips:I

    .line 1446
    .line 1447
    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1448
    .line 1449
    .line 1450
    move-result-object v0

    .line 1451
    new-array v5, v4, [Ljava/lang/Object;

    .line 1452
    .line 1453
    invoke-static {v0, v5}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1454
    .line 1455
    .line 1456
    :cond_44
    :goto_f
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;

    .line 1457
    .line 1458
    .line 1459
    move-result-object v0

    .line 1460
    if-eqz v0, :cond_45

    .line 1461
    .line 1462
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 1463
    .line 1464
    .line 1465
    move-result-object v0

    .line 1466
    invoke-virtual {v0, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 1467
    .line 1468
    .line 1469
    move-result-object v0

    .line 1470
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 1471
    .line 1472
    .line 1473
    move-result-object v2

    .line 1474
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;

    .line 1475
    .line 1476
    .line 1477
    move-result-object p1

    .line 1478
    iget-object v2, v2, LPa/w;->b:Ljava/lang/Object;

    .line 1479
    .line 1480
    check-cast v2, Lcom/google/gson/Gson;

    .line 1481
    .line 1482
    invoke-virtual {v2, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 1483
    .line 1484
    .line 1485
    move-result-object p1

    .line 1486
    invoke-virtual {v0, v1, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 1487
    .line 1488
    .line 1489
    move-result-object p1

    .line 1490
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 1491
    .line 1492
    .line 1493
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 1494
    .line 1495
    .line 1496
    goto :goto_12

    .line 1497
    :cond_45
    const-string p1, "apply result is null"

    .line 1498
    .line 1499
    new-array v0, v4, [Ljava/lang/Object;

    .line 1500
    .line 1501
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1502
    .line 1503
    .line 1504
    goto :goto_12

    .line 1505
    :cond_46
    new-instance v4, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;

    .line 1506
    .line 1507
    const/4 v0, 0x2

    .line 1508
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1509
    .line 1510
    .line 1511
    move-result-object v6

    .line 1512
    const-wide/16 v7, 0x0

    .line 1513
    .line 1514
    move-wide v8, v7

    .line 1515
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1516
    .line 1517
    .line 1518
    move-result-object v7

    .line 1519
    move-wide v9, v8

    .line 1520
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1521
    .line 1522
    .line 1523
    move-result-object v8

    .line 1524
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1525
    .line 1526
    .line 1527
    move-result-object v9

    .line 1528
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 1529
    .line 1530
    .line 1531
    move-result-object v10

    .line 1532
    iget-object p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 1533
    .line 1534
    if-eqz p1, :cond_47

    .line 1535
    .line 1536
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplySource()Ljava/lang/Integer;

    .line 1537
    .line 1538
    .line 1539
    move-result-object p1

    .line 1540
    :goto_10
    move-object v11, p1

    .line 1541
    goto :goto_11

    .line 1542
    :cond_47
    const/4 p1, 0x0

    .line 1543
    goto :goto_10

    .line 1544
    :goto_11
    const-string v5, ""

    .line 1545
    .line 1546
    const-string v12, ""

    .line 1547
    .line 1548
    const/4 v13, 0x0

    .line 1549
    invoke-direct/range {v4 .. v13}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultConfig;)V

    .line 1550
    .line 1551
    .line 1552
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 1553
    .line 1554
    .line 1555
    move-result-object p1

    .line 1556
    invoke-virtual {p1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 1557
    .line 1558
    .line 1559
    move-result-object p1

    .line 1560
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 1561
    .line 1562
    .line 1563
    move-result-object v0

    .line 1564
    iget-object v0, v0, LPa/w;->b:Ljava/lang/Object;

    .line 1565
    .line 1566
    check-cast v0, Lcom/google/gson/Gson;

    .line 1567
    .line 1568
    invoke-virtual {v0, v4}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 1569
    .line 1570
    .line 1571
    move-result-object v0

    .line 1572
    invoke-virtual {p1, v1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 1573
    .line 1574
    .line 1575
    move-result-object p1

    .line 1576
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 1577
    .line 1578
    .line 1579
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 1580
    .line 1581
    .line 1582
    :goto_12
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 1583
    .line 1584
    :goto_13
    add-int/lit8 p1, p1, -0x1

    .line 1585
    .line 1586
    iput p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 1587
    .line 1588
    goto :goto_14

    .line 1589
    :cond_48
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 1590
    .line 1591
    if-eqz v0, :cond_49

    .line 1592
    .line 1593
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 1594
    .line 1595
    .line 1596
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 1597
    .line 1598
    goto :goto_13

    .line 1599
    :cond_49
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 1600
    .line 1601
    if-eqz v0, :cond_4a

    .line 1602
    .line 1603
    invoke-interface {v1, v4, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 1604
    .line 1605
    .line 1606
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 1607
    .line 1608
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 1609
    .line 1610
    new-array v0, v4, [Ljava/lang/Object;

    .line 1611
    .line 1612
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1613
    .line 1614
    .line 1615
    iget p1, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->t:I

    .line 1616
    .line 1617
    goto :goto_13

    .line 1618
    :goto_14
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1619
    .line 1620
    return-object p1

    .line 1621
    :cond_4a
    new-instance p1, Lxf/l;

    .line 1622
    .line 1623
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 1624
    .line 1625
    .line 1626
    throw p1

    .line 1627
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
