.class public final Lub/q;
.super Lcom/transsnet/adsdk/interfaces/CommonAdListener;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/q;->a:I

    iput-object p1, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    invoke-direct {p0}, Lcom/transsnet/adsdk/interfaces/CommonAdListener;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/q;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 7
    .line 8
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->n(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    iget-object v0, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 13
    .line 14
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->n(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_1
    iget-object v0, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 19
    .line 20
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->n(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_2
    iget-object v0, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 25
    .line 26
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->n(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_3
    iget-object v0, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 31
    .line 32
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->n(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :pswitch_4
    iget-object v0, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 37
    .line 38
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->n(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    nop

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public onLoadFailed()V
    .locals 2

    .line 1
    iget v0, p0, Lub/q;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Lcom/transsnet/adsdk/interfaces/CommonAdListener;->onLoadFailed()V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_0
    invoke-super {p0}, Lcom/transsnet/adsdk/interfaces/CommonAdListener;->onLoadFailed()V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->q0:Lxf/t;

    .line 16
    .line 17
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const-string v1, "getValue(...)"

    .line 22
    .line 23
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    check-cast v0, Landroid/widget/LinearLayout;

    .line 27
    .line 28
    const/16 v1, 0x8

    .line 29
    .line 30
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public onLoadSuccess()V
    .locals 2

    .line 1
    iget v0, p0, Lub/q;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Lcom/transsnet/adsdk/interfaces/CommonAdListener;->onLoadSuccess()V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_0
    invoke-super {p0}, Lcom/transsnet/adsdk/interfaces/CommonAdListener;->onLoadSuccess()V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lub/q;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->q0:Lxf/t;

    .line 16
    .line 17
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const-string v1, "getValue(...)"

    .line 22
    .line 23
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    check-cast v0, Landroid/widget/LinearLayout;

    .line 27
    .line 28
    const/4 v1, 0x0

    .line 29
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
