.class public final synthetic Lub/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/t;->a:I

    iput-object p1, p0, Lub/t;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/t;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/t;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 9
    .line 10
    sget v1, LYa/e;->ivNoOutstanding:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0

    .line 17
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 18
    .line 19
    sget v1, LYa/e;->tvNoOutstanding:I

    .line 20
    .line 21
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/widget/TextView;

    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 29
    .line 30
    sget v1, LYa/e;->btnBorrow:I

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 40
    .line 41
    sget v1, LYa/e;->btnPayWithFlexi:I

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 51
    .line 52
    sget v1, LYa/e;->btnBottomTips:I

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v0, Landroid/widget/TextView;

    .line 59
    .line 60
    return-object v0

    .line 61
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 62
    .line 63
    sget v1, LYa/e;->payment_num_tv:I

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Landroid/widget/TextView;

    .line 70
    .line 71
    return-object v0

    .line 72
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 73
    .line 74
    sget v1, LYa/e;->bank_title_tv:I

    .line 75
    .line 76
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Landroid/widget/TextView;

    .line 81
    .line 82
    return-object v0

    .line 83
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 84
    .line 85
    sget v1, LYa/e;->bank_card_method_rv:I

    .line 86
    .line 87
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 92
    .line 93
    return-object v0

    .line 94
    :pswitch_7
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 95
    .line 96
    sget v1, LYa/e;->tvDueDateTitle:I

    .line 97
    .line 98
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    check-cast v0, Landroid/widget/TextView;

    .line 103
    .line 104
    return-object v0

    .line 105
    :pswitch_8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAutoRepaymentExplainActivity;->B:I

    .line 106
    .line 107
    sget v1, LYa/e;->tvRepaymentDate:I

    .line 108
    .line 109
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    check-cast v0, Landroid/widget/TextView;

    .line 114
    .line 115
    return-object v0

    .line 116
    nop

    .line 117
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
