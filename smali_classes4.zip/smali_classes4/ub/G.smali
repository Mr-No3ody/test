.class public final Lub/G;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/text/TextWatcher;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/G;->a:I

    iput-object p1, p0, Lub/G;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final b(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final c(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final d(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final e(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final f(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final g(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final h(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final i(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method

.method private final j(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final afterTextChanged(Landroid/text/Editable;)V
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    const/16 v1, 0x8

    .line 3
    .line 4
    iget-object v2, p0, Lub/G;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;

    .line 5
    .line 6
    iget v3, p0, Lub/G;->a:I

    .line 7
    .line 8
    packed-switch v3, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 12
    .line 13
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->L()Landroid/widget/TextView;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->F()Landroid/widget/EditText;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    sget v4, LYa/d;->cs_oc_contact_et_bg:I

    .line 25
    .line 26
    invoke-virtual {v3, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 27
    .line 28
    .line 29
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-eqz p1, :cond_0

    .line 34
    .line 35
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->A()Landroid/widget/ImageView;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_0
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->A()Landroid/widget/ImageView;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 48
    .line 49
    .line 50
    :goto_0
    return-void

    .line 51
    :pswitch_0
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 52
    .line 53
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->X()Landroid/widget/TextView;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 58
    .line 59
    .line 60
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    if-eqz p1, :cond_1

    .line 65
    .line 66
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->E()Landroid/widget/ImageView;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 71
    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_1
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->E()Landroid/widget/ImageView;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 79
    .line 80
    .line 81
    :goto_1
    return-void

    .line 82
    :pswitch_1
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 83
    .line 84
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->T()Landroid/widget/TextView;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->R()Landroid/widget/EditText;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    sget v4, LYa/d;->cs_oc_contact_et_bg:I

    .line 96
    .line 97
    invoke-virtual {v3, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 98
    .line 99
    .line 100
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 101
    .line 102
    .line 103
    move-result p1

    .line 104
    if-eqz p1, :cond_2

    .line 105
    .line 106
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->D()Landroid/widget/ImageView;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 111
    .line 112
    .line 113
    goto :goto_2

    .line 114
    :cond_2
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->D()Landroid/widget/ImageView;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 119
    .line 120
    .line 121
    :goto_2
    return-void

    .line 122
    :pswitch_2
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 123
    .line 124
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->U()Landroid/widget/TextView;

    .line 125
    .line 126
    .line 127
    move-result-object v3

    .line 128
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->O()Landroid/widget/EditText;

    .line 132
    .line 133
    .line 134
    move-result-object v3

    .line 135
    sget v4, LYa/d;->cs_oc_contact_et_bg:I

    .line 136
    .line 137
    invoke-virtual {v3, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 138
    .line 139
    .line 140
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 141
    .line 142
    .line 143
    move-result p1

    .line 144
    if-eqz p1, :cond_3

    .line 145
    .line 146
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->C()Landroid/widget/ImageView;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 151
    .line 152
    .line 153
    goto :goto_3

    .line 154
    :cond_3
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->C()Landroid/widget/ImageView;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 159
    .line 160
    .line 161
    :goto_3
    return-void

    .line 162
    :pswitch_3
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->l1:I

    .line 163
    .line 164
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->K()Landroid/widget/TextView;

    .line 165
    .line 166
    .line 167
    move-result-object v3

    .line 168
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->I()Landroid/widget/EditText;

    .line 172
    .line 173
    .line 174
    move-result-object v3

    .line 175
    sget v4, LYa/d;->cs_oc_contact_et_bg:I

    .line 176
    .line 177
    invoke-virtual {v3, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 178
    .line 179
    .line 180
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 181
    .line 182
    .line 183
    move-result p1

    .line 184
    if-eqz p1, :cond_4

    .line 185
    .line 186
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->B()Landroid/widget/ImageView;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 191
    .line 192
    .line 193
    goto :goto_4

    .line 194
    :cond_4
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcContactActivity;->B()Landroid/widget/ImageView;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 199
    .line 200
    .line 201
    :goto_4
    return-void

    .line 202
    nop

    .line 203
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    iget p1, p0, Lub/G;->a:I

    return-void
.end method

.method public final onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 1
    iget p1, p0, Lub/G;->a:I

    return-void
.end method
