.class public final synthetic Lub/u0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lub/v0;


# direct methods
.method public synthetic constructor <init>(Lub/v0;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/u0;->a:I

    iput-object p1, p0, Lub/u0;->b:Lub/v0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    iget p1, p0, Lub/u0;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lub/u0;->b:Lub/v0;

    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-static {}, LPa/r0;->U0()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    iget-object p1, p1, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 19
    .line 20
    iget-boolean v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->x0:Z

    .line 21
    .line 22
    if-eqz v0, :cond_1

    .line 23
    .line 24
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->v0:Lub/t0;

    .line 25
    .line 26
    invoke-static {v0}, Lub/t0;->a(Lub/t0;)V

    .line 27
    .line 28
    .line 29
    :cond_1
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    const-class v1, Lub/v0;

    .line 34
    .line 35
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    const-string v2, "_element_click"

    .line 40
    .line 41
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    iget-boolean p1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->x0:Z

    .line 46
    .line 47
    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    const-string v2, "cs_resend_code"

    .line 52
    .line 53
    invoke-virtual {v0, v1, v2, p1}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    :goto_0
    return-void

    .line 57
    :pswitch_0
    iget-object p1, p0, Lub/u0;->b:Lub/v0;

    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    invoke-static {}, LPa/r0;->U0()Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_2

    .line 67
    .line 68
    goto/16 :goto_3

    .line 69
    .line 70
    :cond_2
    iget-object p1, p1, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 71
    .line 72
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->z0:Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;

    .line 73
    .line 74
    if-eqz v0, :cond_4

    .line 75
    .line 76
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;->statusCode:Ljava/lang/String;

    .line 77
    .line 78
    const-string v1, "40080005"

    .line 79
    .line 80
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_3

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_3
    const-string v0, "SKIP"

    .line 88
    .line 89
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->x(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->r()V

    .line 93
    .line 94
    .line 95
    goto :goto_2

    .line 96
    :cond_4
    :goto_1
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->v0:Lub/t0;

    .line 97
    .line 98
    iget-object v0, p1, Lub/t0;->a:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 101
    .line 102
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->p0:Landroidx/appcompat/widget/AppCompatEditText;

    .line 103
    .line 104
    invoke-virtual {v1}, Landroidx/appcompat/widget/AppCompatEditText;->getText()Landroid/text/Editable;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-eqz v1, :cond_5

    .line 113
    .line 114
    const-string p1, "verify code is null"

    .line 115
    .line 116
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 117
    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_5
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 121
    .line 122
    iget-object v1, v1, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 123
    .line 124
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->r0:Landroid/view/View;

    .line 125
    .line 126
    sget v3, LL6/b;->ppColorTextPrimary:I

    .line 127
    .line 128
    invoke-virtual {v1, v3}, Landroid/content/Context;->getColor(I)I

    .line 129
    .line 130
    .line 131
    move-result v3

    .line 132
    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 133
    .line 134
    .line 135
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->s0:Landroid/widget/TextView;

    .line 136
    .line 137
    const/16 v2, 0x8

    .line 138
    .line 139
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 140
    .line 141
    .line 142
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/OcVerifyOneLoopReq;

    .line 143
    .line 144
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->p0:Landroidx/appcompat/widget/AppCompatEditText;

    .line 145
    .line 146
    invoke-virtual {v2}, Landroidx/appcompat/widget/AppCompatEditText;->getText()Landroid/text/Editable;

    .line 147
    .line 148
    .line 149
    move-result-object v2

    .line 150
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->y0:Ljava/lang/String;

    .line 155
    .line 156
    invoke-direct {v1, v2, v3}, Lcom/transsnet/palmpay/credit/bean/req/OcVerifyOneLoopReq;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->t0:Lcom/palmpay/lib/ui/button/PpButton;

    .line 160
    .line 161
    const/4 v2, 0x1

    .line 162
    invoke-virtual {v0, v2}, Lcom/palmpay/lib/ui/button/PpButton;->b(Z)V

    .line 163
    .line 164
    .line 165
    sget-object v0, Lob/c;->a:Lob/a;

    .line 166
    .line 167
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 168
    .line 169
    .line 170
    move-result-object v0

    .line 171
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 172
    .line 173
    .line 174
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->verifyOneLoopOTP(Lcom/transsnet/palmpay/credit/bean/req/OcVerifyOneLoopReq;)Ldf/d;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 183
    .line 184
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    new-instance v1, Lub/s0;

    .line 197
    .line 198
    invoke-direct {v1, p1}, Lub/s0;-><init>(Lub/t0;)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 202
    .line 203
    .line 204
    :goto_2
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 205
    .line 206
    .line 207
    move-result-object p1

    .line 208
    const-class v0, Lub/v0;

    .line 209
    .line 210
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    const-string v1, "_element_click"

    .line 215
    .line 216
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object v0

    .line 220
    const-string v1, "cs_login"

    .line 221
    .line 222
    const-string v2, ""

    .line 223
    .line 224
    invoke-virtual {p1, v0, v1, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    :goto_3
    return-void

    .line 228
    :pswitch_1
    iget-object p1, p0, Lub/u0;->b:Lub/v0;

    .line 229
    .line 230
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 231
    .line 232
    .line 233
    invoke-static {}, LPa/r0;->U0()Z

    .line 234
    .line 235
    .line 236
    move-result v0

    .line 237
    if-eqz v0, :cond_6

    .line 238
    .line 239
    goto :goto_4

    .line 240
    :cond_6
    iget-object p1, p1, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 241
    .line 242
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->r()V

    .line 243
    .line 244
    .line 245
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 246
    .line 247
    .line 248
    move-result-object p1

    .line 249
    const-class v0, Lub/v0;

    .line 250
    .line 251
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    const-string v1, "_element_click"

    .line 256
    .line 257
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 258
    .line 259
    .line 260
    move-result-object v0

    .line 261
    const-string v1, "router_right_tv"

    .line 262
    .line 263
    const-string v2, ""

    .line 264
    .line 265
    invoke-virtual {p1, v0, v1, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 266
    .line 267
    .line 268
    :goto_4
    return-void

    .line 269
    :pswitch_2
    iget-object p1, p0, Lub/u0;->b:Lub/v0;

    .line 270
    .line 271
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 272
    .line 273
    .line 274
    invoke-static {}, LPa/r0;->U0()Z

    .line 275
    .line 276
    .line 277
    move-result v0

    .line 278
    if-eqz v0, :cond_7

    .line 279
    .line 280
    goto :goto_5

    .line 281
    :cond_7
    iget-object p1, p1, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 282
    .line 283
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v()V

    .line 284
    .line 285
    .line 286
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 287
    .line 288
    .line 289
    move-result-object p1

    .line 290
    const-class v0, Lub/v0;

    .line 291
    .line 292
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    const-string v1, "_element_click"

    .line 297
    .line 298
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 299
    .line 300
    .line 301
    move-result-object v0

    .line 302
    const-string v1, "router_close_img"

    .line 303
    .line 304
    const-string v2, ""

    .line 305
    .line 306
    invoke-virtual {p1, v0, v1, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 307
    .line 308
    .line 309
    :goto_5
    return-void

    .line 310
    :pswitch_3
    iget-object p1, p0, Lub/u0;->b:Lub/v0;

    .line 311
    .line 312
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 313
    .line 314
    .line 315
    invoke-static {}, LPa/r0;->U0()Z

    .line 316
    .line 317
    .line 318
    move-result v0

    .line 319
    if-eqz v0, :cond_8

    .line 320
    .line 321
    goto :goto_6

    .line 322
    :cond_8
    iget-object p1, p1, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 323
    .line 324
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->onBackPressed()V

    .line 325
    .line 326
    .line 327
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 328
    .line 329
    .line 330
    move-result-object p1

    .line 331
    const-class v0, Lub/v0;

    .line 332
    .line 333
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 334
    .line 335
    .line 336
    move-result-object v0

    .line 337
    const-string v1, "_element_click"

    .line 338
    .line 339
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v0

    .line 343
    const-string v1, "router_back_img"

    .line 344
    .line 345
    const-string v2, ""

    .line 346
    .line 347
    invoke-virtual {p1, v0, v1, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 348
    .line 349
    .line 350
    :goto_6
    return-void

    .line 351
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
