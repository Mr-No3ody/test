.class public final Lub/Z0;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lub/Z0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 1

    .line 1
    new-instance p1, Lub/Z0;

    .line 2
    .line 3
    iget-object v0, p0, Lub/Z0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 4
    .line 5
    invoke-direct {p1, v0, p2}, Lub/Z0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;Lkotlin/coroutines/Continuation;)V

    .line 6
    .line 7
    .line 8
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lub/Z0;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lub/Z0;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lub/Z0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, Lub/Z0;->a:I

    .line 4
    .line 5
    const/4 v2, 0x6

    .line 6
    const/4 v3, 0x1

    .line 7
    const/4 v4, 0x0

    .line 8
    iget-object v5, p0, Lub/Z0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 9
    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    if-ne v1, v3, :cond_0

    .line 13
    .line 14
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception p1

    .line 19
    goto/16 :goto_2

    .line 20
    .line 21
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 22
    .line 23
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 24
    .line 25
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw p1

    .line 29
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    :try_start_1
    iget-wide v6, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->d1:J

    .line 33
    .line 34
    new-instance p1, Ljava/lang/Long;

    .line 35
    .line 36
    invoke-direct {p1, v6, v7}, Ljava/lang/Long;-><init>(J)V

    .line 37
    .line 38
    .line 39
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/TriggerFullExemptionReq;

    .line 40
    .line 41
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    const/4 v7, 0x0

    .line 46
    invoke-direct {v1, v6, v7, p1}, Lcom/transsnet/palmpay/credit/bean/req/TriggerFullExemptionReq;-><init>(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Long;)V

    .line 47
    .line 48
    .line 49
    sget-object p1, LWf/I;->a:Lcg/f;

    .line 50
    .line 51
    sget-object p1, Lcg/e;->c:Lcg/e;

    .line 52
    .line 53
    new-instance v6, Lub/Y0;

    .line 54
    .line 55
    invoke-direct {v6, v1, v7}, Lub/Y0;-><init>(Lcom/transsnet/palmpay/credit/bean/req/TriggerFullExemptionReq;Lkotlin/coroutines/Continuation;)V

    .line 56
    .line 57
    .line 58
    iput v3, p0, Lub/Z0;->a:I

    .line 59
    .line 60
    invoke-static {p1, v6, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    if-ne p1, v0, :cond_2

    .line 65
    .line 66
    return-object v0

    .line 67
    :cond_2
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 68
    .line 69
    invoke-virtual {v5, v4}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_4

    .line 77
    .line 78
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/resp/TriggerFullExemptionData;

    .line 81
    .line 82
    if-eqz v0, :cond_4

    .line 83
    .line 84
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/TriggerFullExemptionData;->getTriggerStatus()Ljava/lang/Integer;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    if-nez v0, :cond_3

    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_3
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-ne v0, v3, :cond_4

    .line 96
    .line 97
    invoke-virtual {v5}, Landroid/app/Activity;->finish()V

    .line 98
    .line 99
    .line 100
    const-string p1, "LoanFullWaiverClearedResult"

    .line 101
    .line 102
    new-instance v0, Landroid/os/Bundle;

    .line 103
    .line 104
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 105
    .line 106
    .line 107
    const-string v1, "accountType"

    .line 108
    .line 109
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 110
    .line 111
    .line 112
    invoke-static {v0, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    goto :goto_3

    .line 116
    :cond_4
    :goto_1
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/resp/TriggerFullExemptionData;

    .line 119
    .line 120
    if-eqz v0, :cond_5

    .line 121
    .line 122
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/TriggerFullExemptionData;->getPromptMessage()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    if-nez v0, :cond_6

    .line 127
    .line 128
    :cond_5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    :cond_6
    new-array p1, v4, [Ljava/lang/Object;

    .line 133
    .line 134
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 138
    .line 139
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->p()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 140
    .line 141
    .line 142
    goto :goto_3

    .line 143
    :goto_2
    invoke-virtual {v5, v4}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    new-array v0, v4, [Ljava/lang/Object;

    .line 151
    .line 152
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 156
    .line 157
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->p()V

    .line 158
    .line 159
    .line 160
    :goto_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 161
    .line 162
    return-object p1
.end method
