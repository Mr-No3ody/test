.class public final synthetic Lub/Z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeBreakActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeBreakActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/Z;->a:I

    iput-object p1, p0, Lub/Z;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeBreakActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 5

    .line 1
    iget-object p1, p0, Lub/Z;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeBreakActivity;

    .line 2
    .line 3
    iget v0, p0, Lub/Z;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeBreakActivity;->C:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getAccountStatus()Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    const/4 v1, 0x5

    .line 24
    if-ne v0, v1, :cond_1

    .line 25
    .line 26
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const-string v1, "/credit_score/oc_protocol_activity"

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 40
    .line 41
    .line 42
    goto :goto_3

    .line 43
    :cond_1
    :goto_0
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeBreakActivity;->C:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 44
    .line 45
    const-wide/16 v1, 0x0

    .line 46
    .line 47
    if-eqz v0, :cond_2

    .line 48
    .line 49
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getOutstandingAmount()Ljava/lang/Long;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 56
    .line 57
    .line 58
    move-result-wide v3

    .line 59
    goto :goto_1

    .line 60
    :cond_2
    move-wide v3, v1

    .line 61
    :goto_1
    cmp-long v0, v3, v1

    .line 62
    .line 63
    if-lez v0, :cond_4

    .line 64
    .line 65
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    const-string v1, "/credit_score/oc_all_bill_activity"

    .line 70
    .line 71
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeBreakActivity;->C:Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;

    .line 76
    .line 77
    if-eqz v1, :cond_3

    .line 78
    .line 79
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcGoldCardLevelData;->getCardNo()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    goto :goto_2

    .line 84
    :cond_3
    const/4 v1, 0x0

    .line 85
    :goto_2
    const-string v2, "oc_card_no"

    .line 86
    .line 87
    invoke-virtual {v0, v2, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    const-string v1, "oc_bill_list_type"

    .line 92
    .line 93
    const-string v2, "oc_all_bill"

    .line 94
    .line 95
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    invoke-virtual {v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 103
    .line 104
    .line 105
    :cond_4
    :goto_3
    return-void

    .line 106
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcGoldCardUpgradeBreakActivity;->H:I

    .line 107
    .line 108
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 109
    .line 110
    .line 111
    return-void

    .line 112
    nop

    .line 113
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
