.class public final Lub/z1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

.field public final synthetic c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;I)V
    .locals 0

    .line 1
    iput p3, p0, Lub/z1;->a:I

    iput-object p1, p0, Lub/z1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

    iput-object p2, p0, Lub/z1;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    const/4 v2, 0x2

    .line 4
    const/4 v3, -0x1

    .line 5
    const/16 v4, 0x8

    .line 6
    .line 7
    const-string v5, "getValue(...)"

    .line 8
    .line 9
    iget-object v6, p0, Lub/z1;->c:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

    .line 10
    .line 11
    const/4 v7, 0x0

    .line 12
    const/4 v8, 0x1

    .line 13
    iget-object v9, p0, Lub/z1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

    .line 14
    .line 15
    const-string v10, "it"

    .line 16
    .line 17
    iget v11, p0, Lub/z1;->a:I

    .line 18
    .line 19
    packed-switch v11, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 23
    .line 24
    invoke-static {p1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 28
    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    invoke-interface {v9, v8, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 32
    .line 33
    .line 34
    goto/16 :goto_2

    .line 35
    .line 36
    :cond_0
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 37
    .line 38
    if-eqz v0, :cond_5

    .line 39
    .line 40
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 41
    .line 42
    .line 43
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 44
    .line 45
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenUserListResp;

    .line 48
    .line 49
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenUserListResp;->getData()Ljava/util/List;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    check-cast v0, Ljava/util/Collection;

    .line 60
    .line 61
    if-eqz v0, :cond_2

    .line 62
    .line 63
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_1

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_1
    iget-object v0, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->q0:Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;

    .line 71
    .line 72
    if-eqz v0, :cond_2

    .line 73
    .line 74
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenUserListResp;->getData()Ljava/util/List;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->b(Ljava/util/List;)V

    .line 79
    .line 80
    .line 81
    :cond_2
    :goto_0
    iget-object v0, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->Y:Lxf/t;

    .line 82
    .line 83
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    check-cast v0, Landroid/widget/LinearLayout;

    .line 91
    .line 92
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    if-eqz v1, :cond_4

    .line 97
    .line 98
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenUserListResp;->getData()Ljava/util/List;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    check-cast p1, Ljava/util/Collection;

    .line 103
    .line 104
    if-eqz p1, :cond_4

    .line 105
    .line 106
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 107
    .line 108
    .line 109
    move-result p1

    .line 110
    if-eqz p1, :cond_3

    .line 111
    .line 112
    goto :goto_1

    .line 113
    :cond_3
    move v7, v8

    .line 114
    :cond_4
    :goto_1
    invoke-static {v0, v7}, Loa/h;->s(Landroid/view/View;Z)V

    .line 115
    .line 116
    .line 117
    goto :goto_2

    .line 118
    :cond_5
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 119
    .line 120
    if-eqz v0, :cond_6

    .line 121
    .line 122
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 123
    .line 124
    .line 125
    goto :goto_2

    .line 126
    :cond_6
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 127
    .line 128
    if-eqz v0, :cond_7

    .line 129
    .line 130
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 131
    .line 132
    .line 133
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 134
    .line 135
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 136
    .line 137
    new-array v0, v7, [Ljava/lang/Object;

    .line 138
    .line 139
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    :goto_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 143
    .line 144
    return-object p1

    .line 145
    :cond_7
    new-instance p1, Lxf/l;

    .line 146
    .line 147
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 148
    .line 149
    .line 150
    throw p1

    .line 151
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 152
    .line 153
    invoke-static {p1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 157
    .line 158
    if-eqz v0, :cond_8

    .line 159
    .line 160
    invoke-interface {v9, v8, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 161
    .line 162
    .line 163
    goto/16 :goto_5

    .line 164
    .line 165
    :cond_8
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 166
    .line 167
    if-eqz v0, :cond_d

    .line 168
    .line 169
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 170
    .line 171
    .line 172
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 173
    .line 174
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 175
    .line 176
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/CLInstallmentLoanMainPageResp;

    .line 177
    .line 178
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    if-eqz v0, :cond_c

    .line 183
    .line 184
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInstallmentLoanMainPageResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    if-eqz v0, :cond_c

    .line 189
    .line 190
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInstallmentLoanMainPageResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    const/4 v1, 0x0

    .line 195
    if-eqz v0, :cond_9

    .line 196
    .line 197
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;->getApplyStatus()Ljava/lang/Integer;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    goto :goto_3

    .line 202
    :cond_9
    move-object v0, v1

    .line 203
    :goto_3
    if-eqz v0, :cond_b

    .line 204
    .line 205
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 206
    .line 207
    .line 208
    move-result v5

    .line 209
    if-eq v5, v3, :cond_b

    .line 210
    .line 211
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 212
    .line 213
    .line 214
    move-result v3

    .line 215
    if-eqz v3, :cond_b

    .line 216
    .line 217
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 218
    .line 219
    .line 220
    move-result v0

    .line 221
    if-ne v0, v2, :cond_a

    .line 222
    .line 223
    goto :goto_4

    .line 224
    :cond_a
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->p()Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    invoke-virtual {v0, v7}, Landroid/view/View;->setVisibility(I)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->q()Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 236
    .line 237
    .line 238
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->p()Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->p()Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 246
    .line 247
    .line 248
    move-result-object v0

    .line 249
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInstallmentLoanMainPageResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;

    .line 250
    .line 251
    .line 252
    move-result-object p1

    .line 253
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->i(Lcom/transsnet/palmpay/credit/bean/resp/InstallmentLoanMainPageData;)V

    .line 254
    .line 255
    .line 256
    goto :goto_5

    .line 257
    :cond_b
    :goto_4
    iget-object p1, v6, Lcom/transsnet/palmpay/core/base/BaseActivity;->TAG:Ljava/lang/String;

    .line 258
    .line 259
    const-string v0, "installment account is inactive"

    .line 260
    .line 261
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    const/4 v1, 0x3

    .line 266
    invoke-static {p1, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 267
    .line 268
    .line 269
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->p()Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 270
    .line 271
    .line 272
    move-result-object p1

    .line 273
    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    .line 274
    .line 275
    .line 276
    goto :goto_5

    .line 277
    :cond_c
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 278
    .line 279
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->p()Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 287
    .line 288
    .line 289
    move-result-object p1

    .line 290
    new-array v0, v7, [Ljava/lang/Object;

    .line 291
    .line 292
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 293
    .line 294
    .line 295
    goto :goto_5

    .line 296
    :cond_d
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 297
    .line 298
    if-eqz v0, :cond_e

    .line 299
    .line 300
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 301
    .line 302
    .line 303
    goto :goto_5

    .line 304
    :cond_e
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 305
    .line 306
    if-eqz v0, :cond_f

    .line 307
    .line 308
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 309
    .line 310
    .line 311
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 312
    .line 313
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 314
    .line 315
    new-array v0, v7, [Ljava/lang/Object;

    .line 316
    .line 317
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 321
    .line 322
    return-object p1

    .line 323
    :cond_f
    new-instance p1, Lxf/l;

    .line 324
    .line 325
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 326
    .line 327
    .line 328
    throw p1

    .line 329
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 330
    .line 331
    invoke-static {p1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 332
    .line 333
    .line 334
    instance-of v10, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 335
    .line 336
    if-eqz v10, :cond_10

    .line 337
    .line 338
    invoke-interface {v9, v8, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 339
    .line 340
    .line 341
    goto/16 :goto_c

    .line 342
    .line 343
    :cond_10
    instance-of v10, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 344
    .line 345
    if-eqz v10, :cond_1a

    .line 346
    .line 347
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 348
    .line 349
    .line 350
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 351
    .line 352
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 353
    .line 354
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;

    .line 355
    .line 356
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 357
    .line 358
    .line 359
    move-result v8

    .line 360
    if-eqz v8, :cond_19

    .line 361
    .line 362
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 363
    .line 364
    .line 365
    move-result-object v8

    .line 366
    if-eqz v8, :cond_19

    .line 367
    .line 368
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 369
    .line 370
    .line 371
    move-result-object v8

    .line 372
    iput-object v8, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->k0:Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 373
    .line 374
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 375
    .line 376
    .line 377
    move-result-object v8

    .line 378
    iget-object v9, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->A:Lxf/t;

    .line 379
    .line 380
    iget-object v10, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->C:Lxf/t;

    .line 381
    .line 382
    if-eqz v8, :cond_12

    .line 383
    .line 384
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getApplyStatus()Ljava/lang/Integer;

    .line 385
    .line 386
    .line 387
    move-result-object v8

    .line 388
    if-nez v8, :cond_11

    .line 389
    .line 390
    goto :goto_6

    .line 391
    :cond_11
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 392
    .line 393
    .line 394
    move-result v8

    .line 395
    if-ne v8, v3, :cond_12

    .line 396
    .line 397
    goto :goto_7

    .line 398
    :cond_12
    :goto_6
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 399
    .line 400
    .line 401
    move-result-object v3

    .line 402
    if-eqz v3, :cond_14

    .line 403
    .line 404
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getApplyStatus()Ljava/lang/Integer;

    .line 405
    .line 406
    .line 407
    move-result-object v3

    .line 408
    if-nez v3, :cond_13

    .line 409
    .line 410
    goto :goto_8

    .line 411
    :cond_13
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 412
    .line 413
    .line 414
    move-result v3

    .line 415
    if-ne v3, v2, :cond_14

    .line 416
    .line 417
    :goto_7
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    move-result-object p1

    .line 421
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 422
    .line 423
    .line 424
    check-cast p1, Landroid/widget/LinearLayout;

    .line 425
    .line 426
    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    .line 427
    .line 428
    .line 429
    invoke-virtual {v9}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object p1

    .line 433
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 434
    .line 435
    .line 436
    check-cast p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 437
    .line 438
    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    .line 439
    .line 440
    .line 441
    goto/16 :goto_c

    .line 442
    .line 443
    :cond_14
    :goto_8
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 444
    .line 445
    .line 446
    move-result-object v2

    .line 447
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 448
    .line 449
    .line 450
    check-cast v2, Landroid/widget/LinearLayout;

    .line 451
    .line 452
    invoke-virtual {v2, v7}, Landroid/view/View;->setVisibility(I)V

    .line 453
    .line 454
    .line 455
    invoke-virtual {v9}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v2

    .line 459
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 460
    .line 461
    .line 462
    check-cast v2, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 463
    .line 464
    invoke-virtual {v2, v7}, Landroid/view/View;->setVisibility(I)V

    .line 465
    .line 466
    .line 467
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 468
    .line 469
    .line 470
    move-result-object v2

    .line 471
    if-eqz v2, :cond_15

    .line 472
    .line 473
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCreditCard()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;

    .line 474
    .line 475
    .line 476
    move-result-object v2

    .line 477
    if-eqz v2, :cond_15

    .line 478
    .line 479
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getAllOutstandingAmount()Ljava/lang/Long;

    .line 480
    .line 481
    .line 482
    move-result-object v2

    .line 483
    if-eqz v2, :cond_15

    .line 484
    .line 485
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 486
    .line 487
    .line 488
    move-result-wide v2

    .line 489
    goto :goto_9

    .line 490
    :cond_15
    move-wide v2, v0

    .line 491
    :goto_9
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 492
    .line 493
    .line 494
    move-result-object v8

    .line 495
    if-eqz v8, :cond_16

    .line 496
    .line 497
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCurrentCashLoanBill()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;

    .line 498
    .line 499
    .line 500
    move-result-object v8

    .line 501
    if-eqz v8, :cond_16

    .line 502
    .line 503
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCashLoanBill;->getOutstandingAmount()J

    .line 504
    .line 505
    .line 506
    move-result-wide v8

    .line 507
    goto :goto_a

    .line 508
    :cond_16
    move-wide v8, v0

    .line 509
    :goto_a
    cmp-long v2, v2, v8

    .line 510
    .line 511
    if-lez v2, :cond_18

    .line 512
    .line 513
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->n()Landroid/widget/TextView;

    .line 514
    .line 515
    .line 516
    move-result-object v2

    .line 517
    sget v3, LYa/g;->cs_oc_total_outstanding:I

    .line 518
    .line 519
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 520
    .line 521
    .line 522
    move-result-object v4

    .line 523
    if-eqz v4, :cond_17

    .line 524
    .line 525
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;->getCreditCard()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;

    .line 526
    .line 527
    .line 528
    move-result-object v4

    .line 529
    if-eqz v4, :cond_17

    .line 530
    .line 531
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainCreditCard;->getAllOutstandingAmount()Ljava/lang/Long;

    .line 532
    .line 533
    .line 534
    move-result-object v4

    .line 535
    if-eqz v4, :cond_17

    .line 536
    .line 537
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 538
    .line 539
    .line 540
    move-result-wide v0

    .line 541
    :cond_17
    invoke-static {v0, v1, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 542
    .line 543
    .line 544
    move-result-object v0

    .line 545
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 546
    .line 547
    .line 548
    move-result-object v0

    .line 549
    invoke-virtual {v6, v3, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 550
    .line 551
    .line 552
    move-result-object v0

    .line 553
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 554
    .line 555
    .line 556
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->n()Landroid/widget/TextView;

    .line 557
    .line 558
    .line 559
    move-result-object v0

    .line 560
    invoke-virtual {v0, v7}, Landroid/view/View;->setVisibility(I)V

    .line 561
    .line 562
    .line 563
    goto :goto_b

    .line 564
    :cond_18
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->n()Landroid/widget/TextView;

    .line 565
    .line 566
    .line 567
    move-result-object v0

    .line 568
    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    .line 569
    .line 570
    .line 571
    :goto_b
    iget-object v0, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->t:Lxf/t;

    .line 572
    .line 573
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 574
    .line 575
    .line 576
    move-result-object v0

    .line 577
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 578
    .line 579
    .line 580
    check-cast v0, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 581
    .line 582
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/CLMainResp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;

    .line 583
    .line 584
    .line 585
    move-result-object p1

    .line 586
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->h(Lcom/transsnet/palmpay/credit/bean/rsp/CLMainData;)V

    .line 587
    .line 588
    .line 589
    goto :goto_c

    .line 590
    :cond_19
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 591
    .line 592
    .line 593
    move-result-object p1

    .line 594
    new-array v0, v7, [Ljava/lang/Object;

    .line 595
    .line 596
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 597
    .line 598
    .line 599
    goto :goto_c

    .line 600
    :cond_1a
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 601
    .line 602
    if-eqz v0, :cond_1b

    .line 603
    .line 604
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 605
    .line 606
    .line 607
    goto :goto_c

    .line 608
    :cond_1b
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 609
    .line 610
    if-eqz v0, :cond_1c

    .line 611
    .line 612
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 613
    .line 614
    .line 615
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 616
    .line 617
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 618
    .line 619
    new-array v0, v7, [Ljava/lang/Object;

    .line 620
    .line 621
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 622
    .line 623
    .line 624
    :goto_c
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 625
    .line 626
    return-object p1

    .line 627
    :cond_1c
    new-instance p1, Lxf/l;

    .line 628
    .line 629
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 630
    .line 631
    .line 632
    throw p1

    .line 633
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 634
    .line 635
    invoke-static {p1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 636
    .line 637
    .line 638
    instance-of v10, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 639
    .line 640
    if-eqz v10, :cond_1d

    .line 641
    .line 642
    invoke-interface {v9, v8, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 643
    .line 644
    .line 645
    goto/16 :goto_12

    .line 646
    .line 647
    :cond_1d
    instance-of v10, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 648
    .line 649
    if-eqz v10, :cond_26

    .line 650
    .line 651
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 652
    .line 653
    .line 654
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 655
    .line 656
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 657
    .line 658
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRsp;

    .line 659
    .line 660
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 661
    .line 662
    .line 663
    move-result v8

    .line 664
    if-eqz v8, :cond_25

    .line 665
    .line 666
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRsp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 667
    .line 668
    .line 669
    move-result-object v8

    .line 670
    if-eqz v8, :cond_25

    .line 671
    .line 672
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRsp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 673
    .line 674
    .line 675
    move-result-object v8

    .line 676
    iput-object v8, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->Z:Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 677
    .line 678
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRsp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 679
    .line 680
    .line 681
    move-result-object v8

    .line 682
    iget-object v9, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->L:Lxf/t;

    .line 683
    .line 684
    iget-object v10, v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->Q:Lxf/t;

    .line 685
    .line 686
    if-eqz v8, :cond_1f

    .line 687
    .line 688
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getApplyStatus()Ljava/lang/Integer;

    .line 689
    .line 690
    .line 691
    move-result-object v8

    .line 692
    if-nez v8, :cond_1e

    .line 693
    .line 694
    goto :goto_d

    .line 695
    :cond_1e
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 696
    .line 697
    .line 698
    move-result v8

    .line 699
    if-ne v8, v3, :cond_1f

    .line 700
    .line 701
    goto :goto_e

    .line 702
    :cond_1f
    :goto_d
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRsp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 703
    .line 704
    .line 705
    move-result-object v3

    .line 706
    if-eqz v3, :cond_21

    .line 707
    .line 708
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getApplyStatus()Ljava/lang/Integer;

    .line 709
    .line 710
    .line 711
    move-result-object v3

    .line 712
    if-nez v3, :cond_20

    .line 713
    .line 714
    goto :goto_f

    .line 715
    :cond_20
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 716
    .line 717
    .line 718
    move-result v3

    .line 719
    if-ne v3, v2, :cond_21

    .line 720
    .line 721
    :goto_e
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 722
    .line 723
    .line 724
    move-result-object p1

    .line 725
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 726
    .line 727
    .line 728
    check-cast p1, Landroid/widget/LinearLayout;

    .line 729
    .line 730
    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    .line 731
    .line 732
    .line 733
    invoke-virtual {v9}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 734
    .line 735
    .line 736
    move-result-object p1

    .line 737
    invoke-static {p1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 738
    .line 739
    .line 740
    check-cast p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 741
    .line 742
    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    .line 743
    .line 744
    .line 745
    goto/16 :goto_12

    .line 746
    .line 747
    :cond_21
    :goto_f
    invoke-virtual {v10}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 748
    .line 749
    .line 750
    move-result-object v2

    .line 751
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 752
    .line 753
    .line 754
    check-cast v2, Landroid/widget/LinearLayout;

    .line 755
    .line 756
    invoke-virtual {v2, v7}, Landroid/view/View;->setVisibility(I)V

    .line 757
    .line 758
    .line 759
    invoke-virtual {v9}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 760
    .line 761
    .line 762
    move-result-object v2

    .line 763
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 764
    .line 765
    .line 766
    check-cast v2, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 767
    .line 768
    invoke-virtual {v2, v7}, Landroid/view/View;->setVisibility(I)V

    .line 769
    .line 770
    .line 771
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRsp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 772
    .line 773
    .line 774
    move-result-object v2

    .line 775
    if-eqz v2, :cond_22

    .line 776
    .line 777
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getNextCycleInstallmentAmount()Ljava/lang/Long;

    .line 778
    .line 779
    .line 780
    move-result-object v2

    .line 781
    if-eqz v2, :cond_22

    .line 782
    .line 783
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 784
    .line 785
    .line 786
    move-result-wide v2

    .line 787
    goto :goto_10

    .line 788
    :cond_22
    move-wide v2, v0

    .line 789
    :goto_10
    cmp-long v2, v2, v0

    .line 790
    .line 791
    if-lez v2, :cond_24

    .line 792
    .line 793
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r()Landroid/widget/TextView;

    .line 794
    .line 795
    .line 796
    move-result-object v2

    .line 797
    sget v3, LYa/g;->cs_oc_total_outstanding:I

    .line 798
    .line 799
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRsp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 800
    .line 801
    .line 802
    move-result-object v4

    .line 803
    if-eqz v4, :cond_23

    .line 804
    .line 805
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;->getAllOutstandingAmount()Ljava/lang/Long;

    .line 806
    .line 807
    .line 808
    move-result-object v4

    .line 809
    if-eqz v4, :cond_23

    .line 810
    .line 811
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 812
    .line 813
    .line 814
    move-result-wide v0

    .line 815
    :cond_23
    invoke-static {v0, v1, v7}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 816
    .line 817
    .line 818
    move-result-object v0

    .line 819
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 820
    .line 821
    .line 822
    move-result-object v0

    .line 823
    invoke-virtual {v6, v3, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 824
    .line 825
    .line 826
    move-result-object v0

    .line 827
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 828
    .line 829
    .line 830
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r()Landroid/widget/TextView;

    .line 831
    .line 832
    .line 833
    move-result-object v0

    .line 834
    invoke-virtual {v0, v7}, Landroid/view/View;->setVisibility(I)V

    .line 835
    .line 836
    .line 837
    goto :goto_11

    .line 838
    :cond_24
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r()Landroid/widget/TextView;

    .line 839
    .line 840
    .line 841
    move-result-object v0

    .line 842
    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    .line 843
    .line 844
    .line 845
    :goto_11
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->q()Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 846
    .line 847
    .line 848
    move-result-object v0

    .line 849
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRsp;->getData()Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;

    .line 850
    .line 851
    .line 852
    move-result-object p1

    .line 853
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;->j(Lcom/transsnet/palmpay/credit/bean/rsp/OkCardMainPageRspData;)V

    .line 854
    .line 855
    .line 856
    goto :goto_12

    .line 857
    :cond_25
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 858
    .line 859
    .line 860
    move-result-object p1

    .line 861
    new-array v0, v7, [Ljava/lang/Object;

    .line 862
    .line 863
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 864
    .line 865
    .line 866
    goto :goto_12

    .line 867
    :cond_26
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 868
    .line 869
    if-eqz v0, :cond_27

    .line 870
    .line 871
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 872
    .line 873
    .line 874
    goto :goto_12

    .line 875
    :cond_27
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 876
    .line 877
    if-eqz v0, :cond_28

    .line 878
    .line 879
    invoke-interface {v9, v7, v8}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 880
    .line 881
    .line 882
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 883
    .line 884
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 885
    .line 886
    invoke-virtual {v6, v7}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 887
    .line 888
    .line 889
    new-array v0, v7, [Ljava/lang/Object;

    .line 890
    .line 891
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 892
    .line 893
    .line 894
    :goto_12
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 895
    .line 896
    return-object p1

    .line 897
    :cond_28
    new-instance p1, Lxf/l;

    .line 898
    .line 899
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 900
    .line 901
    .line 902
    throw p1

    .line 903
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
