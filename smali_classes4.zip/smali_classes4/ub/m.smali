.class public final synthetic Lub/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/m;->a:I

    iput-object p1, p0, Lub/m;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Lub/m;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/m;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 9
    .line 10
    sget v1, LYa/e;->pending_second_start_iv:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/ImageView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 20
    .line 21
    sget v1, LYa/e;->pending_second_end_iv:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/ImageView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 31
    .line 32
    sget v1, LYa/e;->pending_second_tips_tv:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/widget/TextView;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 42
    .line 43
    sget v1, LYa/e;->pending_third_start_iv:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Landroid/widget/ImageView;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 53
    .line 54
    sget v1, LYa/e;->pending_third_end_iv:I

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Landroid/widget/ImageView;

    .line 61
    .line 62
    return-object v0

    .line 63
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 64
    .line 65
    new-instance v1, Lub/p;

    .line 66
    .line 67
    const/4 v2, 0x1

    .line 68
    invoke-direct {v1, v0, v2}, Lub/p;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;I)V

    .line 69
    .line 70
    .line 71
    return-object v1

    .line 72
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 73
    .line 74
    new-instance v1, Lub/p;

    .line 75
    .line 76
    const/4 v2, 0x2

    .line 77
    invoke-direct {v1, v0, v2}, Lub/p;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;I)V

    .line 78
    .line 79
    .line 80
    return-object v1

    .line 81
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 82
    .line 83
    sget v1, LYa/e;->countdown_tv:I

    .line 84
    .line 85
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    check-cast v0, Landroid/widget/TextView;

    .line 90
    .line 91
    return-object v0

    .line 92
    :pswitch_7
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 93
    .line 94
    new-instance v1, Lub/p;

    .line 95
    .line 96
    const/4 v2, 0x3

    .line 97
    invoke-direct {v1, v0, v2}, Lub/p;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;I)V

    .line 98
    .line 99
    .line 100
    return-object v1

    .line 101
    :pswitch_8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 102
    .line 103
    sget v1, LYa/e;->apply_result_bg_img:I

    .line 104
    .line 105
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Landroid/widget/ImageView;

    .line 110
    .line 111
    return-object v0

    .line 112
    :pswitch_9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 113
    .line 114
    sget v1, LYa/e;->apply_result_mtb:I

    .line 115
    .line 116
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    check-cast v0, Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 121
    .line 122
    return-object v0

    .line 123
    :pswitch_a
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 124
    .line 125
    sget v1, LYa/e;->apply_failed_ll:I

    .line 126
    .line 127
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    check-cast v0, Landroid/widget/LinearLayout;

    .line 132
    .line 133
    return-object v0

    .line 134
    :pswitch_b
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 135
    .line 136
    sget v1, LYa/e;->oc_apply_failed_content_tv:I

    .line 137
    .line 138
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    check-cast v0, Landroid/widget/TextView;

    .line 143
    .line 144
    return-object v0

    .line 145
    :pswitch_c
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 146
    .line 147
    sget v1, LYa/e;->apply_back_bt:I

    .line 148
    .line 149
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 154
    .line 155
    return-object v0

    .line 156
    :pswitch_d
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 157
    .line 158
    sget v1, LYa/e;->apply_result_task_view:I

    .line 159
    .line 160
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    check-cast v0, Lcom/transsnet/palmpay/credit/view/OpenResultTaskView;

    .line 165
    .line 166
    return-object v0

    .line 167
    :pswitch_e
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 168
    .line 169
    sget v1, LYa/e;->pending_third_tips_tv:I

    .line 170
    .line 171
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    check-cast v0, Landroid/widget/TextView;

    .line 176
    .line 177
    return-object v0

    .line 178
    :pswitch_f
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 179
    .line 180
    sget v1, LYa/e;->apply_success_ll:I

    .line 181
    .line 182
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    check-cast v0, Landroid/widget/LinearLayout;

    .line 187
    .line 188
    return-object v0

    .line 189
    :pswitch_10
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 190
    .line 191
    sget v1, LYa/e;->apply_credit_amount_tv:I

    .line 192
    .line 193
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    check-cast v0, Landroid/widget/TextView;

    .line 198
    .line 199
    return-object v0

    .line 200
    :pswitch_11
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 201
    .line 202
    sget v1, LYa/e;->countdown_tips_tv:I

    .line 203
    .line 204
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    check-cast v0, Landroid/widget/TextView;

    .line 209
    .line 210
    return-object v0

    .line 211
    :pswitch_12
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 212
    .line 213
    sget v1, LYa/e;->installment_content_tv:I

    .line 214
    .line 215
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    check-cast v0, Landroid/widget/TextView;

    .line 220
    .line 221
    return-object v0

    .line 222
    :pswitch_13
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 223
    .line 224
    sget v1, LYa/e;->layoutBtn:I

    .line 225
    .line 226
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    check-cast v0, Landroid/widget/LinearLayout;

    .line 231
    .line 232
    return-object v0

    .line 233
    :pswitch_14
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 234
    .line 235
    sget v1, LYa/e;->tvBackHome:I

    .line 236
    .line 237
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    check-cast v0, Landroid/widget/TextView;

    .line 242
    .line 243
    return-object v0

    .line 244
    :pswitch_15
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 245
    .line 246
    sget v1, LYa/e;->tvViewAccount:I

    .line 247
    .line 248
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    check-cast v0, Landroid/widget/TextView;

    .line 253
    .line 254
    return-object v0

    .line 255
    :pswitch_16
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 256
    .line 257
    sget v1, LYa/e;->success_ad_ll:I

    .line 258
    .line 259
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 260
    .line 261
    .line 262
    move-result-object v0

    .line 263
    check-cast v0, Landroid/widget/LinearLayout;

    .line 264
    .line 265
    return-object v0

    .line 266
    :pswitch_17
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 267
    .line 268
    sget v1, LYa/e;->apply_result_sav:I

    .line 269
    .line 270
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 275
    .line 276
    return-object v0

    .line 277
    :pswitch_18
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 278
    .line 279
    sget v1, LYa/e;->success_left_sav:I

    .line 280
    .line 281
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 282
    .line 283
    .line 284
    move-result-object v0

    .line 285
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 286
    .line 287
    return-object v0

    .line 288
    :pswitch_19
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 289
    .line 290
    sget v1, LYa/e;->success_middle_sav:I

    .line 291
    .line 292
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 297
    .line 298
    return-object v0

    .line 299
    :pswitch_1a
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 300
    .line 301
    sget v1, LYa/e;->pending_four_start_iv:I

    .line 302
    .line 303
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 304
    .line 305
    .line 306
    move-result-object v0

    .line 307
    check-cast v0, Landroid/widget/ImageView;

    .line 308
    .line 309
    return-object v0

    .line 310
    :pswitch_1b
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 311
    .line 312
    sget v1, LYa/e;->success_right_sav:I

    .line 313
    .line 314
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 315
    .line 316
    .line 317
    move-result-object v0

    .line 318
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 319
    .line 320
    return-object v0

    .line 321
    :pswitch_1c
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 322
    .line 323
    sget v1, LYa/e;->pending_four_tips_tv:I

    .line 324
    .line 325
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 326
    .line 327
    .line 328
    move-result-object v0

    .line 329
    check-cast v0, Landroid/widget/TextView;

    .line 330
    .line 331
    return-object v0

    .line 332
    nop

    .line 333
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
