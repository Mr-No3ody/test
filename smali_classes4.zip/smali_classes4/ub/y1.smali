.class public final synthetic Lub/y1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/y1;->a:I

    iput-object p1, p0, Lub/y1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lub/y1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/y1;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 9
    .line 10
    sget v1, LYa/e;->total_bill_top_sad:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 20
    .line 21
    sget v1, LYa/e;->oc_bill_title_ll:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Landroid/widget/LinearLayout;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 31
    .line 32
    sget v1, LYa/e;->oc_total_outstanding_tv:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/widget/TextView;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 42
    .line 43
    sget v1, LYa/e;->layoutBillCard:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 53
    .line 54
    sget v1, LYa/e;->oc_bill_card:I

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 61
    .line 62
    return-object v0

    .line 63
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 64
    .line 65
    sget v1, LYa/e;->cl_bill_title_ll:I

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Landroid/widget/LinearLayout;

    .line 72
    .line 73
    return-object v0

    .line 74
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 75
    .line 76
    sget v1, LYa/e;->cl_total_outstanding_tv:I

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    check-cast v0, Landroid/widget/TextView;

    .line 83
    .line 84
    return-object v0

    .line 85
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 86
    .line 87
    sget v1, LYa/e;->total_bill_bottom_right_sad:I

    .line 88
    .line 89
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 94
    .line 95
    return-object v0

    .line 96
    :pswitch_7
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 97
    .line 98
    sget v1, LYa/e;->layoutCashBillCard:I

    .line 99
    .line 100
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 105
    .line 106
    return-object v0

    .line 107
    :pswitch_8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 108
    .line 109
    sget v1, LYa/e;->layoutFlexiCash:I

    .line 110
    .line 111
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    check-cast v0, Landroid/widget/LinearLayout;

    .line 116
    .line 117
    return-object v0

    .line 118
    :pswitch_9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 119
    .line 120
    sget v1, LYa/e;->installment_bill_card:I

    .line 121
    .line 122
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    check-cast v0, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 127
    .line 128
    return-object v0

    .line 129
    :pswitch_a
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 130
    .line 131
    sget v1, LYa/e;->cash_bill_card:I

    .line 132
    .line 133
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    check-cast v0, Lcom/transsnet/palmpay/credit/view/OcCommonBillCard;

    .line 138
    .line 139
    return-object v0

    .line 140
    :pswitch_b
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 141
    .line 142
    sget v1, LYa/e;->total_bill_mid_sad:I

    .line 143
    .line 144
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 145
    .line 146
    .line 147
    move-result-object v0

    .line 148
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 149
    .line 150
    return-object v0

    .line 151
    :pswitch_c
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 152
    .line 153
    sget v1, LYa/e;->export_more_ll:I

    .line 154
    .line 155
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    check-cast v0, Landroid/widget/LinearLayout;

    .line 160
    .line 161
    return-object v0

    .line 162
    :pswitch_d
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 163
    .line 164
    sget v1, LYa/e;->total_bill_bottom_sad:I

    .line 165
    .line 166
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 171
    .line 172
    return-object v0

    .line 173
    :pswitch_e
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 174
    .line 175
    sget v1, LYa/e;->bottom_ad_ll:I

    .line 176
    .line 177
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    check-cast v0, Landroid/widget/LinearLayout;

    .line 182
    .line 183
    return-object v0

    .line 184
    :pswitch_f
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 185
    .line 186
    sget v1, LYa/e;->total_bill_bottom_left_sad:I

    .line 187
    .line 188
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 193
    .line 194
    return-object v0

    .line 195
    :pswitch_10
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalBillActivity;->r0:I

    .line 196
    .line 197
    sget v1, LYa/e;->marqueeView:I

    .line 198
    .line 199
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    check-cast v0, Landroid/widget/LinearLayout;

    .line 204
    .line 205
    return-object v0

    .line 206
    nop

    .line 207
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
