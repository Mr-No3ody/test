.class public final synthetic Lub/x0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/PinEntryView$OnPinEnteredListener;
.implements Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lub/x0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onPinEntered(Ljava/lang/String;)V
    .locals 3

    .line 1
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->v0:I

    .line 2
    .line 3
    const-string v0, "code"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lub/x0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    .line 9
    .line 10
    iput-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->u0:Ljava/lang/String;

    .line 11
    .line 12
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-nez v1, :cond_1

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    const/4 v2, 0x4

    .line 23
    if-ge v1, v2, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    invoke-static {v0}, Lcom/transsnet/palmpay/util/KeyboardUtils;->hideSoftInput(Landroid/app/Activity;)V

    .line 27
    .line 28
    .line 29
    new-instance v1, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;

    .line 30
    .line 31
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;-><init>()V

    .line 32
    .line 33
    .line 34
    const/16 v2, 0xf

    .line 35
    .line 36
    iput v2, v1, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->businessType:I

    .line 37
    .line 38
    invoke-static {}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->y()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->phoneNo:Ljava/lang/String;

    .line 43
    .line 44
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->smsCode:Ljava/lang/String;

    .line 45
    .line 46
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->z()Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV2View;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV2View;->getEmail()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    iput-object p1, v1, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;->email:Ljava/lang/String;

    .line 55
    .line 56
    const/4 p1, 0x1

    .line 57
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 58
    .line 59
    .line 60
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 61
    .line 62
    iget-object p1, p1, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast p1, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 65
    .line 66
    invoke-interface {p1, v1}, Lcom/transsnet/palmpay/core/network/PayApiService;->checkSmsCode(Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;)Ldf/d;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 71
    .line 72
    invoke-virtual {p1, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    invoke-virtual {p1, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    new-instance v1, Lub/z0;

    .line 85
    .line 86
    invoke-direct {v1, v0}, Lub/z0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {p1, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 90
    .line 91
    .line 92
    :cond_1
    :goto_0
    return-void
.end method

.method public onSend(IILjava/lang/String;)V
    .locals 1

    .line 1
    sget p2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->v0:I

    .line 2
    .line 3
    iget-object p2, p0, Lub/x0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    .line 4
    .line 5
    invoke-virtual {p2, p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->A(I)V

    .line 6
    .line 7
    .line 8
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const-string p2, "OcOtpVerifyActivity_element_click"

    .line 13
    .line 14
    const-string p3, "otp_view"

    .line 15
    .line 16
    const-string v0, "sendSms"

    .line 17
    .line 18
    invoke-virtual {p1, p2, p3, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method
