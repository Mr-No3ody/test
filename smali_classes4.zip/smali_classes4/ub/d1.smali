.class public final synthetic Lub/d1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendPreviewActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendPreviewActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/d1;->a:I

    iput-object p1, p0, Lub/d1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendPreviewActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget-object p1, p0, Lub/d1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendPreviewActivity;

    .line 2
    .line 3
    iget v0, p0, Lub/d1;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendPreviewActivity;->w0:I

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/ui/activity/m;->L()V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendPreviewActivity;->w0:I

    .line 15
    .line 16
    iget-object v0, p1, Lcom/transsnet/palmpay/core/ui/activity/m;->d:Lcom/transsnet/palmpay/core/bean/PaymentMethod;

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    if-nez v0, :cond_0

    .line 20
    .line 21
    const-string p1, "please select a payment method"

    .line 22
    .line 23
    new-array v0, v1, [Ljava/lang/Object;

    .line 24
    .line 25
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendPreviewActivity;->u0:Ljava/lang/String;

    .line 30
    .line 31
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    new-array v0, v1, [Ljava/lang/Object;

    .line 38
    .line 39
    const-string v1, "order id is null"

    .line 40
    .line 41
    invoke-static {v1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayExtendPreviewActivity;->u0:Ljava/lang/String;

    .line 49
    .line 50
    iput-object v0, p1, Lcom/transsnet/palmpay/core/ui/activity/m;->i:Ljava/lang/String;

    .line 51
    .line 52
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/ui/activity/m;->E()V

    .line 53
    .line 54
    .line 55
    :goto_0
    return-void

    .line 56
    nop

    .line 57
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
