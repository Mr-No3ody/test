.class public final Lub/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/l;->a:I

    iput-object p1, p0, Lub/l;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;)V
    .locals 0

    const/4 p1, 0x0

    iput p1, p0, Lub/l;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lub/l;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lub/l;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    move-object/from16 v1, p1

    .line 9
    .line 10
    check-cast v1, Ljava/lang/Boolean;

    .line 11
    .line 12
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    const/16 v2, 0x158

    .line 17
    .line 18
    invoke-static {v2, v1}, LC0/G;->u(ILorg/greenrobot/eventbus/c;)V

    .line 19
    .line 20
    .line 21
    iget-object v1, v0, Lub/l;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;

    .line 22
    .line 23
    invoke-virtual {v1}, Landroid/app/Activity;->finish()V

    .line 24
    .line 25
    .line 26
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 27
    .line 28
    return-object v1

    .line 29
    :pswitch_0
    move-object/from16 v1, p1

    .line 30
    .line 31
    check-cast v1, Lcom/transsnet/palmpay/core/base/q;

    .line 32
    .line 33
    const-string v2, "it"

    .line 34
    .line 35
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    instance-of v2, v1, Lcom/transsnet/palmpay/core/base/o;

    .line 39
    .line 40
    if-nez v2, :cond_7

    .line 41
    .line 42
    instance-of v2, v1, Lcom/transsnet/palmpay/core/base/p;

    .line 43
    .line 44
    iget-object v3, v0, Lub/l;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;

    .line 45
    .line 46
    const/4 v4, 0x0

    .line 47
    if-eqz v2, :cond_5

    .line 48
    .line 49
    check-cast v1, Lcom/transsnet/palmpay/core/base/p;

    .line 50
    .line 51
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;

    .line 54
    .line 55
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    if-eqz v2, :cond_4

    .line 60
    .line 61
    new-instance v5, Lcom/transsnet/palmpay/credit/bean/req/OcApplyReq;

    .line 62
    .line 63
    iget v2, v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->B:I

    .line 64
    .line 65
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object v7

    .line 69
    const-string v2, "context"

    .line 70
    .line 71
    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    const/4 v2, 0x0

    .line 75
    :try_start_0
    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    if-eqz v6, :cond_0

    .line 80
    .line 81
    invoke-virtual {v6, v4}, Landroid/content/pm/PackageManager;->getInstalledPackages(I)Ljava/util/List;

    .line 82
    .line 83
    .line 84
    move-result-object v6

    .line 85
    goto :goto_0

    .line 86
    :cond_0
    move-object v6, v2

    .line 87
    :goto_0
    move-object v8, v6

    .line 88
    check-cast v8, Ljava/util/Collection;

    .line 89
    .line 90
    if-eqz v8, :cond_2

    .line 91
    .line 92
    invoke-interface {v8}, Ljava/util/Collection;->isEmpty()Z

    .line 93
    .line 94
    .line 95
    move-result v8

    .line 96
    if-eqz v8, :cond_1

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_1
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 100
    .line 101
    .line 102
    move-result v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 103
    goto :goto_2

    .line 104
    :catch_0
    :cond_2
    :goto_1
    move v6, v4

    .line 105
    :goto_2
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 106
    .line 107
    .line 108
    move-result-object v9

    .line 109
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    if-eqz v1, :cond_3

    .line 114
    .line 115
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;->getApplyId()Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    move-object v12, v1

    .line 120
    goto :goto_3

    .line 121
    :cond_3
    move-object v12, v2

    .line 122
    :goto_3
    const/16 v21, 0x7f80

    .line 123
    .line 124
    const/16 v22, 0x0

    .line 125
    .line 126
    const-string v6, "CASHIER_PAGE"

    .line 127
    .line 128
    const-string v8, ""

    .line 129
    .line 130
    const/4 v10, 0x0

    .line 131
    const/4 v11, 0x0

    .line 132
    const/4 v13, 0x0

    .line 133
    const/4 v14, 0x0

    .line 134
    const/4 v15, 0x0

    .line 135
    const/16 v16, 0x0

    .line 136
    .line 137
    const/16 v17, 0x0

    .line 138
    .line 139
    const/16 v18, 0x0

    .line 140
    .line 141
    const/16 v19, 0x0

    .line 142
    .line 143
    const/16 v20, 0x0

    .line 144
    .line 145
    invoke-direct/range {v5 .. v22}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyReq;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/viewmodel/OcApplyLiteViewModel;

    .line 153
    .line 154
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 155
    .line 156
    .line 157
    const-string v3, "req"

    .line 158
    .line 159
    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    new-instance v3, LDb/l;

    .line 163
    .line 164
    invoke-direct {v3, v5, v2}, LDb/l;-><init>(Lcom/transsnet/palmpay/credit/bean/req/OcApplyReq;Lkotlin/coroutines/Continuation;)V

    .line 165
    .line 166
    .line 167
    const/16 v2, 0x1c

    .line 168
    .line 169
    iget-object v5, v1, Lcom/transsnet/palmpay/credit/ui/viewmodel/OcApplyLiteViewModel;->e:Lcom/transsnet/palmpay/core/base/l;

    .line 170
    .line 171
    invoke-static {v1, v3, v5, v4, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 172
    .line 173
    .line 174
    goto :goto_4

    .line 175
    :cond_4
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    invoke-static {v3, v1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 180
    .line 181
    .line 182
    goto :goto_4

    .line 183
    :cond_5
    instance-of v2, v1, Lcom/transsnet/palmpay/core/base/m;

    .line 184
    .line 185
    if-nez v2, :cond_7

    .line 186
    .line 187
    instance-of v2, v1, Lcom/transsnet/palmpay/core/base/n;

    .line 188
    .line 189
    if-eqz v2, :cond_6

    .line 190
    .line 191
    check-cast v1, Lcom/transsnet/palmpay/core/base/n;

    .line 192
    .line 193
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 194
    .line 195
    invoke-static {v3, v1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->showLoadingDialog(Z)V

    .line 199
    .line 200
    .line 201
    goto :goto_4

    .line 202
    :cond_6
    new-instance v1, Lxf/l;

    .line 203
    .line 204
    invoke-direct {v1}, Ljava/lang/RuntimeException;-><init>()V

    .line 205
    .line 206
    .line 207
    throw v1

    .line 208
    :cond_7
    :goto_4
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 209
    .line 210
    return-object v1

    .line 211
    :pswitch_1
    move-object/from16 v1, p1

    .line 212
    .line 213
    check-cast v1, Lcom/transsnet/palmpay/core/base/q;

    .line 214
    .line 215
    const-string v2, "it"

    .line 216
    .line 217
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    instance-of v2, v1, Lcom/transsnet/palmpay/core/base/o;

    .line 221
    .line 222
    if-eqz v2, :cond_8

    .line 223
    .line 224
    goto/16 :goto_8

    .line 225
    .line 226
    :cond_8
    instance-of v2, v1, Lcom/transsnet/palmpay/core/base/p;

    .line 227
    .line 228
    iget-object v3, v0, Lub/l;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;

    .line 229
    .line 230
    const/4 v4, 0x0

    .line 231
    if-eqz v2, :cond_f

    .line 232
    .line 233
    check-cast v1, Lcom/transsnet/palmpay/core/base/p;

    .line 234
    .line 235
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 236
    .line 237
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultResp;

    .line 238
    .line 239
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 240
    .line 241
    .line 242
    move-result v2

    .line 243
    if-eqz v2, :cond_e

    .line 244
    .line 245
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;

    .line 246
    .line 247
    .line 248
    move-result-object v1

    .line 249
    if-eqz v1, :cond_9

    .line 250
    .line 251
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;->getApplyStatus()Ljava/lang/Integer;

    .line 252
    .line 253
    .line 254
    move-result-object v1

    .line 255
    goto :goto_5

    .line 256
    :cond_9
    const/4 v1, 0x0

    .line 257
    :goto_5
    if-nez v1, :cond_a

    .line 258
    .line 259
    goto :goto_6

    .line 260
    :cond_a
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 261
    .line 262
    .line 263
    move-result v2

    .line 264
    const/4 v4, 0x1

    .line 265
    if-ne v2, v4, :cond_b

    .line 266
    .line 267
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 268
    .line 269
    .line 270
    move-result-object v1

    .line 271
    new-instance v2, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;

    .line 272
    .line 273
    const/16 v4, 0x158

    .line 274
    .line 275
    invoke-direct {v2, v4}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;-><init>(I)V

    .line 276
    .line 277
    .line 278
    invoke-virtual {v1, v2}, Lorg/greenrobot/eventbus/c;->f(Ljava/lang/Object;)V

    .line 279
    .line 280
    .line 281
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 282
    .line 283
    .line 284
    goto :goto_8

    .line 285
    :cond_b
    :goto_6
    if-nez v1, :cond_c

    .line 286
    .line 287
    goto :goto_7

    .line 288
    :cond_c
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 289
    .line 290
    .line 291
    move-result v1

    .line 292
    const/4 v2, 0x2

    .line 293
    if-ne v1, v2, :cond_d

    .line 294
    .line 295
    sget v1, LYa/g;->cs_msg_apply_okcard_fail:I

    .line 296
    .line 297
    invoke-virtual {v3, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v1

    .line 301
    invoke-static {v3, v1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 305
    .line 306
    .line 307
    goto :goto_8

    .line 308
    :cond_d
    :goto_7
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 309
    .line 310
    invoke-static {v1}, Ldf/d;->h(Ljava/lang/Object;)Lio/reactivex/internal/operators/observable/B;

    .line 311
    .line 312
    .line 313
    move-result-object v1

    .line 314
    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 315
    .line 316
    sget-object v4, Ltf/f;->b:Ldf/i;

    .line 317
    .line 318
    const-wide/16 v5, 0xa

    .line 319
    .line 320
    invoke-virtual {v1, v5, v6, v2, v4}, Ldf/d;->e(JLjava/util/concurrent/TimeUnit;Ldf/i;)Lio/reactivex/internal/operators/observable/i;

    .line 321
    .line 322
    .line 323
    move-result-object v1

    .line 324
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 325
    .line 326
    .line 327
    move-result-object v2

    .line 328
    invoke-virtual {v1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 329
    .line 330
    .line 331
    move-result-object v1

    .line 332
    new-instance v2, Lub/l;

    .line 333
    .line 334
    const/4 v4, 0x2

    .line 335
    invoke-direct {v2, v3, v4}, Lub/l;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;I)V

    .line 336
    .line 337
    .line 338
    new-instance v4, Lorg/greenrobot/eventbus/f;

    .line 339
    .line 340
    invoke-direct {v4, v2}, Lorg/greenrobot/eventbus/f;-><init>(Lub/l;)V

    .line 341
    .line 342
    .line 343
    sget-object v2, Ljf/a;->e:Lcom/growingio/android/circler/a;

    .line 344
    .line 345
    sget-object v5, Ljf/a;->c:Lr2/c;

    .line 346
    .line 347
    new-instance v6, Lkf/e;

    .line 348
    .line 349
    invoke-direct {v6, v4, v2, v5}, Lkf/e;-><init>(Lio/reactivex/functions/Consumer;Lio/reactivex/functions/Consumer;Lio/reactivex/functions/Action;)V

    .line 350
    .line 351
    .line 352
    invoke-virtual {v1, v6}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 353
    .line 354
    .line 355
    invoke-virtual {v3, v6}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 356
    .line 357
    .line 358
    goto :goto_8

    .line 359
    :cond_e
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->showLoadingDialog(Z)V

    .line 360
    .line 361
    .line 362
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 363
    .line 364
    .line 365
    move-result-object v1

    .line 366
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->showLoadingDialog(Z)V

    .line 367
    .line 368
    .line 369
    invoke-static {v3, v1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 370
    .line 371
    .line 372
    invoke-virtual {v3}, Landroid/app/Activity;->finish()V

    .line 373
    .line 374
    .line 375
    goto :goto_8

    .line 376
    :cond_f
    instance-of v2, v1, Lcom/transsnet/palmpay/core/base/m;

    .line 377
    .line 378
    if-eqz v2, :cond_10

    .line 379
    .line 380
    goto :goto_8

    .line 381
    :cond_10
    instance-of v2, v1, Lcom/transsnet/palmpay/core/base/n;

    .line 382
    .line 383
    if-eqz v2, :cond_11

    .line 384
    .line 385
    check-cast v1, Lcom/transsnet/palmpay/core/base/n;

    .line 386
    .line 387
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 388
    .line 389
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyLiteActivity;->showLoadingDialog(Z)V

    .line 390
    .line 391
    .line 392
    invoke-static {v3, v1}, Loa/h;->x(Landroid/content/Context;Ljava/lang/String;)V

    .line 393
    .line 394
    .line 395
    :goto_8
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 396
    .line 397
    return-object v1

    .line 398
    :cond_11
    new-instance v1, Lxf/l;

    .line 399
    .line 400
    invoke-direct {v1}, Ljava/lang/RuntimeException;-><init>()V

    .line 401
    .line 402
    .line 403
    throw v1

    .line 404
    nop

    .line 405
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
