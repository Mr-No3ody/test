.class public final Lub/s;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/s;->f:I

    iput-object p1, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_0
    const-string v0, "d"

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :pswitch_1
    const-string v0, "d"

    .line 29
    .line 30
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 34
    .line 35
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_2
    const-string v0, "d"

    .line 40
    .line 41
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 45
    .line 46
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    nop

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget v0, p0, Lub/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    new-array v0, v0, [Ljava/lang/Object;

    .line 14
    .line 15
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void

    .line 19
    :pswitch_0
    const-string v0, "message"

    .line 20
    .line 21
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 25
    .line 26
    const/4 v1, 0x0

    .line 27
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 28
    .line 29
    .line 30
    iget v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 31
    .line 32
    add-int/lit8 v2, v2, -0x1

    .line 33
    .line 34
    iput v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 35
    .line 36
    iput-boolean v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->f:Z

    .line 37
    .line 38
    new-array v0, v1, [Ljava/lang/Object;

    .line 39
    .line 40
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :pswitch_1
    const-string v0, "message"

    .line 45
    .line 46
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 50
    .line 51
    const/4 v1, 0x0

    .line 52
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 53
    .line 54
    .line 55
    iget v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 56
    .line 57
    add-int/lit8 v2, v2, -0x1

    .line 58
    .line 59
    iput v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 60
    .line 61
    iput-boolean v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->f:Z

    .line 62
    .line 63
    new-array v0, v1, [Ljava/lang/Object;

    .line 64
    .line 65
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :pswitch_2
    const-string v0, "message"

    .line 70
    .line 71
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 75
    .line 76
    const/4 v1, 0x0

    .line 77
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 78
    .line 79
    .line 80
    iget v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 81
    .line 82
    add-int/lit8 v2, v2, -0x1

    .line 83
    .line 84
    iput v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 85
    .line 86
    iput-boolean v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->f:Z

    .line 87
    .line 88
    new-array v0, v1, [Ljava/lang/Object;

    .line 89
    .line 90
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    return-void

    .line 94
    nop

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget v0, p0, Lub/s;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v1, 0x1

    .line 15
    if-ne v0, v1, :cond_0

    .line 16
    .line 17
    goto :goto_1

    .line 18
    :cond_0
    const/4 v0, 0x0

    .line 19
    if-eqz p1, :cond_1

    .line 20
    .line 21
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    goto :goto_0

    .line 26
    :cond_1
    move-object v1, v0

    .line 27
    :goto_0
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-nez v1, :cond_3

    .line 32
    .line 33
    if-eqz p1, :cond_2

    .line 34
    .line 35
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    :cond_2
    const/4 p1, 0x0

    .line 40
    new-array p1, p1, [Ljava/lang/Object;

    .line 41
    .line 42
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_3
    :goto_1
    return-void

    .line 46
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 47
    .line 48
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 49
    .line 50
    iget v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 51
    .line 52
    add-int/lit8 v1, v1, -0x1

    .line 53
    .line 54
    iput v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 55
    .line 56
    if-eqz p1, :cond_4

    .line 57
    .line 58
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    const/4 v2, 0x1

    .line 63
    if-ne v1, v2, :cond_4

    .line 64
    .line 65
    goto :goto_3

    .line 66
    :cond_4
    const/4 v1, 0x0

    .line 67
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 68
    .line 69
    .line 70
    iput-boolean v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->f:Z

    .line 71
    .line 72
    if-eqz p1, :cond_5

    .line 73
    .line 74
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    goto :goto_2

    .line 79
    :cond_5
    const/4 p1, 0x0

    .line 80
    :goto_2
    new-array v1, v1, [Ljava/lang/Object;

    .line 81
    .line 82
    invoke-static {p1, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    :goto_3
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->n()V

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 90
    .line 91
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 92
    .line 93
    iget v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 94
    .line 95
    add-int/lit8 v1, v1, -0x1

    .line 96
    .line 97
    iput v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 98
    .line 99
    if-eqz p1, :cond_6

    .line 100
    .line 101
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    const/4 v2, 0x1

    .line 106
    if-ne v1, v2, :cond_6

    .line 107
    .line 108
    goto :goto_5

    .line 109
    :cond_6
    const/4 v1, 0x0

    .line 110
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 111
    .line 112
    .line 113
    iput-boolean v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->f:Z

    .line 114
    .line 115
    if-eqz p1, :cond_7

    .line 116
    .line 117
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    goto :goto_4

    .line 122
    :cond_7
    const/4 p1, 0x0

    .line 123
    :goto_4
    new-array v1, v1, [Ljava/lang/Object;

    .line 124
    .line 125
    invoke-static {p1, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    :goto_5
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->n()V

    .line 129
    .line 130
    .line 131
    return-void

    .line 132
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 133
    .line 134
    iget-object v0, p0, Lub/s;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;

    .line 135
    .line 136
    iget v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 137
    .line 138
    add-int/lit8 v1, v1, -0x1

    .line 139
    .line 140
    iput v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->e:I

    .line 141
    .line 142
    if-eqz p1, :cond_8

    .line 143
    .line 144
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 145
    .line 146
    .line 147
    move-result v1

    .line 148
    const/4 v2, 0x1

    .line 149
    if-ne v1, v2, :cond_8

    .line 150
    .line 151
    goto :goto_7

    .line 152
    :cond_8
    const/4 v1, 0x0

    .line 153
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 154
    .line 155
    .line 156
    iput-boolean v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->f:Z

    .line 157
    .line 158
    if-eqz p1, :cond_9

    .line 159
    .line 160
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    goto :goto_6

    .line 165
    :cond_9
    const/4 p1, 0x0

    .line 166
    :goto_6
    new-array v1, v1, [Ljava/lang/Object;

    .line 167
    .line 168
    invoke-static {p1, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    :goto_7
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcAuthActivity;->n()V

    .line 172
    .line 173
    .line 174
    return-void

    .line 175
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
