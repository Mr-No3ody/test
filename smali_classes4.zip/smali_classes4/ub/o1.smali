.class public final synthetic Lub/o1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/o1;->a:I

    iput-object p1, p0, Lub/o1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, Lub/o1;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;

    .line 2
    .line 3
    iget v1, p0, Lub/o1;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 9
    .line 10
    sget v1, LYa/e;->lite_result_complete_bt:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Landroid/widget/Button;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 20
    .line 21
    new-instance v1, Ltb/w;

    .line 22
    .line 23
    const/4 v2, 0x3

    .line 24
    invoke-direct {v1, v0, v2}, Ltb/w;-><init>(Ljava/lang/Object;I)V

    .line 25
    .line 26
    .line 27
    return-object v1

    .line 28
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 29
    .line 30
    sget v1, LYa/e;->lite_repayment_result_progress_view:I

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Lcom/transsnet/palmpay/core/viewmodel/ModelPaymentResultProgress;

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 40
    .line 41
    sget v1, LYa/e;->itemOrderNo:I

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/ModelPreviewItem;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 51
    .line 52
    sget v1, LYa/e;->itemPaymentMethod:I

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/ModelPreviewItem;

    .line 59
    .line 60
    return-object v0

    .line 61
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 62
    .line 63
    sget v1, LYa/e;->itemTransType:I

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Lcom/transsnet/palmpay/custom_view/model/ModelPreviewItem;

    .line 70
    .line 71
    return-object v0

    .line 72
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 73
    .line 74
    sget v1, LYa/e;->repayment_plan_title_tv:I

    .line 75
    .line 76
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Landroid/widget/TextView;

    .line 81
    .line 82
    return-object v0

    .line 83
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 84
    .line 85
    sget v1, LYa/e;->upcoming_payment_cl:I

    .line 86
    .line 87
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 92
    .line 93
    return-object v0

    .line 94
    :pswitch_7
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 95
    .line 96
    sget v1, LYa/e;->lite_result_again_bt:I

    .line 97
    .line 98
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    check-cast v0, Landroid/widget/Button;

    .line 103
    .line 104
    return-object v0

    .line 105
    :pswitch_8
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 106
    .line 107
    sget v1, LYa/e;->coming_due_date_tv:I

    .line 108
    .line 109
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    check-cast v0, Landroid/widget/TextView;

    .line 114
    .line 115
    return-object v0

    .line 116
    :pswitch_9
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 117
    .line 118
    sget v1, LYa/e;->coming_payment_amount_tv:I

    .line 119
    .line 120
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    check-cast v0, Landroid/widget/TextView;

    .line 125
    .line 126
    return-object v0

    .line 127
    :pswitch_a
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 128
    .line 129
    sget v1, LYa/e;->repayment_plan_tv:I

    .line 130
    .line 131
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    check-cast v0, Landroid/widget/TextView;

    .line 136
    .line 137
    return-object v0

    .line 138
    :pswitch_b
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 139
    .line 140
    sget v1, LYa/e;->oc_repay_result_top_sav:I

    .line 141
    .line 142
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 147
    .line 148
    return-object v0

    .line 149
    :pswitch_c
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 150
    .line 151
    sget v1, LYa/e;->oc_repay_result_middle_first_sav:I

    .line 152
    .line 153
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 158
    .line 159
    return-object v0

    .line 160
    :pswitch_d
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 161
    .line 162
    sget v1, LYa/e;->oc_repay_result_middle_second_sav:I

    .line 163
    .line 164
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 169
    .line 170
    return-object v0

    .line 171
    :pswitch_e
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 172
    .line 173
    sget v1, LYa/e;->oc_repay_result_middle_third_sav:I

    .line 174
    .line 175
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 180
    .line 181
    return-object v0

    .line 182
    :pswitch_f
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayResultActivity;->u0:I

    .line 183
    .line 184
    sget v1, LYa/e;->oc_repay_result_bottom_sav:I

    .line 185
    .line 186
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/o;->findViewById(I)Landroid/view/View;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    check-cast v0, Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 191
    .line 192
    return-object v0

    .line 193
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
