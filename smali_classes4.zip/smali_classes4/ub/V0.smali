.class public final synthetic Lub/V0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/V0;->a:I

    iput-object p1, p0, Lub/V0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 12

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    const-string p1, ""

    .line 4
    .line 5
    const-wide/16 v2, 0x2710

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    const/4 v5, 0x4

    .line 9
    const/4 v6, 0x3

    .line 10
    const v7, 0x800003

    .line 11
    .line 12
    .line 13
    const/4 v8, 0x1

    .line 14
    const/4 v9, 0x0

    .line 15
    iget-object v10, p0, Lub/V0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;

    .line 16
    .line 17
    iget v11, p0, Lub/V0;->a:I

    .line 18
    .line 19
    packed-switch v11, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 23
    .line 24
    new-instance p1, Ljava/text/DecimalFormat;

    .line 25
    .line 26
    const-string v0, "0.00%"

    .line 27
    .line 28
    invoke-direct {p1, v0}, Ljava/text/DecimalFormat;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    new-instance v0, Lkotlin/jvm/internal/F;

    .line 32
    .line 33
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 34
    .line 35
    .line 36
    new-instance v1, LO6/c;

    .line 37
    .line 38
    invoke-direct {v1, v10}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 39
    .line 40
    .line 41
    iput-boolean v9, v1, LO6/c;->k:Z

    .line 42
    .line 43
    sget v2, LYa/g;->cs_initial_dialog_title:I

    .line 44
    .line 45
    invoke-virtual {v10, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-static {v2}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    iput-object v2, v1, LO6/c;->b:Ljava/lang/CharSequence;

    .line 54
    .line 55
    iput v7, v1, LO6/c;->l:I

    .line 56
    .line 57
    sget v2, LYa/g;->cs_initial_payment_total_amount:I

    .line 58
    .line 59
    iget-object v3, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 60
    .line 61
    if-eqz v3, :cond_0

    .line 62
    .line 63
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getExtensionDownPaymentRatio()Ljava/lang/Double;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    if-eqz v3, :cond_0

    .line 68
    .line 69
    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    .line 70
    .line 71
    .line 72
    move-result-wide v3

    .line 73
    goto :goto_0

    .line 74
    :cond_0
    const-wide/16 v3, 0x0

    .line 75
    .line 76
    :goto_0
    invoke-virtual {p1, v3, v4}, Ljava/text/NumberFormat;->format(D)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    invoke-virtual {v10, v2, p1}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    iput-object p1, v1, LO6/c;->d:Ljava/lang/CharSequence;

    .line 89
    .line 90
    sget p1, Lba/k;->core_got_it:I

    .line 91
    .line 92
    invoke-virtual {v10, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    new-instance v2, LAb/l;

    .line 97
    .line 98
    const/4 v3, 0x5

    .line 99
    invoke-direct {v2, v0, v3}, LAb/l;-><init>(Lkotlin/jvm/internal/F;I)V

    .line 100
    .line 101
    .line 102
    iput-object p1, v1, LO6/c;->f:Ljava/lang/String;

    .line 103
    .line 104
    iput-object v2, v1, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 105
    .line 106
    invoke-virtual {v1}, LO6/c;->a()LO6/d;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    iput-object p1, v0, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 111
    .line 112
    invoke-virtual {p1}, LO6/d;->show()V

    .line 113
    .line 114
    .line 115
    return-void

    .line 116
    :pswitch_0
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 117
    .line 118
    new-instance p1, Lkotlin/jvm/internal/F;

    .line 119
    .line 120
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 121
    .line 122
    .line 123
    new-instance v0, LO6/c;

    .line 124
    .line 125
    invoke-direct {v0, v10}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 126
    .line 127
    .line 128
    iput-boolean v9, v0, LO6/c;->k:Z

    .line 129
    .line 130
    sget v1, LYa/g;->cs_oc_min_repayment_dialog_title:I

    .line 131
    .line 132
    invoke-virtual {v10, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    invoke-static {v1}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    iput-object v1, v0, LO6/c;->b:Ljava/lang/CharSequence;

    .line 141
    .line 142
    iput v7, v0, LO6/c;->l:I

    .line 143
    .line 144
    sget v1, LYa/g;->cs_oc_min_repayment_dialog_content:I

    .line 145
    .line 146
    invoke-virtual {v10, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    iput-object v1, v0, LO6/c;->d:Ljava/lang/CharSequence;

    .line 151
    .line 152
    sget v1, Lba/k;->core_got_it:I

    .line 153
    .line 154
    invoke-virtual {v10, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v1

    .line 158
    new-instance v2, LAb/l;

    .line 159
    .line 160
    invoke-direct {v2, p1, v5}, LAb/l;-><init>(Lkotlin/jvm/internal/F;I)V

    .line 161
    .line 162
    .line 163
    iput-object v1, v0, LO6/c;->f:Ljava/lang/String;

    .line 164
    .line 165
    iput-object v2, v0, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 166
    .line 167
    invoke-virtual {v0}, LO6/c;->a()LO6/d;

    .line 168
    .line 169
    .line 170
    move-result-object v0

    .line 171
    iput-object v0, p1, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 172
    .line 173
    invoke-virtual {v0}, LO6/d;->show()V

    .line 174
    .line 175
    .line 176
    return-void

    .line 177
    :pswitch_1
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 178
    .line 179
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    const-string v0, "/credit_score/oc_repay_extend_activity"

    .line 184
    .line 185
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    const-string v0, "oc_extend_bill_id"

    .line 190
    .line 191
    iget-wide v1, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->d1:J

    .line 192
    .line 193
    invoke-virtual {p1, v0, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 194
    .line 195
    .line 196
    move-result-object p1

    .line 197
    const-string v0, "oc_repay_operate_type"

    .line 198
    .line 199
    const-string v1, "12"

    .line 200
    .line 201
    invoke-virtual {p1, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    return-void

    .line 209
    :pswitch_2
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 210
    .line 211
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->D()Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 212
    .line 213
    .line 214
    move-result-object p1

    .line 215
    if-eqz p1, :cond_1

    .line 216
    .line 217
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getWaiverType()Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object p1

    .line 221
    goto :goto_1

    .line 222
    :cond_1
    move-object p1, v4

    .line 223
    :goto_1
    const-string v0, "FULL"

    .line 224
    .line 225
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 226
    .line 227
    .line 228
    move-result p1

    .line 229
    if-eqz p1, :cond_2

    .line 230
    .line 231
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->o()V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v10, v8}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 235
    .line 236
    .line 237
    invoke-static {v10}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 238
    .line 239
    .line 240
    move-result-object p1

    .line 241
    new-instance v0, Lub/Z0;

    .line 242
    .line 243
    invoke-direct {v0, v10, v4}, Lub/Z0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;Lkotlin/coroutines/Continuation;)V

    .line 244
    .line 245
    .line 246
    invoke-static {p1, v4, v4, v0, v6}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 247
    .line 248
    .line 249
    goto :goto_2

    .line 250
    :cond_2
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->n()V

    .line 251
    .line 252
    .line 253
    :goto_2
    return-void

    .line 254
    :pswitch_3
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 255
    .line 256
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 257
    .line 258
    .line 259
    move-result-object p1

    .line 260
    new-instance v0, Landroid/text/SpannableStringBuilder;

    .line 261
    .line 262
    invoke-static {v2, v3}, LPa/r0;->A(J)Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object v1

    .line 266
    invoke-direct {v0, v1}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 267
    .line 268
    .line 269
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 270
    .line 271
    .line 272
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u()Landroid/widget/TextView;

    .line 273
    .line 274
    .line 275
    move-result-object p1

    .line 276
    invoke-static {p1, v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->E(Landroid/widget/TextView;Z)V

    .line 277
    .line 278
    .line 279
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->z()Landroid/widget/TextView;

    .line 280
    .line 281
    .line 282
    move-result-object p1

    .line 283
    invoke-static {p1, v8}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->E(Landroid/widget/TextView;Z)V

    .line 284
    .line 285
    .line 286
    return-void

    .line 287
    :pswitch_4
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 288
    .line 289
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 290
    .line 291
    .line 292
    move-result-object p1

    .line 293
    new-instance v0, Landroid/text/SpannableStringBuilder;

    .line 294
    .line 295
    iget-wide v1, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->f1:J

    .line 296
    .line 297
    invoke-static {v1, v2}, LPa/r0;->A(J)Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v1

    .line 301
    invoke-direct {v0, v1}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 305
    .line 306
    .line 307
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u()Landroid/widget/TextView;

    .line 308
    .line 309
    .line 310
    move-result-object p1

    .line 311
    invoke-static {p1, v8}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->E(Landroid/widget/TextView;Z)V

    .line 312
    .line 313
    .line 314
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->z()Landroid/widget/TextView;

    .line 315
    .line 316
    .line 317
    move-result-object p1

    .line 318
    invoke-static {p1, v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->E(Landroid/widget/TextView;Z)V

    .line 319
    .line 320
    .line 321
    return-void

    .line 322
    :pswitch_5
    iget-object v0, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->e1:Ljava/lang/String;

    .line 323
    .line 324
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 325
    .line 326
    .line 327
    move-result v0

    .line 328
    if-eqz v0, :cond_4

    .line 329
    .line 330
    iget-wide v0, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->f1:J

    .line 331
    .line 332
    cmp-long v0, v0, v2

    .line 333
    .line 334
    if-lez v0, :cond_4

    .line 335
    .line 336
    iget-object v0, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->l1:Ljava/lang/String;

    .line 337
    .line 338
    const-string v1, "oc_repay_all"

    .line 339
    .line 340
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 341
    .line 342
    .line 343
    move-result v0

    .line 344
    if-eqz v0, :cond_3

    .line 345
    .line 346
    goto :goto_3

    .line 347
    :cond_3
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->x()Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 352
    .line 353
    .line 354
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->u()Landroid/widget/TextView;

    .line 355
    .line 356
    .line 357
    move-result-object p1

    .line 358
    invoke-static {p1, v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->E(Landroid/widget/TextView;Z)V

    .line 359
    .line 360
    .line 361
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->z()Landroid/widget/TextView;

    .line 362
    .line 363
    .line 364
    move-result-object p1

    .line 365
    invoke-static {p1, v9}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->E(Landroid/widget/TextView;Z)V

    .line 366
    .line 367
    .line 368
    :cond_4
    :goto_3
    return-void

    .line 369
    :pswitch_6
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 370
    .line 371
    invoke-virtual {v10, v8}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 372
    .line 373
    .line 374
    new-instance p1, Lcom/transsnet/palmpay/credit/bean/req/CLFamilyAndFriendPayReq;

    .line 375
    .line 376
    const-string v0, "single"

    .line 377
    .line 378
    iget-object v1, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->c1:Ljava/lang/String;

    .line 379
    .line 380
    invoke-direct {p1, v0, v1}, Lcom/transsnet/palmpay/credit/bean/req/CLFamilyAndFriendPayReq;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 381
    .line 382
    .line 383
    sget-object v0, Lob/c;->a:Lob/a;

    .line 384
    .line 385
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 386
    .line 387
    .line 388
    move-result-object v0

    .line 389
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 390
    .line 391
    .line 392
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 393
    .line 394
    .line 395
    move-result-object v0

    .line 396
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->queryOutstanding(Lcom/transsnet/palmpay/credit/bean/req/CLFamilyAndFriendPayReq;)Ldf/d;

    .line 397
    .line 398
    .line 399
    move-result-object p1

    .line 400
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 401
    .line 402
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 403
    .line 404
    .line 405
    move-result-object p1

    .line 406
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 407
    .line 408
    .line 409
    move-result-object v0

    .line 410
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 411
    .line 412
    .line 413
    move-result-object p1

    .line 414
    new-instance v0, Lub/X0;

    .line 415
    .line 416
    invoke-direct {v0, v10, v5}, Lub/X0;-><init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;I)V

    .line 417
    .line 418
    .line 419
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 420
    .line 421
    .line 422
    return-void

    .line 423
    :pswitch_7
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->v1:I

    .line 424
    .line 425
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 426
    .line 427
    .line 428
    move-result-object p1

    .line 429
    const-string v0, "/credit_score/oc_install_repay_activity"

    .line 430
    .line 431
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 432
    .line 433
    .line 434
    move-result-object p1

    .line 435
    iget-object v0, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->c1:Ljava/lang/String;

    .line 436
    .line 437
    const-string v1, "oc_repay_card_no"

    .line 438
    .line 439
    invoke-virtual {p1, v1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 440
    .line 441
    .line 442
    move-result-object p1

    .line 443
    const-string v0, "oc_repay_bill_id"

    .line 444
    .line 445
    iget-wide v1, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->d1:J

    .line 446
    .line 447
    invoke-virtual {p1, v0, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 448
    .line 449
    .line 450
    move-result-object p1

    .line 451
    invoke-virtual {p1, v10}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 452
    .line 453
    .line 454
    return-void

    .line 455
    :pswitch_8
    iget-object v2, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 456
    .line 457
    if-eqz v2, :cond_5

    .line 458
    .line 459
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getSpreadPromptType()Ljava/lang/Integer;

    .line 460
    .line 461
    .line 462
    move-result-object v4

    .line 463
    :cond_5
    if-nez v4, :cond_6

    .line 464
    .line 465
    goto :goto_5

    .line 466
    :cond_6
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 467
    .line 468
    .line 469
    move-result v2

    .line 470
    if-ne v2, v8, :cond_9

    .line 471
    .line 472
    sget p1, LYa/g;->cs_oc_bill_ins_unavailable_max_reason:I

    .line 473
    .line 474
    iget-object v2, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 475
    .line 476
    if-eqz v2, :cond_7

    .line 477
    .line 478
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getSpreadThreshold()Ljava/lang/Long;

    .line 479
    .line 480
    .line 481
    move-result-object v2

    .line 482
    if-eqz v2, :cond_7

    .line 483
    .line 484
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 485
    .line 486
    .line 487
    move-result-wide v2

    .line 488
    goto :goto_4

    .line 489
    :cond_7
    move-wide v2, v0

    .line 490
    :goto_4
    invoke-static {v2, v3, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 491
    .line 492
    .line 493
    move-result-object v2

    .line 494
    iget-object v3, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 495
    .line 496
    if-eqz v3, :cond_8

    .line 497
    .line 498
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getUnpaidPrincipal()Ljava/lang/Long;

    .line 499
    .line 500
    .line 501
    move-result-object v3

    .line 502
    if-eqz v3, :cond_8

    .line 503
    .line 504
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 505
    .line 506
    .line 507
    move-result-wide v0

    .line 508
    :cond_8
    invoke-static {v0, v1, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 509
    .line 510
    .line 511
    move-result-object v0

    .line 512
    filled-new-array {v2, v0}, [Ljava/lang/Object;

    .line 513
    .line 514
    .line 515
    move-result-object v0

    .line 516
    invoke-virtual {v10, p1, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 517
    .line 518
    .line 519
    move-result-object p1

    .line 520
    goto :goto_8

    .line 521
    :cond_9
    :goto_5
    if-nez v4, :cond_a

    .line 522
    .line 523
    goto :goto_6

    .line 524
    :cond_a
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 525
    .line 526
    .line 527
    move-result v2

    .line 528
    const/4 v3, 0x2

    .line 529
    if-ne v2, v3, :cond_b

    .line 530
    .line 531
    sget p1, LYa/g;->cs_oc_bill_ins_unavailable_unpaid_reason:I

    .line 532
    .line 533
    invoke-virtual {v10, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 534
    .line 535
    .line 536
    move-result-object p1

    .line 537
    goto :goto_8

    .line 538
    :cond_b
    :goto_6
    if-nez v4, :cond_c

    .line 539
    .line 540
    goto :goto_8

    .line 541
    :cond_c
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 542
    .line 543
    .line 544
    move-result v2

    .line 545
    if-ne v2, v6, :cond_f

    .line 546
    .line 547
    sget p1, LYa/g;->cs_oc_bill_ins_unavailable_mix_reason:I

    .line 548
    .line 549
    iget-object v2, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 550
    .line 551
    if-eqz v2, :cond_d

    .line 552
    .line 553
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getSpreadThreshold()Ljava/lang/Long;

    .line 554
    .line 555
    .line 556
    move-result-object v2

    .line 557
    if-eqz v2, :cond_d

    .line 558
    .line 559
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 560
    .line 561
    .line 562
    move-result-wide v2

    .line 563
    goto :goto_7

    .line 564
    :cond_d
    move-wide v2, v0

    .line 565
    :goto_7
    invoke-static {v2, v3, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 566
    .line 567
    .line 568
    move-result-object v2

    .line 569
    iget-object v3, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->g1:Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;

    .line 570
    .line 571
    if-eqz v3, :cond_e

    .line 572
    .line 573
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/OcCurBillData;->getUnpaidPrincipal()Ljava/lang/Long;

    .line 574
    .line 575
    .line 576
    move-result-object v3

    .line 577
    if-eqz v3, :cond_e

    .line 578
    .line 579
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 580
    .line 581
    .line 582
    move-result-wide v0

    .line 583
    :cond_e
    invoke-static {v0, v1, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 584
    .line 585
    .line 586
    move-result-object v0

    .line 587
    filled-new-array {v2, v0}, [Ljava/lang/Object;

    .line 588
    .line 589
    .line 590
    move-result-object v0

    .line 591
    invoke-virtual {v10, p1, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 592
    .line 593
    .line 594
    move-result-object p1

    .line 595
    :cond_f
    :goto_8
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 596
    .line 597
    .line 598
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 599
    .line 600
    .line 601
    move-result v0

    .line 602
    if-nez v0, :cond_10

    .line 603
    .line 604
    new-instance v0, Lkotlin/jvm/internal/F;

    .line 605
    .line 606
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 607
    .line 608
    .line 609
    new-instance v1, LO6/c;

    .line 610
    .line 611
    invoke-direct {v1, v10}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 612
    .line 613
    .line 614
    iput-boolean v9, v1, LO6/c;->k:Z

    .line 615
    .line 616
    sget v2, LYa/g;->cs_oc_bill_ins_unavailable_dialog_title:I

    .line 617
    .line 618
    invoke-virtual {v10, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 619
    .line 620
    .line 621
    move-result-object v2

    .line 622
    invoke-static {v2}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 623
    .line 624
    .line 625
    move-result-object v2

    .line 626
    iput-object v2, v1, LO6/c;->b:Ljava/lang/CharSequence;

    .line 627
    .line 628
    iput v7, v1, LO6/c;->l:I

    .line 629
    .line 630
    iput-object p1, v1, LO6/c;->d:Ljava/lang/CharSequence;

    .line 631
    .line 632
    sget p1, Lba/k;->core_got_it:I

    .line 633
    .line 634
    invoke-virtual {v10, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 635
    .line 636
    .line 637
    move-result-object p1

    .line 638
    new-instance v2, LAb/l;

    .line 639
    .line 640
    invoke-direct {v2, v0, v6}, LAb/l;-><init>(Lkotlin/jvm/internal/F;I)V

    .line 641
    .line 642
    .line 643
    iput-object p1, v1, LO6/c;->f:Ljava/lang/String;

    .line 644
    .line 645
    iput-object v2, v1, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 646
    .line 647
    invoke-virtual {v1}, LO6/c;->a()LO6/d;

    .line 648
    .line 649
    .line 650
    move-result-object p1

    .line 651
    iput-object p1, v0, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 652
    .line 653
    invoke-virtual {p1}, LO6/d;->show()V

    .line 654
    .line 655
    .line 656
    :cond_10
    return-void

    .line 657
    :pswitch_9
    iget-wide v2, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->d1:J

    .line 658
    .line 659
    cmp-long p1, v2, v0

    .line 660
    .line 661
    if-nez p1, :cond_11

    .line 662
    .line 663
    iget-object p1, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->e1:Ljava/lang/String;

    .line 664
    .line 665
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 666
    .line 667
    .line 668
    move-result p1

    .line 669
    if-eqz p1, :cond_11

    .line 670
    .line 671
    new-instance p1, Lkotlin/jvm/internal/F;

    .line 672
    .line 673
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 674
    .line 675
    .line 676
    new-instance v0, LO6/c;

    .line 677
    .line 678
    invoke-direct {v0, v10}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 679
    .line 680
    .line 681
    iput-boolean v9, v0, LO6/c;->k:Z

    .line 682
    .line 683
    sget v1, LYa/g;->cs_oc_settle_priority_title:I

    .line 684
    .line 685
    invoke-virtual {v10, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 686
    .line 687
    .line 688
    move-result-object v1

    .line 689
    invoke-static {v1}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 690
    .line 691
    .line 692
    move-result-object v1

    .line 693
    iput-object v1, v0, LO6/c;->b:Ljava/lang/CharSequence;

    .line 694
    .line 695
    sget v1, LYa/g;->cs_oc_settle_priority_content:I

    .line 696
    .line 697
    invoke-virtual {v10, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 698
    .line 699
    .line 700
    move-result-object v1

    .line 701
    iput-object v1, v0, LO6/c;->d:Ljava/lang/CharSequence;

    .line 702
    .line 703
    sget v1, Lba/k;->core_ok1:I

    .line 704
    .line 705
    invoke-virtual {v10, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 706
    .line 707
    .line 708
    move-result-object v1

    .line 709
    new-instance v2, LAb/l;

    .line 710
    .line 711
    const/4 v3, 0x6

    .line 712
    invoke-direct {v2, p1, v3}, LAb/l;-><init>(Lkotlin/jvm/internal/F;I)V

    .line 713
    .line 714
    .line 715
    iput-object v1, v0, LO6/c;->f:Ljava/lang/String;

    .line 716
    .line 717
    iput-object v2, v0, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 718
    .line 719
    invoke-virtual {v0}, LO6/c;->a()LO6/d;

    .line 720
    .line 721
    .line 722
    move-result-object v0

    .line 723
    iput-object v0, p1, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 724
    .line 725
    invoke-virtual {v0}, LO6/d;->show()V

    .line 726
    .line 727
    .line 728
    :cond_11
    return-void

    .line 729
    :pswitch_a
    iget-object p1, v10, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->p1:Lcom/transsnet/palmpay/credit/bean/resp/OcRepayExitData;

    .line 730
    .line 731
    if-eqz p1, :cond_12

    .line 732
    .line 733
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRepayExitData;->getNeedPop()Ljava/lang/Boolean;

    .line 734
    .line 735
    .line 736
    move-result-object p1

    .line 737
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 738
    .line 739
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 740
    .line 741
    .line 742
    move-result v9

    .line 743
    :cond_12
    if-eqz v9, :cond_13

    .line 744
    .line 745
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcRepayActivity;->F()V

    .line 746
    .line 747
    .line 748
    goto :goto_9

    .line 749
    :cond_13
    invoke-virtual {v10}, Landroid/app/Activity;->finish()V

    .line 750
    .line 751
    .line 752
    :goto_9
    return-void

    .line 753
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
