.class public final Lub/q0;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lub/t0;


# direct methods
.method public constructor <init>(Lub/t0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/q0;->f:Lub/t0;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/q0;->f:Lub/t0;

    .line 2
    .line 3
    iget-object v0, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lub/q0;->f:Lub/t0;

    .line 2
    .line 3
    iget-object v1, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 9
    .line 10
    .line 11
    iget-object v0, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 16
    .line 17
    iget-object v0, v0, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 18
    .line 19
    const/4 v1, 0x1

    .line 20
    iput-boolean v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->x0:Z

    .line 21
    .line 22
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/SendMTNOTPResp;

    .line 2
    .line 3
    iget-object v0, p0, Lub/q0;->f:Lub/t0;

    .line 4
    .line 5
    iget-object v1, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/bean/resp/SendMTNOTPResp;->data:Lcom/transsnet/palmpay/credit/bean/resp/SendMTNOTPResp$DataBean;

    .line 14
    .line 15
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->E0:I

    .line 16
    .line 17
    iget-object v0, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 20
    .line 21
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const/4 v2, 0x1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/SendMTNOTPResp;->isSendOK()Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_0

    .line 33
    .line 34
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->w0:Landroidx/camera/core/streamsharing/i;

    .line 35
    .line 36
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 40
    .line 41
    .line 42
    move-result-wide v0

    .line 43
    const-wide/32 v2, 0xea60

    .line 44
    .line 45
    .line 46
    add-long/2addr v0, v2

    .line 47
    iput-wide v0, p1, Landroidx/camera/core/streamsharing/i;->a:J

    .line 48
    .line 49
    iget-object v0, p1, Landroidx/camera/core/streamsharing/i;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v0, Landroid/os/Handler;

    .line 52
    .line 53
    new-instance v1, Lj9/B;

    .line 54
    .line 55
    const/16 v2, 0x14

    .line 56
    .line 57
    invoke-direct {v1, p1, v2}, Lj9/B;-><init>(Ljava/lang/Object;I)V

    .line 58
    .line 59
    .line 60
    const-wide/16 v2, 0x1f4

    .line 61
    .line 62
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 63
    .line 64
    .line 65
    sget p1, LYa/g;->cs_str_send_successfully:I

    .line 66
    .line 67
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :cond_0
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 72
    .line 73
    iget-object v0, v0, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 74
    .line 75
    iput-boolean v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->x0:Z

    .line 76
    .line 77
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/SendMTNOTPResp;->data:Lcom/transsnet/palmpay/credit/bean/resp/SendMTNOTPResp$DataBean;

    .line 78
    .line 79
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/SendMTNOTPResp$DataBean;->statusMessage:Ljava/lang/String;

    .line 80
    .line 81
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 82
    .line 83
    .line 84
    return-void

    .line 85
    :cond_1
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 86
    .line 87
    iget-object v0, v0, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 88
    .line 89
    iput-boolean v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->x0:Z

    .line 90
    .line 91
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 96
    .line 97
    .line 98
    return-void
.end method
