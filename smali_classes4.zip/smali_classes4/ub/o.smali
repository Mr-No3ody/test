.class public final synthetic Lub/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/o;->a:I

    iput-object p1, p0, Lub/o;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    const-string p1, "OcApplyResultActivity_element_click"

    .line 2
    .line 3
    const-string v0, ""

    .line 4
    .line 5
    iget-object v1, p0, Lub/o;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 6
    .line 7
    iget v2, p0, Lub/o;->a:I

    .line 8
    .line 9
    packed-switch v2, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->D0:Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;

    .line 13
    .line 14
    if-eqz v2, :cond_1

    .line 15
    .line 16
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;->getApplySource()Ljava/lang/Integer;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    if-nez v2, :cond_0

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    const/4 v3, 0x2

    .line 28
    if-ne v2, v3, :cond_1

    .line 29
    .line 30
    const-string v2, "/airtime/top_up_airtime"

    .line 31
    .line 32
    invoke-static {v2}, LN8/q0;->u(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    :cond_1
    :goto_0
    invoke-virtual {v1}, Landroid/app/Activity;->finish()V

    .line 36
    .line 37
    .line 38
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    const-string v2, "use_coupon_bt"

    .line 43
    .line 44
    invoke-virtual {v1, p1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    return-void

    .line 48
    :pswitch_0
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 49
    .line 50
    const-string p1, "/main/home"

    .line 51
    .line 52
    const-string v2, "tab"

    .line 53
    .line 54
    const-string v3, "finance"

    .line 55
    .line 56
    invoke-static {p1, v2, v3}, Lcom/palmpay/lib/apm/launchcounter/util/d;->H(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    const-string v2, "_element_click"

    .line 72
    .line 73
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    const-string v2, "apply_back_bt"

    .line 78
    .line 79
    invoke-virtual {p1, v1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :pswitch_1
    sget v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 84
    .line 85
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->x()V

    .line 86
    .line 87
    .line 88
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    const-string v2, "mtb_back_iv"

    .line 93
    .line 94
    invoke-virtual {v1, p1, v2, v0}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
