.class public final synthetic Lub/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/p;->a:I

    iput-object p1, p0, Lub/p;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-wide/16 v1, 0x3e8

    .line 4
    .line 5
    const/4 v3, -0x1

    .line 6
    const-string v4, "getValue(...)"

    .line 7
    .line 8
    iget-object v5, v0, Lub/p;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 9
    .line 10
    iget v6, v0, Lub/p;->a:I

    .line 11
    .line 12
    packed-switch v6, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->r()V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_0
    iget-object v6, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->L:Lxf/t;

    .line 20
    .line 21
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    invoke-static {v6, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    check-cast v6, Landroid/widget/TextView;

    .line 29
    .line 30
    iget v4, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->F0:I

    .line 31
    .line 32
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    invoke-virtual {v6, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 37
    .line 38
    .line 39
    iget v4, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->F0:I

    .line 40
    .line 41
    add-int/2addr v4, v3

    .line 42
    iput v4, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->F0:I

    .line 43
    .line 44
    if-gtz v4, :cond_0

    .line 45
    .line 46
    invoke-virtual {v5}, Landroid/app/Activity;->finish()V

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_0
    iget-object v3, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->J0:Landroid/os/Handler;

    .line 51
    .line 52
    iget-object v4, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->K0:Lxf/t;

    .line 53
    .line 54
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    check-cast v4, Ljava/lang/Runnable;

    .line 59
    .line 60
    invoke-virtual {v3, v4, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 61
    .line 62
    .line 63
    :goto_0
    return-void

    .line 64
    :pswitch_1
    sget v6, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 65
    .line 66
    iget-object v6, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->A:Lxf/t;

    .line 67
    .line 68
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    check-cast v7, Landroid/widget/TextView;

    .line 76
    .line 77
    iget v8, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->L0:I

    .line 78
    .line 79
    invoke-static {v8}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v8

    .line 83
    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 84
    .line 85
    .line 86
    iget v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->L0:I

    .line 87
    .line 88
    if-eqz v7, :cond_1

    .line 89
    .line 90
    const/4 v8, 0x1

    .line 91
    if-eq v7, v8, :cond_1

    .line 92
    .line 93
    const/4 v8, 0x4

    .line 94
    const/4 v9, 0x0

    .line 95
    packed-switch v7, :pswitch_data_1

    .line 96
    .line 97
    .line 98
    goto/16 :goto_1

    .line 99
    .line 100
    :pswitch_2
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->u()Landroid/widget/ImageView;

    .line 101
    .line 102
    .line 103
    move-result-object v7

    .line 104
    invoke-virtual {v7, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 105
    .line 106
    .line 107
    new-instance v10, Landroid/view/animation/RotateAnimation;

    .line 108
    .line 109
    const/4 v15, 0x1

    .line 110
    const/high16 v16, 0x3f000000    # 0.5f

    .line 111
    .line 112
    const/4 v11, 0x0

    .line 113
    const/high16 v12, 0x43b40000    # 360.0f

    .line 114
    .line 115
    const/4 v13, 0x1

    .line 116
    const/high16 v14, 0x3f000000    # 0.5f

    .line 117
    .line 118
    invoke-direct/range {v10 .. v16}, Landroid/view/animation/RotateAnimation;-><init>(FFIFIF)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v10, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v10, v3}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    .line 125
    .line 126
    .line 127
    new-instance v7, Landroid/view/animation/LinearInterpolator;

    .line 128
    .line 129
    invoke-direct {v7}, Landroid/view/animation/LinearInterpolator;-><init>()V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v10, v7}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->u()Landroid/widget/ImageView;

    .line 136
    .line 137
    .line 138
    move-result-object v7

    .line 139
    invoke-virtual {v7, v10}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 140
    .line 141
    .line 142
    goto/16 :goto_1

    .line 143
    .line 144
    :pswitch_3
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->u()Landroid/widget/ImageView;

    .line 145
    .line 146
    .line 147
    move-result-object v7

    .line 148
    invoke-virtual {v7}, Landroid/view/View;->clearAnimation()V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->u()Landroid/widget/ImageView;

    .line 152
    .line 153
    .line 154
    move-result-object v7

    .line 155
    invoke-virtual {v7, v8}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 156
    .line 157
    .line 158
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->t:Lxf/t;

    .line 159
    .line 160
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v7

    .line 164
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    check-cast v7, Landroid/widget/ImageView;

    .line 168
    .line 169
    invoke-virtual {v7, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->v()Landroid/widget/ImageView;

    .line 173
    .line 174
    .line 175
    move-result-object v7

    .line 176
    invoke-virtual {v7, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 177
    .line 178
    .line 179
    new-instance v10, Landroid/view/animation/RotateAnimation;

    .line 180
    .line 181
    const/4 v15, 0x1

    .line 182
    const/high16 v16, 0x3f000000    # 0.5f

    .line 183
    .line 184
    const/4 v11, 0x0

    .line 185
    const/high16 v12, 0x43b40000    # 360.0f

    .line 186
    .line 187
    const/4 v13, 0x1

    .line 188
    const/high16 v14, 0x3f000000    # 0.5f

    .line 189
    .line 190
    invoke-direct/range {v10 .. v16}, Landroid/view/animation/RotateAnimation;-><init>(FFIFIF)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v10, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v10, v3}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    .line 197
    .line 198
    .line 199
    new-instance v7, Landroid/view/animation/LinearInterpolator;

    .line 200
    .line 201
    invoke-direct {v7}, Landroid/view/animation/LinearInterpolator;-><init>()V

    .line 202
    .line 203
    .line 204
    invoke-virtual {v10, v7}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 205
    .line 206
    .line 207
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->v()Landroid/widget/ImageView;

    .line 208
    .line 209
    .line 210
    move-result-object v7

    .line 211
    invoke-virtual {v7, v10}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 212
    .line 213
    .line 214
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->j:Lxf/t;

    .line 215
    .line 216
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object v7

    .line 220
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 221
    .line 222
    .line 223
    check-cast v7, Landroid/widget/TextView;

    .line 224
    .line 225
    sget v8, LL6/b;->ppColorTextPrimary:I

    .line 226
    .line 227
    invoke-virtual {v5, v8}, Landroid/content/Context;->getColor(I)I

    .line 228
    .line 229
    .line 230
    move-result v8

    .line 231
    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 232
    .line 233
    .line 234
    goto/16 :goto_1

    .line 235
    .line 236
    :pswitch_4
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->v()Landroid/widget/ImageView;

    .line 237
    .line 238
    .line 239
    move-result-object v7

    .line 240
    invoke-virtual {v7}, Landroid/view/View;->clearAnimation()V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->v()Landroid/widget/ImageView;

    .line 244
    .line 245
    .line 246
    move-result-object v7

    .line 247
    invoke-virtual {v7, v8}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 248
    .line 249
    .line 250
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->o:Lxf/t;

    .line 251
    .line 252
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v7

    .line 256
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    check-cast v7, Landroid/widget/ImageView;

    .line 260
    .line 261
    invoke-virtual {v7, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 262
    .line 263
    .line 264
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->w()Landroid/widget/ImageView;

    .line 265
    .line 266
    .line 267
    move-result-object v7

    .line 268
    invoke-virtual {v7, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 269
    .line 270
    .line 271
    new-instance v10, Landroid/view/animation/RotateAnimation;

    .line 272
    .line 273
    const/4 v15, 0x1

    .line 274
    const/high16 v16, 0x3f000000    # 0.5f

    .line 275
    .line 276
    const/4 v11, 0x0

    .line 277
    const/high16 v12, 0x43b40000    # 360.0f

    .line 278
    .line 279
    const/4 v13, 0x1

    .line 280
    const/high16 v14, 0x3f000000    # 0.5f

    .line 281
    .line 282
    invoke-direct/range {v10 .. v16}, Landroid/view/animation/RotateAnimation;-><init>(FFIFIF)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v10, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 286
    .line 287
    .line 288
    invoke-virtual {v10, v3}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    .line 289
    .line 290
    .line 291
    new-instance v7, Landroid/view/animation/LinearInterpolator;

    .line 292
    .line 293
    invoke-direct {v7}, Landroid/view/animation/LinearInterpolator;-><init>()V

    .line 294
    .line 295
    .line 296
    invoke-virtual {v10, v7}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 297
    .line 298
    .line 299
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->w()Landroid/widget/ImageView;

    .line 300
    .line 301
    .line 302
    move-result-object v7

    .line 303
    invoke-virtual {v7, v10}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 304
    .line 305
    .line 306
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->f:Lxf/t;

    .line 307
    .line 308
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 309
    .line 310
    .line 311
    move-result-object v7

    .line 312
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 313
    .line 314
    .line 315
    check-cast v7, Landroid/widget/TextView;

    .line 316
    .line 317
    sget v8, LL6/b;->ppColorTextPrimary:I

    .line 318
    .line 319
    invoke-virtual {v5, v8}, Landroid/content/Context;->getColor(I)I

    .line 320
    .line 321
    .line 322
    move-result v8

    .line 323
    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 324
    .line 325
    .line 326
    goto/16 :goto_1

    .line 327
    .line 328
    :pswitch_5
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->w()Landroid/widget/ImageView;

    .line 329
    .line 330
    .line 331
    move-result-object v7

    .line 332
    invoke-virtual {v7}, Landroid/view/View;->clearAnimation()V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->w()Landroid/widget/ImageView;

    .line 336
    .line 337
    .line 338
    move-result-object v7

    .line 339
    invoke-virtual {v7, v8}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 340
    .line 341
    .line 342
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->g:Lxf/t;

    .line 343
    .line 344
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    move-result-object v7

    .line 348
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 349
    .line 350
    .line 351
    check-cast v7, Landroid/widget/ImageView;

    .line 352
    .line 353
    invoke-virtual {v7, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 354
    .line 355
    .line 356
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->e:Lxf/t;

    .line 357
    .line 358
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 359
    .line 360
    .line 361
    move-result-object v8

    .line 362
    invoke-static {v8, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 363
    .line 364
    .line 365
    check-cast v8, Landroid/widget/ImageView;

    .line 366
    .line 367
    invoke-virtual {v8, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 368
    .line 369
    .line 370
    new-instance v10, Landroid/view/animation/RotateAnimation;

    .line 371
    .line 372
    const/4 v15, 0x1

    .line 373
    const/high16 v16, 0x3f000000    # 0.5f

    .line 374
    .line 375
    const/4 v11, 0x0

    .line 376
    const/high16 v12, 0x43b40000    # 360.0f

    .line 377
    .line 378
    const/4 v13, 0x1

    .line 379
    const/high16 v14, 0x3f000000    # 0.5f

    .line 380
    .line 381
    invoke-direct/range {v10 .. v16}, Landroid/view/animation/RotateAnimation;-><init>(FFIFIF)V

    .line 382
    .line 383
    .line 384
    invoke-virtual {v10, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 385
    .line 386
    .line 387
    invoke-virtual {v10, v3}, Landroid/view/animation/Animation;->setRepeatCount(I)V

    .line 388
    .line 389
    .line 390
    new-instance v8, Landroid/view/animation/LinearInterpolator;

    .line 391
    .line 392
    invoke-direct {v8}, Landroid/view/animation/LinearInterpolator;-><init>()V

    .line 393
    .line 394
    .line 395
    invoke-virtual {v10, v8}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 396
    .line 397
    .line 398
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 399
    .line 400
    .line 401
    move-result-object v7

    .line 402
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 403
    .line 404
    .line 405
    check-cast v7, Landroid/widget/ImageView;

    .line 406
    .line 407
    invoke-virtual {v7, v10}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 408
    .line 409
    .line 410
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->d:Lxf/t;

    .line 411
    .line 412
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    move-result-object v7

    .line 416
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 417
    .line 418
    .line 419
    check-cast v7, Landroid/widget/TextView;

    .line 420
    .line 421
    sget v8, LL6/b;->ppColorTextPrimary:I

    .line 422
    .line 423
    invoke-virtual {v5, v8}, Landroid/content/Context;->getColor(I)I

    .line 424
    .line 425
    .line 426
    move-result v8

    .line 427
    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 428
    .line 429
    .line 430
    goto :goto_1

    .line 431
    :cond_1
    iget-object v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->w:Lxf/t;

    .line 432
    .line 433
    invoke-virtual {v7}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 434
    .line 435
    .line 436
    move-result-object v7

    .line 437
    invoke-static {v7, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 438
    .line 439
    .line 440
    check-cast v7, Landroid/widget/TextView;

    .line 441
    .line 442
    sget v8, LYa/g;->cs_oc_unstable_network:I

    .line 443
    .line 444
    invoke-virtual {v5, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 445
    .line 446
    .line 447
    move-result-object v8

    .line 448
    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 449
    .line 450
    .line 451
    :goto_1
    iget v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->L0:I

    .line 452
    .line 453
    add-int/2addr v7, v3

    .line 454
    iput v7, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->L0:I

    .line 455
    .line 456
    if-gez v7, :cond_2

    .line 457
    .line 458
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 459
    .line 460
    .line 461
    move-result-object v1

    .line 462
    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 463
    .line 464
    .line 465
    check-cast v1, Landroid/widget/TextView;

    .line 466
    .line 467
    const/4 v2, 0x0

    .line 468
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 469
    .line 470
    .line 471
    goto :goto_2

    .line 472
    :cond_2
    iget-object v3, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->M0:Landroid/os/Handler;

    .line 473
    .line 474
    iget-object v4, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->N0:Lxf/t;

    .line 475
    .line 476
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v4

    .line 480
    check-cast v4, Ljava/lang/Runnable;

    .line 481
    .line 482
    invoke-virtual {v3, v4, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 483
    .line 484
    .line 485
    :goto_2
    return-void

    .line 486
    :pswitch_6
    iget-object v1, v5, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->D0:Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;

    .line 487
    .line 488
    if-eqz v1, :cond_3

    .line 489
    .line 490
    const-string v2, ""

    .line 491
    .line 492
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;->setApplyId(Ljava/lang/String;)V

    .line 493
    .line 494
    .line 495
    :cond_3
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->r()V

    .line 496
    .line 497
    .line 498
    return-void

    .line 499
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    :pswitch_data_1
    .packed-switch 0x7
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
    .end packed-switch
.end method
