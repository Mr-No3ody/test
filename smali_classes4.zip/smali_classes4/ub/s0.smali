.class public final Lub/s0;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lub/t0;


# direct methods
.method public constructor <init>(Lub/t0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/s0;->f:Lub/t0;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lub/s0;->f:Lub/t0;

    .line 2
    .line 3
    iget-object v0, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lub/s0;->f:Lub/t0;

    .line 2
    .line 3
    iget-object v0, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 6
    .line 7
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->t0:Lcom/palmpay/lib/ui/button/PpButton;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-virtual {v0, v1}, Lcom/palmpay/lib/ui/button/PpButton;->b(Z)V

    .line 11
    .line 12
    .line 13
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;

    .line 2
    .line 3
    iget-object v0, p0, Lub/s0;->f:Lub/t0;

    .line 4
    .line 5
    iget-object v1, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 8
    .line 9
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->t0:Lcom/palmpay/lib/ui/button/PpButton;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-virtual {v1, v2}, Lcom/palmpay/lib/ui/button/PpButton;->b(Z)V

    .line 13
    .line 14
    .line 15
    iget-object v0, v0, Lub/t0;->a:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 18
    .line 19
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->C:Ljava/lang/String;

    .line 20
    .line 21
    const-string v3, "oc_use_type_router"

    .line 22
    .line 23
    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_4

    .line 28
    .line 29
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_0

    .line 34
    .line 35
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->r()V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_0
    const-string v1, "40080005"

    .line 40
    .line 41
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-nez v1, :cond_2

    .line 50
    .line 51
    const-string v1, "408"

    .line 52
    .line 53
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_1

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_1
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;->data:Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;

    .line 65
    .line 66
    iput-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->z0:Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;

    .line 67
    .line 68
    new-instance p1, LO6/c;

    .line 69
    .line 70
    invoke-direct {p1, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 71
    .line 72
    .line 73
    sget v1, LYa/g;->cs_oc_skip_one_loop_dialog_title:I

    .line 74
    .line 75
    invoke-virtual {p1, v1}, LO6/c;->e(I)V

    .line 76
    .line 77
    .line 78
    sget v1, LYa/g;->cs_oc_skip_one_loop_dialog_content:I

    .line 79
    .line 80
    invoke-virtual {p1, v1}, LO6/c;->b(I)V

    .line 81
    .line 82
    .line 83
    iput-boolean v2, p1, LO6/c;->k:Z

    .line 84
    .line 85
    new-instance v1, Lub/r0;

    .line 86
    .line 87
    const/4 v2, 0x0

    .line 88
    invoke-direct {v1, p0, v2}, Lub/r0;-><init>(Lub/s0;I)V

    .line 89
    .line 90
    .line 91
    iput-object v1, p1, LO6/c;->j:Landroid/view/View$OnClickListener;

    .line 92
    .line 93
    sget v1, LYa/g;->cs_oc_skip_this_step:I

    .line 94
    .line 95
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    new-instance v2, Lub/r0;

    .line 100
    .line 101
    const/4 v3, 0x1

    .line 102
    invoke-direct {v2, p0, v3}, Lub/r0;-><init>(Lub/s0;I)V

    .line 103
    .line 104
    .line 105
    iput-object v1, p1, LO6/c;->f:Ljava/lang/String;

    .line 106
    .line 107
    iput-object v2, p1, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 108
    .line 109
    invoke-virtual {p1}, LO6/c;->a()LO6/d;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-virtual {p1}, LO6/d;->show()V

    .line 114
    .line 115
    .line 116
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->t0:Lcom/palmpay/lib/ui/button/PpButton;

    .line 117
    .line 118
    sget v1, LYa/g;->cs_oc_skip_this_step:I

    .line 119
    .line 120
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    invoke-virtual {p1, v1}, Lcom/palmpay/lib/ui/button/PpButton;->setText(Ljava/lang/CharSequence;)V

    .line 125
    .line 126
    .line 127
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->q0:Landroid/widget/TextView;

    .line 128
    .line 129
    const/16 v1, 0x8

    .line 130
    .line 131
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 132
    .line 133
    .line 134
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 135
    .line 136
    iget-object p1, p1, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 137
    .line 138
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->r0:Landroid/view/View;

    .line 139
    .line 140
    sget v2, LL6/b;->ppColorTextPrimary:I

    .line 141
    .line 142
    invoke-virtual {p1, v2}, Landroid/content/Context;->getColor(I)I

    .line 143
    .line 144
    .line 145
    move-result v2

    .line 146
    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 147
    .line 148
    .line 149
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->s0:Landroid/widget/TextView;

    .line 150
    .line 151
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 152
    .line 153
    .line 154
    return-void

    .line 155
    :cond_2
    :goto_0
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;->data:Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;

    .line 156
    .line 157
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;->statusMessage:Ljava/lang/String;

    .line 158
    .line 159
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 160
    .line 161
    .line 162
    move-result v1

    .line 163
    if-nez v1, :cond_3

    .line 164
    .line 165
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 166
    .line 167
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;->data:Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;

    .line 168
    .line 169
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;->statusMessage:Ljava/lang/String;

    .line 170
    .line 171
    invoke-static {v0, p1}, Lub/v0;->a(Lub/v0;Ljava/lang/String;)V

    .line 172
    .line 173
    .line 174
    return-void

    .line 175
    :cond_3
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 176
    .line 177
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    invoke-static {v0, p1}, Lub/v0;->a(Lub/v0;Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    return-void

    .line 185
    :cond_4
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 186
    .line 187
    .line 188
    move-result v1

    .line 189
    if-eqz v1, :cond_5

    .line 190
    .line 191
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 192
    .line 193
    .line 194
    return-void

    .line 195
    :cond_5
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;->data:Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;

    .line 196
    .line 197
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;->statusMessage:Ljava/lang/String;

    .line 198
    .line 199
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 200
    .line 201
    .line 202
    move-result v1

    .line 203
    if-nez v1, :cond_6

    .line 204
    .line 205
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 206
    .line 207
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp;->data:Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;

    .line 208
    .line 209
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/resp/MTNLoginResp$DataBean;->statusMessage:Ljava/lang/String;

    .line 210
    .line 211
    invoke-static {v0, p1}, Lub/v0;->a(Lub/v0;Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    return-void

    .line 215
    :cond_6
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 216
    .line 217
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object p1

    .line 221
    invoke-static {v0, p1}, Lub/v0;->a(Lub/v0;Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    return-void
.end method
