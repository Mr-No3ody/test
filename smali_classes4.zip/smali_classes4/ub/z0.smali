.class public final Lub/z0;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/z0;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/z0;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    const-string v0, "message"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/z0;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 10
    .line 11
    .line 12
    new-array v0, v1, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 5

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/SmsActionRsp;

    .line 2
    .line 3
    iget-object v0, p0, Lub/z0;->f:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 7
    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz p1, :cond_1

    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    const/4 v4, 0x1

    .line 17
    if-ne v3, v4, :cond_1

    .line 18
    .line 19
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/SmsActionRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/SmsActionRsp$DataBean;

    .line 20
    .line 21
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/SmsActionRsp$DataBean;->getSmsToken()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iput-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->t0:Ljava/lang/String;

    .line 26
    .line 27
    sget-object p1, Lob/c;->a:Lob/a;

    .line 28
    .line 29
    invoke-static {p1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/OcSaveSmsTokenReq;

    .line 34
    .line 35
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 36
    .line 37
    if-eqz v3, :cond_0

    .line 38
    .line 39
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getApplyId()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    :cond_0
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->t0:Ljava/lang/String;

    .line 44
    .line 45
    invoke-direct {v1, v2, v3}, Lcom/transsnet/palmpay/credit/bean/req/OcSaveSmsTokenReq;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-interface {p1, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->ocSaveSmsCode(Lcom/transsnet/palmpay/credit/bean/req/OcSaveSmsTokenReq;)Ldf/d;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 53
    .line 54
    invoke-virtual {p1, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-virtual {p1, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    new-instance v1, Ltb/q;

    .line 67
    .line 68
    const/16 v2, 0x16

    .line 69
    .line 70
    invoke-direct {v1, v0, v2}, Ltb/q;-><init>(Ljava/lang/Object;I)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p1, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :cond_1
    if-eqz p1, :cond_2

    .line 78
    .line 79
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    :cond_2
    new-array p1, v1, [Ljava/lang/Object;

    .line 84
    .line 85
    invoke-static {v2, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->v0:I

    .line 89
    .line 90
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOtpVerifyActivity;->z()Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV2View;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    if-eqz p1, :cond_3

    .line 95
    .line 96
    iget-object p1, p1, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV2View;->b:Lcom/transsnet/palmpay/custom_view/PinEntryView;

    .line 97
    .line 98
    if-eqz p1, :cond_3

    .line 99
    .line 100
    const-string v0, ""

    .line 101
    .line 102
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/custom_view/PinEntryView;->setText(Ljava/lang/CharSequence;)V

    .line 103
    .line 104
    .line 105
    :cond_3
    return-void
.end method
