.class public final synthetic Lub/j0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lub/k0;


# direct methods
.method public synthetic constructor <init>(Lub/k0;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/j0;->a:I

    iput-object p1, p0, Lub/j0;->b:Lub/k0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    iget p1, p0, Lub/j0;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lub/j0;->b:Lub/k0;

    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-static {}, LPa/r0;->U0()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    iget-object p1, p1, Lub/k0;->b:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 21
    .line 22
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->r()V

    .line 23
    .line 24
    .line 25
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    const-class v0, Lub/k0;

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    const-string v1, "_element_click"

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    const-string v1, "router_right_tv"

    .line 42
    .line 43
    const-string v2, ""

    .line 44
    .line 45
    invoke-virtual {p1, v0, v1, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    :goto_0
    return-void

    .line 49
    :pswitch_0
    iget-object p1, p0, Lub/j0;->b:Lub/k0;

    .line 50
    .line 51
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    invoke-static {}, LPa/r0;->U0()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_1

    .line 59
    .line 60
    goto :goto_1

    .line 61
    :cond_1
    iget-object p1, p1, Lub/k0;->b:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 64
    .line 65
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v()V

    .line 66
    .line 67
    .line 68
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    const-class v0, Lub/k0;

    .line 73
    .line 74
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    const-string v1, "_element_click"

    .line 79
    .line 80
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    const-string v1, "router_close_img"

    .line 85
    .line 86
    const-string v2, ""

    .line 87
    .line 88
    invoke-virtual {p1, v0, v1, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    :goto_1
    return-void

    .line 92
    :pswitch_1
    iget-object p1, p0, Lub/j0;->b:Lub/k0;

    .line 93
    .line 94
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 95
    .line 96
    .line 97
    invoke-static {}, LPa/r0;->U0()Z

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    if-eqz v0, :cond_2

    .line 102
    .line 103
    goto :goto_2

    .line 104
    :cond_2
    iget-object p1, p1, Lub/k0;->b:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 107
    .line 108
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->onBackPressed()V

    .line 109
    .line 110
    .line 111
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    const-class v0, Lub/k0;

    .line 116
    .line 117
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    const-string v1, "_element_click"

    .line 122
    .line 123
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    const-string v1, "router_back_img"

    .line 128
    .line 129
    const-string v2, ""

    .line 130
    .line 131
    invoke-virtual {p1, v0, v1, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    :goto_2
    return-void

    .line 135
    :pswitch_2
    iget-object p1, p0, Lub/j0;->b:Lub/k0;

    .line 136
    .line 137
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 138
    .line 139
    .line 140
    invoke-static {}, LPa/r0;->U0()Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    if-eqz v0, :cond_3

    .line 145
    .line 146
    goto :goto_3

    .line 147
    :cond_3
    iget-object p1, p1, Lub/k0;->b:Ljava/lang/Object;

    .line 148
    .line 149
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 150
    .line 151
    iget-boolean v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->y0:Z

    .line 152
    .line 153
    if-eqz v0, :cond_4

    .line 154
    .line 155
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->w0:Lm6/j;

    .line 156
    .line 157
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->z0:Ljava/lang/String;

    .line 158
    .line 159
    invoke-static {v0, v1}, Lm6/j;->a(Lm6/j;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    :cond_4
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    const-class v1, Lub/k0;

    .line 167
    .line 168
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v1

    .line 172
    const-string v2, "_element_click"

    .line 173
    .line 174
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object v1

    .line 178
    iget-boolean p1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->y0:Z

    .line 179
    .line 180
    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    const-string v2, "cs_resend_code"

    .line 185
    .line 186
    invoke-virtual {v0, v1, v2, p1}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    :goto_3
    return-void

    .line 190
    :pswitch_3
    iget-object p1, p0, Lub/j0;->b:Lub/k0;

    .line 191
    .line 192
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 193
    .line 194
    .line 195
    invoke-static {}, LPa/r0;->U0()Z

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    if-eqz v0, :cond_5

    .line 200
    .line 201
    goto :goto_4

    .line 202
    :cond_5
    iget-object p1, p1, Lub/k0;->b:Ljava/lang/Object;

    .line 203
    .line 204
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 205
    .line 206
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->w0:Lm6/j;

    .line 207
    .line 208
    iget-object v0, p1, Lm6/j;->b:Ljava/lang/Object;

    .line 209
    .line 210
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 211
    .line 212
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->v0:Lub/k0;

    .line 213
    .line 214
    iget-object v1, v1, Lub/k0;->b:Ljava/lang/Object;

    .line 215
    .line 216
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;

    .line 217
    .line 218
    iget-object v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->s0:Landroid/view/View;

    .line 219
    .line 220
    sget v3, LYa/b;->cs_main_color:I

    .line 221
    .line 222
    invoke-virtual {v1, v3}, Landroid/content/Context;->getColor(I)I

    .line 223
    .line 224
    .line 225
    move-result v3

    .line 226
    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 227
    .line 228
    .line 229
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->t0:Landroid/widget/TextView;

    .line 230
    .line 231
    const/16 v2, 0x8

    .line 232
    .line 233
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 234
    .line 235
    .line 236
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/MTNLoginReq;

    .line 237
    .line 238
    invoke-direct {v1}, Lcom/transsnet/palmpay/credit/bean/req/MTNLoginReq;-><init>()V

    .line 239
    .line 240
    .line 241
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->q0:Landroidx/appcompat/widget/AppCompatEditText;

    .line 242
    .line 243
    invoke-virtual {v2}, Landroidx/appcompat/widget/AppCompatEditText;->getText()Landroid/text/Editable;

    .line 244
    .line 245
    .line 246
    move-result-object v2

    .line 247
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 248
    .line 249
    .line 250
    move-result-object v2

    .line 251
    iput-object v2, v1, Lcom/transsnet/palmpay/credit/bean/req/MTNLoginReq;->password:Ljava/lang/String;

    .line 252
    .line 253
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcMTNLoginActivity;->z0:Ljava/lang/String;

    .line 254
    .line 255
    iput-object v2, v1, Lcom/transsnet/palmpay/credit/bean/req/MTNLoginReq;->applyId:Ljava/lang/String;

    .line 256
    .line 257
    const/4 v2, 0x1

    .line 258
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 259
    .line 260
    .line 261
    sget-object v0, Lob/c;->a:Lob/a;

    .line 262
    .line 263
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 268
    .line 269
    .line 270
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->mtnLogin(Lcom/transsnet/palmpay/credit/bean/req/MTNLoginReq;)Ldf/d;

    .line 275
    .line 276
    .line 277
    move-result-object v0

    .line 278
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 279
    .line 280
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 285
    .line 286
    .line 287
    move-result-object v1

    .line 288
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    new-instance v1, Lub/i0;

    .line 293
    .line 294
    invoke-direct {v1, p1}, Lub/i0;-><init>(Lm6/j;)V

    .line 295
    .line 296
    .line 297
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 298
    .line 299
    .line 300
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 301
    .line 302
    .line 303
    move-result-object p1

    .line 304
    const-class v0, Lub/k0;

    .line 305
    .line 306
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    const-string v1, "_element_click"

    .line 311
    .line 312
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v0

    .line 316
    const-string v1, "cs_login"

    .line 317
    .line 318
    const-string v2, ""

    .line 319
    .line 320
    invoke-virtual {p1, v0, v1, v2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 321
    .line 322
    .line 323
    :goto_4
    return-void

    .line 324
    nop

    .line 325
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
