.class public final synthetic Lub/E0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/E0;->a:I

    iput-object p1, p0, Lub/E0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lub/E0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;

    .line 3
    .line 4
    iget v2, p0, Lub/E0;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget-object v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->H:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity$a;

    .line 10
    .line 11
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->p()V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v1, v0, v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->r(ZZ)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    sget-object v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity;->H:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcProtocolActivity$a;

    .line 19
    .line 20
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 21
    .line 22
    .line 23
    sget v2, LYa/g;->cs_oc_install_plugin_failed:I

    .line 24
    .line 25
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    new-array v0, v0, [Ljava/lang/Object;

    .line 30
    .line 31
    invoke-static {v1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
