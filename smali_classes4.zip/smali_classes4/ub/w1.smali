.class public final Lub/w1;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/w1;->f:I

    iput-object p1, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Lub/w1;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    .line 12
    .line 13
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_0
    const-string v0, "d"

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :pswitch_1
    const-string v0, "d"

    .line 29
    .line 30
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    .line 34
    .line 35
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->addSubscription(Lio/reactivex/disposables/Disposable;)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget v0, p0, Lub/w1;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "message"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    const-string v0, "message"

    .line 19
    .line 20
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    const/4 v0, 0x0

    .line 24
    new-array v0, v0, [Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_1
    const-string v0, "message"

    .line 31
    .line 32
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    .line 36
    .line 37
    const/4 v1, 0x0

    .line 38
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 39
    .line 40
    .line 41
    new-array v0, v1, [Ljava/lang/Object;

    .line 42
    .line 43
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 10

    .line 1
    iget v0, p0, Lub/w1;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseResp;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    if-eqz p1, :cond_6

    .line 10
    .line 11
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    const/4 v2, 0x1

    .line 16
    if-ne v1, v2, :cond_6

    .line 17
    .line 18
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseResp;->getData()Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Ljava/util/Collection;

    .line 23
    .line 24
    if-eqz v1, :cond_8

    .line 25
    .line 26
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_0

    .line 31
    .line 32
    goto/16 :goto_4

    .line 33
    .line 34
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseResp;->getData()Ljava/util/List;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseData;

    .line 46
    .line 47
    iget-object v1, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    .line 48
    .line 49
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->f:Lxf/t;

    .line 50
    .line 51
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    const-string v4, "getValue(...)"

    .line 56
    .line 57
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    check-cast v3, Landroid/widget/TextView;

    .line 61
    .line 62
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseData;->getDesc()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v5

    .line 66
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 67
    .line 68
    .line 69
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->e:Lxf/t;

    .line 70
    .line 71
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    check-cast v3, Landroid/widget/TextView;

    .line 79
    .line 80
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseData;->getCreateTime()Ljava/lang/Long;

    .line 81
    .line 82
    .line 83
    move-result-object v5

    .line 84
    const-wide/16 v6, 0x0

    .line 85
    .line 86
    if-eqz v5, :cond_1

    .line 87
    .line 88
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 89
    .line 90
    .line 91
    move-result-wide v8

    .line 92
    goto :goto_0

    .line 93
    :cond_1
    move-wide v8, v6

    .line 94
    :goto_0
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 95
    .line 96
    .line 97
    move-result-object v5

    .line 98
    const-string v8, "HH:mm, MMM dd, yyyy"

    .line 99
    .line 100
    invoke-static {v5, v8}, LPa/r0;->X1(Ljava/lang/Long;Ljava/lang/String;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 105
    .line 106
    .line 107
    iget-object v3, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->d:Lxf/t;

    .line 108
    .line 109
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v3

    .line 113
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    check-cast v3, Landroid/widget/TextView;

    .line 117
    .line 118
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseData;->getChangeQuota()Ljava/lang/Long;

    .line 119
    .line 120
    .line 121
    move-result-object v5

    .line 122
    if-eqz v5, :cond_2

    .line 123
    .line 124
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 125
    .line 126
    .line 127
    move-result-wide v8

    .line 128
    goto :goto_1

    .line 129
    :cond_2
    move-wide v8, v6

    .line 130
    :goto_1
    cmp-long v5, v8, v6

    .line 131
    .line 132
    if-lez v5, :cond_4

    .line 133
    .line 134
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseData;->getChangeQuota()Ljava/lang/Long;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    if-eqz p1, :cond_3

    .line 139
    .line 140
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 141
    .line 142
    .line 143
    move-result-wide v6

    .line 144
    :cond_3
    invoke-static {v6, v7, v2}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    const-string v2, "+"

    .line 149
    .line 150
    invoke-static {v2, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object p1

    .line 154
    goto :goto_2

    .line 155
    :cond_4
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseData;->getChangeQuota()Ljava/lang/Long;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    if-eqz p1, :cond_5

    .line 160
    .line 161
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 162
    .line 163
    .line 164
    move-result-wide v6

    .line 165
    :cond_5
    invoke-static {v6, v7, v2}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    :goto_2
    invoke-virtual {v3, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 170
    .line 171
    .line 172
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->g:Lxf/t;

    .line 173
    .line 174
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object p1

    .line 178
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    check-cast p1, Landroid/widget/LinearLayout;

    .line 182
    .line 183
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 184
    .line 185
    .line 186
    goto :goto_4

    .line 187
    :cond_6
    if-eqz p1, :cond_7

    .line 188
    .line 189
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    goto :goto_3

    .line 194
    :cond_7
    const/4 p1, 0x0

    .line 195
    :goto_3
    new-array v0, v0, [Ljava/lang/Object;

    .line 196
    .line 197
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    :cond_8
    :goto_4
    return-void

    .line 201
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseListResp;

    .line 202
    .line 203
    const/4 v0, 0x0

    .line 204
    if-eqz p1, :cond_c

    .line 205
    .line 206
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    const/4 v2, 0x1

    .line 211
    if-ne v1, v2, :cond_c

    .line 212
    .line 213
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseListResp;->getData()Ljava/util/List;

    .line 214
    .line 215
    .line 216
    move-result-object v1

    .line 217
    iget-object v2, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    .line 218
    .line 219
    if-eqz v1, :cond_b

    .line 220
    .line 221
    iget-object v1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->A:Ljava/util/ArrayList;

    .line 222
    .line 223
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 224
    .line 225
    .line 226
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseListResp;->getData()Ljava/util/List;

    .line 227
    .line 228
    .line 229
    move-result-object v1

    .line 230
    check-cast v1, Ljava/util/Collection;

    .line 231
    .line 232
    if-eqz v1, :cond_a

    .line 233
    .line 234
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 235
    .line 236
    .line 237
    move-result v1

    .line 238
    if-eqz v1, :cond_9

    .line 239
    .line 240
    goto :goto_5

    .line 241
    :cond_9
    iget-object v1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->A:Ljava/util/ArrayList;

    .line 242
    .line 243
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseListResp;->getData()Ljava/util/List;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    check-cast p1, Ljava/util/Collection;

    .line 251
    .line 252
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 253
    .line 254
    .line 255
    :cond_a
    :goto_5
    const-string p1, "mAdapter"

    .line 256
    .line 257
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    throw v0

    .line 261
    :cond_b
    iget-object p1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->v:Lxf/t;

    .line 262
    .line 263
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 264
    .line 265
    .line 266
    move-result-object p1

    .line 267
    const-string v0, "getValue(...)"

    .line 268
    .line 269
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    check-cast p1, Landroidx/core/widget/NestedScrollView;

    .line 273
    .line 274
    invoke-virtual {p1}, Landroidx/core/widget/NestedScrollView;->requestLayout()V

    .line 275
    .line 276
    .line 277
    iget-object p1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->v:Lxf/t;

    .line 278
    .line 279
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    move-result-object p1

    .line 283
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 284
    .line 285
    .line 286
    check-cast p1, Landroidx/core/widget/NestedScrollView;

    .line 287
    .line 288
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 289
    .line 290
    .line 291
    iget-object p1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->i:Lxf/t;

    .line 292
    .line 293
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 294
    .line 295
    .line 296
    move-result-object v1

    .line 297
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 298
    .line 299
    .line 300
    check-cast v1, Landroidx/recyclerview/widget/RecyclerView;

    .line 301
    .line 302
    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    .line 303
    .line 304
    .line 305
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 306
    .line 307
    .line 308
    move-result-object p1

    .line 309
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 310
    .line 311
    .line 312
    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    .line 313
    .line 314
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 315
    .line 316
    .line 317
    iget-object p1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->f:Lxf/t;

    .line 318
    .line 319
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 320
    .line 321
    .line 322
    move-result-object v1

    .line 323
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 324
    .line 325
    .line 326
    check-cast v1, Landroid/widget/TextView;

    .line 327
    .line 328
    invoke-virtual {v1}, Landroid/view/View;->requestLayout()V

    .line 329
    .line 330
    .line 331
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 332
    .line 333
    .line 334
    move-result-object p1

    .line 335
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 336
    .line 337
    .line 338
    check-cast p1, Landroid/widget/TextView;

    .line 339
    .line 340
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 341
    .line 342
    .line 343
    goto :goto_6

    .line 344
    :cond_c
    if-eqz p1, :cond_d

    .line 345
    .line 346
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object v0

    .line 350
    :cond_d
    const/4 p1, 0x0

    .line 351
    new-array p1, p1, [Ljava/lang/Object;

    .line 352
    .line 353
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 354
    .line 355
    .line 356
    :goto_6
    return-void

    .line 357
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitResp;

    .line 358
    .line 359
    iget-object v0, p0, Lub/w1;->g:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;

    .line 360
    .line 361
    const/4 v1, 0x0

    .line 362
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 363
    .line 364
    .line 365
    if-eqz p1, :cond_13

    .line 366
    .line 367
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 368
    .line 369
    .line 370
    move-result v2

    .line 371
    const/4 v3, 0x1

    .line 372
    if-ne v2, v3, :cond_13

    .line 373
    .line 374
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;

    .line 375
    .line 376
    .line 377
    move-result-object p1

    .line 378
    iput-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->w:Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;

    .line 379
    .line 380
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->t:Lxf/t;

    .line 381
    .line 382
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 383
    .line 384
    .line 385
    move-result-object p1

    .line 386
    const-string v1, "getValue(...)"

    .line 387
    .line 388
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 389
    .line 390
    .line 391
    check-cast p1, Landroid/widget/TextView;

    .line 392
    .line 393
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->w:Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;

    .line 394
    .line 395
    const-wide/16 v4, 0x0

    .line 396
    .line 397
    if-eqz v2, :cond_e

    .line 398
    .line 399
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;->getTotalCreditLimit()Ljava/lang/Long;

    .line 400
    .line 401
    .line 402
    move-result-object v2

    .line 403
    if-eqz v2, :cond_e

    .line 404
    .line 405
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 406
    .line 407
    .line 408
    move-result-wide v6

    .line 409
    goto :goto_7

    .line 410
    :cond_e
    move-wide v6, v4

    .line 411
    :goto_7
    invoke-static {v6, v7, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 412
    .line 413
    .line 414
    move-result-object v2

    .line 415
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 416
    .line 417
    .line 418
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->p:Lxf/t;

    .line 419
    .line 420
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 421
    .line 422
    .line 423
    move-result-object p1

    .line 424
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 425
    .line 426
    .line 427
    check-cast p1, Landroid/widget/TextView;

    .line 428
    .line 429
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->w:Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;

    .line 430
    .line 431
    if-eqz v2, :cond_f

    .line 432
    .line 433
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;->getInitCreditLimit()Ljava/lang/Long;

    .line 434
    .line 435
    .line 436
    move-result-object v2

    .line 437
    if-eqz v2, :cond_f

    .line 438
    .line 439
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 440
    .line 441
    .line 442
    move-result-wide v6

    .line 443
    goto :goto_8

    .line 444
    :cond_f
    move-wide v6, v4

    .line 445
    :goto_8
    invoke-static {v6, v7, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 446
    .line 447
    .line 448
    move-result-object v2

    .line 449
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 450
    .line 451
    .line 452
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->o:Lxf/t;

    .line 453
    .line 454
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 455
    .line 456
    .line 457
    move-result-object p1

    .line 458
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 459
    .line 460
    .line 461
    check-cast p1, Landroid/widget/TextView;

    .line 462
    .line 463
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->w:Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;

    .line 464
    .line 465
    if-eqz v2, :cond_10

    .line 466
    .line 467
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;->getChangeCreditLimit()Ljava/lang/Long;

    .line 468
    .line 469
    .line 470
    move-result-object v2

    .line 471
    if-eqz v2, :cond_10

    .line 472
    .line 473
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 474
    .line 475
    .line 476
    move-result-wide v6

    .line 477
    goto :goto_9

    .line 478
    :cond_10
    move-wide v6, v4

    .line 479
    :goto_9
    invoke-static {v6, v7, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 480
    .line 481
    .line 482
    move-result-object v2

    .line 483
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 484
    .line 485
    .line 486
    iget-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->j:Lxf/t;

    .line 487
    .line 488
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 489
    .line 490
    .line 491
    move-result-object p1

    .line 492
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 493
    .line 494
    .line 495
    check-cast p1, Landroid/widget/TextView;

    .line 496
    .line 497
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcTotalAmountActivity;->w:Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;

    .line 498
    .line 499
    if-eqz v1, :cond_11

    .line 500
    .line 501
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcIncreaseLimitData;->getChangeCreditLimit()Ljava/lang/Long;

    .line 502
    .line 503
    .line 504
    move-result-object v1

    .line 505
    if-eqz v1, :cond_11

    .line 506
    .line 507
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 508
    .line 509
    .line 510
    move-result-wide v1

    .line 511
    goto :goto_a

    .line 512
    :cond_11
    move-wide v1, v4

    .line 513
    :goto_a
    cmp-long v1, v1, v4

    .line 514
    .line 515
    if-ltz v1, :cond_12

    .line 516
    .line 517
    sget v1, LYa/g;->cs_total_limit_increased:I

    .line 518
    .line 519
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 520
    .line 521
    .line 522
    move-result-object v0

    .line 523
    goto :goto_b

    .line 524
    :cond_12
    sget v1, LYa/g;->cs_total_limit_decreased:I

    .line 525
    .line 526
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 527
    .line 528
    .line 529
    move-result-object v0

    .line 530
    :goto_b
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 531
    .line 532
    .line 533
    goto :goto_d

    .line 534
    :cond_13
    if-eqz p1, :cond_14

    .line 535
    .line 536
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 537
    .line 538
    .line 539
    move-result-object p1

    .line 540
    goto :goto_c

    .line 541
    :cond_14
    const/4 p1, 0x0

    .line 542
    :goto_c
    new-array v0, v1, [Ljava/lang/Object;

    .line 543
    .line 544
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 545
    .line 546
    .line 547
    :goto_d
    return-void

    .line 548
    nop

    .line 549
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
