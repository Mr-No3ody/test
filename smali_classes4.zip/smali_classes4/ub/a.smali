.class public final synthetic Lub/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/a;->a:I

    iput-object p1, p0, Lub/a;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    const/4 p1, 0x1

    .line 2
    const-string v0, "OcALLVerifyActivity_element_click"

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    iget-object v2, p0, Lub/a;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;

    .line 6
    .line 7
    iget v3, p0, Lub/a;->a:I

    .line 8
    .line 9
    packed-switch v3, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;->r0:I

    .line 13
    .line 14
    iput-boolean p1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v:Z

    .line 15
    .line 16
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    const-string v3, "/account/upgrade"

    .line 21
    .line 22
    invoke-virtual {p1, v3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iget-object v2, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 34
    .line 35
    if-eqz v2, :cond_0

    .line 36
    .line 37
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    :cond_0
    const-string v2, "oc_bvn_tv"

    .line 42
    .line 43
    invoke-virtual {p1, v0, v2, v1}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :pswitch_0
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;->r0:I

    .line 48
    .line 49
    iput-boolean p1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v:Z

    .line 50
    .line 51
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    const-string v3, "/coreImpl/bind_new_bank_account"

    .line 56
    .line 57
    invoke-virtual {p1, v3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    iget-object v2, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 69
    .line 70
    if-eqz v2, :cond_1

    .line 71
    .line 72
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    :cond_1
    const-string v2, "oc_bank_account_tv"

    .line 77
    .line 78
    invoke-virtual {p1, v0, v2, v1}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    return-void

    .line 82
    :pswitch_1
    sget v3, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;->r0:I

    .line 83
    .line 84
    iput-boolean p1, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v:Z

    .line 85
    .line 86
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    const-string v3, "/coreImpl/use_new_card"

    .line 91
    .line 92
    invoke-virtual {p1, v3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    iget-object v2, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 104
    .line 105
    if-eqz v2, :cond_2

    .line 106
    .line 107
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    :cond_2
    const-string v2, "oc_bank_card_tv"

    .line 112
    .line 113
    invoke-virtual {p1, v0, v2, v1}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    return-void

    .line 117
    :pswitch_2
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;->r0:I

    .line 118
    .line 119
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->v()V

    .line 120
    .line 121
    .line 122
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    iget-object v2, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 127
    .line 128
    if-eqz v2, :cond_3

    .line 129
    .line 130
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    :cond_3
    const-string v2, "router_close_img"

    .line 135
    .line 136
    invoke-virtual {p1, v0, v2, v1}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    return-void

    .line 140
    :pswitch_3
    sget p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcALLVerifyActivity;->r0:I

    .line 141
    .line 142
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->onBackPressed()V

    .line 143
    .line 144
    .line 145
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    iget-object v2, v2, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->B:Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 150
    .line 151
    if-eqz v2, :cond_4

    .line 152
    .line 153
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;->getProduct()Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object v1

    .line 157
    :cond_4
    const-string v2, "router_back_img"

    .line 158
    .line 159
    invoke-virtual {p1, v0, v2, v1}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    return-void

    .line 163
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
