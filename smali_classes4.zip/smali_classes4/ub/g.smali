.class public final synthetic Lub/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/g;->a:I

    iput-object p1, p0, Lub/g;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget-object p1, p0, Lub/g;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;

    .line 2
    .line 3
    iget v0, p0, Lub/g;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->X:I

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-static {}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->n()V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->X:I

    .line 18
    .line 19
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-static {}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyBaseActivity;->n()V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    nop

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
