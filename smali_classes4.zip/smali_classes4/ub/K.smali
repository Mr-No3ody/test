.class public final synthetic Lub/K;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/K;->a:I

    iput-object p1, p0, Lub/K;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 4

    .line 1
    iget-object p1, p0, Lub/K;->b:Ljava/lang/Object;

    .line 2
    .line 3
    iget v0, p0, Lub/K;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget-object v0, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;->Z:Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment$a;

    .line 9
    .line 10
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;

    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;->A()V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_0
    sget-object v0, Lcom/transsnet/palmpay/send_money/ui/activity/tobank/TransferToBankInputAmountActivity;->C:Lcom/transsnet/palmpay/send_money/ui/activity/tobank/TransferToBankInputAmountActivity$a;

    .line 17
    .line 18
    check-cast p1, Lcom/transsnet/palmpay/send_money/ui/activity/tobank/TransferToBankInputAmountActivity;

    .line 19
    .line 20
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    check-cast p1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankViewModel;

    .line 25
    .line 26
    if-eqz p1, :cond_0

    .line 27
    .line 28
    new-instance v0, LKd/q1;

    .line 29
    .line 30
    const/4 v1, 0x1

    .line 31
    const/4 v2, 0x0

    .line 32
    invoke-direct {v0, v1, v2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 33
    .line 34
    .line 35
    new-instance v1, Lcom/transsnet/palmpay/core/base/l;

    .line 36
    .line 37
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/base/l;-><init>()V

    .line 38
    .line 39
    .line 40
    const/4 v2, 0x0

    .line 41
    const/16 v3, 0x1c

    .line 42
    .line 43
    invoke-static {p1, v0, v1, v2, v3}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 44
    .line 45
    .line 46
    :cond_0
    return-void

    .line 47
    :pswitch_1
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->H:I

    .line 48
    .line 49
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 50
    .line 51
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
