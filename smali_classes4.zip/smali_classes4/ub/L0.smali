.class public final Lub/L0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/credit/ui/dialog/OcReferEarnWithdrawDialog$WithdrawClickInterface;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/L0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final inviteMote()V
    .locals 2

    .line 1
    iget-object v0, p0, Lub/L0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;

    .line 2
    .line 3
    sget v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcReferEarnActivity;->M:I

    .line 4
    .line 5
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/i;->a:Lcom/transsnet/palmpay/core/base/IBasePresenter;

    .line 6
    .line 7
    check-cast v0, Lpb/p;

    .line 8
    .line 9
    invoke-virtual {v0}, Lpb/p;->queryReferEarnHome()V

    .line 10
    .line 11
    .line 12
    return-void
.end method
