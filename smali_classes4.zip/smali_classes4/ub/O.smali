.class public final Lub/O;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/credit/ui/adapter/okcard/OcFeedbackSelectedImgAdapter$FeedBackAddImgCallBack;
.implements Lcom/transsnet/palmpay/betting/ui/adapter/BettingCouponAdapter$OnCouponClickListener;
.implements Lcom/transsnet/palmpay/core/util/ScanFaceLogicUtil$IScanFaceResultCallBack;


# instance fields
.field public final synthetic a:Landroidx/lifecycle/LifecycleOwner;


# direct methods
.method public synthetic constructor <init>(Landroidx/lifecycle/LifecycleOwner;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lub/O;->a:Landroidx/lifecycle/LifecycleOwner;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public addImg()V
    .locals 9

    .line 1
    iget-object v0, p0, Lub/O;->a:Landroidx/lifecycle/LifecycleOwner;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->w:Lyb/z;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    const-string v3, "mSelectedImgAdapter"

    .line 9
    .line 10
    if-eqz v1, :cond_2

    .line 11
    .line 12
    invoke-virtual {v1}, Lyb/z;->getItemCount()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/16 v4, 0x9

    .line 17
    .line 18
    const/4 v5, 0x0

    .line 19
    if-le v1, v4, :cond_0

    .line 20
    .line 21
    sget v1, LYa/g;->cs_oc_feedback_max_pic:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    new-array v1, v5, [Ljava/lang/Object;

    .line 28
    .line 29
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->o()Landroid/widget/EditText;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-static {v1}, Lcom/transsnet/palmpay/util/KeyboardUtils;->hideSoftInput(Landroid/view/View;)V

    .line 38
    .line 39
    .line 40
    invoke-static {v0}, Lcom/luck/picture/lib/basic/PictureSelector;->create(Landroidx/appcompat/app/o;)Lcom/luck/picture/lib/basic/PictureSelector;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    invoke-static {}, Lcom/luck/picture/lib/config/SelectMimeType;->ofImage()I

    .line 45
    .line 46
    .line 47
    move-result v6

    .line 48
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/basic/PictureSelector;->openGallery(I)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    iget-object v6, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->p:Lxf/t;

    .line 53
    .line 54
    invoke-virtual {v6}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v6

    .line 58
    check-cast v6, Lcom/luck/picture/lib/style/PictureSelectorStyle;

    .line 59
    .line 60
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setSelectorUIStyle(Lcom/luck/picture/lib/style/PictureSelectorStyle;)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-static {}, Lcom/luck/picture/lib/engine/GlideEngine;->createGlideEngine()Lcom/luck/picture/lib/engine/GlideEngine;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setImageEngine(Lcom/luck/picture/lib/engine/ImageEngine;)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    new-instance v6, Ld3/g;

    .line 73
    .line 74
    const/4 v7, 0x2

    .line 75
    invoke-direct {v6, v7}, Ld3/g;-><init>(I)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setCompressEngine(Lcom/luck/picture/lib/engine/CompressFileEngine;)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setEditMediaInterceptListener(Lcom/luck/picture/lib/interfaces/OnMediaEditInterceptListener;)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    const/4 v6, 0x1

    .line 87
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isPageSyncAlbumCount(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    new-instance v7, Lm8/b;

    .line 92
    .line 93
    const/16 v8, 0xf

    .line 94
    .line 95
    invoke-direct {v7, v8}, Lm8/b;-><init>(I)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v1, v7}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setQueryFilterListener(Lcom/luck/picture/lib/interfaces/OnQueryFilterListener;)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    const/4 v7, 0x2

    .line 103
    invoke-virtual {v1, v7}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setSelectionMode(I)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-virtual {v1, v7}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setLanguage(I)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    invoke-virtual {v1, v7}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setDefaultLanguage(I)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isDisplayTimeAxis(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    new-instance v7, Lm8/b;

    .line 120
    .line 121
    const/16 v8, 0x10

    .line 122
    .line 123
    invoke-direct {v7, v8}, Lm8/b;-><init>(I)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v1, v7}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setPreviewInterceptListener(Lcom/luck/picture/lib/interfaces/OnPreviewInterceptListener;)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isOnlyObtainSandboxDir(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isPageStrategy(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isOriginalControl(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 139
    .line 140
    .line 141
    move-result-object v1

    .line 142
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isDisplayCamera(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isOpenClickSound(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isFastSlidingSelect(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isPreviewFullScreenMode(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 155
    .line 156
    .line 157
    move-result-object v1

    .line 158
    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isPreviewImage(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 159
    .line 160
    .line 161
    move-result-object v1

    .line 162
    invoke-virtual {v1, v6}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isMaxSelectEnabledMask(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    invoke-virtual {v1, v4}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setMaxSelectNum(I)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 167
    .line 168
    .line 169
    move-result-object v1

    .line 170
    const/4 v4, -0x1

    .line 171
    invoke-virtual {v1, v4}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setRecyclerAnimationMode(I)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 172
    .line 173
    .line 174
    move-result-object v1

    .line 175
    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->isGif(Z)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    const-wide/16 v4, 0x3c00

    .line 180
    .line 181
    invoke-virtual {v1, v4, v5}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setSelectMaxFileSize(J)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 182
    .line 183
    .line 184
    move-result-object v1

    .line 185
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->w:Lyb/z;

    .line 186
    .line 187
    if-eqz v4, :cond_1

    .line 188
    .line 189
    iget-object v2, v4, Lyb/z;->b:Ljava/util/ArrayList;

    .line 190
    .line 191
    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->setSelectedData(Ljava/util/List;)Lcom/luck/picture/lib/basic/PictureSelectionModel;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    const-string v2, "setSelectedData(...)"

    .line 196
    .line 197
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcFeedbackActivity;->t:Landroidx/activity/result/a;

    .line 201
    .line 202
    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/basic/PictureSelectionModel;->forResult(Landroidx/activity/result/a;)V

    .line 203
    .line 204
    .line 205
    return-void

    .line 206
    :cond_1
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    throw v2

    .line 210
    :cond_2
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    throw v2
.end method

.method public onCouponClick(Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;I)V
    .locals 8

    .line 1
    const-string p2, "coupon"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getStatus()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 11
    .line 12
    .line 13
    move-result p2

    .line 14
    iget-object v0, p0, Lub/O;->a:Landroidx/lifecycle/LifecycleOwner;

    .line 15
    .line 16
    check-cast v0, Lcom/transsnet/palmpay/betting/ui/view/ModelBettingRootView;

    .line 17
    .line 18
    if-eqz p2, :cond_1

    .line 19
    .line 20
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    const-string p2, "item"

    .line 24
    .line 25
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    iget-object p2, v0, Lcom/transsnet/palmpay/betting/ui/view/ModelBettingRootView;->v:LWf/d0;

    .line 29
    .line 30
    if-eqz p2, :cond_0

    .line 31
    .line 32
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 33
    .line 34
    invoke-virtual {p2, v1}, LWf/d0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getClaimId()Ljava/lang/Long;

    .line 38
    .line 39
    .line 40
    move-result-object v4

    .line 41
    new-instance v6, Lw9/d;

    .line 42
    .line 43
    const/4 p1, 0x0

    .line 44
    invoke-direct {v6, v0, p1}, Lw9/d;-><init>(Lcom/transsnet/palmpay/betting/ui/view/ModelBettingRootView;I)V

    .line 45
    .line 46
    .line 47
    new-instance v7, Lw9/d;

    .line 48
    .line 49
    const/4 p1, 0x1

    .line 50
    invoke-direct {v7, v0, p1}, Lw9/d;-><init>(Lcom/transsnet/palmpay/betting/ui/view/ModelBettingRootView;I)V

    .line 51
    .line 52
    .line 53
    const-string p1, "lifecycleOwner"

    .line 54
    .line 55
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    const-string p1, "onSuccess"

    .line 59
    .line 60
    invoke-static {v6, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    const-string p1, "onError"

    .line 64
    .line 65
    invoke-static {v7, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/db/entity/User;->getMemberId()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v5

    .line 80
    invoke-static {v0}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    sget-object p2, LWf/I;->a:Lcg/f;

    .line 85
    .line 86
    sget-object p2, Lcg/e;->c:Lcg/e;

    .line 87
    .line 88
    new-instance v2, Lce/c;

    .line 89
    .line 90
    const/4 v3, 0x0

    .line 91
    invoke-direct/range {v2 .. v7}, Lce/c;-><init>(Lkotlin/coroutines/Continuation;Ljava/lang/Long;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V

    .line 92
    .line 93
    .line 94
    const/4 v1, 0x0

    .line 95
    const/4 v3, 0x2

    .line 96
    invoke-static {p1, p2, v1, v2, v3}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/custom_view/model/BaseConstraintLayout;->addJob(Lkotlinx/coroutines/Job;)V

    .line 101
    .line 102
    .line 103
    iget-object p1, v0, Lcom/transsnet/palmpay/betting/ui/view/ModelBettingRootView;->t:LOe/a;

    .line 104
    .line 105
    if-eqz p1, :cond_3

    .line 106
    .line 107
    invoke-virtual {p1}, LOe/a;->onCouponClaimComplete()V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :cond_1
    iget-object p2, v0, Lcom/transsnet/palmpay/betting/ui/view/ModelBettingRootView;->t:LOe/a;

    .line 112
    .line 113
    if-eqz p2, :cond_3

    .line 114
    .line 115
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getInstitutionIdList()Ljava/util/List;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;->getLimitAmt()Ljava/lang/Long;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    if-eqz p1, :cond_2

    .line 124
    .line 125
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 126
    .line 127
    .line 128
    move-result-wide v1

    .line 129
    goto :goto_0

    .line 130
    :cond_2
    const-wide/16 v1, 0x0

    .line 131
    .line 132
    :goto_0
    invoke-virtual {p2, v0, v1, v2}, LOe/a;->onCouponUseClick(Ljava/util/List;J)V

    .line 133
    .line 134
    .line 135
    :cond_3
    return-void
.end method

.method public onFailed(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-object p3, p0, Lub/O;->a:Landroidx/lifecycle/LifecycleOwner;

    .line 2
    .line 3
    check-cast p3, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFaceRecFragment;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-virtual {p3, v0}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 7
    .line 8
    .line 9
    iget-object p3, p3, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFaceRecFragment;->j:LSd/b;

    .line 10
    .line 11
    if-eqz p3, :cond_0

    .line 12
    .line 13
    invoke-virtual {p3, p1, p2}, LSd/b;->onFaceRecFailed(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public onProcessing()V
    .locals 2

    .line 1
    iget-object v0, p0, Lub/O;->a:Landroidx/lifecycle/LifecycleOwner;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFaceRecFragment;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public onSuccess(Lcom/transsnet/palmpay/core/bean/rsp/ALiFaceCheckResultData;)V
    .locals 2

    .line 1
    const-string v0, "data"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lub/O;->a:Landroidx/lifecycle/LifecycleOwner;

    .line 7
    .line 8
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFaceRecFragment;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 12
    .line 13
    .line 14
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFaceRecFragment;->j:LSd/b;

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {v0, p1}, LSd/b;->onFaceRecSuccess(Lcom/transsnet/palmpay/core/bean/rsp/ALiFaceCheckResultData;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    return-void
.end method
