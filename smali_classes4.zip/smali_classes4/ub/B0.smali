.class public final synthetic Lub/B0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcPromotionActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcPromotionActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, Lub/B0;->a:I

    iput-object p1, p0, Lub/B0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcPromotionActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget-object p1, p0, Lub/B0;->b:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcPromotionActivity;

    .line 2
    .line 3
    iget v0, p0, Lub/B0;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcPromotionActivity;->j:I

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_0
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcPromotionActivity;->j:I

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 18
    .line 19
    .line 20
    sget-object v0, Lob/c;->a:Lob/a;

    .line 21
    .line 22
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    const-string v1, "0"

    .line 34
    .line 35
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->okCardMainPage(Ljava/lang/String;)Ldf/d;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 40
    .line 41
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    new-instance v1, Ltb/q;

    .line 54
    .line 55
    const/16 v2, 0x17

    .line 56
    .line 57
    invoke-direct {v1, p1, v2}, Ltb/q;-><init>(Ljava/lang/Object;I)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :pswitch_1
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcPromotionActivity;->j:I

    .line 65
    .line 66
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    nop

    .line 71
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
