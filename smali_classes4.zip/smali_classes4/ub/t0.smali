.class public final Lub/t0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/credit/logicmanager/OneTouchBorrowManager$OneTouchBorrowListener;


# instance fields
.field public final synthetic a:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lub/t0;->a:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Lub/t0;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lub/t0;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 7
    .line 8
    .line 9
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->u0:Lub/v0;

    .line 10
    .line 11
    iget-object v1, v1, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    iput-boolean v2, v1, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->x0:Z

    .line 15
    .line 16
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/SendOneLoopOTPReq;

    .line 17
    .line 18
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->C0:Ljava/lang/String;

    .line 19
    .line 20
    invoke-direct {v1, v0}, Lcom/transsnet/palmpay/credit/bean/req/SendOneLoopOTPReq;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    sget-object v0, Lob/c;->a:Lob/a;

    .line 24
    .line 25
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->sendOneLoopOTP(Lcom/transsnet/palmpay/credit/bean/req/SendOneLoopOTPReq;)Ldf/d;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 41
    .line 42
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    new-instance v1, Lub/q0;

    .line 55
    .line 56
    invoke-direct {v1, p0}, Lub/q0;-><init>(Lub/t0;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 60
    .line 61
    .line 62
    return-void
.end method


# virtual methods
.method public onOneTouchBorrowCreateOrderSuccess()V
    .locals 3

    .line 1
    sget v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->j1:I

    .line 2
    .line 3
    iget-object v0, p0, Lub/t0;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->x()Lcom/transsnet/palmpay/credit/ui/view/OneTouchBorrowView2;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/ui/view/OneTouchBorrowView2;->c:Lcom/palmpay/lib/ui/button/PpButton;

    .line 14
    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-virtual {v1, v2}, Lcom/palmpay/lib/ui/button/PpButton;->b(Z)V

    .line 19
    .line 20
    .line 21
    :cond_0
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->P0:Lxf/t;

    .line 22
    .line 23
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Lcom/transsnet/palmpay/credit/view/CLMultipleCashProductView;

    .line 28
    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/view/CLMultipleCashProductView;->b()V

    .line 32
    .line 33
    .line 34
    :cond_1
    return-void
.end method

.method public onOneTouchBorrowInfoFail()V
    .locals 3

    .line 1
    sget v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->j1:I

    .line 2
    .line 3
    iget-object v0, p0, Lub/t0;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-virtual {v0, v1, v2}, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->C(ZLcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public onOneTouchBorrowInfoSuccess(Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;)V
    .locals 9

    .line 1
    const-string v0, "selectPlan"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->j1:I

    .line 7
    .line 8
    iget-object v0, p0, Lub/t0;->a:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    invoke-virtual {v0, v1, p1}, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->C(ZLcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;)V

    .line 14
    .line 15
    .line 16
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->H:Lxf/t;

    .line 17
    .line 18
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    check-cast v2, Landroid/widget/TextView;

    .line 23
    .line 24
    if-eqz v2, :cond_2

    .line 25
    .line 26
    const-string v3, "Borrow all: service fee is "

    .line 27
    .line 28
    invoke-static {v3}, LC0/G;->i(Ljava/lang/String;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    sget v5, LL6/b;->ppColorTextNormal:I

    .line 37
    .line 38
    invoke-virtual {v4, v5}, Landroid/content/Context;->getColor(I)I

    .line 39
    .line 40
    .line 41
    move-result v4

    .line 42
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getServiceFeeSum()Ljava/lang/Long;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    const-wide/16 v5, 0x0

    .line 51
    .line 52
    if-eqz v4, :cond_0

    .line 53
    .line 54
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 55
    .line 56
    .line 57
    move-result-wide v7

    .line 58
    goto :goto_0

    .line 59
    :cond_0
    move-wide v7, v5

    .line 60
    :goto_0
    invoke-static {v7, v8}, LPa/r0;->E(J)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v4

    .line 64
    invoke-static {v4, v1}, LPa/r0;->C(Ljava/lang/String;Z)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 73
    .line 74
    .line 75
    move-result-object v4

    .line 76
    sget v7, LL6/b;->ppColorFlexiCashPrimary:I

    .line 77
    .line 78
    const-string v8, ", interest is "

    .line 79
    .line 80
    invoke-static {v4, v7, v3, v8}, Lcom/horcrux/svg/d0;->i(Landroid/content/Context;ILcom/transsnet/palmpay/util/SpanUtils;Ljava/lang/String;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    sget v7, LL6/b;->ppColorTextNormal:I

    .line 89
    .line 90
    invoke-virtual {v4, v7}, Landroid/content/Context;->getColor(I)I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    invoke-virtual {v3, v4}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 95
    .line 96
    .line 97
    move-result-object v3

    .line 98
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getInterestSum()Ljava/lang/Long;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    if-eqz v4, :cond_1

    .line 103
    .line 104
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 105
    .line 106
    .line 107
    move-result-wide v5

    .line 108
    :cond_1
    invoke-static {v5, v6}, LPa/r0;->E(J)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    invoke-static {v4, v1}, LPa/r0;->C(Ljava/lang/String;Z)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    invoke-virtual {v3, v1}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    sget v4, LL6/b;->ppColorFlexiCashPrimary:I

    .line 125
    .line 126
    invoke-static {v3, v4, v1, v2}, LC0/G;->w(Landroid/content/Context;ILcom/transsnet/palmpay/util/SpanUtils;Landroid/widget/TextView;)V

    .line 127
    .line 128
    .line 129
    :cond_2
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/fragment/CLMainFragment;->P0:Lxf/t;

    .line 130
    .line 131
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    check-cast v0, Lcom/transsnet/palmpay/credit/view/CLMultipleCashProductView;

    .line 136
    .line 137
    if-eqz v0, :cond_3

    .line 138
    .line 139
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/credit/view/CLMultipleCashProductView;->c(Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;)V

    .line 140
    .line 141
    .line 142
    :cond_3
    return-void
.end method
