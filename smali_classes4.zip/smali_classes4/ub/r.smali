.class public final Lub/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/credit/view/OpenResultTaskView$taskAllDoneInterface;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/r;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final taskAllDone(Z)V
    .locals 3

    .line 1
    sget v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->O0:I

    .line 2
    .line 3
    iget-object v0, p0, Lub/r;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->z0:Lxf/t;

    .line 6
    .line 7
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const-string v2, "getValue(...)"

    .line 12
    .line 13
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    check-cast v1, Landroid/widget/TextView;

    .line 17
    .line 18
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcApplyResultActivity;->D0:Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcApplyResultData;->getErrorContent()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 v0, 0x0

    .line 28
    :goto_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_1

    .line 33
    .line 34
    if-eqz p1, :cond_1

    .line 35
    .line 36
    const/4 p1, 0x1

    .line 37
    goto :goto_1

    .line 38
    :cond_1
    const/4 p1, 0x0

    .line 39
    :goto_1
    invoke-static {v1, p1}, Loa/h;->s(Landroid/view/View;Z)V

    .line 40
    .line 41
    .line 42
    return-void
.end method
