.class public final Lub/v0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/input/OnOperatorItemClickListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 5
    .line 6
    return-void
.end method

.method public static a(Lub/v0;Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object p0, p0, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 2
    .line 3
    iget-object v0, p0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->r0:Landroid/view/View;

    .line 4
    .line 5
    const-string v1, "#EC2424"

    .line 6
    .line 7
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->s0:Landroid/widget/TextView;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 18
    .line 19
    .line 20
    iget-object p0, p0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->s0:Landroid/widget/TextView;

    .line 21
    .line 22
    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final onOperatorItemClick(Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/QueryOneLoopInfoNetworkItem;

    .line 2
    .line 3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryOneLoopInfoNetworkItem;->getItemName()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget-object v0, p0, Lub/v0;->a:Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;

    .line 8
    .line 9
    iput-object p1, v0, Lcom/transsnet/palmpay/credit/ui/activity/okcard/OcOneLoopActivity;->C0:Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method
