.class public final LXd/l;
.super LKb/c;
.source "SourceFile"

# interfaces
.implements Landroid/widget/SectionIndexer;


# instance fields
.field public final e:Z

.field public final f:Ljava/util/ArrayList;

.field public g:[Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Z)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, LKb/c;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    iput-boolean p2, p0, LXd/l;->e:Z

    .line 5
    .line 6
    new-instance p1, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, LXd/l;->f:Ljava/util/ArrayList;

    .line 12
    .line 13
    const/4 p1, 0x0

    .line 14
    new-array p1, p1, [Ljava/lang/String;

    .line 15
    .line 16
    iput-object p1, p0, LXd/l;->g:[Ljava/lang/String;

    .line 17
    .line 18
    return-void
.end method

.method public static d(Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;)Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getRecommend()Ljava/lang/Boolean;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 6
    .line 7
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    const-string p0, "#"

    .line 14
    .line 15
    return-object p0

    .line 16
    :cond_0
    invoke-virtual {p0}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    if-eqz p0, :cond_2

    .line 21
    .line 22
    invoke-static {p0}, Lkotlin/text/F;->x(Ljava/lang/String;)Ljava/lang/Character;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    if-eqz p0, :cond_2

    .line 27
    .line 28
    invoke-virtual {p0}, Ljava/lang/Character;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    if-eqz p0, :cond_2

    .line 33
    .line 34
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 35
    .line 36
    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    const-string v0, "toUpperCase(...)"

    .line 41
    .line 42
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    if-nez p0, :cond_1

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    return-object p0

    .line 49
    :cond_2
    :goto_0
    const-string p0, ""

    .line 50
    .line 51
    return-object p0
.end method


# virtual methods
.method public final c(I)J
    .locals 2

    .line 1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-ge p1, v0, :cond_2

    .line 8
    .line 9
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 10
    .line 11
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 16
    .line 17
    if-eqz p1, :cond_0

    .line 18
    .line 19
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getRecommend()Ljava/lang/Boolean;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 24
    .line 25
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    const/4 v0, 0x0

    .line 31
    :goto_0
    if-eqz v0, :cond_1

    .line 32
    .line 33
    const/16 p1, 0x23

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_1
    if-eqz p1, :cond_2

    .line 37
    .line 38
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-eqz p1, :cond_2

    .line 43
    .line 44
    invoke-static {p1}, Lkotlin/text/F;->x(Ljava/lang/String;)Ljava/lang/Character;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    if-eqz p1, :cond_2

    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/lang/Character;->charValue()C

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    invoke-static {p1}, Ljava/lang/Character;->toUpperCase(C)C

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    :goto_1
    int-to-long v0, p1

    .line 59
    return-wide v0

    .line 60
    :cond_2
    const-wide/16 v0, 0x0

    .line 61
    .line 62
    return-wide v0
.end method

.method public final getItemCount()I
    .locals 1

    .line 1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final getPositionForSection(I)I
    .locals 1

    .line 1
    iget-object v0, p0, LXd/l;->f:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/collections/CollectionsKt;->G(ILjava/util/List;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ljava/lang/Integer;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    return p1

    .line 16
    :cond_0
    const/4 p1, -0x1

    .line 17
    return p1
.end method

.method public final getSectionForPosition(I)I
    .locals 2

    .line 1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 2
    .line 3
    const-string v1, "mDatas"

    .line 4
    .line 5
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/collections/CollectionsKt;->G(ILjava/util/List;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 13
    .line 14
    if-nez p1, :cond_0

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    if-eqz v0, :cond_2

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_1
    iget-object v0, p0, LXd/l;->g:[Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {p1}, LXd/l;->d(Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-static {v0, p1}, Lkotlin/collections/n;->t([Ljava/lang/Object;Ljava/lang/Object;)I

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    return p1

    .line 41
    :cond_2
    :goto_0
    const/4 p1, -0x1

    .line 42
    return p1
.end method

.method public final getSections()[Ljava/lang/Object;
    .locals 8

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    const/16 v1, 0x1a

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LXd/l;->f:Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 11
    .line 12
    .line 13
    iget-object v2, p0, LKb/c;->b:Ljava/util/List;

    .line 14
    .line 15
    const-string v3, "mDatas"

    .line 16
    .line 17
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    check-cast v2, Ljava/lang/Iterable;

    .line 21
    .line 22
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    const/4 v3, 0x0

    .line 27
    move v4, v3

    .line 28
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    if-eqz v5, :cond_2

    .line 33
    .line 34
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    add-int/lit8 v6, v4, 0x1

    .line 39
    .line 40
    if-ltz v4, :cond_1

    .line 41
    .line 42
    check-cast v5, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 43
    .line 44
    if-eqz v5, :cond_0

    .line 45
    .line 46
    invoke-virtual {v5}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v7

    .line 50
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 51
    .line 52
    .line 53
    move-result v7

    .line 54
    if-nez v7, :cond_0

    .line 55
    .line 56
    invoke-static {v5}, LXd/l;->d(Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v5

    .line 60
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v7

    .line 64
    if-nez v7, :cond_0

    .line 65
    .line 66
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 70
    .line 71
    .line 72
    move-result-object v4

    .line 73
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    :cond_0
    move v4, v6

    .line 77
    goto :goto_0

    .line 78
    :cond_1
    invoke-static {}, Lkotlin/collections/q;->k()V

    .line 79
    .line 80
    .line 81
    const/4 v0, 0x0

    .line 82
    throw v0

    .line 83
    :cond_2
    new-array v1, v3, [Ljava/lang/String;

    .line 84
    .line 85
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    check-cast v0, [Ljava/lang/String;

    .line 90
    .line 91
    iput-object v0, p0, LXd/l;->g:[Ljava/lang/String;

    .line 92
    .line 93
    return-object v0
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 9

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    const-string v2, "holder"

    .line 4
    .line 5
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v2, p0, LKb/c;->b:Ljava/util/List;

    .line 9
    .line 10
    invoke-interface {v2, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    check-cast v2, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 18
    .line 19
    move-object v3, p1

    .line 20
    check-cast v3, LXd/k;

    .line 21
    .line 22
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    const-string v4, "bean"

    .line 26
    .line 27
    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getInstitutionLogo()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    if-eqz v4, :cond_0

    .line 39
    .line 40
    const-string v4, "android.resource://com.transsnet.palmpay/drawable/qt_default_bill_payment_icon"

    .line 41
    .line 42
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_0
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getInstitutionLogo()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    :goto_0
    iget-object v5, v3, LXd/k;->e:Landroid/widget/ImageView;

    .line 62
    .line 63
    if-eqz v5, :cond_1

    .line 64
    .line 65
    new-instance v6, LG1/d;

    .line 66
    .line 67
    invoke-direct {v6}, LG1/a;-><init>()V

    .line 68
    .line 69
    .line 70
    sget v7, LPd/b;->qt_icon_default_biller_history:I

    .line 71
    .line 72
    invoke-virtual {v6, v7}, LG1/a;->j(I)LG1/a;

    .line 73
    .line 74
    .line 75
    move-result-object v6

    .line 76
    check-cast v6, LG1/d;

    .line 77
    .line 78
    sget v7, LPd/b;->qt_icon_default_biller_history:I

    .line 79
    .line 80
    invoke-virtual {v6, v7}, LG1/a;->x(I)LG1/a;

    .line 81
    .line 82
    .line 83
    move-result-object v6

    .line 84
    check-cast v6, LG1/d;

    .line 85
    .line 86
    new-instance v7, Lcom/bumptech/glide/load/resource/bitmap/z;

    .line 87
    .line 88
    const/high16 v8, 0x40800000    # 4.0f

    .line 89
    .line 90
    invoke-static {v8}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 91
    .line 92
    .line 93
    move-result v8

    .line 94
    invoke-direct {v7, v8}, Lcom/bumptech/glide/load/resource/bitmap/z;-><init>(I)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v6, v7}, LG1/a;->H(Lcom/bumptech/glide/load/Transformation;)LG1/a;

    .line 98
    .line 99
    .line 100
    move-result-object v6

    .line 101
    check-cast v6, LG1/d;

    .line 102
    .line 103
    invoke-static {v5, v4, v6}, LPa/r0;->g1(Landroid/widget/ImageView;Landroid/net/Uri;LG1/d;)V

    .line 104
    .line 105
    .line 106
    :cond_1
    iget-object v4, v3, LXd/k;->o:LXd/l;

    .line 107
    .line 108
    iget-boolean v5, v4, LXd/l;->e:Z

    .line 109
    .line 110
    const-string v6, ""

    .line 111
    .line 112
    if-eqz v5, :cond_4

    .line 113
    .line 114
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getAbbreviatedName()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v5

    .line 118
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 119
    .line 120
    .line 121
    move-result v5

    .line 122
    if-eqz v5, :cond_3

    .line 123
    .line 124
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v5

    .line 128
    if-nez v5, :cond_2

    .line 129
    .line 130
    goto :goto_1

    .line 131
    :cond_2
    move-object v6, v5

    .line 132
    goto :goto_1

    .line 133
    :cond_3
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getAbbreviatedName()Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v5

    .line 137
    if-nez v5, :cond_2

    .line 138
    .line 139
    :goto_1
    sget-object v5, Lee/c;->a:Ljava/lang/String;

    .line 140
    .line 141
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getCategoryId()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v5

    .line 145
    iget-object v4, v4, LKb/c;->a:Landroid/content/Context;

    .line 146
    .line 147
    invoke-static {v4, v5}, Lee/c;->c(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v4

    .line 151
    const-string v5, " - "

    .line 152
    .line 153
    invoke-static {v6, v5, v4}, LN8/q0;->y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    goto :goto_3

    .line 158
    :cond_4
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getShortName()Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v4

    .line 162
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 163
    .line 164
    .line 165
    move-result v4

    .line 166
    if-eqz v4, :cond_6

    .line 167
    .line 168
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v4

    .line 172
    if-nez v4, :cond_5

    .line 173
    .line 174
    goto :goto_2

    .line 175
    :cond_5
    move-object v6, v4

    .line 176
    goto :goto_2

    .line 177
    :cond_6
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getShortName()Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v4

    .line 181
    if-nez v4, :cond_5

    .line 182
    .line 183
    :goto_2
    move-object v4, v6

    .line 184
    :goto_3
    iget-object v5, v3, LXd/k;->d:Landroid/widget/TextView;

    .line 185
    .line 186
    if-eqz v5, :cond_7

    .line 187
    .line 188
    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 189
    .line 190
    .line 191
    :cond_7
    iget-object v4, v3, LXd/k;->i:Landroid/widget/TextView;

    .line 192
    .line 193
    if-eqz v4, :cond_8

    .line 194
    .line 195
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v6

    .line 199
    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 200
    .line 201
    .line 202
    :cond_8
    iget-object v4, v3, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 203
    .line 204
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getStatus()Ljava/lang/Integer;

    .line 205
    .line 206
    .line 207
    move-result-object v6

    .line 208
    if-nez v6, :cond_9

    .line 209
    .line 210
    goto :goto_4

    .line 211
    :cond_9
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 212
    .line 213
    .line 214
    move-result v6

    .line 215
    if-ne v1, v6, :cond_a

    .line 216
    .line 217
    move v6, v1

    .line 218
    goto :goto_5

    .line 219
    :cond_a
    :goto_4
    move v6, v0

    .line 220
    :goto_5
    invoke-virtual {v4, v6}, Landroid/view/View;->setEnabled(Z)V

    .line 221
    .line 222
    .line 223
    sget-object v4, Lee/c;->a:Ljava/lang/String;

    .line 224
    .line 225
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getStatus()Ljava/lang/Integer;

    .line 226
    .line 227
    .line 228
    move-result-object v4

    .line 229
    if-eqz v4, :cond_b

    .line 230
    .line 231
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 232
    .line 233
    .line 234
    move-result v4

    .line 235
    goto :goto_6

    .line 236
    :cond_b
    move v4, v0

    .line 237
    :goto_6
    new-array v6, v1, [Landroid/view/View;

    .line 238
    .line 239
    aput-object v5, v6, v0

    .line 240
    .line 241
    invoke-static {v4, v6}, Lee/c;->j(I[Landroid/view/View;)V

    .line 242
    .line 243
    .line 244
    iget-object v4, v3, LXd/k;->j:Landroid/widget/TextView;

    .line 245
    .line 246
    if-eqz v4, :cond_c

    .line 247
    .line 248
    invoke-static {v2}, LXd/l;->d(Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;)Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v5

    .line 252
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 253
    .line 254
    .line 255
    :cond_c
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getHasCoupon()Ljava/lang/Boolean;

    .line 256
    .line 257
    .line 258
    move-result-object v4

    .line 259
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 260
    .line 261
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 262
    .line 263
    .line 264
    move-result v4

    .line 265
    iget-object v5, v3, LXd/k;->g:Landroid/widget/ImageView;

    .line 266
    .line 267
    const/16 v6, 0x8

    .line 268
    .line 269
    if-eqz v4, :cond_d

    .line 270
    .line 271
    if-eqz v5, :cond_e

    .line 272
    .line 273
    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 274
    .line 275
    .line 276
    goto :goto_7

    .line 277
    :cond_d
    if-eqz v5, :cond_e

    .line 278
    .line 279
    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 280
    .line 281
    .line 282
    :cond_e
    :goto_7
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getRemark()Ljava/lang/String;

    .line 283
    .line 284
    .line 285
    move-result-object v4

    .line 286
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 287
    .line 288
    .line 289
    move-result v4

    .line 290
    iget-object v3, v3, LXd/k;->f:Landroid/widget/TextView;

    .line 291
    .line 292
    if-nez v4, :cond_10

    .line 293
    .line 294
    if-eqz v3, :cond_f

    .line 295
    .line 296
    invoke-virtual {v3, v0}, Landroid/view/View;->setVisibility(I)V

    .line 297
    .line 298
    .line 299
    :cond_f
    if-eqz v3, :cond_11

    .line 300
    .line 301
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getRemark()Ljava/lang/String;

    .line 302
    .line 303
    .line 304
    move-result-object v2

    .line 305
    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 306
    .line 307
    .line 308
    goto :goto_8

    .line 309
    :cond_10
    if-eqz v3, :cond_11

    .line 310
    .line 311
    invoke-virtual {v3, v6}, Landroid/view/View;->setVisibility(I)V

    .line 312
    .line 313
    .line 314
    :cond_11
    :goto_8
    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 315
    .line 316
    sget v2, LPd/c;->qlp_header_item:I

    .line 317
    .line 318
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 319
    .line 320
    .line 321
    move-result-object p1

    .line 322
    if-nez p2, :cond_12

    .line 323
    .line 324
    if-eqz p1, :cond_14

    .line 325
    .line 326
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 327
    .line 328
    .line 329
    return-void

    .line 330
    :cond_12
    add-int/lit8 v1, p2, -0x1

    .line 331
    .line 332
    invoke-virtual {p0, v1}, LXd/l;->c(I)J

    .line 333
    .line 334
    .line 335
    move-result-wide v1

    .line 336
    invoke-virtual {p0, p2}, LXd/l;->c(I)J

    .line 337
    .line 338
    .line 339
    move-result-wide v3

    .line 340
    cmp-long p2, v3, v1

    .line 341
    .line 342
    if-eqz p2, :cond_13

    .line 343
    .line 344
    if-eqz p1, :cond_14

    .line 345
    .line 346
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 347
    .line 348
    .line 349
    return-void

    .line 350
    :cond_13
    if-eqz p1, :cond_14

    .line 351
    .line 352
    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    .line 353
    .line 354
    .line 355
    :cond_14
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 2

    .line 1
    const-string p2, "parent"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, LXd/k;

    .line 7
    .line 8
    sget p2, LPd/d;->qt_layout_pick_biller_list_item:I

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iget-object v1, p0, LKb/c;->a:Landroid/content/Context;

    .line 12
    .line 13
    invoke-static {v1, p2, v0}, Landroid/view/View;->inflate(Landroid/content/Context;ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    invoke-direct {p1, p0, p2}, LXd/k;-><init>(LXd/l;Landroid/view/View;)V

    .line 18
    .line 19
    .line 20
    return-object p1
.end method
