.class public final LXd/f;
.super LM1/j;
.source "SourceFile"


# instance fields
.field public final a:Z


# direct methods
.method public constructor <init>(Z)V
    .locals 2

    .line 1
    sget v0, LPd/d;->qt_item_coupon_in_list:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {p0, v0, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 5
    .line 6
    .line 7
    iput-boolean p1, p0, LXd/f;->a:Z

    .line 8
    .line 9
    sget p1, LPd/c;->icilUseTv:I

    .line 10
    .line 11
    sget v0, LPd/c;->llDetailArrow:I

    .line 12
    .line 13
    filled-new-array {p1, v0}, [I

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-virtual {p0, p1}, LM1/j;->addChildClickViewIds([I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 7

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "couponItem"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    sget v0, LPd/c;->llExpand:I

    .line 14
    .line 15
    const/4 v1, 0x1

    .line 16
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 17
    .line 18
    .line 19
    new-instance v0, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 20
    .line 21
    invoke-direct {v0}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 22
    .line 23
    .line 24
    const-string v2, "\u20a6"

    .line 25
    .line 26
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const/high16 v2, 0x41600000    # 14.0f

    .line 31
    .line 32
    invoke-static {v2}, Lcom/transsnet/palmpay/util/SizeUtils;->sp2px(F)I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getNominaValue()Ljava/lang/Long;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    const-wide/16 v3, 0x0

    .line 45
    .line 46
    if-eqz v2, :cond_0

    .line 47
    .line 48
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 49
    .line 50
    .line 51
    move-result-wide v5

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    move-wide v5, v3

    .line 54
    :goto_0
    invoke-static {v5, v6}, LPa/r0;->A(J)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    const-string v5, "getAmountString(...)"

    .line 59
    .line 60
    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    const-string v5, ""

    .line 64
    .line 65
    const-string v6, ".00"

    .line 66
    .line 67
    invoke-static {v2, v6, v5}, Lkotlin/text/y;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    const/16 v2, 0x18

    .line 76
    .line 77
    invoke-static {v2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->setFontSize(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-virtual {v0}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    sget v2, LPd/c;->icilCouponAmount:I

    .line 90
    .line 91
    invoke-virtual {p1, v2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 92
    .line 93
    .line 94
    sget v0, LPd/c;->tvCouponName:I

    .line 95
    .line 96
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getCouponName()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    invoke-virtual {p1, v0, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 101
    .line 102
    .line 103
    sget v0, LPd/c;->ivCouponIcon:I

    .line 104
    .line 105
    invoke-virtual {p1, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Landroid/widget/ImageView;

    .line 110
    .line 111
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getCouponIcon()Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    if-eqz v2, :cond_1

    .line 120
    .line 121
    sget v2, Lcom/transsnet/palmpay/custom_view/r;->cv_coupon_icon:I

    .line 122
    .line 123
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 124
    .line 125
    .line 126
    goto :goto_1

    .line 127
    :cond_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getCouponIcon()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v2

    .line 131
    sget v5, Lcom/transsnet/palmpay/custom_view/r;->cv_coupon_icon:I

    .line 132
    .line 133
    invoke-static {v0, v2, v5}, LPa/r0;->h1(Landroid/widget/ImageView;Ljava/lang/String;I)V

    .line 134
    .line 135
    .line 136
    :goto_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;->getEndTime()Ljava/lang/Long;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    if-eqz v0, :cond_2

    .line 141
    .line 142
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 143
    .line 144
    .line 145
    move-result-wide v5

    .line 146
    goto :goto_2

    .line 147
    :cond_2
    move-wide v5, v3

    .line 148
    :goto_2
    cmp-long v0, v5, v3

    .line 149
    .line 150
    const/4 v2, 0x0

    .line 151
    if-lez v0, :cond_4

    .line 152
    .line 153
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    sget v5, Lba/k;->core_valid_until:I

    .line 162
    .line 163
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;->getEndTime()Ljava/lang/Long;

    .line 164
    .line 165
    .line 166
    move-result-object v6

    .line 167
    if-eqz v6, :cond_3

    .line 168
    .line 169
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 170
    .line 171
    .line 172
    move-result-wide v3

    .line 173
    :cond_3
    invoke-static {v3, v4}, LPa/r0;->S(J)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v3

    .line 177
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v3

    .line 181
    invoke-virtual {v0, v5, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    const-string v3, "getString(...)"

    .line 186
    .line 187
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    sget v3, LPd/c;->dateCouponTv:I

    .line 191
    .line 192
    invoke-virtual {p1, v3, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 193
    .line 194
    .line 195
    sget v0, LPd/c;->dateCouponTv:I

    .line 196
    .line 197
    invoke-virtual {p1, v0, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 198
    .line 199
    .line 200
    goto :goto_3

    .line 201
    :cond_4
    sget v0, LPd/c;->dateCouponTv:I

    .line 202
    .line 203
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 204
    .line 205
    .line 206
    :goto_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getCouponSubhead()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 211
    .line 212
    .line 213
    move-result v0

    .line 214
    if-nez v0, :cond_5

    .line 215
    .line 216
    sget v0, LPd/c;->couponLimitTv:I

    .line 217
    .line 218
    invoke-virtual {p1, v0, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 219
    .line 220
    .line 221
    sget v0, LPd/c;->couponLimitTv:I

    .line 222
    .line 223
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getCouponSubhead()Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object v3

    .line 227
    invoke-virtual {p1, v0, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 228
    .line 229
    .line 230
    goto :goto_4

    .line 231
    :cond_5
    sget v0, LPd/c;->couponLimitTv:I

    .line 232
    .line 233
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 234
    .line 235
    .line 236
    :goto_4
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;->getCouponDesc()Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v0

    .line 240
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 241
    .line 242
    .line 243
    move-result v0

    .line 244
    if-eqz v0, :cond_6

    .line 245
    .line 246
    sget v0, LPd/c;->llDetailArrow:I

    .line 247
    .line 248
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 249
    .line 250
    .line 251
    sget v0, LPd/c;->llExpand:I

    .line 252
    .line 253
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 254
    .line 255
    .line 256
    goto :goto_6

    .line 257
    :cond_6
    sget v0, LPd/c;->llDetailArrow:I

    .line 258
    .line 259
    invoke-virtual {p1, v0, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 260
    .line 261
    .line 262
    sget v0, LPd/c;->tvCouponDesc:I

    .line 263
    .line 264
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;->getCouponDesc()Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v2

    .line 268
    invoke-virtual {p1, v0, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 269
    .line 270
    .line 271
    sget v0, LPd/c;->llExpand:I

    .line 272
    .line 273
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;->getLayoutExpand()Ljava/lang/Boolean;

    .line 274
    .line 275
    .line 276
    move-result-object v2

    .line 277
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 278
    .line 279
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 280
    .line 281
    .line 282
    move-result v2

    .line 283
    xor-int/2addr v1, v2

    .line 284
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 285
    .line 286
    .line 287
    sget v0, LPd/c;->ivExpandArrow:I

    .line 288
    .line 289
    invoke-virtual {p1, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 290
    .line 291
    .line 292
    move-result-object v0

    .line 293
    check-cast v0, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 294
    .line 295
    new-instance v1, Lcom/mikepenz/iconics/IconicsDrawable;

    .line 296
    .line 297
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 298
    .line 299
    .line 300
    move-result-object v2

    .line 301
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;->getLayoutExpand()Ljava/lang/Boolean;

    .line 302
    .line 303
    .line 304
    move-result-object v4

    .line 305
    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 306
    .line 307
    .line 308
    move-result v3

    .line 309
    if-eqz v3, :cond_7

    .line 310
    .line 311
    sget-object v3, LS6/a;->o:LS6/a;

    .line 312
    .line 313
    goto :goto_5

    .line 314
    :cond_7
    sget-object v3, LS6/a;->p:LS6/a;

    .line 315
    .line 316
    :goto_5
    invoke-direct {v1, v2, v3}, Lcom/mikepenz/iconics/IconicsDrawable;-><init>(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;)V

    .line 317
    .line 318
    .line 319
    new-instance v2, LN8/g;

    .line 320
    .line 321
    const/16 v3, 0x1a

    .line 322
    .line 323
    invoke-direct {v2, p0, v3}, LN8/g;-><init>(Ljava/lang/Object;I)V

    .line 324
    .line 325
    .line 326
    invoke-virtual {v1, v2}, Lcom/mikepenz/iconics/IconicsDrawable;->a(Lkotlin/jvm/functions/Function1;)V

    .line 327
    .line 328
    .line 329
    invoke-virtual {v0, v1}, Lcom/mikepenz/iconics/view/IconicsImageView;->setIcon(Lcom/mikepenz/iconics/IconicsDrawable;)V

    .line 330
    .line 331
    .line 332
    :goto_6
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/resp/BillerBaseCouponItemBean;->getStatus()Ljava/lang/String;

    .line 333
    .line 334
    .line 335
    move-result-object p2

    .line 336
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 337
    .line 338
    .line 339
    move-result p2

    .line 340
    if-eqz p2, :cond_8

    .line 341
    .line 342
    sget p2, LPd/c;->icilUseTv:I

    .line 343
    .line 344
    sget v0, LPd/f;->qt_claim:I

    .line 345
    .line 346
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 347
    .line 348
    .line 349
    goto :goto_7

    .line 350
    :cond_8
    sget p2, LPd/c;->icilUseTv:I

    .line 351
    .line 352
    sget v0, Lba/k;->core_use:I

    .line 353
    .line 354
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 355
    .line 356
    .line 357
    :goto_7
    iget-boolean p2, p0, LXd/f;->a:Z

    .line 358
    .line 359
    if-eqz p2, :cond_9

    .line 360
    .line 361
    sget p2, LPd/c;->icilUseTv:I

    .line 362
    .line 363
    sget v0, LL6/b;->ppColorButtonTextWhite:I

    .line 364
    .line 365
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 366
    .line 367
    .line 368
    move-result-object v1

    .line 369
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 370
    .line 371
    .line 372
    move-result v0

    .line 373
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setTextColor(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 374
    .line 375
    .line 376
    return-void

    .line 377
    :cond_9
    sget p2, LPd/c;->icilUseTv:I

    .line 378
    .line 379
    sget v0, LL6/b;->ppColorPrimary:I

    .line 380
    .line 381
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 382
    .line 383
    .line 384
    move-result-object v1

    .line 385
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 386
    .line 387
    .line 388
    move-result v0

    .line 389
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setTextColor(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 390
    .line 391
    .line 392
    return-void
.end method
