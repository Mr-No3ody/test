.class public final LXd/m;
.super LM1/j;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    .line 1
    sget v0, LPd/d;->qt_layout_dialog_pick_biller_list_item:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {p0, v0, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, LXd/m;->a:Ljava/lang/String;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 4
    .line 5
    const-string v2, "holder"

    .line 6
    .line 7
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "bean"

    .line 11
    .line 12
    invoke-static {p2, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getInstitutionLogo()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_0

    .line 24
    .line 25
    sget v2, LPd/c;->iv_biller_icon:I

    .line 26
    .line 27
    invoke-virtual {p1, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    check-cast v2, Landroid/widget/ImageView;

    .line 32
    .line 33
    sget v3, Lcom/transsnet/palmpay/custom_view/r;->cv_palmpay_logo_7:I

    .line 34
    .line 35
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    sget v2, LPd/c;->iv_biller_icon:I

    .line 40
    .line 41
    invoke-virtual {p1, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    check-cast v2, Landroid/widget/ImageView;

    .line 46
    .line 47
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getInstitutionLogo()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    new-instance v4, LG1/d;

    .line 52
    .line 53
    invoke-direct {v4}, LG1/a;-><init>()V

    .line 54
    .line 55
    .line 56
    sget v5, Lcom/transsnet/palmpay/custom_view/r;->cv_palmpay_logo_7:I

    .line 57
    .line 58
    invoke-virtual {v4, v5}, LG1/a;->j(I)LG1/a;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    check-cast v4, LG1/d;

    .line 63
    .line 64
    sget v5, Lcom/transsnet/palmpay/custom_view/r;->cv_palmpay_logo_7:I

    .line 65
    .line 66
    invoke-virtual {v4, v5}, LG1/a;->x(I)LG1/a;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    check-cast v4, LG1/d;

    .line 71
    .line 72
    new-instance v5, Lcom/bumptech/glide/load/resource/bitmap/z;

    .line 73
    .line 74
    const/4 v6, 0x4

    .line 75
    invoke-static {v6}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->getDp(I)I

    .line 76
    .line 77
    .line 78
    move-result v6

    .line 79
    invoke-direct {v5, v6}, Lcom/bumptech/glide/load/resource/bitmap/z;-><init>(I)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v4, v5}, LG1/a;->H(Lcom/bumptech/glide/load/Transformation;)LG1/a;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    check-cast v4, LG1/d;

    .line 87
    .line 88
    invoke-static {v2, v3, v4}, LPa/r0;->j1(Landroid/widget/ImageView;Ljava/lang/String;LG1/d;)V

    .line 89
    .line 90
    .line 91
    :goto_0
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getShortName()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v2

    .line 95
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 96
    .line 97
    .line 98
    move-result v2

    .line 99
    if-eqz v2, :cond_1

    .line 100
    .line 101
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    goto :goto_1

    .line 106
    :cond_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getShortName()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v2

    .line 110
    :goto_1
    sget v3, LPd/c;->tv_biller_name:I

    .line 111
    .line 112
    invoke-virtual {p1, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 113
    .line 114
    .line 115
    move-result-object v3

    .line 116
    check-cast v3, Landroid/widget/TextView;

    .line 117
    .line 118
    if-eqz v3, :cond_2

    .line 119
    .line 120
    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 121
    .line 122
    .line 123
    :cond_2
    sget-object v2, Lee/c;->a:Ljava/lang/String;

    .line 124
    .line 125
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getStatus()Ljava/lang/Integer;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    if-eqz v2, :cond_3

    .line 130
    .line 131
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 132
    .line 133
    .line 134
    move-result v2

    .line 135
    goto :goto_2

    .line 136
    :cond_3
    move v2, v1

    .line 137
    :goto_2
    new-array v4, v0, [Landroid/view/View;

    .line 138
    .line 139
    aput-object v3, v4, v1

    .line 140
    .line 141
    invoke-static {v2, v4}, Lee/c;->j(I[Landroid/view/View;)V

    .line 142
    .line 143
    .line 144
    iget-object v2, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 145
    .line 146
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getStatus()Ljava/lang/Integer;

    .line 147
    .line 148
    .line 149
    move-result-object v3

    .line 150
    if-nez v3, :cond_4

    .line 151
    .line 152
    goto :goto_3

    .line 153
    :cond_4
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 154
    .line 155
    .line 156
    move-result v3

    .line 157
    if-ne v0, v3, :cond_5

    .line 158
    .line 159
    const/high16 v3, 0x3f800000    # 1.0f

    .line 160
    .line 161
    goto :goto_4

    .line 162
    :cond_5
    :goto_3
    const/high16 v3, 0x3f000000    # 0.5f

    .line 163
    .line 164
    :goto_4
    invoke-virtual {v2, v3}, Landroid/view/View;->setAlpha(F)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getHasCoupon()Ljava/lang/Boolean;

    .line 168
    .line 169
    .line 170
    move-result-object v2

    .line 171
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 172
    .line 173
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v2

    .line 177
    if-eqz v2, :cond_6

    .line 178
    .line 179
    sget v2, LPd/c;->iv_coupon_star:I

    .line 180
    .line 181
    invoke-virtual {p1, v2, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 182
    .line 183
    .line 184
    goto :goto_5

    .line 185
    :cond_6
    sget v2, LPd/c;->iv_coupon_star:I

    .line 186
    .line 187
    invoke-virtual {p1, v2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 188
    .line 189
    .line 190
    :goto_5
    const-string v2, "2"

    .line 191
    .line 192
    iget-object v3, p0, LXd/m;->a:Ljava/lang/String;

    .line 193
    .line 194
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    move-result v2

    .line 198
    if-nez v2, :cond_9

    .line 199
    .line 200
    const-string v2, "1"

    .line 201
    .line 202
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v2

    .line 206
    if-eqz v2, :cond_7

    .line 207
    .line 208
    goto :goto_6

    .line 209
    :cond_7
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getRemark()Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object v2

    .line 213
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 214
    .line 215
    .line 216
    move-result v2

    .line 217
    if-nez v2, :cond_8

    .line 218
    .line 219
    sget v0, LPd/c;->iv_cashback:I

    .line 220
    .line 221
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 222
    .line 223
    .line 224
    sget v0, LPd/c;->iv_cashback:I

    .line 225
    .line 226
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getRemark()Ljava/lang/String;

    .line 227
    .line 228
    .line 229
    move-result-object p2

    .line 230
    invoke-virtual {p1, v0, p2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 231
    .line 232
    .line 233
    return-void

    .line 234
    :cond_8
    sget p2, LPd/c;->iv_cashback:I

    .line 235
    .line 236
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 237
    .line 238
    .line 239
    return-void

    .line 240
    :cond_9
    :goto_6
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerTips()Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object v2

    .line 244
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 245
    .line 246
    .line 247
    move-result v2

    .line 248
    if-nez v2, :cond_a

    .line 249
    .line 250
    sget v0, LPd/c;->iv_cashback:I

    .line 251
    .line 252
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 253
    .line 254
    .line 255
    sget v0, LPd/c;->iv_cashback:I

    .line 256
    .line 257
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerTips()Ljava/lang/String;

    .line 258
    .line 259
    .line 260
    move-result-object v1

    .line 261
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 262
    .line 263
    .line 264
    goto :goto_7

    .line 265
    :cond_a
    sget v1, LPd/c;->iv_cashback:I

    .line 266
    .line 267
    invoke-virtual {p1, v1, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 268
    .line 269
    .line 270
    :goto_7
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerLable()Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 275
    .line 276
    .line 277
    move-result v0

    .line 278
    if-nez v0, :cond_b

    .line 279
    .line 280
    sget v0, LPd/c;->iv_label:I

    .line 281
    .line 282
    invoke-virtual {p1, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 283
    .line 284
    .line 285
    move-result-object p1

    .line 286
    check-cast p1, Landroid/widget/ImageView;

    .line 287
    .line 288
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerLable()Ljava/lang/String;

    .line 289
    .line 290
    .line 291
    move-result-object p2

    .line 292
    invoke-static {p2, p1}, LPa/r0;->l1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 293
    .line 294
    .line 295
    :cond_b
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 296
    .line 297
    return-void
.end method
