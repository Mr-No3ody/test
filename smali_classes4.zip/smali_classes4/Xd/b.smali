.class public final LXd/b;
.super LKb/c;
.source "SourceFile"


# instance fields
.field public e:Ljava/lang/String;


# direct methods
.method public static c(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 1
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_1

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v1, 0x2

    .line 12
    if-ge v0, v1, :cond_0

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    const/4 v2, 0x1

    .line 22
    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    :cond_1
    :goto_0
    return-object p0
.end method


# virtual methods
.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 6

    .line 1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-ge p2, v0, :cond_d

    .line 8
    .line 9
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 10
    .line 11
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;

    .line 16
    .line 17
    check-cast p1, LXd/a;

    .line 18
    .line 19
    invoke-virtual {p0}, LKb/c;->getItemCount()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    const/4 v2, 0x1

    .line 24
    sub-int/2addr v1, v2

    .line 25
    const/4 v3, 0x0

    .line 26
    if-ne p2, v1, :cond_0

    .line 27
    .line 28
    move v1, v2

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    move v1, v3

    .line 31
    :goto_0
    invoke-virtual {p0}, LKb/c;->getItemCount()I

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    if-ne v4, v2, :cond_1

    .line 36
    .line 37
    iget-object p2, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 38
    .line 39
    sget v4, Lcom/transsnet/palmpay/custom_view/r;->cv_shape_rect_corner_12_bg_white:I

    .line 40
    .line 41
    invoke-virtual {p2, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_1
    if-nez p2, :cond_2

    .line 46
    .line 47
    iget-object p2, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 48
    .line 49
    sget v4, Lcom/transsnet/palmpay/custom_view/r;->cv_rect_corner_tl_tr_12_bg_white:I

    .line 50
    .line 51
    invoke-virtual {p2, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 52
    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_2
    if-eqz v1, :cond_3

    .line 56
    .line 57
    iget-object p2, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 58
    .line 59
    sget v4, Lcom/transsnet/palmpay/custom_view/r;->cv_rect_corner_bl_br_12_bg_white:I

    .line 60
    .line 61
    invoke-virtual {p2, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 62
    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_3
    iget-object p2, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 66
    .line 67
    sget v4, LL6/b;->ppColorBackgroundLight:I

    .line 68
    .line 69
    invoke-virtual {p2, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 70
    .line 71
    .line 72
    :goto_1
    iget-object p2, p1, LXd/a;->o:Landroid/view/View;

    .line 73
    .line 74
    if-eqz v1, :cond_4

    .line 75
    .line 76
    const/4 v1, 0x4

    .line 77
    goto :goto_2

    .line 78
    :cond_4
    move v1, v3

    .line 79
    :goto_2
    invoke-virtual {p2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 80
    .line 81
    .line 82
    iget-object p2, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->billerName:Ljava/lang/String;

    .line 83
    .line 84
    iget-object v1, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->paymentItemName:Ljava/lang/String;

    .line 85
    .line 86
    sget-object v4, Lee/c;->a:Ljava/lang/String;

    .line 87
    .line 88
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 89
    .line 90
    .line 91
    move-result v4

    .line 92
    const-string v5, ""

    .line 93
    .line 94
    if-eqz v4, :cond_5

    .line 95
    .line 96
    if-nez p2, :cond_8

    .line 97
    .line 98
    move-object p2, v5

    .line 99
    goto :goto_3

    .line 100
    :cond_5
    if-nez p2, :cond_6

    .line 101
    .line 102
    move-object p2, v5

    .line 103
    :cond_6
    if-nez v1, :cond_7

    .line 104
    .line 105
    move-object v1, v5

    .line 106
    :cond_7
    const-string v4, "-"

    .line 107
    .line 108
    invoke-static {p2, v4, v1}, LN8/q0;->y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object p2

    .line 112
    :cond_8
    :goto_3
    iget-object v1, p1, LXd/a;->e:Landroid/widget/TextView;

    .line 113
    .line 114
    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 115
    .line 116
    .line 117
    new-instance p2, Ljava/lang/StringBuilder;

    .line 118
    .line 119
    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 120
    .line 121
    .line 122
    iget-object v1, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->customerId:Ljava/lang/String;

    .line 123
    .line 124
    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 125
    .line 126
    .line 127
    const-string v1, "("

    .line 128
    .line 129
    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 130
    .line 131
    .line 132
    iget-object v1, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->fullName:Ljava/lang/String;

    .line 133
    .line 134
    const-string v4, ")"

    .line 135
    .line 136
    invoke-static {p2, v1, v4}, LC0/G;->r(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object p2

    .line 140
    iget-object v1, p1, LXd/a;->d:Landroid/widget/TextView;

    .line 141
    .line 142
    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 143
    .line 144
    .line 145
    iget-object p2, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->icon:Ljava/lang/String;

    .line 146
    .line 147
    iget v1, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->reminder:I

    .line 148
    .line 149
    iget-object v4, p1, LXd/a;->i:Landroidx/constraintlayout/widget/Group;

    .line 150
    .line 151
    if-nez v1, :cond_9

    .line 152
    .line 153
    const/16 v0, 0x8

    .line 154
    .line 155
    invoke-virtual {v4, v0}, Landroidx/constraintlayout/widget/Group;->setVisibility(I)V

    .line 156
    .line 157
    .line 158
    goto :goto_4

    .line 159
    :cond_9
    invoke-virtual {v4, v3}, Landroidx/constraintlayout/widget/Group;->setVisibility(I)V

    .line 160
    .line 161
    .line 162
    const-string v1, "week"

    .line 163
    .line 164
    iget-object v3, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->remindPeriod:Ljava/lang/String;

    .line 165
    .line 166
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result v1

    .line 170
    iget-object v3, p0, LKb/c;->a:Landroid/content/Context;

    .line 171
    .line 172
    iget-object v4, p1, LXd/a;->j:Landroid/widget/TextView;

    .line 173
    .line 174
    if-eqz v1, :cond_a

    .line 175
    .line 176
    sget v1, Lba/k;->core_week_remind_x:I

    .line 177
    .line 178
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->remindTime:Ljava/lang/String;

    .line 179
    .line 180
    invoke-static {v0}, LXd/b;->c(Ljava/lang/String;)Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    invoke-virtual {v3, v1, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 193
    .line 194
    .line 195
    goto :goto_4

    .line 196
    :cond_a
    const-string v1, "day"

    .line 197
    .line 198
    iget-object v5, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->remindPeriod:Ljava/lang/String;

    .line 199
    .line 200
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 201
    .line 202
    .line 203
    move-result v1

    .line 204
    if-eqz v1, :cond_b

    .line 205
    .line 206
    sget v1, Lba/k;->core_day_remind_x:I

    .line 207
    .line 208
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->remindTime:Ljava/lang/String;

    .line 209
    .line 210
    invoke-static {v0}, LXd/b;->c(Ljava/lang/String;)Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    invoke-virtual {v3, v1, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 223
    .line 224
    .line 225
    goto :goto_4

    .line 226
    :cond_b
    sget v1, Lba/k;->core_month_remind_x:I

    .line 227
    .line 228
    iget-object v0, v0, Lcom/transsnet/palmpay/core/bean/CloseContactBean;->remindTime:Ljava/lang/String;

    .line 229
    .line 230
    invoke-static {v0}, LPa/i0;->z(Ljava/lang/String;)Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    invoke-virtual {v3, v1, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 243
    .line 244
    .line 245
    :goto_4
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 246
    .line 247
    .line 248
    move-result v0

    .line 249
    iget-object p1, p1, LXd/a;->f:Landroid/widget/ImageView;

    .line 250
    .line 251
    const/high16 v1, 0x40800000    # 4.0f

    .line 252
    .line 253
    if-eqz v0, :cond_c

    .line 254
    .line 255
    iget-object p2, p0, LXd/b;->e:Ljava/lang/String;

    .line 256
    .line 257
    invoke-static {p2}, Lee/c;->f(Ljava/lang/String;)Landroid/net/Uri;

    .line 258
    .line 259
    .line 260
    move-result-object p2

    .line 261
    invoke-static {p1}, Lcom/bumptech/glide/b;->f(Landroid/view/View;)Lcom/bumptech/glide/p;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    invoke-virtual {v0, p2}, Lcom/bumptech/glide/p;->j(Landroid/net/Uri;)Lcom/bumptech/glide/m;

    .line 266
    .line 267
    .line 268
    move-result-object p2

    .line 269
    new-instance v0, LG1/d;

    .line 270
    .line 271
    invoke-direct {v0}, LG1/a;-><init>()V

    .line 272
    .line 273
    .line 274
    new-instance v3, Lcom/bumptech/glide/load/resource/bitmap/z;

    .line 275
    .line 276
    invoke-static {v1}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 277
    .line 278
    .line 279
    move-result v1

    .line 280
    invoke-direct {v3, v1}, Lcom/bumptech/glide/load/resource/bitmap/z;-><init>(I)V

    .line 281
    .line 282
    .line 283
    invoke-virtual {v0, v3, v2}, LG1/a;->I(Lcom/bumptech/glide/load/Transformation;Z)LG1/a;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    invoke-virtual {p2, v0}, Lcom/bumptech/glide/m;->O(LG1/a;)Lcom/bumptech/glide/m;

    .line 288
    .line 289
    .line 290
    move-result-object p2

    .line 291
    invoke-virtual {p2, p1}, Lcom/bumptech/glide/m;->S(Landroid/widget/ImageView;)V

    .line 292
    .line 293
    .line 294
    return-void

    .line 295
    :cond_c
    invoke-static {p1}, Lcom/bumptech/glide/b;->f(Landroid/view/View;)Lcom/bumptech/glide/p;

    .line 296
    .line 297
    .line 298
    move-result-object v0

    .line 299
    invoke-virtual {v0, p2}, Lcom/bumptech/glide/p;->n(Ljava/lang/String;)Lcom/bumptech/glide/m;

    .line 300
    .line 301
    .line 302
    move-result-object p2

    .line 303
    new-instance v0, LG1/d;

    .line 304
    .line 305
    invoke-direct {v0}, LG1/a;-><init>()V

    .line 306
    .line 307
    .line 308
    new-instance v3, Lcom/bumptech/glide/load/resource/bitmap/z;

    .line 309
    .line 310
    invoke-static {v1}, Lcom/transsnet/palmpay/util/SizeUtils;->dp2px(F)I

    .line 311
    .line 312
    .line 313
    move-result v1

    .line 314
    invoke-direct {v3, v1}, Lcom/bumptech/glide/load/resource/bitmap/z;-><init>(I)V

    .line 315
    .line 316
    .line 317
    invoke-virtual {v0, v3, v2}, LG1/a;->I(Lcom/bumptech/glide/load/Transformation;Z)LG1/a;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    invoke-virtual {p2, v0}, Lcom/bumptech/glide/m;->O(LG1/a;)Lcom/bumptech/glide/m;

    .line 322
    .line 323
    .line 324
    move-result-object p2

    .line 325
    invoke-virtual {p2, p1}, Lcom/bumptech/glide/m;->S(Landroid/widget/ImageView;)V

    .line 326
    .line 327
    .line 328
    :cond_d
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    .line 1
    new-instance p2, LXd/a;

    .line 2
    .line 3
    iget-object v0, p0, LKb/c;->a:Landroid/content/Context;

    .line 4
    .line 5
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sget v1, LPd/d;->qt_betting_beneficiaries_item:I

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-direct {p2, p0, p1}, LKb/b;-><init>(LKb/c;Landroid/view/View;)V

    .line 17
    .line 18
    .line 19
    sget v0, LPd/c;->mbri_title_tv:I

    .line 20
    .line 21
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/widget/TextView;

    .line 26
    .line 27
    iput-object v0, p2, LXd/a;->d:Landroid/widget/TextView;

    .line 28
    .line 29
    sget v0, LPd/c;->mbri_time_tv:I

    .line 30
    .line 31
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Landroid/widget/TextView;

    .line 36
    .line 37
    iput-object v0, p2, LXd/a;->e:Landroid/widget/TextView;

    .line 38
    .line 39
    sget v0, LPd/c;->mbri_iv:I

    .line 40
    .line 41
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    check-cast v0, Landroid/widget/ImageView;

    .line 46
    .line 47
    iput-object v0, p2, LXd/a;->f:Landroid/widget/ImageView;

    .line 48
    .line 49
    sget v0, LPd/c;->qbbi_remind_time_item:I

    .line 50
    .line 51
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    check-cast v0, Landroidx/constraintlayout/widget/Group;

    .line 56
    .line 57
    iput-object v0, p2, LXd/a;->i:Landroidx/constraintlayout/widget/Group;

    .line 58
    .line 59
    sget v0, LPd/c;->qbbi_time_tv:I

    .line 60
    .line 61
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    check-cast v0, Landroid/widget/TextView;

    .line 66
    .line 67
    iput-object v0, p2, LXd/a;->j:Landroid/widget/TextView;

    .line 68
    .line 69
    sget v0, LPd/c;->mbri_more_iv:I

    .line 70
    .line 71
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    iput-object v0, p2, LXd/a;->g:Landroid/view/View;

    .line 76
    .line 77
    sget v1, LPd/c;->mbri_divide_view:I

    .line 78
    .line 79
    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    iput-object v1, p2, LXd/a;->o:Landroid/view/View;

    .line 84
    .line 85
    sget v1, LPd/c;->mbri_root:I

    .line 86
    .line 87
    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    invoke-virtual {p2, p1}, LKb/b;->a(Landroid/view/View;)V

    .line 92
    .line 93
    .line 94
    invoke-virtual {p2, v0}, LKb/b;->a(Landroid/view/View;)V

    .line 95
    .line 96
    .line 97
    return-object p2
.end method
