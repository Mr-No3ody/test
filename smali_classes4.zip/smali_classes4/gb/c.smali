.class public final Lgb/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final A:Landroid/widget/TextView;

.field public final B:Landroid/widget/TextView;

.field public final C:Landroid/widget/TextView;

.field public final a:Landroid/widget/LinearLayout;

.field public final b:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final c:Landroid/widget/LinearLayout;

.field public final d:Landroid/widget/LinearLayout;

.field public final e:Landroid/widget/TextView;

.field public final f:Landroid/widget/TextView;

.field public final g:Landroid/widget/TextView;

.field public final i:Landroid/widget/TextView;

.field public final j:Landroid/widget/TextView;

.field public final o:Landroid/widget/TextView;

.field public final p:Landroid/widget/TextView;

.field public final t:Landroid/widget/TextView;

.field public final v:Landroid/widget/TextView;

.field public final w:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/widget/LinearLayout;Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lgb/c;->a:Landroid/widget/LinearLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lgb/c;->b:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 7
    .line 8
    iput-object p3, p0, Lgb/c;->c:Landroid/widget/LinearLayout;

    .line 9
    .line 10
    iput-object p4, p0, Lgb/c;->d:Landroid/widget/LinearLayout;

    .line 11
    .line 12
    iput-object p5, p0, Lgb/c;->e:Landroid/widget/TextView;

    .line 13
    .line 14
    iput-object p6, p0, Lgb/c;->f:Landroid/widget/TextView;

    .line 15
    .line 16
    iput-object p7, p0, Lgb/c;->g:Landroid/widget/TextView;

    .line 17
    .line 18
    iput-object p8, p0, Lgb/c;->i:Landroid/widget/TextView;

    .line 19
    .line 20
    iput-object p9, p0, Lgb/c;->j:Landroid/widget/TextView;

    .line 21
    .line 22
    iput-object p10, p0, Lgb/c;->o:Landroid/widget/TextView;

    .line 23
    .line 24
    iput-object p11, p0, Lgb/c;->p:Landroid/widget/TextView;

    .line 25
    .line 26
    iput-object p12, p0, Lgb/c;->t:Landroid/widget/TextView;

    .line 27
    .line 28
    iput-object p13, p0, Lgb/c;->v:Landroid/widget/TextView;

    .line 29
    .line 30
    iput-object p14, p0, Lgb/c;->w:Landroid/widget/TextView;

    .line 31
    .line 32
    iput-object p15, p0, Lgb/c;->A:Landroid/widget/TextView;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lgb/c;->B:Landroid/widget/TextView;

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, Lgb/c;->C:Landroid/widget/TextView;

    .line 41
    .line 42
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lgb/c;->a:Landroid/widget/LinearLayout;

    .line 2
    .line 3
    return-object v0
.end method
