.class public final Lgb/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final a:Lcom/transsnet/palmpay/custom_view/ReboundScrollView;

.field public final b:Lcom/transsnet/adsdk/widgets/SingleAdView;

.field public final c:Lcom/transsnet/adsdk/widgets/banner/BannerAdView;

.field public final d:Landroid/view/ViewStub;

.field public final e:Lcom/transsnet/palmpay/credit/view/KingKongContentInfoView;

.field public final f:Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;

.field public final g:Lcom/transsnet/palmpay/credit/ui/view/NotifyInfoView;

.field public final i:Lcom/transsnet/palmpay/credit/view/ProductContentListView;

.field public final j:Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/custom_view/ReboundScrollView;Lcom/transsnet/adsdk/widgets/SingleAdView;Lcom/transsnet/adsdk/widgets/banner/BannerAdView;Landroid/view/ViewStub;Lcom/transsnet/palmpay/credit/view/KingKongContentInfoView;Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;Lcom/transsnet/palmpay/credit/ui/view/NotifyInfoView;Lcom/transsnet/palmpay/credit/view/ProductContentListView;Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lgb/g;->a:Lcom/transsnet/palmpay/custom_view/ReboundScrollView;

    .line 5
    .line 6
    iput-object p2, p0, Lgb/g;->b:Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 7
    .line 8
    iput-object p3, p0, Lgb/g;->c:Lcom/transsnet/adsdk/widgets/banner/BannerAdView;

    .line 9
    .line 10
    iput-object p4, p0, Lgb/g;->d:Landroid/view/ViewStub;

    .line 11
    .line 12
    iput-object p5, p0, Lgb/g;->e:Lcom/transsnet/palmpay/credit/view/KingKongContentInfoView;

    .line 13
    .line 14
    iput-object p6, p0, Lgb/g;->f:Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;

    .line 15
    .line 16
    iput-object p7, p0, Lgb/g;->g:Lcom/transsnet/palmpay/credit/ui/view/NotifyInfoView;

    .line 17
    .line 18
    iput-object p8, p0, Lgb/g;->i:Lcom/transsnet/palmpay/credit/view/ProductContentListView;

    .line 19
    .line 20
    iput-object p9, p0, Lgb/g;->j:Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lgb/g;->a:Lcom/transsnet/palmpay/custom_view/ReboundScrollView;

    .line 2
    .line 3
    return-object v0
.end method
