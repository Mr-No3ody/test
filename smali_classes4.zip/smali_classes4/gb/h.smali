.class public final Lgb/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final b:Lcom/palmpay/lib/ui/button/PpButton;

.field public final c:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

.field public final d:Landroid/widget/TextView;

.field public final e:Landroid/widget/TextView;

.field public final f:Landroid/widget/TextView;

.field public final g:Landroid/widget/TextView;

.field public final i:Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;


# direct methods
.method public constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;Lcom/palmpay/lib/ui/button/PpButton;Lcom/palmpay/lib/ui/titlebar/PpTitleBar;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lgb/h;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lgb/h;->b:Lcom/palmpay/lib/ui/button/PpButton;

    .line 7
    .line 8
    iput-object p3, p0, Lgb/h;->c:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 9
    .line 10
    iput-object p4, p0, Lgb/h;->d:Landroid/widget/TextView;

    .line 11
    .line 12
    iput-object p5, p0, Lgb/h;->e:Landroid/widget/TextView;

    .line 13
    .line 14
    iput-object p6, p0, Lgb/h;->f:Landroid/widget/TextView;

    .line 15
    .line 16
    iput-object p7, p0, Lgb/h;->g:Landroid/widget/TextView;

    .line 17
    .line 18
    iput-object p8, p0, Lgb/h;->i:Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lgb/h;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2
    .line 3
    return-object v0
.end method
