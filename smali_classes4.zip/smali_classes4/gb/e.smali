.class public final Lgb/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final A:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final A0:Landroid/widget/TextView;

.field public final B:Landroid/widget/LinearLayout;

.field public final B0:Landroid/widget/TextView;

.field public final C:Landroid/widget/LinearLayout;

.field public final C0:Landroid/widget/TextView;

.field public final D0:Landroidx/appcompat/widget/AppCompatTextView;

.field public final E0:Landroidx/appcompat/widget/AppCompatTextView;

.field public final F0:Landroidx/appcompat/widget/AppCompatTextView;

.field public final G0:Lcom/mikepenz/iconics/view/IconicsTextView;

.field public final H:Landroid/widget/LinearLayout;

.field public final H0:Landroid/widget/TextView;

.field public final I0:Landroid/widget/TextView;

.field public final J0:Landroid/widget/TextView;

.field public final K0:Landroid/widget/TextView;

.field public final L:Landroid/widget/LinearLayout;

.field public final L0:Landroid/widget/TextView;

.field public final M:Landroid/widget/LinearLayout;

.field public final M0:Landroid/widget/TextView;

.field public final N0:Landroid/widget/TextView;

.field public final O0:Landroid/view/View;

.field public final Q:Landroid/widget/LinearLayout;

.field public final X:Landroid/widget/RelativeLayout;

.field public final Y:Landroid/widget/TextView;

.field public final Z:Landroid/widget/TextView;

.field public final a:Landroid/view/View;

.field public final b:Landroid/widget/LinearLayout;

.field public final c:Landroid/widget/TextView;

.field public final d:Landroid/widget/TextView;

.field public final e:Landroid/widget/LinearLayout;

.field public final f:Landroid/widget/ImageView;

.field public final g:Landroid/widget/ImageView;

.field public final i:Landroid/widget/ImageView;

.field public final j:Landroid/widget/ImageView;

.field public final k0:Landroid/widget/TextView;

.field public final o:Landroid/widget/ImageView;

.field public final p:Landroid/widget/ImageView;

.field public final p0:Landroid/widget/TextView;

.field public final q0:Landroid/widget/TextView;

.field public final r0:Landroid/widget/TextView;

.field public final s0:Landroid/widget/TextView;

.field public final t:Landroid/widget/ImageView;

.field public final t0:Landroidx/appcompat/widget/AppCompatTextView;

.field public final u0:Landroidx/appcompat/widget/AppCompatTextView;

.field public final v:Landroid/widget/ImageView;

.field public final v0:Landroidx/appcompat/widget/AppCompatTextView;

.field public final w:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final w0:Landroid/widget/TextView;

.field public final x0:Landroid/widget/TextView;

.field public final y0:Landroid/widget/TextView;

.field public final z0:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/view/View;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroidx/constraintlayout/widget/ConstraintLayout;Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/RelativeLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Landroidx/appcompat/widget/AppCompatTextView;Lcom/mikepenz/iconics/view/IconicsTextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lgb/e;->a:Landroid/view/View;

    .line 3
    iput-object p2, p0, Lgb/e;->b:Landroid/widget/LinearLayout;

    .line 4
    iput-object p3, p0, Lgb/e;->c:Landroid/widget/TextView;

    .line 5
    iput-object p4, p0, Lgb/e;->d:Landroid/widget/TextView;

    .line 6
    iput-object p5, p0, Lgb/e;->e:Landroid/widget/LinearLayout;

    .line 7
    iput-object p6, p0, Lgb/e;->f:Landroid/widget/ImageView;

    .line 8
    iput-object p7, p0, Lgb/e;->g:Landroid/widget/ImageView;

    .line 9
    iput-object p8, p0, Lgb/e;->i:Landroid/widget/ImageView;

    .line 10
    iput-object p9, p0, Lgb/e;->j:Landroid/widget/ImageView;

    .line 11
    iput-object p10, p0, Lgb/e;->o:Landroid/widget/ImageView;

    .line 12
    iput-object p11, p0, Lgb/e;->p:Landroid/widget/ImageView;

    .line 13
    iput-object p12, p0, Lgb/e;->t:Landroid/widget/ImageView;

    .line 14
    iput-object p13, p0, Lgb/e;->v:Landroid/widget/ImageView;

    .line 15
    iput-object p14, p0, Lgb/e;->w:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 16
    iput-object p15, p0, Lgb/e;->A:Landroidx/constraintlayout/widget/ConstraintLayout;

    move-object/from16 p1, p16

    .line 17
    iput-object p1, p0, Lgb/e;->B:Landroid/widget/LinearLayout;

    move-object/from16 p1, p17

    .line 18
    iput-object p1, p0, Lgb/e;->C:Landroid/widget/LinearLayout;

    move-object/from16 p1, p18

    .line 19
    iput-object p1, p0, Lgb/e;->H:Landroid/widget/LinearLayout;

    move-object/from16 p1, p19

    .line 20
    iput-object p1, p0, Lgb/e;->L:Landroid/widget/LinearLayout;

    move-object/from16 p1, p20

    .line 21
    iput-object p1, p0, Lgb/e;->M:Landroid/widget/LinearLayout;

    move-object/from16 p1, p21

    .line 22
    iput-object p1, p0, Lgb/e;->Q:Landroid/widget/LinearLayout;

    move-object/from16 p1, p22

    .line 23
    iput-object p1, p0, Lgb/e;->X:Landroid/widget/RelativeLayout;

    move-object/from16 p1, p23

    .line 24
    iput-object p1, p0, Lgb/e;->Y:Landroid/widget/TextView;

    move-object/from16 p1, p24

    .line 25
    iput-object p1, p0, Lgb/e;->Z:Landroid/widget/TextView;

    move-object/from16 p1, p25

    .line 26
    iput-object p1, p0, Lgb/e;->k0:Landroid/widget/TextView;

    move-object/from16 p1, p26

    .line 27
    iput-object p1, p0, Lgb/e;->p0:Landroid/widget/TextView;

    move-object/from16 p1, p27

    .line 28
    iput-object p1, p0, Lgb/e;->q0:Landroid/widget/TextView;

    move-object/from16 p1, p28

    .line 29
    iput-object p1, p0, Lgb/e;->r0:Landroid/widget/TextView;

    move-object/from16 p1, p29

    .line 30
    iput-object p1, p0, Lgb/e;->s0:Landroid/widget/TextView;

    move-object/from16 p1, p30

    .line 31
    iput-object p1, p0, Lgb/e;->t0:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p31

    .line 32
    iput-object p1, p0, Lgb/e;->u0:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p32

    .line 33
    iput-object p1, p0, Lgb/e;->v0:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p33

    .line 34
    iput-object p1, p0, Lgb/e;->w0:Landroid/widget/TextView;

    move-object/from16 p1, p34

    .line 35
    iput-object p1, p0, Lgb/e;->x0:Landroid/widget/TextView;

    move-object/from16 p1, p35

    .line 36
    iput-object p1, p0, Lgb/e;->y0:Landroid/widget/TextView;

    move-object/from16 p1, p36

    .line 37
    iput-object p1, p0, Lgb/e;->z0:Landroid/widget/TextView;

    move-object/from16 p1, p37

    .line 38
    iput-object p1, p0, Lgb/e;->A0:Landroid/widget/TextView;

    move-object/from16 p1, p38

    .line 39
    iput-object p1, p0, Lgb/e;->B0:Landroid/widget/TextView;

    move-object/from16 p1, p39

    .line 40
    iput-object p1, p0, Lgb/e;->C0:Landroid/widget/TextView;

    move-object/from16 p1, p40

    .line 41
    iput-object p1, p0, Lgb/e;->D0:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p41

    .line 42
    iput-object p1, p0, Lgb/e;->E0:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p42

    .line 43
    iput-object p1, p0, Lgb/e;->F0:Landroidx/appcompat/widget/AppCompatTextView;

    move-object/from16 p1, p43

    .line 44
    iput-object p1, p0, Lgb/e;->G0:Lcom/mikepenz/iconics/view/IconicsTextView;

    move-object/from16 p1, p44

    .line 45
    iput-object p1, p0, Lgb/e;->H0:Landroid/widget/TextView;

    move-object/from16 p1, p45

    .line 46
    iput-object p1, p0, Lgb/e;->I0:Landroid/widget/TextView;

    move-object/from16 p1, p46

    .line 47
    iput-object p1, p0, Lgb/e;->J0:Landroid/widget/TextView;

    move-object/from16 p1, p47

    .line 48
    iput-object p1, p0, Lgb/e;->K0:Landroid/widget/TextView;

    move-object/from16 p1, p48

    .line 49
    iput-object p1, p0, Lgb/e;->L0:Landroid/widget/TextView;

    move-object/from16 p1, p49

    .line 50
    iput-object p1, p0, Lgb/e;->M0:Landroid/widget/TextView;

    move-object/from16 p1, p50

    .line 51
    iput-object p1, p0, Lgb/e;->N0:Landroid/widget/TextView;

    move-object/from16 p1, p51

    .line 52
    iput-object p1, p0, Lgb/e;->O0:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lgb/e;->a:Landroid/view/View;

    .line 2
    .line 3
    return-object v0
.end method
