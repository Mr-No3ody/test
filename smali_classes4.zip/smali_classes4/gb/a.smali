.class public final Lgb/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final a:Landroid/widget/LinearLayout;

.field public final b:Landroid/widget/TextView;

.field public final c:Landroid/widget/TextView;

.field public final d:Landroid/widget/ImageView;

.field public final e:Landroid/widget/TextView;

.field public final f:Landroid/view/View;

.field public final g:Landroid/view/View;

.field public final i:Landroidx/viewpager2/widget/ViewPager2;

.field public final j:Lcom/transsnet/palmpay/custom_view/CircleProgressView;


# direct methods
.method public constructor <init>(Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/widget/TextView;Landroid/view/View;Landroid/view/View;Landroidx/viewpager2/widget/ViewPager2;Lcom/transsnet/palmpay/custom_view/CircleProgressView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lgb/a;->a:Landroid/widget/LinearLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lgb/a;->b:Landroid/widget/TextView;

    .line 7
    .line 8
    iput-object p3, p0, Lgb/a;->c:Landroid/widget/TextView;

    .line 9
    .line 10
    iput-object p4, p0, Lgb/a;->d:Landroid/widget/ImageView;

    .line 11
    .line 12
    iput-object p5, p0, Lgb/a;->e:Landroid/widget/TextView;

    .line 13
    .line 14
    iput-object p6, p0, Lgb/a;->f:Landroid/view/View;

    .line 15
    .line 16
    iput-object p7, p0, Lgb/a;->g:Landroid/view/View;

    .line 17
    .line 18
    iput-object p8, p0, Lgb/a;->i:Landroidx/viewpager2/widget/ViewPager2;

    .line 19
    .line 20
    iput-object p9, p0, Lgb/a;->j:Lcom/transsnet/palmpay/custom_view/CircleProgressView;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lgb/a;->a:Landroid/widget/LinearLayout;

    .line 2
    .line 3
    return-object v0
.end method
