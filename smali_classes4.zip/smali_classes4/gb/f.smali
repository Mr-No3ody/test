.class public final Lgb/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final bottomBarrier:Landroidx/constraintlayout/widget/Barrier;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final divideLine:Lcom/transsnet/palmpay/credit/view/DashLine;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final ivAmountIcon:Landroid/widget/ImageView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final ivArrowRight:Landroid/widget/ImageView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final ivTitleIcon:Landroid/widget/ImageView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final ivWaiverAmountIcon:Landroid/widget/ImageView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final layoutWaiver:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final layoutWaiverAmountRow:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final llCountdownHms:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final repayBtn:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final repayBtn2:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final repayBtnContainer:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final repayBtnContainer2:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final rootOutstandingView:Landroidx/constraintlayout/widget/ConstraintLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final rootView:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field private final rootView_:Landroid/widget/LinearLayout;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final rvOutstandingDetail:Landroidx/recyclerview/widget/RecyclerView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final space:Landroid/widget/Space;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final topLine:Landroid/view/View;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvCountdownDayHour:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvCountdownHour:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvCountdownMinute:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvCountdownSecond:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvCouponAmount:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvOutstandingAmount:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvRepaymentDate:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvRepaymentIcon:Landroid/widget/ImageView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvSubtitle:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvTitle:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvWaiverAmountLabel:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvWaiverBadge:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvWaiverCurrentAmount:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final tvWaiverSummary:Landroid/widget/TextView;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field


# direct methods
.method private constructor <init>(Landroid/widget/LinearLayout;Landroidx/constraintlayout/widget/Barrier;Lcom/transsnet/palmpay/credit/view/DashLine;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/widget/LinearLayout;Landroidx/recyclerview/widget/RecyclerView;Landroid/widget/Space;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 0
    .param p1    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2    # Landroidx/constraintlayout/widget/Barrier;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p3    # Lcom/transsnet/palmpay/credit/view/DashLine;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p4    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p5    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p6    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p7    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p8    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p9    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p10    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p11    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p12    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p13    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p14    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p15    # Landroidx/constraintlayout/widget/ConstraintLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p16    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p17    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p18    # Landroid/widget/Space;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p19    # Landroid/view/View;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p20    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p21    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p22    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p23    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p24    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p25    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p26    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p27    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p28    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p29    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p30    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p31    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p32    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p33    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lgb/f;->rootView_:Landroid/widget/LinearLayout;

    .line 3
    iput-object p2, p0, Lgb/f;->bottomBarrier:Landroidx/constraintlayout/widget/Barrier;

    .line 4
    iput-object p3, p0, Lgb/f;->divideLine:Lcom/transsnet/palmpay/credit/view/DashLine;

    .line 5
    iput-object p4, p0, Lgb/f;->ivAmountIcon:Landroid/widget/ImageView;

    .line 6
    iput-object p5, p0, Lgb/f;->ivArrowRight:Landroid/widget/ImageView;

    .line 7
    iput-object p6, p0, Lgb/f;->ivTitleIcon:Landroid/widget/ImageView;

    .line 8
    iput-object p7, p0, Lgb/f;->ivWaiverAmountIcon:Landroid/widget/ImageView;

    .line 9
    iput-object p8, p0, Lgb/f;->layoutWaiver:Landroid/widget/LinearLayout;

    .line 10
    iput-object p9, p0, Lgb/f;->layoutWaiverAmountRow:Landroid/widget/LinearLayout;

    .line 11
    iput-object p10, p0, Lgb/f;->llCountdownHms:Landroid/widget/LinearLayout;

    .line 12
    iput-object p11, p0, Lgb/f;->repayBtn:Landroid/widget/TextView;

    .line 13
    iput-object p12, p0, Lgb/f;->repayBtn2:Landroid/widget/TextView;

    .line 14
    iput-object p13, p0, Lgb/f;->repayBtnContainer:Landroid/widget/LinearLayout;

    .line 15
    iput-object p14, p0, Lgb/f;->repayBtnContainer2:Landroid/widget/LinearLayout;

    .line 16
    iput-object p15, p0, Lgb/f;->rootOutstandingView:Landroidx/constraintlayout/widget/ConstraintLayout;

    move-object/from16 p1, p16

    .line 17
    iput-object p1, p0, Lgb/f;->rootView:Landroid/widget/LinearLayout;

    move-object/from16 p1, p17

    .line 18
    iput-object p1, p0, Lgb/f;->rvOutstandingDetail:Landroidx/recyclerview/widget/RecyclerView;

    move-object/from16 p1, p18

    .line 19
    iput-object p1, p0, Lgb/f;->space:Landroid/widget/Space;

    move-object/from16 p1, p19

    .line 20
    iput-object p1, p0, Lgb/f;->topLine:Landroid/view/View;

    move-object/from16 p1, p20

    .line 21
    iput-object p1, p0, Lgb/f;->tvCountdownDayHour:Landroid/widget/TextView;

    move-object/from16 p1, p21

    .line 22
    iput-object p1, p0, Lgb/f;->tvCountdownHour:Landroid/widget/TextView;

    move-object/from16 p1, p22

    .line 23
    iput-object p1, p0, Lgb/f;->tvCountdownMinute:Landroid/widget/TextView;

    move-object/from16 p1, p23

    .line 24
    iput-object p1, p0, Lgb/f;->tvCountdownSecond:Landroid/widget/TextView;

    move-object/from16 p1, p24

    .line 25
    iput-object p1, p0, Lgb/f;->tvCouponAmount:Landroid/widget/TextView;

    move-object/from16 p1, p25

    .line 26
    iput-object p1, p0, Lgb/f;->tvOutstandingAmount:Landroid/widget/TextView;

    move-object/from16 p1, p26

    .line 27
    iput-object p1, p0, Lgb/f;->tvRepaymentDate:Landroid/widget/TextView;

    move-object/from16 p1, p27

    .line 28
    iput-object p1, p0, Lgb/f;->tvRepaymentIcon:Landroid/widget/ImageView;

    move-object/from16 p1, p28

    .line 29
    iput-object p1, p0, Lgb/f;->tvSubtitle:Landroid/widget/TextView;

    move-object/from16 p1, p29

    .line 30
    iput-object p1, p0, Lgb/f;->tvTitle:Landroid/widget/TextView;

    move-object/from16 p1, p30

    .line 31
    iput-object p1, p0, Lgb/f;->tvWaiverAmountLabel:Landroid/widget/TextView;

    move-object/from16 p1, p31

    .line 32
    iput-object p1, p0, Lgb/f;->tvWaiverBadge:Landroid/widget/TextView;

    move-object/from16 p1, p32

    .line 33
    iput-object p1, p0, Lgb/f;->tvWaiverCurrentAmount:Landroid/widget/TextView;

    move-object/from16 p1, p33

    .line 34
    iput-object p1, p0, Lgb/f;->tvWaiverSummary:Landroid/widget/TextView;

    return-void
.end method

.method public static bind(Landroid/view/View;)Lgb/f;
    .locals 37
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget v1, LYa/e;->bottomBarrier:I

    .line 4
    .line 5
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    move-object v5, v2

    .line 10
    check-cast v5, Landroidx/constraintlayout/widget/Barrier;

    .line 11
    .line 12
    if-eqz v5, :cond_0

    .line 13
    .line 14
    sget v1, LYa/e;->divideLine:I

    .line 15
    .line 16
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    move-object v6, v2

    .line 21
    check-cast v6, Lcom/transsnet/palmpay/credit/view/DashLine;

    .line 22
    .line 23
    if-eqz v6, :cond_0

    .line 24
    .line 25
    sget v1, LYa/e;->ivAmountIcon:I

    .line 26
    .line 27
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    move-object v7, v2

    .line 32
    check-cast v7, Landroid/widget/ImageView;

    .line 33
    .line 34
    if-eqz v7, :cond_0

    .line 35
    .line 36
    sget v1, LYa/e;->ivArrowRight:I

    .line 37
    .line 38
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    move-object v8, v2

    .line 43
    check-cast v8, Landroid/widget/ImageView;

    .line 44
    .line 45
    if-eqz v8, :cond_0

    .line 46
    .line 47
    sget v1, LYa/e;->ivTitleIcon:I

    .line 48
    .line 49
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    move-object v9, v2

    .line 54
    check-cast v9, Landroid/widget/ImageView;

    .line 55
    .line 56
    if-eqz v9, :cond_0

    .line 57
    .line 58
    sget v1, LYa/e;->ivWaiverAmountIcon:I

    .line 59
    .line 60
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    move-object v10, v2

    .line 65
    check-cast v10, Landroid/widget/ImageView;

    .line 66
    .line 67
    if-eqz v10, :cond_0

    .line 68
    .line 69
    sget v1, LYa/e;->layoutWaiver:I

    .line 70
    .line 71
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    move-object v11, v2

    .line 76
    check-cast v11, Landroid/widget/LinearLayout;

    .line 77
    .line 78
    if-eqz v11, :cond_0

    .line 79
    .line 80
    sget v1, LYa/e;->layoutWaiverAmountRow:I

    .line 81
    .line 82
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    move-object v12, v2

    .line 87
    check-cast v12, Landroid/widget/LinearLayout;

    .line 88
    .line 89
    if-eqz v12, :cond_0

    .line 90
    .line 91
    sget v1, LYa/e;->llCountdownHms:I

    .line 92
    .line 93
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    move-object v13, v2

    .line 98
    check-cast v13, Landroid/widget/LinearLayout;

    .line 99
    .line 100
    if-eqz v13, :cond_0

    .line 101
    .line 102
    sget v1, LYa/e;->repayBtn:I

    .line 103
    .line 104
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    move-object v14, v2

    .line 109
    check-cast v14, Landroid/widget/TextView;

    .line 110
    .line 111
    if-eqz v14, :cond_0

    .line 112
    .line 113
    sget v1, LYa/e;->repayBtn2:I

    .line 114
    .line 115
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    move-object v15, v2

    .line 120
    check-cast v15, Landroid/widget/TextView;

    .line 121
    .line 122
    if-eqz v15, :cond_0

    .line 123
    .line 124
    sget v1, LYa/e;->repayBtnContainer:I

    .line 125
    .line 126
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    move-object/from16 v16, v2

    .line 131
    .line 132
    check-cast v16, Landroid/widget/LinearLayout;

    .line 133
    .line 134
    if-eqz v16, :cond_0

    .line 135
    .line 136
    sget v1, LYa/e;->repayBtnContainer2:I

    .line 137
    .line 138
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    move-object/from16 v17, v2

    .line 143
    .line 144
    check-cast v17, Landroid/widget/LinearLayout;

    .line 145
    .line 146
    if-eqz v17, :cond_0

    .line 147
    .line 148
    sget v1, LYa/e;->rootOutstandingView:I

    .line 149
    .line 150
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    move-object/from16 v18, v2

    .line 155
    .line 156
    check-cast v18, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 157
    .line 158
    if-eqz v18, :cond_0

    .line 159
    .line 160
    move-object v4, v0

    .line 161
    check-cast v4, Landroid/widget/LinearLayout;

    .line 162
    .line 163
    sget v1, LYa/e;->rvOutstandingDetail:I

    .line 164
    .line 165
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 166
    .line 167
    .line 168
    move-result-object v2

    .line 169
    move-object/from16 v20, v2

    .line 170
    .line 171
    check-cast v20, Landroidx/recyclerview/widget/RecyclerView;

    .line 172
    .line 173
    if-eqz v20, :cond_0

    .line 174
    .line 175
    sget v1, LYa/e;->space:I

    .line 176
    .line 177
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 178
    .line 179
    .line 180
    move-result-object v2

    .line 181
    move-object/from16 v21, v2

    .line 182
    .line 183
    check-cast v21, Landroid/widget/Space;

    .line 184
    .line 185
    if-eqz v21, :cond_0

    .line 186
    .line 187
    sget v1, LYa/e;->topLine:I

    .line 188
    .line 189
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 190
    .line 191
    .line 192
    move-result-object v22

    .line 193
    if-eqz v22, :cond_0

    .line 194
    .line 195
    sget v1, LYa/e;->tvCountdownDayHour:I

    .line 196
    .line 197
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 198
    .line 199
    .line 200
    move-result-object v2

    .line 201
    move-object/from16 v23, v2

    .line 202
    .line 203
    check-cast v23, Landroid/widget/TextView;

    .line 204
    .line 205
    if-eqz v23, :cond_0

    .line 206
    .line 207
    sget v1, LYa/e;->tvCountdownHour:I

    .line 208
    .line 209
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 210
    .line 211
    .line 212
    move-result-object v2

    .line 213
    move-object/from16 v24, v2

    .line 214
    .line 215
    check-cast v24, Landroid/widget/TextView;

    .line 216
    .line 217
    if-eqz v24, :cond_0

    .line 218
    .line 219
    sget v1, LYa/e;->tvCountdownMinute:I

    .line 220
    .line 221
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 222
    .line 223
    .line 224
    move-result-object v2

    .line 225
    move-object/from16 v25, v2

    .line 226
    .line 227
    check-cast v25, Landroid/widget/TextView;

    .line 228
    .line 229
    if-eqz v25, :cond_0

    .line 230
    .line 231
    sget v1, LYa/e;->tvCountdownSecond:I

    .line 232
    .line 233
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 234
    .line 235
    .line 236
    move-result-object v2

    .line 237
    move-object/from16 v26, v2

    .line 238
    .line 239
    check-cast v26, Landroid/widget/TextView;

    .line 240
    .line 241
    if-eqz v26, :cond_0

    .line 242
    .line 243
    sget v1, LYa/e;->tvCouponAmount:I

    .line 244
    .line 245
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 246
    .line 247
    .line 248
    move-result-object v2

    .line 249
    move-object/from16 v27, v2

    .line 250
    .line 251
    check-cast v27, Landroid/widget/TextView;

    .line 252
    .line 253
    if-eqz v27, :cond_0

    .line 254
    .line 255
    sget v1, LYa/e;->tvOutstandingAmount:I

    .line 256
    .line 257
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 258
    .line 259
    .line 260
    move-result-object v2

    .line 261
    move-object/from16 v28, v2

    .line 262
    .line 263
    check-cast v28, Landroid/widget/TextView;

    .line 264
    .line 265
    if-eqz v28, :cond_0

    .line 266
    .line 267
    sget v1, LYa/e;->tvRepaymentDate:I

    .line 268
    .line 269
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 270
    .line 271
    .line 272
    move-result-object v2

    .line 273
    move-object/from16 v29, v2

    .line 274
    .line 275
    check-cast v29, Landroid/widget/TextView;

    .line 276
    .line 277
    if-eqz v29, :cond_0

    .line 278
    .line 279
    sget v1, LYa/e;->tvRepaymentIcon:I

    .line 280
    .line 281
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 282
    .line 283
    .line 284
    move-result-object v2

    .line 285
    move-object/from16 v30, v2

    .line 286
    .line 287
    check-cast v30, Landroid/widget/ImageView;

    .line 288
    .line 289
    if-eqz v30, :cond_0

    .line 290
    .line 291
    sget v1, LYa/e;->tvSubtitle:I

    .line 292
    .line 293
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 294
    .line 295
    .line 296
    move-result-object v2

    .line 297
    move-object/from16 v31, v2

    .line 298
    .line 299
    check-cast v31, Landroid/widget/TextView;

    .line 300
    .line 301
    if-eqz v31, :cond_0

    .line 302
    .line 303
    sget v1, LYa/e;->tvTitle:I

    .line 304
    .line 305
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 306
    .line 307
    .line 308
    move-result-object v2

    .line 309
    move-object/from16 v32, v2

    .line 310
    .line 311
    check-cast v32, Landroid/widget/TextView;

    .line 312
    .line 313
    if-eqz v32, :cond_0

    .line 314
    .line 315
    sget v1, LYa/e;->tvWaiverAmountLabel:I

    .line 316
    .line 317
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 318
    .line 319
    .line 320
    move-result-object v2

    .line 321
    move-object/from16 v33, v2

    .line 322
    .line 323
    check-cast v33, Landroid/widget/TextView;

    .line 324
    .line 325
    if-eqz v33, :cond_0

    .line 326
    .line 327
    sget v1, LYa/e;->tvWaiverBadge:I

    .line 328
    .line 329
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 330
    .line 331
    .line 332
    move-result-object v2

    .line 333
    move-object/from16 v34, v2

    .line 334
    .line 335
    check-cast v34, Landroid/widget/TextView;

    .line 336
    .line 337
    if-eqz v34, :cond_0

    .line 338
    .line 339
    sget v1, LYa/e;->tvWaiverCurrentAmount:I

    .line 340
    .line 341
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 342
    .line 343
    .line 344
    move-result-object v2

    .line 345
    move-object/from16 v35, v2

    .line 346
    .line 347
    check-cast v35, Landroid/widget/TextView;

    .line 348
    .line 349
    if-eqz v35, :cond_0

    .line 350
    .line 351
    sget v1, LYa/e;->tvWaiverSummary:I

    .line 352
    .line 353
    invoke-static {v1, v0}, Le1/a;->m(ILandroid/view/View;)Landroid/view/View;

    .line 354
    .line 355
    .line 356
    move-result-object v2

    .line 357
    move-object/from16 v36, v2

    .line 358
    .line 359
    check-cast v36, Landroid/widget/TextView;

    .line 360
    .line 361
    if-eqz v36, :cond_0

    .line 362
    .line 363
    new-instance v3, Lgb/f;

    .line 364
    .line 365
    move-object/from16 v19, v4

    .line 366
    .line 367
    invoke-direct/range {v3 .. v36}, Lgb/f;-><init>(Landroid/widget/LinearLayout;Landroidx/constraintlayout/widget/Barrier;Lcom/transsnet/palmpay/credit/view/DashLine;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/widget/LinearLayout;Landroidx/recyclerview/widget/RecyclerView;Landroid/widget/Space;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V

    .line 368
    .line 369
    .line 370
    return-object v3

    .line 371
    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 372
    .line 373
    .line 374
    move-result-object v0

    .line 375
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 376
    .line 377
    .line 378
    move-result-object v0

    .line 379
    new-instance v1, Ljava/lang/NullPointerException;

    .line 380
    .line 381
    const-string v2, "Missing required view with ID: "

    .line 382
    .line 383
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 384
    .line 385
    .line 386
    move-result-object v0

    .line 387
    invoke-direct {v1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 388
    .line 389
    .line 390
    throw v1
.end method

.method public static inflate(Landroid/view/LayoutInflater;)Lgb/f;
    .locals 2
    .param p0    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 1
    invoke-static {p0, v0, v1}, Lgb/f;->inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lgb/f;

    move-result-object p0

    return-object p0
.end method

.method public static inflate(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Z)Lgb/f;
    .locals 2
    .param p0    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 2
    sget v0, LYa/f;->cs_cl_total_outstanding_view:I

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    if-eqz p2, :cond_0

    .line 3
    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 4
    :cond_0
    invoke-static {p0}, Lgb/f;->bind(Landroid/view/View;)Lgb/f;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public bridge synthetic getRoot()Landroid/view/View;
    .locals 1
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    invoke-virtual {p0}, Lgb/f;->getRoot()Landroid/widget/LinearLayout;

    move-result-object v0

    return-object v0
.end method

.method public getRoot()Landroid/widget/LinearLayout;
    .locals 1
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 2
    iget-object v0, p0, Lgb/f;->rootView_:Landroid/widget/LinearLayout;

    return-object v0
.end method
