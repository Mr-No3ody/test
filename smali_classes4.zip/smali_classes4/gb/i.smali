.class public final Lgb/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final b:Lcom/transsnet/adsdk/widgets/SingleAdView;

.field public final c:Lcom/transsnet/palmpay/custom_view/ReboundScrollView;

.field public final d:Landroid/view/ViewStub;

.field public final e:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

.field public final f:Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;

.field public final g:Lcom/transsnet/palmpay/credit/view/LoanOutstandingSummaryView;

.field public final i:Lcom/transsnet/palmpay/credit/view/ProductContentListView;


# direct methods
.method public constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;Lcom/transsnet/adsdk/widgets/SingleAdView;Lcom/transsnet/palmpay/custom_view/ReboundScrollView;Landroid/view/ViewStub;Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;Lcom/transsnet/palmpay/credit/view/LoanOutstandingSummaryView;Lcom/transsnet/palmpay/credit/view/ProductContentListView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lgb/i;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 5
    .line 6
    iput-object p2, p0, Lgb/i;->b:Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 7
    .line 8
    iput-object p3, p0, Lgb/i;->c:Lcom/transsnet/palmpay/custom_view/ReboundScrollView;

    .line 9
    .line 10
    iput-object p4, p0, Lgb/i;->d:Landroid/view/ViewStub;

    .line 11
    .line 12
    iput-object p5, p0, Lgb/i;->e:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    .line 13
    .line 14
    iput-object p6, p0, Lgb/i;->f:Lcom/transsnet/palmpay/credit/view/LoanHomeBottomInfoView;

    .line 15
    .line 16
    iput-object p7, p0, Lgb/i;->g:Lcom/transsnet/palmpay/credit/view/LoanOutstandingSummaryView;

    .line 17
    .line 18
    iput-object p8, p0, Lgb/i;->i:Lcom/transsnet/palmpay/credit/view/ProductContentListView;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lgb/i;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2
    .line 3
    return-object v0
.end method
