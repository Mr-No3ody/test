.class public final Lgb/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final A:Landroid/widget/LinearLayout;

.field public final B:Landroid/widget/ProgressBar;

.field public final C:Landroid/widget/TextView;

.field public final H:Landroid/widget/TextView;

.field public final L:Landroid/widget/TextView;

.field public final M:Landroid/widget/TextView;

.field public final Q:Landroid/widget/TextView;

.field public final X:Landroid/widget/TextView;

.field public final Y:Landroid/widget/TextView;

.field public final Z:Landroid/widget/TextView;

.field public final a:Landroid/view/View;

.field public final b:Landroid/widget/TextView;

.field public final c:Landroid/view/View;

.field public final d:Landroid/view/View;

.field public final e:Landroid/view/View;

.field public final f:Landroid/widget/FrameLayout;

.field public final g:Lcom/mikepenz/iconics/view/IconicsImageView;

.field public final i:Landroid/widget/ImageView;

.field public final j:Lcom/mikepenz/iconics/view/IconicsImageView;

.field public final k0:Landroid/widget/TextView;

.field public final o:Landroid/widget/LinearLayout;

.field public final p:Landroid/widget/LinearLayout;

.field public final p0:Landroid/widget/TextView;

.field public final q0:Lcom/mikepenz/iconics/view/IconicsTextView;

.field public final r0:Landroid/widget/TextView;

.field public final s0:Landroid/widget/TextView;

.field public final t:Landroid/widget/LinearLayout;

.field public final t0:Landroid/widget/TextView;

.field public final u0:Landroid/widget/TextView;

.field public final v:Landroid/widget/LinearLayout;

.field public final w:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>(Landroid/view/View;Landroid/widget/TextView;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/FrameLayout;Lcom/mikepenz/iconics/view/IconicsImageView;Landroid/widget/ImageView;Lcom/mikepenz/iconics/view/IconicsImageView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/ProgressBar;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Lcom/mikepenz/iconics/view/IconicsTextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lgb/d;->a:Landroid/view/View;

    .line 3
    iput-object p2, p0, Lgb/d;->b:Landroid/widget/TextView;

    .line 4
    iput-object p3, p0, Lgb/d;->c:Landroid/view/View;

    .line 5
    iput-object p4, p0, Lgb/d;->d:Landroid/view/View;

    .line 6
    iput-object p5, p0, Lgb/d;->e:Landroid/view/View;

    .line 7
    iput-object p6, p0, Lgb/d;->f:Landroid/widget/FrameLayout;

    .line 8
    iput-object p7, p0, Lgb/d;->g:Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 9
    iput-object p8, p0, Lgb/d;->i:Landroid/widget/ImageView;

    .line 10
    iput-object p9, p0, Lgb/d;->j:Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 11
    iput-object p10, p0, Lgb/d;->o:Landroid/widget/LinearLayout;

    .line 12
    iput-object p11, p0, Lgb/d;->p:Landroid/widget/LinearLayout;

    .line 13
    iput-object p12, p0, Lgb/d;->t:Landroid/widget/LinearLayout;

    .line 14
    iput-object p14, p0, Lgb/d;->v:Landroid/widget/LinearLayout;

    .line 15
    iput-object p15, p0, Lgb/d;->w:Landroid/widget/LinearLayout;

    move-object/from16 p1, p16

    .line 16
    iput-object p1, p0, Lgb/d;->A:Landroid/widget/LinearLayout;

    move-object/from16 p1, p17

    .line 17
    iput-object p1, p0, Lgb/d;->B:Landroid/widget/ProgressBar;

    move-object/from16 p1, p18

    .line 18
    iput-object p1, p0, Lgb/d;->C:Landroid/widget/TextView;

    move-object/from16 p1, p19

    .line 19
    iput-object p1, p0, Lgb/d;->H:Landroid/widget/TextView;

    move-object/from16 p1, p20

    .line 20
    iput-object p1, p0, Lgb/d;->L:Landroid/widget/TextView;

    move-object/from16 p1, p21

    .line 21
    iput-object p1, p0, Lgb/d;->M:Landroid/widget/TextView;

    move-object/from16 p1, p22

    .line 22
    iput-object p1, p0, Lgb/d;->Q:Landroid/widget/TextView;

    move-object/from16 p1, p23

    .line 23
    iput-object p1, p0, Lgb/d;->X:Landroid/widget/TextView;

    move-object/from16 p1, p24

    .line 24
    iput-object p1, p0, Lgb/d;->Y:Landroid/widget/TextView;

    move-object/from16 p1, p25

    .line 25
    iput-object p1, p0, Lgb/d;->Z:Landroid/widget/TextView;

    move-object/from16 p1, p26

    .line 26
    iput-object p1, p0, Lgb/d;->k0:Landroid/widget/TextView;

    move-object/from16 p1, p27

    .line 27
    iput-object p1, p0, Lgb/d;->p0:Landroid/widget/TextView;

    move-object/from16 p1, p28

    .line 28
    iput-object p1, p0, Lgb/d;->q0:Lcom/mikepenz/iconics/view/IconicsTextView;

    move-object/from16 p1, p29

    .line 29
    iput-object p1, p0, Lgb/d;->r0:Landroid/widget/TextView;

    move-object/from16 p1, p30

    .line 30
    iput-object p1, p0, Lgb/d;->s0:Landroid/widget/TextView;

    move-object/from16 p1, p31

    .line 31
    iput-object p1, p0, Lgb/d;->t0:Landroid/widget/TextView;

    move-object/from16 p1, p32

    .line 32
    iput-object p1, p0, Lgb/d;->u0:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Lgb/d;->a:Landroid/view/View;

    .line 2
    .line 3
    return-object v0
.end method
