.class public abstract LUg/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[I

.field public static final b:[I

.field public static final c:[I

.field public static final d:[I

.field public static final e:[I

.field public static final f:[I

.field public static final g:[I

.field public static final h:[I

.field public static final i:[I

.field public static final j:[I

.field public static final k:[I

.field public static final l:[I

.field public static final m:[I

.field public static final n:[I

.field public static final o:[I

.field public static final p:[I

.field public static final q:[B

.field public static final r:[I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 5

    .line 1
    const/16 v0, 0x9

    .line 2
    .line 3
    const/16 v1, 0x8

    .line 4
    .line 5
    const/16 v2, 0x10

    .line 6
    .line 7
    const/16 v3, 0x18

    .line 8
    .line 9
    const/16 v4, 0x700

    .line 10
    .line 11
    new-array v4, v4, [I

    .line 12
    .line 13
    fill-array-data v4, :array_0

    .line 14
    .line 15
    .line 16
    sput-object v4, LUg/d;->a:[I

    .line 17
    .line 18
    new-array v1, v1, [I

    .line 19
    .line 20
    fill-array-data v1, :array_1

    .line 21
    .line 22
    .line 23
    sput-object v1, LUg/d;->b:[I

    .line 24
    .line 25
    const/16 v1, 0x12

    .line 26
    .line 27
    new-array v1, v1, [I

    .line 28
    .line 29
    fill-array-data v1, :array_2

    .line 30
    .line 31
    .line 32
    sput-object v1, LUg/d;->c:[I

    .line 33
    .line 34
    new-array v1, v2, [I

    .line 35
    .line 36
    fill-array-data v1, :array_3

    .line 37
    .line 38
    .line 39
    sput-object v1, LUg/d;->d:[I

    .line 40
    .line 41
    new-array v1, v2, [I

    .line 42
    .line 43
    fill-array-data v1, :array_4

    .line 44
    .line 45
    .line 46
    sput-object v1, LUg/d;->e:[I

    .line 47
    .line 48
    new-array v1, v2, [I

    .line 49
    .line 50
    fill-array-data v1, :array_5

    .line 51
    .line 52
    .line 53
    sput-object v1, LUg/d;->f:[I

    .line 54
    .line 55
    const/16 v1, 0x19

    .line 56
    .line 57
    new-array v1, v1, [I

    .line 58
    .line 59
    fill-array-data v1, :array_6

    .line 60
    .line 61
    .line 62
    sput-object v1, LUg/d;->g:[I

    .line 63
    .line 64
    const/16 v1, 0x19

    .line 65
    .line 66
    new-array v1, v1, [I

    .line 67
    .line 68
    fill-array-data v1, :array_7

    .line 69
    .line 70
    .line 71
    sput-object v1, LUg/d;->h:[I

    .line 72
    .line 73
    const/16 v1, 0x1a

    .line 74
    .line 75
    new-array v1, v1, [I

    .line 76
    .line 77
    fill-array-data v1, :array_8

    .line 78
    .line 79
    .line 80
    sput-object v1, LUg/d;->i:[I

    .line 81
    .line 82
    const/16 v1, 0x1a

    .line 83
    .line 84
    new-array v1, v1, [I

    .line 85
    .line 86
    fill-array-data v1, :array_9

    .line 87
    .line 88
    .line 89
    sput-object v1, LUg/d;->j:[I

    .line 90
    .line 91
    new-array v1, v3, [I

    .line 92
    .line 93
    fill-array-data v1, :array_a

    .line 94
    .line 95
    .line 96
    sput-object v1, LUg/d;->k:[I

    .line 97
    .line 98
    new-array v1, v3, [I

    .line 99
    .line 100
    fill-array-data v1, :array_b

    .line 101
    .line 102
    .line 103
    sput-object v1, LUg/d;->l:[I

    .line 104
    .line 105
    new-array v1, v3, [I

    .line 106
    .line 107
    fill-array-data v1, :array_c

    .line 108
    .line 109
    .line 110
    sput-object v1, LUg/d;->m:[I

    .line 111
    .line 112
    new-array v1, v3, [I

    .line 113
    .line 114
    fill-array-data v1, :array_d

    .line 115
    .line 116
    .line 117
    sput-object v1, LUg/d;->n:[I

    .line 118
    .line 119
    new-array v1, v0, [I

    .line 120
    .line 121
    fill-array-data v1, :array_e

    .line 122
    .line 123
    .line 124
    sput-object v1, LUg/d;->o:[I

    .line 125
    .line 126
    new-array v0, v0, [I

    .line 127
    .line 128
    fill-array-data v0, :array_f

    .line 129
    .line 130
    .line 131
    sput-object v0, LUg/d;->p:[I

    .line 132
    .line 133
    const/16 v0, 0x400

    .line 134
    .line 135
    new-array v1, v0, [B

    .line 136
    .line 137
    sput-object v1, LUg/d;->q:[B

    .line 138
    .line 139
    new-array v0, v0, [I

    .line 140
    .line 141
    sput-object v0, LUg/d;->r:[I

    .line 142
    .line 143
    return-void

    .line 144
    nop

    .line 145
    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x4
        0x4
        0x0
        0x0
        0x4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x8
        0xc
        0x10
        0xc
        0xc
        0x14
        0xc
        0x10
        0x18
        0x1c
        0xc
        0xc
        0x20
        0xc
        0x24
        0xc
        0x2c
        0x2c
        0x2c
        0x2c
        0x2c
        0x2c
        0x2c
        0x2c
        0x2c
        0x2c
        0x20
        0x20
        0x18
        0x28
        0x1c
        0xc
        0xc
        0x30
        0x34
        0x34
        0x34
        0x30
        0x34
        0x34
        0x34
        0x30
        0x34
        0x34
        0x34
        0x34
        0x34
        0x30
        0x34
        0x34
        0x34
        0x34
        0x34
        0x30
        0x34
        0x34
        0x34
        0x34
        0x34
        0x18
        0xc
        0x1c
        0xc
        0xc
        0xc
        0x38
        0x3c
        0x3c
        0x3c
        0x38
        0x3c
        0x3c
        0x3c
        0x38
        0x3c
        0x3c
        0x3c
        0x3c
        0x3c
        0x38
        0x3c
        0x3c
        0x3c
        0x3c
        0x3c
        0x38
        0x3c
        0x3c
        0x3c
        0x3c
        0x3c
        0x18
        0xc
        0x1c
        0xc
        0x0
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x0
        0x1
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x2
        0x3
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x1
        0x1
        0x1
        0x1
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x0
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x4
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x6
        0x7
        0x0
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x8
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x10
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x18
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x20
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x28
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x30
        0x38
        0x0
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xe
        0xf
        0x10
        0x11
        0x12
        0x13
        0x14
        0x15
        0x16
        0x17
        0x18
        0x19
        0x1a
        0x1b
        0x1c
        0x1d
        0x1e
        0x1f
        0x20
        0x21
        0x22
        0x23
        0x24
        0x25
        0x26
        0x27
        0x28
        0x29
        0x2a
        0x2b
        0x2c
        0x2d
        0x2e
        0x2f
        0x30
        0x31
        0x32
        0x33
        0x34
        0x35
        0x36
        0x37
        0x38
        0x39
        0x3a
        0x3b
        0x3c
        0x3d
        0x3e
        0x3f
        0x0
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xe
        0xf
        0x10
        0x11
        0x12
        0x13
        0x14
        0x15
        0x16
        0x17
        0x18
        0x19
        0x1a
        0x1b
        0x1c
        0x1d
        0x1e
        0x1f
        0x20
        0x21
        0x22
        0x23
        0x24
        0x25
        0x26
        0x27
        0x28
        0x29
        0x2a
        0x2b
        0x2c
        0x2d
        0x2e
        0x2f
        0x30
        0x31
        0x32
        0x33
        0x34
        0x35
        0x36
        0x37
        0x38
        0x39
        0x3a
        0x3b
        0x3c
        0x3d
        0x3e
        0x3f
        0x0
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xe
        0xf
        0x10
        0x11
        0x12
        0x13
        0x14
        0x15
        0x16
        0x17
        0x18
        0x19
        0x1a
        0x1b
        0x1c
        0x1d
        0x1e
        0x1f
        0x20
        0x21
        0x22
        0x23
        0x24
        0x25
        0x26
        0x27
        0x28
        0x29
        0x2a
        0x2b
        0x2c
        0x2d
        0x2e
        0x2f
        0x30
        0x31
        0x32
        0x33
        0x34
        0x35
        0x36
        0x37
        0x38
        0x39
        0x3a
        0x3b
        0x3c
        0x3d
        0x3e
        0x3f
        0x0
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xe
        0xf
        0x10
        0x11
        0x12
        0x13
        0x14
        0x15
        0x16
        0x17
        0x18
        0x19
        0x1a
        0x1b
        0x1c
        0x1d
        0x1e
        0x1f
        0x20
        0x21
        0x22
        0x23
        0x24
        0x25
        0x26
        0x27
        0x28
        0x29
        0x2a
        0x2b
        0x2c
        0x2d
        0x2e
        0x2f
        0x30
        0x31
        0x32
        0x33
        0x34
        0x35
        0x36
        0x37
        0x38
        0x39
        0x3a
        0x3b
        0x3c
        0x3d
        0x3e
        0x3f
        0x0
        0x0
        0x0
        0x0
        0x1
        0x1
        0x1
        0x1
        0x2
        0x2
        0x2
        0x2
        0x3
        0x3
        0x3
        0x3
        0x4
        0x4
        0x4
        0x4
        0x5
        0x5
        0x5
        0x5
        0x6
        0x6
        0x6
        0x6
        0x7
        0x7
        0x7
        0x7
        0x8
        0x8
        0x8
        0x8
        0x9
        0x9
        0x9
        0x9
        0xa
        0xa
        0xa
        0xa
        0xb
        0xb
        0xb
        0xb
        0xc
        0xc
        0xc
        0xc
        0xd
        0xd
        0xd
        0xd
        0xe
        0xe
        0xe
        0xe
        0xf
        0xf
        0xf
        0xf
        0x10
        0x10
        0x10
        0x10
        0x11
        0x11
        0x11
        0x11
        0x12
        0x12
        0x12
        0x12
        0x13
        0x13
        0x13
        0x13
        0x14
        0x14
        0x14
        0x14
        0x15
        0x15
        0x15
        0x15
        0x16
        0x16
        0x16
        0x16
        0x17
        0x17
        0x17
        0x17
        0x18
        0x18
        0x18
        0x18
        0x19
        0x19
        0x19
        0x19
        0x1a
        0x1a
        0x1a
        0x1a
        0x1b
        0x1b
        0x1b
        0x1b
        0x1c
        0x1c
        0x1c
        0x1c
        0x1d
        0x1d
        0x1d
        0x1d
        0x1e
        0x1e
        0x1e
        0x1e
        0x1f
        0x1f
        0x1f
        0x1f
        0x20
        0x20
        0x20
        0x20
        0x21
        0x21
        0x21
        0x21
        0x22
        0x22
        0x22
        0x22
        0x23
        0x23
        0x23
        0x23
        0x24
        0x24
        0x24
        0x24
        0x25
        0x25
        0x25
        0x25
        0x26
        0x26
        0x26
        0x26
        0x27
        0x27
        0x27
        0x27
        0x28
        0x28
        0x28
        0x28
        0x29
        0x29
        0x29
        0x29
        0x2a
        0x2a
        0x2a
        0x2a
        0x2b
        0x2b
        0x2b
        0x2b
        0x2c
        0x2c
        0x2c
        0x2c
        0x2d
        0x2d
        0x2d
        0x2d
        0x2e
        0x2e
        0x2e
        0x2e
        0x2f
        0x2f
        0x2f
        0x2f
        0x30
        0x30
        0x30
        0x30
        0x31
        0x31
        0x31
        0x31
        0x32
        0x32
        0x32
        0x32
        0x33
        0x33
        0x33
        0x33
        0x34
        0x34
        0x34
        0x34
        0x35
        0x35
        0x35
        0x35
        0x36
        0x36
        0x36
        0x36
        0x37
        0x37
        0x37
        0x37
        0x38
        0x38
        0x38
        0x38
        0x39
        0x39
        0x39
        0x39
        0x3a
        0x3a
        0x3a
        0x3a
        0x3b
        0x3b
        0x3b
        0x3b
        0x3c
        0x3c
        0x3c
        0x3c
        0x3d
        0x3d
        0x3d
        0x3d
        0x3e
        0x3e
        0x3e
        0x3e
        0x3f
        0x3f
        0x3f
        0x3f
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    :array_1
    .array-data 4
        0x400
        0x600
        0x500
        0x600
        0x0
        0x100
        0x300
        0x200
    .end array-data

    :array_2
    .array-data 4
        0x1
        0x2
        0x3
        0x4
        0x0
        0x5
        0x11
        0x6
        0x10
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xe
        0xf
    .end array-data

    :array_3
    .array-data 4
        0x3
        0x2
        0x1
        0x0
        0x3
        0x3
        0x3
        0x3
        0x3
        0x3
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
    .end array-data

    :array_4
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        -0x1
        0x1
        -0x2
        0x2
        -0x3
        0x3
        -0x1
        0x1
        -0x2
        0x2
        -0x3
        0x3
    .end array-data

    :array_5
    .array-data 4
        0x20000
        0x20004
        0x20003
        0x30002
        0x20000
        0x20004
        0x20003
        0x40001
        0x20000
        0x20004
        0x20003
        0x30002
        0x20000
        0x20004
        0x20003
        0x40005
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1000
        0x2400
        0x5400
        0x8c00
        0xac00
        0xd000
        0xf800
        0x12400
        0x15400
        0x16e00
        0x18a00
        0x19900
        0x1a100
        0x1a980
        0x1bb80
        0x1c500
        0x1cf00
        0x1d440
        0x1d9c0
        0x1dca0
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0xa
        0xa
        0xb
        0xb
        0xa
        0xa
        0xa
        0xa
        0xa
        0x9
        0x9
        0x8
        0x7
        0x7
        0x8
        0x7
        0x7
        0x6
        0x6
        0x5
        0x5
    .end array-data

    :array_8
    .array-data 4
        0x1
        0x5
        0x9
        0xd
        0x11
        0x19
        0x21
        0x29
        0x31
        0x41
        0x51
        0x61
        0x71
        0x91
        0xb1
        0xd1
        0xf1
        0x131
        0x171
        0x1f1
        0x2f1
        0x4f1
        0x8f1
        0x10f1
        0x20f1
        0x40f1
    .end array-data

    :array_9
    .array-data 4
        0x2
        0x2
        0x2
        0x2
        0x3
        0x3
        0x3
        0x3
        0x4
        0x4
        0x4
        0x4
        0x5
        0x5
        0x5
        0x5
        0x6
        0x6
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0x18
    .end array-data

    :array_a
    .array-data 4
        0x0
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
        0x8
        0xa
        0xe
        0x12
        0x1a
        0x22
        0x32
        0x42
        0x62
        0x82
        0xc2
        0x142
        0x242
        0x442
        0x842
        0x1842
        0x5842
    .end array-data

    :array_b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1
        0x1
        0x2
        0x2
        0x3
        0x3
        0x4
        0x4
        0x5
        0x5
        0x6
        0x7
        0x8
        0x9
        0xa
        0xc
        0xe
        0x18
    .end array-data

    :array_c
    .array-data 4
        0x2
        0x3
        0x4
        0x5
        0x6
        0x7
        0x8
        0x9
        0xa
        0xc
        0xe
        0x12
        0x16
        0x1e
        0x26
        0x36
        0x46
        0x66
        0x86
        0xc6
        0x146
        0x246
        0x446
        0x846
    .end array-data

    :array_d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x1
        0x1
        0x2
        0x2
        0x3
        0x3
        0x4
        0x4
        0x5
        0x5
        0x6
        0x7
        0x8
        0x9
        0xa
        0x18
    .end array-data

    :array_e
    .array-data 4
        0x0
        0x0
        0x8
        0x8
        0x0
        0x10
        0x8
        0x10
        0x10
    .end array-data

    :array_f
    .array-data 4
        0x0
        0x8
        0x0
        0x8
        0x10
        0x0
        0x10
        0x8
        0x10
    .end array-data
.end method

.method public static a(II[I[II)V
    .locals 20

    .line 1
    move/from16 v0, p1

    .line 2
    .line 3
    move/from16 v1, p4

    .line 4
    .line 5
    new-array v2, v1, [I

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    new-array v4, v3, [I

    .line 10
    .line 11
    new-array v5, v3, [I

    .line 12
    .line 13
    const/4 v6, 0x0

    .line 14
    move v7, v6

    .line 15
    :goto_0
    const/4 v8, 0x1

    .line 16
    if-ge v7, v1, :cond_0

    .line 17
    .line 18
    aget v9, p3, v7

    .line 19
    .line 20
    aget v10, v4, v9

    .line 21
    .line 22
    add-int/2addr v10, v8

    .line 23
    aput v10, v4, v9

    .line 24
    .line 25
    add-int/lit8 v7, v7, 0x1

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    aput v6, v5, v8

    .line 29
    .line 30
    move v7, v8

    .line 31
    :goto_1
    const/16 v9, 0xf

    .line 32
    .line 33
    if-ge v7, v9, :cond_1

    .line 34
    .line 35
    add-int/lit8 v9, v7, 0x1

    .line 36
    .line 37
    aget v10, v5, v7

    .line 38
    .line 39
    aget v7, v4, v7

    .line 40
    .line 41
    add-int/2addr v10, v7

    .line 42
    aput v10, v5, v9

    .line 43
    .line 44
    move v7, v9

    .line 45
    goto :goto_1

    .line 46
    :cond_1
    move v7, v6

    .line 47
    :goto_2
    if-ge v7, v1, :cond_3

    .line 48
    .line 49
    aget v10, p3, v7

    .line 50
    .line 51
    if-eqz v10, :cond_2

    .line 52
    .line 53
    aget v11, v5, v10

    .line 54
    .line 55
    add-int/lit8 v12, v11, 0x1

    .line 56
    .line 57
    aput v12, v5, v10

    .line 58
    .line 59
    aput v7, v2, v11

    .line 60
    .line 61
    :cond_2
    add-int/lit8 v7, v7, 0x1

    .line 62
    .line 63
    goto :goto_2

    .line 64
    :cond_3
    shl-int v1, v8, v0

    .line 65
    .line 66
    aget v5, v5, v9

    .line 67
    .line 68
    if-ne v5, v8, :cond_4

    .line 69
    .line 70
    move v0, v6

    .line 71
    :goto_3
    if-ge v0, v1, :cond_f

    .line 72
    .line 73
    add-int v3, p0, v0

    .line 74
    .line 75
    aget v4, v2, v6

    .line 76
    .line 77
    aput v4, p2, v3

    .line 78
    .line 79
    add-int/lit8 v0, v0, 0x1

    .line 80
    .line 81
    goto :goto_3

    .line 82
    :cond_4
    const/4 v5, 0x2

    .line 83
    move v11, v5

    .line 84
    move v7, v6

    .line 85
    move v10, v8

    .line 86
    :goto_4
    if-gt v10, v0, :cond_8

    .line 87
    .line 88
    :goto_5
    aget v12, v4, v10

    .line 89
    .line 90
    if-lez v12, :cond_7

    .line 91
    .line 92
    add-int v12, p0, v7

    .line 93
    .line 94
    shl-int/lit8 v13, v10, 0x10

    .line 95
    .line 96
    add-int/lit8 v14, v6, 0x1

    .line 97
    .line 98
    aget v6, v2, v6

    .line 99
    .line 100
    or-int/2addr v13, v6

    .line 101
    move v6, v1

    .line 102
    :cond_5
    sub-int/2addr v6, v11

    .line 103
    add-int v15, v12, v6

    .line 104
    .line 105
    aput v13, p2, v15

    .line 106
    .line 107
    if-gtz v6, :cond_5

    .line 108
    .line 109
    add-int/lit8 v6, v10, -0x1

    .line 110
    .line 111
    shl-int v6, v8, v6

    .line 112
    .line 113
    :goto_6
    and-int v12, v7, v6

    .line 114
    .line 115
    if-eqz v12, :cond_6

    .line 116
    .line 117
    shr-int/lit8 v6, v6, 0x1

    .line 118
    .line 119
    goto :goto_6

    .line 120
    :cond_6
    add-int/lit8 v12, v6, -0x1

    .line 121
    .line 122
    and-int/2addr v7, v12

    .line 123
    add-int/2addr v7, v6

    .line 124
    aget v6, v4, v10

    .line 125
    .line 126
    sub-int/2addr v6, v8

    .line 127
    aput v6, v4, v10

    .line 128
    .line 129
    move v6, v14

    .line 130
    goto :goto_5

    .line 131
    :cond_7
    add-int/lit8 v10, v10, 0x1

    .line 132
    .line 133
    shl-int/lit8 v11, v11, 0x1

    .line 134
    .line 135
    goto :goto_4

    .line 136
    :cond_8
    add-int/lit8 v10, v1, -0x1

    .line 137
    .line 138
    add-int/lit8 v11, v0, 0x1

    .line 139
    .line 140
    const/4 v12, -0x1

    .line 141
    move/from16 v13, p0

    .line 142
    .line 143
    :goto_7
    if-gt v11, v9, :cond_f

    .line 144
    .line 145
    :goto_8
    aget v14, v4, v11

    .line 146
    .line 147
    if-lez v14, :cond_e

    .line 148
    .line 149
    and-int v14, v7, v10

    .line 150
    .line 151
    if-eq v14, v12, :cond_b

    .line 152
    .line 153
    add-int/2addr v13, v1

    .line 154
    sub-int v1, v11, v0

    .line 155
    .line 156
    shl-int v1, v8, v1

    .line 157
    .line 158
    move v12, v11

    .line 159
    :goto_9
    if-ge v12, v9, :cond_a

    .line 160
    .line 161
    aget v15, v4, v12

    .line 162
    .line 163
    sub-int/2addr v1, v15

    .line 164
    if-gtz v1, :cond_9

    .line 165
    .line 166
    goto :goto_a

    .line 167
    :cond_9
    add-int/lit8 v12, v12, 0x1

    .line 168
    .line 169
    shl-int/lit8 v1, v1, 0x1

    .line 170
    .line 171
    goto :goto_9

    .line 172
    :cond_a
    :goto_a
    sub-int/2addr v12, v0

    .line 173
    shl-int v1, v8, v12

    .line 174
    .line 175
    add-int v15, p0, v14

    .line 176
    .line 177
    add-int/2addr v12, v0

    .line 178
    shl-int/2addr v12, v3

    .line 179
    sub-int v16, v13, p0

    .line 180
    .line 181
    sub-int v16, v16, v14

    .line 182
    .line 183
    or-int v12, v12, v16

    .line 184
    .line 185
    aput v12, p2, v15

    .line 186
    .line 187
    move/from16 v16, v14

    .line 188
    .line 189
    move v15, v13

    .line 190
    move v14, v1

    .line 191
    goto :goto_b

    .line 192
    :cond_b
    move/from16 v16, v12

    .line 193
    .line 194
    move v14, v1

    .line 195
    move v15, v13

    .line 196
    :goto_b
    shr-int v1, v7, v0

    .line 197
    .line 198
    add-int v17, v15, v1

    .line 199
    .line 200
    sub-int v1, v11, v0

    .line 201
    .line 202
    shl-int/2addr v1, v3

    .line 203
    add-int/lit8 v18, v6, 0x1

    .line 204
    .line 205
    aget v6, v2, v6

    .line 206
    .line 207
    or-int v19, v1, v6

    .line 208
    .line 209
    move v1, v14

    .line 210
    :cond_c
    sub-int/2addr v1, v5

    .line 211
    add-int v6, v17, v1

    .line 212
    .line 213
    aput v19, p2, v6

    .line 214
    .line 215
    if-gtz v1, :cond_c

    .line 216
    .line 217
    add-int/lit8 v1, v11, -0x1

    .line 218
    .line 219
    shl-int v1, v8, v1

    .line 220
    .line 221
    :goto_c
    and-int v6, v7, v1

    .line 222
    .line 223
    if-eqz v6, :cond_d

    .line 224
    .line 225
    shr-int/lit8 v1, v1, 0x1

    .line 226
    .line 227
    goto :goto_c

    .line 228
    :cond_d
    add-int/lit8 v6, v1, -0x1

    .line 229
    .line 230
    and-int/2addr v6, v7

    .line 231
    add-int v7, v6, v1

    .line 232
    .line 233
    aget v1, v4, v11

    .line 234
    .line 235
    sub-int/2addr v1, v8

    .line 236
    aput v1, v4, v11

    .line 237
    .line 238
    move v1, v14

    .line 239
    move v13, v15

    .line 240
    move/from16 v12, v16

    .line 241
    .line 242
    move/from16 v6, v18

    .line 243
    .line 244
    goto :goto_8

    .line 245
    :cond_e
    add-int/lit8 v11, v11, 0x1

    .line 246
    .line 247
    shl-int/lit8 v5, v5, 0x1

    .line 248
    .line 249
    goto :goto_7

    .line 250
    :cond_f
    return-void
.end method

.method public static b(LUg/f;I)V
    .locals 6

    .line 1
    iget-object v0, p0, LUg/f;->c:LUg/a;

    .line 2
    .line 3
    mul-int/lit8 v1, p1, 0x2

    .line 4
    .line 5
    invoke-static {v0}, LUg/a;->b(LUg/a;)V

    .line 6
    .line 7
    .line 8
    mul-int/lit16 v2, p1, 0x438

    .line 9
    .line 10
    iget-object v3, p0, LUg/f;->e:[I

    .line 11
    .line 12
    invoke-static {v3, v2, v0}, LUg/d;->g([IILUg/a;)I

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    invoke-static {v0}, LUg/a;->b(LUg/a;)V

    .line 17
    .line 18
    .line 19
    iget-object v4, p0, LUg/f;->f:[I

    .line 20
    .line 21
    invoke-static {v4, v2, v0}, LUg/d;->g([IILUg/a;)I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    sget-object v4, LUg/d;->j:[I

    .line 26
    .line 27
    aget v4, v4, v2

    .line 28
    .line 29
    sget-object v5, LUg/d;->i:[I

    .line 30
    .line 31
    aget v2, v5, v2

    .line 32
    .line 33
    invoke-static {v0, v4}, LUg/a;->d(LUg/a;I)I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    add-int/2addr v0, v2

    .line 38
    iget-object v2, p0, LUg/f;->n:[I

    .line 39
    .line 40
    aput v0, v2, p1

    .line 41
    .line 42
    const/4 v0, 0x1

    .line 43
    iget-object v2, p0, LUg/f;->p:[I

    .line 44
    .line 45
    if-ne v3, v0, :cond_0

    .line 46
    .line 47
    add-int/lit8 v3, v1, 0x1

    .line 48
    .line 49
    aget v3, v2, v3

    .line 50
    .line 51
    add-int/2addr v3, v0

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    if-nez v3, :cond_1

    .line 54
    .line 55
    aget v3, v2, v1

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    add-int/lit8 v3, v3, -0x2

    .line 59
    .line 60
    :goto_0
    iget-object p0, p0, LUg/f;->o:[I

    .line 61
    .line 62
    aget p0, p0, p1

    .line 63
    .line 64
    if-lt v3, p0, :cond_2

    .line 65
    .line 66
    sub-int/2addr v3, p0

    .line 67
    :cond_2
    add-int/lit8 p0, v1, 0x1

    .line 68
    .line 69
    aget p1, v2, p0

    .line 70
    .line 71
    aput p1, v2, v1

    .line 72
    .line 73
    aput v3, v2, p0

    .line 74
    .line 75
    return-void
.end method

.method public static c(I[BLUg/a;)I
    .locals 8

    .line 1
    invoke-static {p2}, LUg/a;->e(LUg/a;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    invoke-static {p2, v0}, LUg/a;->d(LUg/a;I)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v1, :cond_1

    .line 11
    .line 12
    const/4 v1, 0x3

    .line 13
    invoke-static {p2, v1}, LUg/a;->d(LUg/a;I)I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-nez v1, :cond_0

    .line 18
    .line 19
    move v3, v0

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    invoke-static {p2, v1}, LUg/a;->d(LUg/a;I)I

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    shl-int v1, v0, v1

    .line 26
    .line 27
    add-int/2addr v3, v1

    .line 28
    goto :goto_0

    .line 29
    :cond_1
    move v3, v2

    .line 30
    :goto_0
    add-int/2addr v3, v0

    .line 31
    if-ne v3, v0, :cond_2

    .line 32
    .line 33
    move p2, v2

    .line 34
    :goto_1
    if-ge p2, p0, :cond_c

    .line 35
    .line 36
    add-int/lit16 v0, p2, 0x400

    .line 37
    .line 38
    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    sub-int/2addr v0, p2

    .line 43
    sget-object v1, LUg/d;->q:[B

    .line 44
    .line 45
    invoke-static {v1, v2, p1, p2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 46
    .line 47
    .line 48
    add-int/2addr p2, v0

    .line 49
    goto :goto_1

    .line 50
    :cond_2
    invoke-static {p2, v0}, LUg/a;->d(LUg/a;I)I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-ne v1, v0, :cond_3

    .line 55
    .line 56
    const/4 v1, 0x4

    .line 57
    invoke-static {p2, v1}, LUg/a;->d(LUg/a;I)I

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    add-int/2addr v1, v0

    .line 62
    goto :goto_2

    .line 63
    :cond_3
    move v1, v2

    .line 64
    :goto_2
    const/16 v4, 0x438

    .line 65
    .line 66
    new-array v4, v4, [I

    .line 67
    .line 68
    add-int v5, v3, v1

    .line 69
    .line 70
    invoke-static {v5, v4, v2, p2}, LUg/d;->f(I[IILUg/a;)V

    .line 71
    .line 72
    .line 73
    move v5, v2

    .line 74
    :cond_4
    :goto_3
    if-ge v5, p0, :cond_8

    .line 75
    .line 76
    invoke-static {p2}, LUg/a;->e(LUg/a;)V

    .line 77
    .line 78
    .line 79
    invoke-static {p2}, LUg/a;->b(LUg/a;)V

    .line 80
    .line 81
    .line 82
    invoke-static {v4, v2, p2}, LUg/d;->g([IILUg/a;)I

    .line 83
    .line 84
    .line 85
    move-result v6

    .line 86
    if-nez v6, :cond_5

    .line 87
    .line 88
    aput-byte v2, p1, v5

    .line 89
    .line 90
    :goto_4
    add-int/lit8 v5, v5, 0x1

    .line 91
    .line 92
    goto :goto_3

    .line 93
    :cond_5
    if-gt v6, v1, :cond_7

    .line 94
    .line 95
    shl-int v7, v0, v6

    .line 96
    .line 97
    invoke-static {p2, v6}, LUg/a;->d(LUg/a;I)I

    .line 98
    .line 99
    .line 100
    move-result v6

    .line 101
    add-int/2addr v6, v7

    .line 102
    :goto_5
    if-eqz v6, :cond_4

    .line 103
    .line 104
    if-ge v5, p0, :cond_6

    .line 105
    .line 106
    aput-byte v2, p1, v5

    .line 107
    .line 108
    add-int/lit8 v5, v5, 0x1

    .line 109
    .line 110
    add-int/lit8 v6, v6, -0x1

    .line 111
    .line 112
    goto :goto_5

    .line 113
    :cond_6
    new-instance p0, LUg/c;

    .line 114
    .line 115
    const-string p1, "Corrupted context map"

    .line 116
    .line 117
    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    throw p0

    .line 121
    :cond_7
    sub-int/2addr v6, v1

    .line 122
    int-to-byte v6, v6

    .line 123
    aput-byte v6, p1, v5

    .line 124
    .line 125
    goto :goto_4

    .line 126
    :cond_8
    invoke-static {p2, v0}, LUg/a;->d(LUg/a;I)I

    .line 127
    .line 128
    .line 129
    move-result p2

    .line 130
    if-ne p2, v0, :cond_c

    .line 131
    .line 132
    const/16 p2, 0x100

    .line 133
    .line 134
    new-array v0, p2, [I

    .line 135
    .line 136
    move v1, v2

    .line 137
    :goto_6
    if-ge v1, p2, :cond_9

    .line 138
    .line 139
    aput v1, v0, v1

    .line 140
    .line 141
    add-int/lit8 v1, v1, 0x1

    .line 142
    .line 143
    goto :goto_6

    .line 144
    :cond_9
    move p2, v2

    .line 145
    :goto_7
    if-ge p2, p0, :cond_c

    .line 146
    .line 147
    aget-byte v1, p1, p2

    .line 148
    .line 149
    and-int/lit16 v1, v1, 0xff

    .line 150
    .line 151
    aget v4, v0, v1

    .line 152
    .line 153
    int-to-byte v5, v4

    .line 154
    aput-byte v5, p1, p2

    .line 155
    .line 156
    if-eqz v1, :cond_b

    .line 157
    .line 158
    :goto_8
    if-lez v1, :cond_a

    .line 159
    .line 160
    add-int/lit8 v5, v1, -0x1

    .line 161
    .line 162
    aget v5, v0, v5

    .line 163
    .line 164
    aput v5, v0, v1

    .line 165
    .line 166
    add-int/lit8 v1, v1, -0x1

    .line 167
    .line 168
    goto :goto_8

    .line 169
    :cond_a
    aput v4, v0, v2

    .line 170
    .line 171
    :cond_b
    add-int/lit8 p2, p2, 0x1

    .line 172
    .line 173
    goto :goto_7

    .line 174
    :cond_c
    return v3
.end method

.method public static d(LUg/f;)V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {p0, v0}, LUg/d;->b(LUg/f;I)V

    .line 3
    .line 4
    .line 5
    iget-object v0, p0, LUg/f;->p:[I

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    aget v0, v0, v1

    .line 9
    .line 10
    shl-int/lit8 v2, v0, 0x6

    .line 11
    .line 12
    iput v2, p0, LUg/f;->A:I

    .line 13
    .line 14
    iget-object v3, p0, LUg/f;->z:[B

    .line 15
    .line 16
    aget-byte v2, v3, v2

    .line 17
    .line 18
    and-int/lit16 v2, v2, 0xff

    .line 19
    .line 20
    iget-object v3, p0, LUg/f;->k:LPa/b;

    .line 21
    .line 22
    iget-object v3, v3, LPa/b;->d:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v3, [I

    .line 25
    .line 26
    aget v2, v3, v2

    .line 27
    .line 28
    iput v2, p0, LUg/f;->v:I

    .line 29
    .line 30
    iget-object v2, p0, LUg/f;->y:[B

    .line 31
    .line 32
    aget-byte v0, v2, v0

    .line 33
    .line 34
    sget-object v2, LUg/d;->b:[I

    .line 35
    .line 36
    aget v3, v2, v0

    .line 37
    .line 38
    iput v3, p0, LUg/f;->C:I

    .line 39
    .line 40
    add-int/2addr v0, v1

    .line 41
    aget v0, v2, v0

    .line 42
    .line 43
    iput v0, p0, LUg/f;->D:I

    .line 44
    .line 45
    return-void
.end method

.method public static e(LUg/f;)V
    .locals 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, LUg/f;->a:I

    .line 4
    .line 5
    if-eqz v1, :cond_63

    .line 6
    .line 7
    const/16 v2, 0xb

    .line 8
    .line 9
    if-eq v1, v2, :cond_62

    .line 10
    .line 11
    iget v1, v0, LUg/f;->P:I

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    sub-int/2addr v1, v3

    .line 15
    iget-object v4, v0, LUg/f;->d:[B

    .line 16
    .line 17
    :goto_0
    iget v5, v0, LUg/f;->a:I

    .line 18
    .line 19
    const-string v6, "Invalid metablock length"

    .line 20
    .line 21
    const-string v7, "Corrupted padding bits"

    .line 22
    .line 23
    const/16 v10, 0xa

    .line 24
    .line 25
    iget-object v11, v0, LUg/f;->c:LUg/a;

    .line 26
    .line 27
    if-eq v5, v10, :cond_5d

    .line 28
    .line 29
    const/16 v13, 0xc

    .line 30
    .line 31
    if-eq v5, v13, :cond_59

    .line 32
    .line 33
    const/4 v15, 0x4

    .line 34
    const/16 v16, 0x7

    .line 35
    .line 36
    const/16 v17, 0x10

    .line 37
    .line 38
    const/16 v18, 0x6

    .line 39
    .line 40
    move/from16 v19, v3

    .line 41
    .line 42
    const/16 v20, 0x2

    .line 43
    .line 44
    const/16 v3, 0x9

    .line 45
    .line 46
    const-string v9, "Invalid backward reference"

    .line 47
    .line 48
    const/16 v23, 0x5

    .line 49
    .line 50
    iget-object v14, v0, LUg/f;->p:[I

    .line 51
    .line 52
    iget-object v12, v0, LUg/f;->m:LPa/b;

    .line 53
    .line 54
    iget-object v8, v0, LUg/f;->l:LPa/b;

    .line 55
    .line 56
    iget-object v10, v0, LUg/f;->k:LPa/b;

    .line 57
    .line 58
    iget-object v2, v0, LUg/f;->n:[I

    .line 59
    .line 60
    packed-switch v5, :pswitch_data_0

    .line 61
    .line 62
    .line 63
    new-instance v1, LUg/c;

    .line 64
    .line 65
    new-instance v2, Ljava/lang/StringBuilder;

    .line 66
    .line 67
    const-string v3, "Unexpected state "

    .line 68
    .line 69
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    iget v0, v0, LUg/f;->a:I

    .line 73
    .line 74
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    throw v1

    .line 85
    :pswitch_0
    iget v2, v0, LUg/f;->L:I

    .line 86
    .line 87
    if-lt v2, v15, :cond_e

    .line 88
    .line 89
    const/16 v5, 0x18

    .line 90
    .line 91
    if-gt v2, v5, :cond_e

    .line 92
    .line 93
    sget-object v5, LUg/d;->g:[I

    .line 94
    .line 95
    aget v5, v5, v2

    .line 96
    .line 97
    iget v6, v0, LUg/f;->K:I

    .line 98
    .line 99
    iget v7, v0, LUg/f;->s:I

    .line 100
    .line 101
    sub-int/2addr v6, v7

    .line 102
    add-int/lit8 v6, v6, -0x1

    .line 103
    .line 104
    sget-object v7, LUg/d;->h:[I

    .line 105
    .line 106
    aget v7, v7, v2

    .line 107
    .line 108
    shl-int v8, v19, v7

    .line 109
    .line 110
    add-int/lit8 v8, v8, -0x1

    .line 111
    .line 112
    and-int/2addr v8, v6

    .line 113
    ushr-int/2addr v6, v7

    .line 114
    mul-int/2addr v8, v2

    .line 115
    add-int/2addr v8, v5

    .line 116
    sget-object v5, LUg/g;->d:[LUg/g;

    .line 117
    .line 118
    array-length v7, v5

    .line 119
    if-ge v6, v7, :cond_d

    .line 120
    .line 121
    iget v7, v0, LUg/f;->M:I

    .line 122
    .line 123
    sget-object v9, LUg/e;->a:[B

    .line 124
    .line 125
    aget-object v5, v5, v6

    .line 126
    .line 127
    iget-object v6, v5, LUg/g;->a:[B

    .line 128
    .line 129
    array-length v10, v6

    .line 130
    move v12, v7

    .line 131
    const/4 v11, 0x0

    .line 132
    :goto_1
    if-ge v11, v10, :cond_0

    .line 133
    .line 134
    add-int/lit8 v14, v12, 0x1

    .line 135
    .line 136
    add-int/lit8 v15, v11, 0x1

    .line 137
    .line 138
    aget-byte v11, v6, v11

    .line 139
    .line 140
    aput-byte v11, v4, v12

    .line 141
    .line 142
    move v12, v14

    .line 143
    move v11, v15

    .line 144
    goto :goto_1

    .line 145
    :cond_0
    iget v6, v5, LUg/g;->b:I

    .line 146
    .line 147
    if-lt v6, v13, :cond_1

    .line 148
    .line 149
    add-int/lit8 v10, v6, -0xb

    .line 150
    .line 151
    goto :goto_2

    .line 152
    :cond_1
    const/4 v10, 0x0

    .line 153
    :goto_2
    if-le v10, v2, :cond_2

    .line 154
    .line 155
    move v10, v2

    .line 156
    :cond_2
    add-int/2addr v8, v10

    .line 157
    sub-int/2addr v2, v10

    .line 158
    if-gt v6, v3, :cond_3

    .line 159
    .line 160
    move v3, v6

    .line 161
    goto :goto_3

    .line 162
    :cond_3
    const/4 v3, 0x0

    .line 163
    :goto_3
    sub-int/2addr v2, v3

    .line 164
    move v3, v2

    .line 165
    :goto_4
    if-lez v3, :cond_4

    .line 166
    .line 167
    add-int/lit8 v10, v12, 0x1

    .line 168
    .line 169
    add-int/lit8 v11, v8, 0x1

    .line 170
    .line 171
    aget-byte v8, v9, v8

    .line 172
    .line 173
    aput-byte v8, v4, v12

    .line 174
    .line 175
    add-int/lit8 v3, v3, -0x1

    .line 176
    .line 177
    move v12, v10

    .line 178
    move v8, v11

    .line 179
    goto :goto_4

    .line 180
    :cond_4
    const/16 v8, 0xb

    .line 181
    .line 182
    const/16 v3, 0xa

    .line 183
    .line 184
    if-eq v6, v8, :cond_5

    .line 185
    .line 186
    if-ne v6, v3, :cond_a

    .line 187
    .line 188
    :cond_5
    sub-int v9, v12, v2

    .line 189
    .line 190
    if-ne v6, v3, :cond_6

    .line 191
    .line 192
    move/from16 v2, v19

    .line 193
    .line 194
    :cond_6
    :goto_5
    if-lez v2, :cond_a

    .line 195
    .line 196
    aget-byte v3, v4, v9

    .line 197
    .line 198
    and-int/lit16 v6, v3, 0xff

    .line 199
    .line 200
    const/16 v10, 0xc0

    .line 201
    .line 202
    if-ge v6, v10, :cond_8

    .line 203
    .line 204
    const/16 v10, 0x61

    .line 205
    .line 206
    if-lt v6, v10, :cond_7

    .line 207
    .line 208
    const/16 v10, 0x7a

    .line 209
    .line 210
    if-gt v6, v10, :cond_7

    .line 211
    .line 212
    xor-int/lit8 v3, v3, 0x20

    .line 213
    .line 214
    int-to-byte v3, v3

    .line 215
    aput-byte v3, v4, v9

    .line 216
    .line 217
    :cond_7
    add-int/lit8 v9, v9, 0x1

    .line 218
    .line 219
    add-int/lit8 v2, v2, -0x1

    .line 220
    .line 221
    goto :goto_5

    .line 222
    :cond_8
    const/16 v3, 0xe0

    .line 223
    .line 224
    if-ge v6, v3, :cond_9

    .line 225
    .line 226
    add-int/lit8 v3, v9, 0x1

    .line 227
    .line 228
    aget-byte v6, v4, v3

    .line 229
    .line 230
    xor-int/lit8 v6, v6, 0x20

    .line 231
    .line 232
    int-to-byte v6, v6

    .line 233
    aput-byte v6, v4, v3

    .line 234
    .line 235
    add-int/lit8 v9, v9, 0x2

    .line 236
    .line 237
    add-int/lit8 v2, v2, -0x2

    .line 238
    .line 239
    goto :goto_5

    .line 240
    :cond_9
    add-int/lit8 v3, v9, 0x2

    .line 241
    .line 242
    aget-byte v6, v4, v3

    .line 243
    .line 244
    xor-int/lit8 v6, v6, 0x5

    .line 245
    .line 246
    int-to-byte v6, v6

    .line 247
    aput-byte v6, v4, v3

    .line 248
    .line 249
    add-int/lit8 v9, v9, 0x3

    .line 250
    .line 251
    add-int/lit8 v2, v2, -0x3

    .line 252
    .line 253
    goto :goto_5

    .line 254
    :cond_a
    iget-object v2, v5, LUg/g;->c:[B

    .line 255
    .line 256
    array-length v3, v2

    .line 257
    const/4 v5, 0x0

    .line 258
    :goto_6
    if-ge v5, v3, :cond_b

    .line 259
    .line 260
    add-int/lit8 v6, v12, 0x1

    .line 261
    .line 262
    add-int/lit8 v9, v5, 0x1

    .line 263
    .line 264
    aget-byte v5, v2, v5

    .line 265
    .line 266
    aput-byte v5, v4, v12

    .line 267
    .line 268
    move v12, v6

    .line 269
    move v5, v9

    .line 270
    goto :goto_6

    .line 271
    :cond_b
    sub-int/2addr v12, v7

    .line 272
    iget v2, v0, LUg/f;->M:I

    .line 273
    .line 274
    add-int/2addr v2, v12

    .line 275
    iput v2, v0, LUg/f;->M:I

    .line 276
    .line 277
    iget v3, v0, LUg/f;->r:I

    .line 278
    .line 279
    add-int/2addr v3, v12

    .line 280
    iput v3, v0, LUg/f;->r:I

    .line 281
    .line 282
    iget v3, v0, LUg/f;->g:I

    .line 283
    .line 284
    sub-int/2addr v3, v12

    .line 285
    iput v3, v0, LUg/f;->g:I

    .line 286
    .line 287
    iget v3, v0, LUg/f;->P:I

    .line 288
    .line 289
    if-lt v2, v3, :cond_c

    .line 290
    .line 291
    const/16 v2, 0x8

    .line 292
    .line 293
    iput v2, v0, LUg/f;->b:I

    .line 294
    .line 295
    iput v3, v0, LUg/f;->X:I

    .line 296
    .line 297
    const/4 v2, 0x0

    .line 298
    iput v2, v0, LUg/f;->W:I

    .line 299
    .line 300
    iput v13, v0, LUg/f;->a:I

    .line 301
    .line 302
    :goto_7
    move/from16 v26, v8

    .line 303
    .line 304
    goto/16 :goto_30

    .line 305
    .line 306
    :cond_c
    const/4 v2, 0x3

    .line 307
    iput v2, v0, LUg/f;->a:I

    .line 308
    .line 309
    goto :goto_7

    .line 310
    :cond_d
    new-instance v0, LUg/c;

    .line 311
    .line 312
    invoke-direct {v0, v9}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 313
    .line 314
    .line 315
    throw v0

    .line 316
    :cond_e
    new-instance v0, LUg/c;

    .line 317
    .line 318
    invoke-direct {v0, v9}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 319
    .line 320
    .line 321
    throw v0

    .line 322
    :pswitch_1
    const/16 v8, 0xb

    .line 323
    .line 324
    iget v2, v0, LUg/f;->P:I

    .line 325
    .line 326
    iget v3, v0, LUg/f;->M:I

    .line 327
    .line 328
    sub-int/2addr v3, v2

    .line 329
    const/4 v5, 0x0

    .line 330
    invoke-static {v4, v2, v4, v5, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 331
    .line 332
    .line 333
    const/4 v2, 0x3

    .line 334
    iput v2, v0, LUg/f;->a:I

    .line 335
    .line 336
    goto :goto_7

    .line 337
    :pswitch_2
    const/16 v26, 0xb

    .line 338
    .line 339
    goto/16 :goto_1c

    .line 340
    .line 341
    :pswitch_3
    move-object/from16 v25, v2

    .line 342
    .line 343
    move/from16 v27, v15

    .line 344
    .line 345
    const/4 v5, 0x0

    .line 346
    const/16 v26, 0xb

    .line 347
    .line 348
    goto/16 :goto_15

    .line 349
    .line 350
    :pswitch_4
    const/4 v5, 0x0

    .line 351
    const/16 v8, 0xb

    .line 352
    .line 353
    iget-object v2, v0, LUg/f;->d:[B

    .line 354
    .line 355
    iget v3, v0, LUg/f;->g:I

    .line 356
    .line 357
    if-gtz v3, :cond_10

    .line 358
    .line 359
    iget v2, v11, LUg/a;->g:I

    .line 360
    .line 361
    const/16 v3, 0x40

    .line 362
    .line 363
    if-ne v2, v3, :cond_f

    .line 364
    .line 365
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 366
    .line 367
    .line 368
    invoke-static {v11, v5}, LUg/a;->a(LUg/a;Z)V

    .line 369
    .line 370
    .line 371
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 372
    .line 373
    .line 374
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 375
    .line 376
    .line 377
    :cond_f
    move/from16 v2, v19

    .line 378
    .line 379
    iput v2, v0, LUg/f;->a:I

    .line 380
    .line 381
    goto :goto_7

    .line 382
    :cond_10
    iget v5, v0, LUg/f;->P:I

    .line 383
    .line 384
    iget v6, v0, LUg/f;->r:I

    .line 385
    .line 386
    sub-int/2addr v5, v6

    .line 387
    invoke-static {v5, v3}, Ljava/lang/Math;->min(II)I

    .line 388
    .line 389
    .line 390
    move-result v3

    .line 391
    iget v5, v0, LUg/f;->r:I

    .line 392
    .line 393
    iget v6, v11, LUg/a;->g:I

    .line 394
    .line 395
    and-int/lit8 v6, v6, 0x7

    .line 396
    .line 397
    if-nez v6, :cond_1b

    .line 398
    .line 399
    move v6, v3

    .line 400
    :goto_8
    iget v7, v11, LUg/a;->g:I

    .line 401
    .line 402
    const/16 v9, 0x40

    .line 403
    .line 404
    if-eq v7, v9, :cond_11

    .line 405
    .line 406
    if-eqz v6, :cond_11

    .line 407
    .line 408
    add-int/lit8 v9, v5, 0x1

    .line 409
    .line 410
    iget-wide v14, v11, LUg/a;->f:J

    .line 411
    .line 412
    ushr-long/2addr v14, v7

    .line 413
    long-to-int v10, v14

    .line 414
    int-to-byte v10, v10

    .line 415
    aput-byte v10, v2, v5

    .line 416
    .line 417
    add-int/lit8 v7, v7, 0x8

    .line 418
    .line 419
    iput v7, v11, LUg/a;->g:I

    .line 420
    .line 421
    add-int/lit8 v6, v6, -0x1

    .line 422
    .line 423
    move v5, v9

    .line 424
    goto :goto_8

    .line 425
    :cond_11
    if-nez v6, :cond_12

    .line 426
    .line 427
    goto :goto_b

    .line 428
    :cond_12
    invoke-static {v11}, LUg/a;->c(LUg/a;)I

    .line 429
    .line 430
    .line 431
    move-result v7

    .line 432
    shr-int/lit8 v9, v6, 0x2

    .line 433
    .line 434
    invoke-static {v7, v9}, Ljava/lang/Math;->min(II)I

    .line 435
    .line 436
    .line 437
    move-result v7

    .line 438
    if-lez v7, :cond_13

    .line 439
    .line 440
    iget v9, v11, LUg/a;->h:I

    .line 441
    .line 442
    shl-int/lit8 v9, v9, 0x2

    .line 443
    .line 444
    shl-int/lit8 v10, v7, 0x2

    .line 445
    .line 446
    iget-object v12, v11, LUg/a;->a:[B

    .line 447
    .line 448
    invoke-static {v12, v9, v2, v5, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 449
    .line 450
    .line 451
    add-int/2addr v5, v10

    .line 452
    sub-int/2addr v6, v10

    .line 453
    iget v9, v11, LUg/a;->h:I

    .line 454
    .line 455
    add-int/2addr v9, v7

    .line 456
    iput v9, v11, LUg/a;->h:I

    .line 457
    .line 458
    :cond_13
    if-nez v6, :cond_14

    .line 459
    .line 460
    goto :goto_b

    .line 461
    :cond_14
    invoke-static {v11}, LUg/a;->c(LUg/a;)I

    .line 462
    .line 463
    .line 464
    move-result v7

    .line 465
    if-lez v7, :cond_16

    .line 466
    .line 467
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 468
    .line 469
    .line 470
    :goto_9
    if-eqz v6, :cond_15

    .line 471
    .line 472
    add-int/lit8 v7, v5, 0x1

    .line 473
    .line 474
    iget-wide v9, v11, LUg/a;->f:J

    .line 475
    .line 476
    iget v12, v11, LUg/a;->g:I

    .line 477
    .line 478
    ushr-long/2addr v9, v12

    .line 479
    long-to-int v9, v9

    .line 480
    int-to-byte v9, v9

    .line 481
    aput-byte v9, v2, v5

    .line 482
    .line 483
    const/16 v25, 0x8

    .line 484
    .line 485
    add-int/lit8 v12, v12, 0x8

    .line 486
    .line 487
    iput v12, v11, LUg/a;->g:I

    .line 488
    .line 489
    add-int/lit8 v6, v6, -0x1

    .line 490
    .line 491
    move v5, v7

    .line 492
    goto :goto_9

    .line 493
    :cond_15
    const/4 v5, 0x0

    .line 494
    invoke-static {v11, v5}, LUg/a;->a(LUg/a;Z)V

    .line 495
    .line 496
    .line 497
    goto :goto_b

    .line 498
    :cond_16
    :goto_a
    if-lez v6, :cond_18

    .line 499
    .line 500
    :try_start_0
    iget-object v7, v11, LUg/a;->d:Ljava/io/InputStream;

    .line 501
    .line 502
    invoke-virtual {v7, v2, v5, v6}, Ljava/io/InputStream;->read([BII)I

    .line 503
    .line 504
    .line 505
    move-result v7

    .line 506
    const/4 v9, -0x1

    .line 507
    if-eq v7, v9, :cond_17

    .line 508
    .line 509
    add-int/2addr v5, v7

    .line 510
    sub-int/2addr v6, v7

    .line 511
    goto :goto_a

    .line 512
    :cond_17
    new-instance v0, LUg/c;

    .line 513
    .line 514
    const-string v1, "Unexpected end of input"

    .line 515
    .line 516
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 517
    .line 518
    .line 519
    throw v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 520
    :catch_0
    move-exception v0

    .line 521
    new-instance v1, LUg/c;

    .line 522
    .line 523
    const-string v2, "Failed to read input"

    .line 524
    .line 525
    invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 526
    .line 527
    .line 528
    throw v1

    .line 529
    :cond_18
    :goto_b
    iget v2, v0, LUg/f;->g:I

    .line 530
    .line 531
    sub-int/2addr v2, v3

    .line 532
    iput v2, v0, LUg/f;->g:I

    .line 533
    .line 534
    iget v2, v0, LUg/f;->r:I

    .line 535
    .line 536
    add-int/2addr v2, v3

    .line 537
    iput v2, v0, LUg/f;->r:I

    .line 538
    .line 539
    iget v3, v0, LUg/f;->P:I

    .line 540
    .line 541
    if-ne v2, v3, :cond_19

    .line 542
    .line 543
    move/from16 v2, v23

    .line 544
    .line 545
    iput v2, v0, LUg/f;->b:I

    .line 546
    .line 547
    iput v3, v0, LUg/f;->X:I

    .line 548
    .line 549
    const/4 v5, 0x0

    .line 550
    iput v5, v0, LUg/f;->W:I

    .line 551
    .line 552
    iput v13, v0, LUg/f;->a:I

    .line 553
    .line 554
    goto/16 :goto_7

    .line 555
    .line 556
    :cond_19
    const/4 v5, 0x0

    .line 557
    iget v2, v11, LUg/a;->g:I

    .line 558
    .line 559
    const/16 v3, 0x40

    .line 560
    .line 561
    if-ne v2, v3, :cond_1a

    .line 562
    .line 563
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 564
    .line 565
    .line 566
    invoke-static {v11, v5}, LUg/a;->a(LUg/a;Z)V

    .line 567
    .line 568
    .line 569
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 570
    .line 571
    .line 572
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 573
    .line 574
    .line 575
    :cond_1a
    const/4 v2, 0x1

    .line 576
    iput v2, v0, LUg/f;->a:I

    .line 577
    .line 578
    goto/16 :goto_7

    .line 579
    .line 580
    :cond_1b
    new-instance v0, LUg/c;

    .line 581
    .line 582
    const-string v1, "Unaligned copyBytes"

    .line 583
    .line 584
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 585
    .line 586
    .line 587
    throw v0

    .line 588
    :pswitch_5
    const/16 v8, 0xb

    .line 589
    .line 590
    :goto_c
    iget v2, v0, LUg/f;->g:I

    .line 591
    .line 592
    if-lez v2, :cond_1c

    .line 593
    .line 594
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 595
    .line 596
    .line 597
    const/16 v2, 0x8

    .line 598
    .line 599
    invoke-static {v11, v2}, LUg/a;->d(LUg/a;I)I

    .line 600
    .line 601
    .line 602
    iget v2, v0, LUg/f;->g:I

    .line 603
    .line 604
    const/4 v5, 0x1

    .line 605
    sub-int/2addr v2, v5

    .line 606
    iput v2, v0, LUg/f;->g:I

    .line 607
    .line 608
    goto :goto_c

    .line 609
    :cond_1c
    const/4 v5, 0x1

    .line 610
    iput v5, v0, LUg/f;->a:I

    .line 611
    .line 612
    goto/16 :goto_7

    .line 613
    .line 614
    :pswitch_6
    const/16 v26, 0xb

    .line 615
    .line 616
    move-object/from16 v25, v2

    .line 617
    .line 618
    move/from16 v27, v15

    .line 619
    .line 620
    move/from16 v6, v19

    .line 621
    .line 622
    goto/16 :goto_14

    .line 623
    .line 624
    :pswitch_7
    move/from16 v5, v19

    .line 625
    .line 626
    const/16 v26, 0xb

    .line 627
    .line 628
    const/4 v6, 0x0

    .line 629
    :goto_d
    iget-object v7, v0, LUg/f;->o:[I

    .line 630
    .line 631
    const/4 v3, 0x3

    .line 632
    if-ge v6, v3, :cond_20

    .line 633
    .line 634
    invoke-static {v11, v5}, LUg/a;->d(LUg/a;I)I

    .line 635
    .line 636
    .line 637
    move-result v19

    .line 638
    if-eqz v19, :cond_1e

    .line 639
    .line 640
    invoke-static {v11, v3}, LUg/a;->d(LUg/a;I)I

    .line 641
    .line 642
    .line 643
    move-result v13

    .line 644
    if-nez v13, :cond_1d

    .line 645
    .line 646
    move/from16 v19, v5

    .line 647
    .line 648
    goto :goto_e

    .line 649
    :cond_1d
    invoke-static {v11, v13}, LUg/a;->d(LUg/a;I)I

    .line 650
    .line 651
    .line 652
    move-result v3

    .line 653
    shl-int v13, v5, v13

    .line 654
    .line 655
    add-int v19, v3, v13

    .line 656
    .line 657
    goto :goto_e

    .line 658
    :cond_1e
    const/16 v19, 0x0

    .line 659
    .line 660
    :goto_e
    add-int/lit8 v19, v19, 0x1

    .line 661
    .line 662
    aput v19, v7, v6

    .line 663
    .line 664
    const/high16 v3, 0x10000000

    .line 665
    .line 666
    aput v3, v2, v6

    .line 667
    .line 668
    aget v3, v7, v6

    .line 669
    .line 670
    if-le v3, v5, :cond_1f

    .line 671
    .line 672
    add-int/lit8 v3, v3, 0x2

    .line 673
    .line 674
    mul-int/lit16 v5, v6, 0x438

    .line 675
    .line 676
    iget-object v7, v0, LUg/f;->e:[I

    .line 677
    .line 678
    invoke-static {v3, v7, v5, v11}, LUg/d;->f(I[IILUg/a;)V

    .line 679
    .line 680
    .line 681
    const/16 v3, 0x1a

    .line 682
    .line 683
    iget-object v7, v0, LUg/f;->f:[I

    .line 684
    .line 685
    invoke-static {v3, v7, v5, v11}, LUg/d;->f(I[IILUg/a;)V

    .line 686
    .line 687
    .line 688
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 689
    .line 690
    .line 691
    invoke-static {v7, v5, v11}, LUg/d;->g([IILUg/a;)I

    .line 692
    .line 693
    .line 694
    move-result v3

    .line 695
    sget-object v5, LUg/d;->j:[I

    .line 696
    .line 697
    aget v5, v5, v3

    .line 698
    .line 699
    sget-object v7, LUg/d;->i:[I

    .line 700
    .line 701
    aget v3, v7, v3

    .line 702
    .line 703
    invoke-static {v11, v5}, LUg/a;->d(LUg/a;I)I

    .line 704
    .line 705
    .line 706
    move-result v5

    .line 707
    add-int/2addr v5, v3

    .line 708
    aput v5, v2, v6

    .line 709
    .line 710
    :cond_1f
    add-int/lit8 v6, v6, 0x1

    .line 711
    .line 712
    const/16 v3, 0x9

    .line 713
    .line 714
    const/4 v5, 0x1

    .line 715
    const/16 v13, 0xc

    .line 716
    .line 717
    goto :goto_d

    .line 718
    :cond_20
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 719
    .line 720
    .line 721
    move/from16 v3, v20

    .line 722
    .line 723
    invoke-static {v11, v3}, LUg/a;->d(LUg/a;I)I

    .line 724
    .line 725
    .line 726
    move-result v5

    .line 727
    iput v5, v0, LUg/f;->J:I

    .line 728
    .line 729
    invoke-static {v11, v15}, LUg/a;->d(LUg/a;I)I

    .line 730
    .line 731
    .line 732
    move-result v3

    .line 733
    iget v5, v0, LUg/f;->J:I

    .line 734
    .line 735
    shl-int/2addr v3, v5

    .line 736
    add-int/lit8 v3, v3, 0x10

    .line 737
    .line 738
    iput v3, v0, LUg/f;->H:I

    .line 739
    .line 740
    const/16 v19, 0x1

    .line 741
    .line 742
    shl-int v6, v19, v5

    .line 743
    .line 744
    add-int/lit8 v6, v6, -0x1

    .line 745
    .line 746
    iput v6, v0, LUg/f;->I:I

    .line 747
    .line 748
    const/16 v6, 0x30

    .line 749
    .line 750
    shl-int v5, v6, v5

    .line 751
    .line 752
    add-int/2addr v3, v5

    .line 753
    const/16 v24, 0x0

    .line 754
    .line 755
    aget v5, v7, v24

    .line 756
    .line 757
    new-array v5, v5, [B

    .line 758
    .line 759
    iput-object v5, v0, LUg/f;->y:[B

    .line 760
    .line 761
    move/from16 v5, v24

    .line 762
    .line 763
    :goto_f
    aget v6, v7, v24

    .line 764
    .line 765
    if-ge v5, v6, :cond_22

    .line 766
    .line 767
    add-int/lit8 v13, v5, 0x60

    .line 768
    .line 769
    invoke-static {v13, v6}, Ljava/lang/Math;->min(II)I

    .line 770
    .line 771
    .line 772
    move-result v6

    .line 773
    :goto_10
    if-ge v5, v6, :cond_21

    .line 774
    .line 775
    iget-object v13, v0, LUg/f;->y:[B

    .line 776
    .line 777
    move/from16 v27, v15

    .line 778
    .line 779
    const/4 v15, 0x2

    .line 780
    invoke-static {v11, v15}, LUg/a;->d(LUg/a;I)I

    .line 781
    .line 782
    .line 783
    move-result v25

    .line 784
    const/16 v19, 0x1

    .line 785
    .line 786
    shl-int/lit8 v15, v25, 0x1

    .line 787
    .line 788
    int-to-byte v15, v15

    .line 789
    aput-byte v15, v13, v5

    .line 790
    .line 791
    add-int/lit8 v5, v5, 0x1

    .line 792
    .line 793
    move/from16 v15, v27

    .line 794
    .line 795
    goto :goto_10

    .line 796
    :cond_21
    move/from16 v27, v15

    .line 797
    .line 798
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 799
    .line 800
    .line 801
    const/16 v24, 0x0

    .line 802
    .line 803
    goto :goto_f

    .line 804
    :cond_22
    move/from16 v27, v15

    .line 805
    .line 806
    shl-int/lit8 v5, v6, 0x6

    .line 807
    .line 808
    new-array v6, v5, [B

    .line 809
    .line 810
    iput-object v6, v0, LUg/f;->z:[B

    .line 811
    .line 812
    invoke-static {v5, v6, v11}, LUg/d;->c(I[BLUg/a;)I

    .line 813
    .line 814
    .line 815
    move-result v5

    .line 816
    const/4 v6, 0x1

    .line 817
    iput-boolean v6, v0, LUg/f;->u:Z

    .line 818
    .line 819
    const/4 v6, 0x0

    .line 820
    :goto_11
    const/4 v13, 0x0

    .line 821
    aget v15, v7, v13

    .line 822
    .line 823
    shl-int/lit8 v15, v15, 0x6

    .line 824
    .line 825
    if-ge v6, v15, :cond_24

    .line 826
    .line 827
    iget-object v15, v0, LUg/f;->z:[B

    .line 828
    .line 829
    aget-byte v15, v15, v6

    .line 830
    .line 831
    move-object/from16 v25, v2

    .line 832
    .line 833
    shr-int/lit8 v2, v6, 0x6

    .line 834
    .line 835
    if-eq v15, v2, :cond_23

    .line 836
    .line 837
    iput-boolean v13, v0, LUg/f;->u:Z

    .line 838
    .line 839
    :goto_12
    const/16 v20, 0x2

    .line 840
    .line 841
    goto :goto_13

    .line 842
    :cond_23
    add-int/lit8 v6, v6, 0x1

    .line 843
    .line 844
    move-object/from16 v2, v25

    .line 845
    .line 846
    goto :goto_11

    .line 847
    :cond_24
    move-object/from16 v25, v2

    .line 848
    .line 849
    goto :goto_12

    .line 850
    :goto_13
    aget v2, v7, v20

    .line 851
    .line 852
    shl-int/lit8 v2, v2, 0x2

    .line 853
    .line 854
    new-array v6, v2, [B

    .line 855
    .line 856
    iput-object v6, v0, LUg/f;->G:[B

    .line 857
    .line 858
    invoke-static {v2, v6, v11}, LUg/d;->c(I[BLUg/a;)I

    .line 859
    .line 860
    .line 861
    move-result v2

    .line 862
    const/16 v6, 0x100

    .line 863
    .line 864
    iput v6, v10, LPa/b;->b:I

    .line 865
    .line 866
    mul-int/lit16 v6, v5, 0x438

    .line 867
    .line 868
    new-array v6, v6, [I

    .line 869
    .line 870
    iput-object v6, v10, LPa/b;->c:Ljava/lang/Object;

    .line 871
    .line 872
    new-array v5, v5, [I

    .line 873
    .line 874
    iput-object v5, v10, LPa/b;->d:Ljava/lang/Object;

    .line 875
    .line 876
    const/16 v19, 0x1

    .line 877
    .line 878
    aget v5, v7, v19

    .line 879
    .line 880
    const/16 v6, 0x2c0

    .line 881
    .line 882
    iput v6, v8, LPa/b;->b:I

    .line 883
    .line 884
    mul-int/lit16 v6, v5, 0x438

    .line 885
    .line 886
    new-array v6, v6, [I

    .line 887
    .line 888
    iput-object v6, v8, LPa/b;->c:Ljava/lang/Object;

    .line 889
    .line 890
    new-array v5, v5, [I

    .line 891
    .line 892
    iput-object v5, v8, LPa/b;->d:Ljava/lang/Object;

    .line 893
    .line 894
    iput v3, v12, LPa/b;->b:I

    .line 895
    .line 896
    mul-int/lit16 v3, v2, 0x438

    .line 897
    .line 898
    new-array v3, v3, [I

    .line 899
    .line 900
    iput-object v3, v12, LPa/b;->c:Ljava/lang/Object;

    .line 901
    .line 902
    new-array v2, v2, [I

    .line 903
    .line 904
    iput-object v2, v12, LPa/b;->d:Ljava/lang/Object;

    .line 905
    .line 906
    invoke-static {v10, v11}, LPa/b;->d(LPa/b;LUg/a;)V

    .line 907
    .line 908
    .line 909
    invoke-static {v8, v11}, LPa/b;->d(LPa/b;LUg/a;)V

    .line 910
    .line 911
    .line 912
    invoke-static {v12, v11}, LPa/b;->d(LPa/b;LUg/a;)V

    .line 913
    .line 914
    .line 915
    const/4 v5, 0x0

    .line 916
    iput v5, v0, LUg/f;->A:I

    .line 917
    .line 918
    iput v5, v0, LUg/f;->B:I

    .line 919
    .line 920
    sget-object v2, LUg/d;->b:[I

    .line 921
    .line 922
    iget-object v3, v0, LUg/f;->y:[B

    .line 923
    .line 924
    aget-byte v3, v3, v5

    .line 925
    .line 926
    aget v6, v2, v3

    .line 927
    .line 928
    iput v6, v0, LUg/f;->C:I

    .line 929
    .line 930
    const/4 v6, 0x1

    .line 931
    add-int/2addr v3, v6

    .line 932
    aget v2, v2, v3

    .line 933
    .line 934
    iput v2, v0, LUg/f;->D:I

    .line 935
    .line 936
    iget-object v2, v10, LPa/b;->d:Ljava/lang/Object;

    .line 937
    .line 938
    check-cast v2, [I

    .line 939
    .line 940
    aget v2, v2, v5

    .line 941
    .line 942
    iput v2, v0, LUg/f;->v:I

    .line 943
    .line 944
    iget-object v2, v8, LPa/b;->d:Ljava/lang/Object;

    .line 945
    .line 946
    check-cast v2, [I

    .line 947
    .line 948
    aget v2, v2, v5

    .line 949
    .line 950
    iput v2, v0, LUg/f;->E:I

    .line 951
    .line 952
    aput v6, v14, v27

    .line 953
    .line 954
    const/16 v20, 0x2

    .line 955
    .line 956
    aput v6, v14, v20

    .line 957
    .line 958
    aput v6, v14, v5

    .line 959
    .line 960
    const/16 v23, 0x5

    .line 961
    .line 962
    aput v5, v14, v23

    .line 963
    .line 964
    const/4 v2, 0x3

    .line 965
    aput v5, v14, v2

    .line 966
    .line 967
    aput v5, v14, v6

    .line 968
    .line 969
    iput v2, v0, LUg/f;->a:I

    .line 970
    .line 971
    :goto_14
    iget v2, v0, LUg/f;->g:I

    .line 972
    .line 973
    if-gtz v2, :cond_25

    .line 974
    .line 975
    iput v6, v0, LUg/f;->a:I

    .line 976
    .line 977
    goto/16 :goto_30

    .line 978
    .line 979
    :cond_25
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 980
    .line 981
    .line 982
    aget v2, v25, v6

    .line 983
    .line 984
    if-nez v2, :cond_26

    .line 985
    .line 986
    invoke-static {v0, v6}, LUg/d;->b(LUg/f;I)V

    .line 987
    .line 988
    .line 989
    iget-object v2, v8, LPa/b;->d:Ljava/lang/Object;

    .line 990
    .line 991
    check-cast v2, [I

    .line 992
    .line 993
    const/16 v22, 0x3

    .line 994
    .line 995
    aget v3, v14, v22

    .line 996
    .line 997
    aget v2, v2, v3

    .line 998
    .line 999
    iput v2, v0, LUg/f;->E:I

    .line 1000
    .line 1001
    :cond_26
    aget v2, v25, v6

    .line 1002
    .line 1003
    sub-int/2addr v2, v6

    .line 1004
    aput v2, v25, v6

    .line 1005
    .line 1006
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 1007
    .line 1008
    .line 1009
    iget-object v2, v8, LPa/b;->c:Ljava/lang/Object;

    .line 1010
    .line 1011
    check-cast v2, [I

    .line 1012
    .line 1013
    iget v3, v0, LUg/f;->E:I

    .line 1014
    .line 1015
    invoke-static {v2, v3, v11}, LUg/d;->g([IILUg/a;)I

    .line 1016
    .line 1017
    .line 1018
    move-result v2

    .line 1019
    ushr-int/lit8 v3, v2, 0x6

    .line 1020
    .line 1021
    const/4 v5, 0x0

    .line 1022
    iput v5, v0, LUg/f;->F:I

    .line 1023
    .line 1024
    const/4 v15, 0x2

    .line 1025
    if-lt v3, v15, :cond_27

    .line 1026
    .line 1027
    add-int/lit8 v3, v3, -0x2

    .line 1028
    .line 1029
    const/4 v5, -0x1

    .line 1030
    iput v5, v0, LUg/f;->F:I

    .line 1031
    .line 1032
    :cond_27
    sget-object v5, LUg/d;->o:[I

    .line 1033
    .line 1034
    aget v5, v5, v3

    .line 1035
    .line 1036
    ushr-int/lit8 v6, v2, 0x3

    .line 1037
    .line 1038
    and-int/lit8 v6, v6, 0x7

    .line 1039
    .line 1040
    add-int/2addr v5, v6

    .line 1041
    sget-object v6, LUg/d;->p:[I

    .line 1042
    .line 1043
    aget v3, v6, v3

    .line 1044
    .line 1045
    and-int/lit8 v2, v2, 0x7

    .line 1046
    .line 1047
    add-int/2addr v3, v2

    .line 1048
    sget-object v2, LUg/d;->k:[I

    .line 1049
    .line 1050
    aget v2, v2, v5

    .line 1051
    .line 1052
    sget-object v6, LUg/d;->l:[I

    .line 1053
    .line 1054
    aget v5, v6, v5

    .line 1055
    .line 1056
    invoke-static {v11, v5}, LUg/a;->d(LUg/a;I)I

    .line 1057
    .line 1058
    .line 1059
    move-result v5

    .line 1060
    add-int/2addr v5, v2

    .line 1061
    iput v5, v0, LUg/f;->x:I

    .line 1062
    .line 1063
    sget-object v2, LUg/d;->m:[I

    .line 1064
    .line 1065
    aget v2, v2, v3

    .line 1066
    .line 1067
    sget-object v5, LUg/d;->n:[I

    .line 1068
    .line 1069
    aget v3, v5, v3

    .line 1070
    .line 1071
    invoke-static {v11, v3}, LUg/a;->d(LUg/a;I)I

    .line 1072
    .line 1073
    .line 1074
    move-result v3

    .line 1075
    add-int/2addr v3, v2

    .line 1076
    iput v3, v0, LUg/f;->L:I

    .line 1077
    .line 1078
    const/4 v5, 0x0

    .line 1079
    iput v5, v0, LUg/f;->w:I

    .line 1080
    .line 1081
    move/from16 v2, v18

    .line 1082
    .line 1083
    iput v2, v0, LUg/f;->a:I

    .line 1084
    .line 1085
    :goto_15
    iget-boolean v2, v0, LUg/f;->u:Z

    .line 1086
    .line 1087
    if-eqz v2, :cond_2b

    .line 1088
    .line 1089
    :goto_16
    iget v2, v0, LUg/f;->w:I

    .line 1090
    .line 1091
    iget v3, v0, LUg/f;->x:I

    .line 1092
    .line 1093
    if-ge v2, v3, :cond_29

    .line 1094
    .line 1095
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 1096
    .line 1097
    .line 1098
    aget v2, v25, v5

    .line 1099
    .line 1100
    if-nez v2, :cond_28

    .line 1101
    .line 1102
    invoke-static {v0}, LUg/d;->d(LUg/f;)V

    .line 1103
    .line 1104
    .line 1105
    :cond_28
    aget v2, v25, v5

    .line 1106
    .line 1107
    const/16 v19, 0x1

    .line 1108
    .line 1109
    add-int/lit8 v2, v2, -0x1

    .line 1110
    .line 1111
    aput v2, v25, v5

    .line 1112
    .line 1113
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 1114
    .line 1115
    .line 1116
    iget v2, v0, LUg/f;->r:I

    .line 1117
    .line 1118
    iget-object v3, v10, LPa/b;->c:Ljava/lang/Object;

    .line 1119
    .line 1120
    check-cast v3, [I

    .line 1121
    .line 1122
    iget v5, v0, LUg/f;->v:I

    .line 1123
    .line 1124
    invoke-static {v3, v5, v11}, LUg/d;->g([IILUg/a;)I

    .line 1125
    .line 1126
    .line 1127
    move-result v3

    .line 1128
    int-to-byte v3, v3

    .line 1129
    aput-byte v3, v4, v2

    .line 1130
    .line 1131
    iget v2, v0, LUg/f;->w:I

    .line 1132
    .line 1133
    add-int/lit8 v2, v2, 0x1

    .line 1134
    .line 1135
    iput v2, v0, LUg/f;->w:I

    .line 1136
    .line 1137
    iget v2, v0, LUg/f;->r:I

    .line 1138
    .line 1139
    add-int/lit8 v3, v2, 0x1

    .line 1140
    .line 1141
    iput v3, v0, LUg/f;->r:I

    .line 1142
    .line 1143
    if-ne v2, v1, :cond_2a

    .line 1144
    .line 1145
    const/4 v2, 0x6

    .line 1146
    iput v2, v0, LUg/f;->b:I

    .line 1147
    .line 1148
    iget v2, v0, LUg/f;->P:I

    .line 1149
    .line 1150
    iput v2, v0, LUg/f;->X:I

    .line 1151
    .line 1152
    const/4 v5, 0x0

    .line 1153
    iput v5, v0, LUg/f;->W:I

    .line 1154
    .line 1155
    const/16 v2, 0xc

    .line 1156
    .line 1157
    iput v2, v0, LUg/f;->a:I

    .line 1158
    .line 1159
    :cond_29
    const/4 v5, 0x6

    .line 1160
    goto/16 :goto_18

    .line 1161
    .line 1162
    :cond_2a
    const/4 v5, 0x0

    .line 1163
    goto :goto_16

    .line 1164
    :cond_2b
    iget v2, v0, LUg/f;->r:I

    .line 1165
    .line 1166
    add-int/lit8 v3, v2, -0x1

    .line 1167
    .line 1168
    and-int/2addr v3, v1

    .line 1169
    aget-byte v3, v4, v3

    .line 1170
    .line 1171
    and-int/lit16 v3, v3, 0xff

    .line 1172
    .line 1173
    const/16 v20, 0x2

    .line 1174
    .line 1175
    add-int/lit8 v2, v2, -0x2

    .line 1176
    .line 1177
    and-int/2addr v2, v1

    .line 1178
    aget-byte v2, v4, v2

    .line 1179
    .line 1180
    and-int/lit16 v2, v2, 0xff

    .line 1181
    .line 1182
    :goto_17
    iget v5, v0, LUg/f;->w:I

    .line 1183
    .line 1184
    iget v6, v0, LUg/f;->x:I

    .line 1185
    .line 1186
    if-ge v5, v6, :cond_29

    .line 1187
    .line 1188
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 1189
    .line 1190
    .line 1191
    const/16 v24, 0x0

    .line 1192
    .line 1193
    aget v5, v25, v24

    .line 1194
    .line 1195
    if-nez v5, :cond_2c

    .line 1196
    .line 1197
    invoke-static {v0}, LUg/d;->d(LUg/f;)V

    .line 1198
    .line 1199
    .line 1200
    :cond_2c
    iget-object v5, v0, LUg/f;->z:[B

    .line 1201
    .line 1202
    iget v6, v0, LUg/f;->A:I

    .line 1203
    .line 1204
    sget-object v7, LUg/d;->a:[I

    .line 1205
    .line 1206
    iget v8, v0, LUg/f;->C:I

    .line 1207
    .line 1208
    add-int/2addr v8, v3

    .line 1209
    aget v8, v7, v8

    .line 1210
    .line 1211
    iget v13, v0, LUg/f;->D:I

    .line 1212
    .line 1213
    add-int/2addr v13, v2

    .line 1214
    aget v2, v7, v13

    .line 1215
    .line 1216
    or-int/2addr v2, v8

    .line 1217
    add-int/2addr v6, v2

    .line 1218
    aget-byte v2, v5, v6

    .line 1219
    .line 1220
    and-int/lit16 v2, v2, 0xff

    .line 1221
    .line 1222
    const/16 v24, 0x0

    .line 1223
    .line 1224
    aget v5, v25, v24

    .line 1225
    .line 1226
    const/16 v19, 0x1

    .line 1227
    .line 1228
    add-int/lit8 v5, v5, -0x1

    .line 1229
    .line 1230
    aput v5, v25, v24

    .line 1231
    .line 1232
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 1233
    .line 1234
    .line 1235
    iget-object v5, v10, LPa/b;->c:Ljava/lang/Object;

    .line 1236
    .line 1237
    check-cast v5, [I

    .line 1238
    .line 1239
    iget-object v6, v10, LPa/b;->d:Ljava/lang/Object;

    .line 1240
    .line 1241
    check-cast v6, [I

    .line 1242
    .line 1243
    aget v2, v6, v2

    .line 1244
    .line 1245
    invoke-static {v5, v2, v11}, LUg/d;->g([IILUg/a;)I

    .line 1246
    .line 1247
    .line 1248
    move-result v2

    .line 1249
    iget v5, v0, LUg/f;->r:I

    .line 1250
    .line 1251
    int-to-byte v6, v2

    .line 1252
    aput-byte v6, v4, v5

    .line 1253
    .line 1254
    iget v6, v0, LUg/f;->w:I

    .line 1255
    .line 1256
    const/16 v19, 0x1

    .line 1257
    .line 1258
    add-int/lit8 v6, v6, 0x1

    .line 1259
    .line 1260
    iput v6, v0, LUg/f;->w:I

    .line 1261
    .line 1262
    add-int/lit8 v6, v5, 0x1

    .line 1263
    .line 1264
    iput v6, v0, LUg/f;->r:I

    .line 1265
    .line 1266
    if-ne v5, v1, :cond_2d

    .line 1267
    .line 1268
    const/4 v5, 0x6

    .line 1269
    iput v5, v0, LUg/f;->b:I

    .line 1270
    .line 1271
    iget v2, v0, LUg/f;->P:I

    .line 1272
    .line 1273
    iput v2, v0, LUg/f;->X:I

    .line 1274
    .line 1275
    const/4 v2, 0x0

    .line 1276
    iput v2, v0, LUg/f;->W:I

    .line 1277
    .line 1278
    const/16 v2, 0xc

    .line 1279
    .line 1280
    iput v2, v0, LUg/f;->a:I

    .line 1281
    .line 1282
    goto :goto_18

    .line 1283
    :cond_2d
    move/from16 v28, v3

    .line 1284
    .line 1285
    move v3, v2

    .line 1286
    move/from16 v2, v28

    .line 1287
    .line 1288
    goto :goto_17

    .line 1289
    :goto_18
    iget v2, v0, LUg/f;->a:I

    .line 1290
    .line 1291
    if-eq v2, v5, :cond_2e

    .line 1292
    .line 1293
    goto/16 :goto_30

    .line 1294
    .line 1295
    :cond_2e
    iget v2, v0, LUg/f;->g:I

    .line 1296
    .line 1297
    iget v3, v0, LUg/f;->x:I

    .line 1298
    .line 1299
    sub-int/2addr v2, v3

    .line 1300
    iput v2, v0, LUg/f;->g:I

    .line 1301
    .line 1302
    if-gtz v2, :cond_2f

    .line 1303
    .line 1304
    const/4 v2, 0x3

    .line 1305
    iput v2, v0, LUg/f;->a:I

    .line 1306
    .line 1307
    goto/16 :goto_30

    .line 1308
    .line 1309
    :cond_2f
    iget v2, v0, LUg/f;->F:I

    .line 1310
    .line 1311
    if-gez v2, :cond_32

    .line 1312
    .line 1313
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 1314
    .line 1315
    .line 1316
    const/4 v15, 0x2

    .line 1317
    aget v2, v25, v15

    .line 1318
    .line 1319
    if-nez v2, :cond_30

    .line 1320
    .line 1321
    invoke-static {v0, v15}, LUg/d;->b(LUg/f;I)V

    .line 1322
    .line 1323
    .line 1324
    const/16 v23, 0x5

    .line 1325
    .line 1326
    aget v2, v14, v23

    .line 1327
    .line 1328
    shl-int/2addr v2, v15

    .line 1329
    iput v2, v0, LUg/f;->B:I

    .line 1330
    .line 1331
    :cond_30
    aget v2, v25, v15

    .line 1332
    .line 1333
    const/16 v19, 0x1

    .line 1334
    .line 1335
    add-int/lit8 v2, v2, -0x1

    .line 1336
    .line 1337
    aput v2, v25, v15

    .line 1338
    .line 1339
    invoke-static {v11}, LUg/a;->b(LUg/a;)V

    .line 1340
    .line 1341
    .line 1342
    iget-object v2, v12, LPa/b;->c:Ljava/lang/Object;

    .line 1343
    .line 1344
    check-cast v2, [I

    .line 1345
    .line 1346
    iget-object v3, v12, LPa/b;->d:Ljava/lang/Object;

    .line 1347
    .line 1348
    check-cast v3, [I

    .line 1349
    .line 1350
    iget-object v5, v0, LUg/f;->G:[B

    .line 1351
    .line 1352
    iget v6, v0, LUg/f;->B:I

    .line 1353
    .line 1354
    iget v7, v0, LUg/f;->L:I

    .line 1355
    .line 1356
    move/from16 v8, v27

    .line 1357
    .line 1358
    if-le v7, v8, :cond_31

    .line 1359
    .line 1360
    const/4 v7, 0x3

    .line 1361
    goto :goto_19

    .line 1362
    :cond_31
    add-int/lit8 v7, v7, -0x2

    .line 1363
    .line 1364
    :goto_19
    add-int/2addr v6, v7

    .line 1365
    aget-byte v5, v5, v6

    .line 1366
    .line 1367
    and-int/lit16 v5, v5, 0xff

    .line 1368
    .line 1369
    aget v3, v3, v5

    .line 1370
    .line 1371
    invoke-static {v2, v3, v11}, LUg/d;->g([IILUg/a;)I

    .line 1372
    .line 1373
    .line 1374
    move-result v2

    .line 1375
    iput v2, v0, LUg/f;->F:I

    .line 1376
    .line 1377
    iget v3, v0, LUg/f;->H:I

    .line 1378
    .line 1379
    if-lt v2, v3, :cond_32

    .line 1380
    .line 1381
    sub-int/2addr v2, v3

    .line 1382
    iget v5, v0, LUg/f;->I:I

    .line 1383
    .line 1384
    and-int/2addr v5, v2

    .line 1385
    iget v6, v0, LUg/f;->J:I

    .line 1386
    .line 1387
    ushr-int/2addr v2, v6

    .line 1388
    iput v2, v0, LUg/f;->F:I

    .line 1389
    .line 1390
    ushr-int/lit8 v6, v2, 0x1

    .line 1391
    .line 1392
    const/16 v19, 0x1

    .line 1393
    .line 1394
    add-int/lit8 v6, v6, 0x1

    .line 1395
    .line 1396
    and-int/lit8 v2, v2, 0x1

    .line 1397
    .line 1398
    const/16 v20, 0x2

    .line 1399
    .line 1400
    add-int/lit8 v2, v2, 0x2

    .line 1401
    .line 1402
    shl-int/2addr v2, v6

    .line 1403
    const/16 v27, 0x4

    .line 1404
    .line 1405
    add-int/lit8 v2, v2, -0x4

    .line 1406
    .line 1407
    add-int/2addr v3, v5

    .line 1408
    invoke-static {v11, v6}, LUg/a;->d(LUg/a;I)I

    .line 1409
    .line 1410
    .line 1411
    move-result v5

    .line 1412
    add-int/2addr v5, v2

    .line 1413
    iget v2, v0, LUg/f;->J:I

    .line 1414
    .line 1415
    shl-int v2, v5, v2

    .line 1416
    .line 1417
    add-int/2addr v3, v2

    .line 1418
    iput v3, v0, LUg/f;->F:I

    .line 1419
    .line 1420
    :cond_32
    iget v2, v0, LUg/f;->F:I

    .line 1421
    .line 1422
    iget v3, v0, LUg/f;->t:I

    .line 1423
    .line 1424
    iget-object v5, v0, LUg/f;->q:[I

    .line 1425
    .line 1426
    move/from16 v6, v17

    .line 1427
    .line 1428
    if-ge v2, v6, :cond_33

    .line 1429
    .line 1430
    sget-object v6, LUg/d;->d:[I

    .line 1431
    .line 1432
    aget v6, v6, v2

    .line 1433
    .line 1434
    add-int/2addr v6, v3

    .line 1435
    const/16 v22, 0x3

    .line 1436
    .line 1437
    and-int/lit8 v6, v6, 0x3

    .line 1438
    .line 1439
    aget v6, v5, v6

    .line 1440
    .line 1441
    sget-object v7, LUg/d;->e:[I

    .line 1442
    .line 1443
    aget v7, v7, v2

    .line 1444
    .line 1445
    add-int/2addr v6, v7

    .line 1446
    goto :goto_1a

    .line 1447
    :cond_33
    add-int/lit8 v6, v2, -0xf

    .line 1448
    .line 1449
    :goto_1a
    iput v6, v0, LUg/f;->K:I

    .line 1450
    .line 1451
    if-ltz v6, :cond_3b

    .line 1452
    .line 1453
    iget v7, v0, LUg/f;->s:I

    .line 1454
    .line 1455
    iget v8, v0, LUg/f;->N:I

    .line 1456
    .line 1457
    if-eq v7, v8, :cond_34

    .line 1458
    .line 1459
    iget v7, v0, LUg/f;->r:I

    .line 1460
    .line 1461
    if-ge v7, v8, :cond_34

    .line 1462
    .line 1463
    iput v7, v0, LUg/f;->s:I

    .line 1464
    .line 1465
    goto :goto_1b

    .line 1466
    :cond_34
    iput v8, v0, LUg/f;->s:I

    .line 1467
    .line 1468
    :goto_1b
    iget v7, v0, LUg/f;->r:I

    .line 1469
    .line 1470
    iput v7, v0, LUg/f;->M:I

    .line 1471
    .line 1472
    iget v7, v0, LUg/f;->s:I

    .line 1473
    .line 1474
    if-le v6, v7, :cond_35

    .line 1475
    .line 1476
    const/16 v7, 0x9

    .line 1477
    .line 1478
    iput v7, v0, LUg/f;->a:I

    .line 1479
    .line 1480
    goto/16 :goto_30

    .line 1481
    .line 1482
    :cond_35
    if-lez v2, :cond_36

    .line 1483
    .line 1484
    and-int/lit8 v2, v3, 0x3

    .line 1485
    .line 1486
    aput v6, v5, v2

    .line 1487
    .line 1488
    add-int/lit8 v3, v3, 0x1

    .line 1489
    .line 1490
    iput v3, v0, LUg/f;->t:I

    .line 1491
    .line 1492
    :cond_36
    iget v2, v0, LUg/f;->L:I

    .line 1493
    .line 1494
    iget v3, v0, LUg/f;->g:I

    .line 1495
    .line 1496
    if-gt v2, v3, :cond_3a

    .line 1497
    .line 1498
    const/4 v5, 0x0

    .line 1499
    iput v5, v0, LUg/f;->w:I

    .line 1500
    .line 1501
    move/from16 v2, v16

    .line 1502
    .line 1503
    iput v2, v0, LUg/f;->a:I

    .line 1504
    .line 1505
    :goto_1c
    iget v2, v0, LUg/f;->r:I

    .line 1506
    .line 1507
    iget v3, v0, LUg/f;->K:I

    .line 1508
    .line 1509
    sub-int v3, v2, v3

    .line 1510
    .line 1511
    and-int/2addr v3, v1

    .line 1512
    iget v5, v0, LUg/f;->L:I

    .line 1513
    .line 1514
    iget v6, v0, LUg/f;->w:I

    .line 1515
    .line 1516
    sub-int/2addr v5, v6

    .line 1517
    add-int v6, v3, v5

    .line 1518
    .line 1519
    if-ge v6, v1, :cond_39

    .line 1520
    .line 1521
    add-int v6, v2, v5

    .line 1522
    .line 1523
    if-ge v6, v1, :cond_39

    .line 1524
    .line 1525
    const/4 v12, 0x0

    .line 1526
    :goto_1d
    if-ge v12, v5, :cond_37

    .line 1527
    .line 1528
    add-int/lit8 v6, v2, 0x1

    .line 1529
    .line 1530
    add-int/lit8 v7, v3, 0x1

    .line 1531
    .line 1532
    aget-byte v3, v4, v3

    .line 1533
    .line 1534
    aput-byte v3, v4, v2

    .line 1535
    .line 1536
    add-int/lit8 v12, v12, 0x1

    .line 1537
    .line 1538
    move v2, v6

    .line 1539
    move v3, v7

    .line 1540
    goto :goto_1d

    .line 1541
    :cond_37
    iget v2, v0, LUg/f;->w:I

    .line 1542
    .line 1543
    add-int/2addr v2, v5

    .line 1544
    iput v2, v0, LUg/f;->w:I

    .line 1545
    .line 1546
    iget v2, v0, LUg/f;->g:I

    .line 1547
    .line 1548
    sub-int/2addr v2, v5

    .line 1549
    iput v2, v0, LUg/f;->g:I

    .line 1550
    .line 1551
    iget v2, v0, LUg/f;->r:I

    .line 1552
    .line 1553
    add-int/2addr v2, v5

    .line 1554
    iput v2, v0, LUg/f;->r:I

    .line 1555
    .line 1556
    :cond_38
    const/4 v2, 0x7

    .line 1557
    goto :goto_1e

    .line 1558
    :cond_39
    iget v2, v0, LUg/f;->w:I

    .line 1559
    .line 1560
    iget v3, v0, LUg/f;->L:I

    .line 1561
    .line 1562
    if-ge v2, v3, :cond_38

    .line 1563
    .line 1564
    iget v3, v0, LUg/f;->r:I

    .line 1565
    .line 1566
    iget v5, v0, LUg/f;->K:I

    .line 1567
    .line 1568
    sub-int v5, v3, v5

    .line 1569
    .line 1570
    and-int/2addr v5, v1

    .line 1571
    aget-byte v5, v4, v5

    .line 1572
    .line 1573
    aput-byte v5, v4, v3

    .line 1574
    .line 1575
    iget v5, v0, LUg/f;->g:I

    .line 1576
    .line 1577
    const/16 v19, 0x1

    .line 1578
    .line 1579
    add-int/lit8 v5, v5, -0x1

    .line 1580
    .line 1581
    iput v5, v0, LUg/f;->g:I

    .line 1582
    .line 1583
    add-int/lit8 v2, v2, 0x1

    .line 1584
    .line 1585
    iput v2, v0, LUg/f;->w:I

    .line 1586
    .line 1587
    add-int/lit8 v2, v3, 0x1

    .line 1588
    .line 1589
    iput v2, v0, LUg/f;->r:I

    .line 1590
    .line 1591
    if-ne v3, v1, :cond_39

    .line 1592
    .line 1593
    const/4 v2, 0x7

    .line 1594
    iput v2, v0, LUg/f;->b:I

    .line 1595
    .line 1596
    iget v3, v0, LUg/f;->P:I

    .line 1597
    .line 1598
    iput v3, v0, LUg/f;->X:I

    .line 1599
    .line 1600
    const/4 v5, 0x0

    .line 1601
    iput v5, v0, LUg/f;->W:I

    .line 1602
    .line 1603
    const/16 v3, 0xc

    .line 1604
    .line 1605
    iput v3, v0, LUg/f;->a:I

    .line 1606
    .line 1607
    :goto_1e
    iget v3, v0, LUg/f;->a:I

    .line 1608
    .line 1609
    if-ne v3, v2, :cond_57

    .line 1610
    .line 1611
    const/4 v2, 0x3

    .line 1612
    iput v2, v0, LUg/f;->a:I

    .line 1613
    .line 1614
    goto/16 :goto_30

    .line 1615
    .line 1616
    :cond_3a
    new-instance v0, LUg/c;

    .line 1617
    .line 1618
    invoke-direct {v0, v9}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 1619
    .line 1620
    .line 1621
    throw v0

    .line 1622
    :cond_3b
    new-instance v0, LUg/c;

    .line 1623
    .line 1624
    const-string v1, "Negative distance"

    .line 1625
    .line 1626
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 1627
    .line 1628
    .line 1629
    throw v0

    .line 1630
    :pswitch_8
    const/16 v26, 0xb

    .line 1631
    .line 1632
    iget v1, v0, LUg/f;->g:I

    .line 1633
    .line 1634
    if-ltz v1, :cond_58

    .line 1635
    .line 1636
    iget-boolean v1, v0, LUg/f;->h:Z

    .line 1637
    .line 1638
    if-eqz v1, :cond_3c

    .line 1639
    .line 1640
    const/16 v3, 0xa

    .line 1641
    .line 1642
    iput v3, v0, LUg/f;->b:I

    .line 1643
    .line 1644
    iget v1, v0, LUg/f;->r:I

    .line 1645
    .line 1646
    iput v1, v0, LUg/f;->X:I

    .line 1647
    .line 1648
    const/4 v5, 0x0

    .line 1649
    iput v5, v0, LUg/f;->W:I

    .line 1650
    .line 1651
    const/16 v2, 0xc

    .line 1652
    .line 1653
    iput v2, v0, LUg/f;->a:I

    .line 1654
    .line 1655
    goto/16 :goto_2f

    .line 1656
    .line 1657
    :cond_3c
    const/4 v1, 0x0

    .line 1658
    iput-object v1, v10, LPa/b;->c:Ljava/lang/Object;

    .line 1659
    .line 1660
    iput-object v1, v10, LPa/b;->d:Ljava/lang/Object;

    .line 1661
    .line 1662
    iput-object v1, v8, LPa/b;->c:Ljava/lang/Object;

    .line 1663
    .line 1664
    iput-object v1, v8, LPa/b;->d:Ljava/lang/Object;

    .line 1665
    .line 1666
    iput-object v1, v12, LPa/b;->c:Ljava/lang/Object;

    .line 1667
    .line 1668
    iput-object v1, v12, LPa/b;->d:Ljava/lang/Object;

    .line 1669
    .line 1670
    invoke-static {v11}, LUg/a;->e(LUg/a;)V

    .line 1671
    .line 1672
    .line 1673
    const/4 v2, 0x1

    .line 1674
    invoke-static {v11, v2}, LUg/a;->d(LUg/a;I)I

    .line 1675
    .line 1676
    .line 1677
    move-result v1

    .line 1678
    if-ne v1, v2, :cond_3d

    .line 1679
    .line 1680
    move v1, v2

    .line 1681
    goto :goto_1f

    .line 1682
    :cond_3d
    const/4 v1, 0x0

    .line 1683
    :goto_1f
    iput-boolean v1, v0, LUg/f;->h:Z

    .line 1684
    .line 1685
    const/4 v5, 0x0

    .line 1686
    iput v5, v0, LUg/f;->g:I

    .line 1687
    .line 1688
    iput-boolean v5, v0, LUg/f;->i:Z

    .line 1689
    .line 1690
    iput-boolean v5, v0, LUg/f;->j:Z

    .line 1691
    .line 1692
    if-eqz v1, :cond_3e

    .line 1693
    .line 1694
    invoke-static {v11, v2}, LUg/a;->d(LUg/a;I)I

    .line 1695
    .line 1696
    .line 1697
    move-result v1

    .line 1698
    if-eqz v1, :cond_3e

    .line 1699
    .line 1700
    :goto_20
    const/4 v8, 0x4

    .line 1701
    goto/16 :goto_27

    .line 1702
    .line 1703
    :cond_3e
    const/4 v15, 0x2

    .line 1704
    invoke-static {v11, v15}, LUg/a;->d(LUg/a;I)I

    .line 1705
    .line 1706
    .line 1707
    move-result v1

    .line 1708
    const/16 v27, 0x4

    .line 1709
    .line 1710
    add-int/lit8 v1, v1, 0x4

    .line 1711
    .line 1712
    const-string v3, "Exuberant nibble"

    .line 1713
    .line 1714
    const/4 v4, 0x7

    .line 1715
    if-ne v1, v4, :cond_44

    .line 1716
    .line 1717
    iput-boolean v2, v0, LUg/f;->j:Z

    .line 1718
    .line 1719
    invoke-static {v11, v2}, LUg/a;->d(LUg/a;I)I

    .line 1720
    .line 1721
    .line 1722
    move-result v1

    .line 1723
    if-nez v1, :cond_43

    .line 1724
    .line 1725
    invoke-static {v11, v15}, LUg/a;->d(LUg/a;I)I

    .line 1726
    .line 1727
    .line 1728
    move-result v1

    .line 1729
    if-nez v1, :cond_3f

    .line 1730
    .line 1731
    goto :goto_20

    .line 1732
    :cond_3f
    const/4 v2, 0x0

    .line 1733
    :goto_21
    if-ge v2, v1, :cond_42

    .line 1734
    .line 1735
    const/16 v4, 0x8

    .line 1736
    .line 1737
    invoke-static {v11, v4}, LUg/a;->d(LUg/a;I)I

    .line 1738
    .line 1739
    .line 1740
    move-result v5

    .line 1741
    if-nez v5, :cond_41

    .line 1742
    .line 1743
    add-int/lit8 v6, v2, 0x1

    .line 1744
    .line 1745
    if-ne v6, v1, :cond_41

    .line 1746
    .line 1747
    const/4 v6, 0x1

    .line 1748
    if-gt v1, v6, :cond_40

    .line 1749
    .line 1750
    goto :goto_22

    .line 1751
    :cond_40
    new-instance v0, LUg/c;

    .line 1752
    .line 1753
    invoke-direct {v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 1754
    .line 1755
    .line 1756
    throw v0

    .line 1757
    :cond_41
    :goto_22
    iget v6, v0, LUg/f;->g:I

    .line 1758
    .line 1759
    mul-int/lit8 v8, v2, 0x8

    .line 1760
    .line 1761
    shl-int/2addr v5, v8

    .line 1762
    or-int/2addr v5, v6

    .line 1763
    iput v5, v0, LUg/f;->g:I

    .line 1764
    .line 1765
    add-int/lit8 v2, v2, 0x1

    .line 1766
    .line 1767
    goto :goto_21

    .line 1768
    :cond_42
    const/4 v8, 0x4

    .line 1769
    goto :goto_25

    .line 1770
    :cond_43
    new-instance v0, LUg/c;

    .line 1771
    .line 1772
    const-string v1, "Corrupted reserved bit"

    .line 1773
    .line 1774
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 1775
    .line 1776
    .line 1777
    throw v0

    .line 1778
    :cond_44
    const/4 v2, 0x0

    .line 1779
    :goto_23
    if-ge v2, v1, :cond_42

    .line 1780
    .line 1781
    const/4 v8, 0x4

    .line 1782
    invoke-static {v11, v8}, LUg/a;->d(LUg/a;I)I

    .line 1783
    .line 1784
    .line 1785
    move-result v4

    .line 1786
    if-nez v4, :cond_46

    .line 1787
    .line 1788
    add-int/lit8 v5, v2, 0x1

    .line 1789
    .line 1790
    if-ne v5, v1, :cond_46

    .line 1791
    .line 1792
    if-gt v1, v8, :cond_45

    .line 1793
    .line 1794
    goto :goto_24

    .line 1795
    :cond_45
    new-instance v0, LUg/c;

    .line 1796
    .line 1797
    invoke-direct {v0, v3}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 1798
    .line 1799
    .line 1800
    throw v0

    .line 1801
    :cond_46
    :goto_24
    iget v5, v0, LUg/f;->g:I

    .line 1802
    .line 1803
    mul-int/lit8 v6, v2, 0x4

    .line 1804
    .line 1805
    shl-int/2addr v4, v6

    .line 1806
    or-int/2addr v4, v5

    .line 1807
    iput v4, v0, LUg/f;->g:I

    .line 1808
    .line 1809
    add-int/lit8 v2, v2, 0x1

    .line 1810
    .line 1811
    goto :goto_23

    .line 1812
    :goto_25
    iget v1, v0, LUg/f;->g:I

    .line 1813
    .line 1814
    const/4 v2, 0x1

    .line 1815
    add-int/2addr v1, v2

    .line 1816
    iput v1, v0, LUg/f;->g:I

    .line 1817
    .line 1818
    iget-boolean v1, v0, LUg/f;->h:Z

    .line 1819
    .line 1820
    if-nez v1, :cond_48

    .line 1821
    .line 1822
    invoke-static {v11, v2}, LUg/a;->d(LUg/a;I)I

    .line 1823
    .line 1824
    .line 1825
    move-result v1

    .line 1826
    if-ne v1, v2, :cond_47

    .line 1827
    .line 1828
    const/4 v1, 0x1

    .line 1829
    goto :goto_26

    .line 1830
    :cond_47
    const/4 v1, 0x0

    .line 1831
    :goto_26
    iput-boolean v1, v0, LUg/f;->i:Z

    .line 1832
    .line 1833
    :cond_48
    :goto_27
    iget v1, v0, LUg/f;->g:I

    .line 1834
    .line 1835
    if-nez v1, :cond_49

    .line 1836
    .line 1837
    iget-boolean v1, v0, LUg/f;->j:Z

    .line 1838
    .line 1839
    if-nez v1, :cond_49

    .line 1840
    .line 1841
    goto/16 :goto_2f

    .line 1842
    .line 1843
    :cond_49
    iget-boolean v1, v0, LUg/f;->i:Z

    .line 1844
    .line 1845
    if-nez v1, :cond_4b

    .line 1846
    .line 1847
    iget-boolean v1, v0, LUg/f;->j:Z

    .line 1848
    .line 1849
    if-eqz v1, :cond_4a

    .line 1850
    .line 1851
    goto :goto_28

    .line 1852
    :cond_4a
    const/4 v15, 0x2

    .line 1853
    iput v15, v0, LUg/f;->a:I

    .line 1854
    .line 1855
    goto :goto_2b

    .line 1856
    :cond_4b
    :goto_28
    iget v1, v11, LUg/a;->g:I

    .line 1857
    .line 1858
    const/16 v21, 0x40

    .line 1859
    .line 1860
    rsub-int/lit8 v9, v1, 0x40

    .line 1861
    .line 1862
    const/16 v16, 0x7

    .line 1863
    .line 1864
    and-int/lit8 v1, v9, 0x7

    .line 1865
    .line 1866
    if-eqz v1, :cond_4d

    .line 1867
    .line 1868
    invoke-static {v11, v1}, LUg/a;->d(LUg/a;I)I

    .line 1869
    .line 1870
    .line 1871
    move-result v1

    .line 1872
    if-nez v1, :cond_4c

    .line 1873
    .line 1874
    goto :goto_29

    .line 1875
    :cond_4c
    new-instance v0, LUg/c;

    .line 1876
    .line 1877
    invoke-direct {v0, v7}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 1878
    .line 1879
    .line 1880
    throw v0

    .line 1881
    :cond_4d
    :goto_29
    iget-boolean v1, v0, LUg/f;->j:Z

    .line 1882
    .line 1883
    if-eqz v1, :cond_4e

    .line 1884
    .line 1885
    move v15, v8

    .line 1886
    goto :goto_2a

    .line 1887
    :cond_4e
    move/from16 v15, v23

    .line 1888
    .line 1889
    :goto_2a
    iput v15, v0, LUg/f;->a:I

    .line 1890
    .line 1891
    :goto_2b
    iget-boolean v1, v0, LUg/f;->j:Z

    .line 1892
    .line 1893
    if-eqz v1, :cond_4f

    .line 1894
    .line 1895
    goto :goto_2f

    .line 1896
    :cond_4f
    iget-wide v1, v0, LUg/f;->Q:J

    .line 1897
    .line 1898
    iget v3, v0, LUg/f;->g:I

    .line 1899
    .line 1900
    int-to-long v3, v3

    .line 1901
    add-long/2addr v1, v3

    .line 1902
    iput-wide v1, v0, LUg/f;->Q:J

    .line 1903
    .line 1904
    iget v3, v0, LUg/f;->P:I

    .line 1905
    .line 1906
    iget v4, v0, LUg/f;->O:I

    .line 1907
    .line 1908
    if-ge v3, v4, :cond_56

    .line 1909
    .line 1910
    int-to-long v5, v4

    .line 1911
    cmp-long v3, v5, v1

    .line 1912
    .line 1913
    if-lez v3, :cond_51

    .line 1914
    .line 1915
    long-to-int v1, v1

    .line 1916
    iget-object v2, v0, LUg/f;->R:[B

    .line 1917
    .line 1918
    array-length v2, v2

    .line 1919
    add-int/2addr v1, v2

    .line 1920
    :goto_2c
    shr-int/lit8 v2, v4, 0x1

    .line 1921
    .line 1922
    if-le v2, v1, :cond_50

    .line 1923
    .line 1924
    move v4, v2

    .line 1925
    goto :goto_2c

    .line 1926
    :cond_50
    iget-boolean v1, v0, LUg/f;->h:Z

    .line 1927
    .line 1928
    if-nez v1, :cond_51

    .line 1929
    .line 1930
    const/16 v1, 0x4000

    .line 1931
    .line 1932
    if-ge v4, v1, :cond_51

    .line 1933
    .line 1934
    iget v2, v0, LUg/f;->O:I

    .line 1935
    .line 1936
    if-lt v2, v1, :cond_51

    .line 1937
    .line 1938
    move v4, v1

    .line 1939
    :cond_51
    iget v1, v0, LUg/f;->P:I

    .line 1940
    .line 1941
    if-gt v4, v1, :cond_52

    .line 1942
    .line 1943
    goto :goto_2f

    .line 1944
    :cond_52
    add-int/lit8 v2, v4, 0x25

    .line 1945
    .line 1946
    new-array v2, v2, [B

    .line 1947
    .line 1948
    iget-object v3, v0, LUg/f;->d:[B

    .line 1949
    .line 1950
    if-eqz v3, :cond_53

    .line 1951
    .line 1952
    const/4 v5, 0x0

    .line 1953
    invoke-static {v3, v5, v2, v5, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1954
    .line 1955
    .line 1956
    goto :goto_2e

    .line 1957
    :cond_53
    const/4 v5, 0x0

    .line 1958
    iget-object v1, v0, LUg/f;->R:[B

    .line 1959
    .line 1960
    array-length v3, v1

    .line 1961
    if-eqz v3, :cond_55

    .line 1962
    .line 1963
    array-length v3, v1

    .line 1964
    iget v6, v0, LUg/f;->N:I

    .line 1965
    .line 1966
    if-le v3, v6, :cond_54

    .line 1967
    .line 1968
    sub-int v24, v3, v6

    .line 1969
    .line 1970
    move v3, v6

    .line 1971
    move/from16 v6, v24

    .line 1972
    .line 1973
    goto :goto_2d

    .line 1974
    :cond_54
    move v6, v5

    .line 1975
    :goto_2d
    invoke-static {v1, v6, v2, v5, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1976
    .line 1977
    .line 1978
    iput v3, v0, LUg/f;->r:I

    .line 1979
    .line 1980
    iput v3, v0, LUg/f;->S:I

    .line 1981
    .line 1982
    :cond_55
    :goto_2e
    iput-object v2, v0, LUg/f;->d:[B

    .line 1983
    .line 1984
    iput v4, v0, LUg/f;->P:I

    .line 1985
    .line 1986
    :cond_56
    :goto_2f
    iget v1, v0, LUg/f;->P:I

    .line 1987
    .line 1988
    const/16 v19, 0x1

    .line 1989
    .line 1990
    add-int/lit8 v1, v1, -0x1

    .line 1991
    .line 1992
    iget-object v4, v0, LUg/f;->d:[B

    .line 1993
    .line 1994
    :cond_57
    :goto_30
    move/from16 v2, v26

    .line 1995
    .line 1996
    const/4 v3, 0x1

    .line 1997
    goto/16 :goto_0

    .line 1998
    .line 1999
    :cond_58
    new-instance v0, LUg/c;

    .line 2000
    .line 2001
    invoke-direct {v0, v6}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 2002
    .line 2003
    .line 2004
    throw v0

    .line 2005
    :cond_59
    move/from16 v26, v2

    .line 2006
    .line 2007
    iget v2, v0, LUg/f;->S:I

    .line 2008
    .line 2009
    if-eqz v2, :cond_5a

    .line 2010
    .line 2011
    iget v3, v0, LUg/f;->W:I

    .line 2012
    .line 2013
    add-int/2addr v3, v2

    .line 2014
    iput v3, v0, LUg/f;->W:I

    .line 2015
    .line 2016
    const/4 v5, 0x0

    .line 2017
    iput v5, v0, LUg/f;->S:I

    .line 2018
    .line 2019
    :cond_5a
    iget v2, v0, LUg/f;->U:I

    .line 2020
    .line 2021
    iget v3, v0, LUg/f;->V:I

    .line 2022
    .line 2023
    sub-int/2addr v2, v3

    .line 2024
    iget v3, v0, LUg/f;->X:I

    .line 2025
    .line 2026
    iget v5, v0, LUg/f;->W:I

    .line 2027
    .line 2028
    sub-int/2addr v3, v5

    .line 2029
    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    .line 2030
    .line 2031
    .line 2032
    move-result v2

    .line 2033
    if-eqz v2, :cond_5b

    .line 2034
    .line 2035
    iget-object v3, v0, LUg/f;->d:[B

    .line 2036
    .line 2037
    iget v5, v0, LUg/f;->W:I

    .line 2038
    .line 2039
    iget-object v6, v0, LUg/f;->Y:[B

    .line 2040
    .line 2041
    iget v7, v0, LUg/f;->T:I

    .line 2042
    .line 2043
    iget v8, v0, LUg/f;->V:I

    .line 2044
    .line 2045
    add-int/2addr v7, v8

    .line 2046
    invoke-static {v3, v5, v6, v7, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2047
    .line 2048
    .line 2049
    iget v3, v0, LUg/f;->V:I

    .line 2050
    .line 2051
    add-int/2addr v3, v2

    .line 2052
    iput v3, v0, LUg/f;->V:I

    .line 2053
    .line 2054
    iget v3, v0, LUg/f;->W:I

    .line 2055
    .line 2056
    add-int/2addr v3, v2

    .line 2057
    iput v3, v0, LUg/f;->W:I

    .line 2058
    .line 2059
    :cond_5b
    iget v2, v0, LUg/f;->V:I

    .line 2060
    .line 2061
    iget v3, v0, LUg/f;->U:I

    .line 2062
    .line 2063
    if-ge v2, v3, :cond_61

    .line 2064
    .line 2065
    iget v2, v0, LUg/f;->r:I

    .line 2066
    .line 2067
    iget v3, v0, LUg/f;->N:I

    .line 2068
    .line 2069
    if-lt v2, v3, :cond_5c

    .line 2070
    .line 2071
    iput v3, v0, LUg/f;->s:I

    .line 2072
    .line 2073
    :cond_5c
    and-int/2addr v2, v1

    .line 2074
    iput v2, v0, LUg/f;->r:I

    .line 2075
    .line 2076
    iget v2, v0, LUg/f;->b:I

    .line 2077
    .line 2078
    iput v2, v0, LUg/f;->a:I

    .line 2079
    .line 2080
    goto :goto_30

    .line 2081
    :cond_5d
    move v3, v10

    .line 2082
    if-ne v5, v3, :cond_61

    .line 2083
    .line 2084
    iget v0, v0, LUg/f;->g:I

    .line 2085
    .line 2086
    if-ltz v0, :cond_60

    .line 2087
    .line 2088
    iget v0, v11, LUg/a;->g:I

    .line 2089
    .line 2090
    const/16 v21, 0x40

    .line 2091
    .line 2092
    rsub-int/lit8 v9, v0, 0x40

    .line 2093
    .line 2094
    const/16 v16, 0x7

    .line 2095
    .line 2096
    and-int/lit8 v0, v9, 0x7

    .line 2097
    .line 2098
    if-eqz v0, :cond_5e

    .line 2099
    .line 2100
    invoke-static {v11, v0}, LUg/a;->d(LUg/a;I)I

    .line 2101
    .line 2102
    .line 2103
    move-result v0

    .line 2104
    if-nez v0, :cond_5f

    .line 2105
    .line 2106
    :cond_5e
    const/4 v2, 0x1

    .line 2107
    goto :goto_31

    .line 2108
    :cond_5f
    new-instance v0, LUg/c;

    .line 2109
    .line 2110
    invoke-direct {v0, v7}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 2111
    .line 2112
    .line 2113
    throw v0

    .line 2114
    :goto_31
    invoke-static {v11, v2}, LUg/a;->a(LUg/a;Z)V

    .line 2115
    .line 2116
    .line 2117
    return-void

    .line 2118
    :cond_60
    new-instance v0, LUg/c;

    .line 2119
    .line 2120
    invoke-direct {v0, v6}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 2121
    .line 2122
    .line 2123
    throw v0

    .line 2124
    :cond_61
    return-void

    .line 2125
    :cond_62
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 2126
    .line 2127
    const-string v1, "Can\'t decompress after close"

    .line 2128
    .line 2129
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 2130
    .line 2131
    .line 2132
    throw v0

    .line 2133
    :cond_63
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 2134
    .line 2135
    const-string v1, "Can\'t decompress until initialized"

    .line 2136
    .line 2137
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 2138
    .line 2139
    .line 2140
    throw v0

    .line 2141
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static f(I[IILUg/a;)V
    .locals 18

    .line 1
    move/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p3

    .line 4
    .line 5
    invoke-static {v1}, LUg/a;->e(LUg/a;)V

    .line 6
    .line 7
    .line 8
    new-array v2, v0, [I

    .line 9
    .line 10
    const/4 v3, 0x2

    .line 11
    invoke-static {v1, v3}, LUg/a;->d(LUg/a;I)I

    .line 12
    .line 13
    .line 14
    move-result v4

    .line 15
    const/16 v5, 0x8

    .line 16
    .line 17
    const/4 v6, 0x3

    .line 18
    const/4 v7, 0x0

    .line 19
    const/4 v8, 0x1

    .line 20
    if-ne v4, v8, :cond_8

    .line 21
    .line 22
    add-int/lit8 v4, v0, -0x1

    .line 23
    .line 24
    const/4 v9, 0x4

    .line 25
    new-array v9, v9, [I

    .line 26
    .line 27
    invoke-static {v1, v3}, LUg/a;->d(LUg/a;I)I

    .line 28
    .line 29
    .line 30
    move-result v10

    .line 31
    add-int/2addr v10, v8

    .line 32
    move v11, v7

    .line 33
    :goto_0
    if-eqz v4, :cond_0

    .line 34
    .line 35
    shr-int/lit8 v4, v4, 0x1

    .line 36
    .line 37
    add-int/lit8 v11, v11, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    move v4, v7

    .line 41
    :goto_1
    if-ge v4, v10, :cond_1

    .line 42
    .line 43
    invoke-static {v1, v11}, LUg/a;->d(LUg/a;I)I

    .line 44
    .line 45
    .line 46
    move-result v12

    .line 47
    rem-int/2addr v12, v0

    .line 48
    aput v12, v9, v4

    .line 49
    .line 50
    aput v3, v2, v12

    .line 51
    .line 52
    add-int/lit8 v4, v4, 0x1

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_1
    aget v4, v9, v7

    .line 56
    .line 57
    aput v8, v2, v4

    .line 58
    .line 59
    if-eq v10, v8, :cond_16

    .line 60
    .line 61
    if-eq v10, v3, :cond_6

    .line 62
    .line 63
    if-eq v10, v6, :cond_4

    .line 64
    .line 65
    aget v4, v9, v7

    .line 66
    .line 67
    aget v10, v9, v8

    .line 68
    .line 69
    if-eq v4, v10, :cond_2

    .line 70
    .line 71
    aget v11, v9, v3

    .line 72
    .line 73
    if-eq v4, v11, :cond_2

    .line 74
    .line 75
    aget v12, v9, v6

    .line 76
    .line 77
    if-eq v4, v12, :cond_2

    .line 78
    .line 79
    if-eq v10, v11, :cond_2

    .line 80
    .line 81
    if-eq v10, v12, :cond_2

    .line 82
    .line 83
    if-eq v11, v12, :cond_2

    .line 84
    .line 85
    move v4, v8

    .line 86
    goto :goto_2

    .line 87
    :cond_2
    move v4, v7

    .line 88
    :goto_2
    invoke-static {v1, v8}, LUg/a;->d(LUg/a;I)I

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    if-ne v1, v8, :cond_3

    .line 93
    .line 94
    aget v1, v9, v3

    .line 95
    .line 96
    aput v6, v2, v1

    .line 97
    .line 98
    aget v1, v9, v6

    .line 99
    .line 100
    aput v6, v2, v1

    .line 101
    .line 102
    goto :goto_3

    .line 103
    :cond_3
    aget v1, v9, v7

    .line 104
    .line 105
    aput v3, v2, v1

    .line 106
    .line 107
    :goto_3
    move v8, v4

    .line 108
    goto/16 :goto_c

    .line 109
    .line 110
    :cond_4
    aget v1, v9, v7

    .line 111
    .line 112
    aget v4, v9, v8

    .line 113
    .line 114
    if-eq v1, v4, :cond_5

    .line 115
    .line 116
    aget v3, v9, v3

    .line 117
    .line 118
    if-eq v1, v3, :cond_5

    .line 119
    .line 120
    if-eq v4, v3, :cond_5

    .line 121
    .line 122
    move v7, v8

    .line 123
    :cond_5
    :goto_4
    move v8, v7

    .line 124
    goto/16 :goto_c

    .line 125
    .line 126
    :cond_6
    aget v1, v9, v7

    .line 127
    .line 128
    aget v3, v9, v8

    .line 129
    .line 130
    if-eq v1, v3, :cond_7

    .line 131
    .line 132
    move v7, v8

    .line 133
    :cond_7
    aput v8, v2, v3

    .line 134
    .line 135
    goto :goto_4

    .line 136
    :cond_8
    const/16 v3, 0x12

    .line 137
    .line 138
    new-array v9, v3, [I

    .line 139
    .line 140
    const/16 v10, 0x20

    .line 141
    .line 142
    move v12, v7

    .line 143
    move v11, v10

    .line 144
    :goto_5
    if-ge v4, v3, :cond_a

    .line 145
    .line 146
    if-lez v11, :cond_a

    .line 147
    .line 148
    sget-object v14, LUg/d;->c:[I

    .line 149
    .line 150
    aget v14, v14, v4

    .line 151
    .line 152
    invoke-static {v1}, LUg/a;->b(LUg/a;)V

    .line 153
    .line 154
    .line 155
    move/from16 v16, v14

    .line 156
    .line 157
    const v15, 0xffff

    .line 158
    .line 159
    .line 160
    iget-wide v13, v1, LUg/a;->f:J

    .line 161
    .line 162
    move/from16 v17, v6

    .line 163
    .line 164
    iget v6, v1, LUg/a;->g:I

    .line 165
    .line 166
    ushr-long/2addr v13, v6

    .line 167
    long-to-int v13, v13

    .line 168
    and-int/lit8 v13, v13, 0xf

    .line 169
    .line 170
    sget-object v14, LUg/d;->f:[I

    .line 171
    .line 172
    aget v13, v14, v13

    .line 173
    .line 174
    shr-int/lit8 v14, v13, 0x10

    .line 175
    .line 176
    add-int/2addr v6, v14

    .line 177
    iput v6, v1, LUg/a;->g:I

    .line 178
    .line 179
    and-int v6, v13, v15

    .line 180
    .line 181
    aput v6, v9, v16

    .line 182
    .line 183
    if-eqz v6, :cond_9

    .line 184
    .line 185
    shr-int v6, v10, v6

    .line 186
    .line 187
    sub-int/2addr v11, v6

    .line 188
    add-int/lit8 v12, v12, 0x1

    .line 189
    .line 190
    :cond_9
    add-int/lit8 v4, v4, 0x1

    .line 191
    .line 192
    move/from16 v6, v17

    .line 193
    .line 194
    goto :goto_5

    .line 195
    :cond_a
    move/from16 v17, v6

    .line 196
    .line 197
    const v15, 0xffff

    .line 198
    .line 199
    .line 200
    if-eq v12, v8, :cond_c

    .line 201
    .line 202
    if-nez v11, :cond_b

    .line 203
    .line 204
    goto :goto_6

    .line 205
    :cond_b
    move v8, v7

    .line 206
    :cond_c
    :goto_6
    new-array v4, v10, [I

    .line 207
    .line 208
    const/4 v6, 0x5

    .line 209
    invoke-static {v7, v6, v4, v9, v3}, LUg/d;->a(II[I[II)V

    .line 210
    .line 211
    .line 212
    move v10, v5

    .line 213
    move v6, v7

    .line 214
    move v11, v6

    .line 215
    move v12, v11

    .line 216
    const v9, 0x8000

    .line 217
    .line 218
    .line 219
    :goto_7
    if-ge v6, v0, :cond_15

    .line 220
    .line 221
    if-lez v9, :cond_15

    .line 222
    .line 223
    invoke-static {v1}, LUg/a;->e(LUg/a;)V

    .line 224
    .line 225
    .line 226
    invoke-static {v1}, LUg/a;->b(LUg/a;)V

    .line 227
    .line 228
    .line 229
    iget-wide v13, v1, LUg/a;->f:J

    .line 230
    .line 231
    const v16, 0x8000

    .line 232
    .line 233
    .line 234
    iget v3, v1, LUg/a;->g:I

    .line 235
    .line 236
    ushr-long/2addr v13, v3

    .line 237
    long-to-int v13, v13

    .line 238
    and-int/lit8 v13, v13, 0x1f

    .line 239
    .line 240
    aget v13, v4, v13

    .line 241
    .line 242
    shr-int/lit8 v14, v13, 0x10

    .line 243
    .line 244
    add-int/2addr v3, v14

    .line 245
    iput v3, v1, LUg/a;->g:I

    .line 246
    .line 247
    and-int v3, v13, v15

    .line 248
    .line 249
    const/16 v13, 0x10

    .line 250
    .line 251
    if-ge v3, v13, :cond_e

    .line 252
    .line 253
    add-int/lit8 v12, v6, 0x1

    .line 254
    .line 255
    aput v3, v2, v6

    .line 256
    .line 257
    if-eqz v3, :cond_d

    .line 258
    .line 259
    shr-int v6, v16, v3

    .line 260
    .line 261
    sub-int/2addr v9, v6

    .line 262
    move v10, v3

    .line 263
    :cond_d
    move v6, v12

    .line 264
    move v12, v7

    .line 265
    goto :goto_7

    .line 266
    :cond_e
    add-int/lit8 v14, v3, -0xe

    .line 267
    .line 268
    if-ne v3, v13, :cond_f

    .line 269
    .line 270
    move v3, v10

    .line 271
    goto :goto_8

    .line 272
    :cond_f
    move v3, v7

    .line 273
    :goto_8
    if-eq v11, v3, :cond_10

    .line 274
    .line 275
    move v11, v3

    .line 276
    move v12, v7

    .line 277
    :cond_10
    if-lez v12, :cond_11

    .line 278
    .line 279
    add-int/lit8 v3, v12, -0x2

    .line 280
    .line 281
    shl-int/2addr v3, v14

    .line 282
    goto :goto_9

    .line 283
    :cond_11
    move v3, v12

    .line 284
    :goto_9
    invoke-static {v1, v14}, LUg/a;->d(LUg/a;I)I

    .line 285
    .line 286
    .line 287
    move-result v13

    .line 288
    add-int/lit8 v13, v13, 0x3

    .line 289
    .line 290
    add-int/2addr v13, v3

    .line 291
    sub-int v3, v13, v12

    .line 292
    .line 293
    add-int v12, v6, v3

    .line 294
    .line 295
    if-gt v12, v0, :cond_14

    .line 296
    .line 297
    move v12, v7

    .line 298
    :goto_a
    if-ge v12, v3, :cond_12

    .line 299
    .line 300
    add-int/lit8 v14, v6, 0x1

    .line 301
    .line 302
    aput v11, v2, v6

    .line 303
    .line 304
    add-int/lit8 v12, v12, 0x1

    .line 305
    .line 306
    move v6, v14

    .line 307
    goto :goto_a

    .line 308
    :cond_12
    if-eqz v11, :cond_13

    .line 309
    .line 310
    rsub-int/lit8 v12, v11, 0xf

    .line 311
    .line 312
    shl-int/2addr v3, v12

    .line 313
    sub-int/2addr v9, v3

    .line 314
    :cond_13
    move v12, v13

    .line 315
    goto :goto_7

    .line 316
    :cond_14
    new-instance v0, LUg/c;

    .line 317
    .line 318
    const-string v1, "symbol + repeatDelta > numSymbols"

    .line 319
    .line 320
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 321
    .line 322
    .line 323
    throw v0

    .line 324
    :cond_15
    if-nez v9, :cond_18

    .line 325
    .line 326
    sub-int v1, v0, v6

    .line 327
    .line 328
    move v3, v7

    .line 329
    :goto_b
    if-ge v3, v1, :cond_16

    .line 330
    .line 331
    add-int/lit16 v4, v3, 0x400

    .line 332
    .line 333
    invoke-static {v4, v1}, Ljava/lang/Math;->min(II)I

    .line 334
    .line 335
    .line 336
    move-result v4

    .line 337
    sub-int/2addr v4, v3

    .line 338
    sget-object v9, LUg/d;->r:[I

    .line 339
    .line 340
    add-int v10, v6, v3

    .line 341
    .line 342
    invoke-static {v9, v7, v2, v10, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 343
    .line 344
    .line 345
    add-int/2addr v3, v4

    .line 346
    goto :goto_b

    .line 347
    :cond_16
    :goto_c
    if-eqz v8, :cond_17

    .line 348
    .line 349
    move-object/from16 v1, p1

    .line 350
    .line 351
    move/from16 v3, p2

    .line 352
    .line 353
    invoke-static {v3, v5, v1, v2, v0}, LUg/d;->a(II[I[II)V

    .line 354
    .line 355
    .line 356
    return-void

    .line 357
    :cond_17
    new-instance v0, LUg/c;

    .line 358
    .line 359
    const-string v1, "Can\'t readHuffmanCode"

    .line 360
    .line 361
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 362
    .line 363
    .line 364
    throw v0

    .line 365
    :cond_18
    new-instance v0, LUg/c;

    .line 366
    .line 367
    const-string v1, "Unused space"

    .line 368
    .line 369
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 370
    .line 371
    .line 372
    throw v0
.end method

.method public static g([IILUg/a;)I
    .locals 6

    .line 1
    iget-wide v0, p2, LUg/a;->f:J

    .line 2
    .line 3
    iget v2, p2, LUg/a;->g:I

    .line 4
    .line 5
    ushr-long/2addr v0, v2

    .line 6
    long-to-int v0, v0

    .line 7
    and-int/lit16 v1, v0, 0xff

    .line 8
    .line 9
    add-int/2addr p1, v1

    .line 10
    aget v1, p0, p1

    .line 11
    .line 12
    shr-int/lit8 v3, v1, 0x10

    .line 13
    .line 14
    const v4, 0xffff

    .line 15
    .line 16
    .line 17
    and-int/2addr v1, v4

    .line 18
    const/16 v5, 0x8

    .line 19
    .line 20
    if-gt v3, v5, :cond_0

    .line 21
    .line 22
    add-int/2addr v2, v3

    .line 23
    iput v2, p2, LUg/a;->g:I

    .line 24
    .line 25
    return v1

    .line 26
    :cond_0
    add-int/2addr p1, v1

    .line 27
    const/4 v1, 0x1

    .line 28
    shl-int v3, v1, v3

    .line 29
    .line 30
    sub-int/2addr v3, v1

    .line 31
    and-int/2addr v0, v3

    .line 32
    ushr-int/2addr v0, v5

    .line 33
    add-int/2addr p1, v0

    .line 34
    aget p0, p0, p1

    .line 35
    .line 36
    shr-int/lit8 p1, p0, 0x10

    .line 37
    .line 38
    add-int/2addr p1, v5

    .line 39
    add-int/2addr p1, v2

    .line 40
    iput p1, p2, LUg/a;->g:I

    .line 41
    .line 42
    and-int/2addr p0, v4

    .line 43
    return p0
.end method
