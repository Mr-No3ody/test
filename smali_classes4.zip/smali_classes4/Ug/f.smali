.class public final LUg/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public A:I

.field public B:I

.field public C:I

.field public D:I

.field public E:I

.field public F:I

.field public G:[B

.field public H:I

.field public I:I

.field public J:I

.field public K:I

.field public L:I

.field public M:I

.field public N:I

.field public O:I

.field public P:I

.field public Q:J

.field public final R:[B

.field public S:I

.field public T:I

.field public U:I

.field public V:I

.field public W:I

.field public X:I

.field public Y:[B

.field public a:I

.field public b:I

.field public final c:LUg/a;

.field public d:[B

.field public final e:[I

.field public final f:[I

.field public g:I

.field public h:Z

.field public i:Z

.field public j:Z

.field public final k:LPa/b;

.field public final l:LPa/b;

.field public final m:LPa/b;

.field public final n:[I

.field public final o:[I

.field public final p:[I

.field public final q:[I

.field public r:I

.field public s:I

.field public t:I

.field public u:Z

.field public v:I

.field public w:I

.field public x:I

.field public y:[B

.field public z:[B


# direct methods
.method public constructor <init>()V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, LUg/f;->a:I

    .line 6
    .line 7
    new-instance v1, LUg/a;

    .line 8
    .line 9
    invoke-direct {v1}, LUg/a;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v1, p0, LUg/f;->c:LUg/a;

    .line 13
    .line 14
    const/16 v1, 0xca8

    .line 15
    .line 16
    new-array v2, v1, [I

    .line 17
    .line 18
    iput-object v2, p0, LUg/f;->e:[I

    .line 19
    .line 20
    new-array v1, v1, [I

    .line 21
    .line 22
    iput-object v1, p0, LUg/f;->f:[I

    .line 23
    .line 24
    new-instance v1, LPa/b;

    .line 25
    .line 26
    const/4 v2, 0x1

    .line 27
    const/4 v3, 0x0

    .line 28
    invoke-direct {v1, v3, v2}, LPa/b;-><init>(BI)V

    .line 29
    .line 30
    .line 31
    iput-object v1, p0, LUg/f;->k:LPa/b;

    .line 32
    .line 33
    new-instance v1, LPa/b;

    .line 34
    .line 35
    const/4 v2, 0x1

    .line 36
    const/4 v3, 0x0

    .line 37
    invoke-direct {v1, v3, v2}, LPa/b;-><init>(BI)V

    .line 38
    .line 39
    .line 40
    iput-object v1, p0, LUg/f;->l:LPa/b;

    .line 41
    .line 42
    new-instance v1, LPa/b;

    .line 43
    .line 44
    const/4 v2, 0x1

    .line 45
    const/4 v3, 0x0

    .line 46
    invoke-direct {v1, v3, v2}, LPa/b;-><init>(BI)V

    .line 47
    .line 48
    .line 49
    iput-object v1, p0, LUg/f;->m:LPa/b;

    .line 50
    .line 51
    const/4 v1, 0x3

    .line 52
    new-array v2, v1, [I

    .line 53
    .line 54
    iput-object v2, p0, LUg/f;->n:[I

    .line 55
    .line 56
    new-array v1, v1, [I

    .line 57
    .line 58
    iput-object v1, p0, LUg/f;->o:[I

    .line 59
    .line 60
    const/4 v1, 0x6

    .line 61
    new-array v1, v1, [I

    .line 62
    .line 63
    iput-object v1, p0, LUg/f;->p:[I

    .line 64
    .line 65
    const/16 v1, 0x10

    .line 66
    .line 67
    const/16 v2, 0xf

    .line 68
    .line 69
    const/16 v3, 0xb

    .line 70
    .line 71
    const/4 v4, 0x4

    .line 72
    filled-new-array {v1, v2, v3, v4}, [I

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    iput-object v1, p0, LUg/f;->q:[I

    .line 77
    .line 78
    iput v0, p0, LUg/f;->r:I

    .line 79
    .line 80
    iput v0, p0, LUg/f;->s:I

    .line 81
    .line 82
    iput v0, p0, LUg/f;->t:I

    .line 83
    .line 84
    iput-boolean v0, p0, LUg/f;->u:Z

    .line 85
    .line 86
    iput v0, p0, LUg/f;->P:I

    .line 87
    .line 88
    const-wide/16 v1, 0x0

    .line 89
    .line 90
    iput-wide v1, p0, LUg/f;->Q:J

    .line 91
    .line 92
    new-array v1, v0, [B

    .line 93
    .line 94
    iput-object v1, p0, LUg/f;->R:[B

    .line 95
    .line 96
    iput v0, p0, LUg/f;->S:I

    .line 97
    .line 98
    return-void
.end method

.method public static a(LUg/f;Ljava/io/InputStream;)V
    .locals 5

    .line 1
    iget v0, p0, LUg/f;->a:I

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    iget-object v0, p0, LUg/f;->c:LUg/a;

    .line 6
    .line 7
    iget-object v1, v0, LUg/a;->d:Ljava/io/InputStream;

    .line 8
    .line 9
    if-nez v1, :cond_4

    .line 10
    .line 11
    iget-object v1, v0, LUg/a;->a:[B

    .line 12
    .line 13
    iget-object v2, v0, LUg/a;->c:Lp1/d;

    .line 14
    .line 15
    iput-object v1, v2, Lp1/d;->b:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v1, v0, LUg/a;->b:[I

    .line 18
    .line 19
    iput-object v1, v2, Lp1/d;->c:Ljava/lang/Object;

    .line 20
    .line 21
    iput-object p1, v0, LUg/a;->d:Ljava/io/InputStream;

    .line 22
    .line 23
    const-wide/16 v1, 0x0

    .line 24
    .line 25
    iput-wide v1, v0, LUg/a;->f:J

    .line 26
    .line 27
    const/16 p1, 0x40

    .line 28
    .line 29
    iput p1, v0, LUg/a;->g:I

    .line 30
    .line 31
    const/16 p1, 0x400

    .line 32
    .line 33
    iput p1, v0, LUg/a;->h:I

    .line 34
    .line 35
    const/4 p1, 0x0

    .line 36
    iput-boolean p1, v0, LUg/a;->e:Z

    .line 37
    .line 38
    invoke-static {v0}, LUg/a;->e(LUg/a;)V

    .line 39
    .line 40
    .line 41
    invoke-static {v0, p1}, LUg/a;->a(LUg/a;Z)V

    .line 42
    .line 43
    .line 44
    invoke-static {v0}, LUg/a;->b(LUg/a;)V

    .line 45
    .line 46
    .line 47
    invoke-static {v0}, LUg/a;->b(LUg/a;)V

    .line 48
    .line 49
    .line 50
    const/4 p1, 0x1

    .line 51
    invoke-static {v0, p1}, LUg/a;->d(LUg/a;I)I

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    const/16 v2, 0x10

    .line 56
    .line 57
    if-nez v1, :cond_0

    .line 58
    .line 59
    move v4, v2

    .line 60
    goto :goto_0

    .line 61
    :cond_0
    const/4 v1, 0x3

    .line 62
    invoke-static {v0, v1}, LUg/a;->d(LUg/a;I)I

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    const/16 v4, 0x11

    .line 67
    .line 68
    if-eqz v3, :cond_1

    .line 69
    .line 70
    add-int/2addr v4, v3

    .line 71
    goto :goto_0

    .line 72
    :cond_1
    invoke-static {v0, v1}, LUg/a;->d(LUg/a;I)I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    if-eqz v0, :cond_2

    .line 77
    .line 78
    add-int/lit8 v4, v0, 0x8

    .line 79
    .line 80
    :cond_2
    :goto_0
    const/16 v0, 0x9

    .line 81
    .line 82
    if-eq v4, v0, :cond_3

    .line 83
    .line 84
    shl-int v0, p1, v4

    .line 85
    .line 86
    iput v0, p0, LUg/f;->O:I

    .line 87
    .line 88
    sub-int/2addr v0, v2

    .line 89
    iput v0, p0, LUg/f;->N:I

    .line 90
    .line 91
    iput p1, p0, LUg/f;->a:I

    .line 92
    .line 93
    return-void

    .line 94
    :cond_3
    new-instance p0, LUg/c;

    .line 95
    .line 96
    const-string p1, "Invalid \'windowBits\' code"

    .line 97
    .line 98
    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    throw p0

    .line 102
    :cond_4
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 103
    .line 104
    const-string p1, "Bit reader already has associated input stream"

    .line 105
    .line 106
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    throw p0

    .line 110
    :cond_5
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 111
    .line 112
    const-string p1, "State MUST be uninitialized"

    .line 113
    .line 114
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    throw p0
.end method
