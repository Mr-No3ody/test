.class public final LUg/b;
.super Ljava/io/InputStream;
.source "SourceFile"


# instance fields
.field public final a:[B

.field public b:I

.field public c:I

.field public final d:LUg/f;


# direct methods
.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, LUg/f;

    .line 5
    .line 6
    invoke-direct {v0}, LUg/f;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LUg/b;->d:LUg/f;

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    const/16 v1, 0x4000

    .line 14
    .line 15
    new-array v1, v1, [B

    .line 16
    .line 17
    iput-object v1, p0, LUg/b;->a:[B

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    iput v1, p0, LUg/b;->b:I

    .line 21
    .line 22
    iput v1, p0, LUg/b;->c:I

    .line 23
    .line 24
    :try_start_0
    invoke-static {v0, p1}, LUg/f;->a(LUg/f;Ljava/io/InputStream;)V
    :try_end_0
    .catch LUg/c; {:try_start_0 .. :try_end_0} :catch_0

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :catch_0
    move-exception p1

    .line 29
    new-instance v0, Ljava/io/IOException;

    .line 30
    .line 31
    const-string v1, "Brotli decoder initialization failed"

    .line 32
    .line 33
    invoke-direct {v0, v1, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 34
    .line 35
    .line 36
    throw v0

    .line 37
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 38
    .line 39
    const-string v0, "source is null"

    .line 40
    .line 41
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw p1
.end method


# virtual methods
.method public final close()V
    .locals 3

    .line 1
    iget-object v0, p0, LUg/b;->d:LUg/f;

    .line 2
    .line 3
    iget v1, v0, LUg/f;->a:I

    .line 4
    .line 5
    if-eqz v1, :cond_2

    .line 6
    .line 7
    const/16 v2, 0xb

    .line 8
    .line 9
    if-ne v1, v2, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iput v2, v0, LUg/f;->a:I

    .line 13
    .line 14
    iget-object v0, v0, LUg/f;->c:LUg/a;

    .line 15
    .line 16
    iget-object v1, v0, LUg/a;->d:Ljava/io/InputStream;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    iput-object v2, v0, LUg/a;->d:Ljava/io/InputStream;

    .line 20
    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    .line 24
    .line 25
    .line 26
    :cond_1
    :goto_0
    return-void

    .line 27
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 28
    .line 29
    const-string v1, "State MUST be initialized"

    .line 30
    .line 31
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    throw v0
.end method

.method public final read()I
    .locals 3

    .line 1
    iget v0, p0, LUg/b;->c:I

    iget v1, p0, LUg/b;->b:I

    iget-object v2, p0, LUg/b;->a:[B

    if-lt v0, v1, :cond_0

    .line 2
    array-length v0, v2

    const/4 v1, 0x0

    invoke-virtual {p0, v2, v1, v0}, LUg/b;->read([BII)I

    move-result v0

    iput v0, p0, LUg/b;->b:I

    .line 3
    iput v1, p0, LUg/b;->c:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    return v1

    .line 4
    :cond_0
    iget v0, p0, LUg/b;->c:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, LUg/b;->c:I

    aget-byte v0, v2, v0

    and-int/lit16 v0, v0, 0xff

    return v0
.end method

.method public final read([BII)I
    .locals 5

    .line 5
    iget-object v0, p0, LUg/b;->d:LUg/f;

    if-ltz p2, :cond_5

    if-ltz p3, :cond_4

    add-int v1, p2, p3

    .line 6
    array-length v2, p1

    if-gt v1, v2, :cond_3

    const/4 v1, 0x0

    if-nez p3, :cond_0

    return v1

    .line 7
    :cond_0
    iget v2, p0, LUg/b;->b:I

    iget v3, p0, LUg/b;->c:I

    sub-int/2addr v2, v3

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v2

    if-eqz v2, :cond_1

    .line 8
    invoke-static {v2, p3}, Ljava/lang/Math;->min(II)I

    move-result v2

    .line 9
    iget-object v3, p0, LUg/b;->a:[B

    iget v4, p0, LUg/b;->c:I

    invoke-static {v3, v4, p1, p2, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 10
    iget v3, p0, LUg/b;->c:I

    add-int/2addr v3, v2

    iput v3, p0, LUg/b;->c:I

    add-int/2addr p2, v2

    sub-int/2addr p3, v2

    if-nez p3, :cond_1

    return v2

    .line 11
    :cond_1
    :try_start_0
    iput-object p1, v0, LUg/f;->Y:[B

    .line 12
    iput p2, v0, LUg/f;->T:I

    .line 13
    iput p3, v0, LUg/f;->U:I

    .line 14
    iput v1, v0, LUg/f;->V:I

    .line 15
    invoke-static {v0}, LUg/d;->e(LUg/f;)V

    .line 16
    iget p1, v0, LUg/f;->V:I
    :try_end_0
    .catch LUg/c; {:try_start_0 .. :try_end_0} :catch_0

    if-nez p1, :cond_2

    const/4 p1, -0x1

    return p1

    :cond_2
    add-int/2addr p1, v2

    return p1

    :catch_0
    move-exception p1

    .line 17
    new-instance p2, Ljava/io/IOException;

    const-string p3, "Brotli stream decoding failed"

    invoke-direct {p2, p3, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    .line 18
    :cond_3
    new-instance p2, Ljava/lang/IllegalArgumentException;

    const-string p3, "Buffer overflow: "

    const-string v0, " > "

    .line 19
    invoke-static {v1, p3, v0}, Landroidx/camera/camera2/internal/F;->e(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    .line 20
    array-length p1, p1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2

    .line 21
    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Bad length: "

    .line 22
    invoke-static {p3, p2}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 23
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 24
    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p3, "Bad offset: "

    .line 25
    invoke-static {p2, p3}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 26
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
