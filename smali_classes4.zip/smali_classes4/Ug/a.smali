.class public final LUg/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:[B

.field public final b:[I

.field public final c:Lp1/d;

.field public d:Ljava/io/InputStream;

.field public e:Z

.field public f:J

.field public g:I

.field public h:I

.field public i:I


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/16 v0, 0x1040

    .line 5
    .line 6
    new-array v0, v0, [B

    .line 7
    .line 8
    iput-object v0, p0, LUg/a;->a:[B

    .line 9
    .line 10
    const/16 v0, 0x410

    .line 11
    .line 12
    new-array v0, v0, [I

    .line 13
    .line 14
    iput-object v0, p0, LUg/a;->b:[I

    .line 15
    .line 16
    new-instance v0, Lp1/d;

    .line 17
    .line 18
    const/16 v1, 0xe

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    invoke-direct {v0, v1, v2}, Lp1/d;-><init>(IZ)V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, LUg/a;->c:Lp1/d;

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    iput v0, p0, LUg/a;->i:I

    .line 28
    .line 29
    return-void
.end method

.method public static a(LUg/a;Z)V
    .locals 2

    .line 1
    iget-boolean v0, p0, LUg/a;->e:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    iget v0, p0, LUg/a;->h:I

    .line 7
    .line 8
    shl-int/lit8 v0, v0, 0x2

    .line 9
    .line 10
    iget v1, p0, LUg/a;->g:I

    .line 11
    .line 12
    add-int/lit8 v1, v1, 0x7

    .line 13
    .line 14
    shr-int/lit8 v1, v1, 0x3

    .line 15
    .line 16
    add-int/2addr v0, v1

    .line 17
    add-int/lit8 v0, v0, -0x8

    .line 18
    .line 19
    iget p0, p0, LUg/a;->i:I

    .line 20
    .line 21
    if-gt v0, p0, :cond_3

    .line 22
    .line 23
    if-eqz p1, :cond_2

    .line 24
    .line 25
    if-ne v0, p0, :cond_1

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_1
    new-instance p0, LUg/c;

    .line 29
    .line 30
    const-string p1, "Unused bytes after end"

    .line 31
    .line 32
    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw p0

    .line 36
    :cond_2
    :goto_0
    return-void

    .line 37
    :cond_3
    new-instance p0, LUg/c;

    .line 38
    .line 39
    const-string p1, "Read after end"

    .line 40
    .line 41
    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw p0
.end method

.method public static b(LUg/a;)V
    .locals 6

    .line 1
    iget v0, p0, LUg/a;->g:I

    .line 2
    .line 3
    const/16 v1, 0x20

    .line 4
    .line 5
    if-lt v0, v1, :cond_0

    .line 6
    .line 7
    iget v2, p0, LUg/a;->h:I

    .line 8
    .line 9
    add-int/lit8 v3, v2, 0x1

    .line 10
    .line 11
    iput v3, p0, LUg/a;->h:I

    .line 12
    .line 13
    iget-object v3, p0, LUg/a;->b:[I

    .line 14
    .line 15
    aget v2, v3, v2

    .line 16
    .line 17
    int-to-long v2, v2

    .line 18
    shl-long/2addr v2, v1

    .line 19
    iget-wide v4, p0, LUg/a;->f:J

    .line 20
    .line 21
    ushr-long/2addr v4, v1

    .line 22
    or-long/2addr v2, v4

    .line 23
    iput-wide v2, p0, LUg/a;->f:J

    .line 24
    .line 25
    sub-int/2addr v0, v1

    .line 26
    iput v0, p0, LUg/a;->g:I

    .line 27
    .line 28
    :cond_0
    return-void
.end method

.method public static c(LUg/a;)I
    .locals 1

    .line 1
    iget-boolean v0, p0, LUg/a;->e:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget v0, p0, LUg/a;->i:I

    .line 6
    .line 7
    add-int/lit8 v0, v0, 0x3

    .line 8
    .line 9
    shr-int/lit8 v0, v0, 0x2

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/16 v0, 0x400

    .line 13
    .line 14
    :goto_0
    iget p0, p0, LUg/a;->h:I

    .line 15
    .line 16
    sub-int/2addr v0, p0

    .line 17
    return v0
.end method

.method public static d(LUg/a;I)I
    .locals 4

    .line 1
    invoke-static {p0}, LUg/a;->b(LUg/a;)V

    .line 2
    .line 3
    .line 4
    iget-wide v0, p0, LUg/a;->f:J

    .line 5
    .line 6
    iget v2, p0, LUg/a;->g:I

    .line 7
    .line 8
    ushr-long/2addr v0, v2

    .line 9
    long-to-int v0, v0

    .line 10
    const/4 v1, 0x1

    .line 11
    shl-int v3, v1, p1

    .line 12
    .line 13
    sub-int/2addr v3, v1

    .line 14
    and-int/2addr v0, v3

    .line 15
    add-int/2addr v2, p1

    .line 16
    iput v2, p0, LUg/a;->g:I

    .line 17
    .line 18
    return v0
.end method

.method public static e(LUg/a;)V
    .locals 7

    .line 1
    iget v0, p0, LUg/a;->h:I

    .line 2
    .line 3
    const/16 v1, 0x3f7

    .line 4
    .line 5
    if-gt v0, v1, :cond_0

    .line 6
    .line 7
    goto/16 :goto_3

    .line 8
    .line 9
    :cond_0
    iget-boolean v1, p0, LUg/a;->e:Z

    .line 10
    .line 11
    if-eqz v1, :cond_2

    .line 12
    .line 13
    invoke-static {p0}, LUg/a;->c(LUg/a;)I

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    const/4 v0, -0x2

    .line 18
    if-lt p0, v0, :cond_1

    .line 19
    .line 20
    goto :goto_3

    .line 21
    :cond_1
    new-instance p0, LUg/c;

    .line 22
    .line 23
    const-string v0, "No more input"

    .line 24
    .line 25
    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw p0

    .line 29
    :cond_2
    shl-int/lit8 v0, v0, 0x2

    .line 30
    .line 31
    rsub-int v1, v0, 0x1000

    .line 32
    .line 33
    iget-object v2, p0, LUg/a;->a:[B

    .line 34
    .line 35
    const/4 v3, 0x0

    .line 36
    invoke-static {v2, v0, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 37
    .line 38
    .line 39
    iput v3, p0, LUg/a;->h:I

    .line 40
    .line 41
    :goto_0
    const/16 v0, 0x1000

    .line 42
    .line 43
    if-ge v1, v0, :cond_4

    .line 44
    .line 45
    :try_start_0
    iget-object v0, p0, LUg/a;->d:Ljava/io/InputStream;

    .line 46
    .line 47
    rsub-int v4, v1, 0x1000

    .line 48
    .line 49
    invoke-virtual {v0, v2, v1, v4}, Ljava/io/InputStream;->read([BII)I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-gtz v0, :cond_3

    .line 54
    .line 55
    const/4 v0, 0x1

    .line 56
    iput-boolean v0, p0, LUg/a;->e:Z

    .line 57
    .line 58
    iput v1, p0, LUg/a;->i:I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 59
    .line 60
    add-int/lit8 v1, v1, 0x3

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_3
    add-int/2addr v1, v0

    .line 64
    goto :goto_0

    .line 65
    :catch_0
    move-exception p0

    .line 66
    new-instance v0, LUg/c;

    .line 67
    .line 68
    const-string v1, "Failed to read input"

    .line 69
    .line 70
    invoke-direct {v0, v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 71
    .line 72
    .line 73
    throw v0

    .line 74
    :cond_4
    :goto_1
    shr-int/lit8 v0, v1, 0x2

    .line 75
    .line 76
    :goto_2
    if-ge v3, v0, :cond_5

    .line 77
    .line 78
    iget-object v1, p0, LUg/a;->c:Lp1/d;

    .line 79
    .line 80
    iget-object v2, v1, Lp1/d;->c:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v2, [I

    .line 83
    .line 84
    iget-object v1, v1, Lp1/d;->b:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v1, [B

    .line 87
    .line 88
    mul-int/lit8 v4, v3, 0x4

    .line 89
    .line 90
    aget-byte v5, v1, v4

    .line 91
    .line 92
    and-int/lit16 v5, v5, 0xff

    .line 93
    .line 94
    add-int/lit8 v6, v4, 0x1

    .line 95
    .line 96
    aget-byte v6, v1, v6

    .line 97
    .line 98
    and-int/lit16 v6, v6, 0xff

    .line 99
    .line 100
    shl-int/lit8 v6, v6, 0x8

    .line 101
    .line 102
    or-int/2addr v5, v6

    .line 103
    add-int/lit8 v6, v4, 0x2

    .line 104
    .line 105
    aget-byte v6, v1, v6

    .line 106
    .line 107
    and-int/lit16 v6, v6, 0xff

    .line 108
    .line 109
    shl-int/lit8 v6, v6, 0x10

    .line 110
    .line 111
    or-int/2addr v5, v6

    .line 112
    add-int/lit8 v4, v4, 0x3

    .line 113
    .line 114
    aget-byte v1, v1, v4

    .line 115
    .line 116
    and-int/lit16 v1, v1, 0xff

    .line 117
    .line 118
    shl-int/lit8 v1, v1, 0x18

    .line 119
    .line 120
    or-int/2addr v1, v5

    .line 121
    aput v1, v2, v3

    .line 122
    .line 123
    add-int/lit8 v3, v3, 0x1

    .line 124
    .line 125
    goto :goto_2

    .line 126
    :cond_5
    :goto_3
    return-void
.end method
