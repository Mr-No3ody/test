.class public final synthetic Lvc/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, Lvc/b;->a:I

    iput-object p1, p0, Lvc/b;->b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lvc/b;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lvc/b;->b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;->b(Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, Lvc/b;->b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;->d(Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, Lvc/b;->b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;->h(Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, Lvc/b;->b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;->g(Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, p0, Lvc/b;->b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;->i(Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;)Landroid/widget/Button;

    move-result-object v0

    return-object v0

    :pswitch_4
    iget-object v0, p0, Lvc/b;->b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;->c(Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;)Landroid/widget/Button;

    move-result-object v0

    return-object v0

    :pswitch_5
    iget-object v0, p0, Lvc/b;->b:Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;->a(Lcom/transsnet/palmpay/jara_packet/ui/dialog/RichTextDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
