.class public final LTd/b;
.super Landroidx/room/n;
.source "SourceFile"


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Landroidx/room/G;I)V
    .locals 0

    .line 1
    iput p2, p0, LTd/b;->d:I

    invoke-direct {p0, p1}, Landroidx/room/P;-><init>(Landroidx/room/G;)V

    return-void
.end method

.method public constructor <init>(Landroidx/room/G;IZ)V
    .locals 0

    iput p2, p0, LTd/b;->d:I

    .line 2
    const-string p2, "database"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0, p1}, Landroidx/room/P;-><init>(Landroidx/room/G;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    .line 1
    iget v0, p0, LTd/b;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "DELETE FROM `events` WHERE `id` = ?"

    .line 7
    .line 8
    return-object v0

    .line 9
    :pswitch_0
    const-string v0, "UPDATE OR ABORT `request_contacts` SET `contact_member_id` = ?,`alias` = ?,`full_name` = ?,`is_favourite` = ?,`is_friend` = ?,`phone` = ?,`photo_path` = ?,`request_source` = ?,`create_time` = ?,`update_time` = ?,`expire_time` = ?,`own_member_id` = ? WHERE `contact_member_id` = ? AND `own_member_id` = ?"

    .line 10
    .line 11
    return-object v0

    .line 12
    :pswitch_1
    const-string v0, "DELETE FROM `request_contacts` WHERE `contact_member_id` = ? AND `own_member_id` = ?"

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_2
    const-string v0, "UPDATE OR ABORT `ad_detail` SET `ad_id` = ?,`application_id` = ?,`ad_slot_id` = ?,`image_url` = ?,`image_url_dark` = ?,`secondary_image_url` = ?,`secondary_image_url_dark` = ?,`jump_type` = ?,`relative_url` = ?,`image_dimention` = ?,`country_code` = ?,`valid_start_time` = ?,`valid_end_time` = ?,`show_times` = ?,`show_times_condition` = ?,`click_frequency` = ?,`max_close_count` = ?,`show_dates` = ?,`multiple_imageUrl` = ?,`text_content` = ?,`text_font_size` = ?,`text_font_color` = ?,`text_font_color_dark` = ?,`text_scroll_speed` = ?,`background_color` = ?,`background_color_dark` = ?,`ad_type` = ?,`native_ad_title` = ?,`native_ad_content` = ?,`native_ad_photo` = ?,`show_close_button` = ?,`has_show_times` = ?,`show_date` = ?,`click_date` = ?,`close_time` = ?,`close_count` = ?,`create_time` = ?,`update_time` = ?,`current_enable` = ?,`jump_params` = ?,`default_img_res` = ?,`text_icon_url` = ?,`text_icon_url_dark` = ?,`alpha` = ?,`display_order` = ? WHERE `ad_id` = ?"

    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_3
    const-string v0, "DELETE FROM `ad_detail` WHERE `ad_id` = ?"

    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_4
    const-string v0, "UPDATE OR ABORT `WorkSpec` SET `id` = ?,`state` = ?,`worker_class_name` = ?,`input_merger_class_name` = ?,`input` = ?,`output` = ?,`initial_delay` = ?,`interval_duration` = ?,`flex_duration` = ?,`run_attempt_count` = ?,`backoff_policy` = ?,`backoff_delay_duration` = ?,`last_enqueue_time` = ?,`minimum_retention_duration` = ?,`schedule_requested_at` = ?,`run_in_foreground` = ?,`out_of_quota_policy` = ?,`period_count` = ?,`generation` = ?,`next_schedule_time_override` = ?,`next_schedule_time_override_generation` = ?,`stop_reason` = ?,`trace_tag` = ?,`required_network_type` = ?,`required_network_request` = ?,`requires_charging` = ?,`requires_device_idle` = ?,`requires_battery_not_low` = ?,`requires_storage_not_low` = ?,`trigger_content_update_delay` = ?,`trigger_max_content_delay` = ?,`content_uri_triggers` = ? WHERE `id` = ?"

    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_5
    const-string v0, "UPDATE OR ABORT `biller_search_record` SET `recordId` = ?,`memberId` = ?,`searchText` = ?,`updateTime` = ? WHERE `recordId` = ?"

    .line 25
    .line 26
    return-object v0

    .line 27
    :pswitch_6
    const-string v0, "DELETE FROM `biller_search_record` WHERE `recordId` = ?"

    .line 28
    .line 29
    return-object v0

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final d(Landroidx/sqlite/db/SupportSQLiteStatement;Ljava/lang/Object;)V
    .locals 6

    .line 1
    iget v0, p0, LTd/b;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p2, Lcom/transsnet/analysis/data/local/entity/EventsEntity;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    iget-wide v1, p2, Lcom/transsnet/analysis/data/local/entity/EventsEntity;->id:J

    .line 10
    .line 11
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :pswitch_0
    check-cast p2, Lcom/transsnet/palmpay/core/db/entity/RequestContact;

    .line 16
    .line 17
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getContactsMemberId()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v1, 0x1

    .line 22
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getAlias()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    const/4 v1, 0x2

    .line 30
    if-nez v0, :cond_0

    .line 31
    .line 32
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getAlias()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 41
    .line 42
    .line 43
    :goto_0
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getFullName()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    const/4 v1, 0x3

    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 51
    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getFullName()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 59
    .line 60
    .line 61
    :goto_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getIsFavourite()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    const/4 v1, 0x4

    .line 66
    if-nez v0, :cond_2

    .line 67
    .line 68
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 69
    .line 70
    .line 71
    goto :goto_2

    .line 72
    :cond_2
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getIsFavourite()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 77
    .line 78
    .line 79
    :goto_2
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->isFriend()Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    const/4 v1, 0x5

    .line 84
    int-to-long v2, v0

    .line 85
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getPhone()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    const/4 v1, 0x6

    .line 93
    if-nez v0, :cond_3

    .line 94
    .line 95
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 96
    .line 97
    .line 98
    goto :goto_3

    .line 99
    :cond_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getPhone()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 104
    .line 105
    .line 106
    :goto_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getPhotoPath()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    const/4 v1, 0x7

    .line 111
    if-nez v0, :cond_4

    .line 112
    .line 113
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 114
    .line 115
    .line 116
    goto :goto_4

    .line 117
    :cond_4
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getPhotoPath()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 122
    .line 123
    .line 124
    :goto_4
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getRequestSource()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    const/16 v1, 0x8

    .line 129
    .line 130
    if-nez v0, :cond_5

    .line 131
    .line 132
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 133
    .line 134
    .line 135
    goto :goto_5

    .line 136
    :cond_5
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getRequestSource()Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 141
    .line 142
    .line 143
    :goto_5
    const/16 v0, 0x9

    .line 144
    .line 145
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getCreateTime()J

    .line 146
    .line 147
    .line 148
    move-result-wide v1

    .line 149
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 150
    .line 151
    .line 152
    const/16 v0, 0xa

    .line 153
    .line 154
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getUpdateTime()J

    .line 155
    .line 156
    .line 157
    move-result-wide v1

    .line 158
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 159
    .line 160
    .line 161
    const/16 v0, 0xb

    .line 162
    .line 163
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getExpireTime()J

    .line 164
    .line 165
    .line 166
    move-result-wide v1

    .line 167
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 168
    .line 169
    .line 170
    const/16 v0, 0xc

    .line 171
    .line 172
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getMemberId()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v1

    .line 176
    invoke-interface {p1, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 177
    .line 178
    .line 179
    const/16 v0, 0xd

    .line 180
    .line 181
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getContactsMemberId()Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v1

    .line 185
    invoke-interface {p1, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 186
    .line 187
    .line 188
    const/16 v0, 0xe

    .line 189
    .line 190
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getMemberId()Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object p2

    .line 194
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 195
    .line 196
    .line 197
    return-void

    .line 198
    :pswitch_1
    check-cast p2, Lcom/transsnet/palmpay/core/db/entity/RequestContact;

    .line 199
    .line 200
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getContactsMemberId()Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    const/4 v1, 0x1

    .line 205
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 206
    .line 207
    .line 208
    const/4 v0, 0x2

    .line 209
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getMemberId()Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object p2

    .line 213
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 214
    .line 215
    .line 216
    return-void

    .line 217
    :pswitch_2
    check-cast p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;

    .line 218
    .line 219
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->adId:Ljava/lang/String;

    .line 220
    .line 221
    const/4 v1, 0x1

    .line 222
    if-nez v0, :cond_6

    .line 223
    .line 224
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 225
    .line 226
    .line 227
    goto :goto_6

    .line 228
    :cond_6
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 229
    .line 230
    .line 231
    :goto_6
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->applicationId:Ljava/lang/String;

    .line 232
    .line 233
    const/4 v1, 0x2

    .line 234
    if-nez v0, :cond_7

    .line 235
    .line 236
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 237
    .line 238
    .line 239
    goto :goto_7

    .line 240
    :cond_7
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 241
    .line 242
    .line 243
    :goto_7
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->adSlotId:Ljava/lang/String;

    .line 244
    .line 245
    const/4 v1, 0x3

    .line 246
    if-nez v0, :cond_8

    .line 247
    .line 248
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 249
    .line 250
    .line 251
    goto :goto_8

    .line 252
    :cond_8
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 253
    .line 254
    .line 255
    :goto_8
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->imageUrl:Ljava/lang/String;

    .line 256
    .line 257
    const/4 v1, 0x4

    .line 258
    if-nez v0, :cond_9

    .line 259
    .line 260
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 261
    .line 262
    .line 263
    goto :goto_9

    .line 264
    :cond_9
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 265
    .line 266
    .line 267
    :goto_9
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->imageUrlDark:Ljava/lang/String;

    .line 268
    .line 269
    const/4 v1, 0x5

    .line 270
    if-nez v0, :cond_a

    .line 271
    .line 272
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 273
    .line 274
    .line 275
    goto :goto_a

    .line 276
    :cond_a
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 277
    .line 278
    .line 279
    :goto_a
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->h5ImageUrl:Ljava/lang/String;

    .line 280
    .line 281
    const/4 v1, 0x6

    .line 282
    if-nez v0, :cond_b

    .line 283
    .line 284
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 285
    .line 286
    .line 287
    goto :goto_b

    .line 288
    :cond_b
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 289
    .line 290
    .line 291
    :goto_b
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->h5ImageUrlDark:Ljava/lang/String;

    .line 292
    .line 293
    const/4 v1, 0x7

    .line 294
    if-nez v0, :cond_c

    .line 295
    .line 296
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 297
    .line 298
    .line 299
    goto :goto_c

    .line 300
    :cond_c
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 301
    .line 302
    .line 303
    :goto_c
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->jumpType:Ljava/lang/String;

    .line 304
    .line 305
    const/16 v1, 0x8

    .line 306
    .line 307
    if-nez v0, :cond_d

    .line 308
    .line 309
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 310
    .line 311
    .line 312
    goto :goto_d

    .line 313
    :cond_d
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 314
    .line 315
    .line 316
    :goto_d
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->relativeUrl:Ljava/lang/String;

    .line 317
    .line 318
    const/16 v1, 0x9

    .line 319
    .line 320
    if-nez v0, :cond_e

    .line 321
    .line 322
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 323
    .line 324
    .line 325
    goto :goto_e

    .line 326
    :cond_e
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 327
    .line 328
    .line 329
    :goto_e
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->imageDimention:Ljava/lang/String;

    .line 330
    .line 331
    const/16 v1, 0xa

    .line 332
    .line 333
    if-nez v0, :cond_f

    .line 334
    .line 335
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 336
    .line 337
    .line 338
    goto :goto_f

    .line 339
    :cond_f
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 340
    .line 341
    .line 342
    :goto_f
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->countryCode:Ljava/lang/String;

    .line 343
    .line 344
    const/16 v1, 0xb

    .line 345
    .line 346
    if-nez v0, :cond_10

    .line 347
    .line 348
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 349
    .line 350
    .line 351
    goto :goto_10

    .line 352
    :cond_10
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 353
    .line 354
    .line 355
    :goto_10
    const/16 v0, 0xc

    .line 356
    .line 357
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->validStartTime:J

    .line 358
    .line 359
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 360
    .line 361
    .line 362
    const/16 v0, 0xd

    .line 363
    .line 364
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->validEndTime:J

    .line 365
    .line 366
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 367
    .line 368
    .line 369
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showTimes:I

    .line 370
    .line 371
    int-to-long v0, v0

    .line 372
    const/16 v2, 0xe

    .line 373
    .line 374
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 375
    .line 376
    .line 377
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showTimesCondition:Ljava/lang/Integer;

    .line 378
    .line 379
    const/16 v1, 0xf

    .line 380
    .line 381
    if-nez v0, :cond_11

    .line 382
    .line 383
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 384
    .line 385
    .line 386
    goto :goto_11

    .line 387
    :cond_11
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 388
    .line 389
    .line 390
    move-result v0

    .line 391
    int-to-long v2, v0

    .line 392
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 393
    .line 394
    .line 395
    :goto_11
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->clickFrequency:Ljava/lang/Integer;

    .line 396
    .line 397
    const/16 v1, 0x10

    .line 398
    .line 399
    if-nez v0, :cond_12

    .line 400
    .line 401
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 402
    .line 403
    .line 404
    goto :goto_12

    .line 405
    :cond_12
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 406
    .line 407
    .line 408
    move-result v0

    .line 409
    int-to-long v2, v0

    .line 410
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 411
    .line 412
    .line 413
    :goto_12
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->closeControl:I

    .line 414
    .line 415
    int-to-long v0, v0

    .line 416
    const/16 v2, 0x11

    .line 417
    .line 418
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 419
    .line 420
    .line 421
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showDates:Ljava/lang/String;

    .line 422
    .line 423
    const/16 v1, 0x12

    .line 424
    .line 425
    if-nez v0, :cond_13

    .line 426
    .line 427
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 428
    .line 429
    .line 430
    goto :goto_13

    .line 431
    :cond_13
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 432
    .line 433
    .line 434
    :goto_13
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->multipleImageUrl:Ljava/lang/String;

    .line 435
    .line 436
    const/16 v1, 0x13

    .line 437
    .line 438
    if-nez v0, :cond_14

    .line 439
    .line 440
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 441
    .line 442
    .line 443
    goto :goto_14

    .line 444
    :cond_14
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 445
    .line 446
    .line 447
    :goto_14
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textContent:Ljava/lang/String;

    .line 448
    .line 449
    const/16 v1, 0x14

    .line 450
    .line 451
    if-nez v0, :cond_15

    .line 452
    .line 453
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 454
    .line 455
    .line 456
    goto :goto_15

    .line 457
    :cond_15
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 458
    .line 459
    .line 460
    :goto_15
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textFontSize:Ljava/lang/String;

    .line 461
    .line 462
    const/16 v1, 0x15

    .line 463
    .line 464
    if-nez v0, :cond_16

    .line 465
    .line 466
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 467
    .line 468
    .line 469
    goto :goto_16

    .line 470
    :cond_16
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 471
    .line 472
    .line 473
    :goto_16
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textFontColor:Ljava/lang/String;

    .line 474
    .line 475
    const/16 v1, 0x16

    .line 476
    .line 477
    if-nez v0, :cond_17

    .line 478
    .line 479
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 480
    .line 481
    .line 482
    goto :goto_17

    .line 483
    :cond_17
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 484
    .line 485
    .line 486
    :goto_17
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textFontColorDark:Ljava/lang/String;

    .line 487
    .line 488
    const/16 v1, 0x17

    .line 489
    .line 490
    if-nez v0, :cond_18

    .line 491
    .line 492
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 493
    .line 494
    .line 495
    goto :goto_18

    .line 496
    :cond_18
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 497
    .line 498
    .line 499
    :goto_18
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textScrollSpeed:Ljava/lang/String;

    .line 500
    .line 501
    const/16 v1, 0x18

    .line 502
    .line 503
    if-nez v0, :cond_19

    .line 504
    .line 505
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 506
    .line 507
    .line 508
    goto :goto_19

    .line 509
    :cond_19
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 510
    .line 511
    .line 512
    :goto_19
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->backgroundColor:Ljava/lang/String;

    .line 513
    .line 514
    const/16 v1, 0x19

    .line 515
    .line 516
    if-nez v0, :cond_1a

    .line 517
    .line 518
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 519
    .line 520
    .line 521
    goto :goto_1a

    .line 522
    :cond_1a
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 523
    .line 524
    .line 525
    :goto_1a
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->backgroundColorDark:Ljava/lang/String;

    .line 526
    .line 527
    const/16 v1, 0x1a

    .line 528
    .line 529
    if-nez v0, :cond_1b

    .line 530
    .line 531
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 532
    .line 533
    .line 534
    goto :goto_1b

    .line 535
    :cond_1b
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 536
    .line 537
    .line 538
    :goto_1b
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->adType:I

    .line 539
    .line 540
    int-to-long v0, v0

    .line 541
    const/16 v2, 0x1b

    .line 542
    .line 543
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 544
    .line 545
    .line 546
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->nativeAdTitle:Ljava/lang/String;

    .line 547
    .line 548
    const/16 v1, 0x1c

    .line 549
    .line 550
    if-nez v0, :cond_1c

    .line 551
    .line 552
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 553
    .line 554
    .line 555
    goto :goto_1c

    .line 556
    :cond_1c
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 557
    .line 558
    .line 559
    :goto_1c
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->nativeAdContent:Ljava/lang/String;

    .line 560
    .line 561
    const/16 v1, 0x1d

    .line 562
    .line 563
    if-nez v0, :cond_1d

    .line 564
    .line 565
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 566
    .line 567
    .line 568
    goto :goto_1d

    .line 569
    :cond_1d
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 570
    .line 571
    .line 572
    :goto_1d
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->nativeAdPhoto:Ljava/lang/String;

    .line 573
    .line 574
    const/16 v1, 0x1e

    .line 575
    .line 576
    if-nez v0, :cond_1e

    .line 577
    .line 578
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 579
    .line 580
    .line 581
    goto :goto_1e

    .line 582
    :cond_1e
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 583
    .line 584
    .line 585
    :goto_1e
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showCloseButton:I

    .line 586
    .line 587
    int-to-long v0, v0

    .line 588
    const/16 v2, 0x1f

    .line 589
    .line 590
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 591
    .line 592
    .line 593
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->hasShowTimes:I

    .line 594
    .line 595
    int-to-long v0, v0

    .line 596
    const/16 v2, 0x20

    .line 597
    .line 598
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 599
    .line 600
    .line 601
    const/16 v0, 0x21

    .line 602
    .line 603
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showDate:J

    .line 604
    .line 605
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 606
    .line 607
    .line 608
    const/16 v0, 0x22

    .line 609
    .line 610
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->clickDate:J

    .line 611
    .line 612
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 613
    .line 614
    .line 615
    const/16 v0, 0x23

    .line 616
    .line 617
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->closeTime:J

    .line 618
    .line 619
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 620
    .line 621
    .line 622
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->closeCount:I

    .line 623
    .line 624
    int-to-long v0, v0

    .line 625
    const/16 v2, 0x24

    .line 626
    .line 627
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 628
    .line 629
    .line 630
    const/16 v0, 0x25

    .line 631
    .line 632
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->createTime:J

    .line 633
    .line 634
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 635
    .line 636
    .line 637
    const/16 v0, 0x26

    .line 638
    .line 639
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->updateTime:J

    .line 640
    .line 641
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 642
    .line 643
    .line 644
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->curEnable:I

    .line 645
    .line 646
    int-to-long v0, v0

    .line 647
    const/16 v2, 0x27

    .line 648
    .line 649
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 650
    .line 651
    .line 652
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->jumpParams:Ljava/lang/String;

    .line 653
    .line 654
    const/16 v1, 0x28

    .line 655
    .line 656
    if-nez v0, :cond_1f

    .line 657
    .line 658
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 659
    .line 660
    .line 661
    goto :goto_1f

    .line 662
    :cond_1f
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 663
    .line 664
    .line 665
    :goto_1f
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->defaultImgRes:I

    .line 666
    .line 667
    int-to-long v0, v0

    .line 668
    const/16 v2, 0x29

    .line 669
    .line 670
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 671
    .line 672
    .line 673
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textIconUrl:Ljava/lang/String;

    .line 674
    .line 675
    const/16 v1, 0x2a

    .line 676
    .line 677
    if-nez v0, :cond_20

    .line 678
    .line 679
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 680
    .line 681
    .line 682
    goto :goto_20

    .line 683
    :cond_20
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 684
    .line 685
    .line 686
    :goto_20
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textIconUrlDark:Ljava/lang/String;

    .line 687
    .line 688
    const/16 v1, 0x2b

    .line 689
    .line 690
    if-nez v0, :cond_21

    .line 691
    .line 692
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 693
    .line 694
    .line 695
    goto :goto_21

    .line 696
    :cond_21
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 697
    .line 698
    .line 699
    :goto_21
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->alpha:I

    .line 700
    .line 701
    int-to-long v0, v0

    .line 702
    const/16 v2, 0x2c

    .line 703
    .line 704
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 705
    .line 706
    .line 707
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->displayOrder:I

    .line 708
    .line 709
    int-to-long v0, v0

    .line 710
    const/16 v2, 0x2d

    .line 711
    .line 712
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 713
    .line 714
    .line 715
    iget-object p2, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->adId:Ljava/lang/String;

    .line 716
    .line 717
    const/16 v0, 0x2e

    .line 718
    .line 719
    if-nez p2, :cond_22

    .line 720
    .line 721
    invoke-interface {p1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 722
    .line 723
    .line 724
    goto :goto_22

    .line 725
    :cond_22
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 726
    .line 727
    .line 728
    :goto_22
    return-void

    .line 729
    :pswitch_3
    check-cast p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;

    .line 730
    .line 731
    iget-object p2, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->adId:Ljava/lang/String;

    .line 732
    .line 733
    const/4 v0, 0x1

    .line 734
    if-nez p2, :cond_23

    .line 735
    .line 736
    invoke-interface {p1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 737
    .line 738
    .line 739
    goto :goto_23

    .line 740
    :cond_23
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 741
    .line 742
    .line 743
    :goto_23
    return-void

    .line 744
    :pswitch_4
    check-cast p2, Landroidx/work/impl/model/k;

    .line 745
    .line 746
    iget-object v0, p2, Landroidx/work/impl/model/k;->a:Ljava/lang/String;

    .line 747
    .line 748
    const/4 v1, 0x1

    .line 749
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 750
    .line 751
    .line 752
    iget-object v0, p2, Landroidx/work/impl/model/k;->b:LV0/Q;

    .line 753
    .line 754
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->n0(LV0/Q;)I

    .line 755
    .line 756
    .line 757
    move-result v0

    .line 758
    const/4 v2, 0x2

    .line 759
    int-to-long v3, v0

    .line 760
    invoke-interface {p1, v2, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 761
    .line 762
    .line 763
    const/4 v0, 0x3

    .line 764
    iget-object v2, p2, Landroidx/work/impl/model/k;->c:Ljava/lang/String;

    .line 765
    .line 766
    invoke-interface {p1, v0, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 767
    .line 768
    .line 769
    const/4 v0, 0x4

    .line 770
    iget-object v2, p2, Landroidx/work/impl/model/k;->d:Ljava/lang/String;

    .line 771
    .line 772
    invoke-interface {p1, v0, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 773
    .line 774
    .line 775
    iget-object v0, p2, Landroidx/work/impl/model/k;->e:LV0/n;

    .line 776
    .line 777
    sget-object v2, LV0/n;->b:LV0/l;

    .line 778
    .line 779
    invoke-virtual {v2, v0}, LV0/l;->toByteArrayInternalV1(LV0/n;)[B

    .line 780
    .line 781
    .line 782
    move-result-object v0

    .line 783
    const/4 v3, 0x5

    .line 784
    invoke-interface {p1, v3, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 785
    .line 786
    .line 787
    iget-object v0, p2, Landroidx/work/impl/model/k;->f:LV0/n;

    .line 788
    .line 789
    invoke-virtual {v2, v0}, LV0/l;->toByteArrayInternalV1(LV0/n;)[B

    .line 790
    .line 791
    .line 792
    move-result-object v0

    .line 793
    const/4 v2, 0x6

    .line 794
    invoke-interface {p1, v2, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 795
    .line 796
    .line 797
    const/4 v0, 0x7

    .line 798
    iget-wide v2, p2, Landroidx/work/impl/model/k;->g:J

    .line 799
    .line 800
    invoke-interface {p1, v0, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 801
    .line 802
    .line 803
    const/16 v0, 0x8

    .line 804
    .line 805
    iget-wide v2, p2, Landroidx/work/impl/model/k;->h:J

    .line 806
    .line 807
    invoke-interface {p1, v0, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 808
    .line 809
    .line 810
    const/16 v0, 0x9

    .line 811
    .line 812
    iget-wide v2, p2, Landroidx/work/impl/model/k;->i:J

    .line 813
    .line 814
    invoke-interface {p1, v0, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 815
    .line 816
    .line 817
    iget v0, p2, Landroidx/work/impl/model/k;->k:I

    .line 818
    .line 819
    int-to-long v2, v0

    .line 820
    const/16 v0, 0xa

    .line 821
    .line 822
    invoke-interface {p1, v0, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 823
    .line 824
    .line 825
    iget-object v0, p2, Landroidx/work/impl/model/k;->l:LV0/a;

    .line 826
    .line 827
    const-string v2, "backoffPolicy"

    .line 828
    .line 829
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 830
    .line 831
    .line 832
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 833
    .line 834
    .line 835
    move-result v0

    .line 836
    const/4 v2, 0x0

    .line 837
    if-eqz v0, :cond_25

    .line 838
    .line 839
    if-ne v0, v1, :cond_24

    .line 840
    .line 841
    move v0, v1

    .line 842
    goto :goto_24

    .line 843
    :cond_24
    new-instance p1, Lxf/l;

    .line 844
    .line 845
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 846
    .line 847
    .line 848
    throw p1

    .line 849
    :cond_25
    move v0, v2

    .line 850
    :goto_24
    const/16 v3, 0xb

    .line 851
    .line 852
    int-to-long v4, v0

    .line 853
    invoke-interface {p1, v3, v4, v5}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 854
    .line 855
    .line 856
    const/16 v0, 0xc

    .line 857
    .line 858
    iget-wide v3, p2, Landroidx/work/impl/model/k;->m:J

    .line 859
    .line 860
    invoke-interface {p1, v0, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 861
    .line 862
    .line 863
    const/16 v0, 0xd

    .line 864
    .line 865
    iget-wide v3, p2, Landroidx/work/impl/model/k;->n:J

    .line 866
    .line 867
    invoke-interface {p1, v0, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 868
    .line 869
    .line 870
    const/16 v0, 0xe

    .line 871
    .line 872
    iget-wide v3, p2, Landroidx/work/impl/model/k;->o:J

    .line 873
    .line 874
    invoke-interface {p1, v0, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 875
    .line 876
    .line 877
    const/16 v0, 0xf

    .line 878
    .line 879
    iget-wide v3, p2, Landroidx/work/impl/model/k;->p:J

    .line 880
    .line 881
    invoke-interface {p1, v0, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 882
    .line 883
    .line 884
    iget-boolean v0, p2, Landroidx/work/impl/model/k;->q:Z

    .line 885
    .line 886
    const/16 v3, 0x10

    .line 887
    .line 888
    int-to-long v4, v0

    .line 889
    invoke-interface {p1, v3, v4, v5}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 890
    .line 891
    .line 892
    iget-object v0, p2, Landroidx/work/impl/model/k;->r:LV0/K;

    .line 893
    .line 894
    const-string v3, "policy"

    .line 895
    .line 896
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 897
    .line 898
    .line 899
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 900
    .line 901
    .line 902
    move-result v0

    .line 903
    if-eqz v0, :cond_27

    .line 904
    .line 905
    if-ne v0, v1, :cond_26

    .line 906
    .line 907
    goto :goto_25

    .line 908
    :cond_26
    new-instance p1, Lxf/l;

    .line 909
    .line 910
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 911
    .line 912
    .line 913
    throw p1

    .line 914
    :cond_27
    move v1, v2

    .line 915
    :goto_25
    const/16 v0, 0x11

    .line 916
    .line 917
    int-to-long v1, v1

    .line 918
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 919
    .line 920
    .line 921
    iget v0, p2, Landroidx/work/impl/model/k;->s:I

    .line 922
    .line 923
    int-to-long v0, v0

    .line 924
    const/16 v2, 0x12

    .line 925
    .line 926
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 927
    .line 928
    .line 929
    iget v0, p2, Landroidx/work/impl/model/k;->t:I

    .line 930
    .line 931
    int-to-long v0, v0

    .line 932
    const/16 v2, 0x13

    .line 933
    .line 934
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 935
    .line 936
    .line 937
    iget-wide v0, p2, Landroidx/work/impl/model/k;->u:J

    .line 938
    .line 939
    const/16 v2, 0x14

    .line 940
    .line 941
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 942
    .line 943
    .line 944
    iget v0, p2, Landroidx/work/impl/model/k;->v:I

    .line 945
    .line 946
    int-to-long v0, v0

    .line 947
    const/16 v2, 0x15

    .line 948
    .line 949
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 950
    .line 951
    .line 952
    iget v0, p2, Landroidx/work/impl/model/k;->w:I

    .line 953
    .line 954
    int-to-long v0, v0

    .line 955
    const/16 v2, 0x16

    .line 956
    .line 957
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 958
    .line 959
    .line 960
    iget-object v0, p2, Landroidx/work/impl/model/k;->x:Ljava/lang/String;

    .line 961
    .line 962
    const/16 v1, 0x17

    .line 963
    .line 964
    if-nez v0, :cond_28

    .line 965
    .line 966
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 967
    .line 968
    .line 969
    goto :goto_26

    .line 970
    :cond_28
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 971
    .line 972
    .line 973
    :goto_26
    iget-object v0, p2, Landroidx/work/impl/model/k;->j:LV0/h;

    .line 974
    .line 975
    iget-object v1, v0, LV0/h;->a:LV0/D;

    .line 976
    .line 977
    invoke-static {v1}, Lorg/chromium/support_lib_boundary/util/b;->U(LV0/D;)I

    .line 978
    .line 979
    .line 980
    move-result v1

    .line 981
    const/16 v2, 0x18

    .line 982
    .line 983
    int-to-long v3, v1

    .line 984
    invoke-interface {p1, v2, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 985
    .line 986
    .line 987
    iget-object v1, v0, LV0/h;->b:Landroidx/work/impl/utils/g;

    .line 988
    .line 989
    invoke-static {v1}, Lorg/chromium/support_lib_boundary/util/b;->x(Landroidx/work/impl/utils/g;)[B

    .line 990
    .line 991
    .line 992
    move-result-object v1

    .line 993
    const/16 v2, 0x19

    .line 994
    .line 995
    invoke-interface {p1, v2, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 996
    .line 997
    .line 998
    iget-boolean v1, v0, LV0/h;->c:Z

    .line 999
    .line 1000
    int-to-long v1, v1

    .line 1001
    const/16 v3, 0x1a

    .line 1002
    .line 1003
    invoke-interface {p1, v3, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1004
    .line 1005
    .line 1006
    iget-boolean v1, v0, LV0/h;->d:Z

    .line 1007
    .line 1008
    int-to-long v1, v1

    .line 1009
    const/16 v3, 0x1b

    .line 1010
    .line 1011
    invoke-interface {p1, v3, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1012
    .line 1013
    .line 1014
    iget-boolean v1, v0, LV0/h;->e:Z

    .line 1015
    .line 1016
    int-to-long v1, v1

    .line 1017
    const/16 v3, 0x1c

    .line 1018
    .line 1019
    invoke-interface {p1, v3, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1020
    .line 1021
    .line 1022
    iget-boolean v1, v0, LV0/h;->f:Z

    .line 1023
    .line 1024
    int-to-long v1, v1

    .line 1025
    const/16 v3, 0x1d

    .line 1026
    .line 1027
    invoke-interface {p1, v3, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1028
    .line 1029
    .line 1030
    const/16 v1, 0x1e

    .line 1031
    .line 1032
    iget-wide v2, v0, LV0/h;->g:J

    .line 1033
    .line 1034
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1035
    .line 1036
    .line 1037
    const/16 v1, 0x1f

    .line 1038
    .line 1039
    iget-wide v2, v0, LV0/h;->h:J

    .line 1040
    .line 1041
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1042
    .line 1043
    .line 1044
    iget-object v0, v0, LV0/h;->i:Ljava/util/Set;

    .line 1045
    .line 1046
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->e0(Ljava/util/Set;)[B

    .line 1047
    .line 1048
    .line 1049
    move-result-object v0

    .line 1050
    const/16 v1, 0x20

    .line 1051
    .line 1052
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 1053
    .line 1054
    .line 1055
    const/16 v0, 0x21

    .line 1056
    .line 1057
    iget-object p2, p2, Landroidx/work/impl/model/k;->a:Ljava/lang/String;

    .line 1058
    .line 1059
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1060
    .line 1061
    .line 1062
    return-void

    .line 1063
    :pswitch_5
    check-cast p2, LUd/a;

    .line 1064
    .line 1065
    iget v0, p2, LUd/a;->a:I

    .line 1066
    .line 1067
    int-to-long v0, v0

    .line 1068
    const/4 v2, 0x1

    .line 1069
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1070
    .line 1071
    .line 1072
    iget-object v0, p2, LUd/a;->b:Ljava/lang/String;

    .line 1073
    .line 1074
    const/4 v1, 0x2

    .line 1075
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1076
    .line 1077
    .line 1078
    iget-object v0, p2, LUd/a;->c:Ljava/lang/String;

    .line 1079
    .line 1080
    const/4 v1, 0x3

    .line 1081
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1082
    .line 1083
    .line 1084
    iget-wide v0, p2, LUd/a;->d:J

    .line 1085
    .line 1086
    const/4 v2, 0x4

    .line 1087
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1088
    .line 1089
    .line 1090
    iget p2, p2, LUd/a;->a:I

    .line 1091
    .line 1092
    int-to-long v0, p2

    .line 1093
    const/4 p2, 0x5

    .line 1094
    invoke-interface {p1, p2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1095
    .line 1096
    .line 1097
    return-void

    .line 1098
    :pswitch_6
    check-cast p2, LUd/a;

    .line 1099
    .line 1100
    iget p2, p2, LUd/a;->a:I

    .line 1101
    .line 1102
    int-to-long v0, p2

    .line 1103
    const/4 p2, 0x1

    .line 1104
    invoke-interface {p1, p2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1105
    .line 1106
    .line 1107
    return-void

    .line 1108
    nop

    .line 1109
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
