.class public final LTd/a;
.super Landroidx/room/o;
.source "SourceFile"


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Landroidx/room/G;I)V
    .locals 0

    .line 1
    iput p2, p0, LTd/a;->d:I

    invoke-direct {p0, p1}, Landroidx/room/P;-><init>(Landroidx/room/G;)V

    return-void
.end method

.method public constructor <init>(Landroidx/room/G;IZ)V
    .locals 0

    iput p2, p0, LTd/a;->d:I

    .line 2
    const-string p2, "database"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0, p1}, Landroidx/room/P;-><init>(Landroidx/room/G;)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 1

    .line 1
    iget v0, p0, LTd/a;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "INSERT OR ABORT INTO `events` (`id`,`data`,`create_time`,`type`) VALUES (nullif(?, 0),?,?,?)"

    .line 7
    .line 8
    return-object v0

    .line 9
    :pswitch_0
    const-string v0, "INSERT OR REPLACE INTO `request_contacts` (`contact_member_id`,`alias`,`full_name`,`is_favourite`,`is_friend`,`phone`,`photo_path`,`request_source`,`create_time`,`update_time`,`expire_time`,`own_member_id`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"

    .line 10
    .line 11
    return-object v0

    .line 12
    :pswitch_1
    const-string v0, "INSERT OR REPLACE INTO `ad_detail` (`ad_id`,`application_id`,`ad_slot_id`,`image_url`,`image_url_dark`,`secondary_image_url`,`secondary_image_url_dark`,`jump_type`,`relative_url`,`image_dimention`,`country_code`,`valid_start_time`,`valid_end_time`,`show_times`,`show_times_condition`,`click_frequency`,`max_close_count`,`show_dates`,`multiple_imageUrl`,`text_content`,`text_font_size`,`text_font_color`,`text_font_color_dark`,`text_scroll_speed`,`background_color`,`background_color_dark`,`ad_type`,`native_ad_title`,`native_ad_content`,`native_ad_photo`,`show_close_button`,`has_show_times`,`show_date`,`click_date`,`close_time`,`close_count`,`create_time`,`update_time`,`current_enable`,`jump_params`,`default_img_res`,`text_icon_url`,`text_icon_url_dark`,`alpha`,`display_order`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_2
    const-string v0, "INSERT OR IGNORE INTO `WorkTag` (`tag`,`work_spec_id`) VALUES (?,?)"

    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_3
    const-string v0, "INSERT OR IGNORE INTO `WorkSpec` (`id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`last_enqueue_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`out_of_quota_policy`,`period_count`,`generation`,`next_schedule_time_override`,`next_schedule_time_override_generation`,`stop_reason`,`trace_tag`,`required_network_type`,`required_network_request`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_4
    const-string v0, "INSERT OR REPLACE INTO `WorkProgress` (`work_spec_id`,`progress`) VALUES (?,?)"

    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_5
    const-string v0, "INSERT OR IGNORE INTO `WorkName` (`name`,`work_spec_id`) VALUES (?,?)"

    .line 25
    .line 26
    return-object v0

    .line 27
    :pswitch_6
    const-string v0, "INSERT OR REPLACE INTO `SystemIdInfo` (`work_spec_id`,`generation`,`system_id`) VALUES (?,?,?)"

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_7
    const-string v0, "INSERT OR REPLACE INTO `Preference` (`key`,`long_value`) VALUES (?,?)"

    .line 31
    .line 32
    return-object v0

    .line 33
    :pswitch_8
    const-string v0, "INSERT OR IGNORE INTO `Dependency` (`work_spec_id`,`prerequisite_id`) VALUES (?,?)"

    .line 34
    .line 35
    return-object v0

    .line 36
    :pswitch_9
    const-string v0, "INSERT OR ABORT INTO `biller_search_record` (`recordId`,`memberId`,`searchText`,`updateTime`) VALUES (nullif(?, 0),?,?,?)"

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final d(Landroidx/sqlite/db/SupportSQLiteStatement;Ljava/lang/Object;)V
    .locals 6

    .line 1
    iget v0, p0, LTd/a;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p2, Lcom/transsnet/analysis/data/local/entity/EventsEntity;

    .line 7
    .line 8
    iget-wide v0, p2, Lcom/transsnet/analysis/data/local/entity/EventsEntity;->id:J

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p2, Lcom/transsnet/analysis/data/local/entity/EventsEntity;->data:Ljava/lang/String;

    .line 15
    .line 16
    const/4 v1, 0x2

    .line 17
    if-nez v0, :cond_0

    .line 18
    .line 19
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 20
    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :goto_0
    const/4 v0, 0x3

    .line 27
    iget-wide v1, p2, Lcom/transsnet/analysis/data/local/entity/EventsEntity;->create_time:J

    .line 28
    .line 29
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 30
    .line 31
    .line 32
    iget p2, p2, Lcom/transsnet/analysis/data/local/entity/EventsEntity;->type:I

    .line 33
    .line 34
    int-to-long v0, p2

    .line 35
    const/4 p2, 0x4

    .line 36
    invoke-interface {p1, p2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :pswitch_0
    check-cast p2, Lcom/transsnet/palmpay/core/db/entity/RequestContact;

    .line 41
    .line 42
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getContactsMemberId()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    const/4 v1, 0x1

    .line 47
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getAlias()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    const/4 v1, 0x2

    .line 55
    if-nez v0, :cond_1

    .line 56
    .line 57
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 58
    .line 59
    .line 60
    goto :goto_1

    .line 61
    :cond_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getAlias()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 66
    .line 67
    .line 68
    :goto_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getFullName()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    const/4 v1, 0x3

    .line 73
    if-nez v0, :cond_2

    .line 74
    .line 75
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 76
    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_2
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getFullName()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 84
    .line 85
    .line 86
    :goto_2
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getIsFavourite()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    const/4 v1, 0x4

    .line 91
    if-nez v0, :cond_3

    .line 92
    .line 93
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 94
    .line 95
    .line 96
    goto :goto_3

    .line 97
    :cond_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getIsFavourite()Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 102
    .line 103
    .line 104
    :goto_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->isFriend()Z

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    const/4 v1, 0x5

    .line 109
    int-to-long v2, v0

    .line 110
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getPhone()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    const/4 v1, 0x6

    .line 118
    if-nez v0, :cond_4

    .line 119
    .line 120
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 121
    .line 122
    .line 123
    goto :goto_4

    .line 124
    :cond_4
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getPhone()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 129
    .line 130
    .line 131
    :goto_4
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getPhotoPath()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    const/4 v1, 0x7

    .line 136
    if-nez v0, :cond_5

    .line 137
    .line 138
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 139
    .line 140
    .line 141
    goto :goto_5

    .line 142
    :cond_5
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getPhotoPath()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 147
    .line 148
    .line 149
    :goto_5
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getRequestSource()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    const/16 v1, 0x8

    .line 154
    .line 155
    if-nez v0, :cond_6

    .line 156
    .line 157
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 158
    .line 159
    .line 160
    goto :goto_6

    .line 161
    :cond_6
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getRequestSource()Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 166
    .line 167
    .line 168
    :goto_6
    const/16 v0, 0x9

    .line 169
    .line 170
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getCreateTime()J

    .line 171
    .line 172
    .line 173
    move-result-wide v1

    .line 174
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 175
    .line 176
    .line 177
    const/16 v0, 0xa

    .line 178
    .line 179
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getUpdateTime()J

    .line 180
    .line 181
    .line 182
    move-result-wide v1

    .line 183
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 184
    .line 185
    .line 186
    const/16 v0, 0xb

    .line 187
    .line 188
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getExpireTime()J

    .line 189
    .line 190
    .line 191
    move-result-wide v1

    .line 192
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 193
    .line 194
    .line 195
    const/16 v0, 0xc

    .line 196
    .line 197
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/db/entity/RequestContact;->getMemberId()Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object p2

    .line 201
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 202
    .line 203
    .line 204
    return-void

    .line 205
    :pswitch_1
    check-cast p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;

    .line 206
    .line 207
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->adId:Ljava/lang/String;

    .line 208
    .line 209
    const/4 v1, 0x1

    .line 210
    if-nez v0, :cond_7

    .line 211
    .line 212
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 213
    .line 214
    .line 215
    goto :goto_7

    .line 216
    :cond_7
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 217
    .line 218
    .line 219
    :goto_7
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->applicationId:Ljava/lang/String;

    .line 220
    .line 221
    const/4 v1, 0x2

    .line 222
    if-nez v0, :cond_8

    .line 223
    .line 224
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 225
    .line 226
    .line 227
    goto :goto_8

    .line 228
    :cond_8
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 229
    .line 230
    .line 231
    :goto_8
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->adSlotId:Ljava/lang/String;

    .line 232
    .line 233
    const/4 v1, 0x3

    .line 234
    if-nez v0, :cond_9

    .line 235
    .line 236
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 237
    .line 238
    .line 239
    goto :goto_9

    .line 240
    :cond_9
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 241
    .line 242
    .line 243
    :goto_9
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->imageUrl:Ljava/lang/String;

    .line 244
    .line 245
    const/4 v1, 0x4

    .line 246
    if-nez v0, :cond_a

    .line 247
    .line 248
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 249
    .line 250
    .line 251
    goto :goto_a

    .line 252
    :cond_a
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 253
    .line 254
    .line 255
    :goto_a
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->imageUrlDark:Ljava/lang/String;

    .line 256
    .line 257
    const/4 v1, 0x5

    .line 258
    if-nez v0, :cond_b

    .line 259
    .line 260
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 261
    .line 262
    .line 263
    goto :goto_b

    .line 264
    :cond_b
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 265
    .line 266
    .line 267
    :goto_b
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->h5ImageUrl:Ljava/lang/String;

    .line 268
    .line 269
    const/4 v1, 0x6

    .line 270
    if-nez v0, :cond_c

    .line 271
    .line 272
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 273
    .line 274
    .line 275
    goto :goto_c

    .line 276
    :cond_c
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 277
    .line 278
    .line 279
    :goto_c
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->h5ImageUrlDark:Ljava/lang/String;

    .line 280
    .line 281
    const/4 v1, 0x7

    .line 282
    if-nez v0, :cond_d

    .line 283
    .line 284
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 285
    .line 286
    .line 287
    goto :goto_d

    .line 288
    :cond_d
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 289
    .line 290
    .line 291
    :goto_d
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->jumpType:Ljava/lang/String;

    .line 292
    .line 293
    const/16 v1, 0x8

    .line 294
    .line 295
    if-nez v0, :cond_e

    .line 296
    .line 297
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 298
    .line 299
    .line 300
    goto :goto_e

    .line 301
    :cond_e
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 302
    .line 303
    .line 304
    :goto_e
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->relativeUrl:Ljava/lang/String;

    .line 305
    .line 306
    const/16 v1, 0x9

    .line 307
    .line 308
    if-nez v0, :cond_f

    .line 309
    .line 310
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 311
    .line 312
    .line 313
    goto :goto_f

    .line 314
    :cond_f
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 315
    .line 316
    .line 317
    :goto_f
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->imageDimention:Ljava/lang/String;

    .line 318
    .line 319
    const/16 v1, 0xa

    .line 320
    .line 321
    if-nez v0, :cond_10

    .line 322
    .line 323
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 324
    .line 325
    .line 326
    goto :goto_10

    .line 327
    :cond_10
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 328
    .line 329
    .line 330
    :goto_10
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->countryCode:Ljava/lang/String;

    .line 331
    .line 332
    const/16 v1, 0xb

    .line 333
    .line 334
    if-nez v0, :cond_11

    .line 335
    .line 336
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 337
    .line 338
    .line 339
    goto :goto_11

    .line 340
    :cond_11
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 341
    .line 342
    .line 343
    :goto_11
    const/16 v0, 0xc

    .line 344
    .line 345
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->validStartTime:J

    .line 346
    .line 347
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 348
    .line 349
    .line 350
    const/16 v0, 0xd

    .line 351
    .line 352
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->validEndTime:J

    .line 353
    .line 354
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 355
    .line 356
    .line 357
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showTimes:I

    .line 358
    .line 359
    int-to-long v0, v0

    .line 360
    const/16 v2, 0xe

    .line 361
    .line 362
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 363
    .line 364
    .line 365
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showTimesCondition:Ljava/lang/Integer;

    .line 366
    .line 367
    const/16 v1, 0xf

    .line 368
    .line 369
    if-nez v0, :cond_12

    .line 370
    .line 371
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 372
    .line 373
    .line 374
    goto :goto_12

    .line 375
    :cond_12
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 376
    .line 377
    .line 378
    move-result v0

    .line 379
    int-to-long v2, v0

    .line 380
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 381
    .line 382
    .line 383
    :goto_12
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->clickFrequency:Ljava/lang/Integer;

    .line 384
    .line 385
    const/16 v1, 0x10

    .line 386
    .line 387
    if-nez v0, :cond_13

    .line 388
    .line 389
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 390
    .line 391
    .line 392
    goto :goto_13

    .line 393
    :cond_13
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 394
    .line 395
    .line 396
    move-result v0

    .line 397
    int-to-long v2, v0

    .line 398
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 399
    .line 400
    .line 401
    :goto_13
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->closeControl:I

    .line 402
    .line 403
    int-to-long v0, v0

    .line 404
    const/16 v2, 0x11

    .line 405
    .line 406
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 407
    .line 408
    .line 409
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showDates:Ljava/lang/String;

    .line 410
    .line 411
    const/16 v1, 0x12

    .line 412
    .line 413
    if-nez v0, :cond_14

    .line 414
    .line 415
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 416
    .line 417
    .line 418
    goto :goto_14

    .line 419
    :cond_14
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 420
    .line 421
    .line 422
    :goto_14
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->multipleImageUrl:Ljava/lang/String;

    .line 423
    .line 424
    const/16 v1, 0x13

    .line 425
    .line 426
    if-nez v0, :cond_15

    .line 427
    .line 428
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 429
    .line 430
    .line 431
    goto :goto_15

    .line 432
    :cond_15
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 433
    .line 434
    .line 435
    :goto_15
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textContent:Ljava/lang/String;

    .line 436
    .line 437
    const/16 v1, 0x14

    .line 438
    .line 439
    if-nez v0, :cond_16

    .line 440
    .line 441
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 442
    .line 443
    .line 444
    goto :goto_16

    .line 445
    :cond_16
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 446
    .line 447
    .line 448
    :goto_16
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textFontSize:Ljava/lang/String;

    .line 449
    .line 450
    const/16 v1, 0x15

    .line 451
    .line 452
    if-nez v0, :cond_17

    .line 453
    .line 454
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 455
    .line 456
    .line 457
    goto :goto_17

    .line 458
    :cond_17
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 459
    .line 460
    .line 461
    :goto_17
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textFontColor:Ljava/lang/String;

    .line 462
    .line 463
    const/16 v1, 0x16

    .line 464
    .line 465
    if-nez v0, :cond_18

    .line 466
    .line 467
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 468
    .line 469
    .line 470
    goto :goto_18

    .line 471
    :cond_18
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 472
    .line 473
    .line 474
    :goto_18
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textFontColorDark:Ljava/lang/String;

    .line 475
    .line 476
    const/16 v1, 0x17

    .line 477
    .line 478
    if-nez v0, :cond_19

    .line 479
    .line 480
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 481
    .line 482
    .line 483
    goto :goto_19

    .line 484
    :cond_19
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 485
    .line 486
    .line 487
    :goto_19
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textScrollSpeed:Ljava/lang/String;

    .line 488
    .line 489
    const/16 v1, 0x18

    .line 490
    .line 491
    if-nez v0, :cond_1a

    .line 492
    .line 493
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 494
    .line 495
    .line 496
    goto :goto_1a

    .line 497
    :cond_1a
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 498
    .line 499
    .line 500
    :goto_1a
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->backgroundColor:Ljava/lang/String;

    .line 501
    .line 502
    const/16 v1, 0x19

    .line 503
    .line 504
    if-nez v0, :cond_1b

    .line 505
    .line 506
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 507
    .line 508
    .line 509
    goto :goto_1b

    .line 510
    :cond_1b
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 511
    .line 512
    .line 513
    :goto_1b
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->backgroundColorDark:Ljava/lang/String;

    .line 514
    .line 515
    const/16 v1, 0x1a

    .line 516
    .line 517
    if-nez v0, :cond_1c

    .line 518
    .line 519
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 520
    .line 521
    .line 522
    goto :goto_1c

    .line 523
    :cond_1c
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 524
    .line 525
    .line 526
    :goto_1c
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->adType:I

    .line 527
    .line 528
    int-to-long v0, v0

    .line 529
    const/16 v2, 0x1b

    .line 530
    .line 531
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 532
    .line 533
    .line 534
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->nativeAdTitle:Ljava/lang/String;

    .line 535
    .line 536
    const/16 v1, 0x1c

    .line 537
    .line 538
    if-nez v0, :cond_1d

    .line 539
    .line 540
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 541
    .line 542
    .line 543
    goto :goto_1d

    .line 544
    :cond_1d
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 545
    .line 546
    .line 547
    :goto_1d
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->nativeAdContent:Ljava/lang/String;

    .line 548
    .line 549
    const/16 v1, 0x1d

    .line 550
    .line 551
    if-nez v0, :cond_1e

    .line 552
    .line 553
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 554
    .line 555
    .line 556
    goto :goto_1e

    .line 557
    :cond_1e
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 558
    .line 559
    .line 560
    :goto_1e
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->nativeAdPhoto:Ljava/lang/String;

    .line 561
    .line 562
    const/16 v1, 0x1e

    .line 563
    .line 564
    if-nez v0, :cond_1f

    .line 565
    .line 566
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 567
    .line 568
    .line 569
    goto :goto_1f

    .line 570
    :cond_1f
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 571
    .line 572
    .line 573
    :goto_1f
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showCloseButton:I

    .line 574
    .line 575
    int-to-long v0, v0

    .line 576
    const/16 v2, 0x1f

    .line 577
    .line 578
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 579
    .line 580
    .line 581
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->hasShowTimes:I

    .line 582
    .line 583
    int-to-long v0, v0

    .line 584
    const/16 v2, 0x20

    .line 585
    .line 586
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 587
    .line 588
    .line 589
    const/16 v0, 0x21

    .line 590
    .line 591
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->showDate:J

    .line 592
    .line 593
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 594
    .line 595
    .line 596
    const/16 v0, 0x22

    .line 597
    .line 598
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->clickDate:J

    .line 599
    .line 600
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 601
    .line 602
    .line 603
    const/16 v0, 0x23

    .line 604
    .line 605
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->closeTime:J

    .line 606
    .line 607
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 608
    .line 609
    .line 610
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->closeCount:I

    .line 611
    .line 612
    int-to-long v0, v0

    .line 613
    const/16 v2, 0x24

    .line 614
    .line 615
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 616
    .line 617
    .line 618
    const/16 v0, 0x25

    .line 619
    .line 620
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->createTime:J

    .line 621
    .line 622
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 623
    .line 624
    .line 625
    const/16 v0, 0x26

    .line 626
    .line 627
    iget-wide v1, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->updateTime:J

    .line 628
    .line 629
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 630
    .line 631
    .line 632
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->curEnable:I

    .line 633
    .line 634
    int-to-long v0, v0

    .line 635
    const/16 v2, 0x27

    .line 636
    .line 637
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 638
    .line 639
    .line 640
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->jumpParams:Ljava/lang/String;

    .line 641
    .line 642
    const/16 v1, 0x28

    .line 643
    .line 644
    if-nez v0, :cond_20

    .line 645
    .line 646
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 647
    .line 648
    .line 649
    goto :goto_20

    .line 650
    :cond_20
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 651
    .line 652
    .line 653
    :goto_20
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->defaultImgRes:I

    .line 654
    .line 655
    int-to-long v0, v0

    .line 656
    const/16 v2, 0x29

    .line 657
    .line 658
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 659
    .line 660
    .line 661
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textIconUrl:Ljava/lang/String;

    .line 662
    .line 663
    const/16 v1, 0x2a

    .line 664
    .line 665
    if-nez v0, :cond_21

    .line 666
    .line 667
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 668
    .line 669
    .line 670
    goto :goto_21

    .line 671
    :cond_21
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 672
    .line 673
    .line 674
    :goto_21
    iget-object v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->textIconUrlDark:Ljava/lang/String;

    .line 675
    .line 676
    const/16 v1, 0x2b

    .line 677
    .line 678
    if-nez v0, :cond_22

    .line 679
    .line 680
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 681
    .line 682
    .line 683
    goto :goto_22

    .line 684
    :cond_22
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 685
    .line 686
    .line 687
    :goto_22
    iget v0, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->alpha:I

    .line 688
    .line 689
    int-to-long v0, v0

    .line 690
    const/16 v2, 0x2c

    .line 691
    .line 692
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 693
    .line 694
    .line 695
    iget p2, p2, Lcom/transsnet/adsdk/data/local/entity/AdEntity;->displayOrder:I

    .line 696
    .line 697
    int-to-long v0, p2

    .line 698
    const/16 p2, 0x2d

    .line 699
    .line 700
    invoke-interface {p1, p2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 701
    .line 702
    .line 703
    return-void

    .line 704
    :pswitch_2
    check-cast p2, Landroidx/work/impl/model/o;

    .line 705
    .line 706
    iget-object v0, p2, Landroidx/work/impl/model/o;->a:Ljava/lang/String;

    .line 707
    .line 708
    const/4 v1, 0x1

    .line 709
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 710
    .line 711
    .line 712
    const/4 v0, 0x2

    .line 713
    iget-object p2, p2, Landroidx/work/impl/model/o;->b:Ljava/lang/String;

    .line 714
    .line 715
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 716
    .line 717
    .line 718
    return-void

    .line 719
    :pswitch_3
    check-cast p2, Landroidx/work/impl/model/k;

    .line 720
    .line 721
    iget-object v0, p2, Landroidx/work/impl/model/k;->a:Ljava/lang/String;

    .line 722
    .line 723
    const/4 v1, 0x1

    .line 724
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 725
    .line 726
    .line 727
    iget-object v0, p2, Landroidx/work/impl/model/k;->b:LV0/Q;

    .line 728
    .line 729
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->n0(LV0/Q;)I

    .line 730
    .line 731
    .line 732
    move-result v0

    .line 733
    const/4 v2, 0x2

    .line 734
    int-to-long v3, v0

    .line 735
    invoke-interface {p1, v2, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 736
    .line 737
    .line 738
    const/4 v0, 0x3

    .line 739
    iget-object v2, p2, Landroidx/work/impl/model/k;->c:Ljava/lang/String;

    .line 740
    .line 741
    invoke-interface {p1, v0, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 742
    .line 743
    .line 744
    const/4 v0, 0x4

    .line 745
    iget-object v2, p2, Landroidx/work/impl/model/k;->d:Ljava/lang/String;

    .line 746
    .line 747
    invoke-interface {p1, v0, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 748
    .line 749
    .line 750
    iget-object v0, p2, Landroidx/work/impl/model/k;->e:LV0/n;

    .line 751
    .line 752
    sget-object v2, LV0/n;->b:LV0/l;

    .line 753
    .line 754
    invoke-virtual {v2, v0}, LV0/l;->toByteArrayInternalV1(LV0/n;)[B

    .line 755
    .line 756
    .line 757
    move-result-object v0

    .line 758
    const/4 v3, 0x5

    .line 759
    invoke-interface {p1, v3, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 760
    .line 761
    .line 762
    iget-object v0, p2, Landroidx/work/impl/model/k;->f:LV0/n;

    .line 763
    .line 764
    invoke-virtual {v2, v0}, LV0/l;->toByteArrayInternalV1(LV0/n;)[B

    .line 765
    .line 766
    .line 767
    move-result-object v0

    .line 768
    const/4 v2, 0x6

    .line 769
    invoke-interface {p1, v2, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 770
    .line 771
    .line 772
    const/4 v0, 0x7

    .line 773
    iget-wide v2, p2, Landroidx/work/impl/model/k;->g:J

    .line 774
    .line 775
    invoke-interface {p1, v0, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 776
    .line 777
    .line 778
    const/16 v0, 0x8

    .line 779
    .line 780
    iget-wide v2, p2, Landroidx/work/impl/model/k;->h:J

    .line 781
    .line 782
    invoke-interface {p1, v0, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 783
    .line 784
    .line 785
    const/16 v0, 0x9

    .line 786
    .line 787
    iget-wide v2, p2, Landroidx/work/impl/model/k;->i:J

    .line 788
    .line 789
    invoke-interface {p1, v0, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 790
    .line 791
    .line 792
    iget v0, p2, Landroidx/work/impl/model/k;->k:I

    .line 793
    .line 794
    int-to-long v2, v0

    .line 795
    const/16 v0, 0xa

    .line 796
    .line 797
    invoke-interface {p1, v0, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 798
    .line 799
    .line 800
    iget-object v0, p2, Landroidx/work/impl/model/k;->l:LV0/a;

    .line 801
    .line 802
    const-string v2, "backoffPolicy"

    .line 803
    .line 804
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 805
    .line 806
    .line 807
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 808
    .line 809
    .line 810
    move-result v0

    .line 811
    const/4 v2, 0x0

    .line 812
    if-eqz v0, :cond_24

    .line 813
    .line 814
    if-ne v0, v1, :cond_23

    .line 815
    .line 816
    move v0, v1

    .line 817
    goto :goto_23

    .line 818
    :cond_23
    new-instance p1, Lxf/l;

    .line 819
    .line 820
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 821
    .line 822
    .line 823
    throw p1

    .line 824
    :cond_24
    move v0, v2

    .line 825
    :goto_23
    const/16 v3, 0xb

    .line 826
    .line 827
    int-to-long v4, v0

    .line 828
    invoke-interface {p1, v3, v4, v5}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 829
    .line 830
    .line 831
    const/16 v0, 0xc

    .line 832
    .line 833
    iget-wide v3, p2, Landroidx/work/impl/model/k;->m:J

    .line 834
    .line 835
    invoke-interface {p1, v0, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 836
    .line 837
    .line 838
    const/16 v0, 0xd

    .line 839
    .line 840
    iget-wide v3, p2, Landroidx/work/impl/model/k;->n:J

    .line 841
    .line 842
    invoke-interface {p1, v0, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 843
    .line 844
    .line 845
    const/16 v0, 0xe

    .line 846
    .line 847
    iget-wide v3, p2, Landroidx/work/impl/model/k;->o:J

    .line 848
    .line 849
    invoke-interface {p1, v0, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 850
    .line 851
    .line 852
    const/16 v0, 0xf

    .line 853
    .line 854
    iget-wide v3, p2, Landroidx/work/impl/model/k;->p:J

    .line 855
    .line 856
    invoke-interface {p1, v0, v3, v4}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 857
    .line 858
    .line 859
    iget-boolean v0, p2, Landroidx/work/impl/model/k;->q:Z

    .line 860
    .line 861
    const/16 v3, 0x10

    .line 862
    .line 863
    int-to-long v4, v0

    .line 864
    invoke-interface {p1, v3, v4, v5}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 865
    .line 866
    .line 867
    iget-object v0, p2, Landroidx/work/impl/model/k;->r:LV0/K;

    .line 868
    .line 869
    const-string v3, "policy"

    .line 870
    .line 871
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 872
    .line 873
    .line 874
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 875
    .line 876
    .line 877
    move-result v0

    .line 878
    if-eqz v0, :cond_26

    .line 879
    .line 880
    if-ne v0, v1, :cond_25

    .line 881
    .line 882
    goto :goto_24

    .line 883
    :cond_25
    new-instance p1, Lxf/l;

    .line 884
    .line 885
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 886
    .line 887
    .line 888
    throw p1

    .line 889
    :cond_26
    move v1, v2

    .line 890
    :goto_24
    const/16 v0, 0x11

    .line 891
    .line 892
    int-to-long v1, v1

    .line 893
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 894
    .line 895
    .line 896
    iget v0, p2, Landroidx/work/impl/model/k;->s:I

    .line 897
    .line 898
    int-to-long v0, v0

    .line 899
    const/16 v2, 0x12

    .line 900
    .line 901
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 902
    .line 903
    .line 904
    iget v0, p2, Landroidx/work/impl/model/k;->t:I

    .line 905
    .line 906
    int-to-long v0, v0

    .line 907
    const/16 v2, 0x13

    .line 908
    .line 909
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 910
    .line 911
    .line 912
    iget-wide v0, p2, Landroidx/work/impl/model/k;->u:J

    .line 913
    .line 914
    const/16 v2, 0x14

    .line 915
    .line 916
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 917
    .line 918
    .line 919
    iget v0, p2, Landroidx/work/impl/model/k;->v:I

    .line 920
    .line 921
    int-to-long v0, v0

    .line 922
    const/16 v2, 0x15

    .line 923
    .line 924
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 925
    .line 926
    .line 927
    iget v0, p2, Landroidx/work/impl/model/k;->w:I

    .line 928
    .line 929
    int-to-long v0, v0

    .line 930
    const/16 v2, 0x16

    .line 931
    .line 932
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 933
    .line 934
    .line 935
    iget-object v0, p2, Landroidx/work/impl/model/k;->x:Ljava/lang/String;

    .line 936
    .line 937
    const/16 v1, 0x17

    .line 938
    .line 939
    if-nez v0, :cond_27

    .line 940
    .line 941
    invoke-interface {p1, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindNull(I)V

    .line 942
    .line 943
    .line 944
    goto :goto_25

    .line 945
    :cond_27
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 946
    .line 947
    .line 948
    :goto_25
    iget-object p2, p2, Landroidx/work/impl/model/k;->j:LV0/h;

    .line 949
    .line 950
    iget-object v0, p2, LV0/h;->a:LV0/D;

    .line 951
    .line 952
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->U(LV0/D;)I

    .line 953
    .line 954
    .line 955
    move-result v0

    .line 956
    const/16 v1, 0x18

    .line 957
    .line 958
    int-to-long v2, v0

    .line 959
    invoke-interface {p1, v1, v2, v3}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 960
    .line 961
    .line 962
    iget-object v0, p2, LV0/h;->b:Landroidx/work/impl/utils/g;

    .line 963
    .line 964
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->x(Landroidx/work/impl/utils/g;)[B

    .line 965
    .line 966
    .line 967
    move-result-object v0

    .line 968
    const/16 v1, 0x19

    .line 969
    .line 970
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 971
    .line 972
    .line 973
    iget-boolean v0, p2, LV0/h;->c:Z

    .line 974
    .line 975
    int-to-long v0, v0

    .line 976
    const/16 v2, 0x1a

    .line 977
    .line 978
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 979
    .line 980
    .line 981
    iget-boolean v0, p2, LV0/h;->d:Z

    .line 982
    .line 983
    int-to-long v0, v0

    .line 984
    const/16 v2, 0x1b

    .line 985
    .line 986
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 987
    .line 988
    .line 989
    iget-boolean v0, p2, LV0/h;->e:Z

    .line 990
    .line 991
    int-to-long v0, v0

    .line 992
    const/16 v2, 0x1c

    .line 993
    .line 994
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 995
    .line 996
    .line 997
    iget-boolean v0, p2, LV0/h;->f:Z

    .line 998
    .line 999
    int-to-long v0, v0

    .line 1000
    const/16 v2, 0x1d

    .line 1001
    .line 1002
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1003
    .line 1004
    .line 1005
    const/16 v0, 0x1e

    .line 1006
    .line 1007
    iget-wide v1, p2, LV0/h;->g:J

    .line 1008
    .line 1009
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1010
    .line 1011
    .line 1012
    const/16 v0, 0x1f

    .line 1013
    .line 1014
    iget-wide v1, p2, LV0/h;->h:J

    .line 1015
    .line 1016
    invoke-interface {p1, v0, v1, v2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1017
    .line 1018
    .line 1019
    iget-object p2, p2, LV0/h;->i:Ljava/util/Set;

    .line 1020
    .line 1021
    invoke-static {p2}, Lorg/chromium/support_lib_boundary/util/b;->e0(Ljava/util/Set;)[B

    .line 1022
    .line 1023
    .line 1024
    move-result-object p2

    .line 1025
    const/16 v0, 0x20

    .line 1026
    .line 1027
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 1028
    .line 1029
    .line 1030
    return-void

    .line 1031
    :pswitch_4
    check-cast p2, Landroidx/work/impl/model/g;

    .line 1032
    .line 1033
    const/4 v0, 0x0

    .line 1034
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1035
    .line 1036
    .line 1037
    const/4 p2, 0x1

    .line 1038
    invoke-interface {p1, p2, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1039
    .line 1040
    .line 1041
    sget-object p2, LV0/n;->b:LV0/l;

    .line 1042
    .line 1043
    const/4 v0, 0x0

    .line 1044
    invoke-virtual {p2, v0}, LV0/l;->toByteArrayInternalV1(LV0/n;)[B

    .line 1045
    .line 1046
    .line 1047
    move-result-object p2

    .line 1048
    const/4 v0, 0x2

    .line 1049
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindBlob(I[B)V

    .line 1050
    .line 1051
    .line 1052
    return-void

    .line 1053
    :pswitch_5
    check-cast p2, Landroidx/work/impl/model/f;

    .line 1054
    .line 1055
    iget-object v0, p2, Landroidx/work/impl/model/f;->a:Ljava/lang/String;

    .line 1056
    .line 1057
    const/4 v1, 0x1

    .line 1058
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1059
    .line 1060
    .line 1061
    const/4 v0, 0x2

    .line 1062
    iget-object p2, p2, Landroidx/work/impl/model/f;->b:Ljava/lang/String;

    .line 1063
    .line 1064
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1065
    .line 1066
    .line 1067
    return-void

    .line 1068
    :pswitch_6
    check-cast p2, Landroidx/work/impl/model/d;

    .line 1069
    .line 1070
    iget-object v0, p2, Landroidx/work/impl/model/d;->a:Ljava/lang/String;

    .line 1071
    .line 1072
    const/4 v1, 0x1

    .line 1073
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1074
    .line 1075
    .line 1076
    iget v0, p2, Landroidx/work/impl/model/d;->b:I

    .line 1077
    .line 1078
    int-to-long v0, v0

    .line 1079
    const/4 v2, 0x2

    .line 1080
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1081
    .line 1082
    .line 1083
    iget p2, p2, Landroidx/work/impl/model/d;->c:I

    .line 1084
    .line 1085
    int-to-long v0, p2

    .line 1086
    const/4 p2, 0x3

    .line 1087
    invoke-interface {p1, p2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1088
    .line 1089
    .line 1090
    return-void

    .line 1091
    :pswitch_7
    check-cast p2, Landroidx/work/impl/model/c;

    .line 1092
    .line 1093
    iget-object v0, p2, Landroidx/work/impl/model/c;->a:Ljava/lang/String;

    .line 1094
    .line 1095
    const/4 v1, 0x1

    .line 1096
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1097
    .line 1098
    .line 1099
    iget-object p2, p2, Landroidx/work/impl/model/c;->b:Ljava/lang/Long;

    .line 1100
    .line 1101
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 1102
    .line 1103
    .line 1104
    move-result-wide v0

    .line 1105
    const/4 p2, 0x2

    .line 1106
    invoke-interface {p1, p2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1107
    .line 1108
    .line 1109
    return-void

    .line 1110
    :pswitch_8
    check-cast p2, Landroidx/work/impl/model/a;

    .line 1111
    .line 1112
    iget-object v0, p2, Landroidx/work/impl/model/a;->a:Ljava/lang/String;

    .line 1113
    .line 1114
    const/4 v1, 0x1

    .line 1115
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1116
    .line 1117
    .line 1118
    const/4 v0, 0x2

    .line 1119
    iget-object p2, p2, Landroidx/work/impl/model/a;->b:Ljava/lang/String;

    .line 1120
    .line 1121
    invoke-interface {p1, v0, p2}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1122
    .line 1123
    .line 1124
    return-void

    .line 1125
    :pswitch_9
    check-cast p2, LUd/a;

    .line 1126
    .line 1127
    iget v0, p2, LUd/a;->a:I

    .line 1128
    .line 1129
    int-to-long v0, v0

    .line 1130
    const/4 v2, 0x1

    .line 1131
    invoke-interface {p1, v2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1132
    .line 1133
    .line 1134
    iget-object v0, p2, LUd/a;->b:Ljava/lang/String;

    .line 1135
    .line 1136
    const/4 v1, 0x2

    .line 1137
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1138
    .line 1139
    .line 1140
    iget-object v0, p2, LUd/a;->c:Ljava/lang/String;

    .line 1141
    .line 1142
    const/4 v1, 0x3

    .line 1143
    invoke-interface {p1, v1, v0}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindString(ILjava/lang/String;)V

    .line 1144
    .line 1145
    .line 1146
    iget-wide v0, p2, LUd/a;->d:J

    .line 1147
    .line 1148
    const/4 p2, 0x4

    .line 1149
    invoke-interface {p1, p2, v0, v1}, Landroidx/sqlite/db/SupportSQLiteProgram;->bindLong(IJ)V

    .line 1150
    .line 1151
    .line 1152
    return-void

    .line 1153
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
