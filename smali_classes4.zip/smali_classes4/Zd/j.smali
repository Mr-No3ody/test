.class public final LZd/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/base/l;

.field public final synthetic c:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/base/l;Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;I)V
    .locals 0

    .line 1
    iput p3, p0, LZd/j;->a:I

    iput-object p1, p0, LZd/j;->b:Lcom/transsnet/palmpay/core/base/l;

    iput-object p2, p0, LZd/j;->c:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, LZd/j;->c:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 2
    .line 3
    iget-object v1, p0, LZd/j;->b:Lcom/transsnet/palmpay/core/base/l;

    .line 4
    .line 5
    const-string v2, "it"

    .line 6
    .line 7
    iget v3, p0, LZd/j;->a:I

    .line 8
    .line 9
    packed-switch v3, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 13
    .line 14
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 18
    .line 19
    if-nez v2, :cond_4

    .line 20
    .line 21
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 22
    .line 23
    if-eqz v2, :cond_2

    .line 24
    .line 25
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 28
    .line 29
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;

    .line 32
    .line 33
    check-cast v1, Ljava/lang/String;

    .line 34
    .line 35
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_4

    .line 40
    .line 41
    if-eqz v1, :cond_0

    .line 42
    .line 43
    iget-object v2, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->w:Ljava/util/LinkedHashMap;

    .line 44
    .line 45
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonListResultV2;->data:Ljava/util/List;

    .line 46
    .line 47
    invoke-interface {v2, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    check-cast p1, Ljava/util/List;

    .line 52
    .line 53
    :cond_0
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Z:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 54
    .line 55
    if-eqz p1, :cond_1

    .line 56
    .line 57
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    goto :goto_0

    .line 62
    :cond_1
    const/4 p1, 0x0

    .line 63
    :goto_0
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    if-eqz p1, :cond_4

    .line 68
    .line 69
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->w:Ljava/util/LinkedHashMap;

    .line 70
    .line 71
    invoke-virtual {p1, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    check-cast p1, Ljava/util/List;

    .line 76
    .line 77
    if-eqz p1, :cond_4

    .line 78
    .line 79
    check-cast p1, Ljava/util/Collection;

    .line 80
    .line 81
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    const/4 v1, 0x1

    .line 86
    xor-int/2addr p1, v1

    .line 87
    if-ne p1, v1, :cond_4

    .line 88
    .line 89
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->D()LXd/c;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->I(Ljava/util/List;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->D()LXd/c;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 105
    .line 106
    .line 107
    goto :goto_1

    .line 108
    :cond_2
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 109
    .line 110
    if-nez v0, :cond_4

    .line 111
    .line 112
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 113
    .line 114
    if-eqz v0, :cond_3

    .line 115
    .line 116
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 117
    .line 118
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 119
    .line 120
    .line 121
    goto :goto_1

    .line 122
    :cond_3
    new-instance p1, Lxf/l;

    .line 123
    .line 124
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 125
    .line 126
    .line 127
    throw p1

    .line 128
    :cond_4
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 129
    .line 130
    return-object p1

    .line 131
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 132
    .line 133
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 137
    .line 138
    if-nez v2, :cond_8

    .line 139
    .line 140
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 141
    .line 142
    const/4 v3, 0x0

    .line 143
    if-eqz v2, :cond_6

    .line 144
    .line 145
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 146
    .line 147
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 148
    .line 149
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 150
    .line 151
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 152
    .line 153
    check-cast v1, Ljava/lang/String;

    .line 154
    .line 155
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 156
    .line 157
    .line 158
    move-result v2

    .line 159
    if-eqz v2, :cond_5

    .line 160
    .line 161
    iget-object v2, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 162
    .line 163
    if-eqz v2, :cond_5

    .line 164
    .line 165
    if-eqz v1, :cond_8

    .line 166
    .line 167
    iget-object v3, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Q:Ljava/util/HashMap;

    .line 168
    .line 169
    check-cast v2, Lcom/transsnet/palmpay/teller/bean/resp/QueryElectricCustomerIdIsExitBean;

    .line 170
    .line 171
    invoke-virtual {v3, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 175
    .line 176
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/resp/QueryElectricCustomerIdIsExitBean;

    .line 177
    .line 178
    invoke-virtual {v0, v1, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->w(Ljava/lang/String;Lcom/transsnet/palmpay/teller/bean/resp/QueryElectricCustomerIdIsExitBean;)V

    .line 179
    .line 180
    .line 181
    goto :goto_2

    .line 182
    :cond_5
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 183
    .line 184
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->B()Landroidx/swiperefreshlayout/widget/c;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    invoke-virtual {p1}, Landroidx/swiperefreshlayout/widget/c;->stop()V

    .line 189
    .line 190
    .line 191
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 192
    .line 193
    check-cast p1, LRd/f0;

    .line 194
    .line 195
    if-eqz p1, :cond_8

    .line 196
    .line 197
    iget-object p1, p1, LRd/f0;->o:Landroid/widget/LinearLayout;

    .line 198
    .line 199
    invoke-static {p1, v3}, Loa/h;->s(Landroid/view/View;Z)V

    .line 200
    .line 201
    .line 202
    goto :goto_2

    .line 203
    :cond_6
    instance-of v1, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 204
    .line 205
    if-nez v1, :cond_8

    .line 206
    .line 207
    instance-of v1, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 208
    .line 209
    if-eqz v1, :cond_7

    .line 210
    .line 211
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 212
    .line 213
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 214
    .line 215
    .line 216
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 217
    .line 218
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->B()Landroidx/swiperefreshlayout/widget/c;

    .line 219
    .line 220
    .line 221
    move-result-object p1

    .line 222
    invoke-virtual {p1}, Landroidx/swiperefreshlayout/widget/c;->stop()V

    .line 223
    .line 224
    .line 225
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 226
    .line 227
    check-cast p1, LRd/f0;

    .line 228
    .line 229
    if-eqz p1, :cond_8

    .line 230
    .line 231
    iget-object p1, p1, LRd/f0;->o:Landroid/widget/LinearLayout;

    .line 232
    .line 233
    invoke-static {p1, v3}, Loa/h;->s(Landroid/view/View;Z)V

    .line 234
    .line 235
    .line 236
    goto :goto_2

    .line 237
    :cond_7
    new-instance p1, Lxf/l;

    .line 238
    .line 239
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 240
    .line 241
    .line 242
    throw p1

    .line 243
    :cond_8
    :goto_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 244
    .line 245
    return-object p1

    .line 246
    nop

    .line 247
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
