.class public final synthetic LZd/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/t;->a:I

    iput-object p1, p0, LZd/t;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LZd/t;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 3
    .line 4
    iget v2, p0, LZd/t;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 10
    .line 11
    iget-object v2, v1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 12
    .line 13
    check-cast v2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;

    .line 14
    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    iget-object v3, v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->L:Ljava/lang/String;

    .line 18
    .line 19
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;->f(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    iget-object v2, v1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 23
    .line 24
    check-cast v2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    iget-object v1, v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->L:Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v2, v1, v0, v0}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;->d(Ljava/lang/String;ZZ)V

    .line 31
    .line 32
    .line 33
    :cond_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 34
    .line 35
    return-object v0

    .line 36
    :pswitch_0
    sget v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 37
    .line 38
    new-instance v2, Landroidx/swiperefreshlayout/widget/c;

    .line 39
    .line 40
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    invoke-direct {v2, v3}, Landroidx/swiperefreshlayout/widget/c;-><init>(Landroid/content/Context;)V

    .line 45
    .line 46
    .line 47
    iget-object v3, v2, Landroidx/swiperefreshlayout/widget/c;->a:Landroidx/swiperefreshlayout/widget/b;

    .line 48
    .line 49
    const/high16 v4, 0x40800000    # 4.0f

    .line 50
    .line 51
    iput v4, v3, Landroidx/swiperefreshlayout/widget/b;->h:F

    .line 52
    .line 53
    iget-object v5, v3, Landroidx/swiperefreshlayout/widget/b;->b:Landroid/graphics/Paint;

    .line 54
    .line 55
    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 59
    .line 60
    .line 61
    const/high16 v4, 0x41800000    # 16.0f

    .line 62
    .line 63
    iput v4, v3, Landroidx/swiperefreshlayout/widget/b;->q:F

    .line 64
    .line 65
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    sget v4, LL6/b;->ppColorPrimary:I

    .line 73
    .line 74
    invoke-virtual {v1, v4}, Landroid/content/Context;->getColor(I)I

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    filled-new-array {v1}, [I

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    iput-object v1, v3, Landroidx/swiperefreshlayout/widget/b;->i:[I

    .line 83
    .line 84
    invoke-virtual {v3, v0}, Landroidx/swiperefreshlayout/widget/b;->a(I)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v3, v0}, Landroidx/swiperefreshlayout/widget/b;->a(I)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v2}, Landroidx/swiperefreshlayout/widget/c;->start()V

    .line 94
    .line 95
    .line 96
    return-object v2

    .line 97
    :pswitch_1
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 98
    .line 99
    new-instance v0, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 100
    .line 101
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    const-string v2, "requireContext(...)"

    .line 106
    .line 107
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-direct {v0, v1}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;-><init>(Landroid/content/Context;)V

    .line 111
    .line 112
    .line 113
    return-object v0

    .line 114
    nop

    .line 115
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
