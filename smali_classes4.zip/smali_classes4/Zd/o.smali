.class public final LZd/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/o;->a:I

    iput-object p1, p0, LZd/o;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;)V
    .locals 0

    const/4 p1, 0x2

    iput p1, p0, LZd/o;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LZd/o;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, LZd/o;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 23
    .line 24
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;

    .line 27
    .line 28
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_3

    .line 33
    .line 34
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;->data:Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;

    .line 35
    .line 36
    if-eqz p1, :cond_3

    .line 37
    .line 38
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMinAmount()J

    .line 39
    .line 40
    .line 41
    move-result-wide v0

    .line 42
    iget-object v2, p0, LZd/o;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 43
    .line 44
    iput-wide v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->k0:J

    .line 45
    .line 46
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMaxAmount()J

    .line 47
    .line 48
    .line 49
    move-result-wide v0

    .line 50
    iput-wide v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->Z:J

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_1
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 54
    .line 55
    if-eqz v0, :cond_2

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_2
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 59
    .line 60
    if-eqz v0, :cond_4

    .line 61
    .line 62
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 63
    .line 64
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 65
    .line 66
    const/4 v0, 0x0

    .line 67
    new-array v0, v0, [Ljava/lang/Object;

    .line 68
    .line 69
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    :cond_3
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 73
    .line 74
    return-object p1

    .line 75
    :cond_4
    new-instance p1, Lxf/l;

    .line 76
    .line 77
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 78
    .line 79
    .line 80
    throw p1

    .line 81
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 82
    .line 83
    const-string v0, "it"

    .line 84
    .line 85
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 89
    .line 90
    iget-object v1, p0, LZd/o;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 91
    .line 92
    const/4 v2, 0x1

    .line 93
    if-eqz v0, :cond_5

    .line 94
    .line 95
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 96
    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_5
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 100
    .line 101
    const-string v3, "/main/trans_history"

    .line 102
    .line 103
    const-string v4, ""

    .line 104
    .line 105
    const/4 v5, 0x0

    .line 106
    if-eqz v0, :cond_7

    .line 107
    .line 108
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 109
    .line 110
    .line 111
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 112
    .line 113
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 116
    .line 117
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 122
    .line 123
    check-cast p1, Ljava/util/ArrayList;

    .line 124
    .line 125
    if-eqz p1, :cond_6

    .line 126
    .line 127
    move-object v4, p1

    .line 128
    :cond_6
    iget-object p1, v0, LPa/w;->b:Ljava/lang/Object;

    .line 129
    .line 130
    check-cast p1, Lcom/google/gson/Gson;

    .line 131
    .line 132
    invoke-virtual {p1, v4}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    invoke-static {v3, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->G(Ljava/lang/String;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    goto :goto_1

    .line 140
    :cond_7
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 141
    .line 142
    if-eqz v0, :cond_8

    .line 143
    .line 144
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 145
    .line 146
    .line 147
    goto :goto_1

    .line 148
    :cond_8
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 149
    .line 150
    if-eqz v0, :cond_9

    .line 151
    .line 152
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 153
    .line 154
    .line 155
    move-object v0, p1

    .line 156
    check-cast v0, Lcom/transsnet/palmpay/core/base/n;

    .line 157
    .line 158
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 159
    .line 160
    new-array v1, v5, [Ljava/lang/Object;

    .line 161
    .line 162
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 166
    .line 167
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    .line 169
    .line 170
    invoke-static {v3, v4}, Lcom/palmpay/lib/apm/launchcounter/util/d;->G(Ljava/lang/String;Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 174
    .line 175
    return-object p1

    .line 176
    :cond_9
    new-instance p1, Lxf/l;

    .line 177
    .line 178
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 179
    .line 180
    .line 181
    throw p1

    .line 182
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 183
    .line 184
    const-string v0, "it"

    .line 185
    .line 186
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 190
    .line 191
    if-nez v0, :cond_14

    .line 192
    .line 193
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 194
    .line 195
    const/4 v1, 0x0

    .line 196
    if-eqz v0, :cond_11

    .line 197
    .line 198
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 199
    .line 200
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 201
    .line 202
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp;

    .line 203
    .line 204
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 205
    .line 206
    .line 207
    move-result v0

    .line 208
    if-eqz v0, :cond_10

    .line 209
    .line 210
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp;->getData()Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;

    .line 211
    .line 212
    .line 213
    move-result-object p1

    .line 214
    iget-object v0, p0, LZd/o;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 215
    .line 216
    const/4 v2, 0x0

    .line 217
    if-eqz p1, :cond_d

    .line 218
    .line 219
    iget-object v3, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->B:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 220
    .line 221
    if-eqz v3, :cond_a

    .line 222
    .line 223
    invoke-virtual {v3}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object v3

    .line 227
    goto :goto_2

    .line 228
    :cond_a
    move-object v3, v2

    .line 229
    :goto_2
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 230
    .line 231
    .line 232
    move-result v3

    .line 233
    if-nez v3, :cond_c

    .line 234
    .line 235
    iget-object v3, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->B:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 236
    .line 237
    if-eqz v3, :cond_b

    .line 238
    .line 239
    invoke-virtual {v3}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v2

    .line 243
    :cond_b
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getBillerId()Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object v3

    .line 247
    invoke-static {v2, v3, v1}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 248
    .line 249
    .line 250
    move-result v1

    .line 251
    if-nez v1, :cond_c

    .line 252
    .line 253
    goto :goto_3

    .line 254
    :cond_c
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getBillerId()Ljava/lang/String;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getPaymentItemId()Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object v2

    .line 262
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getCustomerId()Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object v3

    .line 266
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getBusinessAmount()J

    .line 267
    .line 268
    .line 269
    move-result-wide v4

    .line 270
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 271
    .line 272
    .line 273
    move-result-object p1

    .line 274
    invoke-static {v0, v1, v2, v3, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->D(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 275
    .line 276
    .line 277
    goto :goto_3

    .line 278
    :cond_d
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->B:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 279
    .line 280
    if-eqz p1, :cond_e

    .line 281
    .line 282
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 283
    .line 284
    .line 285
    move-result-object v2

    .line 286
    :cond_e
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 287
    .line 288
    .line 289
    move-result p1

    .line 290
    if-nez p1, :cond_f

    .line 291
    .line 292
    goto :goto_3

    .line 293
    :cond_f
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->C:Ljava/util/ArrayList;

    .line 294
    .line 295
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 296
    .line 297
    .line 298
    move-result p1

    .line 299
    if-nez p1, :cond_14

    .line 300
    .line 301
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->C:Ljava/util/ArrayList;

    .line 302
    .line 303
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object p1

    .line 307
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 308
    .line 309
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 310
    .line 311
    .line 312
    move-result-object p1

    .line 313
    const-wide/16 v1, 0x0

    .line 314
    .line 315
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 316
    .line 317
    .line 318
    move-result-object v1

    .line 319
    const-string v2, ""

    .line 320
    .line 321
    invoke-static {v0, p1, v2, v2, v1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->D(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 322
    .line 323
    .line 324
    goto :goto_3

    .line 325
    :cond_10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 326
    .line 327
    .line 328
    move-result-object p1

    .line 329
    new-array v0, v1, [Ljava/lang/Object;

    .line 330
    .line 331
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 332
    .line 333
    .line 334
    goto :goto_3

    .line 335
    :cond_11
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 336
    .line 337
    if-eqz v0, :cond_12

    .line 338
    .line 339
    goto :goto_3

    .line 340
    :cond_12
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 341
    .line 342
    if-eqz v0, :cond_13

    .line 343
    .line 344
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 345
    .line 346
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 347
    .line 348
    new-array v0, v1, [Ljava/lang/Object;

    .line 349
    .line 350
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 351
    .line 352
    .line 353
    goto :goto_3

    .line 354
    :cond_13
    new-instance p1, Lxf/l;

    .line 355
    .line 356
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 357
    .line 358
    .line 359
    throw p1

    .line 360
    :cond_14
    :goto_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 361
    .line 362
    return-object p1

    .line 363
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
