.class public final synthetic LZd/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/u;->a:I

    iput-object p1, p0, LZd/u;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    const/4 v0, 0x3

    .line 2
    const-string v1, "rsp"

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x0

    .line 6
    const-string v4, ""

    .line 7
    .line 8
    const/4 v5, 0x1

    .line 9
    iget-object v6, p0, LZd/u;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 10
    .line 11
    iget v7, p0, LZd/u;->a:I

    .line 12
    .line 13
    packed-switch v7, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;

    .line 17
    .line 18
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp;

    .line 19
    .line 20
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 21
    .line 22
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_1e

    .line 30
    .line 31
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp;->data:Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;

    .line 32
    .line 33
    if-eqz p2, :cond_26

    .line 34
    .line 35
    iget-object v0, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 36
    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getUserIdTips()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    move-object v0, v3

    .line 45
    :goto_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    iget-object v1, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->L:Ljava/lang/String;

    .line 50
    .line 51
    if-nez v0, :cond_2

    .line 52
    .line 53
    iget-object v0, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 54
    .line 55
    if-eqz v0, :cond_1

    .line 56
    .line 57
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getUserIdTips()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    goto :goto_1

    .line 62
    :cond_1
    move-object v0, v3

    .line 63
    goto :goto_1

    .line 64
    :cond_2
    invoke-static {v1}, Lee/c;->e(Ljava/lang/String;)I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    invoke-virtual {v6, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    :goto_1
    iget-boolean v7, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;->available:Z

    .line 73
    .line 74
    if-eqz v7, :cond_1d

    .line 75
    .line 76
    new-instance v0, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;

    .line 77
    .line 78
    invoke-direct {v0}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;-><init>()V

    .line 79
    .line 80
    .line 81
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 82
    .line 83
    if-eqz v7, :cond_3

    .line 84
    .line 85
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v7

    .line 89
    if-nez v7, :cond_4

    .line 90
    .line 91
    :cond_3
    move-object v7, v4

    .line 92
    :cond_4
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setBillerName(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 96
    .line 97
    if-eqz v7, :cond_5

    .line 98
    .line 99
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v7

    .line 103
    if-nez v7, :cond_6

    .line 104
    .line 105
    :cond_5
    move-object v7, v4

    .line 106
    :cond_6
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setBillerId(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->A()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v7

    .line 113
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setAccountNumber(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    if-eqz p1, :cond_7

    .line 117
    .line 118
    iget-object v7, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->paymentItemName:Ljava/lang/String;

    .line 119
    .line 120
    if-nez v7, :cond_8

    .line 121
    .line 122
    :cond_7
    move-object v7, v4

    .line 123
    :cond_8
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setPaymentItemName(Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    if-eqz p1, :cond_9

    .line 127
    .line 128
    iget-object v7, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->paymentItemId:Ljava/lang/String;

    .line 129
    .line 130
    if-nez v7, :cond_a

    .line 131
    .line 132
    :cond_9
    move-object v7, v4

    .line 133
    :cond_a
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setPaymentItemId(Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 137
    .line 138
    if-eqz v7, :cond_b

    .line 139
    .line 140
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getUserIdTips()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v7

    .line 144
    if-nez v7, :cond_c

    .line 145
    .line 146
    :cond_b
    move-object v7, v4

    .line 147
    :cond_c
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setAccountNmberTitleName(Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 151
    .line 152
    if-eqz v7, :cond_d

    .line 153
    .line 154
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getInstitutionLogo()Ljava/lang/String;

    .line 155
    .line 156
    .line 157
    move-result-object v7

    .line 158
    if-nez v7, :cond_e

    .line 159
    .line 160
    :cond_d
    move-object v7, v4

    .line 161
    :cond_e
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setBillerIcon(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    if-eqz p1, :cond_f

    .line 165
    .line 166
    iget-wide v7, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->businessAmount:J

    .line 167
    .line 168
    :goto_2
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 169
    .line 170
    .line 171
    move-result-object v7

    .line 172
    goto :goto_3

    .line 173
    :cond_f
    const-wide/16 v7, 0x0

    .line 174
    .line 175
    goto :goto_2

    .line 176
    :goto_3
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setAccountAmount(Ljava/lang/Long;)V

    .line 177
    .line 178
    .line 179
    iget-boolean v7, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;->available:Z

    .line 180
    .line 181
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 182
    .line 183
    .line 184
    move-result-object v7

    .line 185
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setAvailable(Ljava/lang/Boolean;)V

    .line 186
    .line 187
    .line 188
    iget-object v7, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;->fullName:Ljava/lang/String;

    .line 189
    .line 190
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setFullName(Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    iget-object v7, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;->referenceId:Ljava/lang/String;

    .line 194
    .line 195
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setReferenceId(Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    iget-object v7, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;->address:Ljava/lang/String;

    .line 199
    .line 200
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setAddress(Ljava/lang/String;)V

    .line 201
    .line 202
    .line 203
    iget-wide v7, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;->minAmount:J

    .line 204
    .line 205
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 206
    .line 207
    .line 208
    move-result-object v7

    .line 209
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setMinAmount(Ljava/lang/Long;)V

    .line 210
    .line 211
    .line 212
    iget-wide v7, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;->renewalAmount:J

    .line 213
    .line 214
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 215
    .line 216
    .line 217
    move-result-object v7

    .line 218
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setRenewalAmount(Ljava/lang/Long;)V

    .line 219
    .line 220
    .line 221
    if-eqz p1, :cond_10

    .line 222
    .line 223
    iget-object v7, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->viewDoc:Ljava/lang/String;

    .line 224
    .line 225
    if-nez v7, :cond_11

    .line 226
    .line 227
    :cond_10
    move-object v7, v4

    .line 228
    :cond_11
    invoke-virtual {v0, v7}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setViewDoc(Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    if-eqz p1, :cond_13

    .line 232
    .line 233
    iget-object v7, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->viewPic:Ljava/lang/String;

    .line 234
    .line 235
    if-nez v7, :cond_12

    .line 236
    .line 237
    goto :goto_4

    .line 238
    :cond_12
    move-object v4, v7

    .line 239
    :cond_13
    :goto_4
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setViewPic(Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    new-instance v4, Ljava/util/ArrayList;

    .line 243
    .line 244
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 245
    .line 246
    .line 247
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->setItems(Ljava/util/ArrayList;)V

    .line 248
    .line 249
    .line 250
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$DataBean;->items:Ljava/util/List;

    .line 251
    .line 252
    if-eqz p2, :cond_15

    .line 253
    .line 254
    check-cast p2, Ljava/lang/Iterable;

    .line 255
    .line 256
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 257
    .line 258
    .line 259
    move-result-object p2

    .line 260
    :cond_14
    :goto_5
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 261
    .line 262
    .line 263
    move-result v4

    .line 264
    if-eqz v4, :cond_15

    .line 265
    .line 266
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v4

    .line 270
    check-cast v4, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$Item;

    .line 271
    .line 272
    if-eqz v4, :cond_14

    .line 273
    .line 274
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean;->getItems()Ljava/util/ArrayList;

    .line 275
    .line 276
    .line 277
    move-result-object v7

    .line 278
    if-eqz v7, :cond_14

    .line 279
    .line 280
    new-instance v8, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean$Item;

    .line 281
    .line 282
    iget-object v9, v4, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$Item;->key:Ljava/lang/String;

    .line 283
    .line 284
    iget-object v4, v4, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdRsp$Item;->value:Ljava/lang/String;

    .line 285
    .line 286
    invoke-direct {v8, v9, v4}, Lcom/transsnet/palmpay/teller/bean/TvRenewDataInfoBean$Item;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 290
    .line 291
    .line 292
    goto :goto_5

    .line 293
    :cond_15
    iget-object p2, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 294
    .line 295
    check-cast p2, LRd/g0;

    .line 296
    .line 297
    if-eqz p2, :cond_1c

    .line 298
    .line 299
    iget-object p2, p2, LRd/g0;->d:Landroidx/appcompat/widget/AppCompatCheckBox;

    .line 300
    .line 301
    invoke-virtual {p2}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 302
    .line 303
    .line 304
    move-result p2

    .line 305
    if-ne p2, v5, :cond_1c

    .line 306
    .line 307
    new-instance p2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;

    .line 308
    .line 309
    invoke-direct {p2}, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;-><init>()V

    .line 310
    .line 311
    .line 312
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->A()Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v4

    .line 316
    iput-object v4, p2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->customerId:Ljava/lang/String;

    .line 317
    .line 318
    if-eqz p1, :cond_16

    .line 319
    .line 320
    iget-object v4, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->paymentItemId:Ljava/lang/String;

    .line 321
    .line 322
    goto :goto_6

    .line 323
    :cond_16
    move-object v4, v3

    .line 324
    :goto_6
    iput-object v4, p2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->itemId:Ljava/lang/String;

    .line 325
    .line 326
    if-eqz p1, :cond_17

    .line 327
    .line 328
    iget-object v4, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->billerName:Ljava/lang/String;

    .line 329
    .line 330
    goto :goto_7

    .line 331
    :cond_17
    move-object v4, v3

    .line 332
    :goto_7
    iput-object v4, p2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->billerName:Ljava/lang/String;

    .line 333
    .line 334
    if-eqz p1, :cond_18

    .line 335
    .line 336
    iget-object v4, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->icon:Ljava/lang/String;

    .line 337
    .line 338
    goto :goto_8

    .line 339
    :cond_18
    move-object v4, v3

    .line 340
    :goto_8
    iput-object v4, p2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->institutionLogo:Ljava/lang/String;

    .line 341
    .line 342
    iput-object v1, p2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->categoryId:Ljava/lang/String;

    .line 343
    .line 344
    if-eqz p1, :cond_19

    .line 345
    .line 346
    iget-object v1, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->paymentItemName:Ljava/lang/String;

    .line 347
    .line 348
    goto :goto_9

    .line 349
    :cond_19
    move-object v1, v3

    .line 350
    :goto_9
    iput-object v1, p2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->itemName:Ljava/lang/String;

    .line 351
    .line 352
    if-eqz p1, :cond_1a

    .line 353
    .line 354
    iget-object p1, p1, Lcom/transsnet/palmpay/teller/bean/CheckCustomerIdReq;->billerId:Ljava/lang/String;

    .line 355
    .line 356
    goto :goto_a

    .line 357
    :cond_1a
    move-object p1, v3

    .line 358
    :goto_a
    iput-object p1, p2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->billerId:Ljava/lang/String;

    .line 359
    .line 360
    iget-object p1, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 361
    .line 362
    check-cast p1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;

    .line 363
    .line 364
    if-eqz p1, :cond_1b

    .line 365
    .line 366
    new-instance v1, Lfe/a0;

    .line 367
    .line 368
    invoke-direct {v1, p2, v3}, Lfe/a0;-><init>(Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;Lkotlin/coroutines/Continuation;)V

    .line 369
    .line 370
    .line 371
    iget-object p2, p1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;->p:Lcom/transsnet/palmpay/core/base/l;

    .line 372
    .line 373
    const/16 v3, 0x1c

    .line 374
    .line 375
    invoke-static {p1, v1, p2, v2, v3}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 376
    .line 377
    .line 378
    :cond_1b
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 379
    .line 380
    .line 381
    move-result-object p1

    .line 382
    const-string p2, "PPay_TV_Btn_SaveToBeneficiaries"

    .line 383
    .line 384
    invoke-virtual {p1, p2}, LPa/n0;->l(Ljava/lang/String;)V

    .line 385
    .line 386
    .line 387
    :cond_1c
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 388
    .line 389
    .line 390
    move-result-object p1

    .line 391
    const-string p2, "/quick_teller/tv_home_pre"

    .line 392
    .line 393
    invoke-virtual {p1, p2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 394
    .line 395
    .line 396
    move-result-object p1

    .line 397
    const-string p2, "extra_renew_data"

    .line 398
    .line 399
    invoke-virtual {p1, p2, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withSerializable(Ljava/lang/String;Ljava/io/Serializable;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 400
    .line 401
    .line 402
    move-result-object p1

    .line 403
    const-string p2, "channel"

    .line 404
    .line 405
    iget-object v0, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->X:Ljava/lang/String;

    .line 406
    .line 407
    invoke-virtual {p1, p2, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 408
    .line 409
    .line 410
    move-result-object p1

    .line 411
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 412
    .line 413
    .line 414
    goto/16 :goto_e

    .line 415
    .line 416
    :cond_1d
    iget-object p1, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 417
    .line 418
    check-cast p1, LRd/g0;

    .line 419
    .line 420
    if-eqz p1, :cond_26

    .line 421
    .line 422
    iget-object p1, p1, LRd/g0;->v:Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;

    .line 423
    .line 424
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;->getErrorTv()Landroid/widget/TextView;

    .line 425
    .line 426
    .line 427
    move-result-object p1

    .line 428
    if-eqz p1, :cond_26

    .line 429
    .line 430
    sget p2, LPd/f;->qt_msg_customer_id_invalid:I

    .line 431
    .line 432
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 433
    .line 434
    .line 435
    move-result-object v0

    .line 436
    invoke-virtual {v6, p2, v0}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 437
    .line 438
    .line 439
    move-result-object p2

    .line 440
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 441
    .line 442
    .line 443
    goto/16 :goto_e

    .line 444
    .line 445
    :cond_1e
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 446
    .line 447
    .line 448
    move-result-object p1

    .line 449
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 450
    .line 451
    .line 452
    move-result-object p2

    .line 453
    if-eqz p1, :cond_26

    .line 454
    .line 455
    const-string v0, "B00015"

    .line 456
    .line 457
    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 458
    .line 459
    .line 460
    move-result v0

    .line 461
    if-eqz v0, :cond_21

    .line 462
    .line 463
    iget-object p1, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 464
    .line 465
    check-cast p1, LRd/g0;

    .line 466
    .line 467
    if-eqz p1, :cond_1f

    .line 468
    .line 469
    iget-object p1, p1, LRd/g0;->c:Lcom/google/android/material/appbar/AppBarLayout;

    .line 470
    .line 471
    invoke-virtual {p1, v5, v5}, Lcom/google/android/material/appbar/AppBarLayout;->setExpanded(ZZ)V

    .line 472
    .line 473
    .line 474
    :cond_1f
    iget-object p1, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 475
    .line 476
    check-cast p1, LRd/g0;

    .line 477
    .line 478
    if-eqz p1, :cond_26

    .line 479
    .line 480
    iget-object p1, p1, LRd/g0;->v:Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;

    .line 481
    .line 482
    if-nez p2, :cond_20

    .line 483
    .line 484
    goto :goto_b

    .line 485
    :cond_20
    move-object v4, p2

    .line 486
    :goto_b
    invoke-virtual {p1, v4}, Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;->setErrorMessage(Ljava/lang/CharSequence;)V

    .line 487
    .line 488
    .line 489
    goto :goto_e

    .line 490
    :cond_21
    const-string v0, "QK00009"

    .line 491
    .line 492
    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 493
    .line 494
    .line 495
    move-result v0

    .line 496
    if-eqz v0, :cond_23

    .line 497
    .line 498
    iget-object p1, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 499
    .line 500
    check-cast p1, LRd/g0;

    .line 501
    .line 502
    if-eqz p1, :cond_26

    .line 503
    .line 504
    iget-object p1, p1, LRd/g0;->H:Lcom/transsnet/palmpay/custom_view/ModelItemSelection;

    .line 505
    .line 506
    if-nez p2, :cond_22

    .line 507
    .line 508
    goto :goto_c

    .line 509
    :cond_22
    move-object v4, p2

    .line 510
    :goto_c
    invoke-virtual {p1, v4}, Lcom/transsnet/palmpay/custom_view/ModelItemSelection;->e(Ljava/lang/String;)V

    .line 511
    .line 512
    .line 513
    goto :goto_e

    .line 514
    :cond_23
    const-string v0, "QK000010"

    .line 515
    .line 516
    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 517
    .line 518
    .line 519
    move-result p1

    .line 520
    if-eqz p1, :cond_25

    .line 521
    .line 522
    sget p1, Lba/k;->core_important_notice:I

    .line 523
    .line 524
    invoke-virtual {v6, p1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 525
    .line 526
    .line 527
    move-result-object p1

    .line 528
    if-nez p2, :cond_24

    .line 529
    .line 530
    goto :goto_d

    .line 531
    :cond_24
    move-object v4, p2

    .line 532
    :goto_d
    sget p2, Lba/k;->core_confirm:I

    .line 533
    .line 534
    invoke-virtual {v6, p2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 535
    .line 536
    .line 537
    move-result-object p2

    .line 538
    invoke-virtual {v6, p1, v4, p2, v3}, Lcom/transsnet/palmpay/core/base/BaseFragment;->r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 539
    .line 540
    .line 541
    goto :goto_e

    .line 542
    :cond_25
    invoke-virtual {v6, p2}, Lcom/transsnet/palmpay/core/base/BaseFragment;->p(Ljava/lang/String;)V

    .line 543
    .line 544
    .line 545
    :cond_26
    :goto_e
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 546
    .line 547
    return-object p1

    .line 548
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/IntegerParams;

    .line 549
    .line 550
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp;

    .line 551
    .line 552
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 553
    .line 554
    const-string p1, "result"

    .line 555
    .line 556
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 557
    .line 558
    .line 559
    invoke-virtual {v6, v2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->F(Z)V

    .line 560
    .line 561
    .line 562
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 563
    .line 564
    .line 565
    move-result p1

    .line 566
    if-eqz p1, :cond_2f

    .line 567
    .line 568
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp;->getData()Ljava/util/ArrayList;

    .line 569
    .line 570
    .line 571
    move-result-object p1

    .line 572
    if-eqz p1, :cond_2f

    .line 573
    .line 574
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp;->getData()Ljava/util/ArrayList;

    .line 575
    .line 576
    .line 577
    move-result-object p1

    .line 578
    if-eqz p1, :cond_27

    .line 579
    .line 580
    iput-object p1, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->B:Ljava/util/ArrayList;

    .line 581
    .line 582
    :cond_27
    iget-object p1, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->p0:LXd/e;

    .line 583
    .line 584
    if-eqz p1, :cond_2d

    .line 585
    .line 586
    iget-object p2, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 587
    .line 588
    if-eqz p2, :cond_29

    .line 589
    .line 590
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 591
    .line 592
    .line 593
    move-result-object p2

    .line 594
    if-nez p2, :cond_28

    .line 595
    .line 596
    goto :goto_f

    .line 597
    :cond_28
    move-object v4, p2

    .line 598
    :cond_29
    :goto_f
    iget-object p2, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->B:Ljava/util/ArrayList;

    .line 599
    .line 600
    const-string v1, "operatorCode"

    .line 601
    .line 602
    invoke-static {v4, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 603
    .line 604
    .line 605
    const-string v1, "list"

    .line 606
    .line 607
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 608
    .line 609
    .line 610
    iput-object v4, p1, LXd/e;->o:Ljava/lang/String;

    .line 611
    .line 612
    iput-object p2, p1, LXd/e;->t:Ljava/util/ArrayList;

    .line 613
    .line 614
    iget-object v1, p1, LXd/e;->p:Ljava/util/HashMap;

    .line 615
    .line 616
    invoke-virtual {v1, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 617
    .line 618
    .line 619
    move-result-object v4

    .line 620
    check-cast v4, Ljava/util/List;

    .line 621
    .line 622
    if-eqz v4, :cond_2a

    .line 623
    .line 624
    invoke-interface {v4}, Ljava/util/List;->clear()V

    .line 625
    .line 626
    .line 627
    :cond_2a
    new-instance v4, Ljava/util/ArrayList;

    .line 628
    .line 629
    const/16 v7, 0xa

    .line 630
    .line 631
    invoke-static {p2, v7}, Lkotlin/collections/r;->l(Ljava/lang/Iterable;I)I

    .line 632
    .line 633
    .line 634
    move-result v7

    .line 635
    invoke-direct {v4, v7}, Ljava/util/ArrayList;-><init>(I)V

    .line 636
    .line 637
    .line 638
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 639
    .line 640
    .line 641
    move-result-object p2

    .line 642
    move v7, v2

    .line 643
    :goto_10
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 644
    .line 645
    .line 646
    move-result v8

    .line 647
    if-eqz v8, :cond_2c

    .line 648
    .line 649
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 650
    .line 651
    .line 652
    move-result-object v8

    .line 653
    add-int/lit8 v9, v7, 0x1

    .line 654
    .line 655
    if-ltz v7, :cond_2b

    .line 656
    .line 657
    check-cast v8, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;

    .line 658
    .line 659
    invoke-virtual {p1, v7, v8}, LXd/e;->h(ILcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;)J

    .line 660
    .line 661
    .line 662
    move-result-wide v7

    .line 663
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 664
    .line 665
    .line 666
    move-result-object v7

    .line 667
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 668
    .line 669
    .line 670
    move v7, v9

    .line 671
    goto :goto_10

    .line 672
    :cond_2b
    invoke-static {}, Lkotlin/collections/q;->k()V

    .line 673
    .line 674
    .line 675
    throw v3

    .line 676
    :cond_2c
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->Z(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 677
    .line 678
    .line 679
    move-result-object p2

    .line 680
    iget-object p1, p1, LXd/e;->o:Ljava/lang/String;

    .line 681
    .line 682
    invoke-virtual {v1, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 683
    .line 684
    .line 685
    :cond_2d
    iget-object p1, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 686
    .line 687
    check-cast p1, LRd/g0;

    .line 688
    .line 689
    if-eqz p1, :cond_2e

    .line 690
    .line 691
    iget-object p1, p1, LRd/g0;->Q:Landroidx/viewpager2/widget/ViewPager2;

    .line 692
    .line 693
    invoke-virtual {p1, v2, v2}, Landroidx/viewpager2/widget/ViewPager2;->setCurrentItem(IZ)V

    .line 694
    .line 695
    .line 696
    :cond_2e
    const-string p1, "notifyDataSetChanged"

    .line 697
    .line 698
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 699
    .line 700
    .line 701
    move-result-object p1

    .line 702
    const-string p2, "BundleFragment"

    .line 703
    .line 704
    invoke-static {p2, v0, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 705
    .line 706
    .line 707
    iget-object p1, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->p0:LXd/e;

    .line 708
    .line 709
    if-eqz p1, :cond_2f

    .line 710
    .line 711
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 712
    .line 713
    .line 714
    :cond_2f
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 715
    .line 716
    return-object p1

    .line 717
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;

    .line 718
    .line 719
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/BillerListRsp;

    .line 720
    .line 721
    sget v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 722
    .line 723
    invoke-static {p2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 724
    .line 725
    .line 726
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 727
    .line 728
    .line 729
    move-result v1

    .line 730
    if-eqz v1, :cond_35

    .line 731
    .line 732
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/BillerListRsp;->data:Ljava/util/List;

    .line 733
    .line 734
    if-eqz p2, :cond_36

    .line 735
    .line 736
    iget-object v1, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Y:Ljava/util/ArrayList;

    .line 737
    .line 738
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 739
    .line 740
    .line 741
    iget-object v1, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Y:Ljava/util/ArrayList;

    .line 742
    .line 743
    check-cast p2, Ljava/util/Collection;

    .line 744
    .line 745
    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 746
    .line 747
    .line 748
    iget-object p2, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Q:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 749
    .line 750
    if-eqz p2, :cond_30

    .line 751
    .line 752
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 753
    .line 754
    .line 755
    move-result-object v1

    .line 756
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getCustomerId()Ljava/lang/String;

    .line 757
    .line 758
    .line 759
    move-result-object p2

    .line 760
    invoke-static {v6, v1, p2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->D(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;Ljava/lang/String;Ljava/lang/String;)V

    .line 761
    .line 762
    .line 763
    :cond_30
    iget-object p2, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->M:Ljava/lang/String;

    .line 764
    .line 765
    if-eqz p2, :cond_32

    .line 766
    .line 767
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 768
    .line 769
    .line 770
    move-result v1

    .line 771
    if-nez v1, :cond_31

    .line 772
    .line 773
    goto :goto_11

    .line 774
    :cond_31
    move-object p2, v3

    .line 775
    :goto_11
    if-eqz p2, :cond_32

    .line 776
    .line 777
    invoke-static {v6, p2, v4}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->D(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;Ljava/lang/String;Ljava/lang/String;)V

    .line 778
    .line 779
    .line 780
    :cond_32
    iget-object p2, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Q:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 781
    .line 782
    if-eqz p2, :cond_33

    .line 783
    .line 784
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerName()Ljava/lang/String;

    .line 785
    .line 786
    .line 787
    move-result-object p2

    .line 788
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 789
    .line 790
    .line 791
    move-result p2

    .line 792
    if-eqz p2, :cond_34

    .line 793
    .line 794
    :cond_33
    iget-object p2, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->M:Ljava/lang/String;

    .line 795
    .line 796
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 797
    .line 798
    .line 799
    move-result p2

    .line 800
    if-eqz p2, :cond_34

    .line 801
    .line 802
    iget-object p2, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 803
    .line 804
    check-cast p2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;

    .line 805
    .line 806
    if-eqz p2, :cond_34

    .line 807
    .line 808
    new-instance v1, Ljava/lang/StringBuilder;

    .line 809
    .line 810
    const-string v2, "queryLastBillerByCategoryId"

    .line 811
    .line 812
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 813
    .line 814
    .line 815
    iget-object v2, v6, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->L:Ljava/lang/String;

    .line 816
    .line 817
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 818
    .line 819
    .line 820
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 821
    .line 822
    .line 823
    move-result-object v1

    .line 824
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 825
    .line 826
    .line 827
    move-result-object v4

    .line 828
    const-string v7, "_"

    .line 829
    .line 830
    invoke-static {v1, v7, v4}, LN8/q0;->y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 831
    .line 832
    .line 833
    move-result-object v1

    .line 834
    invoke-static {p2}, Landroidx/lifecycle/V;->h(Landroidx/lifecycle/a0;)Lkotlinx/coroutines/CoroutineScope;

    .line 835
    .line 836
    .line 837
    move-result-object v4

    .line 838
    new-instance v7, Lfe/u0;

    .line 839
    .line 840
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;->j:Lcom/transsnet/palmpay/core/base/l;

    .line 841
    .line 842
    invoke-direct {v7, p2, v1, v3, v2}, Lfe/u0;-><init>(Lcom/transsnet/palmpay/core/base/l;Ljava/lang/String;Lkotlin/coroutines/Continuation;Ljava/lang/String;)V

    .line 843
    .line 844
    .line 845
    invoke-static {v4, v3, v3, v7, v0}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 846
    .line 847
    .line 848
    :cond_34
    if-eqz p1, :cond_36

    .line 849
    .line 850
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;->getShowDialog()Z

    .line 851
    .line 852
    .line 853
    move-result p1

    .line 854
    if-ne p1, v5, :cond_36

    .line 855
    .line 856
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->E()V

    .line 857
    .line 858
    .line 859
    goto :goto_12

    .line 860
    :cond_35
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 861
    .line 862
    .line 863
    move-result-object p1

    .line 864
    new-array p2, v2, [Ljava/lang/Object;

    .line 865
    .line 866
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 867
    .line 868
    .line 869
    :cond_36
    :goto_12
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 870
    .line 871
    return-object p1

    .line 872
    nop

    .line 873
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
