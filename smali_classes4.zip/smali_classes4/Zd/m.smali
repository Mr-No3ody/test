.class public final synthetic LZd/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/m;->a:I

    iput-object p1, p0, LZd/m;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    iget-object v4, v0, LZd/m;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 7
    .line 8
    iget v5, v0, LZd/m;->a:I

    .line 9
    .line 10
    packed-switch v5, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    sget v5, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 14
    .line 15
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 16
    .line 17
    .line 18
    move-result v5

    .line 19
    if-nez v5, :cond_0

    .line 20
    .line 21
    invoke-static {v1, v1}, LPa/i0;->K(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    goto/16 :goto_1b

    .line 25
    .line 26
    :cond_0
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 27
    .line 28
    if-eqz v5, :cond_2d

    .line 29
    .line 30
    invoke-virtual {v5}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getStatus()Ljava/lang/Integer;

    .line 31
    .line 32
    .line 33
    move-result-object v6

    .line 34
    if-nez v6, :cond_1

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 38
    .line 39
    .line 40
    move-result v6

    .line 41
    if-eq v6, v2, :cond_3

    .line 42
    .line 43
    :goto_0
    invoke-virtual {v5}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    if-nez v2, :cond_2

    .line 48
    .line 49
    const-string v2, ""

    .line 50
    .line 51
    :cond_2
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    sget v6, LPd/f;->qt_service_temporarily_unavailable_3:I

    .line 56
    .line 57
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-virtual {v4, v6, v2}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    new-instance v4, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;

    .line 66
    .line 67
    sget v6, Lcom/transsnet/palmpay/custom_view/t;->cv_toast_dialog:I

    .line 68
    .line 69
    invoke-direct {v4, v5, v6}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;-><init>(Landroid/content/Context;I)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v4, v2}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->setMessage(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v4, v1}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->setTitle(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    invoke-static {v4, v3}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->d(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;I)V

    .line 79
    .line 80
    .line 81
    invoke-static {v4, v1}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->e(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;Lcom/mikepenz/iconics/IconicsDrawable;)V

    .line 82
    .line 83
    .line 84
    invoke-static {v4}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->c(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;)V

    .line 85
    .line 86
    .line 87
    const-wide/16 v1, 0xfa0

    .line 88
    .line 89
    invoke-virtual {v4, v1, v2}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->show(J)V

    .line 90
    .line 91
    .line 92
    goto/16 :goto_1b

    .line 93
    .line 94
    :cond_3
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 95
    .line 96
    const-string v6, "2"

    .line 97
    .line 98
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v5

    .line 102
    if-eqz v5, :cond_4

    .line 103
    .line 104
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 105
    .line 106
    .line 107
    move-result-object v5

    .line 108
    const-string v6, "TV_click_Next"

    .line 109
    .line 110
    invoke-virtual {v5, v6}, LPa/n0;->l(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    goto :goto_1

    .line 114
    :cond_4
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 115
    .line 116
    const-string v6, "1"

    .line 117
    .line 118
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    move-result v5

    .line 122
    if-eqz v5, :cond_5

    .line 123
    .line 124
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 125
    .line 126
    .line 127
    move-result-object v5

    .line 128
    const-string v6, "Electricity_click_Next"

    .line 129
    .line 130
    invoke-virtual {v5, v6}, LPa/n0;->l(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    :cond_5
    :goto_1
    iget-object v5, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 134
    .line 135
    check-cast v5, LRd/l;

    .line 136
    .line 137
    if-eqz v5, :cond_6

    .line 138
    .line 139
    iget-object v8, v5, LRd/l;->g:Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 140
    .line 141
    iget-boolean v8, v8, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->C:Z

    .line 142
    .line 143
    if-ne v8, v2, :cond_6

    .line 144
    .line 145
    goto/16 :goto_6

    .line 146
    .line 147
    :cond_6
    if-eqz v5, :cond_7

    .line 148
    .line 149
    iget-object v5, v5, LRd/l;->g:Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 150
    .line 151
    invoke-virtual {v5}, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->getDoubleAmount()D

    .line 152
    .line 153
    .line 154
    move-result-wide v8

    .line 155
    goto :goto_2

    .line 156
    :cond_7
    const-wide/16 v8, 0x0

    .line 157
    .line 158
    :goto_2
    invoke-static {v8, v9}, LPa/r0;->f(D)J

    .line 159
    .line 160
    .line 161
    move-result-wide v8

    .line 162
    const-wide/16 v10, 0x0

    .line 163
    .line 164
    cmp-long v5, v8, v10

    .line 165
    .line 166
    if-gtz v5, :cond_8

    .line 167
    .line 168
    sget v1, LPd/f;->qt_msg_amount_above_desc:I

    .line 169
    .line 170
    invoke-static {v10, v11, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v2

    .line 174
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object v2

    .line 178
    invoke-virtual {v4, v1, v2}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 179
    .line 180
    .line 181
    move-result-object v1

    .line 182
    new-array v2, v3, [Ljava/lang/Object;

    .line 183
    .line 184
    invoke-static {v1, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 185
    .line 186
    .line 187
    goto/16 :goto_1b

    .line 188
    .line 189
    :cond_8
    iget-wide v12, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->k0:J

    .line 190
    .line 191
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 192
    .line 193
    if-eqz v5, :cond_9

    .line 194
    .line 195
    invoke-virtual {v5}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getMinAmount()Ljava/lang/Long;

    .line 196
    .line 197
    .line 198
    move-result-object v5

    .line 199
    if-eqz v5, :cond_9

    .line 200
    .line 201
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 202
    .line 203
    .line 204
    move-result-wide v14

    .line 205
    goto :goto_3

    .line 206
    :cond_9
    move-wide v14, v10

    .line 207
    :goto_3
    iget-wide v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->p0:J

    .line 208
    .line 209
    invoke-static {v14, v15, v6, v7}, Ljava/lang/Math;->max(JJ)J

    .line 210
    .line 211
    .line 212
    move-result-wide v5

    .line 213
    invoke-static {v12, v13, v5, v6}, Ljava/lang/Math;->max(JJ)J

    .line 214
    .line 215
    .line 216
    move-result-wide v5

    .line 217
    cmp-long v7, v8, v5

    .line 218
    .line 219
    if-gez v7, :cond_a

    .line 220
    .line 221
    iget-object v1, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 222
    .line 223
    check-cast v1, LRd/l;

    .line 224
    .line 225
    if-eqz v1, :cond_2d

    .line 226
    .line 227
    iget-object v1, v1, LRd/l;->g:Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 228
    .line 229
    sget v2, LPd/f;->qt_msg_amount_above_desc:I

    .line 230
    .line 231
    invoke-static {v5, v6, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object v3

    .line 235
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v3

    .line 239
    invoke-virtual {v4, v2, v3}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v2

    .line 243
    invoke-virtual {v1, v2}, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->setError(Ljava/lang/CharSequence;)V

    .line 244
    .line 245
    .line 246
    goto/16 :goto_1b

    .line 247
    .line 248
    :cond_a
    iget-wide v12, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->Z:J

    .line 249
    .line 250
    cmp-long v7, v12, v10

    .line 251
    .line 252
    const-wide v12, 0x7fffffffffffffffL

    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    if-nez v7, :cond_b

    .line 258
    .line 259
    iput-wide v12, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->Z:J

    .line 260
    .line 261
    :cond_b
    iget-object v7, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 262
    .line 263
    if-eqz v7, :cond_d

    .line 264
    .line 265
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getMaxAmount()Ljava/lang/Long;

    .line 266
    .line 267
    .line 268
    move-result-object v7

    .line 269
    if-nez v7, :cond_c

    .line 270
    .line 271
    goto :goto_4

    .line 272
    :cond_c
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    .line 273
    .line 274
    .line 275
    move-result-wide v14

    .line 276
    cmp-long v7, v14, v10

    .line 277
    .line 278
    if-nez v7, :cond_d

    .line 279
    .line 280
    iget-object v7, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 281
    .line 282
    if-eqz v7, :cond_d

    .line 283
    .line 284
    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 285
    .line 286
    .line 287
    move-result-object v14

    .line 288
    invoke-virtual {v7, v14}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->setMaxAmount(Ljava/lang/Long;)V

    .line 289
    .line 290
    .line 291
    :cond_d
    :goto_4
    iget-wide v14, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->q0:J

    .line 292
    .line 293
    cmp-long v7, v14, v10

    .line 294
    .line 295
    if-nez v7, :cond_e

    .line 296
    .line 297
    iput-wide v12, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->q0:J

    .line 298
    .line 299
    :cond_e
    iget-wide v10, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->Z:J

    .line 300
    .line 301
    iget-object v7, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 302
    .line 303
    if-eqz v7, :cond_f

    .line 304
    .line 305
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getMaxAmount()Ljava/lang/Long;

    .line 306
    .line 307
    .line 308
    move-result-object v7

    .line 309
    if-eqz v7, :cond_f

    .line 310
    .line 311
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    .line 312
    .line 313
    .line 314
    move-result-wide v12

    .line 315
    :cond_f
    iget-wide v14, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->q0:J

    .line 316
    .line 317
    invoke-static {v12, v13, v14, v15}, Ljava/lang/Math;->min(JJ)J

    .line 318
    .line 319
    .line 320
    move-result-wide v12

    .line 321
    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->min(JJ)J

    .line 322
    .line 323
    .line 324
    move-result-wide v10

    .line 325
    cmp-long v7, v10, v5

    .line 326
    .line 327
    if-gez v7, :cond_10

    .line 328
    .line 329
    goto :goto_5

    .line 330
    :cond_10
    move-wide v5, v10

    .line 331
    :goto_5
    cmp-long v7, v8, v5

    .line 332
    .line 333
    if-lez v7, :cond_11

    .line 334
    .line 335
    iget-object v1, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 336
    .line 337
    check-cast v1, LRd/l;

    .line 338
    .line 339
    if-eqz v1, :cond_2d

    .line 340
    .line 341
    iget-object v1, v1, LRd/l;->g:Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 342
    .line 343
    sget v2, LPd/f;->qt_msg_amount_below_desc:I

    .line 344
    .line 345
    invoke-static {v5, v6, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 346
    .line 347
    .line 348
    move-result-object v3

    .line 349
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object v3

    .line 353
    invoke-virtual {v4, v2, v3}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 354
    .line 355
    .line 356
    move-result-object v2

    .line 357
    invoke-virtual {v1, v2}, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->setError(Ljava/lang/CharSequence;)V

    .line 358
    .line 359
    .line 360
    goto/16 :goto_1b

    .line 361
    .line 362
    :cond_11
    :goto_6
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->M:Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 363
    .line 364
    if-eqz v5, :cond_1a

    .line 365
    .line 366
    iget-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerId:Ljava/lang/String;

    .line 367
    .line 368
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 369
    .line 370
    .line 371
    move-result v6

    .line 372
    if-eqz v6, :cond_13

    .line 373
    .line 374
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 375
    .line 376
    if-eqz v6, :cond_12

    .line 377
    .line 378
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v6

    .line 382
    goto :goto_7

    .line 383
    :cond_12
    move-object v6, v1

    .line 384
    goto :goto_7

    .line 385
    :cond_13
    iget-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerId:Ljava/lang/String;

    .line 386
    .line 387
    :goto_7
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerId:Ljava/lang/String;

    .line 388
    .line 389
    iget-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerName:Ljava/lang/String;

    .line 390
    .line 391
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 392
    .line 393
    .line 394
    move-result v6

    .line 395
    if-eqz v6, :cond_15

    .line 396
    .line 397
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 398
    .line 399
    if-eqz v6, :cond_14

    .line 400
    .line 401
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object v6

    .line 405
    goto :goto_8

    .line 406
    :cond_14
    move-object v6, v1

    .line 407
    goto :goto_8

    .line 408
    :cond_15
    iget-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerName:Ljava/lang/String;

    .line 409
    .line 410
    :goto_8
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerName:Ljava/lang/String;

    .line 411
    .line 412
    iget-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->institutionLogo:Ljava/lang/String;

    .line 413
    .line 414
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 415
    .line 416
    .line 417
    move-result v6

    .line 418
    if-eqz v6, :cond_17

    .line 419
    .line 420
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 421
    .line 422
    if-eqz v6, :cond_16

    .line 423
    .line 424
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getInstitutionLogo()Ljava/lang/String;

    .line 425
    .line 426
    .line 427
    move-result-object v6

    .line 428
    goto :goto_9

    .line 429
    :cond_16
    move-object v6, v1

    .line 430
    goto :goto_9

    .line 431
    :cond_17
    iget-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->institutionLogo:Ljava/lang/String;

    .line 432
    .line 433
    :goto_9
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->institutionLogo:Ljava/lang/String;

    .line 434
    .line 435
    iget-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->customerField1:Ljava/lang/String;

    .line 436
    .line 437
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 438
    .line 439
    .line 440
    move-result v6

    .line 441
    if-eqz v6, :cond_19

    .line 442
    .line 443
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 444
    .line 445
    if-eqz v6, :cond_18

    .line 446
    .line 447
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getCustomerField1()Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v6

    .line 451
    goto :goto_a

    .line 452
    :cond_18
    move-object v6, v1

    .line 453
    goto :goto_a

    .line 454
    :cond_19
    iget-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->customerField1:Ljava/lang/String;

    .line 455
    .line 456
    :goto_a
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->customerField1:Ljava/lang/String;

    .line 457
    .line 458
    :cond_1a
    new-instance v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;

    .line 459
    .line 460
    invoke-direct {v5}, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;-><init>()V

    .line 461
    .line 462
    .line 463
    iget-object v6, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 464
    .line 465
    check-cast v6, LRd/l;

    .line 466
    .line 467
    if-eqz v6, :cond_1b

    .line 468
    .line 469
    iget-object v6, v6, LRd/l;->g:Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 470
    .line 471
    invoke-virtual {v6}, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->getDoubleAmount()D

    .line 472
    .line 473
    .line 474
    move-result-wide v6

    .line 475
    goto :goto_b

    .line 476
    :cond_1b
    const-wide/16 v6, 0x0

    .line 477
    .line 478
    :goto_b
    invoke-static {v6, v7}, LPa/r0;->f(D)J

    .line 479
    .line 480
    .line 481
    move-result-wide v6

    .line 482
    iput-wide v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->businessAmount:J

    .line 483
    .line 484
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w()Ljava/lang/String;

    .line 485
    .line 486
    .line 487
    move-result-object v6

    .line 488
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->customerId:Ljava/lang/String;

    .line 489
    .line 490
    sget-object v6, Lee/b;->a:Ljava/lang/Object;

    .line 491
    .line 492
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 493
    .line 494
    invoke-static {v6}, Lee/b;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 495
    .line 496
    .line 497
    move-result-object v6

    .line 498
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->transType:Ljava/lang/String;

    .line 499
    .line 500
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 501
    .line 502
    .line 503
    move-result-object v6

    .line 504
    invoke-virtual {v6}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 505
    .line 506
    .line 507
    move-result-object v6

    .line 508
    invoke-virtual {v6}, Lcom/transsnet/palmpay/core/db/entity/User;->getFullName()Ljava/lang/String;

    .line 509
    .line 510
    .line 511
    move-result-object v6

    .line 512
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->fullName:Ljava/lang/String;

    .line 513
    .line 514
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 515
    .line 516
    invoke-static {v6}, Lee/b;->a(Ljava/lang/String;)I

    .line 517
    .line 518
    .line 519
    move-result v6

    .line 520
    iput v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->businessType:I

    .line 521
    .line 522
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->M:Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 523
    .line 524
    if-eqz v6, :cond_1c

    .line 525
    .line 526
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerName:Ljava/lang/String;

    .line 527
    .line 528
    goto :goto_c

    .line 529
    :cond_1c
    move-object v7, v1

    .line 530
    :goto_c
    iput-object v7, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->billerName:Ljava/lang/String;

    .line 531
    .line 532
    if-eqz v6, :cond_1d

    .line 533
    .line 534
    iget-object v6, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerId:Ljava/lang/String;

    .line 535
    .line 536
    goto :goto_d

    .line 537
    :cond_1d
    move-object v6, v1

    .line 538
    :goto_d
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 539
    .line 540
    .line 541
    move-result v6

    .line 542
    if-nez v6, :cond_1f

    .line 543
    .line 544
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->M:Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 545
    .line 546
    if-eqz v6, :cond_1e

    .line 547
    .line 548
    iget-object v6, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerId:Ljava/lang/String;

    .line 549
    .line 550
    goto :goto_e

    .line 551
    :cond_1e
    move-object v6, v1

    .line 552
    :goto_e
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->billerId:Ljava/lang/String;

    .line 553
    .line 554
    goto :goto_11

    .line 555
    :cond_1f
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 556
    .line 557
    if-eqz v6, :cond_20

    .line 558
    .line 559
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 560
    .line 561
    .line 562
    move-result-object v6

    .line 563
    goto :goto_f

    .line 564
    :cond_20
    move-object v6, v1

    .line 565
    :goto_f
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 566
    .line 567
    .line 568
    move-result v6

    .line 569
    if-nez v6, :cond_2c

    .line 570
    .line 571
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 572
    .line 573
    if-eqz v6, :cond_21

    .line 574
    .line 575
    invoke-virtual {v6}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 576
    .line 577
    .line 578
    move-result-object v6

    .line 579
    goto :goto_10

    .line 580
    :cond_21
    move-object v6, v1

    .line 581
    :goto_10
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->billerId:Ljava/lang/String;

    .line 582
    .line 583
    :goto_11
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 584
    .line 585
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->categoryId:Ljava/lang/String;

    .line 586
    .line 587
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->M:Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 588
    .line 589
    if-eqz v6, :cond_22

    .line 590
    .line 591
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->paymentItemId:Ljava/lang/String;

    .line 592
    .line 593
    goto :goto_12

    .line 594
    :cond_22
    move-object v7, v1

    .line 595
    :goto_12
    iput-object v7, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->paymentItemId:Ljava/lang/String;

    .line 596
    .line 597
    if-eqz v6, :cond_23

    .line 598
    .line 599
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->institutionLogo:Ljava/lang/String;

    .line 600
    .line 601
    goto :goto_13

    .line 602
    :cond_23
    move-object v7, v1

    .line 603
    :goto_13
    iput-object v7, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->icon:Ljava/lang/String;

    .line 604
    .line 605
    if-eqz v6, :cond_24

    .line 606
    .line 607
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->paymentItemName:Ljava/lang/String;

    .line 608
    .line 609
    goto :goto_14

    .line 610
    :cond_24
    move-object v7, v1

    .line 611
    :goto_14
    iput-object v7, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->paymentItemName:Ljava/lang/String;

    .line 612
    .line 613
    if-eqz v6, :cond_25

    .line 614
    .line 615
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->paymentItemName:Ljava/lang/String;

    .line 616
    .line 617
    goto :goto_15

    .line 618
    :cond_25
    move-object v7, v1

    .line 619
    :goto_15
    iput-object v7, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->dataBundleItemName:Ljava/lang/String;

    .line 620
    .line 621
    invoke-virtual {v4, v6}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->x(Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;)Ljava/lang/String;

    .line 622
    .line 623
    .line 624
    move-result-object v6

    .line 625
    iput-object v6, v5, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->customerDisplayName:Ljava/lang/String;

    .line 626
    .line 627
    iget-object v6, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 628
    .line 629
    check-cast v6, LRd/l;

    .line 630
    .line 631
    if-eqz v6, :cond_2b

    .line 632
    .line 633
    iget-object v6, v6, LRd/l;->e:Lcom/mikepenz/iconics/view/IconicsCheckBox;

    .line 634
    .line 635
    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 636
    .line 637
    .line 638
    move-result v6

    .line 639
    if-ne v6, v2, :cond_2b

    .line 640
    .line 641
    new-instance v2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;

    .line 642
    .line 643
    invoke-direct {v2}, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;-><init>()V

    .line 644
    .line 645
    .line 646
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w()Ljava/lang/String;

    .line 647
    .line 648
    .line 649
    move-result-object v6

    .line 650
    iput-object v6, v2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->customerId:Ljava/lang/String;

    .line 651
    .line 652
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->M:Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 653
    .line 654
    if-eqz v6, :cond_26

    .line 655
    .line 656
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->paymentItemId:Ljava/lang/String;

    .line 657
    .line 658
    goto :goto_16

    .line 659
    :cond_26
    move-object v7, v1

    .line 660
    :goto_16
    iput-object v7, v2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->itemId:Ljava/lang/String;

    .line 661
    .line 662
    if-eqz v6, :cond_27

    .line 663
    .line 664
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerName:Ljava/lang/String;

    .line 665
    .line 666
    goto :goto_17

    .line 667
    :cond_27
    move-object v7, v1

    .line 668
    :goto_17
    iput-object v7, v2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->billerName:Ljava/lang/String;

    .line 669
    .line 670
    if-eqz v6, :cond_28

    .line 671
    .line 672
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->institutionLogo:Ljava/lang/String;

    .line 673
    .line 674
    goto :goto_18

    .line 675
    :cond_28
    move-object v7, v1

    .line 676
    :goto_18
    iput-object v7, v2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->institutionLogo:Ljava/lang/String;

    .line 677
    .line 678
    iget-object v7, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 679
    .line 680
    iput-object v7, v2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->categoryId:Ljava/lang/String;

    .line 681
    .line 682
    if-eqz v6, :cond_29

    .line 683
    .line 684
    iget-object v7, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->paymentItemName:Ljava/lang/String;

    .line 685
    .line 686
    goto :goto_19

    .line 687
    :cond_29
    move-object v7, v1

    .line 688
    :goto_19
    iput-object v7, v2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->itemName:Ljava/lang/String;

    .line 689
    .line 690
    if-eqz v6, :cond_2a

    .line 691
    .line 692
    iget-object v6, v6, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerId:Ljava/lang/String;

    .line 693
    .line 694
    goto :goto_1a

    .line 695
    :cond_2a
    move-object v6, v1

    .line 696
    :goto_1a
    iput-object v6, v2, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->billerId:Ljava/lang/String;

    .line 697
    .line 698
    iget-object v6, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 699
    .line 700
    check-cast v6, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;

    .line 701
    .line 702
    if-eqz v6, :cond_2b

    .line 703
    .line 704
    new-instance v7, Lfe/G;

    .line 705
    .line 706
    invoke-direct {v7, v2, v1}, Lfe/G;-><init>(Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;Lkotlin/coroutines/Continuation;)V

    .line 707
    .line 708
    .line 709
    iget-object v1, v6, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;->p:Lcom/transsnet/palmpay/core/base/l;

    .line 710
    .line 711
    const/16 v2, 0x1c

    .line 712
    .line 713
    invoke-static {v6, v7, v1, v3, v2}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 714
    .line 715
    .line 716
    :cond_2b
    iget-object v1, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 717
    .line 718
    check-cast v1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;

    .line 719
    .line 720
    if-eqz v1, :cond_2d

    .line 721
    .line 722
    invoke-virtual {v1, v5}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;->d(Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;)V

    .line 723
    .line 724
    .line 725
    goto :goto_1b

    .line 726
    :cond_2c
    sget v1, LPd/f;->qt_select_biller_to_pay:I

    .line 727
    .line 728
    invoke-virtual {v4, v1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 729
    .line 730
    .line 731
    move-result-object v1

    .line 732
    invoke-static {v4, v1}, Loa/h;->y(Landroidx/fragment/app/Fragment;Ljava/lang/String;)V

    .line 733
    .line 734
    .line 735
    :cond_2d
    :goto_1b
    return-void

    .line 736
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 737
    .line 738
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 739
    .line 740
    .line 741
    move-result-object v1

    .line 742
    const-string v2, "/quick_teller/betting_beneficiaries"

    .line 743
    .line 744
    invoke-virtual {v1, v2}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 745
    .line 746
    .line 747
    move-result-object v1

    .line 748
    iget-object v2, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 749
    .line 750
    const-string v3, "KEY_CATEGORY_ID"

    .line 751
    .line 752
    invoke-virtual {v1, v3, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 753
    .line 754
    .line 755
    move-result-object v1

    .line 756
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 757
    .line 758
    .line 759
    move-result-object v2

    .line 760
    const-string v3, "getInstance(...)"

    .line 761
    .line 762
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 763
    .line 764
    .line 765
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 766
    .line 767
    .line 768
    const/16 v3, 0x65

    .line 769
    .line 770
    invoke-static {v2, v4, v1, v3}, LPa/r0;->x(Lcom/alibaba/android/arouter/launcher/ARouter;Landroidx/fragment/app/Fragment;Lcom/alibaba/android/arouter/facade/Postcard;I)V

    .line 771
    .line 772
    .line 773
    return-void

    .line 774
    :pswitch_1
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 775
    .line 776
    if-nez v5, :cond_2e

    .line 777
    .line 778
    iget-object v1, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 779
    .line 780
    check-cast v1, LRd/l;

    .line 781
    .line 782
    if-eqz v1, :cond_31

    .line 783
    .line 784
    iget-object v1, v1, LRd/l;->i:Lcom/transsnet/palmpay/custom_view/ModelItemSelection;

    .line 785
    .line 786
    sget v2, LPd/f;->qt_msg_select_biller_first:I

    .line 787
    .line 788
    invoke-virtual {v4, v2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 789
    .line 790
    .line 791
    move-result-object v2

    .line 792
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/custom_view/ModelItemSelection;->e(Ljava/lang/String;)V

    .line 793
    .line 794
    .line 795
    goto :goto_1c

    .line 796
    :cond_2e
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->H:Ljava/util/ArrayList;

    .line 797
    .line 798
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    .line 799
    .line 800
    .line 801
    move-result v5

    .line 802
    if-eqz v5, :cond_30

    .line 803
    .line 804
    iget-object v5, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 805
    .line 806
    check-cast v5, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;

    .line 807
    .line 808
    if-eqz v5, :cond_31

    .line 809
    .line 810
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 811
    .line 812
    iget-object v4, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->L:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 813
    .line 814
    if-eqz v4, :cond_2f

    .line 815
    .line 816
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 817
    .line 818
    .line 819
    move-result-object v1

    .line 820
    :cond_2f
    invoke-virtual {v5, v2, v3, v6, v1}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;->f(ZZLjava/lang/String;Ljava/lang/String;)V

    .line 821
    .line 822
    .line 823
    goto :goto_1c

    .line 824
    :cond_30
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->G()V

    .line 825
    .line 826
    .line 827
    :cond_31
    :goto_1c
    return-void

    .line 828
    :pswitch_2
    iget-object v1, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->C:Ljava/util/ArrayList;

    .line 829
    .line 830
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 831
    .line 832
    .line 833
    move-result v1

    .line 834
    if-eqz v1, :cond_32

    .line 835
    .line 836
    iget-object v1, v4, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 837
    .line 838
    check-cast v1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;

    .line 839
    .line 840
    if-eqz v1, :cond_33

    .line 841
    .line 842
    iget-object v4, v4, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 843
    .line 844
    invoke-virtual {v1, v4, v2, v3}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;->e(Ljava/lang/String;ZZ)V

    .line 845
    .line 846
    .line 847
    goto :goto_1d

    .line 848
    :cond_32
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->F()V

    .line 849
    .line 850
    .line 851
    :cond_33
    :goto_1d
    return-void

    .line 852
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 853
    .line 854
    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 855
    .line 856
    .line 857
    move-result-object v1

    .line 858
    const-string v2, "null cannot be cast to non-null type com.transsnet.palmpay.teller.ui.activity.BillPaymentHomeActivity"

    .line 859
    .line 860
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 861
    .line 862
    .line 863
    check-cast v1, Lcom/transsnet/palmpay/teller/ui/activity/BillPaymentHomeActivity;

    .line 864
    .line 865
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->goBackToHome()V

    .line 866
    .line 867
    .line 868
    return-void

    .line 869
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
