.class public final synthetic LZd/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/chad/library/adapter/base/listener/OnLoadMoreListener;
.implements Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout$OnRefreshListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;)V
    .locals 0

    .line 1
    iput-object p1, p0, LZd/c;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLoadMore()V
    .locals 6

    .line 1
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;->v:I

    .line 2
    .line 3
    iget-object v0, p0, LZd/c;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;

    .line 4
    .line 5
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 6
    .line 7
    check-cast v1, Lcom/transsnet/palmpay/teller/viewmodel/BillerHistoryViewModel;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    iget-object v1, v1, Lcom/transsnet/palmpay/teller/viewmodel/BillerHistoryViewModel;->e:Lcom/transsnet/palmpay/core/base/l;

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    invoke-virtual {v1}, Landroidx/lifecycle/B;->d()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Lcom/transsnet/palmpay/core/base/q;

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    move-object v1, v2

    .line 24
    :goto_0
    sget-object v3, Lcom/transsnet/palmpay/core/base/o;->a:Lcom/transsnet/palmpay/core/base/o;

    .line 25
    .line 26
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_1

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_1
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 34
    .line 35
    check-cast v1, Lcom/transsnet/palmpay/teller/viewmodel/BillerHistoryViewModel;

    .line 36
    .line 37
    if-eqz v1, :cond_2

    .line 38
    .line 39
    new-instance v3, Lcom/transsnet/palmpay/teller/bean/HistoryOrderReq;

    .line 40
    .line 41
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;->v()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v4

    .line 45
    iget v5, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;->t:I

    .line 46
    .line 47
    add-int/lit8 v5, v5, 0x1

    .line 48
    .line 49
    iput v5, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;->t:I

    .line 50
    .line 51
    iget-object v0, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;->p:Lxf/t;

    .line 52
    .line 53
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    check-cast v0, Ljava/lang/Number;

    .line 58
    .line 59
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    invoke-direct {v3, v4, v5, v0}, Lcom/transsnet/palmpay/teller/bean/HistoryOrderReq;-><init>(Ljava/lang/String;II)V

    .line 64
    .line 65
    .line 66
    const-string v0, "req"

    .line 67
    .line 68
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    new-instance v0, Lfe/G0;

    .line 72
    .line 73
    invoke-direct {v0, v3, v2}, Lfe/G0;-><init>(Lcom/transsnet/palmpay/teller/bean/HistoryOrderReq;Lkotlin/coroutines/Continuation;)V

    .line 74
    .line 75
    .line 76
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 77
    .line 78
    iget-object v3, v1, Lcom/transsnet/palmpay/teller/viewmodel/BillerHistoryViewModel;->e:Lcom/transsnet/palmpay/core/base/l;

    .line 79
    .line 80
    iput-object v2, v3, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 81
    .line 82
    sget-object v2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 83
    .line 84
    const-wide/16 v4, 0x0

    .line 85
    .line 86
    invoke-static {v1, v0, v3, v4, v5}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 87
    .line 88
    .line 89
    :cond_2
    :goto_1
    return-void
.end method

.method public onRefresh()V
    .locals 1

    .line 1
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;->v:I

    .line 2
    .line 3
    iget-object v0, p0, LZd/c;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;

    .line 4
    .line 5
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BaseBillerHistoryFragment;->x()V

    .line 6
    .line 7
    .line 8
    return-void
.end method
