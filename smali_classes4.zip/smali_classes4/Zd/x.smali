.class public final LZd/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/x;->a:I

    iput-object p1, p0, LZd/x;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;)V
    .locals 0

    const/4 p1, 0x3

    iput p1, p0, LZd/x;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LZd/x;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, LZd/x;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 23
    .line 24
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;

    .line 27
    .line 28
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_3

    .line 33
    .line 34
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;->data:Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;

    .line 35
    .line 36
    if-eqz p1, :cond_3

    .line 37
    .line 38
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMinAmount()J

    .line 39
    .line 40
    .line 41
    move-result-wide v0

    .line 42
    iget-object v2, p0, LZd/x;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 43
    .line 44
    iput-wide v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->s0:J

    .line 45
    .line 46
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMaxAmount()J

    .line 47
    .line 48
    .line 49
    move-result-wide v0

    .line 50
    iput-wide v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->r0:J

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_1
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 54
    .line 55
    if-eqz v0, :cond_2

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_2
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 59
    .line 60
    if-eqz v0, :cond_4

    .line 61
    .line 62
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 63
    .line 64
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 65
    .line 66
    const/4 v0, 0x0

    .line 67
    new-array v0, v0, [Ljava/lang/Object;

    .line 68
    .line 69
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    :cond_3
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 73
    .line 74
    return-object p1

    .line 75
    :cond_4
    new-instance p1, Lxf/l;

    .line 76
    .line 77
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 78
    .line 79
    .line 80
    throw p1

    .line 81
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 82
    .line 83
    const-string v0, "it"

    .line 84
    .line 85
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 89
    .line 90
    iget-object v1, p0, LZd/x;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 91
    .line 92
    const/4 v2, 0x1

    .line 93
    if-eqz v0, :cond_5

    .line 94
    .line 95
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 96
    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_5
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 100
    .line 101
    const-string v3, "/main/trans_history"

    .line 102
    .line 103
    const-string v4, ""

    .line 104
    .line 105
    const/4 v5, 0x0

    .line 106
    if-eqz v0, :cond_7

    .line 107
    .line 108
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 109
    .line 110
    .line 111
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 112
    .line 113
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 116
    .line 117
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 122
    .line 123
    check-cast p1, Ljava/util/ArrayList;

    .line 124
    .line 125
    if-eqz p1, :cond_6

    .line 126
    .line 127
    move-object v4, p1

    .line 128
    :cond_6
    iget-object p1, v0, LPa/w;->b:Ljava/lang/Object;

    .line 129
    .line 130
    check-cast p1, Lcom/google/gson/Gson;

    .line 131
    .line 132
    invoke-virtual {p1, v4}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    invoke-static {v3, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->G(Ljava/lang/String;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    goto :goto_1

    .line 140
    :cond_7
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 141
    .line 142
    if-eqz v0, :cond_8

    .line 143
    .line 144
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 145
    .line 146
    .line 147
    goto :goto_1

    .line 148
    :cond_8
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 149
    .line 150
    if-eqz v0, :cond_9

    .line 151
    .line 152
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 153
    .line 154
    .line 155
    move-object v0, p1

    .line 156
    check-cast v0, Lcom/transsnet/palmpay/core/base/n;

    .line 157
    .line 158
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 159
    .line 160
    new-array v1, v5, [Ljava/lang/Object;

    .line 161
    .line 162
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 166
    .line 167
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    .line 169
    .line 170
    invoke-static {v3, v4}, Lcom/palmpay/lib/apm/launchcounter/util/d;->G(Ljava/lang/String;Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 174
    .line 175
    return-object p1

    .line 176
    :cond_9
    new-instance p1, Lxf/l;

    .line 177
    .line 178
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 179
    .line 180
    .line 181
    throw p1

    .line 182
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 183
    .line 184
    const-string v0, "it"

    .line 185
    .line 186
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 190
    .line 191
    if-nez v0, :cond_e

    .line 192
    .line 193
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 194
    .line 195
    if-eqz v0, :cond_b

    .line 196
    .line 197
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 198
    .line 199
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 200
    .line 201
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/resp/QueryAccountHistoryResp;

    .line 202
    .line 203
    iget-object v0, p0, LZd/x;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 204
    .line 205
    iget-object v1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->A:Ljava/util/ArrayList;

    .line 206
    .line 207
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 208
    .line 209
    .line 210
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/QueryAccountHistoryResp;->getData()Ljava/util/List;

    .line 211
    .line 212
    .line 213
    move-result-object p1

    .line 214
    if-eqz p1, :cond_a

    .line 215
    .line 216
    iget-object v1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->A:Ljava/util/ArrayList;

    .line 217
    .line 218
    check-cast p1, Ljava/util/Collection;

    .line 219
    .line 220
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 221
    .line 222
    .line 223
    :cond_a
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 224
    .line 225
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->G(Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;)V

    .line 226
    .line 227
    .line 228
    goto :goto_2

    .line 229
    :cond_b
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 230
    .line 231
    if-eqz v0, :cond_c

    .line 232
    .line 233
    goto :goto_2

    .line 234
    :cond_c
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 235
    .line 236
    if-eqz v0, :cond_d

    .line 237
    .line 238
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 239
    .line 240
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 241
    .line 242
    const/4 v0, 0x0

    .line 243
    new-array v0, v0, [Ljava/lang/Object;

    .line 244
    .line 245
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    goto :goto_2

    .line 249
    :cond_d
    new-instance p1, Lxf/l;

    .line 250
    .line 251
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 252
    .line 253
    .line 254
    throw p1

    .line 255
    :cond_e
    :goto_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 256
    .line 257
    return-object p1

    .line 258
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 259
    .line 260
    const-string v0, "it"

    .line 261
    .line 262
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 263
    .line 264
    .line 265
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 266
    .line 267
    if-nez v0, :cond_19

    .line 268
    .line 269
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 270
    .line 271
    const/4 v1, 0x0

    .line 272
    if-eqz v0, :cond_16

    .line 273
    .line 274
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 275
    .line 276
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 277
    .line 278
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp;

    .line 279
    .line 280
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 281
    .line 282
    .line 283
    move-result v0

    .line 284
    if-eqz v0, :cond_15

    .line 285
    .line 286
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp;->getData()Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;

    .line 287
    .line 288
    .line 289
    move-result-object p1

    .line 290
    iget-object v0, p0, LZd/x;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 291
    .line 292
    const/4 v2, 0x0

    .line 293
    if-eqz p1, :cond_12

    .line 294
    .line 295
    iget-object v3, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Q:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 296
    .line 297
    if-eqz v3, :cond_f

    .line 298
    .line 299
    invoke-virtual {v3}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object v3

    .line 303
    goto :goto_3

    .line 304
    :cond_f
    move-object v3, v2

    .line 305
    :goto_3
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 306
    .line 307
    .line 308
    move-result v3

    .line 309
    if-nez v3, :cond_11

    .line 310
    .line 311
    iget-object v3, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Q:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 312
    .line 313
    if-eqz v3, :cond_10

    .line 314
    .line 315
    invoke-virtual {v3}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 316
    .line 317
    .line 318
    move-result-object v2

    .line 319
    :cond_10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getBillerId()Ljava/lang/String;

    .line 320
    .line 321
    .line 322
    move-result-object v3

    .line 323
    invoke-static {v2, v3, v1}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 324
    .line 325
    .line 326
    move-result v1

    .line 327
    if-nez v1, :cond_11

    .line 328
    .line 329
    goto :goto_4

    .line 330
    :cond_11
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getBillerId()Ljava/lang/String;

    .line 331
    .line 332
    .line 333
    move-result-object v1

    .line 334
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getCustomerId()Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object p1

    .line 338
    invoke-static {v0, v1, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->D(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;Ljava/lang/String;Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    goto :goto_4

    .line 342
    :cond_12
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Q:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 343
    .line 344
    if-eqz p1, :cond_13

    .line 345
    .line 346
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object v2

    .line 350
    :cond_13
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 351
    .line 352
    .line 353
    move-result p1

    .line 354
    if-nez p1, :cond_14

    .line 355
    .line 356
    goto :goto_4

    .line 357
    :cond_14
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Y:Ljava/util/ArrayList;

    .line 358
    .line 359
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 360
    .line 361
    .line 362
    move-result p1

    .line 363
    if-nez p1, :cond_19

    .line 364
    .line 365
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Y:Ljava/util/ArrayList;

    .line 366
    .line 367
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object p1

    .line 371
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 372
    .line 373
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 374
    .line 375
    .line 376
    move-result-object p1

    .line 377
    const-string v1, ""

    .line 378
    .line 379
    invoke-static {v0, p1, v1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->D(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;Ljava/lang/String;Ljava/lang/String;)V

    .line 380
    .line 381
    .line 382
    goto :goto_4

    .line 383
    :cond_15
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 384
    .line 385
    .line 386
    move-result-object p1

    .line 387
    new-array v0, v1, [Ljava/lang/Object;

    .line 388
    .line 389
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 390
    .line 391
    .line 392
    goto :goto_4

    .line 393
    :cond_16
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 394
    .line 395
    if-eqz v0, :cond_17

    .line 396
    .line 397
    goto :goto_4

    .line 398
    :cond_17
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 399
    .line 400
    if-eqz v0, :cond_18

    .line 401
    .line 402
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 403
    .line 404
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 405
    .line 406
    new-array v0, v1, [Ljava/lang/Object;

    .line 407
    .line 408
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 409
    .line 410
    .line 411
    goto :goto_4

    .line 412
    :cond_18
    new-instance p1, Lxf/l;

    .line 413
    .line 414
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 415
    .line 416
    .line 417
    throw p1

    .line 418
    :cond_19
    :goto_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 419
    .line 420
    return-object p1

    .line 421
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
