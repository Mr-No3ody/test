.class public final LZd/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/base/l;

.field public final synthetic c:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/core/base/l;Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;I)V
    .locals 0

    .line 1
    iput p3, p0, LZd/y;->a:I

    iput-object p1, p0, LZd/y;->b:Lcom/transsnet/palmpay/core/base/l;

    iput-object p2, p0, LZd/y;->c:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, LZd/y;->c:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 2
    .line 3
    iget-object v1, p0, LZd/y;->b:Lcom/transsnet/palmpay/core/base/l;

    .line 4
    .line 5
    const-string v2, "it"

    .line 6
    .line 7
    iget v3, p0, LZd/y;->a:I

    .line 8
    .line 9
    packed-switch v3, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 13
    .line 14
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 18
    .line 19
    if-nez v2, :cond_3

    .line 20
    .line 21
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 22
    .line 23
    if-eqz v2, :cond_1

    .line 24
    .line 25
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 28
    .line 29
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/TvItemTipsResp;

    .line 32
    .line 33
    check-cast v1, Ljava/lang/String;

    .line 34
    .line 35
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_3

    .line 40
    .line 41
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvItemTipsResp;->getData()Ljava/util/ArrayList;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    if-eqz v2, :cond_3

    .line 46
    .line 47
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 48
    .line 49
    .line 50
    move-result v2

    .line 51
    if-nez v2, :cond_3

    .line 52
    .line 53
    iget-object v0, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->q0:Landroidx/lifecycle/b0;

    .line 54
    .line 55
    invoke-virtual {v0}, Landroidx/lifecycle/b0;->getValue()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    check-cast v0, Lfe/U0;

    .line 60
    .line 61
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvItemTipsResp;->getData()Ljava/util/ArrayList;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 72
    .line 73
    .line 74
    const-string v2, "operatorId"

    .line 75
    .line 76
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    const-string v2, "cacheData"

    .line 80
    .line 81
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    iget-object v0, v0, Lfe/U0;->d:Landroidx/lifecycle/F;

    .line 85
    .line 86
    invoke-virtual {v0}, Landroidx/lifecycle/B;->d()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    check-cast v2, Ljava/util/Map;

    .line 91
    .line 92
    if-nez v2, :cond_0

    .line 93
    .line 94
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 95
    .line 96
    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 97
    .line 98
    .line 99
    :cond_0
    invoke-interface {v2, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    invoke-virtual {v0, v2}, Landroidx/lifecycle/B;->k(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    goto :goto_0

    .line 106
    :cond_1
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 107
    .line 108
    if-nez v0, :cond_3

    .line 109
    .line 110
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 111
    .line 112
    if-eqz v0, :cond_2

    .line 113
    .line 114
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 115
    .line 116
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_2
    new-instance p1, Lxf/l;

    .line 121
    .line 122
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 123
    .line 124
    .line 125
    throw p1

    .line 126
    :cond_3
    :goto_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 127
    .line 128
    return-object p1

    .line 129
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 130
    .line 131
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 135
    .line 136
    if-nez v2, :cond_7

    .line 137
    .line 138
    instance-of v2, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 139
    .line 140
    const/4 v3, 0x0

    .line 141
    if-eqz v2, :cond_5

    .line 142
    .line 143
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 146
    .line 147
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 148
    .line 149
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/resp/QueryCustomerIdIsExitResp;

    .line 150
    .line 151
    check-cast v1, Ljava/lang/String;

    .line 152
    .line 153
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 154
    .line 155
    .line 156
    move-result v2

    .line 157
    if-eqz v2, :cond_4

    .line 158
    .line 159
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/QueryCustomerIdIsExitResp;->getData()Lcom/transsnet/palmpay/teller/bean/resp/QueryCustomerIdIsExitResp$DataBean;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    if-eqz v2, :cond_4

    .line 164
    .line 165
    if-eqz v1, :cond_7

    .line 166
    .line 167
    iget-object v2, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->t0:Ljava/util/HashMap;

    .line 168
    .line 169
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/QueryCustomerIdIsExitResp;->getData()Lcom/transsnet/palmpay/teller/bean/resp/QueryCustomerIdIsExitResp$DataBean;

    .line 170
    .line 171
    .line 172
    move-result-object v3

    .line 173
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v2, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/resp/QueryCustomerIdIsExitResp;->getData()Lcom/transsnet/palmpay/teller/bean/resp/QueryCustomerIdIsExitResp$DataBean;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    invoke-virtual {v0, v1, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->w(Ljava/lang/String;Lcom/transsnet/palmpay/teller/bean/resp/QueryCustomerIdIsExitResp$DataBean;)V

    .line 184
    .line 185
    .line 186
    goto :goto_1

    .line 187
    :cond_4
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 188
    .line 189
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->z()Landroidx/swiperefreshlayout/widget/c;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    invoke-virtual {p1}, Landroidx/swiperefreshlayout/widget/c;->stop()V

    .line 194
    .line 195
    .line 196
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 197
    .line 198
    check-cast p1, LRd/g0;

    .line 199
    .line 200
    if-eqz p1, :cond_7

    .line 201
    .line 202
    iget-object p1, p1, LRd/g0;->o:Landroid/widget/LinearLayout;

    .line 203
    .line 204
    if-eqz p1, :cond_7

    .line 205
    .line 206
    invoke-static {p1, v3}, Loa/h;->s(Landroid/view/View;Z)V

    .line 207
    .line 208
    .line 209
    goto :goto_1

    .line 210
    :cond_5
    instance-of v1, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 211
    .line 212
    if-nez v1, :cond_7

    .line 213
    .line 214
    instance-of v1, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 215
    .line 216
    if-eqz v1, :cond_6

    .line 217
    .line 218
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 219
    .line 220
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 221
    .line 222
    .line 223
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 224
    .line 225
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->z()Landroidx/swiperefreshlayout/widget/c;

    .line 226
    .line 227
    .line 228
    move-result-object p1

    .line 229
    invoke-virtual {p1}, Landroidx/swiperefreshlayout/widget/c;->stop()V

    .line 230
    .line 231
    .line 232
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 233
    .line 234
    check-cast p1, LRd/g0;

    .line 235
    .line 236
    if-eqz p1, :cond_7

    .line 237
    .line 238
    iget-object p1, p1, LRd/g0;->o:Landroid/widget/LinearLayout;

    .line 239
    .line 240
    if-eqz p1, :cond_7

    .line 241
    .line 242
    invoke-static {p1, v3}, Loa/h;->s(Landroid/view/View;Z)V

    .line 243
    .line 244
    .line 245
    goto :goto_1

    .line 246
    :cond_6
    new-instance p1, Lxf/l;

    .line 247
    .line 248
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 249
    .line 250
    .line 251
    throw p1

    .line 252
    :cond_7
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 253
    .line 254
    return-object p1

    .line 255
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
