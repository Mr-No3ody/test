.class public final synthetic LZd/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;
.implements Lcom/palmpay/lib/ui/edit/PpAmountEditText$OnTextInputListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;)V
    .locals 0

    .line 1
    iput-object p1, p0, LZd/g;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public OnTextInput(Ljava/lang/String;)V
    .locals 0

    .line 1
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 2
    .line 3
    iget-object p1, p0, LZd/g;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 4
    .line 5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Q()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 3

    .line 1
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 2
    .line 3
    const-string v0, "<unused var>"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    if-nez p1, :cond_0

    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    invoke-static {p1, p1}, LPa/i0;->K(Ljava/lang/String;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    invoke-static {}, LPa/r0;->U0()Z

    .line 23
    .line 24
    .line 25
    move-result p1

    .line 26
    if-eqz p1, :cond_1

    .line 27
    .line 28
    return-void

    .line 29
    :cond_1
    iget-object p1, p0, LZd/g;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 30
    .line 31
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->D()LXd/c;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    invoke-virtual {p2, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/PaymentAmountItemBean;

    .line 40
    .line 41
    iget-object v0, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 42
    .line 43
    check-cast v0, LRd/f0;

    .line 44
    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    iget-object v0, v0, LRd/f0;->g:Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 48
    .line 49
    iget-wide v1, p2, Lcom/transsnet/palmpay/teller/bean/PaymentAmountItemBean;->price:J

    .line 50
    .line 51
    invoke-static {v1, v2}, LPa/r0;->A(J)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    invoke-virtual {v0, v1}, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->setAmount(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    :cond_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->D()LXd/c;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iput p3, v0, LXd/c;->a:I

    .line 63
    .line 64
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 65
    .line 66
    .line 67
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 68
    .line 69
    .line 70
    move-result-object p3

    .line 71
    iget-wide v0, p2, Lcom/transsnet/palmpay/teller/bean/PaymentAmountItemBean;->price:J

    .line 72
    .line 73
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object p2

    .line 77
    const-string v0, "ElectriCityClick"

    .line 78
    .line 79
    const-string v1, "SelectAmount"

    .line 80
    .line 81
    invoke-virtual {p3, v0, v1, p2}, LPa/n0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->E()V

    .line 85
    .line 86
    .line 87
    return-void
.end method
