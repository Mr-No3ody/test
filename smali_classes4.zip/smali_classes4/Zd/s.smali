.class public final synthetic LZd/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/s;->a:I

    iput-object p1, p0, LZd/s;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    iget-object p1, p0, LZd/s;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 2
    .line 3
    iget v0, p0, LZd/s;->a:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 9
    .line 10
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-string v1, "/quick_teller/betting_beneficiaries"

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget-object v1, p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->L:Ljava/lang/String;

    .line 21
    .line 22
    const-string v2, "KEY_CATEGORY_ID"

    .line 23
    .line 24
    invoke-virtual {v0, v2, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    const-string v2, "getInstance(...)"

    .line 33
    .line 34
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    const/16 v2, 0x65

    .line 41
    .line 42
    invoke-static {v1, p1, v0, v2}, LPa/r0;->x(Lcom/alibaba/android/arouter/launcher/ARouter;Landroidx/fragment/app/Fragment;Lcom/alibaba/android/arouter/facade/Postcard;I)V

    .line 43
    .line 44
    .line 45
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    const-string v0, "PPay_TV_Btn_Contact"

    .line 50
    .line 51
    invoke-virtual {p1, v0}, LPa/n0;->l(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :pswitch_0
    iget-object v0, p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Y:Ljava/util/ArrayList;

    .line 56
    .line 57
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_0

    .line 62
    .line 63
    iget-object v0, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 64
    .line 65
    check-cast v0, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;

    .line 66
    .line 67
    if-eqz v0, :cond_1

    .line 68
    .line 69
    iget-object p1, p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->L:Ljava/lang/String;

    .line 70
    .line 71
    const/4 v1, 0x0

    .line 72
    const/4 v2, 0x1

    .line 73
    invoke-virtual {v0, p1, v2, v1}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;->d(Ljava/lang/String;ZZ)V

    .line 74
    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->E()V

    .line 78
    .line 79
    .line 80
    :cond_1
    :goto_0
    return-void

    .line 81
    :pswitch_1
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 82
    .line 83
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    const/4 v1, 0x0

    .line 88
    if-nez v0, :cond_2

    .line 89
    .line 90
    invoke-static {v1, v1}, LPa/i0;->K(Ljava/lang/String;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    goto :goto_1

    .line 94
    :cond_2
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 95
    .line 96
    check-cast p1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;

    .line 97
    .line 98
    if-eqz p1, :cond_3

    .line 99
    .line 100
    const-string v0, "17"

    .line 101
    .line 102
    filled-new-array {v0}, [Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-static {v0}, Lkotlin/collections/q;->e([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    const-string v2, "transType"

    .line 111
    .line 112
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    new-instance v2, Ljava/lang/StringBuilder;

    .line 116
    .line 117
    const-string v3, "queryTransactionLinkVM_"

    .line 118
    .line 119
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v3

    .line 133
    const-string v4, "Pref_"

    .line 134
    .line 135
    const-string v5, "_"

    .line 136
    .line 137
    invoke-static {v4, v2, v5, v3}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    invoke-static {p1}, Landroidx/lifecycle/V;->h(Landroidx/lifecycle/a0;)Lkotlinx/coroutines/CoroutineScope;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    new-instance v4, Lfe/A0;

    .line 146
    .line 147
    iget-object p1, p1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeTvViewModel;->w:Lcom/transsnet/palmpay/core/base/l;

    .line 148
    .line 149
    invoke-direct {v4, p1, v2, v1, v0}, Lfe/A0;-><init>(Lcom/transsnet/palmpay/core/base/l;Ljava/lang/String;Lkotlin/coroutines/Continuation;Ljava/util/ArrayList;)V

    .line 150
    .line 151
    .line 152
    const/4 p1, 0x3

    .line 153
    invoke-static {v3, v1, v1, v4, p1}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 154
    .line 155
    .line 156
    :cond_3
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    const-string v0, "PPay_TV_Btn_TransHistory"

    .line 161
    .line 162
    invoke-virtual {p1, v0}, LPa/n0;->l(Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    :goto_1
    return-void

    .line 166
    :pswitch_2
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 167
    .line 168
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    const-string v0, "null cannot be cast to non-null type com.transsnet.palmpay.teller.ui.activity.BillPaymentHomeActivity"

    .line 173
    .line 174
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    check-cast p1, Lcom/transsnet/palmpay/teller/ui/activity/BillPaymentHomeActivity;

    .line 178
    .line 179
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->goBackToHome()V

    .line 180
    .line 181
    .line 182
    return-void

    .line 183
    :pswitch_3
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 184
    .line 185
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    invoke-static {p1}, Lcom/transsnet/palmpay/util/KeyboardUtils;->hideSoftInput(Landroid/app/Activity;)V

    .line 190
    .line 191
    .line 192
    return-void

    .line 193
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
