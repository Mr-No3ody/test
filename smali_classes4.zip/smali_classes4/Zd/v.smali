.class public final synthetic LZd/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/v;->a:I

    iput-object p1, p0, LZd/v;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, LZd/v;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 2
    .line 3
    iget v1, p0, LZd/v;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Ljava/lang/Integer;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 11
    .line 12
    .line 13
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 14
    .line 15
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 16
    .line 17
    check-cast p1, LRd/g0;

    .line 18
    .line 19
    if-eqz p1, :cond_0

    .line 20
    .line 21
    iget-object p1, p1, LRd/g0;->v:Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;

    .line 22
    .line 23
    if-eqz p1, :cond_0

    .line 24
    .line 25
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;->getNumberEdit()Landroidx/appcompat/widget/AppCompatAutoCompleteTextView;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    if-eqz p1, :cond_0

    .line 30
    .line 31
    invoke-virtual {p1}, Landroid/view/View;->clearFocus()V

    .line 32
    .line 33
    .line 34
    :cond_0
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 35
    .line 36
    return-object p1

    .line 37
    :pswitch_0
    check-cast p1, Ljava/lang/String;

    .line 38
    .line 39
    sget v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 40
    .line 41
    const-string v1, "errorMsg"

    .line 42
    .line 43
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    const/4 p1, 0x0

    .line 47
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->F(Z)V

    .line 48
    .line 49
    .line 50
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 51
    .line 52
    return-object p1

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
