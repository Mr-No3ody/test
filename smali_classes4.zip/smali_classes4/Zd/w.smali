.class public final synthetic LZd/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/fragment/app/FragmentResultListener;
.implements Lcom/google/android/material/tabs/TabLayoutMediator$TabConfigurationStrategy;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;)V
    .locals 0

    .line 1
    iput-object p1, p0, LZd/w;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onConfigureTab(Lcom/google/android/material/tabs/TabLayout$Tab;I)V
    .locals 1

    .line 1
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 2
    .line 3
    const-string v0, "tab"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LZd/w;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 9
    .line 10
    iget-object v0, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->B:Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-static {p2, v0}, Lkotlin/collections/CollectionsKt;->G(ILjava/util/List;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p2

    .line 16
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;

    .line 17
    .line 18
    if-eqz p2, :cond_0

    .line 19
    .line 20
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;->getBusinessCategoryName()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p2

    .line 24
    if-nez p2, :cond_1

    .line 25
    .line 26
    :cond_0
    const-string p2, ""

    .line 27
    .line 28
    :cond_1
    invoke-virtual {p1, p2}, Lcom/google/android/material/tabs/TabLayout$Tab;->setText(Ljava/lang/CharSequence;)Lcom/google/android/material/tabs/TabLayout$Tab;

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public onFragmentResult(Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 13

    .line 1
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 2
    .line 3
    const-string v0, "<unused var>"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string p1, "bundle"

    .line 9
    .line 10
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, LZd/w;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->A()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    const/4 v1, 0x1

    .line 24
    if-eqz p1, :cond_1

    .line 25
    .line 26
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 27
    .line 28
    check-cast p1, LRd/g0;

    .line 29
    .line 30
    if-eqz p1, :cond_0

    .line 31
    .line 32
    iget-object p1, p1, LRd/g0;->c:Lcom/google/android/material/appbar/AppBarLayout;

    .line 33
    .line 34
    invoke-virtual {p1, v1, v1}, Lcom/google/android/material/appbar/AppBarLayout;->setExpanded(ZZ)V

    .line 35
    .line 36
    .line 37
    :cond_0
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 38
    .line 39
    check-cast p1, LRd/g0;

    .line 40
    .line 41
    if-eqz p1, :cond_1d

    .line 42
    .line 43
    iget-object p1, p1, LRd/g0;->v:Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;

    .line 44
    .line 45
    sget p2, Lcom/transsnet/palmpay/custom_view/v;->cv_msg_enter_smartcard_number:I

    .line 46
    .line 47
    invoke-virtual {v0, p2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p2

    .line 51
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;->setErrorMessage(Ljava/lang/CharSequence;)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :cond_1
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 56
    .line 57
    if-nez p1, :cond_2

    .line 58
    .line 59
    iget-object p1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 60
    .line 61
    check-cast p1, LRd/g0;

    .line 62
    .line 63
    if-eqz p1, :cond_1d

    .line 64
    .line 65
    iget-object p1, p1, LRd/g0;->H:Lcom/transsnet/palmpay/custom_view/ModelItemSelection;

    .line 66
    .line 67
    sget p2, LPd/f;->qt_service_temporarily_unavailable:I

    .line 68
    .line 69
    invoke-virtual {v0, p2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object p2

    .line 73
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/custom_view/ModelItemSelection;->e(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :cond_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getStatus()Ljava/lang/Integer;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    const-string v6, ""

    .line 82
    .line 83
    if-nez v2, :cond_3

    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_3
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    if-eq v2, v1, :cond_5

    .line 91
    .line 92
    :goto_0
    iget-object p2, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 93
    .line 94
    check-cast p2, LRd/g0;

    .line 95
    .line 96
    if-eqz p2, :cond_1d

    .line 97
    .line 98
    iget-object p2, p2, LRd/g0;->H:Lcom/transsnet/palmpay/custom_view/ModelItemSelection;

    .line 99
    .line 100
    sget v1, LPd/f;->qt_service_temporarily_unavailable_3:I

    .line 101
    .line 102
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    if-nez p1, :cond_4

    .line 107
    .line 108
    goto :goto_1

    .line 109
    :cond_4
    move-object v6, p1

    .line 110
    :goto_1
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    invoke-virtual {v0, v1, p1}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    invoke-virtual {p2, p1}, Lcom/transsnet/palmpay/custom_view/ModelItemSelection;->e(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    return-void

    .line 122
    :cond_5
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 123
    .line 124
    if-eqz p1, :cond_6

    .line 125
    .line 126
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    if-nez p1, :cond_7

    .line 131
    .line 132
    :cond_6
    move-object p1, v6

    .line 133
    :cond_7
    const-string v1, "DATA_KEY_BILLER_ID"

    .line 134
    .line 135
    invoke-virtual {p2, v1, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 140
    .line 141
    if-eqz p1, :cond_8

    .line 142
    .line 143
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerName()Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object p1

    .line 147
    if-nez p1, :cond_9

    .line 148
    .line 149
    :cond_8
    move-object p1, v6

    .line 150
    :cond_9
    const-string v2, "DATA_KEY_BILLER_NAME"

    .line 151
    .line 152
    invoke-virtual {p2, v2, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    new-instance v4, Lkotlin/jvm/internal/F;

    .line 157
    .line 158
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 159
    .line 160
    .line 161
    const-string p1, "DATA_KEY_PAYMENT_ITEM"

    .line 162
    .line 163
    invoke-virtual {p2, p1, v6}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object p1

    .line 167
    const/4 p2, 0x0

    .line 168
    if-eqz p1, :cond_a

    .line 169
    .line 170
    const-class v3, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 171
    .line 172
    invoke-static {v3, p1}, Lcom/horcrux/svg/d0;->l(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object p1

    .line 176
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 177
    .line 178
    goto :goto_2

    .line 179
    :cond_a
    move-object p1, p2

    .line 180
    :goto_2
    iput-object p1, v4, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 181
    .line 182
    if-eqz p1, :cond_1d

    .line 183
    .line 184
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getSuspend()Ljava/lang/Boolean;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 189
    .line 190
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 191
    .line 192
    .line 193
    move-result p1

    .line 194
    if-eqz p1, :cond_c

    .line 195
    .line 196
    iget-object p1, v4, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 199
    .line 200
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getItemName()Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object p1

    .line 204
    if-nez p1, :cond_b

    .line 205
    .line 206
    goto :goto_3

    .line 207
    :cond_b
    move-object v6, p1

    .line 208
    :goto_3
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 209
    .line 210
    .line 211
    move-result-object p1

    .line 212
    sget v1, LPd/f;->qt_service_temporarily_unavailable_3:I

    .line 213
    .line 214
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v2

    .line 218
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    new-instance v1, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;

    .line 223
    .line 224
    sget v2, Lcom/transsnet/palmpay/custom_view/t;->cv_toast_dialog:I

    .line 225
    .line 226
    invoke-direct {v1, p1, v2}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;-><init>(Landroid/content/Context;I)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->setMessage(Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {v1, p2}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->setTitle(Ljava/lang/String;)V

    .line 233
    .line 234
    .line 235
    const/4 p1, 0x0

    .line 236
    invoke-static {v1, p1}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->d(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;I)V

    .line 237
    .line 238
    .line 239
    invoke-static {v1, p2}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->e(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;Lcom/mikepenz/iconics/IconicsDrawable;)V

    .line 240
    .line 241
    .line 242
    invoke-static {v1}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->c(Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;)V

    .line 243
    .line 244
    .line 245
    const-wide/16 p1, 0xfa0

    .line 246
    .line 247
    invoke-virtual {v1, p1, p2}, Lcom/transsnet/palmpay/custom_view/dialog/ToastDialog;->show(J)V

    .line 248
    .line 249
    .line 250
    return-void

    .line 251
    :cond_c
    iget-object p1, v4, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 252
    .line 253
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 254
    .line 255
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->isAmountFixed()Ljava/lang/Boolean;

    .line 256
    .line 257
    .line 258
    move-result-object p1

    .line 259
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 260
    .line 261
    .line 262
    move-result p1

    .line 263
    const-wide/16 v7, 0x0

    .line 264
    .line 265
    if-eqz p1, :cond_e

    .line 266
    .line 267
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 268
    .line 269
    .line 270
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 271
    .line 272
    .line 273
    iget-object p1, v4, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 274
    .line 275
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 276
    .line 277
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getPrice()Ljava/lang/Long;

    .line 278
    .line 279
    .line 280
    move-result-object p1

    .line 281
    if-eqz p1, :cond_d

    .line 282
    .line 283
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 284
    .line 285
    .line 286
    move-result-wide v7

    .line 287
    :cond_d
    iget-object p1, v4, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 288
    .line 289
    move-object v5, p1

    .line 290
    check-cast v5, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 291
    .line 292
    move-wide v3, v7

    .line 293
    invoke-virtual/range {v0 .. v5}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->H(Ljava/lang/String;Ljava/lang/String;JLcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;)V

    .line 294
    .line 295
    .line 296
    return-void

    .line 297
    :cond_e
    iget-object p1, v4, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 298
    .line 299
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 300
    .line 301
    move-object v3, v2

    .line 302
    move-object v2, v1

    .line 303
    move-object v1, v0

    .line 304
    new-instance v0, Lwb/g;

    .line 305
    .line 306
    const/4 v5, 0x2

    .line 307
    invoke-direct/range {v0 .. v5}, Lwb/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 308
    .line 309
    .line 310
    move-object v12, v1

    .line 311
    move-object v1, v0

    .line 312
    move-object v0, v12

    .line 313
    iget-wide v2, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->s0:J

    .line 314
    .line 315
    iget-object v4, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 316
    .line 317
    if-eqz v4, :cond_f

    .line 318
    .line 319
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getMinAmount()Ljava/lang/Long;

    .line 320
    .line 321
    .line 322
    move-result-object v4

    .line 323
    if-eqz v4, :cond_f

    .line 324
    .line 325
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 326
    .line 327
    .line 328
    move-result-wide v4

    .line 329
    goto :goto_4

    .line 330
    :cond_f
    move-wide v4, v7

    .line 331
    :goto_4
    if-eqz p1, :cond_10

    .line 332
    .line 333
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getMinAmount()Ljava/lang/Long;

    .line 334
    .line 335
    .line 336
    move-result-object v9

    .line 337
    if-eqz v9, :cond_10

    .line 338
    .line 339
    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    .line 340
    .line 341
    .line 342
    move-result-wide v9

    .line 343
    goto :goto_5

    .line 344
    :cond_10
    move-wide v9, v7

    .line 345
    :goto_5
    invoke-static {v4, v5, v9, v10}, Ljava/lang/Math;->max(JJ)J

    .line 346
    .line 347
    .line 348
    move-result-wide v4

    .line 349
    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(JJ)J

    .line 350
    .line 351
    .line 352
    move-result-wide v2

    .line 353
    iget-wide v4, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->r0:J

    .line 354
    .line 355
    cmp-long v4, v4, v7

    .line 356
    .line 357
    const-wide v9, 0x7fffffffffffffffL

    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    if-nez v4, :cond_11

    .line 363
    .line 364
    iput-wide v9, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->r0:J

    .line 365
    .line 366
    :cond_11
    iget-object v4, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 367
    .line 368
    if-eqz v4, :cond_13

    .line 369
    .line 370
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getMaxAmount()Ljava/lang/Long;

    .line 371
    .line 372
    .line 373
    move-result-object v4

    .line 374
    if-nez v4, :cond_12

    .line 375
    .line 376
    goto :goto_6

    .line 377
    :cond_12
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 378
    .line 379
    .line 380
    move-result-wide v4

    .line 381
    cmp-long v4, v4, v7

    .line 382
    .line 383
    if-nez v4, :cond_13

    .line 384
    .line 385
    iget-object v4, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 386
    .line 387
    if-eqz v4, :cond_13

    .line 388
    .line 389
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 390
    .line 391
    .line 392
    move-result-object v5

    .line 393
    invoke-virtual {v4, v5}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->setMaxAmount(Ljava/lang/Long;)V

    .line 394
    .line 395
    .line 396
    :cond_13
    :goto_6
    if-eqz p1, :cond_14

    .line 397
    .line 398
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getMaxAmount()Ljava/lang/Long;

    .line 399
    .line 400
    .line 401
    move-result-object v4

    .line 402
    if-eqz v4, :cond_14

    .line 403
    .line 404
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 405
    .line 406
    .line 407
    move-result-wide v4

    .line 408
    goto :goto_7

    .line 409
    :cond_14
    move-wide v4, v7

    .line 410
    :goto_7
    cmp-long v4, v4, v7

    .line 411
    .line 412
    if-nez v4, :cond_15

    .line 413
    .line 414
    if-eqz p1, :cond_15

    .line 415
    .line 416
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 417
    .line 418
    .line 419
    move-result-object v4

    .line 420
    invoke-virtual {p1, v4}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->setMaxAmount(Ljava/lang/Long;)V

    .line 421
    .line 422
    .line 423
    :cond_15
    iget-wide v4, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->r0:J

    .line 424
    .line 425
    iget-object v7, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 426
    .line 427
    if-eqz v7, :cond_16

    .line 428
    .line 429
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getMaxAmount()Ljava/lang/Long;

    .line 430
    .line 431
    .line 432
    move-result-object v7

    .line 433
    if-eqz v7, :cond_16

    .line 434
    .line 435
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    .line 436
    .line 437
    .line 438
    move-result-wide v7

    .line 439
    goto :goto_8

    .line 440
    :cond_16
    move-wide v7, v9

    .line 441
    :goto_8
    if-eqz p1, :cond_17

    .line 442
    .line 443
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getMaxAmount()Ljava/lang/Long;

    .line 444
    .line 445
    .line 446
    move-result-object v11

    .line 447
    if-eqz v11, :cond_17

    .line 448
    .line 449
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    .line 450
    .line 451
    .line 452
    move-result-wide v9

    .line 453
    :cond_17
    invoke-static {v7, v8, v9, v10}, Ljava/lang/Math;->min(JJ)J

    .line 454
    .line 455
    .line 456
    move-result-wide v7

    .line 457
    invoke-static {v4, v5, v7, v8}, Ljava/lang/Math;->min(JJ)J

    .line 458
    .line 459
    .line 460
    move-result-wide v4

    .line 461
    iget-object v0, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->w:Lxf/t;

    .line 462
    .line 463
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 464
    .line 465
    .line 466
    move-result-object v0

    .line 467
    check-cast v0, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 468
    .line 469
    invoke-virtual {v0, v4, v5}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;->setMaxAmount(J)Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 470
    .line 471
    .line 472
    move-result-object v0

    .line 473
    if-eqz p1, :cond_18

    .line 474
    .line 475
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getItemName()Ljava/lang/String;

    .line 476
    .line 477
    .line 478
    move-result-object v4

    .line 479
    if-nez v4, :cond_19

    .line 480
    .line 481
    :cond_18
    move-object v4, v6

    .line 482
    :cond_19
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;->setPaymentItemName(Ljava/lang/String;)Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 483
    .line 484
    .line 485
    move-result-object v0

    .line 486
    invoke-virtual {v0, v2, v3}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;->setMinAmount(J)Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 487
    .line 488
    .line 489
    move-result-object v0

    .line 490
    if-eqz p1, :cond_1b

    .line 491
    .line 492
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getRemark()Ljava/lang/String;

    .line 493
    .line 494
    .line 495
    move-result-object v2

    .line 496
    if-nez v2, :cond_1a

    .line 497
    .line 498
    goto :goto_9

    .line 499
    :cond_1a
    move-object v6, v2

    .line 500
    :cond_1b
    :goto_9
    invoke-virtual {v0, v6}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;->setCashback(Ljava/lang/String;)Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 501
    .line 502
    .line 503
    move-result-object v0

    .line 504
    if-eqz p1, :cond_1c

    .line 505
    .line 506
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getCustomerAmounts()[J

    .line 507
    .line 508
    .line 509
    move-result-object p2

    .line 510
    :cond_1c
    invoke-virtual {v0, p2}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;->setItemAmountList([J)Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 511
    .line 512
    .line 513
    move-result-object p1

    .line 514
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;->setCallback(Lkotlin/jvm/functions/Function1;)Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;

    .line 515
    .line 516
    .line 517
    move-result-object p1

    .line 518
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/dialog/InputPaymentItemAmountDialog;->show()V

    .line 519
    .line 520
    .line 521
    :cond_1d
    return-void
.end method
