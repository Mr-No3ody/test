.class public final synthetic LZd/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/f;->a:I

    iput-object p1, p0, LZd/f;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LZd/f;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 3
    .line 4
    iget v2, p0, LZd/f;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 10
    .line 11
    new-instance v2, Landroidx/swiperefreshlayout/widget/c;

    .line 12
    .line 13
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-direct {v2, v3}, Landroidx/swiperefreshlayout/widget/c;-><init>(Landroid/content/Context;)V

    .line 18
    .line 19
    .line 20
    iget-object v3, v2, Landroidx/swiperefreshlayout/widget/c;->a:Landroidx/swiperefreshlayout/widget/b;

    .line 21
    .line 22
    const/high16 v4, 0x40800000    # 4.0f

    .line 23
    .line 24
    iput v4, v3, Landroidx/swiperefreshlayout/widget/b;->h:F

    .line 25
    .line 26
    iget-object v5, v3, Landroidx/swiperefreshlayout/widget/b;->b:Landroid/graphics/Paint;

    .line 27
    .line 28
    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 32
    .line 33
    .line 34
    const/high16 v4, 0x41800000    # 16.0f

    .line 35
    .line 36
    iput v4, v3, Landroidx/swiperefreshlayout/widget/b;->q:F

    .line 37
    .line 38
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    sget v4, LL6/b;->ppColorPrimary:I

    .line 46
    .line 47
    invoke-virtual {v1, v4}, Landroid/content/Context;->getColor(I)I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    filled-new-array {v1}, [I

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    iput-object v1, v3, Landroidx/swiperefreshlayout/widget/b;->i:[I

    .line 56
    .line 57
    invoke-virtual {v3, v0}, Landroidx/swiperefreshlayout/widget/b;->a(I)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v3, v0}, Landroidx/swiperefreshlayout/widget/b;->a(I)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v2}, Landroidx/swiperefreshlayout/widget/c;->start()V

    .line 67
    .line 68
    .line 69
    return-object v2

    .line 70
    :pswitch_0
    sget v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 71
    .line 72
    iget-object v2, v1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 73
    .line 74
    check-cast v2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 75
    .line 76
    if-eqz v2, :cond_0

    .line 77
    .line 78
    iget-object v3, v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->C:Ljava/lang/String;

    .line 79
    .line 80
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->g(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    :cond_0
    iget-object v2, v1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 84
    .line 85
    check-cast v2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 86
    .line 87
    if-eqz v2, :cond_1

    .line 88
    .line 89
    iget-object v1, v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->C:Ljava/lang/String;

    .line 90
    .line 91
    invoke-virtual {v2, v1, v0, v0}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->d(Ljava/lang/String;ZZ)V

    .line 92
    .line 93
    .line 94
    :cond_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 95
    .line 96
    return-object v0

    .line 97
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
