.class public final synthetic LZd/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/e;->a:I

    iput-object p1, p0, LZd/e;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    const-string v0, "QK000010"

    .line 2
    .line 3
    const-string v1, "B00015"

    .line 4
    .line 5
    const-wide/16 v2, 0x0

    .line 6
    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    const-string v6, ""

    .line 10
    .line 11
    iget-object v7, p0, LZd/e;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 12
    .line 13
    const-string v8, "rsp"

    .line 14
    .line 15
    const/4 v9, 0x0

    .line 16
    iget v10, p0, LZd/e;->a:I

    .line 17
    .line 18
    packed-switch v10, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;

    .line 22
    .line 23
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/PaymentItemListRsp;

    .line 24
    .line 25
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 26
    .line 27
    invoke-static {p2, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_7

    .line 35
    .line 36
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/PaymentItemListRsp;->data:Ljava/util/List;

    .line 37
    .line 38
    if-eqz p2, :cond_8

    .line 39
    .line 40
    iget-object v0, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Y:Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 43
    .line 44
    .line 45
    iget-object v0, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Y:Ljava/util/ArrayList;

    .line 46
    .line 47
    check-cast p2, Ljava/util/Collection;

    .line 48
    .line 49
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 50
    .line 51
    .line 52
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->q0:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 55
    .line 56
    .line 57
    move-result p2

    .line 58
    if-nez p2, :cond_0

    .line 59
    .line 60
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->q0:Ljava/lang/String;

    .line 61
    .line 62
    if-eqz p2, :cond_3

    .line 63
    .line 64
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    if-nez v1, :cond_3

    .line 69
    .line 70
    iget-object v1, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->r0:Ljava/lang/String;

    .line 71
    .line 72
    invoke-virtual {v7, v1, p2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->H(Ljava/lang/String;Ljava/lang/String;)Z

    .line 73
    .line 74
    .line 75
    move-result p2

    .line 76
    goto :goto_1

    .line 77
    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 78
    .line 79
    .line 80
    move-result p2

    .line 81
    if-nez p2, :cond_3

    .line 82
    .line 83
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->r0:Ljava/lang/String;

    .line 84
    .line 85
    iget-object v1, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->L:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 86
    .line 87
    if-eqz v1, :cond_2

    .line 88
    .line 89
    invoke-virtual {v1}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getPaymentItemId()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    if-nez v1, :cond_1

    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_1
    move-object v6, v1

    .line 97
    :cond_2
    :goto_0
    invoke-virtual {v7, p2, v6}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->H(Ljava/lang/String;Ljava/lang/String;)Z

    .line 98
    .line 99
    .line 100
    move-result p2

    .line 101
    goto :goto_1

    .line 102
    :cond_3
    move p2, v9

    .line 103
    :goto_1
    if-eqz p1, :cond_6

    .line 104
    .line 105
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;->isSelectPaymentItemForOtherPager()Z

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    if-nez v1, :cond_6

    .line 110
    .line 111
    if-nez p2, :cond_6

    .line 112
    .line 113
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 114
    .line 115
    .line 116
    move-result p2

    .line 117
    if-lez p2, :cond_6

    .line 118
    .line 119
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Z:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 120
    .line 121
    if-eqz p2, :cond_4

    .line 122
    .line 123
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object p2

    .line 127
    goto :goto_2

    .line 128
    :cond_4
    move-object p2, v5

    .line 129
    :goto_2
    if-eqz p2, :cond_6

    .line 130
    .line 131
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Z:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 132
    .line 133
    if-eqz p2, :cond_5

    .line 134
    .line 135
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v5

    .line 139
    :cond_5
    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object p2

    .line 143
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 144
    .line 145
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerId:Ljava/lang/String;

    .line 146
    .line 147
    invoke-static {v5, p2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    move-result p2

    .line 151
    if-eqz p2, :cond_6

    .line 152
    .line 153
    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object p2

    .line 157
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 158
    .line 159
    invoke-virtual {v7, p2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->onPaymentItemClick(Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;)V

    .line 160
    .line 161
    .line 162
    :cond_6
    if-eqz p1, :cond_8

    .line 163
    .line 164
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;->getShowDialog()Z

    .line 165
    .line 166
    .line 167
    move-result p1

    .line 168
    if-ne p1, v4, :cond_8

    .line 169
    .line 170
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->P()V

    .line 171
    .line 172
    .line 173
    goto :goto_3

    .line 174
    :cond_7
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object p1

    .line 178
    new-array p2, v9, [Ljava/lang/Object;

    .line 179
    .line 180
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    :cond_8
    :goto_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 184
    .line 185
    return-object p1

    .line 186
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;

    .line 187
    .line 188
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/BillerListRsp;

    .line 189
    .line 190
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 191
    .line 192
    invoke-static {p2, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    if-eqz v0, :cond_e

    .line 200
    .line 201
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/BillerListRsp;->data:Ljava/util/List;

    .line 202
    .line 203
    if-eqz p2, :cond_f

    .line 204
    .line 205
    iget-object v0, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->X:Ljava/util/ArrayList;

    .line 206
    .line 207
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 208
    .line 209
    .line 210
    iget-object v0, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->X:Ljava/util/ArrayList;

    .line 211
    .line 212
    check-cast p2, Ljava/util/Collection;

    .line 213
    .line 214
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 215
    .line 216
    .line 217
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->L:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 218
    .line 219
    if-eqz p2, :cond_9

    .line 220
    .line 221
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object v0

    .line 225
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getPaymentItemId()Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object v1

    .line 229
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getCustomerId()Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v8

    .line 233
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBusinessAmount()J

    .line 234
    .line 235
    .line 236
    move-result-wide v9

    .line 237
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 238
    .line 239
    .line 240
    move-result-object p2

    .line 241
    invoke-static {v7, v0, v1, v8, p2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->M(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 242
    .line 243
    .line 244
    :cond_9
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->H:Ljava/lang/String;

    .line 245
    .line 246
    if-eqz p2, :cond_b

    .line 247
    .line 248
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 249
    .line 250
    .line 251
    move-result v0

    .line 252
    if-nez v0, :cond_a

    .line 253
    .line 254
    goto :goto_4

    .line 255
    :cond_a
    move-object p2, v5

    .line 256
    :goto_4
    if-eqz p2, :cond_b

    .line 257
    .line 258
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    invoke-static {v7, p2, v6, v6, v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->M(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 263
    .line 264
    .line 265
    :cond_b
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->L:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 266
    .line 267
    if-eqz p2, :cond_c

    .line 268
    .line 269
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerName()Ljava/lang/String;

    .line 270
    .line 271
    .line 272
    move-result-object p2

    .line 273
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 274
    .line 275
    .line 276
    move-result p2

    .line 277
    if-eqz p2, :cond_d

    .line 278
    .line 279
    iget-object p2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->H:Ljava/lang/String;

    .line 280
    .line 281
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 282
    .line 283
    .line 284
    move-result p2

    .line 285
    if-eqz p2, :cond_d

    .line 286
    .line 287
    :cond_c
    iget-object p2, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 288
    .line 289
    check-cast p2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 290
    .line 291
    if-eqz p2, :cond_d

    .line 292
    .line 293
    new-instance v0, Ljava/lang/StringBuilder;

    .line 294
    .line 295
    const-string v1, "queryLastBillerByCategoryId"

    .line 296
    .line 297
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 298
    .line 299
    .line 300
    iget-object v1, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->C:Ljava/lang/String;

    .line 301
    .line 302
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 303
    .line 304
    .line 305
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v0

    .line 309
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    move-result-object v0

    .line 313
    invoke-static {v0}, LPa/H;->b([Ljava/lang/Object;)Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object v0

    .line 317
    const-string v2, "createCacheKey(...)"

    .line 318
    .line 319
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 323
    .line 324
    .line 325
    move-result-object v2

    .line 326
    const-string v3, "_"

    .line 327
    .line 328
    invoke-static {v0, v3, v2}, LN8/q0;->y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 329
    .line 330
    .line 331
    move-result-object v0

    .line 332
    invoke-static {p2}, Landroidx/lifecycle/V;->h(Landroidx/lifecycle/a0;)Lkotlinx/coroutines/CoroutineScope;

    .line 333
    .line 334
    .line 335
    move-result-object v2

    .line 336
    new-instance v3, Lfe/y;

    .line 337
    .line 338
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->o:Lcom/transsnet/palmpay/core/base/l;

    .line 339
    .line 340
    invoke-direct {v3, p2, v0, v5, v1}, Lfe/y;-><init>(Lcom/transsnet/palmpay/core/base/l;Ljava/lang/String;Lkotlin/coroutines/Continuation;Ljava/lang/String;)V

    .line 341
    .line 342
    .line 343
    const/4 p2, 0x3

    .line 344
    invoke-static {v2, v5, v5, v3, p2}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 345
    .line 346
    .line 347
    :cond_d
    if-eqz p1, :cond_f

    .line 348
    .line 349
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;->getShowDialog()Z

    .line 350
    .line 351
    .line 352
    move-result p1

    .line 353
    if-ne p1, v4, :cond_f

    .line 354
    .line 355
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->O()V

    .line 356
    .line 357
    .line 358
    goto :goto_5

    .line 359
    :cond_e
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 360
    .line 361
    .line 362
    move-result-object p1

    .line 363
    new-array p2, v9, [Ljava/lang/Object;

    .line 364
    .line 365
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 366
    .line 367
    .line 368
    :cond_f
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 369
    .line 370
    return-object p1

    .line 371
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;

    .line 372
    .line 373
    check-cast p2, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 374
    .line 375
    sget v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 376
    .line 377
    invoke-static {p2, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 378
    .line 379
    .line 380
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 381
    .line 382
    .line 383
    move-result v2

    .line 384
    if-eqz v2, :cond_10

    .line 385
    .line 386
    if-eqz p1, :cond_16

    .line 387
    .line 388
    iget-object p2, p2, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 389
    .line 390
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/resp/BillOrderInfoConfirmData;

    .line 391
    .line 392
    if-eqz p2, :cond_16

    .line 393
    .line 394
    new-instance v0, Lcom/transsnet/palmpay/teller/ui/dialog/BillOrderInfoConfirmDialog;

    .line 395
    .line 396
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 397
    .line 398
    .line 399
    move-result-object v1

    .line 400
    const/4 v4, 0x6

    .line 401
    const/4 v5, 0x0

    .line 402
    const/4 v2, 0x0

    .line 403
    const/4 v3, 0x0

    .line 404
    invoke-direct/range {v0 .. v5}, Lcom/transsnet/palmpay/teller/ui/dialog/BillOrderInfoConfirmDialog;-><init>(Landroid/content/Context;IIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 405
    .line 406
    .line 407
    invoke-virtual {v0, p2}, Lcom/transsnet/palmpay/teller/ui/dialog/BillOrderInfoConfirmDialog;->setOrderInfo(Lcom/transsnet/palmpay/teller/bean/resp/BillOrderInfoConfirmData;)Lcom/transsnet/palmpay/teller/ui/dialog/BillOrderInfoConfirmDialog;

    .line 408
    .line 409
    .line 410
    move-result-object p2

    .line 411
    new-instance v0, LHb/L;

    .line 412
    .line 413
    const/4 v1, 0x7

    .line 414
    invoke-direct {v0, v1, p1, v7}, LHb/L;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 415
    .line 416
    .line 417
    invoke-virtual {p2, v0}, Lcom/transsnet/palmpay/teller/ui/dialog/BillOrderInfoConfirmDialog;->setOnConfirmClickListener(Lkotlin/jvm/functions/Function0;)Lcom/transsnet/palmpay/teller/ui/dialog/BillOrderInfoConfirmDialog;

    .line 418
    .line 419
    .line 420
    move-result-object p1

    .line 421
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/dialog/BillOrderInfoConfirmDialog;->show()V

    .line 422
    .line 423
    .line 424
    goto :goto_8

    .line 425
    :cond_10
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 426
    .line 427
    .line 428
    move-result-object p1

    .line 429
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 430
    .line 431
    .line 432
    move-result p1

    .line 433
    if-eqz p1, :cond_13

    .line 434
    .line 435
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 436
    .line 437
    .line 438
    move-result-object p1

    .line 439
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 440
    .line 441
    .line 442
    move-result p1

    .line 443
    if-nez p1, :cond_16

    .line 444
    .line 445
    iget-object p1, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 446
    .line 447
    check-cast p1, LRd/f0;

    .line 448
    .line 449
    if-eqz p1, :cond_11

    .line 450
    .line 451
    iget-object p1, p1, LRd/f0;->o:Landroid/widget/LinearLayout;

    .line 452
    .line 453
    invoke-static {p1, v9}, Loa/h;->s(Landroid/view/View;Z)V

    .line 454
    .line 455
    .line 456
    :cond_11
    iget-object p1, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 457
    .line 458
    check-cast p1, LRd/f0;

    .line 459
    .line 460
    if-eqz p1, :cond_16

    .line 461
    .line 462
    iget-object p1, p1, LRd/f0;->w:Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;

    .line 463
    .line 464
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 465
    .line 466
    .line 467
    move-result-object p2

    .line 468
    if-nez p2, :cond_12

    .line 469
    .line 470
    goto :goto_6

    .line 471
    :cond_12
    move-object v6, p2

    .line 472
    :goto_6
    invoke-virtual {p1, v6}, Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;->setErrorMessage(Ljava/lang/CharSequence;)V

    .line 473
    .line 474
    .line 475
    goto :goto_8

    .line 476
    :cond_13
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 477
    .line 478
    .line 479
    move-result-object p1

    .line 480
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 481
    .line 482
    .line 483
    move-result p1

    .line 484
    if-eqz p1, :cond_15

    .line 485
    .line 486
    sget p1, Lba/k;->core_important_notice:I

    .line 487
    .line 488
    invoke-virtual {v7, p1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 489
    .line 490
    .line 491
    move-result-object p1

    .line 492
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 493
    .line 494
    .line 495
    move-result-object p2

    .line 496
    if-nez p2, :cond_14

    .line 497
    .line 498
    goto :goto_7

    .line 499
    :cond_14
    move-object v6, p2

    .line 500
    :goto_7
    sget p2, Lba/k;->core_confirm:I

    .line 501
    .line 502
    invoke-virtual {v7, p2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 503
    .line 504
    .line 505
    move-result-object p2

    .line 506
    invoke-virtual {v7, p1, v6, p2, v5}, Lcom/transsnet/palmpay/core/base/BaseFragment;->r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 507
    .line 508
    .line 509
    goto :goto_8

    .line 510
    :cond_15
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 511
    .line 512
    .line 513
    move-result-object p1

    .line 514
    new-array p2, v9, [Ljava/lang/Object;

    .line 515
    .line 516
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 517
    .line 518
    .line 519
    :cond_16
    :goto_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 520
    .line 521
    return-object p1

    .line 522
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;

    .line 523
    .line 524
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp;

    .line 525
    .line 526
    sget v10, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 527
    .line 528
    invoke-static {p2, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 529
    .line 530
    .line 531
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 532
    .line 533
    .line 534
    move-result v8

    .line 535
    if-eqz v8, :cond_25

    .line 536
    .line 537
    if-eqz p1, :cond_2c

    .line 538
    .line 539
    iget-object v0, p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp;->data:Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;

    .line 540
    .line 541
    if-eqz v0, :cond_2c

    .line 542
    .line 543
    iget-object v1, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 544
    .line 545
    check-cast v1, LRd/f0;

    .line 546
    .line 547
    iget-object v2, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->C:Ljava/lang/String;

    .line 548
    .line 549
    if-eqz v1, :cond_1d

    .line 550
    .line 551
    iget-object v1, v1, LRd/f0;->e:Landroidx/appcompat/widget/AppCompatCheckBox;

    .line 552
    .line 553
    invoke-virtual {v1}, Landroid/widget/CompoundButton;->isChecked()Z

    .line 554
    .line 555
    .line 556
    move-result v1

    .line 557
    if-ne v1, v4, :cond_1d

    .line 558
    .line 559
    new-instance v1, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;

    .line 560
    .line 561
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;-><init>()V

    .line 562
    .line 563
    .line 564
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->C()Ljava/lang/String;

    .line 565
    .line 566
    .line 567
    move-result-object v3

    .line 568
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->customerId:Ljava/lang/String;

    .line 569
    .line 570
    iget-object v3, v7, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->k0:Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 571
    .line 572
    if-eqz v3, :cond_17

    .line 573
    .line 574
    iget-object v4, v3, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->paymentItemId:Ljava/lang/String;

    .line 575
    .line 576
    goto :goto_9

    .line 577
    :cond_17
    move-object v4, v5

    .line 578
    :goto_9
    iput-object v4, v1, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->itemId:Ljava/lang/String;

    .line 579
    .line 580
    if-eqz v3, :cond_18

    .line 581
    .line 582
    iget-object v4, v3, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerName:Ljava/lang/String;

    .line 583
    .line 584
    goto :goto_a

    .line 585
    :cond_18
    move-object v4, v5

    .line 586
    :goto_a
    iput-object v4, v1, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->billerName:Ljava/lang/String;

    .line 587
    .line 588
    if-eqz v3, :cond_19

    .line 589
    .line 590
    iget-object v4, v3, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->institutionLogo:Ljava/lang/String;

    .line 591
    .line 592
    goto :goto_b

    .line 593
    :cond_19
    move-object v4, v5

    .line 594
    :goto_b
    iput-object v4, v1, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->institutionLogo:Ljava/lang/String;

    .line 595
    .line 596
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->categoryId:Ljava/lang/String;

    .line 597
    .line 598
    if-eqz v3, :cond_1a

    .line 599
    .line 600
    iget-object v4, v3, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->paymentItemName:Ljava/lang/String;

    .line 601
    .line 602
    goto :goto_c

    .line 603
    :cond_1a
    move-object v4, v5

    .line 604
    :goto_c
    iput-object v4, v1, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->itemName:Ljava/lang/String;

    .line 605
    .line 606
    if-eqz v3, :cond_1b

    .line 607
    .line 608
    iget-object v3, v3, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerId:Ljava/lang/String;

    .line 609
    .line 610
    goto :goto_d

    .line 611
    :cond_1b
    move-object v3, v5

    .line 612
    :goto_d
    iput-object v3, v1, Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;->billerId:Ljava/lang/String;

    .line 613
    .line 614
    iget-object v3, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 615
    .line 616
    check-cast v3, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 617
    .line 618
    if-eqz v3, :cond_1c

    .line 619
    .line 620
    new-instance v4, Lfe/h;

    .line 621
    .line 622
    invoke-direct {v4, v1, v5}, Lfe/h;-><init>(Lcom/transsnet/palmpay/core/bean/req/AddFamilyAccontReq;Lkotlin/coroutines/Continuation;)V

    .line 623
    .line 624
    .line 625
    iget-object v1, v3, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->v:Lcom/transsnet/palmpay/core/base/l;

    .line 626
    .line 627
    const/16 v5, 0x1c

    .line 628
    .line 629
    invoke-static {v3, v4, v1, v9, v5}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 630
    .line 631
    .line 632
    :cond_1c
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 633
    .line 634
    .line 635
    move-result-object v1

    .line 636
    const-string v3, "PPay_Electricity_Btn_SaveToBeneficiaries"

    .line 637
    .line 638
    invoke-virtual {v1, v3}, LPa/n0;->l(Ljava/lang/String;)V

    .line 639
    .line 640
    .line 641
    :cond_1d
    iget-object v1, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->orderNo:Ljava/lang/String;

    .line 642
    .line 643
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 644
    .line 645
    .line 646
    move-result v1

    .line 647
    if-nez v1, :cond_24

    .line 648
    .line 649
    iget-object v0, p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp;->data:Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;

    .line 650
    .line 651
    if-eqz v0, :cond_2c

    .line 652
    .line 653
    new-instance v1, LWd/z;

    .line 654
    .line 655
    iget-object v3, v7, Lcom/transsnet/palmpay/core/base/BaseFragment;->c:Landroidx/fragment/app/E;

    .line 656
    .line 657
    const-string v4, "mActivity"

    .line 658
    .line 659
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 660
    .line 661
    .line 662
    invoke-direct {v1, v3, v9}, LWd/z;-><init>(Landroid/content/Context;I)V

    .line 663
    .line 664
    .line 665
    iget-object v3, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->calculationExtInfo:Ljava/lang/String;

    .line 666
    .line 667
    iput-object v3, v1, LKa/b;->i:Ljava/lang/String;

    .line 668
    .line 669
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp;->data:Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;

    .line 670
    .line 671
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->orderNo:Ljava/lang/String;

    .line 672
    .line 673
    iput-object p2, v1, LKa/b;->b:Ljava/lang/String;

    .line 674
    .line 675
    iget-wide v3, p1, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->businessAmount:J

    .line 676
    .line 677
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 678
    .line 679
    .line 680
    move-result-object p2

    .line 681
    invoke-virtual {v1, p2}, LKa/b;->c(Ljava/lang/Long;)V

    .line 682
    .line 683
    .line 684
    invoke-static {v2}, Lee/b;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 685
    .line 686
    .line 687
    move-result-object p2

    .line 688
    iput-object p2, v1, LKa/b;->c:Ljava/lang/String;

    .line 689
    .line 690
    const-string p2, "5"

    .line 691
    .line 692
    iput-object p2, v1, LKa/b;->e:Ljava/lang/String;

    .line 693
    .line 694
    new-instance p2, Ljava/util/ArrayList;

    .line 695
    .line 696
    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 697
    .line 698
    .line 699
    new-instance v2, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;

    .line 700
    .line 701
    sget v3, LPd/f;->qt_biller_name:I

    .line 702
    .line 703
    invoke-virtual {v7, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 704
    .line 705
    .line 706
    move-result-object v3

    .line 707
    iget-object v4, p1, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->billerName:Ljava/lang/String;

    .line 708
    .line 709
    if-nez v4, :cond_1e

    .line 710
    .line 711
    move-object v4, v6

    .line 712
    :cond_1e
    invoke-direct {v2, v3, v4}, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;-><init>(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 713
    .line 714
    .line 715
    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 716
    .line 717
    .line 718
    iget-object v2, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->fullName:Ljava/lang/String;

    .line 719
    .line 720
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 721
    .line 722
    .line 723
    move-result v2

    .line 724
    if-nez v2, :cond_20

    .line 725
    .line 726
    new-instance v2, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;

    .line 727
    .line 728
    sget v3, LVd/a;->qt_account_name:I

    .line 729
    .line 730
    invoke-virtual {v7, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 731
    .line 732
    .line 733
    move-result-object v3

    .line 734
    iget-object v4, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->fullName:Ljava/lang/String;

    .line 735
    .line 736
    if-nez v4, :cond_1f

    .line 737
    .line 738
    move-object v4, v6

    .line 739
    :cond_1f
    invoke-direct {v2, v3, v4}, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;-><init>(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 740
    .line 741
    .line 742
    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 743
    .line 744
    .line 745
    :cond_20
    new-instance v2, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;

    .line 746
    .line 747
    iget-object p1, p1, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->customerDisplayName:Ljava/lang/String;

    .line 748
    .line 749
    if-nez p1, :cond_21

    .line 750
    .line 751
    move-object p1, v6

    .line 752
    :cond_21
    invoke-virtual {v7}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->C()Ljava/lang/String;

    .line 753
    .line 754
    .line 755
    move-result-object v3

    .line 756
    invoke-direct {v2, p1, v3}, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;-><init>(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 757
    .line 758
    .line 759
    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 760
    .line 761
    .line 762
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->address:Ljava/lang/String;

    .line 763
    .line 764
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 765
    .line 766
    .line 767
    move-result p1

    .line 768
    if-nez p1, :cond_23

    .line 769
    .line 770
    new-instance p1, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;

    .line 771
    .line 772
    sget v2, Lba/k;->core_address:I

    .line 773
    .line 774
    invoke-virtual {v7, v2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 775
    .line 776
    .line 777
    move-result-object v2

    .line 778
    iget-object v0, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->address:Ljava/lang/String;

    .line 779
    .line 780
    if-nez v0, :cond_22

    .line 781
    .line 782
    goto :goto_e

    .line 783
    :cond_22
    move-object v6, v0

    .line 784
    :goto_e
    invoke-direct {p1, v2, v6}, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;-><init>(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 785
    .line 786
    .line 787
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 788
    .line 789
    .line 790
    :cond_23
    invoke-virtual {v1, p2}, LKa/b;->b(Ljava/util/ArrayList;)V

    .line 791
    .line 792
    .line 793
    invoke-virtual {v1}, LKa/b;->d()V

    .line 794
    .line 795
    .line 796
    goto/16 :goto_11

    .line 797
    .line 798
    :cond_24
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->outstandingTips:Ljava/lang/String;

    .line 799
    .line 800
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 801
    .line 802
    .line 803
    move-result p1

    .line 804
    if-nez p1, :cond_2c

    .line 805
    .line 806
    iget-object p1, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->outstandingTips:Ljava/lang/String;

    .line 807
    .line 808
    invoke-virtual {v7, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->p(Ljava/lang/String;)V

    .line 809
    .line 810
    .line 811
    goto/16 :goto_11

    .line 812
    .line 813
    :cond_25
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 814
    .line 815
    .line 816
    move-result-object v4

    .line 817
    const-string v8, "QK000011"

    .line 818
    .line 819
    invoke-virtual {v8, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 820
    .line 821
    .line 822
    move-result v4

    .line 823
    if-eqz v4, :cond_26

    .line 824
    .line 825
    if-eqz p1, :cond_2c

    .line 826
    .line 827
    iget-object p2, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 828
    .line 829
    check-cast p2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 830
    .line 831
    if-eqz p2, :cond_2c

    .line 832
    .line 833
    const-string v0, "req"

    .line 834
    .line 835
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 836
    .line 837
    .line 838
    new-instance v0, Lfe/z;

    .line 839
    .line 840
    invoke-direct {v0, p1, v5}, Lfe/z;-><init>(Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;Lkotlin/coroutines/Continuation;)V

    .line 841
    .line 842
    .line 843
    iget-object v1, p2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->t:Lcom/transsnet/palmpay/core/base/l;

    .line 844
    .line 845
    iput-object p1, v1, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 846
    .line 847
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 848
    .line 849
    invoke-static {p2, v0, v1, v2, v3}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 850
    .line 851
    .line 852
    goto :goto_11

    .line 853
    :cond_26
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 854
    .line 855
    .line 856
    move-result-object p1

    .line 857
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 858
    .line 859
    .line 860
    move-result p1

    .line 861
    if-eqz p1, :cond_29

    .line 862
    .line 863
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 864
    .line 865
    .line 866
    move-result-object p1

    .line 867
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 868
    .line 869
    .line 870
    move-result p1

    .line 871
    if-nez p1, :cond_2c

    .line 872
    .line 873
    iget-object p1, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 874
    .line 875
    check-cast p1, LRd/f0;

    .line 876
    .line 877
    if-eqz p1, :cond_27

    .line 878
    .line 879
    iget-object p1, p1, LRd/f0;->o:Landroid/widget/LinearLayout;

    .line 880
    .line 881
    invoke-static {p1, v9}, Loa/h;->s(Landroid/view/View;Z)V

    .line 882
    .line 883
    .line 884
    :cond_27
    iget-object p1, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 885
    .line 886
    check-cast p1, LRd/f0;

    .line 887
    .line 888
    if-eqz p1, :cond_2c

    .line 889
    .line 890
    iget-object p1, p1, LRd/f0;->w:Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;

    .line 891
    .line 892
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 893
    .line 894
    .line 895
    move-result-object p2

    .line 896
    if-nez p2, :cond_28

    .line 897
    .line 898
    goto :goto_f

    .line 899
    :cond_28
    move-object v6, p2

    .line 900
    :goto_f
    invoke-virtual {p1, v6}, Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;->setErrorMessage(Ljava/lang/CharSequence;)V

    .line 901
    .line 902
    .line 903
    goto :goto_11

    .line 904
    :cond_29
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 905
    .line 906
    .line 907
    move-result-object p1

    .line 908
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 909
    .line 910
    .line 911
    move-result p1

    .line 912
    if-eqz p1, :cond_2b

    .line 913
    .line 914
    sget p1, Lba/k;->core_important_notice:I

    .line 915
    .line 916
    invoke-virtual {v7, p1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 917
    .line 918
    .line 919
    move-result-object p1

    .line 920
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 921
    .line 922
    .line 923
    move-result-object p2

    .line 924
    if-nez p2, :cond_2a

    .line 925
    .line 926
    goto :goto_10

    .line 927
    :cond_2a
    move-object v6, p2

    .line 928
    :goto_10
    sget p2, Lba/k;->core_confirm:I

    .line 929
    .line 930
    invoke-virtual {v7, p2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 931
    .line 932
    .line 933
    move-result-object p2

    .line 934
    invoke-virtual {v7, p1, v6, p2, v5}, Lcom/transsnet/palmpay/core/base/BaseFragment;->r(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 935
    .line 936
    .line 937
    goto :goto_11

    .line 938
    :cond_2b
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 939
    .line 940
    .line 941
    move-result-object p1

    .line 942
    new-array p2, v9, [Ljava/lang/Object;

    .line 943
    .line 944
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 945
    .line 946
    .line 947
    :cond_2c
    :goto_11
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 948
    .line 949
    return-object p1

    .line 950
    nop

    .line 951
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
