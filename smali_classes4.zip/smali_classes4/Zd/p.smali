.class public final LZd/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout$OnErrorViewVisibleListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LZd/p;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onErrorViewVisible(Z)V
    .locals 1

    .line 1
    sget v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 2
    .line 3
    iget-object v0, p0, LZd/p;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 4
    .line 5
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 6
    .line 7
    check-cast v0, LRd/l;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, v0, LRd/l;->o:Landroid/widget/LinearLayout;

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    xor-int/lit8 p1, p1, 0x1

    .line 16
    .line 17
    invoke-static {v0, p1}, Loa/h;->s(Landroid/view/View;Z)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method
