.class public final LZd/E;
.super Landroidx/camera/camera2/internal/P0;
.source "SourceFile"


# instance fields
.field public final g:Lcom/transsnet/palmpay/teller/ui/activity/BaseBillerActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/teller/ui/activity/BaseBillerActivity;)V
    .locals 1

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0, p1}, Landroidx/camera/camera2/internal/P0;-><init>(Landroid/content/Context;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LZd/E;->g:Lcom/transsnet/palmpay/teller/ui/activity/BaseBillerActivity;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final c()Landroid/view/View;
    .locals 6

    .line 1
    iget-object v0, p0, LZd/E;->g:Lcom/transsnet/palmpay/teller/ui/activity/BaseBillerActivity;

    .line 2
    .line 3
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sget v1, LPd/d;->qt_phone_network_not_connect_view:I

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-virtual {v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget v1, LPd/c;->atuaInputPhoneNumArea:I

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 21
    .line 22
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getInstance()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    if-eqz v2, :cond_0

    .line 31
    .line 32
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/db/entity/User;->getPhoneNumber()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    if-nez v2, :cond_1

    .line 37
    .line 38
    :cond_0
    const-string v2, ""

    .line 39
    .line 40
    :cond_1
    if-eqz v1, :cond_2

    .line 41
    .line 42
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->getContactIv()Landroid/widget/ImageView;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    if-eqz v3, :cond_2

    .line 47
    .line 48
    new-instance v4, LW8/d;

    .line 49
    .line 50
    const/16 v5, 0xe

    .line 51
    .line 52
    invoke-direct {v4, v5}, LW8/d;-><init>(I)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 56
    .line 57
    .line 58
    :cond_2
    if-eqz v1, :cond_3

    .line 59
    .line 60
    const/4 v3, 0x0

    .line 61
    invoke-virtual {v1, v3}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->setOperatorIconClickable(Z)V

    .line 62
    .line 63
    .line 64
    :cond_3
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    if-nez v3, :cond_5

    .line 69
    .line 70
    if-eqz v1, :cond_4

    .line 71
    .line 72
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->getPhoneNumberEdit()Landroidx/appcompat/widget/AppCompatAutoCompleteTextView;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    if-eqz v3, :cond_4

    .line 77
    .line 78
    invoke-virtual {v3}, Landroid/view/View;->clearFocus()V

    .line 79
    .line 80
    .line 81
    :cond_4
    const/4 v3, 0x4

    .line 82
    invoke-virtual {v2, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    const-string v3, "substring(...)"

    .line 87
    .line 88
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    if-eqz v1, :cond_5

    .line 92
    .line 93
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->setPhoneNumber(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    :cond_5
    sget v1, LPd/c;->networkView:I

    .line 97
    .line 98
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    check-cast v1, Lcom/transsnet/palmpay/common/export/view/NetworkNotConnectView;

    .line 103
    .line 104
    if-eqz v1, :cond_9

    .line 105
    .line 106
    iget-object v2, p0, Landroidx/camera/camera2/internal/P0;->d:Ljava/lang/Object;

    .line 107
    .line 108
    check-cast v2, Ljava/lang/String;

    .line 109
    .line 110
    if-eqz v2, :cond_7

    .line 111
    .line 112
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 113
    .line 114
    .line 115
    move-result v2

    .line 116
    if-nez v2, :cond_6

    .line 117
    .line 118
    goto :goto_0

    .line 119
    :cond_6
    iget-object v2, p0, Landroidx/camera/camera2/internal/P0;->d:Ljava/lang/Object;

    .line 120
    .line 121
    check-cast v2, Ljava/lang/String;

    .line 122
    .line 123
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/common/export/view/NetworkNotConnectView;->setMessage(Ljava/lang/CharSequence;)V

    .line 124
    .line 125
    .line 126
    :cond_7
    :goto_0
    new-instance v2, LC9/i;

    .line 127
    .line 128
    const/16 v3, 0xc

    .line 129
    .line 130
    invoke-direct {v2, p0, v3}, LC9/i;-><init>(Ljava/lang/Object;I)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/common/export/view/NetworkNotConnectView;->setRefreshListener(Lcom/transsnet/palmpay/core/callback/CompleteCallback;)V

    .line 134
    .line 135
    .line 136
    iget-object v2, p0, Landroidx/camera/camera2/internal/P0;->c:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v2, Ljava/lang/String;

    .line 139
    .line 140
    if-eqz v2, :cond_9

    .line 141
    .line 142
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 143
    .line 144
    .line 145
    move-result v2

    .line 146
    if-nez v2, :cond_8

    .line 147
    .line 148
    goto :goto_1

    .line 149
    :cond_8
    iget-object v2, p0, Landroidx/camera/camera2/internal/P0;->c:Ljava/lang/Object;

    .line 150
    .line 151
    check-cast v2, Ljava/lang/String;

    .line 152
    .line 153
    iget-object v3, p0, Landroidx/camera/camera2/internal/P0;->e:Ljava/lang/Object;

    .line 154
    .line 155
    check-cast v3, Landroid/view/View$OnClickListener;

    .line 156
    .line 157
    iget-object v1, v1, Lcom/transsnet/palmpay/common/export/view/NetworkNotConnectView;->c:LBc/e;

    .line 158
    .line 159
    if-eqz v1, :cond_9

    .line 160
    .line 161
    iget-object v1, v1, LBc/e;->i:Landroid/view/View;

    .line 162
    .line 163
    check-cast v1, Lcom/palmpay/lib/ui/button/PpButton;

    .line 164
    .line 165
    invoke-virtual {v1, v2}, Lcom/palmpay/lib/ui/button/PpButton;->setText(Ljava/lang/CharSequence;)V

    .line 166
    .line 167
    .line 168
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 169
    .line 170
    .line 171
    move-result v2

    .line 172
    xor-int/lit8 v2, v2, 0x1

    .line 173
    .line 174
    invoke-static {v1, v2}, Loa/h;->s(Landroid/view/View;Z)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v1, v3}, Lcom/palmpay/lib/ui/button/PpButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 178
    .line 179
    .line 180
    :cond_9
    :goto_1
    return-object v0
.end method
