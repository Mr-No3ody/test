.class public final synthetic LZd/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/d;->a:I

    iput-object p1, p0, LZd/d;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    const/4 p1, 0x0

    .line 2
    const/4 v0, 0x0

    .line 3
    const/4 v1, 0x1

    .line 4
    iget-object v2, p0, LZd/d;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 5
    .line 6
    iget v3, p0, LZd/d;->a:I

    .line 7
    .line 8
    packed-switch v3, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 12
    .line 13
    invoke-static {}, LPa/r0;->U0()Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    if-eqz p1, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->E()V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-static {p1}, Lcom/transsnet/palmpay/util/KeyboardUtils;->hideSoftInput(Landroid/app/Activity;)V

    .line 28
    .line 29
    .line 30
    :goto_0
    return-void

    .line 31
    :pswitch_0
    iget-object v3, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Z:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 32
    .line 33
    if-nez v3, :cond_1

    .line 34
    .line 35
    iget-object p1, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 36
    .line 37
    check-cast p1, LRd/f0;

    .line 38
    .line 39
    if-eqz p1, :cond_8

    .line 40
    .line 41
    iget-object p1, p1, LRd/f0;->C:Lcom/transsnet/palmpay/custom_view/ModelItemSelection;

    .line 42
    .line 43
    sget v0, LPd/f;->qt_msg_select_biller_first:I

    .line 44
    .line 45
    invoke-virtual {v2, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/custom_view/ModelItemSelection;->e(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_1
    invoke-virtual {v3}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getStatus()Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    if-nez v3, :cond_2

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_2
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    if-ne v3, v1, :cond_8

    .line 65
    .line 66
    iget-object v3, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Y:Ljava/util/ArrayList;

    .line 67
    .line 68
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    if-eqz v3, :cond_7

    .line 73
    .line 74
    iget-object v3, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 75
    .line 76
    check-cast v3, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 77
    .line 78
    if-eqz v3, :cond_4

    .line 79
    .line 80
    iget-object v4, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Z:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 81
    .line 82
    if-eqz v4, :cond_3

    .line 83
    .line 84
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    :cond_3
    invoke-virtual {v3, v0, v1, p1}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->e(Ljava/lang/String;ZZ)V

    .line 89
    .line 90
    .line 91
    :cond_4
    iget-object p1, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 92
    .line 93
    check-cast p1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 94
    .line 95
    if-eqz p1, :cond_8

    .line 96
    .line 97
    iget-object v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->Z:Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 98
    .line 99
    if-eqz v0, :cond_5

    .line 100
    .line 101
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    if-nez v0, :cond_6

    .line 106
    .line 107
    :cond_5
    const-string v0, ""

    .line 108
    .line 109
    :cond_6
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->f(Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    goto :goto_1

    .line 113
    :cond_7
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->P()V

    .line 114
    .line 115
    .line 116
    :cond_8
    :goto_1
    return-void

    .line 117
    :pswitch_1
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 118
    .line 119
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 120
    .line 121
    .line 122
    move-result p1

    .line 123
    if-nez p1, :cond_9

    .line 124
    .line 125
    invoke-static {v0, v0}, LPa/i0;->K(Ljava/lang/String;Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    goto :goto_2

    .line 129
    :cond_9
    iget-object p1, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 130
    .line 131
    check-cast p1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 132
    .line 133
    if-eqz p1, :cond_a

    .line 134
    .line 135
    const-string v1, "16"

    .line 136
    .line 137
    filled-new-array {v1}, [Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    invoke-static {v1}, Lkotlin/collections/q;->e([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    const-string v2, "transType"

    .line 146
    .line 147
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    new-instance v2, Ljava/lang/StringBuilder;

    .line 151
    .line 152
    const-string v3, "queryTransactionLinkVM_"

    .line 153
    .line 154
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v2

    .line 164
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCountryLocale()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v3

    .line 168
    const-string v4, "Pref_"

    .line 169
    .line 170
    const-string v5, "_"

    .line 171
    .line 172
    invoke-static {v4, v2, v5, v3}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    invoke-static {p1}, Landroidx/lifecycle/V;->h(Landroidx/lifecycle/a0;)Lkotlinx/coroutines/CoroutineScope;

    .line 177
    .line 178
    .line 179
    move-result-object v3

    .line 180
    new-instance v4, Lfe/F;

    .line 181
    .line 182
    iget-object p1, p1, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->f:Lcom/transsnet/palmpay/core/base/l;

    .line 183
    .line 184
    invoke-direct {v4, p1, v2, v0, v1}, Lfe/F;-><init>(Lcom/transsnet/palmpay/core/base/l;Ljava/lang/String;Lkotlin/coroutines/Continuation;Ljava/util/ArrayList;)V

    .line 185
    .line 186
    .line 187
    const/4 p1, 0x3

    .line 188
    invoke-static {v3, v0, v0, v4, p1}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 189
    .line 190
    .line 191
    :cond_a
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    const-string v0, "PPay_Electricity_Btn_TransHistory"

    .line 196
    .line 197
    invoke-virtual {p1, v0}, LPa/n0;->l(Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    :goto_2
    return-void

    .line 201
    :pswitch_2
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 202
    .line 203
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    const-string v0, "null cannot be cast to non-null type com.transsnet.palmpay.teller.ui.activity.BillPaymentHomeActivity"

    .line 208
    .line 209
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 210
    .line 211
    .line 212
    check-cast p1, Lcom/transsnet/palmpay/teller/ui/activity/BillPaymentHomeActivity;

    .line 213
    .line 214
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/base/BaseActivity;->goBackToHome()V

    .line 215
    .line 216
    .line 217
    return-void

    .line 218
    :pswitch_3
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 219
    .line 220
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 221
    .line 222
    .line 223
    move-result-object p1

    .line 224
    const-string v0, "/quick_teller/betting_beneficiaries"

    .line 225
    .line 226
    invoke-virtual {p1, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 227
    .line 228
    .line 229
    move-result-object p1

    .line 230
    iget-object v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->C:Ljava/lang/String;

    .line 231
    .line 232
    const-string v1, "KEY_CATEGORY_ID"

    .line 233
    .line 234
    invoke-virtual {p1, v1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 235
    .line 236
    .line 237
    move-result-object p1

    .line 238
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    const-string v1, "getInstance(...)"

    .line 243
    .line 244
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    const/16 v1, 0x65

    .line 251
    .line 252
    invoke-static {v0, v2, p1, v1}, LPa/r0;->x(Lcom/alibaba/android/arouter/launcher/ARouter;Landroidx/fragment/app/Fragment;Lcom/alibaba/android/arouter/facade/Postcard;I)V

    .line 253
    .line 254
    .line 255
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 256
    .line 257
    .line 258
    move-result-object p1

    .line 259
    const-string v0, "PPay_Electricity_Btn_Contacts"

    .line 260
    .line 261
    invoke-virtual {p1, v0}, LPa/n0;->l(Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    return-void

    .line 265
    :pswitch_4
    iget-object v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->X:Ljava/util/ArrayList;

    .line 266
    .line 267
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 268
    .line 269
    .line 270
    move-result v0

    .line 271
    if-eqz v0, :cond_b

    .line 272
    .line 273
    iget-object v0, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 274
    .line 275
    check-cast v0, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 276
    .line 277
    if-eqz v0, :cond_c

    .line 278
    .line 279
    iget-object v2, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->C:Ljava/lang/String;

    .line 280
    .line 281
    invoke-virtual {v0, v2, v1, p1}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->d(Ljava/lang/String;ZZ)V

    .line 282
    .line 283
    .line 284
    goto :goto_3

    .line 285
    :cond_b
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->O()V

    .line 286
    .line 287
    .line 288
    :cond_c
    :goto_3
    return-void

    .line 289
    :pswitch_5
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 290
    .line 291
    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 292
    .line 293
    .line 294
    move-result-object p1

    .line 295
    invoke-static {p1}, Lcom/transsnet/palmpay/util/KeyboardUtils;->hideSoftInput(Landroid/app/Activity;)V

    .line 296
    .line 297
    .line 298
    return-void

    .line 299
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
