.class public final synthetic LZd/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/n;->a:I

    iput-object p1, p0, LZd/n;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    const/4 v0, 0x1

    .line 2
    const-string v1, ""

    .line 3
    .line 4
    iget-object v2, p0, LZd/n;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 5
    .line 6
    const-string v3, "rsp"

    .line 7
    .line 8
    const/4 v4, 0x0

    .line 9
    iget v5, p0, LZd/n;->a:I

    .line 10
    .line 11
    packed-switch v5, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;

    .line 15
    .line 16
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/BillerListRsp;

    .line 17
    .line 18
    sget v5, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 19
    .line 20
    invoke-static {p2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    if-eqz v3, :cond_5

    .line 28
    .line 29
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/BillerListRsp;->data:Ljava/util/List;

    .line 30
    .line 31
    if-eqz p2, :cond_6

    .line 32
    .line 33
    iget-object v3, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->C:Ljava/util/ArrayList;

    .line 34
    .line 35
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 36
    .line 37
    .line 38
    iget-object v3, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->C:Ljava/util/ArrayList;

    .line 39
    .line 40
    check-cast p2, Ljava/util/Collection;

    .line 41
    .line 42
    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 43
    .line 44
    .line 45
    iget-object p2, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->B:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 46
    .line 47
    if-eqz p2, :cond_0

    .line 48
    .line 49
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v3

    .line 53
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getPaymentItemId()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getCustomerId()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v5

    .line 61
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBusinessAmount()J

    .line 62
    .line 63
    .line 64
    move-result-wide v6

    .line 65
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 66
    .line 67
    .line 68
    move-result-object p2

    .line 69
    invoke-static {v2, v3, v4, v5, p2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->D(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 70
    .line 71
    .line 72
    :cond_0
    iget-object p2, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->A:Ljava/lang/String;

    .line 73
    .line 74
    if-eqz p2, :cond_2

    .line 75
    .line 76
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    if-nez v3, :cond_1

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_1
    const/4 p2, 0x0

    .line 84
    :goto_0
    if-eqz p2, :cond_2

    .line 85
    .line 86
    const-wide/16 v3, 0x0

    .line 87
    .line 88
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    invoke-static {v2, p2, v1, v1, v3}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->D(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 93
    .line 94
    .line 95
    :cond_2
    iget-object p2, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->B:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 96
    .line 97
    if-eqz p2, :cond_3

    .line 98
    .line 99
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerName()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object p2

    .line 103
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 104
    .line 105
    .line 106
    move-result p2

    .line 107
    if-eqz p2, :cond_4

    .line 108
    .line 109
    :cond_3
    iget-object p2, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->A:Ljava/lang/String;

    .line 110
    .line 111
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 112
    .line 113
    .line 114
    move-result p2

    .line 115
    if-eqz p2, :cond_4

    .line 116
    .line 117
    iget-object p2, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 118
    .line 119
    check-cast p2, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;

    .line 120
    .line 121
    if-eqz p2, :cond_4

    .line 122
    .line 123
    iget-object v1, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 124
    .line 125
    invoke-virtual {p2, v1}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentHomeNGViewModel;->g(Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    :cond_4
    if-eqz p1, :cond_6

    .line 129
    .line 130
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;->getShowDialog()Z

    .line 131
    .line 132
    .line 133
    move-result p1

    .line 134
    if-ne p1, v0, :cond_6

    .line 135
    .line 136
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->F()V

    .line 137
    .line 138
    .line 139
    goto :goto_1

    .line 140
    :cond_5
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    new-array p2, v4, [Ljava/lang/Object;

    .line 145
    .line 146
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 147
    .line 148
    .line 149
    :cond_6
    :goto_1
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 150
    .line 151
    return-object p1

    .line 152
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;

    .line 153
    .line 154
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp;

    .line 155
    .line 156
    sget v5, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 157
    .line 158
    invoke-static {p2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 162
    .line 163
    .line 164
    move-result v3

    .line 165
    if-eqz v3, :cond_13

    .line 166
    .line 167
    if-eqz p1, :cond_14

    .line 168
    .line 169
    iget-object v3, p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp;->data:Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;

    .line 170
    .line 171
    if-eqz v3, :cond_14

    .line 172
    .line 173
    iget-object v5, v3, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->orderNo:Ljava/lang/String;

    .line 174
    .line 175
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 176
    .line 177
    .line 178
    move-result v5

    .line 179
    if-nez v5, :cond_12

    .line 180
    .line 181
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 182
    .line 183
    .line 184
    move-result v3

    .line 185
    if-ne v3, v0, :cond_e

    .line 186
    .line 187
    iget-object v0, p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp;->data:Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;

    .line 188
    .line 189
    if-eqz v0, :cond_14

    .line 190
    .line 191
    new-instance v3, LWd/z;

    .line 192
    .line 193
    iget-object v5, v2, Lcom/transsnet/palmpay/core/base/BaseFragment;->c:Landroidx/fragment/app/E;

    .line 194
    .line 195
    const-string v6, "mActivity"

    .line 196
    .line 197
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    invoke-direct {v3, v5, v4}, LWd/z;-><init>(Landroid/content/Context;I)V

    .line 201
    .line 202
    .line 203
    iget-object v4, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->calculationExtInfo:Ljava/lang/String;

    .line 204
    .line 205
    iput-object v4, v3, LKa/b;->i:Ljava/lang/String;

    .line 206
    .line 207
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp;->data:Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;

    .line 208
    .line 209
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->orderNo:Ljava/lang/String;

    .line 210
    .line 211
    iput-object p2, v3, LKa/b;->b:Ljava/lang/String;

    .line 212
    .line 213
    iget-wide p1, p1, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderReq;->businessAmount:J

    .line 214
    .line 215
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 216
    .line 217
    .line 218
    move-result-object p1

    .line 219
    invoke-virtual {v3, p1}, LKa/b;->c(Ljava/lang/Long;)V

    .line 220
    .line 221
    .line 222
    sget-object p1, Lee/b;->a:Ljava/lang/Object;

    .line 223
    .line 224
    iget-object p1, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w:Ljava/lang/String;

    .line 225
    .line 226
    invoke-static {p1}, Lee/b;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 227
    .line 228
    .line 229
    move-result-object p1

    .line 230
    iput-object p1, v3, LKa/b;->c:Ljava/lang/String;

    .line 231
    .line 232
    const-string p1, "5"

    .line 233
    .line 234
    iput-object p1, v3, LKa/b;->e:Ljava/lang/String;

    .line 235
    .line 236
    new-instance p1, Ljava/util/ArrayList;

    .line 237
    .line 238
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 239
    .line 240
    .line 241
    new-instance p2, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;

    .line 242
    .line 243
    sget v4, LPd/f;->qt_biller_name:I

    .line 244
    .line 245
    invoke-virtual {v2, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object v4

    .line 249
    iget-object v5, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->M:Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 250
    .line 251
    if-eqz v5, :cond_7

    .line 252
    .line 253
    iget-object v5, v5, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;->billerName:Ljava/lang/String;

    .line 254
    .line 255
    if-nez v5, :cond_8

    .line 256
    .line 257
    :cond_7
    move-object v5, v1

    .line 258
    :cond_8
    invoke-direct {p2, v4, v5}, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;-><init>(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 262
    .line 263
    .line 264
    iget-object p2, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->fullName:Ljava/lang/String;

    .line 265
    .line 266
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 267
    .line 268
    .line 269
    move-result p2

    .line 270
    if-nez p2, :cond_a

    .line 271
    .line 272
    new-instance p2, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;

    .line 273
    .line 274
    sget v4, LVd/a;->qt_account_name:I

    .line 275
    .line 276
    invoke-virtual {v2, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 277
    .line 278
    .line 279
    move-result-object v4

    .line 280
    iget-object v5, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->fullName:Ljava/lang/String;

    .line 281
    .line 282
    if-nez v5, :cond_9

    .line 283
    .line 284
    move-object v5, v1

    .line 285
    :cond_9
    invoke-direct {p2, v4, v5}, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;-><init>(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 286
    .line 287
    .line 288
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 289
    .line 290
    .line 291
    :cond_a
    new-instance p2, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;

    .line 292
    .line 293
    iget-object v4, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->M:Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 294
    .line 295
    invoke-virtual {v2, v4}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->x(Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;)Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object v4

    .line 299
    if-nez v4, :cond_b

    .line 300
    .line 301
    sget v4, LVd/a;->qt_internet_customer_id:I

    .line 302
    .line 303
    invoke-virtual {v2, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v4

    .line 307
    const-string v5, "getString(...)"

    .line 308
    .line 309
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 310
    .line 311
    .line 312
    :cond_b
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->w()Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v5

    .line 316
    invoke-direct {p2, v4, v5}, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;-><init>(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 317
    .line 318
    .line 319
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 320
    .line 321
    .line 322
    iget-object p2, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->address:Ljava/lang/String;

    .line 323
    .line 324
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 325
    .line 326
    .line 327
    move-result p2

    .line 328
    if-nez p2, :cond_d

    .line 329
    .line 330
    new-instance p2, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;

    .line 331
    .line 332
    sget v4, Lba/k;->core_address:I

    .line 333
    .line 334
    invoke-virtual {v2, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object v2

    .line 338
    iget-object v0, v0, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->address:Ljava/lang/String;

    .line 339
    .line 340
    if-nez v0, :cond_c

    .line 341
    .line 342
    goto :goto_2

    .line 343
    :cond_c
    move-object v1, v0

    .line 344
    :goto_2
    invoke-direct {p2, v2, v1}, Lcom/transsnet/palmpay/core/bean/cashier/CoreCashierPaymentExtra;-><init>(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 345
    .line 346
    .line 347
    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 348
    .line 349
    .line 350
    :cond_d
    invoke-virtual {v3, p1}, LKa/b;->b(Ljava/util/ArrayList;)V

    .line 351
    .line 352
    .line 353
    invoke-virtual {v3}, LKa/b;->d()V

    .line 354
    .line 355
    .line 356
    goto :goto_5

    .line 357
    :cond_e
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 358
    .line 359
    .line 360
    move-result-object p1

    .line 361
    const-string v0, "B00015"

    .line 362
    .line 363
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 364
    .line 365
    .line 366
    move-result p1

    .line 367
    if-eqz p1, :cond_10

    .line 368
    .line 369
    iget-object p1, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 370
    .line 371
    check-cast p1, LRd/l;

    .line 372
    .line 373
    if-eqz p1, :cond_14

    .line 374
    .line 375
    iget-object p1, p1, LRd/l;->p:Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;

    .line 376
    .line 377
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object p2

    .line 381
    if-nez p2, :cond_f

    .line 382
    .line 383
    goto :goto_3

    .line 384
    :cond_f
    move-object v1, p2

    .line 385
    :goto_3
    invoke-virtual {p1, v1}, Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout;->setErrorMessage(Ljava/lang/CharSequence;)V

    .line 386
    .line 387
    .line 388
    goto :goto_5

    .line 389
    :cond_10
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 390
    .line 391
    .line 392
    move-result-object p1

    .line 393
    if-nez p1, :cond_11

    .line 394
    .line 395
    goto :goto_4

    .line 396
    :cond_11
    move-object v1, p1

    .line 397
    :goto_4
    new-array p1, v4, [Ljava/lang/Object;

    .line 398
    .line 399
    invoke-static {v1, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 400
    .line 401
    .line 402
    goto :goto_5

    .line 403
    :cond_12
    iget-object p1, v3, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->outstandingTips:Ljava/lang/String;

    .line 404
    .line 405
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 406
    .line 407
    .line 408
    move-result p1

    .line 409
    if-nez p1, :cond_14

    .line 410
    .line 411
    iget-object p1, v3, Lcom/transsnet/palmpay/teller/bean/CreateTellerOrderRsp$DataBean;->outstandingTips:Ljava/lang/String;

    .line 412
    .line 413
    invoke-virtual {v2, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->p(Ljava/lang/String;)V

    .line 414
    .line 415
    .line 416
    goto :goto_5

    .line 417
    :cond_13
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 418
    .line 419
    .line 420
    move-result-object p1

    .line 421
    new-array p2, v4, [Ljava/lang/Object;

    .line 422
    .line 423
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 424
    .line 425
    .line 426
    :cond_14
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 427
    .line 428
    return-object p1

    .line 429
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;

    .line 430
    .line 431
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/PaymentItemListRsp;

    .line 432
    .line 433
    sget v5, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 434
    .line 435
    invoke-static {p2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 436
    .line 437
    .line 438
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 439
    .line 440
    .line 441
    move-result v3

    .line 442
    if-eqz v3, :cond_1a

    .line 443
    .line 444
    iget-object p2, p2, Lcom/transsnet/palmpay/teller/bean/PaymentItemListRsp;->data:Ljava/util/List;

    .line 445
    .line 446
    if-eqz p2, :cond_1b

    .line 447
    .line 448
    iget-object v3, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->H:Ljava/util/ArrayList;

    .line 449
    .line 450
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 451
    .line 452
    .line 453
    iget-object v3, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->H:Ljava/util/ArrayList;

    .line 454
    .line 455
    check-cast p2, Ljava/util/Collection;

    .line 456
    .line 457
    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 458
    .line 459
    .line 460
    iget-object p2, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->X:Ljava/lang/String;

    .line 461
    .line 462
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 463
    .line 464
    .line 465
    move-result p2

    .line 466
    if-nez p2, :cond_15

    .line 467
    .line 468
    iget-object p2, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->X:Ljava/lang/String;

    .line 469
    .line 470
    if-eqz p2, :cond_18

    .line 471
    .line 472
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 473
    .line 474
    .line 475
    move-result v1

    .line 476
    if-nez v1, :cond_18

    .line 477
    .line 478
    iget-object v1, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->Y:Ljava/lang/String;

    .line 479
    .line 480
    invoke-virtual {v2, v1, p2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->A(Ljava/lang/String;Ljava/lang/String;)Z

    .line 481
    .line 482
    .line 483
    move-result p2

    .line 484
    goto :goto_7

    .line 485
    :cond_15
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 486
    .line 487
    .line 488
    move-result p2

    .line 489
    if-nez p2, :cond_18

    .line 490
    .line 491
    iget-object p2, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->Y:Ljava/lang/String;

    .line 492
    .line 493
    iget-object v5, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->B:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 494
    .line 495
    if-eqz v5, :cond_17

    .line 496
    .line 497
    invoke-virtual {v5}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getPaymentItemId()Ljava/lang/String;

    .line 498
    .line 499
    .line 500
    move-result-object v5

    .line 501
    if-nez v5, :cond_16

    .line 502
    .line 503
    goto :goto_6

    .line 504
    :cond_16
    move-object v1, v5

    .line 505
    :cond_17
    :goto_6
    invoke-virtual {v2, p2, v1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->A(Ljava/lang/String;Ljava/lang/String;)Z

    .line 506
    .line 507
    .line 508
    move-result p2

    .line 509
    goto :goto_7

    .line 510
    :cond_18
    move p2, v4

    .line 511
    :goto_7
    if-eqz p1, :cond_19

    .line 512
    .line 513
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;->isSelectPaymentItemForOtherPager()Z

    .line 514
    .line 515
    .line 516
    move-result v1

    .line 517
    if-nez v1, :cond_19

    .line 518
    .line 519
    if-nez p2, :cond_19

    .line 520
    .line 521
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 522
    .line 523
    .line 524
    move-result p2

    .line 525
    if-ne p2, v0, :cond_19

    .line 526
    .line 527
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 528
    .line 529
    .line 530
    move-result-object p2

    .line 531
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;

    .line 532
    .line 533
    invoke-virtual {v2, p2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->onPaymentItemClick(Lcom/transsnet/palmpay/teller/bean/PaymentItemBean;)V

    .line 534
    .line 535
    .line 536
    :cond_19
    if-eqz p1, :cond_1b

    .line 537
    .line 538
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillPaymentHomeParams;->getShowDialog()Z

    .line 539
    .line 540
    .line 541
    move-result p1

    .line 542
    if-ne p1, v0, :cond_1b

    .line 543
    .line 544
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->G()V

    .line 545
    .line 546
    .line 547
    goto :goto_8

    .line 548
    :cond_1a
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 549
    .line 550
    .line 551
    move-result-object p1

    .line 552
    new-array p2, v4, [Ljava/lang/Object;

    .line 553
    .line 554
    invoke-static {p1, p2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 555
    .line 556
    .line 557
    :cond_1b
    :goto_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 558
    .line 559
    return-object p1

    .line 560
    nop

    .line 561
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
