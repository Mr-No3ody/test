.class public final LZd/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/input/ModelNumberInputLayout$OnNumberInputListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LZd/q;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onNumberEditComplete(Ljava/lang/String;)V
    .locals 0

    .line 1
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 2
    .line 3
    iget-object p1, p0, LZd/q;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 4
    .line 5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->H()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final onNumberEditing(Ljava/lang/String;)V
    .locals 0

    .line 1
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 2
    .line 3
    iget-object p1, p0, LZd/q;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 4
    .line 5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->H()V

    .line 6
    .line 7
    .line 8
    return-void
.end method
