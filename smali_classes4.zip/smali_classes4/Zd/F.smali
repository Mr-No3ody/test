.class public final synthetic LZd/F;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;
.implements Lcom/chad/library/adapter/base/listener/OnItemChildClickListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;)V
    .locals 0

    .line 1
    iput-object p1, p0, LZd/F;->a:Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemChildClick(LM1/j;Landroid/view/View;I)V
    .locals 1

    .line 1
    const-string v0, "<unused var>"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "view"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p2}, Landroid/view/View;->getId()I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    sget p2, LPd/c;->ll_data_bundle_name:I

    .line 16
    .line 17
    if-eq p1, p2, :cond_0

    .line 18
    .line 19
    sget p2, LPd/c;->data_bundle_name_iv:I

    .line 20
    .line 21
    if-eq p1, p2, :cond_0

    .line 22
    .line 23
    sget p2, LPd/c;->data_bundle_name_tv:I

    .line 24
    .line 25
    if-ne p1, p2, :cond_1

    .line 26
    .line 27
    :cond_0
    iget-object p1, p0, LZd/F;->a:Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;

    .line 28
    .line 29
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;->t()LXd/D;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    sget v0, LPd/c;->data_bundle_name_iv:I

    .line 34
    .line 35
    invoke-virtual {p2, p3, v0}, LM1/j;->getViewByPosition(II)Landroid/view/View;

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;->t()LXd/D;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 47
    .line 48
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;->getDescription()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    if-eqz p1, :cond_1

    .line 53
    .line 54
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 55
    .line 56
    .line 57
    :cond_1
    return-void
.end method

.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 4

    .line 1
    const-string v0, "<unused var>"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    iget-object p1, p0, LZd/F;->a:Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;

    .line 10
    .line 11
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;->t()LXd/D;

    .line 12
    .line 13
    .line 14
    move-result-object p2

    .line 15
    invoke-virtual {p2, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 20
    .line 21
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 22
    .line 23
    .line 24
    move-result-object p3

    .line 25
    iget-object p3, p3, LPa/w;->b:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast p3, Lcom/google/gson/Gson;

    .line 28
    .line 29
    invoke-virtual {p3, p2}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    new-instance p3, Lkotlin/Pair;

    .line 34
    .line 35
    const-string v0, "DATA_KEY_PAYMENT_ITEM"

    .line 36
    .line 37
    invoke-direct {p3, v0, p2}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iget-object p2, p1, Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;->v:Lxf/t;

    .line 41
    .line 42
    invoke-virtual {p2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    check-cast v0, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;

    .line 47
    .line 48
    const-string v1, ""

    .line 49
    .line 50
    if-eqz v0, :cond_0

    .line 51
    .line 52
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;->getBillerId()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    if-nez v0, :cond_1

    .line 57
    .line 58
    :cond_0
    move-object v0, v1

    .line 59
    :cond_1
    new-instance v2, Lkotlin/Pair;

    .line 60
    .line 61
    const-string v3, "DATA_KEY_BILLER_ID"

    .line 62
    .line 63
    invoke-direct {v2, v3, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {p2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p2

    .line 70
    check-cast p2, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;

    .line 71
    .line 72
    if-eqz p2, :cond_3

    .line 73
    .line 74
    invoke-virtual {p2}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;->getBillerName()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p2

    .line 78
    if-nez p2, :cond_2

    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_2
    move-object v1, p2

    .line 82
    :cond_3
    :goto_0
    new-instance p2, Lkotlin/Pair;

    .line 83
    .line 84
    const-string v0, "DATA_KEY_BILLER_NAME"

    .line 85
    .line 86
    invoke-direct {p2, v0, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    filled-new-array {p3, v2, p2}, [Lkotlin/Pair;

    .line 90
    .line 91
    .line 92
    move-result-object p2

    .line 93
    invoke-static {p2}, La/a;->e([Lkotlin/Pair;)Landroid/os/Bundle;

    .line 94
    .line 95
    .line 96
    move-result-object p2

    .line 97
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/Z;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    const-string p3, "REQUEST_CODE_CLICK_PAYMENT_ITEM"

    .line 102
    .line 103
    invoke-virtual {p1, p3, p2}, Landroidx/fragment/app/Z;->setFragmentResult(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 104
    .line 105
    .line 106
    return-void
.end method
