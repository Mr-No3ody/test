.class public final synthetic LZd/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/Observer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/h;->a:I

    iput-object p1, p0, LZd/h;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onChanged(Ljava/lang/Object;)V
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-object v1, p0, LZd/h;->b:Ljava/lang/Object;

    .line 3
    .line 4
    iget v2, p0, LZd/h;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 10
    .line 11
    sget v0, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;->x0:I

    .line 12
    .line 13
    const-string v0, "it"

    .line 14
    .line 15
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 23
    .line 24
    iget-object v0, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v0, Lcom/transsnet/palmpay/core/bean/TopUpHistoryDataResp;

    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_0

    .line 33
    .line 34
    check-cast v1, Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;

    .line 35
    .line 36
    iget-object v0, v1, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 37
    .line 38
    check-cast v0, LRd/H;

    .line 39
    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    iget-object v0, v0, LRd/H;->g:Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 43
    .line 44
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p1, Lcom/transsnet/palmpay/core/bean/TopUpHistoryDataResp;

    .line 47
    .line 48
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/TopUpHistoryDataResp;->getData()Ljava/util/ArrayList;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    new-instance v2, Lj9/x;

    .line 53
    .line 54
    const/4 v3, 0x6

    .line 55
    invoke-direct {v2, v1, v3}, Lj9/x;-><init>(Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;I)V

    .line 56
    .line 57
    .line 58
    new-instance v3, Lj9/x;

    .line 59
    .line 60
    const/4 v4, 0x7

    .line 61
    invoke-direct {v3, v1, v4}, Lj9/x;-><init>(Lcom/transsnet/palmpay/airtime/ui/TopupAirtimeActivity;I)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v0, p1, v2, v3}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->initModelInputRegexData(Ljava/util/List;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;)V

    .line 65
    .line 66
    .line 67
    :cond_0
    return-void

    .line 68
    :pswitch_0
    check-cast p1, Ljava/util/Map;

    .line 69
    .line 70
    check-cast v1, Lcom/transsnet/palmpay/databundle/ui/fragment/DataBundleWalletFragment;

    .line 71
    .line 72
    iget-object v0, v1, Lcom/transsnet/palmpay/databundle/ui/fragment/DataBundleWalletFragment;->w:Lxf/t;

    .line 73
    .line 74
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    check-cast v0, Ljava/lang/String;

    .line 79
    .line 80
    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/DataBundleExtraItemInfo;

    .line 85
    .line 86
    if-eqz p1, :cond_1

    .line 87
    .line 88
    invoke-virtual {v1}, Lcom/transsnet/palmpay/databundle/ui/fragment/DataBundleWalletFragment;->u()LXd/v;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/DataBundleExtraItemInfo;->getBundleTips()Ljava/util/ArrayList;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    invoke-virtual {v0, v2}, LXd/v;->g(Ljava/util/List;)V

    .line 97
    .line 98
    .line 99
    iget-object v0, v1, Lcom/transsnet/palmpay/databundle/ui/fragment/DataBundleWalletFragment;->L:Lcom/transsnet/palmpay/teller/ui/dialog/DataBundleWalletDialog;

    .line 100
    .line 101
    if-eqz v0, :cond_1

    .line 102
    .line 103
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/DataBundleExtraItemInfo;->getBundleTips()Ljava/util/ArrayList;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/teller/ui/dialog/DataBundleWalletDialog;->updateTipsInfo(Ljava/util/List;)V

    .line 108
    .line 109
    .line 110
    :cond_1
    return-void

    .line 111
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 112
    .line 113
    if-eqz p1, :cond_2

    .line 114
    .line 115
    check-cast v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 116
    .line 117
    iput-object p1, v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Q:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 118
    .line 119
    iget-object p1, v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->Q:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 120
    .line 121
    if-eqz p1, :cond_3

    .line 122
    .line 123
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getCustomerId()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    const/4 v3, 0x0

    .line 132
    invoke-virtual {v1, v3, v0, v2, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->C(ZZLjava/lang/String;Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    goto :goto_0

    .line 136
    :cond_2
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 137
    .line 138
    :cond_3
    :goto_0
    return-void

    .line 139
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 140
    .line 141
    if-eqz p1, :cond_4

    .line 142
    .line 143
    check-cast v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;

    .line 144
    .line 145
    iput-object p1, v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->B:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 146
    .line 147
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->C(Z)V

    .line 148
    .line 149
    .line 150
    goto :goto_1

    .line 151
    :cond_4
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentHomeNGFragment;->r0:I

    .line 152
    .line 153
    :goto_1
    return-void

    .line 154
    :pswitch_3
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 155
    .line 156
    if-eqz p1, :cond_5

    .line 157
    .line 158
    check-cast v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 159
    .line 160
    iput-object p1, v1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->L:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 161
    .line 162
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->L(Z)V

    .line 163
    .line 164
    .line 165
    goto :goto_2

    .line 166
    :cond_5
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->z0:I

    .line 167
    .line 168
    :goto_2
    return-void

    .line 169
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
