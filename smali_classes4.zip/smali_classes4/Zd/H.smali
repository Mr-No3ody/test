.class public final synthetic LZd/H;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/Observer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LZd/H;->a:I

    iput-object p1, p0, LZd/H;->b:Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onChanged(Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget v0, p0, LZd/H;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, LZd/H;->b:Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;->v(Lcom/transsnet/palmpay/core/base/q;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_0
    check-cast p1, Ljava/util/Map;

    .line 20
    .line 21
    iget-object v0, p0, LZd/H;->b:Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;

    .line 22
    .line 23
    iget-object v1, v0, Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;->t:Lxf/t;

    .line 24
    .line 25
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    check-cast v1, Ljava/lang/String;

    .line 30
    .line 31
    invoke-interface {p1, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    check-cast p1, Ljava/util/ArrayList;

    .line 36
    .line 37
    if-eqz p1, :cond_0

    .line 38
    .line 39
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/TvPaymentListFragment;->u(Ljava/util/ArrayList;)V

    .line 40
    .line 41
    .line 42
    :cond_0
    return-void

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
