.class public final LZd/A;
.super Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;)V
    .locals 0

    .line 1
    iput-object p1, p0, LZd/A;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 2
    .line 3
    invoke-direct {p0}, Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onPageSelected(I)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;->onPageSelected(I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LZd/A;->a:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 5
    .line 6
    iget-object v0, v0, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->B:Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/collections/CollectionsKt;->G(ILjava/util/List;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;

    .line 13
    .line 14
    if-eqz p1, :cond_0

    .line 15
    .line 16
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvCategoryBean;->getBusinessCategoryName()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    if-nez p1, :cond_1

    .line 21
    .line 22
    :cond_0
    const-string p1, ""

    .line 23
    .line 24
    :cond_1
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    const-string v1, "PPay_TV_Btn_Category_Click"

    .line 29
    .line 30
    const-string v2, "element_name"

    .line 31
    .line 32
    invoke-static {v1, v2, p1}, LC0/G;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    check-cast p1, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 37
    .line 38
    invoke-virtual {v0, p1}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method
