.class public final LZd/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LZd/i;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LZd/i;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;I)V
    .locals 0

    .line 2
    iput p3, p0, LZd/i;->a:I

    iput-object p2, p0, LZd/i;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, LZd/i;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 7
    .line 8
    const-string v0, "it"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto/16 :goto_3

    .line 18
    .line 19
    :cond_0
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    if-eqz v0, :cond_d

    .line 23
    .line 24
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 25
    .line 26
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp;

    .line 29
    .line 30
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget-object v2, p0, LZd/i;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 35
    .line 36
    const-string v3, ""

    .line 37
    .line 38
    const-wide/16 v4, 0x0

    .line 39
    .line 40
    if-eqz v0, :cond_9

    .line 41
    .line 42
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp;->getData()Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    const/4 v0, 0x0

    .line 47
    if-eqz p1, :cond_4

    .line 48
    .line 49
    iget-object v3, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->L:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 50
    .line 51
    if-eqz v3, :cond_1

    .line 52
    .line 53
    invoke-virtual {v3}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    goto :goto_0

    .line 58
    :cond_1
    move-object v3, v0

    .line 59
    :goto_0
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    if-nez v3, :cond_3

    .line 64
    .line 65
    iget-object v3, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->L:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 66
    .line 67
    if-eqz v3, :cond_2

    .line 68
    .line 69
    invoke-virtual {v3}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    :cond_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getBillerId()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    invoke-static {v0, v3, v1}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-nez v0, :cond_3

    .line 82
    .line 83
    goto/16 :goto_3

    .line 84
    .line 85
    :cond_3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getBillerId()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getPaymentItemId()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getCustomerId()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v3

    .line 97
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/QueryLastBillerRsp$Data;->getBusinessAmount()J

    .line 98
    .line 99
    .line 100
    move-result-wide v4

    .line 101
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    invoke-static {v2, v0, v1, v3, p1}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->M(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 106
    .line 107
    .line 108
    goto/16 :goto_3

    .line 109
    .line 110
    :cond_4
    iget-object p1, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->L:Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;

    .line 111
    .line 112
    if-eqz p1, :cond_5

    .line 113
    .line 114
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/ChannelDataItemBean;->getBillerId()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    :cond_5
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 119
    .line 120
    .line 121
    move-result p1

    .line 122
    if-nez p1, :cond_6

    .line 123
    .line 124
    goto/16 :goto_3

    .line 125
    .line 126
    :cond_6
    iget-object p1, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->X:Ljava/util/ArrayList;

    .line 127
    .line 128
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 129
    .line 130
    .line 131
    move-result v0

    .line 132
    if-nez v0, :cond_f

    .line 133
    .line 134
    iget-object v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->X:Ljava/util/ArrayList;

    .line 135
    .line 136
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    check-cast v0, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 141
    .line 142
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 147
    .line 148
    .line 149
    move-result-object v4

    .line 150
    invoke-static {v2, v0, v3, v3, v4}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->M(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 151
    .line 152
    .line 153
    iget-object v0, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 154
    .line 155
    check-cast v0, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 156
    .line 157
    if-eqz v0, :cond_7

    .line 158
    .line 159
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object v4

    .line 163
    check-cast v4, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 164
    .line 165
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object v4

    .line 169
    invoke-virtual {v0, v4, v1, v1}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->e(Ljava/lang/String;ZZ)V

    .line 170
    .line 171
    .line 172
    :cond_7
    iget-object v0, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 173
    .line 174
    check-cast v0, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 175
    .line 176
    if-eqz v0, :cond_f

    .line 177
    .line 178
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 183
    .line 184
    invoke-virtual {p1}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    if-nez p1, :cond_8

    .line 189
    .line 190
    goto :goto_1

    .line 191
    :cond_8
    move-object v3, p1

    .line 192
    :goto_1
    invoke-virtual {v0, v3}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->f(Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    goto :goto_3

    .line 196
    :cond_9
    iget-object v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->X:Ljava/util/ArrayList;

    .line 197
    .line 198
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 199
    .line 200
    .line 201
    move-result v0

    .line 202
    if-nez v0, :cond_c

    .line 203
    .line 204
    iget-object v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->X:Ljava/util/ArrayList;

    .line 205
    .line 206
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    check-cast v0, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 211
    .line 212
    invoke-virtual {v0}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 217
    .line 218
    .line 219
    move-result-object v4

    .line 220
    invoke-static {v2, v0, v3, v3, v4}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->M(Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 221
    .line 222
    .line 223
    iget-object v0, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 224
    .line 225
    check-cast v0, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 226
    .line 227
    iget-object v4, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->X:Ljava/util/ArrayList;

    .line 228
    .line 229
    if-eqz v0, :cond_a

    .line 230
    .line 231
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v5

    .line 235
    check-cast v5, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 236
    .line 237
    invoke-virtual {v5}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object v5

    .line 241
    invoke-virtual {v0, v5, v1, v1}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->e(Ljava/lang/String;ZZ)V

    .line 242
    .line 243
    .line 244
    :cond_a
    iget-object v0, v2, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 245
    .line 246
    check-cast v0, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;

    .line 247
    .line 248
    if-eqz v0, :cond_c

    .line 249
    .line 250
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v2

    .line 254
    check-cast v2, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;

    .line 255
    .line 256
    invoke-virtual {v2}, Lcom/transsnet/palmpay/teller/bean/BillerListItemBean;->getBillerId()Ljava/lang/String;

    .line 257
    .line 258
    .line 259
    move-result-object v2

    .line 260
    if-nez v2, :cond_b

    .line 261
    .line 262
    goto :goto_2

    .line 263
    :cond_b
    move-object v3, v2

    .line 264
    :goto_2
    invoke-virtual {v0, v3}, Lcom/transsnet/palmpay/teller/viewmodel/BillPaymentElectricityHomeViewModel;->f(Ljava/lang/String;)V

    .line 265
    .line 266
    .line 267
    :cond_c
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 268
    .line 269
    .line 270
    move-result-object p1

    .line 271
    new-array v0, v1, [Ljava/lang/Object;

    .line 272
    .line 273
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 274
    .line 275
    .line 276
    goto :goto_3

    .line 277
    :cond_d
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 278
    .line 279
    if-eqz v0, :cond_e

    .line 280
    .line 281
    goto :goto_3

    .line 282
    :cond_e
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 283
    .line 284
    if-eqz v0, :cond_10

    .line 285
    .line 286
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 287
    .line 288
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 289
    .line 290
    new-array v0, v1, [Ljava/lang/Object;

    .line 291
    .line 292
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 293
    .line 294
    .line 295
    :cond_f
    :goto_3
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 296
    .line 297
    return-object p1

    .line 298
    :cond_10
    new-instance p1, Lxf/l;

    .line 299
    .line 300
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 301
    .line 302
    .line 303
    throw p1

    .line 304
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 305
    .line 306
    const-string v0, "it"

    .line 307
    .line 308
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 309
    .line 310
    .line 311
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 312
    .line 313
    if-eqz v0, :cond_11

    .line 314
    .line 315
    goto :goto_4

    .line 316
    :cond_11
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 317
    .line 318
    if-eqz v0, :cond_12

    .line 319
    .line 320
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 321
    .line 322
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 323
    .line 324
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;

    .line 325
    .line 326
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 327
    .line 328
    .line 329
    move-result v0

    .line 330
    if-eqz v0, :cond_14

    .line 331
    .line 332
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp;->data:Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;

    .line 333
    .line 334
    if-eqz p1, :cond_14

    .line 335
    .line 336
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMinAmount()J

    .line 337
    .line 338
    .line 339
    move-result-wide v0

    .line 340
    iget-object v2, p0, LZd/i;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 341
    .line 342
    iput-wide v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->t0:J

    .line 343
    .line 344
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/QueryLimitAmountResp$DataBean;->getMaxAmount()J

    .line 345
    .line 346
    .line 347
    move-result-wide v0

    .line 348
    iput-wide v0, v2, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;->s0:J

    .line 349
    .line 350
    goto :goto_4

    .line 351
    :cond_12
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 352
    .line 353
    if-eqz v0, :cond_13

    .line 354
    .line 355
    goto :goto_4

    .line 356
    :cond_13
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 357
    .line 358
    if-eqz v0, :cond_15

    .line 359
    .line 360
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 361
    .line 362
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 363
    .line 364
    const/4 v0, 0x0

    .line 365
    new-array v0, v0, [Ljava/lang/Object;

    .line 366
    .line 367
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 368
    .line 369
    .line 370
    :cond_14
    :goto_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 371
    .line 372
    return-object p1

    .line 373
    :cond_15
    new-instance p1, Lxf/l;

    .line 374
    .line 375
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 376
    .line 377
    .line 378
    throw p1

    .line 379
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/core/base/q;

    .line 380
    .line 381
    const-string v0, "it"

    .line 382
    .line 383
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 384
    .line 385
    .line 386
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/o;

    .line 387
    .line 388
    iget-object v1, p0, LZd/i;->b:Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentElectricityHomeFragment;

    .line 389
    .line 390
    const/4 v2, 0x1

    .line 391
    if-eqz v0, :cond_16

    .line 392
    .line 393
    invoke-interface {v1, v2, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 394
    .line 395
    .line 396
    goto :goto_5

    .line 397
    :cond_16
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/p;

    .line 398
    .line 399
    const-string v3, "/main/trans_history"

    .line 400
    .line 401
    const-string v4, ""

    .line 402
    .line 403
    const/4 v5, 0x0

    .line 404
    if-eqz v0, :cond_18

    .line 405
    .line 406
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 407
    .line 408
    .line 409
    check-cast p1, Lcom/transsnet/palmpay/core/base/p;

    .line 410
    .line 411
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/p;->a:Ljava/lang/Object;

    .line 412
    .line 413
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 414
    .line 415
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 416
    .line 417
    .line 418
    move-result-object v0

    .line 419
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 420
    .line 421
    check-cast p1, Ljava/util/ArrayList;

    .line 422
    .line 423
    if-eqz p1, :cond_17

    .line 424
    .line 425
    move-object v4, p1

    .line 426
    :cond_17
    iget-object p1, v0, LPa/w;->b:Ljava/lang/Object;

    .line 427
    .line 428
    check-cast p1, Lcom/google/gson/Gson;

    .line 429
    .line 430
    invoke-virtual {p1, v4}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 431
    .line 432
    .line 433
    move-result-object p1

    .line 434
    invoke-static {v3, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->G(Ljava/lang/String;Ljava/lang/String;)V

    .line 435
    .line 436
    .line 437
    goto :goto_5

    .line 438
    :cond_18
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/m;

    .line 439
    .line 440
    if-eqz v0, :cond_19

    .line 441
    .line 442
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 443
    .line 444
    .line 445
    goto :goto_5

    .line 446
    :cond_19
    instance-of v0, p1, Lcom/transsnet/palmpay/core/base/n;

    .line 447
    .line 448
    if-eqz v0, :cond_1a

    .line 449
    .line 450
    invoke-interface {v1, v5, v2}, Lcom/transsnet/palmpay/core/base/IBaseView;->showLoadingDialog(ZZ)V

    .line 451
    .line 452
    .line 453
    move-object v0, p1

    .line 454
    check-cast v0, Lcom/transsnet/palmpay/core/base/n;

    .line 455
    .line 456
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/n;->a:Ljava/lang/String;

    .line 457
    .line 458
    new-array v1, v5, [Ljava/lang/Object;

    .line 459
    .line 460
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 461
    .line 462
    .line 463
    check-cast p1, Lcom/transsnet/palmpay/core/base/n;

    .line 464
    .line 465
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 466
    .line 467
    .line 468
    invoke-static {v3, v4}, Lcom/palmpay/lib/apm/launchcounter/util/d;->G(Ljava/lang/String;Ljava/lang/String;)V

    .line 469
    .line 470
    .line 471
    :goto_5
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 472
    .line 473
    return-object p1

    .line 474
    :cond_1a
    new-instance p1, Lxf/l;

    .line 475
    .line 476
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 477
    .line 478
    .line 479
    throw p1

    .line 480
    nop

    .line 481
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
