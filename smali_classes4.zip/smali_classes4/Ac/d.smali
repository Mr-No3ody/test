.class public final LAc/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static main_about_logo:I = 0x7f0809a7

.field public static main_bank_card_expired:I = 0x7f0809a8

.field public static main_bg_home_account_bar_fund_button:I = 0x7f0809a9

.field public static main_bg_me_total_assets:I = 0x7f0809aa

.field public static main_bg_message_number:I = 0x7f0809ab

.field public static main_bg_palmzone_coupon:I = 0x7f0809ac

.field public static main_bg_palmzone_coupon_package:I = 0x7f0809ad

.field public static main_bg_reward_coupon_combo_title:I = 0x7f0809ae

.field public static main_bg_saving_cashbox:I = 0x7f0809af

.field public static main_bg_saving_exclusive:I = 0x7f0809b0

.field public static main_bg_select_tag:I = 0x7f0809b1

.field public static main_bg_task_init_process:I = 0x7f0809b2

.field public static main_bg_task_item_corner:I = 0x7f0809b3

.field public static main_bg_task_node:I = 0x7f0809b4

.field public static main_bg_unverify_user:I = 0x7f0809b5

.field public static main_bg_white_eye:I = 0x7f0809b6

.field public static main_btn_bg_rewards_coupon_use:I = 0x7f0809b7

.field public static main_btn_card_state_2:I = 0x7f0809b8

.field public static main_cash_box_shadow:I = 0x7f0809b9

.field public static main_coin_rain_finger_icon:I = 0x7f0809ba

.field public static main_exclusive_title:I = 0x7f0809bb

.field public static main_eye_closed_icon_white:I = 0x7f0809bc

.field public static main_eye_opened_icon_white:I = 0x7f0809bd

.field public static main_finger1:I = 0x7f0809be

.field public static main_gradient_blue_btn_bg:I = 0x7f0809bf

.field public static main_gradient_fund_top_bg:I = 0x7f0809c0

.field public static main_gradient_purple_btn_bg:I = 0x7f0809c1

.field public static main_guest_second_title:I = 0x7f0809c2

.field public static main_head_picture:I = 0x7f0809c3

.field public static main_home_account_bar_bg:I = 0x7f0809c4

.field public static main_home_me_level_bg:I = 0x7f0809c5

.field public static main_home_me_premium_account_bar_bg:I = 0x7f0809c6

.field public static main_home_me_tab_asset_bg:I = 0x7f0809c7

.field public static main_home_message_center_holder:I = 0x7f0809c8

.field public static main_home_palmzone_tasks_btn_bg:I = 0x7f0809c9

.field public static main_home_premium_account_bar_bg:I = 0x7f0809ca

.field public static main_home_premium_account_bar_bg_2:I = 0x7f0809cb

.field public static main_ic_refer_earn_cash_milestone:I = 0x7f0809cc

.field public static main_ic_reward_progress_arrow_inactive:I = 0x7f0809cd

.field public static main_icon_cbn:I = 0x7f0809ce

.field public static main_icon_comment_face:I = 0x7f0809cf

.field public static main_icon_finger:I = 0x7f0809d0

.field public static main_icon_hot_product:I = 0x7f0809d1

.field public static main_icon_mine_balance_palmpay:I = 0x7f0809d2

.field public static main_icon_palmpay_black:I = 0x7f0809d3

.field public static main_icon_premium:I = 0x7f0809d4

.field public static main_icon_rewards_3:I = 0x7f0809d5

.field public static main_icon_rewards_corner:I = 0x7f0809d6

.field public static main_icon_saving_lion:I = 0x7f0809d7

.field public static main_icon_share_primary_18dp:I = 0x7f0809d8

.field public static main_icon_spend_save_arrow:I = 0x7f0809d9

.field public static main_icon_star:I = 0x7f0809da

.field public static main_indicator_dot_1:I = 0x7f0809db

.field public static main_invitation_code_bg:I = 0x7f0809dc

.field public static main_item_bg_welcome_back_gift:I = 0x7f0809dd

.field public static main_item_edit_billpayment_icon:I = 0x7f0809de

.field public static main_item_edit_billpayment_icon_unable:I = 0x7f0809df

.field public static main_item_icon_billpayment_minus:I = 0x7f0809e0

.field public static main_life_default_banner:I = 0x7f0809e1

.field public static main_me_guide_top:I = 0x7f0809e2

.field public static main_me_icon_store_copy:I = 0x7f0809e3

.field public static main_me_icon_store_top:I = 0x7f0809e4

.field public static main_merchant_photo:I = 0x7f0809e5

.field public static main_merchant_photo_gray:I = 0x7f0809e6

.field public static main_merchant_qrcode:I = 0x7f0809e7

.field public static main_merchant_qrcode_gray:I = 0x7f0809e8

.field public static main_merchant_qrcode_selector:I = 0x7f0809e9

.field public static main_merchant_save:I = 0x7f0809ea

.field public static main_message_common:I = 0x7f0809eb

.field public static main_message_payments:I = 0x7f0809ec

.field public static main_money_in:I = 0x7f0809ed

.field public static main_money_out:I = 0x7f0809ee

.field public static main_more_rewards_title:I = 0x7f0809ef

.field public static main_my_business:I = 0x7f0809f0

.field public static main_new_msg:I = 0x7f0809f1

.field public static main_new_version:I = 0x7f0809f2

.field public static main_no_bank_account_icon:I = 0x7f0809f3

.field public static main_no_bank_card_icon:I = 0x7f0809f4

.field public static main_offline_qr_code_bg:I = 0x7f0809f5

.field public static main_one_million_shield:I = 0x7f0809f6

.field public static main_palm_safe_logo:I = 0x7f0809f7

.field public static main_point:I = 0x7f0809f8

.field public static main_pop_bg:I = 0x7f0809f9

.field public static main_pop_bg_2:I = 0x7f0809fa

.field public static main_progress_bar_drawable:I = 0x7f0809fb

.field public static main_qrcode_share_bg:I = 0x7f0809fc

.field public static main_qrcode_share_white_bg:I = 0x7f0809fd

.field public static main_rain_reward:I = 0x7f0809fe

.field public static main_rect_bg_7b43fa_corner_12:I = 0x7f0809ff

.field public static main_rect_bg_7b43fa_corner_tl_tr_12:I = 0x7f080a00

.field public static main_rect_bg_secondary_corner_bl_br_12:I = 0x7f080a01

.field public static main_rect_bg_secondary_corner_bl_br_4:I = 0x7f080a02

.field public static main_rect_bg_warning_corner_tr_tl_br_4:I = 0x7f080a03

.field public static main_rect_bg_zone_task_tl_tr_24:I = 0x7f080a04

.field public static main_refer_earn_progress_track:I = 0x7f080a05

.field public static main_reward_ad_skeleton_bg:I = 0x7f080a06

.field public static main_reward_bg_cash:I = 0x7f080a07

.field public static main_reward_bg_coupon:I = 0x7f080a08

.field public static main_reward_bg_points:I = 0x7f080a09

.field public static main_reward_bg_trialcash:I = 0x7f080a0a

.field public static main_reward_coupon_combo_bg:I = 0x7f080a0b

.field public static main_reward_coupon_combo_claim_image:I = 0x7f080a0c

.field public static main_reward_coupon_item_bg:I = 0x7f080a0d

.field public static main_reward_coupon_item_bg_big:I = 0x7f080a0e

.field public static main_reward_coupon_single_item_bg_1:I = 0x7f080a0f

.field public static main_reward_coupon_single_item_bg_2:I = 0x7f080a10

.field public static main_reward_header_skeleton_bg:I = 0x7f080a11

.field public static main_reward_lucky_wish_skeleton_bg:I = 0x7f080a12

.field public static main_reward_premium_benefits_bg:I = 0x7f080a13

.field public static main_reward_premium_benefits_skeleton_bg:I = 0x7f080a14

.field public static main_reward_premium_trial_bg:I = 0x7f080a15

.field public static main_rewards_hot:I = 0x7f080a16

.field public static main_rewards_hot_2:I = 0x7f080a17

.field public static main_rewards_hub_skeleton_bg:I = 0x7f080a18

.field public static main_rewards_item_bg:I = 0x7f080a19

.field public static main_rewards_task_skeleton_bg:I = 0x7f080a1a

.field public static main_rewards_top_bg:I = 0x7f080a1b

.field public static main_rewards_top_icon:I = 0x7f080a1c

.field public static main_rm_qrcode_img_bg:I = 0x7f080a1d

.field public static main_saving_task_bg:I = 0x7f080a1e

.field public static main_shape_reward_progress_node_active:I = 0x7f080a1f

.field public static main_shape_reward_progress_node_inactive:I = 0x7f080a20

.field public static main_smarter_corner:I = 0x7f080a21

.field public static main_stock_down:I = 0x7f080a22

.field public static main_stock_up:I = 0x7f080a23

.field public static main_top_bg_rewards:I = 0x7f080a28

.field public static main_turn_on_save:I = 0x7f080a29

.field public static main_update_dialog_header:I = 0x7f080a2a

.field public static main_update_mark_bg_2:I = 0x7f080a2b

.field public static main_wealth_bg_tip:I = 0x7f080a2c

.field public static main_welcome_back_card_bg:I = 0x7f080a2d

.field public static main_welcome_back_card_bg_1:I = 0x7f080a2e

.field public static main_welcome_back_coupon_bg:I = 0x7f080a2f

.field public static main_welcome_back_coupon_list_bg:I = 0x7f080a30

.field public static main_welcome_back_head_bg:I = 0x7f080a31

.field public static main_welcome_back_page_bg:I = 0x7f080a32

.field public static main_welcome_back_title:I = 0x7f080a33

.field public static main_widget_bundle:I = 0x7f080a34

.field public static main_widget_pay_bills:I = 0x7f080a35

.field public static main_widget_send_money:I = 0x7f080a36

.field public static main_widget_topup_airtime:I = 0x7f080a37

.field public static main_zone_top_bg:I = 0x7f080a38


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
