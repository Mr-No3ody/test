.class public final LAc/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static main_saving_task_lion:I = 0x7f130020

.field public static main_upgrade:I = 0x7f130021


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
