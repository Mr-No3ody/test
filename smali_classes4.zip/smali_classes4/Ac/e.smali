.class public final LAc/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static aatu_amount_item:I = 0x7f0a0031

.field public static aatu_order_data_area:I = 0x7f0a0032

.field public static aatu_payment_method_item:I = 0x7f0a0033

.field public static aatu_points_earnd_item:I = 0x7f0a0034

.field public static aatu_reference_number_item:I = 0x7f0a0035

.field public static aaturv_result_progress_view:I = 0x7f0a0038

.field public static acap_title_bar:I = 0x7f0a0048

.field public static acap_title_info:I = 0x7f0a0049

.field public static acapbo_amount_item:I = 0x7f0a004c

.field public static acapbo_bank_card_item:I = 0x7f0a004d

.field public static acapbo_fee_item:I = 0x7f0a004e

.field public static acapbo_next_btn:I = 0x7f0a004f

.field public static acapbo_payee_icon:I = 0x7f0a0050

.field public static acapbo_payee_name:I = 0x7f0a0051

.field public static acapbo_point_earned_item:I = 0x7f0a0052

.field public static acapbo_point_used_item:I = 0x7f0a0053

.field public static accountBottomModule:I = 0x7f0a0083

.field public static accountMgrItemStub:I = 0x7f0a0084

.field public static accountMobileItemStub:I = 0x7f0a0085

.field public static accountNoBarStub:I = 0x7f0a0086

.field public static accountTopModule:I = 0x7f0a0087

.field public static acl_rev:I = 0x7f0a008f

.field public static acr_countDownArea:I = 0x7f0a0090

.field public static acr_root:I = 0x7f0a0091

.field public static acr_time_remain:I = 0x7f0a0092

.field public static actual_payment_tv:I = 0x7f0a00ab

.field public static actur_ad:I = 0x7f0a00ac

.field public static actur_complete_btn:I = 0x7f0a00ad

.field public static actur_done_tv:I = 0x7f0a00ae

.field public static actur_hint_tv:I = 0x7f0a00af

.field public static actur_iv:I = 0x7f0a00b0

.field public static actur_result_title_tv:I = 0x7f0a00b1

.field public static actur_title_tv:I = 0x7f0a00b2

.field public static adBannerLifeHome:I = 0x7f0a00b5

.field public static adBannerTop:I = 0x7f0a00b6

.field public static adCompliance:I = 0x7f0a00b8

.field public static adHome1:I = 0x7f0a00b9

.field public static adHome2:I = 0x7f0a00ba

.field public static adHome3:I = 0x7f0a00bb

.field public static adHomeGuestTop:I = 0x7f0a00bc

.field public static adMiddle:I = 0x7f0a00bf

.field public static adTopModule:I = 0x7f0a00c3

.field public static adView:I = 0x7f0a00c4

.field public static adViewLayout:I = 0x7f0a00c6

.field public static adViewStub:I = 0x7f0a00c7

.field public static add_bt:I = 0x7f0a00de

.field public static add_card_container:I = 0x7f0a00df

.field public static add_card_tv:I = 0x7f0a00e0

.field public static addressItemStub:I = 0x7f0a00e4

.field public static agree_tv:I = 0x7f0a00eb

.field public static aivCompliance:I = 0x7f0a00fe

.field public static amount:I = 0x7f0a010f

.field public static amount_content:I = 0x7f0a011b

.field public static amount_label:I = 0x7f0a011d

.field public static apbd_amount_list:I = 0x7f0a0140

.field public static apbd_expired_date_tv:I = 0x7f0a0141

.field public static apbd_origin_trading_number_tv:I = 0x7f0a0142

.field public static aqc_cash_in:I = 0x7f0a0157

.field public static aqc_cash_in_item:I = 0x7f0a0158

.field public static aqc_pay_qrcode:I = 0x7f0a0159

.field public static aqc_pay_qrcode_item:I = 0x7f0a015a

.field public static aqc_receive_money:I = 0x7f0a015b

.field public static aqc_receive_money_item:I = 0x7f0a015c

.field public static ard_amount_list:I = 0x7f0a0162

.field public static ard_bill_type:I = 0x7f0a0163

.field public static ard_create_time:I = 0x7f0a0164

.field public static ard_hint_tv:I = 0x7f0a0165

.field public static ard_item_payment_method:I = 0x7f0a0166

.field public static ard_order_number:I = 0x7f0a0167

.field public static ard_posted_time:I = 0x7f0a0168

.field public static ard_remark:I = 0x7f0a0169

.field public static ard_remark_container:I = 0x7f0a016a

.field public static ard_remark_divider:I = 0x7f0a016b

.field public static ard_title_area:I = 0x7f0a016c

.field public static arrow1:I = 0x7f0a016e

.field public static arrow2:I = 0x7f0a016f

.field public static arrow3:I = 0x7f0a0170

.field public static asyncBanner:I = 0x7f0a0177

.field public static asyncComment:I = 0x7f0a0178

.field public static asyncGuestTopAd:I = 0x7f0a0179

.field public static asyncRecomend:I = 0x7f0a017a

.field public static asyncSingleAd:I = 0x7f0a017b

.field public static asyncTask:I = 0x7f0a017c

.field public static asyncTopAccountBar:I = 0x7f0a017d

.field public static asyncTopAdView:I = 0x7f0a017e

.field public static asyncTopFunction:I = 0x7f0a017f

.field public static asyncTransactionHistory:I = 0x7f0a0180

.field public static atu_bill_process:I = 0x7f0a0184

.field public static authorization_desc:I = 0x7f0a01a1

.field public static awrd_sv:I = 0x7f0a01bb

.field public static back_bt:I = 0x7f0a01bd

.field public static bank_card_or_account_rv:I = 0x7f0a01cd

.field public static bank_content:I = 0x7f0a01ce

.field public static bank_icon:I = 0x7f0a01cf

.field public static bank_name:I = 0x7f0a01d2

.field public static bank_num:I = 0x7f0a01d4

.field public static bannerAdId:I = 0x7f0a01d8

.field public static bannerIndicatorView:I = 0x7f0a01db

.field public static bannerView:I = 0x7f0a01de

.field public static banner_indicator_view:I = 0x7f0a01e4

.field public static barrier:I = 0x7f0a01e6

.field public static barrierCouponBg:I = 0x7f0a01e9

.field public static barrier_right:I = 0x7f0a01fe

.field public static bgView:I = 0x7f0a0211

.field public static billList:I = 0x7f0a0214

.field public static birthdayItemStub:I = 0x7f0a022e

.field public static bottomBarrier:I = 0x7f0a0241

.field public static bottomGroup:I = 0x7f0a0243

.field public static bottomSpace:I = 0x7f0a0245

.field public static bottomStub:I = 0x7f0a0246

.field public static bottomTabViewStub:I = 0x7f0a0247

.field public static bottomViewContainer:I = 0x7f0a0249

.field public static bottomViewStub:I = 0x7f0a024a

.field public static btn:I = 0x7f0a0266

.field public static btnAction:I = 0x7f0a0267

.field public static btnAgree:I = 0x7f0a026b

.field public static btnCancel:I = 0x7f0a0273

.field public static btnCheckSoExist:I = 0x7f0a0276

.field public static btnCheckSoPath:I = 0x7f0a0277

.field public static btnClaim:I = 0x7f0a0278

.field public static btnConfirm:I = 0x7f0a027a

.field public static btnCopySoFile:I = 0x7f0a027f

.field public static btnGo:I = 0x7f0a0289

.field public static btnGoByOneKey:I = 0x7f0a028a

.field public static btnGoToARouterActivity:I = 0x7f0a028b

.field public static btnGoToInitModuleActivity:I = 0x7f0a028c

.field public static btnInstall:I = 0x7f0a028e

.field public static btnInviteNow:I = 0x7f0a0290

.field public static btnIsInstalled:I = 0x7f0a0291

.field public static btnKyc:I = 0x7f0a0296

.field public static btnLogOut:I = 0x7f0a0298

.field public static btnNext:I = 0x7f0a0299

.field public static btnOk:I = 0x7f0a029b

.field public static btnOp:I = 0x7f0a029c

.field public static btnRight:I = 0x7f0a02a7

.field public static btnRightClick:I = 0x7f0a02a8

.field public static btnSignUp:I = 0x7f0a02ad

.field public static btnTransfer:I = 0x7f0a02b1

.field public static btnTrial:I = 0x7f0a02b2

.field public static btnTurnOn:I = 0x7f0a02b3

.field public static btnUpgrade:I = 0x7f0a02b7

.field public static btnUse:I = 0x7f0a02b8

.field public static btnVerify:I = 0x7f0a02b9

.field public static btn_view_receipt:I = 0x7f0a02cd

.field public static bundle_app_bar:I = 0x7f0a02d0

.field public static business_account_number_text:I = 0x7f0a02d4

.field public static buttonContainer:I = 0x7f0a02d6

.field public static cardView:I = 0x7f0a0305

.field public static card_bg:I = 0x7f0a0306

.field public static cashBoxIntroductionView:I = 0x7f0a030d

.field public static cash_in_arrow_iv:I = 0x7f0a0310

.field public static cash_in_container:I = 0x7f0a0311

.field public static ch_act_img_dragview:I = 0x7f0a038a

.field public static ch_scrollview:I = 0x7f0a038b

.field public static ch_signup_login_text_area_stub:I = 0x7f0a038c

.field public static ch_top_bar:I = 0x7f0a038d

.field public static checkAddress:I = 0x7f0a0399

.field public static clAutomaticDarkMode:I = 0x7f0a03e8

.field public static clCard:I = 0x7f0a03ee

.field public static clEarnedCash:I = 0x7f0a03f1

.field public static clMiddleRow:I = 0x7f0a03ff

.field public static clPersonalKycLevelRow:I = 0x7f0a0404

.field public static clProgress:I = 0x7f0a0405

.field public static clTomorrowBadge:I = 0x7f0a040a

.field public static clad_btn_container:I = 0x7f0a0472

.field public static close:I = 0x7f0a048e

.field public static common_report_item:I = 0x7f0a04ff

.field public static complete_bt:I = 0x7f0a0503

.field public static complete_button:I = 0x7f0a0504

.field public static constraintLayout1:I = 0x7f0a051b

.field public static constraintLayout2:I = 0x7f0a051c

.field public static container:I = 0x7f0a0530

.field public static container_new_user:I = 0x7f0a0531

.field public static content_root:I = 0x7f0a053c

.field public static copy_icon:I = 0x7f0a054c

.field public static cornerAd:I = 0x7f0a0561

.field public static couponView:I = 0x7f0a0572

.field public static cptv_tv1:I = 0x7f0a0591

.field public static cslEmpty:I = 0x7f0a06b4

.field public static cslHotContent:I = 0x7f0a06b5

.field public static cslManager:I = 0x7f0a06b6

.field public static cslTask:I = 0x7f0a06b7

.field public static cslTop:I = 0x7f0a06b8

.field public static csl_exclusiveList:I = 0x7f0a06ba

.field public static csl_saving_report:I = 0x7f0a06bb

.field public static ctl_frame:I = 0x7f0a06c0

.field public static ctl_title:I = 0x7f0a06c1

.field public static default_card_item:I = 0x7f0a0713

.field public static detailTitle:I = 0x7f0a0723

.field public static disagree_tv:I = 0x7f0a0750

.field public static divider:I = 0x7f0a0757

.field public static divider1:I = 0x7f0a0758

.field public static dividerRevoke:I = 0x7f0a0761

.field public static dividerView:I = 0x7f0a0762

.field public static dragViewStub:I = 0x7f0a0781

.field public static editMail:I = 0x7f0a0792

.field public static editNickName:I = 0x7f0a0796

.field public static emailItemStub:I = 0x7f0a07a8

.field public static emptyView:I = 0x7f0a07ac

.field public static empty_desc:I = 0x7f0a07af

.field public static empty_faq:I = 0x7f0a07b0

.field public static empty_icon:I = 0x7f0a07b1

.field public static empty_title:I = 0x7f0a07b2

.field public static endBarrier:I = 0x7f0a07b8

.field public static etSoName:I = 0x7f0a07ca

.field public static et_arouter_path:I = 0x7f0a07d1

.field public static et_module_name:I = 0x7f0a07d7

.field public static et_sub_activity_name:I = 0x7f0a07da

.field public static exclusiveViewStub:I = 0x7f0a07dc

.field public static faceGuideView:I = 0x7f0a0802

.field public static fhFinanceAdStub:I = 0x7f0a091a

.field public static fhInvestAdStub:I = 0x7f0a091b

.field public static fhRewardsAdStub:I = 0x7f0a091c

.field public static fh_ivInvest:I = 0x7f0a091d

.field public static fh_iv_finance:I = 0x7f0a091e

.field public static fh_iv_home:I = 0x7f0a091f

.field public static fh_iv_me:I = 0x7f0a0920

.field public static fh_iv_zone:I = 0x7f0a0921

.field public static fh_tvInvest:I = 0x7f0a0922

.field public static fh_tv_finance:I = 0x7f0a0923

.field public static fh_tv_home:I = 0x7f0a0924

.field public static fh_tv_me:I = 0x7f0a0925

.field public static fh_tv_zone:I = 0x7f0a0926

.field public static fhm_kyc_stub:I = 0x7f0a0927

.field public static fhm_my_business_stub:I = 0x7f0a0928

.field public static fhm_my_quick_access_stub:I = 0x7f0a0929

.field public static fhm_rcv:I = 0x7f0a092a

.field public static filterFloatLayout:I = 0x7f0a0935

.field public static fin_fl:I = 0x7f0a0936

.field public static flBody:I = 0x7f0a0960

.field public static flFilter:I = 0x7f0a0962

.field public static flFilterAll:I = 0x7f0a0963

.field public static flFilterIO:I = 0x7f0a0964

.field public static flHintBar:I = 0x7f0a0965

.field public static fl_container:I = 0x7f0a0975

.field public static floatAdView:I = 0x7f0a0987

.field public static fragment:I = 0x7f0a099d

.field public static fragmentContainer:I = 0x7f0a099f

.field public static friendItemStub:I = 0x7f0a09da

.field public static fullNameItemStub:I = 0x7f0a09dd

.field public static funListContainer:I = 0x7f0a09e1

.field public static funListContainerStub:I = 0x7f0a09e2

.field public static funListContainerV2:I = 0x7f0a09e3

.field public static funListContainerV2Stub:I = 0x7f0a09e4

.field public static functionIndicator:I = 0x7f0a09e6

.field public static functionList:I = 0x7f0a09e7

.field public static functionListV2:I = 0x7f0a09e8

.field public static functionRow0:I = 0x7f0a09e9

.field public static functionRow1:I = 0x7f0a09ea

.field public static g_card_list:I = 0x7f0a09ec

.field public static g_status:I = 0x7f0a09f5

.field public static genderItemStub:I = 0x7f0a09fb

.field public static glCouponSplit:I = 0x7f0a0a06

.field public static group1:I = 0x7f0a0a18

.field public static groupAccountNo:I = 0x7f0a0a19

.field public static groupExtend:I = 0x7f0a0a1e

.field public static groupNotNetwork:I = 0x7f0a0a22

.field public static groupNotificationEnable:I = 0x7f0a0a23

.field public static groupPreview:I = 0x7f0a0a27

.field public static guestAdView:I = 0x7f0a0a42

.field public static guestStub:I = 0x7f0a0a43

.field public static guestViewContainer:I = 0x7f0a0a44

.field public static guideLine:I = 0x7f0a0a45

.field public static guide_line:I = 0x7f0a0a46

.field public static hScrollView:I = 0x7f0a0a49

.field public static header:I = 0x7f0a0a4d

.field public static headerBottomBarrier:I = 0x7f0a0a4e

.field public static header_tv:I = 0x7f0a0a51

.field public static headlineCardContainer:I = 0x7f0a0a53

.field public static headlineCardViewStub:I = 0x7f0a0a54

.field public static homeBanner1:I = 0x7f0a0a5d

.field public static homeBanner2:I = 0x7f0a0a5e

.field public static homeBottomAd:I = 0x7f0a0a5f

.field public static homeCouponPackage:I = 0x7f0a0a60

.field public static horizontalBarrier:I = 0x7f0a0a64

.field public static iconArrow:I = 0x7f0a0a78

.field public static iconImage:I = 0x7f0a0a79

.field public static ihm_arrow_iv:I = 0x7f0a0a86

.field public static ihm_desc_tv:I = 0x7f0a0a87

.field public static ihm_menu_iv:I = 0x7f0a0a88

.field public static ihm_menu_tv:I = 0x7f0a0a89

.field public static ihm_single_ad:I = 0x7f0a0a8a

.field public static ihphm_tv:I = 0x7f0a0a8b

.field public static iiv_show:I = 0x7f0a0a9c

.field public static imageViewAvatar:I = 0x7f0a0a9f

.field public static imageViewClose:I = 0x7f0a0aa2

.field public static imageViewEmpty:I = 0x7f0a0aa5

.field public static imageViewHeader:I = 0x7f0a0aa7

.field public static imageViewIcon:I = 0x7f0a0aa8

.field public static imageViewNext:I = 0x7f0a0aa9

.field public static imageViewRight:I = 0x7f0a0aac

.field public static imageViewShare:I = 0x7f0a0aad

.field public static imageViewUp:I = 0x7f0a0aae

.field public static includeLayout:I = 0x7f0a0abe

.field public static indicatorIv:I = 0x7f0a0ad3

.field public static indicatorLoan:I = 0x7f0a0ad4

.field public static indicatorMobileInstallment:I = 0x7f0a0ad5

.field public static inputFirstName:I = 0x7f0a0aed

.field public static inputLastName:I = 0x7f0a0af2

.field public static inputMiddleName:I = 0x7f0a0af4

.field public static invitation_code:I = 0x7f0a0b30

.field public static invitee_list:I = 0x7f0a0b35

.field public static invitee_name:I = 0x7f0a0b36

.field public static invitee_num:I = 0x7f0a0b37

.field public static invitee_photo:I = 0x7f0a0b38

.field public static inviter_name:I = 0x7f0a0b39

.field public static item1:I = 0x7f0a0b41

.field public static item2:I = 0x7f0a0b47

.field public static itemAmount:I = 0x7f0a0b52

.field public static itemBillType:I = 0x7f0a0b58

.field public static itemCash:I = 0x7f0a0b5b

.field public static itemCheck:I = 0x7f0a0b5c

.field public static itemContainer:I = 0x7f0a0b5f

.field public static itemContainer2:I = 0x7f0a0b60

.field public static itemCoupon:I = 0x7f0a0b61

.field public static itemCustomId:I = 0x7f0a0b62

.field public static itemDiscount:I = 0x7f0a0b64

.field public static itemEmail:I = 0x7f0a0b67

.field public static itemEndTime:I = 0x7f0a0b68

.field public static itemFee:I = 0x7f0a0b69

.field public static itemLocation:I = 0x7f0a0b6e

.field public static itemOrderDate:I = 0x7f0a0b72

.field public static itemOrderNo:I = 0x7f0a0b73

.field public static itemPaymentMethod:I = 0x7f0a0b75

.field public static itemPaymentType:I = 0x7f0a0b76

.field public static itemPointEarned:I = 0x7f0a0b77

.field public static itemPointUsed:I = 0x7f0a0b7a

.field public static itemPoints:I = 0x7f0a0b7b

.field public static itemPointsStub:I = 0x7f0a0b7c

.field public static itemPostDate:I = 0x7f0a0b7d

.field public static itemRefund:I = 0x7f0a0b80

.field public static itemReport:I = 0x7f0a0b81

.field public static itemSwitch:I = 0x7f0a0b87

.field public static itemTotal:I = 0x7f0a0b89

.field public static itemTransId:I = 0x7f0a0b8a

.field public static itemTransType:I = 0x7f0a0b8b

.field public static itemTranstype:I = 0x7f0a0b8c

.field public static itemVAT:I = 0x7f0a0b8f

.field public static itemView1:I = 0x7f0a0b92

.field public static itemView2:I = 0x7f0a0b93

.field public static itemView3:I = 0x7f0a0b94

.field public static itvArrow:I = 0x7f0a0b9a

.field public static itvDarkMode:I = 0x7f0a0b9b

.field public static itvMore:I = 0x7f0a0b9c

.field public static itvNormalMode:I = 0x7f0a0b9e

.field public static itvNotificationEnable:I = 0x7f0a0b9f

.field public static itv_delete:I = 0x7f0a0ba1

.field public static itv_setting_default:I = 0x7f0a0ba3

.field public static ivAmountArrow:I = 0x7f0a0bb4

.field public static ivArrow:I = 0x7f0a0bba

.field public static ivArrowRight:I = 0x7f0a0bbd

.field public static ivAssetsHolder:I = 0x7f0a0bbe

.field public static ivAutomaticCheck:I = 0x7f0a0bc0

.field public static ivAvatar:I = 0x7f0a0bc2

.field public static ivBank:I = 0x7f0a0bc5

.field public static ivBanner:I = 0x7f0a0bc9

.field public static ivBell:I = 0x7f0a0bca

.field public static ivBg:I = 0x7f0a0bcc

.field public static ivBusinessIcon:I = 0x7f0a0bd8

.field public static ivBusinessJumpIcon:I = 0x7f0a0bd9

.field public static ivCheck:I = 0x7f0a0be8

.field public static ivClose:I = 0x7f0a0bee

.field public static ivCopy:I = 0x7f0a0bf6

.field public static ivCoupon:I = 0x7f0a0bfa

.field public static ivCouponBg:I = 0x7f0a0bfc

.field public static ivCustomerService:I = 0x7f0a0c06

.field public static ivDelete:I = 0x7f0a0c0b

.field public static ivDetail:I = 0x7f0a0c0c

.field public static ivDivider:I = 0x7f0a0c0e

.field public static ivDot:I = 0x7f0a0c0f

.field public static ivExpired:I = 0x7f0a0c1e

.field public static ivEye:I = 0x7f0a0c1f

.field public static ivFinger:I = 0x7f0a0c25

.field public static ivFirstPart:I = 0x7f0a0c28

.field public static ivHeader:I = 0x7f0a0c31

.field public static ivHintAnchor:I = 0x7f0a0c35

.field public static ivHotProduct:I = 0x7f0a0c37

.field public static ivIcon:I = 0x7f0a0c39

.field public static ivItemBg:I = 0x7f0a0c4f

.field public static ivLabelIcon:I = 0x7f0a0c5d

.field public static ivLevel:I = 0x7f0a0c60

.field public static ivLevelIcon:I = 0x7f0a0c61

.field public static ivLion:I = 0x7f0a0c64

.field public static ivLock:I = 0x7f0a0c67

.field public static ivLogo:I = 0x7f0a0c69

.field public static ivMenu:I = 0x7f0a0c6d

.field public static ivMessageHolder:I = 0x7f0a0c6e

.field public static ivMilestoneCash:I = 0x7f0a0c70

.field public static ivNetworkTips:I = 0x7f0a0c73

.field public static ivNew:I = 0x7f0a0c74

.field public static ivNewDot:I = 0x7f0a0c75

.field public static ivNote:I = 0x7f0a0c7e

.field public static ivPalmPrize:I = 0x7f0a0c85

.field public static ivPalmPrizeTag:I = 0x7f0a0c86

.field public static ivPalmpay:I = 0x7f0a0c87

.field public static ivPic:I = 0x7f0a0c8c

.field public static ivPoints:I = 0x7f0a0c93

.field public static ivPolygon:I = 0x7f0a0c94

.field public static ivPremium:I = 0x7f0a0c96

.field public static ivPreview:I = 0x7f0a0c97

.field public static ivRight:I = 0x7f0a0ca9

.field public static ivScan:I = 0x7f0a0cab

.field public static ivSecPalmpay:I = 0x7f0a0cae

.field public static ivSecPart:I = 0x7f0a0caf

.field public static ivSecurityCenter:I = 0x7f0a0cb2

.field public static ivSecurityCenterDot:I = 0x7f0a0cb3

.field public static ivSecurityGuaranteed:I = 0x7f0a0cb4

.field public static ivSettings:I = 0x7f0a0cb6

.field public static ivShield:I = 0x7f0a0cba

.field public static ivSkeleton:I = 0x7f0a0cbe

.field public static ivStar:I = 0x7f0a0cc0

.field public static ivTag:I = 0x7f0a0cca

.field public static ivTemp:I = 0x7f0a0ccc

.field public static ivThirdPart:I = 0x7f0a0cce

.field public static ivTips:I = 0x7f0a0cd5

.field public static ivTipsBg:I = 0x7f0a0cd6

.field public static ivTitle:I = 0x7f0a0cd7

.field public static ivToggleShowBalance:I = 0x7f0a0cda

.field public static ivTomorrowIcon:I = 0x7f0a0cdb

.field public static ivTopBg:I = 0x7f0a0ce0

.field public static ivTopIcon:I = 0x7f0a0ce5

.field public static ivTrialCash:I = 0x7f0a0ce9

.field public static ivTrialIcon:I = 0x7f0a0cea

.field public static ivUpgrade:I = 0x7f0a0ced

.field public static ivYesterDayArrow:I = 0x7f0a0cf8

.field public static iv_ad:I = 0x7f0a0cfc

.field public static iv_add_card:I = 0x7f0a0cfe

.field public static iv_arrow:I = 0x7f0a0d01

.field public static iv_arrow_right:I = 0x7f0a0d03

.field public static iv_avatar:I = 0x7f0a0d05

.field public static iv_bank:I = 0x7f0a0d07

.field public static iv_bg:I = 0x7f0a0d0c

.field public static iv_bill_like_menu_icon:I = 0x7f0a0d12

.field public static iv_bill_like_menu_minus_icon:I = 0x7f0a0d13

.field public static iv_copy:I = 0x7f0a0d25

.field public static iv_coupon_package:I = 0x7f0a0d29

.field public static iv_hot:I = 0x7f0a0d40

.field public static iv_icon:I = 0x7f0a0d41

.field public static iv_setting:I = 0x7f0a0d81

.field public static ivbg:I = 0x7f0a0d9e

.field public static key_about:I = 0x7f0a0ddc

.field public static key_auto_logout_setting:I = 0x7f0a0ddd

.field public static key_automatic_payments:I = 0x7f0a0dde

.field public static key_change_pin:I = 0x7f0a0ddf

.field public static key_change_psw:I = 0x7f0a0de0

.field public static key_close_account:I = 0x7f0a0de1

.field public static key_dark_mode:I = 0x7f0a0de2

.field public static key_device:I = 0x7f0a0de3

.field public static key_email_alert_settings:I = 0x7f0a0de4

.field public static key_legal:I = 0x7f0a0de5

.field public static key_login_author:I = 0x7f0a0de6

.field public static key_login_setting:I = 0x7f0a0de7

.field public static key_merchant:I = 0x7f0a0de8

.field public static key_minor_account_management:I = 0x7f0a0de9

.field public static key_minor_guardian:I = 0x7f0a0dea

.field public static key_notification_setting:I = 0x7f0a0deb

.field public static key_one_step_pay:I = 0x7f0a0dec

.field public static key_palmpay_official:I = 0x7f0a0ded

.field public static key_payMethod:I = 0x7f0a0dee

.field public static key_pay_set:I = 0x7f0a0def

.field public static key_privacy:I = 0x7f0a0df0

.field public static key_rate_us:I = 0x7f0a0df1

.field public static key_reset_pin:I = 0x7f0a0df2

.field public static key_reset_psw:I = 0x7f0a0df3

.field public static key_set_psw:I = 0x7f0a0df4

.field public static key_sms_subscribe:I = 0x7f0a0df5

.field public static key_speaker_on:I = 0x7f0a0df6

.field public static key_threshold:I = 0x7f0a0df7

.field public static key_to_score:I = 0x7f0a0df8

.field public static key_touchId_for_login:I = 0x7f0a0df9

.field public static key_touchId_for_palmpay:I = 0x7f0a0dfa

.field public static layoutAccountInfo:I = 0x7f0a0e12

.field public static layoutAssets:I = 0x7f0a0e1a

.field public static layoutAssetsStub:I = 0x7f0a0e1b

.field public static layoutAuthentication:I = 0x7f0a0e1c

.field public static layoutBank:I = 0x7f0a0e22

.field public static layoutCashBoxModule:I = 0x7f0a0e2f

.field public static layoutCloseAccount:I = 0x7f0a0e31

.field public static layoutContent:I = 0x7f0a0e34

.field public static layoutDarkMode:I = 0x7f0a0e3d

.field public static layoutDefault:I = 0x7f0a0e3e

.field public static layoutDelete:I = 0x7f0a0e3f

.field public static layoutFlexibleSavings:I = 0x7f0a0e52

.field public static layoutFlexibleSavingsAD:I = 0x7f0a0e53

.field public static layoutGuestAssetsStub:I = 0x7f0a0e58

.field public static layoutLine2:I = 0x7f0a0e6c

.field public static layoutLine3:I = 0x7f0a0e6d

.field public static layoutLine4:I = 0x7f0a0e6e

.field public static layoutMerchantSettings:I = 0x7f0a0e73

.field public static layoutMyFortune:I = 0x7f0a0e77

.field public static layoutProgress:I = 0x7f0a0e8e

.field public static layoutRecommend:I = 0x7f0a0e92

.field public static layoutResultAmountList:I = 0x7f0a0e95

.field public static layoutResultInfoList:I = 0x7f0a0e97

.field public static layoutRoot:I = 0x7f0a0e9d

.field public static layoutScanFaceBtn:I = 0x7f0a0ea0

.field public static layoutSecModule:I = 0x7f0a0ea4

.field public static layoutSecurityGuaranteed:I = 0x7f0a0ea5

.field public static layoutSecurityGuaranteedStub:I = 0x7f0a0ea6

.field public static layoutTag:I = 0x7f0a0eaa

.field public static layoutTask:I = 0x7f0a0eab

.field public static layoutThirdModule:I = 0x7f0a0eae

.field public static layoutTransHistory:I = 0x7f0a0eb7

.field public static layoutUserLevel:I = 0x7f0a0ebd

.field public static layoutUserLevelStub:I = 0x7f0a0ebe

.field public static layoutViews:I = 0x7f0a0ec0

.field public static layout_favorites:I = 0x7f0a0eca

.field public static layout_fixed_savings:I = 0x7f0a0ecb

.field public static layout_title:I = 0x7f0a0ee0

.field public static leftView:I = 0x7f0a0ee7

.field public static lifeMenu:I = 0x7f0a0ef5

.field public static line1:I = 0x7f0a0efd

.field public static line2:I = 0x7f0a0efe

.field public static list1:I = 0x7f0a0f02

.field public static list2:I = 0x7f0a0f03

.field public static listContainer:I = 0x7f0a0f04

.field public static llBillType:I = 0x7f0a0f23

.field public static llBottom:I = 0x7f0a0f25

.field public static llContainer:I = 0x7f0a0f2b

.field public static llCouponBg:I = 0x7f0a0f30

.field public static llMyAddress:I = 0x7f0a0f56

.field public static llOrderInfo:I = 0x7f0a0f5a

.field public static llPaymentType:I = 0x7f0a0f5f

.field public static llPremiumTrial:I = 0x7f0a0f63

.field public static llRank:I = 0x7f0a0f68

.field public static llRecommend:I = 0x7f0a0f6a

.field public static llSelectManually:I = 0x7f0a0f72

.field public static llStartDate:I = 0x7f0a0f76

.field public static llStartEnd:I = 0x7f0a0f77

.field public static llTag:I = 0x7f0a0f7c

.field public static llTomorrowReward:I = 0x7f0a0f80

.field public static llTopFilter:I = 0x7f0a0f82

.field public static ll_account:I = 0x7f0a0f91

.field public static ll_all_container:I = 0x7f0a0f94

.field public static ll_amount:I = 0x7f0a0f95

.field public static ll_cashier_confirm_to_pay:I = 0x7f0a0fa1

.field public static ll_container_top:I = 0x7f0a0fa6

.field public static ll_dynmic_module:I = 0x7f0a0fa9

.field public static ll_fee_detail:I = 0x7f0a0fad

.field public static ll_flow:I = 0x7f0a0fb0

.field public static ll_head_item:I = 0x7f0a0fb5

.field public static ll_monthly_overview:I = 0x7f0a0fc2

.field public static ll_rewards:I = 0x7f0a0fd6

.field public static ll_web:I = 0x7f0a0fe7

.field public static loadingIndicator:I = 0x7f0a0fef

.field public static loadingView:I = 0x7f0a0ff2

.field public static loadingViewStub:I = 0x7f0a0ff3

.field public static logoutStub:I = 0x7f0a1002

.field public static m_customer_service:I = 0x7f0a100e

.field public static m_head:I = 0x7f0a100f

.field public static ma_biller_search_item:I = 0x7f0a1012

.field public static ma_clear_iv:I = 0x7f0a1014

.field public static ma_search_et:I = 0x7f0a1016

.field public static main_home_container:I = 0x7f0a101f

.field public static main_home_tab_1:I = 0x7f0a1020

.field public static main_home_tab_2:I = 0x7f0a1021

.field public static main_home_tab_3:I = 0x7f0a1022

.field public static main_home_tab_4:I = 0x7f0a1023

.field public static main_home_tab_5:I = 0x7f0a1024

.field public static main_splash_container:I = 0x7f0a1026

.field public static main_tab_bind_fragment:I = 0x7f0a1027

.field public static main_tag_create_time:I = 0x7f0a1028

.field public static main_tag_extra_data:I = 0x7f0a1029

.field public static main_tag_im_img:I = 0x7f0a102a

.field public static main_tag_message_type:I = 0x7f0a102b

.field public static main_tag_object:I = 0x7f0a102c

.field public static main_tag_order_number:I = 0x7f0a102d

.field public static main_tag_trans_type:I = 0x7f0a102e

.field public static main_tag_view_type:I = 0x7f0a102f

.field public static mal_new_user_banner:I = 0x7f0a1030

.field public static malb_bill_save_banner:I = 0x7f0a1031

.field public static malb_recommend_item_area:I = 0x7f0a1032

.field public static mam_booker_item:I = 0x7f0a1033

.field public static maoqpd_order_date_tv:I = 0x7f0a1035

.field public static maoqpd_post_date_tv:I = 0x7f0a1036

.field public static maoqpd_sv:I = 0x7f0a1037

.field public static maoqpd_title_info_area:I = 0x7f0a1038

.field public static maoqpd_trading_number_tv:I = 0x7f0a1039

.field public static mapbaAvaliableBalance:I = 0x7f0a103b

.field public static mapbaBalanceView:I = 0x7f0a103c

.field public static mapbaEye:I = 0x7f0a103d

.field public static mapbaFrozenAmount:I = 0x7f0a103e

.field public static mapbaFrozenArea:I = 0x7f0a103f

.field public static mapbaFrozenTips:I = 0x7f0a1040

.field public static mapbaFund:I = 0x7f0a1041

.field public static mapbaRecyclerView:I = 0x7f0a1042

.field public static mapbaTopView:I = 0x7f0a1043

.field public static mapbaUpgradeKYC:I = 0x7f0a1044

.field public static mapbaViewAll2:I = 0x7f0a1045

.field public static mapbaWithdraw:I = 0x7f0a1046

.field public static mbc_marquee_ad:I = 0x7f0a1069

.field public static mbcail_root:I = 0x7f0a106a

.field public static mbi_no_balance_container:I = 0x7f0a1090

.field public static menuList:I = 0x7f0a10ab

.field public static merchantList:I = 0x7f0a10b9

.field public static merchant_amount:I = 0x7f0a10ba

.field public static merchant_confirm_btn:I = 0x7f0a10bb

.field public static merchant_desc:I = 0x7f0a10bc

.field public static merchant_fee:I = 0x7f0a10bd

.field public static merchant_icon_iv:I = 0x7f0a10be

.field public static merchant_id:I = 0x7f0a10bf

.field public static merchant_list:I = 0x7f0a10c1

.field public static merchant_name:I = 0x7f0a10c2

.field public static merchant_name_tv:I = 0x7f0a10c3

.field public static merchant_photo:I = 0x7f0a10c4

.field public static merchant_points_earn:I = 0x7f0a10c5

.field public static merchant_points_use:I = 0x7f0a10c6

.field public static messageList:I = 0x7f0a10c8

.field public static messageStub:I = 0x7f0a10c9

.field public static mib_amount_tv:I = 0x7f0a10ce

.field public static mib_bar:I = 0x7f0a10cf

.field public static mib_month_tv:I = 0x7f0a10d0

.field public static middleAdStub:I = 0x7f0a10d3

.field public static middleAdview:I = 0x7f0a10d4

.field public static middleHomeBanner1:I = 0x7f0a10d5

.field public static mihphm_big_icon:I = 0x7f0a10d6

.field public static milestone1:I = 0x7f0a10d7

.field public static milestone2:I = 0x7f0a10d8

.field public static milestone3:I = 0x7f0a10d9

.field public static mlafi_right:I = 0x7f0a10df

.field public static mllb_content_root:I = 0x7f0a10e0

.field public static mllb_corner_icon_iv:I = 0x7f0a10e1

.field public static mllb_desc_tv:I = 0x7f0a10e2

.field public static mllb_icon_iv:I = 0x7f0a10e3

.field public static mllb_menu_name_tv:I = 0x7f0a10e4

.field public static mllb_root:I = 0x7f0a10e5

.field public static mobileItemStub:I = 0x7f0a10ec

.field public static modelCustomerService:I = 0x7f0a10f8

.field public static modelPalmPrizeBanner:I = 0x7f0a10fd

.field public static modelPremiumBenefits:I = 0x7f0a1101

.field public static modelResultHeader:I = 0x7f0a1103

.field public static modelResultReceipt:I = 0x7f0a1105

.field public static moneyInTextViewSummary:I = 0x7f0a112b

.field public static moneyOutTextViewSummary:I = 0x7f0a112c

.field public static mp_l1:I = 0x7f0a113d

.field public static mp_ll:I = 0x7f0a113e

.field public static mp_tv_left1:I = 0x7f0a113f

.field public static mp_tv_left2:I = 0x7f0a1140

.field public static mp_tv_new_tag:I = 0x7f0a1141

.field public static mp_tv_right:I = 0x7f0a1142

.field public static mp_view_bottom_line:I = 0x7f0a1143

.field public static mp_view_top_line:I = 0x7f0a1144

.field public static my_business_root:I = 0x7f0a11e9

.field public static navbarBg:I = 0x7f0a11f3

.field public static nickNameItemStub:I = 0x7f0a120a

.field public static nsvRoot:I = 0x7f0a122a

.field public static nsv_container:I = 0x7f0a122b

.field public static offeringRv:I = 0x7f0a1297

.field public static opLayout:I = 0x7f0a12a3

.field public static orhm_head:I = 0x7f0a12c6

.field public static palmPrizeBottomAdView:I = 0x7f0a139e

.field public static palmPrizeStub:I = 0x7f0a139f

.field public static payProgress:I = 0x7f0a13ac

.field public static pay_qrcode_arrow_iv:I = 0x7f0a13af

.field public static pay_qrcode_container:I = 0x7f0a13b0

.field public static payment_method:I = 0x7f0a13b8

.field public static payment_method_content:I = 0x7f0a13b9

.field public static payment_method_label:I = 0x7f0a13bb

.field public static premiumBenefitsStub:I = 0x7f0a141f

.field public static previewTitle:I = 0x7f0a1429

.field public static prizeList:I = 0x7f0a1433

.field public static professionItemStub:I = 0x7f0a1436

.field public static progressBar:I = 0x7f0a1438

.field public static progressIndicator:I = 0x7f0a1439

.field public static progress_bar:I = 0x7f0a143c

.field public static qbb_empty_area:I = 0x7f0a145e

.field public static qecode_coupon_tv:I = 0x7f0a1471

.field public static qecode_pay_amount:I = 0x7f0a1472

.field public static qecode_pay_amount_content:I = 0x7f0a1473

.field public static qecode_pay_amount_label:I = 0x7f0a1474

.field public static qecode_pay_fee:I = 0x7f0a1475

.field public static qecode_pay_fee_content:I = 0x7f0a1476

.field public static qecode_pay_fee_label:I = 0x7f0a1477

.field public static qecode_pay_order_number:I = 0x7f0a1478

.field public static qecode_pay_promotions_tv:I = 0x7f0a1479

.field public static qecode_pay_store_name_tv:I = 0x7f0a147a

.field public static qecode_pay_title_amount:I = 0x7f0a147b

.field public static qecode_pay_vat_tv:I = 0x7f0a147c

.field public static qecode_points_earned_tv:I = 0x7f0a147d

.field public static qecode_vat_content:I = 0x7f0a147e

.field public static qecode_vat_label:I = 0x7f0a147f

.field public static qrcode_share_iv:I = 0x7f0a149f

.field public static qrcode_share_view:I = 0x7f0a14a0

.field public static rate_cancel_tv:I = 0x7f0a14af

.field public static rate_tv:I = 0x7f0a14b0

.field public static rc_exclusive:I = 0x7f0a14b6

.field public static rcv_choose_list:I = 0x7f0a14b7

.field public static receive_money_arrow_iv:I = 0x7f0a14c2

.field public static receive_money_container:I = 0x7f0a14c3

.field public static receive_money_num:I = 0x7f0a14c4

.field public static receive_money_qrcode:I = 0x7f0a14c5

.field public static receive_money_remark:I = 0x7f0a14c6

.field public static recycler_view:I = 0x7f0a14df

.field public static reference_num:I = 0x7f0a14e0

.field public static reference_num_content:I = 0x7f0a14e1

.field public static reference_num_label:I = 0x7f0a14e2

.field public static refreshLayout:I = 0x7f0a14e4

.field public static remove_container:I = 0x7f0a14ef

.field public static remove_iv:I = 0x7f0a14f0

.field public static remove_tv:I = 0x7f0a14f1

.field public static result_content:I = 0x7f0a1528

.field public static result_desc_tv:I = 0x7f0a1529

.field public static result_img:I = 0x7f0a152a

.field public static result_left_btn:I = 0x7f0a152d

.field public static result_one_btn:I = 0x7f0a152e

.field public static result_right_btn:I = 0x7f0a152f

.field public static result_tv:I = 0x7f0a1530

.field public static result_two_btn_view:I = 0x7f0a1531

.field public static reward1:I = 0x7f0a1537

.field public static reward2:I = 0x7f0a1538

.field public static reward3:I = 0x7f0a1539

.field public static reward4:I = 0x7f0a153a

.field public static rewardTasksViewStub:I = 0x7f0a153d

.field public static rewardsList:I = 0x7f0a153e

.field public static rewardsStub:I = 0x7f0a153f

.field public static rewardsViewStub:I = 0x7f0a1540

.field public static rewards_points:I = 0x7f0a1541

.field public static rewards_points_history:I = 0x7f0a1542

.field public static rightGuideline:I = 0x7f0a1546

.field public static rightView:I = 0x7f0a1549

.field public static rl_accountList:I = 0x7f0a155b

.field public static rl_comment:I = 0x7f0a155d

.field public static rl_exclusiveList:I = 0x7f0a1560

.field public static rl_insurance:I = 0x7f0a1561

.field public static rl_productList:I = 0x7f0a1564

.field public static rl_stock:I = 0x7f0a1569

.field public static rootAccountBottom:I = 0x7f0a1575

.field public static rootView:I = 0x7f0a157c

.field public static rtvGet:I = 0x7f0a15a8

.field public static rtvGetNow:I = 0x7f0a15a9

.field public static rtvInvest:I = 0x7f0a15ad

.field public static rtvSave:I = 0x7f0a15b4

.field public static rvBenefits:I = 0x7f0a15c4

.field public static rvBillList:I = 0x7f0a15c6

.field public static rvChooseList:I = 0x7f0a15c7

.field public static rvIndicator:I = 0x7f0a15ce

.field public static rvPalmPrize:I = 0x7f0a15d6

.field public static rvPaymentFilterList:I = 0x7f0a15d7

.field public static rvTopFilterList:I = 0x7f0a15e6

.field public static rvTransactionList:I = 0x7f0a15e7

.field public static rv_bank_card:I = 0x7f0a15ed

.field public static ry_life_home_menu:I = 0x7f0a160f

.field public static save_bt:I = 0x7f0a1626

.field public static save_qrcode:I = 0x7f0a1629

.field public static scrollNotice:I = 0x7f0a163a

.field public static scrollView:I = 0x7f0a163b

.field public static section_divider:I = 0x7f0a166a

.field public static securityStub:I = 0x7f0a166d

.field public static set_money:I = 0x7f0a1695

.field public static share_bt:I = 0x7f0a16a1

.field public static space:I = 0x7f0a16d8

.field public static space2:I = 0x7f0a16d9

.field public static spma_auth_area:I = 0x7f0a16f7

.field public static spma_enable_tv:I = 0x7f0a16f8

.field public static spma_pay_method:I = 0x7f0a16f9

.field public static spma_refresh_tv:I = 0x7f0a16fa

.field public static srlBillList:I = 0x7f0a170c

.field public static srvList:I = 0x7f0a1710

.field public static statusBarView:I = 0x7f0a1720

.field public static statusView:I = 0x7f0a1721

.field public static subClickView:I = 0x7f0a1739

.field public static success_icon:I = 0x7f0a1742

.field public static success_text:I = 0x7f0a1746

.field public static summaryContainer:I = 0x7f0a1747

.field public static swipe:I = 0x7f0a174d

.field public static tabLayout:I = 0x7f0a1755

.field public static tabLoan:I = 0x7f0a1756

.field public static tabMobileInstallment:I = 0x7f0a1757

.field public static taskCenterViewStub:I = 0x7f0a176f

.field public static taskList:I = 0x7f0a1770

.field public static tasksStub:I = 0x7f0a1771

.field public static text1:I = 0x7f0a177c

.field public static text2:I = 0x7f0a177e

.field public static text3:I = 0x7f0a1780

.field public static textAd:I = 0x7f0a1782

.field public static textView1:I = 0x7f0a178b

.field public static textView2:I = 0x7f0a178c

.field public static textViewAmount:I = 0x7f0a1790

.field public static textViewBalanceAmount:I = 0x7f0a1791

.field public static textViewBanlanceAmount:I = 0x7f0a1792

.field public static textViewCancel:I = 0x7f0a1795

.field public static textViewComplete:I = 0x7f0a1797

.field public static textViewDate:I = 0x7f0a179c

.field public static textViewExpiredDate:I = 0x7f0a17a0

.field public static textViewGo1:I = 0x7f0a17a3

.field public static textViewGo2:I = 0x7f0a17a4

.field public static textViewHeader1:I = 0x7f0a17a5

.field public static textViewHeader2:I = 0x7f0a17a6

.field public static textViewIn:I = 0x7f0a17a7

.field public static textViewLine1:I = 0x7f0a17a8

.field public static textViewLine10:I = 0x7f0a17a9

.field public static textViewLine11:I = 0x7f0a17aa

.field public static textViewLine2:I = 0x7f0a17ab

.field public static textViewLine21:I = 0x7f0a17ac

.field public static textViewLogout:I = 0x7f0a17ad

.field public static textViewLuckMoneyNo:I = 0x7f0a17ae

.field public static textViewMessage:I = 0x7f0a17af

.field public static textViewMoneyTransferNo:I = 0x7f0a17b0

.field public static textViewName:I = 0x7f0a17b2

.field public static textViewNext:I = 0x7f0a17b3

.field public static textViewNote:I = 0x7f0a17b4

.field public static textViewOk:I = 0x7f0a17b5

.field public static textViewOriginOrder:I = 0x7f0a17b6

.field public static textViewOut:I = 0x7f0a17b7

.field public static textViewPendingMessage:I = 0x7f0a17b8

.field public static textViewPostDate:I = 0x7f0a17b9

.field public static textViewRefNo:I = 0x7f0a17ba

.field public static textViewState:I = 0x7f0a17c1

.field public static textViewTitle:I = 0x7f0a17c3

.field public static textViewTransactionDate:I = 0x7f0a17c4

.field public static tf_money_result_desc_tv:I = 0x7f0a17d4

.field public static tf_money_result_img:I = 0x7f0a17d5

.field public static tf_money_result_tv:I = 0x7f0a17d6

.field public static titleBar:I = 0x7f0a17e5

.field public static titleBarBg:I = 0x7f0a17e6

.field public static titleView:I = 0x7f0a17ee

.field public static title_bar:I = 0x7f0a17ef

.field public static title_tv:I = 0x7f0a17f2

.field public static topBannerView:I = 0x7f0a17fd

.field public static topBarContainer:I = 0x7f0a17ff

.field public static topBarEndBarrier:I = 0x7f0a1800

.field public static topContainer:I = 0x7f0a1804

.field public static topTextAd:I = 0x7f0a180b

.field public static transItem1Stub:I = 0x7f0a182b

.field public static transItem2Stub:I = 0x7f0a182c

.field public static transactionHistoryFragment:I = 0x7f0a182e

.field public static tv:I = 0x7f0a184b

.field public static tv1:I = 0x7f0a184c

.field public static tv2:I = 0x7f0a1851

.field public static tv3Month:I = 0x7f0a1857

.field public static tvAccount:I = 0x7f0a185f

.field public static tvAccountLabel:I = 0x7f0a1864

.field public static tvAccountNo:I = 0x7f0a1865

.field public static tvAccountNumber:I = 0x7f0a1867

.field public static tvAll:I = 0x7f0a1886

.field public static tvAmount:I = 0x7f0a1887

.field public static tvAmount2:I = 0x7f0a1889

.field public static tvAppTopMainConfig:I = 0x7f0a1895

.field public static tvApplicationTime:I = 0x7f0a1897

.field public static tvApplicationTitle:I = 0x7f0a1898

.field public static tvAutoDescribe:I = 0x7f0a189a

.field public static tvAutoTitle:I = 0x7f0a18a3

.field public static tvAvailable:I = 0x7f0a18a6

.field public static tvBankName:I = 0x7f0a18b0

.field public static tvBooked:I = 0x7f0a18c4

.field public static tvCancel:I = 0x7f0a18df

.field public static tvCardType:I = 0x7f0a18e4

.field public static tvCashBoxAutoSave:I = 0x7f0a18e6

.field public static tvCashBoxRemark:I = 0x7f0a18e7

.field public static tvCashBoxTitle:I = 0x7f0a18e8

.field public static tvCbn:I = 0x7f0a18f4

.field public static tvChangePercent:I = 0x7f0a18fc

.field public static tvClaimed:I = 0x7f0a1901

.field public static tvComplete:I = 0x7f0a1904

.field public static tvConfirm:I = 0x7f0a190b

.field public static tvContent:I = 0x7f0a190e

.field public static tvCopy:I = 0x7f0a190f

.field public static tvCorner:I = 0x7f0a1911

.field public static tvCornerMark:I = 0x7f0a1912

.field public static tvCount:I = 0x7f0a1913

.field public static tvCountDetail:I = 0x7f0a1914

.field public static tvCountDown:I = 0x7f0a1915

.field public static tvCoupon:I = 0x7f0a191b

.field public static tvCouponAmount:I = 0x7f0a191c

.field public static tvCouponDesc:I = 0x7f0a191e

.field public static tvCouponTitle:I = 0x7f0a1923

.field public static tvCurrent:I = 0x7f0a1930

.field public static tvDate:I = 0x7f0a1945

.field public static tvDebugInfo:I = 0x7f0a194c

.field public static tvDecline:I = 0x7f0a194d

.field public static tvDefaultCard:I = 0x7f0a194f

.field public static tvDesc:I = 0x7f0a1954

.field public static tvDetail:I = 0x7f0a1956

.field public static tvDownload:I = 0x7f0a1963

.field public static tvDuration:I = 0x7f0a1966

.field public static tvDurationDay:I = 0x7f0a1967

.field public static tvDurationNum:I = 0x7f0a1968

.field public static tvEarnedAmount:I = 0x7f0a196b

.field public static tvEarnedLabel:I = 0x7f0a196c

.field public static tvEarningsAmount:I = 0x7f0a196d

.field public static tvEnd:I = 0x7f0a1972

.field public static tvEndDate:I = 0x7f0a1973

.field public static tvExcluesiveTitle:I = 0x7f0a197b

.field public static tvExpireBadge:I = 0x7f0a1984

.field public static tvExpireTime:I = 0x7f0a1989

.field public static tvExtendOp:I = 0x7f0a198c

.field public static tvFailed:I = 0x7f0a1991

.field public static tvFilterActive:I = 0x7f0a1999

.field public static tvFilterAll:I = 0x7f0a199a

.field public static tvFilterIO:I = 0x7f0a199b

.field public static tvFrozen:I = 0x7f0a19ab

.field public static tvFund:I = 0x7f0a19ae

.field public static tvHint:I = 0x7f0a19c0

.field public static tvHistory:I = 0x7f0a19c1

.field public static tvIO:I = 0x7f0a19c6

.field public static tvIn:I = 0x7f0a19c9

.field public static tvIncome:I = 0x7f0a19ca

.field public static tvInterestAmount:I = 0x7f0a19de

.field public static tvInterestPa:I = 0x7f0a19e4

.field public static tvInterval:I = 0x7f0a19e9

.field public static tvJumpContent:I = 0x7f0a19fb

.field public static tvKycMessage:I = 0x7f0a1a0e

.field public static tvKycTitle:I = 0x7f0a1a0f

.field public static tvLabel:I = 0x7f0a1a10

.field public static tvLastLogin:I = 0x7f0a1a11

.field public static tvLastMonth:I = 0x7f0a1a12

.field public static tvLater:I = 0x7f0a1a15

.field public static tvLevel:I = 0x7f0a1a1b

.field public static tvLine1:I = 0x7f0a1a23

.field public static tvLine2:I = 0x7f0a1a24

.field public static tvLine3:I = 0x7f0a1a26

.field public static tvLogin:I = 0x7f0a1a40

.field public static tvMessage:I = 0x7f0a1a49

.field public static tvMilestoneAmt:I = 0x7f0a1a51

.field public static tvMilestoneUser:I = 0x7f0a1a52

.field public static tvMobile:I = 0x7f0a1a54

.field public static tvMoneyIn:I = 0x7f0a1a57

.field public static tvMoneyOut:I = 0x7f0a1a58

.field public static tvMonth:I = 0x7f0a1a59

.field public static tvMonthCustomize:I = 0x7f0a1a5a

.field public static tvMore:I = 0x7f0a1a5d

.field public static tvMoreInfo:I = 0x7f0a1a5e

.field public static tvMsg:I = 0x7f0a1a60

.field public static tvMsgCount:I = 0x7f0a1a63

.field public static tvMyAddress:I = 0x7f0a1a65

.field public static tvName:I = 0x7f0a1a68

.field public static tvNetworkTips:I = 0x7f0a1a6f

.field public static tvNext:I = 0x7f0a1a70

.field public static tvNidc:I = 0x7f0a1a78

.field public static tvNo:I = 0x7f0a1a7d

.field public static tvNoBalanceAccount:I = 0x7f0a1a80

.field public static tvNotice:I = 0x7f0a1a8a

.field public static tvNum:I = 0x7f0a1a8c

.field public static tvOffering:I = 0x7f0a1a96

.field public static tvOperate:I = 0x7f0a1a99

.field public static tvOut:I = 0x7f0a1aa4

.field public static tvPalmPrize:I = 0x7f0a1aad

.field public static tvPalmPrizeAmount:I = 0x7f0a1aae

.field public static tvPaymentTypeTitle:I = 0x7f0a1aba

.field public static tvPending:I = 0x7f0a1abc

.field public static tvPercent:I = 0x7f0a1abe

.field public static tvPhone:I = 0x7f0a1ac4

.field public static tvPointAmount:I = 0x7f0a1ad5

.field public static tvPointAmount2:I = 0x7f0a1ad6

.field public static tvPointClaim:I = 0x7f0a1ad7

.field public static tvPointTitle:I = 0x7f0a1ad8

.field public static tvPoints:I = 0x7f0a1ad9

.field public static tvPrivacyAccount:I = 0x7f0a1ae4

.field public static tvProductContent:I = 0x7f0a1ae8

.field public static tvProductSubContent:I = 0x7f0a1aee

.field public static tvProductSubTitle:I = 0x7f0a1aef

.field public static tvProductTitle:I = 0x7f0a1af0

.field public static tvRate:I = 0x7f0a1af8

.field public static tvRecentTransaction:I = 0x7f0a1afe

.field public static tvRemark:I = 0x7f0a1b09

.field public static tvReserved:I = 0x7f0a1b17

.field public static tvRevokeOp:I = 0x7f0a1b1c

.field public static tvRewardAmt:I = 0x7f0a1b1e

.field public static tvSaveTitle:I = 0x7f0a1b26

.field public static tvSec:I = 0x7f0a1b2a

.field public static tvSecRemark:I = 0x7f0a1b2b

.field public static tvSecTitle:I = 0x7f0a1b2c

.field public static tvSecurityGuaranteed:I = 0x7f0a1b2f

.field public static tvSelectManually:I = 0x7f0a1b31

.field public static tvSignUpLogin:I = 0x7f0a1b42

.field public static tvSkip:I = 0x7f0a1b47

.field public static tvStartDate:I = 0x7f0a1b4a

.field public static tvState:I = 0x7f0a1b4b

.field public static tvStatus:I = 0x7f0a1b4c

.field public static tvStoreName:I = 0x7f0a1b51

.field public static tvSubTitle:I = 0x7f0a1b54

.field public static tvSummery:I = 0x7f0a1b5c

.field public static tvTag:I = 0x7f0a1b66

.field public static tvTagName:I = 0x7f0a1b67

.field public static tvTask:I = 0x7f0a1b69

.field public static tvTaskDesc:I = 0x7f0a1b6a

.field public static tvTaskLabel:I = 0x7f0a1b6b

.field public static tvTaskProgress:I = 0x7f0a1b6d

.field public static tvTaskTitle:I = 0x7f0a1b6e

.field public static tvText:I = 0x7f0a1b76

.field public static tvThirdRemark:I = 0x7f0a1b78

.field public static tvThirdTitle:I = 0x7f0a1b79

.field public static tvTime:I = 0x7f0a1b87

.field public static tvTimes:I = 0x7f0a1b8b

.field public static tvTip:I = 0x7f0a1b8c

.field public static tvTitle:I = 0x7f0a1b8e

.field public static tvTitle1:I = 0x7f0a1b8f

.field public static tvTitle2:I = 0x7f0a1b90

.field public static tvToBeClaimed:I = 0x7f0a1b93

.field public static tvTomorrowLabel:I = 0x7f0a1b94

.field public static tvTomorrowReward:I = 0x7f0a1b95

.field public static tvTotalAssets:I = 0x7f0a1b9c

.field public static tvTotalAssetsAmount:I = 0x7f0a1b9d

.field public static tvTotalTitle:I = 0x7f0a1bac

.field public static tvTransHistory:I = 0x7f0a1bb0

.field public static tvTransactionAmount:I = 0x7f0a1bb1

.field public static tvTransactionName:I = 0x7f0a1bb2

.field public static tvTransactionStatus:I = 0x7f0a1bb3

.field public static tvTransactionTime:I = 0x7f0a1bb4

.field public static tvTrialCash:I = 0x7f0a1bba

.field public static tvTrialCashAmount:I = 0x7f0a1bbb

.field public static tvTrialCashToClaimed:I = 0x7f0a1bbc

.field public static tvTrialContent:I = 0x7f0a1bbe

.field public static tvType:I = 0x7f0a1bc3

.field public static tvTypeCustomize:I = 0x7f0a1bc6

.field public static tvUpgrade:I = 0x7f0a1bd4

.field public static tvUse:I = 0x7f0a1bd7

.field public static tvValue:I = 0x7f0a1be5

.field public static tvVerified:I = 0x7f0a1be6

.field public static tvVersion:I = 0x7f0a1bec

.field public static tvView:I = 0x7f0a1bed

.field public static tvYes:I = 0x7f0a1c04

.field public static tvYesterdayReturn:I = 0x7f0a1c05

.field public static tvYesterdayReturnAmount:I = 0x7f0a1c06

.field public static tv_bank_card_no:I = 0x7f0a1c28

.field public static tv_bank_name:I = 0x7f0a1c29

.field public static tv_bill_like_menu_name:I = 0x7f0a1c2b

.field public static tv_bill_like_remark:I = 0x7f0a1c2c

.field public static tv_confirm:I = 0x7f0a1c4f

.field public static tv_confirm_to_pay:I = 0x7f0a1c50

.field public static tv_default:I = 0x7f0a1c6a

.field public static tv_edit_favourites:I = 0x7f0a1c7b

.field public static tv_remark:I = 0x7f0a1d2b

.field public static tv_status:I = 0x7f0a1d50

.field public static tv_status_tips:I = 0x7f0a1d51

.field public static tv_title:I = 0x7f0a1d6a

.field public static tv_top_remark:I = 0x7f0a1d71

.field public static tv_valid_thru:I = 0x7f0a1d8e

.field public static tv_view:I = 0x7f0a1d91

.field public static unVerifyUserStub:I = 0x7f0a1da2

.field public static unlink_container:I = 0x7f0a1da6

.field public static unlink_iv:I = 0x7f0a1da7

.field public static unlink_tv:I = 0x7f0a1da8

.field public static update_remark_tv:I = 0x7f0a1db2

.field public static userInfoStub:I = 0x7f0a1db9

.field public static ussd_guide_tv:I = 0x7f0a1dc2

.field public static vCoupon1:I = 0x7f0a1dc7

.field public static vCoupon2:I = 0x7f0a1dc8

.field public static vCoupon3:I = 0x7f0a1dc9

.field public static vCouponLeftBg:I = 0x7f0a1dca

.field public static vCouponRightBg:I = 0x7f0a1dcb

.field public static vDivider:I = 0x7f0a1dce

.field public static vLeft:I = 0x7f0a1dd4

.field public static vLine:I = 0x7f0a1dd5

.field public static vRoot:I = 0x7f0a1dd9

.field public static v_header:I = 0x7f0a1def

.field public static v_status_bg:I = 0x7f0a1df9

.field public static valid_until:I = 0x7f0a1e00

.field public static viewAd:I = 0x7f0a1e0d

.field public static viewBankDivider:I = 0x7f0a1e14

.field public static viewBottom:I = 0x7f0a1e1c

.field public static viewClickNotice:I = 0x7f0a1e1e

.field public static viewCoinRain:I = 0x7f0a1e1f

.field public static viewContainer:I = 0x7f0a1e20

.field public static viewDate:I = 0x7f0a1e23

.field public static viewDelete:I = 0x7f0a1e24

.field public static viewDetail:I = 0x7f0a1e25

.field public static viewDivider:I = 0x7f0a1e26

.field public static viewFailReason:I = 0x7f0a1e2b

.field public static viewFlipper:I = 0x7f0a1e2d

.field public static viewGap:I = 0x7f0a1e2e

.field public static viewHeader:I = 0x7f0a1e32

.field public static viewIO:I = 0x7f0a1e33

.field public static viewIndicator:I = 0x7f0a1e36

.field public static viewLine:I = 0x7f0a1e3d

.field public static viewLine1:I = 0x7f0a1e3e

.field public static viewLine2:I = 0x7f0a1e3f

.field public static viewLuckyMoney:I = 0x7f0a1e45

.field public static viewMessageHolder:I = 0x7f0a1e48

.field public static viewMoneyTransfer:I = 0x7f0a1e49

.field public static viewNotNetwork:I = 0x7f0a1e4a

.field public static viewNotNetworkStub:I = 0x7f0a1e4b

.field public static viewPager:I = 0x7f0a1e54

.field public static viewReceipt:I = 0x7f0a1e5d

.field public static viewRemark:I = 0x7f0a1e5f

.field public static viewRoot:I = 0x7f0a1e61

.field public static viewTopMarquee:I = 0x7f0a1e6f

.field public static viewTrialCashToClaimed:I = 0x7f0a1e72

.field public static viewZone:I = 0x7f0a1e74

.field public static view_top_transparent_bg:I = 0x7f0a1e95

.field public static viewpager:I = 0x7f0a1e9d

.field public static vsAdCompliance:I = 0x7f0a1eac

.field public static vs_header:I = 0x7f0a1eb8

.field public static wealthList:I = 0x7f0a1ec9

.field public static wealthViewStub:I = 0x7f0a1eca

.field public static webView:I = 0x7f0a1ecb

.field public static web_view_container:I = 0x7f0a1ece

.field public static welcomeBackView:I = 0x7f0a1ed0


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
