.class public final LAc/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static main_activity_about:I = 0x7f0d047a

.field public static main_activity_account_number:I = 0x7f0d047b

.field public static main_activity_all_function_v2:I = 0x7f0d047c

.field public static main_activity_auto_deduct_home:I = 0x7f0d047d

.field public static main_activity_auto_deduct_order_detail:I = 0x7f0d047e

.field public static main_activity_bank_card_detail:I = 0x7f0d047f

.field public static main_activity_bill_payment_edit:I = 0x7f0d0480

.field public static main_activity_buy_early_refund_bill_detail:I = 0x7f0d0481

.field public static main_activity_buy_early_refund_result:I = 0x7f0d0482

.field public static main_activity_coin_rain:I = 0x7f0d0483

.field public static main_activity_commission_detail:I = 0x7f0d0484

.field public static main_activity_coupon_package_result:I = 0x7f0d0485

.field public static main_activity_dark_mode_setting:I = 0x7f0d0486

.field public static main_activity_disbursement_order_detail:I = 0x7f0d0487

.field public static main_activity_echat:I = 0x7f0d0488

.field public static main_activity_get_coin:I = 0x7f0d0489

.field public static main_activity_home_new:I = 0x7f0d048a

.field public static main_activity_inter_bank_cash_in:I = 0x7f0d048b

.field public static main_activity_life_bills:I = 0x7f0d048c

.field public static main_activity_merchant_order_detail:I = 0x7f0d048d

.field public static main_activity_merchant_payment_list:I = 0x7f0d048e

.field public static main_activity_merchant_payment_preview:I = 0x7f0d048f

.field public static main_activity_minor_account_detail:I = 0x7f0d0490

.field public static main_activity_minor_account_list:I = 0x7f0d0491

.field public static main_activity_minor_guardian_manager:I = 0x7f0d0492

.field public static main_activity_minor_result:I = 0x7f0d0493

.field public static main_activity_my_assets:I = 0x7f0d0494

.field public static main_activity_notification_list_v2:I = 0x7f0d0495

.field public static main_activity_notifications:I = 0x7f0d0496

.field public static main_activity_offline_qr_paymentl_detail:I = 0x7f0d0497

.field public static main_activity_palm_safe_detail:I = 0x7f0d0498

.field public static main_activity_palm_safe_scan_face_v2:I = 0x7f0d0499

.field public static main_activity_palmpay_balance_account:I = 0x7f0d049a

.field public static main_activity_palmpay_balance_statement:I = 0x7f0d049b

.field public static main_activity_palmpay_statement:I = 0x7f0d049c

.field public static main_activity_pay_code_order_detail:I = 0x7f0d049d

.field public static main_activity_pay_code_transaction_result:I = 0x7f0d049e

.field public static main_activity_pay_money_to_palmpay_business_preview:I = 0x7f0d049f

.field public static main_activity_pay_money_to_palmpay_business_result:I = 0x7f0d04a0

.field public static main_activity_payment_method:I = 0x7f0d04a1

.field public static main_activity_paymerchant_result:I = 0x7f0d04a2

.field public static main_activity_pending_voucher_list:I = 0x7f0d04a3

.field public static main_activity_phone_information:I = 0x7f0d04a4

.field public static main_activity_point_bill_detail:I = 0x7f0d04a5

.field public static main_activity_qr_code:I = 0x7f0d04a6

.field public static main_activity_qrcode_pay_money_order_detail:I = 0x7f0d04a7

.field public static main_activity_redirect_order_detail:I = 0x7f0d04a8

.field public static main_activity_refund_bill_detail:I = 0x7f0d04a9

.field public static main_activity_scan_qrcode_pay_money_preview:I = 0x7f0d04aa

.field public static main_activity_set_default_repayment_card:I = 0x7f0d04ab

.field public static main_activity_settings:I = 0x7f0d04ac

.field public static main_activity_sub_settings:I = 0x7f0d04ad

.field public static main_activity_test_dynamic_module:I = 0x7f0d04ae

.field public static main_activity_transaction_download:I = 0x7f0d04af

.field public static main_activity_transaction_download_filter:I = 0x7f0d04b0

.field public static main_activity_transaction_download_filter_type:I = 0x7f0d04b1

.field public static main_activity_transaction_history:I = 0x7f0d04b2

.field public static main_activity_unavailble_coupon_list:I = 0x7f0d04b3

.field public static main_activity_update:I = 0x7f0d04b4

.field public static main_activity_welcome_back:I = 0x7f0d04b5

.field public static main_activity_welcome_new_user:I = 0x7f0d04b6

.field public static main_add_card_complete_activity:I = 0x7f0d04b7

.field public static main_bank_card_account_empty_layout:I = 0x7f0d04b8

.field public static main_bank_card_account_item_layout:I = 0x7f0d04b9

.field public static main_bank_card_and_account_activity:I = 0x7f0d04ba

.field public static main_bank_card_and_account_fragment:I = 0x7f0d04bb

.field public static main_bill_like_menu_item:I = 0x7f0d04bc

.field public static main_choose_item_pop_window:I = 0x7f0d04bd

.field public static main_choose_list_item_pop_window:I = 0x7f0d04be

.field public static main_choose_multi_item_pop_window:I = 0x7f0d04bf

.field public static main_choose_multi_item_pop_window_v2:I = 0x7f0d04c0

.field public static main_content_home:I = 0x7f0d04c1

.field public static main_dialog_accept_turn_on_save:I = 0x7f0d04c2

.field public static main_dialog_coupon_rewards:I = 0x7f0d04c3

.field public static main_dialog_homepage_clipboard_transfer:I = 0x7f0d04c4

.field public static main_dialog_monthly_limit:I = 0x7f0d04c5

.field public static main_dialog_palmzone_chain_progress:I = 0x7f0d04c6

.field public static main_dialog_palmzone_rewards:I = 0x7f0d04c7

.field public static main_dialog_pre_install_build_privacy:I = 0x7f0d04c8

.field public static main_dialog_send_money_handler_home:I = 0x7f0d04c9

.field public static main_edit_bill_like_menu_item:I = 0x7f0d04ca

.field public static main_edit_name_dialog_layout:I = 0x7f0d04cb

.field public static main_fragment_bank_card:I = 0x7f0d04cc

.field public static main_fragment_home_bottom:I = 0x7f0d04cd

.field public static main_fragment_home_finance:I = 0x7f0d04ce

.field public static main_fragment_home_invest:I = 0x7f0d04cf

.field public static main_fragment_home_me_tab:I = 0x7f0d04d0

.field public static main_fragment_home_palm_zone_real_layout:I = 0x7f0d04d1

.field public static main_fragment_home_v2:I = 0x7f0d04d2

.field public static main_fragment_login_settings:I = 0x7f0d04d3

.field public static main_fragment_me_balance_statement:I = 0x7f0d04d4

.field public static main_fragment_message_list:I = 0x7f0d04d5

.field public static main_fragment_palmpay_zone_reward:I = 0x7f0d04d6

.field public static main_fragment_payment_settings:I = 0x7f0d04d7

.field public static main_fragment_rate_app:I = 0x7f0d04d8

.field public static main_fragment_settings:I = 0x7f0d04d9

.field public static main_fragment_transaction_history:I = 0x7f0d04da

.field public static main_home_guest_top_ad:I = 0x7f0d04db

.field public static main_home_me_menu_item_adview:I = 0x7f0d04dc

.field public static main_home_page_account_bar_ng:I = 0x7f0d04dd

.field public static main_home_page_account_bottom:I = 0x7f0d04de

.field public static main_home_page_exclusive_new_user:I = 0x7f0d04df

.field public static main_home_page_reward_tasks:I = 0x7f0d04e0

.field public static main_home_page_rewards_center:I = 0x7f0d04e1

.field public static main_home_page_rewards_center_item:I = 0x7f0d04e2

.field public static main_home_page_rewards_common_item:I = 0x7f0d04e3

.field public static main_home_page_rewards_coupon_combo_claim_item:I = 0x7f0d04e4

.field public static main_home_page_rewards_coupon_combo_used_item:I = 0x7f0d04e5

.field public static main_home_page_rewards_coupon_combo_used_item_child:I = 0x7f0d04e6

.field public static main_home_page_rewards_marketing_coupon_item:I = 0x7f0d04e7

.field public static main_home_page_rewards_single_coupon_item:I = 0x7f0d04e8

.field public static main_home_page_rewards_task_center_item:I = 0x7f0d04e9

.field public static main_home_page_tasks_center:I = 0x7f0d04ea

.field public static main_home_page_tasks_center_headline_card:I = 0x7f0d04eb

.field public static main_home_page_top_bar:I = 0x7f0d04ec

.field public static main_home_page_transaction_history_bar:I = 0x7f0d04ed

.field public static main_home_page_wealth:I = 0x7f0d04ee

.field public static main_home_page_wealth_product_item:I = 0x7f0d04ef

.field public static main_home_page_welcome_back_user:I = 0x7f0d04f0

.field public static main_home_rewards_tab:I = 0x7f0d04f1

.field public static main_home_rewards_tab_banner_stub:I = 0x7f0d04f2

.field public static main_home_rewards_tab_middle_ad_stub:I = 0x7f0d04f3

.field public static main_home_rewards_tab_palmprize_stub:I = 0x7f0d04f4

.field public static main_home_rewards_tab_premium_benefits_stub:I = 0x7f0d04f5

.field public static main_home_savings_v2_fragment:I = 0x7f0d04f6

.field public static main_invest_guide_fg_layout:I = 0x7f0d04f7

.field public static main_invest_guide_item_new:I = 0x7f0d04f8

.field public static main_invitee_header_item_layout:I = 0x7f0d04f9

.field public static main_invitee_list_activity:I = 0x7f0d04fa

.field public static main_invitee_list_item_layout:I = 0x7f0d04fb

.field public static main_item_bank_card:I = 0x7f0d04fc

.field public static main_item_bar_graph:I = 0x7f0d04fd

.field public static main_item_bill_home_group:I = 0x7f0d04fe

.field public static main_item_bill_saving_item2:I = 0x7f0d04ff

.field public static main_item_edit_bill_home_group:I = 0x7f0d0500

.field public static main_item_history_month:I = 0x7f0d0501

.field public static main_item_home_me_menu_2:I = 0x7f0d0502

.field public static main_item_home_page_horizontal_menu:I = 0x7f0d0503

.field public static main_item_home_page_horizontal_menu_v2:I = 0x7f0d0504

.field public static main_item_list_module:I = 0x7f0d0505

.field public static main_item_minor_account:I = 0x7f0d0506

.field public static main_item_minor_transaction:I = 0x7f0d0507

.field public static main_item_payment_type_filter_module:I = 0x7f0d0508

.field public static main_item_premium_benefits_item:I = 0x7f0d0509

.field public static main_item_reward_palmprize:I = 0x7f0d050a

.field public static main_item_rewards_prize_item_cash:I = 0x7f0d050b

.field public static main_item_saving_comment:I = 0x7f0d050c

.field public static main_item_saving_fund:I = 0x7f0d050d

.field public static main_item_saving_fund_operation:I = 0x7f0d050e

.field public static main_item_saving_insurance:I = 0x7f0d050f

.field public static main_item_saving_page_horizontal_menu:I = 0x7f0d0510

.field public static main_item_saving_recommend_fund:I = 0x7f0d0511

.field public static main_item_saving_stock:I = 0x7f0d0512

.field public static main_item_saving_target:I = 0x7f0d0513

.field public static main_item_saving_target_h:I = 0x7f0d0514

.field public static main_item_saving_top_tag:I = 0x7f0d0515

.field public static main_item_signup_login_suspension_button:I = 0x7f0d0516

.field public static main_item_top_filter_module:I = 0x7f0d0517

.field public static main_item_welcome_back_rewards:I = 0x7f0d0518

.field public static main_layout_account_flow_item:I = 0x7f0d0519

.field public static main_layout_activity_reward_premium_indication:I = 0x7f0d051a

.field public static main_layout_bank_card_deail_menu_item:I = 0x7f0d051b

.field public static main_layout_common_message_list_item:I = 0x7f0d051c

.field public static main_layout_coupon_package_result_header:I = 0x7f0d051d

.field public static main_layout_custom_giveway_tab:I = 0x7f0d051e

.field public static main_layout_edit_bills_item:I = 0x7f0d051f

.field public static main_layout_home_account_bar:I = 0x7f0d0520

.field public static main_layout_home_account_no_bar:I = 0x7f0d0521

.field public static main_layout_home_banner_ad:I = 0x7f0d0522

.field public static main_layout_home_coupon_rewards_item:I = 0x7f0d0523

.field public static main_layout_home_giveaway_more:I = 0x7f0d0524

.field public static main_layout_home_me_assets_user_level:I = 0x7f0d0525

.field public static main_layout_home_me_menu:I = 0x7f0d0526

.field public static main_layout_home_me_page_assets:I = 0x7f0d0527

.field public static main_layout_home_me_page_user_info:I = 0x7f0d0528

.field public static main_layout_home_me_tab_drag_view:I = 0x7f0d0529

.field public static main_layout_home_menus:I = 0x7f0d052a

.field public static main_layout_home_menus_v2:I = 0x7f0d052b

.field public static main_layout_home_message_holder:I = 0x7f0d052c

.field public static main_layout_home_message_item:I = 0x7f0d052d

.field public static main_layout_home_middle_banner_ad:I = 0x7f0d052e

.field public static main_layout_home_reward_guest:I = 0x7f0d052f

.field public static main_layout_home_tab_bottom_view:I = 0x7f0d0530

.field public static main_layout_home_tab_drag_view:I = 0x7f0d0531

.field public static main_layout_home_top_function:I = 0x7f0d0532

.field public static main_layout_home_top_text_ad:I = 0x7f0d0533

.field public static main_layout_life_bills_item:I = 0x7f0d0534

.field public static main_layout_loading_view:I = 0x7f0d0535

.field public static main_layout_me_logout_button:I = 0x7f0d0536

.field public static main_layout_me_page_kyc_notice:I = 0x7f0d0537

.field public static main_layout_me_page_security_info:I = 0x7f0d0538

.field public static main_layout_menu_model:I = 0x7f0d0539

.field public static main_layout_merchant_item:I = 0x7f0d053a

.field public static main_layout_more_function:I = 0x7f0d053b

.field public static main_layout_my_asset_balance_item:I = 0x7f0d053c

.field public static main_layout_my_asset_balance_sub_item:I = 0x7f0d053d

.field public static main_layout_my_asset_balance_views:I = 0x7f0d053e

.field public static main_layout_my_assets_top_bar:I = 0x7f0d053f

.field public static main_layout_news_message_list_item:I = 0x7f0d0540

.field public static main_layout_not_network_home_page:I = 0x7f0d0541

.field public static main_layout_notification_list_header_item:I = 0x7f0d0542

.field public static main_layout_palmzone_refer_earn_card:I = 0x7f0d0543

.field public static main_layout_palmzone_refer_earn_milestone_item:I = 0x7f0d0544

.field public static main_layout_palmzone_reward_item:I = 0x7f0d0545

.field public static main_layout_palmzone_reward_item_v2:I = 0x7f0d0546

.field public static main_layout_palmzone_tasks:I = 0x7f0d0547

.field public static main_layout_payment_message_list_item:I = 0x7f0d0548

.field public static main_layout_personal_kyc_level_row:I = 0x7f0d0549

.field public static main_layout_personal_user_info:I = 0x7f0d054a

.field public static main_layout_re_request_money_dialog:I = 0x7f0d054b

.field public static main_layout_reward_palmprize_banner:I = 0x7f0d054c

.field public static main_layout_reward_premium_benefits:I = 0x7f0d054d

.field public static main_layout_reward_tasks_progress:I = 0x7f0d054e

.field public static main_layout_reward_tasks_progress_item:I = 0x7f0d054f

.field public static main_layout_rewards_points_and_coupon:I = 0x7f0d0550

.field public static main_layout_search_item:I = 0x7f0d0551

.field public static main_layout_setting_item:I = 0x7f0d0552

.field public static main_layout_single_ad:I = 0x7f0d0553

.field public static main_layout_total_asset_item_2:I = 0x7f0d0554

.field public static main_layout_trans_history_item:I = 0x7f0d0555

.field public static main_layout_unverify_user:I = 0x7f0d0556

.field public static main_layout_voucher_dialog:I = 0x7f0d0557

.field public static main_layout_widget_bundle:I = 0x7f0d0558

.field public static main_layout_widget_pay_bills:I = 0x7f0d0559

.field public static main_layout_widget_send_money:I = 0x7f0d055a

.field public static main_layout_widget_top_up_airtime:I = 0x7f0d055b

.field public static main_me_page_my_business_item:I = 0x7f0d055c

.field public static main_me_page_my_business_store:I = 0x7f0d055d

.field public static main_me_page_quick_access:I = 0x7f0d055e

.field public static main_me_page_transaction_history_item_v2:I = 0x7f0d055f

.field public static main_merchant_authorization_dialog:I = 0x7f0d0560

.field public static main_merchant_payment_result_activity:I = 0x7f0d0561

.field public static main_merchant_preview_confirm_activity:I = 0x7f0d0562

.field public static main_model_banner_item_palmpay_no_balance_v2:I = 0x7f0d0563

.field public static main_new_user_coupon_item_layout:I = 0x7f0d0564

.field public static main_palm_zone_rewards_activity:I = 0x7f0d0565

.field public static main_palm_zone_task_item_v2:I = 0x7f0d0566

.field public static main_palm_zone_task_list_dialog:I = 0x7f0d0567

.field public static main_payment_method_item:I = 0x7f0d0568

.field public static main_personal_activity_v2:I = 0x7f0d0569

.field public static main_personal_info_item:I = 0x7f0d056a

.field public static main_personal_info_item1:I = 0x7f0d056b

.field public static main_personal_info_item2:I = 0x7f0d056c

.field public static main_popup_bank_card_setting:I = 0x7f0d056d

.field public static main_pref_layout_12_line:I = 0x7f0d056e

.field public static main_pref_layout_double_text_left_right_common:I = 0x7f0d056f

.field public static main_pref_layout_double_text_top_bottom:I = 0x7f0d0570

.field public static main_pref_layout_single_line:I = 0x7f0d0571

.field public static main_pref_layout_single_line_content:I = 0x7f0d0572

.field public static main_pref_layout_single_line_text_switch_with_icon:I = 0x7f0d0573

.field public static main_pref_layout_single_line_with_new_version:I = 0x7f0d0574

.field public static main_pref_layout_tips:I = 0x7f0d0575

.field public static main_qr_code_pay_money_activity:I = 0x7f0d0576

.field public static main_qrcode_pay_money_success_activity:I = 0x7f0d0577

.field public static main_qrcode_share_activity:I = 0x7f0d0578

.field public static main_quick_info_item:I = 0x7f0d0579

.field public static main_receive_money_activity:I = 0x7f0d057a

.field public static main_receive_money_fragment:I = 0x7f0d057b

.field public static main_rewards_points_history_activity:I = 0x7f0d057c

.field public static main_saving_account_list_layout:I = 0x7f0d057d

.field public static main_saving_account_top_layout:I = 0x7f0d057e

.field public static main_saving_basic_item:I = 0x7f0d057f

.field public static main_saving_cashbox_layout:I = 0x7f0d0580

.field public static main_saving_comment_list_layout:I = 0x7f0d0581

.field public static main_saving_fixed_item_exclusive:I = 0x7f0d0582

.field public static main_saving_fixed_item_product:I = 0x7f0d0583

.field public static main_saving_fixed_saving_layout:I = 0x7f0d0584

.field public static main_saving_insurance_layout:I = 0x7f0d0585

.field public static main_saving_module_top_layout:I = 0x7f0d0586

.field public static main_saving_mutual_fund_layout:I = 0x7f0d0587

.field public static main_saving_recommend_layout:I = 0x7f0d0588

.field public static main_saving_smarter_layout:I = 0x7f0d0589

.field public static main_saving_spend_save_layout:I = 0x7f0d058a

.field public static main_saving_stocks_layout:I = 0x7f0d058b

.field public static main_saving_tag_layout:I = 0x7f0d058c

.field public static main_saving_task_layout:I = 0x7f0d058d

.field public static main_third_party_merchant_item_layout:I = 0x7f0d058e

.field public static main_third_party_merchant_list_activity:I = 0x7f0d058f

.field public static main_third_party_merchant_order_detail_activity:I = 0x7f0d0590

.field public static main_three_party_merchant_activity:I = 0x7f0d0591

.field public static main_trans_histroy_filter:I = 0x7f0d0592

.field public static main_welcome_back_coupon_item_layout:I = 0x7f0d0593

.field public static main_welcome_back_coupon_item_layout_v2:I = 0x7f0d0594


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
