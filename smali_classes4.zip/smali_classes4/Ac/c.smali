.class public final LAc/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static main_check_dialog_item_height:I = 0x7f07040a

.field public static main_home_bottom_tab_horizontal_margin:I = 0x7f07040b

.field public static main_home_bottom_tab_left_margin:I = 0x7f07040c

.field public static main_home_bottom_tab_width:I = 0x7f07040d

.field public static main_home_clipboard_bank_name_max_width:I = 0x7f07040e

.field public static main_home_fragment_bottom_margin:I = 0x7f07040f

.field public static main_home_fragment_vertical_margin:I = 0x7f070410

.field public static main_home_top_bar_height:I = 0x7f070411

.field public static main_invitee_photo_text_size:I = 0x7f070412

.field public static main_scan_face_vertical_margin:I = 0x7f070413

.field public static main_scan_face_vertical_margin_2:I = 0x7f070414

.field public static main_setting_item_font_size2:I = 0x7f070415

.field public static main_setting_item_height:I = 0x7f070416

.field public static main_welcome_new_bottom_margin:I = 0x7f070417

.field public static main_welcome_new_middle_margin:I = 0x7f070418

.field public static main_welcome_new_top_margin:I = 0x7f070419


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
