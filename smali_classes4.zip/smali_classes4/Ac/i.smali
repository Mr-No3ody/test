.class public final LAc/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static MainContentLoadingProgress:I = 0x7f15016b

.field public static MainHomeTheme:I = 0x7f15016c

.field public static MainHomeTheme2:I = 0x7f15016d

.field public static MainSplashTheme:I = 0x7f15016e

.field public static MainSplashTheme2:I = 0x7f15016f


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
