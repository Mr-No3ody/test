.class public final LAc/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static MainSettingItem:[I = null

.field public static MainSettingItem_android_defaultValue:I = 0x2

.field public static MainSettingItem_android_summary:I = 0x1

.field public static MainSettingItem_android_title:I = 0x0

.field public static MainSettingItem_st_checkStyle:I = 0x3

.field public static MainSettingItem_st_showDivider:I = 0x4

.field public static MainSettingItem_st_showDot:I = 0x5


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const/4 v0, 0x6

    .line 2
    new-array v0, v0, [I

    .line 3
    .line 4
    fill-array-data v0, :array_0

    .line 5
    .line 6
    .line 7
    sput-object v0, LAc/j;->MainSettingItem:[I

    .line 8
    .line 9
    return-void

    .line 10
    nop

    .line 11
    :array_0
    .array-data 4
        0x10101e1
        0x10101e9
        0x10101ed
        0x7f0408d4
        0x7f0408d5
        0x7f0408d6
    .end array-data
.end method

.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
