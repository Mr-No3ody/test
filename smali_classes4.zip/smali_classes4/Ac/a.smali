.class public final LAc/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static main_anim_tab_enter_left:I = 0x7f01006d

.field public static main_anim_tab_enter_right:I = 0x7f01006e

.field public static main_anim_tab_exit_left:I = 0x7f01006f

.field public static main_anim_tab_exit_right:I = 0x7f010070


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
