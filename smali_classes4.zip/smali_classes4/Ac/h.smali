.class public final LAc/h;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static main_about:I = 0x7f140e30

.field public static main_accepted:I = 0x7f140e31

.field public static main_activities:I = 0x7f140e32

.field public static main_activity_is_over:I = 0x7f140e33

.field public static main_ad_assets_bottom_compliance_slot_id:I = 0x7f140e34

.field public static main_ad_assets_bottom_slot_id:I = 0x7f140e35

.field public static main_ad_early_refund_result_page:I = 0x7f140e36

.field public static main_ad_home_banner1:I = 0x7f140e37

.field public static main_ad_home_banner2:I = 0x7f140e38

.field public static main_ad_home_banner_slot_id:I = 0x7f140e39

.field public static main_ad_home_coupon_package:I = 0x7f140e3a

.field public static main_ad_home_float_ad_slot_id:I = 0x7f140e3b

.field public static main_ad_home_giveaway_snac_slot_id:I = 0x7f140e3c

.field public static main_ad_home_giveaway_top_slot_id:I = 0x7f140e3d

.field public static main_ad_home_guest_top:I = 0x7f140e3e

.field public static main_ad_home_invest_pop_slot_id:I = 0x7f140e3f

.field public static main_ad_home_me_float_ad_slot_id:I = 0x7f140e40

.field public static main_ad_home_me_kyc_slot_id:I = 0x7f140e41

.field public static main_ad_home_me_premium:I = 0x7f140e42

.field public static main_ad_home_middle_banner:I = 0x7f140e43

.field public static main_ad_home_not_log_in:I = 0x7f140e44

.field public static main_ad_home_pop_high_priority_slot_id:I = 0x7f140e45

.field public static main_ad_home_pop_slot_id:I = 0x7f140e46

.field public static main_ad_home_rate_new_slot_id:I = 0x7f140e47

.field public static main_ad_home_rate_slot_id:I = 0x7f140e48

.field public static main_ad_invest_middle_slot_id:I = 0x7f140e49

.field public static main_ad_invest_smart_l_slot_id:I = 0x7f140e4a

.field public static main_ad_invest_smart_rt_slot_id:I = 0x7f140e4b

.field public static main_ad_invest_top_rb_id:I = 0x7f140e4c

.field public static main_ad_invest_top_slot_id:I = 0x7f140e4d

.field public static main_ad_loan_dialog_slot_id:I = 0x7f140e4e

.field public static main_ad_me_sign_corner_1:I = 0x7f140e4f

.field public static main_ad_splash_slot_id:I = 0x7f140e50

.field public static main_ad_transaction_history_slot_id:I = 0x7f140e51

.field public static main_ad_zone_pop_slot_id:I = 0x7f140e52

.field public static main_add_bank_account_desc:I = 0x7f140e53

.field public static main_add_bank_account_text:I = 0x7f140e54

.field public static main_add_bank_account_title:I = 0x7f140e55

.field public static main_add_bank_card_desc:I = 0x7f140e56

.field public static main_add_bank_card_desc2:I = 0x7f140e57

.field public static main_add_bank_card_text:I = 0x7f140e58

.field public static main_add_bank_card_title:I = 0x7f140e59

.field public static main_add_card_fail_desc:I = 0x7f140e5a

.field public static main_add_card_pending_desc:I = 0x7f140e5b

.field public static main_add_card_pending_title:I = 0x7f140e5c

.field public static main_add_card_success_desc:I = 0x7f140e5d

.field public static main_address_info_top:I = 0x7f140e5e

.field public static main_all:I = 0x7f140e5f

.field public static main_amount_to_get:I = 0x7f140e60

.field public static main_application_has_submitted:I = 0x7f140e61

.field public static main_approved:I = 0x7f140e62

.field public static main_at:I = 0x7f140e63

.field public static main_auto_deduct:I = 0x7f140e64

.field public static main_auto_deduct_active:I = 0x7f140e65

.field public static main_auto_deduct_agreement:I = 0x7f140e66

.field public static main_auto_deduct_details:I = 0x7f140e67

.field public static main_auto_deduct_expired:I = 0x7f140e68

.field public static main_auto_deduct_history:I = 0x7f140e69

.field public static main_automatic:I = 0x7f140e6a

.field public static main_automatic_dark_mode:I = 0x7f140e6b

.field public static main_automatic_payments:I = 0x7f140e6c

.field public static main_available_balance:I = 0x7f140e6d

.field public static main_balance:I = 0x7f140e6e

.field public static main_balance_account:I = 0x7f140e6f

.field public static main_balance_statement:I = 0x7f140e70

.field public static main_balance_statement_just:I = 0x7f140e71

.field public static main_bank_account:I = 0x7f140e72

.field public static main_bank_account_delete_success_text:I = 0x7f140e73

.field public static main_bank_account_delete_text:I = 0x7f140e74

.field public static main_bank_account_remove_success_text:I = 0x7f140e75

.field public static main_bank_account_remove_text:I = 0x7f140e76

.field public static main_bank_account_set_as_default_success_text:I = 0x7f140e77

.field public static main_bank_card:I = 0x7f140e78

.field public static main_bank_card_and_account:I = 0x7f140e79

.field public static main_bank_card_delete_success_text:I = 0x7f140e7a

.field public static main_bank_card_delete_text:I = 0x7f140e7b

.field public static main_bank_card_set_as_default_success_text:I = 0x7f140e7c

.field public static main_bank_remove_fail_text:I = 0x7f140e7d

.field public static main_bill_category_title:I = 0x7f140e7e

.field public static main_bill_save_tips_text1:I = 0x7f140e7f

.field public static main_bill_save_tips_text2:I = 0x7f140e80

.field public static main_bill_save_tips_text3:I = 0x7f140e81

.field public static main_bill_saving_title_tips:I = 0x7f140e82

.field public static main_biometric_authentication:I = 0x7f140e83

.field public static main_booker:I = 0x7f140e84

.field public static main_bound:I = 0x7f140e85

.field public static main_buy_data:I = 0x7f140e86

.field public static main_cake_number_0:I = 0x7f140e87

.field public static main_cake_number_format:I = 0x7f140e88

.field public static main_cancel:I = 0x7f140e89

.field public static main_cashbox_auto_save_turned_on:I = 0x7f140e8a

.field public static main_chain_progress_reward_is_yours:I = 0x7f140e8b

.field public static main_chain_progress_tomorrow_reward_label:I = 0x7f140e8c

.field public static main_change_pattern:I = 0x7f140e8d

.field public static main_change_pin:I = 0x7f140e8e

.field public static main_change_psw:I = 0x7f140e8f

.field public static main_check_in_task_tips:I = 0x7f140e90

.field public static main_clear_amount_text:I = 0x7f140e91

.field public static main_click_confirm_to_receive:I = 0x7f140e92

.field public static main_click_go_to_receive_or_open:I = 0x7f140e93

.field public static main_close_account:I = 0x7f140e94

.field public static main_closed:I = 0x7f140e95

.field public static main_commission_cash:I = 0x7f140e96

.field public static main_commission_points:I = 0x7f140e97

.field public static main_complete:I = 0x7f140e98

.field public static main_confirm:I = 0x7f140e99

.field public static main_confirm_your_email:I = 0x7f140e9a

.field public static main_contact_us:I = 0x7f140e9b

.field public static main_convert:I = 0x7f140e9c

.field public static main_convert_points:I = 0x7f140e9d

.field public static main_cumulative_savings:I = 0x7f140e9e

.field public static main_current_balance:I = 0x7f140e9f

.field public static main_customer_service:I = 0x7f140ea0

.field public static main_customize:I = 0x7f140ea1

.field public static main_daily_reminder:I = 0x7f140ea2

.field public static main_dark_mode:I = 0x7f140ea3

.field public static main_decline:I = 0x7f140ea4

.field public static main_declined:I = 0x7f140ea5

.field public static main_default_payment_bank_card:I = 0x7f140ea6

.field public static main_default_text:I = 0x7f140ea7

.field public static main_delete:I = 0x7f140ea8

.field public static main_delete_ask:I = 0x7f140ea9

.field public static main_delete_transaction:I = 0x7f140eaa

.field public static main_denied_permission_open_camera:I = 0x7f140eab

.field public static main_denied_permission_save_qrcode:I = 0x7f140eac

.field public static main_details:I = 0x7f140ead

.field public static main_disable:I = 0x7f140eae

.field public static main_disbursement:I = 0x7f140eaf

.field public static main_disclosure_of_user_data_collection:I = 0x7f140eb0

.field public static main_discover_new_version:I = 0x7f140eb1

.field public static main_down_load_remark:I = 0x7f140eb2

.field public static main_download_statement:I = 0x7f140eb3

.field public static main_duration:I = 0x7f140eb4

.field public static main_duration_check:I = 0x7f140eb5

.field public static main_earned_cash:I = 0x7f140eb6

.field public static main_edit_full_name:I = 0x7f140eb7

.field public static main_edit_name:I = 0x7f140eb8

.field public static main_edit_nickname:I = 0x7f140eb9

.field public static main_edit_tag_desc:I = 0x7f140eba

.field public static main_edit_your_palmpay_tag:I = 0x7f140ebb

.field public static main_email_alert_settings:I = 0x7f140ebc

.field public static main_email_correct:I = 0x7f140ebd

.field public static main_email_format_error:I = 0x7f140ebe

.field public static main_end_date:I = 0x7f140ebf

.field public static main_enter_your_email:I = 0x7f140ec0

.field public static main_exchange:I = 0x7f140ec1

.field public static main_exchange_again:I = 0x7f140ec2

.field public static main_exchange_points_to_coins:I = 0x7f140ec3

.field public static main_expiry_date_s:I = 0x7f140ec4

.field public static main_extend_success:I = 0x7f140ec5

.field public static main_fail_to_claim:I = 0x7f140ec6

.field public static main_failed_please_try_again:I = 0x7f140ec7

.field public static main_favourites_max_size_tips:I = 0x7f140ec8

.field public static main_first_name:I = 0x7f140ec9

.field public static main_forget_pattern:I = 0x7f140ed7

.field public static main_friends:I = 0x7f140ed8

.field public static main_from_merchant:I = 0x7f140ed9

.field public static main_from_palmpay:I = 0x7f140eda

.field public static main_frozen_balance:I = 0x7f140edb

.field public static main_full_name:I = 0x7f140edc

.field public static main_get_coupons:I = 0x7f140edd

.field public static main_get_coupons_title:I = 0x7f140ede

.field public static main_go_back_to_merchant_desc:I = 0x7f140edf

.field public static main_go_settings:I = 0x7f140ee0

.field public static main_go_to_exchange:I = 0x7f140ee1

.field public static main_go_to_scan_face:I = 0x7f140ee2

.field public static main_goods_name:I = 0x7f140ee3

.field public static main_grab:I = 0x7f140ee4

.field public static main_hava_not_enter_email:I = 0x7f140ee5

.field public static main_help:I = 0x7f140ee6

.field public static main_hi_palmpayer:I = 0x7f140ee7

.field public static main_hi_xx:I = 0x7f140ee8

.field public static main_home_clipboard_bank:I = 0x7f140ee9

.field public static main_home_clipboard_default_tip:I = 0x7f140eea

.field public static main_home_clipboard_recipient_account:I = 0x7f140eeb

.field public static main_home_clipboard_transfer_generic_title:I = 0x7f140eec

.field public static main_home_clipboard_transfer_named_title:I = 0x7f140eed

.field public static main_home_clipboard_transfer_now:I = 0x7f140eee

.field public static main_home_finance_tab_corner_icon:I = 0x7f140eef

.field public static main_home_invest_tab_corner_slot_id:I = 0x7f140ef0

.field public static main_home_life_bill_slot_id:I = 0x7f140ef1

.field public static main_home_palm_zone_top_slot_id:I = 0x7f140ef2

.field public static main_home_rewards_tab_corner_ad_slot_id:I = 0x7f140ef3

.field public static main_home_tab_snack_slot_id:I = 0x7f140ef4

.field public static main_home_top_text_slot_id:I = 0x7f140ef5

.field public static main_how_to_get_more_palmpoints_coupons:I = 0x7f140ef6

.field public static main_i_want_to_feedback:I = 0x7f140ef7

.field public static main_if_you_enjoy_using_palmpay_xx:I = 0x7f140ef8

.field public static main_ignore:I = 0x7f140ef9

.field public static main_important_notice:I = 0x7f140efa

.field public static main_in:I = 0x7f140efb

.field public static main_in_use:I = 0x7f140efc

.field public static main_input_amount:I = 0x7f140efd

.field public static main_install:I = 0x7f140efe

.field public static main_interbank_transfer:I = 0x7f140eff

.field public static main_invite_now:I = 0x7f140f00

.field public static main_invitee_list_title:I = 0x7f140f01

.field public static main_kyc_level:I = 0x7f140f02

.field public static main_last_3_month:I = 0x7f140f03

.field public static main_last_login_time:I = 0x7f140f04

.field public static main_last_month:I = 0x7f140f05

.field public static main_last_name:I = 0x7f140f06

.field public static main_leave_bill_payment_edit_tips:I = 0x7f140f07

.field public static main_legal_first_name:I = 0x7f140f08

.field public static main_legal_last_name:I = 0x7f140f09

.field public static main_let_s_start:I = 0x7f140f0a

.field public static main_life_favourites:I = 0x7f140f0b

.field public static main_list_end:I = 0x7f140f0c

.field public static main_lock_pin_setting:I = 0x7f140f0d

.field public static main_log_out:I = 0x7f140f0e

.field public static main_login_author_management:I = 0x7f140f0f

.field public static main_login_settings:I = 0x7f140f10

.field public static main_manage_device:I = 0x7f140f11

.field public static main_measure_layout_1:I = 0x7f140f12

.field public static main_measure_layout_2:I = 0x7f140f13

.field public static main_merchant_id_s:I = 0x7f140f14

.field public static main_merchant_name:I = 0x7f140f15

.field public static main_merchant_payment:I = 0x7f140f16

.field public static main_merchant_payment_fail_desc:I = 0x7f140f17

.field public static main_merchant_payment_pending_desc:I = 0x7f140f18

.field public static main_merchant_payment_success_desc:I = 0x7f140f19

.field public static main_messages:I = 0x7f140f1a

.field public static main_micro_amount:I = 0x7f140f1b

.field public static main_micro_trans_num:I = 0x7f140f1c

.field public static main_middle_name:I = 0x7f140f1d

.field public static main_minor_account_management:I = 0x7f140f1e

.field public static main_minor_authorization_history:I = 0x7f140f1f

.field public static main_minor_big_revoke:I = 0x7f140f20

.field public static main_minor_extend:I = 0x7f140f21

.field public static main_minor_extend_authorization:I = 0x7f140f22

.field public static main_minor_extend_confirm:I = 0x7f140f23

.field public static main_minor_revoke:I = 0x7f140f24

.field public static main_minor_revoke_authorization:I = 0x7f140f25

.field public static main_minor_revoke_confirm:I = 0x7f140f26

.field public static main_mobile_number:I = 0x7f140f27

.field public static main_mobile_wallet:I = 0x7f140f28

.field public static main_money_in:I = 0x7f140f29

.field public static main_money_out:I = 0x7f140f2a

.field public static main_money_transfer_2:I = 0x7f140f2b

.field public static main_more_rewards:I = 0x7f140f2c

.field public static main_move_banner_to_bottom:I = 0x7f140f2d

.field public static main_move_banner_to_middle:I = 0x7f140f2e

.field public static main_msg_check_summary:I = 0x7f140f2f

.field public static main_msg_contact_merchant_to_disable_auto_deduct:I = 0x7f140f30

.field public static main_msg_disable_auto_deduct:I = 0x7f140f31

.field public static main_msg_download_apk:I = 0x7f140f32

.field public static main_msg_download_fail:I = 0x7f140f33

.field public static main_msg_enable_install_apk:I = 0x7f140f34

.field public static main_msg_enable_network_1:I = 0x7f140f35

.field public static main_msg_enable_network_2:I = 0x7f140f36

.field public static main_msg_exchange_points_success:I = 0x7f140f37

.field public static main_msg_file_too_large:I = 0x7f140f38

.field public static main_msg_friend:I = 0x7f140f39

.field public static main_msg_grant_calendar_permission:I = 0x7f140f3a

.field public static main_msg_log_out:I = 0x7f140f3b

.field public static main_msg_merchant_payment_info:I = 0x7f140f3c

.field public static main_msg_name_change_submitted:I = 0x7f140f3d

.field public static main_msg_name_is_same:I = 0x7f140f3e

.field public static main_msg_please_verify_pin:I = 0x7f140f3f

.field public static main_msg_security_1:I = 0x7f140f40

.field public static main_msg_security_2:I = 0x7f140f41

.field public static main_msg_service_unavailable:I = 0x7f140f42

.field public static main_msg_unbind_merchant:I = 0x7f140f43

.field public static main_msg_valid_characters_only:I = 0x7f140f44

.field public static main_my_palmpoints_text:I = 0x7f140f45

.field public static main_my_points:I = 0x7f140f46

.field public static main_my_profile:I = 0x7f140f47

.field public static main_my_store:I = 0x7f140f48

.field public static main_my_store_empty_desc:I = 0x7f140f49

.field public static main_my_store_temp_code:I = 0x7f140f4a

.field public static main_name_change_submitted:I = 0x7f140f4b

.field public static main_new:I = 0x7f140f4c

.field public static main_news:I = 0x7f140f4d

.field public static main_ngn_symbol:I = 0x7f140f4e

.field public static main_nick_name:I = 0x7f140f4f

.field public static main_no_auto_deduct:I = 0x7f140f50

.field public static main_no_bill_record:I = 0x7f140f51

.field public static main_no_limited:I = 0x7f140f52

.field public static main_no_nofitications:I = 0x7f140f53

.field public static main_no_records:I = 0x7f140f54

.field public static main_no_touch_id_data:I = 0x7f140f55

.field public static main_no_transaction_record:I = 0x7f140f56

.field public static main_normal_mode:I = 0x7f140f57

.field public static main_not_network_amount_tips:I = 0x7f140f58

.field public static main_notification_settings:I = 0x7f140f59

.field public static main_notifications:I = 0x7f140f5a

.field public static main_number_of_commission:I = 0x7f140f5b

.field public static main_number_of_transaction:I = 0x7f140f5c

.field public static main_ok:I = 0x7f140f5d

.field public static main_ok_i_know:I = 0x7f140f5e

.field public static main_okay:I = 0x7f140f5f

.field public static main_onece_deleted:I = 0x7f140f60

.field public static main_open:I = 0x7f140f61

.field public static main_open_cashbox_tips:I = 0x7f140f62

.field public static main_order_id_desc:I = 0x7f140f63

.field public static main_orders_in_total_s:I = 0x7f140f64

.field public static main_other_title:I = 0x7f140f65

.field public static main_out:I = 0x7f140f66

.field public static main_p_earned:I = 0x7f140f67

.field public static main_p_expired:I = 0x7f140f68

.field public static main_palm_prize:I = 0x7f140f69

.field public static main_palmcoins:I = 0x7f140f6a

.field public static main_palmpay_service:I = 0x7f140f6b

.field public static main_palmpay_tag:I = 0x7f140f6c

.field public static main_palmpay_text:I = 0x7f140f6d

.field public static main_palmpoints:I = 0x7f140f6e

.field public static main_pattern_Unlock:I = 0x7f140f6f

.field public static main_pattern_lock_hint:I = 0x7f140f70

.field public static main_pattern_setting_tips:I = 0x7f140f71

.field public static main_pattern_settings_title:I = 0x7f140f72

.field public static main_pattern_turned_off:I = 0x7f140f73

.field public static main_pay_again:I = 0x7f140f74

.field public static main_pay_bills:I = 0x7f140f75

.field public static main_pay_without_pin:I = 0x7f140f76

.field public static main_payment_limits:I = 0x7f140f77

.field public static main_payment_limits_item:I = 0x7f140f78

.field public static main_payment_method_notice:I = 0x7f140f79

.field public static main_payment_method_notice_top:I = 0x7f140f7a

.field public static main_payment_setting:I = 0x7f140f7b

.field public static main_payments:I = 0x7f140f7c

.field public static main_personal_homepage:I = 0x7f140f7d

.field public static main_pin:I = 0x7f140f7e

.field public static main_ping:I = 0x7f140f7f

.field public static main_platform:I = 0x7f140f80

.field public static main_please_complete:I = 0x7f140f81

.field public static main_point_expire_format:I = 0x7f140f82

.field public static main_points_amount_should_below:I = 0x7f140f83

.field public static main_points_x_coupon_x:I = 0x7f140f84

.field public static main_preferred_payment_method:I = 0x7f140f85

.field public static main_privacy_policy:I = 0x7f140f86

.field public static main_prize:I = 0x7f140f87

.field public static main_product:I = 0x7f140f88

.field public static main_qr_amount_details:I = 0x7f140f89

.field public static main_qr_commission:I = 0x7f140f8a

.field public static main_qr_commission_title:I = 0x7f140f8b

.field public static main_qr_payment_title:I = 0x7f140f8c

.field public static main_qrcode_collect_desc_text:I = 0x7f140f8d

.field public static main_qrcode_save_in:I = 0x7f140f8e

.field public static main_qrcode_share_desc_text:I = 0x7f140f8f

.field public static main_qrcode_share_invite_code_text:I = 0x7f140f90

.field public static main_qrcode_share_invite_text:I = 0x7f140f91

.field public static main_qrcode_share_picture_saved_deny_text:I = 0x7f140f92

.field public static main_qrcode_share_picture_saved_text:I = 0x7f140f93

.field public static main_qrcode_share_save_picture_text:I = 0x7f140f94

.field public static main_qrcode_share_scan_text:I = 0x7f140f95

.field public static main_qrcode_share_title:I = 0x7f140f96

.field public static main_quick_filter_title:I = 0x7f140f97

.field public static main_quick_text:I = 0x7f140f98

.field public static main_rate_it_with_5_star:I = 0x7f140f99

.field public static main_rate_title:I = 0x7f140f9a

.field public static main_rate_us:I = 0x7f140f9b

.field public static main_receive_money_label:I = 0x7f140f9c

.field public static main_received_merchant:I = 0x7f140f9d

.field public static main_receiving_money:I = 0x7f140f9e

.field public static main_receiving_qrcode_desc:I = 0x7f140f9f

.field public static main_receiving_tool:I = 0x7f140fa0

.field public static main_recently:I = 0x7f140fa1

.field public static main_recently_used:I = 0x7f140fa2

.field public static main_recipient_with_colon:I = 0x7f140fa3

.field public static main_refer_earn:I = 0x7f140fa4

.field public static main_refresh_completed:I = 0x7f140fa5

.field public static main_refund_hint_text_nairabox:I = 0x7f140fa6

.field public static main_rejected:I = 0x7f140fa7

.field public static main_remove:I = 0x7f140fa8

.field public static main_remove_text:I = 0x7f140fa9

.field public static main_request:I = 0x7f140faa

.field public static main_request_failed:I = 0x7f140fab

.field public static main_reserved_balance:I = 0x7f140fac

.field public static main_reset_pin:I = 0x7f140fad

.field public static main_reset_psw:I = 0x7f140fae

.field public static main_revoke_success:I = 0x7f140faf

.field public static main_reward_progress_hint_all_done:I = 0x7f140fb0

.field public static main_reward_progress_hint_claim_congrats:I = 0x7f140fb1

.field public static main_reward_progress_hint_completed_claim:I = 0x7f140fb2

.field public static main_reward_progress_hint_completed_claim_1:I = 0x7f140fb3

.field public static main_reward_progress_hint_completing:I = 0x7f140fb4

.field public static main_reward_progress_hint_completing_1:I = 0x7f140fb5

.field public static main_reward_tasks:I = 0x7f140fb6

.field public static main_rewards_coupon_subtitle:I = 0x7f140fb7

.field public static main_rewards_coupons_combo:I = 0x7f140fb8

.field public static main_rewards_history_title:I = 0x7f140fb9

.field public static main_s_user:I = 0x7f140fba

.field public static main_s_users:I = 0x7f140fbb

.field public static main_save_qrcode_text:I = 0x7f140fbc

.field public static main_search_for_a_biller:I = 0x7f140fbd

.field public static main_select_end_date:I = 0x7f140fbe

.field public static main_select_manually:I = 0x7f140fbf

.field public static main_select_start_date:I = 0x7f140fc0

.field public static main_select_trading_range:I = 0x7f140fc1

.field public static main_sender_with_colon:I = 0x7f140fc2

.field public static main_service:I = 0x7f140fc3

.field public static main_set_amount_text:I = 0x7f140fc4

.field public static main_set_psw:I = 0x7f140fc5

.field public static main_setting:I = 0x7f140fc6

.field public static main_settings:I = 0x7f140fc7

.field public static main_sign_up_and_claim:I = 0x7f140fc8

.field public static main_sign_up_login:I = 0x7f140fc9

.field public static main_signing_time:I = 0x7f140fca

.field public static main_speaker_on:I = 0x7f140fcb

.field public static main_start_date:I = 0x7f140fcc

.field public static main_status:I = 0x7f140fcd

.field public static main_store_owner_s:I = 0x7f140fce

.field public static main_str_create_plan:I = 0x7f140fcf

.field public static main_str_no_balance_account:I = 0x7f140fd0

.field public static main_str_no_slots_available:I = 0x7f140fd1

.field public static main_str_security_guaranteed:I = 0x7f140fd2

.field public static main_str_sold_out:I = 0x7f140fd3

.field public static main_str_total_assets:I = 0x7f140fd4

.field public static main_str_total_balance:I = 0x7f140fd5

.field public static main_str_yesterday_earnings:I = 0x7f140fd6

.field public static main_succeed:I = 0x7f140fd7

.field public static main_support:I = 0x7f140fd8

.field public static main_support_payments:I = 0x7f140fd9

.field public static main_task_center_countdown_days_hours:I = 0x7f140fda

.field public static main_task_center_countdown_hours:I = 0x7f140fdb

.field public static main_task_center_countdown_minutes:I = 0x7f140fdc

.field public static main_task_center_error_result:I = 0x7f140fdd

.field public static main_temp_code_time_out:I = 0x7f140fde

.field public static main_terms_and_conditions:I = 0x7f140fdf

.field public static main_to_palmpay:I = 0x7f140ff6

.field public static main_to_store:I = 0x7f140ff7

.field public static main_today_received:I = 0x7f140ff8

.field public static main_touch_id_for_login:I = 0x7f140ff9

.field public static main_touch_id_for_pay:I = 0x7f140ffa

.field public static main_touch_id_for_unlock:I = 0x7f140ffb

.field public static main_touch_id_unlock:I = 0x7f140ffc

.field public static main_touch_turn_off:I = 0x7f140ffd

.field public static main_touch_turn_on:I = 0x7f140ffe

.field public static main_trans_id:I = 0x7f140fff

.field public static main_transaction_amount_title:I = 0x7f141000

.field public static main_transaction_history:I = 0x7f141001

.field public static main_transaction_info:I = 0x7f141002

.field public static main_transaction_location:I = 0x7f141003

.field public static main_transaction_receipt:I = 0x7f141004

.field public static main_transaction_receipt_bottom_tip:I = 0x7f141005

.field public static main_transaction_type:I = 0x7f141006

.field public static main_transcation_history:I = 0x7f141007

.field public static main_transfer_to_bank:I = 0x7f141008

.field public static main_trip_pay_success:I = 0x7f141009

.field public static main_turn_on_auto_save_tips:I = 0x7f14100a

.field public static main_turn_on_system_notifications:I = 0x7f14100b

.field public static main_types_of_services:I = 0x7f14100c

.field public static main_udpate_time:I = 0x7f14100d

.field public static main_unbind_text:I = 0x7f14100e

.field public static main_unused_savings_coupons_points:I = 0x7f14100f

.field public static main_up_to_xx_rewards:I = 0x7f141010

.field public static main_update:I = 0x7f141011

.field public static main_update_now:I = 0x7f141012

.field public static main_use_points_tips:I = 0x7f141013

.field public static main_use_this_tag_to:I = 0x7f141014

.field public static main_valid_date:I = 0x7f141015

.field public static main_valid_until_remark:I = 0x7f141016

.field public static main_verification_code_id:I = 0x7f141017

.field public static main_verification_history:I = 0x7f141018

.field public static main_verify:I = 0x7f141019

.field public static main_version_s:I = 0x7f14101a

.field public static main_view:I = 0x7f14101b

.field public static main_view_all:I = 0x7f14101c

.field public static main_view_coupon:I = 0x7f14101d

.field public static main_view_more:I = 0x7f14101e

.field public static main_view_original_order:I = 0x7f14101f

.field public static main_waiting_to_open:I = 0x7f141020

.field public static main_waiting_to_receive:I = 0x7f141021

.field public static main_web_test:I = 0x7f141022

.field public static main_welcome_to_palmpay:I = 0x7f141023

.field public static main_x_sent_you_x:I = 0x7f141024

.field public static main_you_can_get_s:I = 0x7f141025

.field public static main_you_can_modify_add:I = 0x7f141026

.field public static main_zone_reward_risk:I = 0x7f141027


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
