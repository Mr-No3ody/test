.class public final LAc/k;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static appwidget_info_data_bundle:I = 0x7f180003

.field public static appwidget_info_pay_bills:I = 0x7f180004

.field public static appwidget_info_send_money:I = 0x7f180005

.field public static appwidget_info_topup_airtime:I = 0x7f180006

.field public static main_pref_pin_setting:I = 0x7f18000e

.field public static shortcuts:I = 0x7f180014


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
