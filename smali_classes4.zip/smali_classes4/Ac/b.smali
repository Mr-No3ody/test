.class public final LAc/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static main_color_19aedd:I = 0x7f06041a

.field public static main_color_1e1e1e:I = 0x7f06041b

.field public static main_color_292929:I = 0x7f06041c

.field public static main_color_64D051:I = 0x7f06041d

.field public static main_color_829fba:I = 0x7f06041e

.field public static main_color_858a8f:I = 0x7f06041f

.field public static main_color_9076b6:I = 0x7f060420

.field public static main_color_bg_home_account_bar:I = 0x7f060421

.field public static main_color_btn_bg_add_money:I = 0x7f060422

.field public static main_color_btn_purple_border:I = 0x7f060423

.field public static main_color_btn_text:I = 0x7f060424

.field public static main_color_btn_withdraw_text:I = 0x7f060425

.field public static main_color_ca7425:I = 0x7f060426

.field public static main_color_d05151:I = 0x7f060427

.field public static main_color_ececec:I = 0x7f060428

.field public static main_color_fd960c:I = 0x7f060429

.field public static main_color_home_text_label:I = 0x7f06042a

.field public static main_color_home_text_label_bg:I = 0x7f06042b

.field public static main_color_premium:I = 0x7f06042c

.field public static main_color_premium_secondary:I = 0x7f06042d

.field public static main_color_reward_bg_cash_end:I = 0x7f06042e

.field public static main_color_reward_bg_cash_start:I = 0x7f06042f

.field public static main_color_reward_bg_cash_stroke:I = 0x7f060430

.field public static main_color_reward_bg_coupon_end:I = 0x7f060431

.field public static main_color_reward_bg_coupon_start:I = 0x7f060432

.field public static main_color_reward_bg_coupon_stroke:I = 0x7f060433

.field public static main_color_reward_bg_points_end:I = 0x7f060434

.field public static main_color_reward_bg_points_start:I = 0x7f060435

.field public static main_color_reward_bg_points_stroke:I = 0x7f060436

.field public static main_color_reward_bg_trialcash_end:I = 0x7f060437

.field public static main_color_reward_bg_trialcash_start:I = 0x7f060438

.field public static main_color_reward_bg_trialcash_stroke:I = 0x7f060439

.field public static main_color_reward_btn_disable_text:I = 0x7f06043a

.field public static main_color_reward_check_in_tips_bg:I = 0x7f06043b

.field public static main_color_reward_coupon_bg:I = 0x7f06043c

.field public static main_color_reward_coupon_combo_bg:I = 0x7f06043d

.field public static main_color_reward_coupon_combo_bottom_bg:I = 0x7f06043e

.field public static main_color_reward_coupon_combo_title_bg:I = 0x7f06043f

.field public static main_color_reward_coupon_item_bg:I = 0x7f060440

.field public static main_color_reward_coupon_local_end_bg:I = 0x7f060441

.field public static main_color_reward_coupon_local_start_bg:I = 0x7f060442

.field public static main_color_reward_progress_active:I = 0x7f060443

.field public static main_color_reward_progress_active_start:I = 0x7f060444

.field public static main_color_rewards_coupon_button_text:I = 0x7f060445

.field public static main_color_rewards_coupon_desc_text:I = 0x7f060446

.field public static main_color_sold_out_bg:I = 0x7f060447

.field public static main_color_sold_out_text:I = 0x7f060448

.field public static main_color_top_card_bg:I = 0x7f060449

.field public static main_coupon_complete_txt_color:I = 0x7f06044a

.field public static main_coupon_failed_txt_color:I = 0x7f06044b

.field public static main_coupon_pending_txt_color:I = 0x7f06044c

.field public static main_divider_color:I = 0x7f06044d

.field public static main_home_account_bar_bg:I = 0x7f06044e

.field public static main_home_loan_refresh_text_color:I = 0x7f06044f

.field public static main_invitee_photo_text_color:I = 0x7f060450

.field public static main_invitee_points_color:I = 0x7f060451

.field public static main_invitee_points_gray_color:I = 0x7f060452

.field public static main_point_text_color_1:I = 0x7f060453

.field public static main_pop_text_color:I = 0x7f060454

.field public static main_rewards_points_coupon_text_color:I = 0x7f060455

.field public static main_saving_fund_tab_text_selector:I = 0x7f060456

.field public static main_savings_invest_bg:I = 0x7f060457

.field public static main_select_white_black:I = 0x7f060458

.field public static main_tab_text_color_1:I = 0x7f060459


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
