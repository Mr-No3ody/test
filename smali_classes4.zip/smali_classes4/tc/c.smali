.class public final Ltc/c;
.super Landroidx/fragment/app/d0;
.source "SourceFile"


# instance fields
.field public h:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment;

.field public i:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

.field public j:Ljava/lang/String;

.field public k:Ljava/util/ArrayList;


# virtual methods
.method public final c()I
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    return v0
.end method

.method public final e(I)Ljava/lang/CharSequence;
    .locals 1

    .line 1
    iget-object v0, p0, Ltc/c;->k:Ljava/util/ArrayList;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ljava/lang/CharSequence;

    .line 10
    .line 11
    return-object p1

    .line 12
    :cond_0
    const-string p1, ""

    .line 13
    .line 14
    return-object p1
.end method

.method public final n(I)Landroidx/fragment/app/Fragment;
    .locals 2

    .line 1
    iget-object v0, p0, Ltc/c;->j:Ljava/lang/String;

    .line 2
    .line 3
    if-eqz p1, :cond_3

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-eq p1, v1, :cond_1

    .line 7
    .line 8
    iget-object p1, p0, Ltc/c;->i:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

    .line 9
    .line 10
    if-nez p1, :cond_0

    .line 11
    .line 12
    sget-object p1, Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;->t:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment$a;

    .line 13
    .line 14
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment$a;->newInstance(Ljava/lang/String;)Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    iput-object p1, p0, Ltc/c;->i:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

    .line 19
    .line 20
    :cond_0
    iget-object p1, p0, Ltc/c;->i:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

    .line 21
    .line 22
    return-object p1

    .line 23
    :cond_1
    iget-object p1, p0, Ltc/c;->h:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment;

    .line 24
    .line 25
    if-nez p1, :cond_2

    .line 26
    .line 27
    sget-object p1, Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment;->w:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment$a;

    .line 28
    .line 29
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment$a;->newInstance(Ljava/lang/String;)Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iput-object p1, p0, Ltc/c;->h:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment;

    .line 34
    .line 35
    :cond_2
    iget-object p1, p0, Ltc/c;->h:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithdrawListFragment;

    .line 36
    .line 37
    return-object p1

    .line 38
    :cond_3
    iget-object p1, p0, Ltc/c;->i:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

    .line 39
    .line 40
    if-nez p1, :cond_4

    .line 41
    .line 42
    sget-object p1, Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;->t:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment$a;

    .line 43
    .line 44
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment$a;->newInstance(Ljava/lang/String;)Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    iput-object p1, p0, Ltc/c;->i:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

    .line 49
    .line 50
    :cond_4
    iget-object p1, p0, Ltc/c;->i:Lcom/transsnet/palmpay/jara_packet/ui/fragment/ReferEarnWithRewardsListFragment;

    .line 51
    .line 52
    return-object p1
.end method
