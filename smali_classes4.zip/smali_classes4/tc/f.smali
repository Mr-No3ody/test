.class public final Ltc/f;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lzb/I;

.field public c:Z

.field public final d:Lxf/t;

.field public final e:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Lzb/I;)V
    .locals 1

    .line 1
    const-string v0, "mContext"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Ltc/f;->a:Landroid/content/Context;

    .line 10
    .line 11
    iput-object p2, p0, Ltc/f;->b:Lzb/I;

    .line 12
    .line 13
    new-instance p1, Lrd/t;

    .line 14
    .line 15
    const/16 p2, 0x10

    .line 16
    .line 17
    invoke-direct {p1, p2}, Lrd/t;-><init>(I)V

    .line 18
    .line 19
    .line 20
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, Ltc/f;->d:Lxf/t;

    .line 25
    .line 26
    const/4 p1, 0x3

    .line 27
    iput p1, p0, Ltc/f;->e:I

    .line 28
    .line 29
    return-void
.end method

.method public static a(J)Ljava/lang/String;
    .locals 1

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrencySymbol()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p0, p1}, LPa/r0;->n0(J)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    const-string p1, "+"

    .line 10
    .line 11
    invoke-static {p1, v0, p0}, LN8/q0;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0
.end method


# virtual methods
.method public final b()Ljava/util/ArrayList;
    .locals 1

    .line 1
    iget-object v0, p0, Ltc/f;->d:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/util/ArrayList;

    .line 8
    .line 9
    return-object v0
.end method

.method public final getItemCount()I
    .locals 2

    .line 1
    iget-boolean v0, p0, Ltc/f;->c:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, Ltc/f;->b()Ljava/util/ArrayList;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    return v0

    .line 14
    :cond_0
    invoke-virtual {p0}, Ltc/f;->b()Ljava/util/ArrayList;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget v1, p0, Ltc/f;->e:I

    .line 23
    .line 24
    if-le v0, v1, :cond_1

    .line 25
    .line 26
    return v1

    .line 27
    :cond_1
    invoke-virtual {p0}, Ltc/f;->b()Ljava/util/ArrayList;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    return v0
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 13

    .line 1
    const-string v0, "getValue(...)"

    .line 2
    .line 3
    check-cast p1, Ltc/e;

    .line 4
    .line 5
    const-string v1, "holder"

    .line 6
    .line 7
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    :try_start_0
    invoke-virtual {p0}, Ltc/f;->b()Ljava/util/ArrayList;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    move-object v2, v1

    .line 19
    check-cast v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;

    .line 20
    .line 21
    iget-object v3, p1, Ltc/e;->b:Lxf/t;

    .line 22
    .line 23
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    check-cast v3, Landroid/widget/TextView;

    .line 31
    .line 32
    iget-object v4, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->phone:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v4}, LPa/r0;->E0(Ljava/lang/String;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 39
    .line 40
    .line 41
    iget-object v3, p1, Ltc/e;->c:Lxf/t;

    .line 42
    .line 43
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    check-cast v3, Landroid/widget/TextView;

    .line 51
    .line 52
    iget-wide v4, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->regRewardAmt:J

    .line 53
    .line 54
    invoke-static {v4, v5}, Ltc/f;->a(J)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 59
    .line 60
    .line 61
    iget-object v3, p1, Ltc/e;->d:Lxf/t;

    .line 62
    .line 63
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    check-cast v3, Landroid/widget/TextView;

    .line 71
    .line 72
    iget-wide v4, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->activeRewardAmt:J

    .line 73
    .line 74
    invoke-static {v4, v5}, Ltc/f;->a(J)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v4

    .line 78
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 79
    .line 80
    .line 81
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->status:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 82
    .line 83
    iget-object v4, p1, Ltc/e;->j:Lxf/t;

    .line 84
    .line 85
    iget-object v5, p1, Ltc/e;->f:Lxf/t;

    .line 86
    .line 87
    const/16 v6, 0x9

    .line 88
    .line 89
    const/4 v7, 0x2

    .line 90
    if-eq v3, v7, :cond_1

    .line 91
    .line 92
    if-ne v3, v6, :cond_0

    .line 93
    .line 94
    goto :goto_0

    .line 95
    :cond_0
    :try_start_1
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v3

    .line 99
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    check-cast v3, Landroid/widget/TextView;

    .line 103
    .line 104
    invoke-static {v3}, Loa/h;->c(Landroid/view/View;)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    check-cast v3, Landroid/view/View;

    .line 115
    .line 116
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {p1}, Ltc/e;->c()Landroid/view/View;

    .line 120
    .line 121
    .line 122
    move-result-object v3

    .line 123
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 124
    .line 125
    .line 126
    goto :goto_1

    .line 127
    :cond_1
    :goto_0
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    check-cast v3, Landroid/widget/TextView;

    .line 135
    .line 136
    iget-object v8, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->remark:Ljava/lang/String;

    .line 137
    .line 138
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    check-cast v3, Landroid/widget/TextView;

    .line 149
    .line 150
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v3

    .line 157
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    check-cast v3, Landroid/view/View;

    .line 161
    .line 162
    invoke-static {v3}, Loa/h;->c(Landroid/view/View;)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {p1}, Ltc/e;->c()Landroid/view/View;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    invoke-static {v3}, Loa/h;->c(Landroid/view/View;)V

    .line 170
    .line 171
    .line 172
    :goto_1
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->status:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 173
    .line 174
    iget-object v5, p1, Ltc/e;->g:Lxf/t;

    .line 175
    .line 176
    const/4 v8, 0x1

    .line 177
    if-ne v3, v8, :cond_2

    .line 178
    .line 179
    :try_start_2
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->regStatus:I

    .line 180
    .line 181
    if-ne v3, v8, :cond_2

    .line 182
    .line 183
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v3

    .line 187
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    check-cast v3, Landroid/widget/ImageView;

    .line 191
    .line 192
    sget v5, Lpc/c;->jp_invitees_selected:I

    .line 193
    .line 194
    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 195
    .line 196
    .line 197
    iget-wide v9, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->regRewardAmt:J

    .line 198
    .line 199
    goto :goto_2

    .line 200
    :cond_2
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v3

    .line 204
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 205
    .line 206
    .line 207
    check-cast v3, Landroid/widget/ImageView;

    .line 208
    .line 209
    sget v5, Lpc/c;->jp_invitees_unselected:I

    .line 210
    .line 211
    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 212
    .line 213
    .line 214
    const-wide/16 v9, 0x0

    .line 215
    .line 216
    :goto_2
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->status:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 217
    .line 218
    iget-object v5, p1, Ltc/e;->i:Lxf/t;

    .line 219
    .line 220
    if-ne v3, v8, :cond_3

    .line 221
    .line 222
    :try_start_3
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->activeStatus:I

    .line 223
    .line 224
    if-ne v3, v8, :cond_3

    .line 225
    .line 226
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v3

    .line 230
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 231
    .line 232
    .line 233
    check-cast v3, Landroid/widget/ImageView;

    .line 234
    .line 235
    sget v5, Lpc/c;->jp_invitees_selected:I

    .line 236
    .line 237
    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 238
    .line 239
    .line 240
    iget-wide v11, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->activeRewardAmt:J

    .line 241
    .line 242
    add-long/2addr v9, v11

    .line 243
    goto :goto_3

    .line 244
    :cond_3
    invoke-virtual {v5}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    move-result-object v3

    .line 248
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 249
    .line 250
    .line 251
    check-cast v3, Landroid/widget/ImageView;

    .line 252
    .line 253
    sget v5, Lpc/c;->jp_invitees_unselected:I

    .line 254
    .line 255
    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 256
    .line 257
    .line 258
    :goto_3
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->status:I

    .line 259
    .line 260
    if-eq v3, v7, :cond_5

    .line 261
    .line 262
    if-ne v3, v6, :cond_4

    .line 263
    .line 264
    goto :goto_4

    .line 265
    :cond_4
    invoke-virtual {p1}, Ltc/e;->b()Landroid/widget/TextView;

    .line 266
    .line 267
    .line 268
    move-result-object v3

    .line 269
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 270
    .line 271
    .line 272
    invoke-virtual {p1}, Ltc/e;->b()Landroid/widget/TextView;

    .line 273
    .line 274
    .line 275
    move-result-object v3

    .line 276
    invoke-static {v9, v10}, Ltc/f;->a(J)Ljava/lang/String;

    .line 277
    .line 278
    .line 279
    move-result-object v5

    .line 280
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 281
    .line 282
    .line 283
    goto :goto_5

    .line 284
    :cond_5
    :goto_4
    invoke-virtual {p1}, Ltc/e;->b()Landroid/widget/TextView;

    .line 285
    .line 286
    .line 287
    move-result-object v3

    .line 288
    invoke-static {v3}, Loa/h;->c(Landroid/view/View;)V

    .line 289
    .line 290
    .line 291
    :goto_5
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->status:I

    .line 292
    .line 293
    if-eq v3, v7, :cond_7

    .line 294
    .line 295
    if-eq v3, v6, :cond_7

    .line 296
    .line 297
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->regStatus:I

    .line 298
    .line 299
    if-ne v3, v8, :cond_6

    .line 300
    .line 301
    iget v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->activeStatus:I

    .line 302
    .line 303
    if-eq v3, v8, :cond_7

    .line 304
    .line 305
    :cond_6
    invoke-virtual {p1}, Ltc/e;->d()Landroid/view/View;

    .line 306
    .line 307
    .line 308
    move-result-object v3

    .line 309
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 310
    .line 311
    .line 312
    invoke-virtual {p1}, Ltc/e;->d()Landroid/view/View;

    .line 313
    .line 314
    .line 315
    move-result-object v3

    .line 316
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 317
    .line 318
    .line 319
    move-result-object p2

    .line 320
    invoke-virtual {v3, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 321
    .line 322
    .line 323
    goto :goto_6

    .line 324
    :cond_7
    invoke-virtual {p1}, Ltc/e;->d()Landroid/view/View;

    .line 325
    .line 326
    .line 327
    move-result-object p2

    .line 328
    invoke-static {p2}, Loa/h;->c(Landroid/view/View;)V

    .line 329
    .line 330
    .line 331
    :goto_6
    iget-object p2, p1, Ltc/e;->p:Lxf/t;

    .line 332
    .line 333
    invoke-virtual {p2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 334
    .line 335
    .line 336
    move-result-object p2

    .line 337
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 338
    .line 339
    .line 340
    check-cast p2, Landroid/widget/TextView;

    .line 341
    .line 342
    iget-object v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->regTaskName:Ljava/lang/String;

    .line 343
    .line 344
    invoke-virtual {p2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 345
    .line 346
    .line 347
    iget-object p2, p1, Ltc/e;->t:Lxf/t;

    .line 348
    .line 349
    invoke-virtual {p2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object p2

    .line 353
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    check-cast p2, Landroid/widget/TextView;

    .line 357
    .line 358
    iget-object v3, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->activeTaskName:Ljava/lang/String;

    .line 359
    .line 360
    invoke-virtual {p2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 361
    .line 362
    .line 363
    iget p2, v2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnRecord;->inviteeType:I

    .line 364
    .line 365
    if-nez p2, :cond_8

    .line 366
    .line 367
    invoke-virtual {p1, v8}, Ltc/e;->a(Z)V

    .line 368
    .line 369
    .line 370
    goto :goto_7

    .line 371
    :cond_8
    invoke-virtual {v4}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 372
    .line 373
    .line 374
    move-result-object p2

    .line 375
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 376
    .line 377
    .line 378
    check-cast p2, Landroid/view/View;

    .line 379
    .line 380
    invoke-static {p2}, Loa/h;->c(Landroid/view/View;)V

    .line 381
    .line 382
    .line 383
    const/4 p2, 0x0

    .line 384
    invoke-virtual {p1, p2}, Ltc/e;->a(Z)V

    .line 385
    .line 386
    .line 387
    :goto_7
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 388
    .line 389
    .line 390
    :catch_0
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    .line 1
    const-string p2, "parent"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p2, Ltc/e;

    .line 7
    .line 8
    iget-object v0, p0, Ltc/f;->a:Landroid/content/Context;

    .line 9
    .line 10
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget v1, Lpc/e;->jp_item_cs_invitees:I

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    const-string v0, "inflate(...)"

    .line 22
    .line 23
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p2, p1}, Ltc/e;-><init>(Landroid/view/View;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p2}, Ltc/e;->d()Landroid/view/View;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    new-instance v0, Ltb/W;

    .line 34
    .line 35
    const/4 v1, 0x1

    .line 36
    invoke-direct {v0, v1, p2, p0}, Ltb/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 40
    .line 41
    .line 42
    return-object p2
.end method
