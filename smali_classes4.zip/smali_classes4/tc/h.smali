.class public final Ltc/h;
.super LKb/c;
.source "SourceFile"


# virtual methods
.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 6

    .line 1
    const-string v0, "holder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    check-cast p1, Ltc/g;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    const/16 v1, 0x8

    .line 10
    .line 11
    const/4 v2, 0x2

    .line 12
    const/4 v3, 0x1

    .line 13
    iget-object v4, p0, LKb/c;->a:Landroid/content/Context;

    .line 14
    .line 15
    if-eqz p2, :cond_0

    .line 16
    .line 17
    if-eq p2, v3, :cond_0

    .line 18
    .line 19
    if-eq p2, v2, :cond_0

    .line 20
    .line 21
    iget-object v5, p1, Ltc/g;->g:Landroid/widget/ImageView;

    .line 22
    .line 23
    invoke-virtual {v5, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p1, Ltc/g;->d:Landroid/widget/TextView;

    .line 27
    .line 28
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 29
    .line 30
    .line 31
    iget-object v0, p1, Ltc/g;->e:Landroid/widget/TextView;

    .line 32
    .line 33
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    sget v5, Lpc/b;->jp_history_processing:I

    .line 38
    .line 39
    invoke-virtual {v1, v5}, Landroid/content/res/Resources;->getColor(I)I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 44
    .line 45
    .line 46
    iget-object v0, p1, Ltc/g;->f:Landroid/widget/TextView;

    .line 47
    .line 48
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    sget v4, Lpc/b;->jp_history_processing:I

    .line 53
    .line 54
    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getColor(I)I

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_0
    iget-object v5, p1, Ltc/g;->g:Landroid/widget/ImageView;

    .line 63
    .line 64
    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 65
    .line 66
    .line 67
    iget-object v0, p1, Ltc/g;->d:Landroid/widget/TextView;

    .line 68
    .line 69
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 70
    .line 71
    .line 72
    iget-object v0, p1, Ltc/g;->e:Landroid/widget/TextView;

    .line 73
    .line 74
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    sget v5, Lpc/b;->jp_yellow:I

    .line 79
    .line 80
    invoke-virtual {v1, v5}, Landroid/content/res/Resources;->getColor(I)I

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 85
    .line 86
    .line 87
    iget-object v0, p1, Ltc/g;->f:Landroid/widget/TextView;

    .line 88
    .line 89
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    sget v4, Lpc/b;->jp_yellow:I

    .line 94
    .line 95
    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getColor(I)I

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 100
    .line 101
    .line 102
    :goto_0
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 103
    .line 104
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/RankList;

    .line 109
    .line 110
    if-eqz p2, :cond_3

    .line 111
    .line 112
    if-eq p2, v3, :cond_2

    .line 113
    .line 114
    if-eq p2, v2, :cond_1

    .line 115
    .line 116
    goto :goto_1

    .line 117
    :cond_1
    iget-object p2, p1, Ltc/g;->g:Landroid/widget/ImageView;

    .line 118
    .line 119
    sget v1, Lpc/c;->jp_rank_3:I

    .line 120
    .line 121
    invoke-static {p2, v1}, LPa/r0;->d1(Landroid/widget/ImageView;I)V

    .line 122
    .line 123
    .line 124
    goto :goto_1

    .line 125
    :cond_2
    iget-object p2, p1, Ltc/g;->g:Landroid/widget/ImageView;

    .line 126
    .line 127
    sget v1, Lpc/c;->jp_rank_2:I

    .line 128
    .line 129
    invoke-static {p2, v1}, LPa/r0;->d1(Landroid/widget/ImageView;I)V

    .line 130
    .line 131
    .line 132
    goto :goto_1

    .line 133
    :cond_3
    iget-object p2, p1, Ltc/g;->g:Landroid/widget/ImageView;

    .line 134
    .line 135
    sget v1, Lpc/c;->jp_rank_1:I

    .line 136
    .line 137
    invoke-static {p2, v1}, LPa/r0;->d1(Landroid/widget/ImageView;I)V

    .line 138
    .line 139
    .line 140
    :goto_1
    iget-object p2, p1, Ltc/g;->d:Landroid/widget/TextView;

    .line 141
    .line 142
    iget v1, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/RankList;->rank:I

    .line 143
    .line 144
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 149
    .line 150
    .line 151
    iget-object p2, p1, Ltc/g;->e:Landroid/widget/TextView;

    .line 152
    .line 153
    iget-object v1, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/RankList;->memberName:Ljava/lang/String;

    .line 154
    .line 155
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 160
    .line 161
    .line 162
    iget-object p1, p1, Ltc/g;->f:Landroid/widget/TextView;

    .line 163
    .line 164
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrencySymbol()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object p2

    .line 168
    iget-wide v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/RankList;->amount:J

    .line 169
    .line 170
    invoke-static {v0, v1}, LPa/r0;->n0(J)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    const-string v1, "+"

    .line 175
    .line 176
    invoke-static {v1, p2, v0, p1}, LC0/G;->y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/widget/TextView;)V

    .line 177
    .line 178
    .line 179
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    .line 1
    const-string p2, "parent"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p2, Ltc/g;

    .line 7
    .line 8
    iget-object v0, p0, LKb/c;->a:Landroid/content/Context;

    .line 9
    .line 10
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget v1, Lpc/e;->jp_item_re_rank:I

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    const-string v0, "inflate(...)"

    .line 22
    .line 23
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p2, p0, p1}, Ltc/g;-><init>(Ltc/h;Landroid/view/View;)V

    .line 27
    .line 28
    .line 29
    return-object p2
.end method
