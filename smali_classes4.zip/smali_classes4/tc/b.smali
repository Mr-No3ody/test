.class public final Ltc/b;
.super LKb/c;
.source "SourceFile"


# direct methods
.method public static c(ILcom/transsnet/palmpay/jara_packet/bean/resp/Comment;)Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;->pictureList:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v0, p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;->pictureList:Ljava/util/List;

    .line 13
    .line 14
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-ge p0, v0, :cond_1

    .line 19
    .line 20
    iget-object p1, p1, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;->pictureList:Ljava/util/List;

    .line 21
    .line 22
    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    check-cast p0, Ljava/lang/String;

    .line 27
    .line 28
    return-object p0

    .line 29
    :cond_1
    :goto_0
    const/4 p0, 0x0

    .line 30
    return-object p0
.end method


# virtual methods
.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 4

    .line 1
    const-string v0, "holder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    check-cast p1, Ltc/a;

    .line 7
    .line 8
    iget-object v0, p1, Ltc/a;->d:Landroid/view/View;

    .line 9
    .line 10
    const-string v1, "#e5e5e5"

    .line 11
    .line 12
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const-string v2, "#ffffff"

    .line 17
    .line 18
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    const/16 v3, 0x14

    .line 23
    .line 24
    invoke-static {v0, v2, v1, v3}, LPa/i0;->h0(Landroid/view/View;III)V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 28
    .line 29
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    check-cast p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;

    .line 34
    .line 35
    iget-object v0, p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;->headPortrait:Ljava/lang/String;

    .line 36
    .line 37
    sget v1, Lcom/transsnet/palmpay/custom_view/r;->cv_avatar_default:I

    .line 38
    .line 39
    iget-object v2, p1, Ltc/a;->e:Landroid/widget/ImageView;

    .line 40
    .line 41
    invoke-static {v2, v0, v1}, LPa/r0;->u1(Landroid/widget/ImageView;Ljava/lang/String;I)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;->nickName:Ljava/lang/String;

    .line 45
    .line 46
    iget-object v1, p1, Ltc/a;->j:Landroid/widget/TextView;

    .line 47
    .line 48
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 49
    .line 50
    .line 51
    iget-wide v0, p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;->createTime:J

    .line 52
    .line 53
    invoke-static {v0, v1}, LPa/r0;->S(J)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    iget-object v1, p1, Ltc/a;->o:Landroid/widget/TextView;

    .line 58
    .line 59
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 60
    .line 61
    .line 62
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrencySymbol()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    iget-wide v1, p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;->amount:J

    .line 67
    .line 68
    invoke-static {v1, v2}, LPa/r0;->n0(J)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    new-instance v2, Ljava/lang/StringBuilder;

    .line 73
    .line 74
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    iget-object v1, p1, Ltc/a;->p:Landroid/widget/TextView;

    .line 88
    .line 89
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 90
    .line 91
    .line 92
    iget-object v0, p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/Comment;->commentsContent:Ljava/lang/String;

    .line 93
    .line 94
    iget-object v1, p1, Ltc/a;->t:Landroid/widget/TextView;

    .line 95
    .line 96
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 97
    .line 98
    .line 99
    const/4 v0, 0x0

    .line 100
    invoke-static {v0, p2}, Ltc/b;->c(ILcom/transsnet/palmpay/jara_packet/bean/resp/Comment;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    iget-object v2, p1, Ltc/a;->f:Landroid/widget/ImageView;

    .line 105
    .line 106
    const/16 v3, 0x8

    .line 107
    .line 108
    if-eqz v1, :cond_0

    .line 109
    .line 110
    invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 111
    .line 112
    .line 113
    invoke-static {v1, v2}, LPa/r0;->l1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 114
    .line 115
    .line 116
    goto :goto_0

    .line 117
    :cond_0
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 118
    .line 119
    .line 120
    :goto_0
    const/4 v1, 0x1

    .line 121
    invoke-static {v1, p2}, Ltc/b;->c(ILcom/transsnet/palmpay/jara_packet/bean/resp/Comment;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    iget-object v2, p1, Ltc/a;->g:Landroid/widget/ImageView;

    .line 126
    .line 127
    if-eqz v1, :cond_1

    .line 128
    .line 129
    invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 130
    .line 131
    .line 132
    invoke-static {v1, v2}, LPa/r0;->l1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 133
    .line 134
    .line 135
    goto :goto_1

    .line 136
    :cond_1
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 137
    .line 138
    .line 139
    :goto_1
    const/4 v1, 0x2

    .line 140
    invoke-static {v1, p2}, Ltc/b;->c(ILcom/transsnet/palmpay/jara_packet/bean/resp/Comment;)Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object p2

    .line 144
    iget-object p1, p1, Ltc/a;->i:Landroid/widget/ImageView;

    .line 145
    .line 146
    if-eqz p2, :cond_2

    .line 147
    .line 148
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 149
    .line 150
    .line 151
    invoke-static {p2, p1}, LPa/r0;->l1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 152
    .line 153
    .line 154
    return-void

    .line 155
    :cond_2
    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 156
    .line 157
    .line 158
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    .line 1
    const-string p2, "parent"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p2, Ltc/a;

    .line 7
    .line 8
    iget-object v0, p0, LKb/c;->a:Landroid/content/Context;

    .line 9
    .line 10
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget v1, Lpc/e;->jp_model_comment:I

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    const-string v0, "inflate(...)"

    .line 22
    .line 23
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p2, p0, p1}, Ltc/a;-><init>(Ltc/b;Landroid/view/View;)V

    .line 27
    .line 28
    .line 29
    return-object p2
.end method
