.class public final synthetic Ltc/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;I)V
    .locals 0

    .line 1
    iput p2, p0, Ltc/d;->a:I

    iput-object p1, p0, Ltc/d;->b:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, Ltc/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget v0, Lpc/d;->ivInviteSignUp:I

    .line 7
    .line 8
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Landroid/widget/ImageView;

    .line 15
    .line 16
    return-object v0

    .line 17
    :pswitch_0
    sget v0, Lpc/d;->tvInviteRemark:I

    .line 18
    .line 19
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/widget/TextView;

    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_1
    sget v0, Lpc/d;->jpInviteMoney:I

    .line 29
    .line 30
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroid/widget/TextView;

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_2
    sget v0, Lpc/d;->tvInviteTopUpAmt:I

    .line 40
    .line 41
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 42
    .line 43
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Landroid/widget/TextView;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_3
    sget v0, Lpc/d;->tvInviteSignUpAmt:I

    .line 51
    .line 52
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 53
    .line 54
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v0, Landroid/widget/TextView;

    .line 59
    .line 60
    return-object v0

    .line 61
    :pswitch_4
    sget v0, Lpc/d;->jp_invitees_phone:I

    .line 62
    .line 63
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 64
    .line 65
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Landroid/widget/TextView;

    .line 70
    .line 71
    return-object v0

    .line 72
    :pswitch_5
    sget v0, Lpc/d;->centerGuideline:I

    .line 73
    .line 74
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 75
    .line 76
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Landroidx/constraintlayout/widget/Guideline;

    .line 81
    .line 82
    return-object v0

    .line 83
    :pswitch_6
    sget v0, Lpc/d;->tvInviteTopUpTaskName:I

    .line 84
    .line 85
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 86
    .line 87
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    check-cast v0, Landroid/widget/TextView;

    .line 92
    .line 93
    return-object v0

    .line 94
    :pswitch_7
    sget v0, Lpc/d;->tvInviteTaskName:I

    .line 95
    .line 96
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 97
    .line 98
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    check-cast v0, Landroid/widget/TextView;

    .line 103
    .line 104
    return-object v0

    .line 105
    :pswitch_8
    sget v0, Lpc/d;->llInviteTopUp:I

    .line 106
    .line 107
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 108
    .line 109
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    return-object v0

    .line 114
    :pswitch_9
    sget v0, Lpc/d;->llInviteSignUp:I

    .line 115
    .line 116
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 117
    .line 118
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    return-object v0

    .line 123
    :pswitch_a
    sget v0, Lpc/d;->ivInviteTopUp:I

    .line 124
    .line 125
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 126
    .line 127
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    check-cast v0, Landroid/widget/ImageView;

    .line 132
    .line 133
    return-object v0

    .line 134
    :pswitch_b
    sget v0, Lpc/d;->jp_invitees_status:I

    .line 135
    .line 136
    iget-object v1, p0, Ltc/d;->b:Landroid/view/View;

    .line 137
    .line 138
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    return-object v0

    .line 143
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
