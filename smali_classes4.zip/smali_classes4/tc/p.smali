.class public final Ltc/p;
.super LKb/c;
.source "SourceFile"


# virtual methods
.method public final getItemCount()I
    .locals 1

    .line 1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 6

    .line 1
    const-string v0, "holder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    check-cast p1, Ltc/o;

    .line 7
    .line 8
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 9
    .line 10
    const/16 v1, 0x8

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p1, Ltc/o;->f:Landroid/widget/TextView;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p1, Ltc/o;->j:Landroid/widget/TextView;

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 28
    .line 29
    .line 30
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 31
    .line 32
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;

    .line 37
    .line 38
    iget v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->status:I

    .line 39
    .line 40
    const/4 v1, 0x2

    .line 41
    const/4 v2, 0x0

    .line 42
    iget-object v3, p0, LKb/c;->a:Landroid/content/Context;

    .line 43
    .line 44
    if-ne v0, v1, :cond_0

    .line 45
    .line 46
    iget-object v0, p1, Ltc/o;->d:Landroid/widget/TextView;

    .line 47
    .line 48
    sget v1, Lpc/b;->jp_history_failed:I

    .line 49
    .line 50
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 55
    .line 56
    .line 57
    iget-object v0, p1, Ltc/o;->e:Landroid/widget/TextView;

    .line 58
    .line 59
    sget v1, Lpc/b;->jp_history_processing:I

    .line 60
    .line 61
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 66
    .line 67
    .line 68
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 69
    .line 70
    sget v1, Lpc/b;->jp_history_failed:I

    .line 71
    .line 72
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 77
    .line 78
    .line 79
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 80
    .line 81
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 82
    .line 83
    .line 84
    iget-object v0, p1, Ltc/o;->j:Landroid/widget/TextView;

    .line 85
    .line 86
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 87
    .line 88
    .line 89
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 90
    .line 91
    sget v1, Lba/k;->core_failed:I

    .line 92
    .line 93
    invoke-virtual {v3, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 98
    .line 99
    .line 100
    goto/16 :goto_1

    .line 101
    .line 102
    :cond_0
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 103
    .line 104
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;

    .line 109
    .line 110
    iget v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->status:I

    .line 111
    .line 112
    const/4 v1, 0x3

    .line 113
    if-eq v0, v1, :cond_4

    .line 114
    .line 115
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 116
    .line 117
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;

    .line 122
    .line 123
    iget v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->status:I

    .line 124
    .line 125
    const/4 v1, 0x4

    .line 126
    if-eq v0, v1, :cond_4

    .line 127
    .line 128
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 129
    .line 130
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;

    .line 135
    .line 136
    iget v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->status:I

    .line 137
    .line 138
    const/4 v1, 0x5

    .line 139
    if-ne v0, v1, :cond_1

    .line 140
    .line 141
    goto/16 :goto_0

    .line 142
    .line 143
    :cond_1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 144
    .line 145
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;

    .line 150
    .line 151
    iget v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->status:I

    .line 152
    .line 153
    if-nez v0, :cond_2

    .line 154
    .line 155
    iget-object v0, p1, Ltc/o;->d:Landroid/widget/TextView;

    .line 156
    .line 157
    sget v1, Lpc/b;->jp_history_processing:I

    .line 158
    .line 159
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 160
    .line 161
    .line 162
    move-result v1

    .line 163
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 164
    .line 165
    .line 166
    iget-object v0, p1, Ltc/o;->e:Landroid/widget/TextView;

    .line 167
    .line 168
    sget v1, Lpc/b;->jp_history_processing:I

    .line 169
    .line 170
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 171
    .line 172
    .line 173
    move-result v1

    .line 174
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 175
    .line 176
    .line 177
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 178
    .line 179
    sget v1, Lpc/b;->jp_history_processing:I

    .line 180
    .line 181
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 182
    .line 183
    .line 184
    move-result v1

    .line 185
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 186
    .line 187
    .line 188
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 189
    .line 190
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 191
    .line 192
    .line 193
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 194
    .line 195
    sget v1, Lpc/f;->jp_waiting2:I

    .line 196
    .line 197
    invoke-virtual {v3, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object v1

    .line 201
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 202
    .line 203
    .line 204
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 205
    .line 206
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 207
    .line 208
    .line 209
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 210
    .line 211
    sget v1, Lpc/c;->jp_withdraw_btn_r6_bg:I

    .line 212
    .line 213
    invoke-virtual {v3, v1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 214
    .line 215
    .line 216
    move-result-object v1

    .line 217
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 218
    .line 219
    .line 220
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 221
    .line 222
    sget v1, Lpc/f;->jp_withdraw:I

    .line 223
    .line 224
    invoke-virtual {v3, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 225
    .line 226
    .line 227
    move-result-object v1

    .line 228
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 229
    .line 230
    .line 231
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 232
    .line 233
    sget v1, LL6/b;->ppColorTextBase:I

    .line 234
    .line 235
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 236
    .line 237
    .line 238
    move-result v1

    .line 239
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 240
    .line 241
    .line 242
    goto/16 :goto_1

    .line 243
    .line 244
    :cond_2
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 245
    .line 246
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    check-cast v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;

    .line 251
    .line 252
    iget-boolean v0, v0, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->commentEnable:Z

    .line 253
    .line 254
    if-eqz v0, :cond_3

    .line 255
    .line 256
    iget-object v0, p1, Ltc/o;->d:Landroid/widget/TextView;

    .line 257
    .line 258
    sget v1, Lcom/transsnet/palmpay/custom_view/p;->cv_text_color_white:I

    .line 259
    .line 260
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 261
    .line 262
    .line 263
    move-result v1

    .line 264
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 265
    .line 266
    .line 267
    iget-object v0, p1, Ltc/o;->e:Landroid/widget/TextView;

    .line 268
    .line 269
    sget v1, Lpc/b;->jp_history_processing:I

    .line 270
    .line 271
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 272
    .line 273
    .line 274
    move-result v1

    .line 275
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 276
    .line 277
    .line 278
    iget-object v0, p1, Ltc/o;->f:Landroid/widget/TextView;

    .line 279
    .line 280
    sget v1, Lpc/b;->jp_history_succ:I

    .line 281
    .line 282
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 283
    .line 284
    .line 285
    move-result v1

    .line 286
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 287
    .line 288
    .line 289
    iget-object v0, p1, Ltc/o;->f:Landroid/widget/TextView;

    .line 290
    .line 291
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 292
    .line 293
    .line 294
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 295
    .line 296
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 297
    .line 298
    .line 299
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 300
    .line 301
    sget v1, Lpc/c;->jp_share_btn_r6_bg:I

    .line 302
    .line 303
    invoke-virtual {v3, v1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 304
    .line 305
    .line 306
    move-result-object v1

    .line 307
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 308
    .line 309
    .line 310
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 311
    .line 312
    sget v1, Lpc/f;->jp_share_earn:I

    .line 313
    .line 314
    invoke-virtual {v3, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 315
    .line 316
    .line 317
    move-result-object v1

    .line 318
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 319
    .line 320
    .line 321
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 322
    .line 323
    sget v1, LL6/b;->ppColorTextBase:I

    .line 324
    .line 325
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 326
    .line 327
    .line 328
    move-result v1

    .line 329
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 330
    .line 331
    .line 332
    goto/16 :goto_1

    .line 333
    .line 334
    :cond_3
    iget-object v0, p1, Ltc/o;->d:Landroid/widget/TextView;

    .line 335
    .line 336
    sget v1, Lcom/transsnet/palmpay/custom_view/p;->cv_text_color_white:I

    .line 337
    .line 338
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 339
    .line 340
    .line 341
    move-result v1

    .line 342
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 343
    .line 344
    .line 345
    iget-object v0, p1, Ltc/o;->e:Landroid/widget/TextView;

    .line 346
    .line 347
    sget v1, Lcom/transsnet/palmpay/custom_view/p;->cv_text_color_white:I

    .line 348
    .line 349
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 350
    .line 351
    .line 352
    move-result v1

    .line 353
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 354
    .line 355
    .line 356
    iget-object v0, p1, Ltc/o;->f:Landroid/widget/TextView;

    .line 357
    .line 358
    sget v1, Lpc/b;->jp_history_succ:I

    .line 359
    .line 360
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 361
    .line 362
    .line 363
    move-result v1

    .line 364
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 365
    .line 366
    .line 367
    iget-object v0, p1, Ltc/o;->f:Landroid/widget/TextView;

    .line 368
    .line 369
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 370
    .line 371
    .line 372
    goto :goto_1

    .line 373
    :cond_4
    :goto_0
    iget-object v0, p1, Ltc/o;->d:Landroid/widget/TextView;

    .line 374
    .line 375
    sget v1, LL6/b;->ppColorWarning:I

    .line 376
    .line 377
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 378
    .line 379
    .line 380
    move-result v1

    .line 381
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 382
    .line 383
    .line 384
    iget-object v0, p1, Ltc/o;->e:Landroid/widget/TextView;

    .line 385
    .line 386
    sget v1, Lpc/b;->jp_history_processing:I

    .line 387
    .line 388
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 389
    .line 390
    .line 391
    move-result v1

    .line 392
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 393
    .line 394
    .line 395
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 396
    .line 397
    sget v1, LL6/b;->ppColorWarning:I

    .line 398
    .line 399
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 400
    .line 401
    .line 402
    move-result v1

    .line 403
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 404
    .line 405
    .line 406
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 407
    .line 408
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 409
    .line 410
    .line 411
    iget-object v0, p1, Ltc/o;->g:Landroid/widget/TextView;

    .line 412
    .line 413
    sget v1, Lba/k;->core_processing:I

    .line 414
    .line 415
    invoke-virtual {v3, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 416
    .line 417
    .line 418
    move-result-object v1

    .line 419
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 420
    .line 421
    .line 422
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 423
    .line 424
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 425
    .line 426
    .line 427
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 428
    .line 429
    sget v1, Lpc/c;->jp_resolve_btn_r6_bg:I

    .line 430
    .line 431
    invoke-virtual {v3, v1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 432
    .line 433
    .line 434
    move-result-object v1

    .line 435
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 436
    .line 437
    .line 438
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 439
    .line 440
    sget v1, Lpc/f;->jp_resolve:I

    .line 441
    .line 442
    invoke-virtual {v3, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 443
    .line 444
    .line 445
    move-result-object v1

    .line 446
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 447
    .line 448
    .line 449
    iget-object v0, p1, Ltc/o;->i:Landroid/widget/TextView;

    .line 450
    .line 451
    sget v1, LL6/b;->ppColorTextPrimary:I

    .line 452
    .line 453
    invoke-virtual {v3, v1}, Landroid/content/Context;->getColor(I)I

    .line 454
    .line 455
    .line 456
    move-result v1

    .line 457
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 458
    .line 459
    .line 460
    :goto_1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 461
    .line 462
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 463
    .line 464
    .line 465
    move-result-object p2

    .line 466
    check-cast p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;

    .line 467
    .line 468
    iget-object v0, p1, Ltc/o;->d:Landroid/widget/TextView;

    .line 469
    .line 470
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 471
    .line 472
    .line 473
    move-result-object v1

    .line 474
    sget v2, Lpc/f;->jp_refer_earn_s:I

    .line 475
    .line 476
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrencySymbol()Ljava/lang/String;

    .line 477
    .line 478
    .line 479
    move-result-object v3

    .line 480
    iget-wide v4, p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->amount:J

    .line 481
    .line 482
    invoke-static {v4, v5}, LPa/r0;->n0(J)Ljava/lang/String;

    .line 483
    .line 484
    .line 485
    move-result-object v4

    .line 486
    invoke-static {v3, v4}, LN8/q0;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 487
    .line 488
    .line 489
    move-result-object v3

    .line 490
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 491
    .line 492
    .line 493
    move-result-object v3

    .line 494
    invoke-virtual {v1, v2, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 495
    .line 496
    .line 497
    move-result-object v1

    .line 498
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 499
    .line 500
    .line 501
    iget-object v0, p1, Ltc/o;->e:Landroid/widget/TextView;

    .line 502
    .line 503
    iget-wide v1, p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->updateTime:J

    .line 504
    .line 505
    invoke-static {v1, v2}, LPa/r0;->R(J)Ljava/lang/String;

    .line 506
    .line 507
    .line 508
    move-result-object v1

    .line 509
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 510
    .line 511
    .line 512
    iget-object p1, p1, Ltc/o;->f:Landroid/widget/TextView;

    .line 513
    .line 514
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrencySymbol()Ljava/lang/String;

    .line 515
    .line 516
    .line 517
    move-result-object v0

    .line 518
    iget-wide v1, p2, Lcom/transsnet/palmpay/jara_packet/bean/resp/ReferEarnWithDraw;->amount:J

    .line 519
    .line 520
    invoke-static {v1, v2}, LPa/r0;->n0(J)Ljava/lang/String;

    .line 521
    .line 522
    .line 523
    move-result-object p2

    .line 524
    const-string v1, "+ "

    .line 525
    .line 526
    invoke-static {v1, v0, p2, p1}, LC0/G;->y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/widget/TextView;)V

    .line 527
    .line 528
    .line 529
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    .line 1
    const-string p2, "parent"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p2, Ltc/o;

    .line 7
    .line 8
    iget-object v0, p0, LKb/c;->a:Landroid/content/Context;

    .line 9
    .line 10
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget v1, Lpc/e;->jp_item_cs_history:I

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    const-string v0, "inflate(...)"

    .line 22
    .line 23
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p2, p0, p1}, Ltc/o;-><init>(Ltc/p;Landroid/view/View;)V

    .line 27
    .line 28
    .line 29
    return-object p2
.end method
