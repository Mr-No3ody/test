.class public abstract Lih/b;
.super Landroid/os/Binder;
.source "SourceFile"

# interfaces
.implements Lq999ggg99999qqggqqg9qg/qg9gqgqqggg9q9qg/q999ggg99999qqggqqg9qg/q999ggg99999qqggqqg9qg/q999ggg99999qqggqqg9qg;


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v0, "4a252b6a72332224337468363c2223283a36232f62662124216b48163c2203083a36232f0504282233342626253e081f3e2d36232f"

    .line 2
    .line 3
    const/16 v1, 0x24

    .line 4
    .line 5
    invoke-static {v0, v1}, Lih/b;->a(Ljava/lang/String;I)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public static a(Ljava/lang/String;I)Ljava/lang/String;
    .locals 7

    .line 1
    const-string v0, "0123456789abcdef"

    .line 2
    .line 3
    :try_start_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    div-int/lit8 v1, v1, 0x2

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    new-array v2, v1, [B

    .line 14
    .line 15
    const/4 v3, 0x0

    .line 16
    move v4, v3

    .line 17
    :goto_0
    if-ge v4, v1, :cond_0

    .line 18
    .line 19
    shl-int/lit8 v5, v4, 0x1

    .line 20
    .line 21
    aget-char v6, p0, v5

    .line 22
    .line 23
    invoke-virtual {v0, v6}, Ljava/lang/String;->indexOf(I)I

    .line 24
    .line 25
    .line 26
    move-result v6

    .line 27
    shl-int/lit8 v6, v6, 0x4

    .line 28
    .line 29
    add-int/lit8 v5, v5, 0x1

    .line 30
    .line 31
    aget-char v5, p0, v5

    .line 32
    .line 33
    invoke-virtual {v0, v5}, Ljava/lang/String;->indexOf(I)I

    .line 34
    .line 35
    .line 36
    move-result v5

    .line 37
    or-int/2addr v5, v6

    .line 38
    int-to-byte v5, v5

    .line 39
    aput-byte v5, v2, v4

    .line 40
    .line 41
    add-int/lit8 v4, v4, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_0
    xor-int/lit8 p0, p1, 0xd

    .line 45
    .line 46
    int-to-byte p0, p0

    .line 47
    aget-byte p1, v2, v3

    .line 48
    .line 49
    xor-int/lit8 p1, p1, 0x29

    .line 50
    .line 51
    int-to-byte p1, p1

    .line 52
    aput-byte p1, v2, v3

    .line 53
    .line 54
    const/4 v0, 0x1

    .line 55
    :goto_1
    if-ge v0, v1, :cond_1

    .line 56
    .line 57
    aget-byte v3, v2, v0

    .line 58
    .line 59
    xor-int/2addr p1, v3

    .line 60
    xor-int/2addr p1, p0

    .line 61
    int-to-byte p1, p1

    .line 62
    aput-byte p1, v2, v0

    .line 63
    .line 64
    add-int/lit8 v0, v0, 0x1

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :cond_1
    new-instance p0, Ljava/lang/String;

    .line 68
    .line 69
    const-string p1, "UTF-8"

    .line 70
    .line 71
    invoke-direct {p0, v2, p1}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 72
    .line 73
    .line 74
    return-object p0

    .line 75
    :catch_0
    move-exception p0

    .line 76
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 77
    .line 78
    .line 79
    const-string p0, ""

    .line 80
    .line 81
    return-object p0
.end method
