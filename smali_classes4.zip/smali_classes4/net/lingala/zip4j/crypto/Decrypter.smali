.class public interface abstract Lnet/lingala/zip4j/crypto/Decrypter;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract decryptData([BII)I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            LKf/d;
        }
    .end annotation
.end method
