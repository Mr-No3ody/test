.class public final LLc/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/viewbinding/ViewBinding;


# instance fields
.field public final A:Landroidx/constraintlayout/widget/Group;

.field public final B:Landroid/widget/TextView;

.field public final C:Landroid/widget/TextView;

.field public final H:Landroid/widget/TextView;

.field public final L:Landroid/widget/TextView;

.field public final M:Landroid/widget/TextView;

.field public final Q:Landroid/widget/TextView;

.field public final X:Landroid/widget/TextView;

.field public final Y:Landroid/widget/TextView;

.field public final Z:Landroid/widget/TextView;

.field public final a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final b:Lcom/transsnet/adsdk/widgets/SingleAdView;

.field public final c:Landroid/view/View;

.field public final d:Landroid/widget/LinearLayout;

.field public final e:LBc/k;

.field public final f:Lcom/transsnet/palmpay/custom_view/AmountEditText;

.field public final g:Landroidx/appcompat/widget/AppCompatEditText;

.field public final i:Landroid/view/View;

.field public final j:Landroid/widget/ImageView;

.field public final k0:Landroid/widget/TextView;

.field public final o:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final p:Landroid/widget/LinearLayout;

.field public final p0:Landroid/widget/TextView;

.field public final q0:Landroid/widget/TextView;

.field public final r0:Landroid/widget/TextView;

.field public final s0:Landroid/widget/TextView;

.field public final t:Lcom/transsnet/palmpay/custom_view/RoundedTextView;

.field public final t0:Landroid/widget/TextView;

.field public final v:Lcom/transsnet/palmpay/custom_view/RoundedTextView;

.field public final w:Landroidx/appcompat/widget/AppCompatImageView;


# direct methods
.method public constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;Lcom/transsnet/adsdk/widgets/SingleAdView;Landroid/view/View;Landroid/widget/LinearLayout;LBc/k;Lcom/transsnet/palmpay/custom_view/AmountEditText;Landroidx/appcompat/widget/AppCompatEditText;Landroid/view/View;Landroid/widget/ImageView;Landroidx/constraintlayout/widget/ConstraintLayout;Landroid/widget/LinearLayout;Lcom/transsnet/palmpay/custom_view/RoundedTextView;Lcom/transsnet/palmpay/custom_view/RoundedTextView;Landroidx/appcompat/widget/AppCompatImageView;Landroidx/constraintlayout/widget/Group;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLc/a;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 5
    .line 6
    iput-object p2, p0, LLc/a;->b:Lcom/transsnet/adsdk/widgets/SingleAdView;

    .line 7
    .line 8
    iput-object p3, p0, LLc/a;->c:Landroid/view/View;

    .line 9
    .line 10
    iput-object p4, p0, LLc/a;->d:Landroid/widget/LinearLayout;

    .line 11
    .line 12
    iput-object p5, p0, LLc/a;->e:LBc/k;

    .line 13
    .line 14
    iput-object p6, p0, LLc/a;->f:Lcom/transsnet/palmpay/custom_view/AmountEditText;

    .line 15
    .line 16
    iput-object p7, p0, LLc/a;->g:Landroidx/appcompat/widget/AppCompatEditText;

    .line 17
    .line 18
    iput-object p8, p0, LLc/a;->i:Landroid/view/View;

    .line 19
    .line 20
    iput-object p9, p0, LLc/a;->j:Landroid/widget/ImageView;

    .line 21
    .line 22
    iput-object p10, p0, LLc/a;->o:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 23
    .line 24
    iput-object p11, p0, LLc/a;->p:Landroid/widget/LinearLayout;

    .line 25
    .line 26
    iput-object p12, p0, LLc/a;->t:Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 27
    .line 28
    iput-object p13, p0, LLc/a;->v:Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 29
    .line 30
    iput-object p14, p0, LLc/a;->w:Landroidx/appcompat/widget/AppCompatImageView;

    .line 31
    .line 32
    iput-object p15, p0, LLc/a;->A:Landroidx/constraintlayout/widget/Group;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, LLc/a;->B:Landroid/widget/TextView;

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, LLc/a;->C:Landroid/widget/TextView;

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, LLc/a;->H:Landroid/widget/TextView;

    .line 45
    .line 46
    move-object/from16 p1, p19

    .line 47
    .line 48
    iput-object p1, p0, LLc/a;->L:Landroid/widget/TextView;

    .line 49
    .line 50
    move-object/from16 p1, p20

    .line 51
    .line 52
    iput-object p1, p0, LLc/a;->M:Landroid/widget/TextView;

    .line 53
    .line 54
    move-object/from16 p1, p21

    .line 55
    .line 56
    iput-object p1, p0, LLc/a;->Q:Landroid/widget/TextView;

    .line 57
    .line 58
    move-object/from16 p1, p22

    .line 59
    .line 60
    iput-object p1, p0, LLc/a;->X:Landroid/widget/TextView;

    .line 61
    .line 62
    move-object/from16 p1, p23

    .line 63
    .line 64
    iput-object p1, p0, LLc/a;->Y:Landroid/widget/TextView;

    .line 65
    .line 66
    move-object/from16 p1, p24

    .line 67
    .line 68
    iput-object p1, p0, LLc/a;->Z:Landroid/widget/TextView;

    .line 69
    .line 70
    move-object/from16 p1, p25

    .line 71
    .line 72
    iput-object p1, p0, LLc/a;->k0:Landroid/widget/TextView;

    .line 73
    .line 74
    move-object/from16 p1, p26

    .line 75
    .line 76
    iput-object p1, p0, LLc/a;->p0:Landroid/widget/TextView;

    .line 77
    .line 78
    move-object/from16 p1, p27

    .line 79
    .line 80
    iput-object p1, p0, LLc/a;->q0:Landroid/widget/TextView;

    .line 81
    .line 82
    move-object/from16 p1, p28

    .line 83
    .line 84
    iput-object p1, p0, LLc/a;->r0:Landroid/widget/TextView;

    .line 85
    .line 86
    move-object/from16 p1, p29

    .line 87
    .line 88
    iput-object p1, p0, LLc/a;->s0:Landroid/widget/TextView;

    .line 89
    .line 90
    move-object/from16 p1, p30

    .line 91
    .line 92
    iput-object p1, p0, LLc/a;->t0:Landroid/widget/TextView;

    .line 93
    .line 94
    return-void
.end method


# virtual methods
.method public final getRoot()Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, LLc/a;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 2
    .line 3
    return-object v0
.end method
