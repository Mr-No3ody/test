.class public final LFb/i;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 0

    .line 1
    return-void
.end method

.method public static a(Landroid/view/View;Ljava/lang/String;)V
    .locals 3

    .line 1
    if-nez p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    const-string v0, ""

    .line 5
    .line 6
    if-eqz p1, :cond_1

    .line 7
    .line 8
    invoke-static {p1}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    const-string v2, " "

    .line 19
    .line 20
    invoke-static {v1, v2, v0}, Lkotlin/text/y;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    goto :goto_0

    .line 25
    :cond_1
    const/4 v1, 0x0

    .line 26
    :goto_0
    if-nez v1, :cond_2

    .line 27
    .line 28
    goto :goto_1

    .line 29
    :cond_2
    move-object v0, v1

    .line 30
    :goto_1
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-lez v0, :cond_3

    .line 35
    .line 36
    const/4 v0, 0x1

    .line 37
    goto :goto_2

    .line 38
    :cond_3
    const/4 v0, 0x0

    .line 39
    :goto_2
    invoke-virtual {p0, v0}, Landroid/view/View;->setEnabled(Z)V

    .line 40
    .line 41
    .line 42
    if-eqz v0, :cond_4

    .line 43
    .line 44
    const/high16 v1, 0x3f800000    # 1.0f

    .line 45
    .line 46
    goto :goto_3

    .line 47
    :cond_4
    const v1, 0x3ecccccd    # 0.4f

    .line 48
    .line 49
    .line 50
    :goto_3
    invoke-virtual {p0, v1}, Landroid/view/View;->setAlpha(F)V

    .line 51
    .line 52
    .line 53
    new-instance v1, LFb/k;

    .line 54
    .line 55
    const/4 v2, 0x0

    .line 56
    invoke-direct {v1, p0, v2, p1, v0}, LFb/k;-><init>(Ljava/lang/Object;ILjava/lang/Object;Z)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 60
    .line 61
    .line 62
    return-void
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    .line 1
    const-string v0, ""

    .line 2
    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    invoke-static {p0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    if-eqz p0, :cond_0

    .line 14
    .line 15
    const-string v1, " "

    .line 16
    .line 17
    invoke-static {p0, v1, v0}, Lkotlin/text/y;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 p0, 0x0

    .line 23
    :goto_0
    if-nez p0, :cond_1

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_1
    move-object v0, p0

    .line 27
    :goto_1
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 28
    .line 29
    .line 30
    move-result p0

    .line 31
    if-nez p0, :cond_2

    .line 32
    .line 33
    const-string p0, "-"

    .line 34
    .line 35
    return-object p0

    .line 36
    :cond_2
    new-instance p0, Ljava/lang/StringBuilder;

    .line 37
    .line 38
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 39
    .line 40
    .line 41
    const/4 v1, 0x0

    .line 42
    move v2, v1

    .line 43
    :goto_2
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 44
    .line 45
    .line 46
    move-result v3

    .line 47
    if-ge v1, v3, :cond_5

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    add-int/lit8 v4, v2, 0x1

    .line 54
    .line 55
    if-lez v2, :cond_4

    .line 56
    .line 57
    const/4 v5, 0x4

    .line 58
    if-eq v2, v5, :cond_3

    .line 59
    .line 60
    const/4 v5, 0x7

    .line 61
    if-ne v2, v5, :cond_4

    .line 62
    .line 63
    :cond_3
    const/16 v2, 0x20

    .line 64
    .line 65
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    :cond_4
    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    add-int/lit8 v1, v1, 0x1

    .line 72
    .line 73
    move v2, v4

    .line 74
    goto :goto_2

    .line 75
    :cond_5
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    return-object p0
.end method

.method public static c(Ljava/util/List;Ljava/util/Set;)Ljava/lang/String;
    .locals 7

    .line 1
    const-string v0, "targetReasonCodes"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "separator"

    .line 7
    .line 8
    const-string v2, "\n"

    .line 9
    .line 10
    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    move-object v0, p0

    .line 14
    check-cast v0, Ljava/util/Collection;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_0
    check-cast p0, Ljava/lang/Iterable;

    .line 27
    .line 28
    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->y(Ljava/lang/Iterable;)LKf/q;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    new-instance v0, LFb/h;

    .line 33
    .line 34
    const/4 v3, 0x0

    .line 35
    invoke-direct {v0, p1, v3}, LFb/h;-><init>(Ljava/util/Set;I)V

    .line 36
    .line 37
    .line 38
    invoke-static {p0, v0}, LSf/p;->c(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)LSf/g;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    new-instance p1, LAb/B;

    .line 43
    .line 44
    const/16 v0, 0xd

    .line 45
    .line 46
    invoke-direct {p1, v0}, LAb/B;-><init>(I)V

    .line 47
    .line 48
    .line 49
    invoke-static {p0, p1}, LSf/p;->g(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)LSf/g;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    new-instance p1, LAb/B;

    .line 54
    .line 55
    const/16 v0, 0xe

    .line 56
    .line 57
    invoke-direct {p1, v0}, LAb/B;-><init>(I)V

    .line 58
    .line 59
    .line 60
    invoke-static {p0, p1}, LSf/p;->c(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)LSf/g;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    invoke-static {p0}, LSf/p;->i(Lkotlin/sequences/Sequence;)Ljava/util/List;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    move-object p1, p0

    .line 69
    check-cast p1, Ljava/util/Collection;

    .line 70
    .line 71
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 72
    .line 73
    .line 74
    move-result p1

    .line 75
    if-nez p1, :cond_1

    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_1
    move-object p0, v1

    .line 79
    :goto_0
    if-eqz p0, :cond_2

    .line 80
    .line 81
    move-object v1, p0

    .line 82
    check-cast v1, Ljava/lang/Iterable;

    .line 83
    .line 84
    const/4 v4, 0x0

    .line 85
    const/16 v6, 0x3e

    .line 86
    .line 87
    const/4 v3, 0x0

    .line 88
    const/4 v5, 0x0

    .line 89
    invoke-static/range {v1 .. v6}, Lkotlin/collections/CollectionsKt;->J(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;I)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    return-object p0

    .line 94
    :cond_2
    :goto_1
    return-object v1
.end method

.method public static d(Ljava/util/List;)I
    .locals 4

    .line 1
    move-object v0, p0

    .line 2
    check-cast v0, Ljava/util/Collection;

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_2

    .line 14
    :cond_0
    move-object v0, p0

    .line 15
    check-cast v0, Ljava/lang/Iterable;

    .line 16
    .line 17
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v2, 0x0

    .line 22
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    if-eqz v3, :cond_2

    .line 27
    .line 28
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;

    .line 33
    .line 34
    iget-object v3, v3, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->outstandingBillCount:Ljava/lang/Integer;

    .line 35
    .line 36
    if-eqz v3, :cond_1

    .line 37
    .line 38
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    goto :goto_1

    .line 43
    :cond_1
    move v3, v1

    .line 44
    :goto_1
    add-int/2addr v2, v3

    .line 45
    goto :goto_0

    .line 46
    :cond_2
    if-lez v2, :cond_3

    .line 47
    .line 48
    return v2

    .line 49
    :cond_3
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 50
    .line 51
    .line 52
    move-result p0

    .line 53
    return p0

    .line 54
    :cond_4
    :goto_2
    return v1
.end method

.method public static e(Landroid/content/Context;Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;)V
    .locals 7

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "info"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v1, "type"

    .line 12
    .line 13
    const-string v2, "repay"

    .line 14
    .line 15
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->waiverInfo:Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 19
    .line 20
    const/4 v2, 0x1

    .line 21
    if-eqz v1, :cond_6

    .line 22
    .line 23
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getWaiverEnable()Ljava/lang/Boolean;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 28
    .line 29
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    if-nez v3, :cond_0

    .line 34
    .line 35
    goto/16 :goto_1

    .line 36
    .line 37
    :cond_0
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getValidUntil()Ljava/lang/Long;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    if-eqz v1, :cond_6

    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 44
    .line 45
    .line 46
    move-result-wide v3

    .line 47
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 48
    .line 49
    .line 50
    move-result-wide v5

    .line 51
    cmp-long v1, v3, v5

    .line 52
    .line 53
    if-lez v1, :cond_6

    .line 54
    .line 55
    sget-object v1, LEb/b;->a:Ljava/util/Set;

    .line 56
    .line 57
    new-instance v1, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 58
    .line 59
    const-string v3, "Loan_Home_Repay_Click"

    .line 60
    .line 61
    invoke-direct {v1, v3}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    invoke-virtual {v3, v1}, LPa/n0;->q(Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;)V

    .line 69
    .line 70
    .line 71
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->outstandingAccounts:Ljava/util/List;

    .line 72
    .line 73
    const/4 v3, 0x0

    .line 74
    if-eqz v1, :cond_1

    .line 75
    .line 76
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;

    .line 81
    .line 82
    if-eqz v1, :cond_1

    .line 83
    .line 84
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->androidLink:Ljava/lang/String;

    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_1
    move-object v1, v3

    .line 88
    :goto_0
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 89
    .line 90
    .line 91
    move-result v4

    .line 92
    if-nez v4, :cond_2

    .line 93
    .line 94
    invoke-static {v1, v3, v3}, LPa/F;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    :cond_2
    iget-object v1, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->jumpPath:Ljava/lang/String;

    .line 99
    .line 100
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 101
    .line 102
    .line 103
    move-result v1

    .line 104
    if-nez v1, :cond_3

    .line 105
    .line 106
    iget-object p0, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->jumpPath:Ljava/lang/String;

    .line 107
    .line 108
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->jumpType:Ljava/lang/String;

    .line 109
    .line 110
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->jumpParams:Ljava/lang/String;

    .line 111
    .line 112
    invoke-static {p0, v0, p1}, LPa/F;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    return-void

    .line 116
    :cond_3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->outstandingAccounts:Ljava/util/List;

    .line 120
    .line 121
    invoke-static {v0}, LFb/i;->d(Ljava/util/List;)I

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    if-gt v0, v2, :cond_5

    .line 126
    .line 127
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->outstandingAccounts:Ljava/util/List;

    .line 128
    .line 129
    if-eqz v0, :cond_4

    .line 130
    .line 131
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;

    .line 136
    .line 137
    if-eqz v0, :cond_4

    .line 138
    .line 139
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->accountType:Ljava/lang/Integer;

    .line 140
    .line 141
    :cond_4
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->outstandingAccounts:Ljava/util/List;

    .line 142
    .line 143
    invoke-static {p0, v3, p1}, LFb/i;->g(Landroid/content/Context;Ljava/lang/Integer;Ljava/util/List;)V

    .line 144
    .line 145
    .line 146
    return-void

    .line 147
    :cond_5
    const-string p0, "LoanRepayMix"

    .line 148
    .line 149
    invoke-static {v3, p0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    return-void

    .line 153
    :cond_6
    :goto_1
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;->outstandingAccounts:Ljava/util/List;

    .line 154
    .line 155
    invoke-static {p0, p1, v2}, Lorg/chromium/support_lib_boundary/util/b;->A(Landroid/content/Context;Ljava/util/List;Z)V

    .line 156
    .line 157
    .line 158
    return-void
.end method

.method public static f(Landroid/content/Context;Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;)Z
    .locals 18

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    const-string v2, "account"

    .line 6
    .line 7
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v3, "detail"

    .line 11
    .line 12
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getWaiverInfo()Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    if-nez v2, :cond_0

    .line 26
    .line 27
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getWaiverInfo()Lcom/transsnet/palmpay/credit/bean/WaiverInfo;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    :cond_0
    if-eqz v2, :cond_7

    .line 32
    .line 33
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getWaiverEnable()Ljava/lang/Boolean;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 38
    .line 39
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    if-nez v3, :cond_1

    .line 44
    .line 45
    goto/16 :goto_1

    .line 46
    .line 47
    :cond_1
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/WaiverInfo;->getValidUntil()Ljava/lang/Long;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    if-eqz v2, :cond_7

    .line 52
    .line 53
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 54
    .line 55
    .line 56
    move-result-wide v2

    .line 57
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 58
    .line 59
    .line 60
    move-result-wide v4

    .line 61
    cmp-long v2, v2, v4

    .line 62
    .line 63
    if-lez v2, :cond_7

    .line 64
    .line 65
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getAndroidLink()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    const/4 v3, 0x1

    .line 74
    if-nez v2, :cond_2

    .line 75
    .line 76
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getAndroidLink()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    const/4 v1, 0x0

    .line 81
    invoke-static {v0, v1, v1}, LPa/F;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    return v3

    .line 85
    :cond_2
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getOutstandingBillCount()Ljava/lang/Integer;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    if-eqz v2, :cond_3

    .line 90
    .line 91
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    goto :goto_0

    .line 96
    :cond_3
    move v2, v3

    .line 97
    :goto_0
    if-gt v2, v3, :cond_6

    .line 98
    .line 99
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getAccountType()Ljava/lang/Integer;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    new-instance v4, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;

    .line 104
    .line 105
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getAccountType()Ljava/lang/Integer;

    .line 106
    .line 107
    .line 108
    move-result-object v5

    .line 109
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getBillId()Ljava/lang/Long;

    .line 110
    .line 111
    .line 112
    move-result-object v6

    .line 113
    if-nez v6, :cond_4

    .line 114
    .line 115
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getOutstandingBillId()Ljava/lang/Long;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    :cond_4
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getCurrentOutstandingAmount()Ljava/lang/Long;

    .line 120
    .line 121
    .line 122
    move-result-object v7

    .line 123
    if-nez v7, :cond_5

    .line 124
    .line 125
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getTotalOutstandingAmount()Ljava/lang/Long;

    .line 126
    .line 127
    .line 128
    move-result-object v7

    .line 129
    :cond_5
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getRepaymentDateStamp()Ljava/lang/Long;

    .line 130
    .line 131
    .line 132
    move-result-object v8

    .line 133
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getOutstandingBillCount()Ljava/lang/Integer;

    .line 134
    .line 135
    .line 136
    move-result-object v9

    .line 137
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getCardNo()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v10

    .line 141
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getLoanProduct()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v12

    .line 145
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getProductTitle()Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v13

    .line 149
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getUnpaidPenalty()Ljava/lang/Long;

    .line 150
    .line 151
    .line 152
    move-result-object v14

    .line 153
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getLoanNo()Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object v16

    .line 157
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getAndroidLink()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v17

    .line 161
    const/4 v11, 0x0

    .line 162
    const/4 v15, 0x0

    .line 163
    invoke-direct/range {v4 .. v17}, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;-><init>(Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    invoke-static {v4}, Lkotlin/collections/p;->c(Ljava/lang/Object;)Ljava/util/List;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    move-object/from16 v1, p0

    .line 171
    .line 172
    invoke-static {v1, v2, v0}, LFb/i;->g(Landroid/content/Context;Ljava/lang/Integer;Ljava/util/List;)V

    .line 173
    .line 174
    .line 175
    return v3

    .line 176
    :cond_6
    move-object/from16 v1, p0

    .line 177
    .line 178
    invoke-static {v1}, LFb/i;->h(Landroid/content/Context;)V

    .line 179
    .line 180
    .line 181
    return v3

    .line 182
    :cond_7
    :goto_1
    const/4 v0, 0x0

    .line 183
    return v0
.end method

.method public static g(Landroid/content/Context;Ljava/lang/Integer;Ljava/util/List;)V
    .locals 1

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    goto :goto_0

    .line 4
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    const/4 v0, 0x6

    .line 9
    if-ne p1, v0, :cond_1

    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    const-string p1, "LoanFlexi"

    .line 13
    .line 14
    invoke-static {p0, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_1
    :goto_0
    const/4 p1, 0x0

    .line 19
    invoke-static {p0, p2, p1}, Lorg/chromium/support_lib_boundary/util/b;->A(Landroid/content/Context;Ljava/util/List;Z)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public static h(Landroid/content/Context;)V
    .locals 3

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    instance-of v0, p0, Landroidx/fragment/app/E;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    move-object v0, p0

    .line 12
    check-cast v0, Landroidx/fragment/app/E;

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    instance-of v2, v0, Landroidx/fragment/app/E;

    .line 20
    .line 21
    if-eqz v2, :cond_1

    .line 22
    .line 23
    check-cast v0, Landroidx/fragment/app/E;

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_1
    move-object v0, v1

    .line 27
    :goto_0
    if-eqz v0, :cond_2

    .line 28
    .line 29
    invoke-virtual {v0}, Landroidx/fragment/app/E;->getSupportFragmentManager()Landroidx/fragment/app/Z;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-eqz v0, :cond_2

    .line 34
    .line 35
    sget v2, LYa/e;->fragmentContainer:I

    .line 36
    .line 37
    invoke-virtual {v0, v2}, Landroidx/fragment/app/Z;->D(I)Landroidx/fragment/app/Fragment;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    goto :goto_1

    .line 42
    :cond_2
    move-object v0, v1

    .line 43
    :goto_1
    instance-of v2, v0, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;

    .line 44
    .line 45
    if-eqz v2, :cond_3

    .line 46
    .line 47
    move-object v1, v0

    .line 48
    check-cast v1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;

    .line 49
    .line 50
    :cond_3
    if-eqz v1, :cond_5

    .line 51
    .line 52
    iget-object p0, v1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanHomeFragment;->M:Lxf/t;

    .line 53
    .line 54
    invoke-virtual {p0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    check-cast p0, Landroidx/viewpager2/widget/ViewPager2;

    .line 59
    .line 60
    if-eqz p0, :cond_4

    .line 61
    .line 62
    const/4 v0, 0x0

    .line 63
    const/4 v1, 0x1

    .line 64
    invoke-virtual {p0, v1, v0}, Landroidx/viewpager2/widget/ViewPager2;->setCurrentItem(IZ)V

    .line 65
    .line 66
    .line 67
    :cond_4
    return-void

    .line 68
    :cond_5
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    const-string v1, "/credit_score/loan_home_activity"

    .line 73
    .line 74
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    const-string v1, "tab"

    .line 79
    .line 80
    const-string v2, "repayment"

    .line 81
    .line 82
    invoke-virtual {v0, v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    const/high16 v1, 0x20000000

    .line 87
    .line 88
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withFlags(I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-virtual {v0, p0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    return-void
.end method
