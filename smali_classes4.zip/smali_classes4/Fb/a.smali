.class public final LFb/a;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 1

    .line 1
    new-instance p1, LFb/a;

    .line 2
    .line 3
    const/4 v0, 0x2

    .line 4
    invoke-direct {p1, v0, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LFb/a;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LFb/a;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LFb/a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LFb/a;->a:I

    .line 4
    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v1, :cond_1

    .line 8
    .line 9
    if-ne v1, v3, :cond_0

    .line 10
    .line 11
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    .line 12
    .line 13
    .line 14
    goto/16 :goto_5

    .line 15
    .line 16
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 19
    .line 20
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    throw p1

    .line 24
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    new-instance p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;

    .line 28
    .line 29
    invoke-direct {p1}, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;-><init>()V

    .line 30
    .line 31
    .line 32
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getCpuModel()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->cpu_architecture:Ljava/lang/String;

    .line 37
    .line 38
    :try_start_1
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getMaxCpuFreq()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    int-to-long v4, v1

    .line 47
    iput-wide v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->cpu_max_freq:J

    .line 48
    .line 49
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getMinCpuFreq()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    int-to-long v4, v1

    .line 58
    iput-wide v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->cpu_min_freq:J
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 59
    .line 60
    :catch_0
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getCpuSerial()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->cpu_serial:Ljava/lang/String;

    .line 65
    .line 66
    invoke-static {}, Lcom/transsnet/palmpay/util/SDCardUtils;->getSDTotalSize()J

    .line 67
    .line 68
    .line 69
    move-result-wide v4

    .line 70
    iput-wide v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->disk_total_space:J

    .line 71
    .line 72
    invoke-static {}, Lcom/transsnet/palmpay/util/SDCardUtils;->getSDFreeSize()J

    .line 73
    .line 74
    .line 75
    move-result-wide v4

    .line 76
    iput-wide v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->disk_free_space:J

    .line 77
    .line 78
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    const-string v4, "activity"

    .line 83
    .line 84
    invoke-virtual {v1, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    check-cast v1, Landroid/app/ActivityManager;

    .line 89
    .line 90
    if-eqz v1, :cond_2

    .line 91
    .line 92
    new-instance v4, Landroid/app/ActivityManager$MemoryInfo;

    .line 93
    .line 94
    invoke-direct {v4}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v1, v4}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    .line 98
    .line 99
    .line 100
    iget-wide v4, v4, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    .line 101
    .line 102
    const/16 v1, 0x400

    .line 103
    .line 104
    int-to-long v6, v1

    .line 105
    div-long/2addr v4, v6

    .line 106
    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->memory_total:Ljava/lang/String;

    .line 111
    .line 112
    :cond_2
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getVmHeepSize()I

    .line 113
    .line 114
    .line 115
    move-result v1

    .line 116
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->heap_size:Ljava/lang/String;

    .line 121
    .line 122
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimState()I

    .line 123
    .line 124
    .line 125
    move-result v1

    .line 126
    iput v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->sim_state:I

    .line 127
    .line 128
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getIMSI()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->imsi:Ljava/lang/String;

    .line 133
    .line 134
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimSerialNumber()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->sim_serial:Ljava/lang/String;

    .line 139
    .line 140
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimMSISDN()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->phone_number:Ljava/lang/String;

    .line 145
    .line 146
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getPhoneType()I

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    iput v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->phone_type:I

    .line 151
    .line 152
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimOperator()Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v1

    .line 156
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->carrier_mobile_country_code:Ljava/lang/String;

    .line 157
    .line 158
    :try_start_2
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getLac()Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v1

    .line 162
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 163
    .line 164
    .line 165
    move-result v1

    .line 166
    iput v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->sim_lac:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 167
    .line 168
    :catch_1
    :try_start_3
    invoke-static {}, Lr5/a;->m()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v1

    .line 172
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 173
    .line 174
    .line 175
    move-result v1

    .line 176
    iput v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->sim_cid:I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 177
    .line 178
    :catch_2
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getCellSignalStrength()I

    .line 179
    .line 180
    .line 181
    move-result v1

    .line 182
    iput v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->sim_strength:I

    .line 183
    .line 184
    invoke-static {}, Landroid/os/Build;->getRadioVersion()Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v1

    .line 188
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->incremental:Ljava/lang/String;

    .line 189
    .line 190
    invoke-static {}, Landroid/os/Build;->getRadioVersion()Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v1

    .line 194
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->radio_version:Ljava/lang/String;

    .line 195
    .line 196
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    invoke-virtual {v1}, Ljava/util/TimeZone;->getDisplayName()Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->sim_timezone:Ljava/lang/String;

    .line 205
    .line 206
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->getNetworkType()Lcom/transsnet/palmpay/util/NetworkUtils$NetworkType;

    .line 207
    .line 208
    .line 209
    move-result-object v1

    .line 210
    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v1

    .line 214
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->internet_type:Ljava/lang/String;

    .line 215
    .line 216
    sget-object v1, LFb/d;->a:LFb/c;

    .line 217
    .line 218
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getPhoneType()I

    .line 219
    .line 220
    .line 221
    move-result v4

    .line 222
    const/4 v5, 0x0

    .line 223
    if-nez v4, :cond_3

    .line 224
    .line 225
    move v4, v3

    .line 226
    goto :goto_0

    .line 227
    :cond_3
    move v4, v5

    .line 228
    :goto_0
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 229
    .line 230
    .line 231
    move-result-object v4

    .line 232
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 233
    .line 234
    .line 235
    move-result-object v4

    .line 236
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_cellular:Ljava/lang/String;

    .line 237
    .line 238
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getPhoneType()I

    .line 239
    .line 240
    .line 241
    move-result v4

    .line 242
    if-nez v4, :cond_4

    .line 243
    .line 244
    move v5, v3

    .line 245
    :cond_4
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 246
    .line 247
    .line 248
    move-result-object v4

    .line 249
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 250
    .line 251
    .line 252
    move-result-object v4

    .line 253
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_telephony:Ljava/lang/String;

    .line 254
    .line 255
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 256
    .line 257
    .line 258
    move-result-object v4

    .line 259
    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 260
    .line 261
    .line 262
    move-result-object v4

    .line 263
    const-string v5, "android.hardware.wifi"

    .line 264
    .line 265
    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 266
    .line 267
    .line 268
    move-result v5

    .line 269
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 270
    .line 271
    .line 272
    move-result-object v5

    .line 273
    invoke-static {v1, v5}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 274
    .line 275
    .line 276
    move-result-object v5

    .line 277
    iput-object v5, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_wifi:Ljava/lang/String;

    .line 278
    .line 279
    const-string v5, "android.hardware.location.gps"

    .line 280
    .line 281
    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 282
    .line 283
    .line 284
    move-result v5

    .line 285
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 286
    .line 287
    .line 288
    move-result-object v5

    .line 289
    invoke-static {v1, v5}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v5

    .line 293
    iput-object v5, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_gps:Ljava/lang/String;

    .line 294
    .line 295
    const-string v5, "android.hardware.nfc"

    .line 296
    .line 297
    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 298
    .line 299
    .line 300
    move-result v5

    .line 301
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 302
    .line 303
    .line 304
    move-result-object v5

    .line 305
    invoke-static {v1, v5}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v5

    .line 309
    iput-object v5, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_nfc:Ljava/lang/String;

    .line 310
    .line 311
    const-string v5, "android.hardware.nfc.hce"

    .line 312
    .line 313
    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 314
    .line 315
    .line 316
    move-result v5

    .line 317
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 318
    .line 319
    .line 320
    move-result-object v5

    .line 321
    invoke-static {v1, v5}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object v5

    .line 325
    iput-object v5, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_nfc_host:Ljava/lang/String;

    .line 326
    .line 327
    const-string v5, "android.hardware.bluetooth"

    .line 328
    .line 329
    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 330
    .line 331
    .line 332
    move-result v5

    .line 333
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 334
    .line 335
    .line 336
    move-result-object v5

    .line 337
    invoke-static {v1, v5}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 338
    .line 339
    .line 340
    move-result-object v5

    .line 341
    iput-object v5, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_bluetooth:Ljava/lang/String;

    .line 342
    .line 343
    const-string v5, "android.hardware.wifi.direct"

    .line 344
    .line 345
    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 346
    .line 347
    .line 348
    move-result v5

    .line 349
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 350
    .line 351
    .line 352
    move-result-object v5

    .line 353
    invoke-static {v1, v5}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 354
    .line 355
    .line 356
    move-result-object v5

    .line 357
    iput-object v5, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_wi_fi_direct:Ljava/lang/String;

    .line 358
    .line 359
    const-string v5, "android.hardware.usb.host"

    .line 360
    .line 361
    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 362
    .line 363
    .line 364
    move-result v5

    .line 365
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 366
    .line 367
    .line 368
    move-result-object v5

    .line 369
    invoke-static {v1, v5}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 370
    .line 371
    .line 372
    move-result-object v5

    .line 373
    iput-object v5, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_otg:Ljava/lang/String;

    .line 374
    .line 375
    const-string v5, "android.hardware.usb.accessory"

    .line 376
    .line 377
    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 378
    .line 379
    .line 380
    move-result v4

    .line 381
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 382
    .line 383
    .line 384
    move-result-object v4

    .line 385
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 386
    .line 387
    .line 388
    move-result-object v4

    .line 389
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->has_aoa:Ljava/lang/String;

    .line 390
    .line 391
    new-instance v4, Landroid/content/IntentFilter;

    .line 392
    .line 393
    const-string v5, "android.intent.action.BATTERY_CHANGED"

    .line 394
    .line 395
    invoke-direct {v4, v5}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 396
    .line 397
    .line 398
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 399
    .line 400
    .line 401
    move-result-object v5

    .line 402
    const/4 v6, 0x0

    .line 403
    invoke-virtual {v5, v6, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 404
    .line 405
    .line 406
    move-result-object v4

    .line 407
    const/4 v5, -0x1

    .line 408
    if-eqz v4, :cond_5

    .line 409
    .line 410
    const-string v6, "status"

    .line 411
    .line 412
    invoke-virtual {v4, v6, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 413
    .line 414
    .line 415
    move-result v6

    .line 416
    goto :goto_1

    .line 417
    :cond_5
    move v6, v5

    .line 418
    :goto_1
    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 419
    .line 420
    .line 421
    move-result-object v6

    .line 422
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->battery_charge_status:Ljava/lang/String;

    .line 423
    .line 424
    if-eqz v4, :cond_6

    .line 425
    .line 426
    const-string v6, "plugged"

    .line 427
    .line 428
    invoke-virtual {v4, v6, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 429
    .line 430
    .line 431
    move-result v6

    .line 432
    goto :goto_2

    .line 433
    :cond_6
    move v6, v5

    .line 434
    :goto_2
    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 435
    .line 436
    .line 437
    move-result-object v6

    .line 438
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->battery_charge_plug:Ljava/lang/String;

    .line 439
    .line 440
    if-eqz v4, :cond_7

    .line 441
    .line 442
    const-string v6, "level"

    .line 443
    .line 444
    invoke-virtual {v4, v6, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 445
    .line 446
    .line 447
    move-result v4

    .line 448
    goto :goto_3

    .line 449
    :cond_7
    move v4, v5

    .line 450
    :goto_3
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 451
    .line 452
    .line 453
    move-result-object v4

    .line 454
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->battery_level:Ljava/lang/String;

    .line 455
    .line 456
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 457
    .line 458
    iput v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->os_version_int:I

    .line 459
    .line 460
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 461
    .line 462
    .line 463
    move-result-wide v6

    .line 464
    iput-wide v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->boot_times:J

    .line 465
    .line 466
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->isEmulator()Z

    .line 467
    .line 468
    .line 469
    move-result v4

    .line 470
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 471
    .line 472
    .line 473
    move-result-object v4

    .line 474
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 475
    .line 476
    .line 477
    move-result-object v4

    .line 478
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->is_emulator:Ljava/lang/String;

    .line 479
    .line 480
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->isDeviceRooted()Z

    .line 481
    .line 482
    .line 483
    move-result v4

    .line 484
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 485
    .line 486
    .line 487
    move-result-object v4

    .line 488
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 489
    .line 490
    .line 491
    move-result-object v4

    .line 492
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->is_root:Ljava/lang/String;

    .line 493
    .line 494
    sget-object v4, Landroid/os/Build;->USER:Ljava/lang/String;

    .line 495
    .line 496
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->user:Ljava/lang/String;

    .line 497
    .line 498
    sget-object v4, Landroid/os/Build$VERSION;->CODENAME:Ljava/lang/String;

    .line 499
    .line 500
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->code_name:Ljava/lang/String;

    .line 501
    .line 502
    :try_start_4
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 503
    .line 504
    .line 505
    move-result-object v4

    .line 506
    const-string v6, "location"

    .line 507
    .line 508
    invoke-virtual {v4, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 509
    .line 510
    .line 511
    move-result-object v4

    .line 512
    const-string v6, "null cannot be cast to non-null type android.location.LocationManager"

    .line 513
    .line 514
    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 515
    .line 516
    .line 517
    check-cast v4, Landroid/location/LocationManager;

    .line 518
    .line 519
    const-string v6, "gps"

    .line 520
    .line 521
    invoke-virtual {v4, v6}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    .line 522
    .line 523
    .line 524
    move-result v4

    .line 525
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 526
    .line 527
    .line 528
    move-result-object v4

    .line 529
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 530
    .line 531
    .line 532
    move-result-object v1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    .line 533
    goto :goto_4

    .line 534
    :catch_3
    sget-object v1, LFb/d;->a:LFb/c;

    .line 535
    .line 536
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 537
    .line 538
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 539
    .line 540
    .line 541
    move-result-object v1

    .line 542
    :goto_4
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->is_open_gps:Ljava/lang/String;

    .line 543
    .line 544
    invoke-static {}, Lcom/transsnet/palmpay/util/ScreenUtils;->getScreenBrightness()I

    .line 545
    .line 546
    .line 547
    move-result v1

    .line 548
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 549
    .line 550
    .line 551
    move-result-object v1

    .line 552
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->screen_brightness:Ljava/lang/String;

    .line 553
    .line 554
    invoke-static {}, Lcom/transsnet/palmpay/util/ScreenUtils;->getScreenManualMode()I

    .line 555
    .line 556
    .line 557
    move-result v1

    .line 558
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 559
    .line 560
    .line 561
    move-result-object v1

    .line 562
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->screen_manual_mode:Ljava/lang/String;

    .line 563
    .line 564
    sget-object v1, LFb/d;->a:LFb/c;

    .line 565
    .line 566
    invoke-static {v1}, LFb/c;->access$getTotalPhotos(LFb/c;)I

    .line 567
    .line 568
    .line 569
    move-result v4

    .line 570
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 571
    .line 572
    .line 573
    move-result-object v4

    .line 574
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->total_photos:Ljava/lang/String;

    .line 575
    .line 576
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->isInVPN()Z

    .line 577
    .line 578
    .line 579
    move-result v4

    .line 580
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 581
    .line 582
    .line 583
    move-result-object v4

    .line 584
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 585
    .line 586
    .line 587
    move-result-object v4

    .line 588
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->is_conn_vpn:Ljava/lang/String;

    .line 589
    .line 590
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getCellSignalStrength()I

    .line 591
    .line 592
    .line 593
    move-result v4

    .line 594
    iput v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->mobile_dbm:I

    .line 595
    .line 596
    invoke-static {v3}, Lcom/transsnet/palmpay/util/NetworkUtils;->getIPAddress(Z)Ljava/lang/String;

    .line 597
    .line 598
    .line 599
    move-result-object v4

    .line 600
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->eth_ip:Ljava/lang/String;

    .line 601
    .line 602
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 603
    .line 604
    .line 605
    move-result-object v4

    .line 606
    const-string v6, "sensor"

    .line 607
    .line 608
    invoke-virtual {v4, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 609
    .line 610
    .line 611
    move-result-object v4

    .line 612
    const-string v6, "null cannot be cast to non-null type android.hardware.SensorManager"

    .line 613
    .line 614
    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 615
    .line 616
    .line 617
    check-cast v4, Landroid/hardware/SensorManager;

    .line 618
    .line 619
    const/4 v6, 0x4

    .line 620
    invoke-virtual {v4, v6}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 621
    .line 622
    .line 623
    move-result-object v6

    .line 624
    const-string v7, "getSensorList(...)"

    .line 625
    .line 626
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 627
    .line 628
    .line 629
    check-cast v6, Ljava/util/Collection;

    .line 630
    .line 631
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 632
    .line 633
    .line 634
    move-result v6

    .line 635
    xor-int/2addr v6, v3

    .line 636
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 637
    .line 638
    .line 639
    move-result-object v6

    .line 640
    invoke-static {v1, v6}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 641
    .line 642
    .line 643
    move-result-object v6

    .line 644
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->gyro_scope_sensor_list:Ljava/lang/String;

    .line 645
    .line 646
    invoke-virtual {v4, v3}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 647
    .line 648
    .line 649
    move-result-object v6

    .line 650
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 651
    .line 652
    .line 653
    check-cast v6, Ljava/util/Collection;

    .line 654
    .line 655
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 656
    .line 657
    .line 658
    move-result v6

    .line 659
    xor-int/2addr v6, v3

    .line 660
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 661
    .line 662
    .line 663
    move-result-object v6

    .line 664
    invoke-static {v1, v6}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 665
    .line 666
    .line 667
    move-result-object v6

    .line 668
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->accelerometer_sensor_list:Ljava/lang/String;

    .line 669
    .line 670
    const/16 v6, 0x9

    .line 671
    .line 672
    invoke-virtual {v4, v6}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 673
    .line 674
    .line 675
    move-result-object v6

    .line 676
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 677
    .line 678
    .line 679
    check-cast v6, Ljava/util/Collection;

    .line 680
    .line 681
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 682
    .line 683
    .line 684
    move-result v6

    .line 685
    xor-int/2addr v6, v3

    .line 686
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 687
    .line 688
    .line 689
    move-result-object v6

    .line 690
    invoke-static {v1, v6}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 691
    .line 692
    .line 693
    move-result-object v6

    .line 694
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->gravity_sensor_list:Ljava/lang/String;

    .line 695
    .line 696
    const/4 v6, 0x2

    .line 697
    invoke-virtual {v4, v6}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 698
    .line 699
    .line 700
    move-result-object v6

    .line 701
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 702
    .line 703
    .line 704
    check-cast v6, Ljava/util/Collection;

    .line 705
    .line 706
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 707
    .line 708
    .line 709
    move-result v6

    .line 710
    xor-int/2addr v6, v3

    .line 711
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 712
    .line 713
    .line 714
    move-result-object v6

    .line 715
    invoke-static {v1, v6}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 716
    .line 717
    .line 718
    move-result-object v6

    .line 719
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->magnetic_sensor_list:Ljava/lang/String;

    .line 720
    .line 721
    const/4 v6, 0x5

    .line 722
    invoke-virtual {v4, v6}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 723
    .line 724
    .line 725
    move-result-object v6

    .line 726
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 727
    .line 728
    .line 729
    check-cast v6, Ljava/util/Collection;

    .line 730
    .line 731
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 732
    .line 733
    .line 734
    move-result v6

    .line 735
    xor-int/2addr v6, v3

    .line 736
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 737
    .line 738
    .line 739
    move-result-object v6

    .line 740
    invoke-static {v1, v6}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 741
    .line 742
    .line 743
    move-result-object v6

    .line 744
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->light_sensor_list:Ljava/lang/String;

    .line 745
    .line 746
    const/16 v6, 0x8

    .line 747
    .line 748
    invoke-virtual {v4, v6}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 749
    .line 750
    .line 751
    move-result-object v6

    .line 752
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 753
    .line 754
    .line 755
    check-cast v6, Ljava/util/Collection;

    .line 756
    .line 757
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 758
    .line 759
    .line 760
    move-result v6

    .line 761
    xor-int/2addr v6, v3

    .line 762
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 763
    .line 764
    .line 765
    move-result-object v6

    .line 766
    invoke-static {v1, v6}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 767
    .line 768
    .line 769
    move-result-object v6

    .line 770
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->proximity_sensor_list:Ljava/lang/String;

    .line 771
    .line 772
    invoke-virtual {v4, v2}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 773
    .line 774
    .line 775
    move-result-object v6

    .line 776
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 777
    .line 778
    .line 779
    check-cast v6, Ljava/util/Collection;

    .line 780
    .line 781
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 782
    .line 783
    .line 784
    move-result v6

    .line 785
    xor-int/2addr v6, v3

    .line 786
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 787
    .line 788
    .line 789
    move-result-object v6

    .line 790
    invoke-static {v1, v6}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 791
    .line 792
    .line 793
    move-result-object v6

    .line 794
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->orientation_sensor_list:Ljava/lang/String;

    .line 795
    .line 796
    const/16 v6, 0xa

    .line 797
    .line 798
    invoke-virtual {v4, v6}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 799
    .line 800
    .line 801
    move-result-object v6

    .line 802
    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 803
    .line 804
    .line 805
    check-cast v6, Ljava/util/Collection;

    .line 806
    .line 807
    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    .line 808
    .line 809
    .line 810
    move-result v6

    .line 811
    xor-int/2addr v6, v3

    .line 812
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 813
    .line 814
    .line 815
    move-result-object v6

    .line 816
    invoke-static {v1, v6}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 817
    .line 818
    .line 819
    move-result-object v6

    .line 820
    iput-object v6, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->linear_acceleration_sensor_list:Ljava/lang/String;

    .line 821
    .line 822
    const/4 v6, 0x6

    .line 823
    invoke-virtual {v4, v6}, Landroid/hardware/SensorManager;->getSensorList(I)Ljava/util/List;

    .line 824
    .line 825
    .line 826
    move-result-object v4

    .line 827
    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 828
    .line 829
    .line 830
    check-cast v4, Ljava/util/Collection;

    .line 831
    .line 832
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 833
    .line 834
    .line 835
    move-result v4

    .line 836
    xor-int/2addr v4, v3

    .line 837
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 838
    .line 839
    .line 840
    move-result-object v4

    .line 841
    invoke-static {v1, v4}, LFb/c;->access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;

    .line 842
    .line 843
    .line 844
    move-result-object v1

    .line 845
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->pressure_sensor_list:Ljava/lang/String;

    .line 846
    .line 847
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->isWifiConnected()Z

    .line 848
    .line 849
    .line 850
    move-result v1

    .line 851
    iput v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->is_current_wifi:I

    .line 852
    .line 853
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->getConnectWifiInfo()Landroid/net/wifi/WifiInfo;

    .line 854
    .line 855
    .line 856
    move-result-object v1

    .line 857
    if-eqz v1, :cond_8

    .line 858
    .line 859
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getFrequency()I

    .line 860
    .line 861
    .line 862
    move-result v4

    .line 863
    iput v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->wifi_frequency:I

    .line 864
    .line 865
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getBSSID()Ljava/lang/String;

    .line 866
    .line 867
    .line 868
    move-result-object v4

    .line 869
    iput-object v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->wifi_bssid:Ljava/lang/String;

    .line 870
    .line 871
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getRssi()I

    .line 872
    .line 873
    .line 874
    move-result v4

    .line 875
    iput v4, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->wifi_level:I

    .line 876
    .line 877
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getSSID()Ljava/lang/String;

    .line 878
    .line 879
    .line 880
    move-result-object v1

    .line 881
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->wifi_ssid:Ljava/lang/String;

    .line 882
    .line 883
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->getConnectWifCapabilities()Ljava/lang/String;

    .line 884
    .line 885
    .line 886
    move-result-object v1

    .line 887
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->wifi_capabilities:Ljava/lang/String;

    .line 888
    .line 889
    :cond_8
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->getBluetoothState()I

    .line 890
    .line 891
    .line 892
    move-result v1

    .line 893
    iput v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->bond_state:I

    .line 894
    .line 895
    :try_start_5
    invoke-static {}, Landroid/bluetooth/BluetoothAdapter;->getDefaultAdapter()Landroid/bluetooth/BluetoothAdapter;

    .line 896
    .line 897
    .line 898
    move-result-object v1

    .line 899
    invoke-virtual {v1}, Landroid/bluetooth/BluetoothAdapter;->getBondedDevices()Ljava/util/Set;

    .line 900
    .line 901
    .line 902
    move-result-object v1

    .line 903
    invoke-interface {v1}, Ljava/util/Set;->isEmpty()Z

    .line 904
    .line 905
    .line 906
    move-result v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 907
    xor-int/lit8 v5, v1, 0x1

    .line 908
    .line 909
    :catchall_0
    iput v5, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->is_bounded:I

    .line 910
    .line 911
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->getBluetoothAddress()Ljava/lang/String;

    .line 912
    .line 913
    .line 914
    move-result-object v1

    .line 915
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->blue_tooth_address:Ljava/lang/String;

    .line 916
    .line 917
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->getBluetoothName()Ljava/lang/String;

    .line 918
    .line 919
    .line 920
    move-result-object v1

    .line 921
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->blue_tooth_name:Ljava/lang/String;

    .line 922
    .line 923
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->getBluetoothType()I

    .line 924
    .line 925
    .line 926
    move-result v1

    .line 927
    iput v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->blue_tooth_type:I

    .line 928
    .line 929
    sget-object v1, LFb/d;->a:LFb/c;

    .line 930
    .line 931
    invoke-static {v1}, LFb/c;->access$getAppList(LFb/c;)Ljava/util/List;

    .line 932
    .line 933
    .line 934
    move-result-object v1

    .line 935
    iput-object v1, p1, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;->appInfo:Ljava/util/List;

    .line 936
    .line 937
    :try_start_6
    sget-object v1, Lob/c;->a:Lob/a;

    .line 938
    .line 939
    invoke-virtual {v1}, Lob/a;->getInstance()Lob/c;

    .line 940
    .line 941
    .line 942
    move-result-object v1

    .line 943
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 944
    .line 945
    .line 946
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 947
    .line 948
    .line 949
    move-result-object v1

    .line 950
    iput v3, p0, LFb/a;->a:I

    .line 951
    .line 952
    invoke-interface {v1, p1, p0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadDeviceInfo(Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 953
    .line 954
    .line 955
    move-result-object p1

    .line 956
    if-ne p1, v0, :cond_9

    .line 957
    .line 958
    return-object v0

    .line 959
    :cond_9
    :goto_5
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonResult;
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    .line 960
    .line 961
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 962
    .line 963
    .line 964
    move-result v0

    .line 965
    if-eqz v0, :cond_a

    .line 966
    .line 967
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 968
    .line 969
    .line 970
    move-result-object v0

    .line 971
    const-string v1, "key_last_upload_oc_device_info"

    .line 972
    .line 973
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 974
    .line 975
    .line 976
    move-result-wide v3

    .line 977
    invoke-virtual {v0, v1, v3, v4}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;J)V

    .line 978
    .line 979
    .line 980
    :cond_a
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 981
    .line 982
    .line 983
    move-result-object p1

    .line 984
    const-string v0, "uploadDeviceInfo: "

    .line 985
    .line 986
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 987
    .line 988
    .line 989
    move-result-object p1

    .line 990
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 991
    .line 992
    .line 993
    move-result-object p1

    .line 994
    const-string v0, "DeviceInfoUtils"

    .line 995
    .line 996
    invoke-static {v0, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 997
    .line 998
    .line 999
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1000
    .line 1001
    return-object p1

    .line 1002
    :catch_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1003
    .line 1004
    return-object p1
.end method
