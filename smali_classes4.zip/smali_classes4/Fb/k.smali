.class public final synthetic LFb/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Z

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/device/ui/activity/DeviceListActivity;Lcom/transsnet/palmpay/account/bean/rsp/QueryDeviceRsp;Z)V
    .locals 1

    .line 1
    const/4 v0, 0x5

    iput v0, p0, LFb/k;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LFb/k;->c:Ljava/lang/Object;

    iput-object p2, p0, LFb/k;->d:Ljava/lang/Object;

    iput-boolean p3, p0, LFb/k;->b:Z

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;Z)V
    .locals 0

    .line 2
    iput p2, p0, LFb/k;->a:I

    iput-boolean p4, p0, LFb/k;->b:Z

    iput-object p1, p0, LFb/k;->c:Ljava/lang/Object;

    iput-object p3, p0, LFb/k;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    const/4 p1, 0x0

    .line 2
    iget-boolean v0, p0, LFb/k;->b:Z

    .line 3
    .line 4
    iget-object v1, p0, LFb/k;->d:Ljava/lang/Object;

    .line 5
    .line 6
    iget-object v2, p0, LFb/k;->c:Ljava/lang/Object;

    .line 7
    .line 8
    iget v3, p0, LFb/k;->a:I

    .line 9
    .line 10
    packed-switch v3, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    check-cast v2, Lcom/transsnet/palmpay/device/ui/activity/DeviceListActivity;

    .line 14
    .line 15
    check-cast v1, Lcom/transsnet/palmpay/account/bean/rsp/QueryDeviceRsp;

    .line 16
    .line 17
    iput-object v1, v2, Lcom/transsnet/palmpay/device/ui/activity/DeviceListActivity;->f:Lcom/transsnet/palmpay/account/bean/rsp/QueryDeviceRsp;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    sget p1, Lcom/transsnet/palmpay/device/ui/activity/DeviceListActivity;->j:I

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    sget p1, Lcom/transsnet/palmpay/device/ui/activity/DeviceListActivity;->o:I

    .line 25
    .line 26
    :goto_0
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const-string v1, "/account/authentication"

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {v0, v2, p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/app/Activity;I)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :pswitch_0
    sget p1, Lcom/transsnet/palmpay/airtime/ui/AirtimeBillDetailActivity;->i:I

    .line 41
    .line 42
    if-eqz v0, :cond_1

    .line 43
    .line 44
    new-instance p1, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;

    .line 45
    .line 46
    check-cast v2, Lcom/transsnet/palmpay/airtime/ui/AirtimeBillDetailActivity;

    .line 47
    .line 48
    invoke-direct {p1, v2}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;-><init>(Landroid/content/Context;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p1}, LO6/f;->show()V

    .line 52
    .line 53
    .line 54
    check-cast v1, Lcom/transsnet/palmpay/airtime/bean/AirtimeDetailData;

    .line 55
    .line 56
    invoke-virtual {v1}, Lcom/transsnet/palmpay/airtime/bean/AirtimeDetailData;->getOrderStatusInfo()Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;->fillData(Lcom/transsnet/palmpay/core/bean/BillProcessDetail;)V

    .line 61
    .line 62
    .line 63
    :cond_1
    return-void

    .line 64
    :pswitch_1
    sget p1, Lcom/transsnet/palmpay/r2c/ui/activity/Recharge2CashDetailActivity;->f:I

    .line 65
    .line 66
    if-eqz v0, :cond_2

    .line 67
    .line 68
    new-instance p1, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;

    .line 69
    .line 70
    check-cast v2, Lcom/transsnet/palmpay/r2c/ui/activity/Recharge2CashDetailActivity;

    .line 71
    .line 72
    invoke-direct {p1, v2}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;-><init>(Landroid/content/Context;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p1}, LO6/f;->show()V

    .line 76
    .line 77
    .line 78
    check-cast v1, Lcom/transsnet/palmpay/airtime/bean/rsp/R2COrderDetailResp;

    .line 79
    .line 80
    iget-object v0, v1, Lcom/transsnet/palmpay/airtime/bean/rsp/R2COrderDetailResp;->orderStatusInfo:Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 81
    .line 82
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;->fillData(Lcom/transsnet/palmpay/core/bean/BillProcessDetail;)V

    .line 83
    .line 84
    .line 85
    :cond_2
    return-void

    .line 86
    :pswitch_2
    sget-object p1, Lcom/transsnet/palmpay/teller/ui/activity/BillPaymentOrderDetailActivity;->i:Lcom/transsnet/palmpay/teller/ui/activity/BillPaymentOrderDetailActivity$a;

    .line 87
    .line 88
    if-eqz v0, :cond_3

    .line 89
    .line 90
    new-instance p1, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;

    .line 91
    .line 92
    check-cast v2, Lcom/transsnet/palmpay/teller/ui/activity/BillPaymentOrderDetailActivity;

    .line 93
    .line 94
    invoke-direct {p1, v2}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;-><init>(Landroid/content/Context;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {p1}, LO6/f;->show()V

    .line 98
    .line 99
    .line 100
    check-cast v1, Lcom/transsnet/palmpay/teller/bean/BillPaymentOrderDetailRsp;

    .line 101
    .line 102
    invoke-virtual {v1}, Lcom/transsnet/palmpay/teller/bean/BillPaymentOrderDetailRsp;->getOrderStatusInfo()Lcom/transsnet/palmpay/core/bean/BillProcessDetail;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/ui/dialog/BillDetailProcessDialog;->fillData(Lcom/transsnet/palmpay/core/bean/BillProcessDetail;)V

    .line 107
    .line 108
    .line 109
    :cond_3
    return-void

    .line 110
    :pswitch_3
    if-eqz v0, :cond_5

    .line 111
    .line 112
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/other/LoanCoupon;

    .line 113
    .line 114
    if-eqz v1, :cond_4

    .line 115
    .line 116
    iget-object p1, v1, Lcom/transsnet/palmpay/credit/bean/other/LoanCoupon;->androidLink:Ljava/lang/String;

    .line 117
    .line 118
    :cond_4
    check-cast v2, LHb/P;

    .line 119
    .line 120
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 121
    .line 122
    .line 123
    invoke-static {p1}, LHb/P;->j(Ljava/lang/String;)Z

    .line 124
    .line 125
    .line 126
    :cond_5
    return-void

    .line 127
    :pswitch_4
    if-nez v0, :cond_6

    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_6
    check-cast v2, Landroid/view/View;

    .line 131
    .line 132
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    const-string v2, "getContext(...)"

    .line 137
    .line 138
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    const-string v2, "context"

    .line 142
    .line 143
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    const-string v2, ""

    .line 147
    .line 148
    check-cast v1, Ljava/lang/String;

    .line 149
    .line 150
    if-eqz v1, :cond_7

    .line 151
    .line 152
    invoke-static {v1}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 153
    .line 154
    .line 155
    move-result-object v1

    .line 156
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v1

    .line 160
    if-eqz v1, :cond_7

    .line 161
    .line 162
    const-string p1, " "

    .line 163
    .line 164
    invoke-static {v1, p1, v2}, Lkotlin/text/y;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    :cond_7
    if-nez p1, :cond_8

    .line 169
    .line 170
    goto :goto_1

    .line 171
    :cond_8
    move-object v2, p1

    .line 172
    :goto_1
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 173
    .line 174
    .line 175
    move-result p1

    .line 176
    if-nez p1, :cond_9

    .line 177
    .line 178
    goto :goto_2

    .line 179
    :cond_9
    const-string p1, "clipboard"

    .line 180
    .line 181
    invoke-virtual {v0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    const-string v0, "null cannot be cast to non-null type android.content.ClipboardManager"

    .line 186
    .line 187
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    check-cast p1, Landroid/content/ClipboardManager;

    .line 191
    .line 192
    const-string v0, "va_account"

    .line 193
    .line 194
    invoke-static {v0, v2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    .line 195
    .line 196
    .line 197
    move-result-object v0

    .line 198
    invoke-virtual {p1, v0}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 199
    .line 200
    .line 201
    const/4 p1, 0x0

    .line 202
    new-array p1, p1, [Ljava/lang/Object;

    .line 203
    .line 204
    const-string v0, "Copied to clipboard"

    .line 205
    .line 206
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 207
    .line 208
    .line 209
    :goto_2
    return-void

    .line 210
    nop

    .line 211
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
