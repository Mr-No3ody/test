.class public abstract LFb/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LFb/c;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LFb/c;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LFb/c;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LFb/d;->a:LFb/c;

    .line 8
    .line 9
    return-void
.end method
