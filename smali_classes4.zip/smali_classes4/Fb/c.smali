.class public final LFb/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LFb/c;-><init>()V

    return-void
.end method

.method public static final synthetic access$convertBoolean(LFb/c;Ljava/lang/Boolean;)Ljava/lang/String;
    .locals 0

    .line 1
    invoke-direct {p0, p1}, LFb/c;->convertBoolean(Ljava/lang/Boolean;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static final synthetic access$getAppList(LFb/c;)Ljava/util/List;
    .locals 0

    .line 1
    invoke-direct {p0}, LFb/c;->getAppList()Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public static final synthetic access$getTotalPhotos(LFb/c;)I
    .locals 0

    .line 1
    invoke-direct {p0}, LFb/c;->getTotalPhotos()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method private final convertBoolean(Ljava/lang/Boolean;)Ljava/lang/String;
    .locals 0

    .line 1
    if-eqz p1, :cond_1

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    const-string p1, "1"

    .line 10
    .line 11
    return-object p1

    .line 12
    :cond_0
    const-string p1, "0"

    .line 13
    .line 14
    return-object p1

    .line 15
    :cond_1
    const-string p1, "-1"

    .line 16
    .line 17
    return-object p1
.end method

.method private final getAppList()Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo$AppInfo;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseApplication;->isOldAndroidDevice()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    const/16 v1, 0x190

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/16 v1, 0x5dc

    .line 20
    .line 21
    :goto_0
    :try_start_0
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    const/4 v3, 0x0

    .line 30
    invoke-virtual {v2, v3}, Landroid/content/pm/PackageManager;->getInstalledPackages(I)Ljava/util/List;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    :cond_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 39
    .line 40
    .line 41
    move-result v4

    .line 42
    if-eqz v4, :cond_3

    .line 43
    .line 44
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    check-cast v4, Landroid/content/pm/PackageInfo;

    .line 49
    .line 50
    iget-object v5, v4, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    .line 51
    .line 52
    if-eqz v5, :cond_2

    .line 53
    .line 54
    new-instance v6, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo$AppInfo;

    .line 55
    .line 56
    new-instance v7, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;

    .line 57
    .line 58
    invoke-direct {v7}, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;-><init>()V

    .line 59
    .line 60
    .line 61
    invoke-virtual {v5, v2}, Landroid/content/pm/PackageItemInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    iget-object v4, v4, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    .line 70
    .line 71
    invoke-direct {v6, v7, v5, v4}, Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo$AppInfo;-><init>(Lcom/transsnet/palmpay/credit/bean/req/OcUploadDeviceInfo;Ljava/lang/String;Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    goto :goto_1

    .line 78
    :catch_0
    move-exception v1

    .line 79
    goto :goto_2

    .line 80
    :cond_2
    :goto_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 81
    .line 82
    .line 83
    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 84
    if-le v4, v1, :cond_1

    .line 85
    .line 86
    goto :goto_3

    .line 87
    :goto_2
    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 88
    .line 89
    .line 90
    :cond_3
    :goto_3
    return-object v0
.end method

.method public static synthetic getOcDeviceInfo$default(LFb/c;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;
    .locals 1

    .line 1
    and-int/lit8 p5, p4, 0x1

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    if-eqz p5, :cond_0

    .line 5
    .line 6
    move-object p1, v0

    .line 7
    :cond_0
    and-int/lit8 p5, p4, 0x2

    .line 8
    .line 9
    if-eqz p5, :cond_1

    .line 10
    .line 11
    move-object p2, v0

    .line 12
    :cond_1
    and-int/lit8 p4, p4, 0x4

    .line 13
    .line 14
    if-eqz p4, :cond_2

    .line 15
    .line 16
    move-object p3, v0

    .line 17
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, LFb/c;->getOcDeviceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0
.end method

.method private final getTotalPhotos()I
    .locals 8

    .line 1
    const/4 v1, 0x0

    .line 2
    :try_start_0
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 7
    .line 8
    .line 9
    move-result-object v2

    .line 10
    sget-object v3, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    .line 11
    .line 12
    const-string v0, "_id"

    .line 13
    .line 14
    filled-new-array {v0}, [Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    const/4 v6, 0x0

    .line 19
    const/4 v7, 0x0

    .line 20
    const/4 v5, 0x0

    .line 21
    invoke-virtual/range {v2 .. v7}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    invoke-interface {v0}, Landroid/database/Cursor;->getCount()I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    invoke-interface {v0}, Landroid/database/Cursor;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    .line 33
    .line 34
    return v1

    .line 35
    :catch_0
    move-exception v0

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    return v1

    .line 38
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 39
    .line 40
    .line 41
    return v1
.end method

.method private final hasSimCard(Landroid/content/Context;)Z
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    const-string v1, "phone"

    .line 3
    .line 4
    invoke-virtual {p1, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    const-string v1, "null cannot be cast to non-null type android.telephony.TelephonyManager"

    .line 9
    .line 10
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    check-cast p1, Landroid/telephony/TelephonyManager;

    .line 14
    .line 15
    invoke-virtual {p1}, Landroid/telephony/TelephonyManager;->getSimState()I

    .line 16
    .line 17
    .line 18
    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 19
    if-eqz p1, :cond_0

    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    if-eq p1, v1, :cond_0

    .line 23
    .line 24
    return v1

    .line 25
    :catch_0
    :cond_0
    return v0
.end method


# virtual methods
.method public final getOcDeviceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;
    .locals 10
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "MissingPermission"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    const-string v0, "NG"

    .line 2
    .line 3
    const-string v1, "null cannot be cast to non-null type android.os.BatteryManager"

    .line 4
    .line 5
    const-string v2, "batterymanager"

    .line 6
    .line 7
    const-string v3, ""

    .line 8
    .line 9
    const-string v4, "Android"

    .line 10
    .line 11
    new-instance v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;

    .line 12
    .line 13
    invoke-direct {v5}, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;-><init>()V

    .line 14
    .line 15
    .line 16
    :try_start_0
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->applyId:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->upload_node:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->uploadNode:Ljava/lang/String;

    .line 21
    .line 22
    iput-object p3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->upload_node_detail:Ljava/lang/String;

    .line 23
    .line 24
    iput-object p3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->uploadNodeDetail:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {}, Landroidx/work/impl/model/b;->e()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->deviceId1:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-virtual {p1}, Lya/a;->c()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->advertising_id:Ljava/lang/String;

    .line 41
    .line 42
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getAndroidID()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->android_id:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {}, Landroid/os/Build;->getRadioVersion()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->base_band:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {}, Lr5/a;->m()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->base_station_no:Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getCellSignalStrength()I

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    new-instance p2, Ljava/lang/StringBuilder;

    .line 65
    .line 66
    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    const-string p1, "dB"

    .line 73
    .line 74
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->base_station_signal_strenth:Ljava/lang/String;

    .line 82
    .line 83
    const/4 p1, 0x0

    .line 84
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->camera_parameters:Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean$CameraParametersBean;

    .line 85
    .line 86
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getCurCpuFreq()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object p2

    .line 90
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->cpu_cur_frequency:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getMaxCpuFreq()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object p2

    .line 96
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->cpu_max_frequency:Ljava/lang/String;

    .line 97
    .line 98
    const-string p2, "credit"

    .line 99
    .line 100
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->data_type:Ljava/lang/String;

    .line 101
    .line 102
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 103
    .line 104
    .line 105
    move-result-object p2

    .line 106
    invoke-virtual {p2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 107
    .line 108
    .line 109
    move-result-object p2

    .line 110
    invoke-virtual {p2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 111
    .line 112
    .line 113
    move-result-object p2

    .line 114
    iget-object p2, p2, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    .line 115
    .line 116
    invoke-virtual {p2}, Ljava/util/Locale;->getDisplayLanguage()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object p2

    .line 120
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->device_language:Ljava/lang/String;

    .line 121
    .line 122
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->isDeviceRooted()Z

    .line 123
    .line 124
    .line 125
    move-result p2

    .line 126
    iput p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->device_root:I

    .line 127
    .line 128
    sget-object p2, LFb/d;->a:LFb/c;

    .line 129
    .line 130
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 131
    .line 132
    .line 133
    move-result-object p3

    .line 134
    const-string v6, "get(...)"

    .line 135
    .line 136
    invoke-static {p3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    invoke-direct {p2, p3}, LFb/c;->hasSimCard(Landroid/content/Context;)Z

    .line 140
    .line 141
    .line 142
    move-result p2

    .line 143
    iput p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->device_sim:I

    .line 144
    .line 145
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->external_ip:Ljava/lang/String;

    .line 146
    .line 147
    iput-object v3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->gps_err_msg:Ljava/lang/String;

    .line 148
    .line 149
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 150
    .line 151
    .line 152
    move-result-wide p2

    .line 153
    const-wide/32 v6, 0x36ee80

    .line 154
    .line 155
    .line 156
    div-long/2addr p2, v6

    .line 157
    iput-wide p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->hours_since_last_launch:J

    .line 158
    .line 159
    invoke-static {}, Landroidx/work/impl/model/b;->e()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object p2

    .line 163
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->imei:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 164
    .line 165
    :try_start_1
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object p2

    .line 169
    const-string p3, "android.permission.ACCESS_COARSE_LOCATION"

    .line 170
    .line 171
    filled-new-array {p2, p3}, [Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object p2

    .line 175
    invoke-static {p2}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 176
    .line 177
    .line 178
    move-result p2

    .line 179
    iput p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->is_gps_permission_opened:I

    .line 180
    .line 181
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 182
    .line 183
    .line 184
    move-result-object p2

    .line 185
    const-string p3, "location"

    .line 186
    .line 187
    invoke-virtual {p2, p3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object p2

    .line 191
    const-string p3, "null cannot be cast to non-null type android.location.LocationManager"

    .line 192
    .line 193
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    check-cast p2, Landroid/location/LocationManager;

    .line 197
    .line 198
    const-string p3, "gps"

    .line 199
    .line 200
    invoke-virtual {p2, p3}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    .line 201
    .line 202
    .line 203
    move-result p2

    .line 204
    iput p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->is_gps_switch_opened:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 205
    .line 206
    goto :goto_0

    .line 207
    :catch_0
    move-exception p2

    .line 208
    :try_start_2
    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    .line 209
    .line 210
    .line 211
    :goto_0
    new-instance p2, Landroid/content/IntentFilter;

    .line 212
    .line 213
    const-string p3, "android.intent.action.BATTERY_CHANGED"

    .line 214
    .line 215
    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 216
    .line 217
    .line 218
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 219
    .line 220
    .line 221
    move-result-object p3

    .line 222
    invoke-virtual {p3, p1, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 223
    .line 224
    .line 225
    move-result-object p2

    .line 226
    const/4 p3, -0x1

    .line 227
    if-eqz p2, :cond_0

    .line 228
    .line 229
    const-string v6, "status"

    .line 230
    .line 231
    invoke-virtual {p2, v6, p3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 232
    .line 233
    .line 234
    move-result p3

    .line 235
    goto :goto_1

    .line 236
    :catch_1
    move-exception p1

    .line 237
    goto/16 :goto_9

    .line 238
    .line 239
    :cond_0
    :goto_1
    const/4 p2, 0x2

    .line 240
    if-eq p3, p2, :cond_1

    .line 241
    .line 242
    const/4 p2, 0x5

    .line 243
    :cond_1
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 244
    .line 245
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 246
    .line 247
    .line 248
    move-result-object p3

    .line 249
    invoke-virtual {p3, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 250
    .line 251
    .line 252
    move-result-object p3

    .line 253
    invoke-static {p3, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 254
    .line 255
    .line 256
    check-cast p3, Landroid/os/BatteryManager;

    .line 257
    .line 258
    invoke-virtual {p3}, Landroid/os/BatteryManager;->isCharging()Z

    .line 259
    .line 260
    .line 261
    move-result p3

    .line 262
    iput p3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->is_phone_charge:I

    .line 263
    .line 264
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 265
    .line 266
    .line 267
    move-result-object p3

    .line 268
    invoke-virtual {p3}, Lya/a;->f()Lcom/transsnet/palmpay/core/bean/LocationRecord;

    .line 269
    .line 270
    .line 271
    move-result-object p3

    .line 272
    if-eqz p3, :cond_2

    .line 273
    .line 274
    invoke-virtual {p3}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLatitude()D

    .line 275
    .line 276
    .line 277
    move-result-wide v6

    .line 278
    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 279
    .line 280
    .line 281
    move-result-object v6

    .line 282
    iput-object v6, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->latitude:Ljava/lang/Double;

    .line 283
    .line 284
    invoke-virtual {p3}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLongitude()D

    .line 285
    .line 286
    .line 287
    move-result-wide v6

    .line 288
    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 289
    .line 290
    .line 291
    move-result-object p3

    .line 292
    iput-object p3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->longitude:Ljava/lang/Double;

    .line 293
    .line 294
    goto :goto_2

    .line 295
    :cond_2
    const-wide v6, 0x40c3878000000000L    # 9999.0

    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 301
    .line 302
    .line 303
    move-result-object p3

    .line 304
    iput-object p3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->latitude:Ljava/lang/Double;

    .line 305
    .line 306
    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 307
    .line 308
    .line 309
    move-result-object p3

    .line 310
    iput-object p3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->longitude:Ljava/lang/Double;

    .line 311
    .line 312
    :goto_2
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getMacAddress()Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object p3

    .line 316
    iput-object p3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->mac:Ljava/lang/String;

    .line 317
    .line 318
    const/16 p3, 0x1c

    .line 319
    .line 320
    if-le p2, p3, :cond_3

    .line 321
    .line 322
    move-object v6, v3

    .line 323
    goto :goto_3

    .line 324
    :cond_3
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getMEID()Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object v6

    .line 328
    :goto_3
    iput-object v6, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->meid:Ljava/lang/String;

    .line 329
    .line 330
    if-le p2, p3, :cond_4

    .line 331
    .line 332
    move-object v6, v3

    .line 333
    goto :goto_4

    .line 334
    :cond_4
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getIMEI2()Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object v6

    .line 338
    :goto_4
    iput-object v6, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->new_imei:Ljava/lang/String;

    .line 339
    .line 340
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getSDKVersionName()Ljava/lang/String;

    .line 341
    .line 342
    .line 343
    move-result-object v6

    .line 344
    new-instance v7, Ljava/lang/StringBuilder;

    .line 345
    .line 346
    invoke-direct {v7, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 347
    .line 348
    .line 349
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 350
    .line 351
    .line 352
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 353
    .line 354
    .line 355
    move-result-object v4

    .line 356
    iput-object v4, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->os_version:Ljava/lang/String;

    .line 357
    .line 358
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getManufacturer()Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object v4

    .line 362
    iput-object v4, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->phone_brand:Ljava/lang/String;

    .line 363
    .line 364
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 365
    .line 366
    .line 367
    move-result-object v4

    .line 368
    invoke-virtual {v4, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 369
    .line 370
    .line 371
    move-result-object v2

    .line 372
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    check-cast v2, Landroid/os/BatteryManager;

    .line 376
    .line 377
    const/4 v1, 0x4

    .line 378
    invoke-virtual {v2, v1}, Landroid/os/BatteryManager;->getIntProperty(I)I

    .line 379
    .line 380
    .line 381
    move-result v1

    .line 382
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 383
    .line 384
    .line 385
    move-result-object v1

    .line 386
    iput-object v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->phone_electric_quantity:Ljava/lang/String;

    .line 387
    .line 388
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getModel()Ljava/lang/String;

    .line 389
    .line 390
    .line 391
    move-result-object v1

    .line 392
    iput-object v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->phone_model:Ljava/lang/String;

    .line 393
    .line 394
    invoke-static {}, Lcom/transsnet/palmpay/util/ScreenUtils;->getScreenDensityDpi()I

    .line 395
    .line 396
    .line 397
    move-result v1

    .line 398
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 399
    .line 400
    .line 401
    move-result-object v1

    .line 402
    iput-object v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->screen_density:Ljava/lang/String;

    .line 403
    .line 404
    invoke-static {}, Lcom/transsnet/palmpay/util/ScreenUtils;->getScreenWidth()I

    .line 405
    .line 406
    .line 407
    move-result v1

    .line 408
    invoke-static {}, Lcom/transsnet/palmpay/util/ScreenUtils;->getScreenHeight()I

    .line 409
    .line 410
    .line 411
    move-result v2

    .line 412
    new-instance v4, Ljava/lang/StringBuilder;

    .line 413
    .line 414
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 415
    .line 416
    .line 417
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 418
    .line 419
    .line 420
    const-string v1, "x"

    .line 421
    .line 422
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 423
    .line 424
    .line 425
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 426
    .line 427
    .line 428
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object v1

    .line 432
    iput-object v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->screen_resolution:Ljava/lang/String;

    .line 433
    .line 434
    invoke-static {}, Lcom/transsnet/palmpay/util/SDCardUtils;->getSDTotalSize()J

    .line 435
    .line 436
    .line 437
    move-result-wide v1

    .line 438
    iput-wide v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sdcard_total_capacity:J

    .line 439
    .line 440
    invoke-static {}, Lcom/transsnet/palmpay/util/SDCardUtils;->getSDFreeSize()J

    .line 441
    .line 442
    .line 443
    move-result-wide v6

    .line 444
    sub-long/2addr v1, v6

    .line 445
    iput-wide v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sdcard_used_capacity:J

    .line 446
    .line 447
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimState()I

    .line 448
    .line 449
    .line 450
    move-result v1

    .line 451
    iput v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim_card_status:I

    .line 452
    .line 453
    if-le p2, p3, :cond_5

    .line 454
    .line 455
    move-object p2, v3

    .line 456
    goto :goto_5

    .line 457
    :cond_5
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getIMSI()Ljava/lang/String;

    .line 458
    .line 459
    .line 460
    move-result-object p2

    .line 461
    :goto_5
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim_code:Ljava/lang/String;

    .line 462
    .line 463
    sget-object p2, Landroid/os/Build;->SERIAL:Ljava/lang/String;

    .line 464
    .line 465
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sn:Ljava/lang/String;

    .line 466
    .line 467
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 468
    .line 469
    .line 470
    move-result-object p2

    .line 471
    const-string p3, "activity"

    .line 472
    .line 473
    invoke-virtual {p2, p3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 474
    .line 475
    .line 476
    move-result-object p2

    .line 477
    check-cast p2, Landroid/app/ActivityManager;

    .line 478
    .line 479
    if-eqz p2, :cond_6

    .line 480
    .line 481
    new-instance p3, Landroid/app/ActivityManager$MemoryInfo;

    .line 482
    .line 483
    invoke-direct {p3}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    .line 484
    .line 485
    .line 486
    invoke-virtual {p2, p3}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    .line 487
    .line 488
    .line 489
    iget-wide v1, p3, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    .line 490
    .line 491
    const/16 p2, 0x400

    .line 492
    .line 493
    int-to-long v6, p2

    .line 494
    div-long v8, v1, v6

    .line 495
    .line 496
    div-long/2addr v8, v6

    .line 497
    iput-wide v8, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->total_memory:J

    .line 498
    .line 499
    iget-wide p2, p3, Landroid/app/ActivityManager$MemoryInfo;->availMem:J

    .line 500
    .line 501
    sub-long/2addr v1, p2

    .line 502
    div-long/2addr v1, v6

    .line 503
    div-long/2addr v1, v6

    .line 504
    iput-wide v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->used_memory:J

    .line 505
    .line 506
    :cond_6
    invoke-static {}, Lcom/transsnet/palmpay/util/SDCardUtils;->getSDTotalSize()J

    .line 507
    .line 508
    .line 509
    move-result-wide p2

    .line 510
    iput-wide p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->total_storage:J

    .line 511
    .line 512
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->isWifiConnected()Z

    .line 513
    .line 514
    .line 515
    move-result p2

    .line 516
    iput p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->wifi_conneted:I

    .line 517
    .line 518
    invoke-static {}, Lr5/a;->x()Lxf/u;

    .line 519
    .line 520
    .line 521
    move-result-object p2
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 522
    if-eqz p2, :cond_9

    .line 523
    .line 524
    iget-object p3, p2, Lxf/u;->c:Ljava/lang/Object;

    .line 525
    .line 526
    :try_start_3
    iget-object v1, p2, Lxf/u;->a:Ljava/lang/Object;

    .line 527
    .line 528
    check-cast v1, Ljava/lang/String;

    .line 529
    .line 530
    iput-object v1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->wifi:Ljava/lang/String;

    .line 531
    .line 532
    iget-object p2, p2, Lxf/u;->b:Ljava/lang/Object;

    .line 533
    .line 534
    check-cast p2, Ljava/lang/Integer;

    .line 535
    .line 536
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->wifi_level:Ljava/lang/Integer;

    .line 537
    .line 538
    move-object p2, p3

    .line 539
    check-cast p2, Ljava/lang/CharSequence;

    .line 540
    .line 541
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 542
    .line 543
    .line 544
    move-result p2

    .line 545
    if-nez p2, :cond_8

    .line 546
    .line 547
    const-string p2, "02:00:00:00:00:00"

    .line 548
    .line 549
    invoke-virtual {p2, p3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 550
    .line 551
    .line 552
    move-result p2

    .line 553
    if-eqz p2, :cond_7

    .line 554
    .line 555
    goto :goto_6

    .line 556
    :cond_7
    check-cast p3, Ljava/lang/String;

    .line 557
    .line 558
    goto :goto_7

    .line 559
    :cond_8
    :goto_6
    invoke-static {}, Lr5/a;->u()Ljava/lang/String;

    .line 560
    .line 561
    .line 562
    move-result-object p3

    .line 563
    :goto_7
    iput-object p3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->mac:Ljava/lang/String;

    .line 564
    .line 565
    goto :goto_8

    .line 566
    :cond_9
    invoke-static {}, Lr5/a;->u()Ljava/lang/String;

    .line 567
    .line 568
    .line 569
    move-result-object p2

    .line 570
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->mac:Ljava/lang/String;

    .line 571
    .line 572
    :goto_8
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->camera_parameters:Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean$CameraParametersBean;

    .line 573
    .line 574
    invoke-static {}, Lr5/a;->m()Ljava/lang/String;

    .line 575
    .line 576
    .line 577
    move-result-object p2

    .line 578
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->base_station:Ljava/lang/String;

    .line 579
    .line 580
    invoke-static {}, Lcom/transsnet/palmpay/util/AppUtils;->getAppVersionCode()I

    .line 581
    .line 582
    .line 583
    move-result p2

    .line 584
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 585
    .line 586
    .line 587
    move-result-object p2

    .line 588
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->app_version:Ljava/lang/Integer;

    .line 589
    .line 590
    sget-object p2, Landroid/os/Build;->BOARD:Ljava/lang/String;

    .line 591
    .line 592
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->build_board:Ljava/lang/String;

    .line 593
    .line 594
    sget-object p2, Landroid/os/Build;->BRAND:Ljava/lang/String;

    .line 595
    .line 596
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->build_brand:Ljava/lang/String;

    .line 597
    .line 598
    sget-object p2, Landroid/os/Build;->HOST:Ljava/lang/String;

    .line 599
    .line 600
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->build_host:Ljava/lang/String;

    .line 601
    .line 602
    sget-object p2, Landroid/os/Build;->ID:Ljava/lang/String;

    .line 603
    .line 604
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->build_id:Ljava/lang/String;

    .line 605
    .line 606
    sget-object p2, Landroid/os/Build;->TAGS:Ljava/lang/String;

    .line 607
    .line 608
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->build_tags:Ljava/lang/String;

    .line 609
    .line 610
    sget-object p2, Landroid/os/Build;->TYPE:Ljava/lang/String;

    .line 611
    .line 612
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->build_type:Ljava/lang/String;

    .line 613
    .line 614
    sget-object p2, Landroid/os/Build;->USER:Ljava/lang/String;

    .line 615
    .line 616
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->build_user:Ljava/lang/String;

    .line 617
    .line 618
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimOperatorCode()Ljava/lang/String;

    .line 619
    .line 620
    .line 621
    move-result-object p2

    .line 622
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->carrier_mobile_country_code:Ljava/lang/String;

    .line 623
    .line 624
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimOperatorName()Ljava/lang/String;

    .line 625
    .line 626
    .line 627
    move-result-object p2

    .line 628
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->carrier_operator:Ljava/lang/String;

    .line 629
    .line 630
    sget-object p2, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    .line 631
    .line 632
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->cpu_architecture:Ljava/lang/String;

    .line 633
    .line 634
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getCpuModel()Ljava/lang/String;

    .line 635
    .line 636
    .line 637
    move-result-object p2

    .line 638
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->cpu_hardware:Ljava/lang/String;

    .line 639
    .line 640
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getMinCpuFreq()Ljava/lang/String;

    .line 641
    .line 642
    .line 643
    move-result-object p2

    .line 644
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->cpu_min_freq:Ljava/lang/String;

    .line 645
    .line 646
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getCpuSerial()Ljava/lang/String;

    .line 647
    .line 648
    .line 649
    move-result-object p2

    .line 650
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->cpu_serial:Ljava/lang/String;

    .line 651
    .line 652
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getCurCpuFreq()Ljava/lang/String;

    .line 653
    .line 654
    .line 655
    move-result-object p2

    .line 656
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->cpu_speed:Ljava/lang/String;

    .line 657
    .line 658
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 659
    .line 660
    .line 661
    move-result-wide p2

    .line 662
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 663
    .line 664
    .line 665
    move-result-object p2

    .line 666
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->create_time:Ljava/lang/Long;

    .line 667
    .line 668
    invoke-static {}, Lcom/transsnet/palmpay/util/DeviceUtils;->getAndroidID()Ljava/lang/String;

    .line 669
    .line 670
    .line 671
    move-result-object p2

    .line 672
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->deviceID:Ljava/lang/String;

    .line 673
    .line 674
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->firebaseInstanceId:Ljava/lang/String;

    .line 675
    .line 676
    sget-object p2, LPa/k;->a:LPa/l;

    .line 677
    .line 678
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 679
    .line 680
    .line 681
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 682
    .line 683
    .line 684
    move-result-object p2

    .line 685
    iget-object p2, p2, Lya/a;->a:Lcom/tencent/mmkv/MMKV;

    .line 686
    .line 687
    const-string p3, "key_default_language"

    .line 688
    .line 689
    invoke-virtual {p2, p3, v0}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 690
    .line 691
    .line 692
    iput-object v0, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->geophysics:Ljava/lang/String;

    .line 693
    .line 694
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->gps_city:Ljava/lang/String;

    .line 695
    .line 696
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->gps_country:Ljava/lang/String;

    .line 697
    .line 698
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->gps_district:Ljava/lang/String;

    .line 699
    .line 700
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->gps_other:Ljava/lang/String;

    .line 701
    .line 702
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->gps_state:Ljava/lang/String;

    .line 703
    .line 704
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getIMEI2()Ljava/lang/String;

    .line 705
    .line 706
    .line 707
    move-result-object p2

    .line 708
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->imei2:Ljava/lang/String;

    .line 709
    .line 710
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getIMSI()Ljava/lang/String;

    .line 711
    .line 712
    .line 713
    move-result-object p2

    .line 714
    iput-object p2, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->imsi:Ljava/lang/String;

    .line 715
    .line 716
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->login_time:Ljava/lang/String;

    .line 717
    .line 718
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->media_uuid:Ljava/lang/String;

    .line 719
    .line 720
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimMSISDN()Ljava/lang/String;

    .line 721
    .line 722
    .line 723
    move-result-object p1

    .line 724
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->phone_number:Ljava/lang/String;

    .line 725
    .line 726
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimType()I

    .line 727
    .line 728
    .line 729
    move-result p1

    .line 730
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 731
    .line 732
    .line 733
    move-result-object p1

    .line 734
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->phone_type:Ljava/lang/Integer;

    .line 735
    .line 736
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimMSISDN()Ljava/lang/String;

    .line 737
    .line 738
    .line 739
    move-result-object p1

    .line 740
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim1_phone_no:Ljava/lang/String;

    .line 741
    .line 742
    iput-object v3, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim2_phone_no:Ljava/lang/String;

    .line 743
    .line 744
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimCountry()Ljava/lang/String;

    .line 745
    .line 746
    .line 747
    move-result-object p1

    .line 748
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim_country_iso:Ljava/lang/String;

    .line 749
    .line 750
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getLac()Ljava/lang/String;

    .line 751
    .line 752
    .line 753
    move-result-object p1

    .line 754
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim_lac:Ljava/lang/String;

    .line 755
    .line 756
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimMcc()Ljava/lang/String;

    .line 757
    .line 758
    .line 759
    move-result-object p1

    .line 760
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim_mcc:Ljava/lang/String;

    .line 761
    .line 762
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimMnc()Ljava/lang/String;

    .line 763
    .line 764
    .line 765
    move-result-object p1

    .line 766
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim_mnc:Ljava/lang/String;

    .line 767
    .line 768
    invoke-static {}, Lcom/transsnet/palmpay/util/PhoneUtils;->getSimSerialNumber()Ljava/lang/String;

    .line 769
    .line 770
    .line 771
    move-result-object p1

    .line 772
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim_serial:Ljava/lang/String;

    .line 773
    .line 774
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 775
    .line 776
    .line 777
    move-result-object p1

    .line 778
    invoke-static {p1}, Landroid/telephony/SubscriptionManager;->from(Landroid/content/Context;)Landroid/telephony/SubscriptionManager;

    .line 779
    .line 780
    .line 781
    move-result-object p1

    .line 782
    invoke-virtual {p1}, Landroid/telephony/SubscriptionManager;->getActiveSubscriptionInfoCount()I

    .line 783
    .line 784
    .line 785
    move-result p1

    .line 786
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 787
    .line 788
    .line 789
    move-result-object p1

    .line 790
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->sim_cnt:Ljava/lang/String;

    .line 791
    .line 792
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 793
    .line 794
    .line 795
    move-result-object p1

    .line 796
    invoke-static {p1}, Landroid/telephony/SubscriptionManager;->from(Landroid/content/Context;)Landroid/telephony/SubscriptionManager;

    .line 797
    .line 798
    .line 799
    move-result-object p1

    .line 800
    invoke-virtual {p1}, Landroid/telephony/SubscriptionManager;->getActiveSubscriptionInfoCountMax()I

    .line 801
    .line 802
    .line 803
    move-result p1

    .line 804
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 805
    .line 806
    .line 807
    move-result-object p1

    .line 808
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->slot_count:Ljava/lang/Integer;

    .line 809
    .line 810
    invoke-static {}, Lcom/transsnet/palmpay/util/ScreenUtils;->getScreenBrightness()I

    .line 811
    .line 812
    .line 813
    move-result p1

    .line 814
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 815
    .line 816
    .line 817
    move-result-object p1

    .line 818
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->screen_brightness:Ljava/lang/String;

    .line 819
    .line 820
    invoke-static {}, Lcom/transsnet/palmpay/util/SDCardUtils;->getSDFreeSize()J

    .line 821
    .line 822
    .line 823
    move-result-wide p1

    .line 824
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 825
    .line 826
    .line 827
    move-result-object p1

    .line 828
    iput-object p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->disk_free_total_space:Ljava/lang/String;

    .line 829
    .line 830
    invoke-static {}, Lcom/transsnet/palmpay/util/NetworkUtils;->isConnected()Z

    .line 831
    .line 832
    .line 833
    move-result p1

    .line 834
    iput-boolean p1, v5, Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;->is_equipment_breakout:Z
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 835
    .line 836
    goto :goto_a

    .line 837
    :goto_9
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 838
    .line 839
    .line 840
    :goto_a
    return-object v5
.end method

.method public final uploadDeviceInfo()V
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "MissingPermission"
        }
    .end annotation

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "key_last_upload_oc_device_info"

    .line 6
    .line 7
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 8
    .line 9
    .line 10
    move-result-wide v2

    .line 11
    invoke-virtual {v0, v1, v2, v3}, Lcom/transsnet/palmpay/util/SPUtils;->getLong(Ljava/lang/String;J)J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    const-wide/32 v2, 0x36ee80

    .line 16
    .line 17
    .line 18
    add-long/2addr v0, v2

    .line 19
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 20
    .line 21
    .line 22
    move-result-wide v2

    .line 23
    cmp-long v0, v0, v2

    .line 24
    .line 25
    if-gez v0, :cond_0

    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    sget-object v0, LWf/V;->a:LWf/V;

    .line 29
    .line 30
    new-instance v1, LFb/b;

    .line 31
    .line 32
    const/4 v2, 0x2

    .line 33
    const/4 v3, 0x0

    .line 34
    invoke-direct {v1, v2, v3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 35
    .line 36
    .line 37
    const/4 v2, 0x3

    .line 38
    invoke-static {v0, v3, v3, v1, v2}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 39
    .line 40
    .line 41
    return-void
.end method
