.class public abstract LFb/j;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V
    .locals 8

    .line 1
    if-eqz p1, :cond_d

    .line 2
    .line 3
    :try_start_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    move-object v0, p0

    .line 8
    check-cast v0, Landroid/view/ViewGroup;

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    :goto_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getHeight()Ljava/lang/Float;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getWidth()Ljava/lang/Float;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-static {v0, v1, v2}, LFb/j;->b(Landroid/view/ViewGroup;Ljava/lang/Float;Ljava/lang/Float;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getBgColors()Ljava/util/List;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const/4 v1, 0x0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 31
    .line 32
    .line 33
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 34
    goto :goto_1

    .line 35
    :cond_1
    move v0, v1

    .line 36
    :goto_1
    const-string v2, "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$"

    .line 37
    .line 38
    const-string v3, ""

    .line 39
    .line 40
    if-lez v0, :cond_7

    .line 41
    .line 42
    :try_start_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getBgColors()Ljava/util/List;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    if-eqz v0, :cond_d

    .line 47
    .line 48
    if-eqz p0, :cond_d

    .line 49
    .line 50
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getCornerRadius()Lcom/transsnet/palmpay/core/bean/style_config/CornerRadius;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    if-nez v4, :cond_2

    .line 55
    .line 56
    new-instance v4, Lcom/transsnet/palmpay/core/bean/style_config/CornerRadius;

    .line 57
    .line 58
    invoke-direct {v4}, Lcom/transsnet/palmpay/core/bean/style_config/CornerRadius;-><init>()V

    .line 59
    .line 60
    .line 61
    :cond_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getStrokeWidth()Ljava/lang/Integer;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    if-eqz v5, :cond_3

    .line 66
    .line 67
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    goto :goto_2

    .line 72
    :cond_3
    move v5, v1

    .line 73
    :goto_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getStrokeColor()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v6

    .line 77
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 78
    .line 79
    .line 80
    move-result v6

    .line 81
    if-nez v6, :cond_6

    .line 82
    .line 83
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getStrokeColor()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    if-nez v6, :cond_4

    .line 88
    .line 89
    move-object v6, v3

    .line 90
    :cond_4
    new-instance v7, Lkotlin/text/Regex;

    .line 91
    .line 92
    invoke-direct {v7, v2}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v7, v6}, Lkotlin/text/Regex;->b(Ljava/lang/CharSequence;)Z

    .line 96
    .line 97
    .line 98
    move-result v2

    .line 99
    if-eqz v2, :cond_6

    .line 100
    .line 101
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getStrokeColor()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    if-nez p1, :cond_5

    .line 106
    .line 107
    goto :goto_3

    .line 108
    :cond_5
    move-object v3, p1

    .line 109
    :goto_3
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 110
    .line 111
    .line 112
    move-result v1

    .line 113
    :cond_6
    invoke-static {v0, v4, v5, v1}, LEb/a;->i(Ljava/util/List;Lcom/transsnet/palmpay/core/bean/style_config/CornerRadius;II)Landroid/graphics/drawable/StateListDrawable;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    invoke-virtual {p0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 118
    .line 119
    .line 120
    return-void

    .line 121
    :cond_7
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getBgColor()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    if-nez v0, :cond_d

    .line 130
    .line 131
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getBgColor()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    if-eqz v0, :cond_d

    .line 136
    .line 137
    if-eqz p0, :cond_d

    .line 138
    .line 139
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getCornerRadius()Lcom/transsnet/palmpay/core/bean/style_config/CornerRadius;

    .line 140
    .line 141
    .line 142
    move-result-object v4

    .line 143
    if-nez v4, :cond_8

    .line 144
    .line 145
    new-instance v4, Lcom/transsnet/palmpay/core/bean/style_config/CornerRadius;

    .line 146
    .line 147
    invoke-direct {v4}, Lcom/transsnet/palmpay/core/bean/style_config/CornerRadius;-><init>()V

    .line 148
    .line 149
    .line 150
    :cond_8
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getStrokeWidth()Ljava/lang/Integer;

    .line 151
    .line 152
    .line 153
    move-result-object v5

    .line 154
    if-eqz v5, :cond_9

    .line 155
    .line 156
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 157
    .line 158
    .line 159
    move-result v5

    .line 160
    goto :goto_4

    .line 161
    :cond_9
    move v5, v1

    .line 162
    :goto_4
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getStrokeColor()Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v6

    .line 166
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 167
    .line 168
    .line 169
    move-result v6

    .line 170
    if-nez v6, :cond_c

    .line 171
    .line 172
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getStrokeColor()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v6

    .line 176
    if-nez v6, :cond_a

    .line 177
    .line 178
    move-object v6, v3

    .line 179
    :cond_a
    new-instance v7, Lkotlin/text/Regex;

    .line 180
    .line 181
    invoke-direct {v7, v2}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v7, v6}, Lkotlin/text/Regex;->b(Ljava/lang/CharSequence;)Z

    .line 185
    .line 186
    .line 187
    move-result v2

    .line 188
    if-eqz v2, :cond_c

    .line 189
    .line 190
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getStrokeColor()Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object p1

    .line 194
    if-nez p1, :cond_b

    .line 195
    .line 196
    goto :goto_5

    .line 197
    :cond_b
    move-object v3, p1

    .line 198
    :goto_5
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 199
    .line 200
    .line 201
    move-result v1

    .line 202
    :cond_c
    invoke-static {v0, v4, v5, v1}, LEb/a;->h(Ljava/lang/String;Lcom/transsnet/palmpay/core/bean/style_config/CornerRadius;II)Landroid/graphics/drawable/StateListDrawable;

    .line 203
    .line 204
    .line 205
    move-result-object p1

    .line 206
    invoke-virtual {p0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 207
    .line 208
    .line 209
    return-void

    .line 210
    :catchall_0
    move-exception p0

    .line 211
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 212
    .line 213
    .line 214
    :cond_d
    return-void
.end method

.method public static b(Landroid/view/ViewGroup;Ljava/lang/Float;Ljava/lang/Float;)V
    .locals 2

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    if-nez p2, :cond_0

    .line 4
    .line 5
    goto/16 :goto_0

    .line 6
    .line 7
    :cond_0
    if-nez p0, :cond_1

    .line 8
    .line 9
    goto/16 :goto_0

    .line 10
    .line 11
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-nez v0, :cond_2

    .line 16
    .line 17
    goto/16 :goto_0

    .line 18
    .line 19
    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    instance-of v1, v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 24
    .line 25
    if-eqz v1, :cond_5

    .line 26
    .line 27
    if-eqz p1, :cond_3

    .line 28
    .line 29
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    move-object v1, v0

    .line 34
    check-cast v1, Landroid/widget/FrameLayout$LayoutParams;

    .line 35
    .line 36
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    iput p1, v1, Landroid/widget/FrameLayout$LayoutParams;->height:I

    .line 41
    .line 42
    :cond_3
    if-eqz p2, :cond_4

    .line 43
    .line 44
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    move-object p2, v0

    .line 49
    check-cast p2, Landroid/widget/FrameLayout$LayoutParams;

    .line 50
    .line 51
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 52
    .line 53
    .line 54
    move-result p1

    .line 55
    iput p1, p2, Landroid/widget/FrameLayout$LayoutParams;->width:I

    .line 56
    .line 57
    :cond_4
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :cond_5
    instance-of v1, v0, Landroid/widget/RelativeLayout$LayoutParams;

    .line 62
    .line 63
    if-eqz v1, :cond_8

    .line 64
    .line 65
    if-eqz p1, :cond_6

    .line 66
    .line 67
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 68
    .line 69
    .line 70
    move-result p1

    .line 71
    move-object v1, v0

    .line 72
    check-cast v1, Landroid/widget/RelativeLayout$LayoutParams;

    .line 73
    .line 74
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 75
    .line 76
    .line 77
    move-result p1

    .line 78
    iput p1, v1, Landroid/widget/RelativeLayout$LayoutParams;->height:I

    .line 79
    .line 80
    :cond_6
    if-eqz p2, :cond_7

    .line 81
    .line 82
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    move-object p2, v0

    .line 87
    check-cast p2, Landroid/widget/RelativeLayout$LayoutParams;

    .line 88
    .line 89
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 90
    .line 91
    .line 92
    move-result p1

    .line 93
    iput p1, p2, Landroid/widget/RelativeLayout$LayoutParams;->width:I

    .line 94
    .line 95
    :cond_7
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :cond_8
    instance-of v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 100
    .line 101
    if-eqz v1, :cond_b

    .line 102
    .line 103
    if-eqz p1, :cond_9

    .line 104
    .line 105
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 106
    .line 107
    .line 108
    move-result p1

    .line 109
    move-object v1, v0

    .line 110
    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 111
    .line 112
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 113
    .line 114
    .line 115
    move-result p1

    .line 116
    iput p1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 117
    .line 118
    :cond_9
    if-eqz p2, :cond_a

    .line 119
    .line 120
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 121
    .line 122
    .line 123
    move-result p1

    .line 124
    move-object p2, v0

    .line 125
    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;

    .line 126
    .line 127
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 128
    .line 129
    .line 130
    move-result p1

    .line 131
    iput p1, p2, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 132
    .line 133
    :cond_a
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 134
    .line 135
    .line 136
    return-void

    .line 137
    :cond_b
    instance-of v1, v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 138
    .line 139
    if-eqz v1, :cond_e

    .line 140
    .line 141
    if-eqz p1, :cond_c

    .line 142
    .line 143
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 144
    .line 145
    .line 146
    move-result p1

    .line 147
    move-object v1, v0

    .line 148
    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 149
    .line 150
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 151
    .line 152
    .line 153
    move-result p1

    .line 154
    iput p1, v1, Landroid/widget/LinearLayout$LayoutParams;->height:I

    .line 155
    .line 156
    :cond_c
    if-eqz p2, :cond_d

    .line 157
    .line 158
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 159
    .line 160
    .line 161
    move-result p1

    .line 162
    move-object p2, v0

    .line 163
    check-cast p2, Landroid/widget/LinearLayout$LayoutParams;

    .line 164
    .line 165
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 166
    .line 167
    .line 168
    move-result p1

    .line 169
    iput p1, p2, Landroid/widget/LinearLayout$LayoutParams;->width:I

    .line 170
    .line 171
    :cond_d
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 172
    .line 173
    .line 174
    return-void

    .line 175
    :cond_e
    instance-of v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 176
    .line 177
    if-eqz v1, :cond_11

    .line 178
    .line 179
    if-eqz p1, :cond_f

    .line 180
    .line 181
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 182
    .line 183
    .line 184
    move-result p1

    .line 185
    move-object v1, v0

    .line 186
    check-cast v1, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 187
    .line 188
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 189
    .line 190
    .line 191
    move-result p1

    .line 192
    iput p1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 193
    .line 194
    :cond_f
    if-eqz p2, :cond_10

    .line 195
    .line 196
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 197
    .line 198
    .line 199
    move-result p1

    .line 200
    move-object p2, v0

    .line 201
    check-cast p2, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 202
    .line 203
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ScreenUtils;->dip2px(F)I

    .line 204
    .line 205
    .line 206
    move-result p1

    .line 207
    iput p1, p2, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 208
    .line 209
    :cond_10
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 210
    .line 211
    .line 212
    :cond_11
    :goto_0
    return-void
.end method

.method public static c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V
    .locals 3

    .line 1
    :try_start_0
    invoke-static {p0, p1}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_2

    .line 5
    .line 6
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;->getTextColor()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-nez v1, :cond_0

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v0, 0x0

    .line 20
    :goto_0
    if-eqz v0, :cond_1

    .line 21
    .line 22
    new-instance v1, Lkotlin/text/Regex;

    .line 23
    .line 24
    const-string v2, "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$"

    .line 25
    .line 26
    invoke-direct {v1, v2}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, v0}, Lkotlin/text/Regex;->b(Ljava/lang/CharSequence;)Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    if-eqz p0, :cond_1

    .line 36
    .line 37
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 42
    .line 43
    .line 44
    :cond_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;->getTextSize()Ljava/lang/Float;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    if-eqz p1, :cond_2

    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    if-eqz p0, :cond_2

    .line 55
    .line 56
    const/4 v0, 0x2

    .line 57
    invoke-virtual {p0, v0, p1}, Landroid/widget/TextView;->setTextSize(IF)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :catchall_0
    move-exception p0

    .line 62
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 63
    .line 64
    .line 65
    :cond_2
    return-void
.end method
