.class public final LJc/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static DEPOSIT:I = 0x7f0a000a

.field public static WITHDRAW:I = 0x7f0a002c

.field public static abl_month_tv:I = 0x7f0a0039

.field public static adView:I = 0x7f0a00c4

.field public static amountViewDivider:I = 0x7f0a0119

.field public static areaWv:I = 0x7f0a016d

.field public static barrier:I = 0x7f0a01e6

.field public static billList:I = 0x7f0a0214

.field public static btnPlanBreak:I = 0x7f0a02a0

.field public static btnPlanContinue:I = 0x7f0a02a1

.field public static btnPlanGoBack:I = 0x7f0a02a2

.field public static btnRepay:I = 0x7f0a02a6

.field public static buttonContainer:I = 0x7f0a02d6

.field public static camera_preview_fl:I = 0x7f0a02fa

.field public static camera_preview_tips:I = 0x7f0a02fb

.field public static cashBoxIntroductionView:I = 0x7f0a030d

.field public static cbIntrol:I = 0x7f0a031c

.field public static centerArrow:I = 0x7f0a037c

.field public static ckProtocol:I = 0x7f0a03e7

.field public static clTrialCash:I = 0x7f0a040c

.field public static clsAddMoney:I = 0x7f0a049b

.field public static clsAdvance:I = 0x7f0a049c

.field public static clsAgreement:I = 0x7f0a049d

.field public static clsContainer:I = 0x7f0a049e

.field public static clsDetail:I = 0x7f0a049f

.field public static cls_contain:I = 0x7f0a04a0

.field public static cls_frame:I = 0x7f0a04a1

.field public static cls_withdraw:I = 0x7f0a04a2

.field public static container:I = 0x7f0a0530

.field public static countdown_shot_cl:I = 0x7f0a0565

.field public static countdown_shot_tv:I = 0x7f0a0566

.field public static createAutoItem:I = 0x7f0a0595

.field public static csl_agree:I = 0x7f0a06b9

.field public static ctb:I = 0x7f0a06bd

.field public static ctl_withdraw:I = 0x7f0a06c2

.field public static done_tv:I = 0x7f0a076a

.field public static editTextOtherReasons:I = 0x7f0a079b

.field public static emptyView:I = 0x7f0a07ac

.field public static etAmount:I = 0x7f0a07c2

.field public static etGoal:I = 0x7f0a07c5

.field public static flVsBadge:I = 0x7f0a0971

.field public static frozenLayout:I = 0x7f0a09dc

.field public static goalViewDivider:I = 0x7f0a0a0c

.field public static groupNewUserNoLotter:I = 0x7f0a0a20

.field public static groupOldUser:I = 0x7f0a0a24

.field public static groupProtocol:I = 0x7f0a0a28

.field public static groupUnLogin:I = 0x7f0a0a2d

.field public static groupWinLotteryPrize:I = 0x7f0a0a31

.field public static iconImageInfo:I = 0x7f0a0a7a

.field public static imageViewClose:I = 0x7f0a0aa2

.field public static imageViewNext:I = 0x7f0a0aa9

.field public static imageViewRight:I = 0x7f0a0aac

.field public static item_name:I = 0x7f0a0b95

.field public static itvTitle:I = 0x7f0a0ba0

.field public static itv_due_date:I = 0x7f0a0ba2

.field public static itv_status:I = 0x7f0a0ba4

.field public static itv_status_text:I = 0x7f0a0ba5

.field public static itv_total_amount:I = 0x7f0a0ba6

.field public static iv:I = 0x7f0a0ba7

.field public static ivAdvancePanelBg:I = 0x7f0a0baf

.field public static ivArrow:I = 0x7f0a0bba

.field public static ivArrowRight:I = 0x7f0a0bbd

.field public static ivBanner:I = 0x7f0a0bc9

.field public static ivBg:I = 0x7f0a0bcc

.field public static ivBreakPanelBg:I = 0x7f0a0bd6

.field public static ivCampaignDiceBg:I = 0x7f0a0bdd

.field public static ivCheckAgreement:I = 0x7f0a0be9

.field public static ivChecked:I = 0x7f0a0bea

.field public static ivClose:I = 0x7f0a0bee

.field public static ivCollapse:I = 0x7f0a0bf0

.field public static ivContent:I = 0x7f0a0bf5

.field public static ivDivergenceBg:I = 0x7f0a0c0d

.field public static ivFirstCheck:I = 0x7f0a0c27

.field public static ivFrozonWarn:I = 0x7f0a0c2c

.field public static ivIcon:I = 0x7f0a0c39

.field public static ivInterest:I = 0x7f0a0c4b

.field public static ivLoading:I = 0x7f0a0c65

.field public static ivNewUserCampaignTop:I = 0x7f0a0c76

.field public static ivNewerTip:I = 0x7f0a0c77

.field public static ivOldCampaignDice:I = 0x7f0a0c81

.field public static ivOldCashboxUsersText:I = 0x7f0a0c82

.field public static ivOrderResult:I = 0x7f0a0c84

.field public static ivProductIcon:I = 0x7f0a0c98

.field public static ivRateWarn:I = 0x7f0a0c9e

.field public static ivRefresh:I = 0x7f0a0ca1

.field public static ivSecCheck:I = 0x7f0a0cad

.field public static ivSecurityGuaranteed:I = 0x7f0a0cb4

.field public static ivThirdCheck:I = 0x7f0a0ccd

.field public static ivToggleShowBalance:I = 0x7f0a0cda

.field public static ivTopBanner:I = 0x7f0a0cde

.field public static ivWarn:I = 0x7f0a0cf5

.field public static ivWinLotteryPrize:I = 0x7f0a0cf7

.field public static iv_arrow:I = 0x7f0a0d01

.field public static iv_banner:I = 0x7f0a0d0a

.field public static iv_cashbox:I = 0x7f0a0d1b

.field public static iv_left:I = 0x7f0a0d53

.field public static iv_listening:I = 0x7f0a0d55

.field public static iv_logo:I = 0x7f0a0d58

.field public static iv_middlePicUrl:I = 0x7f0a0d5a

.field public static iv_title:I = 0x7f0a0d8c

.field public static iv_trial_cash:I = 0x7f0a0d94

.field public static iv_trial_cash_bg:I = 0x7f0a0d95

.field public static iv_triangle:I = 0x7f0a0d96

.field public static ivheaderBanner:I = 0x7f0a0d9f

.field public static layoutADs:I = 0x7f0a0e0f

.field public static layoutAmount:I = 0x7f0a0e16

.field public static layoutAutoRenewalExtroInfo:I = 0x7f0a0e1d

.field public static layoutAutoSave:I = 0x7f0a0e1e

.field public static layoutAutoSaveOp:I = 0x7f0a0e1f

.field public static layoutAutoTransfer:I = 0x7f0a0e20

.field public static layoutBalanceInfo:I = 0x7f0a0e21

.field public static layoutBillOrderInfo:I = 0x7f0a0e26

.field public static layoutBottom:I = 0x7f0a0e29

.field public static layoutCancelAndTry:I = 0x7f0a0e2d

.field public static layoutCashReward:I = 0x7f0a0e30

.field public static layoutComplete:I = 0x7f0a0e32

.field public static layoutContainer:I = 0x7f0a0e33

.field public static layoutCustomerService:I = 0x7f0a0e3c

.field public static layoutEstimatedInterestReturnList:I = 0x7f0a0e49

.field public static layoutExtroInfo:I = 0x7f0a0e4b

.field public static layoutFixedSavings:I = 0x7f0a0e50

.field public static layoutGoal:I = 0x7f0a0e56

.field public static layoutHeader:I = 0x7f0a0e5a

.field public static layoutInfo:I = 0x7f0a0e5e

.field public static layoutInterestInfo:I = 0x7f0a0e63

.field public static layoutInterrestShow:I = 0x7f0a0e64

.field public static layoutMasterInfo:I = 0x7f0a0e72

.field public static layoutNext:I = 0x7f0a0e79

.field public static layoutOrderDetailInfo:I = 0x7f0a0e7f

.field public static layoutOrderInfo:I = 0x7f0a0e80

.field public static layoutOriginalTransaction:I = 0x7f0a0e81

.field public static layoutParent:I = 0x7f0a0e84

.field public static layoutPaybackDate:I = 0x7f0a0e85

.field public static layoutPayoutCard:I = 0x7f0a0e88

.field public static layoutPlanCommonInfo:I = 0x7f0a0e89

.field public static layoutPlanDetailInfo:I = 0x7f0a0e8a

.field public static layoutPlanExtroInfo:I = 0x7f0a0e8b

.field public static layoutPlanInfo:I = 0x7f0a0e8c

.field public static layoutProtocol:I = 0x7f0a0e8f

.field public static layoutRateInfo:I = 0x7f0a0e90

.field public static layoutRoot:I = 0x7f0a0e9d

.field public static layoutSad:I = 0x7f0a0e9f

.field public static layoutSecInfo:I = 0x7f0a0ea3

.field public static layoutSecurityGuaranteed:I = 0x7f0a0ea5

.field public static layoutStrick:I = 0x7f0a0ea8

.field public static layoutTax:I = 0x7f0a0ead

.field public static layoutTotalInterestInfo:I = 0x7f0a0eb5

.field public static layoutTransFilter:I = 0x7f0a0eb6

.field public static layoutTransactionHistory:I = 0x7f0a0eb8

.field public static layoutTransactionInfo:I = 0x7f0a0eb9

.field public static layoutTransactionInfoExtend:I = 0x7f0a0eba

.field public static layout_close:I = 0x7f0a0ec9

.field public static layout_open:I = 0x7f0a0ed3

.field public static leftPanel:I = 0x7f0a0ee5

.field public static llAdvanceChildModule:I = 0x7f0a0f1a

.field public static llAdvanceContent:I = 0x7f0a0f1b

.field public static llAdvanceModule:I = 0x7f0a0f1c

.field public static llBreakContent:I = 0x7f0a0f27

.field public static llContent:I = 0x7f0a0f2c

.field public static llCreatePlan:I = 0x7f0a0f32

.field public static llLeft:I = 0x7f0a0f4e

.field public static llRight:I = 0x7f0a0f6e

.field public static llTitle:I = 0x7f0a0f7f

.field public static ll_add_money:I = 0x7f0a0f92

.field public static ll_basic_container:I = 0x7f0a0f9a

.field public static ll_container:I = 0x7f0a0fa4

.field public static ll_container_top:I = 0x7f0a0fa6

.field public static ll_frame1:I = 0x7f0a0fb1

.field public static ll_frame2:I = 0x7f0a0fb2

.field public static ll_frame3:I = 0x7f0a0fb3

.field public static ll_frame4:I = 0x7f0a0fb4

.field public static modelNewCustomerSavings:I = 0x7f0a10fc

.field public static money_in_textViewSummary:I = 0x7f0a112d

.field public static money_out_textViewSummary:I = 0x7f0a112e

.field public static mtb:I = 0x7f0a114d

.field public static nsv:I = 0x7f0a1227

.field public static openBoxAnimView:I = 0x7f0a12a4

.field public static openNowAnimView:I = 0x7f0a12a5

.field public static paymentMethodItem:I = 0x7f0a13b4

.field public static photo_img:I = 0x7f0a13ff

.field public static plan_progress_pb:I = 0x7f0a140c

.field public static progressView:I = 0x7f0a143b

.field public static review_photo_cl:I = 0x7f0a1536

.field public static rgIndicator:I = 0x7f0a1543

.field public static rightPanel:I = 0x7f0a1547

.field public static riv:I = 0x7f0a1555

.field public static rtvAccountStatus:I = 0x7f0a1596

.field public static rtvAdvance:I = 0x7f0a1598

.field public static rtvAgree:I = 0x7f0a1599

.field public static rtvAll:I = 0x7f0a159a

.field public static rtvBackToCash:I = 0x7f0a159c

.field public static rtvCancel:I = 0x7f0a15a0

.field public static rtvComplete:I = 0x7f0a15a1

.field public static rtvConfirm:I = 0x7f0a15a2

.field public static rtvCreateAccount:I = 0x7f0a15a4

.field public static rtvCreateNew:I = 0x7f0a15a5

.field public static rtvCreatePlan:I = 0x7f0a15a6

.field public static rtvGo:I = 0x7f0a15aa

.field public static rtvInterestRate:I = 0x7f0a15ac

.field public static rtvInvest:I = 0x7f0a15ad

.field public static rtvNext:I = 0x7f0a15ae

.field public static rtvOkay:I = 0x7f0a15b0

.field public static rtvPay:I = 0x7f0a15b1

.field public static rtvSave:I = 0x7f0a15b4

.field public static rtvSaveMore:I = 0x7f0a15b5

.field public static rtvSaveNow:I = 0x7f0a15b6

.field public static rtvSetBreak:I = 0x7f0a15b7

.field public static rtvSetMethod:I = 0x7f0a15b8

.field public static rtvSignIn:I = 0x7f0a15ba

.field public static rtvToCashBox:I = 0x7f0a15bc

.field public static rtvToggleAutoSave:I = 0x7f0a15bd

.field public static rtvTryAgain:I = 0x7f0a15be

.field public static rtvTurnOn:I = 0x7f0a15bf

.field public static rtvViewAll:I = 0x7f0a15c1

.field public static rtvWithdraw:I = 0x7f0a15c2

.field public static rvPayoutOptions:I = 0x7f0a15d8

.field public static rvProductList:I = 0x7f0a15dc

.field public static rvTransactionList:I = 0x7f0a15e7

.field public static sadView1:I = 0x7f0a1617

.field public static sadView2:I = 0x7f0a1618

.field public static saveNowAnimView:I = 0x7f0a1623

.field public static saveNowForFreeAnimView:I = 0x7f0a1624

.field public static space:I = 0x7f0a16d8

.field public static switchInterestWidget:I = 0x7f0a1751

.field public static switchStrictWidget:I = 0x7f0a1752

.field public static switchWidget:I = 0x7f0a1753

.field public static switchWidgetInterest:I = 0x7f0a1754

.field public static tabLayout:I = 0x7f0a1755

.field public static textViewCharacterCount:I = 0x7f0a1796

.field public static titleBar:I = 0x7f0a17e5

.field public static top_divider_view:I = 0x7f0a1810

.field public static totalBarrier:I = 0x7f0a181e

.field public static trialCashModule:I = 0x7f0a1843

.field public static try_again_tv:I = 0x7f0a1847

.field public static tv1:I = 0x7f0a184c

.field public static tv2:I = 0x7f0a1851

.field public static tv3:I = 0x7f0a1854

.field public static tvAddMoney:I = 0x7f0a186f

.field public static tvAdvanceAmount:I = 0x7f0a187a

.field public static tvAdvanceTitle:I = 0x7f0a187b

.field public static tvAdvanceValue:I = 0x7f0a187c

.field public static tvAggainNot:I = 0x7f0a1882

.field public static tvAgreementContent:I = 0x7f0a1884

.field public static tvAmount:I = 0x7f0a1887

.field public static tvAmountDesc:I = 0x7f0a188a

.field public static tvAmountError:I = 0x7f0a188b

.field public static tvAmountTitle:I = 0x7f0a1890

.field public static tvAmountUnit:I = 0x7f0a1891

.field public static tvAutoRemark:I = 0x7f0a189c

.field public static tvAutoRenel:I = 0x7f0a189d

.field public static tvAutoRenew:I = 0x7f0a189e

.field public static tvAutoSave:I = 0x7f0a189f

.field public static tvAutoSaveDesc:I = 0x7f0a18a0

.field public static tvAutoSaveSec:I = 0x7f0a18a1

.field public static tvAutoStatus:I = 0x7f0a18a2

.field public static tvBalance:I = 0x7f0a18ab

.field public static tvBalanceAmount:I = 0x7f0a18ac

.field public static tvBeforeInvestingTitle:I = 0x7f0a18b3

.field public static tvBreakTitle:I = 0x7f0a18d1

.field public static tvCancel:I = 0x7f0a18df

.field public static tvCashBoxTitle:I = 0x7f0a18e8

.field public static tvConfirm:I = 0x7f0a190b

.field public static tvContent:I = 0x7f0a190e

.field public static tvCouponAmount:I = 0x7f0a191c

.field public static tvCouponContent:I = 0x7f0a191d

.field public static tvCouponTitle:I = 0x7f0a1923

.field public static tvCouponsTips:I = 0x7f0a1927

.field public static tvCreatePlanTitle:I = 0x7f0a1928

.field public static tvCurrentAmount:I = 0x7f0a1931

.field public static tvCurrentDate:I = 0x7f0a1932

.field public static tvCurrentTitle:I = 0x7f0a1935

.field public static tvCustomerService:I = 0x7f0a1936

.field public static tvDailyFee:I = 0x7f0a1939

.field public static tvDailyIncome:I = 0x7f0a193b

.field public static tvDepositLimitAmountTips:I = 0x7f0a1952

.field public static tvDesc:I = 0x7f0a1954

.field public static tvDisableInterest:I = 0x7f0a195b

.field public static tvDueDate:I = 0x7f0a1964

.field public static tvDuration:I = 0x7f0a1966

.field public static tvDurationDay:I = 0x7f0a1967

.field public static tvDurationNum:I = 0x7f0a1968

.field public static tvEarlyDialy:I = 0x7f0a1969

.field public static tvEstimatedInterest:I = 0x7f0a1979

.field public static tvExpenditureAmount:I = 0x7f0a1981

.field public static tvExperienceGoldBalance:I = 0x7f0a1982

.field public static tvExperienceGoldUnclaimed:I = 0x7f0a1983

.field public static tvFAQ:I = 0x7f0a198e

.field public static tvFeeValue:I = 0x7f0a1997

.field public static tvFrozenText:I = 0x7f0a19ad

.field public static tvFundName:I = 0x7f0a19b3

.field public static tvGoalAutoDesc:I = 0x7f0a19b6

.field public static tvGoalDesc:I = 0x7f0a19b7

.field public static tvGoalError:I = 0x7f0a19b8

.field public static tvHoldAmount:I = 0x7f0a19c3

.field public static tvIncomeAmount:I = 0x7f0a19cb

.field public static tvInfoSubValue:I = 0x7f0a19d6

.field public static tvInfoTitle:I = 0x7f0a19d7

.field public static tvInfoValue:I = 0x7f0a19d8

.field public static tvInterest:I = 0x7f0a19dd

.field public static tvInterestAmount:I = 0x7f0a19de

.field public static tvInterestAmountTitle:I = 0x7f0a19df

.field public static tvInterestDay:I = 0x7f0a19e1

.field public static tvInterestPa:I = 0x7f0a19e4

.field public static tvInterestRate:I = 0x7f0a19e5

.field public static tvInterestSec:I = 0x7f0a19e6

.field public static tvInterestValue:I = 0x7f0a19e7

.field public static tvKeepInterest:I = 0x7f0a19fc

.field public static tvLockDate:I = 0x7f0a1a3c

.field public static tvLoseInterest:I = 0x7f0a1a43

.field public static tvMaturedOrderNum:I = 0x7f0a1a45

.field public static tvMaturedTips:I = 0x7f0a1a46

.field public static tvMaturityDate:I = 0x7f0a1a47

.field public static tvMiddleAdContent:I = 0x7f0a1a4e

.field public static tvMiddleAdTitle:I = 0x7f0a1a4f

.field public static tvMore:I = 0x7f0a1a5d

.field public static tvMyState:I = 0x7f0a1a67

.field public static tvName:I = 0x7f0a1a68

.field public static tvNextAmount:I = 0x7f0a1a71

.field public static tvNextDate:I = 0x7f0a1a72

.field public static tvNextTitle:I = 0x7f0a1a75

.field public static tvOpenNow:I = 0x7f0a1a98

.field public static tvOrderAmount:I = 0x7f0a1a9c

.field public static tvOrderDesc:I = 0x7f0a1a9e

.field public static tvOrderName:I = 0x7f0a1a9f

.field public static tvOrderStatus:I = 0x7f0a1aa1

.field public static tvPaidCashBoxAccount:I = 0x7f0a1aac

.field public static tvPalmpayBalance:I = 0x7f0a1aaf

.field public static tvPay:I = 0x7f0a1ab1

.field public static tvPaybackDate:I = 0x7f0a1ab2

.field public static tvPaybackDateDesc:I = 0x7f0a1ab3

.field public static tvPayment:I = 0x7f0a1ab4

.field public static tvPayoutTips:I = 0x7f0a1abb

.field public static tvPercent:I = 0x7f0a1abe

.field public static tvPlanStatus:I = 0x7f0a1ad1

.field public static tvPlanStatusDesc:I = 0x7f0a1ad2

.field public static tvPlanTitle:I = 0x7f0a1ad3

.field public static tvPreviewPlanProtocol:I = 0x7f0a1ade

.field public static tvPrincipalAmount:I = 0x7f0a1ae3

.field public static tvProductIncreaseUp:I = 0x7f0a1aea

.field public static tvProductName:I = 0x7f0a1aeb

.field public static tvProductRatio:I = 0x7f0a1aed

.field public static tvProtocol:I = 0x7f0a1af2

.field public static tvRecentTransaction:I = 0x7f0a1afe

.field public static tvRecommendBadge:I = 0x7f0a1b03

.field public static tvRepayAnytime:I = 0x7f0a1b0b

.field public static tvRepayableAmount:I = 0x7f0a1b0d

.field public static tvReport:I = 0x7f0a1b15

.field public static tvSecurity:I = 0x7f0a1b2e

.field public static tvSecurityGuaranteed:I = 0x7f0a1b2f

.field public static tvSetting:I = 0x7f0a1b39

.field public static tvShareReceipt:I = 0x7f0a1b3e

.field public static tvSkip:I = 0x7f0a1b47

.field public static tvState:I = 0x7f0a1b4b

.field public static tvStatus:I = 0x7f0a1b4c

.field public static tvSwitchStatus:I = 0x7f0a1b60

.field public static tvTab:I = 0x7f0a1b63

.field public static tvTaxAmountDesc:I = 0x7f0a1b6f

.field public static tvTaxInformation:I = 0x7f0a1b70

.field public static tvTaxInformationContent:I = 0x7f0a1b71

.field public static tvTips:I = 0x7f0a1b8d

.field public static tvTitle:I = 0x7f0a1b8e

.field public static tvTotalBackAmount:I = 0x7f0a1b9e

.field public static tvTotalInterestAmount:I = 0x7f0a1ba0

.field public static tvTotalPaybackAmount:I = 0x7f0a1ba6

.field public static tvTotalPaybackKey:I = 0x7f0a1ba7

.field public static tvTotalReturnAmount:I = 0x7f0a1baa

.field public static tvTotalSavingsBalanceTitle:I = 0x7f0a1bab

.field public static tvTotalTitle:I = 0x7f0a1bac

.field public static tvTotalValue:I = 0x7f0a1bad

.field public static tvTransactionAmount:I = 0x7f0a1bb1

.field public static tvTransactionName:I = 0x7f0a1bb2

.field public static tvTransactionStatus:I = 0x7f0a1bb3

.field public static tvTransactionTime:I = 0x7f0a1bb4

.field public static tvTransferAgreement:I = 0x7f0a1bb5

.field public static tvTrialCashYesterdayReturnAmount:I = 0x7f0a1bbd

.field public static tvTurnOffAutoSave:I = 0x7f0a1bc2

.field public static tvUpto:I = 0x7f0a1bd5

.field public static tvWithdrawEarnInterest:I = 0x7f0a1c02

.field public static tvWithdrawals:I = 0x7f0a1c03

.field public static tvYesterdayReturn:I = 0x7f0a1c05

.field public static tvYesterdayReturnAmount:I = 0x7f0a1c06

.field public static tv_advance_label:I = 0x7f0a1c16

.field public static tv_agree:I = 0x7f0a1c17

.field public static tv_fee_label:I = 0x7f0a1c8b

.field public static tv_interval:I = 0x7f0a1cb7

.field public static tv_link:I = 0x7f0a1cc8

.field public static tv_rate_name:I = 0x7f0a1d20

.field public static tv_remark:I = 0x7f0a1d2b

.field public static tv_sec:I = 0x7f0a1d3e

.field public static tv_time_limit:I = 0x7f0a1d65

.field public static tv_total_interest:I = 0x7f0a1d76

.field public static tv_withdraw:I = 0x7f0a1d9b

.field public static vAutoRenewalLine:I = 0x7f0a1dc5

.field public static vDivider:I = 0x7f0a1dce

.field public static vLine:I = 0x7f0a1dd5

.field public static v_temp:I = 0x7f0a1dfa

.field public static v_trial_line:I = 0x7f0a1dfd

.field public static viewAd:I = 0x7f0a1e0d

.field public static viewCustomerService:I = 0x7f0a1e22

.field public static viewDivider:I = 0x7f0a1e26

.field public static viewEmpty:I = 0x7f0a1e27

.field public static viewEstimatedInterest:I = 0x7f0a1e29

.field public static viewMarquee:I = 0x7f0a1e46

.field public static viewPager:I = 0x7f0a1e54

.field public static viewReceipt:I = 0x7f0a1e5d

.field public static wvDay:I = 0x7f0a1ee5

.field public static wvMonth:I = 0x7f0a1ee6

.field public static wvYear:I = 0x7f0a1ee7


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
