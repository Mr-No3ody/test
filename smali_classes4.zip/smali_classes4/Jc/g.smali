.class public final LJc/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static CashBoxEstimatedInterestView:[I

.field public static CashBoxEstimatedInterestView_esrv_type:I


# direct methods
.method public static constructor <clinit>()V
    .locals 1

    .line 1
    const v0, 0x7f04034d

    .line 2
    .line 3
    .line 4
    filled-new-array {v0}, [I

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sput-object v0, LJc/g;->CashBoxEstimatedInterestView:[I

    .line 9
    .line 10
    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
