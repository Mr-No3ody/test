.class public final LJc/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static mm_3_common_desc:I = 0x7f141042

.field public static mm_acount_name:I = 0x7f141043

.field public static mm_action_exit:I = 0x7f141044

.field public static mm_action_later:I = 0x7f141045

.field public static mm_action_okay:I = 0x7f141046

.field public static mm_action_save_now:I = 0x7f141047

.field public static mm_action_upgrade:I = 0x7f141048

.field public static mm_advance_repayment:I = 0x7f141049

.field public static mm_advance_repayment_desc:I = 0x7f14104a

.field public static mm_all_matured_tips:I = 0x7f14104b

.field public static mm_all_product_sell_out_desc:I = 0x7f14104c

.field public static mm_amount:I = 0x7f14104d

.field public static mm_amount_currency_symbol:I = 0x7f14104e

.field public static mm_amount_in_renewal:I = 0x7f14104f

.field public static mm_annual_interest_rates:I = 0x7f141050

.field public static mm_auto_enable:I = 0x7f141051

.field public static mm_auto_note_payaccount:I = 0x7f141052

.field public static mm_auto_renewal:I = 0x7f141053

.field public static mm_auto_renewal_dialog_text:I = 0x7f141054

.field public static mm_auto_save:I = 0x7f141055

.field public static mm_auto_save_amount:I = 0x7f141056

.field public static mm_auto_save_off_tips:I = 0x7f141057

.field public static mm_auto_save_on_tips:I = 0x7f141058

.field public static mm_auto_save_terms:I = 0x7f141059

.field public static mm_auto_save_to_cashbox:I = 0x7f14105a

.field public static mm_auto_save_turned_off_tips:I = 0x7f14105b

.field public static mm_auto_save_turned_on:I = 0x7f14105c

.field public static mm_auto_times_renewad:I = 0x7f14105d

.field public static mm_automatic_renewal:I = 0x7f14105e

.field public static mm_automatic_transfer_into_cashbox:I = 0x7f14105f

.field public static mm_available_savings_products:I = 0x7f141060

.field public static mm_back_to_cashbox:I = 0x7f141061

.field public static mm_before_break:I = 0x7f141062

.field public static mm_break_date:I = 0x7f141063

.field public static mm_break_interest_cycles:I = 0x7f141064

.field public static mm_break_interest_cycles_forfeited:I = 0x7f141065

.field public static mm_break_paid_to:I = 0x7f141066

.field public static mm_break_remark:I = 0x7f141067

.field public static mm_break_strict_desc:I = 0x7f141068

.field public static mm_capped_title:I = 0x7f141069

.field public static mm_cash_box_add_money:I = 0x7f14106a

.field public static mm_cash_box_deposit_tips:I = 0x7f14106b

.field public static mm_cash_box_lose_lottery:I = 0x7f14106c

.field public static mm_cash_box_protocol:I = 0x7f14106d

.field public static mm_cash_box_terms_and_conditions:I = 0x7f14106e

.field public static mm_cash_box_transaction_history:I = 0x7f14106f

.field public static mm_cash_box_withdraw_header_tips:I = 0x7f141070

.field public static mm_cash_box_withdraw_tips:I = 0x7f141071

.field public static mm_cash_box_withdraw_title:I = 0x7f141072

.field public static mm_cash_rewards:I = 0x7f141073

.field public static mm_cashbox_auto_save_agree:I = 0x7f141074

.field public static mm_cashbox_auto_save_idle_funds_tips:I = 0x7f141075

.field public static mm_cashbox_auto_save_make_transfer:I = 0x7f141076

.field public static mm_cashbox_auto_save_manually_tips:I = 0x7f141077

.field public static mm_cashbox_auto_save_tips:I = 0x7f141078

.field public static mm_cashbox_auto_save_title:I = 0x7f141079

.field public static mm_cashbox_auto_save_transfer_agreement:I = 0x7f14107a

.field public static mm_cashbox_auto_withdraw_for_free:I = 0x7f14107b

.field public static mm_cashbox_balance:I = 0x7f14107c

.field public static mm_cashbox_deposit:I = 0x7f14107d

.field public static mm_cashbox_deposit_limit_amount_tips:I = 0x7f14107e

.field public static mm_cashbox_maximum_limit_tips:I = 0x7f14107f

.field public static mm_cashbox_t3_maximum_limit_tips:I = 0x7f141080

.field public static mm_cashbox_withdraw:I = 0x7f141081

.field public static mm_check_details:I = 0x7f141082

.field public static mm_completion_time:I = 0x7f141083

.field public static mm_confirm_plan_protocol:I = 0x7f141084

.field public static mm_contact_customer_service:I = 0x7f141085

.field public static mm_coupon_paid_into_cashbox_account:I = 0x7f141086

.field public static mm_create_cash_box_coupon_order_failed_title:I = 0x7f141087

.field public static mm_create_cash_box_coupon_order_success_content:I = 0x7f141088

.field public static mm_create_cash_box_coupon_order_success_title:I = 0x7f141089

.field public static mm_create_plan:I = 0x7f14108a

.field public static mm_create_plan_title:I = 0x7f14108b

.field public static mm_creating_plan_title:I = 0x7f14108c

.field public static mm_customer_service:I = 0x7f14108d

.field public static mm_daily_income:I = 0x7f14108e

.field public static mm_deposit_amount:I = 0x7f14108f

.field public static mm_detail_account_frozen_desc:I = 0x7f141090

.field public static mm_details_of_your_plan:I = 0x7f141091

.field public static mm_duration_days:I = 0x7f141092

.field public static mm_earning_report:I = 0x7f141093

.field public static mm_earyly_withdrawal_fee:I = 0x7f141094

.field public static mm_estimated_interest_loss:I = 0x7f141095

.field public static mm_estimated_interest_return:I = 0x7f141096

.field public static mm_expected_interest_currency_symbol:I = 0x7f141097

.field public static mm_fb_open_code_title:I = 0x7f141098

.field public static mm_fixed_saving_payout_tips:I = 0x7f141099

.field public static mm_fixed_savings_investment:I = 0x7f14109a

.field public static mm_fixed_savings_options:I = 0x7f14109b

.field public static mm_fixed_savings_payout:I = 0x7f14109c

.field public static mm_fixed_savings_title:I = 0x7f14109d

.field public static mm_frozen_title:I = 0x7f14109e

.field public static mm_get_started:I = 0x7f14109f

.field public static mm_history_balance:I = 0x7f1410a0

.field public static mm_input_amount_limit:I = 0x7f1410a1

.field public static mm_input_goal_limit:I = 0x7f1410a2

.field public static mm_interest_currency_symbol:I = 0x7f1410a3

.field public static mm_interest_earned:I = 0x7f1410a4

.field public static mm_interest_earned_remark:I = 0x7f1410a5

.field public static mm_interest_expected_value:I = 0x7f1410a6

.field public static mm_interest_lost:I = 0x7f1410a7

.field public static mm_interest_rate:I = 0x7f1410a8

.field public static mm_interest_rate_by_tax_tips:I = 0x7f1410a9

.field public static mm_interest_value:I = 0x7f1410aa

.field public static mm_limit_exceeds:I = 0x7f1410ab

.field public static mm_limit_exceeds_desc:I = 0x7f1410ac

.field public static mm_loading_first_page_desc:I = 0x7f1410ad

.field public static mm_loading_first_page_title:I = 0x7f1410ae

.field public static mm_loading_second_page_desc:I = 0x7f1410af

.field public static mm_loading_second_page_title:I = 0x7f1410b0

.field public static mm_loading_skip:I = 0x7f1410b1

.field public static mm_loading_third_page_desc:I = 0x7f1410b2

.field public static mm_loading_third_page_title:I = 0x7f1410b3

.field public static mm_matures_into_your:I = 0x7f1410b4

.field public static mm_matures_into_your_tips:I = 0x7f1410b5

.field public static mm_maturity_date:I = 0x7f1410b6

.field public static mm_maturity_date_auto_tips:I = 0x7f1410b7

.field public static mm_maturity_date_tips:I = 0x7f1410b8

.field public static mm_maturity_duration_day:I = 0x7f1410b9

.field public static mm_money_in_amount:I = 0x7f1410ba

.field public static mm_money_out_amount:I = 0x7f1410bb

.field public static mm_my_state:I = 0x7f1410bc

.field public static mm_no_product_for_sale:I = 0x7f1410bd

.field public static mm_no_slots_available:I = 0x7f1410be

.field public static mm_no_transaction_record:I = 0x7f1410bf

.field public static mm_palmpay_balance:I = 0x7f1410c0

.field public static mm_payment_amount:I = 0x7f1410c1

.field public static mm_payment_mature:I = 0x7f1410c2

.field public static mm_payout_amount:I = 0x7f1410c3

.field public static mm_payout_options:I = 0x7f1410c4

.field public static mm_payout_options_content:I = 0x7f1410c5

.field public static mm_payout_options_terms_conditions:I = 0x7f1410c6

.field public static mm_plan_cashbox_balance:I = 0x7f1410c7

.field public static mm_plan_detail_hold_desc:I = 0x7f1410c8

.field public static mm_plan_detail_hold_desc2:I = 0x7f1410c9

.field public static mm_plan_detail_hold_desc2_renewal:I = 0x7f1410ca

.field public static mm_plan_detail_hold_l3_desc:I = 0x7f1410cb

.field public static mm_plan_detail_title:I = 0x7f1410cc

.field public static mm_plan_palmpay_balance:I = 0x7f1410cd

.field public static mm_plan_status_break:I = 0x7f1410ce

.field public static mm_plan_status_break_op:I = 0x7f1410cf

.field public static mm_plan_status_hold:I = 0x7f1410d0

.field public static mm_plan_status_investing:I = 0x7f1410d1

.field public static mm_plan_status_paid:I = 0x7f1410d2

.field public static mm_plan_status_processing:I = 0x7f1410d3

.field public static mm_plan_status_processing_desc:I = 0x7f1410d4

.field public static mm_preview_plan_title:I = 0x7f1410d5

.field public static mm_principal_amount:I = 0x7f1410d6

.field public static mm_product_sell_out_desc:I = 0x7f1410d7

.field public static mm_read_cconsent_agreement:I = 0x7f1410d8

.field public static mm_receive_account:I = 0x7f1410d9

.field public static mm_recent_transaction:I = 0x7f1410da

.field public static mm_remaining_amount:I = 0x7f1410db

.field public static mm_renewal_amount:I = 0x7f1410dc

.field public static mm_renewal_interest_rate:I = 0x7f1410dd

.field public static mm_repay_now:I = 0x7f1410de

.field public static mm_save_more:I = 0x7f1410df

.field public static mm_saved_successfully:I = 0x7f1410e0

.field public static mm_saving_auto_renewal_close:I = 0x7f1410e1

.field public static mm_saving_auto_renewal_open_text:I = 0x7f1410e2

.field public static mm_saving_dis_strict:I = 0x7f1410e3

.field public static mm_saving_open_strict:I = 0x7f1410e4

.field public static mm_saving_strict_warning:I = 0x7f1410e5

.field public static mm_saving_strict_warning_break:I = 0x7f1410e6

.field public static mm_savings_advance:I = 0x7f1410e7

.field public static mm_savings_duration:I = 0x7f1410e8

.field public static mm_savings_locked:I = 0x7f1410e9

.field public static mm_savings_plan_state_desc:I = 0x7f1410ea

.field public static mm_security_guaranteed:I = 0x7f1410eb

.field public static mm_sign_in:I = 0x7f1410ec

.field public static mm_sign_up:I = 0x7f1410ed

.field public static mm_start_data:I = 0x7f1410ee

.field public static mm_status:I = 0x7f1410ef

.field public static mm_strict_enabled:I = 0x7f1410f0

.field public static mm_submitted_fail:I = 0x7f1410f1

.field public static mm_submitted_succ:I = 0x7f1410f2

.field public static mm_successfully:I = 0x7f1410f3

.field public static mm_suspended_title:I = 0x7f1410f4

.field public static mm_tab_matured:I = 0x7f1410f5

.field public static mm_tab_saving:I = 0x7f1410f6

.field public static mm_tax_amount_desc:I = 0x7f1410f7

.field public static mm_tax_information_required:I = 0x7f1410f8

.field public static mm_terms_and_conditions:I = 0x7f1410f9

.field public static mm_terms_and_conditions_text:I = 0x7f1410fa

.field public static mm_total_interest:I = 0x7f1410fb

.field public static mm_total_interest_with_amount:I = 0x7f1410fc

.field public static mm_total_matured_nums:I = 0x7f1410fd

.field public static mm_total_payable:I = 0x7f1410fe

.field public static mm_total_payback:I = 0x7f1410ff

.field public static mm_total_savings:I = 0x7f141100

.field public static mm_total_value:I = 0x7f141101

.field public static mm_transaction_completed:I = 0x7f141102

.field public static mm_transaction_failed:I = 0x7f141103

.field public static mm_transaction_matured:I = 0x7f141104

.field public static mm_turn_off:I = 0x7f141105

.field public static mm_turn_off_auto_save:I = 0x7f141106

.field public static mm_turn_off_auto_save_detainment_tips:I = 0x7f141107

.field public static mm_turn_on_auto_save:I = 0x7f141108

.field public static mm_turn_on_now:I = 0x7f141109

.field public static mm_turn_on_turned_on_successfully:I = 0x7f14110a

.field public static mm_withdraw_amount:I = 0x7f14110b

.field public static mm_withdraw_earn_interest:I = 0x7f14110c

.field public static mm_withdraw_intercept_content:I = 0x7f14110d

.field public static mm_withdraw_intercept_title:I = 0x7f14110e

.field public static mm_withdraw_lost:I = 0x7f14110f

.field public static mm_withdraw_title:I = 0x7f141110

.field public static mm_withholding_tax:I = 0x7f141111

.field public static mm_yesterday_return:I = 0x7f141112


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
