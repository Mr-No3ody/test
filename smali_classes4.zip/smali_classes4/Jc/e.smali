.class public final LJc/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static mm_open_box:I = 0x7f130022


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
