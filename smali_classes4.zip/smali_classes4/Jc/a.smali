.class public final LJc/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static black:I = 0x7f060034

.field public static mm_bg_btn:I = 0x7f060503

.field public static mm_bg_confirm_btn:I = 0x7f060504

.field public static mm_bg_invest_btn:I = 0x7f060505

.field public static mm_color_000000_10:I = 0x7f060506

.field public static mm_color_1e1e1e_4:I = 0x7f060507

.field public static mm_color_202046:I = 0x7f060508

.field public static mm_color_263138:I = 0x7f060509

.field public static mm_color_38d79f:I = 0x7f06050a

.field public static mm_color_6306b2:I = 0x7f06050b

.field public static mm_color_858a8f:I = 0x7f06050c

.field public static mm_color_95a1ab:I = 0x7f06050d

.field public static mm_color_9ca2aa:I = 0x7f06050e

.field public static mm_color_auto_cash:I = 0x7f06050f

.field public static mm_color_balance_eye:I = 0x7f060510

.field public static mm_color_bbbbbb:I = 0x7f060511

.field public static mm_color_c0c3c8:I = 0x7f060512

.field public static mm_color_c1ccd5:I = 0x7f060513

.field public static mm_color_caaee4:I = 0x7f060514

.field public static mm_color_deposit_frame:I = 0x7f060515

.field public static mm_color_e2e8eb:I = 0x7f060516

.field public static mm_color_f0ecfc:I = 0x7f060517

.field public static mm_color_f3f3f3:I = 0x7f060518

.field public static mm_color_f6f6fa:I = 0x7f060519

.field public static mm_color_fe5455:I = 0x7f06051a

.field public static mm_color_ff575c:I = 0x7f06051b

.field public static mm_color_ffaa0c:I = 0x7f06051c

.field public static mm_color_intro_start:I = 0x7f06051d

.field public static mm_color_saving_center:I = 0x7f06051e

.field public static mm_color_saving_start:I = 0x7f06051f

.field public static mm_other_line:I = 0x7f060520

.field public static mm_saving_tab_bg:I = 0x7f060521

.field public static mm_saving_tab_text_selector:I = 0x7f060522

.field public static purple_200:I = 0x7f0605c8

.field public static purple_500:I = 0x7f0605c9

.field public static purple_700:I = 0x7f0605ca

.field public static teal_200:I = 0x7f0605f4

.field public static teal_700:I = 0x7f0605f5

.field public static white:I = 0x7f060626


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
