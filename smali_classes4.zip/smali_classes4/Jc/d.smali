.class public final LJc/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static mm_auto_renewal_item:I = 0x7f0d05a3

.field public static mm_break_pre_savings_child:I = 0x7f0d05a4

.field public static mm_cash_box_auto_save_activity:I = 0x7f0d05a5

.field public static mm_cash_box_auto_save_fragment:I = 0x7f0d05a6

.field public static mm_cash_box_campaign_main_activity:I = 0x7f0d05a7

.field public static mm_cash_box_deposit_fragment:I = 0x7f0d05a8

.field public static mm_cash_box_deposit_withdraw_activity:I = 0x7f0d05a9

.field public static mm_cash_box_estimated_interest_view:I = 0x7f0d05aa

.field public static mm_cash_box_introduction_fragment:I = 0x7f0d05ab

.field public static mm_cash_box_lose_lottery_dialog_fragment:I = 0x7f0d05ac

.field public static mm_cash_box_main_activity:I = 0x7f0d05ad

.field public static mm_cash_box_main_fragment:I = 0x7f0d05ae

.field public static mm_cash_box_newuser_use_coupon_dialog_fragment:I = 0x7f0d05af

.field public static mm_cash_box_order_result_activity:I = 0x7f0d05b0

.field public static mm_cash_box_transaction_detail_activity:I = 0x7f0d05b1

.field public static mm_cash_box_transaction_history_activity:I = 0x7f0d05b2

.field public static mm_cash_box_transaction_history_fragment:I = 0x7f0d05b3

.field public static mm_cash_box_turn_on_auto_save_dialog_fragment:I = 0x7f0d05b4

.field public static mm_cash_box_turn_on_auto_save_success_dialog_fragment:I = 0x7f0d05b5

.field public static mm_cash_box_use_coupon_result_dialog_fragment:I = 0x7f0d05b6

.field public static mm_cash_box_withdraw_fragment:I = 0x7f0d05b7

.field public static mm_cash_coupon_fail_dialog_fragnment:I = 0x7f0d05b8

.field public static mm_cash_coupon_success_dialog_fragnment:I = 0x7f0d05b9

.field public static mm_cashbox_auto_save_dialog_fragment:I = 0x7f0d05ba

.field public static mm_cashbox_terms_conditions_dialog_fragment:I = 0x7f0d05bb

.field public static mm_collapse_order_info:I = 0x7f0d05bc

.field public static mm_congratulations_dialog_fragnment:I = 0x7f0d05bd

.field public static mm_create_auto_renewal_item:I = 0x7f0d05be

.field public static mm_create_plan_activity:I = 0x7f0d05bf

.field public static mm_detail_info_item:I = 0x7f0d05c0

.field public static mm_estimated_interest_dialog_fragnment:I = 0x7f0d05c1

.field public static mm_fixed_auto_saving_dialog_fragment:I = 0x7f0d05c2

.field public static mm_fixed_saving_item_tab_custom:I = 0x7f0d05c3

.field public static mm_fixed_saving_order_for_break_result_activity:I = 0x7f0d05c4

.field public static mm_fixed_savings_more_function_dialog_fragment:I = 0x7f0d05c5

.field public static mm_insurance_take_photo_layout:I = 0x7f0d05c6

.field public static mm_investment_empty_view:I = 0x7f0d05c7

.field public static mm_item_cash_box_estimated_interest:I = 0x7f0d05c8

.field public static mm_item_cash_box_fixed_savings_product:I = 0x7f0d05c9

.field public static mm_item_cash_box_transaction:I = 0x7f0d05ca

.field public static mm_item_fixed_saving_plan:I = 0x7f0d05cb

.field public static mm_item_fund_transaction:I = 0x7f0d05cc

.field public static mm_item_history_month:I = 0x7f0d05cd

.field public static mm_item_new_user_fixed_saving_bottom_banner:I = 0x7f0d05ce

.field public static mm_item_payout_options:I = 0x7f0d05cf

.field public static mm_item_product:I = 0x7f0d05d0

.field public static mm_item_product_bottom:I = 0x7f0d05d1

.field public static mm_item_product_top:I = 0x7f0d05d2

.field public static mm_item_transaction_history:I = 0x7f0d05d3

.field public static mm_loading_page_item:I = 0x7f0d05d4

.field public static mm_more_function_dialog_fragment:I = 0x7f0d05d5

.field public static mm_new_user_fixed_saving_fragment:I = 0x7f0d05d6

.field public static mm_new_user_introduction_activity:I = 0x7f0d05d7

.field public static mm_newer_tip_dialog_fragment:I = 0x7f0d05d8

.field public static mm_old_user_fixed_saving_fragment:I = 0x7f0d05d9

.field public static mm_order_detail_fragment:I = 0x7f0d05da

.field public static mm_other_terms_conditions_dialog_fragment:I = 0x7f0d05db

.field public static mm_pay_back_detail_activity:I = 0x7f0d05dc

.field public static mm_pick_date_dialog_fragment:I = 0x7f0d05dd

.field public static mm_pick_state_dialog_fragment:I = 0x7f0d05de

.field public static mm_plan_break_pre_detail_activity:I = 0x7f0d05df

.field public static mm_plan_detail_activity:I = 0x7f0d05e0

.field public static mm_plan_info_click_item:I = 0x7f0d05e1

.field public static mm_plan_info_click_payment_item:I = 0x7f0d05e2

.field public static mm_plan_info_item:I = 0x7f0d05e3

.field public static mm_preview_plan_fragment:I = 0x7f0d05e4

.field public static mm_saving_advance_intercept_dialog_fragment:I = 0x7f0d05e5

.field public static mm_select_payout_options_dialog_fragment:I = 0x7f0d05e6

.field public static mm_select_state_activity:I = 0x7f0d05e7

.field public static mm_spend_save_preview_activity:I = 0x7f0d05e8

.field public static mm_state_pick_item:I = 0x7f0d05e9

.field public static mm_target_savings_transaction_history_fragment:I = 0x7f0d05ea

.field public static mm_transaction_detail_activity:I = 0x7f0d05eb

.field public static mm_transaction_detail_fragment:I = 0x7f0d05ec

.field public static mm_transaction_history_activity:I = 0x7f0d05ed

.field public static mm_turn_on_auto_save_successfully_dialog:I = 0x7f0d05ee

.field public static mm_use_fixed_saving_fragment:I = 0x7f0d05ef

.field public static mm_user_fixed_saving_activity:I = 0x7f0d05f0

.field public static mm_user_fixed_saving_tab_fragment:I = 0x7f0d05f1

.field public static mm_wealth_more_dialog_fragment:I = 0x7f0d05f2

.field public static mm_why_turn_off_save_dialog_fragment:I = 0x7f0d05f3

.field public static mm_withdraw_intercept_dialog_fragment:I = 0x7f0d05f4

.field public static mm_withdraw_sure_dialog_fragment:I = 0x7f0d05f5


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
