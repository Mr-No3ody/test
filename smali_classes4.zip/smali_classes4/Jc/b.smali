.class public final LJc/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static mm_agent_card:I = 0x7f080a43

.field public static mm_bg_advance_intercept_advance_panel:I = 0x7f080a44

.field public static mm_bg_advance_intercept_break_panel:I = 0x7f080a45

.field public static mm_bg_advance_intercept_icon_circle_gray:I = 0x7f080a46

.field public static mm_bg_advance_intercept_icon_circle_purple:I = 0x7f080a47

.field public static mm_bg_advance_intercept_recommend_badge:I = 0x7f080a48

.field public static mm_bg_agreement:I = 0x7f080a49

.field public static mm_bg_auto_save:I = 0x7f080a4a

.field public static mm_bg_campagin_main:I = 0x7f080a4b

.field public static mm_bg_campaigin_button:I = 0x7f080a4c

.field public static mm_bg_campaigin_button_small:I = 0x7f080a4d

.field public static mm_bg_campaign_dice:I = 0x7f080a4e

.field public static mm_bg_cashbox_main:I = 0x7f080a4f

.field public static mm_bg_common_dialog:I = 0x7f080a50

.field public static mm_bg_dash_line:I = 0x7f080a51

.field public static mm_bg_eye:I = 0x7f080a52

.field public static mm_bg_fixed_saving_preview:I = 0x7f080a53

.field public static mm_bg_index_progress:I = 0x7f080a54

.field public static mm_bg_intro_banner:I = 0x7f080a55

.field public static mm_bg_intro_banner_top:I = 0x7f080a56

.field public static mm_bg_intro_header:I = 0x7f080a57

.field public static mm_bg_introduction:I = 0x7f080a58

.field public static mm_bg_loading_indicator:I = 0x7f080a59

.field public static mm_bg_lose_lottery_okay:I = 0x7f080a5a

.field public static mm_bg_old_campaign_dice:I = 0x7f080a5b

.field public static mm_bg_old_user_fixed_saving_top:I = 0x7f080a5c

.field public static mm_bg_old_user_main:I = 0x7f080a5d

.field public static mm_bg_order_detail_item_divider:I = 0x7f080a5e

.field public static mm_bg_order_info_divider:I = 0x7f080a5f

.field public static mm_bg_paid_order_info:I = 0x7f080a60

.field public static mm_bg_payout_options:I = 0x7f080a61

.field public static mm_bg_plan_info:I = 0x7f080a62

.field public static mm_bg_primary_disable_selected:I = 0x7f080a63

.field public static mm_bg_product_info:I = 0x7f080a64

.field public static mm_bg_product_info_bottom:I = 0x7f080a65

.field public static mm_bg_product_info_middle:I = 0x7f080a66

.field public static mm_bg_product_info_top:I = 0x7f080a67

.field public static mm_bg_select_state:I = 0x7f080a68

.field public static mm_bg_tab_indicator:I = 0x7f080a69

.field public static mm_bg_transparent_h_divider_16:I = 0x7f080a6a

.field public static mm_bg_transparent_h_divider_8:I = 0x7f080a6b

.field public static mm_bg_transparent_v_divider_20:I = 0x7f080a6c

.field public static mm_bg_transparent_v_divider_4:I = 0x7f080a6d

.field public static mm_bg_transparent_v_divider_8:I = 0x7f080a6e

.field public static mm_bg_turn_on_auto_save_dialog:I = 0x7f080a6f

.field public static mm_bg_turn_on_auto_save_successfully_dialog:I = 0x7f080a70

.field public static mm_bg_win_lottery_prize:I = 0x7f080a71

.field public static mm_cash_box_campagin_main_bg:I = 0x7f080a72

.field public static mm_cash_coupon_success:I = 0x7f080a73

.field public static mm_cash_inout:I = 0x7f080a74

.field public static mm_cashbox_header_vector:I = 0x7f080a75

.field public static mm_collapse_order_info:I = 0x7f080a76

.field public static mm_estimated_interest_return_divider:I = 0x7f080a77

.field public static mm_fixed_arrow:I = 0x7f080a78

.field public static mm_fixed_auto_saving_frame:I = 0x7f080a79

.field public static mm_icon_airtime:I = 0x7f080a7a

.field public static mm_icon_anytime:I = 0x7f080a7b

.field public static mm_icon_arrow_up_interest:I = 0x7f080a7c

.field public static mm_icon_auto_save_logo:I = 0x7f080a7d

.field public static mm_icon_auto_save_middle:I = 0x7f080a7e

.field public static mm_icon_bank:I = 0x7f080a7f

.field public static mm_icon_campaign_top:I = 0x7f080a80

.field public static mm_icon_cash_box:I = 0x7f080a81

.field public static mm_icon_cash_box_main_title:I = 0x7f080a82

.field public static mm_icon_copy:I = 0x7f080a83

.field public static mm_icon_data:I = 0x7f080a84

.field public static mm_icon_eye_close_grary:I = 0x7f080a85

.field public static mm_icon_eye_close_white:I = 0x7f080a86

.field public static mm_icon_failed_small:I = 0x7f080a87

.field public static mm_icon_fixed_savings:I = 0x7f080a88

.field public static mm_icon_idle_funds:I = 0x7f080a89

.field public static mm_icon_info_orange:I = 0x7f080a8a

.field public static mm_icon_interest:I = 0x7f080a8b

.field public static mm_icon_investment_empty:I = 0x7f080a8c

.field public static mm_icon_listening:I = 0x7f080a8d

.field public static mm_icon_loading_page_1:I = 0x7f080a8e

.field public static mm_icon_loading_page_2:I = 0x7f080a8f

.field public static mm_icon_loading_page_3:I = 0x7f080a90

.field public static mm_icon_make_transfer:I = 0x7f080a91

.field public static mm_icon_message:I = 0x7f080a92

.field public static mm_icon_notification:I = 0x7f080a93

.field public static mm_icon_old_cashbox_users_text:I = 0x7f080a94

.field public static mm_icon_palmpay_logo:I = 0x7f080a95

.field public static mm_icon_right_gray:I = 0x7f080a96

.field public static mm_icon_rocket_success:I = 0x7f080a97

.field public static mm_icon_roctet_failed:I = 0x7f080a98

.field public static mm_icon_save_money_manually:I = 0x7f080a99

.field public static mm_icon_save_open:I = 0x7f080a9a

.field public static mm_icon_schedule_outline:I = 0x7f080a9b

.field public static mm_icon_sorry:I = 0x7f080a9c

.field public static mm_icon_succeed_white:I = 0x7f080a9d

.field public static mm_icon_sucess_with_star:I = 0x7f080a9e

.field public static mm_icon_total_savings:I = 0x7f080a9f

.field public static mm_icon_triangle:I = 0x7f080aa0

.field public static mm_icon_upgrade:I = 0x7f080aa1

.field public static mm_icon_warn:I = 0x7f080aa2

.field public static mm_icon_warn_gray:I = 0x7f080aa3

.field public static mm_icon_warn_purple:I = 0x7f080aa4

.field public static mm_icon_win_lottery_prize:I = 0x7f080aa5

.field public static mm_icon_withdraw_for_free:I = 0x7f080aa6

.field public static mm_interest:I = 0x7f080aa7

.field public static mm_micro_more_icon:I = 0x7f080aa8

.field public static mm_rect_corner_12_bg_single_fff:I = 0x7f080aa9

.field public static mm_rect_corner_24_bg_f6f6fa:I = 0x7f080aaa

.field public static mm_saving_plan_left:I = 0x7f080aab

.field public static mm_saving_tab_item_selector:I = 0x7f080aac

.field public static mm_select_state_divider:I = 0x7f080aad

.field public static mm_shape_more_function_divider:I = 0x7f080aae

.field public static mm_shape_rect_bg_white_corner:I = 0x7f080aaf

.field public static mm_shape_rect_corner_12_bg_white_stroke_purple:I = 0x7f080ab0

.field public static mm_shape_rect_corner_22_bg_separate_line_dark:I = 0x7f080ab1

.field public static mm_shape_rect_corner_4_bg_white_stroke_purple:I = 0x7f080ab2

.field public static mm_shape_rect_corner_lb_rb_12_bg_f6f6fa_1a:I = 0x7f080ab3

.field public static mm_shape_rect_corner_lt_rt_12_bg_202046:I = 0x7f080ab4

.field public static mm_shape_rect_renewal_bg_6a35ff:I = 0x7f080ab5

.field public static mm_shape_rectangle_gradient_eae3ff_to_fff:I = 0x7f080ab6

.field public static mm_shape_switch_common_thumb:I = 0x7f080ab7

.field public static mm_shape_switch_common_track:I = 0x7f080ab8

.field public static mm_shape_switch_track_selected:I = 0x7f080ab9

.field public static mm_shape_switch_track_selected_enable:I = 0x7f080aba

.field public static mm_shape_switch_track_unselected:I = 0x7f080abb

.field public static mm_shape_switch_track_unselected_enable:I = 0x7f080abc

.field public static mm_vs:I = 0x7f080abd


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
