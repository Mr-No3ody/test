.class public final Lad/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final b:F

.field public final c:F

.field public final d:J

.field public final e:F

.field public final f:F

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lcom/github/chrisbanes/photoview/e;FFFF)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lad/a;->a:I

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lad/a;->g:Ljava/lang/Object;

    .line 8
    iput p4, p0, Lad/a;->b:F

    .line 9
    iput p5, p0, Lad/a;->c:F

    .line 10
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p4

    iput-wide p4, p0, Lad/a;->d:J

    .line 11
    iput p2, p0, Lad/a;->e:F

    .line 12
    iput p3, p0, Lad/a;->f:F

    return-void
.end method

.method public constructor <init>(Lcom/transsnet/palmpay/photograph/crop/CropView;FFFF)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lad/a;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lad/a;->g:Ljava/lang/Object;

    .line 2
    iput p2, p0, Lad/a;->b:F

    .line 3
    iput p3, p0, Lad/a;->c:F

    .line 4
    iput p4, p0, Lad/a;->e:F

    .line 5
    iput p5, p0, Lad/a;->f:F

    .line 6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    iput-wide p1, p0, Lad/a;->d:J

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget v0, p0, Lad/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    iget-wide v2, p0, Lad/a;->d:J

    .line 11
    .line 12
    sub-long/2addr v0, v2

    .line 13
    long-to-float v0, v0

    .line 14
    const/high16 v1, 0x3f800000    # 1.0f

    .line 15
    .line 16
    mul-float/2addr v0, v1

    .line 17
    iget-object v2, p0, Lad/a;->g:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Lcom/github/chrisbanes/photoview/e;

    .line 20
    .line 21
    iget v3, v2, Lcom/github/chrisbanes/photoview/e;->b:I

    .line 22
    .line 23
    int-to-float v3, v3

    .line 24
    div-float/2addr v0, v3

    .line 25
    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    iget-object v3, v2, Lcom/github/chrisbanes/photoview/e;->a:Landroid/view/animation/AccelerateDecelerateInterpolator;

    .line 30
    .line 31
    invoke-virtual {v3, v0}, Landroid/view/animation/AccelerateDecelerateInterpolator;->getInterpolation(F)F

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    iget v3, p0, Lad/a;->f:F

    .line 36
    .line 37
    iget v4, p0, Lad/a;->e:F

    .line 38
    .line 39
    invoke-static {v3, v4, v0, v4}, Lcom/horcrux/svg/d0;->e(FFFF)F

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    invoke-virtual {v2}, Lcom/github/chrisbanes/photoview/e;->e()F

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    div-float/2addr v3, v4

    .line 48
    iget-object v4, v2, Lcom/github/chrisbanes/photoview/e;->t0:Lcom/github/chrisbanes/photoview/b;

    .line 49
    .line 50
    iget v5, p0, Lad/a;->c:F

    .line 51
    .line 52
    iget v6, p0, Lad/a;->b:F

    .line 53
    .line 54
    invoke-virtual {v4, v3, v6, v5}, Lcom/github/chrisbanes/photoview/b;->onScale(FFF)V

    .line 55
    .line 56
    .line 57
    cmpg-float v0, v0, v1

    .line 58
    .line 59
    if-gez v0, :cond_0

    .line 60
    .line 61
    iget-object v0, v2, Lcom/github/chrisbanes/photoview/e;->i:Lcom/github/chrisbanes/photoview/PhotoView;

    .line 62
    .line 63
    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 64
    .line 65
    .line 66
    :cond_0
    return-void

    .line 67
    :pswitch_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 68
    .line 69
    .line 70
    move-result-wide v0

    .line 71
    iget-wide v2, p0, Lad/a;->d:J

    .line 72
    .line 73
    sub-long/2addr v0, v2

    .line 74
    long-to-float v0, v0

    .line 75
    const/high16 v1, 0x3f800000    # 1.0f

    .line 76
    .line 77
    mul-float/2addr v0, v1

    .line 78
    iget-object v2, p0, Lad/a;->g:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v2, Lcom/transsnet/palmpay/photograph/crop/CropView;

    .line 81
    .line 82
    iget-wide v3, v2, Lcom/transsnet/palmpay/photograph/crop/CropView;->d:J

    .line 83
    .line 84
    long-to-float v3, v3

    .line 85
    div-float/2addr v0, v3

    .line 86
    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    iget-object v3, v2, Lcom/transsnet/palmpay/photograph/crop/CropView;->C:Landroid/view/animation/AccelerateDecelerateInterpolator;

    .line 91
    .line 92
    invoke-virtual {v3, v0}, Landroid/view/animation/AccelerateDecelerateInterpolator;->getInterpolation(F)F

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    iget v3, p0, Lad/a;->c:F

    .line 97
    .line 98
    iget v4, p0, Lad/a;->b:F

    .line 99
    .line 100
    invoke-static {v3, v4, v0, v4}, Lcom/horcrux/svg/d0;->e(FFFF)F

    .line 101
    .line 102
    .line 103
    move-result v3

    .line 104
    invoke-static {v2}, Lcom/transsnet/palmpay/photograph/crop/CropView;->b(Lcom/transsnet/palmpay/photograph/crop/CropView;)F

    .line 105
    .line 106
    .line 107
    move-result v4

    .line 108
    div-float/2addr v3, v4

    .line 109
    iget v4, p0, Lad/a;->e:F

    .line 110
    .line 111
    iget v5, p0, Lad/a;->f:F

    .line 112
    .line 113
    invoke-virtual {v2, v3, v4, v5}, Lcom/transsnet/palmpay/photograph/crop/CropView;->onScale(FFF)V

    .line 114
    .line 115
    .line 116
    cmpg-float v0, v0, v1

    .line 117
    .line 118
    if-gez v0, :cond_1

    .line 119
    .line 120
    invoke-virtual {v2, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 121
    .line 122
    .line 123
    :cond_1
    return-void

    .line 124
    nop

    .line 125
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
