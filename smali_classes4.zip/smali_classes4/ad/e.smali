.class public final Lad/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/photograph/crop/CropGestureDetector;


# instance fields
.field public a:I

.field public b:I

.field public final c:Landroid/view/ScaleGestureDetector;

.field public d:Landroid/view/VelocityTracker;

.field public e:Z

.field public f:F

.field public g:F

.field public h:F

.field public i:F

.field public j:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    .line 3
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v1

    int-to-float v1, v1

    iput v1, p0, Lad/e;->f:F

    .line 4
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    move-result v0

    int-to-float v0, v0

    iput v0, p0, Lad/e;->g:F

    const/4 v0, -0x1

    .line 5
    iput v0, p0, Lad/e;->a:I

    const/4 v0, 0x0

    .line 6
    iput v0, p0, Lad/e;->b:I

    .line 7
    new-instance v0, Lad/d;

    invoke-direct {v0, p0}, Lad/d;-><init>(Lad/e;)V

    .line 8
    new-instance v1, Landroid/view/ScaleGestureDetector;

    invoke-direct {v1, p1, v0}, Landroid/view/ScaleGestureDetector;-><init>(Landroid/content/Context;Landroid/view/ScaleGestureDetector$OnScaleGestureListener;)V

    iput-object v1, p0, Lad/e;->c:Landroid/view/ScaleGestureDetector;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/github/chrisbanes/photoview/b;)V
    .locals 2

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 10
    iput v0, p0, Lad/e;->a:I

    const/4 v0, 0x0

    .line 11
    iput v0, p0, Lad/e;->b:I

    .line 12
    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    .line 13
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    move-result v1

    int-to-float v1, v1

    iput v1, p0, Lad/e;->i:F

    .line 14
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v0

    int-to-float v0, v0

    iput v0, p0, Lad/e;->h:F

    .line 15
    iput-object p2, p0, Lad/e;->j:Ljava/lang/Object;

    .line 16
    new-instance p2, Lcom/github/chrisbanes/photoview/a;

    invoke-direct {p2, p0}, Lcom/github/chrisbanes/photoview/a;-><init>(Lad/e;)V

    .line 17
    new-instance v0, Landroid/view/ScaleGestureDetector;

    invoke-direct {v0, p1, p2}, Landroid/view/ScaleGestureDetector;-><init>(Landroid/content/Context;Landroid/view/ScaleGestureDetector$OnScaleGestureListener;)V

    iput-object v0, p0, Lad/e;->c:Landroid/view/ScaleGestureDetector;

    return-void
.end method


# virtual methods
.method public a(Landroid/view/MotionEvent;)V
    .locals 12

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    and-int/lit16 v0, v0, 0xff

    .line 6
    .line 7
    const/4 v1, -0x1

    .line 8
    const/4 v2, 0x0

    .line 9
    if-eqz v0, :cond_8

    .line 10
    .line 11
    iget-object v3, p0, Lad/e;->j:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v3, Lcom/github/chrisbanes/photoview/b;

    .line 14
    .line 15
    const/4 v4, 0x1

    .line 16
    const/4 v5, 0x0

    .line 17
    if-eq v0, v4, :cond_6

    .line 18
    .line 19
    const/4 v6, 0x2

    .line 20
    if-eq v0, v6, :cond_3

    .line 21
    .line 22
    const/4 v3, 0x3

    .line 23
    if-eq v0, v3, :cond_2

    .line 24
    .line 25
    const/4 v3, 0x6

    .line 26
    if-eq v0, v3, :cond_0

    .line 27
    .line 28
    goto/16 :goto_8

    .line 29
    .line 30
    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    const v3, 0xff00

    .line 35
    .line 36
    .line 37
    and-int/2addr v0, v3

    .line 38
    shr-int/lit8 v0, v0, 0x8

    .line 39
    .line 40
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    iget v5, p0, Lad/e;->a:I

    .line 45
    .line 46
    if-ne v3, v5, :cond_a

    .line 47
    .line 48
    if-nez v0, :cond_1

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_1
    move v4, v2

    .line 52
    :goto_0
    invoke-virtual {p1, v4}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    iput v0, p0, Lad/e;->a:I

    .line 57
    .line 58
    invoke-virtual {p1, v4}, Landroid/view/MotionEvent;->getX(I)F

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    iput v0, p0, Lad/e;->f:F

    .line 63
    .line 64
    invoke-virtual {p1, v4}, Landroid/view/MotionEvent;->getY(I)F

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    iput v0, p0, Lad/e;->g:F

    .line 69
    .line 70
    goto/16 :goto_8

    .line 71
    .line 72
    :cond_2
    iput v1, p0, Lad/e;->a:I

    .line 73
    .line 74
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 75
    .line 76
    if-eqz v0, :cond_a

    .line 77
    .line 78
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    .line 79
    .line 80
    .line 81
    iput-object v5, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 82
    .line 83
    goto/16 :goto_8

    .line 84
    .line 85
    :cond_3
    :try_start_0
    iget v0, p0, Lad/e;->b:I

    .line 86
    .line 87
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 88
    .line 89
    .line 90
    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 91
    goto :goto_1

    .line 92
    :catch_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    :goto_1
    :try_start_1
    iget v5, p0, Lad/e;->b:I

    .line 97
    .line 98
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getY(I)F

    .line 99
    .line 100
    .line 101
    move-result v5
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 102
    goto :goto_2

    .line 103
    :catch_1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 104
    .line 105
    .line 106
    move-result v5

    .line 107
    :goto_2
    iget v6, p0, Lad/e;->f:F

    .line 108
    .line 109
    sub-float v6, v0, v6

    .line 110
    .line 111
    iget v7, p0, Lad/e;->g:F

    .line 112
    .line 113
    sub-float v7, v5, v7

    .line 114
    .line 115
    iget-boolean v8, p0, Lad/e;->e:Z

    .line 116
    .line 117
    if-nez v8, :cond_5

    .line 118
    .line 119
    mul-float v8, v6, v6

    .line 120
    .line 121
    mul-float v9, v7, v7

    .line 122
    .line 123
    add-float/2addr v9, v8

    .line 124
    float-to-double v8, v9

    .line 125
    invoke-static {v8, v9}, Ljava/lang/Math;->sqrt(D)D

    .line 126
    .line 127
    .line 128
    move-result-wide v8

    .line 129
    iget v10, p0, Lad/e;->h:F

    .line 130
    .line 131
    float-to-double v10, v10

    .line 132
    cmpl-double v8, v8, v10

    .line 133
    .line 134
    if-ltz v8, :cond_4

    .line 135
    .line 136
    goto :goto_3

    .line 137
    :cond_4
    move v4, v2

    .line 138
    :goto_3
    iput-boolean v4, p0, Lad/e;->e:Z

    .line 139
    .line 140
    :cond_5
    iget-boolean v4, p0, Lad/e;->e:Z

    .line 141
    .line 142
    if-eqz v4, :cond_a

    .line 143
    .line 144
    invoke-virtual {v3, v6, v7}, Lcom/github/chrisbanes/photoview/b;->onDrag(FF)V

    .line 145
    .line 146
    .line 147
    iput v0, p0, Lad/e;->f:F

    .line 148
    .line 149
    iput v5, p0, Lad/e;->g:F

    .line 150
    .line 151
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 152
    .line 153
    if-eqz v0, :cond_a

    .line 154
    .line 155
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 156
    .line 157
    .line 158
    goto/16 :goto_8

    .line 159
    .line 160
    :cond_6
    iput v1, p0, Lad/e;->a:I

    .line 161
    .line 162
    iget-boolean v0, p0, Lad/e;->e:Z

    .line 163
    .line 164
    if-eqz v0, :cond_7

    .line 165
    .line 166
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 167
    .line 168
    if-eqz v0, :cond_7

    .line 169
    .line 170
    :try_start_2
    iget v0, p0, Lad/e;->b:I

    .line 171
    .line 172
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 173
    .line 174
    .line 175
    move-result v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 176
    goto :goto_4

    .line 177
    :catch_2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    :goto_4
    iput v0, p0, Lad/e;->f:F

    .line 182
    .line 183
    :try_start_3
    iget v0, p0, Lad/e;->b:I

    .line 184
    .line 185
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 186
    .line 187
    .line 188
    move-result v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    .line 189
    goto :goto_5

    .line 190
    :catch_3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 191
    .line 192
    .line 193
    move-result v0

    .line 194
    :goto_5
    iput v0, p0, Lad/e;->g:F

    .line 195
    .line 196
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 197
    .line 198
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 199
    .line 200
    .line 201
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 202
    .line 203
    const/16 v4, 0x3e8

    .line 204
    .line 205
    invoke-virtual {v0, v4}, Landroid/view/VelocityTracker;->computeCurrentVelocity(I)V

    .line 206
    .line 207
    .line 208
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 209
    .line 210
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->getXVelocity()F

    .line 211
    .line 212
    .line 213
    move-result v0

    .line 214
    iget-object v4, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 215
    .line 216
    invoke-virtual {v4}, Landroid/view/VelocityTracker;->getYVelocity()F

    .line 217
    .line 218
    .line 219
    move-result v4

    .line 220
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 221
    .line 222
    .line 223
    move-result v6

    .line 224
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 225
    .line 226
    .line 227
    move-result v7

    .line 228
    invoke-static {v6, v7}, Ljava/lang/Math;->max(FF)F

    .line 229
    .line 230
    .line 231
    move-result v6

    .line 232
    iget v7, p0, Lad/e;->i:F

    .line 233
    .line 234
    cmpl-float v6, v6, v7

    .line 235
    .line 236
    if-ltz v6, :cond_7

    .line 237
    .line 238
    iget v6, p0, Lad/e;->f:F

    .line 239
    .line 240
    iget v7, p0, Lad/e;->g:F

    .line 241
    .line 242
    neg-float v0, v0

    .line 243
    neg-float v4, v4

    .line 244
    invoke-virtual {v3, v6, v7, v0, v4}, Lcom/github/chrisbanes/photoview/b;->onFling(FFFF)V

    .line 245
    .line 246
    .line 247
    :cond_7
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 248
    .line 249
    if-eqz v0, :cond_a

    .line 250
    .line 251
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    .line 252
    .line 253
    .line 254
    iput-object v5, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 255
    .line 256
    goto :goto_8

    .line 257
    :cond_8
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 258
    .line 259
    .line 260
    move-result v0

    .line 261
    iput v0, p0, Lad/e;->a:I

    .line 262
    .line 263
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    iput-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 268
    .line 269
    if-eqz v0, :cond_9

    .line 270
    .line 271
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 272
    .line 273
    .line 274
    :cond_9
    :try_start_4
    iget v0, p0, Lad/e;->b:I

    .line 275
    .line 276
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 277
    .line 278
    .line 279
    move-result v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    .line 280
    goto :goto_6

    .line 281
    :catch_4
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 282
    .line 283
    .line 284
    move-result v0

    .line 285
    :goto_6
    iput v0, p0, Lad/e;->f:F

    .line 286
    .line 287
    :try_start_5
    iget v0, p0, Lad/e;->b:I

    .line 288
    .line 289
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 290
    .line 291
    .line 292
    move-result v0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5

    .line 293
    goto :goto_7

    .line 294
    :catch_5
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 295
    .line 296
    .line 297
    move-result v0

    .line 298
    :goto_7
    iput v0, p0, Lad/e;->g:F

    .line 299
    .line 300
    iput-boolean v2, p0, Lad/e;->e:Z

    .line 301
    .line 302
    :cond_a
    :goto_8
    iget v0, p0, Lad/e;->a:I

    .line 303
    .line 304
    if-eq v0, v1, :cond_b

    .line 305
    .line 306
    move v2, v0

    .line 307
    :cond_b
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 308
    .line 309
    .line 310
    move-result p1

    .line 311
    iput p1, p0, Lad/e;->b:I

    .line 312
    .line 313
    return-void
.end method

.method public isDragging()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lad/e;->e:Z

    .line 2
    .line 3
    return v0
.end method

.method public isScaling()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lad/e;->c:Landroid/view/ScaleGestureDetector;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/ScaleGestureDetector;->isInProgress()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 11

    .line 1
    iget-object v0, p0, Lad/e;->c:Landroid/view/ScaleGestureDetector;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/view/ScaleGestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    and-int/lit16 v0, v0, 0xff

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    const/4 v2, -0x1

    .line 14
    const/4 v3, 0x0

    .line 15
    if-eqz v0, :cond_3

    .line 16
    .line 17
    if-eq v0, v1, :cond_2

    .line 18
    .line 19
    const/4 v4, 0x3

    .line 20
    if-eq v0, v4, :cond_2

    .line 21
    .line 22
    const/4 v4, 0x6

    .line 23
    if-eq v0, v4, :cond_0

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    const v4, 0xff00

    .line 31
    .line 32
    .line 33
    and-int/2addr v0, v4

    .line 34
    shr-int/lit8 v0, v0, 0x8

    .line 35
    .line 36
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    iget v5, p0, Lad/e;->a:I

    .line 41
    .line 42
    if-ne v4, v5, :cond_4

    .line 43
    .line 44
    if-nez v0, :cond_1

    .line 45
    .line 46
    move v0, v1

    .line 47
    goto :goto_0

    .line 48
    :cond_1
    move v0, v3

    .line 49
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 50
    .line 51
    .line 52
    move-result v4

    .line 53
    iput v4, p0, Lad/e;->a:I

    .line 54
    .line 55
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 56
    .line 57
    .line 58
    move-result v4

    .line 59
    iput v4, p0, Lad/e;->h:F

    .line 60
    .line 61
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    iput v0, p0, Lad/e;->i:F

    .line 66
    .line 67
    goto :goto_1

    .line 68
    :cond_2
    iput v2, p0, Lad/e;->a:I

    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_3
    invoke-virtual {p1, v3}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    iput v0, p0, Lad/e;->a:I

    .line 76
    .line 77
    :cond_4
    :goto_1
    iget v0, p0, Lad/e;->a:I

    .line 78
    .line 79
    if-eq v0, v2, :cond_5

    .line 80
    .line 81
    move v3, v0

    .line 82
    :cond_5
    invoke-virtual {p1, v3}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    iput v0, p0, Lad/e;->b:I

    .line 87
    .line 88
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    const/4 v2, 0x0

    .line 93
    const/4 v3, 0x1

    .line 94
    if-eqz v0, :cond_c

    .line 95
    .line 96
    const/4 v4, 0x0

    .line 97
    if-eq v0, v3, :cond_a

    .line 98
    .line 99
    const/4 v5, 0x2

    .line 100
    if-eq v0, v5, :cond_7

    .line 101
    .line 102
    const/4 p1, 0x3

    .line 103
    if-eq v0, p1, :cond_6

    .line 104
    .line 105
    goto/16 :goto_8

    .line 106
    .line 107
    :cond_6
    iget-object p1, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 108
    .line 109
    if-eqz p1, :cond_e

    .line 110
    .line 111
    invoke-virtual {p1}, Landroid/view/VelocityTracker;->recycle()V

    .line 112
    .line 113
    .line 114
    iput-object v4, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 115
    .line 116
    goto/16 :goto_8

    .line 117
    .line 118
    :cond_7
    :try_start_0
    iget v0, p0, Lad/e;->b:I

    .line 119
    .line 120
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 121
    .line 122
    .line 123
    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 124
    goto :goto_2

    .line 125
    :catch_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    :goto_2
    :try_start_1
    iget v4, p0, Lad/e;->b:I

    .line 130
    .line 131
    invoke-virtual {p1, v4}, Landroid/view/MotionEvent;->getY(I)F

    .line 132
    .line 133
    .line 134
    move-result v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 135
    goto :goto_3

    .line 136
    :catch_1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 137
    .line 138
    .line 139
    move-result v4

    .line 140
    :goto_3
    iget v5, p0, Lad/e;->h:F

    .line 141
    .line 142
    sub-float v5, v0, v5

    .line 143
    .line 144
    iget v6, p0, Lad/e;->i:F

    .line 145
    .line 146
    sub-float v6, v4, v6

    .line 147
    .line 148
    iget-boolean v7, p0, Lad/e;->e:Z

    .line 149
    .line 150
    if-nez v7, :cond_9

    .line 151
    .line 152
    mul-float v7, v5, v5

    .line 153
    .line 154
    mul-float v8, v6, v6

    .line 155
    .line 156
    add-float/2addr v8, v7

    .line 157
    float-to-double v7, v8

    .line 158
    invoke-static {v7, v8}, Ljava/lang/Math;->sqrt(D)D

    .line 159
    .line 160
    .line 161
    move-result-wide v7

    .line 162
    iget v9, p0, Lad/e;->f:F

    .line 163
    .line 164
    float-to-double v9, v9

    .line 165
    cmpl-double v7, v7, v9

    .line 166
    .line 167
    if-ltz v7, :cond_8

    .line 168
    .line 169
    move v2, v3

    .line 170
    :cond_8
    iput-boolean v2, p0, Lad/e;->e:Z

    .line 171
    .line 172
    :cond_9
    iget-boolean v2, p0, Lad/e;->e:Z

    .line 173
    .line 174
    if-eqz v2, :cond_e

    .line 175
    .line 176
    iget-object v2, p0, Lad/e;->j:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v2, Lcom/transsnet/palmpay/photograph/crop/OnGestureListener;

    .line 179
    .line 180
    invoke-interface {v2, v5, v6}, Lcom/transsnet/palmpay/photograph/crop/OnGestureListener;->onDrag(FF)V

    .line 181
    .line 182
    .line 183
    iput v0, p0, Lad/e;->h:F

    .line 184
    .line 185
    iput v4, p0, Lad/e;->i:F

    .line 186
    .line 187
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 188
    .line 189
    if-eqz v0, :cond_e

    .line 190
    .line 191
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 192
    .line 193
    .line 194
    goto/16 :goto_8

    .line 195
    .line 196
    :cond_a
    iget-boolean v0, p0, Lad/e;->e:Z

    .line 197
    .line 198
    if-eqz v0, :cond_b

    .line 199
    .line 200
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 201
    .line 202
    if-eqz v0, :cond_b

    .line 203
    .line 204
    :try_start_2
    iget v0, p0, Lad/e;->b:I

    .line 205
    .line 206
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 207
    .line 208
    .line 209
    move-result v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 210
    goto :goto_4

    .line 211
    :catch_2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 212
    .line 213
    .line 214
    move-result v0

    .line 215
    :goto_4
    iput v0, p0, Lad/e;->h:F

    .line 216
    .line 217
    :try_start_3
    iget v0, p0, Lad/e;->b:I

    .line 218
    .line 219
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 220
    .line 221
    .line 222
    move-result v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    .line 223
    goto :goto_5

    .line 224
    :catch_3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    :goto_5
    iput v0, p0, Lad/e;->i:F

    .line 229
    .line 230
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 231
    .line 232
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 233
    .line 234
    .line 235
    iget-object p1, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 236
    .line 237
    const/16 v0, 0x3e8

    .line 238
    .line 239
    invoke-virtual {p1, v0}, Landroid/view/VelocityTracker;->computeCurrentVelocity(I)V

    .line 240
    .line 241
    .line 242
    iget-object p1, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 243
    .line 244
    invoke-virtual {p1}, Landroid/view/VelocityTracker;->getXVelocity()F

    .line 245
    .line 246
    .line 247
    move-result p1

    .line 248
    iget-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 249
    .line 250
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->getYVelocity()F

    .line 251
    .line 252
    .line 253
    move-result v0

    .line 254
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 255
    .line 256
    .line 257
    move-result v2

    .line 258
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 259
    .line 260
    .line 261
    move-result v3

    .line 262
    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    .line 263
    .line 264
    .line 265
    move-result v2

    .line 266
    iget v3, p0, Lad/e;->g:F

    .line 267
    .line 268
    cmpl-float v2, v2, v3

    .line 269
    .line 270
    if-ltz v2, :cond_b

    .line 271
    .line 272
    iget-object v2, p0, Lad/e;->j:Ljava/lang/Object;

    .line 273
    .line 274
    check-cast v2, Lcom/transsnet/palmpay/photograph/crop/OnGestureListener;

    .line 275
    .line 276
    iget v3, p0, Lad/e;->h:F

    .line 277
    .line 278
    iget v5, p0, Lad/e;->i:F

    .line 279
    .line 280
    neg-float p1, p1

    .line 281
    neg-float v0, v0

    .line 282
    invoke-interface {v2, v3, v5, p1, v0}, Lcom/transsnet/palmpay/photograph/crop/OnGestureListener;->onFling(FFFF)V

    .line 283
    .line 284
    .line 285
    :cond_b
    iget-object p1, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 286
    .line 287
    if-eqz p1, :cond_e

    .line 288
    .line 289
    invoke-virtual {p1}, Landroid/view/VelocityTracker;->recycle()V

    .line 290
    .line 291
    .line 292
    iput-object v4, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 293
    .line 294
    goto :goto_8

    .line 295
    :cond_c
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 296
    .line 297
    .line 298
    move-result-object v0

    .line 299
    iput-object v0, p0, Lad/e;->d:Landroid/view/VelocityTracker;

    .line 300
    .line 301
    if-eqz v0, :cond_d

    .line 302
    .line 303
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 304
    .line 305
    .line 306
    :cond_d
    :try_start_4
    iget v0, p0, Lad/e;->b:I

    .line 307
    .line 308
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 309
    .line 310
    .line 311
    move-result v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    .line 312
    goto :goto_6

    .line 313
    :catch_4
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 314
    .line 315
    .line 316
    move-result v0

    .line 317
    :goto_6
    iput v0, p0, Lad/e;->h:F

    .line 318
    .line 319
    :try_start_5
    iget v0, p0, Lad/e;->b:I

    .line 320
    .line 321
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 322
    .line 323
    .line 324
    move-result p1
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5

    .line 325
    goto :goto_7

    .line 326
    :catch_5
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 327
    .line 328
    .line 329
    move-result p1

    .line 330
    :goto_7
    iput p1, p0, Lad/e;->i:F

    .line 331
    .line 332
    iput-boolean v2, p0, Lad/e;->e:Z

    .line 333
    .line 334
    :cond_e
    :goto_8
    return v1
.end method

.method public setOnGestureListener(Lcom/transsnet/palmpay/photograph/crop/OnGestureListener;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lad/e;->j:Ljava/lang/Object;

    .line 2
    .line 3
    return-void
.end method
