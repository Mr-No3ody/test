.class public final Lad/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/GestureDetector$OnDoubleTapListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/photograph/crop/CropView;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/photograph/crop/CropView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lad/b;->a:Lcom/transsnet/palmpay/photograph/crop/CropView;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onDoubleTap(Landroid/view/MotionEvent;)Z
    .locals 6

    .line 1
    iget-object v0, p0, Lad/b;->a:Lcom/transsnet/palmpay/photograph/crop/CropView;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    :try_start_0
    invoke-static {v0}, Lcom/transsnet/palmpay/photograph/crop/CropView;->b(Lcom/transsnet/palmpay/photograph/crop/CropView;)F

    .line 5
    .line 6
    .line 7
    move-result v2

    .line 8
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    iget v4, v0, Lcom/transsnet/palmpay/photograph/crop/CropView;->b:F

    .line 17
    .line 18
    cmpg-float v5, v2, v4

    .line 19
    .line 20
    if-gez v5, :cond_0

    .line 21
    .line 22
    invoke-static {v0, v4, v3, p1}, Lcom/transsnet/palmpay/photograph/crop/CropView;->c(Lcom/transsnet/palmpay/photograph/crop/CropView;FFF)V

    .line 23
    .line 24
    .line 25
    return v1

    .line 26
    :cond_0
    cmpl-float v4, v2, v4

    .line 27
    .line 28
    if-ltz v4, :cond_1

    .line 29
    .line 30
    iget v4, v0, Lcom/transsnet/palmpay/photograph/crop/CropView;->c:F

    .line 31
    .line 32
    cmpg-float v2, v2, v4

    .line 33
    .line 34
    if-gez v2, :cond_1

    .line 35
    .line 36
    invoke-static {v0, v4, v3, p1}, Lcom/transsnet/palmpay/photograph/crop/CropView;->c(Lcom/transsnet/palmpay/photograph/crop/CropView;FFF)V

    .line 37
    .line 38
    .line 39
    return v1

    .line 40
    :cond_1
    iget v2, v0, Lcom/transsnet/palmpay/photograph/crop/CropView;->a:F

    .line 41
    .line 42
    invoke-static {v0, v2, v3, p1}, Lcom/transsnet/palmpay/photograph/crop/CropView;->c(Lcom/transsnet/palmpay/photograph/crop/CropView;FFF)V
    :try_end_0
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    .line 43
    .line 44
    .line 45
    :catch_0
    return v1
.end method

.method public final onDoubleTapEvent(Landroid/view/MotionEvent;)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public final onSingleTapConfirmed(Landroid/view/MotionEvent;)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method
