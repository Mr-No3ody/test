.class public final Lad/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public b:I

.field public c:I

.field public final d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lcom/github/chrisbanes/photoview/e;Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lad/c;->a:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lad/c;->e:Ljava/lang/Object;

    .line 5
    new-instance p1, Landroid/widget/OverScroller;

    invoke-direct {p1, p2}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lad/c;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/transsnet/palmpay/photograph/crop/CropView;Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lad/c;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lad/c;->e:Ljava/lang/Object;

    .line 2
    new-instance p1, LAb/r;

    invoke-direct {p1, p2}, LAb/r;-><init>(Landroid/content/Context;)V

    .line 3
    iput-object p1, p0, Lad/c;->d:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    .line 1
    iget v0, p0, Lad/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lad/c;->d:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroid/widget/OverScroller;

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/widget/OverScroller;->isFinished()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {v0}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrX()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrY()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    iget-object v2, p0, Lad/c;->e:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v2, Lcom/github/chrisbanes/photoview/e;

    .line 34
    .line 35
    iget-object v3, v2, Lcom/github/chrisbanes/photoview/e;->v:Landroid/graphics/Matrix;

    .line 36
    .line 37
    iget v4, p0, Lad/c;->b:I

    .line 38
    .line 39
    sub-int/2addr v4, v1

    .line 40
    int-to-float v4, v4

    .line 41
    iget v5, p0, Lad/c;->c:I

    .line 42
    .line 43
    sub-int/2addr v5, v0

    .line 44
    int-to-float v5, v5

    .line 45
    invoke-virtual {v3, v4, v5}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 46
    .line 47
    .line 48
    invoke-virtual {v2}, Lcom/github/chrisbanes/photoview/e;->a()V

    .line 49
    .line 50
    .line 51
    iput v1, p0, Lad/c;->b:I

    .line 52
    .line 53
    iput v0, p0, Lad/c;->c:I

    .line 54
    .line 55
    iget-object v0, v2, Lcom/github/chrisbanes/photoview/e;->i:Lcom/github/chrisbanes/photoview/PhotoView;

    .line 56
    .line 57
    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 58
    .line 59
    .line 60
    :cond_1
    :goto_0
    return-void

    .line 61
    :pswitch_0
    iget-object v0, p0, Lad/c;->d:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v0, LAb/r;

    .line 64
    .line 65
    iget-object v1, v0, LAb/r;->b:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v1, Landroid/widget/OverScroller;

    .line 68
    .line 69
    invoke-virtual {v1}, Landroid/widget/OverScroller;->isFinished()Z

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-eqz v1, :cond_2

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_2
    iget-object v1, v0, LAb/r;->b:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v1, Landroid/widget/OverScroller;

    .line 79
    .line 80
    invoke-virtual {v1}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    if-eqz v1, :cond_3

    .line 85
    .line 86
    iget-object v1, v0, LAb/r;->b:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v1, Landroid/widget/OverScroller;

    .line 89
    .line 90
    invoke-virtual {v1}, Landroid/widget/OverScroller;->getCurrX()I

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    iget-object v0, v0, LAb/r;->b:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast v0, Landroid/widget/OverScroller;

    .line 97
    .line 98
    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrY()I

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    iget-object v2, p0, Lad/c;->e:Ljava/lang/Object;

    .line 103
    .line 104
    check-cast v2, Lcom/transsnet/palmpay/photograph/crop/CropView;

    .line 105
    .line 106
    iget-object v3, v2, Lcom/transsnet/palmpay/photograph/crop/CropView;->t:Landroid/graphics/Matrix;

    .line 107
    .line 108
    iget v4, p0, Lad/c;->b:I

    .line 109
    .line 110
    sub-int/2addr v4, v1

    .line 111
    int-to-float v4, v4

    .line 112
    iget v5, p0, Lad/c;->c:I

    .line 113
    .line 114
    sub-int/2addr v5, v0

    .line 115
    int-to-float v5, v5

    .line 116
    invoke-virtual {v3, v4, v5}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 117
    .line 118
    .line 119
    invoke-static {v2}, Lcom/transsnet/palmpay/photograph/crop/CropView;->a(Lcom/transsnet/palmpay/photograph/crop/CropView;)Landroid/graphics/Matrix;

    .line 120
    .line 121
    .line 122
    move-result-object v3

    .line 123
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    .line 124
    .line 125
    .line 126
    iput v1, p0, Lad/c;->b:I

    .line 127
    .line 128
    iput v0, p0, Lad/c;->c:I

    .line 129
    .line 130
    invoke-virtual {v2, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 131
    .line 132
    .line 133
    :cond_3
    :goto_1
    return-void

    .line 134
    nop

    .line 135
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
