.class public final Lad/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroid/graphics/Bitmap;

.field public final b:I


# direct methods
.method public constructor <init>(Landroid/graphics/Bitmap;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lad/g;->a:Landroid/graphics/Bitmap;

    .line 5
    .line 6
    rem-int/lit16 p2, p2, 0x168

    .line 7
    .line 8
    iput p2, p0, Lad/g;->b:I

    .line 9
    .line 10
    return-void
.end method
