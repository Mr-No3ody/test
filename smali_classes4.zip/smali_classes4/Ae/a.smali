.class public final synthetic LAe/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAe/a;->a:I

    iput-object p1, p0, LAe/a;->b:Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget v0, p0, LAe/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LAe/a;->b:Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;

    .line 7
    .line 8
    invoke-static {p1}, Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;->access$getMContext$p$s1750978249(Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;)Landroid/content/Context;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {p1}, Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;->access$getMJumpParams$p(Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-static {v0, p1}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :pswitch_0
    iget-object v0, p0, LAe/a;->b:Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;

    .line 25
    .line 26
    invoke-static {v0, p1}, Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;->a(Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;Landroid/view/View;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
