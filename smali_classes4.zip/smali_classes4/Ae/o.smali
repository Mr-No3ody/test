.class public final LAe/o;
.super Landroid/webkit/WebChromeClient;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LAe/o;->a:I

    iput-object p1, p0, LAe/o;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/webkit/WebView;I)V
    .locals 2

    .line 1
    iget v0, p0, LAe/o;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    :pswitch_0
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_1
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 11
    .line 12
    .line 13
    const/16 p1, 0x64

    .line 14
    .line 15
    iget-object v0, p0, LAe/o;->b:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantActivity;

    .line 18
    .line 19
    if-ge p2, p1, :cond_0

    .line 20
    .line 21
    iget-object p1, v0, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantActivity;->b:Landroid/widget/ProgressBar;

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 25
    .line 26
    .line 27
    iget-object p1, v0, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantActivity;->b:Landroid/widget/ProgressBar;

    .line 28
    .line 29
    invoke-virtual {p1, p2}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 30
    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_0
    iget-object p1, v0, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantActivity;->b:Landroid/widget/ProgressBar;

    .line 34
    .line 35
    const/16 p2, 0x8

    .line 36
    .line 37
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 38
    .line 39
    .line 40
    :goto_0
    return-void

    .line 41
    :pswitch_2
    const-string v0, "view"

    .line 42
    .line 43
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 47
    .line 48
    .line 49
    const/16 p1, 0x64

    .line 50
    .line 51
    if-ne p2, p1, :cond_1

    .line 52
    .line 53
    const/4 p1, 0x0

    .line 54
    iget-object p2, p0, LAe/o;->b:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast p2, Lcom/transsnet/palmpay/account/ui/fragment/quota/Tier3QuotaAgreementFragment;

    .line 57
    .line 58
    invoke-virtual {p2, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 59
    .line 60
    .line 61
    iget-object p1, p2, Lcom/transsnet/palmpay/account/ui/fragment/quota/Tier3QuotaAgreementFragment;->i:LBc/d;

    .line 62
    .line 63
    if-eqz p1, :cond_1

    .line 64
    .line 65
    iget-object p1, p1, LBc/d;->c:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast p1, Lcom/palmpay/lib/ui/button/PpButton;

    .line 68
    .line 69
    if-eqz p1, :cond_1

    .line 70
    .line 71
    const/4 p2, 0x1

    .line 72
    invoke-virtual {p1, p2}, Landroid/view/View;->setEnabled(Z)V

    .line 73
    .line 74
    .line 75
    :cond_1
    return-void

    .line 76
    :pswitch_3
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 77
    .line 78
    .line 79
    const/16 p1, 0x64

    .line 80
    .line 81
    if-ne p2, p1, :cond_2

    .line 82
    .line 83
    iget-object p1, p0, LAe/o;->b:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast p1, Lcom/transsnet/palmpay/core/viewmodel/PayResultLotteryView;

    .line 86
    .line 87
    iget-object p2, p1, Lcom/transsnet/palmpay/core/viewmodel/PayResultLotteryView;->b:Lcom/transsnet/palmpay/core/bean/message/PushMessage;

    .line 88
    .line 89
    if-eqz p2, :cond_2

    .line 90
    .line 91
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/core/viewmodel/PayResultLotteryView;->onReceivePushMessage(Lcom/transsnet/palmpay/core/bean/message/PushMessage;)V

    .line 92
    .line 93
    .line 94
    :cond_2
    return-void

    .line 95
    :pswitch_4
    const-string v0, "view"

    .line 96
    .line 97
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 101
    .line 102
    .line 103
    const/16 p1, 0x64

    .line 104
    .line 105
    iget-object v0, p0, LAe/o;->b:Ljava/lang/Object;

    .line 106
    .line 107
    check-cast v0, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankAddLinkCardWebFragment;

    .line 108
    .line 109
    if-ne p2, p1, :cond_3

    .line 110
    .line 111
    iget-object p1, v0, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankAddLinkCardWebFragment;->t:Landroid/widget/ProgressBar;

    .line 112
    .line 113
    if-eqz p1, :cond_5

    .line 114
    .line 115
    const/16 p2, 0x8

    .line 116
    .line 117
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 118
    .line 119
    .line 120
    goto :goto_1

    .line 121
    :cond_3
    iget-object p1, v0, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankAddLinkCardWebFragment;->t:Landroid/widget/ProgressBar;

    .line 122
    .line 123
    if-eqz p1, :cond_4

    .line 124
    .line 125
    const/4 v1, 0x0

    .line 126
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 127
    .line 128
    .line 129
    :cond_4
    iget-object p1, v0, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankAddLinkCardWebFragment;->t:Landroid/widget/ProgressBar;

    .line 130
    .line 131
    if-eqz p1, :cond_5

    .line 132
    .line 133
    invoke-virtual {p1, p2}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 134
    .line 135
    .line 136
    :cond_5
    :goto_1
    return-void

    .line 137
    :pswitch_5
    const-string v0, "view"

    .line 138
    .line 139
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 143
    .line 144
    .line 145
    const/16 p1, 0x64

    .line 146
    .line 147
    if-ne p2, p1, :cond_6

    .line 148
    .line 149
    iget-object p1, p0, LAe/o;->b:Ljava/lang/Object;

    .line 150
    .line 151
    check-cast p1, Lcom/transsnet/palmpay/account/ui/activity/PalmPayLevelUp3Activity;

    .line 152
    .line 153
    const/4 p2, 0x0

    .line 154
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 155
    .line 156
    .line 157
    :cond_6
    return-void

    .line 158
    :pswitch_6
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 159
    .line 160
    .line 161
    const/16 p1, 0x64

    .line 162
    .line 163
    iget-object v0, p0, LAe/o;->b:Ljava/lang/Object;

    .line 164
    .line 165
    check-cast v0, Lcom/transsnet/palmpay/core/ui/fragment/verify/AddLinkCardWebFragment;

    .line 166
    .line 167
    if-ne p2, p1, :cond_7

    .line 168
    .line 169
    iget-object p1, v0, Lcom/transsnet/palmpay/core/ui/fragment/verify/AddLinkCardWebFragment;->j:Landroid/widget/ProgressBar;

    .line 170
    .line 171
    const/16 p2, 0x8

    .line 172
    .line 173
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 174
    .line 175
    .line 176
    goto :goto_2

    .line 177
    :cond_7
    iget-object p1, v0, Lcom/transsnet/palmpay/core/ui/fragment/verify/AddLinkCardWebFragment;->j:Landroid/widget/ProgressBar;

    .line 178
    .line 179
    const/4 v1, 0x0

    .line 180
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 181
    .line 182
    .line 183
    iget-object p1, v0, Lcom/transsnet/palmpay/core/ui/fragment/verify/AddLinkCardWebFragment;->j:Landroid/widget/ProgressBar;

    .line 184
    .line 185
    invoke-virtual {p1, p2}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 186
    .line 187
    .line 188
    :goto_2
    return-void

    .line 189
    :pswitch_7
    const-string v0, "view"

    .line 190
    .line 191
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 195
    .line 196
    .line 197
    const/16 p1, 0x64

    .line 198
    .line 199
    if-ne p2, p1, :cond_8

    .line 200
    .line 201
    iget-object p1, p0, LAe/o;->b:Ljava/lang/Object;

    .line 202
    .line 203
    check-cast p1, LAe/p;

    .line 204
    .line 205
    iget-object p2, p1, LAe/p;->g:Lxf/t;

    .line 206
    .line 207
    invoke-virtual {p2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object p2

    .line 211
    check-cast p2, Lcom/wang/avi/AVLoadingIndicatorView;

    .line 212
    .line 213
    new-instance v0, LAe/n;

    .line 214
    .line 215
    const/4 v1, 0x0

    .line 216
    invoke-direct {v0, p1, v1}, LAe/n;-><init>(Ljava/lang/Object;I)V

    .line 217
    .line 218
    .line 219
    invoke-virtual {p2, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 220
    .line 221
    .line 222
    :cond_8
    return-void

    .line 223
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public onReceivedTitle(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 1

    .line 1
    iget v0, p0, LAe/o;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onReceivedTitle(Landroid/webkit/WebView;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_0
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onReceivedTitle(Landroid/webkit/WebView;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    if-nez p1, :cond_0

    .line 18
    .line 19
    iget-object p1, p0, LAe/o;->b:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p1, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantActivity;

    .line 22
    .line 23
    iget-object p1, p1, Lcom/transsnet/palmpay/ui/activity/thirdpartymerchant/ThirdPartyMerchantActivity;->e:Lcom/palmpay/lib/ui/titlebar/PpTitleBar;

    .line 24
    .line 25
    invoke-virtual {p1, p2}, Lcom/palmpay/lib/ui/titlebar/PpTitleBar;->setTitle(Ljava/lang/CharSequence;)V

    .line 26
    .line 27
    .line 28
    :cond_0
    return-void

    .line 29
    :pswitch_data_0
    .packed-switch 0x7
        :pswitch_0
    .end packed-switch
.end method

.method public onShowFileChooser(Landroid/webkit/WebView;Landroid/webkit/ValueCallback;Landroid/webkit/WebChromeClient$FileChooserParams;)Z
    .locals 2

    .line 1
    iget v0, p0, LAe/o;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebChromeClient;->onShowFileChooser(Landroid/webkit/WebView;Landroid/webkit/ValueCallback;Landroid/webkit/WebChromeClient$FileChooserParams;)Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    return p1

    .line 11
    :pswitch_0
    iget-object p1, p0, LAe/o;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Lcom/transsnet/palmpay/echat/EchatActivity;

    .line 14
    .line 15
    iput-object p2, p1, Lcom/transsnet/palmpay/echat/EchatActivity;->b:Landroid/webkit/ValueCallback;

    .line 16
    .line 17
    const/4 p2, 0x1

    .line 18
    :try_start_0
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 19
    .line 20
    .line 21
    move-result-object p3

    .line 22
    const-string v0, "/account/setUserPhoto"

    .line 23
    .line 24
    invoke-virtual {p3, v0}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 25
    .line 26
    .line 27
    move-result-object p3

    .line 28
    const-string v0, "crop_photo"

    .line 29
    .line 30
    const/4 v1, 0x0

    .line 31
    invoke-virtual {p3, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withBoolean(Ljava/lang/String;Z)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 32
    .line 33
    .line 34
    move-result-object p3

    .line 35
    const-string v0, "origin_photo"

    .line 36
    .line 37
    invoke-virtual {p3, v0, p2}, Lcom/alibaba/android/arouter/facade/Postcard;->withBoolean(Ljava/lang/String;Z)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 38
    .line 39
    .line 40
    move-result-object p3

    .line 41
    const-string v0, "photoBig"

    .line 42
    .line 43
    invoke-virtual {p3, v0, p2}, Lcom/alibaba/android/arouter/facade/Postcard;->withBoolean(Ljava/lang/String;Z)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 44
    .line 45
    .line 46
    move-result-object p3

    .line 47
    const/16 v0, 0xfe

    .line 48
    .line 49
    invoke-virtual {p3, p1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/app/Activity;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 50
    .line 51
    .line 52
    :catch_0
    return p2

    .line 53
    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_0
    .end packed-switch
.end method
