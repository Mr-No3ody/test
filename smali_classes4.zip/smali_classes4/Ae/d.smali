.class public final synthetic LAe/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;I)V
    .locals 0

    .line 1
    iput p2, p0, LAe/d;->a:I

    iput-object p1, p0, LAe/d;->b:Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget p1, p0, LAe/d;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LAe/d;->b:Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;

    .line 7
    .line 8
    new-instance v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;

    .line 9
    .line 10
    invoke-direct {v0}, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;-><init>()V

    .line 11
    .line 12
    .line 13
    iget-boolean v1, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->b:Z

    .line 14
    .line 15
    if-nez v1, :cond_3

    .line 16
    .line 17
    iget-object v1, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->f:Lcom/transsnet/palmpay/custom_view/TitleEditView;

    .line 18
    .line 19
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/TitleEditView;->getEditText()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    iput-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->firstName:Ljava/lang/String;

    .line 24
    .line 25
    iget-object v1, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->g:Lcom/transsnet/palmpay/custom_view/TitleEditView;

    .line 26
    .line 27
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/TitleEditView;->getEditText()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    iput-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->middleName:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v1, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->i:Lcom/transsnet/palmpay/custom_view/TitleEditView;

    .line 34
    .line 35
    invoke-virtual {v1}, Lcom/transsnet/palmpay/custom_view/TitleEditView;->getEditText()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    iput-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->lastName:Ljava/lang/String;

    .line 40
    .line 41
    iget-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->firstName:Ljava/lang/String;

    .line 42
    .line 43
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    if-eqz v1, :cond_0

    .line 48
    .line 49
    iget-object v0, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->f:Lcom/transsnet/palmpay/custom_view/TitleEditView;

    .line 50
    .line 51
    sget v1, Lba/k;->core_msg_sth_is_empty:I

    .line 52
    .line 53
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/TitleEditView;->getTitle()Ljava/lang/CharSequence;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-virtual {p1, v1, v2}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/custom_view/TitleEditView;->setError(Ljava/lang/CharSequence;)V

    .line 66
    .line 67
    .line 68
    goto/16 :goto_1

    .line 69
    .line 70
    :cond_0
    iget-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->lastName:Ljava/lang/String;

    .line 71
    .line 72
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    if-eqz v1, :cond_1

    .line 77
    .line 78
    iget-object v0, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->i:Lcom/transsnet/palmpay/custom_view/TitleEditView;

    .line 79
    .line 80
    sget v1, Lba/k;->core_msg_sth_is_empty:I

    .line 81
    .line 82
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/TitleEditView;->getTitle()Ljava/lang/CharSequence;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    invoke-virtual {p1, v1, v2}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/custom_view/TitleEditView;->setError(Ljava/lang/CharSequence;)V

    .line 95
    .line 96
    .line 97
    goto/16 :goto_1

    .line 98
    .line 99
    :cond_1
    iget-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->firstName:Ljava/lang/String;

    .line 100
    .line 101
    iget-object v2, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->a:Lcom/transsnet/palmpay/core/db/entity/User;

    .line 102
    .line 103
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/db/entity/User;->getFirstName()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    if-eqz v1, :cond_2

    .line 112
    .line 113
    iget-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->lastName:Ljava/lang/String;

    .line 114
    .line 115
    iget-object v2, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->a:Lcom/transsnet/palmpay/core/db/entity/User;

    .line 116
    .line 117
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/db/entity/User;->getLastName()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    if-eqz v1, :cond_2

    .line 126
    .line 127
    iget-object v0, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->i:Lcom/transsnet/palmpay/custom_view/TitleEditView;

    .line 128
    .line 129
    sget v1, LAc/h;->main_msg_name_is_same:I

    .line 130
    .line 131
    invoke-virtual {p1, v1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/custom_view/TitleEditView;->setError(Ljava/lang/CharSequence;)V

    .line 136
    .line 137
    .line 138
    goto :goto_1

    .line 139
    :cond_2
    iget-object v1, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->a:Lcom/transsnet/palmpay/core/db/entity/User;

    .line 140
    .line 141
    const/4 v2, 0x0

    .line 142
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/db/entity/User;->setUpdateNameFlag(I)V

    .line 143
    .line 144
    .line 145
    goto :goto_0

    .line 146
    :cond_3
    iget-object v1, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->j:Lcom/palmpay/lib/ui/form/PpFormVertical;

    .line 147
    .line 148
    invoke-virtual {v1}, Lcom/palmpay/lib/ui/form/PpFormVertical;->getEditContent()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    iput-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->nickName:Ljava/lang/String;

    .line 153
    .line 154
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    const/4 v2, 0x1

    .line 159
    if-eqz v1, :cond_4

    .line 160
    .line 161
    sget v0, Lba/k;->core_msg_sth_is_empty:I

    .line 162
    .line 163
    sget v1, LAc/h;->main_nick_name:I

    .line 164
    .line 165
    invoke-virtual {p1, v1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    invoke-virtual {p1, v0, v1}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    invoke-virtual {p1, v0, v2}, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->g(Ljava/lang/String;Z)V

    .line 178
    .line 179
    .line 180
    goto :goto_1

    .line 181
    :cond_4
    iget-object v1, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->nickName:Ljava/lang/String;

    .line 182
    .line 183
    invoke-static {v1}, Landroid/text/TextUtils;->isDigitsOnly(Ljava/lang/CharSequence;)Z

    .line 184
    .line 185
    .line 186
    move-result v1

    .line 187
    if-eqz v1, :cond_5

    .line 188
    .line 189
    sget v0, LAc/h;->main_msg_valid_characters_only:I

    .line 190
    .line 191
    invoke-virtual {p1, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    invoke-virtual {p1, v0, v2}, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->g(Ljava/lang/String;Z)V

    .line 196
    .line 197
    .line 198
    goto :goto_1

    .line 199
    :cond_5
    iget-object v1, p1, Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;->a:Lcom/transsnet/palmpay/core/db/entity/User;

    .line 200
    .line 201
    iget-object v2, v0, Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;->nickName:Ljava/lang/String;

    .line 202
    .line 203
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/db/entity/User;->setNickName(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    :goto_0
    invoke-static {}, LG8/a;->t()Lcom/transsnet/palmpay/account/business/IApiAccountService;

    .line 207
    .line 208
    .line 209
    move-result-object v1

    .line 210
    invoke-interface {v1, v0}, Lcom/transsnet/palmpay/account/business/IApiAccountService;->changeUserName(Lcom/transsnet/palmpay/account/bean/req/ChangeUserInfoReq;)Ldf/d;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 215
    .line 216
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 217
    .line 218
    .line 219
    move-result-object v0

    .line 220
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 221
    .line 222
    .line 223
    move-result-object v1

    .line 224
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    new-instance v1, LAb/D;

    .line 229
    .line 230
    const/4 v2, 0x1

    .line 231
    invoke-direct {v1, p1, v2}, LAb/D;-><init>(Ljava/lang/Object;I)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 235
    .line 236
    .line 237
    :goto_1
    return-void

    .line 238
    :pswitch_0
    iget-object p1, p0, LAe/d;->b:Lcom/transsnet/palmpay/ui/dialog/EditNameDialogFragment;

    .line 239
    .line 240
    invoke-virtual {p1}, Landroidx/fragment/app/DialogFragment;->dismissAllowingStateLoss()V

    .line 241
    .line 242
    .line 243
    return-void

    .line 244
    nop

    .line 245
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
