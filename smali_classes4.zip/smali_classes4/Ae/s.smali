.class public final LAe/s;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

.field public final synthetic b:Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/bean/CommonBeanResult;Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LAe/s;->a:Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 2
    .line 3
    iput-object p2, p0, LAe/s;->b:Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LAe/s;

    .line 2
    .line 3
    iget-object v0, p0, LAe/s;->a:Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 4
    .line 5
    iget-object v1, p0, LAe/s;->b:Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;

    .line 6
    .line 7
    invoke-direct {p1, v0, v1, p2}, LAe/s;-><init>(Lcom/transsnet/palmpay/core/bean/CommonBeanResult;Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;Lkotlin/coroutines/Continuation;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LAe/s;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LAe/s;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LAe/s;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LAe/s;->a:Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 7
    .line 8
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    iget-object v0, p0, LAe/s;->b:Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;

    .line 15
    .line 16
    invoke-static {v0}, Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;->access$getText3(Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;)Landroid/widget/TextView;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    new-instance v1, LA8/b;

    .line 23
    .line 24
    const/16 v2, 0xd

    .line 25
    .line 26
    invoke-direct {v1, p1, v2}, LA8/b;-><init>(Ljava/lang/Object;I)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 30
    .line 31
    .line 32
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 33
    .line 34
    return-object p1

    .line 35
    :cond_0
    const/4 p1, 0x0

    .line 36
    return-object p1

    .line 37
    :cond_1
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    const/4 v0, 0x0

    .line 42
    new-array v0, v0, [Ljava/lang/Object;

    .line 43
    .line 44
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 48
    .line 49
    return-object p1
.end method
