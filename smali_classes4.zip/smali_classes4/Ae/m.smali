.class public final synthetic LAe/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LAe/p;


# direct methods
.method public synthetic constructor <init>(LAe/p;I)V
    .locals 0

    .line 1
    iput p2, p0, LAe/m;->a:I

    iput-object p1, p0, LAe/m;->b:LAe/p;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LAe/m;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget v0, LAc/e;->imageViewClose:I

    .line 7
    .line 8
    iget-object v1, p0, LAe/m;->b:LAe/p;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Landroid/widget/ImageView;

    .line 15
    .line 16
    return-object v0

    .line 17
    :pswitch_0
    sget v0, LAc/e;->ll_web:I

    .line 18
    .line 19
    iget-object v1, p0, LAe/m;->b:LAe/p;

    .line 20
    .line 21
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Landroid/widget/LinearLayout;

    .line 26
    .line 27
    return-object v0

    .line 28
    :pswitch_1
    sget v0, LAc/e;->loadingView:I

    .line 29
    .line 30
    iget-object v1, p0, LAe/m;->b:LAe/p;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Lcom/wang/avi/AVLoadingIndicatorView;

    .line 37
    .line 38
    return-object v0

    .line 39
    :pswitch_2
    sget v0, LAc/e;->tvNo:I

    .line 40
    .line 41
    iget-object v1, p0, LAe/m;->b:LAe/p;

    .line 42
    .line 43
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Landroid/widget/TextView;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_3
    sget v0, LAc/e;->tvYes:I

    .line 51
    .line 52
    iget-object v1, p0, LAe/m;->b:LAe/p;

    .line 53
    .line 54
    invoke-virtual {v1, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    check-cast v0, Landroid/widget/TextView;

    .line 59
    .line 60
    return-object v0

    .line 61
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
