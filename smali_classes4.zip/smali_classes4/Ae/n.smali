.class public final synthetic LAe/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LAe/n;->a:I

    iput-object p1, p0, LAe/n;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    .line 1
    const/high16 v0, 0x40000000    # 2.0f

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x1

    .line 6
    iget v4, p0, LAe/n;->a:I

    .line 7
    .line 8
    packed-switch v4, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    sget-object v0, Lcom/transsnet/palmpay/service/PushMainService;->f:Lcom/transsnet/palmpay/service/PushMainService$a;

    .line 12
    .line 13
    const-string v0, "main service bind sub push service"

    .line 14
    .line 15
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const/4 v1, 0x5

    .line 20
    const-string v2, "aidl-service-main"

    .line 21
    .line 22
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v0, Lcom/transsnet/palmpay/service/PushMainService;

    .line 28
    .line 29
    iput-boolean v3, v0, Lcom/transsnet/palmpay/service/PushMainService;->a:Z

    .line 30
    .line 31
    new-instance v1, Landroid/content/Intent;

    .line 32
    .line 33
    const-class v2, Lcom/transsnet/palmpay/service/PushSubService;

    .line 34
    .line 35
    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 36
    .line 37
    .line 38
    iget-object v2, v0, Lcom/transsnet/palmpay/service/PushMainService;->b:Lxf/t;

    .line 39
    .line 40
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    check-cast v2, LLd/c;

    .line 45
    .line 46
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :pswitch_0
    invoke-static {v1}, Landroid/os/Process;->setThreadPriority(I)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v0, Ljava/lang/Runnable;

    .line 56
    .line 57
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :pswitch_1
    sget v1, Lcom/palmpay/lib/scanplus/view/ScanLineView;->Q:I

    .line 62
    .line 63
    const-string v1, "this$0"

    .line 64
    .line 65
    iget-object v2, p0, LAe/n;->b:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v2, Lcom/palmpay/lib/scanplus/view/ScanLineView;

    .line 68
    .line 69
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    invoke-static {v1, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 81
    .line 82
    .line 83
    move-result v3

    .line 84
    invoke-static {v3, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    invoke-virtual {v2, v1, v0}, Landroid/view/View;->measure(II)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2}, Landroid/view/View;->getLeft()I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    invoke-virtual {v2}, Landroid/view/View;->getRight()I

    .line 100
    .line 101
    .line 102
    move-result v3

    .line 103
    invoke-virtual {v2}, Landroid/view/View;->getBottom()I

    .line 104
    .line 105
    .line 106
    move-result v4

    .line 107
    invoke-virtual {v2, v0, v1, v3, v4}, Landroid/view/View;->layout(IIII)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :pswitch_2
    sget v1, Lcom/palmpay/lib/scanplus/view/CodePointView;->A:I

    .line 112
    .line 113
    const-string v1, "this$0"

    .line 114
    .line 115
    iget-object v2, p0, LAe/n;->b:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast v2, Lcom/palmpay/lib/scanplus/view/CodePointView;

    .line 118
    .line 119
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 123
    .line 124
    .line 125
    move-result v1

    .line 126
    invoke-static {v1, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 127
    .line 128
    .line 129
    move-result v1

    .line 130
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 131
    .line 132
    .line 133
    move-result v3

    .line 134
    invoke-static {v3, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    invoke-virtual {v2, v1, v0}, Landroid/view/View;->measure(II)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v2}, Landroid/view/View;->getLeft()I

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    .line 146
    .line 147
    .line 148
    move-result v1

    .line 149
    invoke-virtual {v2}, Landroid/view/View;->getRight()I

    .line 150
    .line 151
    .line 152
    move-result v3

    .line 153
    invoke-virtual {v2}, Landroid/view/View;->getBottom()I

    .line 154
    .line 155
    .line 156
    move-result v4

    .line 157
    invoke-virtual {v2, v0, v1, v3, v4}, Landroid/view/View;->layout(IIII)V

    .line 158
    .line 159
    .line 160
    return-void

    .line 161
    :pswitch_3
    sget v0, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;->j:I

    .line 162
    .line 163
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 164
    .line 165
    check-cast v0, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;

    .line 166
    .line 167
    iget-object v1, v0, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;->d:LP6/a;

    .line 168
    .line 169
    if-eqz v1, :cond_1

    .line 170
    .line 171
    invoke-virtual {v1}, Landroid/app/Dialog;->isShowing()Z

    .line 172
    .line 173
    .line 174
    move-result v3

    .line 175
    if-eqz v3, :cond_0

    .line 176
    .line 177
    goto :goto_0

    .line 178
    :cond_0
    move-object v1, v2

    .line 179
    :goto_0
    if-eqz v1, :cond_1

    .line 180
    .line 181
    invoke-virtual {v1}, LO6/a;->dismiss()V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v1, v2}, LO6/f;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V

    .line 185
    .line 186
    .line 187
    :cond_1
    iput-object v2, v0, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;->d:LP6/a;

    .line 188
    .line 189
    return-void

    .line 190
    :pswitch_4
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 191
    .line 192
    check-cast v0, LK3/d;

    .line 193
    .line 194
    invoke-virtual {v0}, LK3/d;->loadingDismiss()V

    .line 195
    .line 196
    .line 197
    return-void

    .line 198
    :pswitch_5
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 199
    .line 200
    check-cast v0, LJe/j;

    .line 201
    .line 202
    iget-object v0, v0, LJe/j;->d:Landroid/widget/ViewFlipper;

    .line 203
    .line 204
    if-eqz v0, :cond_2

    .line 205
    .line 206
    invoke-virtual {v0}, Landroid/widget/ViewFlipper;->startFlipping()V

    .line 207
    .line 208
    .line 209
    :cond_2
    return-void

    .line 210
    :pswitch_6
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 211
    .line 212
    check-cast v0, LIe/m;

    .line 213
    .line 214
    invoke-virtual {v0}, LIe/m;->a()V

    .line 215
    .line 216
    .line 217
    return-void

    .line 218
    :pswitch_7
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 219
    .line 220
    check-cast v0, Lcom/transsnet/palmpay/ui/view/ModelPremiumScrollNotice;

    .line 221
    .line 222
    iput v1, v0, Lcom/transsnet/palmpay/ui/view/ModelPremiumScrollNotice;->e:I

    .line 223
    .line 224
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    .line 225
    .line 226
    .line 227
    return-void

    .line 228
    :pswitch_8
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 229
    .line 230
    check-cast v0, LHb/z;

    .line 231
    .line 232
    iget-object v0, v0, LHb/z;->e:Landroid/animation/AnimatorSet;

    .line 233
    .line 234
    if-eqz v0, :cond_3

    .line 235
    .line 236
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 237
    .line 238
    .line 239
    :cond_3
    return-void

    .line 240
    :pswitch_9
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 241
    .line 242
    check-cast v0, LHb/x;

    .line 243
    .line 244
    iget-object v0, v0, LHb/x;->e:Landroid/animation/AnimatorSet;

    .line 245
    .line 246
    if-eqz v0, :cond_4

    .line 247
    .line 248
    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    .line 249
    .line 250
    .line 251
    :cond_4
    return-void

    .line 252
    :pswitch_a
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 253
    .line 254
    check-cast v0, Lcom/transsnet/palmpay/credit/view/ProductContentListView;

    .line 255
    .line 256
    invoke-static {v0}, Lcom/transsnet/palmpay/credit/view/ProductContentListView;->e(Lcom/transsnet/palmpay/credit/view/ProductContentListView;)V

    .line 257
    .line 258
    .line 259
    return-void

    .line 260
    :pswitch_b
    sget v0, Lcom/transsnet/palmpay/credit/view/MultiLoanCtaLightView;->p:I

    .line 261
    .line 262
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 263
    .line 264
    check-cast v0, Lcom/transsnet/palmpay/credit/view/MultiLoanCtaLightView;

    .line 265
    .line 266
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/view/MultiLoanCtaLightView;->b()V

    .line 267
    .line 268
    .line 269
    return-void

    .line 270
    :pswitch_c
    sget v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->t0:I

    .line 271
    .line 272
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 273
    .line 274
    check-cast v0, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;

    .line 275
    .line 276
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 277
    .line 278
    .line 279
    move-result-object v1

    .line 280
    invoke-static {v1}, LPa/i0;->W(Landroid/app/Activity;)Z

    .line 281
    .line 282
    .line 283
    move-result v1

    .line 284
    if-nez v1, :cond_5

    .line 285
    .line 286
    goto :goto_1

    .line 287
    :cond_5
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/fragment/WithdrawHomeFragment;->u()V

    .line 288
    .line 289
    .line 290
    :goto_1
    return-void

    .line 291
    :pswitch_d
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 292
    .line 293
    check-cast v0, LE2/a;

    .line 294
    .line 295
    iget-object v0, v0, LE2/a;->e:Ljava/lang/Object;

    .line 296
    .line 297
    check-cast v0, LG/h;

    .line 298
    .line 299
    if-eqz v0, :cond_6

    .line 300
    .line 301
    invoke-virtual {v0}, Ljava/util/AbstractMap;->values()Ljava/util/Collection;

    .line 302
    .line 303
    .line 304
    move-result-object v0

    .line 305
    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 306
    .line 307
    .line 308
    move-result-object v0

    .line 309
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 310
    .line 311
    .line 312
    move-result v1

    .line 313
    if-eqz v1, :cond_6

    .line 314
    .line 315
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object v1

    .line 319
    check-cast v1, Landroidx/camera/core/processing/m;

    .line 320
    .line 321
    invoke-virtual {v1}, Landroidx/camera/core/processing/m;->c()V

    .line 322
    .line 323
    .line 324
    goto :goto_2

    .line 325
    :cond_6
    return-void

    .line 326
    :pswitch_e
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 327
    .line 328
    check-cast v0, LG/f;

    .line 329
    .line 330
    iput-boolean v3, v0, LG/f;->f:Z

    .line 331
    .line 332
    invoke-virtual {v0}, LG/f;->a()V

    .line 333
    .line 334
    .line 335
    return-void

    .line 336
    :pswitch_f
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 337
    .line 338
    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeFragment;

    .line 339
    .line 340
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->isAdded()Z

    .line 341
    .line 342
    .line 343
    move-result v1

    .line 344
    if-eqz v1, :cond_e

    .line 345
    .line 346
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    .line 347
    .line 348
    .line 349
    move-result-object v1

    .line 350
    if-nez v1, :cond_7

    .line 351
    .line 352
    goto/16 :goto_4

    .line 353
    .line 354
    :cond_7
    invoke-virtual {v0}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeFragment;->y()V

    .line 355
    .line 356
    .line 357
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 358
    .line 359
    check-cast v1, Lod/r;

    .line 360
    .line 361
    if-eqz v1, :cond_8

    .line 362
    .line 363
    iget-object v1, v1, Lod/r;->t:Lcom/transsnet/palmpay/send_money/ui/view/TransferToPalmPayAccountView;

    .line 364
    .line 365
    iget-object v1, v1, Lcom/transsnet/palmpay/send_money/ui/view/TransferToPalmPayAccountView;->c:LBc/D;

    .line 366
    .line 367
    if-eqz v1, :cond_8

    .line 368
    .line 369
    iget-object v1, v1, LBc/D;->p:Landroid/view/View;

    .line 370
    .line 371
    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/view/ClipboardAccountPromptView;

    .line 372
    .line 373
    iget-object v3, v1, Lcom/transsnet/palmpay/send_money/ui/view/ClipboardAccountPromptView;->a:LBc/p;

    .line 374
    .line 375
    iget-object v3, v3, LBc/p;->d:Ljava/lang/Object;

    .line 376
    .line 377
    check-cast v3, Landroid/widget/TextView;

    .line 378
    .line 379
    invoke-virtual {v3, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 380
    .line 381
    .line 382
    invoke-static {v1}, Loa/h;->c(Landroid/view/View;)V

    .line 383
    .line 384
    .line 385
    :cond_8
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    .line 386
    .line 387
    .line 388
    move-result-object v1

    .line 389
    iget-object v3, v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeFragment;->L:Lxf/t;

    .line 390
    .line 391
    if-nez v1, :cond_9

    .line 392
    .line 393
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 394
    .line 395
    .line 396
    move-result-object v0

    .line 397
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;

    .line 398
    .line 399
    invoke-virtual {v0}, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;->d()V

    .line 400
    .line 401
    .line 402
    goto :goto_4

    .line 403
    :cond_9
    invoke-static {}, LPa/e;->d()Z

    .line 404
    .line 405
    .line 406
    move-result v1

    .line 407
    if-eqz v1, :cond_d

    .line 408
    .line 409
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 410
    .line 411
    .line 412
    move-result v1

    .line 413
    if-eqz v1, :cond_d

    .line 414
    .line 415
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->isVisible()Z

    .line 416
    .line 417
    .line 418
    move-result v1

    .line 419
    if-eqz v1, :cond_d

    .line 420
    .line 421
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    .line 422
    .line 423
    .line 424
    move-result-object v1

    .line 425
    invoke-interface {v1}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/o;

    .line 426
    .line 427
    .line 428
    move-result-object v1

    .line 429
    check-cast v1, Landroidx/lifecycle/w;

    .line 430
    .line 431
    iget-object v1, v1, Landroidx/lifecycle/w;->d:Landroidx/lifecycle/n;

    .line 432
    .line 433
    sget-object v4, Landroidx/lifecycle/n;->e:Landroidx/lifecycle/n;

    .line 434
    .line 435
    invoke-virtual {v1, v4}, Landroidx/lifecycle/n;->a(Landroidx/lifecycle/n;)Z

    .line 436
    .line 437
    .line 438
    move-result v1

    .line 439
    if-nez v1, :cond_a

    .line 440
    .line 441
    goto :goto_3

    .line 442
    :cond_a
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 443
    .line 444
    .line 445
    move-result-object v0

    .line 446
    if-eqz v0, :cond_b

    .line 447
    .line 448
    invoke-static {v0}, LPa/e;->c(Landroid/content/Context;)Ljava/lang/String;

    .line 449
    .line 450
    .line 451
    move-result-object v2

    .line 452
    :cond_b
    if-nez v2, :cond_c

    .line 453
    .line 454
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 455
    .line 456
    .line 457
    move-result-object v0

    .line 458
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;

    .line 459
    .line 460
    invoke-virtual {v0}, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;->d()V

    .line 461
    .line 462
    .line 463
    goto :goto_4

    .line 464
    :cond_c
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 465
    .line 466
    .line 467
    move-result-object v0

    .line 468
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;

    .line 469
    .line 470
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;->e(Ljava/lang/String;)V

    .line 471
    .line 472
    .line 473
    goto :goto_4

    .line 474
    :cond_d
    :goto_3
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 475
    .line 476
    .line 477
    move-result-object v0

    .line 478
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;

    .line 479
    .line 480
    invoke-virtual {v0}, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;->d()V

    .line 481
    .line 482
    .line 483
    :cond_e
    :goto_4
    return-void

    .line 484
    :pswitch_10
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 485
    .line 486
    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomeFragment;

    .line 487
    .line 488
    iget-object v1, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmVBFragment;->j:Landroidx/viewbinding/ViewBinding;

    .line 489
    .line 490
    check-cast v1, Lod/q;

    .line 491
    .line 492
    if-eqz v1, :cond_f

    .line 493
    .line 494
    iget-object v1, v1, Lod/q;->i:Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankAccountView;

    .line 495
    .line 496
    iget-object v1, v1, Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankAccountView;->c:LBc/E;

    .line 497
    .line 498
    if-eqz v1, :cond_f

    .line 499
    .line 500
    iget-object v1, v1, LBc/E;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 501
    .line 502
    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/view/ClipboardAccountPromptView;

    .line 503
    .line 504
    iget-object v3, v1, Lcom/transsnet/palmpay/send_money/ui/view/ClipboardAccountPromptView;->a:LBc/p;

    .line 505
    .line 506
    iget-object v3, v3, LBc/p;->d:Ljava/lang/Object;

    .line 507
    .line 508
    check-cast v3, Landroid/widget/TextView;

    .line 509
    .line 510
    invoke-virtual {v3, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 511
    .line 512
    .line 513
    invoke-static {v1}, Loa/h;->c(Landroid/view/View;)V

    .line 514
    .line 515
    .line 516
    :cond_f
    invoke-static {}, LPa/e;->d()Z

    .line 517
    .line 518
    .line 519
    move-result v1

    .line 520
    iget-object v3, v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomeFragment;->v:Lxf/t;

    .line 521
    .line 522
    if-eqz v1, :cond_13

    .line 523
    .line 524
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 525
    .line 526
    .line 527
    move-result v1

    .line 528
    if-eqz v1, :cond_13

    .line 529
    .line 530
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->isVisible()Z

    .line 531
    .line 532
    .line 533
    move-result v1

    .line 534
    if-eqz v1, :cond_13

    .line 535
    .line 536
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    .line 537
    .line 538
    .line 539
    move-result-object v1

    .line 540
    invoke-interface {v1}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/o;

    .line 541
    .line 542
    .line 543
    move-result-object v1

    .line 544
    check-cast v1, Landroidx/lifecycle/w;

    .line 545
    .line 546
    iget-object v1, v1, Landroidx/lifecycle/w;->d:Landroidx/lifecycle/n;

    .line 547
    .line 548
    sget-object v4, Landroidx/lifecycle/n;->e:Landroidx/lifecycle/n;

    .line 549
    .line 550
    invoke-virtual {v1, v4}, Landroidx/lifecycle/n;->a(Landroidx/lifecycle/n;)Z

    .line 551
    .line 552
    .line 553
    move-result v1

    .line 554
    if-nez v1, :cond_10

    .line 555
    .line 556
    goto :goto_5

    .line 557
    :cond_10
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 558
    .line 559
    .line 560
    move-result-object v0

    .line 561
    if-eqz v0, :cond_11

    .line 562
    .line 563
    invoke-static {v0}, LPa/e;->c(Landroid/content/Context;)Ljava/lang/String;

    .line 564
    .line 565
    .line 566
    move-result-object v0

    .line 567
    if-eqz v0, :cond_11

    .line 568
    .line 569
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 570
    .line 571
    .line 572
    move-result v1

    .line 573
    const/16 v4, 0xa

    .line 574
    .line 575
    if-ne v1, v4, :cond_11

    .line 576
    .line 577
    move-object v2, v0

    .line 578
    :cond_11
    if-nez v2, :cond_12

    .line 579
    .line 580
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 581
    .line 582
    .line 583
    move-result-object v0

    .line 584
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;

    .line 585
    .line 586
    invoke-virtual {v0}, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;->d()V

    .line 587
    .line 588
    .line 589
    goto :goto_6

    .line 590
    :cond_12
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 591
    .line 592
    .line 593
    move-result-object v0

    .line 594
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;

    .line 595
    .line 596
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;->e(Ljava/lang/String;)V

    .line 597
    .line 598
    .line 599
    goto :goto_6

    .line 600
    :cond_13
    :goto_5
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 601
    .line 602
    .line 603
    move-result-object v0

    .line 604
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;

    .line 605
    .line 606
    invoke-virtual {v0}, Lcom/transsnet/palmpay/send_money/viewmodel/ClipboardMatchInfoViewModel;->d()V

    .line 607
    .line 608
    .line 609
    :goto_6
    return-void

    .line 610
    :pswitch_11
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 611
    .line 612
    check-cast v0, LE/b0;

    .line 613
    .line 614
    invoke-virtual {v0}, LE/n0;->o()V

    .line 615
    .line 616
    .line 617
    return-void

    .line 618
    :pswitch_12
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 619
    .line 620
    check-cast v0, LE/J;

    .line 621
    .line 622
    iget-object v1, v0, LE/J;->Q:Ljava/lang/Object;

    .line 623
    .line 624
    monitor-enter v1

    .line 625
    :try_start_0
    iput-object v2, v0, LE/J;->Y:LE/I;

    .line 626
    .line 627
    iget-object v3, v0, LE/J;->X:Landroidx/camera/core/ImageProxy;

    .line 628
    .line 629
    if-eqz v3, :cond_14

    .line 630
    .line 631
    iput-object v2, v0, LE/J;->X:Landroidx/camera/core/ImageProxy;

    .line 632
    .line 633
    invoke-virtual {v0, v3}, LE/J;->e(Landroidx/camera/core/ImageProxy;)V

    .line 634
    .line 635
    .line 636
    goto :goto_7

    .line 637
    :catchall_0
    move-exception v0

    .line 638
    goto :goto_8

    .line 639
    :cond_14
    :goto_7
    monitor-exit v1

    .line 640
    return-void

    .line 641
    :goto_8
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 642
    throw v0

    .line 643
    :pswitch_13
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 644
    .line 645
    check-cast v0, Lcom/transsnet/palmpay/core/rnbridge/modules/PPRNBridge;

    .line 646
    .line 647
    invoke-static {v0}, Lcom/transsnet/palmpay/core/rnbridge/modules/PPRNBridge;->l(Lcom/transsnet/palmpay/core/rnbridge/modules/PPRNBridge;)V

    .line 648
    .line 649
    .line 650
    return-void

    .line 651
    :pswitch_14
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 652
    .line 653
    check-cast v0, LD/d;

    .line 654
    .line 655
    iget-object v1, v0, LD/d;->g:Ljava/lang/Object;

    .line 656
    .line 657
    check-cast v1, Landroidx/concurrent/futures/k;

    .line 658
    .line 659
    if-eqz v1, :cond_15

    .line 660
    .line 661
    invoke-virtual {v1, v2}, Landroidx/concurrent/futures/k;->b(Ljava/lang/Object;)Z

    .line 662
    .line 663
    .line 664
    iput-object v2, v0, LD/d;->g:Ljava/lang/Object;

    .line 665
    .line 666
    :cond_15
    return-void

    .line 667
    :pswitch_15
    sget v0, Lcom/transsnet/palmpay/ui/fragment/TransactionHistoryFragment;->k0:I

    .line 668
    .line 669
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 670
    .line 671
    check-cast v0, Lcom/transsnet/palmpay/ui/fragment/TransactionHistoryFragment;

    .line 672
    .line 673
    invoke-virtual {v0}, Lcom/transsnet/palmpay/ui/fragment/TransactionHistoryFragment;->v()Lve/w;

    .line 674
    .line 675
    .line 676
    move-result-object v0

    .line 677
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 678
    .line 679
    .line 680
    return-void

    .line 681
    :pswitch_16
    sget v0, Lcom/transsnet/palmpay/send_money/ui/fragment/MoneyTransferHistoryFragment;->X:I

    .line 682
    .line 683
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 684
    .line 685
    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/fragment/MoneyTransferHistoryFragment;

    .line 686
    .line 687
    invoke-virtual {v0}, Lcom/transsnet/palmpay/send_money/ui/fragment/MoneyTransferHistoryFragment;->w()Lld/d;

    .line 688
    .line 689
    .line 690
    move-result-object v0

    .line 691
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 692
    .line 693
    .line 694
    return-void

    .line 695
    :pswitch_17
    sget-object v0, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawResultActivity;->A:[Ljava/lang/String;

    .line 696
    .line 697
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 698
    .line 699
    check-cast v0, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawResultActivity;

    .line 700
    .line 701
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawResultActivity;->l()V

    .line 702
    .line 703
    .line 704
    return-void

    .line 705
    :pswitch_18
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 706
    .line 707
    check-cast v0, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;

    .line 708
    .line 709
    iget-object v1, v0, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;->B:Lxf/t;

    .line 710
    .line 711
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 712
    .line 713
    .line 714
    move-result-object v1

    .line 715
    const-string v2, "getValue(...)"

    .line 716
    .line 717
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 718
    .line 719
    .line 720
    check-cast v1, Landroid/widget/ScrollView;

    .line 721
    .line 722
    const/16 v2, 0x82

    .line 723
    .line 724
    invoke-virtual {v1, v2}, Landroid/widget/ScrollView;->fullScroll(I)Z

    .line 725
    .line 726
    .line 727
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/activity/RechargeActivity;->p()Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 728
    .line 729
    .line 730
    move-result-object v0

    .line 731
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 732
    .line 733
    .line 734
    return-void

    .line 735
    :pswitch_19
    sget-object v0, Lcom/transsnet/palmpay/cash_in/ui/activity/FundResultActivity;->v:[Ljava/lang/String;

    .line 736
    .line 737
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 738
    .line 739
    check-cast v0, Lcom/transsnet/palmpay/cash_in/ui/activity/FundResultActivity;

    .line 740
    .line 741
    invoke-virtual {v0}, Lcom/transsnet/palmpay/cash_in/ui/activity/FundResultActivity;->l()V

    .line 742
    .line 743
    .line 744
    return-void

    .line 745
    :pswitch_1a
    sget-object v0, Lcom/palmpay/lib/liveness/video/VideoActivity;->B:Landroid/util/Size;

    .line 746
    .line 747
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 748
    .line 749
    check-cast v0, Lcom/palmpay/lib/liveness/video/VideoActivity;

    .line 750
    .line 751
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 752
    .line 753
    .line 754
    move-result-object v0

    .line 755
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 756
    .line 757
    .line 758
    move-result-object v0

    .line 759
    const/4 v1, -0x1

    .line 760
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 761
    .line 762
    .line 763
    return-void

    .line 764
    :pswitch_1b
    sget v0, Lcom/transsnet/mtn/sdk/ui/view/InputView;->B:I

    .line 765
    .line 766
    new-instance v0, LB8/b;

    .line 767
    .line 768
    invoke-direct {v0, v3}, LB8/b;-><init>(I)V

    .line 769
    .line 770
    .line 771
    iget-object v2, p0, LAe/n;->b:Ljava/lang/Object;

    .line 772
    .line 773
    check-cast v2, Lcom/transsnet/mtn/sdk/ui/view/InputView;

    .line 774
    .line 775
    iget v4, v2, Lcom/transsnet/mtn/sdk/ui/view/InputView;->g:I

    .line 776
    .line 777
    if-lez v4, :cond_16

    .line 778
    .line 779
    const/4 v5, 0x2

    .line 780
    goto :goto_9

    .line 781
    :cond_16
    move v5, v3

    .line 782
    :goto_9
    new-array v5, v5, [Landroid/text/InputFilter;

    .line 783
    .line 784
    aput-object v0, v5, v1

    .line 785
    .line 786
    if-lez v4, :cond_17

    .line 787
    .line 788
    new-instance v0, Landroid/text/InputFilter$LengthFilter;

    .line 789
    .line 790
    iget v1, v2, Lcom/transsnet/mtn/sdk/ui/view/InputView;->g:I

    .line 791
    .line 792
    invoke-direct {v0, v1}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    .line 793
    .line 794
    .line 795
    aput-object v0, v5, v3

    .line 796
    .line 797
    :cond_17
    iget-object v0, v2, Lcom/transsnet/mtn/sdk/ui/view/InputView;->a:Landroidx/appcompat/widget/AppCompatEditText;

    .line 798
    .line 799
    invoke-virtual {v0}, Landroid/widget/TextView;->getEditableText()Landroid/text/Editable;

    .line 800
    .line 801
    .line 802
    move-result-object v0

    .line 803
    invoke-interface {v0, v5}, Landroid/text/Editable;->setFilters([Landroid/text/InputFilter;)V

    .line 804
    .line 805
    .line 806
    return-void

    .line 807
    :pswitch_1c
    sget v0, LAe/p;->o:I

    .line 808
    .line 809
    iget-object v0, p0, LAe/n;->b:Ljava/lang/Object;

    .line 810
    .line 811
    check-cast v0, LAe/p;

    .line 812
    .line 813
    iget-object v1, v0, LAe/p;->g:Lxf/t;

    .line 814
    .line 815
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 816
    .line 817
    .line 818
    move-result-object v1

    .line 819
    check-cast v1, Lcom/wang/avi/AVLoadingIndicatorView;

    .line 820
    .line 821
    const/16 v2, 0x8

    .line 822
    .line 823
    invoke-virtual {v1, v2}, Lcom/wang/avi/AVLoadingIndicatorView;->setVisibility(I)V

    .line 824
    .line 825
    .line 826
    iget-object v0, v0, LAe/p;->e:Lxf/t;

    .line 827
    .line 828
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 829
    .line 830
    .line 831
    move-result-object v0

    .line 832
    check-cast v0, Landroid/widget/TextView;

    .line 833
    .line 834
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 835
    .line 836
    .line 837
    return-void

    .line 838
    nop

    .line 839
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
