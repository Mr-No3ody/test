.class public final synthetic LAe/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;I)V
    .locals 0

    .line 1
    iput p3, p0, LAe/q;->a:I

    iput-object p1, p0, LAe/q;->b:Ljava/lang/String;

    iput-object p2, p0, LAe/q;->c:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    .line 1
    const-string v0, "ReFaceVerifyError_Text"

    .line 2
    .line 3
    const-string v1, "ReFaceVerifyError_type"

    .line 4
    .line 5
    const-string v2, "KYC_ReFaceVerify_Click"

    .line 6
    .line 7
    iget-object v3, p0, LAe/q;->c:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v4, p0, LAe/q;->b:Ljava/lang/String;

    .line 10
    .line 11
    iget v5, p0, LAe/q;->a:I

    .line 12
    .line 13
    packed-switch v5, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    sget p1, Lcom/transsnet/palmpay/account/ui/fragment/upgrade/UpgradeTier3StepFaceFragment;->p:I

    .line 17
    .line 18
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    new-instance v5, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 23
    .line 24
    invoke-direct {v5, v2}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v5, v1, v4}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    check-cast v1, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 32
    .line 33
    invoke-virtual {v1, v0, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 38
    .line 39
    invoke-virtual {p1, v0}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :pswitch_0
    sget p1, Lcom/transsnet/palmpay/account/ui/fragment/upgrade/UpgradeTier3StepFaceFragment;->p:I

    .line 44
    .line 45
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    new-instance v5, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 50
    .line 51
    invoke-direct {v5, v2}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v5, v1, v4}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    check-cast v1, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 59
    .line 60
    invoke-virtual {v1, v0, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    check-cast v0, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 65
    .line 66
    invoke-virtual {p1, v0}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :pswitch_1
    invoke-static {v4, v3, p1}, Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;->d(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)V

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    nop

    .line 75
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
