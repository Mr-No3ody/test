.class public final LAe/p;
.super LO6/a;
.source "SourceFile"


# static fields
.field public static final synthetic o:I


# instance fields
.field public final d:LCe/l;

.field public final e:Lxf/t;

.field public final f:Lxf/t;

.field public final g:Lxf/t;

.field public final i:Lxf/t;

.field public final j:Lxf/t;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/E;LCe/l;)V
    .locals 1

    .line 1
    const-string v0, "callback"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget v0, LAc/f;->main_dialog_pre_install_build_privacy:I

    .line 7
    .line 8
    invoke-direct {p0, p1, v0}, LO6/a;-><init>(Landroid/content/Context;I)V

    .line 9
    .line 10
    .line 11
    iput-object p2, p0, LAe/p;->d:LCe/l;

    .line 12
    .line 13
    new-instance p1, LAe/m;

    .line 14
    .line 15
    const/4 p2, 0x0

    .line 16
    invoke-direct {p1, p0, p2}, LAe/m;-><init>(LAe/p;I)V

    .line 17
    .line 18
    .line 19
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    iput-object p1, p0, LAe/p;->e:Lxf/t;

    .line 24
    .line 25
    new-instance p1, LAe/m;

    .line 26
    .line 27
    const/4 p2, 0x1

    .line 28
    invoke-direct {p1, p0, p2}, LAe/m;-><init>(LAe/p;I)V

    .line 29
    .line 30
    .line 31
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    iput-object p1, p0, LAe/p;->f:Lxf/t;

    .line 36
    .line 37
    new-instance p1, LAe/m;

    .line 38
    .line 39
    const/4 p2, 0x2

    .line 40
    invoke-direct {p1, p0, p2}, LAe/m;-><init>(LAe/p;I)V

    .line 41
    .line 42
    .line 43
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    iput-object p1, p0, LAe/p;->g:Lxf/t;

    .line 48
    .line 49
    new-instance p1, LAe/m;

    .line 50
    .line 51
    const/4 p2, 0x3

    .line 52
    invoke-direct {p1, p0, p2}, LAe/m;-><init>(LAe/p;I)V

    .line 53
    .line 54
    .line 55
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    iput-object p1, p0, LAe/p;->i:Lxf/t;

    .line 60
    .line 61
    new-instance p1, LAe/m;

    .line 62
    .line 63
    const/4 p2, 0x4

    .line 64
    invoke-direct {p1, p0, p2}, LAe/m;-><init>(LAe/p;I)V

    .line 65
    .line 66
    .line 67
    invoke-static {p1}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    iput-object p1, p0, LAe/p;->j:Lxf/t;

    .line 72
    .line 73
    return-void
.end method

.method public static b(LAe/p;Landroid/view/View;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    sget v0, LAc/e;->imageViewClose:I

    .line 6
    .line 7
    if-eq p1, v0, :cond_2

    .line 8
    .line 9
    sget v0, LAc/e;->tvNo:I

    .line 10
    .line 11
    if-ne p1, v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    sget v0, LAc/e;->tvYes:I

    .line 15
    .line 16
    if-ne p1, v0, :cond_1

    .line 17
    .line 18
    iget-object p1, p0, LAe/p;->d:LCe/l;

    .line 19
    .line 20
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 21
    .line 22
    filled-new-array {v0}, [Ljava/lang/Boolean;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {p1, v0}, LCe/l;->onComplete([Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    invoke-super {p0}, LO6/a;->dismiss()V

    .line 30
    .line 31
    .line 32
    :cond_1
    return-void

    .line 33
    :cond_2
    :goto_0
    iget-object p1, p0, LAe/p;->d:LCe/l;

    .line 34
    .line 35
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 36
    .line 37
    filled-new-array {v0}, [Ljava/lang/Boolean;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {p1, v0}, LCe/l;->onComplete([Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    invoke-super {p0}, LO6/a;->dismiss()V

    .line 45
    .line 46
    .line 47
    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;)V
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object p1, p0, LO6/a;->a:Landroid/content/Context;

    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-virtual {p0, p1}, LO6/a;->showAtBottom(Landroid/view/Window;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 15
    .line 16
    .line 17
    new-instance p1, LA8/b;

    .line 18
    .line 19
    const/16 v1, 0xb

    .line 20
    .line 21
    invoke-direct {p1, p0, v1}, LA8/b;-><init>(Ljava/lang/Object;I)V

    .line 22
    .line 23
    .line 24
    iget-object v1, p0, LAe/p;->j:Lxf/t;

    .line 25
    .line 26
    invoke-virtual {v1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Landroid/widget/ImageView;

    .line 31
    .line 32
    iget-object v2, p0, LAe/p;->f:Lxf/t;

    .line 33
    .line 34
    invoke-virtual {v2}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    check-cast v2, Landroid/widget/TextView;

    .line 39
    .line 40
    iget-object v3, p0, LAe/p;->e:Lxf/t;

    .line 41
    .line 42
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    check-cast v4, Landroid/widget/TextView;

    .line 47
    .line 48
    const/4 v5, 0x3

    .line 49
    new-array v5, v5, [Landroid/view/View;

    .line 50
    .line 51
    aput-object v1, v5, v0

    .line 52
    .line 53
    const/4 v1, 0x1

    .line 54
    aput-object v2, v5, v1

    .line 55
    .line 56
    const/4 v1, 0x2

    .line 57
    aput-object v4, v5, v1

    .line 58
    .line 59
    invoke-static {p1, v5}, Loa/h;->q(Landroid/view/View$OnClickListener;[Landroid/view/View;)V

    .line 60
    .line 61
    .line 62
    iget-object p1, p0, LAe/p;->g:Lxf/t;

    .line 63
    .line 64
    invoke-virtual {p1}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    check-cast p1, Lcom/wang/avi/AVLoadingIndicatorView;

    .line 69
    .line 70
    if-eqz p1, :cond_0

    .line 71
    .line 72
    invoke-virtual {p1, v0}, Lcom/wang/avi/AVLoadingIndicatorView;->setVisibility(I)V

    .line 73
    .line 74
    .line 75
    :cond_0
    invoke-virtual {v3}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    check-cast p1, Landroid/widget/TextView;

    .line 80
    .line 81
    if-eqz p1, :cond_1

    .line 82
    .line 83
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 84
    .line 85
    .line 86
    :cond_1
    new-instance p1, Lcom/transsnet/palmpay/core/viewmodel/ActivityWebView;

    .line 87
    .line 88
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    invoke-direct {p1, v1}, Lcom/transsnet/palmpay/core/viewmodel/ActivityWebView;-><init>(Landroid/content/Context;)V

    .line 93
    .line 94
    .line 95
    new-instance v1, LAe/o;

    .line 96
    .line 97
    invoke-direct {v1, p0, v0}, LAe/o;-><init>(Ljava/lang/Object;I)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 101
    .line 102
    .line 103
    iget-object v0, p0, LAe/p;->i:Lxf/t;

    .line 104
    .line 105
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Landroid/widget/LinearLayout;

    .line 110
    .line 111
    if-eqz v0, :cond_2

    .line 112
    .line 113
    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 114
    .line 115
    .line 116
    :cond_2
    const-string v0, "/h5/policy/ng/permission"

    .line 117
    .line 118
    invoke-static {v0}, Lcom/transsnet/palmpay/core/config/d;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    new-instance v1, LJa/a;

    .line 123
    .line 124
    invoke-direct {v1, v0}, LJa/a;-><init>(Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {p1, v1}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/core/viewmodel/ActivityWebView;->loadUrl(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    return-void
.end method
