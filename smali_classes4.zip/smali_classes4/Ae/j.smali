.class public final synthetic LAe/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LAe/j;->a:I

    iput-object p1, p0, LAe/j;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LAe/j;->b:Ljava/lang/Object;

    .line 3
    .line 4
    iget v2, p0, LAe/j;->a:I

    .line 5
    .line 6
    packed-switch v2, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 10
    .line 11
    iget-object v0, v0, Landroidx/camera/video/internal/c;->d:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 14
    .line 15
    check-cast v1, Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;

    .line 16
    .line 17
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/network/api/AccountApiService;->queryPaymentMethodV3(Lcom/transsnet/palmpay/core/bean/req/PaymentMethodReq;)Ldf/d;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0

    .line 22
    :pswitch_0
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 23
    .line 24
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 27
    .line 28
    check-cast v1, Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;

    .line 29
    .line 30
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryLimitAmountV2(Lcom/transsnet/palmpay/core/bean/req/QueryLimitAmountV2Req;)Ldf/d;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    return-object v0

    .line 35
    :pswitch_1
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 36
    .line 37
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 40
    .line 41
    check-cast v1, Lcom/transsnet/palmpay/core/bean/req/QueryCouponByConditionReq;

    .line 42
    .line 43
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/network/PayApiService;->queryUserCouponListByCondition(Lcom/transsnet/palmpay/core/bean/req/QueryCouponByConditionReq;)Ldf/d;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    return-object v0

    .line 48
    :pswitch_2
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 49
    .line 50
    iget-object v0, v0, Landroidx/camera/video/internal/c;->d:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v0, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 53
    .line 54
    check-cast v1, Lcom/transsnet/palmpay/core/bean/req/CheckBankCardInfoReq;

    .line 55
    .line 56
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/network/api/AccountApiService;->checkInputBankInfo(Lcom/transsnet/palmpay/core/bean/req/CheckBankCardInfoReq;)Ldf/d;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    return-object v0

    .line 61
    :pswitch_3
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 62
    .line 63
    iget-object v0, v0, Landroidx/camera/video/internal/c;->b:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v0, Lcom/transsnet/palmpay/core/network/PayApiService;

    .line 66
    .line 67
    check-cast v1, Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;

    .line 68
    .line 69
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/network/PayApiService;->bindBankCard(Lcom/transsnet/palmpay/core/bean/req/BindBankCardReq;)Ldf/d;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    return-object v0

    .line 74
    :pswitch_4
    sget-object v0, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 75
    .line 76
    iget-object v0, v0, Landroidx/camera/video/internal/c;->d:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v0, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 79
    .line 80
    check-cast v1, Lcom/transsnet/palmpay/core/bean/req/CheckCardBindNumReq;

    .line 81
    .line 82
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/core/network/api/AccountApiService;->checkCardBindNum(Lcom/transsnet/palmpay/core/bean/req/CheckCardBindNumReq;)Ldf/d;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    return-object v0

    .line 87
    :pswitch_5
    new-instance v0, LAe/n;

    .line 88
    .line 89
    check-cast v1, LJe/j;

    .line 90
    .line 91
    const/16 v2, 0x17

    .line 92
    .line 93
    invoke-direct {v0, v1, v2}, LAe/n;-><init>(Ljava/lang/Object;I)V

    .line 94
    .line 95
    .line 96
    return-object v0

    .line 97
    :pswitch_6
    sget-object v2, Lcom/transsnet/palmpay/core/ui/fragment/bankaccount/AddBankAccountOtpFragment;->H:Lcom/transsnet/palmpay/core/ui/fragment/bankaccount/AddBankAccountOtpFragment$a;

    .line 98
    .line 99
    check-cast v1, Lcom/transsnet/palmpay/core/ui/fragment/bankaccount/AddBankAccountOtpFragment;

    .line 100
    .line 101
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 102
    .line 103
    if-eqz v1, :cond_0

    .line 104
    .line 105
    sget v0, LL9/a;->tvNext:I

    .line 106
    .line 107
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    check-cast v0, Landroid/widget/TextView;

    .line 112
    .line 113
    :cond_0
    return-object v0

    .line 114
    :pswitch_7
    sget-object v2, Lcom/transsnet/palmpay/core/ui/fragment/bankaccount/AddBankAccountNgFragment;->C:Lcom/transsnet/palmpay/core/ui/fragment/bankaccount/AddBankAccountNgFragment$a;

    .line 115
    .line 116
    check-cast v1, Lcom/transsnet/palmpay/core/ui/fragment/bankaccount/AddBankAccountNgFragment;

    .line 117
    .line 118
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 119
    .line 120
    if-eqz v1, :cond_1

    .line 121
    .line 122
    sget v0, LL9/a;->tvNext:I

    .line 123
    .line 124
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    check-cast v0, Landroid/widget/TextView;

    .line 129
    .line 130
    :cond_1
    return-object v0

    .line 131
    :pswitch_8
    sget v0, Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankAccountView;->A:I

    .line 132
    .line 133
    new-instance v0, Lld/w;

    .line 134
    .line 135
    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankAccountView;

    .line 136
    .line 137
    invoke-static {v1}, LPa/i0;->V(Landroid/view/View;)Z

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    invoke-direct {v0, v1}, Lld/w;-><init>(Z)V

    .line 142
    .line 143
    .line 144
    return-object v0

    .line 145
    :pswitch_9
    sget v0, Lcom/transsnet/palmpay/send_money/ui/view/SearchRecipientAccountToBankView;->f:I

    .line 146
    .line 147
    new-instance v0, Lld/w;

    .line 148
    .line 149
    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/view/SearchRecipientAccountToBankView;

    .line 150
    .line 151
    invoke-static {v1}, LPa/i0;->V(Landroid/view/View;)Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    invoke-direct {v0, v1}, Lld/w;-><init>(Z)V

    .line 156
    .line 157
    .line 158
    return-object v0

    .line 159
    :pswitch_a
    sget v0, Lcom/transsnet/palmpay/send_money/ui/view/BankCustomerServiceView;->c:I

    .line 160
    .line 161
    sget v0, Lkd/e;->tv_customer_service_tips:I

    .line 162
    .line 163
    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/view/BankCustomerServiceView;

    .line 164
    .line 165
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    check-cast v0, Landroid/widget/TextView;

    .line 170
    .line 171
    return-object v0

    .line 172
    :pswitch_b
    check-cast v1, Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;

    .line 173
    .line 174
    iget-object v0, v1, Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;->c:Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;

    .line 175
    .line 176
    if-eqz v0, :cond_2

    .line 177
    .line 178
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;->k(Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfo;)V

    .line 179
    .line 180
    .line 181
    :cond_2
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 182
    .line 183
    return-object v0

    .line 184
    :pswitch_c
    sget-object v0, Lcom/transsnet/palmpay/credit/view/ProductContentListView;->c:Lcom/transsnet/palmpay/credit/view/ProductContentListView$a;

    .line 185
    .line 186
    sget v0, LYa/e;->rvProductList:I

    .line 187
    .line 188
    check-cast v1, Lcom/transsnet/palmpay/credit/view/ProductContentListView;

    .line 189
    .line 190
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 195
    .line 196
    return-object v0

    .line 197
    :pswitch_d
    check-cast v1, Lcom/transsnet/palmpay/credit/view/LoanOutstandingSummaryView;

    .line 198
    .line 199
    iget-object v0, v1, Lcom/transsnet/palmpay/credit/view/LoanOutstandingSummaryView;->c:Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfoV2;

    .line 200
    .line 201
    if-eqz v0, :cond_3

    .line 202
    .line 203
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/credit/view/LoanOutstandingSummaryView;->g(Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfoV2;)V

    .line 204
    .line 205
    .line 206
    :cond_3
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 207
    .line 208
    return-object v0

    .line 209
    :pswitch_e
    sget v0, Lcom/transsnet/palmpay/credit/view/KingKongContentInfoView;->b:I

    .line 210
    .line 211
    sget v0, LYa/e;->rvInfoList:I

    .line 212
    .line 213
    check-cast v1, Lcom/transsnet/palmpay/credit/view/KingKongContentInfoView;

    .line 214
    .line 215
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 220
    .line 221
    return-object v0

    .line 222
    :pswitch_f
    sget-object v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment;->M:Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment$a;

    .line 223
    .line 224
    new-instance v0, Lld/w;

    .line 225
    .line 226
    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankAddBankAccountFragment;

    .line 227
    .line 228
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->m()Z

    .line 229
    .line 230
    .line 231
    move-result v1

    .line 232
    invoke-direct {v0, v1}, Lld/w;-><init>(Z)V

    .line 233
    .line 234
    .line 235
    return-object v0

    .line 236
    :pswitch_10
    check-cast v1, Ltop/zibin/luban/io/a;

    .line 237
    .line 238
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 239
    .line 240
    .line 241
    invoke-static {}, Ltop/zibin/luban/io/a;->l()Z

    .line 242
    .line 243
    .line 244
    move-result v0

    .line 245
    if-eqz v0, :cond_5

    .line 246
    .line 247
    iget-object v0, v1, Ltop/zibin/luban/io/a;->c:Ljava/lang/Object;

    .line 248
    .line 249
    check-cast v0, Ljava/lang/String;

    .line 250
    .line 251
    if-nez v0, :cond_4

    .line 252
    .line 253
    goto :goto_0

    .line 254
    :cond_4
    iget-object v2, v1, Ltop/zibin/luban/io/a;->d:Ljava/lang/Object;

    .line 255
    .line 256
    check-cast v2, Landroid/os/Handler;

    .line 257
    .line 258
    new-instance v3, LB6/g;

    .line 259
    .line 260
    const/16 v4, 0xb

    .line 261
    .line 262
    invoke-direct {v3, v4, v1, v0}, LB6/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 263
    .line 264
    .line 265
    const-wide/16 v0, 0xbb8

    .line 266
    .line 267
    invoke-virtual {v2, v3, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 268
    .line 269
    .line 270
    :cond_5
    :goto_0
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 271
    .line 272
    return-object v0

    .line 273
    :pswitch_11
    sget v0, Lcom/transsnet/palmpay/send_money/ui/fragment/kkcar/KkCarOnboardingFragment;->t:I

    .line 274
    .line 275
    new-instance v0, Landroidx/camera/video/internal/c;

    .line 276
    .line 277
    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/fragment/kkcar/KkCarOnboardingFragment;

    .line 278
    .line 279
    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 280
    .line 281
    .line 282
    move-result-object v1

    .line 283
    const-string v2, "requireActivity(...)"

    .line 284
    .line 285
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 286
    .line 287
    .line 288
    invoke-direct {v0, v1}, Landroidx/camera/video/internal/c;-><init>(Landroidx/lifecycle/ViewModelStoreOwner;)V

    .line 289
    .line 290
    .line 291
    const-class v1, Lcom/transsnet/palmpay/send_money/viewmodel/KkCarHostViewModel;

    .line 292
    .line 293
    invoke-virtual {v0, v1}, Landroidx/camera/video/internal/c;->h(Ljava/lang/Class;)Landroidx/lifecycle/a0;

    .line 294
    .line 295
    .line 296
    move-result-object v0

    .line 297
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/KkCarHostViewModel;

    .line 298
    .line 299
    return-object v0

    .line 300
    :pswitch_12
    sget v2, Lcom/transsnet/palmpay/cash_in/ui/activity/instruction/AddMoneyHomeActivity;->o:I

    .line 301
    .line 302
    check-cast v1, Lcom/transsnet/palmpay/cash_in/ui/activity/instruction/AddMoneyHomeActivity;

    .line 303
    .line 304
    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 305
    .line 306
    .line 307
    move-result-object v1

    .line 308
    if-eqz v1, :cond_6

    .line 309
    .line 310
    const-string v0, "scene"

    .line 311
    .line 312
    invoke-virtual {v1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v0

    .line 316
    :cond_6
    return-object v0

    .line 317
    :pswitch_13
    check-cast v1, LD6/m;

    .line 318
    .line 319
    iget-object v0, v1, LD6/m;->L:Lcom/google/mlkit/vision/face/FaceDetectorOptions;

    .line 320
    .line 321
    invoke-static {v0}, Lcom/google/mlkit/vision/face/FaceDetection;->getClient(Lcom/google/mlkit/vision/face/FaceDetectorOptions;)Lcom/google/mlkit/vision/face/FaceDetector;

    .line 322
    .line 323
    .line 324
    move-result-object v0

    .line 325
    return-object v0

    .line 326
    :pswitch_14
    check-cast v1, LD6/e;

    .line 327
    .line 328
    iget-object v0, v1, LD6/e;->B:Lcom/google/mlkit/vision/face/FaceDetectorOptions;

    .line 329
    .line 330
    invoke-static {v0}, Lcom/google/mlkit/vision/face/FaceDetection;->getClient(Lcom/google/mlkit/vision/face/FaceDetectorOptions;)Lcom/google/mlkit/vision/face/FaceDetector;

    .line 331
    .line 332
    .line 333
    move-result-object v0

    .line 334
    return-object v0

    .line 335
    :pswitch_15
    sget-object v2, Lcom/transsnet/palmpay/ui/fragment/PalmZoneTaskRewardsFragment;->v:Lcom/transsnet/palmpay/ui/fragment/PalmZoneTaskRewardsFragment$a;

    .line 336
    .line 337
    check-cast v1, Lcom/transsnet/palmpay/ui/fragment/PalmZoneTaskRewardsFragment;

    .line 338
    .line 339
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 340
    .line 341
    if-eqz v1, :cond_7

    .line 342
    .line 343
    sget v0, LAc/e;->rewardsList:I

    .line 344
    .line 345
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 346
    .line 347
    .line 348
    move-result-object v0

    .line 349
    check-cast v0, Lcom/transsnet/palmpay/custom_view/SwipeRecyclerView;

    .line 350
    .line 351
    :cond_7
    return-object v0

    .line 352
    :pswitch_16
    check-cast v1, Lcom/transsnet/palmpay/ui/fragment/MessageListFragment;

    .line 353
    .line 354
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 355
    .line 356
    if-eqz v1, :cond_8

    .line 357
    .line 358
    sget v0, LAc/e;->messageList:I

    .line 359
    .line 360
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 361
    .line 362
    .line 363
    move-result-object v0

    .line 364
    check-cast v0, Lcom/transsnet/palmpay/custom_view/SwipeRecyclerView;

    .line 365
    .line 366
    :cond_8
    return-object v0

    .line 367
    :pswitch_17
    check-cast v1, Lcom/transsnet/palmpay/ui/fragment/HomeFragment;

    .line 368
    .line 369
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 370
    .line 371
    if-eqz v1, :cond_9

    .line 372
    .line 373
    sget v0, LAc/e;->navbarBg:I

    .line 374
    .line 375
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 376
    .line 377
    .line 378
    move-result-object v0

    .line 379
    :cond_9
    return-object v0

    .line 380
    :pswitch_18
    sget v2, Lcom/transsnet/palmpay/ui/fragment/HomeFinanceFragment;->H:I

    .line 381
    .line 382
    check-cast v1, Lcom/transsnet/palmpay/ui/fragment/HomeFinanceFragment;

    .line 383
    .line 384
    iget-object v1, v1, Lcom/transsnet/palmpay/core/base/BaseFragment;->b:Landroid/view/View;

    .line 385
    .line 386
    if-eqz v1, :cond_a

    .line 387
    .line 388
    sget v0, LAc/e;->refreshLayout:I

    .line 389
    .line 390
    invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 391
    .line 392
    .line 393
    move-result-object v0

    .line 394
    check-cast v0, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    .line 395
    .line 396
    :cond_a
    return-object v0

    .line 397
    :pswitch_19
    check-cast v1, LC6/v;

    .line 398
    .line 399
    iget-object v0, v1, LC6/v;->M:Lcom/google/mlkit/vision/face/FaceDetectorOptions;

    .line 400
    .line 401
    invoke-static {v0}, Lcom/google/mlkit/vision/face/FaceDetection;->getClient(Lcom/google/mlkit/vision/face/FaceDetectorOptions;)Lcom/google/mlkit/vision/face/FaceDetector;

    .line 402
    .line 403
    .line 404
    move-result-object v0

    .line 405
    return-object v0

    .line 406
    :pswitch_1a
    check-cast v1, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;

    .line 407
    .line 408
    invoke-static {v1}, Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;->b(Lcom/transsnet/palmpay/ui/dialog/reward/PalmZoneCouponRewardsDialog;)Landroid/widget/ImageView;

    .line 409
    .line 410
    .line 411
    move-result-object v0

    .line 412
    return-object v0

    .line 413
    :pswitch_1b
    check-cast v1, LB6/c;

    .line 414
    .line 415
    iget-object v0, v1, LB6/c;->a:Lcom/google/mlkit/vision/face/FaceDetectorOptions;

    .line 416
    .line 417
    invoke-static {v0}, Lcom/google/mlkit/vision/face/FaceDetection;->getClient(Lcom/google/mlkit/vision/face/FaceDetectorOptions;)Lcom/google/mlkit/vision/face/FaceDetector;

    .line 418
    .line 419
    .line 420
    move-result-object v0

    .line 421
    return-object v0

    .line 422
    :pswitch_1c
    check-cast v1, Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;

    .line 423
    .line 424
    invoke-static {v1}, Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;->b(Lcom/transsnet/palmpay/ui/dialog/OtpVerifyDialog;)LAe/k;

    .line 425
    .line 426
    .line 427
    move-result-object v0

    .line 428
    return-object v0

    .line 429
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
