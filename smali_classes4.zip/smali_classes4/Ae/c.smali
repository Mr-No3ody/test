.class public final LAe/c;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LAe/c;->b:Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 1

    .line 1
    new-instance p1, LAe/c;

    .line 2
    .line 3
    iget-object v0, p0, LAe/c;->b:Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;

    .line 4
    .line 5
    invoke-direct {p1, v0, p2}, LAe/c;-><init>(Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;Lkotlin/coroutines/Continuation;)V

    .line 6
    .line 7
    .line 8
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LAe/c;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LAe/c;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LAe/c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    const/16 v2, 0x1c

    .line 5
    .line 6
    sget-object v3, LEf/a;->a:LEf/a;

    .line 7
    .line 8
    iget v4, v1, LAe/c;->a:I

    .line 9
    .line 10
    if-eqz v4, :cond_1

    .line 11
    .line 12
    if-ne v4, v0, :cond_0

    .line 13
    .line 14
    :try_start_0
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    .line 16
    .line 17
    move-object/from16 v4, p1

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catch_0
    move-exception v0

    .line 21
    goto/16 :goto_5

    .line 22
    .line 23
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 24
    .line 25
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 26
    .line 27
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    throw v0

    .line 31
    :cond_1
    invoke-static/range {p1 .. p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    :try_start_1
    sget-object v4, LWf/I;->a:Lcg/f;

    .line 35
    .line 36
    sget-object v4, Lcg/e;->c:Lcg/e;

    .line 37
    .line 38
    new-instance v5, LAe/b;

    .line 39
    .line 40
    const/4 v6, 0x2

    .line 41
    const/4 v7, 0x0

    .line 42
    invoke-direct {v5, v6, v7}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 43
    .line 44
    .line 45
    iput v0, v1, LAe/c;->a:I

    .line 46
    .line 47
    invoke-static {v4, v5, v1}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    if-ne v4, v3, :cond_2

    .line 52
    .line 53
    return-object v3

    .line 54
    :cond_2
    :goto_0
    check-cast v4, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 55
    .line 56
    invoke-virtual {v4}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 57
    .line 58
    .line 59
    move-result v3
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 60
    iget-object v5, v1, LAe/c;->b:Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;

    .line 61
    .line 62
    const-string v6, "getContext(...)"

    .line 63
    .line 64
    if-eqz v3, :cond_5

    .line 65
    .line 66
    :try_start_2
    invoke-virtual {v5}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 67
    .line 68
    .line 69
    move-result-object v7

    .line 70
    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    sget v3, LAc/h;->main_cashbox_auto_save_turned_on:I

    .line 74
    .line 75
    new-instance v9, Ljava/lang/Integer;

    .line 76
    .line 77
    invoke-direct {v9, v3}, Ljava/lang/Integer;-><init>(I)V

    .line 78
    .line 79
    .line 80
    sget v3, Lcom/transsnet/palmpay/custom_view/r;->cv_pay_success_green:I

    .line 81
    .line 82
    new-instance v11, Ljava/lang/Integer;

    .line 83
    .line 84
    invoke-direct {v11, v3}, Ljava/lang/Integer;-><init>(I)V

    .line 85
    .line 86
    .line 87
    iget-object v3, v4, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast v3, Lcom/transsnet/palmpay/main/export/bean/rsp/UpdateAutoTransferConfig;

    .line 90
    .line 91
    if-eqz v3, :cond_4

    .line 92
    .line 93
    iget-object v3, v3, Lcom/transsnet/palmpay/main/export/bean/rsp/UpdateAutoTransferConfig;->advertMsg:Ljava/lang/String;

    .line 94
    .line 95
    if-nez v3, :cond_3

    .line 96
    .line 97
    goto :goto_2

    .line 98
    :cond_3
    :goto_1
    move-object v14, v3

    .line 99
    goto :goto_3

    .line 100
    :cond_4
    :goto_2
    const-string v3, ""

    .line 101
    .line 102
    goto :goto_1

    .line 103
    :goto_3
    sget v3, Lba/k;->core_go:I

    .line 104
    .line 105
    new-instance v15, Ljava/lang/Integer;

    .line 106
    .line 107
    invoke-direct {v15, v3}, Ljava/lang/Integer;-><init>(I)V

    .line 108
    .line 109
    .line 110
    new-instance v3, LAe/a;

    .line 111
    .line 112
    invoke-direct {v3, v5, v0}, LAe/a;-><init>(Lcom/transsnet/palmpay/ui/dialog/AcceptTurnOnSaveDialog;I)V

    .line 113
    .line 114
    .line 115
    new-instance v0, LAb/e;

    .line 116
    .line 117
    invoke-direct {v0, v2}, LAb/e;-><init>(I)V

    .line 118
    .line 119
    .line 120
    const v24, 0x7f7a75

    .line 121
    .line 122
    .line 123
    const/4 v8, 0x0

    .line 124
    const/4 v10, 0x0

    .line 125
    const/4 v12, 0x0

    .line 126
    const/4 v13, 0x0

    .line 127
    const/16 v16, 0x0

    .line 128
    .line 129
    const/16 v18, 0x0

    .line 130
    .line 131
    const/16 v19, 0x0

    .line 132
    .line 133
    const/16 v20, 0x0

    .line 134
    .line 135
    const/16 v22, 0x0

    .line 136
    .line 137
    const/16 v23, 0x0

    .line 138
    .line 139
    move-object/from16 v21, v0

    .line 140
    .line 141
    move-object/from16 v17, v3

    .line 142
    .line 143
    invoke-static/range {v7 .. v24}, Lio/fastkv/n;->O(Landroid/content/Context;ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;Lcom/mikepenz/iconics/IconicsDrawable;Landroid/graphics/drawable/Drawable;Ljava/lang/CharSequence;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;ZII)LO6/d;

    .line 144
    .line 145
    .line 146
    goto :goto_4

    .line 147
    :cond_5
    invoke-virtual {v5}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    sget v3, LAc/h;->main_failed_please_try_again:I

    .line 155
    .line 156
    new-instance v8, Ljava/lang/Integer;

    .line 157
    .line 158
    invoke-direct {v8, v3}, Ljava/lang/Integer;-><init>(I)V

    .line 159
    .line 160
    .line 161
    sget v3, Lcom/transsnet/palmpay/custom_view/r;->cv_pay_fail:I

    .line 162
    .line 163
    new-instance v10, Ljava/lang/Integer;

    .line 164
    .line 165
    invoke-direct {v10, v3}, Ljava/lang/Integer;-><init>(I)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v4}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v13

    .line 172
    sget v3, Lba/k;->core_ok:I

    .line 173
    .line 174
    new-instance v14, Ljava/lang/Integer;

    .line 175
    .line 176
    invoke-direct {v14, v3}, Ljava/lang/Integer;-><init>(I)V

    .line 177
    .line 178
    .line 179
    new-instance v3, LAb/e;

    .line 180
    .line 181
    invoke-direct {v3, v2}, LAb/e;-><init>(I)V

    .line 182
    .line 183
    .line 184
    new-instance v4, LAb/e;

    .line 185
    .line 186
    invoke-direct {v4, v2}, LAb/e;-><init>(I)V

    .line 187
    .line 188
    .line 189
    const v23, 0x7f7a75

    .line 190
    .line 191
    .line 192
    const/4 v7, 0x0

    .line 193
    const/4 v9, 0x0

    .line 194
    const/4 v11, 0x0

    .line 195
    const/4 v12, 0x0

    .line 196
    const/4 v15, 0x0

    .line 197
    const/16 v17, 0x0

    .line 198
    .line 199
    const/16 v18, 0x0

    .line 200
    .line 201
    const/16 v19, 0x0

    .line 202
    .line 203
    const/16 v21, 0x0

    .line 204
    .line 205
    const/16 v22, 0x0

    .line 206
    .line 207
    move-object v6, v0

    .line 208
    move-object/from16 v16, v3

    .line 209
    .line 210
    move-object/from16 v20, v4

    .line 211
    .line 212
    invoke-static/range {v6 .. v23}, Lio/fastkv/n;->O(Landroid/content/Context;ILjava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;Lcom/mikepenz/iconics/IconicsDrawable;Landroid/graphics/drawable/Drawable;Ljava/lang/CharSequence;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Ljava/lang/Integer;Ljava/lang/String;Landroid/view/View$OnClickListener;Landroid/view/View$OnClickListener;ZII)LO6/d;

    .line 213
    .line 214
    .line 215
    :goto_4
    invoke-virtual {v5}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 216
    .line 217
    .line 218
    goto :goto_6

    .line 219
    :goto_5
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->W(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object v0

    .line 223
    const/4 v2, 0x0

    .line 224
    new-array v2, v2, [Ljava/lang/Object;

    .line 225
    .line 226
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    :goto_6
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 230
    .line 231
    return-object v0
.end method
