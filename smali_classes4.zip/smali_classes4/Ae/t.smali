.class public final LAe/t;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Lcom/transsnet/palmpay/core/bean/req/ShareAccountDetailReq;

.field public final synthetic c:Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/bean/req/ShareAccountDetailReq;Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LAe/t;->b:Lcom/transsnet/palmpay/core/bean/req/ShareAccountDetailReq;

    .line 2
    .line 3
    iput-object p2, p0, LAe/t;->c:Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LAe/t;

    .line 2
    .line 3
    iget-object v0, p0, LAe/t;->b:Lcom/transsnet/palmpay/core/bean/req/ShareAccountDetailReq;

    .line 4
    .line 5
    iget-object v1, p0, LAe/t;->c:Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;

    .line 6
    .line 7
    invoke-direct {p1, v0, v1, p2}, LAe/t;-><init>(Lcom/transsnet/palmpay/core/bean/req/ShareAccountDetailReq;Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;Lkotlin/coroutines/Continuation;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LAe/t;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LAe/t;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LAe/t;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LAe/t;->a:I

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v1, :cond_2

    .line 8
    .line 9
    if-eq v1, v3, :cond_1

    .line 10
    .line 11
    if-ne v1, v2, :cond_0

    .line 12
    .line 13
    :try_start_0
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 14
    .line 15
    .line 16
    goto :goto_2

    .line 17
    :catch_0
    move-exception p1

    .line 18
    goto :goto_3

    .line 19
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 22
    .line 23
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1

    .line 27
    :cond_1
    :try_start_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_2
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    :try_start_2
    sget-object p1, Lva/c;->a:Landroidx/camera/video/internal/c;

    .line 35
    .line 36
    iget-object p1, p1, Landroidx/camera/video/internal/c;->d:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast p1, Lcom/transsnet/palmpay/core/network/api/AccountApiService;

    .line 39
    .line 40
    iget-object v1, p0, LAe/t;->b:Lcom/transsnet/palmpay/core/bean/req/ShareAccountDetailReq;

    .line 41
    .line 42
    iput v3, p0, LAe/t;->a:I

    .line 43
    .line 44
    invoke-interface {p1, v1, p0}, Lcom/transsnet/palmpay/core/network/api/AccountApiService;->queryShareAccountDetailMvvm(Lcom/transsnet/palmpay/core/bean/req/ShareAccountDetailReq;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    if-ne p1, v0, :cond_3

    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_3
    :goto_0
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 52
    .line 53
    sget-object v1, LWf/I;->a:Lcg/f;

    .line 54
    .line 55
    sget-object v1, Lag/o;->a:LWf/p0;

    .line 56
    .line 57
    new-instance v3, LAe/s;

    .line 58
    .line 59
    iget-object v4, p0, LAe/t;->c:Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;

    .line 60
    .line 61
    const/4 v5, 0x0

    .line 62
    invoke-direct {v3, p1, v4, v5}, LAe/s;-><init>(Lcom/transsnet/palmpay/core/bean/CommonBeanResult;Lcom/transsnet/palmpay/ui/dialog/SendMoneyHandlerHomeDialog;Lkotlin/coroutines/Continuation;)V

    .line 63
    .line 64
    .line 65
    iput v2, p0, LAe/t;->a:I

    .line 66
    .line 67
    invoke-static {v1, v3, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-ne p1, v0, :cond_4

    .line 72
    .line 73
    :goto_1
    return-object v0

    .line 74
    :cond_4
    :goto_2
    check-cast p1, Lkotlin/Unit;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 75
    .line 76
    goto :goto_4

    .line 77
    :goto_3
    invoke-static {p1}, Lorg/chromium/support_lib_boundary/util/b;->W(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    const/4 v0, 0x0

    .line 82
    new-array v0, v0, [Ljava/lang/Object;

    .line 83
    .line 84
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    :goto_4
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 88
    .line 89
    return-object p1
.end method
