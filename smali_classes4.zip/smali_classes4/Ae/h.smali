.class public final LAe/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAe/h;->a:I

    iput-object p1, p0, LAe/h;->b:Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 1
    iget v0, p0, LAe/h;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAe/h;->b:Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 9
    .line 10
    .line 11
    invoke-static {v0}, Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;->b(Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;)Landroid/view/View$OnClickListener;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    invoke-static {v0}, Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;->b(Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;)Landroid/view/View$OnClickListener;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void

    .line 25
    :pswitch_0
    iget-object v0, p0, LAe/h;->b:Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;

    .line 26
    .line 27
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 28
    .line 29
    .line 30
    invoke-static {v0}, Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;->a(Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;)Landroid/view/View$OnClickListener;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    if-eqz v1, :cond_1

    .line 35
    .line 36
    invoke-static {v0}, Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;->a(Lcom/transsnet/palmpay/ui/dialog/MerchantAuthorizationDialog;)Landroid/view/View$OnClickListener;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-interface {v0, p1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    return-void

    .line 44
    nop

    .line 45
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
