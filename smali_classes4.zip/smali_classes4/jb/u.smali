.class public abstract Ljb/u;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 14

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    filled-new-array {v0}, [Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    .line 16
    .line 17
    filled-new-array {v0}, [Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0}, Lya/a;->f()Lcom/transsnet/palmpay/core/bean/LocationRecord;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    if-nez v0, :cond_1

    .line 37
    .line 38
    const-string p0, "location is null"

    .line 39
    .line 40
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    const-string p1, "uploadLocationInfo"

    .line 45
    .line 46
    invoke-static {p1, p0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :cond_1
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLatitude()D

    .line 51
    .line 52
    .line 53
    move-result-wide v1

    .line 54
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLongitude()D

    .line 55
    .line 56
    .line 57
    move-result-wide v3

    .line 58
    new-instance v5, Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;

    .line 59
    .line 60
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 65
    .line 66
    .line 67
    move-result-object v7

    .line 68
    const/4 v13, 0x0

    .line 69
    const/4 v9, 0x0

    .line 70
    const/16 v12, 0x8

    .line 71
    .line 72
    move-object v8, p0

    .line 73
    move-object v10, p1

    .line 74
    move-object/from16 v11, p2

    .line 75
    .line 76
    invoke-direct/range {v5 .. v13}, Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;-><init>(Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 77
    .line 78
    .line 79
    sget-object p0, Lob/c;->a:Lob/a;

    .line 80
    .line 81
    invoke-virtual {p0}, Lob/a;->getInstance()Lob/c;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    invoke-interface {p0, v5}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadLocationInfo(Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;)Ldf/d;

    .line 93
    .line 94
    .line 95
    move-result-object p0

    .line 96
    sget-object p1, Ltf/f;->b:Ldf/i;

    .line 97
    .line 98
    invoke-virtual {p0, p1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 99
    .line 100
    .line 101
    move-result-object p0

    .line 102
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    invoke-virtual {p0, p1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    new-instance p1, LN8/t;

    .line 111
    .line 112
    const/4 v0, 0x4

    .line 113
    invoke-direct {p1, v0}, LN8/t;-><init>(I)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {p0, p1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 117
    .line 118
    .line 119
    return-void
.end method
