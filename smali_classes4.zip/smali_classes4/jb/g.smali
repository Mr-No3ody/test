.class public final Ljb/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final o:Ljb/d;

.field public static final p:Lxf/t;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/util/ArrayList;

.field public g:Ljava/util/ArrayList;

.field public h:I

.field public i:Lcom/transsnet/palmpay/core/base/BaseFragment;

.field public j:Ljava/lang/Integer;

.field public k:Ljava/lang/Integer;

.field public l:I

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/Integer;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ljb/d;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Ljb/d;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Ljb/g;->o:Ljb/d;

    .line 8
    .line 9
    new-instance v0, Lcom/transsnet/palmpay/managemoney/ui/view/c;

    .line 10
    .line 11
    const/16 v1, 0x19

    .line 12
    .line 13
    invoke-direct {v0, v1}, Lcom/transsnet/palmpay/managemoney/ui/view/c;-><init>(I)V

    .line 14
    .line 15
    .line 16
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, Ljb/g;->p:Lxf/t;

    .line 21
    .line 22
    return-void
.end method

.method public static final a(Ljb/g;Lio/reactivex/disposables/Disposable;)V
    .locals 0

    .line 1
    iget-object p0, p0, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 2
    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->f(Lio/reactivex/disposables/Disposable;)V

    .line 6
    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public static final b(Ljb/g;Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteList()Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object v1, v0

    .line 19
    :goto_0
    check-cast v1, Ljava/util/Collection;

    .line 20
    .line 21
    const/4 v2, 0x1

    .line 22
    if-eqz v1, :cond_6

    .line 23
    .line 24
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-eqz v1, :cond_1

    .line 29
    .line 30
    goto :goto_2

    .line 31
    :cond_1
    if-eqz p1, :cond_2

    .line 32
    .line 33
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    if-eqz p1, :cond_2

    .line 38
    .line 39
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteList()Ljava/util/List;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    :cond_2
    check-cast v0, Ljava/util/Collection;

    .line 44
    .line 45
    if-eqz v0, :cond_5

    .line 46
    .line 47
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    if-eqz p1, :cond_3

    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_3
    iget-object p1, p0, Ljb/g;->g:Ljava/util/ArrayList;

    .line 55
    .line 56
    const/4 v0, 0x0

    .line 57
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    const-string v1, "oc_permission_router"

    .line 62
    .line 63
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    if-eqz p1, :cond_4

    .line 68
    .line 69
    iput v2, p0, Ljb/g;->h:I

    .line 70
    .line 71
    invoke-virtual {p0}, Ljb/g;->c()V

    .line 72
    .line 73
    .line 74
    return-void

    .line 75
    :cond_4
    iput v0, p0, Ljb/g;->h:I

    .line 76
    .line 77
    invoke-virtual {p0}, Ljb/g;->h()V

    .line 78
    .line 79
    .line 80
    return-void

    .line 81
    :cond_5
    :goto_1
    invoke-virtual {p0}, Ljb/g;->j()V

    .line 82
    .line 83
    .line 84
    return-void

    .line 85
    :cond_6
    :goto_2
    iget-object p1, p0, Ljb/g;->b:Ljava/lang/String;

    .line 86
    .line 87
    const-string v0, "LOAN_WITHDRAW"

    .line 88
    .line 89
    invoke-static {p1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 90
    .line 91
    .line 92
    move-result p1

    .line 93
    if-eqz p1, :cond_a

    .line 94
    .line 95
    iget-object p1, p0, Ljb/g;->k:Ljava/lang/Integer;

    .line 96
    .line 97
    if-nez p1, :cond_7

    .line 98
    .line 99
    goto :goto_3

    .line 100
    :cond_7
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 101
    .line 102
    .line 103
    move-result p1

    .line 104
    if-ne p1, v2, :cond_8

    .line 105
    .line 106
    iget-object p1, p0, Ljb/g;->j:Ljava/lang/Integer;

    .line 107
    .line 108
    invoke-virtual {p0, p1}, Ljb/g;->e(Ljava/lang/Integer;)V

    .line 109
    .line 110
    .line 111
    return-void

    .line 112
    :cond_8
    :goto_3
    iget-object p0, p0, Ljb/g;->n:Ljava/lang/Integer;

    .line 113
    .line 114
    if-eqz p0, :cond_9

    .line 115
    .line 116
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 117
    .line 118
    .line 119
    move-result p0

    .line 120
    goto :goto_4

    .line 121
    :cond_9
    const/4 p0, 0x7

    .line 122
    :goto_4
    new-instance p1, Landroid/os/Bundle;

    .line 123
    .line 124
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 125
    .line 126
    .line 127
    const-string v0, "accountType"

    .line 128
    .line 129
    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 130
    .line 131
    .line 132
    const-string p0, "bundle"

    .line 133
    .line 134
    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    invoke-static {p1, p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    sget-object p0, LEb/a;->a:Ljava/lang/String;

    .line 141
    .line 142
    const-string v0, "Home_Source"

    .line 143
    .line 144
    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    const-string p0, "LoanBorrowHome"

    .line 151
    .line 152
    invoke-static {p1, p0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    return-void

    .line 156
    :cond_a
    invoke-virtual {p0}, Ljb/g;->j()V

    .line 157
    .line 158
    .line 159
    return-void
.end method

.method public static d()I
    .locals 4

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->get()Lcom/transsnet/palmpay/util/SPUtils;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "credit_bind_times"

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/util/SPUtils;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    const-string v1, "_"

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-static {v0, v1, v2}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    if-eqz v3, :cond_0

    .line 22
    .line 23
    invoke-static {v0, v1}, Landroid/text/TextUtils;->split(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const/4 v1, 0x1

    .line 28
    aget-object v0, v0, v1

    .line 29
    .line 30
    invoke-static {v0}, LPa/E;->b(Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    return v0

    .line 35
    :cond_0
    return v2
.end method

.method public static g(Ljb/g;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Lcom/transsnet/palmpay/core/base/BaseFragment;ILjava/lang/String;Ljava/lang/String;I)V
    .locals 9

    .line 1
    and-int/lit8 v0, p8, 0x20

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move-object v0, v1

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    move-object v0, p6

    .line 9
    :goto_0
    and-int/lit8 v2, p8, 0x40

    .line 10
    .line 11
    if-eqz v2, :cond_1

    .line 12
    .line 13
    move-object v2, v1

    .line 14
    goto :goto_1

    .line 15
    :cond_1
    move-object/from16 v2, p7

    .line 16
    .line 17
    :goto_1
    const/4 v3, 0x7

    .line 18
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    if-nez p3, :cond_2

    .line 26
    .line 27
    const-string v4, "CASH_LOAN"

    .line 28
    .line 29
    goto :goto_2

    .line 30
    :cond_2
    move-object v4, p3

    .line 31
    :goto_2
    iput-object v4, p0, Ljb/g;->b:Ljava/lang/String;

    .line 32
    .line 33
    iput-object p1, p0, Ljb/g;->j:Ljava/lang/Integer;

    .line 34
    .line 35
    iput-object p2, p0, Ljb/g;->k:Ljava/lang/Integer;

    .line 36
    .line 37
    iput-object p4, p0, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 38
    .line 39
    iput p5, p0, Ljb/g;->l:I

    .line 40
    .line 41
    iput-object v2, p0, Ljb/g;->m:Ljava/lang/String;

    .line 42
    .line 43
    iput-object v3, p0, Ljb/g;->n:Ljava/lang/Integer;

    .line 44
    .line 45
    if-eqz v0, :cond_3

    .line 46
    .line 47
    iput-object v0, p0, Ljb/g;->a:Ljava/lang/String;

    .line 48
    .line 49
    :cond_3
    const/4 p1, 0x1

    .line 50
    invoke-virtual {p0, p1}, Ljb/g;->k(Z)V

    .line 51
    .line 52
    .line 53
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 54
    .line 55
    .line 56
    move-result p1

    .line 57
    if-nez p1, :cond_4

    .line 58
    .line 59
    iput-object v1, p0, Ljb/g;->d:Ljava/lang/String;

    .line 60
    .line 61
    invoke-virtual {p0, p4}, Ljb/g;->f(Landroidx/fragment/app/Fragment;)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :cond_4
    sget-object p1, Lob/c;->a:Lob/a;

    .line 66
    .line 67
    invoke-static {p1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    new-instance v0, Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;

    .line 72
    .line 73
    iget-object v1, p0, Ljb/g;->a:Ljava/lang/String;

    .line 74
    .line 75
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 76
    .line 77
    const/16 v7, 0x20

    .line 78
    .line 79
    const/4 v8, 0x0

    .line 80
    const/4 v3, 0x2

    .line 81
    const/4 v4, 0x0

    .line 82
    const/4 v6, 0x0

    .line 83
    move-object v2, p3

    .line 84
    invoke-direct/range {v0 .. v8}, Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;-><init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 85
    .line 86
    .line 87
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->clInitApply(Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;)Ldf/d;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    sget-object p2, Ltf/f;->b:Ldf/i;

    .line 92
    .line 93
    invoke-virtual {p1, p2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 98
    .line 99
    .line 100
    move-result-object p2

    .line 101
    invoke-virtual {p1, p2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    new-instance p2, LN8/r;

    .line 106
    .line 107
    const/16 p3, 0x8

    .line 108
    .line 109
    invoke-direct {p2, p3, p0, p4}, LN8/r;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {p1, p2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 113
    .line 114
    .line 115
    return-void
.end method


# virtual methods
.method public final c()V
    .locals 11

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->v()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Ljb/g;->h()V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 14
    .line 15
    .line 16
    const-string v1, "android.permission.READ_PHONE_STATE"

    .line 17
    .line 18
    filled-new-array {v1}, [Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-static {v2}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-nez v2, :cond_1

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    :cond_1
    const-string v2, "android.permission.ACCESS_COARSE_LOCATION"

    .line 32
    .line 33
    filled-new-array {v2}, [Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    invoke-static {v3}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    if-nez v3, :cond_2

    .line 42
    .line 43
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    :cond_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    if-nez v3, :cond_3

    .line 51
    .line 52
    invoke-virtual {p0}, Ljb/g;->l()V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_3
    iget-object v3, p0, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 57
    .line 58
    if-eqz v3, :cond_7

    .line 59
    .line 60
    new-instance v4, Ljava/util/ArrayList;

    .line 61
    .line 62
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 63
    .line 64
    .line 65
    filled-new-array {v1}, [Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    invoke-static {v1}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-nez v1, :cond_4

    .line 74
    .line 75
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;

    .line 76
    .line 77
    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 78
    .line 79
    .line 80
    move-result-object v5

    .line 81
    sget v6, LYa/d;->cs_device_info_icon:I

    .line 82
    .line 83
    invoke-virtual {v5, v6}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    const-string v6, "Device Information"

    .line 88
    .line 89
    invoke-direct {v1, v5, v6}, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    :cond_4
    filled-new-array {v2}, [Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-static {v1}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    const-string v2, "requireContext(...)"

    .line 104
    .line 105
    if-eqz v1, :cond_5

    .line 106
    .line 107
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    filled-new-array {v1}, [Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    invoke-static {v1}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    if-nez v1, :cond_6

    .line 120
    .line 121
    :cond_5
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;

    .line 122
    .line 123
    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 124
    .line 125
    .line 126
    move-result-object v5

    .line 127
    invoke-static {v5, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    sget-object v6, LS6/a;->P0:LS6/a;

    .line 131
    .line 132
    sget v7, LL6/b;->ppColorTextPrimary:I

    .line 133
    .line 134
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 135
    .line 136
    .line 137
    move-result-object v8

    .line 138
    const/high16 v9, 0x41c00000    # 24.0f

    .line 139
    .line 140
    const/16 v10, 0x72

    .line 141
    .line 142
    const/4 v7, 0x0

    .line 143
    invoke-static/range {v5 .. v10}, LG8/a;->x(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;Ljava/lang/Integer;Ljava/lang/Integer;FI)Lcom/mikepenz/iconics/IconicsDrawable;

    .line 144
    .line 145
    .line 146
    move-result-object v5

    .line 147
    const-string v6, "Local Information"

    .line 148
    .line 149
    invoke-direct {v1, v5, v6}, Lcom/transsnet/palmpay/credit/bean/other/CLNoPermissionBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    :cond_6
    new-instance v1, Lcom/transsnet/palmpay/credit/ui/dialog/OcNoPermissionDialog;

    .line 156
    .line 157
    invoke-virtual {v3}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 158
    .line 159
    .line 160
    move-result-object v5

    .line 161
    invoke-static {v5, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    invoke-direct {v1, v5, v4}, Lcom/transsnet/palmpay/credit/ui/dialog/OcNoPermissionDialog;-><init>(Landroid/content/Context;Ljava/util/ArrayList;)V

    .line 165
    .line 166
    .line 167
    new-instance v2, Ljb/c;

    .line 168
    .line 169
    const/4 v4, 0x0

    .line 170
    invoke-direct {v2, v3, v0, v4}, Ljb/c;-><init>(Lcom/transsnet/palmpay/core/base/BaseFragment;Ljava/util/ArrayList;I)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/credit/ui/dialog/OcNoPermissionDialog;->setOnSetPermissionClickListener(Lkotlin/jvm/functions/Function0;)V

    .line 174
    .line 175
    .line 176
    new-instance v2, Ljb/c;

    .line 177
    .line 178
    const/4 v4, 0x1

    .line 179
    invoke-direct {v2, v3, v0, v4}, Ljb/c;-><init>(Lcom/transsnet/palmpay/core/base/BaseFragment;Ljava/util/ArrayList;I)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/credit/ui/dialog/OcNoPermissionDialog;->setOnCloseClickListener(Lkotlin/jvm/functions/Function0;)V

    .line 183
    .line 184
    .line 185
    new-instance v2, Ljb/c;

    .line 186
    .line 187
    const/4 v4, 0x2

    .line 188
    invoke-direct {v2, v3, v0, v4}, Ljb/c;-><init>(Lcom/transsnet/palmpay/core/base/BaseFragment;Ljava/util/ArrayList;I)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/credit/ui/dialog/OcNoPermissionDialog;->setOnSetCountdownListener(Lkotlin/jvm/functions/Function0;)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/ui/dialog/OcNoPermissionDialog;->show()V

    .line 195
    .line 196
    .line 197
    :cond_7
    return-void
.end method

.method public final e(Ljava/lang/Integer;)V
    .locals 2

    .line 1
    sget-object v0, Lob/c;->a:Lob/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->getH5BorrowUrl(Ljava/lang/Integer;)Ldf/d;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    sget-object v0, Ltf/f;->b:Ldf/i;

    .line 19
    .line 20
    invoke-virtual {p1, v0}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {p1, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    new-instance v0, Ljb/e;

    .line 33
    .line 34
    const/4 v1, 0x0

    .line 35
    invoke-direct {v0, p0, v1}, Ljb/e;-><init>(Ljb/g;I)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1, v0}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 39
    .line 40
    .line 41
    return-void
.end method

.method public final f(Landroidx/fragment/app/Fragment;)V
    .locals 9

    .line 1
    const-string v0, "getRouterList >>> "

    .line 2
    .line 3
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x3

    .line 8
    const-string v2, "CLOpenAccountManager"

    .line 9
    .line 10
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lob/c;->a:Lob/a;

    .line 14
    .line 15
    invoke-static {v0}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/OcRouterReq;

    .line 20
    .line 21
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 22
    .line 23
    iget-object v3, p0, Ljb/g;->b:Ljava/lang/String;

    .line 24
    .line 25
    const/4 v4, -0x1

    .line 26
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    iget-object v7, p0, Ljb/g;->a:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v8, p0, Ljb/g;->d:Ljava/lang/String;

    .line 33
    .line 34
    const/4 v4, 0x2

    .line 35
    move-object v6, v2

    .line 36
    invoke-direct/range {v1 .. v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterReq;-><init>(Ljava/lang/Boolean;Ljava/lang/String;ILjava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->getRouterList(Lcom/transsnet/palmpay/credit/bean/req/OcRouterReq;)Ldf/d;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    new-instance v1, Ljb/f;

    .line 58
    .line 59
    invoke-direct {v1, p0, p1}, Ljb/f;-><init>(Ljb/g;Landroidx/fragment/app/Fragment;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public final h()V
    .locals 3

    .line 1
    iget-object v0, p0, Ljb/g;->g:Ljava/util/ArrayList;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget v0, p0, Ljb/g;->h:I

    .line 13
    .line 14
    iget-object v1, p0, Ljb/g;->g:Ljava/util/ArrayList;

    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-ge v0, v1, :cond_1

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    invoke-virtual {p0, v0}, Ljb/g;->k(Z)V

    .line 24
    .line 25
    .line 26
    const-string v0, "/credit_score/oc_start_apply_activity"

    .line 27
    .line 28
    invoke-virtual {p0, v0}, Ljb/g;->i(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :cond_1
    :goto_0
    iget-object v0, p0, Ljb/g;->b:Ljava/lang/String;

    .line 33
    .line 34
    const-string v1, "LOAN_WITHDRAW"

    .line 35
    .line 36
    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_6

    .line 41
    .line 42
    iget-object v0, p0, Ljb/g;->k:Ljava/lang/Integer;

    .line 43
    .line 44
    const/4 v1, 0x1

    .line 45
    if-nez v0, :cond_2

    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_2
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-ne v0, v1, :cond_3

    .line 53
    .line 54
    iget-object v0, p0, Ljb/g;->j:Ljava/lang/Integer;

    .line 55
    .line 56
    invoke-virtual {p0, v0}, Ljb/g;->e(Ljava/lang/Integer;)V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :cond_3
    :goto_1
    iget v0, p0, Ljb/g;->l:I

    .line 61
    .line 62
    if-ne v0, v1, :cond_4

    .line 63
    .line 64
    const-string v0, "/credit_score/cl_last_protocol_activity"

    .line 65
    .line 66
    invoke-virtual {p0, v0}, Ljb/g;->i(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :cond_4
    iget-object v0, p0, Ljb/g;->n:Ljava/lang/Integer;

    .line 71
    .line 72
    if-eqz v0, :cond_5

    .line 73
    .line 74
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    goto :goto_2

    .line 79
    :cond_5
    const/4 v0, 0x7

    .line 80
    :goto_2
    new-instance v1, Landroid/os/Bundle;

    .line 81
    .line 82
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 83
    .line 84
    .line 85
    const-string v2, "accountType"

    .line 86
    .line 87
    invoke-virtual {v1, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 88
    .line 89
    .line 90
    const-string v0, "bundle"

    .line 91
    .line 92
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    sget-object v0, LEb/a;->a:Ljava/lang/String;

    .line 99
    .line 100
    const-string v2, "Home_Source"

    .line 101
    .line 102
    invoke-virtual {v1, v2, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v1, v2, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    const-string v0, "LoanBorrowHome"

    .line 109
    .line 110
    invoke-static {v1, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    return-void

    .line 114
    :cond_6
    invoke-virtual {p0}, Ljb/g;->j()V

    .line 115
    .line 116
    .line 117
    return-void
.end method

.method public final i(Ljava/lang/String;)V
    .locals 13

    .line 1
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p1}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    const-string v0, "oc_current_router_index"

    .line 10
    .line 11
    iget v1, p0, Ljb/g;->h:I

    .line 12
    .line 13
    invoke-virtual {p1, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    iget-object v0, p0, Ljb/g;->b:Ljava/lang/String;

    .line 18
    .line 19
    const-string v1, "oc_business_type"

    .line 20
    .line 21
    invoke-virtual {p1, v1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    const-string v0, "oc_router_operate_type"

    .line 26
    .line 27
    iget-object v1, p0, Ljb/g;->m:Ljava/lang/String;

    .line 28
    .line 29
    invoke-virtual {p1, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    const-string v0, "key_need_sign_type"

    .line 34
    .line 35
    iget v1, p0, Ljb/g;->l:I

    .line 36
    .line 37
    invoke-virtual {p1, v0, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    iget-object v0, p0, Ljb/g;->j:Ljava/lang/Integer;

    .line 42
    .line 43
    if-eqz v0, :cond_0

    .line 44
    .line 45
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    goto :goto_0

    .line 50
    :cond_0
    const/4 v0, 0x1

    .line 51
    :goto_0
    const-string v1, "cl_product_type"

    .line 52
    .line 53
    invoke-virtual {p1, v1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 62
    .line 63
    iget-object v2, p0, Ljb/g;->a:Ljava/lang/String;

    .line 64
    .line 65
    const/4 v3, 0x2

    .line 66
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 67
    .line 68
    .line 69
    move-result-object v3

    .line 70
    iget-object v4, p0, Ljb/g;->d:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v5, p0, Ljb/g;->c:Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 73
    .line 74
    if-eqz v5, :cond_1

    .line 75
    .line 76
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;->getSceneType()Ljava/lang/Integer;

    .line 77
    .line 78
    .line 79
    move-result-object v5

    .line 80
    :goto_1
    move-object v6, v5

    .line 81
    goto :goto_2

    .line 82
    :cond_1
    const/4 v5, 0x0

    .line 83
    goto :goto_1

    .line 84
    :goto_2
    iget-object v9, p0, Ljb/g;->e:Ljava/lang/String;

    .line 85
    .line 86
    iget-object v10, p0, Ljb/g;->b:Ljava/lang/String;

    .line 87
    .line 88
    iget-object v11, p0, Ljb/g;->f:Ljava/util/ArrayList;

    .line 89
    .line 90
    iget-object v12, p0, Ljb/g;->g:Ljava/util/ArrayList;

    .line 91
    .line 92
    const/4 v7, 0x0

    .line 93
    const/4 v8, 0x0

    .line 94
    const-string v5, ""

    .line 95
    .line 96
    invoke-direct/range {v1 .. v12}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 97
    .line 98
    .line 99
    iget-object v0, v0, LPa/w;->b:Ljava/lang/Object;

    .line 100
    .line 101
    check-cast v0, Lcom/google/gson/Gson;

    .line 102
    .line 103
    invoke-virtual {v0, v1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    const-string v1, "oc_apply_data"

    .line 108
    .line 109
    invoke-virtual {p1, v1, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    return-void
.end method

.method public final j()V
    .locals 4

    .line 1
    iget-object v0, p0, Ljb/g;->b:Ljava/lang/String;

    .line 2
    .line 3
    const-string v1, "CASH_LOAN"

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_1

    .line 10
    .line 11
    iget-object v0, p0, Ljb/g;->b:Ljava/lang/String;

    .line 12
    .line 13
    const-string v1, "CASH_INSTANT_LOAN"

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    iget-object v0, p0, Ljb/g;->b:Ljava/lang/String;

    .line 22
    .line 23
    const-string v1, "INSTALLMENT_LOAN"

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    sget-object v0, Lob/c;->a:Lob/a;

    .line 33
    .line 34
    invoke-static {v0}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iget-object v1, p0, Ljb/g;->d:Ljava/lang/String;

    .line 39
    .line 40
    iget-object v2, p0, Ljb/g;->b:Ljava/lang/String;

    .line 41
    .line 42
    const/4 v3, 0x0

    .line 43
    invoke-interface {v0, v1, v3, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->installmentRaiseAmountV2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ldf/d;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    new-instance v1, Ljb/e;

    .line 62
    .line 63
    const/4 v2, 0x3

    .line 64
    invoke-direct {v1, p0, v2}, Ljb/e;-><init>(Ljb/g;I)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :cond_1
    :goto_0
    iget-object v0, p0, Ljb/g;->b:Ljava/lang/String;

    .line 72
    .line 73
    sget-object v1, Lob/c;->a:Lob/a;

    .line 74
    .line 75
    invoke-static {v1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    new-instance v2, Lcom/transsnet/palmpay/credit/bean/req/DoubleSignReq;

    .line 80
    .line 81
    invoke-direct {v2, v0}, Lcom/transsnet/palmpay/credit/bean/req/DoubleSignReq;-><init>(Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->querySignStatus(Lcom/transsnet/palmpay/credit/bean/req/DoubleSignReq;)Ldf/d;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 89
    .line 90
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    new-instance v1, Ljb/e;

    .line 103
    .line 104
    const/4 v2, 0x2

    .line 105
    invoke-direct {v1, p0, v2}, Ljb/e;-><init>(Ljb/g;I)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 109
    .line 110
    .line 111
    return-void
.end method

.method public final k(Z)V
    .locals 1

    .line 1
    iget-object v0, p0, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/core/base/BaseFragment;->showLoadingDialog(Z)V

    .line 6
    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public final l()V
    .locals 14

    .line 1
    iget-object v0, p0, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    new-instance v6, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    new-instance v0, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    const/4 v2, 0x0

    .line 14
    const/4 v3, 0x3

    .line 15
    invoke-direct {v0, v1, v2, v3, v1}, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 16
    .line 17
    .line 18
    const-string v4, "android.permission.READ_CONTACTS"

    .line 19
    .line 20
    invoke-virtual {v0, v4}, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;->setName(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    filled-new-array {v4}, [Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    invoke-static {v4}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    const/4 v5, 0x1

    .line 32
    if-nez v4, :cond_0

    .line 33
    .line 34
    invoke-virtual {v0, v3}, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;->setState(I)V

    .line 35
    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    invoke-virtual {v0, v5}, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;->setState(I)V

    .line 39
    .line 40
    .line 41
    :goto_0
    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    new-instance v0, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;

    .line 45
    .line 46
    invoke-direct {v0, v1, v2, v3, v1}, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 47
    .line 48
    .line 49
    const-string v1, "android.permission.READ_PHONE_STATE"

    .line 50
    .line 51
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;->setName(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    filled-new-array {v1}, [Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    invoke-static {v1}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-nez v1, :cond_1

    .line 63
    .line 64
    invoke-virtual {v0, v3}, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;->setState(I)V

    .line 65
    .line 66
    .line 67
    goto :goto_1

    .line 68
    :cond_1
    invoke-virtual {v0, v5}, Lcom/transsnet/palmpay/credit/bean/req/CLPermissionInfo;->setState(I)V

    .line 69
    .line 70
    .line 71
    :goto_1
    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/PermissionReq;

    .line 75
    .line 76
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 77
    .line 78
    .line 79
    move-result-wide v2

    .line 80
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 85
    .line 86
    .line 87
    move-result-wide v2

    .line 88
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 89
    .line 90
    .line 91
    move-result-object v5

    .line 92
    const-string v2, "flexi cash"

    .line 93
    .line 94
    const-string v3, "trade"

    .line 95
    .line 96
    invoke-direct/range {v1 .. v6}, Lcom/transsnet/palmpay/credit/bean/req/PermissionReq;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/util/List;)V

    .line 97
    .line 98
    .line 99
    sget-object v0, Lob/c;->a:Lob/a;

    .line 100
    .line 101
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 106
    .line 107
    .line 108
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadPermissionResult(Lcom/transsnet/palmpay/credit/bean/req/PermissionReq;)Ldf/d;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 117
    .line 118
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    new-instance v1, Ljb/e;

    .line 131
    .line 132
    const/4 v2, 0x7

    .line 133
    invoke-direct {v1, p0, v2}, Ljb/e;-><init>(Ljb/g;I)V

    .line 134
    .line 135
    .line 136
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 137
    .line 138
    .line 139
    :cond_2
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->j()Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    filled-new-array {v0}, [Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    if-nez v0, :cond_3

    .line 152
    .line 153
    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    .line 154
    .line 155
    filled-new-array {v0}, [Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-nez v0, :cond_3

    .line 164
    .line 165
    goto :goto_3

    .line 166
    :cond_3
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-virtual {v0}, Lya/a;->f()Lcom/transsnet/palmpay/core/bean/LocationRecord;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    if-eqz v0, :cond_4

    .line 175
    .line 176
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLatitude()D

    .line 177
    .line 178
    .line 179
    move-result-wide v1

    .line 180
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLongitude()D

    .line 181
    .line 182
    .line 183
    move-result-wide v3

    .line 184
    goto :goto_2

    .line 185
    :cond_4
    const-wide v1, 0x40c3878000000000L    # 9999.0

    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    move-wide v3, v1

    .line 191
    :goto_2
    new-instance v5, Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;

    .line 192
    .line 193
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 194
    .line 195
    .line 196
    move-result-object v6

    .line 197
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 198
    .line 199
    .line 200
    move-result-object v7

    .line 201
    const/16 v12, 0xc

    .line 202
    .line 203
    const/4 v13, 0x0

    .line 204
    const/4 v8, 0x0

    .line 205
    const/4 v9, 0x0

    .line 206
    const-string v10, "flexi cash"

    .line 207
    .line 208
    const-string v11, "trade"

    .line 209
    .line 210
    invoke-direct/range {v5 .. v13}, Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;-><init>(Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 211
    .line 212
    .line 213
    sget-object v0, Lob/c;->a:Lob/a;

    .line 214
    .line 215
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 220
    .line 221
    .line 222
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    invoke-interface {v0, v5}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadLocationInfo(Lcom/transsnet/palmpay/credit/bean/req/OcLocationInfoReq;)Ldf/d;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 231
    .line 232
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 233
    .line 234
    .line 235
    move-result-object v0

    .line 236
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    new-instance v1, Ljb/e;

    .line 245
    .line 246
    const/4 v2, 0x6

    .line 247
    invoke-direct {v1, p0, v2}, Ljb/e;-><init>(Ljb/g;I)V

    .line 248
    .line 249
    .line 250
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 251
    .line 252
    .line 253
    :goto_3
    sget-object v0, LFb/d;->a:LFb/c;

    .line 254
    .line 255
    iget-object v1, p0, Ljb/g;->d:Ljava/lang/String;

    .line 256
    .line 257
    const-string v2, "flexi cash"

    .line 258
    .line 259
    const-string v3, "trade"

    .line 260
    .line 261
    invoke-virtual {v0, v1, v2, v3}, LFb/c;->getOcDeviceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    sget-object v1, Lob/c;->a:Lob/a;

    .line 266
    .line 267
    invoke-virtual {v1}, Lob/a;->getInstance()Lob/c;

    .line 268
    .line 269
    .line 270
    move-result-object v3

    .line 271
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 272
    .line 273
    .line 274
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 275
    .line 276
    .line 277
    move-result-object v3

    .line 278
    invoke-interface {v3, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadDeviceInfoNew(Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;)Ldf/d;

    .line 279
    .line 280
    .line 281
    move-result-object v0

    .line 282
    sget-object v3, Ltf/f;->b:Ldf/i;

    .line 283
    .line 284
    invoke-virtual {v0, v3}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 285
    .line 286
    .line 287
    move-result-object v0

    .line 288
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 289
    .line 290
    .line 291
    move-result-object v4

    .line 292
    invoke-virtual {v0, v4}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    new-instance v4, Ljb/e;

    .line 297
    .line 298
    const/4 v5, 0x5

    .line 299
    invoke-direct {v4, p0, v5}, Ljb/e;-><init>(Ljb/g;I)V

    .line 300
    .line 301
    .line 302
    invoke-virtual {v0, v4}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 303
    .line 304
    .line 305
    const-string v0, "android.permission.CAMERA"

    .line 306
    .line 307
    filled-new-array {v0}, [Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    move-result-object v0

    .line 311
    invoke-static {v0}, Lcom/transsnet/palmpay/util/PermissionUtils;->isGranted([Ljava/lang/String;)Z

    .line 312
    .line 313
    .line 314
    move-result v0

    .line 315
    if-nez v0, :cond_5

    .line 316
    .line 317
    goto :goto_4

    .line 318
    :cond_5
    invoke-static {v1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 319
    .line 320
    .line 321
    move-result-object v0

    .line 322
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 323
    .line 324
    .line 325
    move-result-object v1

    .line 326
    invoke-static {v1}, Lcom/transsnet/palmpay/util/CameraUtils;->getOcCameraInfo(Landroid/content/Context;)Lcom/transsnet/palmpay/util/OcCameraInfoBean;

    .line 327
    .line 328
    .line 329
    move-result-object v1

    .line 330
    const-string v4, "getOcCameraInfo(...)"

    .line 331
    .line 332
    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadCameraInfo(Lcom/transsnet/palmpay/util/OcCameraInfoBean;)Ldf/d;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    invoke-virtual {v0, v3}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 340
    .line 341
    .line 342
    move-result-object v0

    .line 343
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 344
    .line 345
    .line 346
    move-result-object v1

    .line 347
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 348
    .line 349
    .line 350
    move-result-object v0

    .line 351
    new-instance v1, Ljb/e;

    .line 352
    .line 353
    const/4 v3, 0x4

    .line 354
    invoke-direct {v1, p0, v3}, Ljb/e;-><init>(Ljb/g;I)V

    .line 355
    .line 356
    .line 357
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 358
    .line 359
    .line 360
    :goto_4
    iget-object v0, p0, Ljb/g;->d:Ljava/lang/String;

    .line 361
    .line 362
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 363
    .line 364
    .line 365
    move-result v0

    .line 366
    if-eqz v0, :cond_6

    .line 367
    .line 368
    const-string v0, ""

    .line 369
    .line 370
    goto :goto_5

    .line 371
    :cond_6
    iget-object v0, p0, Ljb/g;->d:Ljava/lang/String;

    .line 372
    .line 373
    :goto_5
    iput-object v0, p0, Ljb/g;->d:Ljava/lang/String;

    .line 374
    .line 375
    sget-object v1, LGa/c;->a:LGa/b;

    .line 376
    .line 377
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 378
    .line 379
    .line 380
    const-string v3, "4"

    .line 381
    .line 382
    invoke-virtual {v1, v0, v3, v2}, LGa/b;->upload(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 383
    .line 384
    .line 385
    iget-object v0, p0, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 386
    .line 387
    if-eqz v0, :cond_7

    .line 388
    .line 389
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 390
    .line 391
    .line 392
    move-result-object v2

    .line 393
    if-eqz v2, :cond_7

    .line 394
    .line 395
    sget-object v1, Lcom/transsnet/palmpay/core/service/CollectDeviceInfoService;->o:Lcom/transsnet/palmpay/core/service/CollectDeviceInfoService$a;

    .line 396
    .line 397
    iget-object v7, p0, Ljb/g;->d:Ljava/lang/String;

    .line 398
    .line 399
    const-string v8, "flexi cash"

    .line 400
    .line 401
    const-string v9, "trade"

    .line 402
    .line 403
    const/4 v3, 0x1

    .line 404
    const/4 v4, 0x0

    .line 405
    const/4 v5, 0x1

    .line 406
    const/4 v6, 0x0

    .line 407
    const/4 v10, 0x4

    .line 408
    const/4 v11, 0x0

    .line 409
    invoke-static/range {v1 .. v11}, Lcom/transsnet/palmpay/core/service/CollectDeviceInfoService$a;->enqueueWork$default(Lcom/transsnet/palmpay/core/service/CollectDeviceInfoService$a;Landroid/content/Context;ZZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)V

    .line 410
    .line 411
    .line 412
    :cond_7
    invoke-virtual {p0}, Ljb/g;->h()V

    .line 413
    .line 414
    .line 415
    return-void
.end method
