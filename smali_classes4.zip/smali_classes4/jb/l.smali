.class public final Ljb/l;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljb/o;


# direct methods
.method public synthetic constructor <init>(Ljb/o;I)V
    .locals 0

    .line 1
    iput p2, p0, Ljb/l;->f:I

    iput-object p1, p0, Ljb/l;->g:Ljb/o;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Ljb/l;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljb/o;->i()Lgf/a;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :pswitch_0
    const-string v0, "d"

    .line 22
    .line 23
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 27
    .line 28
    invoke-virtual {v0}, Ljb/o;->i()Lgf/a;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :pswitch_1
    const-string v0, "d"

    .line 37
    .line 38
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 42
    .line 43
    invoke-virtual {v0}, Ljb/o;->i()Lgf/a;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :pswitch_2
    const-string v0, "d"

    .line 52
    .line 53
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 57
    .line 58
    invoke-virtual {v0}, Ljb/o;->i()Lgf/a;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 63
    .line 64
    .line 65
    return-void

    .line 66
    :pswitch_3
    const-string v0, "d"

    .line 67
    .line 68
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 72
    .line 73
    invoke-virtual {v0}, Ljb/o;->i()Lgf/a;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 78
    .line 79
    .line 80
    return-void

    .line 81
    :pswitch_4
    const-string v0, "d"

    .line 82
    .line 83
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 87
    .line 88
    invoke-virtual {v0}, Ljb/o;->i()Lgf/a;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 93
    .line 94
    .line 95
    return-void

    .line 96
    nop

    .line 97
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget v0, p0, Ljb/l;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "message"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    new-array v0, v0, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 19
    .line 20
    invoke-virtual {v0}, Ljb/o;->o()V

    .line 21
    .line 22
    .line 23
    const/4 v0, 0x0

    .line 24
    new-array v0, v0, [Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_1
    const-string v0, "loanRoute onFail >>> "

    .line 31
    .line 32
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    const-string v1, "CreditRouterManager"

    .line 41
    .line 42
    invoke-static {v1, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    const/4 v0, 0x0

    .line 46
    new-array v0, v0, [Ljava/lang/Object;

    .line 47
    .line 48
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    return-void

    .line 52
    :pswitch_2
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 53
    .line 54
    invoke-virtual {v0}, Ljb/o;->B()V

    .line 55
    .line 56
    .line 57
    if-eqz p1, :cond_1

    .line 58
    .line 59
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_0

    .line 64
    .line 65
    move-object v0, p1

    .line 66
    goto :goto_0

    .line 67
    :cond_0
    const/4 v0, 0x0

    .line 68
    :goto_0
    if-eqz v0, :cond_1

    .line 69
    .line 70
    const/4 v0, 0x0

    .line 71
    new-array v0, v0, [Ljava/lang/Object;

    .line 72
    .line 73
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_1
    return-void

    .line 77
    :pswitch_3
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 78
    .line 79
    invoke-virtual {v0}, Ljb/o;->B()V

    .line 80
    .line 81
    .line 82
    if-eqz p1, :cond_3

    .line 83
    .line 84
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-nez v0, :cond_2

    .line 89
    .line 90
    move-object v0, p1

    .line 91
    goto :goto_1

    .line 92
    :cond_2
    const/4 v0, 0x0

    .line 93
    :goto_1
    if-eqz v0, :cond_3

    .line 94
    .line 95
    const/4 v0, 0x0

    .line 96
    new-array v0, v0, [Ljava/lang/Object;

    .line 97
    .line 98
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    :cond_3
    return-void

    .line 102
    :pswitch_4
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 103
    .line 104
    invoke-virtual {v0}, Ljb/o;->o()V

    .line 105
    .line 106
    .line 107
    if-eqz p1, :cond_5

    .line 108
    .line 109
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 110
    .line 111
    .line 112
    move-result v1

    .line 113
    if-nez v1, :cond_4

    .line 114
    .line 115
    move-object v1, p1

    .line 116
    goto :goto_2

    .line 117
    :cond_4
    const/4 v1, 0x0

    .line 118
    :goto_2
    if-eqz v1, :cond_5

    .line 119
    .line 120
    const/4 v1, 0x0

    .line 121
    new-array v1, v1, [Ljava/lang/Object;

    .line 122
    .line 123
    invoke-static {p1, v1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    :cond_5
    iget-object p1, v0, Ljb/o;->k:Ljava/lang/String;

    .line 127
    .line 128
    const-string v1, "PALMPAY_CARD"

    .line 129
    .line 130
    invoke-static {p1, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 131
    .line 132
    .line 133
    move-result p1

    .line 134
    if-eqz p1, :cond_6

    .line 135
    .line 136
    iget p1, v0, Ljb/o;->m:I

    .line 137
    .line 138
    add-int/lit8 p1, p1, -0x1

    .line 139
    .line 140
    iput p1, v0, Ljb/o;->m:I

    .line 141
    .line 142
    :cond_6
    return-void

    .line 143
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 12

    .line 1
    iget v0, p0, Ljb/l;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentRaiseAmountRsp;

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v1, 0x1

    .line 15
    if-ne v0, v1, :cond_0

    .line 16
    .line 17
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentRaiseAmountRsp;->data:Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 22
    .line 23
    iget-object v1, p0, Ljb/l;->g:Ljb/o;

    .line 24
    .line 25
    invoke-static {v1, v0, p1}, Ljb/o;->a(Ljb/o;Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;Ljava/lang/Boolean;)V

    .line 26
    .line 27
    .line 28
    goto :goto_1

    .line 29
    :cond_0
    if-eqz p1, :cond_1

    .line 30
    .line 31
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    const/4 p1, 0x0

    .line 37
    :goto_0
    const/4 v0, 0x0

    .line 38
    new-array v0, v0, [Ljava/lang/Object;

    .line 39
    .line 40
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :goto_1
    return-void

    .line 44
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;

    .line 45
    .line 46
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 47
    .line 48
    invoke-virtual {v0}, Ljb/o;->o()V

    .line 49
    .line 50
    .line 51
    if-eqz p1, :cond_2

    .line 52
    .line 53
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    const/4 v2, 0x1

    .line 58
    if-ne v1, v2, :cond_2

    .line 59
    .line 60
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    if-eqz v1, :cond_2

    .line 65
    .line 66
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 71
    .line 72
    invoke-static {v0, p1, v1}, Ljb/o;->a(Ljb/o;Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;Ljava/lang/Boolean;)V

    .line 73
    .line 74
    .line 75
    goto :goto_3

    .line 76
    :cond_2
    if-eqz p1, :cond_3

    .line 77
    .line 78
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    goto :goto_2

    .line 83
    :cond_3
    const/4 p1, 0x0

    .line 84
    :goto_2
    const/4 v0, 0x0

    .line 85
    new-array v0, v0, [Ljava/lang/Object;

    .line 86
    .line 87
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    :goto_3
    return-void

    .line 91
    :pswitch_1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;

    .line 92
    .line 93
    const-string v0, "loanRoute onSuccess >>>"

    .line 94
    .line 95
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    const/4 v1, 0x3

    .line 100
    const-string v2, "CreditRouterManager"

    .line 101
    .line 102
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    const/4 v0, 0x0

    .line 106
    const/4 v3, 0x0

    .line 107
    iget-object v4, p0, Ljb/l;->g:Ljb/o;

    .line 108
    .line 109
    if-eqz p1, :cond_17

    .line 110
    .line 111
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 112
    .line 113
    .line 114
    move-result v5

    .line 115
    if-eqz v5, :cond_17

    .line 116
    .line 117
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 118
    .line 119
    .line 120
    move-result-object v5

    .line 121
    if-nez v5, :cond_4

    .line 122
    .line 123
    goto/16 :goto_e

    .line 124
    .line 125
    :cond_4
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 126
    .line 127
    .line 128
    move-result-object v5

    .line 129
    if-eqz v5, :cond_5

    .line 130
    .line 131
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getCustomerTag()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v5

    .line 135
    goto :goto_4

    .line 136
    :cond_5
    move-object v5, v0

    .line 137
    :goto_4
    iput-object v5, v4, Ljb/o;->l:Ljava/lang/String;

    .line 138
    .line 139
    sget-object v5, Llb/f;->e:Llb/e;

    .line 140
    .line 141
    invoke-virtual {v5}, Llb/e;->getInstance()Llb/f;

    .line 142
    .line 143
    .line 144
    move-result-object v5

    .line 145
    iget-object v8, v4, Ljb/o;->k:Ljava/lang/String;

    .line 146
    .line 147
    iput-object v8, v5, Llb/f;->b:Ljava/lang/String;

    .line 148
    .line 149
    new-instance v6, Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 150
    .line 151
    iget-object v7, v4, Ljb/o;->e:Ljava/lang/String;

    .line 152
    .line 153
    const-string v5, "OK_CARD"

    .line 154
    .line 155
    invoke-static {v8, v5}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    move-result v5

    .line 159
    if-eqz v5, :cond_6

    .line 160
    .line 161
    const-string v5, "OK_CARD_APPLY"

    .line 162
    .line 163
    :goto_5
    move-object v9, v5

    .line 164
    goto :goto_6

    .line 165
    :cond_6
    const-string v5, "CASH_LOAN_APPLY"

    .line 166
    .line 167
    goto :goto_5

    .line 168
    :goto_6
    iget v10, v4, Ljb/o;->m:I

    .line 169
    .line 170
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 171
    .line 172
    .line 173
    move-result-object v5

    .line 174
    if-eqz v5, :cond_7

    .line 175
    .line 176
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteInfoList()Ljava/util/List;

    .line 177
    .line 178
    .line 179
    move-result-object v5

    .line 180
    move-object v11, v5

    .line 181
    goto :goto_7

    .line 182
    :cond_7
    move-object v11, v0

    .line 183
    :goto_7
    invoke-direct/range {v6 .. v11}, Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/util/List;)V

    .line 184
    .line 185
    .line 186
    iput-object v6, v4, Ljb/o;->c:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 187
    .line 188
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 189
    .line 190
    .line 191
    move-result-object p1

    .line 192
    if-eqz p1, :cond_8

    .line 193
    .line 194
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteInfoList()Ljava/util/List;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    goto :goto_8

    .line 199
    :cond_8
    move-object p1, v0

    .line 200
    :goto_8
    iput-object p1, v4, Ljb/o;->d:Ljava/util/List;

    .line 201
    .line 202
    iget-object p1, v4, Ljb/o;->g:Ljava/lang/Integer;

    .line 203
    .line 204
    const-string v5, "mLoanCreditFragmentRef"

    .line 205
    .line 206
    const-string v6, "oc_permission_router"

    .line 207
    .line 208
    const/4 v7, 0x1

    .line 209
    if-nez p1, :cond_9

    .line 210
    .line 211
    goto/16 :goto_b

    .line 212
    .line 213
    :cond_9
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 214
    .line 215
    .line 216
    move-result p1

    .line 217
    if-ne p1, v7, :cond_10

    .line 218
    .line 219
    const-string p1, "creditBind >>>"

    .line 220
    .line 221
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object p1

    .line 225
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 226
    .line 227
    .line 228
    iget-object p1, v4, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 229
    .line 230
    if-eqz p1, :cond_f

    .line 231
    .line 232
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object p1

    .line 236
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 237
    .line 238
    if-eqz p1, :cond_1e

    .line 239
    .line 240
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/Z;

    .line 241
    .line 242
    .line 243
    move-result-object p1

    .line 244
    if-eqz p1, :cond_1e

    .line 245
    .line 246
    sget-object v1, Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog;->L:Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog$a;

    .line 247
    .line 248
    iget-object v2, v4, Ljb/o;->d:Ljava/util/List;

    .line 249
    .line 250
    if-eqz v2, :cond_e

    .line 251
    .line 252
    check-cast v2, Ljava/lang/Iterable;

    .line 253
    .line 254
    new-instance v5, Ljava/util/ArrayList;

    .line 255
    .line 256
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 257
    .line 258
    .line 259
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 260
    .line 261
    .line 262
    move-result-object v2

    .line 263
    :cond_a
    :goto_9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 264
    .line 265
    .line 266
    move-result v8

    .line 267
    if-eqz v8, :cond_d

    .line 268
    .line 269
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v8

    .line 273
    if-eqz v3, :cond_b

    .line 274
    .line 275
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 276
    .line 277
    .line 278
    goto :goto_9

    .line 279
    :cond_b
    move-object v9, v8

    .line 280
    check-cast v9, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 281
    .line 282
    if-eqz v9, :cond_c

    .line 283
    .line 284
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 285
    .line 286
    .line 287
    move-result-object v9

    .line 288
    goto :goto_a

    .line 289
    :cond_c
    move-object v9, v0

    .line 290
    :goto_a
    invoke-static {v6, v9}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 291
    .line 292
    .line 293
    move-result v9

    .line 294
    if-nez v9, :cond_a

    .line 295
    .line 296
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 297
    .line 298
    .line 299
    move v3, v7

    .line 300
    goto :goto_9

    .line 301
    :cond_d
    move-object v0, v5

    .line 302
    :cond_e
    new-instance v2, Ljb/i;

    .line 303
    .line 304
    const/4 v3, 0x0

    .line 305
    invoke-direct {v2, v4, v3}, Ljb/i;-><init>(Ljb/o;I)V

    .line 306
    .line 307
    .line 308
    invoke-virtual {v1, v0, v2}, Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog$a;->newInstance(Ljava/util/List;Lkotlin/jvm/functions/Function0;)Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog;

    .line 309
    .line 310
    .line 311
    move-result-object v0

    .line 312
    const-string v1, "showVerifyPalmPayAccountDialog"

    .line 313
    .line 314
    invoke-virtual {v0, p1, v1}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 315
    .line 316
    .line 317
    goto/16 :goto_10

    .line 318
    .line 319
    :cond_f
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    throw v0

    .line 323
    :cond_10
    :goto_b
    iget-object p1, v4, Ljb/o;->k:Ljava/lang/String;

    .line 324
    .line 325
    const-string v8, "LOAN_WITHDRAW"

    .line 326
    .line 327
    invoke-static {p1, v8}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 328
    .line 329
    .line 330
    move-result p1

    .line 331
    if-eqz p1, :cond_16

    .line 332
    .line 333
    iget-object p1, v4, Ljb/o;->d:Ljava/util/List;

    .line 334
    .line 335
    check-cast p1, Ljava/util/Collection;

    .line 336
    .line 337
    if-eqz p1, :cond_16

    .line 338
    .line 339
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 340
    .line 341
    .line 342
    move-result p1

    .line 343
    if-eqz p1, :cond_11

    .line 344
    .line 345
    goto/16 :goto_d

    .line 346
    .line 347
    :cond_11
    iget-object p1, v4, Ljb/o;->d:Ljava/util/List;

    .line 348
    .line 349
    if-eqz p1, :cond_13

    .line 350
    .line 351
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 352
    .line 353
    .line 354
    move-result p1

    .line 355
    if-ne p1, v7, :cond_13

    .line 356
    .line 357
    iget-object p1, v4, Ljb/o;->d:Ljava/util/List;

    .line 358
    .line 359
    if-eqz p1, :cond_12

    .line 360
    .line 361
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 362
    .line 363
    .line 364
    move-result-object p1

    .line 365
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 366
    .line 367
    if-eqz p1, :cond_12

    .line 368
    .line 369
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 370
    .line 371
    .line 372
    move-result-object p1

    .line 373
    goto :goto_c

    .line 374
    :cond_12
    move-object p1, v0

    .line 375
    :goto_c
    invoke-static {p1, v6}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 376
    .line 377
    .line 378
    move-result p1

    .line 379
    if-eqz p1, :cond_13

    .line 380
    .line 381
    goto :goto_d

    .line 382
    :cond_13
    const-string p1, "creditBorrow >>>"

    .line 383
    .line 384
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 385
    .line 386
    .line 387
    move-result-object p1

    .line 388
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 389
    .line 390
    .line 391
    iget-object p1, v4, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 392
    .line 393
    if-eqz p1, :cond_15

    .line 394
    .line 395
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 396
    .line 397
    .line 398
    move-result-object p1

    .line 399
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 400
    .line 401
    if-eqz p1, :cond_1e

    .line 402
    .line 403
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/Z;

    .line 404
    .line 405
    .line 406
    move-result-object p1

    .line 407
    if-eqz p1, :cond_1e

    .line 408
    .line 409
    iget-object v1, v4, Ljb/o;->d:Ljava/util/List;

    .line 410
    .line 411
    if-eqz v1, :cond_14

    .line 412
    .line 413
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 414
    .line 415
    .line 416
    move-result-object v1

    .line 417
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 418
    .line 419
    if-eqz v1, :cond_14

    .line 420
    .line 421
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 422
    .line 423
    .line 424
    move-result-object v0

    .line 425
    :cond_14
    sget-object v1, Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment;->M:Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment$a;

    .line 426
    .line 427
    invoke-virtual {v1, v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment$a;->newInstance(Ljava/lang/String;)Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment;

    .line 428
    .line 429
    .line 430
    move-result-object v0

    .line 431
    new-instance v1, Ljb/i;

    .line 432
    .line 433
    const/4 v2, 0x2

    .line 434
    invoke-direct {v1, v4, v2}, Ljb/i;-><init>(Ljb/o;I)V

    .line 435
    .line 436
    .line 437
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 438
    .line 439
    .line 440
    const-string v2, "countDownFinished"

    .line 441
    .line 442
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 443
    .line 444
    .line 445
    iput-object v1, v0, Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment;->H:Lkotlin/jvm/functions/Function0;

    .line 446
    .line 447
    const-string v1, "showFillYourInformationDialog"

    .line 448
    .line 449
    invoke-virtual {v0, p1, v1}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 450
    .line 451
    .line 452
    goto :goto_10

    .line 453
    :cond_15
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 454
    .line 455
    .line 456
    throw v0

    .line 457
    :cond_16
    :goto_d
    iget-object p1, v4, Ljb/o;->d:Ljava/util/List;

    .line 458
    .line 459
    invoke-virtual {v4, p1}, Ljb/o;->m(Ljava/util/List;)V

    .line 460
    .line 461
    .line 462
    goto :goto_10

    .line 463
    :cond_17
    :goto_e
    sget-object v1, Ljb/o;->z:Ljb/j;

    .line 464
    .line 465
    invoke-virtual {v1}, Ljb/j;->getCREDIT_INTERCEPT_CODES()[Ljava/lang/String;

    .line 466
    .line 467
    .line 468
    move-result-object v1

    .line 469
    if-eqz p1, :cond_18

    .line 470
    .line 471
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 472
    .line 473
    .line 474
    move-result-object v2

    .line 475
    goto :goto_f

    .line 476
    :cond_18
    move-object v2, v0

    .line 477
    :goto_f
    invoke-static {v1, v2}, Lkotlin/collections/n;->p([Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 478
    .line 479
    .line 480
    move-result v1

    .line 481
    if-eqz v1, :cond_19

    .line 482
    .line 483
    goto :goto_10

    .line 484
    :cond_19
    if-eqz p1, :cond_1a

    .line 485
    .line 486
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 487
    .line 488
    .line 489
    move-result-object v1

    .line 490
    if-nez v1, :cond_1b

    .line 491
    .line 492
    :cond_1a
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 493
    .line 494
    .line 495
    move-result-object v1

    .line 496
    sget v2, LYa/g;->cs_cl_service_busy:I

    .line 497
    .line 498
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 499
    .line 500
    .line 501
    move-result-object v1

    .line 502
    const-string v2, "getString(...)"

    .line 503
    .line 504
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 505
    .line 506
    .line 507
    :cond_1b
    if-eqz p1, :cond_1c

    .line 508
    .line 509
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 510
    .line 511
    .line 512
    move-result-object v0

    .line 513
    :cond_1c
    const-string p1, "FX000007"

    .line 514
    .line 515
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 516
    .line 517
    .line 518
    move-result p1

    .line 519
    if-eqz p1, :cond_1d

    .line 520
    .line 521
    invoke-static {v4, v1}, Ljb/o;->b(Ljb/o;Ljava/lang/String;)V

    .line 522
    .line 523
    .line 524
    goto :goto_10

    .line 525
    :cond_1d
    new-array p1, v3, [Ljava/lang/Object;

    .line 526
    .line 527
    invoke-static {v1, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 528
    .line 529
    .line 530
    :cond_1e
    :goto_10
    return-void

    .line 531
    :pswitch_2
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcSkipOneLoopResp;

    .line 532
    .line 533
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 534
    .line 535
    if-eqz p1, :cond_21

    .line 536
    .line 537
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 538
    .line 539
    .line 540
    move-result v1

    .line 541
    const/4 v2, 0x0

    .line 542
    if-eqz v1, :cond_1f

    .line 543
    .line 544
    goto :goto_11

    .line 545
    :cond_1f
    move-object p1, v2

    .line 546
    :goto_11
    if-eqz p1, :cond_21

    .line 547
    .line 548
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcSkipOneLoopResp;->getData()Ljava/lang/Boolean;

    .line 549
    .line 550
    .line 551
    move-result-object p1

    .line 552
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 553
    .line 554
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 555
    .line 556
    .line 557
    move-result p1

    .line 558
    if-eqz p1, :cond_20

    .line 559
    .line 560
    const-string p1, "OneLoopAct"

    .line 561
    .line 562
    invoke-static {v2, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 563
    .line 564
    .line 565
    goto :goto_12

    .line 566
    :cond_20
    invoke-static {v0}, Ljb/o;->w(Ljb/o;)V

    .line 567
    .line 568
    .line 569
    goto :goto_12

    .line 570
    :cond_21
    invoke-virtual {v0}, Ljb/o;->B()V

    .line 571
    .line 572
    .line 573
    :goto_12
    return-void

    .line 574
    :pswitch_3
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopDataResp;

    .line 575
    .line 576
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 577
    .line 578
    if-eqz p1, :cond_24

    .line 579
    .line 580
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 581
    .line 582
    .line 583
    move-result v1

    .line 584
    const/4 v2, 0x0

    .line 585
    if-eqz v1, :cond_22

    .line 586
    .line 587
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopDataResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopData;

    .line 588
    .line 589
    .line 590
    move-result-object v1

    .line 591
    if-eqz v1, :cond_22

    .line 592
    .line 593
    move-object v1, p1

    .line 594
    goto :goto_13

    .line 595
    :cond_22
    move-object v1, v2

    .line 596
    :goto_13
    if-eqz v1, :cond_24

    .line 597
    .line 598
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopDataResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopData;

    .line 599
    .line 600
    .line 601
    move-result-object p1

    .line 602
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 603
    .line 604
    .line 605
    const-string v1, "routerOneLoop >>>"

    .line 606
    .line 607
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 608
    .line 609
    .line 610
    move-result-object v1

    .line 611
    const/4 v3, 0x3

    .line 612
    const-string v4, "CreditRouterManager"

    .line 613
    .line 614
    invoke-static {v4, v3, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 615
    .line 616
    .line 617
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 618
    .line 619
    .line 620
    move-result-object v1

    .line 621
    if-eqz v1, :cond_25

    .line 622
    .line 623
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 624
    .line 625
    .line 626
    move-result-object v3

    .line 627
    sget v4, Lba/k;->core_one_loop_secret_key:I

    .line 628
    .line 629
    invoke-virtual {v1, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 630
    .line 631
    .line 632
    move-result-object v4

    .line 633
    sget v5, Lba/k;->core_one_loop_env:I

    .line 634
    .line 635
    invoke-virtual {v1, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 636
    .line 637
    .line 638
    move-result-object v5

    .line 639
    const-string v6, "getString(...)"

    .line 640
    .line 641
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 642
    .line 643
    .line 644
    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 645
    .line 646
    .line 647
    move-result v5

    .line 648
    invoke-static {v3, v4, v5}, Lcom/transsnet/mtn/sdk/MTN;->init(Landroid/content/Context;Ljava/lang/String;I)V

    .line 649
    .line 650
    .line 651
    new-instance v3, Lcom/transsnet/mtn/sdk/config/Configuration;

    .line 652
    .line 653
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 654
    .line 655
    .line 656
    if-eqz p1, :cond_23

    .line 657
    .line 658
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopData;->getId()Ljava/lang/String;

    .line 659
    .line 660
    .line 661
    move-result-object v2

    .line 662
    :cond_23
    iput-object v2, v3, Lcom/transsnet/mtn/sdk/config/Configuration;->auth_id:Ljava/lang/String;

    .line 663
    .line 664
    const-string p1, "100016"

    .line 665
    .line 666
    iput-object p1, v3, Lcom/transsnet/mtn/sdk/config/Configuration;->mtn_id:Ljava/lang/String;

    .line 667
    .line 668
    const-string p1, ""

    .line 669
    .line 670
    iput-object p1, v3, Lcom/transsnet/mtn/sdk/config/Configuration;->phone:Ljava/lang/String;

    .line 671
    .line 672
    iput-object p1, v3, Lcom/transsnet/mtn/sdk/config/Configuration;->agreeUrl:Ljava/lang/String;

    .line 673
    .line 674
    new-instance p1, Landroidx/work/impl/model/b;

    .line 675
    .line 676
    const/16 v2, 0xc

    .line 677
    .line 678
    invoke-direct {p1, v2, v0, v1}, Landroidx/work/impl/model/b;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 679
    .line 680
    .line 681
    invoke-static {v3, p1}, Lcom/transsnet/mtn/sdk/MTN;->start(Lcom/transsnet/mtn/sdk/config/Configuration;Lcom/transsnet/mtn/sdk/util/MTNHandler;)V

    .line 682
    .line 683
    .line 684
    goto :goto_14

    .line 685
    :cond_24
    invoke-virtual {v0}, Ljb/o;->B()V

    .line 686
    .line 687
    .line 688
    :cond_25
    :goto_14
    return-void

    .line 689
    :pswitch_4
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;

    .line 690
    .line 691
    iget-object v0, p0, Ljb/l;->g:Ljb/o;

    .line 692
    .line 693
    invoke-virtual {v0}, Ljb/o;->o()V

    .line 694
    .line 695
    .line 696
    const/4 v1, 0x0

    .line 697
    if-eqz p1, :cond_27

    .line 698
    .line 699
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 700
    .line 701
    .line 702
    move-result v2

    .line 703
    if-eqz v2, :cond_26

    .line 704
    .line 705
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 706
    .line 707
    .line 708
    move-result-object v2

    .line 709
    if-eqz v2, :cond_26

    .line 710
    .line 711
    move-object v2, p1

    .line 712
    goto :goto_15

    .line 713
    :cond_26
    move-object v2, v1

    .line 714
    :goto_15
    if-eqz v2, :cond_27

    .line 715
    .line 716
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 717
    .line 718
    .line 719
    move-result-object p1

    .line 720
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 721
    .line 722
    invoke-static {v0, p1, v1}, Ljb/o;->a(Ljb/o;Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;Ljava/lang/Boolean;)V

    .line 723
    .line 724
    .line 725
    goto :goto_16

    .line 726
    :cond_27
    if-eqz p1, :cond_29

    .line 727
    .line 728
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 729
    .line 730
    .line 731
    move-result-object p1

    .line 732
    if-eqz p1, :cond_29

    .line 733
    .line 734
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 735
    .line 736
    .line 737
    move-result v2

    .line 738
    if-nez v2, :cond_28

    .line 739
    .line 740
    move-object v1, p1

    .line 741
    :cond_28
    if-eqz v1, :cond_29

    .line 742
    .line 743
    const/4 p1, 0x0

    .line 744
    new-array p1, p1, [Ljava/lang/Object;

    .line 745
    .line 746
    invoke-static {v1, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 747
    .line 748
    .line 749
    :cond_29
    iget-object p1, v0, Ljb/o;->k:Ljava/lang/String;

    .line 750
    .line 751
    const-string v1, "PALMPAY_CARD"

    .line 752
    .line 753
    invoke-static {p1, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 754
    .line 755
    .line 756
    move-result p1

    .line 757
    if-eqz p1, :cond_2a

    .line 758
    .line 759
    iget p1, v0, Ljb/o;->m:I

    .line 760
    .line 761
    add-int/lit8 p1, p1, -0x1

    .line 762
    .line 763
    iput p1, v0, Ljb/o;->m:I

    .line 764
    .line 765
    :cond_2a
    :goto_16
    return-void

    .line 766
    nop

    .line 767
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
