.class public final synthetic Ljb/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljb/o;


# direct methods
.method public synthetic constructor <init>(Ljb/o;I)V
    .locals 0

    .line 1
    iput p2, p0, Ljb/h;->a:I

    iput-object p1, p0, Ljb/h;->b:Ljb/o;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Ljb/h;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    move-object/from16 v1, p1

    .line 9
    .line 10
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusResp;

    .line 11
    .line 12
    const-string v2, "it"

    .line 13
    .line 14
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v2, v0, Ljb/h;->b:Ljb/o;

    .line 18
    .line 19
    iget-object v3, v2, Ljb/o;->g:Ljava/lang/Integer;

    .line 20
    .line 21
    if-nez v3, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    const/4 v4, 0x1

    .line 29
    if-eq v3, v4, :cond_3

    .line 30
    .line 31
    :goto_0
    const-string v3, "PALMPAY_CARD"

    .line 32
    .line 33
    iget-object v4, v2, Ljb/o;->k:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v3, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    if-nez v3, :cond_3

    .line 40
    .line 41
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-eqz v3, :cond_2

    .line 46
    .line 47
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusData;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    if-eqz v1, :cond_2

    .line 52
    .line 53
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusData;->getType()Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    if-nez v1, :cond_1

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_1
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-nez v1, :cond_2

    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_2
    :goto_1
    invoke-virtual {v2}, Ljb/o;->o()V

    .line 68
    .line 69
    .line 70
    const-string v1, "/credit_score/cl_last_protocol_activity"

    .line 71
    .line 72
    const/4 v3, 0x0

    .line 73
    invoke-virtual {v2, v3, v1, v3}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    sget-object v1, Lio/reactivex/internal/operators/observable/m;->a:Lio/reactivex/internal/operators/observable/m;

    .line 77
    .line 78
    goto :goto_3

    .line 79
    :cond_3
    :goto_2
    const-string v1, "protocol is signed, just call submit"

    .line 80
    .line 81
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    const/4 v3, 0x3

    .line 86
    const-string v4, "CreditRouterManager"

    .line 87
    .line 88
    invoke-static {v4, v3, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    sget-object v1, Lob/c;->a:Lob/a;

    .line 92
    .line 93
    invoke-static {v1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    new-instance v3, Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;

    .line 98
    .line 99
    iget-object v4, v2, Ljb/o;->j:Ljava/lang/String;

    .line 100
    .line 101
    iget-object v5, v2, Ljb/o;->e:Ljava/lang/String;

    .line 102
    .line 103
    invoke-static {}, Ljb/o;->g()I

    .line 104
    .line 105
    .line 106
    move-result v6

    .line 107
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 108
    .line 109
    .line 110
    move-result-object v7

    .line 111
    iget-object v10, v2, Ljb/o;->l:Ljava/lang/String;

    .line 112
    .line 113
    iget-object v2, v2, Ljb/o;->k:Ljava/lang/String;

    .line 114
    .line 115
    const/16 v17, 0x0

    .line 116
    .line 117
    const/16 v18, 0x0

    .line 118
    .line 119
    const/4 v6, 0x0

    .line 120
    const/4 v8, 0x0

    .line 121
    const/4 v9, 0x0

    .line 122
    const/4 v11, 0x0

    .line 123
    const/4 v12, 0x0

    .line 124
    const/4 v13, 0x0

    .line 125
    const/4 v14, 0x0

    .line 126
    const/4 v15, 0x0

    .line 127
    const/16 v16, 0x0

    .line 128
    .line 129
    const/16 v20, 0x7fb4

    .line 130
    .line 131
    const/16 v21, 0x0

    .line 132
    .line 133
    move-object/from16 v19, v2

    .line 134
    .line 135
    invoke-direct/range {v3 .. v21}, Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 136
    .line 137
    .line 138
    invoke-interface {v1, v3}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->openCashLoan(Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;)Ldf/d;

    .line 139
    .line 140
    .line 141
    move-result-object v1

    .line 142
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 143
    .line 144
    invoke-virtual {v1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    :goto_3
    return-object v1

    .line 149
    :pswitch_0
    move-object/from16 v1, p1

    .line 150
    .line 151
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;

    .line 152
    .line 153
    const-string v2, "it"

    .line 154
    .line 155
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 159
    .line 160
    .line 161
    move-result v2

    .line 162
    if-eqz v2, :cond_5

    .line 163
    .line 164
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    if-nez v2, :cond_4

    .line 169
    .line 170
    goto :goto_4

    .line 171
    :cond_4
    iget-object v1, v0, Ljb/h;->b:Ljb/o;

    .line 172
    .line 173
    iget-object v2, v1, Ljb/o;->k:Ljava/lang/String;

    .line 174
    .line 175
    iget-object v3, v1, Ljb/o;->j:Ljava/lang/String;

    .line 176
    .line 177
    iget-object v1, v1, Ljb/o;->e:Ljava/lang/String;

    .line 178
    .line 179
    invoke-static {v2, v3, v1}, Ljb/o;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ldf/d;

    .line 180
    .line 181
    .line 182
    move-result-object v1

    .line 183
    goto :goto_5

    .line 184
    :cond_5
    :goto_4
    new-instance v2, Ljava/lang/StringBuilder;

    .line 185
    .line 186
    const-string v3, "initApplyLog error >>> "

    .line 187
    .line 188
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 192
    .line 193
    .line 194
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object v2

    .line 198
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v2

    .line 202
    const-string v3, "CreditRouterManager"

    .line 203
    .line 204
    invoke-static {v3, v2}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    sget-object v2, Ljb/o;->B:[Ljava/lang/String;

    .line 208
    .line 209
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object v4

    .line 213
    invoke-static {v2, v4}, Lkotlin/collections/n;->p([Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 214
    .line 215
    .line 216
    move-result v2

    .line 217
    if-eqz v2, :cond_6

    .line 218
    .line 219
    const-string v2, "CLRouteInterceptDialog >>> show"

    .line 220
    .line 221
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v2

    .line 225
    const/4 v4, 0x3

    .line 226
    invoke-static {v3, v4, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 230
    .line 231
    .line 232
    move-result-object v2

    .line 233
    if-eqz v2, :cond_6

    .line 234
    .line 235
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;->getBlockItem()Lcom/transsnet/palmpay/credit/bean/resp/BlockItem;

    .line 236
    .line 237
    .line 238
    move-result-object v2

    .line 239
    if-eqz v2, :cond_6

    .line 240
    .line 241
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 242
    .line 243
    .line 244
    move-result-object v3

    .line 245
    if-eqz v3, :cond_6

    .line 246
    .line 247
    new-instance v4, Lcom/flexibank/sdk/g;

    .line 248
    .line 249
    const/16 v5, 0x17

    .line 250
    .line 251
    invoke-direct {v4, v5, v3, v2}, Lcom/flexibank/sdk/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v3, v4}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 255
    .line 256
    .line 257
    :cond_6
    new-instance v2, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;

    .line 258
    .line 259
    const/4 v3, 0x0

    .line 260
    invoke-direct {v2, v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;-><init>(Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;)V

    .line 261
    .line 262
    .line 263
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 264
    .line 265
    .line 266
    move-result-object v3

    .line 267
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/core/bean/CommonResult;->setRespCode(Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    move-result-object v1

    .line 274
    invoke-virtual {v2, v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->setRespMsg(Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    invoke-static {v2}, Ldf/d;->h(Ljava/lang/Object;)Lio/reactivex/internal/operators/observable/B;

    .line 278
    .line 279
    .line 280
    move-result-object v1

    .line 281
    :goto_5
    return-object v1

    .line 282
    :pswitch_1
    move-object/from16 v1, p1

    .line 283
    .line 284
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;

    .line 285
    .line 286
    if-eqz v1, :cond_a

    .line 287
    .line 288
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 289
    .line 290
    .line 291
    move-result v2

    .line 292
    const/4 v3, 0x1

    .line 293
    if-ne v2, v3, :cond_a

    .line 294
    .line 295
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 296
    .line 297
    .line 298
    move-result-object v2

    .line 299
    if-eqz v2, :cond_a

    .line 300
    .line 301
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 302
    .line 303
    .line 304
    move-result-object v2

    .line 305
    const/4 v3, 0x0

    .line 306
    if-eqz v2, :cond_7

    .line 307
    .line 308
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;->getApplyId()Ljava/lang/String;

    .line 309
    .line 310
    .line 311
    move-result-object v2

    .line 312
    goto :goto_6

    .line 313
    :cond_7
    move-object v2, v3

    .line 314
    :goto_6
    iget-object v4, v0, Ljb/h;->b:Ljb/o;

    .line 315
    .line 316
    iput-object v2, v4, Ljb/o;->e:Ljava/lang/String;

    .line 317
    .line 318
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 319
    .line 320
    .line 321
    move-result-object v2

    .line 322
    if-eqz v2, :cond_8

    .line 323
    .line 324
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;->getSceneType()Ljava/lang/Integer;

    .line 325
    .line 326
    .line 327
    move-result-object v2

    .line 328
    goto :goto_7

    .line 329
    :cond_8
    move-object v2, v3

    .line 330
    :goto_7
    iput-object v2, v4, Ljb/o;->g:Ljava/lang/Integer;

    .line 331
    .line 332
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 333
    .line 334
    .line 335
    move-result-object v1

    .line 336
    if-eqz v1, :cond_9

    .line 337
    .line 338
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;->getCreditSceneRouteBindingFailTimes()Ljava/lang/Integer;

    .line 339
    .line 340
    .line 341
    move-result-object v3

    .line 342
    :cond_9
    iput-object v3, v4, Ljb/o;->f:Ljava/lang/Integer;

    .line 343
    .line 344
    :cond_a
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 345
    .line 346
    return-object v1

    .line 347
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
