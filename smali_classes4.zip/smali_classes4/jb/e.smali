.class public final Ljb/e;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljb/g;


# direct methods
.method public synthetic constructor <init>(Ljb/g;I)V
    .locals 0

    .line 1
    iput p2, p0, Ljb/e;->f:I

    iput-object p1, p0, Ljb/e;->g:Ljb/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final R(Ljava/lang/String;)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Ljb/e;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 12
    .line 13
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :pswitch_0
    const-string v0, "d"

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 23
    .line 24
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :pswitch_1
    const-string v0, "d"

    .line 29
    .line 30
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 34
    .line 35
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_2
    const-string v0, "d"

    .line 40
    .line 41
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 45
    .line 46
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :pswitch_3
    const-string v0, "d"

    .line 51
    .line 52
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 56
    .line 57
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :pswitch_4
    const-string v0, "d"

    .line 62
    .line 63
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 67
    .line 68
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :pswitch_5
    const-string v0, "d"

    .line 73
    .line 74
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 78
    .line 79
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :pswitch_6
    const-string v0, "d"

    .line 84
    .line 85
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 89
    .line 90
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 91
    .line 92
    .line 93
    return-void

    .line 94
    nop

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget v0, p0, Ljb/e;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    const-string v0, "message"

    .line 8
    .line 9
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    new-array v0, v0, [Ljava/lang/Object;

    .line 14
    .line 15
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_1
    const-string v0, "message"

    .line 20
    .line 21
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    new-array v0, v0, [Ljava/lang/Object;

    .line 26
    .line 27
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :pswitch_2
    const-string v0, "message"

    .line 32
    .line 33
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const/4 v0, 0x0

    .line 37
    new-array v0, v0, [Ljava/lang/Object;

    .line 38
    .line 39
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :pswitch_3
    const-string v0, "message"

    .line 44
    .line 45
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 49
    .line 50
    const/4 v1, 0x0

    .line 51
    invoke-virtual {v0, v1}, Ljb/g;->k(Z)V

    .line 52
    .line 53
    .line 54
    new-array v0, v1, [Ljava/lang/Object;

    .line 55
    .line 56
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :pswitch_4
    const-string v0, "message"

    .line 61
    .line 62
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 66
    .line 67
    const/4 v1, 0x0

    .line 68
    invoke-virtual {v0, v1}, Ljb/g;->k(Z)V

    .line 69
    .line 70
    .line 71
    new-array v0, v1, [Ljava/lang/Object;

    .line 72
    .line 73
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :pswitch_5
    const-string v0, "message"

    .line 78
    .line 79
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 83
    .line 84
    const/4 v1, 0x0

    .line 85
    invoke-virtual {v0, v1}, Ljb/g;->k(Z)V

    .line 86
    .line 87
    .line 88
    new-array v0, v1, [Ljava/lang/Object;

    .line 89
    .line 90
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    return-void

    .line 94
    :pswitch_6
    const-string v0, "message"

    .line 95
    .line 96
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    iget-object v0, p0, Ljb/e;->g:Ljb/g;

    .line 100
    .line 101
    const/4 v1, 0x0

    .line 102
    invoke-virtual {v0, v1}, Ljb/g;->k(Z)V

    .line 103
    .line 104
    .line 105
    new-array v0, v1, [Ljava/lang/Object;

    .line 106
    .line 107
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 23

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Ljb/e;->f:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    move-object/from16 v0, p1

    .line 9
    .line 10
    check-cast v0, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 11
    .line 12
    return-void

    .line 13
    :pswitch_0
    move-object/from16 v0, p1

    .line 14
    .line 15
    check-cast v0, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    const/4 v3, 0x1

    .line 24
    if-ne v2, v3, :cond_0

    .line 25
    .line 26
    goto :goto_1

    .line 27
    :cond_0
    if-eqz v0, :cond_1

    .line 28
    .line 29
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    goto :goto_0

    .line 34
    :cond_1
    const/4 v0, 0x0

    .line 35
    :goto_0
    const/4 v2, 0x0

    .line 36
    new-array v2, v2, [Ljava/lang/Object;

    .line 37
    .line 38
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    :goto_1
    return-void

    .line 42
    :pswitch_1
    move-object/from16 v0, p1

    .line 43
    .line 44
    check-cast v0, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 45
    .line 46
    if-eqz v0, :cond_2

    .line 47
    .line 48
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    const/4 v3, 0x1

    .line 53
    if-ne v2, v3, :cond_2

    .line 54
    .line 55
    goto :goto_3

    .line 56
    :cond_2
    if-eqz v0, :cond_3

    .line 57
    .line 58
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    goto :goto_2

    .line 63
    :cond_3
    const/4 v0, 0x0

    .line 64
    :goto_2
    const/4 v2, 0x0

    .line 65
    new-array v2, v2, [Ljava/lang/Object;

    .line 66
    .line 67
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    :goto_3
    return-void

    .line 71
    :pswitch_2
    move-object/from16 v0, p1

    .line 72
    .line 73
    check-cast v0, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 74
    .line 75
    if-eqz v0, :cond_4

    .line 76
    .line 77
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    const/4 v3, 0x1

    .line 82
    if-ne v2, v3, :cond_4

    .line 83
    .line 84
    goto :goto_5

    .line 85
    :cond_4
    if-eqz v0, :cond_5

    .line 86
    .line 87
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    goto :goto_4

    .line 92
    :cond_5
    const/4 v0, 0x0

    .line 93
    :goto_4
    const/4 v2, 0x0

    .line 94
    new-array v2, v2, [Ljava/lang/Object;

    .line 95
    .line 96
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    :goto_5
    return-void

    .line 100
    :pswitch_3
    move-object/from16 v0, p1

    .line 101
    .line 102
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentRaiseAmountRsp;

    .line 103
    .line 104
    iget-object v2, v1, Ljb/e;->g:Ljb/g;

    .line 105
    .line 106
    const/4 v3, 0x0

    .line 107
    invoke-virtual {v2, v3}, Ljb/g;->k(Z)V

    .line 108
    .line 109
    .line 110
    if-eqz v0, :cond_6

    .line 111
    .line 112
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 113
    .line 114
    .line 115
    move-result v2

    .line 116
    const/4 v4, 0x1

    .line 117
    if-ne v2, v4, :cond_6

    .line 118
    .line 119
    iget-object v2, v0, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentRaiseAmountRsp;->data:Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 120
    .line 121
    if-eqz v2, :cond_6

    .line 122
    .line 123
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    const-string v3, "/credit_score/ol_open_result_activity"

    .line 128
    .line 129
    invoke-virtual {v2, v3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 134
    .line 135
    .line 136
    move-result-object v3

    .line 137
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/bean/resp/OcInstallmentRaiseAmountRsp;->data:Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 138
    .line 139
    iget-object v3, v3, LPa/w;->b:Ljava/lang/Object;

    .line 140
    .line 141
    check-cast v3, Lcom/google/gson/Gson;

    .line 142
    .line 143
    invoke-virtual {v3, v0}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    const-string v3, "cl_open_result"

    .line 148
    .line 149
    invoke-virtual {v2, v3, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    invoke-virtual {v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    goto :goto_7

    .line 157
    :cond_6
    if-eqz v0, :cond_7

    .line 158
    .line 159
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    goto :goto_6

    .line 164
    :cond_7
    const/4 v0, 0x0

    .line 165
    :goto_6
    new-array v2, v3, [Ljava/lang/Object;

    .line 166
    .line 167
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    :goto_7
    return-void

    .line 171
    :pswitch_4
    move-object/from16 v0, p1

    .line 172
    .line 173
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusResp;

    .line 174
    .line 175
    iget-object v2, v1, Ljb/e;->g:Ljb/g;

    .line 176
    .line 177
    const/4 v3, 0x0

    .line 178
    invoke-virtual {v2, v3}, Ljb/g;->k(Z)V

    .line 179
    .line 180
    .line 181
    const/4 v4, 0x0

    .line 182
    if-eqz v0, :cond_d

    .line 183
    .line 184
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 185
    .line 186
    .line 187
    move-result v5

    .line 188
    const/4 v6, 0x1

    .line 189
    if-ne v5, v6, :cond_d

    .line 190
    .line 191
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusData;

    .line 192
    .line 193
    .line 194
    move-result-object v5

    .line 195
    if-eqz v5, :cond_d

    .line 196
    .line 197
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusData;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    if-eqz v0, :cond_c

    .line 202
    .line 203
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/OcSignStatusData;->getType()Ljava/lang/Integer;

    .line 204
    .line 205
    .line 206
    move-result-object v0

    .line 207
    if-nez v0, :cond_8

    .line 208
    .line 209
    goto/16 :goto_b

    .line 210
    .line 211
    :cond_8
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 212
    .line 213
    .line 214
    move-result v0

    .line 215
    if-nez v0, :cond_c

    .line 216
    .line 217
    :try_start_0
    iget-object v0, v2, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 218
    .line 219
    if-eqz v0, :cond_9

    .line 220
    .line 221
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 222
    .line 223
    .line 224
    move-result-object v0

    .line 225
    if-eqz v0, :cond_9

    .line 226
    .line 227
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    if-eqz v0, :cond_9

    .line 232
    .line 233
    invoke-virtual {v0, v3}, Landroid/content/pm/PackageManager;->getInstalledPackages(I)Ljava/util/List;

    .line 234
    .line 235
    .line 236
    move-result-object v4

    .line 237
    goto :goto_8

    .line 238
    :catch_0
    move-exception v0

    .line 239
    goto :goto_9

    .line 240
    :cond_9
    :goto_8
    move-object v0, v4

    .line 241
    check-cast v0, Ljava/util/Collection;

    .line 242
    .line 243
    if-eqz v0, :cond_b

    .line 244
    .line 245
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 246
    .line 247
    .line 248
    move-result v0

    .line 249
    if-eqz v0, :cond_a

    .line 250
    .line 251
    goto :goto_a

    .line 252
    :cond_a
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 253
    .line 254
    .line 255
    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 256
    goto :goto_a

    .line 257
    :goto_9
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 258
    .line 259
    .line 260
    :cond_b
    :goto_a
    sget-object v0, Lob/c;->a:Lob/a;

    .line 261
    .line 262
    invoke-static {v0}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    new-instance v4, Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;

    .line 267
    .line 268
    iget-object v5, v2, Ljb/g;->a:Ljava/lang/String;

    .line 269
    .line 270
    iget-object v6, v2, Ljb/g;->d:Ljava/lang/String;

    .line 271
    .line 272
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 273
    .line 274
    .line 275
    move-result-object v8

    .line 276
    iget-object v11, v2, Ljb/g;->e:Ljava/lang/String;

    .line 277
    .line 278
    iget-object v12, v2, Ljb/g;->b:Ljava/lang/String;

    .line 279
    .line 280
    const v21, 0xff00

    .line 281
    .line 282
    .line 283
    const/16 v22, 0x0

    .line 284
    .line 285
    const-string v7, ""

    .line 286
    .line 287
    const/4 v9, 0x0

    .line 288
    const/4 v10, 0x0

    .line 289
    const/4 v13, 0x0

    .line 290
    const/4 v14, 0x0

    .line 291
    const/4 v15, 0x0

    .line 292
    const/16 v16, 0x0

    .line 293
    .line 294
    const/16 v17, 0x0

    .line 295
    .line 296
    const/16 v18, 0x0

    .line 297
    .line 298
    const/16 v19, 0x0

    .line 299
    .line 300
    const/16 v20, 0x0

    .line 301
    .line 302
    invoke-direct/range {v4 .. v22}, Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 303
    .line 304
    .line 305
    invoke-interface {v0, v4}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->openCashLoan(Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;)Ldf/d;

    .line 306
    .line 307
    .line 308
    move-result-object v0

    .line 309
    sget-object v3, Ltf/f;->b:Ldf/i;

    .line 310
    .line 311
    invoke-virtual {v0, v3}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 316
    .line 317
    .line 318
    move-result-object v3

    .line 319
    invoke-virtual {v0, v3}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 320
    .line 321
    .line 322
    move-result-object v0

    .line 323
    new-instance v3, Ljb/e;

    .line 324
    .line 325
    const/4 v4, 0x1

    .line 326
    invoke-direct {v3, v2, v4}, Ljb/e;-><init>(Ljb/g;I)V

    .line 327
    .line 328
    .line 329
    invoke-virtual {v0, v3}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 330
    .line 331
    .line 332
    goto :goto_c

    .line 333
    :cond_c
    :goto_b
    const-string v0, "/credit_score/cl_last_protocol_activity"

    .line 334
    .line 335
    invoke-virtual {v2, v0}, Ljb/g;->i(Ljava/lang/String;)V

    .line 336
    .line 337
    .line 338
    goto :goto_c

    .line 339
    :cond_d
    if-eqz v0, :cond_e

    .line 340
    .line 341
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object v4

    .line 345
    :cond_e
    new-array v0, v3, [Ljava/lang/Object;

    .line 346
    .line 347
    invoke-static {v4, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    :goto_c
    return-void

    .line 351
    :pswitch_5
    move-object/from16 v0, p1

    .line 352
    .line 353
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;

    .line 354
    .line 355
    iget-object v2, v1, Ljb/e;->g:Ljb/g;

    .line 356
    .line 357
    const/4 v3, 0x0

    .line 358
    invoke-virtual {v2, v3}, Ljb/g;->k(Z)V

    .line 359
    .line 360
    .line 361
    if-eqz v0, :cond_f

    .line 362
    .line 363
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 364
    .line 365
    .line 366
    move-result v2

    .line 367
    const/4 v4, 0x1

    .line 368
    if-ne v2, v4, :cond_f

    .line 369
    .line 370
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 371
    .line 372
    .line 373
    move-result-object v2

    .line 374
    if-eqz v2, :cond_f

    .line 375
    .line 376
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 377
    .line 378
    .line 379
    move-result-object v2

    .line 380
    const-string v3, "/credit_score/ol_open_result_activity"

    .line 381
    .line 382
    invoke-virtual {v2, v3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 383
    .line 384
    .line 385
    move-result-object v2

    .line 386
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 387
    .line 388
    .line 389
    move-result-object v3

    .line 390
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;

    .line 391
    .line 392
    .line 393
    move-result-object v0

    .line 394
    iget-object v3, v3, LPa/w;->b:Ljava/lang/Object;

    .line 395
    .line 396
    check-cast v3, Lcom/google/gson/Gson;

    .line 397
    .line 398
    invoke-virtual {v3, v0}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 399
    .line 400
    .line 401
    move-result-object v0

    .line 402
    const-string v3, "cl_open_result"

    .line 403
    .line 404
    invoke-virtual {v2, v3, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 405
    .line 406
    .line 407
    move-result-object v0

    .line 408
    invoke-virtual {v0}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 409
    .line 410
    .line 411
    goto :goto_e

    .line 412
    :cond_f
    if-eqz v0, :cond_10

    .line 413
    .line 414
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 415
    .line 416
    .line 417
    move-result-object v0

    .line 418
    goto :goto_d

    .line 419
    :cond_10
    const/4 v0, 0x0

    .line 420
    :goto_d
    new-array v2, v3, [Ljava/lang/Object;

    .line 421
    .line 422
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 423
    .line 424
    .line 425
    :goto_e
    return-void

    .line 426
    :pswitch_6
    move-object/from16 v0, p1

    .line 427
    .line 428
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlResp;

    .line 429
    .line 430
    iget-object v2, v1, Ljb/e;->g:Ljb/g;

    .line 431
    .line 432
    const/4 v3, 0x0

    .line 433
    invoke-virtual {v2, v3}, Ljb/g;->k(Z)V

    .line 434
    .line 435
    .line 436
    const/4 v4, 0x0

    .line 437
    if-eqz v0, :cond_18

    .line 438
    .line 439
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 440
    .line 441
    .line 442
    move-result v5

    .line 443
    const/4 v6, 0x1

    .line 444
    if-ne v5, v6, :cond_18

    .line 445
    .line 446
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlData;

    .line 447
    .line 448
    .line 449
    move-result-object v5

    .line 450
    if-eqz v5, :cond_11

    .line 451
    .line 452
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlData;->getH5BorrowUrl()Ljava/lang/String;

    .line 453
    .line 454
    .line 455
    move-result-object v5

    .line 456
    goto :goto_f

    .line 457
    :cond_11
    move-object v5, v4

    .line 458
    :goto_f
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 459
    .line 460
    .line 461
    move-result v5

    .line 462
    if-nez v5, :cond_18

    .line 463
    .line 464
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 465
    .line 466
    .line 467
    move-result-object v5

    .line 468
    const-string v7, "show_h5_borrow_dialog"

    .line 469
    .line 470
    invoke-virtual {v5, v7, v6}, Lcom/transsnet/palmpay/util/SPUtils;->getBoolean(Ljava/lang/String;Z)Z

    .line 471
    .line 472
    .line 473
    move-result v5

    .line 474
    if-eqz v5, :cond_17

    .line 475
    .line 476
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlData;

    .line 477
    .line 478
    .line 479
    move-result-object v0

    .line 480
    if-eqz v0, :cond_12

    .line 481
    .line 482
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlData;->getH5BorrowUrl()Ljava/lang/String;

    .line 483
    .line 484
    .line 485
    move-result-object v0

    .line 486
    goto :goto_10

    .line 487
    :cond_12
    move-object v0, v4

    .line 488
    :goto_10
    new-instance v5, LO6/c;

    .line 489
    .line 490
    iget-object v6, v2, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 491
    .line 492
    if-eqz v6, :cond_13

    .line 493
    .line 494
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 495
    .line 496
    .line 497
    move-result-object v6

    .line 498
    goto :goto_11

    .line 499
    :cond_13
    move-object v6, v4

    .line 500
    :goto_11
    invoke-direct {v5, v6}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 501
    .line 502
    .line 503
    sget v6, LL6/i;->ppFlexiCashDialogTheme:I

    .line 504
    .line 505
    iput v6, v5, LO6/c;->v:I

    .line 506
    .line 507
    iput-boolean v3, v5, LO6/c;->k:Z

    .line 508
    .line 509
    iget-object v6, v2, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 510
    .line 511
    if-eqz v6, :cond_14

    .line 512
    .line 513
    sget v8, LYa/g;->cs_cl_h5_borrow_dialog_title:I

    .line 514
    .line 515
    invoke-virtual {v6, v8}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 516
    .line 517
    .line 518
    move-result-object v6

    .line 519
    goto :goto_12

    .line 520
    :cond_14
    move-object v6, v4

    .line 521
    :goto_12
    invoke-static {v6}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 522
    .line 523
    .line 524
    move-result-object v6

    .line 525
    iput-object v6, v5, LO6/c;->b:Ljava/lang/CharSequence;

    .line 526
    .line 527
    iget-object v6, v2, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 528
    .line 529
    if-eqz v6, :cond_15

    .line 530
    .line 531
    sget v8, LYa/g;->cs_cl_h5_borrow_dialog_content:I

    .line 532
    .line 533
    invoke-virtual {v6, v8}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 534
    .line 535
    .line 536
    move-result-object v6

    .line 537
    goto :goto_13

    .line 538
    :cond_15
    move-object v6, v4

    .line 539
    :goto_13
    iput-object v6, v5, LO6/c;->d:Ljava/lang/CharSequence;

    .line 540
    .line 541
    iget-object v2, v2, Ljb/g;->i:Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 542
    .line 543
    if-eqz v2, :cond_16

    .line 544
    .line 545
    sget v4, Lba/k;->core_got_it:I

    .line 546
    .line 547
    invoke-virtual {v2, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    .line 548
    .line 549
    .line 550
    move-result-object v4

    .line 551
    :cond_16
    new-instance v2, LC9/q;

    .line 552
    .line 553
    const/4 v6, 0x7

    .line 554
    invoke-direct {v2, v0, v6}, LC9/q;-><init>(Ljava/lang/String;I)V

    .line 555
    .line 556
    .line 557
    iput-object v4, v5, LO6/c;->f:Ljava/lang/String;

    .line 558
    .line 559
    iput-object v2, v5, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 560
    .line 561
    invoke-virtual {v5}, LO6/c;->a()LO6/d;

    .line 562
    .line 563
    .line 564
    move-result-object v0

    .line 565
    invoke-virtual {v0}, LO6/d;->show()V

    .line 566
    .line 567
    .line 568
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 569
    .line 570
    .line 571
    move-result-object v0

    .line 572
    invoke-virtual {v0, v7, v3}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;Z)V

    .line 573
    .line 574
    .line 575
    goto :goto_14

    .line 576
    :cond_17
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlData;

    .line 577
    .line 578
    .line 579
    move-result-object v0

    .line 580
    if-eqz v0, :cond_1a

    .line 581
    .line 582
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/CLH5BorrowUrlData;->getH5BorrowUrl()Ljava/lang/String;

    .line 583
    .line 584
    .line 585
    move-result-object v0

    .line 586
    if-eqz v0, :cond_1a

    .line 587
    .line 588
    invoke-static {v0, v6}, Lcom/transsnet/palmpay/util/IntentUtils;->getOpenUrlIntent(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 589
    .line 590
    .line 591
    move-result-object v0

    .line 592
    if-eqz v0, :cond_1a

    .line 593
    .line 594
    invoke-static {v0}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 595
    .line 596
    .line 597
    goto :goto_14

    .line 598
    :cond_18
    if-eqz v0, :cond_19

    .line 599
    .line 600
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 601
    .line 602
    .line 603
    move-result-object v4

    .line 604
    :cond_19
    new-array v0, v3, [Ljava/lang/Object;

    .line 605
    .line 606
    invoke-static {v4, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 607
    .line 608
    .line 609
    :cond_1a
    :goto_14
    return-void

    .line 610
    nop

    .line 611
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
