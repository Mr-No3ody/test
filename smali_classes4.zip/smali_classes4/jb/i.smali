.class public final synthetic Ljb/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljb/o;


# direct methods
.method public synthetic constructor <init>(Ljb/o;I)V
    .locals 0

    .line 1
    iput p2, p0, Ljb/i;->a:I

    iput-object p1, p0, Ljb/i;->b:Ljb/o;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, Ljb/i;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Ljb/i;->b:Ljb/o;

    .line 7
    .line 8
    iget-object v1, v0, Ljb/o;->d:Ljava/util/List;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljb/o;->m(Ljava/util/List;)V

    .line 11
    .line 12
    .line 13
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 14
    .line 15
    return-object v0

    .line 16
    :pswitch_0
    iget-object v0, p0, Ljb/i;->b:Ljb/o;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljb/o;->x()V

    .line 19
    .line 20
    .line 21
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_1
    iget-object v0, p0, Ljb/i;->b:Ljb/o;

    .line 25
    .line 26
    iget-object v1, v0, Ljb/o;->f:Ljava/lang/Integer;

    .line 27
    .line 28
    if-eqz v1, :cond_0

    .line 29
    .line 30
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    const/4 v1, 0x0

    .line 36
    :goto_0
    invoke-static {}, Ljb/o;->h()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-ge v1, v2, :cond_2

    .line 41
    .line 42
    iget-object v0, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 43
    .line 44
    const/4 v1, 0x0

    .line 45
    if-eqz v0, :cond_1

    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 52
    .line 53
    if-eqz v0, :cond_3

    .line 54
    .line 55
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    if-eqz v0, :cond_3

    .line 60
    .line 61
    new-instance v2, LO6/c;

    .line 62
    .line 63
    invoke-direct {v2, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 64
    .line 65
    .line 66
    sget v0, LL6/i;->ppFlexiCashDialogTheme:I

    .line 67
    .line 68
    iput v0, v2, LO6/c;->v:I

    .line 69
    .line 70
    sget v0, LYa/d;->cs_failed_sorry_icon:I

    .line 71
    .line 72
    iput v0, v2, LO6/c;->m:I

    .line 73
    .line 74
    const-string v0, "Sorry"

    .line 75
    .line 76
    invoke-static {v0}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    iput-object v0, v2, LO6/c;->b:Ljava/lang/CharSequence;

    .line 81
    .line 82
    sget v0, LYa/g;->cs_cl_credit_bind_failed_tips:I

    .line 83
    .line 84
    invoke-virtual {v2, v0}, LO6/c;->b(I)V

    .line 85
    .line 86
    .line 87
    sget v0, LYa/g;->cs_confirm:I

    .line 88
    .line 89
    invoke-virtual {v2, v0, v1}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v2}, LO6/c;->g()LO6/d;

    .line 93
    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_1
    const-string v0, "mLoanCreditFragmentRef"

    .line 97
    .line 98
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    throw v1

    .line 102
    :cond_2
    invoke-static {}, Ljb/o;->h()I

    .line 103
    .line 104
    .line 105
    move-result v1

    .line 106
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->get()Lcom/transsnet/palmpay/util/SPUtils;

    .line 107
    .line 108
    .line 109
    move-result-object v2

    .line 110
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 111
    .line 112
    .line 113
    move-result-wide v3

    .line 114
    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    add-int/lit8 v1, v1, 0x1

    .line 119
    .line 120
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    filled-new-array {v3, v1}, [Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-static {v1}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    check-cast v1, Ljava/lang/Iterable;

    .line 133
    .line 134
    const-string v3, "_"

    .line 135
    .line 136
    invoke-static {v3, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    const-string v3, "credit_bind_times"

    .line 141
    .line 142
    invoke-virtual {v2, v3, v1}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    iget-object v1, v0, Ljb/o;->d:Ljava/util/List;

    .line 146
    .line 147
    invoke-virtual {v0, v1}, Ljb/o;->m(Ljava/util/List;)V

    .line 148
    .line 149
    .line 150
    :cond_3
    :goto_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 151
    .line 152
    return-object v0

    .line 153
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
