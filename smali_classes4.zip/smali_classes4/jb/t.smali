.class public final Ljb/t;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final n:Ljb/p;

.field public static final o:Ljb/t;


# instance fields
.field public final a:Lxf/t;

.field public b:Ljava/util/List;

.field public c:Ljava/lang/String;

.field public final d:Ljava/lang/Integer;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/Boolean;

.field public final i:I

.field public j:Z

.field public k:Ljava/lang/String;

.field public l:Ljava/lang/Integer;

.field public m:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ljb/p;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Ljb/p;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Ljb/t;->n:Ljb/p;

    .line 8
    .line 9
    sget-object v0, Ljb/q;->a:Ljb/t;

    .line 10
    .line 11
    sget-object v0, Ljb/q;->a:Ljb/t;

    .line 12
    .line 13
    sput-object v0, Ljb/t;->o:Ljb/t;

    .line 14
    .line 15
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0, p0}, Lorg/greenrobot/eventbus/c;->j(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, Lcom/transsnet/palmpay/managemoney/ui/view/c;

    .line 12
    .line 13
    const/16 v1, 0x1b

    .line 14
    .line 15
    invoke-direct {v0, v1}, Lcom/transsnet/palmpay/managemoney/ui/view/c;-><init>(I)V

    .line 16
    .line 17
    .line 18
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iput-object v0, p0, Ljb/t;->a:Lxf/t;

    .line 23
    .line 24
    const/4 v0, -0x1

    .line 25
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    iput-object v1, p0, Ljb/t;->d:Ljava/lang/Integer;

    .line 30
    .line 31
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 32
    .line 33
    iput-object v1, p0, Ljb/t;->h:Ljava/lang/Boolean;

    .line 34
    .line 35
    iput v0, p0, Ljb/t;->i:I

    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Integer;Ljava/lang/String;)V
    .locals 4

    .line 1
    const-string v0, "getVerifyInfo >>> routerPath = "

    .line 2
    .line 3
    invoke-static {v0, p2}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const/4 v1, 0x3

    .line 12
    const-string v2, "CreditRouterManagerV2"

    .line 13
    .line 14
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lob/c;->a:Lob/a;

    .line 18
    .line 19
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-interface {v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->queryAllVerifyInfo()Ldf/d;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    new-instance v2, Lio/reactivex/internal/operators/observable/K;

    .line 44
    .line 45
    const/4 v3, 0x1

    .line 46
    invoke-direct {v2, v0, v1, v3}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 47
    .line 48
    .line 49
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-virtual {v2, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    new-instance v1, Ljb/s;

    .line 58
    .line 59
    invoke-direct {v1, p0, p2, p1}, Ljb/s;-><init>(Ljb/t;Ljava/lang/String;Ljava/lang/Integer;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public final b(I)V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move/from16 v0, p1

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    const-string v4, "interceptRouter >>> routeId="

    .line 8
    .line 9
    invoke-static {v0, v4}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v4

    .line 17
    const/4 v5, 0x3

    .line 18
    const-string v6, "CreditRouterManagerV2"

    .line 19
    .line 20
    invoke-static {v6, v5, v4}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object v4, v1, Ljb/t;->b:Ljava/util/List;

    .line 24
    .line 25
    const/4 v7, 0x0

    .line 26
    if-eqz v4, :cond_3

    .line 27
    .line 28
    check-cast v4, Ljava/lang/Iterable;

    .line 29
    .line 30
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    .line 36
    .line 37
    move-result v8

    .line 38
    if-eqz v8, :cond_2

    .line 39
    .line 40
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v8

    .line 44
    move-object v9, v8

    .line 45
    check-cast v9, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 46
    .line 47
    if-eqz v9, :cond_0

    .line 48
    .line 49
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 50
    .line 51
    .line 52
    move-result-object v9

    .line 53
    if-nez v9, :cond_1

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_1
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 57
    .line 58
    .line 59
    move-result v9

    .line 60
    if-ne v9, v0, :cond_0

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_2
    move-object v8, v7

    .line 64
    :goto_1
    check-cast v8, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_3
    move-object v8, v7

    .line 68
    :goto_2
    if-nez v8, :cond_4

    .line 69
    .line 70
    const-string v3, "Service error: route "

    .line 71
    .line 72
    const-string v4, " is null"

    .line 73
    .line 74
    invoke-static {v0, v3, v4}, Landroidx/camera/camera2/internal/F;->c(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    new-array v2, v2, [Ljava/lang/Object;

    .line 79
    .line 80
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_4
    const-string v0, "interceptRouter >>>"

    .line 85
    .line 86
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-static {v6, v5, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    if-nez v0, :cond_5

    .line 98
    .line 99
    const-string v0, "Sorry, the service is unavailable now (code-2)"

    .line 100
    .line 101
    new-array v2, v2, [Ljava/lang/Object;

    .line 102
    .line 103
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    return-void

    .line 107
    :cond_5
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    const-string v4, "parse(...)"

    .line 116
    .line 117
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v4

    .line 124
    const-string v9, "router path = "

    .line 125
    .line 126
    invoke-static {v9, v4}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v4

    .line 130
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v4

    .line 134
    invoke-static {v6, v5, v4}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 138
    .line 139
    .line 140
    move-result-object v4

    .line 141
    if-eqz v4, :cond_6

    .line 142
    .line 143
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 144
    .line 145
    .line 146
    move-result v4

    .line 147
    goto :goto_3

    .line 148
    :cond_6
    const/4 v4, -0x1

    .line 149
    :goto_3
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v10

    .line 153
    if-nez v10, :cond_7

    .line 154
    .line 155
    const-string v10, ""

    .line 156
    .line 157
    :cond_7
    new-instance v11, Landroid/os/Bundle;

    .line 158
    .line 159
    invoke-direct {v11}, Landroid/os/Bundle;-><init>()V

    .line 160
    .line 161
    .line 162
    const-string v12, "applyId"

    .line 163
    .line 164
    iget-object v13, v1, Ljb/t;->c:Ljava/lang/String;

    .line 165
    .line 166
    invoke-virtual {v11, v12, v13}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    const-string v12, "loanProduct"

    .line 170
    .line 171
    iget-object v13, v1, Ljb/t;->f:Ljava/lang/String;

    .line 172
    .line 173
    invoke-virtual {v11, v12, v13}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    iget-object v12, v1, Ljb/t;->f:Ljava/lang/String;

    .line 177
    .line 178
    const-string v13, "LOAN_WITHDRAW"

    .line 179
    .line 180
    invoke-static {v12, v13}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 181
    .line 182
    .line 183
    move-result v12

    .line 184
    if-eqz v12, :cond_8

    .line 185
    .line 186
    const-string v12, "LOAN_BORROW"

    .line 187
    .line 188
    goto :goto_4

    .line 189
    :cond_8
    const-string v12, "LOAN_CREDIT"

    .line 190
    .line 191
    :goto_4
    const-string v13, "scene"

    .line 192
    .line 193
    invoke-virtual {v11, v13, v12}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    const-string v12, "routePath"

    .line 197
    .line 198
    invoke-virtual {v11, v12, v10}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    const-string v10, "externalParams"

    .line 202
    .line 203
    iget-object v12, v1, Ljb/t;->k:Ljava/lang/String;

    .line 204
    .line 205
    invoke-virtual {v11, v10, v12}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 206
    .line 207
    .line 208
    const-string v10, "routeId"

    .line 209
    .line 210
    invoke-virtual {v11, v10, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 211
    .line 212
    .line 213
    sget-object v10, Llb/f;->e:Llb/e;

    .line 214
    .line 215
    invoke-virtual {v10}, Llb/e;->getInstance()Llb/f;

    .line 216
    .line 217
    .line 218
    move-result-object v10

    .line 219
    iget-object v10, v10, Llb/f;->d:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 220
    .line 221
    if-eqz v10, :cond_d

    .line 222
    .line 223
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 224
    .line 225
    .line 226
    move-result-object v12

    .line 227
    new-instance v13, Ljava/lang/StringBuilder;

    .line 228
    .line 229
    const-string v14, "getCurRouteIndex >>> routeId="

    .line 230
    .line 231
    invoke-direct {v13, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 235
    .line 236
    .line 237
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object v13

    .line 241
    filled-new-array {v13}, [Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v13

    .line 245
    invoke-static {v6, v5, v13}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    iget-object v13, v1, Ljb/t;->b:Ljava/util/List;

    .line 249
    .line 250
    if-eqz v13, :cond_c

    .line 251
    .line 252
    check-cast v13, Ljava/lang/Iterable;

    .line 253
    .line 254
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 255
    .line 256
    .line 257
    move-result-object v13

    .line 258
    move v14, v2

    .line 259
    :goto_5
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 260
    .line 261
    .line 262
    move-result v15

    .line 263
    if-eqz v15, :cond_c

    .line 264
    .line 265
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object v15

    .line 269
    add-int/lit8 v16, v14, 0x1

    .line 270
    .line 271
    if-ltz v14, :cond_b

    .line 272
    .line 273
    check-cast v15, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 274
    .line 275
    if-eqz v15, :cond_9

    .line 276
    .line 277
    invoke-virtual {v15}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 278
    .line 279
    .line 280
    move-result-object v15

    .line 281
    goto :goto_6

    .line 282
    :cond_9
    move-object v15, v7

    .line 283
    :goto_6
    invoke-virtual {v12, v15}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 284
    .line 285
    .line 286
    move-result v15

    .line 287
    if-eqz v15, :cond_a

    .line 288
    .line 289
    goto :goto_7

    .line 290
    :cond_a
    move/from16 v14, v16

    .line 291
    .line 292
    goto :goto_5

    .line 293
    :cond_b
    invoke-static {}, Lkotlin/collections/q;->k()V

    .line 294
    .line 295
    .line 296
    throw v7

    .line 297
    :cond_c
    const/4 v14, -0x1

    .line 298
    :goto_7
    add-int/2addr v14, v3

    .line 299
    iput v14, v10, Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;->currentIndex:I

    .line 300
    .line 301
    :cond_d
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 302
    .line 303
    .line 304
    move-result-object v10

    .line 305
    invoke-virtual {v1, v10, v7}, Ljb/t;->c(Ljava/lang/Integer;Ljava/lang/String;)Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 306
    .line 307
    .line 308
    move-result-object v10

    .line 309
    const-string v12, "/account/upgrade"

    .line 310
    .line 311
    if-eqz v10, :cond_17

    .line 312
    .line 313
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getName()Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object v13

    .line 317
    invoke-virtual {v10}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getType()Ljava/lang/Integer;

    .line 318
    .line 319
    .line 320
    move-result-object v10

    .line 321
    new-instance v14, Ljava/lang/StringBuilder;

    .line 322
    .line 323
    const-string v15, "isDynamicRnRoute, intercept >>> routeType="

    .line 324
    .line 325
    invoke-direct {v14, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 326
    .line 327
    .line 328
    invoke-virtual {v14, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 329
    .line 330
    .line 331
    const-string v15, ", routePath="

    .line 332
    .line 333
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 334
    .line 335
    .line 336
    invoke-virtual {v14, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 337
    .line 338
    .line 339
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v14

    .line 343
    filled-new-array {v14}, [Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v14

    .line 347
    invoke-static {v6, v5, v14}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    const/4 v14, 0x5

    .line 351
    if-eqz v13, :cond_f

    .line 352
    .line 353
    sget-object v16, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->RN:Lcom/transsnet/palmpay/credit/bean/RoutePageType;

    .line 354
    .line 355
    invoke-virtual/range {v16 .. v16}, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->getCode()I

    .line 356
    .line 357
    .line 358
    move-result v3

    .line 359
    if-nez v10, :cond_e

    .line 360
    .line 361
    goto :goto_8

    .line 362
    :cond_e
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 363
    .line 364
    .line 365
    move-result v9

    .line 366
    if-ne v9, v3, :cond_f

    .line 367
    .line 368
    const-string v0, "isDynamicRnRoute, jump rn page >>> "

    .line 369
    .line 370
    invoke-virtual {v0, v13}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 371
    .line 372
    .line 373
    move-result-object v0

    .line 374
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 375
    .line 376
    .line 377
    move-result-object v0

    .line 378
    invoke-static {v6, v14, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 379
    .line 380
    .line 381
    invoke-static {v11, v13}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 382
    .line 383
    .line 384
    return-void

    .line 385
    :cond_f
    :goto_8
    if-eqz v13, :cond_16

    .line 386
    .line 387
    sget-object v3, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->H5:Lcom/transsnet/palmpay/credit/bean/RoutePageType;

    .line 388
    .line 389
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->getCode()I

    .line 390
    .line 391
    .line 392
    move-result v3

    .line 393
    if-nez v10, :cond_10

    .line 394
    .line 395
    goto/16 :goto_f

    .line 396
    .line 397
    :cond_10
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 398
    .line 399
    .line 400
    move-result v9

    .line 401
    if-ne v9, v3, :cond_16

    .line 402
    .line 403
    const-string v0, "isDynamicRnRoute, jump h5 page >>> "

    .line 404
    .line 405
    invoke-virtual {v0, v13}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 406
    .line 407
    .line 408
    move-result-object v0

    .line 409
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    invoke-static {v6, v14, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 414
    .line 415
    .line 416
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 417
    .line 418
    .line 419
    move-result-object v3

    .line 420
    new-instance v0, Ljava/lang/StringBuilder;

    .line 421
    .line 422
    const-string v4, "toNewBvnPage >>> curRouteId="

    .line 423
    .line 424
    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 425
    .line 426
    .line 427
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 428
    .line 429
    .line 430
    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 431
    .line 432
    .line 433
    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 434
    .line 435
    .line 436
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 437
    .line 438
    .line 439
    move-result-object v0

    .line 440
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 441
    .line 442
    .line 443
    move-result-object v0

    .line 444
    invoke-static {v6, v5, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 445
    .line 446
    .line 447
    :try_start_0
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 448
    .line 449
    new-instance v0, Lcom/google/gson/Gson;

    .line 450
    .line 451
    invoke-direct {v0}, Lcom/google/gson/Gson;-><init>()V

    .line 452
    .line 453
    .line 454
    const-class v4, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;

    .line 455
    .line 456
    invoke-virtual {v0, v7, v4}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 460
    :try_start_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 461
    .line 462
    goto :goto_a

    .line 463
    :catchall_0
    move-exception v0

    .line 464
    goto :goto_9

    .line 465
    :catchall_1
    move-exception v0

    .line 466
    move-object v4, v7

    .line 467
    :goto_9
    sget-object v8, Lxf/q;->a:Lxf/o;

    .line 468
    .line 469
    invoke-static {v0}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 470
    .line 471
    .line 472
    :goto_a
    if-nez v4, :cond_11

    .line 473
    .line 474
    const-string v0, "toNewBvnPage >>> routerNode is null"

    .line 475
    .line 476
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v0

    .line 480
    invoke-static {v6, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 481
    .line 482
    .line 483
    new-array v0, v2, [Ljava/lang/Object;

    .line 484
    .line 485
    const-string v2, "Sorry, the service is unavailable now (code-3)"

    .line 486
    .line 487
    invoke-static {v2, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 488
    .line 489
    .line 490
    goto/16 :goto_e

    .line 491
    .line 492
    :cond_11
    const/4 v0, 0x6

    .line 493
    const-string v8, "?"

    .line 494
    .line 495
    invoke-static {v13, v8, v2, v2, v0}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 496
    .line 497
    .line 498
    move-result v0

    .line 499
    new-instance v2, Ljava/lang/StringBuilder;

    .line 500
    .line 501
    invoke-direct {v2, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 502
    .line 503
    .line 504
    const/4 v9, -0x1

    .line 505
    if-eq v0, v9, :cond_12

    .line 506
    .line 507
    invoke-virtual {v13, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 508
    .line 509
    .line 510
    move-result-object v0

    .line 511
    const-string v8, "substring(...)"

    .line 512
    .line 513
    invoke-static {v0, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 514
    .line 515
    .line 516
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 517
    .line 518
    .line 519
    const-string v0, "&"

    .line 520
    .line 521
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 522
    .line 523
    .line 524
    goto :goto_b

    .line 525
    :cond_12
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 526
    .line 527
    .line 528
    :goto_b
    check-cast v4, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;

    .line 529
    .line 530
    iget-object v0, v4, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;->current:Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 531
    .line 532
    if-eqz v0, :cond_13

    .line 533
    .line 534
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 535
    .line 536
    .line 537
    move-result-object v0

    .line 538
    goto :goto_c

    .line 539
    :cond_13
    move-object v0, v7

    .line 540
    :goto_c
    new-instance v8, Ljava/lang/StringBuilder;

    .line 541
    .line 542
    const-string v9, "current="

    .line 543
    .line 544
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 545
    .line 546
    .line 547
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 548
    .line 549
    .line 550
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 551
    .line 552
    .line 553
    move-result-object v0

    .line 554
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 555
    .line 556
    .line 557
    iget-object v0, v4, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;->prev:Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 558
    .line 559
    if-eqz v0, :cond_14

    .line 560
    .line 561
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 562
    .line 563
    .line 564
    move-result-object v0

    .line 565
    goto :goto_d

    .line 566
    :cond_14
    move-object v0, v7

    .line 567
    :goto_d
    new-instance v8, Ljava/lang/StringBuilder;

    .line 568
    .line 569
    const-string v9, "&prev="

    .line 570
    .line 571
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 572
    .line 573
    .line 574
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 575
    .line 576
    .line 577
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 578
    .line 579
    .line 580
    move-result-object v0

    .line 581
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 582
    .line 583
    .line 584
    iget-object v0, v4, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;->next:Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 585
    .line 586
    if-eqz v0, :cond_15

    .line 587
    .line 588
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 589
    .line 590
    .line 591
    move-result-object v7

    .line 592
    :cond_15
    new-instance v0, Ljava/lang/StringBuilder;

    .line 593
    .line 594
    const-string v4, "&next="

    .line 595
    .line 596
    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 597
    .line 598
    .line 599
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 600
    .line 601
    .line 602
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 603
    .line 604
    .line 605
    move-result-object v0

    .line 606
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 607
    .line 608
    .line 609
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 610
    .line 611
    .line 612
    move-result-object v0

    .line 613
    const-string v2, "toString(...)"

    .line 614
    .line 615
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 616
    .line 617
    .line 618
    const-string v2, "toNewBvnPage >>> targetBvnUrl="

    .line 619
    .line 620
    invoke-static {v2, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 621
    .line 622
    .line 623
    move-result-object v2

    .line 624
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 625
    .line 626
    .line 627
    move-result-object v2

    .line 628
    invoke-static {v6, v5, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 629
    .line 630
    .line 631
    invoke-virtual {v1, v3, v12, v0}, Ljb/t;->f(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 632
    .line 633
    .line 634
    :goto_e
    return-void

    .line 635
    :cond_16
    :goto_f
    const-string v3, "isDynamicRnRoute, intercept >>> continue"

    .line 636
    .line 637
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 638
    .line 639
    .line 640
    move-result-object v3

    .line 641
    const/4 v9, 0x4

    .line 642
    invoke-static {v6, v9, v3}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 643
    .line 644
    .line 645
    :cond_17
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 646
    .line 647
    .line 648
    move-result-object v3

    .line 649
    if-eqz v3, :cond_25

    .line 650
    .line 651
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 652
    .line 653
    .line 654
    move-result v9

    .line 655
    sparse-switch v9, :sswitch_data_0

    .line 656
    .line 657
    .line 658
    goto/16 :goto_10

    .line 659
    .line 660
    :sswitch_0
    const-string v0, "/coreImpl/add_new_card"

    .line 661
    .line 662
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 663
    .line 664
    .line 665
    move-result v0

    .line 666
    if-nez v0, :cond_24

    .line 667
    .line 668
    goto/16 :goto_10

    .line 669
    .line 670
    :sswitch_1
    const-string v0, "oc_business_info_rn_router"

    .line 671
    .line 672
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 673
    .line 674
    .line 675
    move-result v0

    .line 676
    if-nez v0, :cond_18

    .line 677
    .line 678
    goto/16 :goto_10

    .line 679
    .line 680
    :cond_18
    const-string v0, "LoanBusinessInfo"

    .line 681
    .line 682
    invoke-static {v11, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 683
    .line 684
    .line 685
    return-void

    .line 686
    :sswitch_2
    const-string v0, "/coreImpl/bind_new_bank_account"

    .line 687
    .line 688
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 689
    .line 690
    .line 691
    move-result v0

    .line 692
    if-nez v0, :cond_24

    .line 693
    .line 694
    goto/16 :goto_10

    .line 695
    .line 696
    :sswitch_3
    const-string v0, "oc_one_loop_router"

    .line 697
    .line 698
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 699
    .line 700
    .line 701
    move-result v0

    .line 702
    if-nez v0, :cond_19

    .line 703
    .line 704
    goto/16 :goto_10

    .line 705
    .line 706
    :cond_19
    iget-object v0, v1, Ljb/t;->c:Ljava/lang/String;

    .line 707
    .line 708
    const-string v3, "getOneLoopData >>>"

    .line 709
    .line 710
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 711
    .line 712
    .line 713
    move-result-object v3

    .line 714
    invoke-static {v6, v5, v3}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 715
    .line 716
    .line 717
    sget-object v3, Lob/c;->a:Lob/a;

    .line 718
    .line 719
    invoke-virtual {v3}, Lob/a;->getInstance()Lob/c;

    .line 720
    .line 721
    .line 722
    move-result-object v3

    .line 723
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 724
    .line 725
    .line 726
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 727
    .line 728
    .line 729
    move-result-object v3

    .line 730
    invoke-interface {v3, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->getOneLoopData(Ljava/lang/String;)Ldf/d;

    .line 731
    .line 732
    .line 733
    move-result-object v0

    .line 734
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 735
    .line 736
    .line 737
    sget-object v3, Ltf/f;->b:Ldf/i;

    .line 738
    .line 739
    invoke-virtual {v0, v3}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 740
    .line 741
    .line 742
    move-result-object v0

    .line 743
    new-instance v4, Lio/reactivex/internal/operators/observable/K;

    .line 744
    .line 745
    const/4 v5, 0x1

    .line 746
    invoke-direct {v4, v0, v3, v5}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 747
    .line 748
    .line 749
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 750
    .line 751
    .line 752
    move-result-object v0

    .line 753
    invoke-virtual {v4, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 754
    .line 755
    .line 756
    move-result-object v0

    .line 757
    new-instance v3, Ljb/r;

    .line 758
    .line 759
    invoke-direct {v3, v1, v2}, Ljb/r;-><init>(Ljb/t;I)V

    .line 760
    .line 761
    .line 762
    invoke-virtual {v0, v3}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 763
    .line 764
    .line 765
    return-void

    .line 766
    :sswitch_4
    const-string v0, "oc_bank_auth_router"

    .line 767
    .line 768
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 769
    .line 770
    .line 771
    move-result v0

    .line 772
    if-nez v0, :cond_1a

    .line 773
    .line 774
    goto/16 :goto_10

    .line 775
    .line 776
    :cond_1a
    const-string v0, "BankAuth"

    .line 777
    .line 778
    invoke-static {v11, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 779
    .line 780
    .line 781
    return-void

    .line 782
    :sswitch_5
    const-string v0, "oc_business_expectation_rn_router"

    .line 783
    .line 784
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 785
    .line 786
    .line 787
    move-result v0

    .line 788
    if-nez v0, :cond_1b

    .line 789
    .line 790
    goto/16 :goto_10

    .line 791
    .line 792
    :cond_1b
    const-string v0, "LoanBusinessExpectation"

    .line 793
    .line 794
    invoke-static {v11, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 795
    .line 796
    .line 797
    return-void

    .line 798
    :sswitch_6
    const-string v0, "oc_add_contact_rn_router"

    .line 799
    .line 800
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 801
    .line 802
    .line 803
    move-result v0

    .line 804
    if-nez v0, :cond_1c

    .line 805
    .line 806
    goto/16 :goto_10

    .line 807
    .line 808
    :cond_1c
    const-string v0, "LoanContact"

    .line 809
    .line 810
    invoke-static {v11, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 811
    .line 812
    .line 813
    return-void

    .line 814
    :sswitch_7
    const-string v2, "oc_person_info_router"

    .line 815
    .line 816
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 817
    .line 818
    .line 819
    move-result v2

    .line 820
    if-nez v2, :cond_1d

    .line 821
    .line 822
    goto/16 :goto_10

    .line 823
    .line 824
    :cond_1d
    const-string v2, "type"

    .line 825
    .line 826
    invoke-virtual {v0, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 827
    .line 828
    .line 829
    move-result-object v0

    .line 830
    invoke-virtual {v11, v2, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 831
    .line 832
    .line 833
    const-string v0, "PersonalInfoV2"

    .line 834
    .line 835
    invoke-static {v11, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 836
    .line 837
    .line 838
    return-void

    .line 839
    :sswitch_8
    const-string v0, "/settings/upgrape-kyc/verify"

    .line 840
    .line 841
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 842
    .line 843
    .line 844
    move-result v0

    .line 845
    if-nez v0, :cond_1e

    .line 846
    .line 847
    goto/16 :goto_10

    .line 848
    .line 849
    :cond_1e
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 850
    .line 851
    .line 852
    move-result-object v0

    .line 853
    const-string v2, "/credit_score/oc_kyc_router_activity"

    .line 854
    .line 855
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 856
    .line 857
    .line 858
    move-result-object v3

    .line 859
    invoke-virtual {v1, v0, v2, v3}, Ljb/t;->f(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 860
    .line 861
    .line 862
    return-void

    .line 863
    :sswitch_9
    const-string v0, "/credit_score/all_operate_one_loop_activity"

    .line 864
    .line 865
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 866
    .line 867
    .line 868
    move-result v0

    .line 869
    if-nez v0, :cond_1f

    .line 870
    .line 871
    goto/16 :goto_10

    .line 872
    .line 873
    :cond_1f
    const-string v0, "querySkipOneLoop >>>"

    .line 874
    .line 875
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 876
    .line 877
    .line 878
    move-result-object v0

    .line 879
    invoke-static {v6, v5, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 880
    .line 881
    .line 882
    sget-object v0, Lob/c;->a:Lob/a;

    .line 883
    .line 884
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 885
    .line 886
    .line 887
    move-result-object v0

    .line 888
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 889
    .line 890
    .line 891
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 892
    .line 893
    .line 894
    move-result-object v0

    .line 895
    invoke-interface {v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->querySkipOneLoop()Ldf/d;

    .line 896
    .line 897
    .line 898
    move-result-object v0

    .line 899
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 900
    .line 901
    .line 902
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 903
    .line 904
    invoke-virtual {v0, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 905
    .line 906
    .line 907
    move-result-object v0

    .line 908
    new-instance v3, Lio/reactivex/internal/operators/observable/K;

    .line 909
    .line 910
    const/4 v5, 0x1

    .line 911
    invoke-direct {v3, v0, v2, v5}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 912
    .line 913
    .line 914
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 915
    .line 916
    .line 917
    move-result-object v0

    .line 918
    invoke-virtual {v3, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 919
    .line 920
    .line 921
    move-result-object v0

    .line 922
    new-instance v2, Ljb/r;

    .line 923
    .line 924
    invoke-direct {v2, v1, v5}, Ljb/r;-><init>(Ljb/t;I)V

    .line 925
    .line 926
    .line 927
    invoke-virtual {v0, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 928
    .line 929
    .line 930
    return-void

    .line 931
    :sswitch_a
    const-string v0, "/coreImpl/use_new_card"

    .line 932
    .line 933
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 934
    .line 935
    .line 936
    move-result v0

    .line 937
    if-nez v0, :cond_24

    .line 938
    .line 939
    goto :goto_10

    .line 940
    :sswitch_b
    const-string v0, "oc_opay_reverse_router"

    .line 941
    .line 942
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 943
    .line 944
    .line 945
    move-result v0

    .line 946
    if-nez v0, :cond_20

    .line 947
    .line 948
    goto :goto_10

    .line 949
    :cond_20
    const-string v0, "LoanOpayReverse"

    .line 950
    .line 951
    invoke-static {v11, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 952
    .line 953
    .line 954
    return-void

    .line 955
    :sswitch_c
    invoke-virtual {v3, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 956
    .line 957
    .line 958
    move-result v0

    .line 959
    if-nez v0, :cond_21

    .line 960
    .line 961
    goto :goto_10

    .line 962
    :cond_21
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 963
    .line 964
    .line 965
    move-result-object v0

    .line 966
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 967
    .line 968
    .line 969
    move-result-object v2

    .line 970
    invoke-virtual {v1, v0, v2}, Ljb/t;->a(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 971
    .line 972
    .line 973
    return-void

    .line 974
    :sswitch_d
    const-string v0, "oc_bank_verify_router"

    .line 975
    .line 976
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 977
    .line 978
    .line 979
    move-result v0

    .line 980
    if-nez v0, :cond_22

    .line 981
    .line 982
    goto :goto_10

    .line 983
    :cond_22
    const-string v0, "BankVerify"

    .line 984
    .line 985
    invoke-static {v11, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 986
    .line 987
    .line 988
    return-void

    .line 989
    :sswitch_e
    const-string v0, "oc_loan_expectation_router"

    .line 990
    .line 991
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 992
    .line 993
    .line 994
    move-result v0

    .line 995
    if-nez v0, :cond_23

    .line 996
    .line 997
    goto :goto_10

    .line 998
    :cond_23
    const-string v0, "LoanExpectation"

    .line 999
    .line 1000
    invoke-static {v11, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 1001
    .line 1002
    .line 1003
    return-void

    .line 1004
    :sswitch_f
    const-string v0, "/credit_score/oc_all_verify_activity"

    .line 1005
    .line 1006
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1007
    .line 1008
    .line 1009
    move-result v0

    .line 1010
    if-nez v0, :cond_24

    .line 1011
    .line 1012
    goto :goto_10

    .line 1013
    :cond_24
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 1014
    .line 1015
    .line 1016
    move-result-object v0

    .line 1017
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 1018
    .line 1019
    .line 1020
    move-result-object v2

    .line 1021
    invoke-virtual {v1, v0, v2}, Ljb/t;->a(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 1022
    .line 1023
    .line 1024
    return-void

    .line 1025
    :cond_25
    :goto_10
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1026
    .line 1027
    .line 1028
    move-result-object v0

    .line 1029
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 1030
    .line 1031
    .line 1032
    move-result-object v2

    .line 1033
    invoke-virtual {v1, v0, v2, v7}, Ljb/t;->f(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 1034
    .line 1035
    .line 1036
    return-void

    .line 1037
    :sswitch_data_0
    .sparse-switch
        -0x79eccc60 -> :sswitch_f
        -0x7763f310 -> :sswitch_e
        -0x7686dea9 -> :sswitch_d
        -0x66f75fd5 -> :sswitch_c
        -0x62393c7f -> :sswitch_b
        -0x4d2c5518 -> :sswitch_a
        -0x478a467c -> :sswitch_9
        -0x30fe26b3 -> :sswitch_8
        -0x288e8da5 -> :sswitch_7
        -0x142eeafc -> :sswitch_6
        -0x810ff0b -> :sswitch_5
        -0x3b454b8 -> :sswitch_4
        -0x3105380 -> :sswitch_3
        0x4c40436a -> :sswitch_2
        0x4db2354f -> :sswitch_1
        0x6b42d50e -> :sswitch_0
    .end sparse-switch
.end method

.method public final c(Ljava/lang/Integer;Ljava/lang/String;)Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;
    .locals 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "isDynamicRnRoute >>> routeId="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, ", routePath="

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const/4 v1, 0x3

    .line 28
    const-string v2, "CreditRouterManagerV2"

    .line 29
    .line 30
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Ljb/t;->m:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    const/4 v1, 0x0

    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    goto/16 :goto_5

    .line 43
    .line 44
    :cond_0
    if-nez p1, :cond_1

    .line 45
    .line 46
    if-nez p2, :cond_1

    .line 47
    .line 48
    const-string p1, "isDynamicRnRoute >>> routeId and routePath are null"

    .line 49
    .line 50
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    invoke-static {v2, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    return-object v1

    .line 58
    :cond_1
    :try_start_0
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 59
    .line 60
    new-instance v0, Lcom/transsnet/palmpay/credit/hook/CreditRouterManagerV2$isDynamicRnRoute$1$listType$1;

    .line 61
    .line 62
    invoke-direct {v0}, Lcom/transsnet/palmpay/credit/hook/CreditRouterManagerV2$isDynamicRnRoute$1$listType$1;-><init>()V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0}, Lcom/google/gson/reflect/TypeToken;->getType()Ljava/lang/reflect/Type;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    new-instance v3, Lcom/google/gson/Gson;

    .line 70
    .line 71
    invoke-direct {v3}, Lcom/google/gson/Gson;-><init>()V

    .line 72
    .line 73
    .line 74
    iget-object v4, p0, Ljb/t;->m:Ljava/lang/String;

    .line 75
    .line 76
    invoke-virtual {v3, v4, v0}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    const-string v3, "fromJson(...)"

    .line 81
    .line 82
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    check-cast v0, Ljava/util/List;

    .line 86
    .line 87
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 88
    .line 89
    .line 90
    move-result v3

    .line 91
    if-eqz v3, :cond_2

    .line 92
    .line 93
    goto/16 :goto_5

    .line 94
    .line 95
    :cond_2
    if-eqz p1, :cond_6

    .line 96
    .line 97
    check-cast v0, Ljava/lang/Iterable;

    .line 98
    .line 99
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 100
    .line 101
    .line 102
    move-result-object p2

    .line 103
    :cond_3
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    if-eqz v0, :cond_5

    .line 108
    .line 109
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    move-object v3, v0

    .line 114
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 115
    .line 116
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getParams()Lcom/transsnet/palmpay/credit/bean/RouterPageInfoParams;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    if-eqz v3, :cond_4

    .line 121
    .line 122
    iget-object v3, v3, Lcom/transsnet/palmpay/credit/bean/RouterPageInfoParams;->routeId:Ljava/lang/Integer;

    .line 123
    .line 124
    goto :goto_0

    .line 125
    :catchall_0
    move-exception p1

    .line 126
    goto :goto_3

    .line 127
    :cond_4
    move-object v3, v1

    .line 128
    :goto_0
    invoke-static {v3, p1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    move-result v3

    .line 132
    if-eqz v3, :cond_3

    .line 133
    .line 134
    goto :goto_1

    .line 135
    :cond_5
    move-object v0, v1

    .line 136
    :goto_1
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 137
    .line 138
    return-object v0

    .line 139
    :cond_6
    if-eqz p2, :cond_9

    .line 140
    .line 141
    check-cast v0, Ljava/lang/Iterable;

    .line 142
    .line 143
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 144
    .line 145
    .line 146
    move-result-object p1

    .line 147
    :cond_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    if-eqz v0, :cond_8

    .line 152
    .line 153
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    move-object v3, v0

    .line 158
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 159
    .line 160
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getName()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v3

    .line 164
    if-eqz v3, :cond_7

    .line 165
    .line 166
    const/4 v4, 0x0

    .line 167
    invoke-static {v3, p2, v4}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 168
    .line 169
    .line 170
    move-result v3

    .line 171
    const/4 v4, 0x1

    .line 172
    if-ne v3, v4, :cond_7

    .line 173
    .line 174
    goto :goto_2

    .line 175
    :cond_8
    move-object v0, v1

    .line 176
    :goto_2
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 177
    .line 178
    return-object v0

    .line 179
    :cond_9
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 180
    .line 181
    goto :goto_4

    .line 182
    :goto_3
    sget-object p2, Lxf/q;->a:Lxf/o;

    .line 183
    .line 184
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    :goto_4
    invoke-static {p1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 189
    .line 190
    .line 191
    move-result-object p1

    .line 192
    if-eqz p1, :cond_a

    .line 193
    .line 194
    new-instance p2, Ljava/lang/StringBuilder;

    .line 195
    .line 196
    const-string v0, "isDynamicRnRoute >>> error , "

    .line 197
    .line 198
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object p1

    .line 208
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object p1

    .line 212
    invoke-static {v2, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 213
    .line 214
    .line 215
    :cond_a
    :goto_5
    return-object v1
.end method

.method public final d()V
    .locals 3

    .line 1
    iget-object v0, p0, Ljb/t;->l:Ljava/lang/Integer;

    .line 2
    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    const-string v2, "routerNext >>> curRouteId="

    .line 6
    .line 7
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v1, 0x3

    .line 22
    const-string v2, "CreditRouterManagerV2"

    .line 23
    .line 24
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Ljb/t;->l:Ljava/lang/Integer;

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move-object v0, v1

    .line 38
    :goto_0
    const-string v2, "NoticeCreditRouteNext"

    .line 39
    .line 40
    invoke-static {v2, v0, v1}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public final e()V
    .locals 3

    .line 1
    iget-object v0, p0, Ljb/t;->l:Ljava/lang/Integer;

    .line 2
    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    const-string v2, "v >>> curRouteId="

    .line 6
    .line 7
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v1, 0x3

    .line 22
    const-string v2, "CreditRouterManagerV2"

    .line 23
    .line 24
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Ljb/t;->l:Ljava/lang/Integer;

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    if-eqz v0, :cond_0

    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move-object v0, v1

    .line 38
    :goto_0
    const-string v2, "NoticeCreditRoutePrevious"

    .line 39
    .line 40
    invoke-static {v2, v0, v1}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    return-void
.end method

.method public final f(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V
    .locals 22

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    new-instance v4, Ljava/lang/StringBuilder;

    .line 10
    .line 11
    const-string v5, "routerTarget, routeId="

    .line 12
    .line 13
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    const-string v5, ", routerPath="

    .line 20
    .line 21
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string v5, ", url="

    .line 28
    .line 29
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    const/4 v5, 0x3

    .line 44
    const-string v6, "CreditRouterManagerV2"

    .line 45
    .line 46
    invoke-static {v6, v5, v4}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    if-nez v4, :cond_0

    .line 54
    .line 55
    goto/16 :goto_4

    .line 56
    .line 57
    :cond_0
    new-instance v7, Lcom/google/gson/Gson;

    .line 58
    .line 59
    invoke-direct {v7}, Lcom/google/gson/Gson;-><init>()V

    .line 60
    .line 61
    .line 62
    new-instance v8, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 63
    .line 64
    iget-object v9, v1, Ljb/t;->e:Ljava/lang/String;

    .line 65
    .line 66
    iget-object v11, v1, Ljb/t;->c:Ljava/lang/String;

    .line 67
    .line 68
    iget-object v10, v1, Ljb/t;->g:Ljava/lang/String;

    .line 69
    .line 70
    iget-object v12, v1, Ljb/t;->f:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v13, v1, Ljb/t;->b:Ljava/util/List;

    .line 73
    .line 74
    move-object/from16 v18, v13

    .line 75
    .line 76
    iget-object v13, v1, Ljb/t;->d:Ljava/lang/Integer;

    .line 77
    .line 78
    const/4 v15, 0x0

    .line 79
    const/16 v19, 0x0

    .line 80
    .line 81
    move-object/from16 v16, v10

    .line 82
    .line 83
    const/4 v10, 0x0

    .line 84
    move-object/from16 v17, v12

    .line 85
    .line 86
    const/4 v12, 0x0

    .line 87
    const/4 v14, 0x0

    .line 88
    const/16 v20, 0x46a

    .line 89
    .line 90
    const/16 v21, 0x0

    .line 91
    .line 92
    invoke-direct/range {v8 .. v21}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v7, v8}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v7

    .line 99
    :try_start_0
    sget-object v8, Lxf/q;->a:Lxf/o;

    .line 100
    .line 101
    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 102
    .line 103
    .line 104
    move-result-object v8

    .line 105
    const-string v9, "parse(...)"

    .line 106
    .line 107
    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 111
    .line 112
    .line 113
    move-result-object v9

    .line 114
    invoke-virtual {v8}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v10

    .line 118
    invoke-virtual {v9, v10}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 119
    .line 120
    .line 121
    move-result-object v9

    .line 122
    const-string v10, "build(...)"

    .line 123
    .line 124
    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v8}, Landroid/net/Uri;->getQuery()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v8

    .line 131
    invoke-static {v9, v8}, LPa/F;->h(Lcom/alibaba/android/arouter/facade/Postcard;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 132
    .line 133
    .line 134
    move-result-object v8

    .line 135
    const-string v9, "parseQueryString(...)"

    .line 136
    .line 137
    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 141
    .line 142
    .line 143
    move-result v9

    .line 144
    if-nez v9, :cond_1

    .line 145
    .line 146
    const-string v9, "jump_url"

    .line 147
    .line 148
    invoke-virtual {v8, v9, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 149
    .line 150
    .line 151
    goto :goto_0

    .line 152
    :catchall_0
    move-exception v0

    .line 153
    goto/16 :goto_2

    .line 154
    .line 155
    :cond_1
    :goto_0
    const-string v3, "/coreImpl/add_new_card"

    .line 156
    .line 157
    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 158
    .line 159
    .line 160
    move-result v2

    .line 161
    const/4 v3, 0x1

    .line 162
    if-eqz v2, :cond_2

    .line 163
    .line 164
    const-string v2, "business_type"

    .line 165
    .line 166
    const-wide/16 v9, 0x1

    .line 167
    .line 168
    invoke-virtual {v8, v2, v9, v10}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 169
    .line 170
    .line 171
    const-string v2, "me_bind_bank_card"

    .line 172
    .line 173
    invoke-virtual {v8, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withBoolean(Ljava/lang/String;Z)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 174
    .line 175
    .line 176
    :cond_2
    const-string v2, "applyId"

    .line 177
    .line 178
    iget-object v9, v1, Ljb/t;->c:Ljava/lang/String;

    .line 179
    .line 180
    invoke-virtual {v8, v2, v9}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 181
    .line 182
    .line 183
    move-result-object v2

    .line 184
    const-string v8, "oc_business_type"

    .line 185
    .line 186
    iget-object v9, v1, Ljb/t;->f:Ljava/lang/String;

    .line 187
    .line 188
    invoke-virtual {v2, v8, v9}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 189
    .line 190
    .line 191
    move-result-object v2

    .line 192
    const-string v8, "key_need_sign_type"

    .line 193
    .line 194
    iget v9, v1, Ljb/t;->i:I

    .line 195
    .line 196
    invoke-virtual {v2, v8, v9}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 197
    .line 198
    .line 199
    move-result-object v2

    .line 200
    const-string v8, "oc_scene_type"

    .line 201
    .line 202
    iget-object v9, v1, Ljb/t;->d:Ljava/lang/Integer;

    .line 203
    .line 204
    const/4 v10, -0x1

    .line 205
    if-eqz v9, :cond_3

    .line 206
    .line 207
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 208
    .line 209
    .line 210
    move-result v9

    .line 211
    goto :goto_1

    .line 212
    :cond_3
    move v9, v10

    .line 213
    :goto_1
    invoke-virtual {v2, v8, v9}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 214
    .line 215
    .line 216
    move-result-object v2

    .line 217
    const-string v8, "oc_route_id"

    .line 218
    .line 219
    if-eqz v0, :cond_4

    .line 220
    .line 221
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 222
    .line 223
    .line 224
    move-result v10

    .line 225
    :cond_4
    invoke-virtual {v2, v8, v10}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 226
    .line 227
    .line 228
    move-result-object v0

    .line 229
    const-string v2, "oc_apply_data"

    .line 230
    .line 231
    invoke-virtual {v0, v2, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    const-string v2, "ext_business_data"

    .line 236
    .line 237
    invoke-virtual {v0, v2, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    const-string v2, "businessType"

    .line 242
    .line 243
    iget-object v7, v1, Ljb/t;->f:Ljava/lang/String;

    .line 244
    .line 245
    invoke-virtual {v0, v2, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 246
    .line 247
    .line 248
    move-result-object v0

    .line 249
    const-string v2, "jump_source"

    .line 250
    .line 251
    iget-object v7, v1, Ljb/t;->f:Ljava/lang/String;

    .line 252
    .line 253
    invoke-virtual {v0, v2, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    const-string v2, "extra_type"

    .line 258
    .line 259
    invoke-virtual {v0, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 260
    .line 261
    .line 262
    move-result-object v0

    .line 263
    const/16 v2, 0x3e8

    .line 264
    .line 265
    invoke-virtual {v0, v4, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/app/Activity;I)V

    .line 266
    .line 267
    .line 268
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 269
    .line 270
    goto :goto_3

    .line 271
    :goto_2
    sget-object v2, Lxf/q;->a:Lxf/o;

    .line 272
    .line 273
    invoke-static {v0}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 274
    .line 275
    .line 276
    move-result-object v0

    .line 277
    :goto_3
    instance-of v2, v0, Lxf/p;

    .line 278
    .line 279
    if-nez v2, :cond_5

    .line 280
    .line 281
    move-object v2, v0

    .line 282
    check-cast v2, Lkotlin/Unit;

    .line 283
    .line 284
    const-string v2, "routerTarget >>> success"

    .line 285
    .line 286
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v2

    .line 290
    invoke-static {v6, v5, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 291
    .line 292
    .line 293
    :cond_5
    invoke-static {v0}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 294
    .line 295
    .line 296
    move-result-object v0

    .line 297
    if-eqz v0, :cond_6

    .line 298
    .line 299
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object v2

    .line 303
    const-string v3, "routerTarget >>> failed, "

    .line 304
    .line 305
    invoke-static {v3, v2}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v2

    .line 309
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    move-result-object v2

    .line 313
    invoke-static {v6, v2}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object v0

    .line 320
    const/4 v2, 0x0

    .line 321
    new-array v2, v2, [Ljava/lang/Object;

    .line 322
    .line 323
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 324
    .line 325
    .line 326
    :cond_6
    :goto_4
    return-void
.end method

.method public final g(Lcom/transsnet/palmpay/credit/bean/HandleRouterParam;)V
    .locals 9

    .line 1
    const-string v0, "params"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/lang/StringBuilder;

    .line 7
    .line 8
    const-string v1, "syncCreditData >>> params="

    .line 9
    .line 10
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const/4 v1, 0x3

    .line 25
    const-string v2, "CreditRouterManagerV2"

    .line 26
    .line 27
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    :try_start_0
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 31
    .line 32
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/HandleRouterParam;->applyId:Ljava/lang/String;

    .line 33
    .line 34
    iput-object v0, p0, Ljb/t;->c:Ljava/lang/String;

    .line 35
    .line 36
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/HandleRouterParam;->customerTag:Ljava/lang/String;

    .line 37
    .line 38
    iput-object v0, p0, Ljb/t;->g:Ljava/lang/String;

    .line 39
    .line 40
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/HandleRouterParam;->loanProduct:Ljava/lang/String;

    .line 41
    .line 42
    iput-object v0, p0, Ljb/t;->f:Ljava/lang/String;

    .line 43
    .line 44
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/HandleRouterParam;->channelEnum:Ljava/lang/String;

    .line 45
    .line 46
    iput-object v0, p0, Ljb/t;->e:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v0, p1, Lcom/transsnet/palmpay/credit/bean/HandleRouterParam;->externalParams:Ljava/lang/String;

    .line 49
    .line 50
    iput-object v0, p0, Ljb/t;->k:Ljava/lang/String;

    .line 51
    .line 52
    new-instance v0, Lcom/transsnet/palmpay/credit/hook/CreditRouterManagerV2$syncCreditData$1$listType$1;

    .line 53
    .line 54
    invoke-direct {v0}, Lcom/transsnet/palmpay/credit/hook/CreditRouterManagerV2$syncCreditData$1$listType$1;-><init>()V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0}, Lcom/google/gson/reflect/TypeToken;->getType()Ljava/lang/reflect/Type;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    new-instance v1, Lcom/google/gson/Gson;

    .line 62
    .line 63
    invoke-direct {v1}, Lcom/google/gson/Gson;-><init>()V

    .line 64
    .line 65
    .line 66
    iget-object p1, p1, Lcom/transsnet/palmpay/credit/bean/HandleRouterParam;->routeInfoList:Ljava/lang/String;

    .line 67
    .line 68
    invoke-virtual {v1, p1, v0}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    const-string v0, "fromJson(...)"

    .line 73
    .line 74
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    check-cast p1, Ljava/util/List;

    .line 78
    .line 79
    iput-object p1, p0, Ljb/t;->b:Ljava/util/List;

    .line 80
    .line 81
    sget-object p1, Llb/f;->e:Llb/e;

    .line 82
    .line 83
    invoke-virtual {p1}, Llb/e;->getInstance()Llb/f;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 88
    .line 89
    iput-object v1, v0, Llb/f;->a:Ljava/lang/Boolean;

    .line 90
    .line 91
    invoke-virtual {p1}, Llb/e;->getInstance()Llb/f;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    iget-object v1, p0, Ljb/t;->f:Ljava/lang/String;

    .line 96
    .line 97
    iput-object v1, v0, Llb/f;->b:Ljava/lang/String;

    .line 98
    .line 99
    invoke-virtual {p1}, Llb/e;->getInstance()Llb/f;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    new-instance v3, Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 104
    .line 105
    iget-object v4, p0, Ljb/t;->c:Ljava/lang/String;

    .line 106
    .line 107
    iget-object v5, p0, Ljb/t;->f:Ljava/lang/String;

    .line 108
    .line 109
    const-string v0, "OK_CARD"

    .line 110
    .line 111
    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    if-eqz v0, :cond_0

    .line 116
    .line 117
    const-string v0, "OK_CARD_APPLY"

    .line 118
    .line 119
    :goto_0
    move-object v6, v0

    .line 120
    goto :goto_1

    .line 121
    :cond_0
    const-string v0, "CASH_LOAN_APPLY"

    .line 122
    .line 123
    goto :goto_0

    .line 124
    :goto_1
    iget-object v8, p0, Ljb/t;->b:Ljava/util/List;

    .line 125
    .line 126
    const/4 v7, 0x0

    .line 127
    invoke-direct/range {v3 .. v8}, Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/util/List;)V

    .line 128
    .line 129
    .line 130
    iput-object v3, p1, Llb/f;->d:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 131
    .line 132
    invoke-virtual {p0}, Ljb/t;->h()V

    .line 133
    .line 134
    .line 135
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 136
    .line 137
    goto :goto_2

    .line 138
    :catchall_0
    move-exception v0

    .line 139
    move-object p1, v0

    .line 140
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 141
    .line 142
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    :goto_2
    invoke-static {p1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    if-eqz p1, :cond_1

    .line 151
    .line 152
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    invoke-static {v2, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    :cond_1
    return-void
.end method

.method public final h()V
    .locals 6

    .line 1
    iget-object v0, p0, Ljb/t;->c:Ljava/lang/String;

    .line 2
    .line 3
    const-string v1, "uploadAppList >>> applyId="

    .line 4
    .line 5
    invoke-static {v1, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const/4 v1, 0x3

    .line 14
    const-string v2, "CreditRouterManagerV2"

    .line 15
    .line 16
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_4

    .line 24
    .line 25
    iget-object v0, p0, Ljb/t;->c:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    goto :goto_2

    .line 34
    :cond_0
    iget-object v0, p0, Ljb/t;->c:Ljava/lang/String;

    .line 35
    .line 36
    iget-object v1, p0, Ljb/t;->f:Ljava/lang/String;

    .line 37
    .line 38
    const-string v2, "OK_CARD"

    .line 39
    .line 40
    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-eqz v1, :cond_1

    .line 45
    .line 46
    const-string v1, "flexi"

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_1
    const-string v1, "flexi cash"

    .line 50
    .line 51
    :goto_0
    iget-object v2, p0, Ljb/t;->f:Ljava/lang/String;

    .line 52
    .line 53
    const-string v3, "LOAN_WITHDRAW"

    .line 54
    .line 55
    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 56
    .line 57
    .line 58
    move-result v2

    .line 59
    if-eqz v2, :cond_2

    .line 60
    .line 61
    const-string v2, "trade"

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_2
    const-string v2, "credit"

    .line 65
    .line 66
    :goto_1
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    if-nez v3, :cond_3

    .line 71
    .line 72
    goto :goto_2

    .line 73
    :cond_3
    const/4 v3, -0x4

    .line 74
    invoke-static {v3}, LPa/T;->b(I)Ljava/util/concurrent/ExecutorService;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    new-instance v4, Landroidx/emoji2/text/j;

    .line 79
    .line 80
    const/16 v5, 0x19

    .line 81
    .line 82
    invoke-direct {v4, v0, v5, v1, v2}, Landroidx/emoji2/text/j;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    invoke-interface {v3, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 86
    .line 87
    .line 88
    :cond_4
    :goto_2
    return-void
.end method

.method public final i()V
    .locals 4

    .line 1
    iget-object v0, p0, Ljb/t;->h:Ljava/lang/Boolean;

    .line 2
    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    const-string v2, "uploadLocationInfo >>> mUploadLocation = "

    .line 6
    .line 7
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v1, 0x3

    .line 22
    const-string v2, "CreditRouterManagerV2"

    .line 23
    .line 24
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Lya/a;->f()Lcom/transsnet/palmpay/core/bean/LocationRecord;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iget-object v1, p0, Ljb/t;->h:Ljava/lang/Boolean;

    .line 36
    .line 37
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 38
    .line 39
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_2

    .line 44
    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 48
    .line 49
    iput-object v0, p0, Ljb/t;->h:Ljava/lang/Boolean;

    .line 50
    .line 51
    iget-object v0, p0, Ljb/t;->c:Ljava/lang/String;

    .line 52
    .line 53
    iget-object v1, p0, Ljb/t;->f:Ljava/lang/String;

    .line 54
    .line 55
    const-string v2, "OK_CARD"

    .line 56
    .line 57
    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_0

    .line 62
    .line 63
    const-string v1, "flexi"

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_0
    const-string v1, "flexi cash"

    .line 67
    .line 68
    :goto_0
    iget-object v2, p0, Ljb/t;->f:Ljava/lang/String;

    .line 69
    .line 70
    const-string v3, "LOAN_WITHDRAW"

    .line 71
    .line 72
    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    if-eqz v2, :cond_1

    .line 77
    .line 78
    const-string v2, "trade"

    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_1
    const-string v2, "credit"

    .line 82
    .line 83
    :goto_1
    invoke-static {v0, v1, v2}, Ljb/u;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    :cond_2
    return-void
.end method

.method public onMessageEvent(Lcom/transsnet/palmpay/core/bean/message/MessageEvent;)V
    .locals 7
    .param p1    # Lcom/transsnet/palmpay/core/bean/message/MessageEvent;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation runtime Lorg/greenrobot/eventbus/Subscribe;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    const-string v0, "event"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventType()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const-string v1, "onMessageEvent = "

    .line 11
    .line 12
    invoke-static {v0, v1}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const/4 v1, 0x3

    .line 21
    const-string v2, "CreditRouterManagerV2"

    .line 22
    .line 23
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventType()I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    const/16 v3, 0x9

    .line 31
    .line 32
    if-eq v0, v3, :cond_a

    .line 33
    .line 34
    const/16 v3, 0x113

    .line 35
    .line 36
    const-string v4, "1"

    .line 37
    .line 38
    if-eq v0, v3, :cond_8

    .line 39
    .line 40
    const/16 v3, 0x152

    .line 41
    .line 42
    const/4 v5, 0x0

    .line 43
    if-eq v0, v3, :cond_6

    .line 44
    .line 45
    const/16 v3, 0x223

    .line 46
    .line 47
    if-eq v0, v3, :cond_5

    .line 48
    .line 49
    const/16 v3, 0x229

    .line 50
    .line 51
    const/4 v6, 0x5

    .line 52
    if-eq v0, v3, :cond_3

    .line 53
    .line 54
    const/16 v3, 0x230

    .line 55
    .line 56
    if-eq v0, v3, :cond_a

    .line 57
    .line 58
    const/16 v1, 0x236

    .line 59
    .line 60
    if-eq v0, v1, :cond_2

    .line 61
    .line 62
    const/16 v1, 0x238

    .line 63
    .line 64
    if-eq v0, v1, :cond_0

    .line 65
    .line 66
    goto/16 :goto_0

    .line 67
    .line 68
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventObj()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    const/16 v0, 0xc8

    .line 73
    .line 74
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    if-eqz p1, :cond_1

    .line 83
    .line 84
    iget-boolean p1, p0, Ljb/t;->j:Z

    .line 85
    .line 86
    if-eqz p1, :cond_1

    .line 87
    .line 88
    const-string p1, "mBvnVerified >>> no exit"

    .line 89
    .line 90
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-static {v2, v6, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    :cond_1
    invoke-virtual {p0}, Ljb/t;->e()V

    .line 99
    .line 100
    .line 101
    return-void

    .line 102
    :cond_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventContent()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    invoke-static {p1, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 107
    .line 108
    .line 109
    move-result p1

    .line 110
    if-eqz p1, :cond_9

    .line 111
    .line 112
    invoke-virtual {p0}, Ljb/t;->e()V

    .line 113
    .line 114
    .line 115
    return-void

    .line 116
    :cond_3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventContent()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    const-string v0, "exitRNRouterPage >>> moduleName="

    .line 121
    .line 122
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {p0, v5, p1}, Ljb/t;->c(Ljava/lang/Integer;Ljava/lang/String;)Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    if-eqz p1, :cond_9

    .line 138
    .line 139
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getType()Ljava/lang/Integer;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    sget-object v1, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->RN:Lcom/transsnet/palmpay/credit/bean/RoutePageType;

    .line 144
    .line 145
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->getCode()I

    .line 146
    .line 147
    .line 148
    move-result v1

    .line 149
    if-nez v0, :cond_4

    .line 150
    .line 151
    goto/16 :goto_0

    .line 152
    .line 153
    :cond_4
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 154
    .line 155
    .line 156
    move-result v0

    .line 157
    if-ne v0, v1, :cond_9

    .line 158
    .line 159
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getName()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    const-string v0, "exitRNRouterPage >>> isDynamicRnRoute, routePath="

    .line 164
    .line 165
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    invoke-static {v2, v6, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {p0}, Ljb/t;->e()V

    .line 177
    .line 178
    .line 179
    return-void

    .line 180
    :cond_5
    const/4 p1, 0x1

    .line 181
    iput-boolean p1, p0, Ljb/t;->j:Z

    .line 182
    .line 183
    const-string p1, "mBvnVerified >>> success"

    .line 184
    .line 185
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {p0}, Ljb/t;->d()V

    .line 193
    .line 194
    .line 195
    return-void

    .line 196
    :cond_6
    invoke-virtual {p0}, Ljb/t;->i()V

    .line 197
    .line 198
    .line 199
    const-string p1, "doLocationChange >>>"

    .line 200
    .line 201
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 206
    .line 207
    .line 208
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 209
    .line 210
    .line 211
    move-result-object p1

    .line 212
    invoke-virtual {p1}, Lya/a;->f()Lcom/transsnet/palmpay/core/bean/LocationRecord;

    .line 213
    .line 214
    .line 215
    move-result-object p1

    .line 216
    if-nez p1, :cond_7

    .line 217
    .line 218
    goto :goto_0

    .line 219
    :cond_7
    new-instance v0, Lorg/json/JSONObject;

    .line 220
    .line 221
    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 222
    .line 223
    .line 224
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLatitude()D

    .line 225
    .line 226
    .line 227
    move-result-wide v1

    .line 228
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    const-string v2, "latitude"

    .line 233
    .line 234
    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 235
    .line 236
    .line 237
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/LocationRecord;->getLongitude()D

    .line 238
    .line 239
    .line 240
    move-result-wide v1

    .line 241
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    .line 242
    .line 243
    .line 244
    move-result-object p1

    .line 245
    const-string v1, "longitude"

    .line 246
    .line 247
    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 248
    .line 249
    .line 250
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object p1

    .line 254
    const-string v0, "NoticeRNCreditLocationChange"

    .line 255
    .line 256
    invoke-static {v0, p1, v5}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    return-void

    .line 260
    :cond_8
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventContent()Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object p1

    .line 264
    invoke-static {p1, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 265
    .line 266
    .line 267
    move-result p1

    .line 268
    if-eqz p1, :cond_9

    .line 269
    .line 270
    invoke-virtual {p0}, Ljb/t;->d()V

    .line 271
    .line 272
    .line 273
    :cond_9
    :goto_0
    return-void

    .line 274
    :cond_a
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventType()I

    .line 275
    .line 276
    .line 277
    move-result p1

    .line 278
    const-string v0, "onMessageEvent routeNext= "

    .line 279
    .line 280
    invoke-static {p1, v0}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object p1

    .line 284
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 285
    .line 286
    .line 287
    move-result-object p1

    .line 288
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 289
    .line 290
    .line 291
    invoke-virtual {p0}, Ljb/t;->d()V

    .line 292
    .line 293
    .line 294
    return-void
.end method
