.class public abstract Ljb/q;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljb/t;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ljb/t;

    .line 2
    .line 3
    invoke-direct {v0}, Ljb/t;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Ljb/q;->a:Ljb/t;

    .line 7
    .line 8
    return-void
.end method
