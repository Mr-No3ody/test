.class public final Ljb/m;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Ljb/o;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic i:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(Ljb/o;Ljava/lang/String;Ljava/lang/Integer;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ljb/m;->f:Ljb/o;

    .line 5
    .line 6
    iput-object p2, p0, Ljb/m;->g:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Ljb/m;->i:Ljava/lang/Integer;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Ljb/m;->f:Ljb/o;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljb/o;->i()Lgf/a;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-object v0, p0, Ljb/m;->f:Ljb/o;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljb/o;->B()V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    new-array v0, v0, [Ljava/lang/Object;

    .line 8
    .line 9
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 6

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;

    .line 2
    .line 3
    iget-object v0, p0, Ljb/m;->g:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-object v2, p0, Ljb/m;->f:Ljb/o;

    .line 14
    .line 15
    if-eqz v1, :cond_11

    .line 16
    .line 17
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    iget-object v4, p0, Ljb/m;->i:Ljava/lang/Integer;

    .line 22
    .line 23
    const/4 v5, 0x0

    .line 24
    sparse-switch v3, :sswitch_data_0

    .line 25
    .line 26
    .line 27
    goto/16 :goto_7

    .line 28
    .line 29
    :sswitch_0
    const-string v3, "/coreImpl/add_new_card"

    .line 30
    .line 31
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    if-nez v1, :cond_0

    .line 36
    .line 37
    goto/16 :goto_7

    .line 38
    .line 39
    :cond_0
    if-eqz p1, :cond_1

    .line 40
    .line 41
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;

    .line 42
    .line 43
    if-eqz p1, :cond_1

    .line 44
    .line 45
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;->bankCard:Ljava/lang/String;

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    move-object p1, v5

    .line 49
    :goto_0
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    if-eqz p1, :cond_2

    .line 54
    .line 55
    invoke-virtual {v2, v4, v0, v5}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_2
    invoke-static {v2}, Ljb/o;->w(Ljb/o;)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :sswitch_1
    const-string v3, "/coreImpl/bind_new_bank_account"

    .line 64
    .line 65
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    if-nez v1, :cond_3

    .line 70
    .line 71
    goto/16 :goto_7

    .line 72
    .line 73
    :cond_3
    if-eqz p1, :cond_4

    .line 74
    .line 75
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;

    .line 76
    .line 77
    if-eqz p1, :cond_4

    .line 78
    .line 79
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;->bankAccount:Ljava/lang/String;

    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_4
    move-object p1, v5

    .line 83
    :goto_1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    if-eqz p1, :cond_5

    .line 88
    .line 89
    invoke-virtual {v2, v4, v0, v5}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    return-void

    .line 93
    :cond_5
    invoke-static {v2}, Ljb/o;->w(Ljb/o;)V

    .line 94
    .line 95
    .line 96
    return-void

    .line 97
    :sswitch_2
    const-string v3, "/coreImpl/use_new_card"

    .line 98
    .line 99
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    if-nez v1, :cond_6

    .line 104
    .line 105
    goto/16 :goto_7

    .line 106
    .line 107
    :cond_6
    if-eqz p1, :cond_7

    .line 108
    .line 109
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;

    .line 110
    .line 111
    if-eqz p1, :cond_7

    .line 112
    .line 113
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;->bankCard:Ljava/lang/String;

    .line 114
    .line 115
    goto :goto_2

    .line 116
    :cond_7
    move-object p1, v5

    .line 117
    :goto_2
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 118
    .line 119
    .line 120
    move-result p1

    .line 121
    if-eqz p1, :cond_8

    .line 122
    .line 123
    invoke-virtual {v2, v4, v0, v5}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    return-void

    .line 127
    :cond_8
    invoke-static {v2}, Ljb/o;->w(Ljb/o;)V

    .line 128
    .line 129
    .line 130
    return-void

    .line 131
    :sswitch_3
    const-string v3, "/account/upgrade"

    .line 132
    .line 133
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 134
    .line 135
    .line 136
    move-result v1

    .line 137
    if-nez v1, :cond_9

    .line 138
    .line 139
    goto :goto_7

    .line 140
    :cond_9
    if-eqz p1, :cond_a

    .line 141
    .line 142
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;

    .line 143
    .line 144
    if-eqz p1, :cond_a

    .line 145
    .line 146
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;->bvn:Ljava/lang/String;

    .line 147
    .line 148
    goto :goto_3

    .line 149
    :cond_a
    move-object p1, v5

    .line 150
    :goto_3
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 151
    .line 152
    .line 153
    move-result p1

    .line 154
    if-eqz p1, :cond_b

    .line 155
    .line 156
    invoke-virtual {v2, v4, v0, v5}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    return-void

    .line 160
    :cond_b
    invoke-static {v2}, Ljb/o;->w(Ljb/o;)V

    .line 161
    .line 162
    .line 163
    return-void

    .line 164
    :sswitch_4
    const-string v3, "/credit_score/oc_all_verify_activity"

    .line 165
    .line 166
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result v1

    .line 170
    if-nez v1, :cond_c

    .line 171
    .line 172
    goto :goto_7

    .line 173
    :cond_c
    if-eqz p1, :cond_d

    .line 174
    .line 175
    iget-object v1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;

    .line 176
    .line 177
    if-eqz v1, :cond_d

    .line 178
    .line 179
    iget-object v1, v1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;->bvn:Ljava/lang/String;

    .line 180
    .line 181
    goto :goto_4

    .line 182
    :cond_d
    move-object v1, v5

    .line 183
    :goto_4
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 184
    .line 185
    .line 186
    move-result v1

    .line 187
    if-eqz v1, :cond_10

    .line 188
    .line 189
    if-eqz p1, :cond_e

    .line 190
    .line 191
    iget-object v1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;

    .line 192
    .line 193
    if-eqz v1, :cond_e

    .line 194
    .line 195
    iget-object v1, v1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;->bankCard:Ljava/lang/String;

    .line 196
    .line 197
    goto :goto_5

    .line 198
    :cond_e
    move-object v1, v5

    .line 199
    :goto_5
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 200
    .line 201
    .line 202
    move-result v1

    .line 203
    if-eqz v1, :cond_10

    .line 204
    .line 205
    if-eqz p1, :cond_f

    .line 206
    .line 207
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp;->data:Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;

    .line 208
    .line 209
    if-eqz p1, :cond_f

    .line 210
    .line 211
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/rsp/AllAuthInfoRsp$DataBean;->bankAccount:Ljava/lang/String;

    .line 212
    .line 213
    goto :goto_6

    .line 214
    :cond_f
    move-object p1, v5

    .line 215
    :goto_6
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 216
    .line 217
    .line 218
    move-result p1

    .line 219
    if-eqz p1, :cond_10

    .line 220
    .line 221
    invoke-virtual {v2, v4, v0, v5}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    return-void

    .line 225
    :cond_10
    invoke-static {v2}, Ljb/o;->w(Ljb/o;)V

    .line 226
    .line 227
    .line 228
    return-void

    .line 229
    :cond_11
    :goto_7
    invoke-static {v2}, Ljb/o;->w(Ljb/o;)V

    .line 230
    .line 231
    .line 232
    return-void

    .line 233
    :sswitch_data_0
    .sparse-switch
        -0x79eccc60 -> :sswitch_4
        -0x66f75fd5 -> :sswitch_3
        -0x4d2c5518 -> :sswitch_2
        0x4c40436a -> :sswitch_1
        0x6b42d50e -> :sswitch_0
    .end sparse-switch
.end method
