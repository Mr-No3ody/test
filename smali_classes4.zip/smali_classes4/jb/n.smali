.class public final Ljb/n;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Ljb/o;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic i:Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;


# direct methods
.method public constructor <init>(Ljb/o;Ljava/lang/String;Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ljb/n;->f:Ljb/o;

    .line 5
    .line 6
    iput-object p2, p0, Ljb/n;->g:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Ljb/n;->i:Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Ljb/n;->f:Ljb/o;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljb/o;->i()Lgf/a;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    const-string v0, "startBorrow preCheck onFail >>> "

    .line 2
    .line 3
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const-string v1, "CreditRouterManager"

    .line 12
    .line 13
    invoke-static {v1, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    if-eqz p1, :cond_1

    .line 17
    .line 18
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    move-object v0, p1

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v0, 0x0

    .line 27
    :goto_0
    if-eqz v0, :cond_1

    .line 28
    .line 29
    iget-object v0, p0, Ljb/n;->f:Ljb/o;

    .line 30
    .line 31
    invoke-static {v0, p1}, Ljb/o;->b(Ljb/o;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    :cond_1
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 11

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;

    .line 2
    .line 3
    iget-object v0, p0, Ljb/n;->f:Ljb/o;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    const-string v2, "CreditRouterManager"

    .line 7
    .line 8
    if-eqz p1, :cond_38

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    if-eqz v3, :cond_0

    .line 21
    .line 22
    move-object v3, p1

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    move-object v3, v1

    .line 25
    :goto_0
    if-eqz v3, :cond_38

    .line 26
    .line 27
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    if-eqz p1, :cond_1

    .line 32
    .line 33
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getLoanPreCheck()Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    if-eqz p1, :cond_1

    .line 38
    .line 39
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;->getAccountType()Ljava/lang/Integer;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    goto :goto_1

    .line 44
    :cond_1
    move-object p1, v1

    .line 45
    :goto_1
    iput-object p1, v0, Ljb/o;->h:Ljava/lang/Integer;

    .line 46
    .line 47
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    if-eqz p1, :cond_2

    .line 52
    .line 53
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getLoanPreCheck()Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    goto :goto_2

    .line 58
    :cond_2
    move-object p1, v1

    .line 59
    :goto_2
    iget-object v4, v0, Ljb/o;->h:Ljava/lang/Integer;

    .line 60
    .line 61
    if-eqz p1, :cond_3

    .line 62
    .line 63
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;->getNeedRoute()Ljava/lang/Boolean;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    goto :goto_3

    .line 68
    :cond_3
    move-object p1, v1

    .line 69
    :goto_3
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 70
    .line 71
    .line 72
    move-result-object v5

    .line 73
    if-eqz v5, :cond_4

    .line 74
    .line 75
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getCanCredit()Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;

    .line 76
    .line 77
    .line 78
    move-result-object v5

    .line 79
    if-eqz v5, :cond_4

    .line 80
    .line 81
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;->getCan()Ljava/lang/Boolean;

    .line 82
    .line 83
    .line 84
    move-result-object v5

    .line 85
    goto :goto_4

    .line 86
    :cond_4
    move-object v5, v1

    .line 87
    :goto_4
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 88
    .line 89
    .line 90
    move-result-object v6

    .line 91
    if-eqz v6, :cond_5

    .line 92
    .line 93
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getMoveCashApp()Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;

    .line 94
    .line 95
    .line 96
    move-result-object v6

    .line 97
    if-eqz v6, :cond_5

    .line 98
    .line 99
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;->getMoveStrategy()Ljava/lang/Boolean;

    .line 100
    .line 101
    .line 102
    move-result-object v6

    .line 103
    goto :goto_5

    .line 104
    :cond_5
    move-object v6, v1

    .line 105
    :goto_5
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 106
    .line 107
    .line 108
    move-result-object v7

    .line 109
    if-eqz v7, :cond_6

    .line 110
    .line 111
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getCalcManagementFee()Lcom/transsnet/palmpay/credit/bean/resp/CalcManagementFee;

    .line 112
    .line 113
    .line 114
    move-result-object v7

    .line 115
    if-eqz v7, :cond_6

    .line 116
    .line 117
    invoke-virtual {v7}, Lcom/transsnet/palmpay/credit/bean/resp/CalcManagementFee;->getManagementMode()Ljava/lang/Integer;

    .line 118
    .line 119
    .line 120
    move-result-object v7

    .line 121
    goto :goto_6

    .line 122
    :cond_6
    move-object v7, v1

    .line 123
    :goto_6
    new-instance v8, Ljava/lang/StringBuilder;

    .line 124
    .line 125
    const-string v9, "startBorrow preCheck onSuccess >>> mAccountType="

    .line 126
    .line 127
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    const-string v4, ", needRoute="

    .line 134
    .line 135
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    const-string p1, ", canCredit.can="

    .line 142
    .line 143
    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 144
    .line 145
    .line 146
    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 147
    .line 148
    .line 149
    const-string p1, ", moveStrategy="

    .line 150
    .line 151
    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 152
    .line 153
    .line 154
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    const-string p1, ", managementMode="

    .line 158
    .line 159
    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 160
    .line 161
    .line 162
    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 163
    .line 164
    .line 165
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    const/4 v4, 0x3

    .line 174
    invoke-static {v2, v4, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    const/4 v5, 0x0

    .line 182
    if-eqz p1, :cond_7

    .line 183
    .line 184
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getMoveCashApp()Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    if-eqz p1, :cond_7

    .line 189
    .line 190
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;->getMoveStrategy()Ljava/lang/Boolean;

    .line 191
    .line 192
    .line 193
    move-result-object p1

    .line 194
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 195
    .line 196
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 197
    .line 198
    .line 199
    move-result p1

    .line 200
    goto :goto_7

    .line 201
    :cond_7
    move p1, v5

    .line 202
    :goto_7
    const-string v6, "mLoanCreditFragmentRef"

    .line 203
    .line 204
    const/4 v7, 0x1

    .line 205
    if-eqz p1, :cond_11

    .line 206
    .line 207
    const-string p1, "startBorrow preCheck branch >>> MOVE_CASH_APP"

    .line 208
    .line 209
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object p1

    .line 213
    invoke-static {v2, v4, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    const-string p1, "com.legend.cash"

    .line 217
    .line 218
    invoke-static {p1}, Lcom/transsnet/palmpay/util/AppUtils;->isAppInstalled(Ljava/lang/String;)Z

    .line 219
    .line 220
    .line 221
    move-result p1

    .line 222
    if-eqz p1, :cond_9

    .line 223
    .line 224
    iget-object p1, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 225
    .line 226
    if-eqz p1, :cond_8

    .line 227
    .line 228
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object p1

    .line 232
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 233
    .line 234
    if-eqz p1, :cond_3b

    .line 235
    .line 236
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 237
    .line 238
    .line 239
    move-result-object p1

    .line 240
    if-eqz p1, :cond_3b

    .line 241
    .line 242
    invoke-static {p1}, LPa/i0;->Z(Landroid/content/Context;)V

    .line 243
    .line 244
    .line 245
    return-void

    .line 246
    :cond_8
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    throw v1

    .line 250
    :cond_9
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 251
    .line 252
    .line 253
    move-result-object p1

    .line 254
    if-eqz p1, :cond_a

    .line 255
    .line 256
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getMoveCashApp()Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;

    .line 257
    .line 258
    .line 259
    move-result-object p1

    .line 260
    if-eqz p1, :cond_a

    .line 261
    .line 262
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;->getDownloadUrl()Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object p1

    .line 266
    goto :goto_8

    .line 267
    :cond_a
    move-object p1, v1

    .line 268
    :goto_8
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 269
    .line 270
    .line 271
    move-result p1

    .line 272
    if-eqz p1, :cond_b

    .line 273
    .line 274
    goto/16 :goto_1c

    .line 275
    .line 276
    :cond_b
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 277
    .line 278
    .line 279
    move-result-object p1

    .line 280
    if-eqz p1, :cond_e

    .line 281
    .line 282
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getMoveCashApp()Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;

    .line 283
    .line 284
    .line 285
    move-result-object p1

    .line 286
    if-eqz p1, :cond_e

    .line 287
    .line 288
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;->getDownloadOpenType()Ljava/lang/Integer;

    .line 289
    .line 290
    .line 291
    move-result-object p1

    .line 292
    if-nez p1, :cond_c

    .line 293
    .line 294
    goto :goto_9

    .line 295
    :cond_c
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 296
    .line 297
    .line 298
    move-result p1

    .line 299
    if-ne p1, v4, :cond_e

    .line 300
    .line 301
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 302
    .line 303
    .line 304
    move-result-object p1

    .line 305
    if-eqz p1, :cond_d

    .line 306
    .line 307
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getMoveCashApp()Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;

    .line 308
    .line 309
    .line 310
    move-result-object p1

    .line 311
    if-eqz p1, :cond_d

    .line 312
    .line 313
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;->getDownloadUrl()Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object v1

    .line 317
    :cond_d
    invoke-static {v1, v7}, Lcom/transsnet/palmpay/util/IntentUtils;->getOpenUrlIntent(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 318
    .line 319
    .line 320
    move-result-object p1

    .line 321
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 322
    .line 323
    .line 324
    return-void

    .line 325
    :cond_e
    :goto_9
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 326
    .line 327
    .line 328
    move-result-object p1

    .line 329
    if-eqz p1, :cond_3b

    .line 330
    .line 331
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getMoveCashApp()Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;

    .line 332
    .line 333
    .line 334
    move-result-object p1

    .line 335
    if-eqz p1, :cond_3b

    .line 336
    .line 337
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;->getDownloadOpenType()Ljava/lang/Integer;

    .line 338
    .line 339
    .line 340
    move-result-object p1

    .line 341
    if-nez p1, :cond_f

    .line 342
    .line 343
    goto/16 :goto_1c

    .line 344
    .line 345
    :cond_f
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 346
    .line 347
    .line 348
    move-result p1

    .line 349
    const/4 v0, 0x4

    .line 350
    if-ne p1, v0, :cond_3b

    .line 351
    .line 352
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 353
    .line 354
    .line 355
    move-result-object p1

    .line 356
    if-eqz p1, :cond_10

    .line 357
    .line 358
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getMoveCashApp()Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;

    .line 359
    .line 360
    .line 361
    move-result-object p1

    .line 362
    if-eqz p1, :cond_10

    .line 363
    .line 364
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/MoveCashAppResp;->getDownloadUrl()Ljava/lang/String;

    .line 365
    .line 366
    .line 367
    move-result-object v1

    .line 368
    :cond_10
    invoke-static {v1}, LPa/i0;->c0(Ljava/lang/String;)V

    .line 369
    .line 370
    .line 371
    return-void

    .line 372
    :cond_11
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 373
    .line 374
    .line 375
    move-result-object p1

    .line 376
    if-eqz p1, :cond_12

    .line 377
    .line 378
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getCalcManagementFee()Lcom/transsnet/palmpay/credit/bean/resp/CalcManagementFee;

    .line 379
    .line 380
    .line 381
    move-result-object p1

    .line 382
    if-eqz p1, :cond_12

    .line 383
    .line 384
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CalcManagementFee;->getManagementMode()Ljava/lang/Integer;

    .line 385
    .line 386
    .line 387
    move-result-object p1

    .line 388
    if-eqz p1, :cond_12

    .line 389
    .line 390
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 391
    .line 392
    .line 393
    move-result p1

    .line 394
    goto :goto_a

    .line 395
    :cond_12
    const/4 p1, -0x1

    .line 396
    :goto_a
    if-ne p1, v7, :cond_15

    .line 397
    .line 398
    const-string p1, "startBorrow preCheck branch >>> MANAGEMENT_FEE"

    .line 399
    .line 400
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 401
    .line 402
    .line 403
    move-result-object p1

    .line 404
    invoke-static {v2, v4, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 405
    .line 406
    .line 407
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 408
    .line 409
    .line 410
    move-result-object p1

    .line 411
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 412
    .line 413
    .line 414
    move-result-object v2

    .line 415
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 416
    .line 417
    .line 418
    move-result-object v2

    .line 419
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/db/entity/User;->getMemberId()Ljava/lang/String;

    .line 420
    .line 421
    .line 422
    move-result-object v2

    .line 423
    invoke-virtual {p1, v2, v7}, Lcom/transsnet/palmpay/util/SPUtils;->getBoolean(Ljava/lang/String;Z)Z

    .line 424
    .line 425
    .line 426
    move-result p1

    .line 427
    if-eqz p1, :cond_14

    .line 428
    .line 429
    iget-object p1, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 430
    .line 431
    if-eqz p1, :cond_13

    .line 432
    .line 433
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 434
    .line 435
    .line 436
    move-result-object p1

    .line 437
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 438
    .line 439
    if-eqz p1, :cond_3b

    .line 440
    .line 441
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/Z;

    .line 442
    .line 443
    .line 444
    move-result-object p1

    .line 445
    if-eqz p1, :cond_3b

    .line 446
    .line 447
    sget-object v0, Lcom/transsnet/palmpay/credit/ui/dialog/CLManagementFeeDialogFragment;->C:Lcom/transsnet/palmpay/credit/ui/dialog/CLManagementFeeDialogFragment$a;

    .line 448
    .line 449
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/dialog/CLManagementFeeDialogFragment$a;->newInstance()Lcom/transsnet/palmpay/credit/ui/dialog/CLManagementFeeDialogFragment;

    .line 450
    .line 451
    .line 452
    move-result-object v0

    .line 453
    const-string v1, "showCLManagementFeeDialog"

    .line 454
    .line 455
    invoke-virtual {v0, p1, v1}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 456
    .line 457
    .line 458
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->getInstance()Lcom/transsnet/palmpay/util/SPUtils;

    .line 459
    .line 460
    .line 461
    move-result-object p1

    .line 462
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 463
    .line 464
    .line 465
    move-result-object v0

    .line 466
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 467
    .line 468
    .line 469
    move-result-object v0

    .line 470
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/db/entity/User;->getMemberId()Ljava/lang/String;

    .line 471
    .line 472
    .line 473
    move-result-object v0

    .line 474
    invoke-virtual {p1, v0, v5}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;Z)V

    .line 475
    .line 476
    .line 477
    return-void

    .line 478
    :cond_13
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 479
    .line 480
    .line 481
    throw v1

    .line 482
    :cond_14
    invoke-static {}, LC0/G;->k()Ljava/lang/String;

    .line 483
    .line 484
    .line 485
    move-result-object p1

    .line 486
    new-instance v0, Ljava/lang/StringBuilder;

    .line 487
    .line 488
    const-string v1, "https://h5.fleximfb.com/cash/download-guide?source=CashHome&m="

    .line 489
    .line 490
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 491
    .line 492
    .line 493
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 494
    .line 495
    .line 496
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 497
    .line 498
    .line 499
    move-result-object p1

    .line 500
    invoke-static {p1}, LPa/i0;->c0(Ljava/lang/String;)V

    .line 501
    .line 502
    .line 503
    return-void

    .line 504
    :cond_15
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 505
    .line 506
    .line 507
    move-result-object p1

    .line 508
    if-eqz p1, :cond_16

    .line 509
    .line 510
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getLoanPreCheck()Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;

    .line 511
    .line 512
    .line 513
    move-result-object p1

    .line 514
    if-eqz p1, :cond_16

    .line 515
    .line 516
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;->getSignList()Ljava/util/List;

    .line 517
    .line 518
    .line 519
    move-result-object p1

    .line 520
    goto :goto_b

    .line 521
    :cond_16
    move-object p1, v1

    .line 522
    :goto_b
    const-string v8, "needSignedWithholdProtocol >>>"

    .line 523
    .line 524
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 525
    .line 526
    .line 527
    move-result-object v8

    .line 528
    invoke-static {v2, v4, v8}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 529
    .line 530
    .line 531
    if-eqz p1, :cond_17

    .line 532
    .line 533
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 534
    .line 535
    .line 536
    move-result v8

    .line 537
    if-nez v8, :cond_17

    .line 538
    .line 539
    goto :goto_f

    .line 540
    :cond_17
    if-eqz p1, :cond_1c

    .line 541
    .line 542
    check-cast p1, Ljava/lang/Iterable;

    .line 543
    .line 544
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 545
    .line 546
    .line 547
    move-result-object p1

    .line 548
    :cond_18
    :goto_c
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 549
    .line 550
    .line 551
    move-result v8

    .line 552
    if-eqz v8, :cond_1b

    .line 553
    .line 554
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 555
    .line 556
    .line 557
    move-result-object v8

    .line 558
    move-object v9, v8

    .line 559
    check-cast v9, Lcom/transsnet/palmpay/credit/bean/resp/SignItem;

    .line 560
    .line 561
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/resp/SignItem;->getSignType()Ljava/lang/Integer;

    .line 562
    .line 563
    .line 564
    move-result-object v10

    .line 565
    if-nez v10, :cond_19

    .line 566
    .line 567
    goto :goto_c

    .line 568
    :cond_19
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 569
    .line 570
    .line 571
    move-result v10

    .line 572
    if-ne v10, v7, :cond_18

    .line 573
    .line 574
    invoke-virtual {v9}, Lcom/transsnet/palmpay/credit/bean/resp/SignItem;->getSignStatus()Ljava/lang/Integer;

    .line 575
    .line 576
    .line 577
    move-result-object v9

    .line 578
    if-nez v9, :cond_1a

    .line 579
    .line 580
    goto :goto_c

    .line 581
    :cond_1a
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 582
    .line 583
    .line 584
    move-result v9

    .line 585
    if-ne v9, v7, :cond_18

    .line 586
    .line 587
    goto :goto_d

    .line 588
    :cond_1b
    move-object v8, v1

    .line 589
    :goto_d
    check-cast v8, Lcom/transsnet/palmpay/credit/bean/resp/SignItem;

    .line 590
    .line 591
    goto :goto_e

    .line 592
    :cond_1c
    move-object v8, v1

    .line 593
    :goto_e
    if-eqz v8, :cond_1d

    .line 594
    .line 595
    move p1, v7

    .line 596
    goto :goto_10

    .line 597
    :cond_1d
    :goto_f
    move p1, v5

    .line 598
    :goto_10
    if-eqz p1, :cond_1f

    .line 599
    .line 600
    const-string p1, "startBorrow preCheck branch >>> WITHHOLD_PROTOCOL_DIALOG"

    .line 601
    .line 602
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 603
    .line 604
    .line 605
    move-result-object p1

    .line 606
    invoke-static {v2, v4, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 607
    .line 608
    .line 609
    iget-object p1, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 610
    .line 611
    if-eqz p1, :cond_1e

    .line 612
    .line 613
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 614
    .line 615
    .line 616
    move-result-object p1

    .line 617
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 618
    .line 619
    if-eqz p1, :cond_3b

    .line 620
    .line 621
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 622
    .line 623
    .line 624
    move-result-object p1

    .line 625
    if-eqz p1, :cond_3b

    .line 626
    .line 627
    new-instance v1, Lcom/transsnet/palmpay/credit/ui/dialog/AgentAutoRepaymentDialog;

    .line 628
    .line 629
    new-instance v2, Lcb/c;

    .line 630
    .line 631
    const/16 v4, 0xa

    .line 632
    .line 633
    invoke-direct {v2, v4, v0, v3}, Lcb/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 634
    .line 635
    .line 636
    invoke-direct {v1, p1, v2}, Lcom/transsnet/palmpay/credit/ui/dialog/AgentAutoRepaymentDialog;-><init>(Landroid/content/Context;Lcom/transsnet/palmpay/credit/ui/dialog/AgentAutoRepaymentDialogListener;)V

    .line 637
    .line 638
    .line 639
    invoke-virtual {v1}, LO6/f;->show()V

    .line 640
    .line 641
    .line 642
    return-void

    .line 643
    :cond_1e
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 644
    .line 645
    .line 646
    throw v1

    .line 647
    :cond_1f
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 648
    .line 649
    .line 650
    move-result-object p1

    .line 651
    if-eqz p1, :cond_20

    .line 652
    .line 653
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getCanCredit()Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;

    .line 654
    .line 655
    .line 656
    move-result-object p1

    .line 657
    if-eqz p1, :cond_20

    .line 658
    .line 659
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;->getCan()Ljava/lang/Boolean;

    .line 660
    .line 661
    .line 662
    move-result-object p1

    .line 663
    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 664
    .line 665
    invoke-static {p1, v8}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 666
    .line 667
    .line 668
    move-result p1

    .line 669
    goto :goto_11

    .line 670
    :cond_20
    move p1, v5

    .line 671
    :goto_11
    iget-object v8, p0, Ljb/n;->g:Ljava/lang/String;

    .line 672
    .line 673
    if-eqz p1, :cond_2a

    .line 674
    .line 675
    const-string p1, "startBorrow preCheck branch >>> CANNOT_BORROW"

    .line 676
    .line 677
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 678
    .line 679
    .line 680
    move-result-object p1

    .line 681
    invoke-static {v2, v4, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 682
    .line 683
    .line 684
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 685
    .line 686
    .line 687
    move-result-object p1

    .line 688
    if-eqz p1, :cond_21

    .line 689
    .line 690
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getCanCredit()Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;

    .line 691
    .line 692
    .line 693
    move-result-object p1

    .line 694
    if-eqz p1, :cond_21

    .line 695
    .line 696
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;->getOutstandingContentInfo()Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfoV2;

    .line 697
    .line 698
    .line 699
    move-result-object p1

    .line 700
    goto :goto_12

    .line 701
    :cond_21
    move-object p1, v1

    .line 702
    :goto_12
    if-nez p1, :cond_22

    .line 703
    .line 704
    goto :goto_13

    .line 705
    :cond_22
    sget-object v9, Lcom/transsnet/palmpay/credit/ui/dialog/BorrowPreCheckRepaymentDialog;->Companion:Lcom/transsnet/palmpay/credit/ui/dialog/BorrowPreCheckRepaymentDialog$a;

    .line 706
    .line 707
    invoke-virtual {v9, p1}, Lcom/transsnet/palmpay/credit/ui/dialog/BorrowPreCheckRepaymentDialog$a;->canShow(Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfoV2;)Z

    .line 708
    .line 709
    .line 710
    move-result v9

    .line 711
    if-nez v9, :cond_23

    .line 712
    .line 713
    goto :goto_13

    .line 714
    :cond_23
    iget-object v0, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 715
    .line 716
    if-eqz v0, :cond_29

    .line 717
    .line 718
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 719
    .line 720
    .line 721
    move-result-object v0

    .line 722
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 723
    .line 724
    if-eqz v0, :cond_25

    .line 725
    .line 726
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 727
    .line 728
    .line 729
    move-result-object v0

    .line 730
    if-nez v0, :cond_24

    .line 731
    .line 732
    goto :goto_13

    .line 733
    :cond_24
    new-instance v5, Lcom/transsnet/palmpay/credit/ui/dialog/BorrowPreCheckRepaymentDialog;

    .line 734
    .line 735
    invoke-direct {v5, v0, p1}, Lcom/transsnet/palmpay/credit/ui/dialog/BorrowPreCheckRepaymentDialog;-><init>(Landroid/content/Context;Lcom/transsnet/palmpay/credit/bean/OutstandingContentInfoV2;)V

    .line 736
    .line 737
    .line 738
    invoke-virtual {v5}, LO6/f;->show()V

    .line 739
    .line 740
    .line 741
    move v5, v7

    .line 742
    :cond_25
    :goto_13
    const-string p1, "fail"

    .line 743
    .line 744
    if-eqz v5, :cond_26

    .line 745
    .line 746
    const-string v0, "startBorrow preCheck >>> showBorrowPreCheckRepaymentDialog"

    .line 747
    .line 748
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 749
    .line 750
    .line 751
    move-result-object v0

    .line 752
    invoke-static {v2, v4, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 753
    .line 754
    .line 755
    invoke-static {p1, v8}, LEb/b;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 756
    .line 757
    .line 758
    return-void

    .line 759
    :cond_26
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 760
    .line 761
    .line 762
    move-result-object v0

    .line 763
    if-eqz v0, :cond_27

    .line 764
    .line 765
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getCanCredit()Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;

    .line 766
    .line 767
    .line 768
    move-result-object v0

    .line 769
    if-eqz v0, :cond_27

    .line 770
    .line 771
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;->getMsg()Ljava/lang/String;

    .line 772
    .line 773
    .line 774
    move-result-object v0

    .line 775
    goto :goto_14

    .line 776
    :cond_27
    move-object v0, v1

    .line 777
    :goto_14
    const-string v5, "startBorrow preCheck >>> toast "

    .line 778
    .line 779
    invoke-static {v5, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 780
    .line 781
    .line 782
    move-result-object v0

    .line 783
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 784
    .line 785
    .line 786
    move-result-object v0

    .line 787
    invoke-static {v2, v4, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 788
    .line 789
    .line 790
    invoke-static {p1, v8}, LEb/b;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 791
    .line 792
    .line 793
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 794
    .line 795
    .line 796
    move-result-object p1

    .line 797
    if-eqz p1, :cond_28

    .line 798
    .line 799
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getCanCredit()Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;

    .line 800
    .line 801
    .line 802
    move-result-object p1

    .line 803
    if-eqz p1, :cond_28

    .line 804
    .line 805
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/CanCredit;->getMsg()Ljava/lang/String;

    .line 806
    .line 807
    .line 808
    move-result-object v1

    .line 809
    :cond_28
    invoke-static {v1}, Landroidx/camera/core/impl/utils/n;->u(Ljava/lang/CharSequence;)V

    .line 810
    .line 811
    .line 812
    return-void

    .line 813
    :cond_29
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 814
    .line 815
    .line 816
    throw v1

    .line 817
    :cond_2a
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 818
    .line 819
    .line 820
    move-result-object p1

    .line 821
    if-eqz p1, :cond_2b

    .line 822
    .line 823
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getLoanPreCheck()Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;

    .line 824
    .line 825
    .line 826
    move-result-object p1

    .line 827
    if-eqz p1, :cond_2b

    .line 828
    .line 829
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;->getNeedRoute()Ljava/lang/Boolean;

    .line 830
    .line 831
    .line 832
    move-result-object p1

    .line 833
    sget-object v9, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 834
    .line 835
    invoke-static {p1, v9}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 836
    .line 837
    .line 838
    move-result p1

    .line 839
    goto :goto_15

    .line 840
    :cond_2b
    move p1, v5

    .line 841
    :goto_15
    const-string v9, "success"

    .line 842
    .line 843
    if-eqz p1, :cond_36

    .line 844
    .line 845
    const-string p1, "startBorrow preCheck branch >>> NEED_ROUTE_START_APPLY"

    .line 846
    .line 847
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 848
    .line 849
    .line 850
    move-result-object p1

    .line 851
    invoke-static {v2, v4, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 852
    .line 853
    .line 854
    invoke-static {v9, v8}, LEb/b;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 855
    .line 856
    .line 857
    iget-object p1, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 858
    .line 859
    if-eqz p1, :cond_35

    .line 860
    .line 861
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 862
    .line 863
    .line 864
    move-result-object p1

    .line 865
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 866
    .line 867
    if-eqz p1, :cond_3b

    .line 868
    .line 869
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithdrawPreCheckResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;

    .line 870
    .line 871
    .line 872
    move-result-object v3

    .line 873
    if-eqz v3, :cond_2c

    .line 874
    .line 875
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/QueryWithDrawData;->getLoanPreCheck()Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;

    .line 876
    .line 877
    .line 878
    move-result-object v3

    .line 879
    if-eqz v3, :cond_2c

    .line 880
    .line 881
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/LoanPreCheck;->getSignList()Ljava/util/List;

    .line 882
    .line 883
    .line 884
    move-result-object v3

    .line 885
    goto :goto_16

    .line 886
    :cond_2c
    move-object v3, v1

    .line 887
    :goto_16
    const-string v6, "needSignedSilentProtocol >>>"

    .line 888
    .line 889
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 890
    .line 891
    .line 892
    move-result-object v6

    .line 893
    invoke-static {v2, v4, v6}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 894
    .line 895
    .line 896
    if-eqz v3, :cond_2d

    .line 897
    .line 898
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 899
    .line 900
    .line 901
    move-result v2

    .line 902
    if-nez v2, :cond_2d

    .line 903
    .line 904
    goto :goto_18

    .line 905
    :cond_2d
    if-eqz v3, :cond_32

    .line 906
    .line 907
    check-cast v3, Ljava/lang/Iterable;

    .line 908
    .line 909
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 910
    .line 911
    .line 912
    move-result-object v2

    .line 913
    :cond_2e
    :goto_17
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 914
    .line 915
    .line 916
    move-result v3

    .line 917
    if-eqz v3, :cond_31

    .line 918
    .line 919
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 920
    .line 921
    .line 922
    move-result-object v3

    .line 923
    move-object v4, v3

    .line 924
    check-cast v4, Lcom/transsnet/palmpay/credit/bean/resp/SignItem;

    .line 925
    .line 926
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/SignItem;->getSignType()Ljava/lang/Integer;

    .line 927
    .line 928
    .line 929
    move-result-object v6

    .line 930
    if-nez v6, :cond_2f

    .line 931
    .line 932
    goto :goto_17

    .line 933
    :cond_2f
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 934
    .line 935
    .line 936
    move-result v6

    .line 937
    if-nez v6, :cond_2e

    .line 938
    .line 939
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/resp/SignItem;->getSignStatus()Ljava/lang/Integer;

    .line 940
    .line 941
    .line 942
    move-result-object v4

    .line 943
    if-nez v4, :cond_30

    .line 944
    .line 945
    goto :goto_17

    .line 946
    :cond_30
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 947
    .line 948
    .line 949
    move-result v4

    .line 950
    if-ne v4, v7, :cond_2e

    .line 951
    .line 952
    move-object v1, v3

    .line 953
    :cond_31
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/SignItem;

    .line 954
    .line 955
    :cond_32
    if-eqz v1, :cond_33

    .line 956
    .line 957
    move v5, v7

    .line 958
    :cond_33
    :goto_18
    if-eqz v5, :cond_34

    .line 959
    .line 960
    :goto_19
    move v4, v7

    .line 961
    goto :goto_1a

    .line 962
    :cond_34
    const/4 v7, 0x2

    .line 963
    goto :goto_19

    .line 964
    :goto_1a
    const/4 v2, 0x0

    .line 965
    const/16 v6, 0x12

    .line 966
    .line 967
    const-string v3, "LOAN_WITHDRAW"

    .line 968
    .line 969
    const/4 v5, 0x0

    .line 970
    move-object v1, p1

    .line 971
    invoke-static/range {v0 .. v6}, Ljb/o;->z(Ljb/o;Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;I)V

    .line 972
    .line 973
    .line 974
    return-void

    .line 975
    :cond_35
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 976
    .line 977
    .line 978
    throw v1

    .line 979
    :cond_36
    invoke-static {v9, v8}, LEb/b;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 980
    .line 981
    .line 982
    iget-object p1, v0, Ljb/o;->i:Ljava/lang/String;

    .line 983
    .line 984
    iget-object v1, p0, Ljb/n;->i:Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;

    .line 985
    .line 986
    if-eqz v1, :cond_37

    .line 987
    .line 988
    move v5, v7

    .line 989
    :cond_37
    new-instance v3, Ljava/lang/StringBuilder;

    .line 990
    .line 991
    const-string v6, "startBorrow preCheck branch >>> TRIAL_NAV (borrowRoutePath="

    .line 992
    .line 993
    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 994
    .line 995
    .line 996
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 997
    .line 998
    .line 999
    const-string p1, ", jumpLinkInfo="

    .line 1000
    .line 1001
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1002
    .line 1003
    .line 1004
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 1005
    .line 1006
    .line 1007
    const-string p1, ")"

    .line 1008
    .line 1009
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1010
    .line 1011
    .line 1012
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1013
    .line 1014
    .line 1015
    move-result-object p1

    .line 1016
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 1017
    .line 1018
    .line 1019
    move-result-object p1

    .line 1020
    invoke-static {v2, v4, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1021
    .line 1022
    .line 1023
    invoke-virtual {v0, v1}, Ljb/o;->e(Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;)V

    .line 1024
    .line 1025
    .line 1026
    return-void

    .line 1027
    :cond_38
    if-eqz p1, :cond_39

    .line 1028
    .line 1029
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 1030
    .line 1031
    .line 1032
    move-result-object v3

    .line 1033
    goto :goto_1b

    .line 1034
    :cond_39
    move-object v3, v1

    .line 1035
    :goto_1b
    const-string v4, "startBorrow preCheck empty/invalid data >>> respMsg="

    .line 1036
    .line 1037
    invoke-static {v4, v3}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1038
    .line 1039
    .line 1040
    move-result-object v3

    .line 1041
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v3

    .line 1045
    invoke-static {v2, v3}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1046
    .line 1047
    .line 1048
    if-eqz p1, :cond_3b

    .line 1049
    .line 1050
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 1051
    .line 1052
    .line 1053
    move-result-object p1

    .line 1054
    if-eqz p1, :cond_3b

    .line 1055
    .line 1056
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1057
    .line 1058
    .line 1059
    move-result v2

    .line 1060
    if-nez v2, :cond_3a

    .line 1061
    .line 1062
    move-object v1, p1

    .line 1063
    :cond_3a
    if-eqz v1, :cond_3b

    .line 1064
    .line 1065
    invoke-static {v0, v1}, Ljb/o;->b(Ljb/o;Ljava/lang/String;)V

    .line 1066
    .line 1067
    .line 1068
    :cond_3b
    :goto_1c
    return-void
.end method
