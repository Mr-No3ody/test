.class public final Ljb/f;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:Ljb/g;

.field public final synthetic g:Landroidx/fragment/app/Fragment;


# direct methods
.method public constructor <init>(Ljb/g;Landroidx/fragment/app/Fragment;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ljb/f;->f:Ljb/g;

    .line 5
    .line 6
    iput-object p2, p0, Ljb/f;->g:Landroidx/fragment/app/Fragment;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Ljb/f;->f:Ljb/g;

    .line 7
    .line 8
    invoke-static {v0, p1}, Ljb/g;->a(Ljb/g;Lio/reactivex/disposables/Disposable;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final w(Ljava/lang/String;)V
    .locals 2

    .line 1
    const-string v0, "message"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Ljb/f;->f:Ljb/g;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1}, Ljb/g;->k(Z)V

    .line 10
    .line 11
    .line 12
    new-array v0, v1, [Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    new-instance p1, Lorg/json/JSONObject;

    .line 18
    .line 19
    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    const/4 v0, 0x0

    .line 27
    const-string v1, "GET_ROUTE_LIST_FINISH"

    .line 28
    .line 29
    invoke-static {v1, p1, v0}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 12

    .line 1
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;

    .line 2
    .line 3
    iget-object v0, p0, Ljb/f;->f:Ljb/g;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Ljb/g;->k(Z)V

    .line 7
    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz p1, :cond_10

    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    const/4 v4, 0x1

    .line 17
    if-ne v3, v4, :cond_10

    .line 18
    .line 19
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    if-eqz v3, :cond_10

    .line 24
    .line 25
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    if-eqz v3, :cond_0

    .line 30
    .line 31
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getCustomerTag()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    move-object v3, v2

    .line 37
    :goto_0
    iput-object v3, v0, Ljb/g;->e:Ljava/lang/String;

    .line 38
    .line 39
    iget-object v3, v0, Ljb/g;->f:Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 42
    .line 43
    .line 44
    iget-object v5, v0, Ljb/g;->g:Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 50
    .line 51
    .line 52
    move-result-object v6

    .line 53
    if-eqz v6, :cond_1

    .line 54
    .line 55
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteList()Ljava/util/List;

    .line 56
    .line 57
    .line 58
    move-result-object v6

    .line 59
    if-eqz v6, :cond_1

    .line 60
    .line 61
    check-cast v6, Ljava/util/Collection;

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_1
    new-instance v6, Ljava/util/ArrayList;

    .line 65
    .line 66
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 67
    .line 68
    .line 69
    :goto_1
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 70
    .line 71
    .line 72
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    if-eqz v5, :cond_2

    .line 77
    .line 78
    invoke-virtual {v5}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteInfoList()Ljava/util/List;

    .line 79
    .line 80
    .line 81
    move-result-object v5

    .line 82
    if-eqz v5, :cond_2

    .line 83
    .line 84
    check-cast v5, Ljava/util/Collection;

    .line 85
    .line 86
    goto :goto_2

    .line 87
    :cond_2
    new-instance v5, Ljava/util/ArrayList;

    .line 88
    .line 89
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 90
    .line 91
    .line 92
    :goto_2
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 93
    .line 94
    .line 95
    iget-object v3, v0, Ljb/g;->c:Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 96
    .line 97
    iget-object v5, p0, Ljb/f;->g:Landroidx/fragment/app/Fragment;

    .line 98
    .line 99
    const-string v6, "getChildFragmentManager(...)"

    .line 100
    .line 101
    const-string v7, "oc_permission_router"

    .line 102
    .line 103
    if-eqz v3, :cond_9

    .line 104
    .line 105
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;->getSceneType()Ljava/lang/Integer;

    .line 106
    .line 107
    .line 108
    move-result-object v3

    .line 109
    if-nez v3, :cond_3

    .line 110
    .line 111
    goto :goto_5

    .line 112
    :cond_3
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 113
    .line 114
    .line 115
    move-result v3

    .line 116
    if-ne v3, v4, :cond_9

    .line 117
    .line 118
    sget-object v3, Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog;->L:Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog$a;

    .line 119
    .line 120
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 121
    .line 122
    .line 123
    move-result-object v8

    .line 124
    if-eqz v8, :cond_7

    .line 125
    .line 126
    invoke-virtual {v8}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteInfoList()Ljava/util/List;

    .line 127
    .line 128
    .line 129
    move-result-object v8

    .line 130
    if-eqz v8, :cond_7

    .line 131
    .line 132
    check-cast v8, Ljava/lang/Iterable;

    .line 133
    .line 134
    new-instance v9, Ljava/util/ArrayList;

    .line 135
    .line 136
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 137
    .line 138
    .line 139
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 140
    .line 141
    .line 142
    move-result-object v8

    .line 143
    :cond_4
    :goto_3
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 144
    .line 145
    .line 146
    move-result v10

    .line 147
    if-eqz v10, :cond_8

    .line 148
    .line 149
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v10

    .line 153
    if-eqz v1, :cond_5

    .line 154
    .line 155
    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    goto :goto_3

    .line 159
    :cond_5
    move-object v11, v10

    .line 160
    check-cast v11, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 161
    .line 162
    if-eqz v11, :cond_6

    .line 163
    .line 164
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v11

    .line 168
    goto :goto_4

    .line 169
    :cond_6
    move-object v11, v2

    .line 170
    :goto_4
    invoke-static {v7, v11}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 171
    .line 172
    .line 173
    move-result v11

    .line 174
    if-nez v11, :cond_4

    .line 175
    .line 176
    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 177
    .line 178
    .line 179
    move v1, v4

    .line 180
    goto :goto_3

    .line 181
    :cond_7
    move-object v9, v2

    .line 182
    :cond_8
    new-instance v1, LHb/A;

    .line 183
    .line 184
    const/16 v4, 0xa

    .line 185
    .line 186
    invoke-direct {v1, v0, v4, v5, p1}, LHb/A;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v3, v9, v1}, Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog$a;->newInstance(Ljava/util/List;Lkotlin/jvm/functions/Function0;)Lcom/transsnet/palmpay/credit/ui/dialog/CLVerifyPalmPayAccountDialog;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    invoke-virtual {v5}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/Z;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    const-string v1, "showVerifyPalmPayAccountDialog"

    .line 201
    .line 202
    invoke-virtual {p1, v0, v1}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 203
    .line 204
    .line 205
    goto/16 :goto_a

    .line 206
    .line 207
    :cond_9
    :goto_5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 208
    .line 209
    .line 210
    move-result-object v3

    .line 211
    if-eqz v3, :cond_a

    .line 212
    .line 213
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteList()Ljava/util/List;

    .line 214
    .line 215
    .line 216
    move-result-object v3

    .line 217
    goto :goto_6

    .line 218
    :cond_a
    move-object v3, v2

    .line 219
    :goto_6
    check-cast v3, Ljava/util/Collection;

    .line 220
    .line 221
    if-eqz v3, :cond_d

    .line 222
    .line 223
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 224
    .line 225
    .line 226
    move-result v3

    .line 227
    if-eqz v3, :cond_b

    .line 228
    .line 229
    goto :goto_8

    .line 230
    :cond_b
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 231
    .line 232
    .line 233
    move-result-object v3

    .line 234
    if-eqz v3, :cond_c

    .line 235
    .line 236
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteList()Ljava/util/List;

    .line 237
    .line 238
    .line 239
    move-result-object v3

    .line 240
    if-eqz v3, :cond_c

    .line 241
    .line 242
    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v3

    .line 246
    check-cast v3, Ljava/lang/String;

    .line 247
    .line 248
    goto :goto_7

    .line 249
    :cond_c
    move-object v3, v2

    .line 250
    :goto_7
    invoke-static {v3, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 251
    .line 252
    .line 253
    move-result v3

    .line 254
    if-eqz v3, :cond_e

    .line 255
    .line 256
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 257
    .line 258
    .line 259
    move-result-object v3

    .line 260
    if-eqz v3, :cond_e

    .line 261
    .line 262
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteList()Ljava/util/List;

    .line 263
    .line 264
    .line 265
    move-result-object v3

    .line 266
    if-eqz v3, :cond_e

    .line 267
    .line 268
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 269
    .line 270
    .line 271
    move-result v3

    .line 272
    if-ne v3, v4, :cond_e

    .line 273
    .line 274
    :cond_d
    :goto_8
    move v1, v4

    .line 275
    :cond_e
    iget-object v3, v0, Ljb/g;->b:Ljava/lang/String;

    .line 276
    .line 277
    const-string v7, "LOAN_WITHDRAW"

    .line 278
    .line 279
    invoke-static {v3, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 280
    .line 281
    .line 282
    move-result v3

    .line 283
    if-eqz v3, :cond_f

    .line 284
    .line 285
    if-nez v1, :cond_f

    .line 286
    .line 287
    sget-object v1, Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment;->M:Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment$a;

    .line 288
    .line 289
    invoke-static {v1, v2, v4, v2}, Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment$a;->newInstance$default(Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment$a;Ljava/lang/String;ILjava/lang/Object;)Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment;

    .line 290
    .line 291
    .line 292
    move-result-object v1

    .line 293
    new-instance v3, LHb/L;

    .line 294
    .line 295
    const/16 v4, 0x14

    .line 296
    .line 297
    invoke-direct {v3, v4, v0, p1}, LHb/L;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 298
    .line 299
    .line 300
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 301
    .line 302
    .line 303
    const-string p1, "countDownFinished"

    .line 304
    .line 305
    invoke-static {v3, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    iput-object v3, v1, Lcom/transsnet/palmpay/credit/ui/dialog/CLFillYourInformationDialogFragment;->H:Lkotlin/jvm/functions/Function0;

    .line 309
    .line 310
    invoke-virtual {v5}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/Z;

    .line 311
    .line 312
    .line 313
    move-result-object p1

    .line 314
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 315
    .line 316
    .line 317
    const-string v0, "showFillYourInformationDialog"

    .line 318
    .line 319
    invoke-virtual {v1, p1, v0}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    goto :goto_a

    .line 323
    :cond_f
    invoke-static {v0, p1}, Ljb/g;->b(Ljb/g;Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;)V

    .line 324
    .line 325
    .line 326
    goto :goto_a

    .line 327
    :cond_10
    invoke-virtual {v0, v1}, Ljb/g;->k(Z)V

    .line 328
    .line 329
    .line 330
    if-eqz p1, :cond_11

    .line 331
    .line 332
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 333
    .line 334
    .line 335
    move-result-object p1

    .line 336
    goto :goto_9

    .line 337
    :cond_11
    move-object p1, v2

    .line 338
    :goto_9
    new-array v0, v1, [Ljava/lang/Object;

    .line 339
    .line 340
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 341
    .line 342
    .line 343
    :goto_a
    new-instance p1, Lorg/json/JSONObject;

    .line 344
    .line 345
    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    .line 346
    .line 347
    .line 348
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object p1

    .line 352
    const-string v0, "GET_ROUTE_LIST_FINISH"

    .line 353
    .line 354
    invoke-static {v0, p1, v2}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 355
    .line 356
    .line 357
    return-void
.end method
