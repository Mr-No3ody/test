.class public final Ljb/r;
.super LZ4/e;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljb/t;


# direct methods
.method public synthetic constructor <init>(Ljb/t;I)V
    .locals 0

    .line 1
    iput p2, p0, Ljb/r;->f:I

    iput-object p1, p0, Ljb/r;->g:Ljb/t;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onSubscribe(Lio/reactivex/disposables/Disposable;)V
    .locals 1

    .line 1
    iget v0, p0, Ljb/r;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "d"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Ljb/r;->g:Ljb/t;

    .line 12
    .line 13
    iget-object v0, v0, Ljb/t;->a:Lxf/t;

    .line 14
    .line 15
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lgf/a;

    .line 20
    .line 21
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :pswitch_0
    const-string v0, "d"

    .line 26
    .line 27
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    iget-object v0, p0, Ljb/r;->g:Ljb/t;

    .line 31
    .line 32
    iget-object v0, v0, Ljb/t;->a:Lxf/t;

    .line 33
    .line 34
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Lgf/a;

    .line 39
    .line 40
    invoke-virtual {v0, p1}, Lgf/a;->add(Lio/reactivex/disposables/Disposable;)Z

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    nop

    .line 45
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final w(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget v0, p0, Ljb/r;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    if-eqz p1, :cond_1

    .line 7
    .line 8
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    move-object v0, p1

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 v0, 0x0

    .line 17
    :goto_0
    if-eqz v0, :cond_1

    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    new-array v0, v0, [Ljava/lang/Object;

    .line 21
    .line 22
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showShort(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    :cond_1
    return-void

    .line 26
    :pswitch_0
    if-eqz p1, :cond_3

    .line 27
    .line 28
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_2

    .line 33
    .line 34
    move-object v0, p1

    .line 35
    goto :goto_1

    .line 36
    :cond_2
    const/4 v0, 0x0

    .line 37
    :goto_1
    if-eqz v0, :cond_3

    .line 38
    .line 39
    const/4 v0, 0x0

    .line 40
    new-array v0, v0, [Ljava/lang/Object;

    .line 41
    .line 42
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_3
    return-void

    .line 46
    nop

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 7

    .line 1
    iget v0, p0, Ljb/r;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcSkipOneLoopResp;

    .line 7
    .line 8
    if-eqz p1, :cond_2

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v1, 0x0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object p1, v1

    .line 19
    :goto_0
    if-eqz p1, :cond_2

    .line 20
    .line 21
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcSkipOneLoopResp;->getData()Ljava/lang/Boolean;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 26
    .line 27
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_1

    .line 32
    .line 33
    const-string p1, "OneLoopAct"

    .line 34
    .line 35
    invoke-static {v1, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    iget-object p1, p0, Ljb/r;->g:Ljb/t;

    .line 40
    .line 41
    invoke-virtual {p1}, Ljb/t;->d()V

    .line 42
    .line 43
    .line 44
    :cond_2
    :goto_1
    return-void

    .line 45
    :pswitch_0
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopDataResp;

    .line 46
    .line 47
    if-eqz p1, :cond_5

    .line 48
    .line 49
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    const/4 v1, 0x0

    .line 54
    if-eqz v0, :cond_3

    .line 55
    .line 56
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopDataResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopData;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    if-eqz v0, :cond_3

    .line 61
    .line 62
    move-object v0, p1

    .line 63
    goto :goto_2

    .line 64
    :cond_3
    move-object v0, v1

    .line 65
    :goto_2
    if-eqz v0, :cond_5

    .line 66
    .line 67
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopDataResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopData;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    iget-object v0, p0, Ljb/r;->g:Ljb/t;

    .line 72
    .line 73
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 74
    .line 75
    .line 76
    const-string v2, "routerOneLoop >>>"

    .line 77
    .line 78
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    const/4 v3, 0x3

    .line 83
    const-string v4, "CreditRouterManagerV2"

    .line 84
    .line 85
    invoke-static {v4, v3, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 89
    .line 90
    .line 91
    move-result-object v2

    .line 92
    if-eqz v2, :cond_5

    .line 93
    .line 94
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 95
    .line 96
    .line 97
    move-result-object v3

    .line 98
    sget v4, Lba/k;->core_one_loop_secret_key:I

    .line 99
    .line 100
    invoke-virtual {v2, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    sget v5, Lba/k;->core_one_loop_env:I

    .line 105
    .line 106
    invoke-virtual {v2, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v5

    .line 110
    const-string v6, "getString(...)"

    .line 111
    .line 112
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 116
    .line 117
    .line 118
    move-result v5

    .line 119
    invoke-static {v3, v4, v5}, Lcom/transsnet/mtn/sdk/MTN;->init(Landroid/content/Context;Ljava/lang/String;I)V

    .line 120
    .line 121
    .line 122
    new-instance v3, Lcom/transsnet/mtn/sdk/config/Configuration;

    .line 123
    .line 124
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 125
    .line 126
    .line 127
    if-eqz p1, :cond_4

    .line 128
    .line 129
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/OcOneLoopData;->getId()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    :cond_4
    iput-object v1, v3, Lcom/transsnet/mtn/sdk/config/Configuration;->auth_id:Ljava/lang/String;

    .line 134
    .line 135
    const-string p1, "100016"

    .line 136
    .line 137
    iput-object p1, v3, Lcom/transsnet/mtn/sdk/config/Configuration;->mtn_id:Ljava/lang/String;

    .line 138
    .line 139
    const-string p1, ""

    .line 140
    .line 141
    iput-object p1, v3, Lcom/transsnet/mtn/sdk/config/Configuration;->phone:Ljava/lang/String;

    .line 142
    .line 143
    iput-object p1, v3, Lcom/transsnet/mtn/sdk/config/Configuration;->agreeUrl:Ljava/lang/String;

    .line 144
    .line 145
    new-instance p1, Landroidx/work/impl/model/b;

    .line 146
    .line 147
    const/16 v1, 0xd

    .line 148
    .line 149
    invoke-direct {p1, v1, v0, v2}, Landroidx/work/impl/model/b;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    invoke-static {v3, p1}, Lcom/transsnet/mtn/sdk/MTN;->start(Lcom/transsnet/mtn/sdk/config/Configuration;Lcom/transsnet/mtn/sdk/util/MTNHandler;)V

    .line 153
    .line 154
    .line 155
    :cond_5
    return-void

    .line 156
    nop

    .line 157
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
