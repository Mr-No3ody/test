.class public final Ljb/o;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final A:Ljb/o;

.field public static final B:[Ljava/lang/String;

.field public static final z:Ljb/j;


# instance fields
.field public final a:Lxf/t;

.field public b:Ljava/lang/ref/WeakReference;

.field public c:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

.field public d:Ljava/util/List;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/Integer;

.field public g:Ljava/lang/Integer;

.field public h:Ljava/lang/Integer;

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;

.field public k:Ljava/lang/String;

.field public l:Ljava/lang/String;

.field public m:I

.field public final n:Ljava/lang/Boolean;

.field public o:Ljava/lang/Boolean;

.field public p:I

.field public q:Ljava/lang/String;

.field public r:Ljava/lang/String;

.field public s:Ljava/lang/String;

.field public t:Z

.field public u:Lcom/transsnet/palmpay/custom_view/dialog/LoadingDialog;

.field public v:Z

.field public w:J

.field public x:Ljava/lang/String;

.field public y:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ljb/j;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Ljb/j;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Ljb/o;->z:Ljb/j;

    .line 8
    .line 9
    sget-object v0, Ljb/k;->a:Ljb/o;

    .line 10
    .line 11
    sget-object v0, Ljb/k;->a:Ljb/o;

    .line 12
    .line 13
    sput-object v0, Ljb/o;->A:Ljb/o;

    .line 14
    .line 15
    const-string v0, "FB_OPEN_ACCOUNT_NOT_ALLOW_PP"

    .line 16
    .line 17
    const-string v1, "FB_OPEN_ACCOUNT_NOT_ALLOW_PP_EXIST"

    .line 18
    .line 19
    const-string v2, "FB_OPEN_ACCOUNT_NOT_ALLOW"

    .line 20
    .line 21
    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, Ljb/o;->B:[Ljava/lang/String;

    .line 26
    .line 27
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Lorg/greenrobot/eventbus/c;->b()Lorg/greenrobot/eventbus/c;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0, p0}, Lorg/greenrobot/eventbus/c;->j(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, Lcom/transsnet/palmpay/managemoney/ui/view/c;

    .line 12
    .line 13
    const/16 v1, 0x1a

    .line 14
    .line 15
    invoke-direct {v0, v1}, Lcom/transsnet/palmpay/managemoney/ui/view/c;-><init>(I)V

    .line 16
    .line 17
    .line 18
    invoke-static {v0}, Lxf/j;->b(Lkotlin/jvm/functions/Function0;)Lxf/t;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iput-object v0, p0, Ljb/o;->a:Lxf/t;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, Ljb/o;->f:Ljava/lang/Integer;

    .line 30
    .line 31
    const/4 v0, -0x1

    .line 32
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    iput-object v1, p0, Ljb/o;->g:Ljava/lang/Integer;

    .line 37
    .line 38
    iput v0, p0, Ljb/o;->m:I

    .line 39
    .line 40
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 41
    .line 42
    iput-object v1, p0, Ljb/o;->n:Ljava/lang/Boolean;

    .line 43
    .line 44
    iput-object v1, p0, Ljb/o;->o:Ljava/lang/Boolean;

    .line 45
    .line 46
    iput v0, p0, Ljb/o;->p:I

    .line 47
    .line 48
    return-void
.end method

.method public static final a(Ljb/o;Lcom/transsnet/palmpay/credit/bean/resp/CLOpenAccountData;Ljava/lang/Boolean;)V
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Ljb/o;->v:Z

    .line 3
    .line 4
    new-instance v1, Ljava/lang/StringBuilder;

    .line 5
    .line 6
    const-string v2, "gotoApplyResultPage >>> data="

    .line 7
    .line 8
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    const-string v2, ", raiseAmount="

    .line 15
    .line 16
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    const/4 v2, 0x3

    .line 31
    const-string v3, "CreditRouterManager"

    .line 32
    .line 33
    invoke-static {v3, v2, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Ljb/o;->g:Ljava/lang/Integer;

    .line 37
    .line 38
    if-nez v1, :cond_0

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-ne v1, v0, :cond_1

    .line 46
    .line 47
    const/4 p0, 0x0

    .line 48
    const-string p1, "CreditBindSuccess"

    .line 49
    .line 50
    invoke-static {p0, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :cond_1
    :goto_0
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 55
    .line 56
    const-string v1, "PALMPAY_CARD"

    .line 57
    .line 58
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_4

    .line 63
    .line 64
    iget-object p1, p0, Ljb/o;->s:Ljava/lang/String;

    .line 65
    .line 66
    const-string p2, "gotoApplyResultPage >>> pendingUrl="

    .line 67
    .line 68
    invoke-static {p2, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    invoke-static {v3, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    iget-object p1, p0, Ljb/o;->e:Ljava/lang/String;

    .line 80
    .line 81
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-nez p1, :cond_3

    .line 86
    .line 87
    iget-object p1, p0, Ljb/o;->s:Ljava/lang/String;

    .line 88
    .line 89
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 90
    .line 91
    .line 92
    move-result p1

    .line 93
    if-eqz p1, :cond_2

    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_2
    iget-object p1, p0, Ljb/o;->s:Ljava/lang/String;

    .line 97
    .line 98
    invoke-static {p1}, Lcom/transsnet/palmpay/core/config/d;->g(Ljava/lang/String;)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    iget-object p0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 103
    .line 104
    new-instance p2, Ljava/lang/StringBuilder;

    .line 105
    .line 106
    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    .line 107
    .line 108
    .line 109
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    const-string p1, "&applyId="

    .line 113
    .line 114
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object p0

    .line 124
    invoke-static {p0}, LPa/i0;->c0(Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    invoke-static {}, Ljb/o;->d()V

    .line 128
    .line 129
    .line 130
    return-void

    .line 131
    :cond_3
    :goto_1
    iget-object p1, p0, Ljb/o;->e:Ljava/lang/String;

    .line 132
    .line 133
    iget-object p0, p0, Ljb/o;->s:Ljava/lang/String;

    .line 134
    .line 135
    const-string p2, "Service error, applyId="

    .line 136
    .line 137
    const-string v0, ", pendingUrl="

    .line 138
    .line 139
    invoke-static {p2, p1, v0, p0}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object p0

    .line 143
    const/4 p1, 0x0

    .line 144
    new-array p1, p1, [Ljava/lang/Object;

    .line 145
    .line 146
    invoke-static {p0, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 147
    .line 148
    .line 149
    return-void

    .line 150
    :cond_4
    new-instance v0, Landroid/os/Bundle;

    .line 151
    .line 152
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 153
    .line 154
    .line 155
    const-string v1, "creditApplyId"

    .line 156
    .line 157
    iget-object v2, p0, Ljb/o;->e:Ljava/lang/String;

    .line 158
    .line 159
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    const-string v1, "loanProduct"

    .line 163
    .line 164
    iget-object v2, p0, Ljb/o;->k:Ljava/lang/String;

    .line 165
    .line 166
    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    iget-object v1, v1, LPa/w;->b:Ljava/lang/Object;

    .line 174
    .line 175
    check-cast v1, Lcom/google/gson/Gson;

    .line 176
    .line 177
    invoke-virtual {v1, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v1

    .line 181
    const-string v2, "submitData"

    .line 182
    .line 183
    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 187
    .line 188
    .line 189
    move-result-object v1

    .line 190
    iget-object v1, v1, LPa/w;->b:Ljava/lang/Object;

    .line 191
    .line 192
    check-cast v1, Lcom/google/gson/Gson;

    .line 193
    .line 194
    invoke-virtual {v1, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    const-string v1, "raiseAmountData"

    .line 199
    .line 200
    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 201
    .line 202
    .line 203
    const-string p1, "successUrl"

    .line 204
    .line 205
    iget-object v1, p0, Ljb/o;->r:Ljava/lang/String;

    .line 206
    .line 207
    invoke-virtual {v0, p1, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    const-string p1, "errorUrl"

    .line 211
    .line 212
    iget-object v1, p0, Ljb/o;->q:Ljava/lang/String;

    .line 213
    .line 214
    invoke-virtual {v0, p1, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    const-string p1, "pendingUrl"

    .line 218
    .line 219
    iget-object p0, p0, Ljb/o;->s:Ljava/lang/String;

    .line 220
    .line 221
    invoke-virtual {v0, p1, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 225
    .line 226
    .line 227
    move-result p0

    .line 228
    const-string p1, "raiseAmount"

    .line 229
    .line 230
    invoke-virtual {v0, p1, p0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 231
    .line 232
    .line 233
    const-string p0, "LoanCreditResult"

    .line 234
    .line 235
    invoke-static {v0, p0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    return-void
.end method

.method public static final b(Ljb/o;Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const-string p0, "showBusinessFailedDialog >>>"

    .line 5
    .line 6
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    const/4 v0, 0x3

    .line 11
    const-string v1, "CreditRouterManager"

    .line 12
    .line 13
    invoke-static {v1, v0, p0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    if-nez p0, :cond_0

    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    new-instance v0, LO6/c;

    .line 24
    .line 25
    invoke-direct {v0, p0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 26
    .line 27
    .line 28
    sget v1, LL6/i;->ppFlexiCashDialogTheme:I

    .line 29
    .line 30
    iput v1, v0, LO6/c;->v:I

    .line 31
    .line 32
    sget v1, LYa/d;->cs_cl_failed:I

    .line 33
    .line 34
    iput v1, v0, LO6/c;->m:I

    .line 35
    .line 36
    iput-object p1, v0, LO6/c;->d:Ljava/lang/CharSequence;

    .line 37
    .line 38
    sget p1, LYa/g;->cs_confirm:I

    .line 39
    .line 40
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    iput-object p0, v0, LO6/c;->f:Ljava/lang/String;

    .line 45
    .line 46
    const/4 p0, 0x0

    .line 47
    iput-object p0, v0, LO6/c;->h:Landroid/view/View$OnClickListener;

    .line 48
    .line 49
    invoke-virtual {v0}, LO6/c;->a()LO6/d;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    invoke-virtual {p0}, LO6/d;->show()V

    .line 54
    .line 55
    .line 56
    return-void
.end method

.method public static d()V
    .locals 6

    .line 1
    const-string v0, "closeAllRoutePage >>>"

    .line 2
    .line 3
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x3

    .line 8
    const-string v2, "CreditRouterManager"

    .line 9
    .line 10
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    :try_start_0
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 14
    .line 15
    const-class v0, Lcom/transsnet/palmpay/ui/activity/HomeActivity;

    .line 16
    .line 17
    sget-object v1, Lcom/transsnet/palmpay/ui/activity/HomeActivity;->H:Lcom/transsnet/palmpay/ui/activity/HomeActivity$a;

    .line 18
    .line 19
    invoke-static {}, Lcom/transsnet/palmpay/util/Utils;->getActivityList()Ljava/util/LinkedList;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const-string v3, "getActivityList(...)"

    .line 24
    .line 25
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    add-int/lit8 v3, v3, -0x1

    .line 33
    .line 34
    if-ltz v3, :cond_2

    .line 35
    .line 36
    :goto_0
    add-int/lit8 v4, v3, -0x1

    .line 37
    .line 38
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    check-cast v3, Landroid/app/Activity;

    .line 43
    .line 44
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    invoke-virtual {v5, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    if-eqz v5, :cond_0

    .line 53
    .line 54
    goto :goto_4

    .line 55
    :cond_0
    const/4 v5, 0x1

    .line 56
    invoke-static {v3, v5}, Lcom/transsnet/palmpay/util/ActivityUtils;->finishActivity(Landroid/app/Activity;Z)V

    .line 57
    .line 58
    .line 59
    if-gez v4, :cond_1

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_1
    move v3, v4

    .line 63
    goto :goto_0

    .line 64
    :catchall_0
    move-exception v0

    .line 65
    goto :goto_2

    .line 66
    :cond_2
    :goto_1
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 67
    .line 68
    goto :goto_3

    .line 69
    :goto_2
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 70
    .line 71
    invoke-static {v0}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    :goto_3
    invoke-static {v0}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    if-eqz v0, :cond_3

    .line 80
    .line 81
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-static {v2, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    :cond_3
    :goto_4
    return-void
.end method

.method public static g()I
    .locals 3

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "getContext(...)"

    .line 6
    .line 7
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v1, "context"

    .line 11
    .line 12
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getInstalledPackages(I)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 v0, 0x0

    .line 28
    :goto_0
    move-object v2, v0

    .line 29
    check-cast v2, Ljava/util/Collection;

    .line 30
    .line 31
    if-eqz v2, :cond_2

    .line 32
    .line 33
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_1

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_1
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 41
    .line 42
    .line 43
    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 44
    return v0

    .line 45
    :catch_0
    :cond_2
    :goto_1
    return v1
.end method

.method public static h()I
    .locals 4

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->get()Lcom/transsnet/palmpay/util/SPUtils;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "credit_bind_times"

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/util/SPUtils;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    const-string v1, "_"

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-static {v0, v1, v2}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    if-eqz v3, :cond_0

    .line 22
    .line 23
    invoke-static {v0, v1}, Landroid/text/TextUtils;->split(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const/4 v1, 0x1

    .line 28
    aget-object v0, v0, v1

    .line 29
    .line 30
    invoke-static {v0}, LPa/E;->b(Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    return v0

    .line 35
    :cond_0
    return v2
.end method

.method public static u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ldf/d;
    .locals 11

    .line 1
    const-string v0, "routerListObservable >>> "

    .line 2
    .line 3
    const-string v1, ", "

    .line 4
    .line 5
    invoke-static {v0, p0, v1, p1, v1}, Landroidx/camera/camera2/internal/F;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const/4 v1, 0x3

    .line 21
    const-string v2, "CreditRouterManager"

    .line 22
    .line 23
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    sget-object v0, Lob/c;->a:Lob/a;

    .line 27
    .line 28
    invoke-static {v0}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    new-instance v1, Lcom/transsnet/palmpay/credit/bean/req/OcRouterReq;

    .line 33
    .line 34
    const-string v2, "CASH_INSTALLMENT_RAISE_AMOUNT"

    .line 35
    .line 36
    invoke-static {p0, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 41
    .line 42
    .line 43
    move-result-object v6

    .line 44
    const/4 v4, 0x0

    .line 45
    const/4 v5, 0x0

    .line 46
    const/4 v2, 0x0

    .line 47
    const/16 v9, 0xd

    .line 48
    .line 49
    const/4 v10, 0x0

    .line 50
    move-object v3, p0

    .line 51
    move-object v7, p1

    .line 52
    move-object v8, p2

    .line 53
    invoke-direct/range {v1 .. v10}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterReq;-><init>(Ljava/lang/Boolean;Ljava/lang/String;ILjava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 54
    .line 55
    .line 56
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->getRouterList(Lcom/transsnet/palmpay/credit/bean/req/OcRouterReq;)Ldf/d;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    return-object p0
.end method

.method public static synthetic w(Ljb/o;)V
    .locals 1

    .line 1
    iget v0, p0, Ljb/o;->m:I

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Ljb/o;->v(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public static z(Ljb/o;Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;I)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    and-int/lit8 v3, p6, 0x2

    .line 8
    .line 9
    if-eqz v3, :cond_0

    .line 10
    .line 11
    const-string v3, "OTHER"

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move-object/from16 v3, p2

    .line 15
    .line 16
    :goto_0
    and-int/lit8 v4, p6, 0x8

    .line 17
    .line 18
    const/4 v5, -0x1

    .line 19
    if-eqz v4, :cond_1

    .line 20
    .line 21
    move v4, v5

    .line 22
    goto :goto_1

    .line 23
    :cond_1
    move/from16 v4, p4

    .line 24
    .line 25
    :goto_1
    and-int/lit8 v6, p6, 0x10

    .line 26
    .line 27
    const/4 v7, 0x0

    .line 28
    if-eqz v6, :cond_2

    .line 29
    .line 30
    move-object v6, v7

    .line 31
    goto :goto_2

    .line 32
    :cond_2
    move-object/from16 v6, p5

    .line 33
    .line 34
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    const-string v8, "loanCreditFragment"

    .line 38
    .line 39
    invoke-static {v1, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    new-instance v8, Ljava/lang/StringBuilder;

    .line 43
    .line 44
    const-string v9, "startApply >>> product="

    .line 45
    .line 46
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v8

    .line 56
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v8

    .line 60
    const/4 v9, 0x3

    .line 61
    const-string v10, "CreditRouterManager"

    .line 62
    .line 63
    invoke-static {v10, v9, v8}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 67
    .line 68
    .line 69
    move-result-wide v11

    .line 70
    iget-wide v13, v0, Ljb/o;->w:J

    .line 71
    .line 72
    const-wide/16 v15, 0x0

    .line 73
    .line 74
    cmp-long v8, v13, v15

    .line 75
    .line 76
    const/4 v15, 0x0

    .line 77
    if-lez v8, :cond_3

    .line 78
    .line 79
    sub-long v13, v11, v13

    .line 80
    .line 81
    const-wide/16 v16, 0x5dc

    .line 82
    .line 83
    cmp-long v8, v13, v16

    .line 84
    .line 85
    if-gez v8, :cond_3

    .line 86
    .line 87
    const/4 v8, 0x1

    .line 88
    goto :goto_3

    .line 89
    :cond_3
    move v8, v15

    .line 90
    :goto_3
    iget-object v13, v0, Ljb/o;->k:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v2, v13}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v13

    .line 96
    if-eqz v13, :cond_4

    .line 97
    .line 98
    if-eqz v8, :cond_4

    .line 99
    .line 100
    const-string v0, "startApply >>> intercept repeat apply"

    .line 101
    .line 102
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    const/4 v1, 0x5

    .line 107
    invoke-static {v10, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :cond_4
    iput-wide v11, v0, Ljb/o;->w:J

    .line 112
    .line 113
    new-instance v8, Ljava/lang/ref/WeakReference;

    .line 114
    .line 115
    invoke-direct {v8, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    iput-object v8, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 119
    .line 120
    iput v5, v0, Ljb/o;->m:I

    .line 121
    .line 122
    iput-object v3, v0, Ljb/o;->j:Ljava/lang/String;

    .line 123
    .line 124
    iput v4, v0, Ljb/o;->p:I

    .line 125
    .line 126
    iput-object v2, v0, Ljb/o;->k:Ljava/lang/String;

    .line 127
    .line 128
    iput-object v6, v0, Ljb/o;->e:Ljava/lang/String;

    .line 129
    .line 130
    iput-boolean v15, v0, Ljb/o;->t:Z

    .line 131
    .line 132
    iput-boolean v15, v0, Ljb/o;->v:Z

    .line 133
    .line 134
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 135
    .line 136
    iput-object v1, v0, Ljb/o;->o:Ljava/lang/Boolean;

    .line 137
    .line 138
    iput-object v7, v0, Ljb/o;->d:Ljava/util/List;

    .line 139
    .line 140
    iput-object v7, v0, Ljb/o;->c:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 141
    .line 142
    iput-object v7, v0, Ljb/o;->x:Ljava/lang/String;

    .line 143
    .line 144
    iput-object v7, v0, Ljb/o;->y:Ljava/lang/String;

    .line 145
    .line 146
    const-string v1, "queryBusinessConfig >>>"

    .line 147
    .line 148
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    invoke-static {v10, v9, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    iget-object v1, v0, Ljb/o;->e:Ljava/lang/String;

    .line 156
    .line 157
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    if-eqz v1, :cond_9

    .line 162
    .line 163
    iget-object v1, v0, Ljb/o;->k:Ljava/lang/String;

    .line 164
    .line 165
    const-string v2, "LOAN_WITHDRAW"

    .line 166
    .line 167
    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 168
    .line 169
    .line 170
    move-result v1

    .line 171
    if-eqz v1, :cond_5

    .line 172
    .line 173
    move-object v14, v7

    .line 174
    goto :goto_6

    .line 175
    :cond_5
    :try_start_0
    invoke-static {}, Lface/security/device/api/FaceSecDevice;->getInstance()Lface/security/device/api/FaceSecDevice;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    invoke-virtual {v1}, Lface/security/device/api/FaceSecDevice;->getDeviceToken()Lface/security/device/api/FaceSecToken;

    .line 180
    .line 181
    .line 182
    move-result-object v1

    .line 183
    if-nez v1, :cond_7

    .line 184
    .line 185
    :catch_0
    :cond_6
    :goto_4
    move-object v1, v7

    .line 186
    goto :goto_5

    .line 187
    :cond_7
    iget v2, v1, Lface/security/device/api/FaceSecToken;->code:I

    .line 188
    .line 189
    const/16 v3, 0x2710

    .line 190
    .line 191
    if-eq v3, v2, :cond_8

    .line 192
    .line 193
    goto :goto_4

    .line 194
    :cond_8
    iget-object v1, v1, Lface/security/device/api/FaceSecToken;->token:Ljava/lang/String;

    .line 195
    .line 196
    if-eqz v1, :cond_6

    .line 197
    .line 198
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 199
    .line 200
    .line 201
    move-result v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 202
    if-lez v2, :cond_6

    .line 203
    .line 204
    :goto_5
    move-object v14, v1

    .line 205
    :goto_6
    sget-object v1, Lob/c;->a:Lob/a;

    .line 206
    .line 207
    invoke-static {v1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    new-instance v8, Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;

    .line 212
    .line 213
    iget-object v9, v0, Ljb/o;->j:Ljava/lang/String;

    .line 214
    .line 215
    iget-object v10, v0, Ljb/o;->k:Ljava/lang/String;

    .line 216
    .line 217
    const/16 v15, 0x18

    .line 218
    .line 219
    const/16 v16, 0x0

    .line 220
    .line 221
    const/4 v11, 0x2

    .line 222
    const/4 v12, 0x0

    .line 223
    const/4 v13, 0x0

    .line 224
    invoke-direct/range {v8 .. v16}, Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;-><init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 225
    .line 226
    .line 227
    invoke-interface {v1, v8}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->clInitApply(Lcom/transsnet/palmpay/credit/bean/req/CLInitReq;)Ldf/d;

    .line 228
    .line 229
    .line 230
    move-result-object v1

    .line 231
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 232
    .line 233
    .line 234
    move-result-object v2

    .line 235
    invoke-virtual {v1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    new-instance v2, Ljb/h;

    .line 240
    .line 241
    const/4 v3, 0x0

    .line 242
    invoke-direct {v2, v0, v3}, Ljb/h;-><init>(Ljb/o;I)V

    .line 243
    .line 244
    .line 245
    new-instance v3, Lj9/b;

    .line 246
    .line 247
    const/4 v4, 0x5

    .line 248
    invoke-direct {v3, v2, v4}, Lj9/b;-><init>(Ljava/lang/Object;I)V

    .line 249
    .line 250
    .line 251
    sget-object v2, Ljf/a;->d:Lretrofit2/adapter/rxjava2/d;

    .line 252
    .line 253
    sget-object v4, Ljf/a;->c:Lr2/c;

    .line 254
    .line 255
    new-instance v5, Lio/reactivex/internal/operators/observable/k;

    .line 256
    .line 257
    invoke-direct {v5, v1, v3, v2, v4}, Lio/reactivex/internal/operators/observable/k;-><init>(Ldf/d;Lio/reactivex/functions/Consumer;Lio/reactivex/functions/Consumer;Lio/reactivex/functions/Action;)V

    .line 258
    .line 259
    .line 260
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 261
    .line 262
    invoke-virtual {v5, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 263
    .line 264
    .line 265
    move-result-object v1

    .line 266
    new-instance v2, Ljb/h;

    .line 267
    .line 268
    const/4 v3, 0x1

    .line 269
    invoke-direct {v2, v0, v3}, Ljb/h;-><init>(Ljb/o;I)V

    .line 270
    .line 271
    .line 272
    new-instance v3, Lj9/b;

    .line 273
    .line 274
    const/4 v4, 0x6

    .line 275
    invoke-direct {v3, v2, v4}, Lj9/b;-><init>(Ljava/lang/Object;I)V

    .line 276
    .line 277
    .line 278
    invoke-virtual {v1, v3}, Ldf/d;->f(Lio/reactivex/functions/Function;)Ldf/d;

    .line 279
    .line 280
    .line 281
    move-result-object v1

    .line 282
    goto :goto_7

    .line 283
    :cond_9
    iget-object v1, v0, Ljb/o;->k:Ljava/lang/String;

    .line 284
    .line 285
    iget-object v2, v0, Ljb/o;->j:Ljava/lang/String;

    .line 286
    .line 287
    iget-object v3, v0, Ljb/o;->e:Ljava/lang/String;

    .line 288
    .line 289
    invoke-static {v1, v2, v3}, Ljb/o;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ldf/d;

    .line 290
    .line 291
    .line 292
    move-result-object v1

    .line 293
    :goto_7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 294
    .line 295
    .line 296
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 297
    .line 298
    invoke-virtual {v1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 299
    .line 300
    .line 301
    move-result-object v1

    .line 302
    new-instance v3, Lio/reactivex/internal/operators/observable/K;

    .line 303
    .line 304
    const/4 v4, 0x1

    .line 305
    invoke-direct {v3, v1, v2, v4}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 306
    .line 307
    .line 308
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 309
    .line 310
    .line 311
    move-result-object v1

    .line 312
    invoke-virtual {v3, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 313
    .line 314
    .line 315
    move-result-object v1

    .line 316
    iget-object v2, v0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 317
    .line 318
    if-eqz v2, :cond_a

    .line 319
    .line 320
    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v2

    .line 324
    check-cast v2, Lcom/transsnet/palmpay/core/base/BaseFragment;

    .line 325
    .line 326
    new-instance v3, Ljava/lang/ref/WeakReference;

    .line 327
    .line 328
    invoke-direct {v3, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 329
    .line 330
    .line 331
    new-instance v2, LPa/Y;

    .line 332
    .line 333
    const/4 v4, 0x0

    .line 334
    invoke-direct {v2, v3, v4}, LPa/Y;-><init>(Ljava/lang/ref/WeakReference;I)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {v1, v2}, Ldf/d;->c(Lio/reactivex/ObservableTransformer;)Ldf/d;

    .line 338
    .line 339
    .line 340
    move-result-object v1

    .line 341
    new-instance v2, Ljb/l;

    .line 342
    .line 343
    const/4 v3, 0x3

    .line 344
    invoke-direct {v2, v0, v3}, Ljb/l;-><init>(Ljb/o;I)V

    .line 345
    .line 346
    .line 347
    invoke-virtual {v1, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 348
    .line 349
    .line 350
    return-void

    .line 351
    :cond_a
    const-string v0, "mLoanCreditFragmentRef"

    .line 352
    .line 353
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    throw v7
.end method


# virtual methods
.method public final A(Ljava/lang/Integer;Ljava/lang/String;)V
    .locals 8

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "toNewBvnPage >>> curRouteId="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, ", routePath="

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const/4 v1, 0x3

    .line 28
    const-string v2, "CreditRouterManager"

    .line 29
    .line 30
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    const/4 v0, 0x0

    .line 34
    :try_start_0
    sget-object v3, Lxf/q;->a:Lxf/o;

    .line 35
    .line 36
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    iget-object v4, p0, Ljb/o;->x:Ljava/lang/String;

    .line 41
    .line 42
    const-class v5, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 43
    .line 44
    :try_start_1
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    invoke-static {v4, v5}, LPa/w;->d(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 51
    :try_start_2
    sget-object v4, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 52
    .line 53
    goto :goto_2

    .line 54
    :catchall_0
    move-exception v4

    .line 55
    goto :goto_1

    .line 56
    :catchall_1
    move-exception v3

    .line 57
    move-object v4, v3

    .line 58
    :goto_0
    move-object v3, v0

    .line 59
    goto :goto_1

    .line 60
    :catchall_2
    move-exception v4

    .line 61
    goto :goto_0

    .line 62
    :goto_1
    sget-object v5, Lxf/q;->a:Lxf/o;

    .line 63
    .line 64
    invoke-static {v4}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 65
    .line 66
    .line 67
    :goto_2
    const/4 v4, 0x0

    .line 68
    if-nez v3, :cond_0

    .line 69
    .line 70
    const-string p1, "toNewBvnPage >>> routerNode is null"

    .line 71
    .line 72
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    invoke-static {v2, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    new-array p1, v4, [Ljava/lang/Object;

    .line 80
    .line 81
    const-string p2, "Sorry, the service is unavailable now (code-3)"

    .line 82
    .line 83
    invoke-static {p2, p1}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :cond_0
    const/4 v5, 0x6

    .line 88
    const-string v6, "?"

    .line 89
    .line 90
    invoke-static {p2, v6, v4, v4, v5}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    new-instance v5, Ljava/lang/StringBuilder;

    .line 95
    .line 96
    invoke-direct {v5, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    const/4 v7, -0x1

    .line 100
    if-eq v4, v7, :cond_1

    .line 101
    .line 102
    invoke-virtual {p2, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p2

    .line 106
    const-string v4, "substring(...)"

    .line 107
    .line 108
    invoke-static {p2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    const-string p2, "&"

    .line 115
    .line 116
    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    .line 118
    .line 119
    goto :goto_3

    .line 120
    :cond_1
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 121
    .line 122
    .line 123
    :goto_3
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;

    .line 124
    .line 125
    iget-object p2, v3, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;->current:Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 126
    .line 127
    if-eqz p2, :cond_2

    .line 128
    .line 129
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 130
    .line 131
    .line 132
    move-result-object p2

    .line 133
    goto :goto_4

    .line 134
    :cond_2
    move-object p2, v0

    .line 135
    :goto_4
    new-instance v4, Ljava/lang/StringBuilder;

    .line 136
    .line 137
    const-string v6, "current="

    .line 138
    .line 139
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object p2

    .line 149
    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 150
    .line 151
    .line 152
    iget-object p2, v3, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;->prev:Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 153
    .line 154
    if-eqz p2, :cond_3

    .line 155
    .line 156
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 157
    .line 158
    .line 159
    move-result-object p2

    .line 160
    goto :goto_5

    .line 161
    :cond_3
    move-object p2, v0

    .line 162
    :goto_5
    new-instance v4, Ljava/lang/StringBuilder;

    .line 163
    .line 164
    const-string v6, "&prev="

    .line 165
    .line 166
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 170
    .line 171
    .line 172
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object p2

    .line 176
    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 177
    .line 178
    .line 179
    iget-object p2, v3, Lcom/transsnet/palmpay/credit/bean/RouterNodeInfo;->next:Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 180
    .line 181
    if-eqz p2, :cond_4

    .line 182
    .line 183
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 184
    .line 185
    .line 186
    move-result-object v0

    .line 187
    :cond_4
    new-instance p2, Ljava/lang/StringBuilder;

    .line 188
    .line 189
    const-string v3, "&next="

    .line 190
    .line 191
    invoke-direct {p2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 195
    .line 196
    .line 197
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object p2

    .line 201
    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object p2

    .line 208
    const-string v0, "toString(...)"

    .line 209
    .line 210
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    const-string v0, "toNewBvnPage >>> targetBvnUrl="

    .line 214
    .line 215
    invoke-static {v0, p2}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object v0

    .line 223
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 224
    .line 225
    .line 226
    const-string v0, "/account/upgrade"

    .line 227
    .line 228
    invoke-virtual {p0, p1, v0, p2}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    return-void
.end method

.method public final B()V
    .locals 3

    .line 1
    iget v0, p0, Ljb/o;->m:I

    .line 2
    .line 3
    add-int/lit8 v0, v0, -0x1

    .line 4
    .line 5
    iput v0, p0, Ljb/o;->m:I

    .line 6
    .line 7
    const-string v1, "\u5f53\u524d\u8def\u7531\u7d22\u5f15\u4e3a >>> "

    .line 8
    .line 9
    invoke-static {v0, v1}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const/4 v1, 0x3

    .line 18
    const-string v2, "CreditRouterManager"

    .line 19
    .line 20
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    sget-object v0, Llb/f;->e:Llb/e;

    .line 24
    .line 25
    invoke-virtual {v0}, Llb/e;->getInstance()Llb/f;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iget-object v1, p0, Ljb/o;->c:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 30
    .line 31
    if-eqz v1, :cond_0

    .line 32
    .line 33
    iget v2, p0, Ljb/o;->m:I

    .line 34
    .line 35
    iput v2, v1, Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;->currentIndex:I

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    const/4 v1, 0x0

    .line 39
    :goto_0
    iput-object v1, v0, Llb/f;->c:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 40
    .line 41
    return-void
.end method

.method public final C(I)V
    .locals 3

    .line 1
    iput p1, p0, Ljb/o;->m:I

    .line 2
    .line 3
    const-string v0, "\u5f53\u524d\u8def\u7531\u7d22\u5f15\u4e3a <<< "

    .line 4
    .line 5
    invoke-static {p1, v0}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const/4 v1, 0x5

    .line 14
    const-string v2, "CreditRouterManager"

    .line 15
    .line 16
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    sget-object v0, Llb/f;->e:Llb/e;

    .line 20
    .line 21
    invoke-virtual {v0}, Llb/e;->getInstance()Llb/f;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iget-object v1, p0, Ljb/o;->c:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 26
    .line 27
    if-eqz v1, :cond_0

    .line 28
    .line 29
    iput p1, v1, Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;->currentIndex:I

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    const/4 v1, 0x0

    .line 33
    :goto_0
    iput-object v1, v0, Llb/f;->c:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 34
    .line 35
    return-void
.end method

.method public final D()V
    .locals 10

    .line 1
    invoke-virtual {p0}, Ljb/o;->E()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 5
    .line 6
    iget-object v1, p0, Ljb/o;->k:Ljava/lang/String;

    .line 7
    .line 8
    const-string v2, "OK_CARD"

    .line 9
    .line 10
    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const-string v3, "flexi"

    .line 15
    .line 16
    const-string v4, "flexi cash"

    .line 17
    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    move-object v1, v3

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    move-object v1, v4

    .line 23
    :goto_0
    iget-object v5, p0, Ljb/o;->k:Ljava/lang/String;

    .line 24
    .line 25
    const-string v6, "LOAN_WITHDRAW"

    .line 26
    .line 27
    invoke-static {v5, v6}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result v5

    .line 31
    const-string v7, "credit"

    .line 32
    .line 33
    const-string v8, "trade"

    .line 34
    .line 35
    if-eqz v5, :cond_1

    .line 36
    .line 37
    move-object v5, v8

    .line 38
    goto :goto_1

    .line 39
    :cond_1
    move-object v5, v7

    .line 40
    :goto_1
    sget-object v9, LFb/d;->a:LFb/c;

    .line 41
    .line 42
    invoke-virtual {v9, v0, v1, v5}, LFb/c;->getOcDeviceInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    sget-object v1, Lob/c;->a:Lob/a;

    .line 47
    .line 48
    invoke-virtual {v1}, Lob/a;->getInstance()Lob/c;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    invoke-interface {v1, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->uploadDeviceInfoNew(Lcom/transsnet/palmpay/core/bean/req/UploadDeviceInfoReq$DeviceInfoBean;)Ldf/d;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    invoke-virtual {v0, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    new-instance v1, LN8/t;

    .line 78
    .line 79
    const/4 v5, 0x3

    .line 80
    invoke-direct {v1, v5}, LN8/t;-><init>(I)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 84
    .line 85
    .line 86
    iget-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 87
    .line 88
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    if-eqz v0, :cond_2

    .line 93
    .line 94
    const-string v0, ""

    .line 95
    .line 96
    goto :goto_2

    .line 97
    :cond_2
    iget-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 98
    .line 99
    :goto_2
    iput-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 100
    .line 101
    sget-object v1, LGa/c;->a:LGa/b;

    .line 102
    .line 103
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    const-string v5, "4"

    .line 107
    .line 108
    invoke-virtual {v1, v0, v5, v4}, LGa/b;->upload(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    iget-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 112
    .line 113
    iget-object v1, p0, Ljb/o;->k:Ljava/lang/String;

    .line 114
    .line 115
    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    if-eqz v1, :cond_3

    .line 120
    .line 121
    goto :goto_3

    .line 122
    :cond_3
    move-object v3, v4

    .line 123
    :goto_3
    iget-object v1, p0, Ljb/o;->k:Ljava/lang/String;

    .line 124
    .line 125
    invoke-static {v1, v6}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    if-eqz v1, :cond_4

    .line 130
    .line 131
    move-object v7, v8

    .line 132
    :cond_4
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 133
    .line 134
    .line 135
    move-result v1

    .line 136
    if-nez v1, :cond_5

    .line 137
    .line 138
    return-void

    .line 139
    :cond_5
    const/4 v1, -0x4

    .line 140
    invoke-static {v1}, LPa/T;->b(I)Ljava/util/concurrent/ExecutorService;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    new-instance v2, Landroidx/emoji2/text/j;

    .line 145
    .line 146
    const/16 v4, 0x19

    .line 147
    .line 148
    invoke-direct {v2, v0, v4, v3, v7}, Landroidx/emoji2/text/j;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 152
    .line 153
    .line 154
    return-void
.end method

.method public final E()V
    .locals 4

    .line 1
    iget-object v0, p0, Ljb/o;->o:Ljava/lang/Boolean;

    .line 2
    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    const-string v2, "uploadLocationInfo >>> mUploadLocation = "

    .line 6
    .line 7
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v1, 0x3

    .line 22
    const-string v2, "CreditRouterManager"

    .line 23
    .line 24
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    invoke-static {}, Lya/a;->d()Lya/a;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, Lya/a;->f()Lcom/transsnet/palmpay/core/bean/LocationRecord;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iget-object v1, p0, Ljb/o;->o:Ljava/lang/Boolean;

    .line 36
    .line 37
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 38
    .line 39
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_2

    .line 44
    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 48
    .line 49
    iput-object v0, p0, Ljb/o;->o:Ljava/lang/Boolean;

    .line 50
    .line 51
    iget-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 52
    .line 53
    iget-object v1, p0, Ljb/o;->k:Ljava/lang/String;

    .line 54
    .line 55
    const-string v2, "OK_CARD"

    .line 56
    .line 57
    invoke-static {v1, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_0

    .line 62
    .line 63
    const-string v1, "flexi"

    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_0
    const-string v1, "flexi cash"

    .line 67
    .line 68
    :goto_0
    iget-object v2, p0, Ljb/o;->k:Ljava/lang/String;

    .line 69
    .line 70
    const-string v3, "LOAN_WITHDRAW"

    .line 71
    .line 72
    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 73
    .line 74
    .line 75
    move-result v2

    .line 76
    if-eqz v2, :cond_1

    .line 77
    .line 78
    const-string v2, "trade"

    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_1
    const-string v2, "credit"

    .line 82
    .line 83
    :goto_1
    invoke-static {v0, v1, v2}, Ljb/u;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    :cond_2
    return-void
.end method

.method public final c()V
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Ljb/o;->k:Ljava/lang/String;

    .line 4
    .line 5
    const-string v2, "applySubmit >>> loanProduct="

    .line 6
    .line 7
    invoke-static {v2, v1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    const/4 v2, 0x3

    .line 16
    const-string v3, "CreditRouterManager"

    .line 17
    .line 18
    invoke-static {v3, v2, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Ljb/o;->q()Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    iget-object v1, v0, Ljb/o;->k:Ljava/lang/String;

    .line 28
    .line 29
    const-string v4, "submitDirectly >>> loanProduct="

    .line 30
    .line 31
    invoke-static {v4, v1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-static {v3, v2, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    invoke-static {v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->isValidActivityContext(Landroid/app/Activity;)Z

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    if-nez v2, :cond_0

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_0
    if-eqz v1, :cond_1

    .line 54
    .line 55
    new-instance v2, Lcom/flexibank/sdk/g;

    .line 56
    .line 57
    const/16 v3, 0x16

    .line 58
    .line 59
    invoke-direct {v2, v3, v0, v1}, Lcom/flexibank/sdk/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v1, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 63
    .line 64
    .line 65
    :cond_1
    :goto_0
    sget-object v1, Lob/c;->a:Lob/a;

    .line 66
    .line 67
    invoke-static {v1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    new-instance v2, Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;

    .line 72
    .line 73
    iget-object v3, v0, Ljb/o;->j:Ljava/lang/String;

    .line 74
    .line 75
    iget-object v4, v0, Ljb/o;->e:Ljava/lang/String;

    .line 76
    .line 77
    invoke-static {}, Ljb/o;->g()I

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 82
    .line 83
    .line 84
    move-result-object v6

    .line 85
    iget-object v9, v0, Ljb/o;->l:Ljava/lang/String;

    .line 86
    .line 87
    iget-object v5, v0, Ljb/o;->k:Ljava/lang/String;

    .line 88
    .line 89
    const/16 v19, 0x7fb4

    .line 90
    .line 91
    const/16 v20, 0x0

    .line 92
    .line 93
    move-object/from16 v18, v5

    .line 94
    .line 95
    const/4 v5, 0x0

    .line 96
    const/4 v7, 0x0

    .line 97
    const/4 v8, 0x0

    .line 98
    const/4 v10, 0x0

    .line 99
    const/4 v11, 0x0

    .line 100
    const/4 v12, 0x0

    .line 101
    const/4 v13, 0x0

    .line 102
    const/4 v14, 0x0

    .line 103
    const/4 v15, 0x0

    .line 104
    const/16 v16, 0x0

    .line 105
    .line 106
    const/16 v17, 0x0

    .line 107
    .line 108
    invoke-direct/range {v2 .. v20}, Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 109
    .line 110
    .line 111
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->openCashLoan(Lcom/transsnet/palmpay/credit/bean/req/CLOpenAccountReq;)Ldf/d;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 116
    .line 117
    invoke-virtual {v1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 118
    .line 119
    .line 120
    move-result-object v1

    .line 121
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    invoke-virtual {v1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 126
    .line 127
    .line 128
    move-result-object v1

    .line 129
    new-instance v2, Ljb/l;

    .line 130
    .line 131
    const/4 v3, 0x4

    .line 132
    invoke-direct {v2, v0, v3}, Ljb/l;-><init>(Ljb/o;I)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v1, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 136
    .line 137
    .line 138
    return-void

    .line 139
    :cond_2
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    invoke-static {v1}, Lcom/transsnet/palmpay/util/ActivityUtils;->isValidActivityContext(Landroid/app/Activity;)Z

    .line 144
    .line 145
    .line 146
    move-result v2

    .line 147
    if-nez v2, :cond_3

    .line 148
    .line 149
    goto :goto_1

    .line 150
    :cond_3
    if-eqz v1, :cond_4

    .line 151
    .line 152
    new-instance v2, Lcom/flexibank/sdk/g;

    .line 153
    .line 154
    const/16 v3, 0x16

    .line 155
    .line 156
    invoke-direct {v2, v3, v0, v1}, Lcom/flexibank/sdk/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v1, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 160
    .line 161
    .line 162
    :cond_4
    :goto_1
    sget-object v1, Lob/c;->a:Lob/a;

    .line 163
    .line 164
    invoke-static {v1}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    new-instance v2, Lcom/transsnet/palmpay/credit/bean/req/DoubleSignReq;

    .line 169
    .line 170
    iget-object v3, v0, Ljb/o;->k:Ljava/lang/String;

    .line 171
    .line 172
    invoke-direct {v2, v3}, Lcom/transsnet/palmpay/credit/bean/req/DoubleSignReq;-><init>(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    invoke-interface {v1, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->querySignStatus(Lcom/transsnet/palmpay/credit/bean/req/DoubleSignReq;)Ldf/d;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 180
    .line 181
    .line 182
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 183
    .line 184
    invoke-virtual {v1, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 185
    .line 186
    .line 187
    move-result-object v1

    .line 188
    new-instance v3, Lio/reactivex/internal/operators/observable/K;

    .line 189
    .line 190
    const/4 v4, 0x1

    .line 191
    invoke-direct {v3, v1, v2, v4}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 192
    .line 193
    .line 194
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 195
    .line 196
    .line 197
    move-result-object v1

    .line 198
    invoke-virtual {v3, v1}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    new-instance v2, Ljb/h;

    .line 203
    .line 204
    const/4 v3, 0x2

    .line 205
    invoke-direct {v2, v0, v3}, Ljb/h;-><init>(Ljb/o;I)V

    .line 206
    .line 207
    .line 208
    new-instance v3, Lj9/b;

    .line 209
    .line 210
    const/4 v4, 0x7

    .line 211
    invoke-direct {v3, v2, v4}, Lj9/b;-><init>(Ljava/lang/Object;I)V

    .line 212
    .line 213
    .line 214
    invoke-virtual {v1, v3}, Ldf/d;->f(Lio/reactivex/functions/Function;)Ldf/d;

    .line 215
    .line 216
    .line 217
    move-result-object v1

    .line 218
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 219
    .line 220
    .line 221
    move-result-object v2

    .line 222
    invoke-virtual {v1, v2}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    new-instance v2, Ljb/l;

    .line 227
    .line 228
    const/4 v3, 0x0

    .line 229
    invoke-direct {v2, v0, v3}, Ljb/l;-><init>(Ljb/o;I)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {v1, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 233
    .line 234
    .line 235
    return-void
.end method

.method public final e(Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;)V
    .locals 11

    .line 1
    iget-object v0, p0, Ljb/o;->h:Ljava/lang/Integer;

    .line 2
    .line 3
    iget-object v1, p0, Ljb/o;->k:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v2, p0, Ljb/o;->i:Ljava/lang/String;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    iget-object v4, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpPath:Ljava/lang/String;

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move-object v4, v3

    .line 14
    :goto_0
    if-eqz p1, :cond_1

    .line 15
    .line 16
    iget-object v5, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->androidLink:Ljava/lang/String;

    .line 17
    .line 18
    goto :goto_1

    .line 19
    :cond_1
    move-object v5, v3

    .line 20
    :goto_1
    new-instance v6, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    const-string v7, "completeBorrowTrialNavigation >>> mAccountType="

    .line 23
    .line 24
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const-string v0, ", loanProduct="

    .line 31
    .line 32
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    const-string v1, ", borrowRoutePath="

    .line 39
    .line 40
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v1, ", jumpLinkInfo.jumpPath="

    .line 44
    .line 45
    const-string v7, ", jumpLinkInfo.androidLink="

    .line 46
    .line 47
    invoke-static {v6, v2, v1, v4, v7}, Landroidx/camera/video/u;->x(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    const/4 v2, 0x3

    .line 62
    const-string v4, "CreditRouterManager"

    .line 63
    .line 64
    invoke-static {v4, v2, v1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    const/4 v1, 0x1

    .line 68
    iput-boolean v1, p0, Ljb/o;->v:Z

    .line 69
    .line 70
    iget-object v4, p0, Ljb/o;->i:Ljava/lang/String;

    .line 71
    .line 72
    iget-object v5, p0, Ljb/o;->h:Ljava/lang/Integer;

    .line 73
    .line 74
    iget-object v6, p0, Ljb/o;->k:Ljava/lang/String;

    .line 75
    .line 76
    if-eqz p1, :cond_2

    .line 77
    .line 78
    iget-object v7, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpPath:Ljava/lang/String;

    .line 79
    .line 80
    goto :goto_2

    .line 81
    :cond_2
    move-object v7, v3

    .line 82
    :goto_2
    if-eqz p1, :cond_3

    .line 83
    .line 84
    iget-object v8, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->androidLink:Ljava/lang/String;

    .line 85
    .line 86
    goto :goto_3

    .line 87
    :cond_3
    move-object v8, v3

    .line 88
    :goto_3
    new-instance v9, Ljava/lang/StringBuilder;

    .line 89
    .line 90
    const-string v10, "navigate enter >>> borrowRoutePath="

    .line 91
    .line 92
    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    const-string v10, ", accountType="

    .line 99
    .line 100
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 104
    .line 105
    .line 106
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    const-string v0, ", jumpPath="

    .line 110
    .line 111
    const-string v10, ", androidLink="

    .line 112
    .line 113
    invoke-static {v9, v6, v0, v7, v10}, Landroidx/camera/video/u;->x(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    .line 118
    .line 119
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    const-string v7, "BorrowTrialRouteNavigator"

    .line 128
    .line 129
    invoke-static {v7, v2, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    if-eqz v4, :cond_4

    .line 133
    .line 134
    invoke-static {v4}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v3

    .line 142
    :cond_4
    if-nez v3, :cond_5

    .line 143
    .line 144
    const-string v3, ""

    .line 145
    .line 146
    :cond_5
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    const-string v4, "accountType"

    .line 151
    .line 152
    const/4 v8, 0x7

    .line 153
    if-lez v0, :cond_e

    .line 154
    .line 155
    const-string p1, "navigate mode=ROUTE_PATH path="

    .line 156
    .line 157
    invoke-virtual {p1, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    invoke-static {v7, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    const-string p1, "arouter://"

    .line 169
    .line 170
    invoke-static {v3, p1, v1}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 171
    .line 172
    .line 173
    move-result p1

    .line 174
    if-nez p1, :cond_d

    .line 175
    .line 176
    const-string p1, "palmpay://"

    .line 177
    .line 178
    invoke-static {v3, p1, v1}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 179
    .line 180
    .line 181
    move-result p1

    .line 182
    if-eqz p1, :cond_6

    .line 183
    .line 184
    goto :goto_6

    .line 185
    :cond_6
    if-eqz v5, :cond_7

    .line 186
    .line 187
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 188
    .line 189
    .line 190
    move-result v8

    .line 191
    goto :goto_5

    .line 192
    :cond_7
    if-eqz v6, :cond_c

    .line 193
    .line 194
    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    .line 195
    .line 196
    .line 197
    move-result p1

    .line 198
    const v0, -0x2b09f584

    .line 199
    .line 200
    .line 201
    if-eq p1, v0, :cond_b

    .line 202
    .line 203
    const v0, 0xa44b63a

    .line 204
    .line 205
    .line 206
    if-eq p1, v0, :cond_a

    .line 207
    .line 208
    const v0, 0x2a48dc16

    .line 209
    .line 210
    .line 211
    if-eq p1, v0, :cond_8

    .line 212
    .line 213
    goto :goto_5

    .line 214
    :cond_8
    const-string p1, "INSTALLMENT_LOAN"

    .line 215
    .line 216
    invoke-virtual {v6, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    move-result p1

    .line 220
    if-nez p1, :cond_9

    .line 221
    .line 222
    goto :goto_5

    .line 223
    :cond_9
    const/16 v8, 0x9

    .line 224
    .line 225
    goto :goto_5

    .line 226
    :cond_a
    const-string p1, "CASH_INSTANT_LOAN"

    .line 227
    .line 228
    :goto_4
    invoke-virtual {v6, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 229
    .line 230
    .line 231
    goto :goto_5

    .line 232
    :cond_b
    const-string p1, "CASH_LOAN"

    .line 233
    .line 234
    goto :goto_4

    .line 235
    :cond_c
    :goto_5
    new-instance p1, Ljava/lang/StringBuilder;

    .line 236
    .line 237
    const-string v0, "navigateByRoutePath >>> RouterManager.goToRnPage module="

    .line 238
    .line 239
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 243
    .line 244
    .line 245
    const-string v0, " (strict) accountType="

    .line 246
    .line 247
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 248
    .line 249
    .line 250
    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 251
    .line 252
    .line 253
    const-string v0, ", preCheckAccountType="

    .line 254
    .line 255
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 256
    .line 257
    .line 258
    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 259
    .line 260
    .line 261
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 262
    .line 263
    .line 264
    move-result-object p1

    .line 265
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object p1

    .line 269
    invoke-static {v7, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 270
    .line 271
    .line 272
    new-instance p1, Landroid/os/Bundle;

    .line 273
    .line 274
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 275
    .line 276
    .line 277
    invoke-virtual {p1, v4, v8}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 278
    .line 279
    .line 280
    invoke-static {p1, v3}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 281
    .line 282
    .line 283
    return-void

    .line 284
    :cond_d
    :goto_6
    const-string p1, "navigateByRoutePath >>> PageRouteUtil.gotoPage(fullScheme) path="

    .line 285
    .line 286
    invoke-virtual {p1, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 287
    .line 288
    .line 289
    move-result-object p1

    .line 290
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object p1

    .line 294
    invoke-static {v7, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 295
    .line 296
    .line 297
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 298
    .line 299
    .line 300
    move-result-object p1

    .line 301
    invoke-static {p1, v3}, LPa/F;->g(Landroid/content/Context;Ljava/lang/String;)Z

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :cond_e
    if-eqz p1, :cond_10

    .line 306
    .line 307
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpPath:Ljava/lang/String;

    .line 308
    .line 309
    iget-object v1, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpType:Ljava/lang/String;

    .line 310
    .line 311
    iget-object v3, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpParams:Ljava/lang/String;

    .line 312
    .line 313
    iget-object v4, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->androidLink:Ljava/lang/String;

    .line 314
    .line 315
    const-string v5, "navigate mode=JUMP_LINK_INFO jumpPath="

    .line 316
    .line 317
    const-string v6, ", jumpType="

    .line 318
    .line 319
    const-string v8, ", jumpParams="

    .line 320
    .line 321
    invoke-static {v5, v0, v6, v1, v8}, Landroidx/camera/camera2/internal/F;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 322
    .line 323
    .line 324
    move-result-object v0

    .line 325
    invoke-static {v0, v3, v10, v4}, Landroidx/camera/camera2/internal/F;->d(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 326
    .line 327
    .line 328
    move-result-object v0

    .line 329
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 330
    .line 331
    .line 332
    move-result-object v0

    .line 333
    invoke-static {v7, v2, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 334
    .line 335
    .line 336
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpPath:Ljava/lang/String;

    .line 337
    .line 338
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 339
    .line 340
    .line 341
    move-result v0

    .line 342
    if-eqz v0, :cond_f

    .line 343
    .line 344
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->androidLink:Ljava/lang/String;

    .line 345
    .line 346
    const-string v1, "navigateByJumpLinkInfo >>> PageRouteUtil.gotoPage(androidLink)="

    .line 347
    .line 348
    invoke-static {v1, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object v0

    .line 352
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 353
    .line 354
    .line 355
    move-result-object v0

    .line 356
    invoke-static {v7, v2, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 357
    .line 358
    .line 359
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->androidLink:Ljava/lang/String;

    .line 364
    .line 365
    invoke-static {v0, p1}, LPa/F;->g(Landroid/content/Context;Ljava/lang/String;)Z

    .line 366
    .line 367
    .line 368
    return-void

    .line 369
    :cond_f
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpPath:Ljava/lang/String;

    .line 370
    .line 371
    iget-object v1, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpType:Ljava/lang/String;

    .line 372
    .line 373
    iget-object v3, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpParams:Ljava/lang/String;

    .line 374
    .line 375
    const-string v4, "navigateByJumpLinkInfo >>> PageRouteUtil.gotoPage jumpPath="

    .line 376
    .line 377
    invoke-static {v4, v0, v6, v1, v8}, Landroidx/camera/camera2/internal/F;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 378
    .line 379
    .line 380
    move-result-object v0

    .line 381
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 382
    .line 383
    .line 384
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 385
    .line 386
    .line 387
    move-result-object v0

    .line 388
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 389
    .line 390
    .line 391
    move-result-object v0

    .line 392
    invoke-static {v7, v2, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 393
    .line 394
    .line 395
    iget-object v0, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpPath:Ljava/lang/String;

    .line 396
    .line 397
    iget-object v1, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpType:Ljava/lang/String;

    .line 398
    .line 399
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;->jumpParams:Ljava/lang/String;

    .line 400
    .line 401
    invoke-static {v0, v1, p1}, LPa/F;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 402
    .line 403
    .line 404
    return-void

    .line 405
    :cond_10
    const-string p1, "navigate mode=DEFAULT_BORROW_HOME"

    .line 406
    .line 407
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    move-result-object p1

    .line 411
    invoke-static {v7, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 412
    .line 413
    .line 414
    if-eqz v5, :cond_11

    .line 415
    .line 416
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 417
    .line 418
    .line 419
    move-result v8

    .line 420
    :cond_11
    const-string p1, "navigateDefaultBorrowHome >>> RouterManager.goToRnPage module=LoanBorrowFlexiLoan, accountType="

    .line 421
    .line 422
    invoke-static {v8, p1}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 423
    .line 424
    .line 425
    move-result-object p1

    .line 426
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 427
    .line 428
    .line 429
    move-result-object p1

    .line 430
    invoke-static {v7, v2, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 431
    .line 432
    .line 433
    new-instance p1, Landroid/os/Bundle;

    .line 434
    .line 435
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 436
    .line 437
    .line 438
    invoke-virtual {p1, v4, v8}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 439
    .line 440
    .line 441
    const-string v0, "LoanBorrowFlexiLoan"

    .line 442
    .line 443
    invoke-static {p1, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    return-void
.end method

.method public final f()V
    .locals 3

    .line 1
    iget-object v0, p0, Ljb/o;->x:Ljava/lang/String;

    .line 2
    .line 3
    const-string v1, "doRouterPre >>> routeNodeInfo="

    .line 4
    .line 5
    invoke-static {v1, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const/4 v1, 0x3

    .line 14
    const-string v2, "CreditRouterManager"

    .line 15
    .line 16
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-boolean v0, p0, Ljb/o;->v:Z

    .line 20
    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    iget-object v0, p0, Ljb/o;->x:Ljava/lang/String;

    .line 24
    .line 25
    const/4 v1, 0x0

    .line 26
    const-string v2, "NoticeCreditRoutePrevious"

    .line 27
    .line 28
    invoke-static {v2, v0, v1}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    :cond_0
    return-void
.end method

.method public final i()Lgf/a;
    .locals 1

    .line 1
    iget-object v0, p0, Ljb/o;->a:Lxf/t;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lgf/a;

    .line 8
    .line 9
    return-object v0
.end method

.method public final j(Ljava/lang/Integer;Z)I
    .locals 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "getCurRouteIndex >>> routeId="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const/4 v1, 0x3

    .line 20
    const-string v2, "CreditRouterManager"

    .line 21
    .line 22
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, Ljb/o;->d:Ljava/util/List;

    .line 26
    .line 27
    if-eqz v0, :cond_4

    .line 28
    .line 29
    check-cast v0, Ljava/lang/Iterable;

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    const/4 v1, 0x0

    .line 36
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_4

    .line 41
    .line 42
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    add-int/lit8 v3, v1, 0x1

    .line 47
    .line 48
    const/4 v4, 0x0

    .line 49
    if-ltz v1, :cond_3

    .line 50
    .line 51
    check-cast v2, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 52
    .line 53
    if-eqz v2, :cond_0

    .line 54
    .line 55
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 56
    .line 57
    .line 58
    move-result-object v4

    .line 59
    :cond_0
    invoke-virtual {p1, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    if-eqz v2, :cond_2

    .line 64
    .line 65
    if-eqz p2, :cond_1

    .line 66
    .line 67
    invoke-virtual {p0}, Ljb/o;->n()Z

    .line 68
    .line 69
    .line 70
    move-result p1

    .line 71
    if-eqz p1, :cond_1

    .line 72
    .line 73
    add-int/lit8 v1, v1, -0x1

    .line 74
    .line 75
    :cond_1
    return v1

    .line 76
    :cond_2
    move v1, v3

    .line 77
    goto :goto_0

    .line 78
    :cond_3
    invoke-static {}, Lkotlin/collections/q;->k()V

    .line 79
    .line 80
    .line 81
    throw v4

    .line 82
    :cond_4
    const/4 p1, -0x1

    .line 83
    return p1
.end method

.method public final k(Ljava/lang/Integer;)Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "getRoutePathById >>> routeId="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const/4 v1, 0x3

    .line 20
    const-string v2, "CreditRouterManager"

    .line 21
    .line 22
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, Ljb/o;->d:Ljava/util/List;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    if-eqz v0, :cond_3

    .line 29
    .line 30
    check-cast v0, Ljava/lang/Iterable;

    .line 31
    .line 32
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_2

    .line 41
    .line 42
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    move-object v3, v2

    .line 47
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 48
    .line 49
    if-eqz v3, :cond_1

    .line 50
    .line 51
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    goto :goto_0

    .line 56
    :cond_1
    move-object v3, v1

    .line 57
    :goto_0
    invoke-static {v3, p1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v3

    .line 61
    if-eqz v3, :cond_0

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_2
    move-object v2, v1

    .line 65
    :goto_1
    check-cast v2, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 66
    .line 67
    goto :goto_2

    .line 68
    :cond_3
    move-object v2, v1

    .line 69
    :goto_2
    if-eqz v2, :cond_4

    .line 70
    .line 71
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    return-object p1

    .line 76
    :cond_4
    return-object v1
.end method

.method public final l(Ljava/lang/Integer;Ljava/lang/String;)V
    .locals 4

    .line 1
    const-string v0, "getVerifyInfo >>> routerPath = "

    .line 2
    .line 3
    invoke-static {v0, p2}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const/4 v1, 0x3

    .line 12
    const-string v2, "CreditRouterManager"

    .line 13
    .line 14
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lob/c;->a:Lob/a;

    .line 18
    .line 19
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-interface {v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->queryAllVerifyInfo()Ldf/d;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    new-instance v2, Lio/reactivex/internal/operators/observable/K;

    .line 44
    .line 45
    const/4 v3, 0x1

    .line 46
    invoke-direct {v2, v0, v1, v3}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 47
    .line 48
    .line 49
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-virtual {v2, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    new-instance v1, Ljb/m;

    .line 58
    .line 59
    invoke-direct {v1, p0, p2, p1}, Ljb/m;-><init>(Ljb/o;Ljava/lang/String;Ljava/lang/Integer;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public final m(Ljava/util/List;)V
    .locals 4

    .line 1
    const-string v0, "handleRouterList >>>"

    .line 2
    .line 3
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x3

    .line 8
    const-string v2, "CreditRouterManager"

    .line 9
    .line 10
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    move-object v0, p1

    .line 14
    check-cast v0, Ljava/util/Collection;

    .line 15
    .line 16
    const/4 v3, 0x0

    .line 17
    if-eqz v0, :cond_5

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_0
    const/4 v0, 0x0

    .line 27
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 32
    .line 33
    if-eqz p1, :cond_1

    .line 34
    .line 35
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    goto :goto_0

    .line 40
    :cond_1
    move-object p1, v3

    .line 41
    :goto_0
    const-string v0, "oc_permission_router"

    .line 42
    .line 43
    invoke-static {v0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 44
    .line 45
    .line 46
    move-result p1

    .line 47
    if-eqz p1, :cond_4

    .line 48
    .line 49
    const-string p1, "handleRouterList >>> checkPermission"

    .line 50
    .line 51
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    iget-object p1, p0, Ljb/o;->b:Ljava/lang/ref/WeakReference;

    .line 59
    .line 60
    if-eqz p1, :cond_3

    .line 61
    .line 62
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;

    .line 67
    .line 68
    if-eqz p1, :cond_2

    .line 69
    .line 70
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 71
    .line 72
    invoke-virtual {p1, v0}, Lcom/transsnet/palmpay/credit/ui/fragment/LoanCreditFragment;->checkPermission(Ljava/lang/Boolean;)V

    .line 73
    .line 74
    .line 75
    :cond_2
    return-void

    .line 76
    :cond_3
    const-string p1, "mLoanCreditFragmentRef"

    .line 77
    .line 78
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    throw v3

    .line 82
    :cond_4
    invoke-virtual {p0}, Ljb/o;->x()V

    .line 83
    .line 84
    .line 85
    return-void

    .line 86
    :cond_5
    :goto_1
    iget-object p1, p0, Ljb/o;->k:Ljava/lang/String;

    .line 87
    .line 88
    const-string v0, "LOAN_WITHDRAW"

    .line 89
    .line 90
    invoke-static {p1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 91
    .line 92
    .line 93
    move-result p1

    .line 94
    if-eqz p1, :cond_6

    .line 95
    .line 96
    invoke-virtual {p0, v3}, Ljb/o;->e(Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;)V

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :cond_6
    invoke-virtual {p0}, Ljb/o;->c()V

    .line 101
    .line 102
    .line 103
    return-void
.end method

.method public final n()Z
    .locals 2

    .line 1
    iget-object v0, p0, Ljb/o;->d:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v0, 0x0

    .line 20
    :goto_0
    const-string v1, "oc_permission_router"

    .line 21
    .line 22
    invoke-static {v1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    return v0
.end method

.method public final o()V
    .locals 2

    .line 1
    :try_start_0
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 2
    .line 3
    iget-object v0, p0, Ljb/o;->u:Lcom/transsnet/palmpay/custom_view/dialog/LoadingDialog;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {v0}, Lcom/transsnet/palmpay/custom_view/dialog/LoadingDialog;->dismiss()V

    .line 8
    .line 9
    .line 10
    goto :goto_0

    .line 11
    :catchall_0
    move-exception v0

    .line 12
    goto :goto_1

    .line 13
    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 14
    iput-object v0, p0, Ljb/o;->u:Lcom/transsnet/palmpay/custom_view/dialog/LoadingDialog;

    .line 15
    .line 16
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    .line 18
    return-void

    .line 19
    :goto_1
    sget-object v1, Lxf/q;->a:Lxf/o;

    .line 20
    .line 21
    invoke-static {v0}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public onMessageEvent(Lcom/transsnet/palmpay/core/bean/message/MessageEvent;)V
    .locals 6
    .param p1    # Lcom/transsnet/palmpay/core/bean/message/MessageEvent;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation runtime Lorg/greenrobot/eventbus/Subscribe;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    const-string v0, "event"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventType()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const-string v1, "onMessageEvent = "

    .line 11
    .line 12
    invoke-static {v0, v1}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const/4 v1, 0x3

    .line 21
    const-string v2, "CreditRouterManager"

    .line 22
    .line 23
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventType()I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    const/16 v3, 0x9

    .line 31
    .line 32
    if-eq v0, v3, :cond_c

    .line 33
    .line 34
    const/16 v3, 0x113

    .line 35
    .line 36
    const-string v4, "1"

    .line 37
    .line 38
    if-eq v0, v3, :cond_a

    .line 39
    .line 40
    const/16 v3, 0x152

    .line 41
    .line 42
    if-eq v0, v3, :cond_9

    .line 43
    .line 44
    const/16 v3, 0x223

    .line 45
    .line 46
    if-eq v0, v3, :cond_8

    .line 47
    .line 48
    const/16 v3, 0x229

    .line 49
    .line 50
    const/4 v5, 0x5

    .line 51
    if-eq v0, v3, :cond_3

    .line 52
    .line 53
    const/16 v3, 0x230

    .line 54
    .line 55
    if-eq v0, v3, :cond_c

    .line 56
    .line 57
    const/16 v1, 0x236

    .line 58
    .line 59
    if-eq v0, v1, :cond_2

    .line 60
    .line 61
    const/16 v1, 0x238

    .line 62
    .line 63
    if-eq v0, v1, :cond_0

    .line 64
    .line 65
    goto/16 :goto_2

    .line 66
    .line 67
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventObj()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    const/16 v0, 0xc8

    .line 72
    .line 73
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result p1

    .line 81
    if-eqz p1, :cond_1

    .line 82
    .line 83
    iget-boolean p1, p0, Ljb/o;->t:Z

    .line 84
    .line 85
    if-eqz p1, :cond_1

    .line 86
    .line 87
    const-string p1, "mBvnVerified >>> no exit"

    .line 88
    .line 89
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-static {v2, v5, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    return-void

    .line 97
    :cond_1
    iget p1, p0, Ljb/o;->m:I

    .line 98
    .line 99
    invoke-virtual {p0, p1}, Ljb/o;->t(I)V

    .line 100
    .line 101
    .line 102
    return-void

    .line 103
    :cond_2
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventContent()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    invoke-static {p1, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 108
    .line 109
    .line 110
    move-result p1

    .line 111
    if-eqz p1, :cond_b

    .line 112
    .line 113
    iget p1, p0, Ljb/o;->m:I

    .line 114
    .line 115
    invoke-virtual {p0, p1}, Ljb/o;->t(I)V

    .line 116
    .line 117
    .line 118
    return-void

    .line 119
    :cond_3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventContent()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    const-string v0, "exitRNRouterPage >>> moduleName="

    .line 124
    .line 125
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    const/4 v0, 0x0

    .line 137
    invoke-virtual {p0, v0, p1}, Ljb/o;->r(Ljava/lang/Integer;Ljava/lang/String;)Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    invoke-virtual {p0}, Ljb/o;->q()Z

    .line 142
    .line 143
    .line 144
    move-result v1

    .line 145
    if-eqz v1, :cond_5

    .line 146
    .line 147
    if-eqz v0, :cond_5

    .line 148
    .line 149
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getType()Ljava/lang/Integer;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    sget-object v3, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->RN:Lcom/transsnet/palmpay/credit/bean/RoutePageType;

    .line 154
    .line 155
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->getCode()I

    .line 156
    .line 157
    .line 158
    move-result v3

    .line 159
    if-nez v1, :cond_4

    .line 160
    .line 161
    goto :goto_0

    .line 162
    :cond_4
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 163
    .line 164
    .line 165
    move-result v1

    .line 166
    if-ne v1, v3, :cond_5

    .line 167
    .line 168
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getName()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    const-string v0, "exitRNRouterPage >>> isDynamicRnRoute, routePath="

    .line 173
    .line 174
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 175
    .line 176
    .line 177
    move-result-object p1

    .line 178
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    invoke-static {v2, v5, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {p0}, Ljb/o;->f()V

    .line 186
    .line 187
    .line 188
    return-void

    .line 189
    :cond_5
    :goto_0
    if-eqz p1, :cond_b

    .line 190
    .line 191
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    sparse-switch v0, :sswitch_data_0

    .line 196
    .line 197
    .line 198
    goto/16 :goto_2

    .line 199
    .line 200
    :sswitch_0
    const-string v0, "ContactPage"

    .line 201
    .line 202
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result p1

    .line 206
    if-nez p1, :cond_6

    .line 207
    .line 208
    goto/16 :goto_2

    .line 209
    .line 210
    :sswitch_1
    const-string v0, "LoanBusinessExpectation"

    .line 211
    .line 212
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result p1

    .line 216
    if-nez p1, :cond_6

    .line 217
    .line 218
    goto/16 :goto_2

    .line 219
    .line 220
    :sswitch_2
    const-string v0, "LoanKycHome"

    .line 221
    .line 222
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 223
    .line 224
    .line 225
    move-result p1

    .line 226
    if-nez p1, :cond_6

    .line 227
    .line 228
    goto/16 :goto_2

    .line 229
    .line 230
    :sswitch_3
    const-string v0, "LoanKycVerify"

    .line 231
    .line 232
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 233
    .line 234
    .line 235
    move-result p1

    .line 236
    if-nez p1, :cond_6

    .line 237
    .line 238
    goto/16 :goto_2

    .line 239
    .line 240
    :sswitch_4
    const-string v0, "LoanOtpVerify"

    .line 241
    .line 242
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 243
    .line 244
    .line 245
    move-result p1

    .line 246
    if-eqz p1, :cond_b

    .line 247
    .line 248
    goto :goto_1

    .line 249
    :sswitch_5
    const-string v0, "LoanOpayReverse"

    .line 250
    .line 251
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 252
    .line 253
    .line 254
    move-result p1

    .line 255
    if-nez p1, :cond_6

    .line 256
    .line 257
    goto/16 :goto_2

    .line 258
    .line 259
    :sswitch_6
    const-string v0, "LoanExpectation"

    .line 260
    .line 261
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 262
    .line 263
    .line 264
    move-result p1

    .line 265
    if-nez p1, :cond_6

    .line 266
    .line 267
    goto/16 :goto_2

    .line 268
    .line 269
    :sswitch_7
    const-string v0, "LoanOneLoop"

    .line 270
    .line 271
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result p1

    .line 275
    if-nez p1, :cond_6

    .line 276
    .line 277
    goto/16 :goto_2

    .line 278
    .line 279
    :sswitch_8
    const-string v0, "BVN"

    .line 280
    .line 281
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 282
    .line 283
    .line 284
    move-result p1

    .line 285
    if-nez p1, :cond_6

    .line 286
    .line 287
    goto/16 :goto_2

    .line 288
    .line 289
    :sswitch_9
    const-string v0, "LoanFaceVerify"

    .line 290
    .line 291
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 292
    .line 293
    .line 294
    move-result p1

    .line 295
    if-nez p1, :cond_6

    .line 296
    .line 297
    goto :goto_2

    .line 298
    :sswitch_a
    const-string v0, "LoanBusinessInfo"

    .line 299
    .line 300
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 301
    .line 302
    .line 303
    move-result p1

    .line 304
    if-nez p1, :cond_6

    .line 305
    .line 306
    goto :goto_2

    .line 307
    :sswitch_b
    const-string v0, "PersonalInfoV2"

    .line 308
    .line 309
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 310
    .line 311
    .line 312
    move-result p1

    .line 313
    if-nez p1, :cond_6

    .line 314
    .line 315
    goto :goto_2

    .line 316
    :sswitch_c
    const-string v0, "BankAuth"

    .line 317
    .line 318
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result p1

    .line 322
    if-nez p1, :cond_6

    .line 323
    .line 324
    goto :goto_2

    .line 325
    :sswitch_d
    const-string v0, "LoanContact"

    .line 326
    .line 327
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 328
    .line 329
    .line 330
    move-result p1

    .line 331
    if-nez p1, :cond_6

    .line 332
    .line 333
    goto :goto_2

    .line 334
    :sswitch_e
    const-string v0, "OneLoopAct"

    .line 335
    .line 336
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 337
    .line 338
    .line 339
    move-result p1

    .line 340
    if-nez p1, :cond_6

    .line 341
    .line 342
    goto :goto_2

    .line 343
    :cond_6
    :goto_1
    invoke-virtual {p0}, Ljb/o;->q()Z

    .line 344
    .line 345
    .line 346
    move-result p1

    .line 347
    if-eqz p1, :cond_7

    .line 348
    .line 349
    invoke-virtual {p0}, Ljb/o;->f()V

    .line 350
    .line 351
    .line 352
    return-void

    .line 353
    :cond_7
    invoke-virtual {p0}, Ljb/o;->B()V

    .line 354
    .line 355
    .line 356
    return-void

    .line 357
    :cond_8
    const/4 p1, 0x1

    .line 358
    iput-boolean p1, p0, Ljb/o;->t:Z

    .line 359
    .line 360
    const-string p1, "mBvnVerified >>> success"

    .line 361
    .line 362
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 363
    .line 364
    .line 365
    move-result-object p1

    .line 366
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 367
    .line 368
    .line 369
    iget p1, p0, Ljb/o;->m:I

    .line 370
    .line 371
    invoke-virtual {p0, p1}, Ljb/o;->v(I)V

    .line 372
    .line 373
    .line 374
    return-void

    .line 375
    :cond_9
    invoke-virtual {p0}, Ljb/o;->E()V

    .line 376
    .line 377
    .line 378
    return-void

    .line 379
    :cond_a
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventContent()Ljava/lang/String;

    .line 380
    .line 381
    .line 382
    move-result-object p1

    .line 383
    invoke-static {p1, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 384
    .line 385
    .line 386
    move-result p1

    .line 387
    if-eqz p1, :cond_b

    .line 388
    .line 389
    iget p1, p0, Ljb/o;->m:I

    .line 390
    .line 391
    invoke-virtual {p0, p1}, Ljb/o;->v(I)V

    .line 392
    .line 393
    .line 394
    :cond_b
    :goto_2
    return-void

    .line 395
    :cond_c
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/message/MessageEvent;->getEventType()I

    .line 396
    .line 397
    .line 398
    move-result p1

    .line 399
    const-string v0, "onMessageEvent routeNext= "

    .line 400
    .line 401
    invoke-static {p1, v0}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object p1

    .line 405
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 406
    .line 407
    .line 408
    move-result-object p1

    .line 409
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 410
    .line 411
    .line 412
    iget p1, p0, Ljb/o;->m:I

    .line 413
    .line 414
    invoke-virtual {p0, p1}, Ljb/o;->v(I)V

    .line 415
    .line 416
    .line 417
    return-void

    .line 418
    nop

    .line 419
    :sswitch_data_0
    .sparse-switch
        -0x740411d8 -> :sswitch_e
        -0x73a3cf10 -> :sswitch_d
        -0x6afdc1dc -> :sswitch_c
        -0x2fa4d5b6 -> :sswitch_b
        -0x1f8bd242 -> :sswitch_a
        -0x551ad9a -> :sswitch_9
        0x1027a -> :sswitch_8
        0x4e152fa -> :sswitch_7
        0x8a9430c -> :sswitch_6
        0x9205399 -> :sswitch_5
        0x1788f054 -> :sswitch_4
        0x1e2c125e -> :sswitch_3
        0x43efb404 -> :sswitch_2
        0x56c3032c -> :sswitch_1
        0x65d792af -> :sswitch_0
    .end sparse-switch
.end method

.method public final p(Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;)V
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    const/4 v2, 0x2

    .line 4
    const/4 v3, 0x1

    .line 5
    const-string v0, "interceptRouter >>>"

    .line 6
    .line 7
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const/4 v4, 0x3

    .line 12
    const-string v5, "CreditRouterManager"

    .line 13
    .line 14
    invoke-static {v5, v4, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    const/4 v6, 0x0

    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    move-object v0, v6

    .line 26
    :goto_0
    const/4 v7, 0x0

    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    const-string v0, "Sorry, the service is unavailable now (code-2)"

    .line 30
    .line 31
    new-array v2, v7, [Ljava/lang/Object;

    .line 32
    .line 33
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    const-string v8, "parse(...)"

    .line 46
    .line 47
    invoke-static {v0, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v8

    .line 54
    const-string v9, "router path = "

    .line 55
    .line 56
    invoke-static {v9, v8}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v8

    .line 60
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v8

    .line 64
    invoke-static {v5, v4, v8}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 68
    .line 69
    .line 70
    move-result-object v8

    .line 71
    if-eqz v8, :cond_2

    .line 72
    .line 73
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 74
    .line 75
    .line 76
    move-result v8

    .line 77
    goto :goto_1

    .line 78
    :cond_2
    const/4 v8, -0x1

    .line 79
    :goto_1
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v9

    .line 83
    if-nez v9, :cond_3

    .line 84
    .line 85
    const-string v9, ""

    .line 86
    .line 87
    :cond_3
    new-instance v10, Landroid/os/Bundle;

    .line 88
    .line 89
    invoke-direct {v10}, Landroid/os/Bundle;-><init>()V

    .line 90
    .line 91
    .line 92
    const-string v11, "applyId"

    .line 93
    .line 94
    iget-object v12, v1, Ljb/o;->e:Ljava/lang/String;

    .line 95
    .line 96
    invoke-virtual {v10, v11, v12}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    const-string v11, "loanProduct"

    .line 100
    .line 101
    iget-object v12, v1, Ljb/o;->k:Ljava/lang/String;

    .line 102
    .line 103
    invoke-virtual {v10, v11, v12}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    iget-object v11, v1, Ljb/o;->k:Ljava/lang/String;

    .line 107
    .line 108
    const-string v12, "LOAN_WITHDRAW"

    .line 109
    .line 110
    invoke-static {v11, v12}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 111
    .line 112
    .line 113
    move-result v11

    .line 114
    if-eqz v11, :cond_4

    .line 115
    .line 116
    const-string v11, "LOAN_BORROW"

    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_4
    const-string v11, "LOAN_CREDIT"

    .line 120
    .line 121
    :goto_2
    const-string v12, "scene"

    .line 122
    .line 123
    invoke-virtual {v10, v12, v11}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    const-string v11, "routePath"

    .line 127
    .line 128
    invoke-virtual {v10, v11, v9}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    const-string v11, "routeInfo"

    .line 132
    .line 133
    iget-object v13, v1, Ljb/o;->x:Ljava/lang/String;

    .line 134
    .line 135
    invoke-virtual {v10, v11, v13}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    const-string v11, "routeId"

    .line 139
    .line 140
    invoke-virtual {v10, v11, v8}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v1}, Ljb/o;->q()Z

    .line 144
    .line 145
    .line 146
    move-result v11

    .line 147
    const/4 v13, 0x5

    .line 148
    if-eqz v11, :cond_a

    .line 149
    .line 150
    sget-object v11, Llb/f;->e:Llb/e;

    .line 151
    .line 152
    invoke-virtual {v11}, Llb/e;->getInstance()Llb/f;

    .line 153
    .line 154
    .line 155
    move-result-object v11

    .line 156
    iget-object v11, v11, Llb/f;->d:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 157
    .line 158
    if-eqz v11, :cond_5

    .line 159
    .line 160
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 161
    .line 162
    .line 163
    move-result-object v14

    .line 164
    invoke-virtual {v1, v14, v7}, Ljb/o;->j(Ljava/lang/Integer;Z)I

    .line 165
    .line 166
    .line 167
    move-result v14

    .line 168
    iput v14, v11, Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;->currentIndex:I

    .line 169
    .line 170
    :cond_5
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 171
    .line 172
    .line 173
    move-result-object v11

    .line 174
    invoke-virtual {v1, v11, v6}, Ljb/o;->r(Ljava/lang/Integer;Ljava/lang/String;)Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 175
    .line 176
    .line 177
    move-result-object v11

    .line 178
    if-eqz v11, :cond_a

    .line 179
    .line 180
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getName()Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v14

    .line 184
    invoke-virtual {v11}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getType()Ljava/lang/Integer;

    .line 185
    .line 186
    .line 187
    move-result-object v11

    .line 188
    new-instance v15, Ljava/lang/StringBuilder;

    .line 189
    .line 190
    const-string v6, "isDynamicRnRoute, intercept >>> routeType="

    .line 191
    .line 192
    invoke-direct {v15, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v15, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 196
    .line 197
    .line 198
    const-string v6, ", routePath="

    .line 199
    .line 200
    invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 201
    .line 202
    .line 203
    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 204
    .line 205
    .line 206
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v6

    .line 210
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    move-result-object v6

    .line 214
    invoke-static {v5, v4, v6}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 215
    .line 216
    .line 217
    if-eqz v14, :cond_7

    .line 218
    .line 219
    sget-object v6, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->RN:Lcom/transsnet/palmpay/credit/bean/RoutePageType;

    .line 220
    .line 221
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->getCode()I

    .line 222
    .line 223
    .line 224
    move-result v6

    .line 225
    if-nez v11, :cond_6

    .line 226
    .line 227
    goto :goto_3

    .line 228
    :cond_6
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 229
    .line 230
    .line 231
    move-result v15

    .line 232
    if-ne v15, v6, :cond_7

    .line 233
    .line 234
    const-string v0, "isDynamicRnRoute, jump rn page >>> "

    .line 235
    .line 236
    invoke-virtual {v0, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v0

    .line 240
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    invoke-static {v5, v13, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 245
    .line 246
    .line 247
    invoke-static {v10, v14}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    return-void

    .line 251
    :cond_7
    :goto_3
    if-eqz v14, :cond_9

    .line 252
    .line 253
    sget-object v6, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->H5:Lcom/transsnet/palmpay/credit/bean/RoutePageType;

    .line 254
    .line 255
    invoke-virtual {v6}, Lcom/transsnet/palmpay/credit/bean/RoutePageType;->getCode()I

    .line 256
    .line 257
    .line 258
    move-result v6

    .line 259
    if-nez v11, :cond_8

    .line 260
    .line 261
    goto :goto_4

    .line 262
    :cond_8
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 263
    .line 264
    .line 265
    move-result v11

    .line 266
    if-ne v11, v6, :cond_9

    .line 267
    .line 268
    const-string v0, "isDynamicRnRoute, jump h5 page >>> "

    .line 269
    .line 270
    invoke-virtual {v0, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    move-result-object v0

    .line 274
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 275
    .line 276
    .line 277
    move-result-object v0

    .line 278
    invoke-static {v5, v13, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 279
    .line 280
    .line 281
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 282
    .line 283
    .line 284
    move-result-object v0

    .line 285
    invoke-virtual {v1, v0, v14}, Ljb/o;->A(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 286
    .line 287
    .line 288
    return-void

    .line 289
    :cond_9
    :goto_4
    const-string v6, "isDynamicRnRoute, intercept >>> continue"

    .line 290
    .line 291
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 292
    .line 293
    .line 294
    move-result-object v6

    .line 295
    const/4 v11, 0x4

    .line 296
    invoke-static {v5, v11, v6}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 297
    .line 298
    .line 299
    :cond_a
    invoke-virtual {v0}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object v6

    .line 303
    if-eqz v6, :cond_1f

    .line 304
    .line 305
    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    .line 306
    .line 307
    .line 308
    move-result v11

    .line 309
    const-string v14, "type"

    .line 310
    .line 311
    sparse-switch v11, :sswitch_data_0

    .line 312
    .line 313
    .line 314
    goto/16 :goto_5

    .line 315
    .line 316
    :sswitch_0
    const-string v0, "/coreImpl/add_new_card"

    .line 317
    .line 318
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v0

    .line 322
    if-nez v0, :cond_1d

    .line 323
    .line 324
    goto/16 :goto_5

    .line 325
    .line 326
    :sswitch_1
    const-string v0, "oc_verify_otp_rn_router"

    .line 327
    .line 328
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 329
    .line 330
    .line 331
    move-result v0

    .line 332
    if-nez v0, :cond_b

    .line 333
    .line 334
    goto/16 :goto_5

    .line 335
    .line 336
    :cond_b
    const-string v0, "LoanOtpVerify"

    .line 337
    .line 338
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    return-void

    .line 342
    :sswitch_2
    const-string v0, "oc_business_info_rn_router"

    .line 343
    .line 344
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 345
    .line 346
    .line 347
    move-result v0

    .line 348
    if-nez v0, :cond_c

    .line 349
    .line 350
    goto/16 :goto_5

    .line 351
    .line 352
    :cond_c
    const-string v0, "LoanBusinessInfo"

    .line 353
    .line 354
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 355
    .line 356
    .line 357
    return-void

    .line 358
    :sswitch_3
    const-string v0, "/coreImpl/bind_new_bank_account"

    .line 359
    .line 360
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 361
    .line 362
    .line 363
    move-result v0

    .line 364
    if-nez v0, :cond_1d

    .line 365
    .line 366
    goto/16 :goto_5

    .line 367
    .line 368
    :sswitch_4
    const-string v0, "oc_verify_face_rn_router"

    .line 369
    .line 370
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 371
    .line 372
    .line 373
    move-result v0

    .line 374
    if-nez v0, :cond_d

    .line 375
    .line 376
    goto/16 :goto_5

    .line 377
    .line 378
    :cond_d
    const-string v0, "LoanFaceVerify"

    .line 379
    .line 380
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 381
    .line 382
    .line 383
    return-void

    .line 384
    :sswitch_5
    const-string v0, "oc_verify_kyc_both_rn_router"

    .line 385
    .line 386
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 387
    .line 388
    .line 389
    move-result v0

    .line 390
    if-nez v0, :cond_e

    .line 391
    .line 392
    goto/16 :goto_5

    .line 393
    .line 394
    :cond_e
    const-string v0, "both"

    .line 395
    .line 396
    const-string v2, "1"

    .line 397
    .line 398
    invoke-virtual {v10, v0, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 399
    .line 400
    .line 401
    iget-object v0, v1, Ljb/o;->k:Ljava/lang/String;

    .line 402
    .line 403
    invoke-virtual {v10, v12, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 404
    .line 405
    .line 406
    const-string v0, "businessType"

    .line 407
    .line 408
    iget-object v2, v1, Ljb/o;->l:Ljava/lang/String;

    .line 409
    .line 410
    invoke-virtual {v10, v0, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 411
    .line 412
    .line 413
    const-string v0, "LoanKycVerify"

    .line 414
    .line 415
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 416
    .line 417
    .line 418
    return-void

    .line 419
    :sswitch_6
    const-string v0, "oc_verify_kyc_bvn_rn_router"

    .line 420
    .line 421
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 422
    .line 423
    .line 424
    move-result v0

    .line 425
    if-nez v0, :cond_f

    .line 426
    .line 427
    goto/16 :goto_5

    .line 428
    .line 429
    :cond_f
    iget-object v0, v1, Ljb/o;->k:Ljava/lang/String;

    .line 430
    .line 431
    invoke-virtual {v10, v12, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 432
    .line 433
    .line 434
    const-string v0, "3"

    .line 435
    .line 436
    invoke-virtual {v10, v14, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 437
    .line 438
    .line 439
    const-string v0, "LoanKycHome"

    .line 440
    .line 441
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 442
    .line 443
    .line 444
    return-void

    .line 445
    :sswitch_7
    const-string v0, "oc_one_loop_router"

    .line 446
    .line 447
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 448
    .line 449
    .line 450
    move-result v0

    .line 451
    if-nez v0, :cond_10

    .line 452
    .line 453
    goto/16 :goto_5

    .line 454
    .line 455
    :cond_10
    iget-object v0, v1, Ljb/o;->e:Ljava/lang/String;

    .line 456
    .line 457
    const-string v2, "getOneLoopData >>>"

    .line 458
    .line 459
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 460
    .line 461
    .line 462
    move-result-object v2

    .line 463
    invoke-static {v5, v4, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 464
    .line 465
    .line 466
    sget-object v2, Lob/c;->a:Lob/a;

    .line 467
    .line 468
    invoke-virtual {v2}, Lob/a;->getInstance()Lob/c;

    .line 469
    .line 470
    .line 471
    move-result-object v2

    .line 472
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 473
    .line 474
    .line 475
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 476
    .line 477
    .line 478
    move-result-object v2

    .line 479
    invoke-interface {v2, v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->getOneLoopData(Ljava/lang/String;)Ldf/d;

    .line 480
    .line 481
    .line 482
    move-result-object v0

    .line 483
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 484
    .line 485
    .line 486
    sget-object v2, Ltf/f;->b:Ldf/i;

    .line 487
    .line 488
    invoke-virtual {v0, v2}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 489
    .line 490
    .line 491
    move-result-object v0

    .line 492
    new-instance v4, Lio/reactivex/internal/operators/observable/K;

    .line 493
    .line 494
    invoke-direct {v4, v0, v2, v3}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 495
    .line 496
    .line 497
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 498
    .line 499
    .line 500
    move-result-object v0

    .line 501
    invoke-virtual {v4, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 502
    .line 503
    .line 504
    move-result-object v0

    .line 505
    new-instance v2, Ljb/l;

    .line 506
    .line 507
    invoke-direct {v2, v1, v3}, Ljb/l;-><init>(Ljb/o;I)V

    .line 508
    .line 509
    .line 510
    invoke-virtual {v0, v2}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 511
    .line 512
    .line 513
    return-void

    .line 514
    :sswitch_8
    const-string v0, "oc_bank_auth_router"

    .line 515
    .line 516
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 517
    .line 518
    .line 519
    move-result v0

    .line 520
    if-nez v0, :cond_11

    .line 521
    .line 522
    goto/16 :goto_5

    .line 523
    .line 524
    :cond_11
    const-string v0, "BankAuth"

    .line 525
    .line 526
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 527
    .line 528
    .line 529
    return-void

    .line 530
    :sswitch_9
    const-string v0, "oc_business_expectation_rn_router"

    .line 531
    .line 532
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 533
    .line 534
    .line 535
    move-result v0

    .line 536
    if-nez v0, :cond_12

    .line 537
    .line 538
    goto/16 :goto_5

    .line 539
    .line 540
    :cond_12
    const-string v0, "LoanBusinessExpectation"

    .line 541
    .line 542
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 543
    .line 544
    .line 545
    return-void

    .line 546
    :sswitch_a
    const-string v0, "oc_add_contact_rn_router"

    .line 547
    .line 548
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 549
    .line 550
    .line 551
    move-result v0

    .line 552
    if-nez v0, :cond_13

    .line 553
    .line 554
    goto/16 :goto_5

    .line 555
    .line 556
    :cond_13
    const-string v0, "LoanContact"

    .line 557
    .line 558
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 559
    .line 560
    .line 561
    return-void

    .line 562
    :sswitch_b
    const-string v9, "oc_person_info_router"

    .line 563
    .line 564
    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 565
    .line 566
    .line 567
    move-result v6

    .line 568
    if-nez v6, :cond_14

    .line 569
    .line 570
    goto/16 :goto_5

    .line 571
    .line 572
    :cond_14
    invoke-virtual {v0, v14}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 573
    .line 574
    .line 575
    move-result-object v0

    .line 576
    invoke-virtual {v10, v14, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 577
    .line 578
    .line 579
    const-string v0, "PersonalInfoV2"

    .line 580
    .line 581
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 582
    .line 583
    .line 584
    return-void

    .line 585
    :sswitch_c
    const-string v0, "/settings/upgrape-kyc/verify"

    .line 586
    .line 587
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 588
    .line 589
    .line 590
    move-result v0

    .line 591
    if-nez v0, :cond_15

    .line 592
    .line 593
    goto/16 :goto_5

    .line 594
    .line 595
    :cond_15
    invoke-virtual {v1}, Ljb/o;->q()Z

    .line 596
    .line 597
    .line 598
    move-result v0

    .line 599
    if-eqz v0, :cond_16

    .line 600
    .line 601
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 602
    .line 603
    .line 604
    move-result-object v0

    .line 605
    invoke-virtual {v1, v0, v9}, Ljb/o;->A(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 606
    .line 607
    .line 608
    return-void

    .line 609
    :cond_16
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 610
    .line 611
    .line 612
    move-result-object v0

    .line 613
    const-string v2, "/credit_score/oc_kyc_router_activity"

    .line 614
    .line 615
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 616
    .line 617
    .line 618
    move-result-object v3

    .line 619
    invoke-virtual {v1, v0, v2, v3}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 620
    .line 621
    .line 622
    return-void

    .line 623
    :sswitch_d
    const-string v0, "/credit_score/all_operate_one_loop_activity"

    .line 624
    .line 625
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 626
    .line 627
    .line 628
    move-result v0

    .line 629
    if-nez v0, :cond_17

    .line 630
    .line 631
    goto/16 :goto_5

    .line 632
    .line 633
    :cond_17
    const-string v0, "querySkipOneLoop >>>"

    .line 634
    .line 635
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 636
    .line 637
    .line 638
    move-result-object v0

    .line 639
    invoke-static {v5, v4, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 640
    .line 641
    .line 642
    sget-object v0, Lob/c;->a:Lob/a;

    .line 643
    .line 644
    invoke-virtual {v0}, Lob/a;->getInstance()Lob/c;

    .line 645
    .line 646
    .line 647
    move-result-object v0

    .line 648
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 649
    .line 650
    .line 651
    invoke-static {}, Lob/c;->a()Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 652
    .line 653
    .line 654
    move-result-object v0

    .line 655
    invoke-interface {v0}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->querySkipOneLoop()Ldf/d;

    .line 656
    .line 657
    .line 658
    move-result-object v0

    .line 659
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 660
    .line 661
    .line 662
    sget-object v4, Ltf/f;->b:Ldf/i;

    .line 663
    .line 664
    invoke-virtual {v0, v4}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 665
    .line 666
    .line 667
    move-result-object v0

    .line 668
    new-instance v5, Lio/reactivex/internal/operators/observable/K;

    .line 669
    .line 670
    invoke-direct {v5, v0, v4, v3}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 671
    .line 672
    .line 673
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 674
    .line 675
    .line 676
    move-result-object v0

    .line 677
    invoke-virtual {v5, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 678
    .line 679
    .line 680
    move-result-object v0

    .line 681
    new-instance v3, Ljb/l;

    .line 682
    .line 683
    invoke-direct {v3, v1, v2}, Ljb/l;-><init>(Ljb/o;I)V

    .line 684
    .line 685
    .line 686
    invoke-virtual {v0, v3}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 687
    .line 688
    .line 689
    return-void

    .line 690
    :sswitch_e
    const-string v0, "/coreImpl/use_new_card"

    .line 691
    .line 692
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 693
    .line 694
    .line 695
    move-result v0

    .line 696
    if-nez v0, :cond_1d

    .line 697
    .line 698
    goto/16 :goto_5

    .line 699
    .line 700
    :sswitch_f
    const-string v0, "oc_opay_reverse_router"

    .line 701
    .line 702
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 703
    .line 704
    .line 705
    move-result v0

    .line 706
    if-nez v0, :cond_18

    .line 707
    .line 708
    goto :goto_5

    .line 709
    :cond_18
    const-string v0, "LoanOpayReverse"

    .line 710
    .line 711
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 712
    .line 713
    .line 714
    return-void

    .line 715
    :sswitch_10
    const-string v0, "/account/upgrade"

    .line 716
    .line 717
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 718
    .line 719
    .line 720
    move-result v0

    .line 721
    if-nez v0, :cond_19

    .line 722
    .line 723
    goto :goto_5

    .line 724
    :cond_19
    invoke-virtual {v1}, Ljb/o;->q()Z

    .line 725
    .line 726
    .line 727
    move-result v0

    .line 728
    if-eqz v0, :cond_1a

    .line 729
    .line 730
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 731
    .line 732
    .line 733
    move-result-object v0

    .line 734
    invoke-virtual {v1, v0, v9}, Ljb/o;->A(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 735
    .line 736
    .line 737
    return-void

    .line 738
    :cond_1a
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 739
    .line 740
    .line 741
    move-result-object v0

    .line 742
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 743
    .line 744
    .line 745
    move-result-object v2

    .line 746
    invoke-virtual {v1, v0, v2}, Ljb/o;->l(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 747
    .line 748
    .line 749
    return-void

    .line 750
    :sswitch_11
    const-string v0, "oc_bank_verify_router"

    .line 751
    .line 752
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 753
    .line 754
    .line 755
    move-result v0

    .line 756
    if-nez v0, :cond_1b

    .line 757
    .line 758
    goto :goto_5

    .line 759
    :cond_1b
    const-string v0, "BankVerify"

    .line 760
    .line 761
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 762
    .line 763
    .line 764
    return-void

    .line 765
    :sswitch_12
    const-string v0, "oc_loan_expectation_router"

    .line 766
    .line 767
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 768
    .line 769
    .line 770
    move-result v0

    .line 771
    if-nez v0, :cond_1c

    .line 772
    .line 773
    goto :goto_5

    .line 774
    :cond_1c
    const-string v0, "LoanExpectation"

    .line 775
    .line 776
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 777
    .line 778
    .line 779
    return-void

    .line 780
    :sswitch_13
    const-string v0, "/credit_score/oc_all_verify_activity"

    .line 781
    .line 782
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 783
    .line 784
    .line 785
    move-result v0

    .line 786
    if-nez v0, :cond_1d

    .line 787
    .line 788
    goto :goto_5

    .line 789
    :cond_1d
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRouteId()Ljava/lang/Integer;

    .line 790
    .line 791
    .line 792
    move-result-object v0

    .line 793
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 794
    .line 795
    .line 796
    move-result-object v2

    .line 797
    invoke-virtual {v1, v0, v2}, Ljb/o;->l(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 798
    .line 799
    .line 800
    return-void

    .line 801
    :sswitch_14
    const-string v0, "oc_one_loop_rn_router"

    .line 802
    .line 803
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 804
    .line 805
    .line 806
    move-result v0

    .line 807
    if-nez v0, :cond_1e

    .line 808
    .line 809
    goto :goto_5

    .line 810
    :cond_1e
    const-string v0, "LoanOneLoop"

    .line 811
    .line 812
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 813
    .line 814
    .line 815
    return-void

    .line 816
    :cond_1f
    :goto_5
    invoke-virtual/range {p1 .. p1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 817
    .line 818
    .line 819
    move-result-object v6

    .line 820
    if-eqz v6, :cond_2b

    .line 821
    .line 822
    invoke-static {v6}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 823
    .line 824
    .line 825
    move-result v0

    .line 826
    if-eqz v0, :cond_20

    .line 827
    .line 828
    goto/16 :goto_c

    .line 829
    .line 830
    :cond_20
    invoke-static {v6}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 831
    .line 832
    .line 833
    move-result-object v0

    .line 834
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 835
    .line 836
    .line 837
    move-result-object v0

    .line 838
    const-string v9, "arouter://coreImpl/rn_host"

    .line 839
    .line 840
    invoke-static {v0, v9, v3}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 841
    .line 842
    .line 843
    move-result v9

    .line 844
    if-nez v9, :cond_21

    .line 845
    .line 846
    const-string v9, "/coreImpl/rn_host"

    .line 847
    .line 848
    invoke-static {v0, v9, v3}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 849
    .line 850
    .line 851
    move-result v9

    .line 852
    if-eqz v9, :cond_2b

    .line 853
    .line 854
    :cond_21
    const-string v9, "rn_module_name="

    .line 855
    .line 856
    invoke-static {v0, v9, v3}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 857
    .line 858
    .line 859
    move-result v0

    .line 860
    if-eqz v0, :cond_2b

    .line 861
    .line 862
    invoke-static {v6}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 863
    .line 864
    .line 865
    move-result v0

    .line 866
    if-eqz v0, :cond_23

    .line 867
    .line 868
    :cond_22
    :goto_6
    const/4 v0, 0x0

    .line 869
    goto/16 :goto_a

    .line 870
    .line 871
    :cond_23
    :try_start_0
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 872
    .line 873
    invoke-static {v6}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 874
    .line 875
    .line 876
    move-result-object v0

    .line 877
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 878
    .line 879
    .line 880
    move-result-object v0

    .line 881
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 882
    .line 883
    .line 884
    move-result-object v0

    .line 885
    const-string v8, "rn_module_name"

    .line 886
    .line 887
    invoke-virtual {v0, v8}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 888
    .line 889
    .line 890
    move-result-object v0

    .line 891
    if-eqz v0, :cond_25

    .line 892
    .line 893
    invoke-static {v0}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 894
    .line 895
    .line 896
    move-result v8

    .line 897
    if-eqz v8, :cond_24

    .line 898
    .line 899
    goto :goto_7

    .line 900
    :cond_24
    invoke-static {v0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 901
    .line 902
    .line 903
    move-result-object v0

    .line 904
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 905
    .line 906
    .line 907
    move-result-object v0

    .line 908
    goto :goto_a

    .line 909
    :catchall_0
    move-exception v0

    .line 910
    goto :goto_8

    .line 911
    :cond_25
    :goto_7
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 912
    .line 913
    goto :goto_9

    .line 914
    :goto_8
    sget-object v8, Lxf/q;->a:Lxf/o;

    .line 915
    .line 916
    invoke-static {v0}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 917
    .line 918
    .line 919
    move-result-object v0

    .line 920
    :goto_9
    invoke-static {v0}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 921
    .line 922
    .line 923
    move-result-object v0

    .line 924
    if-eqz v0, :cond_26

    .line 925
    .line 926
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 927
    .line 928
    .line 929
    move-result-object v0

    .line 930
    const-string v8, "extractRnModuleName >>> parse uri failed, "

    .line 931
    .line 932
    invoke-static {v8, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 933
    .line 934
    .line 935
    move-result-object v0

    .line 936
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 937
    .line 938
    .line 939
    move-result-object v0

    .line 940
    invoke-static {v5, v13, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 941
    .line 942
    .line 943
    :cond_26
    invoke-static {v6, v9, v7, v3, v2}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 944
    .line 945
    .line 946
    move-result v0

    .line 947
    if-gez v0, :cond_27

    .line 948
    .line 949
    goto :goto_6

    .line 950
    :cond_27
    add-int/lit8 v0, v0, 0xf

    .line 951
    .line 952
    invoke-virtual {v6, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 953
    .line 954
    .line 955
    move-result-object v0

    .line 956
    const-string v2, "substring(...)"

    .line 957
    .line 958
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 959
    .line 960
    .line 961
    const/16 v3, 0x26

    .line 962
    .line 963
    const/4 v8, 0x6

    .line 964
    invoke-static {v0, v3, v7, v8}, Lkotlin/text/StringsKt;->D(Ljava/lang/CharSequence;CII)I

    .line 965
    .line 966
    .line 967
    move-result v3

    .line 968
    if-ltz v3, :cond_28

    .line 969
    .line 970
    invoke-virtual {v0, v7, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 971
    .line 972
    .line 973
    move-result-object v0

    .line 974
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 975
    .line 976
    .line 977
    :cond_28
    invoke-static {v0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 978
    .line 979
    .line 980
    move-result-object v0

    .line 981
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 982
    .line 983
    .line 984
    move-result-object v0

    .line 985
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 986
    .line 987
    .line 988
    move-result v2

    .line 989
    if-lez v2, :cond_22

    .line 990
    .line 991
    :goto_a
    if-eqz v0, :cond_2a

    .line 992
    .line 993
    invoke-static {v0}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 994
    .line 995
    .line 996
    move-result v2

    .line 997
    if-eqz v2, :cond_29

    .line 998
    .line 999
    goto :goto_b

    .line 1000
    :cond_29
    const-string v2, "interceptRouter >>> dynamic rn_host, moduleName="

    .line 1001
    .line 1002
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 1003
    .line 1004
    .line 1005
    move-result-object v2

    .line 1006
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 1007
    .line 1008
    .line 1009
    move-result-object v2

    .line 1010
    invoke-static {v5, v4, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 1011
    .line 1012
    .line 1013
    invoke-static {v10, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 1014
    .line 1015
    .line 1016
    return-void

    .line 1017
    :cond_2a
    :goto_b
    const-string v0, "interceptRouter >>> dynamic rn_host but module name is empty, routePath="

    .line 1018
    .line 1019
    invoke-virtual {v0, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 1020
    .line 1021
    .line 1022
    move-result-object v0

    .line 1023
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 1024
    .line 1025
    .line 1026
    move-result-object v0

    .line 1027
    invoke-static {v5, v0}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1028
    .line 1029
    .line 1030
    const-string v0, "Sorry, the service is unavailable now (code-4)"

    .line 1031
    .line 1032
    new-array v2, v7, [Ljava/lang/Object;

    .line 1033
    .line 1034
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 1035
    .line 1036
    .line 1037
    return-void

    .line 1038
    :cond_2b
    :goto_c
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1039
    .line 1040
    .line 1041
    move-result-object v0

    .line 1042
    const/4 v2, 0x0

    .line 1043
    invoke-virtual {v1, v0, v6, v2}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 1044
    .line 1045
    .line 1046
    return-void

    .line 1047
    :sswitch_data_0
    .sparse-switch
        -0x7f68e9eb -> :sswitch_14
        -0x79eccc60 -> :sswitch_13
        -0x7763f310 -> :sswitch_12
        -0x7686dea9 -> :sswitch_11
        -0x66f75fd5 -> :sswitch_10
        -0x62393c7f -> :sswitch_f
        -0x4d2c5518 -> :sswitch_e
        -0x478a467c -> :sswitch_d
        -0x30fe26b3 -> :sswitch_c
        -0x288e8da5 -> :sswitch_b
        -0x142eeafc -> :sswitch_a
        -0x810ff0b -> :sswitch_9
        -0x3b454b8 -> :sswitch_8
        -0x3105380 -> :sswitch_7
        0x707ff02 -> :sswitch_6
        0x1c1b1713 -> :sswitch_5
        0x3350c7a5 -> :sswitch_4
        0x4c40436a -> :sswitch_3
        0x4db2354f -> :sswitch_2
        0x55b586dd -> :sswitch_1
        0x6b42d50e -> :sswitch_0
    .end sparse-switch
.end method

.method public final q()Z
    .locals 2

    .line 1
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 2
    .line 3
    const-string v1, "PALMPAY_BUSINESS_LOAN"

    .line 4
    .line 5
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public final r(Ljava/lang/Integer;Ljava/lang/String;)Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;
    .locals 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "isDynamicRnRoute >>> routeId="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, ", routePath="

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const/4 v1, 0x3

    .line 28
    const-string v2, "CreditRouterManager"

    .line 29
    .line 30
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Ljb/o;->y:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    const/4 v1, 0x0

    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    goto/16 :goto_5

    .line 43
    .line 44
    :cond_0
    if-nez p1, :cond_1

    .line 45
    .line 46
    if-nez p2, :cond_1

    .line 47
    .line 48
    const-string p1, "isDynamicRnRoute >>> routeId and routePath are null"

    .line 49
    .line 50
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    invoke-static {v2, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    return-object v1

    .line 58
    :cond_1
    :try_start_0
    sget-object v0, Lxf/q;->a:Lxf/o;

    .line 59
    .line 60
    new-instance v0, Lcom/transsnet/palmpay/credit/hook/CreditRouterManager$isDynamicRnRoute$1$listType$1;

    .line 61
    .line 62
    invoke-direct {v0}, Lcom/transsnet/palmpay/credit/hook/CreditRouterManager$isDynamicRnRoute$1$listType$1;-><init>()V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0}, Lcom/google/gson/reflect/TypeToken;->getType()Ljava/lang/reflect/Type;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 70
    .line 71
    .line 72
    move-result-object v3

    .line 73
    iget-object v4, p0, Ljb/o;->y:Ljava/lang/String;

    .line 74
    .line 75
    invoke-virtual {v3, v4, v0}, LPa/w;->e(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    const-string v3, "fromJson(...)"

    .line 80
    .line 81
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    check-cast v0, Ljava/util/List;

    .line 85
    .line 86
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 87
    .line 88
    .line 89
    move-result v3

    .line 90
    if-eqz v3, :cond_2

    .line 91
    .line 92
    goto/16 :goto_5

    .line 93
    .line 94
    :cond_2
    if-eqz p1, :cond_6

    .line 95
    .line 96
    check-cast v0, Ljava/lang/Iterable;

    .line 97
    .line 98
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 99
    .line 100
    .line 101
    move-result-object p2

    .line 102
    :cond_3
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-eqz v0, :cond_5

    .line 107
    .line 108
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    move-object v3, v0

    .line 113
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 114
    .line 115
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getParams()Lcom/transsnet/palmpay/credit/bean/RouterPageInfoParams;

    .line 116
    .line 117
    .line 118
    move-result-object v3

    .line 119
    if-eqz v3, :cond_4

    .line 120
    .line 121
    iget-object v3, v3, Lcom/transsnet/palmpay/credit/bean/RouterPageInfoParams;->routeId:Ljava/lang/Integer;

    .line 122
    .line 123
    goto :goto_0

    .line 124
    :catchall_0
    move-exception p1

    .line 125
    goto :goto_3

    .line 126
    :cond_4
    move-object v3, v1

    .line 127
    :goto_0
    invoke-static {v3, p1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result v3

    .line 131
    if-eqz v3, :cond_3

    .line 132
    .line 133
    goto :goto_1

    .line 134
    :cond_5
    move-object v0, v1

    .line 135
    :goto_1
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 136
    .line 137
    return-object v0

    .line 138
    :cond_6
    if-eqz p2, :cond_9

    .line 139
    .line 140
    check-cast v0, Ljava/lang/Iterable;

    .line 141
    .line 142
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    :cond_7
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    if-eqz v0, :cond_8

    .line 151
    .line 152
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    move-object v3, v0

    .line 157
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 158
    .line 159
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;->getName()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v3

    .line 163
    if-eqz v3, :cond_7

    .line 164
    .line 165
    const/4 v4, 0x0

    .line 166
    invoke-static {v3, p2, v4}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 167
    .line 168
    .line 169
    move-result v3

    .line 170
    const/4 v4, 0x1

    .line 171
    if-ne v3, v4, :cond_7

    .line 172
    .line 173
    goto :goto_2

    .line 174
    :cond_8
    move-object v0, v1

    .line 175
    :goto_2
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/RouterPageInfo;

    .line 176
    .line 177
    return-object v0

    .line 178
    :cond_9
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 179
    .line 180
    goto :goto_4

    .line 181
    :goto_3
    sget-object p2, Lxf/q;->a:Lxf/o;

    .line 182
    .line 183
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    :goto_4
    invoke-static {p1}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    if-eqz p1, :cond_a

    .line 192
    .line 193
    new-instance p2, Ljava/lang/StringBuilder;

    .line 194
    .line 195
    const-string v0, "isDynamicRnRoute >>> error , "

    .line 196
    .line 197
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 201
    .line 202
    .line 203
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object p1

    .line 211
    invoke-static {v2, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    :cond_a
    :goto_5
    return-object v1
.end method

.method public final s()V
    .locals 7

    .line 1
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 2
    .line 3
    const-string v1, "routerComplete >>> product = "

    .line 4
    .line 5
    invoke-static {v1, v0}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const/4 v1, 0x3

    .line 14
    const-string v2, "CreditRouterManager"

    .line 15
    .line 16
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 20
    .line 21
    const-string v3, "LOAN_WITHDRAW"

    .line 22
    .line 23
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    const/4 v3, 0x0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    iget v0, p0, Ljb/o;->p:I

    .line 31
    .line 32
    const/4 v1, 0x1

    .line 33
    if-ne v0, v1, :cond_0

    .line 34
    .line 35
    const-string v0, "/credit_score/cl_last_protocol_activity"

    .line 36
    .line 37
    invoke-virtual {p0, v3, v0, v3}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :cond_0
    invoke-virtual {p0, v3}, Ljb/o;->e(Lcom/transsnet/palmpay/core/bean/JumpLinkInfo;)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :cond_1
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 46
    .line 47
    const-string v4, "OK_CARD"

    .line 48
    .line 49
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    const-string v0, "/credit_score/oc_last_protocol_activity"

    .line 56
    .line 57
    invoke-virtual {p0, v3, v0, v3}, Ljb/o;->y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :cond_2
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 62
    .line 63
    const-string v4, "CASH_LOAN"

    .line 64
    .line 65
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-nez v0, :cond_4

    .line 70
    .line 71
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 72
    .line 73
    const-string v4, "CASH_INSTANT_LOAN"

    .line 74
    .line 75
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-nez v0, :cond_4

    .line 80
    .line 81
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 82
    .line 83
    const-string v4, "INSTALLMENT_LOAN"

    .line 84
    .line 85
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-nez v0, :cond_4

    .line 90
    .line 91
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 92
    .line 93
    const-string v4, "PALMPAY_CARD"

    .line 94
    .line 95
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-nez v0, :cond_4

    .line 100
    .line 101
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 102
    .line 103
    const-string v4, "PALMPAY_BUSINESS_LOAN"

    .line 104
    .line 105
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_3

    .line 110
    .line 111
    goto :goto_0

    .line 112
    :cond_3
    iget-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 113
    .line 114
    iget-object v4, p0, Ljb/o;->k:Ljava/lang/String;

    .line 115
    .line 116
    const-string v5, "upgradeCashLoan, mApplyId = "

    .line 117
    .line 118
    const-string v6, ",  mProduct = "

    .line 119
    .line 120
    invoke-static {v5, v0, v6, v4}, LC0/G;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    sget-object v0, Lob/c;->a:Lob/a;

    .line 132
    .line 133
    invoke-static {v0}, LC0/G;->h(Lob/a;)Lcom/transsnet/palmpay/credit/network/IApiCreditService;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    iget-object v1, p0, Ljb/o;->e:Ljava/lang/String;

    .line 138
    .line 139
    iget-object v2, p0, Ljb/o;->k:Ljava/lang/String;

    .line 140
    .line 141
    invoke-interface {v0, v1, v3, v2}, Lcom/transsnet/palmpay/credit/network/IApiCreditService;->installmentRaiseAmountV2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ldf/d;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    .line 147
    .line 148
    sget-object v1, Ltf/f;->b:Ldf/i;

    .line 149
    .line 150
    invoke-virtual {v0, v1}, Ldf/d;->k(Ldf/i;)Lio/reactivex/internal/operators/observable/K;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    new-instance v2, Lio/reactivex/internal/operators/observable/K;

    .line 155
    .line 156
    const/4 v3, 0x1

    .line 157
    invoke-direct {v2, v0, v1, v3}, Lio/reactivex/internal/operators/observable/K;-><init>(Ldf/d;Ldf/i;I)V

    .line 158
    .line 159
    .line 160
    invoke-static {}, Lef/b;->a()Lef/d;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    invoke-virtual {v2, v0}, Ldf/d;->i(Ldf/i;)Lio/reactivex/internal/operators/observable/q;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    new-instance v1, Ljb/l;

    .line 169
    .line 170
    const/4 v2, 0x5

    .line 171
    invoke-direct {v1, p0, v2}, Ljb/l;-><init>(Ljb/o;I)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v0, v1}, Ldf/d;->subscribe(Lio/reactivex/Observer;)V

    .line 175
    .line 176
    .line 177
    return-void

    .line 178
    :cond_4
    :goto_0
    invoke-virtual {p0}, Ljb/o;->c()V

    .line 179
    .line 180
    .line 181
    return-void
.end method

.method public final t(I)V
    .locals 5

    .line 1
    const-string v0, "routerExit >>> "

    .line 2
    .line 3
    invoke-static {p1, v0}, LC0/G;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const/4 v1, 0x3

    .line 12
    const-string v2, "CreditRouterManager"

    .line 13
    .line 14
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Ljb/o;->q()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    invoke-virtual {p0}, Ljb/o;->f()V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :cond_0
    iget v0, p0, Ljb/o;->m:I

    .line 28
    .line 29
    if-ne p1, v0, :cond_1

    .line 30
    .line 31
    add-int/lit8 v0, v0, -0x1

    .line 32
    .line 33
    iput v0, p0, Ljb/o;->m:I

    .line 34
    .line 35
    invoke-virtual {p0, v0}, Ljb/o;->C(I)V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :cond_1
    const-string v3, "\u89d2\u6807\u6821\u9a8c "

    .line 40
    .line 41
    const-string v4, " : "

    .line 42
    .line 43
    invoke-static {p1, v3, v0, v4}, Landroidx/camera/video/u;->h(ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public final v(I)V
    .locals 10

    .line 1
    const-string v0, "routerNext >>>"

    .line 2
    .line 3
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x3

    .line 8
    const-string v2, "CreditRouterManager"

    .line 9
    .line 10
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0}, Ljb/o;->q()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/4 v3, 0x0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    iget-object p1, p0, Ljb/o;->x:Ljava/lang/String;

    .line 21
    .line 22
    const-string v0, "doRouterNext >>> routeNodeInfo="

    .line 23
    .line 24
    invoke-static {v0, p1}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iget-boolean p1, p0, Ljb/o;->v:Z

    .line 36
    .line 37
    if-nez p1, :cond_0

    .line 38
    .line 39
    iget-object p1, p0, Ljb/o;->x:Ljava/lang/String;

    .line 40
    .line 41
    const-string v0, "NoticeCreditRouteNext"

    .line 42
    .line 43
    invoke-static {v0, p1, v3}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    return-void

    .line 47
    :cond_1
    iget-boolean v0, p0, Ljb/o;->t:Z

    .line 48
    .line 49
    const/4 v4, -0x1

    .line 50
    if-eq p1, v4, :cond_2

    .line 51
    .line 52
    iget v5, p0, Ljb/o;->m:I

    .line 53
    .line 54
    if-eq p1, v5, :cond_2

    .line 55
    .line 56
    if-eqz v0, :cond_2

    .line 57
    .line 58
    const-string v0, "anyVerified, need fix route index"

    .line 59
    .line 60
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    const/4 v5, 0x4

    .line 65
    invoke-static {v2, v5, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    iput p1, p0, Ljb/o;->m:I

    .line 69
    .line 70
    :cond_2
    iget v0, p0, Ljb/o;->m:I

    .line 71
    .line 72
    const-string v5, "errorMsg"

    .line 73
    .line 74
    const-string v6, "applyId"

    .line 75
    .line 76
    const-string v7, "loanProduct"

    .line 77
    .line 78
    const-string v8, "CreditRouterManager_routerNext"

    .line 79
    .line 80
    const/4 v9, 0x0

    .line 81
    if-eq p1, v0, :cond_3

    .line 82
    .line 83
    const-string v3, "\u89d2\u6807\u6821\u9a8c "

    .line 84
    .line 85
    const-string v4, " : "

    .line 86
    .line 87
    invoke-static {p1, v3, v0, v4}, Landroidx/camera/video/u;->h(ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    invoke-static {v2, v1, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    const-string p1, "Sorry, the service is unavailable now (code-0)"

    .line 99
    .line 100
    new-array v0, v9, [Ljava/lang/Object;

    .line 101
    .line 102
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 110
    .line 111
    new-instance v1, Lkotlin/Pair;

    .line 112
    .line 113
    invoke-direct {v1, v7, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    iget-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 117
    .line 118
    new-instance v2, Lkotlin/Pair;

    .line 119
    .line 120
    invoke-direct {v2, v6, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    new-instance v0, Lkotlin/Pair;

    .line 124
    .line 125
    const-string v3, "curIndex != mCurrentIndex"

    .line 126
    .line 127
    invoke-direct {v0, v5, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    filled-new-array {v1, v2, v0}, [Lkotlin/Pair;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    invoke-static {v0}, Lkotlin/collections/G;->g([Lkotlin/Pair;)Ljava/util/Map;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    invoke-virtual {p1, v8, v0}, LPa/n0;->r(Ljava/lang/String;Ljava/util/Map;)V

    .line 139
    .line 140
    .line 141
    return-void

    .line 142
    :cond_3
    const/4 p1, 0x1

    .line 143
    if-ne v0, v4, :cond_5

    .line 144
    .line 145
    invoke-virtual {p0}, Ljb/o;->n()Z

    .line 146
    .line 147
    .line 148
    move-result v0

    .line 149
    if-eqz v0, :cond_4

    .line 150
    .line 151
    goto :goto_0

    .line 152
    :cond_4
    move p1, v9

    .line 153
    goto :goto_0

    .line 154
    :cond_5
    add-int/2addr p1, v0

    .line 155
    :goto_0
    invoke-virtual {p0, p1}, Ljb/o;->C(I)V

    .line 156
    .line 157
    .line 158
    iget-object v0, p0, Ljb/o;->d:Ljava/util/List;

    .line 159
    .line 160
    if-eqz v0, :cond_6

    .line 161
    .line 162
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    goto :goto_1

    .line 167
    :cond_6
    move v0, v9

    .line 168
    :goto_1
    if-lt p1, v0, :cond_7

    .line 169
    .line 170
    invoke-virtual {p0}, Ljb/o;->s()V

    .line 171
    .line 172
    .line 173
    return-void

    .line 174
    :cond_7
    if-gez p1, :cond_8

    .line 175
    .line 176
    const-string p1, "Sorry, the service is unavailable now (code-1)"

    .line 177
    .line 178
    new-array v0, v9, [Ljava/lang/Object;

    .line 179
    .line 180
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    iget-object v0, p0, Ljb/o;->k:Ljava/lang/String;

    .line 188
    .line 189
    new-instance v1, Lkotlin/Pair;

    .line 190
    .line 191
    invoke-direct {v1, v7, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 192
    .line 193
    .line 194
    iget-object v0, p0, Ljb/o;->e:Ljava/lang/String;

    .line 195
    .line 196
    new-instance v2, Lkotlin/Pair;

    .line 197
    .line 198
    invoke-direct {v2, v6, v0}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 199
    .line 200
    .line 201
    new-instance v0, Lkotlin/Pair;

    .line 202
    .line 203
    const-string v3, "nextRouteIndex < 0"

    .line 204
    .line 205
    invoke-direct {v0, v5, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 206
    .line 207
    .line 208
    filled-new-array {v1, v2, v0}, [Lkotlin/Pair;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    invoke-static {v0}, Lkotlin/collections/G;->g([Lkotlin/Pair;)Ljava/util/Map;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    invoke-virtual {p1, v8, v0}, LPa/n0;->r(Ljava/lang/String;Ljava/util/Map;)V

    .line 217
    .line 218
    .line 219
    return-void

    .line 220
    :cond_8
    iget-object v0, p0, Ljb/o;->d:Ljava/util/List;

    .line 221
    .line 222
    if-eqz v0, :cond_9

    .line 223
    .line 224
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    move-result-object p1

    .line 228
    move-object v3, p1

    .line 229
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 230
    .line 231
    :cond_9
    invoke-virtual {p0, v3}, Ljb/o;->p(Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;)V

    .line 232
    .line 233
    .line 234
    return-void
.end method

.method public final x()V
    .locals 6

    .line 1
    const-string v0, "routerStart >>>"

    .line 2
    .line 3
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x3

    .line 8
    const-string v2, "CreditRouterManager"

    .line 9
    .line 10
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0}, Ljb/o;->q()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_5

    .line 18
    .line 19
    sget-object v0, Llb/f;->e:Llb/e;

    .line 20
    .line 21
    invoke-virtual {v0}, Llb/e;->getInstance()Llb/f;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iget-object v3, p0, Ljb/o;->c:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 26
    .line 27
    iput-object v3, v0, Llb/f;->d:Lcom/transsnet/palmpay/credit/bean/CreditProcessInfo;

    .line 28
    .line 29
    iget-object v0, p0, Ljb/o;->d:Ljava/util/List;

    .line 30
    .line 31
    new-instance v3, Ljava/lang/StringBuilder;

    .line 32
    .line 33
    const-string v4, "doRouterStart >>> routerInfoList="

    .line 34
    .line 35
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iget-object v0, p0, Ljb/o;->d:Ljava/util/List;

    .line 53
    .line 54
    const/4 v1, 0x0

    .line 55
    if-eqz v0, :cond_3

    .line 56
    .line 57
    check-cast v0, Ljava/lang/Iterable;

    .line 58
    .line 59
    new-instance v2, Ljava/util/ArrayList;

    .line 60
    .line 61
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 62
    .line 63
    .line 64
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    if-eqz v3, :cond_2

    .line 73
    .line 74
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    move-object v4, v3

    .line 79
    check-cast v4, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 80
    .line 81
    if-eqz v4, :cond_1

    .line 82
    .line 83
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    goto :goto_1

    .line 88
    :cond_1
    move-object v4, v1

    .line 89
    :goto_1
    const-string v5, "oc_permission_router"

    .line 90
    .line 91
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v4

    .line 95
    if-nez v4, :cond_0

    .line 96
    .line 97
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    goto :goto_0

    .line 101
    :cond_2
    move-object v1, v2

    .line 102
    :cond_3
    iget-boolean v0, p0, Ljb/o;->v:Z

    .line 103
    .line 104
    if-nez v0, :cond_4

    .line 105
    .line 106
    new-instance v0, Lorg/json/JSONObject;

    .line 107
    .line 108
    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 109
    .line 110
    .line 111
    const-string v2, "applyId"

    .line 112
    .line 113
    iget-object v3, p0, Ljb/o;->e:Ljava/lang/String;

    .line 114
    .line 115
    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 116
    .line 117
    .line 118
    const-string v2, "loanProduct"

    .line 119
    .line 120
    iget-object v3, p0, Ljb/o;->k:Ljava/lang/String;

    .line 121
    .line 122
    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 123
    .line 124
    .line 125
    const-string v2, "customerTag"

    .line 126
    .line 127
    iget-object v3, p0, Ljb/o;->l:Ljava/lang/String;

    .line 128
    .line 129
    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 130
    .line 131
    .line 132
    const-string v2, "bindCard"

    .line 133
    .line 134
    const/4 v3, 0x0

    .line 135
    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 136
    .line 137
    .line 138
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    iget-object v2, v2, LPa/w;->b:Ljava/lang/Object;

    .line 143
    .line 144
    check-cast v2, Lcom/google/gson/Gson;

    .line 145
    .line 146
    invoke-virtual {v2, v1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v1

    .line 150
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    const-string v2, "NoticeCreditRouteStart"

    .line 155
    .line 156
    invoke-static {v2, v1, v0}, LPa/r0;->O1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    :cond_4
    return-void

    .line 160
    :cond_5
    iget v0, p0, Ljb/o;->m:I

    .line 161
    .line 162
    invoke-virtual {p0, v0}, Ljb/o;->v(I)V

    .line 163
    .line 164
    .line 165
    return-void
.end method

.method public final y(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;)V
    .locals 22

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    new-instance v4, Ljava/lang/StringBuilder;

    .line 10
    .line 11
    const-string v5, "routerTarget, routeId="

    .line 12
    .line 13
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    const-string v5, ", routerPath="

    .line 20
    .line 21
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string v5, ", url="

    .line 28
    .line 29
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    const/4 v5, 0x3

    .line 44
    const-string v6, "CreditRouterManager"

    .line 45
    .line 46
    invoke-static {v6, v5, v4}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    invoke-static {}, Lcom/transsnet/palmpay/util/ActivityUtils;->getTopActivity()Landroid/app/Activity;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    if-nez v4, :cond_0

    .line 54
    .line 55
    goto/16 :goto_5

    .line 56
    .line 57
    :cond_0
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 58
    .line 59
    .line 60
    move-result-object v7

    .line 61
    new-instance v8, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;

    .line 62
    .line 63
    iget-object v9, v1, Ljb/o;->j:Ljava/lang/String;

    .line 64
    .line 65
    iget-object v11, v1, Ljb/o;->e:Ljava/lang/String;

    .line 66
    .line 67
    iget-object v13, v1, Ljb/o;->g:Ljava/lang/Integer;

    .line 68
    .line 69
    iget-object v10, v1, Ljb/o;->l:Ljava/lang/String;

    .line 70
    .line 71
    iget-object v12, v1, Ljb/o;->k:Ljava/lang/String;

    .line 72
    .line 73
    iget-object v14, v1, Ljb/o;->d:Ljava/util/List;

    .line 74
    .line 75
    const/4 v15, 0x0

    .line 76
    const/16 v19, 0x0

    .line 77
    .line 78
    move-object/from16 v16, v10

    .line 79
    .line 80
    const/4 v10, 0x0

    .line 81
    move-object/from16 v17, v12

    .line 82
    .line 83
    const/4 v12, 0x0

    .line 84
    move-object/from16 v18, v14

    .line 85
    .line 86
    const/4 v14, 0x0

    .line 87
    const/16 v20, 0x46a

    .line 88
    .line 89
    const/16 v21, 0x0

    .line 90
    .line 91
    invoke-direct/range {v8 .. v21}, Lcom/transsnet/palmpay/credit/bean/req/OcApplyData;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 92
    .line 93
    .line 94
    iget-object v7, v7, LPa/w;->b:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast v7, Lcom/google/gson/Gson;

    .line 97
    .line 98
    invoke-virtual {v7, v8}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v7

    .line 102
    const/4 v8, -0x1

    .line 103
    :try_start_0
    sget-object v9, Lxf/q;->a:Lxf/o;

    .line 104
    .line 105
    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 106
    .line 107
    .line 108
    move-result-object v9

    .line 109
    const-string v10, "parse(...)"

    .line 110
    .line 111
    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 115
    .line 116
    .line 117
    move-result-object v10

    .line 118
    invoke-virtual {v9}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v11

    .line 122
    invoke-virtual {v10, v11}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 123
    .line 124
    .line 125
    move-result-object v10

    .line 126
    const-string v11, "build(...)"

    .line 127
    .line 128
    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v9}, Landroid/net/Uri;->getQuery()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v9

    .line 135
    invoke-static {v10, v9}, LPa/F;->h(Lcom/alibaba/android/arouter/facade/Postcard;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 136
    .line 137
    .line 138
    move-result-object v9

    .line 139
    const-string v10, "parseQueryString(...)"

    .line 140
    .line 141
    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 145
    .line 146
    .line 147
    move-result v10

    .line 148
    if-nez v10, :cond_1

    .line 149
    .line 150
    const-string v10, "jump_url"

    .line 151
    .line 152
    invoke-virtual {v9, v10, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 153
    .line 154
    .line 155
    goto :goto_0

    .line 156
    :catchall_0
    move-exception v0

    .line 157
    goto/16 :goto_3

    .line 158
    .line 159
    :cond_1
    :goto_0
    const-string v3, "/coreImpl/add_new_card"

    .line 160
    .line 161
    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 162
    .line 163
    .line 164
    move-result v2

    .line 165
    const/4 v3, 0x1

    .line 166
    if-eqz v2, :cond_2

    .line 167
    .line 168
    const-string v2, "business_type"

    .line 169
    .line 170
    const-wide/16 v10, 0x1

    .line 171
    .line 172
    invoke-virtual {v9, v2, v10, v11}, Lcom/alibaba/android/arouter/facade/Postcard;->withLong(Ljava/lang/String;J)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 173
    .line 174
    .line 175
    const-string v2, "me_bind_bank_card"

    .line 176
    .line 177
    invoke-virtual {v9, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withBoolean(Ljava/lang/String;Z)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 178
    .line 179
    .line 180
    :cond_2
    const-string v2, "applyId"

    .line 181
    .line 182
    iget-object v10, v1, Ljb/o;->e:Ljava/lang/String;

    .line 183
    .line 184
    invoke-virtual {v9, v2, v10}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 185
    .line 186
    .line 187
    move-result-object v2

    .line 188
    const-string v9, "oc_current_router_index"

    .line 189
    .line 190
    iget v10, v1, Ljb/o;->m:I

    .line 191
    .line 192
    invoke-virtual {v2, v9, v10}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 193
    .line 194
    .line 195
    move-result-object v2

    .line 196
    const-string v9, "oc_business_type"

    .line 197
    .line 198
    iget-object v10, v1, Ljb/o;->k:Ljava/lang/String;

    .line 199
    .line 200
    invoke-virtual {v2, v9, v10}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 201
    .line 202
    .line 203
    move-result-object v2

    .line 204
    const-string v9, "key_need_sign_type"

    .line 205
    .line 206
    iget v10, v1, Ljb/o;->p:I

    .line 207
    .line 208
    invoke-virtual {v2, v9, v10}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 209
    .line 210
    .line 211
    move-result-object v2

    .line 212
    const-string v9, "oc_scene_type"

    .line 213
    .line 214
    iget-object v10, v1, Ljb/o;->g:Ljava/lang/Integer;

    .line 215
    .line 216
    if-eqz v10, :cond_3

    .line 217
    .line 218
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 219
    .line 220
    .line 221
    move-result v10

    .line 222
    goto :goto_1

    .line 223
    :cond_3
    move v10, v8

    .line 224
    :goto_1
    invoke-virtual {v2, v9, v10}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 225
    .line 226
    .line 227
    move-result-object v2

    .line 228
    const-string v9, "oc_route_id"

    .line 229
    .line 230
    if-eqz v0, :cond_4

    .line 231
    .line 232
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 233
    .line 234
    .line 235
    move-result v0

    .line 236
    goto :goto_2

    .line 237
    :cond_4
    move v0, v8

    .line 238
    :goto_2
    invoke-virtual {v2, v9, v0}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    const-string v2, "oc_apply_data"

    .line 243
    .line 244
    invoke-virtual {v0, v2, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    const-string v2, "ext_business_data"

    .line 249
    .line 250
    invoke-virtual {v0, v2, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    const-string v2, "businessType"

    .line 255
    .line 256
    iget-object v7, v1, Ljb/o;->k:Ljava/lang/String;

    .line 257
    .line 258
    invoke-virtual {v0, v2, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    const-string v2, "jump_source"

    .line 263
    .line 264
    iget-object v7, v1, Ljb/o;->k:Ljava/lang/String;

    .line 265
    .line 266
    invoke-virtual {v0, v2, v7}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    const-string v2, "extra_type"

    .line 271
    .line 272
    invoke-virtual {v0, v2, v3}, Lcom/alibaba/android/arouter/facade/Postcard;->withInt(Ljava/lang/String;I)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 273
    .line 274
    .line 275
    move-result-object v0

    .line 276
    const/16 v2, 0x3e8

    .line 277
    .line 278
    invoke-virtual {v0, v4, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/app/Activity;I)V

    .line 279
    .line 280
    .line 281
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 282
    .line 283
    goto :goto_4

    .line 284
    :goto_3
    sget-object v2, Lxf/q;->a:Lxf/o;

    .line 285
    .line 286
    invoke-static {v0}, Landroidx/camera/core/impl/utils/executor/g;->f(Ljava/lang/Throwable;)Lxf/p;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    :goto_4
    instance-of v2, v0, Lxf/p;

    .line 291
    .line 292
    if-nez v2, :cond_5

    .line 293
    .line 294
    move-object v2, v0

    .line 295
    check-cast v2, Lkotlin/Unit;

    .line 296
    .line 297
    const-string v2, "routerTarget >>> success"

    .line 298
    .line 299
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    move-result-object v2

    .line 303
    invoke-static {v6, v5, v2}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 304
    .line 305
    .line 306
    :cond_5
    invoke-static {v0}, Lxf/q;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    if-eqz v0, :cond_6

    .line 311
    .line 312
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v2

    .line 316
    const-string v3, "routerTarget >>> failed, "

    .line 317
    .line 318
    invoke-static {v3, v2}, LC0/G;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 319
    .line 320
    .line 321
    move-result-object v2

    .line 322
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 323
    .line 324
    .line 325
    move-result-object v2

    .line 326
    invoke-static {v6, v2}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 327
    .line 328
    .line 329
    iget v2, v1, Ljb/o;->m:I

    .line 330
    .line 331
    add-int/2addr v2, v8

    .line 332
    iput v2, v1, Ljb/o;->m:I

    .line 333
    .line 334
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object v0

    .line 338
    const/4 v2, 0x0

    .line 339
    new-array v2, v2, [Ljava/lang/Object;

    .line 340
    .line 341
    invoke-static {v0, v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 342
    .line 343
    .line 344
    :cond_6
    :goto_5
    return-void
.end method
