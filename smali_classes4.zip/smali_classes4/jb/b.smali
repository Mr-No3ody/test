.class public final Ljb/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljb/a;

.field public static final b:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ljb/a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Ljb/a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Ljb/b;->a:Ljb/a;

    .line 8
    .line 9
    sget-object v0, Lxf/k;->a:Lxf/k;

    .line 10
    .line 11
    new-instance v1, Lcom/transsnet/palmpay/managemoney/ui/view/c;

    .line 12
    .line 13
    const/16 v2, 0x18

    .line 14
    .line 15
    invoke-direct {v1, v2}, Lcom/transsnet/palmpay/managemoney/ui/view/c;-><init>(I)V

    .line 16
    .line 17
    .line 18
    invoke-static {v0, v1}, Lxf/j;->a(Lxf/k;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    sput-object v0, Ljb/b;->b:Ljava/lang/Object;

    .line 23
    .line 24
    return-void
.end method
