.class public final Ljb/j;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljb/j;-><init>()V

    return-void
.end method


# virtual methods
.method public final getCREDIT_INTERCEPT_CODES()[Ljava/lang/String;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    sget-object v0, Ljb/o;->B:[Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getInstance()Ljb/o;
    .locals 1
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    sget-object v0, Ljb/o;->A:Ljb/o;

    .line 2
    .line 3
    return-object v0
.end method
