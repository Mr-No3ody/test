.class public final LUb/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/animation/Animation$AnimationListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/KeyEvent$Callback;


# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;I)V
    .locals 0

    .line 1
    iput p2, p0, LUb/b;->a:I

    iput-object p1, p0, LUb/b;->b:Landroid/view/KeyEvent$Callback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(Landroid/view/animation/Animation;)V
    .locals 0

    .line 1
    return-void
.end method

.method private final b(Landroid/view/animation/Animation;)V
    .locals 0

    .line 1
    return-void
.end method

.method private final c(Landroid/view/animation/Animation;)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/view/animation/Animation;)V
    .locals 4

    .line 1
    const-string v0, "animation"

    .line 2
    .line 3
    iget-object v1, p0, LUb/b;->b:Landroid/view/KeyEvent$Callback;

    .line 4
    .line 5
    iget v2, p0, LUb/b;->a:I

    .line 6
    .line 7
    packed-switch v2, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast v1, Landroid/view/View;

    .line 11
    .line 12
    const/16 p1, 0x8

    .line 13
    .line 14
    invoke-virtual {v1, p1}, Landroid/view/View;->setVisibility(I)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    sget-object p1, Lcom/transsnet/palmpay/ui/activity/HomeActivity;->H:Lcom/transsnet/palmpay/ui/activity/HomeActivity$a;

    .line 22
    .line 23
    check-cast v1, Lcom/transsnet/palmpay/ui/activity/HomeActivity;

    .line 24
    .line 25
    invoke-virtual {v1}, Lcom/transsnet/palmpay/ui/activity/HomeActivity;->u()V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_1
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    check-cast v1, Lcom/swmansion/rnscreens/stack/views/ScreensCoordinatorLayout;

    .line 33
    .line 34
    invoke-virtual {v1}, Lcom/swmansion/rnscreens/stack/views/ScreensCoordinatorLayout;->getFragment$react_native_screens_release()Lcom/swmansion/rnscreens/ScreenStackFragment;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-virtual {p1}, Lcom/swmansion/rnscreens/ScreenStackFragment;->onViewAnimationEnd()V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :pswitch_2
    check-cast v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;

    .line 43
    .line 44
    iget p1, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->A:I

    .line 45
    .line 46
    add-int/lit8 p1, p1, 0x1

    .line 47
    .line 48
    iput p1, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->A:I

    .line 49
    .line 50
    iget-object v0, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->B:Ljava/util/List;

    .line 51
    .line 52
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    const/4 v2, 0x0

    .line 57
    if-lt p1, v0, :cond_0

    .line 58
    .line 59
    iput v2, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->A:I

    .line 60
    .line 61
    :cond_0
    iget-object p1, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->B:Ljava/util/List;

    .line 62
    .line 63
    iget v0, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->A:I

    .line 64
    .line 65
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    invoke-virtual {v1, p1}, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->a(Ljava/lang/Object;)Landroid/widget/LinearLayout;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    iget-object v0, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->H:Lcom/transsnet/palmpay/custom_view/marqueeview/IMarqueeItemChanged;

    .line 74
    .line 75
    if-eqz v0, :cond_1

    .line 76
    .line 77
    iget v3, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->A:I

    .line 78
    .line 79
    invoke-interface {v0, v3}, Lcom/transsnet/palmpay/custom_view/marqueeview/IMarqueeItemChanged;->onItemChanged(I)V

    .line 80
    .line 81
    .line 82
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    if-nez v0, :cond_2

    .line 87
    .line 88
    invoke-virtual {v1, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 89
    .line 90
    .line 91
    :cond_2
    iput-boolean v2, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->M:Z

    .line 92
    .line 93
    return-void

    .line 94
    nop

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onAnimationRepeat(Landroid/view/animation/Animation;)V
    .locals 1

    .line 1
    iget v0, p0, LUb/b;->a:I

    packed-switch v0, :pswitch_data_0

    return-void

    :pswitch_0
    const-string v0, "animation"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    :pswitch_1
    const-string v0, "animation"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    :pswitch_2
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onAnimationStart(Landroid/view/animation/Animation;)V
    .locals 2

    .line 1
    iget v0, p0, LUb/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    const-string v0, "animation"

    .line 8
    .line 9
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, LUb/b;->b:Landroid/view/KeyEvent$Callback;

    .line 13
    .line 14
    check-cast p1, Lcom/transsnet/palmpay/ui/activity/HomeActivity;

    .line 15
    .line 16
    iget-object p1, p1, Lcom/transsnet/palmpay/ui/activity/HomeActivity;->i:Landroid/widget/FrameLayout;

    .line 17
    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    const/4 v0, 0x1

    .line 21
    invoke-static {p1, v0}, Loa/h;->s(Landroid/view/View;Z)V

    .line 22
    .line 23
    .line 24
    :cond_0
    return-void

    .line 25
    :pswitch_1
    const-string v0, "animation"

    .line 26
    .line 27
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    iget-object p1, p0, LUb/b;->b:Landroid/view/KeyEvent$Callback;

    .line 31
    .line 32
    check-cast p1, Lcom/swmansion/rnscreens/stack/views/ScreensCoordinatorLayout;

    .line 33
    .line 34
    invoke-virtual {p1}, Lcom/swmansion/rnscreens/stack/views/ScreensCoordinatorLayout;->getFragment$react_native_screens_release()Lcom/swmansion/rnscreens/ScreenStackFragment;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    const/4 v0, 0x0

    .line 39
    invoke-virtual {p1, v0}, Lcom/swmansion/rnscreens/ScreenFragment;->f(Z)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :pswitch_2
    iget-object v0, p0, LUb/b;->b:Landroid/view/KeyEvent$Callback;

    .line 44
    .line 45
    check-cast v0, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;

    .line 46
    .line 47
    iget-boolean v1, v0, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->M:Z

    .line 48
    .line 49
    if-eqz v1, :cond_1

    .line 50
    .line 51
    invoke-virtual {p1}, Landroid/view/animation/Animation;->cancel()V

    .line 52
    .line 53
    .line 54
    :cond_1
    const/4 p1, 0x1

    .line 55
    iput-boolean p1, v0, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->M:Z

    .line 56
    .line 57
    return-void

    .line 58
    nop

    .line 59
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
