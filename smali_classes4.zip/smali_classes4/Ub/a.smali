.class public final LUb/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LUb/a;->c:Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;

    .line 5
    .line 6
    iput p2, p0, LUb/a;->a:I

    .line 7
    .line 8
    iput p3, p0, LUb/a;->b:I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    sget v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->Q:I

    .line 3
    .line 4
    iget-object v1, p0, LUb/a;->c:Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;

    .line 5
    .line 6
    invoke-virtual {v1}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 7
    .line 8
    .line 9
    invoke-virtual {v1}, Landroid/view/View;->clearAnimation()V

    .line 10
    .line 11
    .line 12
    iget-object v2, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->B:Ljava/util/List;

    .line 13
    .line 14
    if-eqz v2, :cond_4

    .line 15
    .line 16
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-nez v2, :cond_4

    .line 21
    .line 22
    iput v0, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->A:I

    .line 23
    .line 24
    iget-object v2, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->B:Ljava/util/List;

    .line 25
    .line 26
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->a(Ljava/lang/Object;)Landroid/widget/LinearLayout;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 35
    .line 36
    .line 37
    iget-object v2, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->B:Ljava/util/List;

    .line 38
    .line 39
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    const/4 v3, 0x1

    .line 44
    if-le v2, v3, :cond_2

    .line 45
    .line 46
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    iget v3, p0, LUb/a;->a:I

    .line 51
    .line 52
    invoke-static {v2, v3}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    iget-boolean v3, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->b:Z

    .line 57
    .line 58
    if-eqz v3, :cond_0

    .line 59
    .line 60
    iget v3, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->c:I

    .line 61
    .line 62
    int-to-long v3, v3

    .line 63
    invoke-virtual {v2, v3, v4}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 64
    .line 65
    .line 66
    :cond_0
    invoke-virtual {v1, v2}, Landroid/widget/ViewAnimator;->setInAnimation(Landroid/view/animation/Animation;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    iget v3, p0, LUb/a;->b:I

    .line 74
    .line 75
    invoke-static {v2, v3}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    iget-boolean v3, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->b:Z

    .line 80
    .line 81
    if-eqz v3, :cond_1

    .line 82
    .line 83
    iget v3, v1, Lcom/transsnet/palmpay/custom_view/marqueeview/MarqueeView;->c:I

    .line 84
    .line 85
    int-to-long v3, v3

    .line 86
    invoke-virtual {v2, v3, v4}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 87
    .line 88
    .line 89
    :cond_1
    invoke-virtual {v1, v2}, Landroid/widget/ViewAnimator;->setOutAnimation(Landroid/view/animation/Animation;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v1}, Landroid/widget/ViewFlipper;->startFlipping()V

    .line 93
    .line 94
    .line 95
    :cond_2
    invoke-virtual {v1}, Landroid/widget/ViewAnimator;->getInAnimation()Landroid/view/animation/Animation;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    if-eqz v2, :cond_3

    .line 100
    .line 101
    invoke-virtual {v1}, Landroid/widget/ViewAnimator;->getInAnimation()Landroid/view/animation/Animation;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    new-instance v3, LUb/b;

    .line 106
    .line 107
    invoke-direct {v3, v1, v0}, LUb/b;-><init>(Landroid/view/KeyEvent$Callback;I)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v2, v3}, Landroid/view/animation/Animation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    .line 111
    .line 112
    .line 113
    :cond_3
    return-void

    .line 114
    :cond_4
    new-instance v0, Ljava/lang/RuntimeException;

    .line 115
    .line 116
    const-string v1, "The messages cannot be empty!"

    .line 117
    .line 118
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    throw v0
.end method
