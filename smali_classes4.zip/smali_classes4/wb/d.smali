.class public final Lwb/d;
.super LZ1/a;
.source "SourceFile"


# instance fields
.field public b:Ljava/util/List;

.field public c:Landroid/content/Context;

.field public d:Lzb/a;


# virtual methods
.method public final getItemCount()I
    .locals 1

    .line 1
    iget-object v0, p0, Lwb/d;->b:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final getSwipeLayoutResourceId(I)I
    .locals 0

    .line 1
    sget p1, LYa/e;->contact_swipe:I

    .line 2
    .line 3
    return p1
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 9

    .line 1
    check-cast p1, Lwb/c;

    .line 2
    .line 3
    iget-object v0, p0, Lwb/d;->b:Ljava/util/List;

    .line 4
    .line 5
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientType()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    const/4 v2, 0x4

    .line 16
    const/4 v3, 0x7

    .line 17
    const/4 v4, 0x2

    .line 18
    const/4 v5, 0x0

    .line 19
    const/4 v6, 0x1

    .line 20
    if-ne v1, v2, :cond_2

    .line 21
    .line 22
    sget v1, LYa/e;->contact_photo:I

    .line 23
    .line 24
    invoke-virtual {p1, v1}, Lwb/c;->getView(I)Landroid/view/View;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    check-cast v1, Landroid/widget/ImageView;

    .line 29
    .line 30
    sget v2, Lcom/transsnet/palmpay/custom_view/r;->cv_avatar_default:I

    .line 31
    .line 32
    invoke-static {v2}, LG1/d;->O(I)LG1/d;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    invoke-virtual {v2}, LG1/a;->d()LG1/a;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    check-cast v2, LG1/d;

    .line 41
    .line 42
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientHeadImage()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v7

    .line 46
    invoke-static {v1, v7, v2}, LPa/r0;->j1(Landroid/widget/ImageView;Ljava/lang/String;LG1/d;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientNickname()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-eqz v1, :cond_0

    .line 58
    .line 59
    sget v1, LYa/e;->contact_name:I

    .line 60
    .line 61
    invoke-virtual {p1, v1, v5}, Lwb/c;->b(IZ)V

    .line 62
    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_0
    sget v1, LYa/e;->contact_name:I

    .line 66
    .line 67
    invoke-virtual {p1, v1, v6}, Lwb/c;->b(IZ)V

    .line 68
    .line 69
    .line 70
    sget v1, LYa/e;->contact_name:I

    .line 71
    .line 72
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientNickname()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    invoke-virtual {p1, v1, v2}, Lwb/c;->a(ILjava/lang/String;)V

    .line 77
    .line 78
    .line 79
    :goto_0
    sget v1, LYa/e;->contact_number:I

    .line 80
    .line 81
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientChannel()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v2

    .line 85
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientPhone()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v7

    .line 89
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 90
    .line 91
    .line 92
    move-result v8

    .line 93
    if-nez v8, :cond_1

    .line 94
    .line 95
    const-string v8, " ("

    .line 96
    .line 97
    invoke-static {v2, v8}, LC0/G;->t(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    invoke-static {v7}, LPa/r0;->w0(Ljava/lang/String;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v7

    .line 105
    invoke-static {v7}, LPa/r0;->D0(Ljava/lang/String;)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v7

    .line 109
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    const-string v7, ")"

    .line 113
    .line 114
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    goto :goto_1

    .line 122
    :cond_1
    invoke-static {v7}, LPa/r0;->w0(Ljava/lang/String;)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v2

    .line 126
    invoke-static {v2}, LPa/r0;->D0(Ljava/lang/String;)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    :goto_1
    invoke-virtual {p1, v1, v2}, Lwb/c;->a(ILjava/lang/String;)V

    .line 131
    .line 132
    .line 133
    goto/16 :goto_5

    .line 134
    .line 135
    :cond_2
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientType()I

    .line 136
    .line 137
    .line 138
    move-result v1

    .line 139
    if-eq v1, v4, :cond_5

    .line 140
    .line 141
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientType()I

    .line 142
    .line 143
    .line 144
    move-result v1

    .line 145
    if-ne v1, v3, :cond_3

    .line 146
    .line 147
    goto :goto_3

    .line 148
    :cond_3
    sget v1, LYa/e;->contact_photo:I

    .line 149
    .line 150
    invoke-virtual {p1, v1}, Lwb/c;->getView(I)Landroid/view/View;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    check-cast v1, Landroid/widget/ImageView;

    .line 155
    .line 156
    sget v2, Lcom/transsnet/palmpay/custom_view/r;->cv_avatar_default:I

    .line 157
    .line 158
    invoke-static {v2}, LG1/d;->O(I)LG1/d;

    .line 159
    .line 160
    .line 161
    move-result-object v2

    .line 162
    invoke-virtual {v2}, LG1/a;->d()LG1/a;

    .line 163
    .line 164
    .line 165
    move-result-object v2

    .line 166
    check-cast v2, LG1/d;

    .line 167
    .line 168
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientHeadImage()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v7

    .line 172
    invoke-static {v1, v7, v2}, LPa/r0;->j1(Landroid/widget/ImageView;Ljava/lang/String;LG1/d;)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientNickname()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 180
    .line 181
    .line 182
    move-result v1

    .line 183
    if-eqz v1, :cond_4

    .line 184
    .line 185
    sget v1, LYa/e;->contact_name:I

    .line 186
    .line 187
    invoke-virtual {p1, v1, v5}, Lwb/c;->b(IZ)V

    .line 188
    .line 189
    .line 190
    goto :goto_2

    .line 191
    :cond_4
    sget v1, LYa/e;->contact_name:I

    .line 192
    .line 193
    invoke-virtual {p1, v1, v6}, Lwb/c;->b(IZ)V

    .line 194
    .line 195
    .line 196
    sget v1, LYa/e;->contact_name:I

    .line 197
    .line 198
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientNickname()Ljava/lang/String;

    .line 199
    .line 200
    .line 201
    move-result-object v2

    .line 202
    invoke-virtual {p1, v1, v2}, Lwb/c;->a(ILjava/lang/String;)V

    .line 203
    .line 204
    .line 205
    :goto_2
    sget v1, LYa/e;->contact_number:I

    .line 206
    .line 207
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientPhone()Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object v2

    .line 211
    invoke-static {v2}, LPa/r0;->w0(Ljava/lang/String;)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v2

    .line 215
    invoke-static {v2}, LPa/r0;->D0(Ljava/lang/String;)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v2

    .line 219
    invoke-virtual {p1, v1, v2}, Lwb/c;->a(ILjava/lang/String;)V

    .line 220
    .line 221
    .line 222
    goto :goto_5

    .line 223
    :cond_5
    :goto_3
    sget v1, LYa/e;->contact_photo:I

    .line 224
    .line 225
    invoke-virtual {p1, v1}, Lwb/c;->getView(I)Landroid/view/View;

    .line 226
    .line 227
    .line 228
    move-result-object v1

    .line 229
    check-cast v1, Landroid/widget/ImageView;

    .line 230
    .line 231
    sget v2, Lcom/transsnet/palmpay/custom_view/r;->cv_bank_account:I

    .line 232
    .line 233
    invoke-static {v2}, LG1/d;->O(I)LG1/d;

    .line 234
    .line 235
    .line 236
    move-result-object v2

    .line 237
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientHeadImage()Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object v7

    .line 241
    invoke-static {v1, v7, v2}, LPa/r0;->j1(Landroid/widget/ImageView;Ljava/lang/String;LG1/d;)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientNickname()Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v1

    .line 248
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 249
    .line 250
    .line 251
    move-result v1

    .line 252
    if-eqz v1, :cond_6

    .line 253
    .line 254
    sget v1, LYa/e;->contact_name:I

    .line 255
    .line 256
    invoke-virtual {p1, v1, v5}, Lwb/c;->b(IZ)V

    .line 257
    .line 258
    .line 259
    goto :goto_4

    .line 260
    :cond_6
    sget v1, LYa/e;->contact_name:I

    .line 261
    .line 262
    invoke-virtual {p1, v1, v6}, Lwb/c;->b(IZ)V

    .line 263
    .line 264
    .line 265
    sget v1, LYa/e;->contact_name:I

    .line 266
    .line 267
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientNickname()Ljava/lang/String;

    .line 268
    .line 269
    .line 270
    move-result-object v2

    .line 271
    invoke-virtual {p1, v1, v2}, Lwb/c;->a(ILjava/lang/String;)V

    .line 272
    .line 273
    .line 274
    :goto_4
    sget v1, LYa/e;->contact_number:I

    .line 275
    .line 276
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientBankName()Ljava/lang/String;

    .line 277
    .line 278
    .line 279
    move-result-object v2

    .line 280
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientAccountNumber()Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v7

    .line 284
    invoke-static {v2, v7}, LPa/r0;->A0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 285
    .line 286
    .line 287
    move-result-object v2

    .line 288
    invoke-virtual {p1, v1, v2}, Lwb/c;->a(ILjava/lang/String;)V

    .line 289
    .line 290
    .line 291
    :goto_5
    sget v1, LYa/e;->content:I

    .line 292
    .line 293
    invoke-virtual {p1, v1}, Lwb/c;->getView(I)Landroid/view/View;

    .line 294
    .line 295
    .line 296
    move-result-object v1

    .line 297
    new-instance v2, LGd/e;

    .line 298
    .line 299
    const/4 v7, 0x4

    .line 300
    invoke-direct {v2, p0, p2, p1, v7}, LGd/e;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    .line 301
    .line 302
    .line 303
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 304
    .line 305
    .line 306
    sget v1, LYa/e;->delete_tv:I

    .line 307
    .line 308
    invoke-virtual {p1, v1}, Lwb/c;->getView(I)Landroid/view/View;

    .line 309
    .line 310
    .line 311
    move-result-object v1

    .line 312
    new-instance v2, Lvd/c;

    .line 313
    .line 314
    invoke-direct {v2, p0, p2}, Lvd/c;-><init>(Lwb/d;I)V

    .line 315
    .line 316
    .line 317
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientType()I

    .line 321
    .line 322
    .line 323
    move-result v1

    .line 324
    if-eq v1, v4, :cond_8

    .line 325
    .line 326
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientType()I

    .line 327
    .line 328
    .line 329
    move-result v1

    .line 330
    if-eq v1, v3, :cond_8

    .line 331
    .line 332
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/bean/resp/RecipientListResp$RecipientBean;->getRecipientType()I

    .line 333
    .line 334
    .line 335
    move-result v1

    .line 336
    if-ne v1, v6, :cond_7

    .line 337
    .line 338
    goto :goto_6

    .line 339
    :cond_7
    sget v1, LYa/e;->edit_tv:I

    .line 340
    .line 341
    invoke-virtual {p1, v1, v5}, Lwb/c;->b(IZ)V

    .line 342
    .line 343
    .line 344
    goto :goto_7

    .line 345
    :cond_8
    :goto_6
    sget v1, LYa/e;->edit_tv:I

    .line 346
    .line 347
    invoke-virtual {p1, v1, v6}, Lwb/c;->b(IZ)V

    .line 348
    .line 349
    .line 350
    :goto_7
    sget v1, LYa/e;->edit_tv:I

    .line 351
    .line 352
    invoke-virtual {p1, v1}, Lwb/c;->getView(I)Landroid/view/View;

    .line 353
    .line 354
    .line 355
    move-result-object v1

    .line 356
    new-instance v2, Ltb/W;

    .line 357
    .line 358
    const/16 v3, 0xc

    .line 359
    .line 360
    invoke-direct {v2, v3, p0, v0}, Ltb/W;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 361
    .line 362
    .line 363
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 364
    .line 365
    .line 366
    iget-object v0, p0, LZ1/a;->a:La2/d;

    .line 367
    .line 368
    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 369
    .line 370
    invoke-virtual {v0, p2, p1}, La2/d;->a(ILandroid/view/View;)V

    .line 371
    .line 372
    .line 373
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    .line 1
    new-instance p2, Lwb/c;

    .line 2
    .line 3
    iget-object v0, p0, Lwb/d;->c:Landroid/content/Context;

    .line 4
    .line 5
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sget v1, LYa/f;->cs_contact_list_item_layout:I

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-direct {p2, p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    .line 17
    .line 18
    .line 19
    new-instance p1, Landroid/util/SparseArray;

    .line 20
    .line 21
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p2, Lwb/c;->a:Landroid/util/SparseArray;

    .line 25
    .line 26
    return-object p2
.end method
