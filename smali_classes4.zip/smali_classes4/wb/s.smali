.class public final Lwb/s;
.super LM1/j;
.source "SourceFile"


# instance fields
.field public a:Lcom/transsnet/palmpay/credit/bean/rsp/SysConfigValue;


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/credit/bean/rsp/SysConfigValue;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "item"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    sget v0, Lhb/c;->tv_language:I

    .line 14
    .line 15
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/rsp/SysConfigValue;->getKeyText()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lwb/s;->a:Lcom/transsnet/palmpay/credit/bean/rsp/SysConfigValue;

    .line 23
    .line 24
    invoke-static {v0, p2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p2

    .line 28
    if-eqz p2, :cond_0

    .line 29
    .line 30
    sget p2, Lhb/c;->tv_language:I

    .line 31
    .line 32
    sget v0, Lhb/b;->cs_selected_language:I

    .line 33
    .line 34
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setBackgroundResource(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_0
    sget p2, Lhb/c;->tv_language:I

    .line 39
    .line 40
    sget v0, Lhb/b;->cs_unselected_language:I

    .line 41
    .line 42
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setBackgroundResource(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 43
    .line 44
    .line 45
    return-void
.end method
