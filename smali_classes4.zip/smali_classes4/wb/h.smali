.class public final synthetic Lwb/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Lwb/h;->a:I

    iput-object p2, p0, Lwb/h;->b:Ljava/lang/Object;

    iput-object p3, p0, Lwb/h;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, Lwb/h;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lwb/h;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;

    .line 9
    .line 10
    iget-object v1, v0, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->A:Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLInitData;->getCreditSceneRouteBindingFailTimes()Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    if-eqz v1, :cond_0

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    goto :goto_0

    .line 26
    :cond_0
    move v1, v2

    .line 27
    :goto_0
    invoke-static {}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->x()I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    const/4 v4, 0x0

    .line 32
    if-ge v1, v3, :cond_1

    .line 33
    .line 34
    new-instance v1, LO6/c;

    .line 35
    .line 36
    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-direct {v1, v0}, LO6/c;-><init>(Landroid/content/Context;)V

    .line 41
    .line 42
    .line 43
    sget v0, LYa/d;->cs_failed_sorry_icon:I

    .line 44
    .line 45
    iput v0, v1, LO6/c;->m:I

    .line 46
    .line 47
    const-string v0, "Sorry"

    .line 48
    .line 49
    invoke-static {v0}, LO6/d;->f(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    iput-object v0, v1, LO6/c;->b:Ljava/lang/CharSequence;

    .line 54
    .line 55
    sget v0, LYa/g;->cs_cl_credit_bind_failed_tips:I

    .line 56
    .line 57
    invoke-virtual {v1, v0}, LO6/c;->b(I)V

    .line 58
    .line 59
    .line 60
    sget v0, LYa/g;->cs_confirm:I

    .line 61
    .line 62
    invoke-virtual {v1, v0, v4}, LO6/c;->d(ILandroid/view/View$OnClickListener;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1}, LO6/c;->g()LO6/d;

    .line 66
    .line 67
    .line 68
    goto/16 :goto_4

    .line 69
    .line 70
    :cond_1
    invoke-static {}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->x()I

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->get()Lcom/transsnet/palmpay/util/SPUtils;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 79
    .line 80
    .line 81
    move-result-wide v5

    .line 82
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    const/4 v6, 0x1

    .line 87
    add-int/2addr v1, v6

    .line 88
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    filled-new-array {v5, v1}, [Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    invoke-static {v1}, Lkotlin/collections/q;->h([Ljava/lang/Object;)Ljava/util/List;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    check-cast v1, Ljava/lang/Iterable;

    .line 101
    .line 102
    const-string v5, "_"

    .line 103
    .line 104
    invoke-static {v5, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    const-string v5, "credit_bind_times"

    .line 109
    .line 110
    invoke-virtual {v3, v5, v1}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    iget-object v1, p0, Lwb/h;->c:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;

    .line 116
    .line 117
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 118
    .line 119
    .line 120
    move-result-object v3

    .line 121
    if-eqz v3, :cond_2

    .line 122
    .line 123
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteInfoList()Ljava/util/List;

    .line 124
    .line 125
    .line 126
    move-result-object v3

    .line 127
    goto :goto_1

    .line 128
    :cond_2
    move-object v3, v4

    .line 129
    :goto_1
    check-cast v3, Ljava/util/Collection;

    .line 130
    .line 131
    if-eqz v3, :cond_8

    .line 132
    .line 133
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 134
    .line 135
    .line 136
    move-result v3

    .line 137
    if-eqz v3, :cond_3

    .line 138
    .line 139
    goto :goto_3

    .line 140
    :cond_3
    iget-object v3, v0, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->M:Ljava/util/ArrayList;

    .line 141
    .line 142
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterResp;->getData()Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    if-eqz v1, :cond_4

    .line 147
    .line 148
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/OcRouterData;->getRouteInfoList()Ljava/util/List;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    goto :goto_2

    .line 153
    :cond_4
    move-object v1, v4

    .line 154
    :goto_2
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    check-cast v1, Ljava/util/Collection;

    .line 158
    .line 159
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 160
    .line 161
    .line 162
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;

    .line 167
    .line 168
    if-eqz v1, :cond_5

    .line 169
    .line 170
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/req/OcRouterDetail;->getRoutePath()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v4

    .line 174
    :cond_5
    const-string v1, "oc_permission_router"

    .line 175
    .line 176
    invoke-static {v4, v1}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 177
    .line 178
    .line 179
    move-result v1

    .line 180
    if-eqz v1, :cond_7

    .line 181
    .line 182
    iput v6, v0, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->X:I

    .line 183
    .line 184
    invoke-static {}, Lcom/transsnet/palmpay/core/config/d;->v()Z

    .line 185
    .line 186
    .line 187
    move-result v1

    .line 188
    if-nez v1, :cond_6

    .line 189
    .line 190
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->A()V

    .line 191
    .line 192
    .line 193
    goto :goto_4

    .line 194
    :cond_6
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->Y:Landroidx/activity/result/a;

    .line 195
    .line 196
    if-eqz v0, :cond_9

    .line 197
    .line 198
    const-string v1, "android.permission.READ_PHONE_STATE"

    .line 199
    .line 200
    const-string v2, "android.permission.ACCESS_COARSE_LOCATION"

    .line 201
    .line 202
    filled-new-array {v1, v2}, [Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v1

    .line 206
    invoke-virtual {v0, v1}, Landroidx/activity/result/a;->a(Ljava/lang/Object;)V

    .line 207
    .line 208
    .line 209
    goto :goto_4

    .line 210
    :cond_7
    iput v2, v0, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->X:I

    .line 211
    .line 212
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->A()V

    .line 213
    .line 214
    .line 215
    goto :goto_4

    .line 216
    :cond_8
    :goto_3
    invoke-virtual {v0}, Lcom/transsnet/palmpay/credit/ui/fragment/OpenAccountBaseFragment;->C()V

    .line 217
    .line 218
    .line 219
    :cond_9
    :goto_4
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 220
    .line 221
    return-object v0

    .line 222
    :pswitch_0
    iget-object v0, p0, Lwb/h;->c:Ljava/lang/Object;

    .line 223
    .line 224
    check-cast v0, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 225
    .line 226
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getBindingAdapterPosition()I

    .line 227
    .line 228
    .line 229
    move-result v0

    .line 230
    iget-object v1, p0, Lwb/h;->b:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast v1, Lwb/i;

    .line 233
    .line 234
    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemChanged(I)V

    .line 235
    .line 236
    .line 237
    sget-object v0, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 238
    .line 239
    return-object v0

    .line 240
    nop

    .line 241
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
