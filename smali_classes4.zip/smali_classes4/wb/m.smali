.class public final Lwb/m;
.super LKb/c;
.source "SourceFile"

# interfaces
.implements Lcom/timehop/stickyheadersrecyclerview/StickyRecyclerHeadersAdapter;


# virtual methods
.method public final c(I)Lcom/transsnet/palmpay/core/bean/PalmPayContact;
    .locals 1

    .line 1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lcom/transsnet/palmpay/core/bean/PalmPayContact;

    .line 8
    .line 9
    return-object p1
.end method

.method public final getHeaderId(I)J
    .locals 2

    .line 1
    invoke-virtual {p0, p1}, Lwb/m;->c(I)Lcom/transsnet/palmpay/core/bean/PalmPayContact;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/PalmPayContact;->getFullName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-static {p1}, Le1/a;->t(Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    int-to-long v0, p1

    .line 18
    return-wide v0
.end method

.method public final bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lwb/m;->c(I)Lcom/transsnet/palmpay/core/bean/PalmPayContact;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final getItemCount()I
    .locals 1

    .line 1
    iget-object v0, p0, LKb/c;->b:Ljava/util/List;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    :goto_0
    return v0
.end method

.method public final getItemViewType(I)I
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public final onBindHeaderViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 1

    .line 1
    check-cast p1, Lwb/l;

    .line 2
    .line 3
    sget v0, LYa/e;->title_tv:I

    .line 4
    .line 5
    invoke-virtual {p0, p2}, Lwb/m;->c(I)Lcom/transsnet/palmpay/core/bean/PalmPayContact;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/PalmPayContact;->getFullName()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p2

    .line 13
    invoke-static {p2}, Le1/a;->t(Ljava/lang/String;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    invoke-virtual {p1, v0, p2}, LKb/b;->b(ILjava/lang/String;)V

    .line 18
    .line 19
    .line 20
    sget p2, LYa/e;->icon_iv:I

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    invoke-virtual {p1, p2, v0}, LKb/b;->c(IZ)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 4

    .line 1
    iget-object v0, p0, LKb/c;->a:Landroid/content/Context;

    .line 2
    .line 3
    check-cast p1, Lwb/k;

    .line 4
    .line 5
    invoke-virtual {p0, p2}, Lwb/m;->c(I)Lcom/transsnet/palmpay/core/bean/PalmPayContact;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    sget v1, LYa/e;->contact_photo:I

    .line 10
    .line 11
    invoke-virtual {p1, v1}, LKb/b;->getView(I)Landroid/view/View;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Landroid/widget/ImageView;

    .line 16
    .line 17
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/PalmPayContact;->getPhotoPath()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    sget v3, Lcom/transsnet/palmpay/custom_view/r;->cv_avatar_default:I

    .line 22
    .line 23
    invoke-static {v3}, LG1/d;->O(I)LG1/d;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    invoke-virtual {v3}, LG1/a;->d()LG1/a;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    check-cast v3, LG1/d;

    .line 32
    .line 33
    invoke-static {v0}, Lcom/bumptech/glide/b;->e(Landroid/content/Context;)Lcom/bumptech/glide/p;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {v0, v2}, Lcom/bumptech/glide/p;->n(Ljava/lang/String;)Lcom/bumptech/glide/m;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {v0, v3}, Lcom/bumptech/glide/m;->O(LG1/a;)Lcom/bumptech/glide/m;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {v0, v1}, Lcom/bumptech/glide/m;->S(Landroid/widget/ImageView;)V

    .line 46
    .line 47
    .line 48
    sget v0, LYa/e;->contact_note_name:I

    .line 49
    .line 50
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/PalmPayContact;->getFullName()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-virtual {p1, v0, v1}, LKb/b;->b(ILjava/lang/String;)V

    .line 55
    .line 56
    .line 57
    sget v0, LYa/e;->contact_number:I

    .line 58
    .line 59
    invoke-virtual {p2}, Lcom/transsnet/palmpay/core/bean/PalmPayContact;->getPhone()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p2

    .line 63
    invoke-static {p2}, LPa/r0;->D0(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p2

    .line 67
    invoke-virtual {p1, v0, p2}, LKb/b;->b(ILjava/lang/String;)V

    .line 68
    .line 69
    .line 70
    return-void
.end method

.method public final onCreateHeaderViewHolder(Landroid/view/ViewGroup;)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 4

    .line 1
    new-instance v0, Lwb/l;

    .line 2
    .line 3
    iget-object v1, p0, LKb/c;->a:Landroid/content/Context;

    .line 4
    .line 5
    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    sget v2, LYa/f;->cs_list_title_item_layout:I

    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    invoke-virtual {v1, v2, p1, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-direct {v0, p0, p1}, LKb/b;-><init>(LKb/c;Landroid/view/View;)V

    .line 17
    .line 18
    .line 19
    return-object v0
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    iget-object v2, p0, LKb/c;->a:Landroid/content/Context;

    .line 4
    .line 5
    if-ne p2, v0, :cond_0

    .line 6
    .line 7
    new-instance p2, Lwb/j;

    .line 8
    .line 9
    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sget v2, LYa/f;->cs_contact_list_header_item_layout:I

    .line 14
    .line 15
    invoke-virtual {v0, v2, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-direct {p2, p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;-><init>(Landroid/view/View;)V

    .line 20
    .line 21
    .line 22
    sget v0, LYa/e;->new_contact_number:I

    .line 23
    .line 24
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    check-cast v0, Landroid/widget/TextView;

    .line 29
    .line 30
    iput-object v0, p2, Lwb/j;->a:Landroid/widget/TextView;

    .line 31
    .line 32
    new-instance v0, LF5/b;

    .line 33
    .line 34
    const/16 v1, 0xa

    .line 35
    .line 36
    invoke-direct {v0, v1}, LF5/b;-><init>(I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 40
    .line 41
    .line 42
    return-object p2

    .line 43
    :cond_0
    new-instance p2, Lwb/k;

    .line 44
    .line 45
    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    sget v2, LYa/f;->cs_mobile_contact_list_item_layout:I

    .line 50
    .line 51
    invoke-virtual {v0, v2, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-direct {p2, p0, p1}, LKb/b;-><init>(LKb/c;Landroid/view/View;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p2, p1}, LKb/b;->a(Landroid/view/View;)V

    .line 59
    .line 60
    .line 61
    return-object p2
.end method
