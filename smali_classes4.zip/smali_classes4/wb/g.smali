.class public final synthetic Lwb/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p5, p0, Lwb/g;->a:I

    iput-object p1, p0, Lwb/g;->b:Ljava/lang/Object;

    iput-object p2, p0, Lwb/g;->c:Ljava/lang/Object;

    iput-object p3, p0, Lwb/g;->d:Ljava/lang/Object;

    iput-object p4, p0, Lwb/g;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    const-string v0, "it"

    .line 2
    .line 3
    iget-object v1, p0, Lwb/g;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Lwb/g;->e:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, p0, Lwb/g;->d:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, p0, Lwb/g;->c:Ljava/lang/Object;

    .line 10
    .line 11
    iget v5, p0, Lwb/g;->a:I

    .line 12
    .line 13
    packed-switch v5, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    check-cast p1, Ljava/lang/Long;

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 19
    .line 20
    .line 21
    move-result-wide v8

    .line 22
    sget p1, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->v0:I

    .line 23
    .line 24
    move-object v6, v4

    .line 25
    check-cast v6, Ljava/lang/String;

    .line 26
    .line 27
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    move-object v7, v3

    .line 31
    check-cast v7, Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    check-cast v2, Lkotlin/jvm/internal/F;

    .line 37
    .line 38
    iget-object p1, v2, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 39
    .line 40
    move-object v10, p1

    .line 41
    check-cast v10, Lcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;

    .line 42
    .line 43
    move-object v5, v1

    .line 44
    check-cast v5, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;

    .line 45
    .line 46
    invoke-virtual/range {v5 .. v10}, Lcom/transsnet/palmpay/teller/ui/fragment/BillPaymentTvHomeFragment;->H(Ljava/lang/String;Ljava/lang/String;JLcom/transsnet/palmpay/teller/bean/TvListByCategoryIdResp$TvItemChildBean;)V

    .line 47
    .line 48
    .line 49
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 50
    .line 51
    return-object p1

    .line 52
    :pswitch_0
    check-cast p1, Landroid/view/View;

    .line 53
    .line 54
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    check-cast v1, Landroid/content/Context;

    .line 58
    .line 59
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;

    .line 60
    .line 61
    check-cast v4, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;

    .line 62
    .line 63
    invoke-static {v1, v4, v3}, LFb/i;->f(Landroid/content/Context;Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;)Z

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    if-eqz p1, :cond_0

    .line 68
    .line 69
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_0
    check-cast v2, Lwb/i;

    .line 73
    .line 74
    iget-object p1, v2, Lwb/i;->a:Lj9/o;

    .line 75
    .line 76
    invoke-virtual {p1, v4, v3}, Lj9/o;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 80
    .line 81
    :goto_0
    return-object p1

    .line 82
    :pswitch_1
    check-cast p1, Landroid/view/View;

    .line 83
    .line 84
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    check-cast v1, Landroid/content/Context;

    .line 88
    .line 89
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;

    .line 90
    .line 91
    check-cast v4, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;

    .line 92
    .line 93
    invoke-static {v1, v4, v3}, LFb/i;->f(Landroid/content/Context;Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;)Z

    .line 94
    .line 95
    .line 96
    move-result p1

    .line 97
    if-eqz p1, :cond_1

    .line 98
    .line 99
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 100
    .line 101
    goto/16 :goto_9

    .line 102
    .line 103
    :cond_1
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getDetailList()Ljava/util/List;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    if-eqz p1, :cond_2

    .line 108
    .line 109
    const/4 v0, 0x0

    .line 110
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;

    .line 115
    .line 116
    if-eqz p1, :cond_2

    .line 117
    .line 118
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getAndroidLink()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    if-eqz p1, :cond_2

    .line 123
    .line 124
    check-cast v2, Lwb/i;

    .line 125
    .line 126
    invoke-virtual {v2}, LM1/j;->getContext()Landroid/content/Context;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-static {v0, p1}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 131
    .line 132
    .line 133
    move-result-object p1

    .line 134
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 135
    .line 136
    .line 137
    goto/16 :goto_8

    .line 138
    .line 139
    :cond_2
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getAccountType()Ljava/lang/Integer;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    if-nez p1, :cond_3

    .line 144
    .line 145
    goto :goto_1

    .line 146
    :cond_3
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 147
    .line 148
    .line 149
    move-result p1

    .line 150
    const/16 v0, 0xb

    .line 151
    .line 152
    if-ne p1, v0, :cond_4

    .line 153
    .line 154
    const-string p1, "/credit_score/oc_home_mobile_installment_standalone_activity"

    .line 155
    .line 156
    invoke-static {p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->F(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    goto/16 :goto_8

    .line 160
    .line 161
    :cond_4
    :goto_1
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getAccountType()Ljava/lang/Integer;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    if-nez p1, :cond_5

    .line 166
    .line 167
    goto :goto_2

    .line 168
    :cond_5
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 169
    .line 170
    .line 171
    move-result p1

    .line 172
    const/4 v0, 0x6

    .line 173
    if-ne p1, v0, :cond_6

    .line 174
    .line 175
    const/4 p1, 0x0

    .line 176
    const-string v0, "LoanFlexi"

    .line 177
    .line 178
    invoke-static {p1, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    goto/16 :goto_8

    .line 182
    .line 183
    :cond_6
    :goto_2
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getAccountType()Ljava/lang/Integer;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    const-string v0, "billId"

    .line 188
    .line 189
    if-nez p1, :cond_7

    .line 190
    .line 191
    goto :goto_3

    .line 192
    :cond_7
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 193
    .line 194
    .line 195
    move-result p1

    .line 196
    const/4 v1, 0x7

    .line 197
    if-eq p1, v1, :cond_d

    .line 198
    .line 199
    :goto_3
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getAccountType()Ljava/lang/Integer;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    if-nez p1, :cond_8

    .line 204
    .line 205
    goto :goto_4

    .line 206
    :cond_8
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 207
    .line 208
    .line 209
    move-result p1

    .line 210
    const/16 v1, 0xe

    .line 211
    .line 212
    if-eq p1, v1, :cond_d

    .line 213
    .line 214
    :goto_4
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getAccountType()Ljava/lang/Integer;

    .line 215
    .line 216
    .line 217
    move-result-object p1

    .line 218
    if-nez p1, :cond_9

    .line 219
    .line 220
    goto :goto_5

    .line 221
    :cond_9
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 222
    .line 223
    .line 224
    move-result p1

    .line 225
    const/16 v1, 0x9

    .line 226
    .line 227
    if-ne p1, v1, :cond_a

    .line 228
    .line 229
    goto :goto_7

    .line 230
    :cond_a
    :goto_5
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentAccount;->getAccountType()Ljava/lang/Integer;

    .line 231
    .line 232
    .line 233
    move-result-object p1

    .line 234
    if-nez p1, :cond_b

    .line 235
    .line 236
    goto :goto_8

    .line 237
    :cond_b
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 238
    .line 239
    .line 240
    move-result p1

    .line 241
    const/16 v1, 0xd

    .line 242
    .line 243
    if-ne p1, v1, :cond_f

    .line 244
    .line 245
    new-instance p1, Landroid/os/Bundle;

    .line 246
    .line 247
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 248
    .line 249
    .line 250
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getBillId()Ljava/lang/Long;

    .line 251
    .line 252
    .line 253
    move-result-object v1

    .line 254
    if-eqz v1, :cond_c

    .line 255
    .line 256
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 257
    .line 258
    .line 259
    move-result-wide v1

    .line 260
    goto :goto_6

    .line 261
    :cond_c
    const-wide/16 v1, 0x0

    .line 262
    .line 263
    :goto_6
    invoke-virtual {p1, v0, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 264
    .line 265
    .line 266
    const-string v0, "PalmPayCardRepayment"

    .line 267
    .line 268
    invoke-static {p1, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    goto :goto_8

    .line 272
    :cond_d
    :goto_7
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getLoanNo()Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object p1

    .line 276
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 277
    .line 278
    .line 279
    move-result p1

    .line 280
    if-eqz p1, :cond_e

    .line 281
    .line 282
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getBillId()Ljava/lang/Long;

    .line 283
    .line 284
    .line 285
    move-result-object p1

    .line 286
    if-eqz p1, :cond_f

    .line 287
    .line 288
    :cond_e
    new-instance p1, Landroid/os/Bundle;

    .line 289
    .line 290
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 291
    .line 292
    .line 293
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getBillId()Ljava/lang/Long;

    .line 294
    .line 295
    .line 296
    move-result-object v1

    .line 297
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object v1

    .line 301
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 302
    .line 303
    .line 304
    const-string v0, "accountType"

    .line 305
    .line 306
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getAccountType()Ljava/lang/String;

    .line 307
    .line 308
    .line 309
    move-result-object v1

    .line 310
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    const-string v0, "cardNo"

    .line 314
    .line 315
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getCardNo()Ljava/lang/String;

    .line 316
    .line 317
    .line 318
    move-result-object v1

    .line 319
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    const-string v0, "loanProduct"

    .line 323
    .line 324
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/rsp/LoanHomeRepaymentDetail;->getLoanProduct()Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object v1

    .line 328
    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 329
    .line 330
    .line 331
    const-string v0, "LoanOutstandingBill"

    .line 332
    .line 333
    invoke-static {p1, v0}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 334
    .line 335
    .line 336
    :cond_f
    :goto_8
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 337
    .line 338
    :goto_9
    return-object p1

    .line 339
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
