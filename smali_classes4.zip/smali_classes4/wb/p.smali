.class public final Lwb/p;
.super LKb/c;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lwb/n;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lwb/n;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 11

    .line 1
    const-string v0, "holder"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    instance-of v0, p1, Lwb/o;

    .line 7
    .line 8
    if-eqz v0, :cond_18

    .line 9
    .line 10
    check-cast p1, Lwb/o;

    .line 11
    .line 12
    invoke-virtual {p0, p2}, LKb/c;->getItem(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p2

    .line 16
    check-cast p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    const-string v0, "OutstandingDetailAdapter >>> loan"

    .line 22
    .line 23
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const/4 v1, 0x3

    .line 28
    const-string v2, "OutstandingDetailAdapter"

    .line 29
    .line 30
    invoke-static {v2, v1, v0}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p1, Lwb/o;->d:Landroid/widget/TextView;

    .line 34
    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    if-eqz p2, :cond_0

    .line 38
    .line 39
    iget-object v3, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->productTitle:Ljava/lang/String;

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    const/4 v3, 0x0

    .line 43
    :goto_0
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 44
    .line 45
    .line 46
    :cond_1
    iget-object v0, p1, Lwb/o;->f:Landroid/widget/TextView;

    .line 47
    .line 48
    const/4 v3, 0x1

    .line 49
    const-wide/16 v4, 0x0

    .line 50
    .line 51
    if-eqz v0, :cond_3

    .line 52
    .line 53
    if-eqz p2, :cond_2

    .line 54
    .line 55
    iget-object v6, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->billOutstandingAmount:Ljava/lang/Long;

    .line 56
    .line 57
    if-eqz v6, :cond_2

    .line 58
    .line 59
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 60
    .line 61
    .line 62
    move-result-wide v6

    .line 63
    goto :goto_1

    .line 64
    :cond_2
    move-wide v6, v4

    .line 65
    :goto_1
    invoke-static {v6, v7, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 70
    .line 71
    .line 72
    :cond_3
    if-eqz p2, :cond_4

    .line 73
    .line 74
    iget-object v0, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->repaymentDateStamp:Ljava/lang/Long;

    .line 75
    .line 76
    if-eqz v0, :cond_4

    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 79
    .line 80
    .line 81
    move-result-wide v6

    .line 82
    goto :goto_2

    .line 83
    :cond_4
    move-wide v6, v4

    .line 84
    :goto_2
    invoke-static {v6, v7}, LE/c;->z(J)J

    .line 85
    .line 86
    .line 87
    move-result-wide v6

    .line 88
    if-eqz p2, :cond_5

    .line 89
    .line 90
    iget-object v0, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->repaymentDateStamp:Ljava/lang/Long;

    .line 91
    .line 92
    if-eqz v0, :cond_5

    .line 93
    .line 94
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 95
    .line 96
    .line 97
    move-result-wide v8

    .line 98
    goto :goto_3

    .line 99
    :cond_5
    move-wide v8, v4

    .line 100
    :goto_3
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    const-string v8, "MMM dd"

    .line 105
    .line 106
    invoke-static {v0, v8}, LPa/r0;->X1(Ljava/lang/Long;Ljava/lang/String;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    new-instance v8, Ljava/lang/StringBuilder;

    .line 111
    .line 112
    const-string v9, "leftDays = "

    .line 113
    .line 114
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v8, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    const-string v9, ", dueDate = "

    .line 121
    .line 122
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v8

    .line 132
    filled-new-array {v8}, [Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v8

    .line 136
    invoke-static {v2, v1, v8}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    cmp-long v1, v6, v4

    .line 140
    .line 141
    iget-object v2, p1, Lwb/o;->e:Landroid/widget/TextView;

    .line 142
    .line 143
    iget-object v8, p1, Lwb/o;->i:Lwb/p;

    .line 144
    .line 145
    const-wide/16 v9, 0x1

    .line 146
    .line 147
    if-gez v1, :cond_a

    .line 148
    .line 149
    if-eqz p2, :cond_6

    .line 150
    .line 151
    iget-object v0, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->repaymentDateStamp:Ljava/lang/Long;

    .line 152
    .line 153
    if-eqz v0, :cond_6

    .line 154
    .line 155
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 156
    .line 157
    .line 158
    move-result-wide v0

    .line 159
    goto :goto_4

    .line 160
    :cond_6
    move-wide v0, v4

    .line 161
    :goto_4
    invoke-static {v0, v1}, LE/c;->D(J)J

    .line 162
    .line 163
    .line 164
    move-result-wide v0

    .line 165
    if-eqz v2, :cond_7

    .line 166
    .line 167
    iget-object v6, v8, LKb/c;->a:Landroid/content/Context;

    .line 168
    .line 169
    sget v7, LYa/d;->cs_cl_outstanding_item_desc_bg_red:I

    .line 170
    .line 171
    invoke-static {v7, v6}, Lr5/a;->q(ILandroid/content/Context;)Landroid/graphics/drawable/Drawable;

    .line 172
    .line 173
    .line 174
    move-result-object v6

    .line 175
    invoke-virtual {v2, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 176
    .line 177
    .line 178
    :cond_7
    if-eqz v2, :cond_8

    .line 179
    .line 180
    iget-object v6, v8, LKb/c;->a:Landroid/content/Context;

    .line 181
    .line 182
    sget v7, Lcom/transsnet/palmpay/custom_view/p;->md_white_1000:I

    .line 183
    .line 184
    invoke-virtual {v6, v7}, Landroid/content/Context;->getColor(I)I

    .line 185
    .line 186
    .line 187
    move-result v6

    .line 188
    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 189
    .line 190
    .line 191
    :cond_8
    if-eqz v2, :cond_14

    .line 192
    .line 193
    cmp-long v6, v0, v9

    .line 194
    .line 195
    if-gtz v6, :cond_9

    .line 196
    .line 197
    iget-object v0, v8, LKb/c;->a:Landroid/content/Context;

    .line 198
    .line 199
    sget v1, LYa/g;->cs_cl_outstanding_item_desc_overdue_one:I

    .line 200
    .line 201
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    goto :goto_5

    .line 206
    :cond_9
    iget-object v6, v8, LKb/c;->a:Landroid/content/Context;

    .line 207
    .line 208
    sget v7, LYa/g;->cs_cl_outstanding_item_desc_overdue:I

    .line 209
    .line 210
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    invoke-virtual {v6, v7, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    :goto_5
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 223
    .line 224
    .line 225
    goto/16 :goto_7

    .line 226
    .line 227
    :cond_a
    cmp-long v1, v6, v9

    .line 228
    .line 229
    if-gez v1, :cond_d

    .line 230
    .line 231
    if-eqz v2, :cond_b

    .line 232
    .line 233
    iget-object v0, v8, LKb/c;->a:Landroid/content/Context;

    .line 234
    .line 235
    sget v1, LYa/d;->cs_cl_outstanding_item_desc_bg_red:I

    .line 236
    .line 237
    invoke-static {v1, v0}, Lr5/a;->q(ILandroid/content/Context;)Landroid/graphics/drawable/Drawable;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    invoke-virtual {v2, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 242
    .line 243
    .line 244
    :cond_b
    if-eqz v2, :cond_c

    .line 245
    .line 246
    iget-object v0, v8, LKb/c;->a:Landroid/content/Context;

    .line 247
    .line 248
    sget v1, Lcom/transsnet/palmpay/custom_view/p;->md_white_1000:I

    .line 249
    .line 250
    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    .line 251
    .line 252
    .line 253
    move-result v0

    .line 254
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 255
    .line 256
    .line 257
    :cond_c
    if-eqz v2, :cond_14

    .line 258
    .line 259
    iget-object v0, v8, LKb/c;->a:Landroid/content/Context;

    .line 260
    .line 261
    sget v1, LYa/g;->cs_cl_outstanding_item_desc_due_date_today:I

    .line 262
    .line 263
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 268
    .line 269
    .line 270
    goto :goto_7

    .line 271
    :cond_d
    const-wide/16 v9, 0x3

    .line 272
    .line 273
    cmp-long v9, v6, v9

    .line 274
    .line 275
    if-gtz v9, :cond_11

    .line 276
    .line 277
    if-eqz v2, :cond_e

    .line 278
    .line 279
    iget-object v0, v8, LKb/c;->a:Landroid/content/Context;

    .line 280
    .line 281
    sget v9, LYa/d;->cs_cl_outstanding_item_desc_bg_yellow:I

    .line 282
    .line 283
    invoke-static {v9, v0}, Lr5/a;->q(ILandroid/content/Context;)Landroid/graphics/drawable/Drawable;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    invoke-virtual {v2, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 288
    .line 289
    .line 290
    :cond_e
    if-eqz v2, :cond_f

    .line 291
    .line 292
    iget-object v0, v8, LKb/c;->a:Landroid/content/Context;

    .line 293
    .line 294
    sget v9, LL6/b;->ppColorWarning:I

    .line 295
    .line 296
    invoke-virtual {v0, v9}, Landroid/content/Context;->getColor(I)I

    .line 297
    .line 298
    .line 299
    move-result v0

    .line 300
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 301
    .line 302
    .line 303
    :cond_f
    if-eqz v2, :cond_14

    .line 304
    .line 305
    if-gtz v1, :cond_10

    .line 306
    .line 307
    iget-object v0, v8, LKb/c;->a:Landroid/content/Context;

    .line 308
    .line 309
    sget v1, LYa/g;->cs_cl_outstanding_item_desc_due_date_one:I

    .line 310
    .line 311
    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    goto :goto_6

    .line 316
    :cond_10
    iget-object v0, v8, LKb/c;->a:Landroid/content/Context;

    .line 317
    .line 318
    sget v1, LYa/g;->cs_cl_outstanding_item_desc_due_date:I

    .line 319
    .line 320
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 321
    .line 322
    .line 323
    move-result-object v6

    .line 324
    filled-new-array {v6}, [Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object v6

    .line 328
    invoke-virtual {v0, v1, v6}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 329
    .line 330
    .line 331
    move-result-object v0

    .line 332
    :goto_6
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 333
    .line 334
    .line 335
    goto :goto_7

    .line 336
    :cond_11
    if-eqz v2, :cond_12

    .line 337
    .line 338
    iget-object v1, v8, LKb/c;->a:Landroid/content/Context;

    .line 339
    .line 340
    sget v6, LYa/d;->cs_cl_outstanding_item_desc_bg_gray:I

    .line 341
    .line 342
    invoke-static {v6, v1}, Lr5/a;->q(ILandroid/content/Context;)Landroid/graphics/drawable/Drawable;

    .line 343
    .line 344
    .line 345
    move-result-object v1

    .line 346
    invoke-virtual {v2, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 347
    .line 348
    .line 349
    :cond_12
    if-eqz v2, :cond_13

    .line 350
    .line 351
    iget-object v1, v8, LKb/c;->a:Landroid/content/Context;

    .line 352
    .line 353
    sget v6, LL6/b;->ppColorTextAssist:I

    .line 354
    .line 355
    invoke-virtual {v1, v6}, Landroid/content/Context;->getColor(I)I

    .line 356
    .line 357
    .line 358
    move-result v1

    .line 359
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 360
    .line 361
    .line 362
    :cond_13
    if-eqz v2, :cond_14

    .line 363
    .line 364
    iget-object v1, v8, LKb/c;->a:Landroid/content/Context;

    .line 365
    .line 366
    sget v6, LYa/g;->cs_cl_outstanding_item_desc_normal:I

    .line 367
    .line 368
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 369
    .line 370
    .line 371
    move-result-object v0

    .line 372
    invoke-virtual {v1, v6, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 373
    .line 374
    .line 375
    move-result-object v0

    .line 376
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 377
    .line 378
    .line 379
    :cond_14
    :goto_7
    if-eqz p2, :cond_15

    .line 380
    .line 381
    iget-object p2, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->penalty:Ljava/lang/Long;

    .line 382
    .line 383
    if-eqz p2, :cond_15

    .line 384
    .line 385
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 386
    .line 387
    .line 388
    move-result-wide v0

    .line 389
    goto :goto_8

    .line 390
    :cond_15
    move-wide v0, v4

    .line 391
    :goto_8
    invoke-static {v0, v1, v3}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 392
    .line 393
    .line 394
    move-result-object p2

    .line 395
    iget-object p1, p1, Lwb/o;->g:Landroid/widget/TextView;

    .line 396
    .line 397
    if-eqz p1, :cond_17

    .line 398
    .line 399
    cmp-long v0, v0, v4

    .line 400
    .line 401
    if-lez v0, :cond_16

    .line 402
    .line 403
    goto :goto_9

    .line 404
    :cond_16
    const/4 v3, 0x0

    .line 405
    :goto_9
    invoke-static {p1, v3}, Loa/h;->s(Landroid/view/View;Z)V

    .line 406
    .line 407
    .line 408
    :cond_17
    if-eqz p1, :cond_18

    .line 409
    .line 410
    new-instance v0, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 411
    .line 412
    invoke-direct {v0}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 413
    .line 414
    .line 415
    iget-object v1, v8, LKb/c;->a:Landroid/content/Context;

    .line 416
    .line 417
    sget v2, LYa/g;->cs_cl_outstanding_item_desc_late_fee:I

    .line 418
    .line 419
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 420
    .line 421
    .line 422
    move-result-object v1

    .line 423
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 424
    .line 425
    .line 426
    move-result-object v0

    .line 427
    sget v1, LL6/b;->ppColorTextAssist:I

    .line 428
    .line 429
    iget-object v2, v8, LKb/c;->a:Landroid/content/Context;

    .line 430
    .line 431
    invoke-virtual {v2, v1}, Landroid/content/Context;->getColor(I)I

    .line 432
    .line 433
    .line 434
    move-result v1

    .line 435
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 436
    .line 437
    .line 438
    move-result-object v0

    .line 439
    const-string v1, " "

    .line 440
    .line 441
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 442
    .line 443
    .line 444
    move-result-object v0

    .line 445
    invoke-virtual {v0, p2}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 446
    .line 447
    .line 448
    move-result-object p2

    .line 449
    sget v0, LL6/b;->ppColorError:I

    .line 450
    .line 451
    invoke-static {v2, v0, p2, p1}, LC0/G;->w(Landroid/content/Context;ILcom/transsnet/palmpay/util/SpanUtils;Landroid/widget/TextView;)V

    .line 452
    .line 453
    .line 454
    :cond_18
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 3

    .line 1
    const-string p2, "parent"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p2, Lwb/o;

    .line 7
    .line 8
    iget-object v0, p0, LKb/c;->a:Landroid/content/Context;

    .line 9
    .line 10
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sget v1, LYa/f;->cs_cl_outstanding_detail_item:I

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    const-string v0, "inflate(...)"

    .line 22
    .line 23
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p2, p0, p1}, Lwb/o;-><init>(Lwb/p;Landroid/view/View;)V

    .line 27
    .line 28
    .line 29
    return-object p2
.end method
