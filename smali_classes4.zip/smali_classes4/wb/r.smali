.class public final Lwb/r;
.super LM1/j;
.source "SourceFile"

# interfaces
.implements Lcom/chad/library/adapter/base/module/LoadMoreModule;


# virtual methods
.method public final addLoadMoreModule(LM1/j;)LS1/c;
    .locals 0

    .line 1
    invoke-static {p0, p1}, LS1/e;->a(Lcom/chad/library/adapter/base/module/LoadMoreModule;LM1/j;)LS1/c;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/core/bean/rsp/GetRecentMerchantsResp$ListDataBean;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "item"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    sget v0, LYa/e;->tv_merchant:I

    .line 14
    .line 15
    iget-object v1, p2, Lcom/transsnet/palmpay/core/bean/rsp/GetRecentMerchantsResp$ListDataBean;->merchantName:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    sget v0, LYa/e;->tv_account_date:I

    .line 22
    .line 23
    iget-object v1, p2, Lcom/transsnet/palmpay/core/bean/rsp/GetRecentMerchantsResp$ListDataBean;->snNo:Ljava/lang/String;

    .line 24
    .line 25
    const-string v2, "snNo"

    .line 26
    .line 27
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const/4 v2, 0x0

    .line 31
    const-string v3, "M010001"

    .line 32
    .line 33
    invoke-static {v1, v3, v2}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_0

    .line 38
    .line 39
    iget-object p2, p2, Lcom/transsnet/palmpay/core/bean/rsp/GetRecentMerchantsResp$ListDataBean;->snNo:Ljava/lang/String;

    .line 40
    .line 41
    invoke-static {p2}, LPa/r0;->T1(Ljava/lang/String;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p2

    .line 45
    goto :goto_0

    .line 46
    :cond_0
    iget-object p2, p2, Lcom/transsnet/palmpay/core/bean/rsp/GetRecentMerchantsResp$ListDataBean;->snNo:Ljava/lang/String;

    .line 47
    .line 48
    invoke-static {p2}, LPa/i0;->o(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p2

    .line 52
    :goto_0
    new-instance v1, Ljava/lang/StringBuilder;

    .line 53
    .line 54
    const-string v2, "Account: "

    .line 55
    .line 56
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p2

    .line 66
    invoke-virtual {p1, v0, p2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 67
    .line 68
    .line 69
    return-void
.end method
