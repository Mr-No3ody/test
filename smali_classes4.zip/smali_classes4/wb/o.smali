.class public final Lwb/o;
.super LKb/b;
.source "SourceFile"


# instance fields
.field public final d:Landroid/widget/TextView;

.field public final e:Landroid/widget/TextView;

.field public final f:Landroid/widget/TextView;

.field public final g:Landroid/widget/TextView;

.field public final synthetic i:Lwb/p;


# direct methods
.method public constructor <init>(Lwb/p;Landroid/view/View;)V
    .locals 1

    .line 1
    const-string v0, "itemView"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lwb/o;->i:Lwb/p;

    .line 7
    .line 8
    invoke-direct {p0, p1, p2}, LKb/b;-><init>(LKb/c;Landroid/view/View;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, p2}, LKb/b;->a(Landroid/view/View;)V

    .line 12
    .line 13
    .line 14
    sget p1, LYa/e;->tvProduct:I

    .line 15
    .line 16
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    check-cast p1, Landroid/widget/TextView;

    .line 21
    .line 22
    iput-object p1, p0, Lwb/o;->d:Landroid/widget/TextView;

    .line 23
    .line 24
    sget p1, LYa/e;->tvDesc:I

    .line 25
    .line 26
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    check-cast p1, Landroid/widget/TextView;

    .line 31
    .line 32
    iput-object p1, p0, Lwb/o;->e:Landroid/widget/TextView;

    .line 33
    .line 34
    sget p1, LYa/e;->tvAmount:I

    .line 35
    .line 36
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Landroid/widget/TextView;

    .line 41
    .line 42
    iput-object p1, p0, Lwb/o;->f:Landroid/widget/TextView;

    .line 43
    .line 44
    sget p1, LYa/e;->tvLateFee:I

    .line 45
    .line 46
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, Landroid/widget/TextView;

    .line 51
    .line 52
    iput-object p1, p0, Lwb/o;->g:Landroid/widget/TextView;

    .line 53
    .line 54
    sget p1, LYa/e;->ivArrow:I

    .line 55
    .line 56
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    check-cast p1, Landroid/widget/ImageView;

    .line 61
    .line 62
    return-void
.end method
