.class public final Lwb/e;
.super LM1/b;
.source "SourceFile"


# instance fields
.field public b:Ljava/lang/String;

.field public c:LGb/v;


# virtual methods
.method public final b(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;)V
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    const-string v3, "holder"

    .line 8
    .line 9
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const-string v3, "item"

    .line 13
    .line 14
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getItemViewType()I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    const-string v6, "+"

    .line 22
    .line 23
    const-string v7, ","

    .line 24
    .line 25
    const-string v8, " "

    .line 26
    .line 27
    const/4 v9, 0x3

    .line 28
    const/4 v10, 0x0

    .line 29
    const/4 v11, 0x1

    .line 30
    if-eqz v3, :cond_42

    .line 31
    .line 32
    if-eq v3, v11, :cond_41

    .line 33
    .line 34
    const/4 v13, 0x6

    .line 35
    if-eq v3, v9, :cond_1b

    .line 36
    .line 37
    const/4 v4, 0x5

    .line 38
    if-eq v3, v4, :cond_a

    .line 39
    .line 40
    if-eq v3, v13, :cond_9

    .line 41
    .line 42
    const/4 v4, 0x7

    .line 43
    if-eq v3, v4, :cond_1

    .line 44
    .line 45
    const/16 v4, 0x8

    .line 46
    .line 47
    if-eq v3, v4, :cond_0

    .line 48
    .line 49
    goto/16 :goto_6f

    .line 50
    .line 51
    :cond_0
    sget v3, LYa/e;->vaTransferRepaymentView:I

    .line 52
    .line 53
    invoke-virtual {v0, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    check-cast v0, Lcom/transsnet/palmpay/credit/view/VaTransferRepaymentInfoView;

    .line 58
    .line 59
    if-eqz v0, :cond_b2

    .line 60
    .line 61
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/credit/view/VaTransferRepaymentInfoView;->a(Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :cond_1
    sget v3, LYa/e;->defaultView:I

    .line 66
    .line 67
    invoke-virtual {v0, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Lcom/transsnet/palmpay/credit/view/DefaultInfoView;

    .line 72
    .line 73
    if-eqz v0, :cond_b2

    .line 74
    .line 75
    iget-object v3, v1, Lwb/e;->b:Ljava/lang/String;

    .line 76
    .line 77
    invoke-virtual {v0, v3}, Lcom/transsnet/palmpay/credit/view/DefaultInfoView;->setAccountNo(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getDefaultInfoData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    if-nez v2, :cond_2

    .line 85
    .line 86
    goto/16 :goto_6f

    .line 87
    .line 88
    :cond_2
    iget-object v3, v2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;->itemStyle:Ljava/lang/String;

    .line 89
    .line 90
    if-eqz v3, :cond_4

    .line 91
    .line 92
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 93
    .line 94
    .line 95
    move-result v4

    .line 96
    if-nez v4, :cond_3

    .line 97
    .line 98
    goto :goto_0

    .line 99
    :cond_3
    const-class v4, Lcom/transsnet/palmpay/credit/bean/style/AgentInformationStyleConfig;

    .line 100
    .line 101
    const-string v5, "getAgentInfoStyleConfig"

    .line 102
    .line 103
    invoke-static {v3, v5, v4}, Lz5/l;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v3

    .line 107
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/style/AgentInformationStyleConfig;

    .line 108
    .line 109
    :cond_4
    :goto_0
    iget-object v0, v0, Lcom/transsnet/palmpay/credit/view/DefaultInfoView;->a:LBc/b;

    .line 110
    .line 111
    if-eqz v0, :cond_5

    .line 112
    .line 113
    iget-object v3, v0, LBc/b;->f:Landroid/view/View;

    .line 114
    .line 115
    check-cast v3, Landroid/widget/ImageView;

    .line 116
    .line 117
    goto :goto_1

    .line 118
    :cond_5
    const/4 v3, 0x0

    .line 119
    :goto_1
    iget-object v4, v2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;->phoneImage:Ljava/lang/String;

    .line 120
    .line 121
    iget-object v5, v2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;->phoneImageDark:Ljava/lang/String;

    .line 122
    .line 123
    invoke-static {v3, v4, v5}, LPa/r0;->q1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    if-eqz v0, :cond_6

    .line 127
    .line 128
    iget-object v3, v0, LBc/b;->g:Landroid/view/View;

    .line 129
    .line 130
    check-cast v3, Landroid/widget/ImageView;

    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_6
    const/4 v3, 0x0

    .line 134
    :goto_2
    iget-object v4, v2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;->descriptionImage:Ljava/lang/String;

    .line 135
    .line 136
    iget-object v5, v2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;->descriptionImageDark:Ljava/lang/String;

    .line 137
    .line 138
    invoke-static {v3, v4, v5}, LPa/r0;->q1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    if-eqz v0, :cond_7

    .line 142
    .line 143
    iget-object v3, v0, LBc/b;->e:Ljava/lang/Object;

    .line 144
    .line 145
    move-object v12, v3

    .line 146
    check-cast v12, Landroid/widget/ImageView;

    .line 147
    .line 148
    goto :goto_3

    .line 149
    :cond_7
    const/4 v12, 0x0

    .line 150
    :goto_3
    iget-object v3, v2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;->customerServiceImage:Ljava/lang/String;

    .line 151
    .line 152
    iget-object v4, v2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;->customerServiceImageDark:Ljava/lang/String;

    .line 153
    .line 154
    invoke-static {v12, v3, v4}, LPa/r0;->q1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    if-eqz v0, :cond_8

    .line 158
    .line 159
    iget-object v3, v0, LBc/b;->c:Landroid/view/View;

    .line 160
    .line 161
    check-cast v3, Landroid/widget/TextView;

    .line 162
    .line 163
    iget-object v4, v2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/DefaultInfoData;->customerServicePhone:Ljava/lang/String;

    .line 164
    .line 165
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 166
    .line 167
    .line 168
    :cond_8
    if-eqz v0, :cond_b2

    .line 169
    .line 170
    iget-object v0, v0, LBc/b;->b:Landroid/view/ViewGroup;

    .line 171
    .line 172
    check-cast v0, Landroid/widget/LinearLayout;

    .line 173
    .line 174
    new-instance v3, LCe/a;

    .line 175
    .line 176
    const/16 v4, 0x12

    .line 177
    .line 178
    invoke-direct {v3, v2, v4}, LCe/a;-><init>(Ljava/lang/Object;I)V

    .line 179
    .line 180
    .line 181
    invoke-virtual {v0, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 182
    .line 183
    .line 184
    return-void

    .line 185
    :cond_9
    sget v3, LYa/e;->aboutRepaymentView:I

    .line 186
    .line 187
    invoke-virtual {v0, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    check-cast v0, Lcom/transsnet/palmpay/credit/view/AboutRepaymentInfoView;

    .line 192
    .line 193
    if-eqz v0, :cond_b2

    .line 194
    .line 195
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getAboutRepaymentData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/AboutRepaymentCardData;

    .line 196
    .line 197
    .line 198
    move-result-object v2

    .line 199
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/credit/view/AboutRepaymentInfoView;->a(Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/AboutRepaymentCardData;)V

    .line 200
    .line 201
    .line 202
    return-void

    .line 203
    :cond_a
    sget v3, LYa/e;->productInfoChangeView:I

    .line 204
    .line 205
    invoke-virtual {v0, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    check-cast v0, Lcom/transsnet/palmpay/credit/view/ProductInfoChangeView;

    .line 210
    .line 211
    if-eqz v0, :cond_b2

    .line 212
    .line 213
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getProductInfoChangeData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;

    .line 214
    .line 215
    .line 216
    move-result-object v2

    .line 217
    if-eqz v2, :cond_b

    .line 218
    .line 219
    move v10, v11

    .line 220
    :cond_b
    invoke-static {v0, v10}, Loa/h;->s(Landroid/view/View;Z)V

    .line 221
    .line 222
    .line 223
    if-eqz v2, :cond_b2

    .line 224
    .line 225
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getItemStyle()Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object v3

    .line 229
    iget-object v4, v0, Lcom/transsnet/palmpay/credit/view/ProductInfoChangeView;->a:LBc/b;

    .line 230
    .line 231
    if-eqz v3, :cond_14

    .line 232
    .line 233
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 234
    .line 235
    .line 236
    move-result v5

    .line 237
    if-nez v5, :cond_c

    .line 238
    .line 239
    goto/16 :goto_b

    .line 240
    .line 241
    :cond_c
    const-class v5, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;

    .line 242
    .line 243
    const-string v6, "getMobileInstallmentProductInfoStyleConfig"

    .line 244
    .line 245
    invoke-static {v3, v6, v5}, Lz5/l;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    move-result-object v3

    .line 249
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;

    .line 250
    .line 251
    if-eqz v3, :cond_14

    .line 252
    .line 253
    if-eqz v4, :cond_d

    .line 254
    .line 255
    iget-object v5, v4, LBc/b;->b:Landroid/view/ViewGroup;

    .line 256
    .line 257
    check-cast v5, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 258
    .line 259
    goto :goto_4

    .line 260
    :cond_d
    const/4 v5, 0x0

    .line 261
    :goto_4
    iget-object v6, v3, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;->productInfoChangeBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 262
    .line 263
    invoke-static {v5, v6}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 264
    .line 265
    .line 266
    if-eqz v4, :cond_e

    .line 267
    .line 268
    iget-object v5, v4, LBc/b;->e:Ljava/lang/Object;

    .line 269
    .line 270
    check-cast v5, Landroid/widget/TextView;

    .line 271
    .line 272
    goto :goto_5

    .line 273
    :cond_e
    const/4 v5, 0x0

    .line 274
    :goto_5
    iget-object v6, v3, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;->productInfoTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 275
    .line 276
    invoke-static {v5, v6}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 277
    .line 278
    .line 279
    if-eqz v4, :cond_f

    .line 280
    .line 281
    iget-object v5, v4, LBc/b;->d:Landroid/view/View;

    .line 282
    .line 283
    check-cast v5, Landroid/widget/TextView;

    .line 284
    .line 285
    goto :goto_6

    .line 286
    :cond_f
    const/4 v5, 0x0

    .line 287
    :goto_6
    iget-object v6, v3, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;->productInfoSubTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 288
    .line 289
    invoke-static {v5, v6}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 290
    .line 291
    .line 292
    if-eqz v4, :cond_10

    .line 293
    .line 294
    iget-object v5, v4, LBc/b;->f:Landroid/view/View;

    .line 295
    .line 296
    check-cast v5, Landroid/widget/ImageView;

    .line 297
    .line 298
    goto :goto_7

    .line 299
    :cond_10
    const/4 v5, 0x0

    .line 300
    :goto_7
    iget-object v6, v3, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;->productInfoTitleImageIcon:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 301
    .line 302
    invoke-static {v5, v6}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 303
    .line 304
    .line 305
    if-eqz v4, :cond_11

    .line 306
    .line 307
    iget-object v5, v4, LBc/b;->g:Landroid/view/View;

    .line 308
    .line 309
    check-cast v5, Landroid/widget/ImageView;

    .line 310
    .line 311
    goto :goto_8

    .line 312
    :cond_11
    const/4 v5, 0x0

    .line 313
    :goto_8
    iget-object v6, v3, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;->productInfoActiveImageIcon:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 314
    .line 315
    invoke-static {v5, v6}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 316
    .line 317
    .line 318
    if-eqz v4, :cond_12

    .line 319
    .line 320
    iget-object v5, v4, LBc/b;->c:Landroid/view/View;

    .line 321
    .line 322
    check-cast v5, Landroid/widget/TextView;

    .line 323
    .line 324
    goto :goto_9

    .line 325
    :cond_12
    const/4 v5, 0x0

    .line 326
    :goto_9
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;->getProductInfoLocateBg()Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 327
    .line 328
    .line 329
    move-result-object v6

    .line 330
    invoke-static {v5, v6}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 331
    .line 332
    .line 333
    if-eqz v4, :cond_13

    .line 334
    .line 335
    iget-object v5, v4, LBc/b;->c:Landroid/view/View;

    .line 336
    .line 337
    check-cast v5, Landroid/widget/TextView;

    .line 338
    .line 339
    goto :goto_a

    .line 340
    :cond_13
    const/4 v5, 0x0

    .line 341
    :goto_a
    iget-object v3, v3, Lcom/transsnet/palmpay/credit/bean/style/ProductInfoChangeStyleConfig;->productInfoLocateText:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 342
    .line 343
    invoke-static {v5, v3}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 344
    .line 345
    .line 346
    :cond_14
    :goto_b
    if-eqz v4, :cond_15

    .line 347
    .line 348
    iget-object v3, v4, LBc/b;->f:Landroid/view/View;

    .line 349
    .line 350
    check-cast v3, Landroid/widget/ImageView;

    .line 351
    .line 352
    goto :goto_c

    .line 353
    :cond_15
    const/4 v3, 0x0

    .line 354
    :goto_c
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 355
    .line 356
    .line 357
    move-result-object v5

    .line 358
    const-string v6, "null cannot be cast to non-null type com.transsnet.palmpay.core.base.BaseActivity"

    .line 359
    .line 360
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    check-cast v5, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 364
    .line 365
    invoke-virtual {v5}, Lcom/transsnet/palmpay/core/base/BaseActivity;->isDarkMode()Z

    .line 366
    .line 367
    .line 368
    move-result v5

    .line 369
    if-eqz v5, :cond_16

    .line 370
    .line 371
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getTitleImageDark()Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v5

    .line 375
    goto :goto_d

    .line 376
    :cond_16
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getTitleImage()Ljava/lang/String;

    .line 377
    .line 378
    .line 379
    move-result-object v5

    .line 380
    :goto_d
    invoke-static {v5, v3}, LPa/r0;->l1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 381
    .line 382
    .line 383
    if-eqz v4, :cond_17

    .line 384
    .line 385
    iget-object v3, v4, LBc/b;->g:Landroid/view/View;

    .line 386
    .line 387
    move-object v12, v3

    .line 388
    check-cast v12, Landroid/widget/ImageView;

    .line 389
    .line 390
    goto :goto_e

    .line 391
    :cond_17
    const/4 v12, 0x0

    .line 392
    :goto_e
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 393
    .line 394
    .line 395
    move-result-object v0

    .line 396
    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 397
    .line 398
    .line 399
    check-cast v0, Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 400
    .line 401
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/base/BaseActivity;->isDarkMode()Z

    .line 402
    .line 403
    .line 404
    move-result v0

    .line 405
    if-eqz v0, :cond_18

    .line 406
    .line 407
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getActiveImageDark()Ljava/lang/String;

    .line 408
    .line 409
    .line 410
    move-result-object v0

    .line 411
    goto :goto_f

    .line 412
    :cond_18
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getActiveImage()Ljava/lang/String;

    .line 413
    .line 414
    .line 415
    move-result-object v0

    .line 416
    :goto_f
    invoke-static {v0, v12}, LPa/r0;->l1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 417
    .line 418
    .line 419
    if-eqz v4, :cond_19

    .line 420
    .line 421
    iget-object v0, v4, LBc/b;->e:Ljava/lang/Object;

    .line 422
    .line 423
    check-cast v0, Landroid/widget/TextView;

    .line 424
    .line 425
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getTitle()Ljava/lang/String;

    .line 426
    .line 427
    .line 428
    move-result-object v3

    .line 429
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 430
    .line 431
    .line 432
    :cond_19
    if-eqz v4, :cond_1a

    .line 433
    .line 434
    iget-object v0, v4, LBc/b;->d:Landroid/view/View;

    .line 435
    .line 436
    check-cast v0, Landroid/widget/TextView;

    .line 437
    .line 438
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getDescription()Ljava/lang/String;

    .line 439
    .line 440
    .line 441
    move-result-object v3

    .line 442
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 443
    .line 444
    .line 445
    :cond_1a
    if-eqz v4, :cond_b2

    .line 446
    .line 447
    iget-object v0, v4, LBc/b;->c:Landroid/view/View;

    .line 448
    .line 449
    check-cast v0, Landroid/widget/TextView;

    .line 450
    .line 451
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getButton()Ljava/lang/String;

    .line 452
    .line 453
    .line 454
    move-result-object v2

    .line 455
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 456
    .line 457
    .line 458
    return-void

    .line 459
    :cond_1b
    sget v3, LYa/e;->phoneInstallmentLoanWaitPayView:I

    .line 460
    .line 461
    invoke-virtual {v0, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 462
    .line 463
    .line 464
    move-result-object v0

    .line 465
    check-cast v0, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanWaitPayView;

    .line 466
    .line 467
    if-eqz v0, :cond_b2

    .line 468
    .line 469
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getHirePurchaseDownPayCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;

    .line 470
    .line 471
    .line 472
    move-result-object v2

    .line 473
    if-eqz v2, :cond_b2

    .line 474
    .line 475
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getItemStyle()Ljava/lang/String;

    .line 476
    .line 477
    .line 478
    move-result-object v3

    .line 479
    iget-object v9, v0, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanWaitPayView;->a:LBc/s;

    .line 480
    .line 481
    if-eqz v3, :cond_2b

    .line 482
    .line 483
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 484
    .line 485
    .line 486
    move-result v14

    .line 487
    if-nez v14, :cond_1c

    .line 488
    .line 489
    goto/16 :goto_1e

    .line 490
    .line 491
    :cond_1c
    const-class v14, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;

    .line 492
    .line 493
    const-string v15, "getMobileInstallmentFirstPayStyleConfig"

    .line 494
    .line 495
    invoke-static {v3, v15, v14}, Lz5/l;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 496
    .line 497
    .line 498
    move-result-object v3

    .line 499
    check-cast v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;

    .line 500
    .line 501
    if-eqz v3, :cond_2c

    .line 502
    .line 503
    if-eqz v9, :cond_1d

    .line 504
    .line 505
    iget-object v14, v9, LBc/s;->H:Landroid/view/View;

    .line 506
    .line 507
    goto :goto_10

    .line 508
    :cond_1d
    const/4 v14, 0x0

    .line 509
    :goto_10
    iget-object v15, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->topDividerBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 510
    .line 511
    invoke-static {v14, v15}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 512
    .line 513
    .line 514
    if-eqz v9, :cond_1e

    .line 515
    .line 516
    iget-object v14, v9, LBc/s;->v:Landroid/view/ViewGroup;

    .line 517
    .line 518
    check-cast v14, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 519
    .line 520
    goto :goto_11

    .line 521
    :cond_1e
    const/4 v14, 0x0

    .line 522
    :goto_11
    iget-object v15, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->cardBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 523
    .line 524
    invoke-static {v14, v15}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 525
    .line 526
    .line 527
    if-eqz v9, :cond_1f

    .line 528
    .line 529
    iget-object v14, v9, LBc/s;->c:Landroid/widget/TextView;

    .line 530
    .line 531
    goto :goto_12

    .line 532
    :cond_1f
    const/4 v14, 0x0

    .line 533
    :goto_12
    iget-object v15, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->brand:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 534
    .line 535
    invoke-static {v14, v15}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 536
    .line 537
    .line 538
    if-eqz v9, :cond_20

    .line 539
    .line 540
    iget-object v14, v9, LBc/s;->g:Landroid/widget/TextView;

    .line 541
    .line 542
    goto :goto_13

    .line 543
    :cond_20
    const/4 v14, 0x0

    .line 544
    :goto_13
    iget-object v15, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->mobilePriceLabel:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 545
    .line 546
    invoke-static {v14, v15}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 547
    .line 548
    .line 549
    if-eqz v9, :cond_21

    .line 550
    .line 551
    iget-object v14, v9, LBc/s;->i:Landroid/widget/TextView;

    .line 552
    .line 553
    goto :goto_14

    .line 554
    :cond_21
    const/4 v14, 0x0

    .line 555
    :goto_14
    iget-object v15, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->productAmount:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 556
    .line 557
    invoke-static {v14, v15}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 558
    .line 559
    .line 560
    if-eqz v9, :cond_22

    .line 561
    .line 562
    iget-object v14, v9, LBc/s;->f:Landroid/widget/TextView;

    .line 563
    .line 564
    goto :goto_15

    .line 565
    :cond_22
    const/4 v14, 0x0

    .line 566
    :goto_15
    iget-object v15, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->downPaymentTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 567
    .line 568
    invoke-static {v14, v15}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 569
    .line 570
    .line 571
    if-eqz v9, :cond_23

    .line 572
    .line 573
    iget-object v14, v9, LBc/s;->e:Landroid/widget/TextView;

    .line 574
    .line 575
    goto :goto_16

    .line 576
    :cond_23
    const/4 v14, 0x0

    .line 577
    :goto_16
    iget-object v15, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->downPaymentAmount:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 578
    .line 579
    invoke-static {v14, v15}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 580
    .line 581
    .line 582
    if-eqz v9, :cond_24

    .line 583
    .line 584
    iget-object v14, v9, LBc/s;->b:Landroid/widget/TextView;

    .line 585
    .line 586
    goto :goto_17

    .line 587
    :cond_24
    const/4 v14, 0x0

    .line 588
    :goto_17
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getRepaymentStatus()Ljava/lang/Integer;

    .line 589
    .line 590
    .line 591
    move-result-object v15

    .line 592
    if-nez v15, :cond_25

    .line 593
    .line 594
    goto :goto_18

    .line 595
    :cond_25
    invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I

    .line 596
    .line 597
    .line 598
    move-result v15

    .line 599
    if-ne v15, v13, :cond_26

    .line 600
    .line 601
    iget-object v13, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->btnConfirmPay:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 602
    .line 603
    goto :goto_19

    .line 604
    :cond_26
    :goto_18
    iget-object v13, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->btnConfirmPayUnable:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 605
    .line 606
    :goto_19
    invoke-static {v14, v13}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 607
    .line 608
    .line 609
    if-eqz v9, :cond_27

    .line 610
    .line 611
    iget-object v13, v9, LBc/s;->w:Landroid/view/ViewGroup;

    .line 612
    .line 613
    check-cast v13, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 614
    .line 615
    goto :goto_1a

    .line 616
    :cond_27
    const/4 v13, 0x0

    .line 617
    :goto_1a
    iget-object v14, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->totalOutstandingBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 618
    .line 619
    invoke-static {v13, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 620
    .line 621
    .line 622
    if-eqz v9, :cond_28

    .line 623
    .line 624
    iget-object v13, v9, LBc/s;->p:Landroid/widget/TextView;

    .line 625
    .line 626
    goto :goto_1b

    .line 627
    :cond_28
    const/4 v13, 0x0

    .line 628
    :goto_1b
    iget-object v14, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->totalOutstandingTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 629
    .line 630
    invoke-static {v13, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 631
    .line 632
    .line 633
    if-eqz v9, :cond_29

    .line 634
    .line 635
    iget-object v13, v9, LBc/s;->o:Landroid/widget/TextView;

    .line 636
    .line 637
    goto :goto_1c

    .line 638
    :cond_29
    const/4 v13, 0x0

    .line 639
    :goto_1c
    iget-object v14, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->totalOutstandingAmount:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 640
    .line 641
    invoke-static {v13, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 642
    .line 643
    .line 644
    if-eqz v9, :cond_2a

    .line 645
    .line 646
    iget-object v13, v9, LBc/s;->j:Landroid/widget/TextView;

    .line 647
    .line 648
    goto :goto_1d

    .line 649
    :cond_2a
    const/4 v13, 0x0

    .line 650
    :goto_1d
    iget-object v14, v3, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;->repaymentTotalTerms:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 651
    .line 652
    invoke-static {v13, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 653
    .line 654
    .line 655
    goto :goto_1f

    .line 656
    :cond_2b
    :goto_1e
    const/4 v3, 0x0

    .line 657
    :cond_2c
    :goto_1f
    if-eqz v9, :cond_2d

    .line 658
    .line 659
    iget-object v13, v9, LBc/s;->A:Landroid/view/View;

    .line 660
    .line 661
    check-cast v13, Landroid/widget/ImageView;

    .line 662
    .line 663
    goto :goto_20

    .line 664
    :cond_2d
    const/4 v13, 0x0

    .line 665
    :goto_20
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getTitleBrandIocUrl()Ljava/lang/String;

    .line 666
    .line 667
    .line 668
    move-result-object v14

    .line 669
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getTitleBrandIocUrlDark()Ljava/lang/String;

    .line 670
    .line 671
    .line 672
    move-result-object v15

    .line 673
    invoke-static {v13, v14, v15}, LPa/r0;->k1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 674
    .line 675
    .line 676
    if-eqz v9, :cond_2e

    .line 677
    .line 678
    iget-object v13, v9, LBc/s;->B:Landroid/view/View;

    .line 679
    .line 680
    check-cast v13, Landroid/widget/ImageView;

    .line 681
    .line 682
    goto :goto_21

    .line 683
    :cond_2e
    const/4 v13, 0x0

    .line 684
    :goto_21
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getPhoneBrandIocUrl()Ljava/lang/String;

    .line 685
    .line 686
    .line 687
    move-result-object v14

    .line 688
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getPhoneBrandIocUrlDark()Ljava/lang/String;

    .line 689
    .line 690
    .line 691
    move-result-object v15

    .line 692
    invoke-static {v13, v14, v15}, LPa/r0;->k1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 693
    .line 694
    .line 695
    if-eqz v9, :cond_2f

    .line 696
    .line 697
    iget-object v13, v9, LBc/s;->c:Landroid/widget/TextView;

    .line 698
    .line 699
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getBrand()Ljava/lang/String;

    .line 700
    .line 701
    .line 702
    move-result-object v14

    .line 703
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getType()Ljava/lang/String;

    .line 704
    .line 705
    .line 706
    move-result-object v15

    .line 707
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getStorage()Ljava/lang/String;

    .line 708
    .line 709
    .line 710
    move-result-object v4

    .line 711
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getMemory()Ljava/lang/String;

    .line 712
    .line 713
    .line 714
    move-result-object v5

    .line 715
    new-instance v12, Ljava/lang/StringBuilder;

    .line 716
    .line 717
    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    .line 718
    .line 719
    .line 720
    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 721
    .line 722
    .line 723
    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 724
    .line 725
    .line 726
    invoke-virtual {v12, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 727
    .line 728
    .line 729
    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 730
    .line 731
    .line 732
    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 733
    .line 734
    .line 735
    invoke-virtual {v12, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 736
    .line 737
    .line 738
    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 739
    .line 740
    .line 741
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 742
    .line 743
    .line 744
    move-result-object v4

    .line 745
    invoke-virtual {v13, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 746
    .line 747
    .line 748
    :cond_2f
    if-eqz v9, :cond_31

    .line 749
    .line 750
    iget-object v4, v9, LBc/s;->i:Landroid/widget/TextView;

    .line 751
    .line 752
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getProductAmount()Ljava/lang/Long;

    .line 753
    .line 754
    .line 755
    move-result-object v5

    .line 756
    if-eqz v5, :cond_30

    .line 757
    .line 758
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 759
    .line 760
    .line 761
    move-result-wide v5

    .line 762
    goto :goto_22

    .line 763
    :cond_30
    const-wide/16 v5, 0x0

    .line 764
    .line 765
    :goto_22
    invoke-static {v5, v6, v11}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 766
    .line 767
    .line 768
    move-result-object v5

    .line 769
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 770
    .line 771
    .line 772
    move-result-object v5

    .line 773
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 774
    .line 775
    .line 776
    :cond_31
    if-eqz v9, :cond_32

    .line 777
    .line 778
    iget-object v4, v9, LBc/s;->f:Landroid/widget/TextView;

    .line 779
    .line 780
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getDownPaymentTitle()Ljava/lang/String;

    .line 781
    .line 782
    .line 783
    move-result-object v5

    .line 784
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 785
    .line 786
    .line 787
    :cond_32
    if-eqz v9, :cond_34

    .line 788
    .line 789
    iget-object v4, v9, LBc/s;->e:Landroid/widget/TextView;

    .line 790
    .line 791
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getDownPaymentAmount()Ljava/lang/Long;

    .line 792
    .line 793
    .line 794
    move-result-object v5

    .line 795
    if-eqz v5, :cond_33

    .line 796
    .line 797
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 798
    .line 799
    .line 800
    move-result-wide v5

    .line 801
    goto :goto_23

    .line 802
    :cond_33
    const-wide/16 v5, 0x0

    .line 803
    .line 804
    :goto_23
    invoke-static {v5, v6, v11}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 805
    .line 806
    .line 807
    move-result-object v5

    .line 808
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 809
    .line 810
    .line 811
    :cond_34
    if-eqz v9, :cond_35

    .line 812
    .line 813
    iget-object v4, v9, LBc/s;->p:Landroid/widget/TextView;

    .line 814
    .line 815
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getUnpaidAmountTitle()Ljava/lang/String;

    .line 816
    .line 817
    .line 818
    move-result-object v5

    .line 819
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 820
    .line 821
    .line 822
    :cond_35
    if-eqz v9, :cond_37

    .line 823
    .line 824
    iget-object v4, v9, LBc/s;->o:Landroid/widget/TextView;

    .line 825
    .line 826
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getUnpaidAmount()Ljava/lang/Long;

    .line 827
    .line 828
    .line 829
    move-result-object v5

    .line 830
    if-eqz v5, :cond_36

    .line 831
    .line 832
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 833
    .line 834
    .line 835
    move-result-wide v5

    .line 836
    goto :goto_24

    .line 837
    :cond_36
    const-wide/16 v5, 0x0

    .line 838
    .line 839
    :goto_24
    invoke-static {v5, v6, v11}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 840
    .line 841
    .line 842
    move-result-object v5

    .line 843
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 844
    .line 845
    .line 846
    :cond_37
    if-eqz v9, :cond_38

    .line 847
    .line 848
    iget-object v4, v9, LBc/s;->b:Landroid/widget/TextView;

    .line 849
    .line 850
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getBtnConfirmPay()Ljava/lang/String;

    .line 851
    .line 852
    .line 853
    move-result-object v5

    .line 854
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 855
    .line 856
    .line 857
    :cond_38
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getBtnMsg()Ljava/lang/String;

    .line 858
    .line 859
    .line 860
    move-result-object v4

    .line 861
    if-eqz v4, :cond_3b

    .line 862
    .line 863
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 864
    .line 865
    .line 866
    move-result v5

    .line 867
    if-nez v5, :cond_39

    .line 868
    .line 869
    goto :goto_25

    .line 870
    :cond_39
    const/4 v4, 0x0

    .line 871
    :goto_25
    if-eqz v4, :cond_3b

    .line 872
    .line 873
    if-eqz v9, :cond_3a

    .line 874
    .line 875
    iget-object v5, v9, LBc/s;->d:Landroid/widget/TextView;

    .line 876
    .line 877
    invoke-static {v5}, Loa/h;->C(Landroid/view/View;)V

    .line 878
    .line 879
    .line 880
    :cond_3a
    if-eqz v9, :cond_3c

    .line 881
    .line 882
    iget-object v5, v9, LBc/s;->d:Landroid/widget/TextView;

    .line 883
    .line 884
    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 885
    .line 886
    .line 887
    goto :goto_26

    .line 888
    :cond_3b
    if-eqz v9, :cond_3c

    .line 889
    .line 890
    iget-object v4, v9, LBc/s;->d:Landroid/widget/TextView;

    .line 891
    .line 892
    invoke-static {v4}, Loa/h;->c(Landroid/view/View;)V

    .line 893
    .line 894
    .line 895
    :cond_3c
    :goto_26
    if-eqz v9, :cond_3d

    .line 896
    .line 897
    iget-object v4, v9, LBc/s;->j:Landroid/widget/TextView;

    .line 898
    .line 899
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getLoanTermTitle()Ljava/lang/String;

    .line 900
    .line 901
    .line 902
    move-result-object v5

    .line 903
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 904
    .line 905
    .line 906
    :cond_3d
    if-eqz v9, :cond_3e

    .line 907
    .line 908
    iget-object v4, v9, LBc/s;->C:Landroid/view/ViewGroup;

    .line 909
    .line 910
    check-cast v4, Lcom/transsnet/palmpay/credit/view/InnerRecyclerView;

    .line 911
    .line 912
    invoke-virtual {v4, v11}, Landroidx/recyclerview/widget/RecyclerView;->setHasFixedSize(Z)V

    .line 913
    .line 914
    .line 915
    :cond_3e
    if-eqz v9, :cond_3f

    .line 916
    .line 917
    iget-object v4, v9, LBc/s;->C:Landroid/view/ViewGroup;

    .line 918
    .line 919
    check-cast v4, Lcom/transsnet/palmpay/credit/view/InnerRecyclerView;

    .line 920
    .line 921
    new-instance v5, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 922
    .line 923
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 924
    .line 925
    .line 926
    move-result-object v0

    .line 927
    invoke-direct {v5, v0, v11, v10}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    .line 928
    .line 929
    .line 930
    invoke-virtual {v4, v5}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 931
    .line 932
    .line 933
    :cond_3f
    if-eqz v9, :cond_b2

    .line 934
    .line 935
    iget-object v0, v9, LBc/s;->C:Landroid/view/ViewGroup;

    .line 936
    .line 937
    check-cast v0, Lcom/transsnet/palmpay/credit/view/InnerRecyclerView;

    .line 938
    .line 939
    sget v4, LYa/f;->cs_cl_phone_installment_loan_repayment_plan_item:I

    .line 940
    .line 941
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getRepaymentPlanList()Ljava/util/List;

    .line 942
    .line 943
    .line 944
    move-result-object v2

    .line 945
    if-eqz v2, :cond_40

    .line 946
    .line 947
    check-cast v2, Ljava/util/Collection;

    .line 948
    .line 949
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->Z(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 950
    .line 951
    .line 952
    move-result-object v12

    .line 953
    goto :goto_27

    .line 954
    :cond_40
    const/4 v12, 0x0

    .line 955
    :goto_27
    new-instance v2, LGb/M;

    .line 956
    .line 957
    invoke-direct {v2, v3, v4, v12}, LGb/M;-><init>(Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentFirstPayStyleConfig;ILjava/util/ArrayList;)V

    .line 958
    .line 959
    .line 960
    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 961
    .line 962
    .line 963
    return-void

    .line 964
    :cond_41
    sget v3, LYa/e;->agentInfoView:I

    .line 965
    .line 966
    invoke-virtual {v0, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 967
    .line 968
    .line 969
    move-result-object v0

    .line 970
    check-cast v0, Lcom/transsnet/palmpay/credit/view/AgentInformationView;

    .line 971
    .line 972
    if-eqz v0, :cond_b2

    .line 973
    .line 974
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getAgentInfoData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/AgentInformationCardData;

    .line 975
    .line 976
    .line 977
    move-result-object v2

    .line 978
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/credit/view/AgentInformationView;->c(Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/AgentInformationCardData;)V

    .line 979
    .line 980
    .line 981
    return-void

    .line 982
    :cond_42
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getMobileInstallmentCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;

    .line 983
    .line 984
    .line 985
    move-result-object v2

    .line 986
    sget v3, LYa/e;->phoneInstallmentDailyLoanView:I

    .line 987
    .line 988
    invoke-virtual {v0, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 989
    .line 990
    .line 991
    move-result-object v3

    .line 992
    check-cast v3, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentDailyLoanView;

    .line 993
    .line 994
    sget v4, LYa/e;->phoneInstallmentLoanView:I

    .line 995
    .line 996
    invoke-virtual {v0, v4}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 997
    .line 998
    .line 999
    move-result-object v0

    .line 1000
    move-object v4, v0

    .line 1001
    check-cast v4, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;

    .line 1002
    .line 1003
    if-eqz v2, :cond_43

    .line 1004
    .line 1005
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLoanTermSpanUnit()Ljava/lang/String;

    .line 1006
    .line 1007
    .line 1008
    move-result-object v0

    .line 1009
    goto :goto_28

    .line 1010
    :cond_43
    const/4 v0, 0x0

    .line 1011
    :goto_28
    if-eqz v0, :cond_44

    .line 1012
    .line 1013
    invoke-static {v0}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 1014
    .line 1015
    .line 1016
    move-result-object v0

    .line 1017
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1018
    .line 1019
    .line 1020
    move-result-object v0

    .line 1021
    goto :goto_29

    .line 1022
    :cond_44
    const/4 v0, 0x0

    .line 1023
    :goto_29
    const-string v5, "D"

    .line 1024
    .line 1025
    invoke-virtual {v5, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 1026
    .line 1027
    .line 1028
    move-result v0

    .line 1029
    if-eqz v0, :cond_47

    .line 1030
    .line 1031
    if-eqz v4, :cond_45

    .line 1032
    .line 1033
    invoke-static {v4}, Loa/h;->c(Landroid/view/View;)V

    .line 1034
    .line 1035
    .line 1036
    :cond_45
    if-eqz v3, :cond_46

    .line 1037
    .line 1038
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 1039
    .line 1040
    .line 1041
    :cond_46
    if-eqz v3, :cond_b2

    .line 1042
    .line 1043
    iget-object v0, v1, Lwb/e;->c:LGb/v;

    .line 1044
    .line 1045
    invoke-virtual {v3, v0}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentDailyLoanView;->setOnUnlockCountDownFinished(Lkotlin/jvm/functions/Function0;)V

    .line 1046
    .line 1047
    .line 1048
    invoke-virtual {v3, v2}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentDailyLoanView;->j(Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;)V

    .line 1049
    .line 1050
    .line 1051
    return-void

    .line 1052
    :cond_47
    if-eqz v3, :cond_48

    .line 1053
    .line 1054
    invoke-static {v3}, Loa/h;->c(Landroid/view/View;)V

    .line 1055
    .line 1056
    .line 1057
    :cond_48
    if-eqz v4, :cond_49

    .line 1058
    .line 1059
    invoke-static {v4}, Loa/h;->C(Landroid/view/View;)V

    .line 1060
    .line 1061
    .line 1062
    :cond_49
    if-eqz v4, :cond_b2

    .line 1063
    .line 1064
    iget-object v0, v1, Lwb/e;->c:LGb/v;

    .line 1065
    .line 1066
    invoke-virtual {v4, v0}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->setOnUnlockCountDownFinished(Lkotlin/jvm/functions/Function0;)V

    .line 1067
    .line 1068
    .line 1069
    if-nez v2, :cond_4a

    .line 1070
    .line 1071
    invoke-virtual {v4}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->b()V

    .line 1072
    .line 1073
    .line 1074
    goto/16 :goto_6f

    .line 1075
    .line 1076
    :cond_4a
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getItemStyle()Ljava/lang/String;

    .line 1077
    .line 1078
    .line 1079
    move-result-object v0

    .line 1080
    iget-object v3, v4, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->a:Lgb/e;

    .line 1081
    .line 1082
    const-string v5, ""

    .line 1083
    .line 1084
    const/4 v12, 0x2

    .line 1085
    if-eqz v0, :cond_79

    .line 1086
    .line 1087
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 1088
    .line 1089
    .line 1090
    move-result v13

    .line 1091
    if-nez v13, :cond_4b

    .line 1092
    .line 1093
    goto/16 :goto_51

    .line 1094
    .line 1095
    :cond_4b
    const-class v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;

    .line 1096
    .line 1097
    const-string v14, "getMobileInstallmentStyleConfig"

    .line 1098
    .line 1099
    invoke-static {v0, v14, v13}, Lz5/l;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 1100
    .line 1101
    .line 1102
    move-result-object v0

    .line 1103
    move-object v13, v0

    .line 1104
    check-cast v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;

    .line 1105
    .line 1106
    if-eqz v13, :cond_79

    .line 1107
    .line 1108
    if-eqz v3, :cond_4c

    .line 1109
    .line 1110
    iget-object v0, v3, Lgb/e;->e:Landroid/widget/LinearLayout;

    .line 1111
    .line 1112
    goto :goto_2a

    .line 1113
    :cond_4c
    const/4 v0, 0x0

    .line 1114
    :goto_2a
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->cardBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1115
    .line 1116
    invoke-static {v0, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1117
    .line 1118
    .line 1119
    if-eqz v3, :cond_4d

    .line 1120
    .line 1121
    iget-object v0, v3, Lgb/e;->Y:Landroid/widget/TextView;

    .line 1122
    .line 1123
    goto :goto_2b

    .line 1124
    :cond_4d
    const/4 v0, 0x0

    .line 1125
    :goto_2b
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->brand:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1126
    .line 1127
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1128
    .line 1129
    .line 1130
    if-eqz v3, :cond_4e

    .line 1131
    .line 1132
    iget-object v0, v3, Lgb/e;->s0:Landroid/widget/TextView;

    .line 1133
    .line 1134
    goto :goto_2c

    .line 1135
    :cond_4e
    const/4 v0, 0x0

    .line 1136
    :goto_2c
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->mobilePriceLabel:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1137
    .line 1138
    if-nez v14, :cond_4f

    .line 1139
    .line 1140
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->deviceActiveTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1141
    .line 1142
    :cond_4f
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1143
    .line 1144
    .line 1145
    if-eqz v3, :cond_50

    .line 1146
    .line 1147
    iget-object v0, v3, Lgb/e;->p:Landroid/widget/ImageView;

    .line 1148
    .line 1149
    goto :goto_2d

    .line 1150
    :cond_50
    const/4 v0, 0x0

    .line 1151
    :goto_2d
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->deviceActiveIcon:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1152
    .line 1153
    invoke-static {v0, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1154
    .line 1155
    .line 1156
    if-eqz v3, :cond_51

    .line 1157
    .line 1158
    iget-object v0, v3, Lgb/e;->v:Landroid/widget/ImageView;

    .line 1159
    .line 1160
    goto :goto_2e

    .line 1161
    :cond_51
    const/4 v0, 0x0

    .line 1162
    :goto_2e
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->deviceActiveRefreshIcon:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1163
    .line 1164
    invoke-static {v0, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1165
    .line 1166
    .line 1167
    if-eqz v3, :cond_52

    .line 1168
    .line 1169
    iget-object v0, v3, Lgb/e;->k0:Landroid/widget/TextView;

    .line 1170
    .line 1171
    goto :goto_2f

    .line 1172
    :cond_52
    const/4 v0, 0x0

    .line 1173
    :goto_2f
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->currentOutstandingTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1174
    .line 1175
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1176
    .line 1177
    .line 1178
    if-eqz v3, :cond_53

    .line 1179
    .line 1180
    iget-object v0, v3, Lgb/e;->Z:Landroid/widget/TextView;

    .line 1181
    .line 1182
    goto :goto_30

    .line 1183
    :cond_53
    const/4 v0, 0x0

    .line 1184
    :goto_30
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->currentOutstandingAmount:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1185
    .line 1186
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1187
    .line 1188
    .line 1189
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getOverDueStatus()Ljava/lang/Integer;

    .line 1190
    .line 1191
    .line 1192
    move-result-object v0

    .line 1193
    if-nez v0, :cond_54

    .line 1194
    .line 1195
    goto :goto_31

    .line 1196
    :cond_54
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 1197
    .line 1198
    .line 1199
    move-result v0

    .line 1200
    if-ne v0, v11, :cond_55

    .line 1201
    .line 1202
    goto :goto_32

    .line 1203
    :cond_55
    :goto_31
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentStatus()Ljava/lang/Integer;

    .line 1204
    .line 1205
    .line 1206
    move-result-object v0

    .line 1207
    if-nez v0, :cond_56

    .line 1208
    .line 1209
    goto :goto_33

    .line 1210
    :cond_56
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 1211
    .line 1212
    .line 1213
    move-result v0

    .line 1214
    if-ne v0, v12, :cond_57

    .line 1215
    .line 1216
    :goto_32
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->phoneInstallmentTipsOverdue:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1217
    .line 1218
    if-nez v0, :cond_58

    .line 1219
    .line 1220
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->phoneInstallmentTips:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1221
    .line 1222
    goto :goto_34

    .line 1223
    :cond_57
    :goto_33
    iget-object v0, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->phoneInstallmentTips:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1224
    .line 1225
    :cond_58
    :goto_34
    if-eqz v3, :cond_59

    .line 1226
    .line 1227
    iget-object v14, v3, Lgb/e;->D0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 1228
    .line 1229
    goto :goto_35

    .line 1230
    :cond_59
    const/4 v14, 0x0

    .line 1231
    :goto_35
    invoke-static {v14, v0}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1232
    .line 1233
    .line 1234
    if-eqz v3, :cond_5a

    .line 1235
    .line 1236
    iget-object v0, v3, Lgb/e;->L:Landroid/widget/LinearLayout;

    .line 1237
    .line 1238
    goto :goto_36

    .line 1239
    :cond_5a
    const/4 v0, 0x0

    .line 1240
    :goto_36
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->phoneInstallmentExemptionBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1241
    .line 1242
    invoke-static {v0, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1243
    .line 1244
    .line 1245
    if-eqz v3, :cond_5b

    .line 1246
    .line 1247
    iget-object v0, v3, Lgb/e;->E0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 1248
    .line 1249
    goto :goto_37

    .line 1250
    :cond_5b
    const/4 v0, 0x0

    .line 1251
    :goto_37
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->phoneInstallmentExemptionTips:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1252
    .line 1253
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1254
    .line 1255
    .line 1256
    if-eqz v3, :cond_5c

    .line 1257
    .line 1258
    iget-object v0, v3, Lgb/e;->c:Landroid/widget/TextView;

    .line 1259
    .line 1260
    goto :goto_38

    .line 1261
    :cond_5c
    const/4 v0, 0x0

    .line 1262
    :goto_38
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->btnRepayPrimary:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1263
    .line 1264
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1265
    .line 1266
    .line 1267
    if-eqz v3, :cond_5d

    .line 1268
    .line 1269
    iget-object v0, v3, Lgb/e;->d:Landroid/widget/TextView;

    .line 1270
    .line 1271
    goto :goto_39

    .line 1272
    :cond_5d
    const/4 v0, 0x0

    .line 1273
    :goto_39
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->btnTemporaryUnlock:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1274
    .line 1275
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1276
    .line 1277
    .line 1278
    if-eqz v3, :cond_5e

    .line 1279
    .line 1280
    iget-object v0, v3, Lgb/e;->b:Landroid/widget/LinearLayout;

    .line 1281
    .line 1282
    goto :goto_3a

    .line 1283
    :cond_5e
    const/4 v0, 0x0

    .line 1284
    :goto_3a
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->expireTimeBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1285
    .line 1286
    invoke-static {v0, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1287
    .line 1288
    .line 1289
    if-eqz v3, :cond_5f

    .line 1290
    .line 1291
    iget-object v0, v3, Lgb/e;->x0:Landroid/widget/TextView;

    .line 1292
    .line 1293
    goto :goto_3b

    .line 1294
    :cond_5f
    const/4 v0, 0x0

    .line 1295
    :goto_3b
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->expireTimeTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1296
    .line 1297
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1298
    .line 1299
    .line 1300
    if-eqz v3, :cond_60

    .line 1301
    .line 1302
    iget-object v0, v3, Lgb/e;->y0:Landroid/widget/TextView;

    .line 1303
    .line 1304
    goto :goto_3c

    .line 1305
    :cond_60
    const/4 v0, 0x0

    .line 1306
    :goto_3c
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->expireTimeMinute:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1307
    .line 1308
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1309
    .line 1310
    .line 1311
    if-eqz v3, :cond_61

    .line 1312
    .line 1313
    iget-object v0, v3, Lgb/e;->z0:Landroid/widget/TextView;

    .line 1314
    .line 1315
    goto :goto_3d

    .line 1316
    :cond_61
    const/4 v0, 0x0

    .line 1317
    :goto_3d
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->expireTimeSecond:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1318
    .line 1319
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1320
    .line 1321
    .line 1322
    if-eqz v3, :cond_62

    .line 1323
    .line 1324
    iget-object v0, v3, Lgb/e;->w0:Landroid/widget/TextView;

    .line 1325
    .line 1326
    goto :goto_3e

    .line 1327
    :cond_62
    const/4 v0, 0x0

    .line 1328
    :goto_3e
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->expireTimeColon:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1329
    .line 1330
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1331
    .line 1332
    .line 1333
    if-eqz v3, :cond_63

    .line 1334
    .line 1335
    iget-object v0, v3, Lgb/e;->H0:Landroid/widget/TextView;

    .line 1336
    .line 1337
    goto :goto_3f

    .line 1338
    :cond_63
    const/4 v0, 0x0

    .line 1339
    :goto_3f
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->totalOutstandingTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1340
    .line 1341
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1342
    .line 1343
    .line 1344
    if-eqz v3, :cond_64

    .line 1345
    .line 1346
    iget-object v0, v3, Lgb/e;->B:Landroid/widget/LinearLayout;

    .line 1347
    .line 1348
    goto :goto_40

    .line 1349
    :cond_64
    const/4 v0, 0x0

    .line 1350
    :goto_40
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->dailyPaymentBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1351
    .line 1352
    invoke-static {v0, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1353
    .line 1354
    .line 1355
    if-eqz v3, :cond_65

    .line 1356
    .line 1357
    iget-object v0, v3, Lgb/e;->q0:Landroid/widget/TextView;

    .line 1358
    .line 1359
    goto :goto_41

    .line 1360
    :cond_65
    const/4 v0, 0x0

    .line 1361
    :goto_41
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->dailyPaymentTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1362
    .line 1363
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1364
    .line 1365
    .line 1366
    if-eqz v3, :cond_66

    .line 1367
    .line 1368
    iget-object v0, v3, Lgb/e;->p0:Landroid/widget/TextView;

    .line 1369
    .line 1370
    goto :goto_42

    .line 1371
    :cond_66
    const/4 v0, 0x0

    .line 1372
    :goto_42
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->dailyPaymentAmount:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1373
    .line 1374
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1375
    .line 1376
    .line 1377
    if-eqz v3, :cond_67

    .line 1378
    .line 1379
    iget-object v0, v3, Lgb/e;->Q:Landroid/widget/LinearLayout;

    .line 1380
    .line 1381
    goto :goto_43

    .line 1382
    :cond_67
    const/4 v0, 0x0

    .line 1383
    :goto_43
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->weeklyPaymentBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1384
    .line 1385
    invoke-static {v0, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1386
    .line 1387
    .line 1388
    if-eqz v3, :cond_68

    .line 1389
    .line 1390
    iget-object v0, v3, Lgb/e;->N0:Landroid/widget/TextView;

    .line 1391
    .line 1392
    goto :goto_44

    .line 1393
    :cond_68
    const/4 v0, 0x0

    .line 1394
    :goto_44
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->weeklyPaymentTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1395
    .line 1396
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1397
    .line 1398
    .line 1399
    if-eqz v3, :cond_69

    .line 1400
    .line 1401
    iget-object v0, v3, Lgb/e;->M0:Landroid/widget/TextView;

    .line 1402
    .line 1403
    goto :goto_45

    .line 1404
    :cond_69
    const/4 v0, 0x0

    .line 1405
    :goto_45
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->weeklyPaymentAmount:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1406
    .line 1407
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1408
    .line 1409
    .line 1410
    if-eqz v3, :cond_6a

    .line 1411
    .line 1412
    iget-object v0, v3, Lgb/e;->H:Landroid/widget/LinearLayout;

    .line 1413
    .line 1414
    goto :goto_46

    .line 1415
    :cond_6a
    const/4 v0, 0x0

    .line 1416
    :goto_46
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->monthlyPaymentBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1417
    .line 1418
    invoke-static {v0, v14}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1419
    .line 1420
    .line 1421
    if-eqz v3, :cond_6b

    .line 1422
    .line 1423
    iget-object v0, v3, Lgb/e;->C0:Landroid/widget/TextView;

    .line 1424
    .line 1425
    goto :goto_47

    .line 1426
    :cond_6b
    const/4 v0, 0x0

    .line 1427
    :goto_47
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->monthlyPaymentTitle:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1428
    .line 1429
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1430
    .line 1431
    .line 1432
    if-eqz v3, :cond_6c

    .line 1433
    .line 1434
    iget-object v0, v3, Lgb/e;->B0:Landroid/widget/TextView;

    .line 1435
    .line 1436
    goto :goto_48

    .line 1437
    :cond_6c
    const/4 v0, 0x0

    .line 1438
    :goto_48
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->monthlyPaymentAmount:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1439
    .line 1440
    invoke-static {v0, v14}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1441
    .line 1442
    .line 1443
    if-eqz v3, :cond_6d

    .line 1444
    .line 1445
    iget-object v0, v3, Lgb/e;->f:Landroid/widget/ImageView;

    .line 1446
    .line 1447
    goto :goto_49

    .line 1448
    :cond_6d
    const/4 v0, 0x0

    .line 1449
    :goto_49
    iget-object v14, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->cardBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1450
    .line 1451
    if-eqz v14, :cond_6e

    .line 1452
    .line 1453
    :try_start_0
    invoke-virtual {v14}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getBgColor()Ljava/lang/String;

    .line 1454
    .line 1455
    .line 1456
    move-result-object v15

    .line 1457
    goto :goto_4a

    .line 1458
    :catch_0
    move-exception v0

    .line 1459
    goto :goto_4b

    .line 1460
    :cond_6e
    const/4 v15, 0x0

    .line 1461
    :goto_4a
    invoke-static {v15}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1462
    .line 1463
    .line 1464
    move-result v15

    .line 1465
    if-nez v15, :cond_73

    .line 1466
    .line 1467
    if-eqz v14, :cond_6f

    .line 1468
    .line 1469
    invoke-virtual {v14}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getBgColor()Ljava/lang/String;

    .line 1470
    .line 1471
    .line 1472
    move-result-object v15

    .line 1473
    if-nez v15, :cond_70

    .line 1474
    .line 1475
    :cond_6f
    move-object v15, v5

    .line 1476
    :cond_70
    new-instance v10, Lkotlin/text/Regex;

    .line 1477
    .line 1478
    const-string v9, "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$"

    .line 1479
    .line 1480
    invoke-direct {v10, v9}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    .line 1481
    .line 1482
    .line 1483
    invoke-virtual {v10, v15}, Lkotlin/text/Regex;->b(Ljava/lang/CharSequence;)Z

    .line 1484
    .line 1485
    .line 1486
    move-result v9

    .line 1487
    if-eqz v9, :cond_73

    .line 1488
    .line 1489
    if-eqz v14, :cond_71

    .line 1490
    .line 1491
    invoke-virtual {v14}, Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;->getBgColor()Ljava/lang/String;

    .line 1492
    .line 1493
    .line 1494
    move-result-object v9

    .line 1495
    if-nez v9, :cond_72

    .line 1496
    .line 1497
    :cond_71
    move-object v9, v5

    .line 1498
    :cond_72
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 1499
    .line 1500
    .line 1501
    move-result v9

    .line 1502
    if-eqz v0, :cond_73

    .line 1503
    .line 1504
    sget-object v10, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 1505
    .line 1506
    invoke-virtual {v0, v9, v10}, Landroid/widget/ImageView;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 1507
    .line 1508
    .line 1509
    goto :goto_4c

    .line 1510
    :goto_4b
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 1511
    .line 1512
    .line 1513
    :cond_73
    :goto_4c
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLocked()Ljava/lang/Boolean;

    .line 1514
    .line 1515
    .line 1516
    move-result-object v0

    .line 1517
    sget-object v9, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1518
    .line 1519
    invoke-static {v0, v9}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1520
    .line 1521
    .line 1522
    move-result v0

    .line 1523
    if-eqz v0, :cond_76

    .line 1524
    .line 1525
    if-eqz v3, :cond_74

    .line 1526
    .line 1527
    iget-object v0, v3, Lgb/e;->w:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 1528
    .line 1529
    goto :goto_4d

    .line 1530
    :cond_74
    const/4 v0, 0x0

    .line 1531
    :goto_4d
    iget-object v9, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->deviceInfoBgLock:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1532
    .line 1533
    invoke-static {v0, v9}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1534
    .line 1535
    .line 1536
    if-eqz v3, :cond_75

    .line 1537
    .line 1538
    iget-object v0, v3, Lgb/e;->r0:Landroid/widget/TextView;

    .line 1539
    .line 1540
    goto :goto_4e

    .line 1541
    :cond_75
    const/4 v0, 0x0

    .line 1542
    :goto_4e
    iget-object v9, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->deviceActiveTimeLock:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1543
    .line 1544
    invoke-static {v0, v9}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1545
    .line 1546
    .line 1547
    goto :goto_51

    .line 1548
    :cond_76
    if-eqz v3, :cond_77

    .line 1549
    .line 1550
    iget-object v0, v3, Lgb/e;->w:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 1551
    .line 1552
    goto :goto_4f

    .line 1553
    :cond_77
    const/4 v0, 0x0

    .line 1554
    :goto_4f
    iget-object v9, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->deviceInfoBg:Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;

    .line 1555
    .line 1556
    invoke-static {v0, v9}, LFb/j;->a(Landroid/view/View;Lcom/transsnet/palmpay/core/bean/style_config/BaseStyleConfig;)V

    .line 1557
    .line 1558
    .line 1559
    if-eqz v3, :cond_78

    .line 1560
    .line 1561
    iget-object v0, v3, Lgb/e;->r0:Landroid/widget/TextView;

    .line 1562
    .line 1563
    goto :goto_50

    .line 1564
    :cond_78
    const/4 v0, 0x0

    .line 1565
    :goto_50
    iget-object v9, v13, Lcom/transsnet/palmpay/credit/bean/style/MobileInstallmentStyleConfig;->deviceActiveTime:Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;

    .line 1566
    .line 1567
    invoke-static {v0, v9}, LFb/j;->c(Landroid/widget/TextView;Lcom/transsnet/palmpay/core/bean/style_config/TextStyleConfig;)V

    .line 1568
    .line 1569
    .line 1570
    :cond_79
    :goto_51
    if-eqz v3, :cond_7a

    .line 1571
    .line 1572
    iget-object v0, v3, Lgb/e;->g:Landroid/widget/ImageView;

    .line 1573
    .line 1574
    goto :goto_52

    .line 1575
    :cond_7a
    const/4 v0, 0x0

    .line 1576
    :goto_52
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getTitleBrandIocUrl()Ljava/lang/String;

    .line 1577
    .line 1578
    .line 1579
    move-result-object v9

    .line 1580
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getTitleBrandIocUrlDark()Ljava/lang/String;

    .line 1581
    .line 1582
    .line 1583
    move-result-object v10

    .line 1584
    invoke-static {v0, v9, v10}, LPa/r0;->k1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 1585
    .line 1586
    .line 1587
    if-eqz v3, :cond_7b

    .line 1588
    .line 1589
    iget-object v0, v3, Lgb/e;->i:Landroid/widget/ImageView;

    .line 1590
    .line 1591
    goto :goto_53

    .line 1592
    :cond_7b
    const/4 v0, 0x0

    .line 1593
    :goto_53
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getImageLockNew()Ljava/lang/String;

    .line 1594
    .line 1595
    .line 1596
    move-result-object v9

    .line 1597
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getImageLockDarkNew()Ljava/lang/String;

    .line 1598
    .line 1599
    .line 1600
    move-result-object v10

    .line 1601
    invoke-static {v0, v9, v10}, LPa/r0;->k1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 1602
    .line 1603
    .line 1604
    if-eqz v3, :cond_7c

    .line 1605
    .line 1606
    iget-object v0, v3, Lgb/e;->j:Landroid/widget/ImageView;

    .line 1607
    .line 1608
    goto :goto_54

    .line 1609
    :cond_7c
    const/4 v0, 0x0

    .line 1610
    :goto_54
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getImageLockNew()Ljava/lang/String;

    .line 1611
    .line 1612
    .line 1613
    move-result-object v9

    .line 1614
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getImageLockDarkNew()Ljava/lang/String;

    .line 1615
    .line 1616
    .line 1617
    move-result-object v10

    .line 1618
    invoke-static {v0, v9, v10}, LPa/r0;->k1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 1619
    .line 1620
    .line 1621
    if-eqz v3, :cond_7d

    .line 1622
    .line 1623
    iget-object v0, v3, Lgb/e;->p:Landroid/widget/ImageView;

    .line 1624
    .line 1625
    goto :goto_55

    .line 1626
    :cond_7d
    const/4 v0, 0x0

    .line 1627
    :goto_55
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getImageLock()Ljava/lang/String;

    .line 1628
    .line 1629
    .line 1630
    move-result-object v9

    .line 1631
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getImageLockDark()Ljava/lang/String;

    .line 1632
    .line 1633
    .line 1634
    move-result-object v10

    .line 1635
    invoke-static {v0, v9, v10}, LPa/r0;->k1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 1636
    .line 1637
    .line 1638
    if-eqz v3, :cond_7e

    .line 1639
    .line 1640
    iget-object v0, v3, Lgb/e;->v:Landroid/widget/ImageView;

    .line 1641
    .line 1642
    goto :goto_56

    .line 1643
    :cond_7e
    const/4 v0, 0x0

    .line 1644
    :goto_56
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getImageRefresh()Ljava/lang/String;

    .line 1645
    .line 1646
    .line 1647
    move-result-object v9

    .line 1648
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getImageRefreshDark()Ljava/lang/String;

    .line 1649
    .line 1650
    .line 1651
    move-result-object v10

    .line 1652
    invoke-static {v0, v9, v10}, LPa/r0;->k1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 1653
    .line 1654
    .line 1655
    if-eqz v3, :cond_7f

    .line 1656
    .line 1657
    iget-object v0, v3, Lgb/e;->Y:Landroid/widget/TextView;

    .line 1658
    .line 1659
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getBrand()Ljava/lang/String;

    .line 1660
    .line 1661
    .line 1662
    move-result-object v9

    .line 1663
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getType()Ljava/lang/String;

    .line 1664
    .line 1665
    .line 1666
    move-result-object v10

    .line 1667
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getStorage()Ljava/lang/String;

    .line 1668
    .line 1669
    .line 1670
    move-result-object v13

    .line 1671
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getMemory()Ljava/lang/String;

    .line 1672
    .line 1673
    .line 1674
    move-result-object v14

    .line 1675
    new-instance v15, Ljava/lang/StringBuilder;

    .line 1676
    .line 1677
    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    .line 1678
    .line 1679
    .line 1680
    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1681
    .line 1682
    .line 1683
    invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1684
    .line 1685
    .line 1686
    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1687
    .line 1688
    .line 1689
    invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1690
    .line 1691
    .line 1692
    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1693
    .line 1694
    .line 1695
    invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1696
    .line 1697
    .line 1698
    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1699
    .line 1700
    .line 1701
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1702
    .line 1703
    .line 1704
    move-result-object v6

    .line 1705
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1706
    .line 1707
    .line 1708
    :cond_7f
    if-eqz v3, :cond_80

    .line 1709
    .line 1710
    iget-object v0, v3, Lgb/e;->s0:Landroid/widget/TextView;

    .line 1711
    .line 1712
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getDeviceActiveTitle()Ljava/lang/String;

    .line 1713
    .line 1714
    .line 1715
    move-result-object v6

    .line 1716
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1717
    .line 1718
    .line 1719
    :cond_80
    if-eqz v3, :cond_81

    .line 1720
    .line 1721
    iget-object v0, v3, Lgb/e;->r0:Landroid/widget/TextView;

    .line 1722
    .line 1723
    sget-object v6, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->f:Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView$a;

    .line 1724
    .line 1725
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getDeviceActiveTime()Ljava/lang/Long;

    .line 1726
    .line 1727
    .line 1728
    move-result-object v7

    .line 1729
    invoke-virtual {v6, v7}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView$a;->resolveDeviceActiveTimeMs(Ljava/lang/Long;)J

    .line 1730
    .line 1731
    .line 1732
    move-result-wide v6

    .line 1733
    new-instance v8, Ljava/text/SimpleDateFormat;

    .line 1734
    .line 1735
    const-string v9, "MMM/dd/yyyy HH:mm"

    .line 1736
    .line 1737
    sget-object v10, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 1738
    .line 1739
    invoke-direct {v8, v9, v10}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 1740
    .line 1741
    .line 1742
    invoke-static {v6, v7, v8}, Lcom/transsnet/palmpay/util/TimeUtils;->millis2String(JLjava/text/DateFormat;)Ljava/lang/String;

    .line 1743
    .line 1744
    .line 1745
    move-result-object v6

    .line 1746
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1747
    .line 1748
    .line 1749
    :cond_81
    if-eqz v3, :cond_89

    .line 1750
    .line 1751
    iget-object v0, v3, Lgb/e;->A:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 1752
    .line 1753
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getOverDueStatus()Ljava/lang/Integer;

    .line 1754
    .line 1755
    .line 1756
    move-result-object v6

    .line 1757
    if-nez v6, :cond_82

    .line 1758
    .line 1759
    goto :goto_58

    .line 1760
    :cond_82
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 1761
    .line 1762
    .line 1763
    move-result v6

    .line 1764
    if-ne v6, v11, :cond_84

    .line 1765
    .line 1766
    :cond_83
    :goto_57
    const/4 v6, 0x0

    .line 1767
    goto :goto_5c

    .line 1768
    :cond_84
    :goto_58
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentStatus()Ljava/lang/Integer;

    .line 1769
    .line 1770
    .line 1771
    move-result-object v6

    .line 1772
    if-nez v6, :cond_85

    .line 1773
    .line 1774
    goto :goto_59

    .line 1775
    :cond_85
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 1776
    .line 1777
    .line 1778
    move-result v7

    .line 1779
    if-eq v7, v12, :cond_83

    .line 1780
    .line 1781
    :goto_59
    if-nez v6, :cond_86

    .line 1782
    .line 1783
    goto :goto_5a

    .line 1784
    :cond_86
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 1785
    .line 1786
    .line 1787
    move-result v7

    .line 1788
    const/4 v8, 0x3

    .line 1789
    if-eq v7, v8, :cond_83

    .line 1790
    .line 1791
    :goto_5a
    if-nez v6, :cond_87

    .line 1792
    .line 1793
    goto :goto_5b

    .line 1794
    :cond_87
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 1795
    .line 1796
    .line 1797
    move-result v6

    .line 1798
    const/4 v7, 0x4

    .line 1799
    if-ne v6, v7, :cond_88

    .line 1800
    .line 1801
    goto :goto_57

    .line 1802
    :cond_88
    :goto_5b
    move v6, v11

    .line 1803
    :goto_5c
    invoke-static {v0, v6}, Loa/h;->s(Landroid/view/View;Z)V

    .line 1804
    .line 1805
    .line 1806
    :cond_89
    if-eqz v3, :cond_8a

    .line 1807
    .line 1808
    iget-object v0, v3, Lgb/e;->k0:Landroid/widget/TextView;

    .line 1809
    .line 1810
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getUnpaidAmountTitle()Ljava/lang/String;

    .line 1811
    .line 1812
    .line 1813
    move-result-object v6

    .line 1814
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1815
    .line 1816
    .line 1817
    :cond_8a
    if-eqz v3, :cond_8c

    .line 1818
    .line 1819
    iget-object v0, v3, Lgb/e;->Z:Landroid/widget/TextView;

    .line 1820
    .line 1821
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getUnpaidAmount()Ljava/lang/Long;

    .line 1822
    .line 1823
    .line 1824
    move-result-object v6

    .line 1825
    if-eqz v6, :cond_8b

    .line 1826
    .line 1827
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 1828
    .line 1829
    .line 1830
    move-result-wide v6

    .line 1831
    :goto_5d
    const/4 v8, 0x0

    .line 1832
    goto :goto_5e

    .line 1833
    :cond_8b
    const-wide/16 v6, 0x0

    .line 1834
    .line 1835
    goto :goto_5d

    .line 1836
    :goto_5e
    invoke-static {v6, v7, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 1837
    .line 1838
    .line 1839
    move-result-object v6

    .line 1840
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1841
    .line 1842
    .line 1843
    :cond_8c
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getExemptionBadgeVisible()Ljava/lang/Boolean;

    .line 1844
    .line 1845
    .line 1846
    move-result-object v0

    .line 1847
    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1848
    .line 1849
    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1850
    .line 1851
    .line 1852
    move-result v0

    .line 1853
    if-eqz v3, :cond_8d

    .line 1854
    .line 1855
    iget-object v7, v3, Lgb/e;->o:Landroid/widget/ImageView;

    .line 1856
    .line 1857
    invoke-static {v7, v0}, Loa/h;->s(Landroid/view/View;Z)V

    .line 1858
    .line 1859
    .line 1860
    :cond_8d
    if-eqz v3, :cond_8e

    .line 1861
    .line 1862
    iget-object v7, v3, Lgb/e;->L:Landroid/widget/LinearLayout;

    .line 1863
    .line 1864
    invoke-static {v7, v0}, Loa/h;->s(Landroid/view/View;Z)V

    .line 1865
    .line 1866
    .line 1867
    :cond_8e
    if-eqz v3, :cond_8f

    .line 1868
    .line 1869
    iget-object v7, v3, Lgb/e;->D0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 1870
    .line 1871
    const/4 v8, 0x0

    .line 1872
    invoke-static {v7, v8}, Loa/h;->s(Landroid/view/View;Z)V

    .line 1873
    .line 1874
    .line 1875
    goto :goto_5f

    .line 1876
    :cond_8f
    const/4 v8, 0x0

    .line 1877
    :goto_5f
    if-eqz v3, :cond_90

    .line 1878
    .line 1879
    iget-object v7, v3, Lgb/e;->X:Landroid/widget/RelativeLayout;

    .line 1880
    .line 1881
    invoke-static {v7, v8}, Loa/h;->s(Landroid/view/View;Z)V

    .line 1882
    .line 1883
    .line 1884
    :cond_90
    if-nez v0, :cond_9a

    .line 1885
    .line 1886
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getOverDueStatus()Ljava/lang/Integer;

    .line 1887
    .line 1888
    .line 1889
    move-result-object v0

    .line 1890
    if-nez v0, :cond_91

    .line 1891
    .line 1892
    goto :goto_61

    .line 1893
    :cond_91
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 1894
    .line 1895
    .line 1896
    move-result v0

    .line 1897
    if-ne v0, v11, :cond_98

    .line 1898
    .line 1899
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentReminderContent()Ljava/lang/String;

    .line 1900
    .line 1901
    .line 1902
    move-result-object v0

    .line 1903
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1904
    .line 1905
    .line 1906
    move-result v0

    .line 1907
    if-nez v0, :cond_97

    .line 1908
    .line 1909
    if-eqz v3, :cond_92

    .line 1910
    .line 1911
    iget-object v0, v3, Lgb/e;->X:Landroid/widget/RelativeLayout;

    .line 1912
    .line 1913
    invoke-static {v0}, Loa/h;->C(Landroid/view/View;)V

    .line 1914
    .line 1915
    .line 1916
    :cond_92
    if-eqz v3, :cond_93

    .line 1917
    .line 1918
    iget-object v0, v3, Lgb/e;->F0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 1919
    .line 1920
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentReminderContent()Ljava/lang/String;

    .line 1921
    .line 1922
    .line 1923
    move-result-object v5

    .line 1924
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1925
    .line 1926
    .line 1927
    :cond_93
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLocked()Ljava/lang/Boolean;

    .line 1928
    .line 1929
    .line 1930
    move-result-object v0

    .line 1931
    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1932
    .line 1933
    .line 1934
    move-result v0

    .line 1935
    if-eqz v0, :cond_96

    .line 1936
    .line 1937
    if-eqz v3, :cond_94

    .line 1938
    .line 1939
    iget-object v0, v3, Lgb/e;->t:Landroid/widget/ImageView;

    .line 1940
    .line 1941
    invoke-static {v0}, Loa/h;->C(Landroid/view/View;)V

    .line 1942
    .line 1943
    .line 1944
    :cond_94
    if-eqz v3, :cond_95

    .line 1945
    .line 1946
    iget-object v12, v3, Lgb/e;->t:Landroid/widget/ImageView;

    .line 1947
    .line 1948
    goto :goto_60

    .line 1949
    :cond_95
    const/4 v12, 0x0

    .line 1950
    :goto_60
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentReminderBackground()Ljava/lang/String;

    .line 1951
    .line 1952
    .line 1953
    move-result-object v0

    .line 1954
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentReminderBackground()Ljava/lang/String;

    .line 1955
    .line 1956
    .line 1957
    move-result-object v5

    .line 1958
    invoke-static {v12, v0, v5}, LPa/r0;->k1(Landroid/widget/ImageView;Ljava/lang/String;Ljava/lang/String;)V

    .line 1959
    .line 1960
    .line 1961
    goto :goto_66

    .line 1962
    :cond_96
    if-eqz v3, :cond_a1

    .line 1963
    .line 1964
    iget-object v0, v3, Lgb/e;->t:Landroid/widget/ImageView;

    .line 1965
    .line 1966
    invoke-static {v0}, Loa/h;->d(Landroid/view/View;)V

    .line 1967
    .line 1968
    .line 1969
    goto :goto_66

    .line 1970
    :cond_97
    if-eqz v3, :cond_a1

    .line 1971
    .line 1972
    iget-object v0, v3, Lgb/e;->X:Landroid/widget/RelativeLayout;

    .line 1973
    .line 1974
    invoke-static {v0}, Loa/h;->c(Landroid/view/View;)V

    .line 1975
    .line 1976
    .line 1977
    goto :goto_66

    .line 1978
    :cond_98
    :goto_61
    if-eqz v3, :cond_99

    .line 1979
    .line 1980
    iget-object v0, v3, Lgb/e;->D0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 1981
    .line 1982
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentReminderContent()Ljava/lang/String;

    .line 1983
    .line 1984
    .line 1985
    move-result-object v5

    .line 1986
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1987
    .line 1988
    .line 1989
    move-result v5

    .line 1990
    xor-int/2addr v5, v11

    .line 1991
    invoke-static {v0, v5}, Loa/h;->s(Landroid/view/View;Z)V

    .line 1992
    .line 1993
    .line 1994
    :cond_99
    if-eqz v3, :cond_a1

    .line 1995
    .line 1996
    iget-object v0, v3, Lgb/e;->D0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 1997
    .line 1998
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentReminderContent()Ljava/lang/String;

    .line 1999
    .line 2000
    .line 2001
    move-result-object v5

    .line 2002
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2003
    .line 2004
    .line 2005
    goto :goto_66

    .line 2006
    :cond_9a
    if-eqz v3, :cond_9c

    .line 2007
    .line 2008
    iget-object v0, v3, Lgb/e;->E0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 2009
    .line 2010
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getRepaymentReminderContent()Ljava/lang/String;

    .line 2011
    .line 2012
    .line 2013
    move-result-object v6

    .line 2014
    if-nez v6, :cond_9b

    .line 2015
    .line 2016
    goto :goto_62

    .line 2017
    :cond_9b
    move-object v5, v6

    .line 2018
    :goto_62
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2019
    .line 2020
    .line 2021
    :cond_9c
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getExemptionBadgeAssetUrl()Ljava/lang/String;

    .line 2022
    .line 2023
    .line 2024
    move-result-object v0

    .line 2025
    if-eqz v0, :cond_9f

    .line 2026
    .line 2027
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 2028
    .line 2029
    .line 2030
    move-result v5

    .line 2031
    if-nez v5, :cond_9d

    .line 2032
    .line 2033
    goto :goto_64

    .line 2034
    :cond_9d
    if-eqz v3, :cond_9e

    .line 2035
    .line 2036
    iget-object v12, v3, Lgb/e;->o:Landroid/widget/ImageView;

    .line 2037
    .line 2038
    goto :goto_63

    .line 2039
    :cond_9e
    const/4 v12, 0x0

    .line 2040
    :goto_63
    invoke-static {v0, v12}, LPa/r0;->l1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 2041
    .line 2042
    .line 2043
    goto :goto_65

    .line 2044
    :cond_9f
    :goto_64
    if-eqz v3, :cond_a0

    .line 2045
    .line 2046
    iget-object v0, v3, Lgb/e;->o:Landroid/widget/ImageView;

    .line 2047
    .line 2048
    sget v5, LYa/d;->icon_phone_exemption_badge:I

    .line 2049
    .line 2050
    invoke-virtual {v0, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 2051
    .line 2052
    .line 2053
    :cond_a0
    :goto_65
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getExemptionExpireTime()Ljava/lang/Long;

    .line 2054
    .line 2055
    .line 2056
    move-result-object v0

    .line 2057
    invoke-virtual {v4, v0}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->d(Ljava/lang/Long;)V

    .line 2058
    .line 2059
    .line 2060
    :cond_a1
    :goto_66
    if-eqz v3, :cond_a2

    .line 2061
    .line 2062
    iget-object v0, v3, Lgb/e;->c:Landroid/widget/TextView;

    .line 2063
    .line 2064
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getBtnRepayContent()Ljava/lang/String;

    .line 2065
    .line 2066
    .line 2067
    move-result-object v5

    .line 2068
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2069
    .line 2070
    .line 2071
    :cond_a2
    if-eqz v3, :cond_a3

    .line 2072
    .line 2073
    iget-object v0, v3, Lgb/e;->d:Landroid/widget/TextView;

    .line 2074
    .line 2075
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getBtnTemporaryUnlockContent()Ljava/lang/String;

    .line 2076
    .line 2077
    .line 2078
    move-result-object v5

    .line 2079
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2080
    .line 2081
    .line 2082
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getBtnTemporaryUnlockContent()Ljava/lang/String;

    .line 2083
    .line 2084
    .line 2085
    move-result-object v5

    .line 2086
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2087
    .line 2088
    .line 2089
    move-result v5

    .line 2090
    xor-int/2addr v5, v11

    .line 2091
    invoke-static {v0, v5}, Loa/h;->s(Landroid/view/View;Z)V

    .line 2092
    .line 2093
    .line 2094
    :cond_a3
    if-eqz v3, :cond_a4

    .line 2095
    .line 2096
    iget-object v0, v3, Lgb/e;->x0:Landroid/widget/TextView;

    .line 2097
    .line 2098
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getBtnExpireIn()Ljava/lang/String;

    .line 2099
    .line 2100
    .line 2101
    move-result-object v5

    .line 2102
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2103
    .line 2104
    .line 2105
    :cond_a4
    if-eqz v3, :cond_a5

    .line 2106
    .line 2107
    iget-object v0, v3, Lgb/e;->b:Landroid/widget/LinearLayout;

    .line 2108
    .line 2109
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getBtnExpireIn()Ljava/lang/String;

    .line 2110
    .line 2111
    .line 2112
    move-result-object v5

    .line 2113
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 2114
    .line 2115
    .line 2116
    move-result v5

    .line 2117
    xor-int/2addr v5, v11

    .line 2118
    invoke-static {v0, v5}, Loa/h;->s(Landroid/view/View;Z)V

    .line 2119
    .line 2120
    .line 2121
    :cond_a5
    if-eqz v3, :cond_a6

    .line 2122
    .line 2123
    iget-object v0, v3, Lgb/e;->H0:Landroid/widget/TextView;

    .line 2124
    .line 2125
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getTotalOutstandingAmountTitle()Ljava/lang/String;

    .line 2126
    .line 2127
    .line 2128
    move-result-object v5

    .line 2129
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2130
    .line 2131
    .line 2132
    :cond_a6
    if-eqz v3, :cond_a8

    .line 2133
    .line 2134
    iget-object v0, v3, Lgb/e;->G0:Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 2135
    .line 2136
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getTotalOutstandingAmount()Ljava/lang/Long;

    .line 2137
    .line 2138
    .line 2139
    move-result-object v5

    .line 2140
    if-eqz v5, :cond_a7

    .line 2141
    .line 2142
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 2143
    .line 2144
    .line 2145
    move-result-wide v5

    .line 2146
    :goto_67
    const/4 v8, 0x0

    .line 2147
    goto :goto_68

    .line 2148
    :cond_a7
    const-wide/16 v5, 0x0

    .line 2149
    .line 2150
    goto :goto_67

    .line 2151
    :goto_68
    invoke-static {v5, v6, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 2152
    .line 2153
    .line 2154
    move-result-object v5

    .line 2155
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2156
    .line 2157
    .line 2158
    :cond_a8
    if-eqz v3, :cond_a9

    .line 2159
    .line 2160
    iget-object v0, v3, Lgb/e;->q0:Landroid/widget/TextView;

    .line 2161
    .line 2162
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getDailyPaymentAmountTitle()Ljava/lang/String;

    .line 2163
    .line 2164
    .line 2165
    move-result-object v5

    .line 2166
    sget v6, LYa/g;->cs_mi_repayment_cycle_daily_label:I

    .line 2167
    .line 2168
    invoke-virtual {v4, v6, v5}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->a(ILjava/lang/String;)Ljava/lang/String;

    .line 2169
    .line 2170
    .line 2171
    move-result-object v5

    .line 2172
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2173
    .line 2174
    .line 2175
    :cond_a9
    if-eqz v3, :cond_ab

    .line 2176
    .line 2177
    iget-object v0, v3, Lgb/e;->p0:Landroid/widget/TextView;

    .line 2178
    .line 2179
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getDailyPaymentAmount()Ljava/lang/Long;

    .line 2180
    .line 2181
    .line 2182
    move-result-object v5

    .line 2183
    if-eqz v5, :cond_aa

    .line 2184
    .line 2185
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 2186
    .line 2187
    .line 2188
    move-result-wide v5

    .line 2189
    :goto_69
    const/4 v8, 0x0

    .line 2190
    goto :goto_6a

    .line 2191
    :cond_aa
    const-wide/16 v5, 0x0

    .line 2192
    .line 2193
    goto :goto_69

    .line 2194
    :goto_6a
    invoke-static {v5, v6, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 2195
    .line 2196
    .line 2197
    move-result-object v5

    .line 2198
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2199
    .line 2200
    .line 2201
    :cond_ab
    if-eqz v3, :cond_ac

    .line 2202
    .line 2203
    iget-object v0, v3, Lgb/e;->N0:Landroid/widget/TextView;

    .line 2204
    .line 2205
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getWeeklyPaymentAmountTitle()Ljava/lang/String;

    .line 2206
    .line 2207
    .line 2208
    move-result-object v5

    .line 2209
    sget v6, LYa/g;->cs_mi_repayment_cycle_weekly_label:I

    .line 2210
    .line 2211
    invoke-virtual {v4, v6, v5}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->a(ILjava/lang/String;)Ljava/lang/String;

    .line 2212
    .line 2213
    .line 2214
    move-result-object v5

    .line 2215
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2216
    .line 2217
    .line 2218
    :cond_ac
    if-eqz v3, :cond_ae

    .line 2219
    .line 2220
    iget-object v0, v3, Lgb/e;->M0:Landroid/widget/TextView;

    .line 2221
    .line 2222
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getWeeklyPaymentAmount()Ljava/lang/Long;

    .line 2223
    .line 2224
    .line 2225
    move-result-object v5

    .line 2226
    if-eqz v5, :cond_ad

    .line 2227
    .line 2228
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 2229
    .line 2230
    .line 2231
    move-result-wide v5

    .line 2232
    :goto_6b
    const/4 v8, 0x0

    .line 2233
    goto :goto_6c

    .line 2234
    :cond_ad
    const-wide/16 v5, 0x0

    .line 2235
    .line 2236
    goto :goto_6b

    .line 2237
    :goto_6c
    invoke-static {v5, v6, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 2238
    .line 2239
    .line 2240
    move-result-object v5

    .line 2241
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2242
    .line 2243
    .line 2244
    :cond_ae
    if-eqz v3, :cond_af

    .line 2245
    .line 2246
    iget-object v0, v3, Lgb/e;->C0:Landroid/widget/TextView;

    .line 2247
    .line 2248
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getMonthlyPaymentAmountTitle()Ljava/lang/String;

    .line 2249
    .line 2250
    .line 2251
    move-result-object v5

    .line 2252
    sget v6, LYa/g;->cs_mi_repayment_cycle_monthly_label:I

    .line 2253
    .line 2254
    invoke-virtual {v4, v6, v5}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->a(ILjava/lang/String;)Ljava/lang/String;

    .line 2255
    .line 2256
    .line 2257
    move-result-object v5

    .line 2258
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2259
    .line 2260
    .line 2261
    :cond_af
    if-eqz v3, :cond_b1

    .line 2262
    .line 2263
    iget-object v0, v3, Lgb/e;->B0:Landroid/widget/TextView;

    .line 2264
    .line 2265
    invoke-virtual {v2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getMonthlyPaymentAmount()Ljava/lang/Long;

    .line 2266
    .line 2267
    .line 2268
    move-result-object v3

    .line 2269
    if-eqz v3, :cond_b0

    .line 2270
    .line 2271
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 2272
    .line 2273
    .line 2274
    move-result-wide v5

    .line 2275
    :goto_6d
    const/4 v8, 0x0

    .line 2276
    goto :goto_6e

    .line 2277
    :cond_b0
    const-wide/16 v5, 0x0

    .line 2278
    .line 2279
    goto :goto_6d

    .line 2280
    :goto_6e
    invoke-static {v5, v6, v8}, LPa/r0;->B(JZ)Ljava/lang/String;

    .line 2281
    .line 2282
    .line 2283
    move-result-object v3

    .line 2284
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2285
    .line 2286
    .line 2287
    :cond_b1
    invoke-virtual {v4, v2}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->c(Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;)V

    .line 2288
    .line 2289
    .line 2290
    :cond_b2
    :goto_6f
    return-void
.end method

.method public final bridge synthetic convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;

    invoke-virtual {p0, p1, p2}, Lwb/e;->b(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;)V

    return-void
.end method

.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;Ljava/util/List;)V
    .locals 6

    .line 2
    check-cast p2, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;

    .line 3
    const-string v0, "holder"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "item"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "payloads"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    move-object v0, p3

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    const-string v2, "D"

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v1, :cond_3

    .line 5
    invoke-interface {p3, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const-string v5, "EXEMPTION_COUNTDOWN_UPDATE"

    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    .line 6
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getItemViewType()I

    move-result p3

    if-nez p3, :cond_6

    .line 7
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getMobileInstallmentCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;

    move-result-object p3

    if-eqz p3, :cond_0

    .line 8
    invoke-virtual {p3}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLoanTermSpanUnit()Ljava/lang/String;

    move-result-object p3

    goto :goto_0

    :cond_0
    move-object p3, v4

    :goto_0
    if-eqz p3, :cond_1

    .line 9
    invoke-static {p3}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    goto :goto_1

    :cond_1
    move-object p3, v4

    .line 10
    :goto_1
    invoke-virtual {v2, p3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p3

    if-nez p3, :cond_6

    .line 11
    sget p3, LYa/e;->phoneInstallmentLoanView:I

    invoke-virtual {p1, p3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;

    if-eqz p1, :cond_6

    .line 12
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getMobileInstallmentCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;

    move-result-object p2

    if-eqz p2, :cond_2

    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getExemptionExpireTime()Ljava/lang/Long;

    move-result-object v4

    .line 13
    :cond_2
    invoke-virtual {p1, v4}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->d(Ljava/lang/Long;)V

    return-void

    .line 14
    :cond_3
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_7

    invoke-interface {p3, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    const-string v0, "COUNTDOWN_UPDATE"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_7

    .line 15
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getItemViewType()I

    move-result p3

    if-nez p3, :cond_6

    .line 16
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getMobileInstallmentCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;

    move-result-object p3

    if-eqz p3, :cond_4

    .line 17
    invoke-virtual {p3}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLoanTermSpanUnit()Ljava/lang/String;

    move-result-object p3

    goto :goto_2

    :cond_4
    move-object p3, v4

    :goto_2
    if-eqz p3, :cond_5

    .line 18
    invoke-static {p3}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    .line 19
    :cond_5
    invoke-virtual {v2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p3

    if-nez p3, :cond_6

    .line 20
    sget p3, LYa/e;->phoneInstallmentLoanView:I

    invoke-virtual {p1, p3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;

    if-eqz p1, :cond_6

    .line 21
    invoke-virtual {p2}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getMobileInstallmentCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/credit/view/PhoneInstallmentLoanView;->c(Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;)V

    :cond_6
    return-void

    .line 22
    :cond_7
    invoke-virtual {p0, p1, p2}, Lwb/e;->b(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;)V

    return-void
.end method
