.class public final Lag/n;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e:Lag/l;

.field public static final synthetic f:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field public static final synthetic g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

.field public static final h:LPa/a0;


# instance fields
.field private volatile synthetic _next$volatile:Ljava/lang/Object;

.field private volatile synthetic _state$volatile:J

.field public final a:I

.field public final b:Z

.field public final c:I

.field public final synthetic d:Ljava/util/concurrent/atomic/AtomicReferenceArray;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lag/l;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lag/l;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lag/n;->e:Lag/l;

    .line 8
    .line 9
    const-class v0, Lag/n;

    .line 10
    .line 11
    const-class v1, Ljava/lang/Object;

    .line 12
    .line 13
    const-string v2, "_next$volatile"

    .line 14
    .line 15
    invoke-static {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    sput-object v1, Lag/n;->f:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 20
    .line 21
    const-string v1, "_state$volatile"

    .line 22
    .line 23
    invoke-static {v0, v1}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sput-object v0, Lag/n;->g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 28
    .line 29
    new-instance v0, LPa/a0;

    .line 30
    .line 31
    const-string v1, "REMOVE_FROZEN"

    .line 32
    .line 33
    const/4 v2, 0x1

    .line 34
    invoke-direct {v0, v1, v2}, LPa/a0;-><init>(Ljava/lang/String;I)V

    .line 35
    .line 36
    .line 37
    sput-object v0, Lag/n;->h:LPa/a0;

    .line 38
    .line 39
    return-void
.end method

.method public constructor <init>(IZ)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lag/n;->a:I

    .line 5
    .line 6
    iput-boolean p2, p0, Lag/n;->b:Z

    .line 7
    .line 8
    add-int/lit8 p2, p1, -0x1

    .line 9
    .line 10
    iput p2, p0, Lag/n;->c:I

    .line 11
    .line 12
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 13
    .line 14
    invoke-direct {v0, p1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lag/n;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 18
    .line 19
    const v0, 0x3fffffff    # 1.9999999f

    .line 20
    .line 21
    .line 22
    const-string v1, "Check failed."

    .line 23
    .line 24
    if-gt p2, v0, :cond_1

    .line 25
    .line 26
    and-int/2addr p1, p2

    .line 27
    if-nez p1, :cond_0

    .line 28
    .line 29
    return-void

    .line 30
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 31
    .line 32
    invoke-direct {p1, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw p1

    .line 36
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 37
    .line 38
    invoke-direct {p1, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw p1
.end method


# virtual methods
.method public final a(Ljava/lang/Runnable;)I
    .locals 12

    .line 1
    :cond_0
    sget-object v0, Lag/n;->g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    .line 4
    .line 5
    .line 6
    move-result-wide v2

    .line 7
    const-wide/high16 v4, 0x3000000000000000L    # 1.727233711018889E-77

    .line 8
    .line 9
    and-long/2addr v4, v2

    .line 10
    const-wide/16 v6, 0x0

    .line 11
    .line 12
    cmp-long v1, v4, v6

    .line 13
    .line 14
    sget-object v4, Lag/n;->e:Lag/l;

    .line 15
    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    invoke-virtual {v4, v2, v3}, Lag/l;->addFailReason(J)I

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    return p1

    .line 23
    :cond_1
    const-wide/32 v8, 0x3fffffff

    .line 24
    .line 25
    .line 26
    and-long/2addr v8, v2

    .line 27
    long-to-int v1, v8

    .line 28
    const-wide v8, 0xfffffffc0000000L

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    and-long/2addr v8, v2

    .line 34
    const/16 v5, 0x1e

    .line 35
    .line 36
    shr-long/2addr v8, v5

    .line 37
    long-to-int v8, v8

    .line 38
    add-int/lit8 v5, v8, 0x2

    .line 39
    .line 40
    iget v9, p0, Lag/n;->c:I

    .line 41
    .line 42
    and-int/2addr v5, v9

    .line 43
    and-int v10, v1, v9

    .line 44
    .line 45
    if-ne v5, v10, :cond_2

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_2
    iget-object v10, p0, Lag/n;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 49
    .line 50
    iget-boolean v5, p0, Lag/n;->b:Z

    .line 51
    .line 52
    const v11, 0x3fffffff    # 1.9999999f

    .line 53
    .line 54
    .line 55
    if-nez v5, :cond_4

    .line 56
    .line 57
    and-int v5, v8, v9

    .line 58
    .line 59
    invoke-virtual {v10, v5}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v5

    .line 63
    if-eqz v5, :cond_4

    .line 64
    .line 65
    const/16 v0, 0x400

    .line 66
    .line 67
    iget v2, p0, Lag/n;->a:I

    .line 68
    .line 69
    if-lt v2, v0, :cond_3

    .line 70
    .line 71
    sub-int/2addr v8, v1

    .line 72
    and-int v0, v8, v11

    .line 73
    .line 74
    shr-int/lit8 v1, v2, 0x1

    .line 75
    .line 76
    if-le v0, v1, :cond_0

    .line 77
    .line 78
    :cond_3
    :goto_0
    const/4 p1, 0x1

    .line 79
    return p1

    .line 80
    :cond_4
    add-int/lit8 v1, v8, 0x1

    .line 81
    .line 82
    and-int/2addr v1, v11

    .line 83
    invoke-virtual {v4, v2, v3, v1}, Lag/l;->updateTail(JI)J

    .line 84
    .line 85
    .line 86
    move-result-wide v4

    .line 87
    move-object v1, p0

    .line 88
    invoke-virtual/range {v0 .. v5}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    .line 89
    .line 90
    .line 91
    move-result v2

    .line 92
    if-eqz v2, :cond_0

    .line 93
    .line 94
    and-int v1, v8, v9

    .line 95
    .line 96
    invoke-virtual {v10, v1, p1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->set(ILjava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    move-object v1, p0

    .line 100
    :cond_5
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    .line 101
    .line 102
    .line 103
    move-result-wide v2

    .line 104
    const-wide/high16 v4, 0x1000000000000000L

    .line 105
    .line 106
    and-long/2addr v2, v4

    .line 107
    cmp-long v2, v2, v6

    .line 108
    .line 109
    if-eqz v2, :cond_7

    .line 110
    .line 111
    invoke-virtual {v1}, Lag/n;->c()Lag/n;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    iget-object v2, v1, Lag/n;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 116
    .line 117
    iget v3, v1, Lag/n;->c:I

    .line 118
    .line 119
    and-int/2addr v3, v8

    .line 120
    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v4

    .line 124
    instance-of v5, v4, Lag/m;

    .line 125
    .line 126
    if-eqz v5, :cond_6

    .line 127
    .line 128
    check-cast v4, Lag/m;

    .line 129
    .line 130
    iget v4, v4, Lag/m;->a:I

    .line 131
    .line 132
    if-ne v4, v8, :cond_6

    .line 133
    .line 134
    invoke-virtual {v2, v3, p1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->set(ILjava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    goto :goto_1

    .line 138
    :cond_6
    const/4 v1, 0x0

    .line 139
    :goto_1
    if-nez v1, :cond_5

    .line 140
    .line 141
    :cond_7
    const/4 p1, 0x0

    .line 142
    return p1
.end method

.method public final b()Z
    .locals 12

    .line 1
    :cond_0
    sget-object v0, Lag/n;->g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    .line 4
    .line 5
    .line 6
    move-result-wide v2

    .line 7
    const-wide/high16 v4, 0x2000000000000000L

    .line 8
    .line 9
    and-long v6, v2, v4

    .line 10
    .line 11
    const-wide/16 v8, 0x0

    .line 12
    .line 13
    cmp-long v1, v6, v8

    .line 14
    .line 15
    const/4 v6, 0x1

    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    return v6

    .line 19
    :cond_1
    const-wide/high16 v10, 0x1000000000000000L

    .line 20
    .line 21
    and-long/2addr v10, v2

    .line 22
    cmp-long v1, v10, v8

    .line 23
    .line 24
    if-eqz v1, :cond_2

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    return v0

    .line 28
    :cond_2
    or-long/2addr v4, v2

    .line 29
    move-object v1, p0

    .line 30
    invoke-virtual/range {v0 .. v5}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    return v6
.end method

.method public final c()Lag/n;
    .locals 13

    .line 1
    :cond_0
    sget-object v0, Lag/n;->g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    .line 4
    .line 5
    .line 6
    move-result-wide v2

    .line 7
    const-wide/high16 v6, 0x1000000000000000L

    .line 8
    .line 9
    and-long v4, v2, v6

    .line 10
    .line 11
    const-wide/16 v8, 0x0

    .line 12
    .line 13
    cmp-long v1, v4, v8

    .line 14
    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    move-object v1, p0

    .line 18
    goto :goto_0

    .line 19
    :cond_1
    or-long v4, v2, v6

    .line 20
    .line 21
    move-object v1, p0

    .line 22
    invoke-virtual/range {v0 .. v5}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-eqz v2, :cond_0

    .line 27
    .line 28
    move-wide v2, v4

    .line 29
    :goto_0
    sget-object v4, Lag/n;->f:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 30
    .line 31
    invoke-virtual {v4, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v5

    .line 35
    check-cast v5, Lag/n;

    .line 36
    .line 37
    if-eqz v5, :cond_2

    .line 38
    .line 39
    return-object v5

    .line 40
    :cond_2
    new-instance v5, Lag/n;

    .line 41
    .line 42
    iget v8, v1, Lag/n;->a:I

    .line 43
    .line 44
    mul-int/lit8 v8, v8, 0x2

    .line 45
    .line 46
    iget-boolean v9, v1, Lag/n;->b:Z

    .line 47
    .line 48
    invoke-direct {v5, v8, v9}, Lag/n;-><init>(IZ)V

    .line 49
    .line 50
    .line 51
    const-wide/32 v8, 0x3fffffff

    .line 52
    .line 53
    .line 54
    and-long/2addr v8, v2

    .line 55
    long-to-int v8, v8

    .line 56
    const-wide v9, 0xfffffffc0000000L

    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    and-long/2addr v9, v2

    .line 62
    const/16 v11, 0x1e

    .line 63
    .line 64
    shr-long/2addr v9, v11

    .line 65
    long-to-int v9, v9

    .line 66
    :goto_1
    iget v10, v1, Lag/n;->c:I

    .line 67
    .line 68
    and-int v11, v8, v10

    .line 69
    .line 70
    and-int/2addr v10, v9

    .line 71
    if-eq v11, v10, :cond_4

    .line 72
    .line 73
    iget-object v10, v1, Lag/n;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 74
    .line 75
    invoke-virtual {v10, v11}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v10

    .line 79
    if-nez v10, :cond_3

    .line 80
    .line 81
    new-instance v10, Lag/m;

    .line 82
    .line 83
    invoke-direct {v10, v8}, Lag/m;-><init>(I)V

    .line 84
    .line 85
    .line 86
    :cond_3
    iget-object v11, v5, Lag/n;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 87
    .line 88
    iget v12, v5, Lag/n;->c:I

    .line 89
    .line 90
    and-int/2addr v12, v8

    .line 91
    invoke-virtual {v11, v12, v10}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->set(ILjava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    add-int/lit8 v8, v8, 0x1

    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_4
    sget-object v8, Lag/n;->e:Lag/l;

    .line 98
    .line 99
    invoke-virtual {v8, v2, v3, v6, v7}, Lag/l;->wo(JJ)J

    .line 100
    .line 101
    .line 102
    move-result-wide v8

    .line 103
    invoke-virtual {v0, v5, v8, v9}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->set(Ljava/lang/Object;J)V

    .line 104
    .line 105
    .line 106
    :cond_5
    const/4 v8, 0x0

    .line 107
    invoke-virtual {v4, p0, v8, v5}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v8

    .line 111
    if-eqz v8, :cond_6

    .line 112
    .line 113
    goto :goto_0

    .line 114
    :cond_6
    invoke-virtual {v4, p0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v8

    .line 118
    if-eqz v8, :cond_5

    .line 119
    .line 120
    goto :goto_0
.end method

.method public final d()Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    :cond_0
    sget-object v0, Lag/n;->g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    .line 6
    .line 7
    .line 8
    move-result-wide v2

    .line 9
    const-wide/high16 v6, 0x1000000000000000L

    .line 10
    .line 11
    and-long v4, v2, v6

    .line 12
    .line 13
    const-wide/16 v8, 0x0

    .line 14
    .line 15
    cmp-long v4, v4, v8

    .line 16
    .line 17
    if-eqz v4, :cond_1

    .line 18
    .line 19
    sget-object v0, Lag/n;->h:LPa/a0;

    .line 20
    .line 21
    return-object v0

    .line 22
    :cond_1
    const-wide/32 v10, 0x3fffffff

    .line 23
    .line 24
    .line 25
    and-long v4, v2, v10

    .line 26
    .line 27
    long-to-int v4, v4

    .line 28
    const-wide v12, 0xfffffffc0000000L

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    and-long/2addr v12, v2

    .line 34
    const/16 v5, 0x1e

    .line 35
    .line 36
    shr-long/2addr v12, v5

    .line 37
    long-to-int v5, v12

    .line 38
    iget v12, v1, Lag/n;->c:I

    .line 39
    .line 40
    and-int/2addr v5, v12

    .line 41
    and-int/2addr v12, v4

    .line 42
    const/4 v13, 0x0

    .line 43
    if-ne v5, v12, :cond_2

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_2
    iget-object v14, v1, Lag/n;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 47
    .line 48
    invoke-virtual {v14, v12}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v15

    .line 52
    iget-boolean v5, v1, Lag/n;->b:Z

    .line 53
    .line 54
    if-nez v15, :cond_3

    .line 55
    .line 56
    if-eqz v5, :cond_0

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_3
    move-wide/from16 v16, v6

    .line 60
    .line 61
    instance-of v6, v15, Lag/m;

    .line 62
    .line 63
    if-eqz v6, :cond_4

    .line 64
    .line 65
    :goto_0
    return-object v13

    .line 66
    :cond_4
    add-int/lit8 v4, v4, 0x1

    .line 67
    .line 68
    const v6, 0x3fffffff    # 1.9999999f

    .line 69
    .line 70
    .line 71
    and-int/2addr v6, v4

    .line 72
    sget-object v7, Lag/n;->e:Lag/l;

    .line 73
    .line 74
    move/from16 v18, v5

    .line 75
    .line 76
    invoke-virtual {v7, v2, v3, v6}, Lag/l;->updateHead(JI)J

    .line 77
    .line 78
    .line 79
    move-result-wide v4

    .line 80
    invoke-virtual/range {v0 .. v5}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-eqz v0, :cond_5

    .line 85
    .line 86
    invoke-virtual {v14, v12, v13}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->set(ILjava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    return-object v15

    .line 90
    :cond_5
    move-object/from16 v1, p0

    .line 91
    .line 92
    if-eqz v18, :cond_0

    .line 93
    .line 94
    :cond_6
    sget-object v0, Lag/n;->g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 95
    .line 96
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->get(Ljava/lang/Object;)J

    .line 97
    .line 98
    .line 99
    move-result-wide v2

    .line 100
    and-long v4, v2, v10

    .line 101
    .line 102
    long-to-int v4, v4

    .line 103
    and-long v18, v2, v16

    .line 104
    .line 105
    cmp-long v5, v18, v8

    .line 106
    .line 107
    if-eqz v5, :cond_7

    .line 108
    .line 109
    invoke-virtual {v1}, Lag/n;->c()Lag/n;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    move-object v1, v0

    .line 114
    goto :goto_1

    .line 115
    :cond_7
    invoke-virtual {v7, v2, v3, v6}, Lag/l;->updateHead(JI)J

    .line 116
    .line 117
    .line 118
    move-result-wide v23

    .line 119
    move-object/from16 v19, v0

    .line 120
    .line 121
    move-object/from16 v20, v1

    .line 122
    .line 123
    move-wide/from16 v21, v2

    .line 124
    .line 125
    invoke-virtual/range {v19 .. v24}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->compareAndSet(Ljava/lang/Object;JJ)Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    if-eqz v0, :cond_6

    .line 130
    .line 131
    iget-object v0, v1, Lag/n;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    .line 132
    .line 133
    iget v1, v1, Lag/n;->c:I

    .line 134
    .line 135
    and-int/2addr v1, v4

    .line 136
    invoke-virtual {v0, v1, v13}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->set(ILjava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    move-object v1, v13

    .line 140
    :goto_1
    if-nez v1, :cond_6

    .line 141
    .line 142
    return-object v15
.end method
