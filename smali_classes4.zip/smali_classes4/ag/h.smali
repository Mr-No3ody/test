.class public final Lag/h;
.super Lag/j;
.source "SourceFile"


# instance fields
.field public final d:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lag/j;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lag/h;->d:I

    .line 5
    .line 6
    return-void
.end method
