.class public final synthetic LAd/z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/z;->a:I

    iput-object p1, p0, LAd/z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/z;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;->g(Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;)Lcom/mikepenz/iconics/view/IconicsImageView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;->i(Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;)Landroidx/constraintlayout/widget/Group;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LAd/z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, LAd/z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, p0, LAd/z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;->e(Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_4
    iget-object v0, p0, LAd/z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;->f(Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_5
    iget-object v0, p0, LAd/z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;->j(Lcom/transsnet/palmpay/send_money/ui/dialog/CyberSecurityLevyDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
