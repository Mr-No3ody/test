.class public final synthetic LAd/C;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/C;->a:I

    iput-object p1, p0, LAd/C;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/C;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/C;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;->e(Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;)Lcom/mikepenz/iconics/view/IconicsImageView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/C;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LAd/C;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;->d(Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, LAd/C;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, p0, LAd/C;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;->g(Lcom/transsnet/palmpay/send_money/ui/dialog/ExceedsDailyLimitDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
