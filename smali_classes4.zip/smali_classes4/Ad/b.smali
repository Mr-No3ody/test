.class public final synthetic LAd/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/b;->a:I

    iput-object p1, p0, LAd/b;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget v0, p0, LAd/b;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/b;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    invoke-static {v0, p1}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Landroid/view/View;)V

    return-void

    :pswitch_0
    iget-object v0, p0, LAd/b;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    invoke-static {v0, p1}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Landroid/view/View;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
