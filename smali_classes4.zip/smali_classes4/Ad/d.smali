.class public final synthetic LAd/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/d;->a:I

    iput-object p1, p0, LAd/d;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/d;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/d;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;)LAd/f;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/d;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->f(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;)LAd/g;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
