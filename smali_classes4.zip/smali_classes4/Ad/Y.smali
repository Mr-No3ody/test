.class public final LAd/Y;
.super LM1/j;
.source "SourceFile"


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 7

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail$SubTax;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "item"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getLayoutPosition()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_0

    .line 18
    .line 19
    sget v0, LL6/b;->ppColorPrimary:I

    .line 20
    .line 21
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    sget v0, LL6/b;->ppColorTextPrimary:I

    .line 31
    .line 32
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-static {v0, v1}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    :goto_0
    sget v1, Lkd/e;->tvName:I

    .line 41
    .line 42
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail$SubTax;->getTaxName()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    invoke-virtual {p1, v1, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    sget v2, Lkd/e;->tvName:I

    .line 51
    .line 52
    invoke-virtual {v1, v2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setTextColor(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 53
    .line 54
    .line 55
    new-instance v1, Lcom/transsnet/palmpay/util/SpanUtils;

    .line 56
    .line 57
    invoke-direct {v1}, Lcom/transsnet/palmpay/util/SpanUtils;-><init>()V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail$SubTax;->getUnderlineTax()Ljava/lang/Long;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    const-wide/16 v3, 0x0

    .line 65
    .line 66
    if-eqz v2, :cond_1

    .line 67
    .line 68
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 69
    .line 70
    .line 71
    move-result-wide v5

    .line 72
    goto :goto_1

    .line 73
    :cond_1
    move-wide v5, v3

    .line 74
    :goto_1
    cmp-long v2, v5, v3

    .line 75
    .line 76
    if-lez v2, :cond_3

    .line 77
    .line 78
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail$SubTax;->getUnderlineTax()Ljava/lang/Long;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    if-eqz v2, :cond_2

    .line 83
    .line 84
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 85
    .line 86
    .line 87
    move-result-wide v5

    .line 88
    goto :goto_2

    .line 89
    :cond_2
    move-wide v5, v3

    .line 90
    :goto_2
    invoke-static {v5, v6}, LJd/c;->a(J)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    invoke-virtual {v2}, Lcom/transsnet/palmpay/util/SpanUtils;->setStrikethrough()Lcom/transsnet/palmpay/util/SpanUtils;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    sget v5, LL6/b;->ppColorTextAssist:I

    .line 103
    .line 104
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 105
    .line 106
    .line 107
    move-result-object v6

    .line 108
    invoke-static {v5, v6}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 109
    .line 110
    .line 111
    move-result v5

    .line 112
    invoke-virtual {v2, v5}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 113
    .line 114
    .line 115
    move-result-object v2

    .line 116
    const-string v5, " "

    .line 117
    .line 118
    invoke-virtual {v2, v5}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 119
    .line 120
    .line 121
    :cond_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail$SubTax;->getTax()Ljava/lang/Long;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    if-eqz v2, :cond_4

    .line 126
    .line 127
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 128
    .line 129
    .line 130
    move-result-wide v3

    .line 131
    :cond_4
    invoke-static {v3, v4}, LJd/c;->a(J)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/util/SpanUtils;->append(Ljava/lang/CharSequence;)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 136
    .line 137
    .line 138
    move-result-object v2

    .line 139
    invoke-virtual {v2, v0}, Lcom/transsnet/palmpay/util/SpanUtils;->setForegroundColor(I)Lcom/transsnet/palmpay/util/SpanUtils;

    .line 140
    .line 141
    .line 142
    sget v0, Lkd/e;->tvAmount:I

    .line 143
    .line 144
    invoke-virtual {v1}, Lcom/transsnet/palmpay/util/SpanUtils;->create()Landroid/text/SpannableStringBuilder;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 149
    .line 150
    .line 151
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail$SubTax;->getTaxDesc()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 156
    .line 157
    .line 158
    move-result v0

    .line 159
    if-eqz v0, :cond_5

    .line 160
    .line 161
    sget p2, Lkd/e;->tvDetail:I

    .line 162
    .line 163
    const/4 v0, 0x1

    .line 164
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 165
    .line 166
    .line 167
    return-void

    .line 168
    :cond_5
    sget v0, Lkd/e;->tvDetail:I

    .line 169
    .line 170
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/TradeRecordDetailResp$RecordDetail$SubTax;->getTaxDesc()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object p2

    .line 174
    invoke-virtual {p1, v0, p2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 175
    .line 176
    .line 177
    move-result-object p1

    .line 178
    sget p2, Lkd/e;->tvDetail:I

    .line 179
    .line 180
    const/4 v0, 0x0

    .line 181
    invoke-virtual {p1, p2, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 182
    .line 183
    .line 184
    return-void
.end method
