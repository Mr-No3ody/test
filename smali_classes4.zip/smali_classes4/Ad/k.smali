.class public final LAd/k;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public a:I

.field public final synthetic b:Ljava/util/List;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/lang/String;Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LAd/k;->b:Ljava/util/List;

    .line 2
    .line 3
    iput-object p2, p0, LAd/k;->c:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p3, p0, LAd/k;->d:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3

    .line 1
    new-instance p1, LAd/k;

    .line 2
    .line 3
    iget-object v0, p0, LAd/k;->c:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v1, p0, LAd/k;->d:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    .line 6
    .line 7
    iget-object v2, p0, LAd/k;->b:Ljava/util/List;

    .line 8
    .line 9
    invoke-direct {p1, v2, v0, v1, p2}, LAd/k;-><init>(Ljava/util/List;Ljava/lang/String;Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Lkotlin/coroutines/Continuation;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LAd/k;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LAd/k;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LAd/k;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    iget v1, p0, LAd/k;->a:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v4, 0x1

    .line 8
    if-eqz v1, :cond_2

    .line 9
    .line 10
    if-eq v1, v4, :cond_1

    .line 11
    .line 12
    if-ne v1, v3, :cond_0

    .line 13
    .line 14
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    goto :goto_2

    .line 18
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 19
    .line 20
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 21
    .line 22
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    throw p1

    .line 26
    :cond_1
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_2
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    sget-object p1, LWf/I;->a:Lcg/f;

    .line 34
    .line 35
    new-instance v1, LAd/j;

    .line 36
    .line 37
    iget-object v5, p0, LAd/k;->b:Ljava/util/List;

    .line 38
    .line 39
    iget-object v6, p0, LAd/k;->c:Ljava/lang/String;

    .line 40
    .line 41
    invoke-direct {v1, v5, v6, v2}, LAd/j;-><init>(Ljava/util/List;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 42
    .line 43
    .line 44
    iput v4, p0, LAd/k;->a:I

    .line 45
    .line 46
    invoke-static {p1, v1, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    if-ne p1, v0, :cond_3

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_3
    :goto_0
    check-cast p1, Ljava/util/List;

    .line 54
    .line 55
    sget-object v1, LWf/I;->a:Lcg/f;

    .line 56
    .line 57
    sget-object v1, Lag/o;->a:LWf/p0;

    .line 58
    .line 59
    new-instance v4, LAd/i;

    .line 60
    .line 61
    iget-object v5, p0, LAd/k;->d:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    .line 62
    .line 63
    invoke-direct {v4, v5, p1, v2}, LAd/i;-><init>(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Ljava/util/List;Lkotlin/coroutines/Continuation;)V

    .line 64
    .line 65
    .line 66
    iput v3, p0, LAd/k;->a:I

    .line 67
    .line 68
    invoke-static {v1, v4, p0}, LWf/y;->s(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    if-ne p1, v0, :cond_4

    .line 73
    .line 74
    :goto_1
    return-object v0

    .line 75
    :cond_4
    :goto_2
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 76
    .line 77
    return-object p1
.end method
