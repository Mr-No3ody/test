.class public final LAd/m;
.super Lcom/transsnet/palmpay/custom_view/dialog/a;
.source "SourceFile"


# instance fields
.field public final b:Landroid/widget/TextView;

.field public final c:Landroid/widget/TextView;

.field public final d:Landroid/widget/TextView;

.field public final e:Landroid/widget/ImageView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0, p1}, Lcom/transsnet/palmpay/custom_view/dialog/a;-><init>(Landroid/content/Context;)V

    .line 7
    .line 8
    .line 9
    sget p1, Lkd/f;->sm_dialog_bank_customer_phone:I

    .line 10
    .line 11
    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetDialog;->setContentView(I)V

    .line 12
    .line 13
    .line 14
    sget p1, Lkd/e;->tv_confirm:I

    .line 15
    .line 16
    invoke-virtual {p0, p1}, Landroidx/appcompat/app/K;->findViewById(I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    check-cast p1, Landroid/widget/TextView;

    .line 21
    .line 22
    iput-object p1, p0, LAd/m;->b:Landroid/widget/TextView;

    .line 23
    .line 24
    sget p1, Lkd/e;->tv_content:I

    .line 25
    .line 26
    invoke-virtual {p0, p1}, Landroidx/appcompat/app/K;->findViewById(I)Landroid/view/View;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    check-cast p1, Landroid/widget/TextView;

    .line 31
    .line 32
    iput-object p1, p0, LAd/m;->c:Landroid/widget/TextView;

    .line 33
    .line 34
    sget p1, Lkd/e;->tv_title:I

    .line 35
    .line 36
    invoke-virtual {p0, p1}, Landroidx/appcompat/app/K;->findViewById(I)Landroid/view/View;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Landroid/widget/TextView;

    .line 41
    .line 42
    iput-object p1, p0, LAd/m;->d:Landroid/widget/TextView;

    .line 43
    .line 44
    sget p1, Lkd/e;->iv_bank_logo:I

    .line 45
    .line 46
    invoke-virtual {p0, p1}, Landroidx/appcompat/app/K;->findViewById(I)Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, Landroid/widget/ImageView;

    .line 51
    .line 52
    iput-object p1, p0, LAd/m;->e:Landroid/widget/ImageView;

    .line 53
    .line 54
    sget p1, Lkd/e;->iv_close:I

    .line 55
    .line 56
    invoke-virtual {p0, p1}, Landroidx/appcompat/app/K;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    check-cast p1, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 61
    .line 62
    if-eqz p1, :cond_0

    .line 63
    .line 64
    new-instance v0, LA8/b;

    .line 65
    .line 66
    const/4 v1, 0x4

    .line 67
    invoke-direct {v0, p0, v1}, LA8/b;-><init>(Ljava/lang/Object;I)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 71
    .line 72
    .line 73
    :cond_0
    return-void
.end method
