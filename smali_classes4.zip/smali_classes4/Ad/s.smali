.class public final synthetic LAd/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/s;->a:I

    iput-object p1, p0, LAd/s;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/s;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/s;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;)Lcom/mikepenz/iconics/view/IconicsImageView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/s;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;)Lcom/palmpay/lib/ui/button/PpButton;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LAd/s;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;->d(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmDuplicateTransferDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
