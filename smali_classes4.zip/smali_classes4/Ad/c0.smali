.class public final synthetic LAd/c0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView$OnWheelItemSelectedListener;
.implements Lcom/google/android/gms/tasks/OnCompleteListener;
.implements Landroidx/camera/core/impl/Config$OptionMatcher;
.implements Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;
.implements Landroidx/camera/core/impl/ImageReaderProxy$OnImageAvailableListener;
.implements Lcom/chad/library/adapter/base/listener/OnItemChildClickListener;
.implements Lio/reactivex/ObservableOnSubscribe;
.implements Lcom/transsnet/palmpay/send_money/ui/dialog/AccountUnavailableDialog$OnAccountUnavailableListener;
.implements Lcom/transsnet/palmpay/core/callback/ResultCallback;
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;
.implements Lcom/transsnet/palmpay/custom_view/async/PpAsyncInflateQueue$OnInflateFinished;
.implements Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;
.implements Lcom/transsnet/palmpay/core/callback/Argument2Callback;
.implements Lcom/transsnet/palmpay/custom_view/adapter/BaseRecyclerViewAdapter$ItemViewOnClickListener;
.implements Lcom/transsnet/palmpay/custom_view/interfac/OnItemClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LAd/c0;->a:I

    iput-object p2, p0, LAd/c0;->b:Ljava/lang/Object;

    iput-object p3, p0, LAd/c0;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public OnItemViewOnClick(Landroid/view/View;Ljava/lang/Object;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V
    .locals 0

    .line 1
    iget p1, p0, LAd/c0;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast p1, Lda/A;

    check-cast p2, Lcom/transsnet/palmpay/core/bean/bill/BillType;

    iget-object p3, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast p3, LNa/d;

    invoke-static {p3, p1, p2}, LNa/d;->b(LNa/d;Lda/A;Lcom/transsnet/palmpay/core/bean/bill/BillType;)V

    return-void

    :pswitch_0
    check-cast p2, Lcom/transsnet/palmpay/core/bean/KeyValue;

    iget-object p1, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast p1, LNa/a;

    iget-object p3, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast p3, LNa/b;

    invoke-static {p1, p3, p2}, LNa/b;->b(LNa/a;LNa/b;Lcom/transsnet/palmpay/core/bean/KeyValue;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x19
        :pswitch_0
    .end packed-switch
.end method

.method public attachCompleter(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LAd/c0;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LE/m0;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 16
    .line 17
    invoke-virtual {v1, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    new-instance p1, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    const-string v1, "SurfaceRequest-surface-recreation("

    .line 23
    .line 24
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    const-string v0, ")"

    .line 35
    .line 36
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    return-object p1

    .line 44
    :pswitch_0
    iget-object v0, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 45
    .line 46
    move-object v2, v0

    .line 47
    check-cast v2, Landroidx/camera/core/c;

    .line 48
    .line 49
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 53
    .line 54
    .line 55
    move-result-wide v7

    .line 56
    iget-object v0, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 57
    .line 58
    move-object v3, v0

    .line 59
    check-cast v3, Landroid/content/Context;

    .line 60
    .line 61
    new-instance v1, LE/r;

    .line 62
    .line 63
    iget-object v4, v2, Landroidx/camera/core/c;->d:Ljava/util/concurrent/Executor;

    .line 64
    .line 65
    const/4 v5, 0x1

    .line 66
    move-object v6, p1

    .line 67
    invoke-direct/range {v1 .. v8}, LE/r;-><init>(Landroidx/camera/core/c;Landroid/content/Context;Ljava/util/concurrent/Executor;ILandroidx/concurrent/futures/k;J)V

    .line 68
    .line 69
    .line 70
    invoke-interface {v4, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 71
    .line 72
    .line 73
    const-string p1, "CameraX initInternal"

    .line 74
    .line 75
    return-object p1

    .line 76
    nop

    .line 77
    :pswitch_data_0
    .packed-switch 0x3
        :pswitch_0
    .end packed-switch
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 8

    .line 1
    check-cast p1, Ljava/lang/Integer;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    check-cast p2, Landroid/content/Intent;

    .line 8
    .line 9
    iget-object v0, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;

    .line 12
    .line 13
    iget-object v1, v0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->b:Lcom/transsnet/palmpay/account/bean/LogInReq;

    .line 14
    .line 15
    const/4 v2, -0x1

    .line 16
    const/4 v3, 0x0

    .line 17
    const/4 v4, 0x1

    .line 18
    const/4 v5, 0x0

    .line 19
    if-ne p1, v2, :cond_6

    .line 20
    .line 21
    if-eqz p2, :cond_1

    .line 22
    .line 23
    const-string v6, "_token"

    .line 24
    .line 25
    invoke-virtual {p2, v6}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v6

    .line 29
    if-eqz v6, :cond_1

    .line 30
    .line 31
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 32
    .line 33
    .line 34
    move-result v7

    .line 35
    if-nez v7, :cond_0

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    move-object v6, v5

    .line 39
    :goto_0
    if-eqz v6, :cond_1

    .line 40
    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    iget-object v0, v0, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->B:Ljava/lang/String;

    .line 44
    .line 45
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->verifyTokenNumber:Ljava/lang/String;

    .line 46
    .line 47
    iput-object v6, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->verifyToken:Ljava/lang/String;

    .line 48
    .line 49
    iput-boolean v4, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->supplement:Z

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :cond_1
    move-object v6, v5

    .line 53
    :cond_2
    :goto_1
    if-eqz p2, :cond_4

    .line 54
    .line 55
    const-string v0, "_face_token"

    .line 56
    .line 57
    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-eqz v0, :cond_4

    .line 62
    .line 63
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 64
    .line 65
    .line 66
    move-result v7

    .line 67
    if-nez v7, :cond_3

    .line 68
    .line 69
    move-object v5, v0

    .line 70
    :cond_3
    if-eqz v5, :cond_4

    .line 71
    .line 72
    if-eqz v1, :cond_4

    .line 73
    .line 74
    iput-object v5, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->faceToken:Ljava/lang/String;

    .line 75
    .line 76
    iput-boolean v4, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->supplement:Z

    .line 77
    .line 78
    :cond_4
    if-eqz p2, :cond_5

    .line 79
    .line 80
    if-eqz v1, :cond_5

    .line 81
    .line 82
    iput-boolean v4, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->supplement:Z

    .line 83
    .line 84
    const-string v0, "stateCode"

    .line 85
    .line 86
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->stateCode:Ljava/lang/String;

    .line 91
    .line 92
    const-string v0, "stateName"

    .line 93
    .line 94
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->stateName:Ljava/lang/String;

    .line 99
    .line 100
    const-string v0, "lgaCode"

    .line 101
    .line 102
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->lgaCode:Ljava/lang/String;

    .line 107
    .line 108
    const-string v0, "lgaName"

    .line 109
    .line 110
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->lgaName:Ljava/lang/String;

    .line 115
    .line 116
    const-string v0, "areaCode"

    .line 117
    .line 118
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->areaCode:Ljava/lang/String;

    .line 123
    .line 124
    const-string v0, "areaName"

    .line 125
    .line 126
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->areaName:Ljava/lang/String;

    .line 131
    .line 132
    const-string v0, "street"

    .line 133
    .line 134
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v0

    .line 138
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->street:Ljava/lang/String;

    .line 139
    .line 140
    const-string v0, "industry"

    .line 141
    .line 142
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->industry:Ljava/lang/String;

    .line 147
    .line 148
    const-string v0, "profession"

    .line 149
    .line 150
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->profession:Ljava/lang/String;

    .line 155
    .line 156
    const-string v0, "sourceOfFunds"

    .line 157
    .line 158
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->sourceOfFunds:Ljava/lang/String;

    .line 163
    .line 164
    const-string v0, "annualIncome"

    .line 165
    .line 166
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->annualIncome:Ljava/lang/String;

    .line 171
    .line 172
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    if-nez v0, :cond_5

    .line 177
    .line 178
    const-string v0, "currentPolitically"

    .line 179
    .line 180
    invoke-virtual {p2, v0, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 181
    .line 182
    .line 183
    move-result v0

    .line 184
    iput-boolean v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->currentPolitically:Z

    .line 185
    .line 186
    const-string v0, "politicallyExposedPerson"

    .line 187
    .line 188
    invoke-virtual {p2, v0, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    .line 189
    .line 190
    .line 191
    move-result v0

    .line 192
    iput-boolean v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->politicallyExposedPerson:Z

    .line 193
    .line 194
    const-string v0, "positionHeld"

    .line 195
    .line 196
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    iput-object v0, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->positionHeld:Ljava/lang/String;

    .line 201
    .line 202
    const-string v0, "nationality"

    .line 203
    .line 204
    invoke-static {p2, v0}, Lcom/transsnet/palmpay/account/ui/activity/LogInActivity;->q(Landroid/content/Intent;Ljava/lang/String;)Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object p2

    .line 208
    iput-object p2, v1, Lcom/transsnet/palmpay/account/bean/SignUpInReq;->nationality:Ljava/lang/String;

    .line 209
    .line 210
    :cond_5
    move-object v5, v6

    .line 211
    :cond_6
    iget-object p2, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast p2, Lcom/transsnet/palmpay/core/callback/Argument2Callback;

    .line 214
    .line 215
    if-ne p1, v2, :cond_7

    .line 216
    .line 217
    move v3, v4

    .line 218
    :cond_7
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 219
    .line 220
    .line 221
    move-result-object p1

    .line 222
    invoke-interface {p2, v5, p1}, Lcom/transsnet/palmpay/core/callback/Argument2Callback;->invoke(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 223
    .line 224
    .line 225
    return-void
.end method

.method public onComplete(Lcom/google/android/gms/tasks/Task;)V
    .locals 1

    .line 2
    iget-object p1, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast p1, Landroidx/camera/core/ImageProxy;

    invoke-interface {p1}, Landroidx/camera/core/ImageProxy;->close()V

    const/4 p1, 0x0

    .line 3
    iget-object v0, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast v0, Lkotlinx/coroutines/channels/ProducerScope;

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/SendChannel;->close(Ljava/lang/Throwable;)Z

    return-void
.end method

.method public onComplete(Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget-object v0, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmRecipientInfoDialog;

    check-cast p1, Ljava/lang/Boolean;

    iget-object v1, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankAccountView;

    invoke-static {v1, v0, p1}, Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankAccountView;->a(Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankAccountView;Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmRecipientInfoDialog;Ljava/lang/Boolean;)V

    return-void
.end method

.method public onImageAvailable(Landroidx/camera/core/impl/ImageReaderProxy;)V
    .locals 1

    .line 1
    iget-object p1, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, LE/d0;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Landroidx/camera/core/impl/ImageReaderProxy$OnImageAvailableListener;

    .line 11
    .line 12
    invoke-interface {v0, p1}, Landroidx/camera/core/impl/ImageReaderProxy$OnImageAvailableListener;->onImageAvailable(Landroidx/camera/core/impl/ImageReaderProxy;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public onInflateFinished(Landroid/view/View;)V
    .locals 2

    .line 1
    sget v0, Lcom/transsnet/palmpay/custom_view/async/AsyncViewStub;->d:I

    .line 2
    .line 3
    const-string v0, "view"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lcom/transsnet/palmpay/custom_view/async/AsyncViewStub;

    .line 11
    .line 12
    iget-object v1, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 15
    .line 16
    invoke-virtual {v0, p1, v1}, Lcom/transsnet/palmpay/custom_view/async/AsyncViewStub;->a(Landroid/view/View;Lkotlin/jvm/functions/Function1;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public onItemChildClick(LM1/j;Landroid/view/View;I)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move/from16 v3, p3

    .line 8
    .line 9
    sget-object v8, LG7/q;->a:LG7/q;

    .line 10
    .line 11
    sget-object v11, LG7/c;->b:LG7/c;

    .line 12
    .line 13
    const/16 v12, 0x15

    .line 14
    .line 15
    const/16 v13, 0xa

    .line 16
    .line 17
    const-string v14, "layout"

    .line 18
    .line 19
    const-string v15, "requireContext(...)"

    .line 20
    .line 21
    iget-object v4, v0, LAd/c0;->c:Ljava/lang/Object;

    .line 22
    .line 23
    const/4 v5, 0x5

    .line 24
    const/4 v6, 0x0

    .line 25
    iget-object v7, v0, LAd/c0;->b:Ljava/lang/Object;

    .line 26
    .line 27
    const-string v9, "view"

    .line 28
    .line 29
    const/16 v16, 0x3

    .line 30
    .line 31
    iget v10, v0, LAd/c0;->a:I

    .line 32
    .line 33
    packed-switch v10, :pswitch_data_0

    .line 34
    .line 35
    .line 36
    const-string v10, "<unused var>"

    .line 37
    .line 38
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-static {v2, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    sget v9, Lkd/e;->ivMore:I

    .line 49
    .line 50
    check-cast v7, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;

    .line 51
    .line 52
    if-ne v1, v9, :cond_1

    .line 53
    .line 54
    invoke-virtual {v7}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;->t()Lld/x;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    invoke-virtual {v1}, LM1/j;->getItemCount()I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-lt v1, v5, :cond_0

    .line 63
    .line 64
    check-cast v4, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 65
    .line 66
    invoke-virtual {v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    add-int/lit8 v1, v1, -0x3

    .line 71
    .line 72
    :cond_0
    invoke-virtual {v7}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;->t()Lld/x;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    invoke-virtual {v1, v3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    check-cast v1, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 81
    .line 82
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 83
    .line 84
    .line 85
    move-result-object v3

    .line 86
    invoke-static {v3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    sget v4, Lkd/f;->sm_popup_beneficiaries_operation:I

    .line 91
    .line 92
    invoke-virtual {v3, v4, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    new-instance v4, LG7/g;

    .line 97
    .line 98
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 99
    .line 100
    .line 101
    move-result-object v5

    .line 102
    invoke-static {v5, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    invoke-direct {v4, v5}, LG7/g;-><init>(Landroid/content/Context;)V

    .line 106
    .line 107
    .line 108
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    invoke-static {v3, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    iput-object v3, v4, LG7/g;->G:Landroid/view/View;

    .line 115
    .line 116
    invoke-virtual {v4, v13}, LG7/g;->d(I)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v4, v12}, LG7/g;->i(I)V

    .line 120
    .line 121
    .line 122
    sget-object v5, LG7/b;->c:LG7/b;

    .line 123
    .line 124
    invoke-virtual {v4, v5}, LG7/g;->b(LG7/b;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v4, v11}, LG7/g;->c(LG7/c;)V

    .line 128
    .line 129
    .line 130
    const/4 v5, 0x4

    .line 131
    invoke-virtual {v4, v5}, LG7/g;->e(I)V

    .line 132
    .line 133
    .line 134
    const/high16 v5, 0x41000000    # 8.0f

    .line 135
    .line 136
    invoke-virtual {v4, v5}, LG7/g;->g(F)V

    .line 137
    .line 138
    .line 139
    sget v5, LL6/b;->ppColorPopupWhiteBg:I

    .line 140
    .line 141
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 142
    .line 143
    .line 144
    move-result-object v6

    .line 145
    invoke-static {v5, v6}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 146
    .line 147
    .line 148
    move-result v5

    .line 149
    iput v5, v4, LG7/g;->t:I

    .line 150
    .line 151
    invoke-virtual {v4, v8}, LG7/g;->f(LG7/q;)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    .line 155
    .line 156
    .line 157
    move-result-object v5

    .line 158
    iput-object v5, v4, LG7/g;->O:Landroidx/lifecycle/LifecycleOwner;

    .line 159
    .line 160
    invoke-virtual {v4}, LG7/g;->a()Lcom/skydoves/balloon/Balloon;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    invoke-static {v2, v4}, La/a;->B(Landroid/view/View;Lcom/skydoves/balloon/Balloon;)V

    .line 165
    .line 166
    .line 167
    sget v2, Lkd/e;->tv_delete:I

    .line 168
    .line 169
    invoke-virtual {v3, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 170
    .line 171
    .line 172
    move-result-object v2

    .line 173
    check-cast v2, Landroid/widget/TextView;

    .line 174
    .line 175
    new-instance v3, LB6/i;

    .line 176
    .line 177
    move/from16 v5, v16

    .line 178
    .line 179
    invoke-direct {v3, v4, v5, v7, v1}, LB6/i;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 183
    .line 184
    .line 185
    goto :goto_0

    .line 186
    :cond_1
    sget v2, Lkd/e;->ivFavorite:I

    .line 187
    .line 188
    if-ne v1, v2, :cond_2

    .line 189
    .line 190
    invoke-virtual {v7}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;->t()Lld/x;

    .line 191
    .line 192
    .line 193
    move-result-object v1

    .line 194
    invoke-virtual {v1, v3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v1

    .line 198
    check-cast v1, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 199
    .line 200
    if-eqz v1, :cond_2

    .line 201
    .line 202
    iget-object v2, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 203
    .line 204
    check-cast v2, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 205
    .line 206
    if-eqz v2, :cond_2

    .line 207
    .line 208
    invoke-virtual {v1}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v1

    .line 212
    new-instance v3, LKd/p1;

    .line 213
    .line 214
    const/4 v4, 0x0

    .line 215
    invoke-direct {v3, v1, v4, v6}, LKd/p1;-><init>(Ljava/lang/String;ZLkotlin/coroutines/Continuation;)V

    .line 216
    .line 217
    .line 218
    iget-object v4, v2, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->g:Lcom/transsnet/palmpay/core/base/l;

    .line 219
    .line 220
    iput-object v1, v4, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 221
    .line 222
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 223
    .line 224
    const-wide/16 v5, 0x0

    .line 225
    .line 226
    invoke-static {v2, v3, v4, v5, v6}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 227
    .line 228
    .line 229
    :cond_2
    :goto_0
    return-void

    .line 230
    :pswitch_0
    const-string v10, "adapter"

    .line 231
    .line 232
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 233
    .line 234
    .line 235
    invoke-static {v2, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    invoke-virtual {v2}, Landroid/view/View;->getId()I

    .line 239
    .line 240
    .line 241
    move-result v9

    .line 242
    sget v10, Lkd/e;->ivMore:I

    .line 243
    .line 244
    check-cast v7, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;

    .line 245
    .line 246
    if-ne v9, v10, :cond_4

    .line 247
    .line 248
    invoke-virtual {v1}, LM1/j;->getItemCount()I

    .line 249
    .line 250
    .line 251
    move-result v1

    .line 252
    if-lt v1, v5, :cond_3

    .line 253
    .line 254
    check-cast v4, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 255
    .line 256
    invoke-virtual {v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    .line 257
    .line 258
    .line 259
    move-result v1

    .line 260
    const/16 v16, 0x3

    .line 261
    .line 262
    add-int/lit8 v1, v1, -0x3

    .line 263
    .line 264
    :cond_3
    invoke-virtual {v7}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;->u()Lld/x;

    .line 265
    .line 266
    .line 267
    move-result-object v1

    .line 268
    invoke-virtual {v1, v3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object v1

    .line 272
    check-cast v1, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 273
    .line 274
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    .line 275
    .line 276
    .line 277
    move-result-object v3

    .line 278
    invoke-static {v3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 279
    .line 280
    .line 281
    move-result-object v3

    .line 282
    sget v4, Lkd/f;->sm_popup_beneficiaries_operation:I

    .line 283
    .line 284
    invoke-virtual {v3, v4, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 285
    .line 286
    .line 287
    move-result-object v3

    .line 288
    new-instance v4, LG7/g;

    .line 289
    .line 290
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 291
    .line 292
    .line 293
    move-result-object v5

    .line 294
    invoke-static {v5, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    invoke-direct {v4, v5}, LG7/g;-><init>(Landroid/content/Context;)V

    .line 298
    .line 299
    .line 300
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 301
    .line 302
    .line 303
    invoke-static {v3, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    iput-object v3, v4, LG7/g;->G:Landroid/view/View;

    .line 307
    .line 308
    invoke-virtual {v4, v13}, LG7/g;->d(I)V

    .line 309
    .line 310
    .line 311
    invoke-virtual {v4, v12}, LG7/g;->i(I)V

    .line 312
    .line 313
    .line 314
    sget-object v5, LG7/b;->c:LG7/b;

    .line 315
    .line 316
    invoke-virtual {v4, v5}, LG7/g;->b(LG7/b;)V

    .line 317
    .line 318
    .line 319
    invoke-virtual {v4, v11}, LG7/g;->c(LG7/c;)V

    .line 320
    .line 321
    .line 322
    const/4 v5, 0x4

    .line 323
    invoke-virtual {v4, v5}, LG7/g;->e(I)V

    .line 324
    .line 325
    .line 326
    const/high16 v5, 0x41000000    # 8.0f

    .line 327
    .line 328
    invoke-virtual {v4, v5}, LG7/g;->g(F)V

    .line 329
    .line 330
    .line 331
    sget v5, LL6/b;->ppColorPopupWhiteBg:I

    .line 332
    .line 333
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 334
    .line 335
    .line 336
    move-result-object v6

    .line 337
    invoke-static {v5, v6}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 338
    .line 339
    .line 340
    move-result v5

    .line 341
    iput v5, v4, LG7/g;->t:I

    .line 342
    .line 343
    invoke-virtual {v4, v8}, LG7/g;->f(LG7/q;)V

    .line 344
    .line 345
    .line 346
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Landroidx/lifecycle/LifecycleOwner;

    .line 347
    .line 348
    .line 349
    move-result-object v5

    .line 350
    iput-object v5, v4, LG7/g;->O:Landroidx/lifecycle/LifecycleOwner;

    .line 351
    .line 352
    invoke-virtual {v4}, LG7/g;->a()Lcom/skydoves/balloon/Balloon;

    .line 353
    .line 354
    .line 355
    move-result-object v4

    .line 356
    invoke-static {v2, v4}, La/a;->B(Landroid/view/View;Lcom/skydoves/balloon/Balloon;)V

    .line 357
    .line 358
    .line 359
    sget v2, Lkd/e;->tv_delete:I

    .line 360
    .line 361
    invoke-virtual {v3, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 362
    .line 363
    .line 364
    move-result-object v2

    .line 365
    check-cast v2, Landroid/widget/TextView;

    .line 366
    .line 367
    new-instance v3, LB6/i;

    .line 368
    .line 369
    const/4 v5, 0x2

    .line 370
    invoke-direct {v3, v4, v5, v7, v1}, LB6/i;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 371
    .line 372
    .line 373
    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 374
    .line 375
    .line 376
    goto/16 :goto_1

    .line 377
    .line 378
    :cond_4
    sget v1, Lkd/e;->ivFavorite:I

    .line 379
    .line 380
    const-string v2, "beneficiary_bean"

    .line 381
    .line 382
    const-string v4, "beneficiary_type"

    .line 383
    .line 384
    const-string v5, "/sm/add_beneficiary"

    .line 385
    .line 386
    if-ne v9, v1, :cond_6

    .line 387
    .line 388
    invoke-virtual {v7}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;->u()Lld/x;

    .line 389
    .line 390
    .line 391
    move-result-object v1

    .line 392
    invoke-virtual {v1}, LM1/j;->getData()Ljava/util/List;

    .line 393
    .line 394
    .line 395
    move-result-object v1

    .line 396
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v1

    .line 400
    check-cast v1, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 401
    .line 402
    if-eqz v1, :cond_8

    .line 403
    .line 404
    iget-boolean v3, v1, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->favorite:Z

    .line 405
    .line 406
    if-eqz v3, :cond_5

    .line 407
    .line 408
    iget-object v2, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 409
    .line 410
    check-cast v2, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 411
    .line 412
    if-eqz v2, :cond_8

    .line 413
    .line 414
    invoke-virtual {v1}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 415
    .line 416
    .line 417
    move-result-object v3

    .line 418
    iget-boolean v1, v1, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->favorite:Z

    .line 419
    .line 420
    xor-int/lit8 v1, v1, 0x1

    .line 421
    .line 422
    new-instance v4, LKd/p1;

    .line 423
    .line 424
    invoke-direct {v4, v3, v1, v6}, LKd/p1;-><init>(Ljava/lang/String;ZLkotlin/coroutines/Continuation;)V

    .line 425
    .line 426
    .line 427
    iget-object v1, v2, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->g:Lcom/transsnet/palmpay/core/base/l;

    .line 428
    .line 429
    iput-object v3, v1, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 430
    .line 431
    sget-object v3, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 432
    .line 433
    const-wide/16 v5, 0x0

    .line 434
    .line 435
    invoke-static {v2, v4, v1, v5, v6}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 436
    .line 437
    .line 438
    goto :goto_1

    .line 439
    :cond_5
    const/4 v3, 0x2

    .line 440
    invoke-static {v3, v5, v4}, Lcom/horcrux/svg/d0;->g(ILjava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 441
    .line 442
    .line 443
    move-result-object v3

    .line 444
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 445
    .line 446
    .line 447
    move-result-object v4

    .line 448
    iget-object v4, v4, LPa/w;->b:Ljava/lang/Object;

    .line 449
    .line 450
    check-cast v4, Lcom/google/gson/Gson;

    .line 451
    .line 452
    invoke-virtual {v4, v1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 453
    .line 454
    .line 455
    move-result-object v1

    .line 456
    invoke-virtual {v3, v2, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 457
    .line 458
    .line 459
    move-result-object v1

    .line 460
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 461
    .line 462
    .line 463
    move-result-object v2

    .line 464
    invoke-virtual {v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 465
    .line 466
    .line 467
    goto :goto_1

    .line 468
    :cond_6
    sget v1, Lkd/e;->btnSetup:I

    .line 469
    .line 470
    if-ne v9, v1, :cond_8

    .line 471
    .line 472
    invoke-virtual {v7}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;->u()Lld/x;

    .line 473
    .line 474
    .line 475
    move-result-object v1

    .line 476
    invoke-virtual {v1, v3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v1

    .line 480
    check-cast v1, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 481
    .line 482
    if-eqz v1, :cond_8

    .line 483
    .line 484
    iget-object v3, v7, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 485
    .line 486
    check-cast v3, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 487
    .line 488
    if-eqz v3, :cond_7

    .line 489
    .line 490
    invoke-virtual {v1}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 491
    .line 492
    .line 493
    move-result-object v8

    .line 494
    new-instance v9, LKd/S0;

    .line 495
    .line 496
    invoke-direct {v9, v8, v6}, LKd/S0;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 497
    .line 498
    .line 499
    new-instance v6, Lcom/transsnet/palmpay/core/base/l;

    .line 500
    .line 501
    invoke-direct {v6}, Lcom/transsnet/palmpay/core/base/l;-><init>()V

    .line 502
    .line 503
    .line 504
    const/16 v8, 0x1c

    .line 505
    .line 506
    const/4 v10, 0x0

    .line 507
    invoke-static {v3, v9, v6, v10, v8}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 508
    .line 509
    .line 510
    :cond_7
    const/4 v3, 0x2

    .line 511
    invoke-static {v3, v5, v4}, Lcom/horcrux/svg/d0;->g(ILjava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 512
    .line 513
    .line 514
    move-result-object v3

    .line 515
    invoke-static {}, LPa/w;->f()LPa/w;

    .line 516
    .line 517
    .line 518
    move-result-object v4

    .line 519
    iget-object v4, v4, LPa/w;->b:Ljava/lang/Object;

    .line 520
    .line 521
    check-cast v4, Lcom/google/gson/Gson;

    .line 522
    .line 523
    invoke-virtual {v4, v1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    .line 524
    .line 525
    .line 526
    move-result-object v1

    .line 527
    invoke-virtual {v3, v2, v1}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 528
    .line 529
    .line 530
    move-result-object v1

    .line 531
    invoke-virtual {v7}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    .line 532
    .line 533
    .line 534
    move-result-object v2

    .line 535
    invoke-virtual {v1, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 536
    .line 537
    .line 538
    :cond_8
    :goto_1
    return-void

    .line 539
    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_0
    .end packed-switch
.end method

.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 5

    iget v0, p0, LAd/c0;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/ui/view/ModelPremiumBenefits;

    iget-object v1, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-static {v0, v1, p1, p2, p3}, Lcom/transsnet/palmpay/ui/view/ModelPremiumBenefits;->c(Lcom/transsnet/palmpay/ui/view/ModelPremiumBenefits;Landroid/content/Context;LM1/j;Landroid/view/View;I)V

    return-void

    .line 1
    :pswitch_0
    const-string v0, "<unused var>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    iget-object p1, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast p1, Lda/b0;

    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    .line 3
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->isSelected()Z

    move-result p2

    const/4 p3, 0x1

    xor-int/2addr p2, p3

    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->setSelected(Z)V

    .line 4
    iget-object p2, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast p2, LGe/d;

    iget-object v0, p2, LGe/d;->b:Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp;

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp;->getPaymentType()Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$PaymentTypeBean;

    move-result-object v0

    if-eqz v0, :cond_6

    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$PaymentTypeBean;->getConditions()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_6

    .line 5
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    .line 6
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->getChildTypeParam()Ljava/util/ArrayList;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 7
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    .line 8
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->isSelected()Z

    move-result v3

    if-eqz v3, :cond_1

    .line 9
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->getAll()Z

    move-result p3

    iget-object v0, p2, LGe/d;->b:Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp;

    if-eqz p3, :cond_3

    .line 10
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->isSelected()Z

    move-result p3

    if-eqz p3, :cond_7

    if-eqz v0, :cond_7

    .line 11
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp;->getPaymentType()Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$PaymentTypeBean;

    move-result-object p3

    if-eqz p3, :cond_7

    invoke-virtual {p3}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$PaymentTypeBean;->getConditions()Ljava/util/ArrayList;

    move-result-object p3

    if-eqz p3, :cond_7

    .line 12
    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :cond_2
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    .line 13
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->getChildTypeParam()Ljava/util/ArrayList;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 14
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    .line 15
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->getCode()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->getCode()Ljava/lang/String;

    move-result-object v4

    .line 16
    invoke-static {v3, v4, v1}, Lkotlin/text/y;->h(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    .line 17
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->setSelected(Z)V

    goto :goto_0

    :cond_3
    if-eqz v0, :cond_7

    .line 18
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp;->getPaymentType()Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$PaymentTypeBean;

    move-result-object p1

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$PaymentTypeBean;->getConditions()Ljava/util/ArrayList;

    move-result-object p1

    if-eqz p1, :cond_7

    .line 19
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    .line 20
    invoke-virtual {p3}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->getChildTypeParam()Ljava/util/ArrayList;

    move-result-object p3

    if-eqz p3, :cond_4

    .line 21
    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :cond_5
    :goto_1
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    .line 22
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->getAll()Z

    move-result v2

    if-eqz v2, :cond_5

    .line 23
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->setSelected(Z)V

    goto :goto_1

    .line 24
    :cond_6
    invoke-virtual {p1, p3}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->setSelected(Z)V

    .line 25
    const-string p1, "Please select at least one Payment Type."

    new-array p3, v1, [Ljava/lang/Object;

    invoke-static {p1, p3}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 26
    :cond_7
    iget-object p1, p2, LGe/d;->g:Ljava/util/ArrayList;

    .line 27
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_8

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lda/b0;

    .line 28
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    goto :goto_2

    :cond_8
    return-void

    :pswitch_data_0
    .packed-switch 0x14
        :pswitch_0
    .end packed-switch
.end method

.method public onItemClick(Ljava/lang/Object;)V
    .locals 2

    iget p1, p0, LAd/c0;->a:I

    packed-switch p1, :pswitch_data_0

    .line 29
    iget-object p1, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast p1, LNc/t;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getAdapterPosition()I

    move-result p1

    .line 30
    iget-object v0, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast v0, LNc/u;

    iget v1, v0, LNc/u;->c:I

    if-ne v1, p1, :cond_0

    goto :goto_0

    .line 31
    :cond_0
    iget-object v1, v0, LNc/u;->a:Ljava/util/ArrayList;

    if-eqz v1, :cond_1

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/transsnet/palmpay/managemoney/bean/PayoutOption;

    if-eqz v1, :cond_1

    .line 32
    iput p1, v0, LNc/u;->c:I

    .line 33
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 34
    iget-object p1, v0, LNc/u;->b:La;

    if-eqz p1, :cond_1

    invoke-virtual {p1, v1}, La;->onItemClick(Ljava/lang/Object;)V

    :cond_1
    :goto_0
    return-void

    .line 35
    :pswitch_0
    iget-object p1, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast p1, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    if-eqz p1, :cond_2

    .line 36
    iget-object v0, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast v0, LNc/k;

    iget-object v0, v0, LNc/k;->c:Lcom/palmpay/lib/bridgewrapper/photo/upload/a;

    if-eqz v0, :cond_2

    invoke-virtual {v0, p1}, Lcom/palmpay/lib/bridgewrapper/photo/upload/a;->onItemClick(Ljava/lang/Object;)V

    :cond_2
    return-void

    .line 37
    :pswitch_1
    iget-object p1, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast p1, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    if-eqz p1, :cond_3

    .line 38
    iget-object v0, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast v0, LNc/e;

    iget-object v0, v0, LNc/e;->d:Lcom/transsnet/palmpay/custom_view/interfac/OnItemClickListener;

    if-eqz v0, :cond_3

    invoke-interface {v0, p1}, Lcom/transsnet/palmpay/custom_view/interfac/OnItemClickListener;->onItemClick(Ljava/lang/Object;)V

    :cond_3
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1b
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public onItemSelected(ILjava/lang/Object;)V
    .locals 2

    .line 1
    iget-object v0, p0, LAd/c0;->c:Ljava/lang/Object;

    check-cast v0, Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView;

    check-cast p2, LAd/f0;

    iget-object v1, p0, LAd/c0;->b:Ljava/lang/Object;

    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/dialog/WeekDayPickerDialog;

    invoke-static {v1, v0, p1, p2}, Lcom/transsnet/palmpay/send_money/ui/dialog/WeekDayPickerDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/WeekDayPickerDialog;Lcom/transsnet/palmpay/custom_view/wheelview/widget/WheelView;ILAd/f0;)V

    return-void
.end method

.method public onOptionMatched(Landroidx/camera/core/impl/V;)Z
    .locals 3

    .line 1
    iget-object v0, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LD/e;

    .line 4
    .line 5
    iget-object v0, v0, LD/e;->a:Landroidx/camera/core/impl/m0;

    .line 6
    .line 7
    iget-object v1, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Landroidx/camera/core/impl/Config;

    .line 10
    .line 11
    invoke-interface {v1, p1}, Landroidx/camera/core/impl/Config;->getOptionPriority(Landroidx/camera/core/impl/V;)Landroidx/camera/core/impl/W;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    invoke-interface {v1, p1}, Landroidx/camera/core/impl/Config;->retrieveOption(Landroidx/camera/core/impl/V;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v0, p1, v2, v1}, Landroidx/camera/core/impl/m0;->insertOption(Landroidx/camera/core/impl/V;Landroidx/camera/core/impl/W;Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    const/4 p1, 0x1

    .line 23
    return p1
.end method

.method public onRemoveClick()V
    .locals 8

    .line 1
    const/4 v0, 0x3

    .line 2
    const/4 v1, 0x5

    .line 3
    const-wide/16 v2, 0x0

    .line 4
    .line 5
    iget-object v4, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    iget-object v6, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 9
    .line 10
    iget v7, p0, LAd/c0;->a:I

    .line 11
    .line 12
    packed-switch v7, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeRecentlyFragment;->A:I

    .line 16
    .line 17
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeRecentlyFragment;

    .line 18
    .line 19
    iget-object v1, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 20
    .line 21
    check-cast v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayHomeViewModel;

    .line 22
    .line 23
    if-eqz v1, :cond_1

    .line 24
    .line 25
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 30
    .line 31
    if-eqz v4, :cond_0

    .line 32
    .line 33
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    move-object v4, v5

    .line 39
    :goto_0
    new-instance v6, LKd/i2;

    .line 40
    .line 41
    invoke-direct {v6, v0, v4, v5}, LKd/i2;-><init>(Ljava/lang/Integer;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 42
    .line 43
    .line 44
    iget-object v0, v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayHomeViewModel;->o:Lcom/transsnet/palmpay/core/base/l;

    .line 45
    .line 46
    invoke-static {v1, v6, v0, v2, v3}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 47
    .line 48
    .line 49
    :cond_1
    return-void

    .line 50
    :pswitch_1
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeFavoriteFragment;

    .line 51
    .line 52
    iget-object v0, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 53
    .line 54
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayHomeViewModel;

    .line 55
    .line 56
    if-eqz v0, :cond_3

    .line 57
    .line 58
    const/4 v1, 0x1

    .line 59
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 64
    .line 65
    if-eqz v4, :cond_2

    .line 66
    .line 67
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v4

    .line 71
    goto :goto_1

    .line 72
    :cond_2
    move-object v4, v5

    .line 73
    :goto_1
    new-instance v6, LKd/i2;

    .line 74
    .line 75
    invoke-direct {v6, v1, v4, v5}, LKd/i2;-><init>(Ljava/lang/Integer;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 76
    .line 77
    .line 78
    iget-object v1, v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayHomeViewModel;->o:Lcom/transsnet/palmpay/core/base/l;

    .line 79
    .line 80
    invoke-static {v0, v6, v1, v2, v3}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 81
    .line 82
    .line 83
    :cond_3
    return-void

    .line 84
    :pswitch_2
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayContactFavoriteFragment;

    .line 85
    .line 86
    iget-object v0, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 87
    .line 88
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;

    .line 89
    .line 90
    if-eqz v0, :cond_5

    .line 91
    .line 92
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 93
    .line 94
    if-eqz v4, :cond_4

    .line 95
    .line 96
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    goto :goto_2

    .line 101
    :cond_4
    move-object v1, v5

    .line 102
    :goto_2
    new-instance v4, LKd/R1;

    .line 103
    .line 104
    invoke-direct {v4, v1, v5}, LKd/R1;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 105
    .line 106
    .line 107
    iget-object v1, v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;->j:Lcom/transsnet/palmpay/core/base/l;

    .line 108
    .line 109
    invoke-static {v0, v4, v1, v2, v3}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 110
    .line 111
    .line 112
    :cond_5
    return-void

    .line 113
    :pswitch_3
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayContactAllFragment;

    .line 114
    .line 115
    iget-object v0, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 116
    .line 117
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;

    .line 118
    .line 119
    if-eqz v0, :cond_7

    .line 120
    .line 121
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 122
    .line 123
    if-eqz v4, :cond_6

    .line 124
    .line 125
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v1

    .line 129
    goto :goto_3

    .line 130
    :cond_6
    move-object v1, v5

    .line 131
    :goto_3
    new-instance v4, LKd/R1;

    .line 132
    .line 133
    invoke-direct {v4, v1, v5}, LKd/R1;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 134
    .line 135
    .line 136
    iget-object v1, v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;->j:Lcom/transsnet/palmpay/core/base/l;

    .line 137
    .line 138
    invoke-static {v0, v4, v1, v2, v3}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 139
    .line 140
    .line 141
    :cond_7
    return-void

    .line 142
    :pswitch_4
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomePalmPayContactsFragment;

    .line 143
    .line 144
    iget-object v1, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 145
    .line 146
    check-cast v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayHomeViewModel;

    .line 147
    .line 148
    if-eqz v1, :cond_9

    .line 149
    .line 150
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 155
    .line 156
    if-eqz v4, :cond_8

    .line 157
    .line 158
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v4

    .line 162
    goto :goto_4

    .line 163
    :cond_8
    move-object v4, v5

    .line 164
    :goto_4
    new-instance v6, LKd/i2;

    .line 165
    .line 166
    invoke-direct {v6, v0, v4, v5}, LKd/i2;-><init>(Ljava/lang/Integer;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 167
    .line 168
    .line 169
    iget-object v0, v1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayHomeViewModel;->o:Lcom/transsnet/palmpay/core/base/l;

    .line 170
    .line 171
    invoke-static {v1, v6, v0, v2, v3}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 172
    .line 173
    .line 174
    :cond_9
    return-void

    .line 175
    :pswitch_5
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomeFavoriteFragment;

    .line 176
    .line 177
    iget-object v0, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 178
    .line 179
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 180
    .line 181
    if-eqz v0, :cond_b

    .line 182
    .line 183
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 184
    .line 185
    .line 186
    move-result-object v1

    .line 187
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 188
    .line 189
    if-eqz v4, :cond_a

    .line 190
    .line 191
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v5

    .line 195
    :cond_a
    invoke-virtual {v0, v1, v5}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->j(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    :cond_b
    return-void

    .line 199
    :pswitch_6
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomeBeneficiariesFragment;

    .line 200
    .line 201
    iget-object v0, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 202
    .line 203
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 204
    .line 205
    if-eqz v0, :cond_d

    .line 206
    .line 207
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 212
    .line 213
    if-eqz v4, :cond_c

    .line 214
    .line 215
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v5

    .line 219
    :cond_c
    invoke-virtual {v0, v1, v5}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->j(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    :cond_d
    return-void

    .line 223
    :pswitch_7
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountPalmPayContactFragment;

    .line 224
    .line 225
    iget-object v0, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 226
    .line 227
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;

    .line 228
    .line 229
    if-eqz v0, :cond_f

    .line 230
    .line 231
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;

    .line 232
    .line 233
    if-eqz v4, :cond_e

    .line 234
    .line 235
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientBeanV2;->getRelationId()Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    goto :goto_5

    .line 240
    :cond_e
    move-object v1, v5

    .line 241
    :goto_5
    new-instance v4, LKd/R1;

    .line 242
    .line 243
    invoke-direct {v4, v1, v5}, LKd/R1;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 244
    .line 245
    .line 246
    iget-object v1, v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToPalmPayContactViewModel;->j:Lcom/transsnet/palmpay/core/base/l;

    .line 247
    .line 248
    invoke-static {v0, v4, v1, v2, v3}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 249
    .line 250
    .line 251
    :cond_f
    return-void

    .line 252
    :pswitch_8
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;

    .line 253
    .line 254
    iget-object v0, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 255
    .line 256
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 257
    .line 258
    if-eqz v0, :cond_11

    .line 259
    .line 260
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 261
    .line 262
    .line 263
    move-result-object v1

    .line 264
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 265
    .line 266
    if-eqz v4, :cond_10

    .line 267
    .line 268
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 269
    .line 270
    .line 271
    move-result-object v5

    .line 272
    :cond_10
    invoke-virtual {v0, v1, v5}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->j(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    :cond_11
    return-void

    .line 276
    :pswitch_9
    check-cast v6, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;

    .line 277
    .line 278
    iget-object v0, v6, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 279
    .line 280
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 281
    .line 282
    if-eqz v0, :cond_13

    .line 283
    .line 284
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 285
    .line 286
    .line 287
    move-result-object v1

    .line 288
    check-cast v4, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 289
    .line 290
    if-eqz v4, :cond_12

    .line 291
    .line 292
    invoke-virtual {v4}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientId()Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object v5

    .line 296
    :cond_12
    invoke-virtual {v0, v1, v5}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->j(Ljava/lang/Integer;Ljava/lang/String;)V

    .line 297
    .line 298
    .line 299
    :cond_13
    return-void

    .line 300
    nop

    .line 301
    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_9
        :pswitch_0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public onSend(IILjava/lang/String;)V
    .locals 3

    .line 1
    sget p1, Lcom/transsnet/palmpay/account/ui/activity/AuthenticationOtpActivity;->f:I

    .line 2
    .line 3
    iget-object p1, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p1, Lcom/transsnet/palmpay/account/ui/activity/AuthenticationOtpActivity;

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    check-cast p1, Lcom/transsnet/palmpay/account/ui/viewmodel/VerifyRegisterInfoViewModel;

    .line 12
    .line 13
    iget-object p2, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p2, Lkotlin/jvm/internal/F;

    .line 16
    .line 17
    iget-object p2, p2, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p2, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;

    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    const-string p3, "req"

    .line 25
    .line 26
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    new-instance p3, Lg9/d0;

    .line 30
    .line 31
    const/4 v0, 0x0

    .line 32
    invoke-direct {p3, p2, v0}, Lg9/d0;-><init>(Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;Lkotlin/coroutines/Continuation;)V

    .line 33
    .line 34
    .line 35
    iget-object v0, p1, Lcom/transsnet/palmpay/account/ui/viewmodel/VerifyRegisterInfoViewModel;->f:Lcom/transsnet/palmpay/core/base/l;

    .line 36
    .line 37
    iput-object p2, v0, Lcom/transsnet/palmpay/core/base/l;->m:Ljava/lang/Object;

    .line 38
    .line 39
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 40
    .line 41
    const-wide/16 v1, 0x0

    .line 42
    .line 43
    invoke-static {p1, p3, v0, v1, v2}, Lj8/f;->v(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;J)LWf/t0;

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public subscribe(Lio/reactivex/ObservableEmitter;)V
    .locals 9

    .line 1
    const-string v0, "emitter"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, LAd/c0;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;

    .line 14
    .line 15
    iget-object v1, v1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;->H:Ljava/util/List;

    .line 16
    .line 17
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    if-eqz v2, :cond_5

    .line 26
    .line 27
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    check-cast v2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 32
    .line 33
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientAccountNumber()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    iget-object v4, p0, LAd/c0;->c:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v4, Ljava/lang/String;

    .line 44
    .line 45
    const/4 v5, 0x0

    .line 46
    const-string v6, "toUpperCase(...)"

    .line 47
    .line 48
    if-nez v3, :cond_1

    .line 49
    .line 50
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientAccountNumber()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    const-string v7, "getRecipientAccountNumber(...)"

    .line 55
    .line 56
    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 60
    .line 61
    invoke-virtual {v3, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v3

    .line 65
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v4, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-static {v3, v7, v5}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 76
    .line 77
    .line 78
    move-result v3

    .line 79
    if-nez v3, :cond_4

    .line 80
    .line 81
    :cond_1
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientBankName()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 86
    .line 87
    .line 88
    move-result v3

    .line 89
    if-nez v3, :cond_2

    .line 90
    .line 91
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientBankName()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    const-string v7, "getRecipientBankName(...)"

    .line 96
    .line 97
    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 101
    .line 102
    invoke-virtual {v3, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v4, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v7

    .line 113
    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    invoke-static {v3, v7, v5}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 117
    .line 118
    .line 119
    move-result v3

    .line 120
    if-nez v3, :cond_4

    .line 121
    .line 122
    :cond_2
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientNickname()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 127
    .line 128
    .line 129
    move-result v3

    .line 130
    if-nez v3, :cond_3

    .line 131
    .line 132
    invoke-virtual {v2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientNickname()Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v3

    .line 136
    const-string v7, "getRecipientNickname(...)"

    .line 137
    .line 138
    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 142
    .line 143
    invoke-virtual {v3, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v3

    .line 147
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v4, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v7

    .line 154
    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    invoke-static {v3, v7, v5}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 158
    .line 159
    .line 160
    move-result v3

    .line 161
    if-nez v3, :cond_4

    .line 162
    .line 163
    :cond_3
    iget-object v3, v2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->accountNo:Ljava/lang/String;

    .line 164
    .line 165
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 166
    .line 167
    .line 168
    move-result v3

    .line 169
    if-nez v3, :cond_0

    .line 170
    .line 171
    iget-object v3, v2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->accountNo:Ljava/lang/String;

    .line 172
    .line 173
    if-eqz v3, :cond_0

    .line 174
    .line 175
    const-string v7, "getDefault(...)"

    .line 176
    .line 177
    invoke-static {v7, v3, v6}, Lcom/airbnb/lottie/model/layer/d;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v3

    .line 181
    if-eqz v3, :cond_0

    .line 182
    .line 183
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 184
    .line 185
    .line 186
    move-result-object v8

    .line 187
    invoke-static {v8, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    invoke-virtual {v4, v8}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v4

    .line 194
    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    invoke-static {v3, v4, v5}, Lkotlin/text/StringsKt;->A(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    .line 198
    .line 199
    .line 200
    move-result v3

    .line 201
    const/4 v4, 0x1

    .line 202
    if-ne v3, v4, :cond_0

    .line 203
    .line 204
    :cond_4
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 205
    .line 206
    .line 207
    goto/16 :goto_0

    .line 208
    .line 209
    :cond_5
    invoke-interface {p1, v0}, Lio/reactivex/Emitter;->onNext(Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    invoke-interface {p1}, Lio/reactivex/Emitter;->onComplete()V

    .line 213
    .line 214
    .line 215
    return-void
.end method
