.class public final synthetic LAd/F;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:LAd/H;


# direct methods
.method public synthetic constructor <init>(LAd/H;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/F;->a:I

    iput-object p1, p0, LAd/F;->b:LAd/H;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 1
    iget p1, p0, LAd/F;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LAd/F;->b:LAd/H;

    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    const-string v0, "TransferSavingPopup_saveclick"

    .line 12
    .line 13
    invoke-static {v0}, LAd/H;->b(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p1, LAd/H;->g:Lxd/C;

    .line 17
    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-virtual {v0}, Lxd/C;->onSaveToCashBox()V

    .line 21
    .line 22
    .line 23
    :cond_0
    invoke-virtual {p1}, Landroidx/appcompat/app/K;->dismiss()V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :pswitch_0
    iget-object p1, p0, LAd/F;->b:LAd/H;

    .line 28
    .line 29
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    const-string v0, "TransferSavingPopup_transferclick"

    .line 33
    .line 34
    invoke-static {v0}, LAd/H;->b(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    iget-object v0, p1, LAd/H;->g:Lxd/C;

    .line 38
    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    invoke-virtual {v0}, Lxd/C;->onTransfer()V

    .line 42
    .line 43
    .line 44
    :cond_1
    invoke-virtual {p1}, Landroidx/appcompat/app/K;->dismiss()V

    .line 45
    .line 46
    .line 47
    return-void

    .line 48
    :pswitch_1
    iget-object p1, p0, LAd/F;->b:LAd/H;

    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    const-string v0, "TransferSavingPopup_closeclick"

    .line 54
    .line 55
    invoke-static {v0}, LAd/H;->b(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p1}, Landroidx/appcompat/app/K;->dismiss()V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    nop

    .line 63
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
