.class public final LAd/H;
.super Lcom/transsnet/palmpay/custom_view/dialog/a;
.source "SourceFile"


# static fields
.field public static final i:LAd/G;


# instance fields
.field public b:Landroid/widget/TextView;

.field public c:Landroid/widget/TextView;

.field public d:Landroid/widget/ImageView;

.field public e:Landroid/widget/TextView;

.field public f:Landroid/widget/TextView;

.field public g:Lxd/C;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LAd/G;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LAd/G;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LAd/H;->i:LAd/G;

    .line 8
    .line 9
    return-void
.end method

.method public static b(Ljava/lang/String;)V
    .locals 2

    .line 1
    new-instance v0, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p0}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    if-eqz p0, :cond_0

    .line 15
    .line 16
    invoke-virtual {p0}, Lcom/transsnet/palmpay/core/db/entity/User;->getMemberId()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 p0, 0x0

    .line 22
    :goto_0
    const-string v1, "memberId"

    .line 23
    .line 24
    invoke-virtual {v0, v1, p0}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    check-cast p0, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 29
    .line 30
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v0, p0}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final show()V
    .locals 4

    .line 1
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->get()Lcom/transsnet/palmpay/util/SPUtils;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, LAd/H;->i:LAd/G;

    .line 6
    .line 7
    invoke-static {v1}, LAd/G;->access$todayString(LAd/G;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const-string v2, "finance_guidance_last_day"

    .line 12
    .line 13
    invoke-virtual {v0, v2, v1}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->get()Lcom/transsnet/palmpay/util/SPUtils;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const-string v1, "finance_guidance_week_count"

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    invoke-virtual {v0, v1, v2}, Lcom/transsnet/palmpay/util/SPUtils;->getInt(Ljava/lang/String;I)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    const/4 v2, 0x3

    .line 28
    if-ge v0, v2, :cond_0

    .line 29
    .line 30
    invoke-static {}, Lcom/transsnet/palmpay/util/SPUtils;->get()Lcom/transsnet/palmpay/util/SPUtils;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    add-int/lit8 v0, v0, 0x1

    .line 35
    .line 36
    invoke-virtual {v2, v1, v0}, Lcom/transsnet/palmpay/util/SPUtils;->put(Ljava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    :cond_0
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    new-instance v1, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;

    .line 44
    .line 45
    const-string v2, "TransferSavingPopup_view"

    .line 46
    .line 47
    invoke-direct {v1, v2}, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getUser()Lcom/transsnet/palmpay/core/db/entity/User;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    if-eqz v2, :cond_1

    .line 59
    .line 60
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/db/entity/User;->getMemberId()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    goto :goto_0

    .line 65
    :cond_1
    const/4 v2, 0x0

    .line 66
    :goto_0
    const-string v3, "memberId"

    .line 67
    .line 68
    invoke-virtual {v1, v3, v2}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    check-cast v1, Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;

    .line 73
    .line 74
    invoke-virtual {v0, v1}, LPa/n0;->u(Lcom/transsnet/palmpay/core/util/statistic/ViewEvent;)V

    .line 75
    .line 76
    .line 77
    invoke-super {p0}, Lcom/transsnet/palmpay/custom_view/dialog/a;->show()V

    .line 78
    .line 79
    .line 80
    return-void
.end method
