.class public final LAd/L;
.super LZb/a;
.source "SourceFile"


# instance fields
.field public final synthetic f:I

.field public g:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>()V
    .locals 1

    .line 1
    const/4 v0, 0x3

    iput v0, p0, LAd/L;->f:I

    invoke-direct {p0}, LZb/a;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .locals 0

    iput p2, p0, LAd/L;->f:I

    packed-switch p2, :pswitch_data_0

    const-string p2, "context"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-direct {p0}, LZb/a;-><init>()V

    .line 4
    iput-object p1, p0, LAd/L;->g:Landroid/content/Context;

    return-void

    .line 5
    :pswitch_0
    const-string p2, "context"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    invoke-direct {p0}, LZb/a;-><init>()V

    .line 7
    iput-object p1, p0, LAd/L;->g:Landroid/content/Context;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public synthetic constructor <init>(Landroid/content/Context;IZ)V
    .locals 0

    .line 2
    iput p2, p0, LAd/L;->f:I

    invoke-direct {p0}, LZb/a;-><init>()V

    iput-object p1, p0, LAd/L;->g:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final a(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 4

    .line 1
    iget v0, p0, LAd/L;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    if-nez p2, :cond_0

    .line 7
    .line 8
    new-instance p2, LNc/i;

    .line 9
    .line 10
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    iget-object p3, p0, LAd/L;->g:Landroid/content/Context;

    .line 14
    .line 15
    invoke-static {p3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 16
    .line 17
    .line 18
    move-result-object p3

    .line 19
    sget v0, LJc/d;->mm_state_pick_item:I

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    invoke-virtual {p3, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 23
    .line 24
    .line 25
    move-result-object p3

    .line 26
    sget v0, LJc/c;->item_name:I

    .line 27
    .line 28
    invoke-virtual {p3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Landroid/widget/TextView;

    .line 33
    .line 34
    iput-object v0, p2, LNc/i;->a:Landroid/widget/TextView;

    .line 35
    .line 36
    invoke-virtual {p3, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    .line 40
    .line 41
    const/high16 v1, 0x42100000    # 36.0f

    .line 42
    .line 43
    invoke-static {v1}, Lcom/scwang/smartrefresh/layout/util/DensityUtil;->dp2px(F)I

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    const/4 v2, -0x1

    .line 48
    invoke-direct {v0, v2, v1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p3, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 52
    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_0
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p3

    .line 59
    check-cast p3, LNc/i;

    .line 60
    .line 61
    move-object v3, p3

    .line 62
    move-object p3, p2

    .line 63
    move-object p2, v3

    .line 64
    :goto_0
    iget-object p2, p2, LNc/i;->a:Landroid/widget/TextView;

    .line 65
    .line 66
    iget-object v0, p0, LZb/a;->a:Ljava/util/List;

    .line 67
    .line 68
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    check-cast p1, Ljava/lang/CharSequence;

    .line 73
    .line 74
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 75
    .line 76
    .line 77
    return-object p3

    .line 78
    :pswitch_0
    if-nez p2, :cond_1

    .line 79
    .line 80
    new-instance p2, LKb/i;

    .line 81
    .line 82
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 83
    .line 84
    .line 85
    iget-object p3, p0, LAd/L;->g:Landroid/content/Context;

    .line 86
    .line 87
    invoke-static {p3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 88
    .line 89
    .line 90
    move-result-object p3

    .line 91
    sget v0, Lcom/transsnet/palmpay/custom_view/t;->cv_state_pick_item:I

    .line 92
    .line 93
    const/4 v1, 0x0

    .line 94
    invoke-virtual {p3, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 95
    .line 96
    .line 97
    move-result-object p3

    .line 98
    sget v0, Lcom/transsnet/palmpay/custom_view/s;->item_name:I

    .line 99
    .line 100
    invoke-virtual {p3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    check-cast v0, Landroid/widget/TextView;

    .line 105
    .line 106
    iput-object v0, p2, LKb/i;->a:Landroid/widget/TextView;

    .line 107
    .line 108
    invoke-virtual {p3, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    goto :goto_1

    .line 112
    :cond_1
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object p3

    .line 116
    check-cast p3, LKb/i;

    .line 117
    .line 118
    move-object v3, p3

    .line 119
    move-object p3, p2

    .line 120
    move-object p2, v3

    .line 121
    :goto_1
    iget-object p2, p2, LKb/i;->a:Landroid/widget/TextView;

    .line 122
    .line 123
    iget-object v0, p0, LZb/a;->a:Ljava/util/List;

    .line 124
    .line 125
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object p1

    .line 133
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 134
    .line 135
    .line 136
    return-object p3

    .line 137
    :pswitch_1
    if-nez p2, :cond_2

    .line 138
    .line 139
    new-instance p2, LKb/e;

    .line 140
    .line 141
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 142
    .line 143
    .line 144
    iget-object p3, p0, LAd/L;->g:Landroid/content/Context;

    .line 145
    .line 146
    invoke-static {p3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 147
    .line 148
    .line 149
    move-result-object p3

    .line 150
    sget v0, Lcom/transsnet/palmpay/custom_view/t;->cv_item_pick_time:I

    .line 151
    .line 152
    const/4 v1, 0x0

    .line 153
    invoke-virtual {p3, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 154
    .line 155
    .line 156
    move-result-object p3

    .line 157
    sget v0, Lcom/transsnet/palmpay/custom_view/s;->item_name:I

    .line 158
    .line 159
    invoke-virtual {p3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    check-cast v0, Landroid/widget/TextView;

    .line 164
    .line 165
    iput-object v0, p2, LKb/e;->a:Landroid/widget/TextView;

    .line 166
    .line 167
    invoke-virtual {p3, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    goto :goto_2

    .line 171
    :cond_2
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object p3

    .line 175
    check-cast p3, LKb/e;

    .line 176
    .line 177
    move-object v3, p3

    .line 178
    move-object p3, p2

    .line 179
    move-object p2, v3

    .line 180
    :goto_2
    iget-object p2, p2, LKb/e;->a:Landroid/widget/TextView;

    .line 181
    .line 182
    iget-object v0, p0, LZb/a;->a:Ljava/util/List;

    .line 183
    .line 184
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object p1

    .line 188
    check-cast p1, Ljava/lang/CharSequence;

    .line 189
    .line 190
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 191
    .line 192
    .line 193
    return-object p3

    .line 194
    :pswitch_2
    const-string v0, "parent"

    .line 195
    .line 196
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    if-nez p2, :cond_3

    .line 200
    .line 201
    new-instance p2, LAd/e0;

    .line 202
    .line 203
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 204
    .line 205
    .line 206
    iget-object p3, p0, LAd/L;->g:Landroid/content/Context;

    .line 207
    .line 208
    invoke-static {p3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 209
    .line 210
    .line 211
    move-result-object p3

    .line 212
    sget v0, Lcom/transsnet/palmpay/custom_view/t;->cv_item_pick_time:I

    .line 213
    .line 214
    const/4 v1, 0x0

    .line 215
    invoke-virtual {p3, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 216
    .line 217
    .line 218
    move-result-object p3

    .line 219
    sget v0, Lcom/transsnet/palmpay/custom_view/s;->item_name:I

    .line 220
    .line 221
    invoke-virtual {p3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 222
    .line 223
    .line 224
    move-result-object v0

    .line 225
    const-string v1, "null cannot be cast to non-null type android.widget.TextView"

    .line 226
    .line 227
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    check-cast v0, Landroid/widget/TextView;

    .line 231
    .line 232
    iput-object v0, p2, LAd/e0;->a:Landroid/widget/TextView;

    .line 233
    .line 234
    invoke-virtual {p3, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 235
    .line 236
    .line 237
    goto :goto_3

    .line 238
    :cond_3
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    move-result-object p3

    .line 242
    const-string v0, "null cannot be cast to non-null type com.transsnet.palmpay.send_money.ui.dialog.WeekDayPickerDialog.ScheduleWeekWheelAdapter.ViewHolder"

    .line 243
    .line 244
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    check-cast p3, LAd/e0;

    .line 248
    .line 249
    move-object v3, p3

    .line 250
    move-object p3, p2

    .line 251
    move-object p2, v3

    .line 252
    :goto_3
    iget-object v0, p0, LZb/a;->a:Ljava/util/List;

    .line 253
    .line 254
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object p1

    .line 258
    check-cast p1, LAd/f0;

    .line 259
    .line 260
    iget-object p2, p2, LAd/e0;->a:Landroid/widget/TextView;

    .line 261
    .line 262
    if-eqz p2, :cond_4

    .line 263
    .line 264
    iget-object p1, p1, LAd/f0;->a:Ljava/lang/String;

    .line 265
    .line 266
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 267
    .line 268
    .line 269
    :cond_4
    return-object p3

    .line 270
    :pswitch_3
    const-string v0, "parent"

    .line 271
    .line 272
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    if-nez p2, :cond_5

    .line 276
    .line 277
    new-instance p2, LAd/K;

    .line 278
    .line 279
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 280
    .line 281
    .line 282
    iget-object p3, p0, LAd/L;->g:Landroid/content/Context;

    .line 283
    .line 284
    invoke-static {p3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 285
    .line 286
    .line 287
    move-result-object p3

    .line 288
    sget v0, Lcom/transsnet/palmpay/custom_view/t;->cv_item_pick_time:I

    .line 289
    .line 290
    const/4 v1, 0x0

    .line 291
    invoke-virtual {p3, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 292
    .line 293
    .line 294
    move-result-object p3

    .line 295
    sget v0, Lcom/transsnet/palmpay/custom_view/s;->item_name:I

    .line 296
    .line 297
    invoke-virtual {p3, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    const-string v1, "null cannot be cast to non-null type android.widget.TextView"

    .line 302
    .line 303
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    check-cast v0, Landroid/widget/TextView;

    .line 307
    .line 308
    iput-object v0, p2, LAd/K;->a:Landroid/widget/TextView;

    .line 309
    .line 310
    invoke-virtual {p3, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 311
    .line 312
    .line 313
    goto :goto_4

    .line 314
    :cond_5
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 315
    .line 316
    .line 317
    move-result-object p3

    .line 318
    const-string v0, "null cannot be cast to non-null type com.transsnet.palmpay.send_money.ui.dialog.FrequencyPickerDialog.ScheduleWheelAdapter.ViewHolder"

    .line 319
    .line 320
    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 321
    .line 322
    .line 323
    check-cast p3, LAd/K;

    .line 324
    .line 325
    move-object v3, p3

    .line 326
    move-object p3, p2

    .line 327
    move-object p2, v3

    .line 328
    :goto_4
    iget-object v0, p0, LZb/a;->a:Ljava/util/List;

    .line 329
    .line 330
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object p1

    .line 334
    check-cast p1, LJd/a;

    .line 335
    .line 336
    iget-object p2, p2, LAd/K;->a:Landroid/widget/TextView;

    .line 337
    .line 338
    if-eqz p2, :cond_7

    .line 339
    .line 340
    iget v0, p1, LJd/a;->a:I

    .line 341
    .line 342
    if-lez v0, :cond_6

    .line 343
    .line 344
    iget-object p1, p1, LJd/a;->b:Ljava/lang/String;

    .line 345
    .line 346
    new-instance v1, Ljava/lang/StringBuilder;

    .line 347
    .line 348
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 349
    .line 350
    .line 351
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 352
    .line 353
    .line 354
    const-string p1, ", "

    .line 355
    .line 356
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 357
    .line 358
    .line 359
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 360
    .line 361
    .line 362
    const-string p1, " times in total"

    .line 363
    .line 364
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 365
    .line 366
    .line 367
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 368
    .line 369
    .line 370
    move-result-object p1

    .line 371
    goto :goto_5

    .line 372
    :cond_6
    const-string p1, "No End"

    .line 373
    .line 374
    :goto_5
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 375
    .line 376
    .line 377
    :cond_7
    return-object p3

    .line 378
    nop

    .line 379
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
