.class public final synthetic LAd/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/l;->a:I

    iput-object p1, p0, LAd/l;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/l;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/l;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;->d(Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;)Landroid/view/View;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/l;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;)Lcom/mikepenz/iconics/view/IconicsImageView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LAd/l;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;)Landroid/widget/Button;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, LAd/l;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/AddShortcutDialog;)Landroid/widget/Button;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
