.class public final synthetic LAd/I;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/I;->a:I

    iput-object p1, p0, LAd/I;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/I;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/I;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/I;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/FrequencyPickerDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
