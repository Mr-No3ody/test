.class public final LAd/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/material/tabs/TabLayout$OnTabSelectedListener;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

.field public final synthetic b:Landroidx/recyclerview/widget/RecyclerView;

.field public final synthetic c:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAd/h;->a:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    .line 5
    .line 6
    iput-object p2, p0, LAd/h;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 7
    .line 8
    iput-object p3, p0, LAd/h;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final onTabReselected(Lcom/google/android/material/tabs/TabLayout$Tab;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final onTabSelected(Lcom/google/android/material/tabs/TabLayout$Tab;)V
    .locals 5

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    invoke-virtual {p1}, Lcom/google/android/material/tabs/TabLayout$Tab;->getPosition()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget-object v1, p0, LAd/h;->a:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    .line 8
    .line 9
    invoke-static {v1, v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->access$setTabCurrentPosition$p(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;I)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p1}, Lcom/google/android/material/tabs/TabLayout$Tab;->getPosition()I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    const/4 v0, 0x0

    .line 17
    const/4 v2, 0x1

    .line 18
    iget-object v3, p0, LAd/h;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 19
    .line 20
    iget-object v4, p0, LAd/h;->c:Landroidx/recyclerview/widget/RecyclerView;

    .line 21
    .line 22
    if-nez p1, :cond_1

    .line 23
    .line 24
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    invoke-static {v3}, Loa/h;->C(Landroid/view/View;)V

    .line 28
    .line 29
    .line 30
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    invoke-static {v4}, Loa/h;->c(Landroid/view/View;)V

    .line 34
    .line 35
    .line 36
    invoke-static {v1}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->access$getBtnAddNow$p(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;)Landroid/widget/TextView;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    if-eqz p1, :cond_3

    .line 41
    .line 42
    invoke-static {v1}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->access$getSelectRecent$p(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;)Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    if-eqz v1, :cond_0

    .line 47
    .line 48
    move v0, v2

    .line 49
    :cond_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_1
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-static {v3}, Loa/h;->c(Landroid/view/View;)V

    .line 57
    .line 58
    .line 59
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    invoke-static {v4}, Loa/h;->C(Landroid/view/View;)V

    .line 63
    .line 64
    .line 65
    invoke-static {v1}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->access$getBtnAddNow$p(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;)Landroid/widget/TextView;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    if-eqz p1, :cond_3

    .line 70
    .line 71
    invoke-static {v1}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->access$getSelectPhoneContact$p(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;)Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    if-eqz v1, :cond_2

    .line 76
    .line 77
    move v0, v2

    .line 78
    :cond_2
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 79
    .line 80
    .line 81
    :cond_3
    return-void
.end method

.method public final onTabUnselected(Lcom/google/android/material/tabs/TabLayout$Tab;)V
    .locals 0

    .line 1
    return-void
.end method
