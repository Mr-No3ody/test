.class public final synthetic LAd/V;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILcom/transsnet/palmpay/managemoney/ui/activity/UserFixedSavingTabFragment;)V
    .locals 1

    .line 1
    const/4 v0, 0x6

    iput v0, p0, LAd/V;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LAd/V;->b:I

    iput-object p2, p0, LAd/V;->c:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;II)V
    .locals 0

    .line 2
    iput p3, p0, LAd/V;->a:I

    iput-object p1, p0, LAd/V;->c:Ljava/lang/Object;

    iput p2, p0, LAd/V;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 7

    .line 1
    const/4 p1, 0x0

    .line 2
    const/4 v0, 0x0

    .line 3
    const/4 v1, 0x1

    .line 4
    iget v2, p0, LAd/V;->b:I

    .line 5
    .line 6
    iget-object v3, p0, LAd/V;->c:Ljava/lang/Object;

    .line 7
    .line 8
    iget v4, p0, LAd/V;->a:I

    .line 9
    .line 10
    packed-switch v4, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    sget p1, Lcom/transsnet/palmpay/betting/ui/view/ModelBillerSelection;->g:I

    .line 14
    .line 15
    check-cast v3, Lcom/transsnet/palmpay/betting/ui/view/ModelBillerSelection;

    .line 16
    .line 17
    invoke-virtual {v3, v2, v1}, Lcom/transsnet/palmpay/betting/ui/view/ModelBillerSelection;->d(IZ)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :pswitch_0
    check-cast v3, Lve/c;

    .line 22
    .line 23
    iget-object p1, v3, Lve/c;->d:Ljava/lang/Object;

    .line 24
    .line 25
    if-eqz p1, :cond_0

    .line 26
    .line 27
    iget-object v0, v3, Lve/c;->b:Ljava/util/List;

    .line 28
    .line 29
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/ui/adapter/BankCardAndAccountAdapter$OnClickListener;->onUnbindClick(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    return-void

    .line 37
    :pswitch_1
    check-cast v3, Lda/D;

    .line 38
    .line 39
    iget-object p1, v3, Lda/D;->b:Lcom/transsnet/palmpay/core/ui/activity/CoreCommentActivity;

    .line 40
    .line 41
    invoke-virtual {p1, v2}, Lcom/transsnet/palmpay/core/ui/activity/CoreCommentActivity;->closeShareImg(I)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :pswitch_2
    sget-object p1, Lcom/transsnet/palmpay/managemoney/ui/activity/UserFixedSavingTabFragment;->w:Lcom/transsnet/palmpay/managemoney/ui/activity/UserFixedSavingTabFragment$a;

    .line 46
    .line 47
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    if-nez v2, :cond_1

    .line 52
    .line 53
    const-string v0, "FixedPlansPage_MyPlansTab_Click"

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_1
    const-string v0, "MyPlansPage_FixedPlansTab_Click"

    .line 57
    .line 58
    :goto_0
    invoke-virtual {p1, v0}, LPa/n0;->l(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    check-cast v3, Lcom/transsnet/palmpay/managemoney/ui/activity/UserFixedSavingTabFragment;

    .line 62
    .line 63
    invoke-virtual {v3, v2}, Lcom/transsnet/palmpay/managemoney/ui/activity/UserFixedSavingTabFragment;->x(I)V

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :pswitch_3
    sget v4, Lcom/transsnet/palmpay/managemoney/ui/activity/CreatePlanActivity;->M:I

    .line 68
    .line 69
    check-cast v3, Lcom/transsnet/palmpay/managemoney/ui/activity/CreatePlanActivity;

    .line 70
    .line 71
    invoke-virtual {v3}, Lcom/transsnet/palmpay/core/base/BaseMvvmActivity;->l()Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    check-cast v3, Lcom/transsnet/palmpay/managemoney/ui/viewmodel/CreatePlanViewModel;

    .line 76
    .line 77
    if-eqz v3, :cond_3

    .line 78
    .line 79
    if-nez v2, :cond_2

    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_2
    move v1, p1

    .line 83
    :goto_1
    new-instance v2, LQc/T;

    .line 84
    .line 85
    invoke-direct {v2, v1, v0}, LQc/T;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 86
    .line 87
    .line 88
    iget-object v0, v3, Lcom/transsnet/palmpay/managemoney/ui/viewmodel/CreatePlanViewModel;->i:Lcom/transsnet/palmpay/core/base/l;

    .line 89
    .line 90
    const/16 v1, 0x1c

    .line 91
    .line 92
    invoke-static {v3, v2, v0, p1, v1}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 93
    .line 94
    .line 95
    :cond_3
    return-void

    .line 96
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->q0:I

    .line 97
    .line 98
    check-cast v3, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;

    .line 99
    .line 100
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->z()Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;->g:Landroidx/lifecycle/F;

    .line 105
    .line 106
    invoke-virtual {v1}, Landroidx/lifecycle/B;->d()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    instance-of v4, v1, LJb/G;

    .line 111
    .line 112
    if-eqz v4, :cond_4

    .line 113
    .line 114
    check-cast v1, LJb/G;

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_4
    move-object v1, v0

    .line 118
    :goto_2
    if-nez v1, :cond_5

    .line 119
    .line 120
    goto/16 :goto_a

    .line 121
    .line 122
    :cond_5
    iget v1, v1, LJb/G;->d:I

    .line 123
    .line 124
    if-ne v2, v1, :cond_6

    .line 125
    .line 126
    goto/16 :goto_a

    .line 127
    .line 128
    :cond_6
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->z()Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;->f:Landroidx/lifecycle/F;

    .line 133
    .line 134
    invoke-virtual {v1}, Landroidx/lifecycle/B;->d()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v4

    .line 138
    instance-of v5, v4, LJb/G;

    .line 139
    .line 140
    if-eqz v5, :cond_7

    .line 141
    .line 142
    check-cast v4, LJb/G;

    .line 143
    .line 144
    goto :goto_3

    .line 145
    :cond_7
    move-object v4, v0

    .line 146
    :goto_3
    if-nez v4, :cond_8

    .line 147
    .line 148
    goto :goto_4

    .line 149
    :cond_8
    if-ltz v2, :cond_a

    .line 150
    .line 151
    iget-object v5, v4, LJb/G;->c:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast v5, Ljava/util/Collection;

    .line 154
    .line 155
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    .line 156
    .line 157
    .line 158
    move-result v5

    .line 159
    if-ge v2, v5, :cond_a

    .line 160
    .line 161
    iget v5, v4, LJb/G;->d:I

    .line 162
    .line 163
    if-ne v2, v5, :cond_9

    .line 164
    .line 165
    goto :goto_4

    .line 166
    :cond_9
    const/16 v5, 0x17

    .line 167
    .line 168
    invoke-static {v4, v2, p1, v5}, LJb/G;->a(LJb/G;IZI)LJb/G;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    invoke-virtual {v1, v2}, Landroidx/lifecycle/B;->k(Ljava/lang/Object;)V

    .line 173
    .line 174
    .line 175
    :cond_a
    :goto_4
    invoke-virtual {v3}, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->z()Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    iget-object v1, v1, Lcom/transsnet/palmpay/credit/viewmodel/TransferByLoanViewModel;->f:Landroidx/lifecycle/F;

    .line 180
    .line 181
    invoke-virtual {v1}, Landroidx/lifecycle/B;->d()Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v1

    .line 185
    instance-of v2, v1, LJb/G;

    .line 186
    .line 187
    if-eqz v2, :cond_b

    .line 188
    .line 189
    check-cast v1, LJb/G;

    .line 190
    .line 191
    goto :goto_5

    .line 192
    :cond_b
    move-object v1, v0

    .line 193
    :goto_5
    if-nez v1, :cond_c

    .line 194
    .line 195
    move-object v1, v0

    .line 196
    goto :goto_6

    .line 197
    :cond_c
    iget-object v2, v1, LJb/G;->c:Ljava/lang/Object;

    .line 198
    .line 199
    iget v1, v1, LJb/G;->d:I

    .line 200
    .line 201
    invoke-static {v1, v2}, Lkotlin/collections/CollectionsKt;->G(ILjava/util/List;)Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object v1

    .line 205
    check-cast v1, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;

    .line 206
    .line 207
    :goto_6
    if-eqz v1, :cond_16

    .line 208
    .line 209
    iget-object v2, v3, Lcom/transsnet/palmpay/credit/ui/dialog/TransferByLoanSheet;->j:Lcom/transsnet/palmpay/core/bean/TransferByLoanOpenParams;

    .line 210
    .line 211
    if-eqz v2, :cond_15

    .line 212
    .line 213
    invoke-virtual {v2}, Lcom/transsnet/palmpay/core/bean/TransferByLoanOpenParams;->getLoanAmount()J

    .line 214
    .line 215
    .line 216
    move-result-wide v2

    .line 217
    const-string v0, "plan"

    .line 218
    .line 219
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getId()Ljava/lang/Integer;

    .line 227
    .line 228
    .line 229
    move-result-object v4

    .line 230
    if-eqz v4, :cond_d

    .line 231
    .line 232
    invoke-virtual {v4}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    .line 233
    .line 234
    .line 235
    move-result-object v4

    .line 236
    if-nez v4, :cond_11

    .line 237
    .line 238
    :cond_d
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getProductSubId()Ljava/lang/Integer;

    .line 239
    .line 240
    .line 241
    move-result-object v4

    .line 242
    if-eqz v4, :cond_e

    .line 243
    .line 244
    invoke-virtual {v4}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v4

    .line 248
    goto :goto_9

    .line 249
    :cond_e
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getLoanDays()Ljava/lang/Integer;

    .line 250
    .line 251
    .line 252
    move-result-object v4

    .line 253
    if-eqz v4, :cond_f

    .line 254
    .line 255
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 256
    .line 257
    .line 258
    move-result v4

    .line 259
    goto :goto_7

    .line 260
    :cond_f
    move v4, p1

    .line 261
    :goto_7
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getLoanTerm()Ljava/lang/Integer;

    .line 262
    .line 263
    .line 264
    move-result-object v5

    .line 265
    if-eqz v5, :cond_10

    .line 266
    .line 267
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 268
    .line 269
    .line 270
    move-result v5

    .line 271
    goto :goto_8

    .line 272
    :cond_10
    move v5, p1

    .line 273
    :goto_8
    new-instance v6, Ljava/lang/StringBuilder;

    .line 274
    .line 275
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 276
    .line 277
    .line 278
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 279
    .line 280
    .line 281
    const-string v4, "_"

    .line 282
    .line 283
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 284
    .line 285
    .line 286
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 287
    .line 288
    .line 289
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v4

    .line 293
    :cond_11
    :goto_9
    new-instance v5, Lkotlin/Pair;

    .line 294
    .line 295
    const-string v6, "selected_tenure_id"

    .line 296
    .line 297
    invoke-direct {v5, v6, v4}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 298
    .line 299
    .line 300
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getLoanDays()Ljava/lang/Integer;

    .line 301
    .line 302
    .line 303
    move-result-object v4

    .line 304
    if-eqz v4, :cond_12

    .line 305
    .line 306
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 307
    .line 308
    .line 309
    move-result p1

    .line 310
    :cond_12
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 311
    .line 312
    .line 313
    move-result-object p1

    .line 314
    new-instance v4, Lkotlin/Pair;

    .line 315
    .line 316
    const-string v6, "tenure_days"

    .line 317
    .line 318
    invoke-direct {v4, v6, p1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 319
    .line 320
    .line 321
    invoke-virtual {v1}, Lcom/transsnet/palmpay/credit/bean/resp/CLRepaymentPlanData;->getInterestRatio()Ljava/lang/Double;

    .line 322
    .line 323
    .line 324
    move-result-object p1

    .line 325
    if-eqz p1, :cond_13

    .line 326
    .line 327
    invoke-virtual {p1}, Ljava/lang/Double;->toString()Ljava/lang/String;

    .line 328
    .line 329
    .line 330
    move-result-object p1

    .line 331
    if-nez p1, :cond_14

    .line 332
    .line 333
    :cond_13
    const-string p1, "0"

    .line 334
    .line 335
    :cond_14
    new-instance v1, Lkotlin/Pair;

    .line 336
    .line 337
    const-string v6, "interest_rate"

    .line 338
    .line 339
    invoke-direct {v1, v6, p1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 340
    .line 341
    .line 342
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 343
    .line 344
    .line 345
    move-result-object p1

    .line 346
    new-instance v2, Lkotlin/Pair;

    .line 347
    .line 348
    const-string v3, "transfer_amount"

    .line 349
    .line 350
    invoke-direct {v2, v3, p1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 351
    .line 352
    .line 353
    filled-new-array {v5, v4, v1, v2}, [Lkotlin/Pair;

    .line 354
    .line 355
    .line 356
    move-result-object p1

    .line 357
    invoke-static {p1}, LJ3/a;->g([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    .line 358
    .line 359
    .line 360
    move-result-object p1

    .line 361
    const-string v1, "loan_transfer_tenure_select"

    .line 362
    .line 363
    invoke-virtual {v0, v1, p1}, LPa/n0;->n(Ljava/lang/String;Ljava/util/Map;)V

    .line 364
    .line 365
    .line 366
    goto :goto_a

    .line 367
    :cond_15
    const-string p1, "params"

    .line 368
    .line 369
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 370
    .line 371
    .line 372
    throw v0

    .line 373
    :cond_16
    :goto_a
    return-void

    .line 374
    :pswitch_5
    check-cast v3, LXc/f;

    .line 375
    .line 376
    iget-object p1, v3, LXc/f;->a:LXc/g;

    .line 377
    .line 378
    iget-object p1, p1, LXc/g;->a:Lcom/transsnet/palmpay/p2pcash/ui/atm/view/P2PInputAmountView;

    .line 379
    .line 380
    iget-object v0, p1, Lcom/transsnet/palmpay/p2pcash/ui/atm/view/P2PInputAmountView;->g:Ljava/util/ArrayList;

    .line 381
    .line 382
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 383
    .line 384
    .line 385
    move-result-object v0

    .line 386
    check-cast v0, Ljava/lang/Long;

    .line 387
    .line 388
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 389
    .line 390
    .line 391
    move-result-wide v0

    .line 392
    const-wide/16 v2, 0x64

    .line 393
    .line 394
    div-long/2addr v0, v2

    .line 395
    iget-object p1, p1, Lcom/transsnet/palmpay/p2pcash/ui/atm/view/P2PInputAmountView;->c:Landroidx/appcompat/widget/AppCompatEditText;

    .line 396
    .line 397
    new-instance v2, Ljava/lang/StringBuilder;

    .line 398
    .line 399
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 400
    .line 401
    .line 402
    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 403
    .line 404
    .line 405
    const-string v0, ""

    .line 406
    .line 407
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 408
    .line 409
    .line 410
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 411
    .line 412
    .line 413
    move-result-object v0

    .line 414
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 415
    .line 416
    .line 417
    return-void

    .line 418
    :pswitch_6
    check-cast v3, LIe/e;

    .line 419
    .line 420
    invoke-virtual {v3, v2}, LIe/e;->b(I)V

    .line 421
    .line 422
    .line 423
    return-void

    .line 424
    :pswitch_7
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 425
    .line 426
    .line 427
    move-result-object p1

    .line 428
    const-string v1, "PalmPay_Wealth_ExclusiveSave_Click"

    .line 429
    .line 430
    invoke-virtual {p1, v1}, LPa/n0;->l(Ljava/lang/String;)V

    .line 431
    .line 432
    .line 433
    check-cast v3, Lcom/transsnet/palmpay/main/export/ui/view/a;

    .line 434
    .line 435
    iget-object p1, v3, Lcom/transsnet/palmpay/main/export/ui/view/a;->b:Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings$OnInvestBtnClickListener;

    .line 436
    .line 437
    if-eqz p1, :cond_18

    .line 438
    .line 439
    iget-object v1, v3, Lcom/transsnet/palmpay/main/export/ui/view/a;->a:Ljava/util/List;

    .line 440
    .line 441
    if-eqz v1, :cond_17

    .line 442
    .line 443
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 444
    .line 445
    .line 446
    move-result-object v0

    .line 447
    check-cast v0, Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;

    .line 448
    .line 449
    :cond_17
    invoke-interface {p1, v0}, Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings$OnInvestBtnClickListener;->onInvestBtnClick(Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;)V

    .line 450
    .line 451
    .line 452
    :cond_18
    return-void

    .line 453
    :pswitch_8
    check-cast v3, Lcom/transsnet/palmpay/send_money/ui/dialog/a;

    .line 454
    .line 455
    iget-object p1, v3, Lcom/transsnet/palmpay/send_money/ui/dialog/a;->e:Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;

    .line 456
    .line 457
    invoke-static {p1}, Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;)Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog$DaySelectCallback;

    .line 458
    .line 459
    .line 460
    move-result-object v0

    .line 461
    if-eqz v0, :cond_19

    .line 462
    .line 463
    add-int/2addr v2, v1

    .line 464
    invoke-static {p1, v2}, Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;->d(Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;I)V

    .line 465
    .line 466
    .line 467
    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 468
    .line 469
    .line 470
    invoke-static {p1}, Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;)Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog$DaySelectCallback;

    .line 471
    .line 472
    .line 473
    move-result-object v0

    .line 474
    invoke-static {p1}, Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog;)I

    .line 475
    .line 476
    .line 477
    move-result v1

    .line 478
    invoke-interface {v0, v1}, Lcom/transsnet/palmpay/send_money/ui/dialog/SelectDayDialog$DaySelectCallback;->onDaySelect(I)V

    .line 479
    .line 480
    .line 481
    :cond_19
    invoke-virtual {p1}, Lcom/transsnet/palmpay/custom_view/dialog/b;->dismiss()V

    .line 482
    .line 483
    .line 484
    return-void

    .line 485
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
