.class public final LAd/f;
.super LM1/j;
.source "SourceFile"


# instance fields
.field public final a:Z


# direct methods
.method public constructor <init>(Z)V
    .locals 2

    .line 1
    sget v0, Lkd/f;->sm_item_dialog_beneficiaries:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {p0, v0, v1}, LM1/j;-><init>(ILjava/util/List;)V

    .line 5
    .line 6
    .line 7
    iput-boolean p1, p0, LAd/f;->a:Z

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "item"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    sget v0, Lkd/e;->tvRecipientName:I

    .line 14
    .line 15
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;->getRecipientName()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sget v1, Lkd/e;->tvInfo:I

    .line 24
    .line 25
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;->getRecipientPhone()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    if-eqz v2, :cond_0

    .line 30
    .line 31
    invoke-static {v2}, LPa/r0;->w(Ljava/lang/String;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    const/4 v2, 0x0

    .line 37
    :goto_0
    invoke-virtual {v0, v1, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    sget v1, Lkd/e;->tvPalmpayUser:I

    .line 42
    .line 43
    iget-boolean v2, p0, LAd/f;->a:Z

    .line 44
    .line 45
    invoke-virtual {v0, v1, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 46
    .line 47
    .line 48
    sget v0, Lkd/e;->ivRecentlyBank:I

    .line 49
    .line 50
    invoke-virtual {p1, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    check-cast v0, Landroid/widget/ImageView;

    .line 55
    .line 56
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;->getRecipientHeadImage()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    invoke-static {v1, v0}, LPa/r0;->m1(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 61
    .line 62
    .line 63
    sget v0, Lkd/e;->iivCheck:I

    .line 64
    .line 65
    invoke-virtual {p1, v0}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->getView(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    check-cast p1, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 70
    .line 71
    new-instance v0, Lcom/mikepenz/iconics/IconicsDrawable;

    .line 72
    .line 73
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;->isSelect()Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    if-eqz v2, :cond_1

    .line 82
    .line 83
    sget-object v2, LS6/a;->a1:LS6/a;

    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_1
    sget-object v2, LS6/a;->B:LS6/a;

    .line 87
    .line 88
    :goto_1
    invoke-direct {v0, v1, v2}, Lcom/mikepenz/iconics/IconicsDrawable;-><init>(Landroid/content/Context;Lcom/mikepenz/iconics/typeface/IIcon;)V

    .line 89
    .line 90
    .line 91
    new-instance v1, LAd/e;

    .line 92
    .line 93
    const/4 v2, 0x0

    .line 94
    invoke-direct {v1, v2, p2, p0}, LAd/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v0, v1}, Lcom/mikepenz/iconics/IconicsDrawable;->a(Lkotlin/jvm/functions/Function1;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/AppCompatImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 101
    .line 102
    .line 103
    return-void
.end method
