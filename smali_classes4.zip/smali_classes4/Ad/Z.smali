.class public final synthetic LAd/Z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/Z;->a:I

    iput-object p1, p0, LAd/Z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/Z;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/Z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/Z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;->e(Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;)Lcom/transsnet/palmpay/send_money/ui/view/TransferToBankProgressModel;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LAd/Z;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/TransferProcessDialog;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
