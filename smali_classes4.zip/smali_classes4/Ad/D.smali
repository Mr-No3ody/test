.class public final synthetic LAd/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/D;->a:I

    iput-object p1, p0, LAd/D;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/D;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/D;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;->d(Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;)Lcom/mikepenz/iconics/view/IconicsImageView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/D;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;->e(Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LAd/D;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, LAd/D;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, p0, LAd/D;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;->j(Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_4
    iget-object v0, p0, LAd/D;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;->h(Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_5
    iget-object v0, p0, LAd/D;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;->i(Lcom/transsnet/palmpay/send_money/ui/dialog/FasterSendToPalmPayAccountDialog;)Lcom/mikepenz/iconics/view/IconicsCheckBox;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
