.class public final LAd/P;
.super LM1/j;
.source "SourceFile"


# instance fields
.field public a:I


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p2, LAd/O;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "item"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    sget v0, Lkd/e;->tv_date:I

    .line 14
    .line 15
    iget-object p2, p2, LAd/O;->b:Ljava/lang/Integer;

    .line 16
    .line 17
    invoke-static {p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p2

    .line 21
    invoke-virtual {p1, v0, p2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 22
    .line 23
    .line 24
    move-result-object p2

    .line 25
    sget v0, Lkd/e;->tv_date:I

    .line 26
    .line 27
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    iget v2, p0, LAd/P;->a:I

    .line 32
    .line 33
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getLayoutPosition()I

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-ne v2, v3, :cond_0

    .line 38
    .line 39
    sget v2, LL6/b;->ppColorPrimary:I

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    sget v2, LL6/b;->ppColorTextPrimary:I

    .line 43
    .line 44
    :goto_0
    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    invoke-virtual {p2, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setTextColor(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 49
    .line 50
    .line 51
    move-result-object p2

    .line 52
    sget v0, Lkd/e;->tv_date:I

    .line 53
    .line 54
    iget v1, p0, LAd/P;->a:I

    .line 55
    .line 56
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getLayoutPosition()I

    .line 57
    .line 58
    .line 59
    move-result p1

    .line 60
    if-ne v1, p1, :cond_1

    .line 61
    .line 62
    sget p1, Lba/d;->core_rect_round_corner_bg_f3ebf9:I

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_1
    sget p1, Lcom/transsnet/palmpay/custom_view/p;->transparent:I

    .line 66
    .line 67
    :goto_1
    invoke-virtual {p2, v0, p1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setBackgroundResource(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 68
    .line 69
    .line 70
    return-void
.end method
