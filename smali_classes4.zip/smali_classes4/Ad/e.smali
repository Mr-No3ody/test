.class public final synthetic LAd/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LAd/e;->a:I

    iput-object p2, p0, LAd/e;->b:Ljava/lang/Object;

    iput-object p3, p0, LAd/e;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const/16 v1, 0x18

    .line 4
    .line 5
    const-string v2, "$this$apply"

    .line 6
    .line 7
    const/16 v3, 0x3e8

    .line 8
    .line 9
    const/4 v4, 0x4

    .line 10
    const-string v5, "S"

    .line 11
    .line 12
    const/4 v6, 0x2

    .line 13
    const/4 v7, 0x1

    .line 14
    const/4 v8, 0x0

    .line 15
    const/4 v9, 0x0

    .line 16
    const-string v10, "it"

    .line 17
    .line 18
    iget-object v11, v0, LAd/e;->c:Ljava/lang/Object;

    .line 19
    .line 20
    iget-object v12, v0, LAd/e;->b:Ljava/lang/Object;

    .line 21
    .line 22
    iget v13, v0, LAd/e;->a:I

    .line 23
    .line 24
    packed-switch v13, :pswitch_data_0

    .line 25
    .line 26
    .line 27
    move-object/from16 v1, p1

    .line 28
    .line 29
    check-cast v1, Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 30
    .line 31
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    move-object v13, v12

    .line 39
    check-cast v13, Ld9/i;

    .line 40
    .line 41
    if-eqz v2, :cond_0

    .line 42
    .line 43
    iget-object v14, v13, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 44
    .line 45
    new-instance v15, Ld9/h;

    .line 46
    .line 47
    check-cast v11, Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;

    .line 48
    .line 49
    invoke-direct {v15, v11, v8}, Ld9/h;-><init>(Lcom/transsnet/palmpay/core/bean/req/SmsActionReq;Lkotlin/coroutines/Continuation;)V

    .line 50
    .line 51
    .line 52
    new-instance v1, Ld9/a;

    .line 53
    .line 54
    invoke-direct {v1, v13, v7}, Ld9/a;-><init>(Ld9/i;I)V

    .line 55
    .line 56
    .line 57
    new-instance v2, Ld9/a;

    .line 58
    .line 59
    invoke-direct {v2, v13, v6}, Ld9/a;-><init>(Ld9/i;I)V

    .line 60
    .line 61
    .line 62
    const/16 v18, 0x0

    .line 63
    .line 64
    const/16 v19, 0x0

    .line 65
    .line 66
    move-object/from16 v16, v1

    .line 67
    .line 68
    move-object/from16 v17, v2

    .line 69
    .line 70
    invoke-static/range {v13 .. v19}, LJ3/a;->D(Lcom/transsnet/palmpay/core/base/IBaseSubscription;Lcom/transsnet/palmpay/core/base/IBaseView;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ZZ)V

    .line 71
    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_0
    iget-object v2, v13, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 75
    .line 76
    check-cast v2, Lcom/transsnet/palmpay/account/ui/mvp/contract/ChangeMobileContract$View;

    .line 77
    .line 78
    if-eqz v2, :cond_1

    .line 79
    .line 80
    invoke-interface {v2, v9}, Lcom/transsnet/palmpay/account/ui/mvp/contract/ChangeMobileContract$View;->showLoadingView(Z)V

    .line 81
    .line 82
    .line 83
    :cond_1
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespCode()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    const-string v3, "CFRONT_300013"

    .line 88
    .line 89
    invoke-virtual {v3, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v2

    .line 93
    if-eqz v2, :cond_2

    .line 94
    .line 95
    sget v2, LF8/h;->ac_msg_mobile_number_is_used:I

    .line 96
    .line 97
    invoke-static {v2}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(I)V

    .line 98
    .line 99
    .line 100
    goto :goto_0

    .line 101
    :cond_2
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    new-array v3, v9, [Ljava/lang/Object;

    .line 106
    .line 107
    invoke-static {v2, v3}, Lcom/transsnet/palmpay/util/ToastUtils;->showLong(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    :goto_0
    iget-object v2, v13, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 111
    .line 112
    check-cast v2, Lcom/transsnet/palmpay/account/ui/mvp/contract/ChangeMobileContract$View;

    .line 113
    .line 114
    if-eqz v2, :cond_3

    .line 115
    .line 116
    invoke-interface {v2, v1}, Lcom/transsnet/palmpay/account/ui/mvp/contract/ChangeMobileContract$View;->handSendMessageResult(Lcom/transsnet/palmpay/core/bean/CommonResult;)V

    .line 117
    .line 118
    .line 119
    :cond_3
    :goto_1
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 120
    .line 121
    return-object v1

    .line 122
    :pswitch_0
    move-object/from16 v1, p1

    .line 123
    .line 124
    check-cast v1, Lcom/google/android/play/core/appupdate/AppUpdateInfo;

    .line 125
    .line 126
    check-cast v12, Lcom/google/android/play/core/appupdate/AppUpdateManager;

    .line 127
    .line 128
    check-cast v11, Landroid/app/Activity;

    .line 129
    .line 130
    invoke-static {v12, v11, v1}, Lcom/transsnet/palmpay/util/GooglePlayInnerAppHelper;->a(Lcom/google/android/play/core/appupdate/AppUpdateManager;Landroid/app/Activity;Lcom/google/android/play/core/appupdate/AppUpdateInfo;)Lkotlin/Unit;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    return-object v1

    .line 135
    :pswitch_1
    move-object/from16 v1, p1

    .line 136
    .line 137
    check-cast v1, Ljava/lang/Integer;

    .line 138
    .line 139
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    check-cast v12, Lkotlin/jvm/internal/D;

    .line 144
    .line 145
    check-cast v11, Ljava/lang/String;

    .line 146
    .line 147
    invoke-static {v12, v11, v1}, Lcom/transsnet/palmpay/custom_view/utils/CommonExtKt;->a(Lkotlin/jvm/internal/D;Ljava/lang/String;I)Ljava/lang/CharSequence;

    .line 148
    .line 149
    .line 150
    move-result-object v1

    .line 151
    return-object v1

    .line 152
    :pswitch_2
    move-object/from16 v1, p1

    .line 153
    .line 154
    check-cast v1, Ljava/lang/Integer;

    .line 155
    .line 156
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 157
    .line 158
    .line 159
    move-result v1

    .line 160
    check-cast v12, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;

    .line 161
    .line 162
    check-cast v11, Lkotlin/jvm/functions/Function1;

    .line 163
    .line 164
    invoke-static {v12, v11, v1}, Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;->i(Lcom/transsnet/palmpay/custom_view/input/ModelMobileWithIconInputLayout;Lkotlin/jvm/functions/Function1;I)Lkotlin/Unit;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    return-object v1

    .line 169
    :pswitch_3
    move-object/from16 v1, p1

    .line 170
    .line 171
    check-cast v1, Ljava/lang/Long;

    .line 172
    .line 173
    sget-object v2, Lcom/transsnet/palmpay/credit/ui/dialog/CreditApplicationDialogFragment;->L:Lcom/transsnet/palmpay/credit/ui/dialog/CreditApplicationDialogFragment$a;

    .line 174
    .line 175
    check-cast v12, Landroid/widget/TextView;

    .line 176
    .line 177
    if-eqz v12, :cond_4

    .line 178
    .line 179
    new-instance v2, Ljava/lang/StringBuilder;

    .line 180
    .line 181
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 185
    .line 186
    .line 187
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 188
    .line 189
    .line 190
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v2

    .line 194
    invoke-virtual {v12, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 195
    .line 196
    .line 197
    :cond_4
    check-cast v11, Lcom/transsnet/palmpay/custom_view/CircleProgressView;

    .line 198
    .line 199
    if-eqz v11, :cond_5

    .line 200
    .line 201
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 202
    .line 203
    .line 204
    move-result-wide v1

    .line 205
    long-to-int v1, v1

    .line 206
    invoke-virtual {v11, v1, v4}, Lcom/transsnet/palmpay/custom_view/CircleProgressView;->b(II)V

    .line 207
    .line 208
    .line 209
    :cond_5
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 210
    .line 211
    return-object v1

    .line 212
    :pswitch_4
    move-object/from16 v1, p1

    .line 213
    .line 214
    check-cast v1, Ljava/lang/Boolean;

    .line 215
    .line 216
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 217
    .line 218
    .line 219
    move-result v1

    .line 220
    check-cast v12, Lcom/transsnet/adsdk/widgets/Interstitial/InterstitialAdView;

    .line 221
    .line 222
    check-cast v11, Lcom/transsnet/adsdk/widgets/interfaces/AdShowCallback;

    .line 223
    .line 224
    invoke-static {v12, v11, v1}, Lcom/transsnet/adsdk/widgets/Interstitial/InterstitialAdView;->c(Lcom/transsnet/adsdk/widgets/Interstitial/InterstitialAdView;Lcom/transsnet/adsdk/widgets/interfaces/AdShowCallback;Z)Ljava/lang/Boolean;

    .line 225
    .line 226
    .line 227
    move-result-object v1

    .line 228
    return-object v1

    .line 229
    :pswitch_5
    move-object/from16 v1, p1

    .line 230
    .line 231
    check-cast v1, Lcom/facebook/react/runtime/ReactInstance;

    .line 232
    .line 233
    check-cast v12, Lcom/facebook/react/runtime/ReactHostImpl;

    .line 234
    .line 235
    check-cast v11, Lcom/facebook/react/bridge/JSBundleLoader;

    .line 236
    .line 237
    invoke-static {v12, v11, v1}, Lcom/facebook/react/runtime/ReactHostImpl;->q(Lcom/facebook/react/runtime/ReactHostImpl;Lcom/facebook/react/bridge/JSBundleLoader;Lcom/facebook/react/runtime/ReactInstance;)Lkotlin/Unit;

    .line 238
    .line 239
    .line 240
    move-result-object v1

    .line 241
    return-object v1

    .line 242
    :pswitch_6
    move-object/from16 v1, p1

    .line 243
    .line 244
    check-cast v1, Lcom/facebook/react/runtime/internal/bolts/Task;

    .line 245
    .line 246
    check-cast v12, Lcom/facebook/react/runtime/ReactHostImpl;

    .line 247
    .line 248
    check-cast v11, Ljava/lang/String;

    .line 249
    .line 250
    invoke-static {v12, v11, v1}, Lcom/facebook/react/runtime/ReactHostImpl;->S(Lcom/facebook/react/runtime/ReactHostImpl;Ljava/lang/String;Lcom/facebook/react/runtime/internal/bolts/Task;)Lcom/facebook/react/runtime/ReactInstance;

    .line 251
    .line 252
    .line 253
    move-result-object v1

    .line 254
    return-object v1

    .line 255
    :pswitch_7
    move-object/from16 v1, p1

    .line 256
    .line 257
    check-cast v1, Lcom/transsnet/palmpay/teller/bean/resp/BillerCouponItemBean;

    .line 258
    .line 259
    sget v2, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;->i:I

    .line 260
    .line 261
    check-cast v12, Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;

    .line 262
    .line 263
    check-cast v11, Lkotlin/jvm/functions/Function1;

    .line 264
    .line 265
    invoke-interface {v11, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    if-eqz v1, :cond_6

    .line 269
    .line 270
    new-instance v13, Lcom/transsnet/palmpay/teller/ui/dialog/CouponClaimResultDialog;

    .line 271
    .line 272
    invoke-virtual {v12}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 273
    .line 274
    .line 275
    move-result-object v14

    .line 276
    const/4 v15, 0x0

    .line 277
    const/16 v16, 0x0

    .line 278
    .line 279
    const/16 v17, 0x6

    .line 280
    .line 281
    const/16 v18, 0x0

    .line 282
    .line 283
    invoke-direct/range {v13 .. v18}, Lcom/transsnet/palmpay/teller/ui/dialog/CouponClaimResultDialog;-><init>(Landroid/content/Context;IIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 284
    .line 285
    .line 286
    invoke-static {v1}, Lkotlin/collections/p;->c(Ljava/lang/Object;)Ljava/util/List;

    .line 287
    .line 288
    .line 289
    move-result-object v1

    .line 290
    invoke-virtual {v13, v1}, Lcom/transsnet/palmpay/teller/ui/dialog/CouponClaimResultDialog;->setCouponItem(Ljava/util/List;)Lcom/transsnet/palmpay/teller/ui/dialog/CouponClaimResultDialog;

    .line 291
    .line 292
    .line 293
    move-result-object v1

    .line 294
    new-instance v2, LU8/a;

    .line 295
    .line 296
    const/16 v3, 0x14

    .line 297
    .line 298
    invoke-direct {v2, v3, v12, v13}, LU8/a;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/teller/ui/dialog/CouponClaimResultDialog;->setResultCallback(Lcom/transsnet/palmpay/core/callback/ResultCallback;)Lcom/transsnet/palmpay/teller/ui/dialog/CouponClaimResultDialog;

    .line 302
    .line 303
    .line 304
    move-result-object v1

    .line 305
    invoke-virtual {v1}, LO6/f;->show()V

    .line 306
    .line 307
    .line 308
    :cond_6
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 309
    .line 310
    .line 311
    move-result v1

    .line 312
    if-nez v1, :cond_7

    .line 313
    .line 314
    goto :goto_2

    .line 315
    :cond_7
    invoke-static {v12}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleCoroutineScopeImpl;

    .line 316
    .line 317
    .line 318
    move-result-object v1

    .line 319
    sget-object v2, LWf/I;->a:Lcg/f;

    .line 320
    .line 321
    sget-object v2, Lcg/e;->c:Lcg/e;

    .line 322
    .line 323
    new-instance v3, Lce/u;

    .line 324
    .line 325
    invoke-direct {v3, v8, v12}, Lce/u;-><init>(Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/teller/ui/view/ModelAvailableCouponAndPointItem;)V

    .line 326
    .line 327
    .line 328
    invoke-static {v1, v2, v8, v3, v6}, LWf/y;->m(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;LWf/w;Lkotlin/jvm/functions/Function2;I)LWf/t0;

    .line 329
    .line 330
    .line 331
    move-result-object v1

    .line 332
    invoke-virtual {v12, v1}, Lcom/transsnet/palmpay/custom_view/model/BaseConstraintLayout;->addJob(Lkotlinx/coroutines/Job;)V

    .line 333
    .line 334
    .line 335
    :goto_2
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 336
    .line 337
    return-object v1

    .line 338
    :pswitch_8
    move-object/from16 v1, p1

    .line 339
    .line 340
    check-cast v1, Ljava/lang/String;

    .line 341
    .line 342
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 343
    .line 344
    .line 345
    check-cast v12, Lcom/transsnet/palmpay/account/ui/fragment/upgrade/UpgradeTier3StepBillsFragment;

    .line 346
    .line 347
    iget-object v1, v12, Lcom/transsnet/palmpay/account/ui/fragment/upgrade/UpgradeTier3StepBillsFragment;->t:Lb9/d;

    .line 348
    .line 349
    if-eqz v1, :cond_8

    .line 350
    .line 351
    check-cast v11, Lcom/transsnet/palmpay/account/bean/rsp/QueryAddressFromBillRsp;

    .line 352
    .line 353
    invoke-virtual {v1, v11}, Lb9/d;->b(Lcom/transsnet/palmpay/account/bean/rsp/QueryAddressFromBillRsp;)V

    .line 354
    .line 355
    .line 356
    :cond_8
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 357
    .line 358
    return-object v1

    .line 359
    :pswitch_9
    move-object/from16 v1, p1

    .line 360
    .line 361
    check-cast v1, Ljava/lang/Throwable;

    .line 362
    .line 363
    check-cast v12, LXf/d;

    .line 364
    .line 365
    check-cast v11, LB6/g;

    .line 366
    .line 367
    iget-object v1, v12, LXf/d;->c:Landroid/os/Handler;

    .line 368
    .line 369
    invoke-virtual {v1, v11}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 370
    .line 371
    .line 372
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 373
    .line 374
    return-object v1

    .line 375
    :pswitch_a
    move-object/from16 v1, p1

    .line 376
    .line 377
    check-cast v1, Ljava/lang/Long;

    .line 378
    .line 379
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 380
    .line 381
    .line 382
    move-result-wide v1

    .line 383
    sget v4, Lcom/transsnet/palmpay/teller/ui/activity/BillerTransactionResultActivity;->Y:I

    .line 384
    .line 385
    check-cast v12, Lcom/transsnet/palmpay/teller/ui/activity/BillerTransactionResultActivity;

    .line 386
    .line 387
    iget-object v4, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 388
    .line 389
    check-cast v4, LRd/n;

    .line 390
    .line 391
    if-eqz v4, :cond_9

    .line 392
    .line 393
    iget-object v4, v4, LRd/n;->f:Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;

    .line 394
    .line 395
    invoke-virtual {v4}, Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;->getOrderStatusTv()Landroid/widget/TextView;

    .line 396
    .line 397
    .line 398
    move-result-object v4

    .line 399
    if-eqz v4, :cond_9

    .line 400
    .line 401
    int-to-long v6, v3

    .line 402
    div-long/2addr v1, v6

    .line 403
    new-instance v3, Ljava/lang/StringBuilder;

    .line 404
    .line 405
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 406
    .line 407
    .line 408
    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 409
    .line 410
    .line 411
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 412
    .line 413
    .line 414
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 415
    .line 416
    .line 417
    move-result-object v1

    .line 418
    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 419
    .line 420
    .line 421
    :cond_9
    iget-object v1, v12, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 422
    .line 423
    check-cast v1, LRd/n;

    .line 424
    .line 425
    if-eqz v1, :cond_a

    .line 426
    .line 427
    iget-object v1, v1, LRd/n;->f:Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;

    .line 428
    .line 429
    check-cast v11, Ljava/lang/String;

    .line 430
    .line 431
    invoke-virtual {v1, v11}, Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;->h(Ljava/lang/CharSequence;)V

    .line 432
    .line 433
    .line 434
    :cond_a
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 435
    .line 436
    return-object v1

    .line 437
    :pswitch_b
    move-object/from16 v1, p1

    .line 438
    .line 439
    check-cast v1, Ljava/lang/String;

    .line 440
    .line 441
    const-string v2, "line"

    .line 442
    .line 443
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    new-instance v2, Landroid/text/style/ForegroundColorSpan;

    .line 447
    .line 448
    sget v3, LL6/b;->ppColorTextPrimary:I

    .line 449
    .line 450
    check-cast v11, Lcom/transsnet/palmpay/p2pcash/ui/atm/MapPage;

    .line 451
    .line 452
    invoke-static {v3, v11}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 453
    .line 454
    .line 455
    move-result v3

    .line 456
    invoke-direct {v2, v3}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    .line 457
    .line 458
    .line 459
    const-string v3, "1. How to find the exact address of the nearby agent?\n\nClick the Nearby Agent and find the agent according to the map. If the agent provides a phone number, you can also call in advance to find the agent.\n\n\n2. How to get cashback when you use PalmPay App\'s Withdrawal Feature to get cash from the agents?\n\nYou can get cashback at any agent store that provides the payment method of PalmPay\'s Pay With Transfer and the account name shows cashback label at the same time when you enter the account number.\n\n\n3. How to get cash after finding the nearby agent?\n\nAfter you find an agent, you can use the Withdrawal feature on PalmPay App to transfer money to his or her PalmPay account or pay with transfer account number, and then get cash.\n\n\n4. What are the benefits of withdrawing cash through PalmPay App?\n\nWithdraw cash from PalmPay agent through the Withdrawal feature of PalmPay App will be free of charge. And you will have a chance to get cashback every day.\n\n\n5. What should I do if I see an agent on Nearby Agent but I don\'t find one?\n\nYou can call the customer service number\uff08018886888\uff09 to mention the issue. We will verify the location of the agent as soon as possible, notify the agent to change the location if there\u2019s any problem, and give you feedback on the results.\n\nxxxxx If there\u2019s any address problem, click here to feedback\n"

    .line 460
    .line 461
    const/4 v4, 0x6

    .line 462
    invoke-static {v3, v1, v9, v9, v4}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 463
    .line 464
    .line 465
    move-result v5

    .line 466
    invoke-static {v3, v1, v9, v9, v4}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 467
    .line 468
    .line 469
    move-result v6

    .line 470
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 471
    .line 472
    .line 473
    move-result v8

    .line 474
    add-int/2addr v8, v6

    .line 475
    check-cast v12, Landroid/text/SpannableString;

    .line 476
    .line 477
    const/16 v6, 0x21

    .line 478
    .line 479
    invoke-virtual {v12, v2, v5, v8, v6}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 480
    .line 481
    .line 482
    new-instance v2, Landroid/text/style/StyleSpan;

    .line 483
    .line 484
    invoke-direct {v2, v7}, Landroid/text/style/StyleSpan;-><init>(I)V

    .line 485
    .line 486
    .line 487
    invoke-static {v3, v1, v9, v9, v4}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 488
    .line 489
    .line 490
    move-result v5

    .line 491
    invoke-static {v3, v1, v9, v9, v4}, Lkotlin/text/StringsKt;->E(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    .line 492
    .line 493
    .line 494
    move-result v3

    .line 495
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 496
    .line 497
    .line 498
    move-result v1

    .line 499
    add-int/2addr v1, v3

    .line 500
    invoke-virtual {v12, v2, v5, v1, v6}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 501
    .line 502
    .line 503
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 504
    .line 505
    return-object v1

    .line 506
    :pswitch_c
    move-object/from16 v1, p1

    .line 507
    .line 508
    check-cast v1, Ljava/lang/Integer;

    .line 509
    .line 510
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 511
    .line 512
    .line 513
    move-result v2

    .line 514
    if-ltz v2, :cond_b

    .line 515
    .line 516
    check-cast v12, Ljava/util/List;

    .line 517
    .line 518
    check-cast v12, Ljava/util/Collection;

    .line 519
    .line 520
    invoke-interface {v12}, Ljava/util/Collection;->size()I

    .line 521
    .line 522
    .line 523
    move-result v3

    .line 524
    if-ge v2, v3, :cond_b

    .line 525
    .line 526
    check-cast v11, Lkotlin/jvm/functions/Function1;

    .line 527
    .line 528
    invoke-interface {v11, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 529
    .line 530
    .line 531
    :cond_b
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 532
    .line 533
    return-object v1

    .line 534
    :pswitch_d
    move-object/from16 v1, p1

    .line 535
    .line 536
    check-cast v1, Ljava/lang/Integer;

    .line 537
    .line 538
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 539
    .line 540
    .line 541
    move-result v1

    .line 542
    check-cast v12, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;

    .line 543
    .line 544
    iget-object v2, v12, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->g:Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;

    .line 545
    .line 546
    if-eqz v2, :cond_10

    .line 547
    .line 548
    check-cast v11, Ljava/util/ArrayList;

    .line 549
    .line 550
    invoke-virtual {v11, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 551
    .line 552
    .line 553
    move-result-object v1

    .line 554
    check-cast v1, Ljava/lang/Number;

    .line 555
    .line 556
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 557
    .line 558
    .line 559
    move-result v1

    .line 560
    const/16 v3, 0x7d0

    .line 561
    .line 562
    if-lt v1, v3, :cond_d

    .line 563
    .line 564
    invoke-virtual {v12, v4}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->f(I)Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;

    .line 565
    .line 566
    .line 567
    move-result-object v5

    .line 568
    sub-int/2addr v1, v3

    .line 569
    if-eqz v5, :cond_c

    .line 570
    .line 571
    iget-object v8, v5, Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;->sender:Ljava/lang/String;

    .line 572
    .line 573
    :cond_c
    invoke-interface {v2, v4, v1, v8}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 574
    .line 575
    .line 576
    goto :goto_3

    .line 577
    :cond_d
    const/4 v4, 0x3

    .line 578
    if-ne v1, v4, :cond_f

    .line 579
    .line 580
    invoke-virtual {v12, v4}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->f(I)Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;

    .line 581
    .line 582
    .line 583
    move-result-object v5

    .line 584
    sub-int/2addr v1, v3

    .line 585
    if-eqz v5, :cond_e

    .line 586
    .line 587
    iget-object v8, v5, Lcom/transsnet/palmpay/core/bean/rsp/SmsChannelRsp;->sender:Ljava/lang/String;

    .line 588
    .line 589
    :cond_e
    invoke-interface {v2, v4, v1, v8}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 590
    .line 591
    .line 592
    goto :goto_3

    .line 593
    :cond_f
    invoke-virtual {v12}, Lcom/transsnet/palmpay/core/viewmodel/OneTimeCodeV5View;->k()V

    .line 594
    .line 595
    .line 596
    invoke-interface {v2, v1, v9, v8}, Lcom/transsnet/palmpay/core/listener/OnSendCodeListener;->onSend(IILjava/lang/String;)V

    .line 597
    .line 598
    .line 599
    :cond_10
    :goto_3
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 600
    .line 601
    return-object v1

    .line 602
    :pswitch_e
    move-object/from16 v1, p1

    .line 603
    .line 604
    check-cast v1, Landroid/net/Uri;

    .line 605
    .line 606
    check-cast v12, Lcom/transsnet/palmpay/account/ui/activity/SetUserPhotoActivity;

    .line 607
    .line 608
    check-cast v11, Ljava/lang/String;

    .line 609
    .line 610
    invoke-static {v12, v11, v1}, Lcom/transsnet/palmpay/account/ui/activity/SetUserPhotoActivity;->y(Lcom/transsnet/palmpay/account/ui/activity/SetUserPhotoActivity;Ljava/lang/String;Landroid/net/Uri;)Ljava/io/File;

    .line 611
    .line 612
    .line 613
    move-result-object v1

    .line 614
    return-object v1

    .line 615
    :pswitch_f
    move-object/from16 v1, p1

    .line 616
    .line 617
    check-cast v1, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;

    .line 618
    .line 619
    sget-object v2, Lcom/swmansion/rnscreens/ScreenStack;->L:Lcom/swmansion/rnscreens/ScreenStack$a;

    .line 620
    .line 621
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 622
    .line 623
    .line 624
    check-cast v12, Lkotlin/jvm/internal/F;

    .line 625
    .line 626
    iget-object v2, v12, Lkotlin/jvm/internal/F;->a:Ljava/lang/Object;

    .line 627
    .line 628
    if-eq v1, v2, :cond_11

    .line 629
    .line 630
    check-cast v11, Lcom/swmansion/rnscreens/ScreenStack;

    .line 631
    .line 632
    iget-object v2, v11, Lcom/swmansion/rnscreens/ScreenStack;->o:Ljava/util/HashSet;

    .line 633
    .line 634
    invoke-static {v2, v1}, Lkotlin/collections/CollectionsKt;->A(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    .line 635
    .line 636
    .line 637
    move-result v2

    .line 638
    if-eqz v2, :cond_13

    .line 639
    .line 640
    :cond_11
    invoke-interface {v1}, Lcom/swmansion/rnscreens/ScreenFragmentWrapper;->getScreen()Lcom/swmansion/rnscreens/Screen;

    .line 641
    .line 642
    .line 643
    move-result-object v1

    .line 644
    invoke-virtual {v1}, Lcom/swmansion/rnscreens/Screen;->getActivityState()LM7/n;

    .line 645
    .line 646
    .line 647
    move-result-object v1

    .line 648
    sget-object v2, LM7/n;->a:LM7/n;

    .line 649
    .line 650
    if-ne v1, v2, :cond_12

    .line 651
    .line 652
    goto :goto_4

    .line 653
    :cond_12
    move v7, v9

    .line 654
    :cond_13
    :goto_4
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 655
    .line 656
    .line 657
    move-result-object v1

    .line 658
    return-object v1

    .line 659
    :pswitch_10
    move-object/from16 v1, p1

    .line 660
    .line 661
    check-cast v1, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp;

    .line 662
    .line 663
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 664
    .line 665
    .line 666
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 667
    .line 668
    .line 669
    move-result v2

    .line 670
    check-cast v12, LLa/F;

    .line 671
    .line 672
    if-eqz v2, :cond_17

    .line 673
    .line 674
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 675
    .line 676
    .line 677
    move-result-object v2

    .line 678
    if-nez v2, :cond_14

    .line 679
    .line 680
    goto :goto_5

    .line 681
    :cond_14
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 682
    .line 683
    .line 684
    move-result-object v1

    .line 685
    iget-wide v2, v1, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->orderAmount:J

    .line 686
    .line 687
    iget-object v4, v12, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 688
    .line 689
    check-cast v4, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 690
    .line 691
    if-eqz v4, :cond_15

    .line 692
    .line 693
    invoke-interface {v4, v2, v3}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setPayAmount(J)V

    .line 694
    .line 695
    .line 696
    :cond_15
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 697
    .line 698
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 699
    .line 700
    if-eqz v2, :cond_16

    .line 701
    .line 702
    iget-wide v3, v1, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;->fee:J

    .line 703
    .line 704
    invoke-interface {v2, v3, v4}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->setFeeAmount(J)V

    .line 705
    .line 706
    .line 707
    :cond_16
    :goto_5
    check-cast v11, Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;

    .line 708
    .line 709
    iget-object v1, v11, Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;->transType:Ljava/lang/String;

    .line 710
    .line 711
    const/16 v2, 0xc

    .line 712
    .line 713
    invoke-static {v12, v1, v2}, LLa/F;->d(LLa/F;Ljava/lang/String;I)V

    .line 714
    .line 715
    .line 716
    goto :goto_6

    .line 717
    :cond_17
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 718
    .line 719
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 720
    .line 721
    if-eqz v2, :cond_18

    .line 722
    .line 723
    invoke-interface {v2, v9}, Lcom/transsnet/palmpay/core/ui/mvp/contract/BasePaymentContract$IView;->showLoadingView(Z)V

    .line 724
    .line 725
    .line 726
    :cond_18
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 727
    .line 728
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;

    .line 729
    .line 730
    if-eqz v2, :cond_19

    .line 731
    .line 732
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->getRespMsg()Ljava/lang/String;

    .line 733
    .line 734
    .line 735
    move-result-object v1

    .line 736
    invoke-interface {v2, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/SelectPaymentContract$IView;->showPaymentMethodError(Ljava/lang/String;)V

    .line 737
    .line 738
    .line 739
    :cond_19
    :goto_6
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 740
    .line 741
    return-object v1

    .line 742
    :pswitch_11
    move-object/from16 v1, p1

    .line 743
    .line 744
    check-cast v1, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp;

    .line 745
    .line 746
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 747
    .line 748
    .line 749
    check-cast v12, LLa/x;

    .line 750
    .line 751
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 752
    .line 753
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/CorePaymentPreviewContract$View;

    .line 754
    .line 755
    if-eqz v2, :cond_1b

    .line 756
    .line 757
    check-cast v11, Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;

    .line 758
    .line 759
    if-eqz v11, :cond_1a

    .line 760
    .line 761
    iget-object v8, v11, Lcom/transsnet/palmpay/core/bean/req/PreviewPayInfoV2Req;->payerAccountType:Ljava/lang/String;

    .line 762
    .line 763
    :cond_1a
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp;->getData()Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;

    .line 764
    .line 765
    .line 766
    move-result-object v1

    .line 767
    invoke-interface {v2, v8, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/CorePaymentPreviewContract$View;->updatePreviewInfo(Ljava/lang/String;Lcom/transsnet/palmpay/core/bean/payment/PreviewPayInfoResp$DataBean;)V

    .line 768
    .line 769
    .line 770
    :cond_1b
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 771
    .line 772
    return-object v1

    .line 773
    :pswitch_12
    move-object/from16 v1, p1

    .line 774
    .line 775
    check-cast v1, Lcom/transsnet/palmpay/core/bean/rsp/CheckBankCardInfoRsp;

    .line 776
    .line 777
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 778
    .line 779
    .line 780
    check-cast v12, LLa/l;

    .line 781
    .line 782
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 783
    .line 784
    check-cast v2, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;

    .line 785
    .line 786
    if-eqz v2, :cond_1c

    .line 787
    .line 788
    check-cast v11, Lcom/transsnet/palmpay/core/bean/req/CheckBankCardInfoReq;

    .line 789
    .line 790
    invoke-interface {v2, v11, v1}, Lcom/transsnet/palmpay/core/ui/mvp/contract/AddNewCardContract$IView;->handleCheckInputBankCardInfoRsp(Lcom/transsnet/palmpay/core/bean/req/CheckBankCardInfoReq;Lcom/transsnet/palmpay/core/bean/rsp/CheckBankCardInfoRsp;)V

    .line 791
    .line 792
    .line 793
    :cond_1c
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 794
    .line 795
    return-object v1

    .line 796
    :pswitch_13
    move-object/from16 v1, p1

    .line 797
    .line 798
    check-cast v1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 799
    .line 800
    const-string v2, "response"

    .line 801
    .line 802
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 803
    .line 804
    .line 805
    invoke-virtual {v1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 806
    .line 807
    .line 808
    move-result v2

    .line 809
    if-eqz v2, :cond_1d

    .line 810
    .line 811
    check-cast v12, LFe/I;

    .line 812
    .line 813
    iget-object v2, v12, Lcom/transsnet/palmpay/core/base/j;->a:Lcom/transsnet/palmpay/core/base/IBaseView;

    .line 814
    .line 815
    check-cast v2, Lcom/transsnet/palmpay/ui/mvp/contract/HomeFragmentContract$IView;

    .line 816
    .line 817
    if-eqz v2, :cond_1d

    .line 818
    .line 819
    iget-object v1, v1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 820
    .line 821
    check-cast v1, Lcom/transsnet/palmpay/core/bean/rsp/ClipboardMatchInfoResp;

    .line 822
    .line 823
    check-cast v11, Ljava/lang/String;

    .line 824
    .line 825
    invoke-interface {v2, v11, v1}, Lcom/transsnet/palmpay/ui/mvp/contract/HomeFragmentContract$IView;->handleClipboardMatchInfo(Ljava/lang/String;Lcom/transsnet/palmpay/core/bean/rsp/ClipboardMatchInfoResp;)V

    .line 826
    .line 827
    .line 828
    :cond_1d
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 829
    .line 830
    return-object v1

    .line 831
    :pswitch_14
    move-object/from16 v1, p1

    .line 832
    .line 833
    check-cast v1, Landroid/view/View;

    .line 834
    .line 835
    sget-object v2, Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment;->t0:Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment$a;

    .line 836
    .line 837
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 838
    .line 839
    .line 840
    check-cast v12, Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment;

    .line 841
    .line 842
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isAdded()Z

    .line 843
    .line 844
    .line 845
    move-result v2

    .line 846
    if-eqz v2, :cond_1f

    .line 847
    .line 848
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isDetached()Z

    .line 849
    .line 850
    .line 851
    move-result v2

    .line 852
    if-eqz v2, :cond_1e

    .line 853
    .line 854
    goto :goto_7

    .line 855
    :cond_1e
    new-instance v2, LIe/t;

    .line 856
    .line 857
    invoke-direct {v2, v1}, LIe/t;-><init>(Landroid/view/View;)V

    .line 858
    .line 859
    .line 860
    iput-object v2, v12, Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment;->Z:LIe/t;

    .line 861
    .line 862
    check-cast v11, Ljava/util/List;

    .line 863
    .line 864
    invoke-virtual {v2, v11}, LIe/t;->a(Ljava/util/List;)V

    .line 865
    .line 866
    .line 867
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 868
    .line 869
    goto :goto_8

    .line 870
    :cond_1f
    :goto_7
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 871
    .line 872
    :goto_8
    return-object v1

    .line 873
    :pswitch_15
    move-object/from16 v1, p1

    .line 874
    .line 875
    check-cast v1, Landroid/view/View;

    .line 876
    .line 877
    sget-object v2, Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment;->t0:Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment$a;

    .line 878
    .line 879
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 880
    .line 881
    .line 882
    check-cast v12, Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment;

    .line 883
    .line 884
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isAdded()Z

    .line 885
    .line 886
    .line 887
    move-result v2

    .line 888
    if-eqz v2, :cond_21

    .line 889
    .line 890
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isDetached()Z

    .line 891
    .line 892
    .line 893
    move-result v2

    .line 894
    if-eqz v2, :cond_20

    .line 895
    .line 896
    goto :goto_9

    .line 897
    :cond_20
    new-instance v2, LIe/u;

    .line 898
    .line 899
    invoke-direct {v2, v1}, LIe/u;-><init>(Landroid/view/View;)V

    .line 900
    .line 901
    .line 902
    iput-object v2, v12, Lcom/transsnet/palmpay/ui/fragment/InvestGuideFragment;->X:LIe/u;

    .line 903
    .line 904
    check-cast v11, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryRecommendModuleResp;

    .line 905
    .line 906
    invoke-virtual {v2, v11}, LIe/u;->a(Lcom/transsnet/palmpay/main/export/bean/rsp/QueryRecommendModuleResp;)V

    .line 907
    .line 908
    .line 909
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 910
    .line 911
    goto :goto_a

    .line 912
    :cond_21
    :goto_9
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 913
    .line 914
    :goto_a
    return-object v1

    .line 915
    :pswitch_16
    move-object/from16 v1, p1

    .line 916
    .line 917
    check-cast v1, Landroid/view/View;

    .line 918
    .line 919
    sget-object v2, Lcom/transsnet/palmpay/ui/fragment/HomeSavingsUserV2Fragment;->F0:Lcom/transsnet/palmpay/ui/fragment/HomeSavingsUserV2Fragment$a;

    .line 920
    .line 921
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 922
    .line 923
    .line 924
    check-cast v12, Lcom/transsnet/palmpay/ui/fragment/HomeSavingsUserV2Fragment;

    .line 925
    .line 926
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isAdded()Z

    .line 927
    .line 928
    .line 929
    move-result v2

    .line 930
    if-eqz v2, :cond_23

    .line 931
    .line 932
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isDetached()Z

    .line 933
    .line 934
    .line 935
    move-result v2

    .line 936
    if-eqz v2, :cond_22

    .line 937
    .line 938
    goto :goto_b

    .line 939
    :cond_22
    new-instance v2, LIe/u;

    .line 940
    .line 941
    invoke-direct {v2, v1}, LIe/u;-><init>(Landroid/view/View;)V

    .line 942
    .line 943
    .line 944
    iput-object v2, v12, Lcom/transsnet/palmpay/ui/fragment/HomeSavingsUserV2Fragment;->y0:LIe/u;

    .line 945
    .line 946
    check-cast v11, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryRecommendModuleResp;

    .line 947
    .line 948
    invoke-virtual {v2, v11}, LIe/u;->a(Lcom/transsnet/palmpay/main/export/bean/rsp/QueryRecommendModuleResp;)V

    .line 949
    .line 950
    .line 951
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 952
    .line 953
    goto :goto_c

    .line 954
    :cond_23
    :goto_b
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 955
    .line 956
    :goto_c
    return-object v1

    .line 957
    :pswitch_17
    move-object/from16 v1, p1

    .line 958
    .line 959
    check-cast v1, Landroid/view/View;

    .line 960
    .line 961
    sget-object v2, Lcom/transsnet/palmpay/ui/fragment/HomeSavingsUserV2Fragment;->F0:Lcom/transsnet/palmpay/ui/fragment/HomeSavingsUserV2Fragment$a;

    .line 962
    .line 963
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 964
    .line 965
    .line 966
    check-cast v12, Lcom/transsnet/palmpay/ui/fragment/HomeSavingsUserV2Fragment;

    .line 967
    .line 968
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isAdded()Z

    .line 969
    .line 970
    .line 971
    move-result v2

    .line 972
    if-eqz v2, :cond_25

    .line 973
    .line 974
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isDetached()Z

    .line 975
    .line 976
    .line 977
    move-result v2

    .line 978
    if-eqz v2, :cond_24

    .line 979
    .line 980
    goto :goto_d

    .line 981
    :cond_24
    new-instance v2, LO2/a;

    .line 982
    .line 983
    invoke-direct {v2, v1, v6}, LO2/a;-><init>(Landroid/view/View;I)V

    .line 984
    .line 985
    .line 986
    iput-object v2, v12, Lcom/transsnet/palmpay/ui/fragment/HomeSavingsUserV2Fragment;->z0:LO2/a;

    .line 987
    .line 988
    check-cast v11, Lcom/transsnet/palmpay/main/export/bean/rsp/QuerySavingTaskModuleResp;

    .line 989
    .line 990
    invoke-virtual {v2, v11}, LO2/a;->d(Lcom/transsnet/palmpay/main/export/bean/rsp/QuerySavingTaskModuleResp;)V

    .line 991
    .line 992
    .line 993
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 994
    .line 995
    goto :goto_e

    .line 996
    :cond_25
    :goto_d
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 997
    .line 998
    :goto_e
    return-object v1

    .line 999
    :pswitch_18
    move-object/from16 v1, p1

    .line 1000
    .line 1001
    check-cast v1, Landroid/view/View;

    .line 1002
    .line 1003
    sget v2, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->A0:I

    .line 1004
    .line 1005
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1006
    .line 1007
    .line 1008
    check-cast v12, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;

    .line 1009
    .line 1010
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isAdded()Z

    .line 1011
    .line 1012
    .line 1013
    move-result v2

    .line 1014
    if-eqz v2, :cond_27

    .line 1015
    .line 1016
    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->isDetached()Z

    .line 1017
    .line 1018
    .line 1019
    move-result v2

    .line 1020
    if-eqz v2, :cond_26

    .line 1021
    .line 1022
    goto :goto_f

    .line 1023
    :cond_26
    new-instance v2, LIe/m;

    .line 1024
    .line 1025
    invoke-direct {v2, v1}, LIe/m;-><init>(Landroid/view/View;)V

    .line 1026
    .line 1027
    .line 1028
    iput-object v2, v12, Lcom/transsnet/palmpay/ui/fragment/HomeFragmentHomeTab;->w0:LIe/m;

    .line 1029
    .line 1030
    check-cast v11, Ljava/util/List;

    .line 1031
    .line 1032
    invoke-virtual {v2, v11}, LIe/m;->c(Ljava/util/List;)V

    .line 1033
    .line 1034
    .line 1035
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1036
    .line 1037
    goto :goto_10

    .line 1038
    :cond_27
    :goto_f
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1039
    .line 1040
    :goto_10
    return-object v1

    .line 1041
    :pswitch_19
    move-object/from16 v1, p1

    .line 1042
    .line 1043
    check-cast v1, Ljava/lang/Long;

    .line 1044
    .line 1045
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 1046
    .line 1047
    .line 1048
    move-result-wide v1

    .line 1049
    sget v4, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawAgentPaymentResultActivity;->H:I

    .line 1050
    .line 1051
    check-cast v12, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawAgentPaymentResultActivity;

    .line 1052
    .line 1053
    invoke-virtual {v12}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawAgentPaymentResultActivity;->n()Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;

    .line 1054
    .line 1055
    .line 1056
    move-result-object v4

    .line 1057
    invoke-virtual {v4}, Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;->getOrderStatusTv()Landroid/widget/TextView;

    .line 1058
    .line 1059
    .line 1060
    move-result-object v4

    .line 1061
    int-to-long v6, v3

    .line 1062
    div-long/2addr v1, v6

    .line 1063
    new-instance v3, Ljava/lang/StringBuilder;

    .line 1064
    .line 1065
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 1066
    .line 1067
    .line 1068
    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 1069
    .line 1070
    .line 1071
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1072
    .line 1073
    .line 1074
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1075
    .line 1076
    .line 1077
    move-result-object v1

    .line 1078
    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1079
    .line 1080
    .line 1081
    invoke-virtual {v12}, Lcom/transsnet/palmpay/cash_in/ui/activity/WithdrawAgentPaymentResultActivity;->n()Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;

    .line 1082
    .line 1083
    .line 1084
    move-result-object v1

    .line 1085
    check-cast v11, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;

    .line 1086
    .line 1087
    iget-object v2, v11, Lcom/transsnet/palmpay/core/bean/payment/PayByOrderResp$DataBean;->pendingCountdownAcTips:Ljava/lang/String;

    .line 1088
    .line 1089
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/custom_view/model/TransactionResultHeaderModel;->h(Ljava/lang/CharSequence;)V

    .line 1090
    .line 1091
    .line 1092
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1093
    .line 1094
    return-object v1

    .line 1095
    :pswitch_1a
    move-object/from16 v1, p1

    .line 1096
    .line 1097
    check-cast v1, Ljava/util/List;

    .line 1098
    .line 1099
    new-instance v2, LB6/a;

    .line 1100
    .line 1101
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 1102
    .line 1103
    .line 1104
    check-cast v12, Lcom/google/mlkit/vision/common/InputImage;

    .line 1105
    .line 1106
    invoke-direct {v2, v1, v12}, LB6/a;-><init>(Ljava/util/List;Lcom/google/mlkit/vision/common/InputImage;)V

    .line 1107
    .line 1108
    .line 1109
    check-cast v11, Lkotlinx/coroutines/channels/ProducerScope;

    .line 1110
    .line 1111
    invoke-interface {v11, v2}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1112
    .line 1113
    .line 1114
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1115
    .line 1116
    return-object v1

    .line 1117
    :pswitch_1b
    move-object/from16 v3, p1

    .line 1118
    .line 1119
    check-cast v3, Lcom/mikepenz/iconics/IconicsDrawable;

    .line 1120
    .line 1121
    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1122
    .line 1123
    .line 1124
    invoke-static {v3, v1}, Lhf/a;->I(Lcom/mikepenz/iconics/IconicsDrawable;I)V

    .line 1125
    .line 1126
    .line 1127
    check-cast v12, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;

    .line 1128
    .line 1129
    invoke-virtual {v12}, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;->isSelect()Z

    .line 1130
    .line 1131
    .line 1132
    move-result v1

    .line 1133
    check-cast v11, LAd/g;

    .line 1134
    .line 1135
    if-eqz v1, :cond_28

    .line 1136
    .line 1137
    sget v1, LL6/b;->ppColorPrimary:I

    .line 1138
    .line 1139
    invoke-virtual {v11}, LM1/j;->getContext()Landroid/content/Context;

    .line 1140
    .line 1141
    .line 1142
    move-result-object v2

    .line 1143
    invoke-static {v1, v2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 1144
    .line 1145
    .line 1146
    move-result v1

    .line 1147
    goto :goto_11

    .line 1148
    :cond_28
    sget v1, LL6/b;->ppColorTextAssist:I

    .line 1149
    .line 1150
    invoke-virtual {v11}, LM1/j;->getContext()Landroid/content/Context;

    .line 1151
    .line 1152
    .line 1153
    move-result-object v2

    .line 1154
    invoke-static {v1, v2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 1155
    .line 1156
    .line 1157
    move-result v1

    .line 1158
    :goto_11
    invoke-static {v3, v1}, LD3/a;->F(Lcom/mikepenz/iconics/IconicsDrawable;I)V

    .line 1159
    .line 1160
    .line 1161
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1162
    .line 1163
    return-object v1

    .line 1164
    :pswitch_1c
    move-object/from16 v3, p1

    .line 1165
    .line 1166
    check-cast v3, Lcom/mikepenz/iconics/IconicsDrawable;

    .line 1167
    .line 1168
    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1169
    .line 1170
    .line 1171
    invoke-static {v3, v1}, Lhf/a;->I(Lcom/mikepenz/iconics/IconicsDrawable;I)V

    .line 1172
    .line 1173
    .line 1174
    check-cast v12, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;

    .line 1175
    .line 1176
    invoke-virtual {v12}, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;->isSelect()Z

    .line 1177
    .line 1178
    .line 1179
    move-result v1

    .line 1180
    check-cast v11, LAd/f;

    .line 1181
    .line 1182
    if-eqz v1, :cond_29

    .line 1183
    .line 1184
    sget v1, LL6/b;->ppColorPrimary:I

    .line 1185
    .line 1186
    invoke-virtual {v11}, LM1/j;->getContext()Landroid/content/Context;

    .line 1187
    .line 1188
    .line 1189
    move-result-object v2

    .line 1190
    invoke-static {v1, v2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 1191
    .line 1192
    .line 1193
    move-result v1

    .line 1194
    goto :goto_12

    .line 1195
    :cond_29
    sget v1, LL6/b;->ppColorTextAssist:I

    .line 1196
    .line 1197
    invoke-virtual {v11}, LM1/j;->getContext()Landroid/content/Context;

    .line 1198
    .line 1199
    .line 1200
    move-result-object v2

    .line 1201
    invoke-static {v1, v2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 1202
    .line 1203
    .line 1204
    move-result v1

    .line 1205
    :goto_12
    invoke-static {v3, v1}, LD3/a;->F(Lcom/mikepenz/iconics/IconicsDrawable;I)V

    .line 1206
    .line 1207
    .line 1208
    sget-object v1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 1209
    .line 1210
    return-object v1

    .line 1211
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
