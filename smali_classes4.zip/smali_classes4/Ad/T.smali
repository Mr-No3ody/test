.class public final synthetic LAd/T;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/T;->a:I

    iput-object p1, p0, LAd/T;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/T;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/T;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;->f(Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;)Lcom/mikepenz/iconics/view/IconicsImageView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/T;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;->d(Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LAd/T;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;->b(Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, LAd/T;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;->g(Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, p0, LAd/T;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;->a(Lcom/transsnet/palmpay/send_money/ui/dialog/NotificationEmailDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
