.class public final LAd/i;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

.field public final synthetic b:Ljava/util/List;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Ljava/util/List;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 1
    iput-object p1, p0, LAd/i;->a:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    .line 2
    .line 3
    iput-object p2, p0, LAd/i;->b:Ljava/util/List;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, LAd/i;

    .line 2
    .line 3
    iget-object v0, p0, LAd/i;->a:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    .line 4
    .line 5
    iget-object v1, p0, LAd/i;->b:Ljava/util/List;

    .line 6
    .line 7
    invoke-direct {p1, v0, v1, p2}, LAd/i;-><init>(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Ljava/util/List;Lkotlin/coroutines/Continuation;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LAd/i;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LAd/i;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LAd/i;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LAd/i;->a:Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;

    .line 7
    .line 8
    iget-object v0, p0, LAd/i;->b:Ljava/util/List;

    .line 9
    .line 10
    invoke-static {p1, v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;->access$setList(Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog;Ljava/util/List;)V

    .line 11
    .line 12
    .line 13
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 14
    .line 15
    return-object p1
.end method
