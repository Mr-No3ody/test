.class public final synthetic LAd/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;I)V
    .locals 0

    .line 1
    iput p2, p0, LAd/t;->a:I

    iput-object p1, p0, LAd/t;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LAd/t;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LAd/t;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;->f(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;)Lcom/mikepenz/iconics/view/IconicsImageView;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LAd/t;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;->h(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;)Landroid/widget/ImageView;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LAd/t;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;->e(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_2
    iget-object v0, p0, LAd/t;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;->g(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, p0, LAd/t;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;->d(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;)Landroid/widget/LinearLayout;

    move-result-object v0

    return-object v0

    :pswitch_4
    iget-object v0, p0, LAd/t;->b:Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;

    invoke-static {v0}, Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;->c(Lcom/transsnet/palmpay/send_money/ui/dialog/ConfirmScheduleTransferDialog;)Landroid/widget/TextView;

    move-result-object v0

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
