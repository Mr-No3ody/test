.class public final LAd/a0;
.super LM1/j;
.source "SourceFile"


# virtual methods
.method public final convert(Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/core/bean/BillProcessData2;

    .line 2
    .line 3
    const-string v0, "holder"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    const-string v0, "item"

    .line 9
    .line 10
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    sget v0, Lkd/e;->tv_progress_title:I

    .line 14
    .line 15
    iget-object v1, p2, Lcom/transsnet/palmpay/core/bean/BillProcessData2;->shortTips:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {p1, v0, v1}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sget v1, Lkd/e;->tv_progress_title:I

    .line 22
    .line 23
    invoke-virtual {p0}, LM1/j;->getContext()Landroid/content/Context;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    iget-boolean v3, p2, Lcom/transsnet/palmpay/core/bean/BillProcessData2;->selected:Z

    .line 28
    .line 29
    if-eqz v3, :cond_0

    .line 30
    .line 31
    sget v3, LL6/b;->ppColorTextPrimary:I

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    sget v3, LL6/b;->ppColorTextDisable:I

    .line 35
    .line 36
    :goto_0
    invoke-virtual {v2, v3}, Landroid/content/Context;->getColor(I)I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-virtual {v0, v1, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setTextColor(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    sget v1, Lkd/e;->tv_progress_tips:I

    .line 45
    .line 46
    iget-object v2, p2, Lcom/transsnet/palmpay/core/bean/BillProcessData2;->tips:Ljava/lang/String;

    .line 47
    .line 48
    invoke-virtual {v0, v1, v2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setText(ILjava/lang/CharSequence;)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    sget v1, Lkd/e;->v_divider:I

    .line 53
    .line 54
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getAdapterPosition()I

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    invoke-virtual {p0}, LM1/j;->getData()Ljava/util/List;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 63
    .line 64
    .line 65
    move-result v2

    .line 66
    const/4 v3, 0x1

    .line 67
    sub-int/2addr v2, v3

    .line 68
    if-ne p1, v2, :cond_1

    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_1
    const/4 v3, 0x0

    .line 72
    :goto_1
    invoke-virtual {v0, v1, v3}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setGone(IZ)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    sget v0, Lkd/e;->iv_progress:I

    .line 77
    .line 78
    iget p2, p2, Lcom/transsnet/palmpay/core/bean/BillProcessData2;->nodeStatus:I

    .line 79
    .line 80
    invoke-static {p2}, LPa/i0;->A(I)I

    .line 81
    .line 82
    .line 83
    move-result p2

    .line 84
    invoke-virtual {p1, v0, p2}, Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;->setImageResource(II)Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;

    .line 85
    .line 86
    .line 87
    return-void
.end method
