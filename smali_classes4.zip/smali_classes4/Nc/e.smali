.class public final LNc/e;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:Z

.field public c:Ljava/util/List;

.field public d:Lcom/transsnet/palmpay/custom_view/interfac/OnItemClickListener;

.field public e:Lcom/transsnet/palmpay/managemoney/ui/adapter/CashBoxTransactionMonthViewHolder$OnMonthClickListener;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LNc/d;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LNc/d;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(I)V
    .locals 1

    .line 1
    and-int/lit8 p1, p1, 0x2

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    move p1, v0

    .line 9
    :goto_0
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-boolean v0, p0, LNc/e;->a:Z

    .line 13
    .line 14
    iput-boolean p1, p0, LNc/e;->b:Z

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final a(I)Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;
    .locals 2

    .line 1
    const/4 v0, -0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-object v1

    .line 6
    :cond_0
    iget-object v0, p0, LNc/e;->c:Ljava/util/List;

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    goto :goto_0

    .line 15
    :cond_1
    const/4 v0, 0x0

    .line 16
    :goto_0
    if-gt v0, p1, :cond_2

    .line 17
    .line 18
    return-object v1

    .line 19
    :cond_2
    iget-object v0, p0, LNc/e;->c:Ljava/util/List;

    .line 20
    .line 21
    if-eqz v0, :cond_3

    .line 22
    .line 23
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    .line 28
    .line 29
    return-object p1

    .line 30
    :cond_3
    return-object v1
.end method

.method public final b(JJJ)V
    .locals 7

    .line 1
    iget-object v0, p0, LNc/e;->c:Ljava/util/List;

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    check-cast v0, Ljava/lang/Iterable;

    .line 7
    .line 8
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const/4 v2, 0x0

    .line 13
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    if-eqz v3, :cond_2

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    add-int/lit8 v4, v2, 0x1

    .line 24
    .line 25
    if-ltz v2, :cond_1

    .line 26
    .line 27
    check-cast v3, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    .line 28
    .line 29
    invoke-virtual {v3}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getItemType()I

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    const/4 v6, 0x1

    .line 34
    if-ne v5, v6, :cond_0

    .line 35
    .line 36
    invoke-virtual {v3}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getStartTime()J

    .line 37
    .line 38
    .line 39
    move-result-wide v5

    .line 40
    cmp-long v3, v5, p1

    .line 41
    .line 42
    if-nez v3, :cond_0

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_0
    move v2, v4

    .line 46
    goto :goto_0

    .line 47
    :cond_1
    invoke-static {}, Lkotlin/collections/q;->k()V

    .line 48
    .line 49
    .line 50
    const/4 p1, 0x0

    .line 51
    throw p1

    .line 52
    :cond_2
    move v2, v1

    .line 53
    :goto_1
    if-eq v2, v1, :cond_3

    .line 54
    .line 55
    invoke-virtual {p0, v2}, LNc/e;->a(I)Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    if-eqz p1, :cond_3

    .line 60
    .line 61
    invoke-virtual {p1, p3, p4}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->setInComeAmount(J)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p1, p5, p6}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->setPayOutAmount(J)V

    .line 65
    .line 66
    .line 67
    new-instance p1, Landroid/os/Bundle;

    .line 68
    .line 69
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 70
    .line 71
    .line 72
    invoke-virtual {p0, v2, p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyItemChanged(ILjava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    :cond_3
    return-void
.end method

.method public final getItemCount()I
    .locals 1

    .line 1
    iget-object v0, p0, LNc/e;->c:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    return v0
.end method

.method public final getItemViewType(I)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, LNc/e;->a(I)Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getItemType()I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1

    .line 12
    :cond_0
    const/4 p1, 0x0

    .line 13
    return p1
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 2

    .line 1
    check-cast p1, LNc/a;

    .line 2
    const-string v0, "holder"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-virtual {p0, p2}, LNc/e;->a(I)Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 4
    invoke-virtual {p1, p2, v0}, LNc/a;->a(ILjava/lang/Object;)V

    .line 5
    :cond_0
    new-instance p2, LAd/c0;

    const/16 v1, 0x1b

    invoke-direct {p2, v1, v0, p0}, LAd/c0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 6
    iput-object p2, p1, LNc/a;->a:Lcom/transsnet/palmpay/custom_view/interfac/OnItemClickListener;

    return-void
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;ILjava/util/List;)V
    .locals 1

    .line 7
    check-cast p1, LNc/a;

    .line 8
    const-string v0, "holder"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "payloads"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    invoke-interface {p3}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 10
    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;ILjava/util/List;)V

    return-void

    .line 11
    :cond_0
    invoke-virtual {p0, p2}, LNc/e;->a(I)Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    move-result-object p3

    if-eqz p3, :cond_1

    .line 12
    invoke-virtual {p1, p2, p3}, LNc/a;->a(ILjava/lang/Object;)V

    :cond_1
    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 4

    .line 1
    const-string v0, "parent"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    const-string v1, "inflate(...)"

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-ne p2, v0, :cond_0

    .line 11
    .line 12
    new-instance p2, LNc/f;

    .line 13
    .line 14
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    sget v3, LJc/d;->mm_item_history_month:I

    .line 23
    .line 24
    invoke-virtual {v0, v3, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, LNc/e;->e:Lcom/transsnet/palmpay/managemoney/ui/adapter/CashBoxTransactionMonthViewHolder$OnMonthClickListener;

    .line 32
    .line 33
    invoke-direct {p2, p1, v0}, LNc/f;-><init>(Landroid/view/View;Lcom/transsnet/palmpay/managemoney/ui/adapter/CashBoxTransactionMonthViewHolder$OnMonthClickListener;)V

    .line 34
    .line 35
    .line 36
    return-object p2

    .line 37
    :cond_0
    new-instance p2, LNc/h;

    .line 38
    .line 39
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sget v3, LJc/d;->mm_item_cash_box_transaction:I

    .line 48
    .line 49
    invoke-virtual {v0, v3, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    iget-boolean v0, p0, LNc/e;->a:Z

    .line 57
    .line 58
    iget-boolean v1, p0, LNc/e;->b:Z

    .line 59
    .line 60
    invoke-direct {p2, p1, v0, v1}, LNc/h;-><init>(Landroid/view/View;ZZ)V

    .line 61
    .line 62
    .line 63
    return-object p2
.end method
