.class public final synthetic LNc/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/custom_view/interfac/OnItemClickListener;
.implements Landroidx/camera/core/impl/utils/futures/AsyncFunction;
.implements Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;
.implements Landroidx/core/view/accessibility/AccessibilityViewCommand;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput-object p1, p0, LNc/v;->b:Ljava/lang/Object;

    iput p2, p0, LNc/v;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Lcom/google/common/util/concurrent/ListenableFuture;
    .locals 3

    .line 1
    check-cast p1, Landroid/hardware/camera2/TotalCaptureResult;

    .line 2
    .line 3
    iget-object v0, p0, LNc/v;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Landroidx/camera/camera2/internal/Z;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iget v1, p0, LNc/v;->a:I

    .line 11
    .line 12
    invoke-static {v1, p1}, Landroidx/camera/camera2/internal/g0;->c(ILandroid/hardware/camera2/TotalCaptureResult;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    sget-wide v1, Landroidx/camera/camera2/internal/Z;->k:J

    .line 19
    .line 20
    iput-wide v1, v0, Landroidx/camera/camera2/internal/Z;->g:J

    .line 21
    .line 22
    :cond_0
    iget-object v0, v0, Landroidx/camera/camera2/internal/Z;->i:Landroidx/camera/camera2/internal/X;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Landroidx/camera/camera2/internal/X;->preCapture(Landroid/hardware/camera2/TotalCaptureResult;)Lcom/google/common/util/concurrent/ListenableFuture;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    return-object p1
.end method

.method public attachCompleter(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, LNc/v;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/camera/camera2/internal/j1;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    new-instance v1, LH0/a;

    .line 9
    .line 10
    iget v2, p0, LNc/v;->a:I

    .line 11
    .line 12
    const/16 v3, 0x8

    .line 13
    .line 14
    invoke-direct {v1, v0, p1, v2, v3}, LH0/a;-><init>(Ljava/lang/Object;Ljava/lang/Object;II)V

    .line 15
    .line 16
    .line 17
    iget-object p1, v0, Landroidx/camera/camera2/internal/j1;->b:Landroidx/camera/core/impl/utils/executor/i;

    .line 18
    .line 19
    invoke-virtual {p1, v1}, Landroidx/camera/core/impl/utils/executor/i;->execute(Ljava/lang/Runnable;)V

    .line 20
    .line 21
    .line 22
    new-instance p1, Ljava/lang/StringBuilder;

    .line 23
    .line 24
    const-string v0, "setExposureCompensationIndex["

    .line 25
    .line 26
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    const-string v0, "]"

    .line 33
    .line 34
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    return-object p1
.end method

.method public onItemClick(Ljava/lang/Object;)V
    .locals 10

    .line 1
    iget-object p1, p0, LNc/v;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, LNc/A;

    .line 4
    .line 5
    iget v0, p1, LNc/A;->a:I

    .line 6
    .line 7
    iget v1, p0, LNc/v;->a:I

    .line 8
    .line 9
    const-string v2, "r2"

    .line 10
    .line 11
    const-string v3, "r1"

    .line 12
    .line 13
    const-string v4, "transType"

    .line 14
    .line 15
    const-string v5, "orderNo"

    .line 16
    .line 17
    const/4 v6, 0x0

    .line 18
    const/4 v7, 0x1

    .line 19
    iget v8, p1, LNc/A;->b:I

    .line 20
    .line 21
    if-eqz v0, :cond_4

    .line 22
    .line 23
    if-eq v0, v7, :cond_0

    .line 24
    .line 25
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 26
    .line 27
    return-void

    .line 28
    :cond_0
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    const-string v9, "/manage_money/detail_activity"

    .line 33
    .line 34
    invoke-virtual {v0, v9}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    if-ne v8, v7, :cond_1

    .line 39
    .line 40
    iget-object p1, p1, LNc/A;->c:Ljava/util/List;

    .line 41
    .line 42
    if-eqz p1, :cond_2

    .line 43
    .line 44
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    check-cast p1, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;

    .line 49
    .line 50
    if-eqz p1, :cond_2

    .line 51
    .line 52
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getMainOrderId()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v6

    .line 56
    goto :goto_0

    .line 57
    :cond_1
    iget-object p1, p1, LNc/A;->c:Ljava/util/List;

    .line 58
    .line 59
    if-eqz p1, :cond_2

    .line 60
    .line 61
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    check-cast p1, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;

    .line 66
    .line 67
    if-eqz p1, :cond_2

    .line 68
    .line 69
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getCashOrderId()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v6

    .line 73
    :cond_2
    :goto_0
    invoke-virtual {v0, v5, v6}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    if-ne v8, v7, :cond_3

    .line 78
    .line 79
    move-object v2, v3

    .line 80
    :cond_3
    invoke-virtual {p1, v4, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    return-void

    .line 88
    :cond_4
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    const-string v9, "/manage_money/plan_detail_activity"

    .line 93
    .line 94
    invoke-virtual {v0, v9}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    iget-object p1, p1, LNc/A;->c:Ljava/util/List;

    .line 99
    .line 100
    if-eqz p1, :cond_5

    .line 101
    .line 102
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    check-cast p1, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;

    .line 107
    .line 108
    if-eqz p1, :cond_5

    .line 109
    .line 110
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getOrderId()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v6

    .line 114
    :cond_5
    invoke-virtual {v0, v5, v6}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    if-ne v8, v7, :cond_6

    .line 119
    .line 120
    move-object v2, v3

    .line 121
    :cond_6
    invoke-virtual {p1, v4, v2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 122
    .line 123
    .line 124
    move-result-object p1

    .line 125
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    return-void
.end method

.method public perform(Landroid/view/View;Lf0/h;)Z
    .locals 1

    .line 1
    iget-object p2, p0, LNc/v;->b:Ljava/lang/Object;

    check-cast p2, Lcom/google/android/material/sidesheet/SideSheetBehavior;

    iget v0, p0, LNc/v;->a:I

    invoke-static {p2, p1, v0}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->a(Lcom/google/android/material/sidesheet/SideSheetBehavior;Landroid/view/View;I)Z

    move-result p1

    return p1
.end method
