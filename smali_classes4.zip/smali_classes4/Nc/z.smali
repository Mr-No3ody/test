.class public final LNc/z;
.super LNc/a;
.source "SourceFile"


# instance fields
.field public A:Landroid/widget/TextView;

.field public b:Landroid/widget/ImageView;

.field public c:Landroid/widget/TextView;

.field public d:Landroid/widget/TextView;

.field public e:Landroid/widget/TextView;

.field public f:Landroid/widget/TextView;

.field public g:Landroid/widget/TextView;

.field public i:Landroid/widget/TextView;

.field public j:Landroid/widget/TextView;

.field public o:Lcom/mikepenz/iconics/view/IconicsImageView;

.field public p:Landroid/widget/TextView;

.field public t:I

.field public v:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public w:Landroid/widget/TextView;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LNc/y;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LNc/y;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final a(ILjava/lang/Object;)V
    .locals 5

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;

    .line 2
    .line 3
    invoke-super {p0, p1, p2}, LNc/a;->a(ILjava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    sget v0, LJc/f;->mm_amount_currency_symbol:I

    .line 13
    .line 14
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrencySymbol()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {p1, v0, v1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    iget-object v0, p0, LNc/z;->i:Landroid/widget/TextView;

    .line 27
    .line 28
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 29
    .line 30
    .line 31
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 32
    .line 33
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    iget v0, p0, LNc/z;->t:I

    .line 38
    .line 39
    const/4 v1, 0x1

    .line 40
    if-ne v0, v1, :cond_0

    .line 41
    .line 42
    sget v0, LJc/f;->mm_expected_interest_currency_symbol:I

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    sget v0, LJc/f;->mm_interest_currency_symbol:I

    .line 46
    .line 47
    :goto_0
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getCurrencySymbol()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    invoke-virtual {p1, v0, v2}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    iget-object v0, p0, LNc/z;->j:Landroid/widget/TextView;

    .line 60
    .line 61
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 62
    .line 63
    .line 64
    if-eqz p2, :cond_c

    .line 65
    .line 66
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductIcon()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    sget v0, Lcom/transsnet/palmpay/custom_view/r;->cv_fixed_saving:I

    .line 71
    .line 72
    iget-object v2, p0, LNc/z;->b:Landroid/widget/ImageView;

    .line 73
    .line 74
    invoke-static {v2, p1, v0}, LPa/r0;->h1(Landroid/widget/ImageView;Ljava/lang/String;I)V

    .line 75
    .line 76
    .line 77
    iget-object p1, p0, LNc/z;->c:Landroid/widget/TextView;

    .line 78
    .line 79
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getShowName()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAnnualizedIncomeRatio()F

    .line 87
    .line 88
    .line 89
    move-result p1

    .line 90
    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    const-string v0, "100"

    .line 95
    .line 96
    invoke-static {p1, v0}, LPa/r0;->w1(Ljava/lang/String;Ljava/lang/String;)Ljava/math/BigDecimal;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-virtual {p1}, Ljava/math/BigDecimal;->toPlainString()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    invoke-static {p1}, LPa/r0;->z0(Ljava/lang/String;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    const-string v0, "%p.a."

    .line 109
    .line 110
    invoke-static {p1, v0}, LN8/q0;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    iget-object v0, p0, LNc/z;->d:Landroid/widget/TextView;

    .line 115
    .line 116
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getPrincipal()J

    .line 120
    .line 121
    .line 122
    move-result-wide v2

    .line 123
    invoke-static {v2, v3}, LPa/r0;->A(J)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object p1

    .line 127
    iget-object v0, p0, LNc/z;->e:Landroid/widget/TextView;

    .line 128
    .line 129
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 130
    .line 131
    .line 132
    const-string p1, "fonts/PalmPayNum-Bold.ttf"

    .line 133
    .line 134
    invoke-static {v0, p1}, LPa/r0;->R1(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    sget-object v0, Lcom/transsnet/palmpay/managemoney/bean/PlanStatusFactory;->Companion:Lcom/transsnet/palmpay/managemoney/bean/PlanStatusFactory$Companion;

    .line 138
    .line 139
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getPlanStatus()I

    .line 140
    .line 141
    .line 142
    move-result v2

    .line 143
    invoke-virtual {v0, v2}, Lcom/transsnet/palmpay/managemoney/bean/PlanStatusFactory$Companion;->produce(I)Lcom/transsnet/palmpay/managemoney/bean/PlanStatus;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 148
    .line 149
    invoke-virtual {v2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 150
    .line 151
    .line 152
    move-result-object v2

    .line 153
    invoke-virtual {v0}, Lcom/transsnet/palmpay/managemoney/bean/PlanStatus;->getPlanStatusText()I

    .line 154
    .line 155
    .line 156
    move-result v3

    .line 157
    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v2

    .line 161
    iget-object v3, p0, LNc/z;->f:Landroid/widget/TextView;

    .line 162
    .line 163
    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 164
    .line 165
    .line 166
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 167
    .line 168
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    invoke-virtual {v0}, Lcom/transsnet/palmpay/managemoney/bean/PlanStatus;->getPlanStatusColor()I

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    invoke-virtual {v2, v0}, Landroid/content/Context;->getColor(I)I

    .line 177
    .line 178
    .line 179
    move-result v0

    .line 180
    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getInterestSwitchStatus()I

    .line 184
    .line 185
    .line 186
    move-result v0

    .line 187
    if-ne v0, v1, :cond_1

    .line 188
    .line 189
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 190
    .line 191
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    sget v2, Lba/k;->core_disabled:I

    .line 196
    .line 197
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    goto :goto_1

    .line 202
    :cond_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getEarning()J

    .line 203
    .line 204
    .line 205
    move-result-wide v2

    .line 206
    invoke-static {v2, v3}, LPa/r0;->A(J)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    :goto_1
    iget-object v2, p0, LNc/z;->g:Landroid/widget/TextView;

    .line 211
    .line 212
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 213
    .line 214
    .line 215
    invoke-static {v2, p1}, LPa/r0;->R1(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getInterestSwitchStatus()I

    .line 219
    .line 220
    .line 221
    move-result p1

    .line 222
    const/16 v0, 0x8

    .line 223
    .line 224
    const/4 v3, 0x0

    .line 225
    if-ne p1, v1, :cond_2

    .line 226
    .line 227
    move p1, v3

    .line 228
    goto :goto_2

    .line 229
    :cond_2
    move p1, v0

    .line 230
    :goto_2
    iget-object v4, p0, LNc/z;->o:Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 231
    .line 232
    invoke-virtual {v4, p1}, Landroid/view/View;->setVisibility(I)V

    .line 233
    .line 234
    .line 235
    new-instance p1, LNc/x;

    .line 236
    .line 237
    const/4 v4, 0x0

    .line 238
    invoke-direct {p1, p2, v4}, LNc/x;-><init>(Ljava/lang/Object;I)V

    .line 239
    .line 240
    .line 241
    invoke-virtual {v2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getRenewDepositSwitch()I

    .line 245
    .line 246
    .line 247
    move-result p1

    .line 248
    if-ne p1, v1, :cond_3

    .line 249
    .line 250
    goto :goto_3

    .line 251
    :cond_3
    move v1, v3

    .line 252
    :goto_3
    iget-object p1, p0, LNc/z;->p:Landroid/widget/TextView;

    .line 253
    .line 254
    if-eqz p1, :cond_5

    .line 255
    .line 256
    if-eqz v1, :cond_4

    .line 257
    .line 258
    move v1, v3

    .line 259
    goto :goto_4

    .line 260
    :cond_4
    move v1, v0

    .line 261
    :goto_4
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 262
    .line 263
    .line 264
    :cond_5
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getHasAdvance()Z

    .line 265
    .line 266
    .line 267
    move-result p1

    .line 268
    iget-object v1, p0, LNc/z;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 269
    .line 270
    if-eqz p1, :cond_b

    .line 271
    .line 272
    if-eqz v1, :cond_7

    .line 273
    .line 274
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAdvanceSummary()Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;

    .line 275
    .line 276
    .line 277
    move-result-object p1

    .line 278
    if-eqz p1, :cond_6

    .line 279
    .line 280
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAdvanceSummary()Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;

    .line 281
    .line 282
    .line 283
    move-result-object p1

    .line 284
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;->getAdvanceNo()Ljava/lang/String;

    .line 285
    .line 286
    .line 287
    move-result-object p1

    .line 288
    if-eqz p1, :cond_6

    .line 289
    .line 290
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 291
    .line 292
    .line 293
    move-result p1

    .line 294
    if-lez p1, :cond_6

    .line 295
    .line 296
    move v0, v3

    .line 297
    :cond_6
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 298
    .line 299
    .line 300
    :cond_7
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAdvanceSummary()Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;

    .line 301
    .line 302
    .line 303
    move-result-object p1

    .line 304
    const-wide/16 v0, 0x0

    .line 305
    .line 306
    if-eqz p1, :cond_a

    .line 307
    .line 308
    iget-object p1, p0, LNc/z;->w:Landroid/widget/TextView;

    .line 309
    .line 310
    if-eqz p1, :cond_a

    .line 311
    .line 312
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAdvanceSummary()Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;

    .line 313
    .line 314
    .line 315
    move-result-object v2

    .line 316
    if-eqz v2, :cond_8

    .line 317
    .line 318
    invoke-virtual {v2}, Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;->getTotalRepayableAmount()Ljava/lang/Long;

    .line 319
    .line 320
    .line 321
    move-result-object v2

    .line 322
    if-eqz v2, :cond_8

    .line 323
    .line 324
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 325
    .line 326
    .line 327
    move-result-wide v2

    .line 328
    goto :goto_5

    .line 329
    :cond_8
    move-wide v2, v0

    .line 330
    :goto_5
    invoke-static {v2, v3}, LPa/r0;->A(J)Ljava/lang/String;

    .line 331
    .line 332
    .line 333
    move-result-object v2

    .line 334
    if-eqz v2, :cond_9

    .line 335
    .line 336
    const-string v3, ""

    .line 337
    .line 338
    const-string v4, ".00"

    .line 339
    .line 340
    invoke-static {v2, v4, v3}, Lkotlin/text/y;->k(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 341
    .line 342
    .line 343
    move-result-object v2

    .line 344
    goto :goto_6

    .line 345
    :cond_9
    const/4 v2, 0x0

    .line 346
    :goto_6
    const-string v3, "Advance: \u20a6"

    .line 347
    .line 348
    invoke-static {v3, v2, p1}, LC0/G;->x(Ljava/lang/String;Ljava/lang/String;Landroid/widget/TextView;)V

    .line 349
    .line 350
    .line 351
    :cond_a
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAdvanceSummary()Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;

    .line 352
    .line 353
    .line 354
    move-result-object p1

    .line 355
    if-eqz p1, :cond_c

    .line 356
    .line 357
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAdvanceSummary()Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;

    .line 358
    .line 359
    .line 360
    move-result-object p1

    .line 361
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;->getDueDate()J

    .line 362
    .line 363
    .line 364
    move-result-wide v2

    .line 365
    cmp-long p1, v2, v0

    .line 366
    .line 367
    if-lez p1, :cond_c

    .line 368
    .line 369
    iget-object p1, p0, LNc/z;->A:Landroid/widget/TextView;

    .line 370
    .line 371
    if-eqz p1, :cond_c

    .line 372
    .line 373
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAdvanceSummary()Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;

    .line 374
    .line 375
    .line 376
    move-result-object p2

    .line 377
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/AdvanceSummary;->getDueDate()J

    .line 378
    .line 379
    .line 380
    move-result-wide v0

    .line 381
    new-instance p2, Ljava/text/SimpleDateFormat;

    .line 382
    .line 383
    const-string v2, "dd MMM yyyy"

    .line 384
    .line 385
    sget-object v3, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 386
    .line 387
    invoke-direct {p2, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 388
    .line 389
    .line 390
    invoke-static {v0, v1, p2}, Lcom/transsnet/palmpay/util/TimeUtils;->millis2String(JLjava/text/DateFormat;)Ljava/lang/String;

    .line 391
    .line 392
    .line 393
    move-result-object p2

    .line 394
    const-string v0, "Due: "

    .line 395
    .line 396
    invoke-static {v0, p2, p1}, LC0/G;->x(Ljava/lang/String;Ljava/lang/String;Landroid/widget/TextView;)V

    .line 397
    .line 398
    .line 399
    return-void

    .line 400
    :cond_b
    if-eqz v1, :cond_c

    .line 401
    .line 402
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 403
    .line 404
    .line 405
    :cond_c
    return-void
.end method

.method public final b(Landroid/os/Bundle;)V
    .locals 4

    .line 1
    invoke-virtual {p1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "keySet(...)"

    .line 6
    .line 7
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_1

    .line 19
    .line 20
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    check-cast v1, Ljava/lang/String;

    .line 25
    .line 26
    const-string v2, "plan_status"

    .line 27
    .line 28
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_0

    .line 33
    .line 34
    sget-object v2, Lcom/transsnet/palmpay/managemoney/bean/PlanStatusFactory;->Companion:Lcom/transsnet/palmpay/managemoney/bean/PlanStatusFactory$Companion;

    .line 35
    .line 36
    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-virtual {v2, v1}, Lcom/transsnet/palmpay/managemoney/bean/PlanStatusFactory$Companion;->produce(I)Lcom/transsnet/palmpay/managemoney/bean/PlanStatus;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 45
    .line 46
    invoke-virtual {v2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-virtual {v1}, Lcom/transsnet/palmpay/managemoney/bean/PlanStatus;->getPlanStatusText()I

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    iget-object v3, p0, LNc/z;->f:Landroid/widget/TextView;

    .line 59
    .line 60
    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 61
    .line 62
    .line 63
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 64
    .line 65
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    invoke-virtual {v1}, Lcom/transsnet/palmpay/managemoney/bean/PlanStatus;->getPlanStatusColor()I

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    invoke-virtual {v2, v1}, Landroid/content/Context;->getColor(I)I

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 78
    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_1
    return-void
.end method
