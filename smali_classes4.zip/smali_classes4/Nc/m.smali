.class public final synthetic LNc/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/adsdk/data/local/entity/AdEntity;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/adsdk/data/local/entity/AdEntity;I)V
    .locals 0

    .line 1
    iput p2, p0, LNc/m;->a:I

    iput-object p1, p0, LNc/m;->b:Lcom/transsnet/adsdk/data/local/entity/AdEntity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget v0, p0, LNc/m;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LNc/m;->b:Lcom/transsnet/adsdk/data/local/entity/AdEntity;

    .line 7
    .line 8
    invoke-static {v0}, Lcom/transsnet/adsdk/AdManager;->d(Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    iget-object v0, p0, LNc/m;->b:Lcom/transsnet/adsdk/data/local/entity/AdEntity;

    .line 13
    .line 14
    invoke-static {v0}, Lcom/transsnet/adsdk/AdManager;->a(Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_1
    iget-object v0, p0, LNc/m;->b:Lcom/transsnet/adsdk/data/local/entity/AdEntity;

    .line 19
    .line 20
    invoke-static {v0}, Lorg/chromium/support_lib_boundary/util/b;->P(Lcom/transsnet/adsdk/data/local/entity/AdEntity;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
