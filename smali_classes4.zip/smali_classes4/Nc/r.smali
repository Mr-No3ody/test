.class public final LNc/r;
.super LNc/a;
.source "SourceFile"


# instance fields
.field public final b:Landroid/widget/ImageView;

.field public final c:Landroid/widget/TextView;

.field public final d:Landroid/widget/TextView;

.field public final e:Lcom/transsnet/palmpay/custom_view/RoundedTextView;

.field public final synthetic f:LNc/s;


# direct methods
.method public constructor <init>(LNc/s;Landroid/view/View;)V
    .locals 1

    .line 1
    const-string v0, "itemView"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, LNc/r;->f:LNc/s;

    .line 7
    .line 8
    invoke-direct {p0, p2}, LNc/a;-><init>(Landroid/view/View;)V

    .line 9
    .line 10
    .line 11
    sget p1, LJc/c;->ivIcon:I

    .line 12
    .line 13
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    const-string v0, "findViewById(...)"

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    check-cast p1, Landroid/widget/ImageView;

    .line 23
    .line 24
    iput-object p1, p0, LNc/r;->b:Landroid/widget/ImageView;

    .line 25
    .line 26
    sget p1, LJc/c;->tvInterestAmount:I

    .line 27
    .line 28
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    check-cast p1, Landroid/widget/TextView;

    .line 36
    .line 37
    iput-object p1, p0, LNc/r;->c:Landroid/widget/TextView;

    .line 38
    .line 39
    sget p1, LJc/c;->tvDurationNum:I

    .line 40
    .line 41
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    check-cast p1, Landroid/widget/TextView;

    .line 49
    .line 50
    iput-object p1, p0, LNc/r;->d:Landroid/widget/TextView;

    .line 51
    .line 52
    sget p1, LJc/c;->rtvInvest:I

    .line 53
    .line 54
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    check-cast p1, Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 62
    .line 63
    iput-object p1, p0, LNc/r;->e:Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 64
    .line 65
    return-void
.end method


# virtual methods
.method public final a(ILjava/lang/Object;)V
    .locals 6

    .line 1
    invoke-super {p0, p1, p2}, LNc/a;->a(ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    if-eqz p2, :cond_b

    .line 5
    .line 6
    check-cast p2, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;

    .line 7
    .line 8
    iget-object v0, p0, LNc/r;->f:LNc/s;

    .line 9
    .line 10
    iget-object v1, v0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    invoke-virtual {v1}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getProductList()Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const/4 v1, 0x0

    .line 26
    :goto_0
    const/4 v2, 0x0

    .line 27
    const/4 v3, 0x1

    .line 28
    if-ne v1, v3, :cond_4

    .line 29
    .line 30
    iget-object p1, v0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 31
    .line 32
    if-eqz p1, :cond_1

    .line 33
    .line 34
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getExclusiveList()Ljava/util/List;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    :cond_1
    check-cast v2, Ljava/util/Collection;

    .line 39
    .line 40
    if-eqz v2, :cond_3

    .line 41
    .line 42
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    if-eqz p1, :cond_2

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_2
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 50
    .line 51
    sget v1, LJc/b;->mm_bg_product_info_bottom:I

    .line 52
    .line 53
    invoke-virtual {p1, v1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 54
    .line 55
    .line 56
    goto :goto_3

    .line 57
    :cond_3
    :goto_1
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 58
    .line 59
    sget v1, Lcom/transsnet/palmpay/custom_view/r;->cv_rect_corner_12_bg_white:I

    .line 60
    .line 61
    invoke-virtual {p1, v1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 62
    .line 63
    .line 64
    goto :goto_3

    .line 65
    :cond_4
    iget-object v4, v0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 66
    .line 67
    if-eqz v4, :cond_5

    .line 68
    .line 69
    invoke-virtual {v4}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getExclusiveList()Ljava/util/List;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    :cond_5
    check-cast v2, Ljava/util/Collection;

    .line 74
    .line 75
    if-eqz v2, :cond_6

    .line 76
    .line 77
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    if-eqz v2, :cond_7

    .line 82
    .line 83
    :cond_6
    if-nez p1, :cond_7

    .line 84
    .line 85
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 86
    .line 87
    sget v1, LJc/b;->mm_bg_product_info_top:I

    .line 88
    .line 89
    invoke-virtual {p1, v1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 90
    .line 91
    .line 92
    goto :goto_3

    .line 93
    :cond_7
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 94
    .line 95
    sub-int/2addr v1, v3

    .line 96
    if-ne p1, v1, :cond_8

    .line 97
    .line 98
    sget p1, LJc/b;->mm_bg_product_info_bottom:I

    .line 99
    .line 100
    goto :goto_2

    .line 101
    :cond_8
    sget p1, LJc/b;->mm_bg_product_info_middle:I

    .line 102
    .line 103
    :goto_2
    invoke-virtual {v2, p1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 104
    .line 105
    .line 106
    :goto_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductIcon()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    sget v1, Lcom/transsnet/palmpay/custom_view/r;->cv_fixed_saving:I

    .line 111
    .line 112
    iget-object v2, p0, LNc/r;->b:Landroid/widget/ImageView;

    .line 113
    .line 114
    invoke-static {v2, p1, v1}, LPa/r0;->h1(Landroid/widget/ImageView;Ljava/lang/String;I)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getAnnualizedIncomeRatio()F

    .line 118
    .line 119
    .line 120
    move-result p1

    .line 121
    invoke-static {p1}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object p1

    .line 125
    const-string v1, "100"

    .line 126
    .line 127
    invoke-static {p1, v1}, LPa/r0;->w1(Ljava/lang/String;Ljava/lang/String;)Ljava/math/BigDecimal;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    invoke-virtual {p1}, Ljava/math/BigDecimal;->toPlainString()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    invoke-static {p1}, LPa/r0;->z0(Ljava/lang/String;)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    iget-object v1, p0, LNc/r;->c:Landroid/widget/TextView;

    .line 140
    .line 141
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getDurationDay()J

    .line 145
    .line 146
    .line 147
    move-result-wide v4

    .line 148
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getMaxDurationDay()I

    .line 149
    .line 150
    .line 151
    move-result p1

    .line 152
    new-instance v2, Ljava/lang/StringBuilder;

    .line 153
    .line 154
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    const-string v4, "-"

    .line 161
    .line 162
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 163
    .line 164
    .line 165
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    iget-object v2, p0, LNc/r;->d:Landroid/widget/TextView;

    .line 173
    .line 174
    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductStatus()I

    .line 178
    .line 179
    .line 180
    move-result p1

    .line 181
    const/4 v2, 0x7

    .line 182
    if-eq p1, v2, :cond_a

    .line 183
    .line 184
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductStatus()I

    .line 185
    .line 186
    .line 187
    move-result p1

    .line 188
    if-ne p1, v3, :cond_9

    .line 189
    .line 190
    goto :goto_4

    .line 191
    :cond_9
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 192
    .line 193
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 194
    .line 195
    .line 196
    move-result-object p1

    .line 197
    sget v2, LL6/b;->ppColorPrimary:I

    .line 198
    .line 199
    invoke-virtual {p1, v2}, Landroid/content/Context;->getColor(I)I

    .line 200
    .line 201
    .line 202
    move-result p1

    .line 203
    goto :goto_5

    .line 204
    :cond_a
    :goto_4
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 205
    .line 206
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 207
    .line 208
    .line 209
    move-result-object p1

    .line 210
    sget v2, LJc/a;->mm_color_caaee4:I

    .line 211
    .line 212
    invoke-virtual {p1, v2}, Landroid/content/Context;->getColor(I)I

    .line 213
    .line 214
    .line 215
    move-result p1

    .line 216
    :goto_5
    iget-object v2, p0, LNc/r;->e:Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 217
    .line 218
    invoke-virtual {v2, p1}, Lcom/transsnet/palmpay/custom_view/RoundedTextView;->setRoundedBackgroundColor(I)V

    .line 219
    .line 220
    .line 221
    new-instance p1, LB6/i;

    .line 222
    .line 223
    const/16 v3, 0xf

    .line 224
    .line 225
    invoke-direct {p1, v0, v3, p0, p2}, LB6/i;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {v2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 229
    .line 230
    .line 231
    const-string p1, "fonts/PalmPayNum-Bold.ttf"

    .line 232
    .line 233
    invoke-static {v1, p1}, LPa/r0;->R1(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    :cond_b
    return-void
.end method
