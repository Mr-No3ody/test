.class public final LNc/n;
.super LNc/a;
.source "SourceFile"


# static fields
.field public static final synthetic c:I


# instance fields
.field public b:Lcom/transsnet/adsdk/widgets/banner/BannerAdView;


# virtual methods
.method public final b(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    const/4 p1, 0x1

    .line 2
    const/4 v0, 0x0

    .line 3
    iget-object v1, p0, LNc/n;->b:Lcom/transsnet/adsdk/widgets/banner/BannerAdView;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-static {v1, v2, p1, v0}, Lcom/transsnet/adsdk/widgets/banner/BannerAdView;->refreshData$default(Lcom/transsnet/adsdk/widgets/banner/BannerAdView;ZILjava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
