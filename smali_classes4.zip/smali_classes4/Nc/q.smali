.class public final LNc/q;
.super LNc/a;
.source "SourceFile"


# instance fields
.field public final b:Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings;

.field public final synthetic c:LNc/s;


# direct methods
.method public constructor <init>(LNc/s;Landroid/view/View;)V
    .locals 2

    .line 1
    const-string v0, "itemView"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, LNc/q;->c:LNc/s;

    .line 7
    .line 8
    invoke-direct {p0, p2}, LNc/a;-><init>(Landroid/view/View;)V

    .line 9
    .line 10
    .line 11
    sget p1, LJc/c;->modelNewCustomerSavings:I

    .line 12
    .line 13
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    const-string v0, "findViewById(...)"

    .line 18
    .line 19
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    check-cast p1, Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings;

    .line 23
    .line 24
    iput-object p1, p0, LNc/q;->b:Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings;

    .line 25
    .line 26
    sget p1, LJc/c;->tvSecurity:I

    .line 27
    .line 28
    invoke-virtual {p2, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    check-cast p1, Lcom/mikepenz/iconics/view/IconicsTextView;

    .line 36
    .line 37
    sget v1, LJc/c;->iv_title:I

    .line 38
    .line 39
    invoke-virtual {p2, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    check-cast v1, Landroid/widget/ImageView;

    .line 47
    .line 48
    invoke-static {}, LPa/i0;->T()Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_0

    .line 53
    .line 54
    sget v0, LL6/b;->ppColorTextPrimary:I

    .line 55
    .line 56
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 57
    .line 58
    .line 59
    move-result-object p2

    .line 60
    invoke-static {v0, p2}, Lcom/transsnet/palmpay/custom_view/utils/CommonViewExtKt;->colorInt(ILandroid/content/Context;)I

    .line 61
    .line 62
    .line 63
    move-result p2

    .line 64
    if-eqz v1, :cond_0

    .line 65
    .line 66
    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 67
    .line 68
    .line 69
    :cond_0
    if-eqz p1, :cond_1

    .line 70
    .line 71
    new-instance p2, LK8/a;

    .line 72
    .line 73
    const/16 v0, 0xd

    .line 74
    .line 75
    invoke-direct {p2, v0}, LK8/a;-><init>(I)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 79
    .line 80
    .line 81
    :cond_1
    return-void
.end method


# virtual methods
.method public final a(ILjava/lang/Object;)V
    .locals 4

    .line 1
    invoke-super {p0, p1, p2}, LNc/a;->a(ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    if-eqz p2, :cond_7

    .line 5
    .line 6
    check-cast p2, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 7
    .line 8
    new-instance p1, LNc/p;

    .line 9
    .line 10
    iget-object v0, p0, LNc/q;->c:LNc/s;

    .line 11
    .line 12
    invoke-direct {p1, v0, p0}, LNc/p;-><init>(LNc/s;LNc/q;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, LNc/q;->b:Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings;

    .line 16
    .line 17
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings;->setOnInvestBtnClickListener(Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings$OnInvestBtnClickListener;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getExclusiveList()Ljava/util/List;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    check-cast p1, Ljava/util/Collection;

    .line 25
    .line 26
    if-eqz p1, :cond_3

    .line 27
    .line 28
    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    if-eqz p1, :cond_0

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_0
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getExclusiveList()Ljava/util/List;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    check-cast p1, Ljava/lang/Iterable;

    .line 43
    .line 44
    new-instance v1, Ljava/util/ArrayList;

    .line 45
    .line 46
    const/16 v2, 0xa

    .line 47
    .line 48
    invoke-static {p1, v2}, Lkotlin/collections/r;->l(Ljava/lang/Iterable;I)I

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 53
    .line 54
    .line 55
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    if-eqz v2, :cond_2

    .line 64
    .line 65
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    check-cast v2, Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;

    .line 70
    .line 71
    invoke-virtual {v2}, Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;->getIntroduction()Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 76
    .line 77
    .line 78
    move-result v3

    .line 79
    if-eqz v3, :cond_1

    .line 80
    .line 81
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getExclusiveListContent()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;->setIntroduction(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    :cond_1
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_2
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->Y(Ljava/lang/Iterable;)Ljava/util/List;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    goto :goto_2

    .line 97
    :cond_3
    :goto_1
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getExclusiveList()Ljava/util/List;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    :goto_2
    sget p2, Lcom/transsnet/palmpay/custom_view/r;->cv_rect_corner_12_bg_white:I

    .line 102
    .line 103
    move-object v1, p1

    .line 104
    check-cast v1, Ljava/util/Collection;

    .line 105
    .line 106
    if-eqz v1, :cond_5

    .line 107
    .line 108
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-eqz v1, :cond_4

    .line 113
    .line 114
    goto :goto_3

    .line 115
    :cond_4
    const/4 v1, 0x0

    .line 116
    goto :goto_4

    .line 117
    :cond_5
    :goto_3
    const/16 v1, 0x8

    .line 118
    .line 119
    :goto_4
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 120
    .line 121
    .line 122
    iput p2, v0, Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings;->d:I

    .line 123
    .line 124
    iget-object p2, v0, Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings;->c:Lcom/transsnet/palmpay/main/export/ui/view/a;

    .line 125
    .line 126
    if-eqz p2, :cond_6

    .line 127
    .line 128
    iput-object p1, p2, Lcom/transsnet/palmpay/main/export/ui/view/a;->a:Ljava/util/List;

    .line 129
    .line 130
    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 131
    .line 132
    .line 133
    return-void

    .line 134
    :cond_6
    const-string p1, "mNewUserCustomerSavingsAdapter"

    .line 135
    .line 136
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->n(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    const/4 p1, 0x0

    .line 140
    throw p1

    .line 141
    :cond_7
    return-void
.end method

.method public final b(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    return-void
.end method
