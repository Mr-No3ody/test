.class public final LNc/s;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "SourceFile"


# static fields
.field public static final synthetic c:I


# instance fields
.field public a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

.field public b:Lcom/transsnet/palmpay/managemoney/ui/fragment/O;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LNc/o;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LNc/o;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final getItemCount()I
    .locals 4

    .line 1
    iget-object v0, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_4

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getProductList()Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-ne v0, v1, :cond_0

    .line 19
    .line 20
    goto :goto_1

    .line 21
    :cond_0
    iget-object v0, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    invoke-virtual {v0}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getProductList()Ljava/util/List;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    goto :goto_0

    .line 37
    :cond_1
    move v0, v2

    .line 38
    :goto_0
    iget-object v3, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 39
    .line 40
    if-eqz v3, :cond_2

    .line 41
    .line 42
    invoke-virtual {v3}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getFixedSavingShow()Ljava/lang/Boolean;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 47
    .line 48
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    :cond_2
    if-eqz v2, :cond_3

    .line 53
    .line 54
    add-int/2addr v0, v1

    .line 55
    return v0

    .line 56
    :cond_3
    add-int/lit8 v0, v0, 0x2

    .line 57
    .line 58
    return v0

    .line 59
    :cond_4
    :goto_1
    return v1
.end method

.method public final getItemViewType(I)I
    .locals 5

    .line 1
    iget-object v0, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_7

    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getProductList()Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-ne v0, v2, :cond_0

    .line 20
    .line 21
    goto :goto_2

    .line 22
    :cond_0
    iget-object v0, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 23
    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    invoke-virtual {v0}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getProductList()Ljava/util/List;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    goto :goto_0

    .line 37
    :cond_1
    move v0, v1

    .line 38
    :goto_0
    iget-object v3, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    .line 39
    .line 40
    if-eqz v3, :cond_2

    .line 41
    .line 42
    invoke-virtual {v3}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getFixedSavingShow()Ljava/lang/Boolean;

    .line 43
    .line 44
    .line 45
    move-result-object v3

    .line 46
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 47
    .line 48
    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    goto :goto_1

    .line 53
    :cond_2
    move v3, v1

    .line 54
    :goto_1
    if-eqz v3, :cond_4

    .line 55
    .line 56
    if-nez p1, :cond_3

    .line 57
    .line 58
    return v1

    .line 59
    :cond_3
    return v2

    .line 60
    :cond_4
    add-int/2addr v0, v2

    .line 61
    if-ne p1, v0, :cond_5

    .line 62
    .line 63
    const/4 p1, 0x2

    .line 64
    return p1

    .line 65
    :cond_5
    if-nez p1, :cond_6

    .line 66
    .line 67
    return v1

    .line 68
    :cond_6
    return v2

    .line 69
    :cond_7
    :goto_2
    return v1
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 3

    .line 1
    check-cast p1, LNc/a;

    .line 2
    const-string v0, "holder"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-virtual {p0, p2}, LNc/s;->getItemViewType(I)I

    move-result v0

    if-nez v0, :cond_0

    .line 4
    iget-object v0, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    invoke-virtual {p1, p2, v0}, LNc/a;->a(ILjava/lang/Object;)V

    return-void

    .line 5
    :cond_0
    invoke-virtual {p0, p2}, LNc/s;->getItemViewType(I)I

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-ne v0, v1, :cond_2

    .line 6
    iget-object v0, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getFixedSavingShow()Ljava/lang/Boolean;

    move-result-object v2

    :cond_1
    invoke-virtual {p1, p2, v2}, LNc/a;->a(ILjava/lang/Object;)V

    return-void

    .line 7
    :cond_2
    iget-object v0, p0, LNc/s;->a:Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lcom/transsnet/palmpay/managemoney/bean/resp/GetIntroductionResp$Data;->getProductList()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_3

    add-int/lit8 v1, p2, -0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;

    :cond_3
    add-int/lit8 p2, p2, -0x1

    invoke-virtual {p1, p2, v2}, LNc/a;->a(ILjava/lang/Object;)V

    return-void
.end method

.method public final onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;ILjava/util/List;)V
    .locals 1

    .line 8
    check-cast p1, LNc/a;

    .line 9
    const-string v0, "holder"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "payloads"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    instance-of v0, p1, LNc/q;

    if-eqz v0, :cond_0

    if-nez p2, :cond_0

    move-object v0, p3

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 11
    check-cast p1, LNc/q;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    .line 12
    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;ILjava/util/List;)V

    return-void
.end method

.method public final onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 4

    .line 1
    const-string v0, "parent"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "inflate(...)"

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz p2, :cond_3

    .line 10
    .line 11
    const/4 v2, 0x2

    .line 12
    if-eq p2, v2, :cond_0

    .line 13
    .line 14
    new-instance p2, LNc/r;

    .line 15
    .line 16
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    sget v3, LJc/d;->mm_item_product:I

    .line 25
    .line 26
    invoke-virtual {v2, v3, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-direct {p2, p0, p1}, LNc/r;-><init>(LNc/s;Landroid/view/View;)V

    .line 34
    .line 35
    .line 36
    return-object p2

    .line 37
    :cond_0
    new-instance p2, LNc/n;

    .line 38
    .line 39
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    sget v3, LJc/d;->mm_item_product_bottom:I

    .line 48
    .line 49
    invoke-virtual {v2, v3, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    const-string v0, "itemView"

    .line 57
    .line 58
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    invoke-direct {p2, p1}, LNc/a;-><init>(Landroid/view/View;)V

    .line 62
    .line 63
    .line 64
    sget v0, LJc/c;->llLeft:I

    .line 65
    .line 66
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    const-string v1, "findViewById(...)"

    .line 71
    .line 72
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    check-cast v0, Landroid/widget/LinearLayout;

    .line 76
    .line 77
    if-eqz v0, :cond_1

    .line 78
    .line 79
    new-instance v2, LK8/a;

    .line 80
    .line 81
    const/16 v3, 0xc

    .line 82
    .line 83
    invoke-direct {v2, v3}, LK8/a;-><init>(I)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 87
    .line 88
    .line 89
    :cond_1
    sget v0, LJc/c;->viewPager:I

    .line 90
    .line 91
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    check-cast v0, Lcom/transsnet/adsdk/widgets/banner/BannerAdView;

    .line 99
    .line 100
    iput-object v0, p2, LNc/n;->b:Lcom/transsnet/adsdk/widgets/banner/BannerAdView;

    .line 101
    .line 102
    sget v2, LJc/c;->llRight:I

    .line 103
    .line 104
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    invoke-static {p1, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    check-cast p1, Landroid/widget/LinearLayout;

    .line 112
    .line 113
    if-eqz p1, :cond_2

    .line 114
    .line 115
    new-instance v1, LK8/a;

    .line 116
    .line 117
    const/16 v2, 0xc

    .line 118
    .line 119
    invoke-direct {v1, v2}, LK8/a;-><init>(I)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 123
    .line 124
    .line 125
    :cond_2
    new-instance p1, LCe/u0;

    .line 126
    .line 127
    const/4 v1, 0x1

    .line 128
    invoke-direct {p1, p2, v1}, LCe/u0;-><init>(Ljava/lang/Object;I)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v0, p1}, Lcom/transsnet/adsdk/widgets/banner/BannerAdView;->setAdListener(Lcom/transsnet/adsdk/interfaces/IAdListener;)V

    .line 132
    .line 133
    .line 134
    return-object p2

    .line 135
    :cond_3
    new-instance p2, LNc/q;

    .line 136
    .line 137
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    sget v3, LJc/d;->mm_item_product_top:I

    .line 146
    .line 147
    invoke-virtual {v2, v3, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    invoke-direct {p2, p0, p1}, LNc/q;-><init>(LNc/s;Landroid/view/View;)V

    .line 155
    .line 156
    .line 157
    return-object p2
.end method
