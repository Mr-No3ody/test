.class public final LNc/b;
.super LNc/a;
.source "SourceFile"


# instance fields
.field public b:Landroid/widget/ImageView;

.field public c:Landroid/widget/TextView;

.field public d:Landroid/widget/TextView;

.field public e:Lcom/transsnet/palmpay/custom_view/RoundedTextView;


# virtual methods
.method public final bridge synthetic a(ILjava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;

    .line 2
    .line 3
    invoke-virtual {p0, p2, p1}, LNc/b;->c(Lcom/transsnet/palmpay/managemoney/bean/ProductBean;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final c(Lcom/transsnet/palmpay/managemoney/bean/ProductBean;I)V
    .locals 2

    .line 1
    invoke-super {p0, p2, p1}, LNc/a;->a(ILjava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_2

    .line 5
    .line 6
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductIcon()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    sget v0, Lcom/transsnet/palmpay/custom_view/r;->cv_fixed_saving:I

    .line 11
    .line 12
    iget-object v1, p0, LNc/b;->b:Landroid/widget/ImageView;

    .line 13
    .line 14
    invoke-static {v1, p2, v0}, LPa/r0;->h1(Landroid/widget/ImageView;Ljava/lang/String;I)V

    .line 15
    .line 16
    .line 17
    iget-object p2, p0, LNc/b;->c:Landroid/widget/TextView;

    .line 18
    .line 19
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductName()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 24
    .line 25
    .line 26
    iget-object p2, p0, LNc/b;->d:Landroid/widget/TextView;

    .line 27
    .line 28
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductIncreaseUpContent()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductStatus()I

    .line 36
    .line 37
    .line 38
    move-result p2

    .line 39
    const/4 v0, 0x7

    .line 40
    if-eq p2, v0, :cond_1

    .line 41
    .line 42
    invoke-virtual {p1}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getProductStatus()I

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    const/4 p2, 0x1

    .line 47
    if-ne p1, p2, :cond_0

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_0
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 51
    .line 52
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    sget p2, LL6/b;->ppColorPrimary:I

    .line 57
    .line 58
    invoke-virtual {p1, p2}, Landroid/content/Context;->getColor(I)I

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    goto :goto_1

    .line 63
    :cond_1
    :goto_0
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 64
    .line 65
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    sget p2, LL6/b;->ppColorDisabled:I

    .line 70
    .line 71
    invoke-virtual {p1, p2}, Landroid/content/Context;->getColor(I)I

    .line 72
    .line 73
    .line 74
    move-result p1

    .line 75
    :goto_1
    iget-object p2, p0, LNc/b;->e:Lcom/transsnet/palmpay/custom_view/RoundedTextView;

    .line 76
    .line 77
    invoke-virtual {p2, p1}, Lcom/transsnet/palmpay/custom_view/RoundedTextView;->setRoundedBackgroundColor(I)V

    .line 78
    .line 79
    .line 80
    :cond_2
    return-void
.end method
