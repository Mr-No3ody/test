.class public final synthetic LNc/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LNc/x;->a:I

    iput-object p1, p0, LNc/x;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 8

    .line 1
    const-string v0, "null cannot be cast to non-null type com.flexibank.sdk.cashier.ui.activity.FlexiBankPayVerificationActivity"

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x4

    .line 5
    const/4 v3, 0x1

    .line 6
    const-string v4, "null cannot be cast to non-null type com.flexibank.sdk.cashier.callback.FlexiBankPayVerificationCallback"

    .line 7
    .line 8
    const/4 v5, 0x0

    .line 9
    iget-object v6, p0, LNc/x;->b:Ljava/lang/Object;

    .line 10
    .line 11
    iget v7, p0, LNc/x;->a:I

    .line 12
    .line 13
    packed-switch v7, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    sget-object v0, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckVoucherCodeFragment;->A:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckVoucherCodeFragment$a;

    .line 17
    .line 18
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    sget v0, Lcom/flexibank/sdk/p;->fb_cmf_next_btn:I

    .line 23
    .line 24
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckVoucherCodeFragment;

    .line 25
    .line 26
    if-ne p1, v0, :cond_1

    .line 27
    .line 28
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    check-cast p1, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;

    .line 36
    .line 37
    iget-object v0, v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckVoucherCodeFragment;->p:Lcom/flexibank/sdk/customview/FlexiBankTitleEditView;

    .line 38
    .line 39
    if-eqz v0, :cond_0

    .line 40
    .line 41
    invoke-virtual {v0}, Lcom/flexibank/sdk/customview/FlexiBankTitleEditView;->getEditText()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v5

    .line 45
    :cond_0
    const/4 v0, 0x6

    .line 46
    invoke-interface {p1, v5, v0}, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;->verifyPayMethod(Ljava/lang/String;I)V

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_1
    sget v0, Lcom/flexibank/sdk/p;->fb_voucher_guide_tv:I

    .line 51
    .line 52
    if-ne p1, v0, :cond_2

    .line 53
    .line 54
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/E;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    const-string v0, "requireActivity(...)"

    .line 59
    .line 60
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    const-string v0, "mContext"

    .line 64
    .line 65
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    const-string v0, "VODAFONE"

    .line 69
    .line 70
    const-string v3, "operatorCode"

    .line 71
    .line 72
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    new-instance v4, Lc4/c;

    .line 76
    .line 77
    sget v5, Lcom/flexibank/sdk/q;->fb_mobile_wallet_guide_dialog:I

    .line 78
    .line 79
    const-string v6, "context"

    .line 80
    .line 81
    invoke-static {p1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-direct {v4, p1, v5, v2, v1}, Lo4/b;-><init>(Landroid/content/Context;III)V

    .line 85
    .line 86
    .line 87
    sget v1, Lcom/flexibank/sdk/r;->fb_create_voucher_guide_title:I

    .line 88
    .line 89
    invoke-virtual {p1, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    const-string v2, "getString(...)"

    .line 94
    .line 95
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    iput-object v1, v4, Lc4/c;->e:Ljava/lang/String;

    .line 99
    .line 100
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    sget v1, Lcom/flexibank/sdk/r;->fb_mobile_wallet_name_vodafone:I

    .line 104
    .line 105
    invoke-virtual {p1, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    iput-object v1, v4, Lc4/c;->f:Ljava/lang/String;

    .line 113
    .line 114
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    sget v0, Lcom/flexibank/sdk/r;->fb_vodafone_guide_msg:I

    .line 118
    .line 119
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    iput-object p1, v4, Lc4/c;->g:Ljava/lang/String;

    .line 127
    .line 128
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 129
    .line 130
    .line 131
    :cond_2
    :goto_0
    return-void

    .line 132
    :pswitch_0
    sget-object p1, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayPinFragment;->C:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayPinFragment$a;

    .line 133
    .line 134
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayPinFragment;

    .line 135
    .line 136
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 137
    .line 138
    .line 139
    move-result-object p1

    .line 140
    instance-of p1, p1, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 141
    .line 142
    if-eqz p1, :cond_4

    .line 143
    .line 144
    iget-object p1, v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayPinFragment;->A:Ljava/lang/String;

    .line 145
    .line 146
    const-string v1, "t6"

    .line 147
    .line 148
    invoke-static {p1, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 149
    .line 150
    .line 151
    move-result p1

    .line 152
    if-eqz p1, :cond_3

    .line 153
    .line 154
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    if-eqz p1, :cond_5

    .line 159
    .line 160
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 161
    .line 162
    .line 163
    goto :goto_1

    .line 164
    :cond_3
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 169
    .line 170
    .line 171
    check-cast p1, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 172
    .line 173
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->g()V

    .line 174
    .line 175
    .line 176
    goto :goto_1

    .line 177
    :cond_4
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    if-eqz p1, :cond_5

    .line 182
    .line 183
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 184
    .line 185
    .line 186
    :cond_5
    :goto_1
    return-void

    .line 187
    :pswitch_1
    sget-object p1, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayOtpFragment;->p:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayOtpFragment$a;

    .line 188
    .line 189
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckPalmPayOtpFragment;

    .line 190
    .line 191
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    instance-of v0, p1, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 196
    .line 197
    if-eqz v0, :cond_6

    .line 198
    .line 199
    check-cast p1, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 200
    .line 201
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->g()V

    .line 202
    .line 203
    .line 204
    goto :goto_2

    .line 205
    :cond_6
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 206
    .line 207
    .line 208
    move-result-object p1

    .line 209
    if-eqz p1, :cond_7

    .line 210
    .line 211
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 212
    .line 213
    .line 214
    :cond_7
    :goto_2
    return-void

    .line 215
    :pswitch_2
    sget-object v0, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckMobileFragment;->B:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckMobileFragment$a;

    .line 216
    .line 217
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 218
    .line 219
    .line 220
    move-result p1

    .line 221
    sget v0, Lcom/flexibank/sdk/p;->fb_cmf_next_btn:I

    .line 222
    .line 223
    if-ne p1, v0, :cond_9

    .line 224
    .line 225
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckMobileFragment;

    .line 226
    .line 227
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 228
    .line 229
    .line 230
    move-result-object p1

    .line 231
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    check-cast p1, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;

    .line 235
    .line 236
    iget-object v0, v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckMobileFragment;->t:Lcom/flexibank/sdk/customview/FlexiBankTitleEditView;

    .line 237
    .line 238
    if-eqz v0, :cond_8

    .line 239
    .line 240
    invoke-virtual {v0}, Lcom/flexibank/sdk/customview/FlexiBankTitleEditView;->getEditText()Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object v5

    .line 244
    :cond_8
    invoke-interface {p1, v5, v2}, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;->verifyPayMethod(Ljava/lang/String;I)V

    .line 245
    .line 246
    .line 247
    :cond_9
    return-void

    .line 248
    :pswitch_3
    check-cast v6, LR3/c;

    .line 249
    .line 250
    invoke-virtual {v6}, Lo4/b;->dismiss()V

    .line 251
    .line 252
    .line 253
    return-void

    .line 254
    :pswitch_4
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBirthdayFragment;

    .line 255
    .line 256
    iget-object p1, v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBirthdayFragment;->A:Ljava/lang/String;

    .line 257
    .line 258
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 259
    .line 260
    .line 261
    move-result p1

    .line 262
    if-nez p1, :cond_a

    .line 263
    .line 264
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 265
    .line 266
    .line 267
    move-result-object p1

    .line 268
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    check-cast p1, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;

    .line 272
    .line 273
    iget-object v0, v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBirthdayFragment;->A:Ljava/lang/String;

    .line 274
    .line 275
    iget v1, v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBirthdayFragment;->C:I

    .line 276
    .line 277
    invoke-interface {p1, v0, v1, v5}, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;->verifyPayMethodWithReference(Ljava/lang/String;ILjava/lang/String;)V

    .line 278
    .line 279
    .line 280
    :cond_a
    return-void

    .line 281
    :pswitch_5
    sget-object p1, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankPinFragment;->t:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankPinFragment$a;

    .line 282
    .line 283
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankPinFragment;

    .line 284
    .line 285
    invoke-virtual {v6}, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankBaseVerifyFragment;->o()Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;

    .line 286
    .line 287
    .line 288
    move-result-object p1

    .line 289
    if-eqz p1, :cond_c

    .line 290
    .line 291
    iget-object v0, v6, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;->f:Landroidx/viewbinding/ViewBinding;

    .line 292
    .line 293
    check-cast v0, Lx4/b;

    .line 294
    .line 295
    if-eqz v0, :cond_b

    .line 296
    .line 297
    iget-object v0, v0, Lx4/b;->c:Landroidx/appcompat/widget/AppCompatEditText;

    .line 298
    .line 299
    if-eqz v0, :cond_b

    .line 300
    .line 301
    invoke-virtual {v0}, Landroid/widget/TextView;->getEditableText()Landroid/text/Editable;

    .line 302
    .line 303
    .line 304
    move-result-object v5

    .line 305
    :cond_b
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v0

    .line 309
    invoke-interface {p1, v0, v3}, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;->verifyPayMethod(Ljava/lang/String;I)V

    .line 310
    .line 311
    .line 312
    :cond_c
    return-void

    .line 313
    :pswitch_6
    sget-object p1, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankOtpFragment;->t:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankOtpFragment$a;

    .line 314
    .line 315
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankOtpFragment;

    .line 316
    .line 317
    invoke-virtual {v6}, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankBaseVerifyFragment;->o()Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;

    .line 318
    .line 319
    .line 320
    move-result-object p1

    .line 321
    if-eqz p1, :cond_e

    .line 322
    .line 323
    iget-object v0, v6, Lcom/flexibank/sdk/base/FlexiBankBaseFragment;->f:Landroidx/viewbinding/ViewBinding;

    .line 324
    .line 325
    check-cast v0, Lx4/g;

    .line 326
    .line 327
    if-eqz v0, :cond_d

    .line 328
    .line 329
    iget-object v0, v0, Lx4/g;->c:Landroidx/appcompat/widget/AppCompatEditText;

    .line 330
    .line 331
    if-eqz v0, :cond_d

    .line 332
    .line 333
    invoke-virtual {v0}, Landroid/widget/TextView;->getEditableText()Landroid/text/Editable;

    .line 334
    .line 335
    .line 336
    move-result-object v0

    .line 337
    if-eqz v0, :cond_d

    .line 338
    .line 339
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v5

    .line 343
    :cond_d
    const/4 v0, 0x2

    .line 344
    invoke-interface {p1, v5, v0}, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;->verifyPayMethod(Ljava/lang/String;I)V

    .line 345
    .line 346
    .line 347
    :cond_e
    return-void

    .line 348
    :pswitch_7
    sget-object p1, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankAccountOtpFragment;->C:Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankAccountOtpFragment$a;

    .line 349
    .line 350
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankAccountOtpFragment;

    .line 351
    .line 352
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 353
    .line 354
    .line 355
    move-result-object p1

    .line 356
    invoke-static {p1, v4}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 357
    .line 358
    .line 359
    check-cast p1, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;

    .line 360
    .line 361
    iget-object v0, v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankCheckBankAccountOtpFragment;->p:Lcom/flexibank/sdk/customview/model/FlexiBankModelSendSms;

    .line 362
    .line 363
    if-eqz v0, :cond_f

    .line 364
    .line 365
    invoke-virtual {v0}, Lcom/flexibank/sdk/customview/model/FlexiBankModelSendSms;->getMEditText()Landroid/widget/EditText;

    .line 366
    .line 367
    .line 368
    move-result-object v0

    .line 369
    if-eqz v0, :cond_f

    .line 370
    .line 371
    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    .line 372
    .line 373
    .line 374
    move-result-object v5

    .line 375
    :cond_f
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 376
    .line 377
    .line 378
    move-result-object v0

    .line 379
    const/16 v1, 0xa

    .line 380
    .line 381
    invoke-interface {p1, v0, v1}, Lcom/flexibank/sdk/cashier/callback/FlexiBankPayVerificationCallback;->verifyPayMethod(Ljava/lang/String;I)V

    .line 382
    .line 383
    .line 384
    return-void

    .line 385
    :pswitch_8
    sget p1, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankBaseVerifyFragment;->o:I

    .line 386
    .line 387
    check-cast v6, Lcom/flexibank/sdk/cashier/ui/fragment/verify/FlexiBankBaseVerifyFragment;

    .line 388
    .line 389
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 390
    .line 391
    .line 392
    move-result-object p1

    .line 393
    instance-of p1, p1, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 394
    .line 395
    if-eqz p1, :cond_10

    .line 396
    .line 397
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 398
    .line 399
    .line 400
    move-result-object p1

    .line 401
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 402
    .line 403
    .line 404
    check-cast p1, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;

    .line 405
    .line 406
    invoke-virtual {p1}, Lcom/flexibank/sdk/cashier/ui/activity/FlexiBankPayVerificationActivity;->g()V

    .line 407
    .line 408
    .line 409
    goto :goto_3

    .line 410
    :cond_10
    invoke-virtual {v6}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 411
    .line 412
    .line 413
    move-result-object p1

    .line 414
    if-eqz p1, :cond_11

    .line 415
    .line 416
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 417
    .line 418
    .line 419
    :cond_11
    :goto_3
    return-void

    .line 420
    :pswitch_9
    check-cast v6, Lcom/transsnet/palmpay/account/ui/dialog/SignUpRewardOnBackDialog;

    .line 421
    .line 422
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/account/ui/dialog/SignUpRewardOnBackDialog;->b(Lcom/transsnet/palmpay/account/ui/dialog/SignUpRewardOnBackDialog;Landroid/view/View;)V

    .line 423
    .line 424
    .line 425
    return-void

    .line 426
    :pswitch_a
    check-cast v6, Lcom/transsnet/palmpay/account/ui/dialog/SignUpInviteSuccDialog;

    .line 427
    .line 428
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/account/ui/dialog/SignUpInviteSuccDialog;->a(Lcom/transsnet/palmpay/account/ui/dialog/SignUpInviteSuccDialog;Landroid/view/View;)V

    .line 429
    .line 430
    .line 431
    return-void

    .line 432
    :pswitch_b
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 433
    .line 434
    .line 435
    move-result p1

    .line 436
    sget v0, LF8/d;->tvCancel:I

    .line 437
    .line 438
    check-cast v6, LQ8/d;

    .line 439
    .line 440
    if-ne p1, v0, :cond_12

    .line 441
    .line 442
    invoke-virtual {v6}, Landroid/app/Dialog;->dismiss()V

    .line 443
    .line 444
    .line 445
    goto :goto_4

    .line 446
    :cond_12
    sget v0, LF8/d;->tv1:I

    .line 447
    .line 448
    iget-object v2, v6, LQ8/d;->a:Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;

    .line 449
    .line 450
    if-ne p1, v0, :cond_14

    .line 451
    .line 452
    if-eqz v2, :cond_13

    .line 453
    .line 454
    sget p1, Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;->g:I

    .line 455
    .line 456
    invoke-virtual {v2, v1}, Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;->n(Z)V

    .line 457
    .line 458
    .line 459
    :cond_13
    invoke-virtual {v6}, Landroid/app/Dialog;->dismiss()V

    .line 460
    .line 461
    .line 462
    goto :goto_4

    .line 463
    :cond_14
    sget v0, LF8/d;->tv2:I

    .line 464
    .line 465
    if-ne p1, v0, :cond_16

    .line 466
    .line 467
    if-eqz v2, :cond_15

    .line 468
    .line 469
    invoke-virtual {v2}, Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;->m()V

    .line 470
    .line 471
    .line 472
    :cond_15
    invoke-virtual {v6}, Landroid/app/Dialog;->dismiss()V

    .line 473
    .line 474
    .line 475
    goto :goto_4

    .line 476
    :cond_16
    sget v0, LF8/d;->tv3:I

    .line 477
    .line 478
    if-ne p1, v0, :cond_18

    .line 479
    .line 480
    if-eqz v2, :cond_17

    .line 481
    .line 482
    invoke-virtual {v2}, Lcom/transsnet/palmpay/account/ui/activity/PinSafeWithPatternActivity;->l()V

    .line 483
    .line 484
    .line 485
    :cond_17
    invoke-virtual {v6}, Landroid/app/Dialog;->dismiss()V

    .line 486
    .line 487
    .line 488
    :cond_18
    :goto_4
    return-void

    .line 489
    :pswitch_c
    check-cast v6, Lcom/transsnet/palmpay/account/ui/dialog/ConfirmDobDialog;

    .line 490
    .line 491
    invoke-static {v6, p1}, Lcom/transsnet/palmpay/account/ui/dialog/ConfirmDobDialog;->a(Lcom/transsnet/palmpay/account/ui/dialog/ConfirmDobDialog;Landroid/view/View;)V

    .line 492
    .line 493
    .line 494
    return-void

    .line 495
    :pswitch_d
    check-cast v6, Lcom/palmpay/lib/ui/edit/PpAmountEditText;

    .line 496
    .line 497
    iget-object p1, v6, Lcom/palmpay/lib/ui/edit/PpAmountEditText;->c:Lcom/palmpay/lib/ui/edit/AmountEditText;

    .line 498
    .line 499
    const-string v0, ""

    .line 500
    .line 501
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 502
    .line 503
    .line 504
    return-void

    .line 505
    :pswitch_e
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    .line 506
    .line 507
    .line 508
    move-result p1

    .line 509
    sget v0, Lcom/flexibank/sdk/p;->fb_cdpr_cancel_tv:I

    .line 510
    .line 511
    check-cast v6, LQ3/k;

    .line 512
    .line 513
    if-ne p1, v0, :cond_19

    .line 514
    .line 515
    iget-object p1, v6, LQ3/k;->p:LSd/b;

    .line 516
    .line 517
    if-eqz p1, :cond_1a

    .line 518
    .line 519
    invoke-virtual {p1}, LSd/b;->onCancelClick()V

    .line 520
    .line 521
    .line 522
    goto :goto_5

    .line 523
    :cond_19
    sget v0, Lcom/flexibank/sdk/p;->fb_cdpr_confirm_tv:I

    .line 524
    .line 525
    if-ne p1, v0, :cond_1a

    .line 526
    .line 527
    iget-object p1, v6, LQ3/k;->p:LSd/b;

    .line 528
    .line 529
    if-eqz p1, :cond_1a

    .line 530
    .line 531
    invoke-virtual {p1}, LSd/b;->onConfirmClick()V

    .line 532
    .line 533
    .line 534
    :cond_1a
    :goto_5
    return-void

    .line 535
    :pswitch_f
    check-cast v6, LPa/g0;

    .line 536
    .line 537
    iget-object p1, v6, LPa/g0;->b:Lcom/transsnet/palmpay/core/util/ScanFaceLogicUtil$IScanFaceResultCallBack;

    .line 538
    .line 539
    if-eqz p1, :cond_1b

    .line 540
    .line 541
    const-string v0, "User denied camera permission."

    .line 542
    .line 543
    invoke-interface {p1, v5, v0, v5}, Lcom/transsnet/palmpay/core/util/ScanFaceLogicUtil$IScanFaceResultCallBack;->onFailed(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 544
    .line 545
    .line 546
    :cond_1b
    invoke-virtual {v6, p1}, LPa/g0;->c(Lcom/transsnet/palmpay/core/util/ScanFaceLogicUtil$IScanFaceResultCallBack;)V

    .line 547
    .line 548
    .line 549
    return-void

    .line 550
    :pswitch_10
    check-cast v6, Lcom/google/android/material/snackbar/Snackbar;

    .line 551
    .line 552
    invoke-virtual {v6}, Lcom/google/android/material/snackbar/Snackbar;->dismiss()V

    .line 553
    .line 554
    .line 555
    return-void

    .line 556
    :pswitch_11
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 557
    .line 558
    .line 559
    move-result-object p1

    .line 560
    const-string v0, "PopUp_Close_Click"

    .line 561
    .line 562
    check-cast v6, Ljava/util/HashMap;

    .line 563
    .line 564
    invoke-virtual {p1, v0, v6}, LPa/n0;->n(Ljava/lang/String;Ljava/util/Map;)V

    .line 565
    .line 566
    .line 567
    return-void

    .line 568
    :pswitch_12
    sget-object p1, Lcom/transsnet/palmpay/managemoney/ui/dialog/WhyTurnOffSaveDialogFragment;->Z:Lcom/transsnet/palmpay/managemoney/ui/dialog/WhyTurnOffSaveDialogFragment$a;

    .line 569
    .line 570
    check-cast v6, Lcom/transsnet/palmpay/managemoney/ui/dialog/WhyTurnOffSaveDialogFragment;

    .line 571
    .line 572
    invoke-virtual {v6}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->dismiss()V

    .line 573
    .line 574
    .line 575
    return-void

    .line 576
    :pswitch_13
    sget-object p1, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;->X:Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment$a;

    .line 577
    .line 578
    check-cast v6, Lcom/transsnet/palmpay/managemoney/ui/dialog/SelectPayoutOptionsDialogFragment;

    .line 579
    .line 580
    invoke-virtual {v6}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->dismiss()V

    .line 581
    .line 582
    .line 583
    return-void

    .line 584
    :pswitch_14
    sget-object p1, Lcom/transsnet/palmpay/managemoney/ui/dialog/NewerTipDialogFragment;->C:Lcom/transsnet/palmpay/managemoney/ui/dialog/NewerTipDialogFragment$a;

    .line 585
    .line 586
    check-cast v6, Lcom/transsnet/palmpay/managemoney/ui/dialog/NewerTipDialogFragment;

    .line 587
    .line 588
    invoke-virtual {v6}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->dismiss()V

    .line 589
    .line 590
    .line 591
    return-void

    .line 592
    :pswitch_15
    sget p1, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxNewUserUseCouponDialogFragment;->L:I

    .line 593
    .line 594
    check-cast v6, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxNewUserUseCouponDialogFragment;

    .line 595
    .line 596
    invoke-virtual {v6}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->dismiss()V

    .line 597
    .line 598
    .line 599
    return-void

    .line 600
    :pswitch_16
    sget-object p1, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxNewUserOpenDialogFragment;->L:Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxNewUserOpenDialogFragment$a;

    .line 601
    .line 602
    check-cast v6, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxNewUserOpenDialogFragment;

    .line 603
    .line 604
    invoke-virtual {v6}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->dismiss()V

    .line 605
    .line 606
    .line 607
    return-void

    .line 608
    :pswitch_17
    sget-object p1, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxLoseLotteryDialogFragment;->C:Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxLoseLotteryDialogFragment$a;

    .line 609
    .line 610
    check-cast v6, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxLoseLotteryDialogFragment;

    .line 611
    .line 612
    invoke-virtual {v6}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->dismiss()V

    .line 613
    .line 614
    .line 615
    return-void

    .line 616
    :pswitch_18
    sget-object p1, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxAutoSaveDialogFragment;->M:Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxAutoSaveDialogFragment$a;

    .line 617
    .line 618
    check-cast v6, Lcom/transsnet/palmpay/managemoney/ui/dialog/CashBoxAutoSaveDialogFragment;

    .line 619
    .line 620
    invoke-virtual {v6}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->dismiss()V

    .line 621
    .line 622
    .line 623
    return-void

    .line 624
    :pswitch_19
    check-cast v6, Lcom/transsnet/palmpay/core/ui/widget/BrowseCountdownView;

    .line 625
    .line 626
    invoke-static {v6}, Lcom/transsnet/palmpay/core/ui/widget/BrowseCountdownView;->c(Lcom/transsnet/palmpay/core/ui/widget/BrowseCountdownView;)Landroidx/fragment/app/E;

    .line 627
    .line 628
    .line 629
    move-result-object p1

    .line 630
    if-eqz p1, :cond_1c

    .line 631
    .line 632
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 633
    .line 634
    .line 635
    :cond_1c
    return-void

    .line 636
    :pswitch_1a
    check-cast v6, Lcom/transsnet/palmpay/core/ui/widget/BillDetailProcessDataWedgit;

    .line 637
    .line 638
    iget-boolean p1, v6, Lcom/transsnet/palmpay/core/ui/widget/BillDetailProcessDataWedgit;->f:Z

    .line 639
    .line 640
    xor-int/2addr p1, v3

    .line 641
    invoke-virtual {v6, p1}, Lcom/transsnet/palmpay/core/ui/widget/BillDetailProcessDataWedgit;->e(Z)V

    .line 642
    .line 643
    .line 644
    return-void

    .line 645
    :pswitch_1b
    sget-object p1, Lcom/transsnet/palmpay/account/ui/activity/quota/Tier3QuotaApplyResultActivity;->b:Lcom/transsnet/palmpay/account/ui/activity/quota/Tier3QuotaApplyResultActivity$a;

    .line 646
    .line 647
    check-cast v6, Lcom/transsnet/palmpay/account/ui/activity/quota/Tier3QuotaApplyResultActivity;

    .line 648
    .line 649
    invoke-virtual {v6}, Landroid/app/Activity;->finish()V

    .line 650
    .line 651
    .line 652
    return-void

    .line 653
    :pswitch_1c
    check-cast v6, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;

    .line 654
    .line 655
    invoke-virtual {v6}, Lcom/transsnet/palmpay/managemoney/bean/ProductBean;->getInterestSwitchStatus()I

    .line 656
    .line 657
    .line 658
    move-result p1

    .line 659
    if-ne p1, v3, :cond_1d

    .line 660
    .line 661
    const-string p1, "/cashbox/interest-setting"

    .line 662
    .line 663
    invoke-static {p1}, LPa/i0;->b0(Ljava/lang/String;)V

    .line 664
    .line 665
    .line 666
    :cond_1d
    return-void

    .line 667
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
