.class public final LNc/h;
.super LNc/a;
.source "SourceFile"


# instance fields
.field public final b:Z

.field public final c:Z

.field public final d:Landroid/widget/ImageView;

.field public final e:Landroid/widget/TextView;

.field public final f:Landroid/widget/TextView;

.field public final g:Landroid/widget/TextView;

.field public final i:Landroid/widget/TextView;

.field public final j:Landroid/widget/TextView;

.field public final o:Landroid/view/View;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LNc/g;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LNc/g;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(Landroid/view/View;ZZ)V
    .locals 1

    .line 1
    const-string v0, "itemView"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0, p1}, LNc/a;-><init>(Landroid/view/View;)V

    .line 7
    .line 8
    .line 9
    iput-boolean p2, p0, LNc/h;->b:Z

    .line 10
    .line 11
    iput-boolean p3, p0, LNc/h;->c:Z

    .line 12
    .line 13
    sget p2, LJc/c;->ivIcon:I

    .line 14
    .line 15
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    const-string p3, "findViewById(...)"

    .line 20
    .line 21
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    check-cast p2, Landroid/widget/ImageView;

    .line 25
    .line 26
    iput-object p2, p0, LNc/h;->d:Landroid/widget/ImageView;

    .line 27
    .line 28
    sget p2, LJc/c;->tvTransactionName:I

    .line 29
    .line 30
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 31
    .line 32
    .line 33
    move-result-object p2

    .line 34
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    check-cast p2, Landroid/widget/TextView;

    .line 38
    .line 39
    iput-object p2, p0, LNc/h;->e:Landroid/widget/TextView;

    .line 40
    .line 41
    sget p2, LJc/c;->tvTransactionTime:I

    .line 42
    .line 43
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 44
    .line 45
    .line 46
    move-result-object p2

    .line 47
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    check-cast p2, Landroid/widget/TextView;

    .line 51
    .line 52
    iput-object p2, p0, LNc/h;->f:Landroid/widget/TextView;

    .line 53
    .line 54
    sget p2, LJc/c;->tvTransactionAmount:I

    .line 55
    .line 56
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object p2

    .line 60
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    check-cast p2, Landroid/widget/TextView;

    .line 64
    .line 65
    iput-object p2, p0, LNc/h;->g:Landroid/widget/TextView;

    .line 66
    .line 67
    sget p2, LJc/c;->tvTransactionStatus:I

    .line 68
    .line 69
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 70
    .line 71
    .line 72
    move-result-object p2

    .line 73
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    check-cast p2, Landroid/widget/TextView;

    .line 77
    .line 78
    iput-object p2, p0, LNc/h;->i:Landroid/widget/TextView;

    .line 79
    .line 80
    sget p2, LJc/c;->viewDivider:I

    .line 81
    .line 82
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 83
    .line 84
    .line 85
    move-result-object p2

    .line 86
    invoke-static {p2, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    iput-object p2, p0, LNc/h;->o:Landroid/view/View;

    .line 90
    .line 91
    sget p2, LJc/c;->tvFundName:I

    .line 92
    .line 93
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    check-cast p1, Landroid/widget/TextView;

    .line 98
    .line 99
    iput-object p1, p0, LNc/h;->j:Landroid/widget/TextView;

    .line 100
    .line 101
    return-void
.end method


# virtual methods
.method public final a(ILjava/lang/Object;)V
    .locals 9

    .line 1
    check-cast p2, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;

    .line 2
    .line 3
    invoke-super {p0, p1, p2}, LNc/a;->a(ILjava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-boolean p1, p0, LNc/h;->b:Z

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/16 p1, 0x8

    .line 13
    .line 14
    :goto_0
    iget-object v0, p0, LNc/h;->o:Landroid/view/View;

    .line 15
    .line 16
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 17
    .line 18
    .line 19
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 20
    .line 21
    invoke-static {p1}, LPa/i0;->V(Landroid/view/View;)Z

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 26
    .line 27
    if-eqz v0, :cond_2

    .line 28
    .line 29
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    if-eqz p1, :cond_1

    .line 38
    .line 39
    sget p1, Lcom/transsnet/palmpay/custom_view/p;->cv_color_1e1e1e:I

    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_1
    sget p1, Lcom/transsnet/palmpay/custom_view/p;->md_white_1000:I

    .line 43
    .line 44
    :goto_1
    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getColor(I)I

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 49
    .line 50
    .line 51
    :cond_2
    if-eqz p2, :cond_11

    .line 52
    .line 53
    iget-object p1, p0, LNc/h;->d:Landroid/widget/ImageView;

    .line 54
    .line 55
    const/16 v0, 0xe

    .line 56
    .line 57
    iget-boolean v1, p0, LNc/h;->c:Z

    .line 58
    .line 59
    if-eqz v1, :cond_3

    .line 60
    .line 61
    const-string v1, "x5"

    .line 62
    .line 63
    invoke-static {v0, v1}, LEa/a;->d(ILjava/lang/String;)Landroid/net/Uri;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    new-instance v1, LG1/d;

    .line 68
    .line 69
    invoke-direct {v1}, LG1/a;-><init>()V

    .line 70
    .line 71
    .line 72
    sget v2, Lcom/transsnet/palmpay/custom_view/r;->cv_bill_default_icon:I

    .line 73
    .line 74
    invoke-virtual {v1, v2}, LG1/a;->x(I)LG1/a;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    check-cast v1, LG1/d;

    .line 79
    .line 80
    invoke-static {p1, v0, v1}, LPa/r0;->g1(Landroid/widget/ImageView;Landroid/net/Uri;LG1/d;)V

    .line 81
    .line 82
    .line 83
    goto :goto_2

    .line 84
    :cond_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getOrgTransactionType()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    if-eqz v1, :cond_5

    .line 89
    .line 90
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 91
    .line 92
    .line 93
    move-result v2

    .line 94
    if-nez v2, :cond_4

    .line 95
    .line 96
    const/4 v1, 0x0

    .line 97
    :cond_4
    if-eqz v1, :cond_5

    .line 98
    .line 99
    invoke-static {v0, v1}, LEa/a;->d(ILjava/lang/String;)Landroid/net/Uri;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    new-instance v1, LG1/d;

    .line 104
    .line 105
    invoke-direct {v1}, LG1/a;-><init>()V

    .line 106
    .line 107
    .line 108
    sget v2, Lcom/transsnet/palmpay/custom_view/r;->cv_bill_default_icon:I

    .line 109
    .line 110
    invoke-virtual {v1, v2}, LG1/a;->x(I)LG1/a;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    check-cast v1, LG1/d;

    .line 115
    .line 116
    invoke-static {p1, v0, v1}, LPa/r0;->g1(Landroid/widget/ImageView;Landroid/net/Uri;LG1/d;)V

    .line 117
    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_5
    sget v0, LJc/b;->mm_icon_cash_box:I

    .line 121
    .line 122
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 123
    .line 124
    .line 125
    :goto_2
    iget-object p1, p0, LNc/h;->e:Landroid/widget/TextView;

    .line 126
    .line 127
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getTransactionName()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getGmtCreated()J

    .line 135
    .line 136
    .line 137
    move-result-wide v0

    .line 138
    invoke-static {v0, v1}, LPa/r0;->O(J)Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    iget-object v0, p0, LNc/h;->f:Landroid/widget/TextView;

    .line 143
    .line 144
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getSubTransType()Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    const-string v0, "x7_01"

    .line 152
    .line 153
    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result p1

    .line 157
    iget-object v0, p0, LNc/h;->g:Landroid/widget/TextView;

    .line 158
    .line 159
    const/4 v1, 0x1

    .line 160
    const-string v2, "format(...)"

    .line 161
    .line 162
    const-string v3, "-"

    .line 163
    .line 164
    const-string v4, "+"

    .line 165
    .line 166
    const/4 v5, 0x3

    .line 167
    const/4 v6, 0x2

    .line 168
    if-eqz p1, :cond_7

    .line 169
    .line 170
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getTransactionDirection()I

    .line 171
    .line 172
    .line 173
    move-result p1

    .line 174
    if-ne p1, v1, :cond_6

    .line 175
    .line 176
    move-object v3, v4

    .line 177
    :cond_6
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getUnits()D

    .line 178
    .line 179
    .line 180
    move-result-wide v7

    .line 181
    :try_start_0
    invoke-static {v7, v8}, Ljava/math/BigDecimal;->valueOf(D)Ljava/math/BigDecimal;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    const/4 v4, 0x4

    .line 186
    invoke-virtual {p1, v4, v4}, Ljava/math/BigDecimal;->setScale(II)Ljava/math/BigDecimal;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    invoke-virtual {p1}, Ljava/math/BigDecimal;->doubleValue()D

    .line 191
    .line 192
    .line 193
    move-result-wide v7
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 194
    :catch_0
    invoke-static {v7, v8}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    const-string v4, " Units"

    .line 199
    .line 200
    filled-new-array {v3, p1, v4}, [Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object p1

    .line 204
    invoke-static {p1, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object p1

    .line 208
    const-string v3, "%s%s%s"

    .line 209
    .line 210
    invoke-static {v3, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object p1

    .line 214
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 218
    .line 219
    .line 220
    goto :goto_3

    .line 221
    :cond_7
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getTransactionDirection()I

    .line 222
    .line 223
    .line 224
    move-result p1

    .line 225
    if-ne p1, v1, :cond_8

    .line 226
    .line 227
    move-object v3, v4

    .line 228
    :cond_8
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getAmount()J

    .line 229
    .line 230
    .line 231
    move-result-wide v7

    .line 232
    invoke-static {v7, v8}, LPa/r0;->A(J)Ljava/lang/String;

    .line 233
    .line 234
    .line 235
    move-result-object p1

    .line 236
    filled-new-array {v3, p1}, [Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object p1

    .line 240
    invoke-static {p1, v6}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object p1

    .line 244
    const-string v3, "%s%s"

    .line 245
    .line 246
    invoke-static {v3, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object p1

    .line 250
    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 254
    .line 255
    .line 256
    :goto_3
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getBalance()Ljava/lang/Long;

    .line 257
    .line 258
    .line 259
    move-result-object p1

    .line 260
    iget-object v0, p0, LNc/h;->i:Landroid/widget/TextView;

    .line 261
    .line 262
    if-eqz p1, :cond_d

    .line 263
    .line 264
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getTransactionStatus()I

    .line 265
    .line 266
    .line 267
    move-result p1

    .line 268
    if-ne p1, v6, :cond_9

    .line 269
    .line 270
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 271
    .line 272
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 273
    .line 274
    .line 275
    move-result-object p1

    .line 276
    sget v2, LJc/f;->mm_history_balance:I

    .line 277
    .line 278
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getBalance()Ljava/lang/Long;

    .line 279
    .line 280
    .line 281
    move-result-object v3

    .line 282
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->e(Ljava/lang/Object;)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 286
    .line 287
    .line 288
    move-result-wide v3

    .line 289
    invoke-static {v3, v4}, LPa/r0;->A(J)Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v3

    .line 293
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 294
    .line 295
    .line 296
    move-result-object v3

    .line 297
    invoke-virtual {p1, v2, v3}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 298
    .line 299
    .line 300
    move-result-object p1

    .line 301
    goto :goto_5

    .line 302
    :cond_9
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 303
    .line 304
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 305
    .line 306
    .line 307
    move-result-object p1

    .line 308
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getTransactionStatus()I

    .line 309
    .line 310
    .line 311
    move-result v2

    .line 312
    if-eq v2, v1, :cond_c

    .line 313
    .line 314
    if-eq v2, v6, :cond_b

    .line 315
    .line 316
    if-eq v2, v5, :cond_a

    .line 317
    .line 318
    sget v2, Lba/k;->core_refunded:I

    .line 319
    .line 320
    goto :goto_4

    .line 321
    :cond_a
    sget v2, Lba/k;->core_failed:I

    .line 322
    .line 323
    goto :goto_4

    .line 324
    :cond_b
    sget v2, Lba/k;->core_successful:I

    .line 325
    .line 326
    goto :goto_4

    .line 327
    :cond_c
    sget v2, Lba/k;->core_processing:I

    .line 328
    .line 329
    :goto_4
    invoke-virtual {p1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 330
    .line 331
    .line 332
    move-result-object p1

    .line 333
    :goto_5
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 334
    .line 335
    .line 336
    goto :goto_6

    .line 337
    :cond_d
    const-string p1, ""

    .line 338
    .line 339
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 340
    .line 341
    .line 342
    :goto_6
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 343
    .line 344
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 345
    .line 346
    .line 347
    move-result-object p1

    .line 348
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getTransactionStatus()I

    .line 349
    .line 350
    .line 351
    move-result v2

    .line 352
    if-eq v2, v1, :cond_10

    .line 353
    .line 354
    if-eq v2, v6, :cond_f

    .line 355
    .line 356
    if-eq v2, v5, :cond_e

    .line 357
    .line 358
    sget v1, LL6/b;->ppColorTextDisable:I

    .line 359
    .line 360
    goto :goto_7

    .line 361
    :cond_e
    sget v1, LL6/b;->ppColorError:I

    .line 362
    .line 363
    goto :goto_7

    .line 364
    :cond_f
    sget v1, LL6/b;->ppColorTextAssist:I

    .line 365
    .line 366
    goto :goto_7

    .line 367
    :cond_10
    sget v1, Lcom/transsnet/palmpay/custom_view/p;->cv_color_ffaa0c:I

    .line 368
    .line 369
    :goto_7
    invoke-virtual {p1, v1}, Landroid/content/Context;->getColor(I)I

    .line 370
    .line 371
    .line 372
    move-result p1

    .line 373
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 374
    .line 375
    .line 376
    invoke-virtual {p2}, Lcom/transsnet/palmpay/managemoney/bean/resp/QueryCashBoxTransactionListResp$CashBoxTransaction;->getFundName()Ljava/lang/String;

    .line 377
    .line 378
    .line 379
    move-result-object p1

    .line 380
    if-eqz p1, :cond_11

    .line 381
    .line 382
    iget-object p2, p0, LNc/h;->j:Landroid/widget/TextView;

    .line 383
    .line 384
    if-eqz p2, :cond_11

    .line 385
    .line 386
    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 387
    .line 388
    .line 389
    :cond_11
    return-void
.end method
