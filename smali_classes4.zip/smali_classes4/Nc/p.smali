.class public final LNc/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/transsnet/palmpay/main/export/ui/view/ModelNewCustomerSavings$OnInvestBtnClickListener;


# instance fields
.field public final synthetic a:LNc/s;

.field public final synthetic b:LNc/q;


# direct methods
.method public constructor <init>(LNc/s;LNc/q;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LNc/p;->a:LNc/s;

    .line 5
    .line 6
    iput-object p2, p0, LNc/p;->b:LNc/q;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onInvestBtnClick(Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;)V
    .locals 14

    .line 1
    if-eqz p1, :cond_2

    .line 2
    .line 3
    sget v0, LNc/s;->c:I

    .line 4
    .line 5
    iget-object v0, p0, LNc/p;->a:LNc/s;

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;->getProductStatus()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    const/4 v2, 0x7

    .line 12
    const-string v3, "showCommonTipsDialog"

    .line 13
    .line 14
    const-string v4, "getSupportFragmentManager(...)"

    .line 15
    .line 16
    const-string v5, "null cannot be cast to non-null type androidx.appcompat.app.AppCompatActivity"

    .line 17
    .line 18
    iget-object v6, p0, LNc/p;->b:LNc/q;

    .line 19
    .line 20
    if-ne v1, v2, :cond_0

    .line 21
    .line 22
    sget-object v7, Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment;->X:Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment$a;

    .line 23
    .line 24
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    sget v1, LJc/f;->mm_product_sell_out_desc:I

    .line 35
    .line 36
    invoke-virtual {p1}, Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;->getShowName()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    const-string v2, "tomorrow"

    .line 41
    .line 42
    filled-new-array {p1, v2}, [Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    invoke-virtual {v0, v1, p1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v9

    .line 50
    const-string v10, "Ok"

    .line 51
    .line 52
    const/4 v11, 0x0

    .line 53
    const-string v8, "Oops!"

    .line 54
    .line 55
    const/16 v12, 0x8

    .line 56
    .line 57
    const/4 v13, 0x0

    .line 58
    invoke-static/range {v7 .. v13}, Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment$a;->createDialog$default(Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment$a;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Boolean;ILjava/lang/Object;)Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 63
    .line 64
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    check-cast v0, Landroidx/appcompat/app/o;

    .line 72
    .line 73
    invoke-virtual {v0}, Landroidx/fragment/app/E;->getSupportFragmentManager()Landroidx/fragment/app/Z;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p1, v0, v3}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_0
    invoke-virtual {p1}, Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;->getProductStatus()I

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    const/4 v2, 0x1

    .line 89
    if-ne v1, v2, :cond_1

    .line 90
    .line 91
    sget-object v7, Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment;->X:Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment$a;

    .line 92
    .line 93
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 94
    .line 95
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    sget v1, LJc/f;->mm_product_sell_out_desc:I

    .line 104
    .line 105
    invoke-virtual {p1}, Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;->getShowName()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    const-string v2, "today 9:00am"

    .line 110
    .line 111
    filled-new-array {p1, v2}, [Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    invoke-virtual {v0, v1, p1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v9

    .line 119
    const-string v10, "Ok"

    .line 120
    .line 121
    const/4 v11, 0x0

    .line 122
    const-string v8, "Oops!"

    .line 123
    .line 124
    const/16 v12, 0x8

    .line 125
    .line 126
    const/4 v13, 0x0

    .line 127
    invoke-static/range {v7 .. v13}, Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment$a;->createDialog$default(Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment$a;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/Boolean;ILjava/lang/Object;)Lcom/transsnet/palmpay/custom_view/dialog/CommonTipsDialogFragment;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->itemView:Landroid/view/View;

    .line 132
    .line 133
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    check-cast v0, Landroidx/appcompat/app/o;

    .line 141
    .line 142
    invoke-virtual {v0}, Landroidx/fragment/app/E;->getSupportFragmentManager()Landroidx/fragment/app/Z;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p1, v0, v3}, Lcom/transsnet/palmpay/custom_view/dialog/BaseDialogFragment;->show(Landroidx/fragment/app/Z;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    return-void

    .line 153
    :cond_1
    iget-object v0, v0, LNc/s;->b:Lcom/transsnet/palmpay/managemoney/ui/fragment/O;

    .line 154
    .line 155
    if-eqz v0, :cond_2

    .line 156
    .line 157
    invoke-virtual {v0, p1}, Lcom/transsnet/palmpay/managemoney/ui/fragment/O;->onInvestBtnClick(Lcom/transsnet/palmpay/main/export/bean/rsp/SavingProduct;)V

    .line 158
    .line 159
    .line 160
    :cond_2
    return-void
.end method
