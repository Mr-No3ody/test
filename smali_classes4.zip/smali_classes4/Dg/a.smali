.class public final synthetic LDg/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lokhttp3/EventListener$Factory;
.implements Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;
.implements Landroidx/camera/core/resolutionselector/ResolutionFilter;
.implements Landroidx/camera/core/ImageAnalysis$Analyzer;
.implements Landroidx/camera/core/impl/ImageReaderProxy$OnImageAvailableListener;
.implements Lcom/chad/library/adapter/base/listener/OnItemClickListener;
.implements Lio/reactivex/functions/Consumer;
.implements Lcom/transsnet/palmpay/send_money/ui/view/AdvancedRefundViewHolderListener;
.implements Lcom/transsnet/palmpay/send_money/ui/dialog/AddFromContactsDialog$OnAddFromContactsListener;
.implements Lcom/google/android/material/tabs/TabLayoutMediator$TabConfigurationStrategy;
.implements Lio/reactivex/ObservableOnSubscribe;
.implements Lcom/chad/library/adapter/base/listener/OnItemChildClickListener;
.implements Lcom/transsnet/palmpay/custom_view/adapter/BaseRecyclerViewAdapter$ItemViewOnClickListener;
.implements Lcom/transsnet/palmpay/custom_view/PinEntryView$OnPinEnteredListener;
.implements Landroidx/appcompat/widget/SearchView$OnCloseListener;
.implements Lcom/facebook/react/uimanager/UIBlock;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p2, p0, LDg/a;->a:I

    iput-object p1, p0, LDg/a;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public OnItemViewOnClick(Landroid/view/View;Ljava/lang/Object;Landroidx/recyclerview/widget/RecyclerView$ViewHolder;)V
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x6

    .line 3
    iget-object v2, p0, LDg/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iget v3, p0, LDg/a;->a:I

    .line 6
    .line 7
    sparse-switch v3, :sswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast p2, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeSlideMenuBean;

    .line 11
    .line 12
    const-string p1, "data"

    .line 13
    .line 14
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget p1, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->menuId:I

    .line 18
    .line 19
    if-eq p1, v1, :cond_5

    .line 20
    .line 21
    const/16 p3, 0x1a

    .line 22
    .line 23
    if-eq p1, p3, :cond_4

    .line 24
    .line 25
    const/16 p3, 0x2f

    .line 26
    .line 27
    if-eq p1, p3, :cond_3

    .line 28
    .line 29
    const/16 p3, 0x32

    .line 30
    .line 31
    if-eq p1, p3, :cond_2

    .line 32
    .line 33
    const/16 p3, 0x38

    .line 34
    .line 35
    if-eq p1, p3, :cond_1

    .line 36
    .line 37
    const/16 p3, 0x44

    .line 38
    .line 39
    if-eq p1, p3, :cond_0

    .line 40
    .line 41
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    new-instance p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 46
    .line 47
    const-string v0, "PalmPay_Me_Click"

    .line 48
    .line 49
    invoke-direct {p3, v0}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    const-string v0, "module_name"

    .line 53
    .line 54
    iget-object v1, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->menuName:Ljava/lang/String;

    .line 55
    .line 56
    invoke-virtual {p3, v0, v1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 57
    .line 58
    .line 59
    move-result-object p3

    .line 60
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 61
    .line 62
    invoke-virtual {p1, p3}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 63
    .line 64
    .line 65
    goto :goto_0

    .line 66
    :cond_0
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    const-string p3, "PalmPay_Me_Report_Scam_Click"

    .line 71
    .line 72
    invoke-virtual {p1, p3}, LPa/n0;->l(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_1
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    const-string p3, "PalmPay_Me_MyAssets_Click"

    .line 81
    .line 82
    invoke-virtual {p1, p3}, LPa/n0;->l(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_2
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    const-string p3, "PalmPay_Me_Palm_Official_Click"

    .line 91
    .line 92
    invoke-virtual {p1, p3}, LPa/n0;->l(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_3
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    const-string p3, "PalmPay_Me_Invitation_Click"

    .line 101
    .line 102
    invoke-virtual {p1, p3}, LPa/n0;->l(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    goto :goto_0

    .line 106
    :cond_4
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    const-string p3, "PalmPay_Me_Help_One_Click"

    .line 111
    .line 112
    invoke-virtual {p1, p3}, LPa/n0;->l(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    goto :goto_0

    .line 116
    :cond_5
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    const-string p3, "PalmPay_Me_Banks_Cards_Click"

    .line 121
    .line 122
    invoke-virtual {p1, p3}, LPa/n0;->l(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    :goto_0
    iget-object p1, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->jumpPath:Ljava/lang/String;

    .line 126
    .line 127
    if-eqz p1, :cond_6

    .line 128
    .line 129
    const/4 p3, 0x0

    .line 130
    const-string v0, "arouter://"

    .line 131
    .line 132
    invoke-static {p1, v0, p3}, Lkotlin/text/y;->m(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 133
    .line 134
    .line 135
    move-result p1

    .line 136
    const/4 p3, 0x1

    .line 137
    if-ne p1, p3, :cond_6

    .line 138
    .line 139
    check-cast v2, LKe/d;

    .line 140
    .line 141
    iget-object p1, v2, LKe/d;->b:Ljava/lang/ref/WeakReference;

    .line 142
    .line 143
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object p1

    .line 147
    check-cast p1, Landroid/app/Activity;

    .line 148
    .line 149
    if-eqz p1, :cond_7

    .line 150
    .line 151
    iget-object p2, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->jumpPath:Ljava/lang/String;

    .line 152
    .line 153
    invoke-static {p1, p2}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 154
    .line 155
    .line 156
    move-result-object p1

    .line 157
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 158
    .line 159
    .line 160
    goto :goto_1

    .line 161
    :cond_6
    invoke-static {p2}, LPa/F;->d(Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;)V

    .line 162
    .line 163
    .line 164
    :cond_7
    :goto_1
    return-void

    .line 165
    :sswitch_0
    check-cast p2, Ljava/lang/String;

    .line 166
    .line 167
    sget-object p1, Lcom/transsnet/palmpay/account/kotlin/ui/activity/SelectResetPinVerifyTypeActivity;->g:Lcom/transsnet/palmpay/account/kotlin/ui/activity/SelectResetPinVerifyTypeActivity$a;

    .line 168
    .line 169
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    const-string p3, "/account/reset_pin_verify"

    .line 174
    .line 175
    invoke-virtual {p1, p3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    check-cast v2, Lcom/transsnet/palmpay/account/kotlin/ui/activity/SelectResetPinVerifyTypeActivity;

    .line 180
    .line 181
    iget-object p3, v2, Lcom/transsnet/palmpay/account/kotlin/ui/activity/SelectResetPinVerifyTypeActivity;->d:Ljava/lang/String;

    .line 182
    .line 183
    const-string v0, "extra_data"

    .line 184
    .line 185
    invoke-virtual {p1, v0, p3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    const-string p3, "extra_type"

    .line 190
    .line 191
    invoke-virtual {p1, p3, p2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    const-string p2, "extra_data_1"

    .line 196
    .line 197
    iget-object p3, v2, Lcom/transsnet/palmpay/account/kotlin/ui/activity/SelectResetPinVerifyTypeActivity;->a:Ljava/lang/String;

    .line 198
    .line 199
    invoke-virtual {p1, p2, p3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    const-string p2, "extra_data_2"

    .line 204
    .line 205
    iget-object p3, v2, Lcom/transsnet/palmpay/account/kotlin/ui/activity/SelectResetPinVerifyTypeActivity;->b:Ljava/lang/String;

    .line 206
    .line 207
    invoke-virtual {p1, p2, p3}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 208
    .line 209
    .line 210
    move-result-object p1

    .line 211
    const-string p2, "_security_flow_info"

    .line 212
    .line 213
    iget-object p3, v2, Lcom/transsnet/palmpay/account/kotlin/ui/activity/SelectResetPinVerifyTypeActivity;->c:Lcom/transsnet/palmpay/account/bean/rsp/GetSecurityFlowRsp;

    .line 214
    .line 215
    invoke-virtual {p1, p2, p3}, Lcom/alibaba/android/arouter/facade/Postcard;->withParcelable(Ljava/lang/String;Landroid/os/Parcelable;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 216
    .line 217
    .line 218
    move-result-object p1

    .line 219
    invoke-virtual {p1}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation()Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    invoke-virtual {v2}, Landroid/app/Activity;->finish()V

    .line 223
    .line 224
    .line 225
    return-void

    .line 226
    :sswitch_1
    check-cast p2, Lcom/transsnet/palmpay/core/bean/HomePageMenuData;

    .line 227
    .line 228
    check-cast v2, LIe/s;

    .line 229
    .line 230
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 231
    .line 232
    .line 233
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 234
    .line 235
    .line 236
    move-result-object p1

    .line 237
    new-instance p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 238
    .line 239
    const-string v1, "MySerview_Entrance_Click"

    .line 240
    .line 241
    invoke-direct {p3, v1}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 242
    .line 243
    .line 244
    iget-object v1, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->menuName:Ljava/lang/String;

    .line 245
    .line 246
    const-string v3, "menuName"

    .line 247
    .line 248
    invoke-virtual {p3, v3, v1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 249
    .line 250
    .line 251
    move-result-object p3

    .line 252
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 253
    .line 254
    iget-object v1, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->menuName:Ljava/lang/String;

    .line 255
    .line 256
    invoke-virtual {p3, v3, v1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 257
    .line 258
    .line 259
    move-result-object p3

    .line 260
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 261
    .line 262
    const-string v1, "menuGroupName"

    .line 263
    .line 264
    iget-object v3, p2, Lcom/transsnet/palmpay/core/bean/HomePageMenuData;->menuGroupName:Ljava/lang/String;

    .line 265
    .line 266
    invoke-virtual {p3, v1, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 267
    .line 268
    .line 269
    move-result-object p3

    .line 270
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 271
    .line 272
    iget v1, p2, Lcom/transsnet/palmpay/core/bean/HomePageMenuData;->type:I

    .line 273
    .line 274
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object v1

    .line 278
    const-string v3, "type"

    .line 279
    .line 280
    invoke-virtual {p3, v3, v1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 281
    .line 282
    .line 283
    move-result-object p3

    .line 284
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 285
    .line 286
    iget v1, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->menuId:I

    .line 287
    .line 288
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 289
    .line 290
    .line 291
    move-result-object v1

    .line 292
    const-string v3, "menuId"

    .line 293
    .line 294
    invoke-virtual {p3, v3, v1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 295
    .line 296
    .line 297
    move-result-object p3

    .line 298
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 299
    .line 300
    invoke-virtual {p1, p3}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 301
    .line 302
    .line 303
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->hasLogin()Z

    .line 304
    .line 305
    .line 306
    move-result p1

    .line 307
    if-nez p1, :cond_8

    .line 308
    .line 309
    iget-object p1, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->jumpPath:Ljava/lang/String;

    .line 310
    .line 311
    iget-object p3, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->jumpType:Ljava/lang/String;

    .line 312
    .line 313
    iget-object p2, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->jumpParams:Ljava/lang/String;

    .line 314
    .line 315
    invoke-static {p1, p3, p2}, LPa/F;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 316
    .line 317
    .line 318
    move-result-object p1

    .line 319
    invoke-static {v0, p1}, LPa/i0;->K(Ljava/lang/String;Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    goto :goto_2

    .line 323
    :cond_8
    iget-object p1, v2, LIe/s;->d:Lcom/transsnet/palmpay/ui/viewhandler/MenuModelViewHandler$OnMenuItemClickListener;

    .line 324
    .line 325
    if-eqz p1, :cond_9

    .line 326
    .line 327
    invoke-interface {p1, p2}, Lcom/transsnet/palmpay/ui/viewhandler/MenuModelViewHandler$OnMenuItemClickListener;->onMenuItemClick(Lcom/transsnet/palmpay/core/bean/HomePageMenuData;)V

    .line 328
    .line 329
    .line 330
    :cond_9
    iget-object p1, p2, Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;->jumpPath:Ljava/lang/String;

    .line 331
    .line 332
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 333
    .line 334
    .line 335
    move-result p1

    .line 336
    if-nez p1, :cond_a

    .line 337
    .line 338
    invoke-static {p2}, LPa/F;->d(Lcom/transsnet/palmpay/core/bean/rsp/HomeMenuBean;)V

    .line 339
    .line 340
    .line 341
    :cond_a
    :goto_2
    return-void

    .line 342
    :sswitch_2
    check-cast p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;

    .line 343
    .line 344
    sget v3, Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;->d:I

    .line 345
    .line 346
    const-string v3, "<unused var>"

    .line 347
    .line 348
    invoke-static {p1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 349
    .line 350
    .line 351
    const-string p1, "viewHolder"

    .line 352
    .line 353
    invoke-static {p3, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    invoke-virtual {p3}, Landroidx/recyclerview/widget/RecyclerView$ViewHolder;->getLayoutPosition()I

    .line 357
    .line 358
    .line 359
    move-result p1

    .line 360
    if-eqz p2, :cond_b

    .line 361
    .line 362
    iget-object p3, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->loanProduct:Ljava/lang/String;

    .line 363
    .line 364
    goto :goto_3

    .line 365
    :cond_b
    move-object p3, v0

    .line 366
    :goto_3
    const-string v3, "OutstandingDetailItem >>> click, position="

    .line 367
    .line 368
    const-string v4, ", loanProduct="

    .line 369
    .line 370
    invoke-static {v3, p1, v4, p3}, Lcom/airbnb/lottie/model/layer/d;->j(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 371
    .line 372
    .line 373
    move-result-object p1

    .line 374
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 375
    .line 376
    .line 377
    move-result-object p1

    .line 378
    const/4 p3, 0x3

    .line 379
    const-string v3, "TotalOutstandingView"

    .line 380
    .line 381
    invoke-static {v3, p3, p1}, LF6/d;->h(Ljava/lang/String;I[Ljava/lang/Object;)V

    .line 382
    .line 383
    .line 384
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 385
    .line 386
    .line 387
    move-result-object p1

    .line 388
    new-instance p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 389
    .line 390
    const-string v3, "outstanding_loan_item_click"

    .line 391
    .line 392
    invoke-direct {p3, v3}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 393
    .line 394
    .line 395
    if-eqz p2, :cond_c

    .line 396
    .line 397
    iget-object v3, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->loanProduct:Ljava/lang/String;

    .line 398
    .line 399
    goto :goto_4

    .line 400
    :cond_c
    move-object v3, v0

    .line 401
    :goto_4
    const-string v4, "loanProduct"

    .line 402
    .line 403
    invoke-virtual {p3, v4, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 404
    .line 405
    .line 406
    move-result-object p3

    .line 407
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 408
    .line 409
    if-eqz p2, :cond_d

    .line 410
    .line 411
    iget-object v3, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->billId:Ljava/lang/Long;

    .line 412
    .line 413
    if-eqz v3, :cond_d

    .line 414
    .line 415
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 416
    .line 417
    .line 418
    move-result-wide v5

    .line 419
    goto :goto_5

    .line 420
    :cond_d
    const-wide/16 v5, 0x0

    .line 421
    .line 422
    :goto_5
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 423
    .line 424
    .line 425
    move-result-object v3

    .line 426
    const-string v5, "billId"

    .line 427
    .line 428
    invoke-virtual {p3, v5, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 429
    .line 430
    .line 431
    move-result-object p3

    .line 432
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 433
    .line 434
    invoke-virtual {p1, p3}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 435
    .line 436
    .line 437
    check-cast v2, Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;

    .line 438
    .line 439
    if-eqz p2, :cond_f

    .line 440
    .line 441
    iget-object p1, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->accountType:Ljava/lang/Integer;

    .line 442
    .line 443
    if-nez p1, :cond_e

    .line 444
    .line 445
    goto :goto_6

    .line 446
    :cond_e
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 447
    .line 448
    .line 449
    move-result p1

    .line 450
    if-ne p1, v1, :cond_f

    .line 451
    .line 452
    invoke-static {}, Lcom/alibaba/android/arouter/launcher/ARouter;->getInstance()Lcom/alibaba/android/arouter/launcher/ARouter;

    .line 453
    .line 454
    .line 455
    move-result-object p1

    .line 456
    const-string p3, "/credit_score/oc_repay_activity"

    .line 457
    .line 458
    invoke-virtual {p1, p3}, Lcom/alibaba/android/arouter/launcher/ARouter;->build(Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 459
    .line 460
    .line 461
    move-result-object p1

    .line 462
    const-string p3, "oc_repay_card_no"

    .line 463
    .line 464
    iget-object p2, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->cardNo:Ljava/lang/String;

    .line 465
    .line 466
    invoke-virtual {p1, p3, p2}, Lcom/alibaba/android/arouter/facade/Postcard;->withString(Ljava/lang/String;Ljava/lang/String;)Lcom/alibaba/android/arouter/facade/Postcard;

    .line 467
    .line 468
    .line 469
    move-result-object p1

    .line 470
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 471
    .line 472
    .line 473
    move-result-object p2

    .line 474
    invoke-virtual {p1, p2}, Lcom/alibaba/android/arouter/facade/Postcard;->navigation(Landroid/content/Context;)Ljava/lang/Object;

    .line 475
    .line 476
    .line 477
    goto :goto_b

    .line 478
    :cond_f
    :goto_6
    if-eqz p2, :cond_11

    .line 479
    .line 480
    iget-object p1, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->accountType:Ljava/lang/Integer;

    .line 481
    .line 482
    if-nez p1, :cond_10

    .line 483
    .line 484
    goto :goto_7

    .line 485
    :cond_10
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 486
    .line 487
    .line 488
    move-result p1

    .line 489
    const/16 p3, 0xd

    .line 490
    .line 491
    if-ne p1, p3, :cond_11

    .line 492
    .line 493
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 494
    .line 495
    .line 496
    invoke-static {p2}, Lcom/transsnet/palmpay/credit/view/TotalOutstandingView;->g(Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;)V

    .line 497
    .line 498
    .line 499
    goto :goto_b

    .line 500
    :cond_11
    :goto_7
    new-instance p1, Landroid/os/Bundle;

    .line 501
    .line 502
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 503
    .line 504
    .line 505
    if-eqz p2, :cond_12

    .line 506
    .line 507
    iget-object p3, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->billId:Ljava/lang/Long;

    .line 508
    .line 509
    goto :goto_8

    .line 510
    :cond_12
    move-object p3, v0

    .line 511
    :goto_8
    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 512
    .line 513
    .line 514
    move-result-object p3

    .line 515
    invoke-virtual {p1, v5, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 516
    .line 517
    .line 518
    if-eqz p2, :cond_13

    .line 519
    .line 520
    iget-object p3, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->accountType:Ljava/lang/Integer;

    .line 521
    .line 522
    goto :goto_9

    .line 523
    :cond_13
    move-object p3, v0

    .line 524
    :goto_9
    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 525
    .line 526
    .line 527
    move-result-object p3

    .line 528
    const-string v1, "accountType"

    .line 529
    .line 530
    invoke-virtual {p1, v1, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 531
    .line 532
    .line 533
    if-eqz p2, :cond_14

    .line 534
    .line 535
    iget-object p3, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->cardNo:Ljava/lang/String;

    .line 536
    .line 537
    goto :goto_a

    .line 538
    :cond_14
    move-object p3, v0

    .line 539
    :goto_a
    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 540
    .line 541
    .line 542
    move-result-object p3

    .line 543
    const-string v1, "cardNo"

    .line 544
    .line 545
    invoke-virtual {p1, v1, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 546
    .line 547
    .line 548
    if-eqz p2, :cond_15

    .line 549
    .line 550
    iget-object v0, p2, Lcom/transsnet/palmpay/credit/bean/OutstandingAccount;->loanProduct:Ljava/lang/String;

    .line 551
    .line 552
    :cond_15
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 553
    .line 554
    .line 555
    move-result-object p2

    .line 556
    invoke-virtual {p1, v4, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 557
    .line 558
    .line 559
    const-string p2, "LoanOutstandingBill"

    .line 560
    .line 561
    invoke-static {p1, p2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 562
    .line 563
    .line 564
    :goto_b
    return-void

    .line 565
    :sswitch_data_0
    .sparse-switch
        0xe -> :sswitch_2
        0x13 -> :sswitch_1
        0x16 -> :sswitch_0
    .end sparse-switch
.end method

.method public accept(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LEd/d;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LEd/d;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public analyze(Landroidx/camera/core/ImageProxy;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, LDg/a;->b:Ljava/lang/Object;

    .line 6
    .line 7
    iget v3, v0, LDg/a;->a:I

    .line 8
    .line 9
    packed-switch v3, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget v3, Lcom/palmpay/lib/scanplus/view/CameraXView;->t:I

    .line 13
    .line 14
    check-cast v2, Lcom/palmpay/lib/scanplus/view/CameraXView;

    .line 15
    .line 16
    const-string v3, "this$0"

    .line 17
    .line 18
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string v3, "imageProxy"

    .line 22
    .line 23
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v3, v2, Lcom/palmpay/lib/scanplus/view/CameraXView;->f:Landroid/graphics/Matrix;

    .line 27
    .line 28
    const/4 v4, 0x2

    .line 29
    if-nez v3, :cond_1

    .line 30
    .line 31
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getWidth()I

    .line 40
    .line 41
    .line 42
    move-result v6

    .line 43
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getHeight()I

    .line 44
    .line 45
    .line 46
    move-result v7

    .line 47
    int-to-float v7, v7

    .line 48
    int-to-float v6, v6

    .line 49
    div-float/2addr v7, v6

    .line 50
    int-to-float v3, v3

    .line 51
    int-to-float v5, v5

    .line 52
    div-float v6, v3, v5

    .line 53
    .line 54
    cmpg-float v8, v6, v7

    .line 55
    .line 56
    const/high16 v9, 0x3f800000    # 1.0f

    .line 57
    .line 58
    if-gez v8, :cond_0

    .line 59
    .line 60
    div-float/2addr v7, v6

    .line 61
    move v6, v9

    .line 62
    move v9, v7

    .line 63
    goto :goto_0

    .line 64
    :cond_0
    div-float/2addr v6, v7

    .line 65
    :goto_0
    mul-float v7, v3, v9

    .line 66
    .line 67
    mul-float v8, v5, v6

    .line 68
    .line 69
    sub-float/2addr v3, v7

    .line 70
    int-to-float v7, v4

    .line 71
    div-float/2addr v3, v7

    .line 72
    sub-float/2addr v5, v8

    .line 73
    div-float/2addr v5, v7

    .line 74
    new-instance v7, Landroid/graphics/Matrix;

    .line 75
    .line 76
    invoke-direct {v7}, Landroid/graphics/Matrix;-><init>()V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v7, v9, v6}, Landroid/graphics/Matrix;->postScale(FF)Z

    .line 80
    .line 81
    .line 82
    invoke-virtual {v7, v3, v5}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 83
    .line 84
    .line 85
    iput-object v7, v2, Lcom/palmpay/lib/scanplus/view/CameraXView;->f:Landroid/graphics/Matrix;

    .line 86
    .line 87
    :cond_1
    iget-object v3, v2, Lcom/palmpay/lib/scanplus/view/CameraXView;->j:Lkotlin/jvm/functions/Function4;

    .line 88
    .line 89
    if-eqz v3, :cond_3

    .line 90
    .line 91
    const-string v5, "image"

    .line 92
    .line 93
    invoke-static {v1, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getWidth()I

    .line 97
    .line 98
    .line 99
    move-result v5

    .line 100
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getHeight()I

    .line 101
    .line 102
    .line 103
    move-result v6

    .line 104
    mul-int/2addr v6, v5

    .line 105
    mul-int/lit8 v6, v6, 0x3

    .line 106
    .line 107
    div-int/2addr v6, v4

    .line 108
    new-array v15, v6, [B

    .line 109
    .line 110
    new-instance v7, Lcom/palmpay/lib/scanplus/code/YuvUtils;

    .line 111
    .line 112
    invoke-direct {v7}, Lcom/palmpay/lib/scanplus/code/YuvUtils;-><init>()V

    .line 113
    .line 114
    .line 115
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getPlanes()[Landroidx/camera/core/ImageProxy$PlaneProxy;

    .line 116
    .line 117
    .line 118
    move-result-object v5

    .line 119
    const/4 v6, 0x0

    .line 120
    aget-object v5, v5, v6

    .line 121
    .line 122
    invoke-interface {v5}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getBuffer()Ljava/nio/ByteBuffer;

    .line 123
    .line 124
    .line 125
    move-result-object v8

    .line 126
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getPlanes()[Landroidx/camera/core/ImageProxy$PlaneProxy;

    .line 127
    .line 128
    .line 129
    move-result-object v5

    .line 130
    const/4 v9, 0x1

    .line 131
    aget-object v5, v5, v9

    .line 132
    .line 133
    invoke-interface {v5}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getBuffer()Ljava/nio/ByteBuffer;

    .line 134
    .line 135
    .line 136
    move-result-object v5

    .line 137
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getPlanes()[Landroidx/camera/core/ImageProxy$PlaneProxy;

    .line 138
    .line 139
    .line 140
    move-result-object v10

    .line 141
    aget-object v10, v10, v4

    .line 142
    .line 143
    invoke-interface {v10}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getBuffer()Ljava/nio/ByteBuffer;

    .line 144
    .line 145
    .line 146
    move-result-object v10

    .line 147
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getPlanes()[Landroidx/camera/core/ImageProxy$PlaneProxy;

    .line 148
    .line 149
    .line 150
    move-result-object v11

    .line 151
    aget-object v11, v11, v6

    .line 152
    .line 153
    invoke-interface {v11}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getRowStride()I

    .line 154
    .line 155
    .line 156
    move-result v11

    .line 157
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getPlanes()[Landroidx/camera/core/ImageProxy$PlaneProxy;

    .line 158
    .line 159
    .line 160
    move-result-object v12

    .line 161
    aget-object v9, v12, v9

    .line 162
    .line 163
    invoke-interface {v9}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getRowStride()I

    .line 164
    .line 165
    .line 166
    move-result v12

    .line 167
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getPlanes()[Landroidx/camera/core/ImageProxy$PlaneProxy;

    .line 168
    .line 169
    .line 170
    move-result-object v9

    .line 171
    aget-object v9, v9, v4

    .line 172
    .line 173
    invoke-interface {v9}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getRowStride()I

    .line 174
    .line 175
    .line 176
    move-result v13

    .line 177
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getPlanes()[Landroidx/camera/core/ImageProxy$PlaneProxy;

    .line 178
    .line 179
    .line 180
    move-result-object v9

    .line 181
    aget-object v9, v9, v4

    .line 182
    .line 183
    invoke-interface {v9}, Landroidx/camera/core/ImageProxy$PlaneProxy;->getPixelStride()I

    .line 184
    .line 185
    .line 186
    move-result v14

    .line 187
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getWidth()I

    .line 188
    .line 189
    .line 190
    move-result v16

    .line 191
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getHeight()I

    .line 192
    .line 193
    .line 194
    move-result v17

    .line 195
    move-object v9, v5

    .line 196
    invoke-virtual/range {v7 .. v17}, Lcom/palmpay/lib/scanplus/code/YuvUtils;->Android420ToI420(Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;IIII[BII)V

    .line 197
    .line 198
    .line 199
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getWidth()I

    .line 200
    .line 201
    .line 202
    move-result v10

    .line 203
    invoke-interface {v1}, Landroidx/camera/core/ImageProxy;->getHeight()I

    .line 204
    .line 205
    .line 206
    move-result v11

    .line 207
    const/16 v5, 0x9

    .line 208
    .line 209
    new-array v5, v5, [F

    .line 210
    .line 211
    iget-object v7, v2, Lcom/palmpay/lib/scanplus/view/CameraXView;->f:Landroid/graphics/Matrix;

    .line 212
    .line 213
    if-eqz v7, :cond_2

    .line 214
    .line 215
    invoke-virtual {v7, v5}, Landroid/graphics/Matrix;->getValues([F)V

    .line 216
    .line 217
    .line 218
    :cond_2
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 219
    .line 220
    .line 221
    move-result v7

    .line 222
    int-to-float v7, v7

    .line 223
    aget v6, v5, v6

    .line 224
    .line 225
    mul-float/2addr v7, v6

    .line 226
    float-to-int v6, v7

    .line 227
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 228
    .line 229
    .line 230
    move-result v7

    .line 231
    int-to-float v7, v7

    .line 232
    const/4 v8, 0x4

    .line 233
    aget v8, v5, v8

    .line 234
    .line 235
    mul-float/2addr v7, v8

    .line 236
    float-to-int v7, v7

    .line 237
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 238
    .line 239
    .line 240
    move-result v8

    .line 241
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 242
    .line 243
    .line 244
    move-result v9

    .line 245
    mul-int/2addr v9, v8

    .line 246
    mul-int/lit8 v9, v9, 0x3

    .line 247
    .line 248
    div-int/2addr v9, v4

    .line 249
    new-array v9, v9, [B

    .line 250
    .line 251
    const/4 v8, 0x5

    .line 252
    aget v8, v5, v8

    .line 253
    .line 254
    invoke-static {v8}, Ljava/lang/Math;->abs(F)F

    .line 255
    .line 256
    .line 257
    move-result v8

    .line 258
    float-to-int v12, v8

    .line 259
    aget v4, v5, v4

    .line 260
    .line 261
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 262
    .line 263
    .line 264
    move-result v4

    .line 265
    float-to-int v13, v4

    .line 266
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 267
    .line 268
    .line 269
    move-result v14

    .line 270
    move-object v8, v15

    .line 271
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 272
    .line 273
    .line 274
    move-result v15

    .line 275
    move/from16 v16, v7

    .line 276
    .line 277
    iget-object v7, v2, Lcom/palmpay/lib/scanplus/view/CameraXView;->p:Lcom/palmpay/lib/scanplus/code/YuvUtils;

    .line 278
    .line 279
    move/from16 v17, v6

    .line 280
    .line 281
    invoke-virtual/range {v7 .. v17}, Lcom/palmpay/lib/scanplus/code/YuvUtils;->scaleAndclipping([B[BIIIIIIII)V

    .line 282
    .line 283
    .line 284
    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    .line 285
    .line 286
    .line 287
    move-result v4

    .line 288
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 289
    .line 290
    .line 291
    move-result-object v4

    .line 292
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    .line 293
    .line 294
    .line 295
    move-result v2

    .line 296
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 297
    .line 298
    .line 299
    move-result-object v2

    .line 300
    invoke-interface {v3, v1, v9, v4, v2}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    :cond_3
    return-void

    .line 304
    :pswitch_0
    check-cast v2, Landroidx/camera/core/ImageAnalysis$Analyzer;

    .line 305
    .line 306
    invoke-interface {v2, v1}, Landroidx/camera/core/ImageAnalysis$Analyzer;->analyze(Landroidx/camera/core/ImageProxy;)V

    .line 307
    .line 308
    .line 309
    return-void

    .line 310
    nop

    .line 311
    :pswitch_data_0
    .packed-switch 0x3
        :pswitch_0
    .end packed-switch
.end method

.method public attachCompleter(Landroidx/concurrent/futures/k;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/camera/core/c;

    .line 4
    .line 5
    iget-object v1, v0, Landroidx/camera/core/c;->a:LN2/a;

    .line 6
    .line 7
    iget-object v2, v1, LN2/a;->a:Ljava/lang/Object;

    .line 8
    .line 9
    monitor-enter v2

    .line 10
    :try_start_0
    iget-object v3, v1, LN2/a;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v3, Ljava/util/LinkedHashMap;

    .line 13
    .line 14
    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    if-eqz v3, :cond_1

    .line 19
    .line 20
    iget-object v1, v1, LN2/a;->d:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v1, Landroidx/concurrent/futures/m;

    .line 23
    .line 24
    if-nez v1, :cond_0

    .line 25
    .line 26
    sget-object v1, Landroidx/camera/core/impl/utils/futures/l;->c:Landroidx/camera/core/impl/utils/futures/l;

    .line 27
    .line 28
    :cond_0
    monitor-exit v2

    .line 29
    goto :goto_1

    .line 30
    :catchall_0
    move-exception p1

    .line 31
    goto :goto_2

    .line 32
    :cond_1
    iget-object v3, v1, LN2/a;->d:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v3, Landroidx/concurrent/futures/m;

    .line 35
    .line 36
    if-nez v3, :cond_2

    .line 37
    .line 38
    new-instance v3, Landroidx/camera/core/impl/L;

    .line 39
    .line 40
    const/4 v4, 0x0

    .line 41
    invoke-direct {v3, v1, v4}, Landroidx/camera/core/impl/L;-><init>(Ljava/lang/Object;I)V

    .line 42
    .line 43
    .line 44
    invoke-static {v3}, LE/c;->y(Landroidx/concurrent/futures/CallbackToFutureAdapter$Resolver;)Landroidx/concurrent/futures/m;

    .line 45
    .line 46
    .line 47
    move-result-object v3

    .line 48
    iput-object v3, v1, LN2/a;->d:Ljava/lang/Object;

    .line 49
    .line 50
    :cond_2
    iget-object v4, v1, LN2/a;->c:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v4, Ljava/util/HashSet;

    .line 53
    .line 54
    iget-object v5, v1, LN2/a;->b:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v5, Ljava/util/LinkedHashMap;

    .line 57
    .line 58
    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 59
    .line 60
    .line 61
    move-result-object v5

    .line 62
    invoke-interface {v4, v5}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 63
    .line 64
    .line 65
    iget-object v4, v1, LN2/a;->b:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v4, Ljava/util/LinkedHashMap;

    .line 68
    .line 69
    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 70
    .line 71
    .line 72
    move-result-object v4

    .line 73
    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    if-eqz v5, :cond_3

    .line 82
    .line 83
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    check-cast v5, Landroidx/camera/core/impl/CameraInternal;

    .line 88
    .line 89
    invoke-interface {v5}, Landroidx/camera/core/impl/CameraInternal;->release()Lcom/google/common/util/concurrent/ListenableFuture;

    .line 90
    .line 91
    .line 92
    move-result-object v6

    .line 93
    new-instance v7, Landroidx/biometric/g;

    .line 94
    .line 95
    const/16 v8, 0xa

    .line 96
    .line 97
    invoke-direct {v7, v8, v1, v5}, Landroidx/biometric/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    invoke-static {}, Lorg/chromium/support_lib_boundary/util/b;->u()Landroidx/camera/core/impl/utils/executor/a;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    invoke-interface {v6, v7, v5}, Lcom/google/common/util/concurrent/ListenableFuture;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 105
    .line 106
    .line 107
    goto :goto_0

    .line 108
    :cond_3
    iget-object v1, v1, LN2/a;->b:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v1, Ljava/util/LinkedHashMap;

    .line 111
    .line 112
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->clear()V

    .line 113
    .line 114
    .line 115
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 116
    move-object v1, v3

    .line 117
    :goto_1
    new-instance v2, LB6/g;

    .line 118
    .line 119
    const/4 v3, 0x7

    .line 120
    invoke-direct {v2, v3, v0, p1}, LB6/g;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    iget-object p1, v0, Landroidx/camera/core/c;->d:Ljava/util/concurrent/Executor;

    .line 124
    .line 125
    invoke-interface {v1, v2, p1}, Lcom/google/common/util/concurrent/ListenableFuture;->addListener(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 126
    .line 127
    .line 128
    const-string p1, "CameraX shutdownInternal"

    .line 129
    .line 130
    return-object p1

    .line 131
    :goto_2
    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 132
    throw p1
.end method

.method public create(Lokhttp3/Call;)Lokhttp3/y;
    .locals 2

    .line 1
    const-string v0, "$this_asFactory"

    .line 2
    .line 3
    iget-object v1, p0, LDg/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lokhttp3/y;

    .line 6
    .line 7
    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v0, "it"

    .line 11
    .line 12
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    return-object v1
.end method

.method public execute(Lcom/facebook/react/uimanager/NativeViewHierarchyManager;)V
    .locals 1

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    goto :goto_0

    .line 4
    :cond_0
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v0, LM7/H;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/facebook/react/uimanager/ReactShadowNodeImpl;->getReactTag()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-virtual {p1, v0}, Lcom/facebook/react/uimanager/NativeViewHierarchyManager;->resolveView(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    instance-of v0, p1, Lcom/swmansion/rnscreens/ScreenContainer;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    check-cast p1, Lcom/swmansion/rnscreens/ScreenContainer;

    .line 21
    .line 22
    invoke-virtual {p1}, Lcom/swmansion/rnscreens/ScreenContainer;->g()V

    .line 23
    .line 24
    .line 25
    :cond_1
    :goto_0
    return-void
.end method

.method public filter(Ljava/util/List;I)Ljava/util/List;
    .locals 1

    .line 1
    new-instance p2, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {p2, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, LDg/a;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Landroid/util/Size;

    .line 9
    .line 10
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    invoke-virtual {p2, v0, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    return-object p2
.end method

.method public onAdvancedCountDownEnd()V
    .locals 1

    .line 1
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomeFragment;

    .line 4
    .line 5
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 6
    .line 7
    check-cast v0, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->e()V

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
.end method

.method public onClose()Z
    .locals 4

    .line 1
    iget v0, p0, LDg/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lcom/swmansion/rnscreens/SearchBarView;

    .line 9
    .line 10
    invoke-static {v0}, Lcom/swmansion/rnscreens/SearchBarView;->c(Lcom/swmansion/rnscreens/SearchBarView;)V

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    return v0

    .line 15
    :pswitch_0
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lcom/swmansion/rnscreens/CustomSearchView;

    .line 18
    .line 19
    iget-object v1, v0, Lcom/swmansion/rnscreens/CustomSearchView;->M0:Landroidx/appcompat/widget/SearchView$OnCloseListener;

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    if-eqz v1, :cond_0

    .line 23
    .line 24
    invoke-interface {v1}, Landroidx/appcompat/widget/SearchView$OnCloseListener;->onClose()Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    move v1, v2

    .line 30
    :goto_0
    iget-object v0, v0, Lcom/swmansion/rnscreens/CustomSearchView;->O0:LM7/b;

    .line 31
    .line 32
    iget-boolean v3, v0, LM7/b;->a:Z

    .line 33
    .line 34
    if-eqz v3, :cond_1

    .line 35
    .line 36
    iget-object v3, v0, LM7/b;->d:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v3, Ltb/K;

    .line 39
    .line 40
    invoke-virtual {v3}, Landroidx/activity/z;->remove()V

    .line 41
    .line 42
    .line 43
    iput-boolean v2, v0, LM7/b;->a:Z

    .line 44
    .line 45
    :cond_1
    return v1

    .line 46
    nop

    .line 47
    :pswitch_data_0
    .packed-switch 0x1a
        :pswitch_0
    .end packed-switch
.end method

.method public onConfigureTab(Lcom/google/android/material/tabs/TabLayout$Tab;I)V
    .locals 1

    .line 1
    const-string v0, "tab"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeFragment;

    .line 9
    .line 10
    iget-object v0, v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayHomeFragment;->p:Lxf/t;

    .line 11
    .line 12
    invoke-virtual {v0}, Lxf/t;->getValue()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p2

    .line 22
    check-cast p2, Ljava/lang/CharSequence;

    .line 23
    .line 24
    invoke-virtual {p1, p2}, Lcom/google/android/material/tabs/TabLayout$Tab;->setText(Ljava/lang/CharSequence;)Lcom/google/android/material/tabs/TabLayout$Tab;

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public onImageAvailable(Landroidx/camera/core/impl/ImageReaderProxy;)V
    .locals 3

    .line 1
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LE/W;

    .line 4
    .line 5
    iget-object v1, v0, LE/W;->a:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v1

    .line 8
    :try_start_0
    iget v2, v0, LE/W;->c:I

    .line 9
    .line 10
    add-int/lit8 v2, v2, 0x1

    .line 11
    .line 12
    iput v2, v0, LE/W;->c:I

    .line 13
    .line 14
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    invoke-virtual {v0, p1}, LE/W;->c(Landroidx/camera/core/impl/ImageReaderProxy;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :catchall_0
    move-exception p1

    .line 20
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 21
    throw p1
.end method

.method public onItemChildClick(LM1/j;Landroid/view/View;I)V
    .locals 7

    .line 1
    iget v0, p0, LDg/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "<unused var>"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string p1, "view"

    .line 12
    .line 13
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p2}, Landroid/view/View;->getId()I

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    iget-object p2, p0, LDg/a;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast p2, LMe/o;

    .line 23
    .line 24
    iget-object v0, p2, LMe/o;->c:LP8/a;

    .line 25
    .line 26
    if-eqz v0, :cond_5

    .line 27
    .line 28
    invoke-virtual {v0, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    check-cast v0, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeCouponRewardsItems;

    .line 33
    .line 34
    if-nez v0, :cond_0

    .line 35
    .line 36
    goto/16 :goto_2

    .line 37
    .line 38
    :cond_0
    new-instance v1, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 39
    .line 40
    const-string v2, "new_reward_hub_click"

    .line 41
    .line 42
    invoke-direct {v1, v2}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    iget-object v2, v0, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeCouponRewardsItems;->claimType:Ljava/lang/String;

    .line 46
    .line 47
    const-string v3, "combo"

    .line 48
    .line 49
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_1

    .line 54
    .line 55
    const-string v2, "coupons_combo"

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    const-string v2, "coupon"

    .line 59
    .line 60
    :goto_0
    const-string v3, "reward_type"

    .line 61
    .line 62
    invoke-virtual {v1, v3, v2}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 63
    .line 64
    .line 65
    const-string v2, "reward_title"

    .line 66
    .line 67
    iget-object v3, v0, Lcom/transsnet/palmpay/core/bean/CouponItem;->couponName:Ljava/lang/String;

    .line 68
    .line 69
    invoke-virtual {v1, v2, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 70
    .line 71
    .line 72
    iget-wide v2, v0, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeCouponRewardsItems;->nominalValue:J

    .line 73
    .line 74
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    const-string v3, "reward_value"

    .line 79
    .line 80
    invoke-virtual {v1, v3, v2}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 81
    .line 82
    .line 83
    iget-wide v2, v0, Lcom/transsnet/palmpay/core/bean/CouponItem;->couponId:J

    .line 84
    .line 85
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    const-string v3, "id"

    .line 90
    .line 91
    invoke-virtual {v1, v3, v2}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 92
    .line 93
    .line 94
    const-string v2, "priority"

    .line 95
    .line 96
    invoke-static {p3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    invoke-virtual {v1, v2, v3}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 101
    .line 102
    .line 103
    sget v2, LAc/e;->btnClaim:I

    .line 104
    .line 105
    const-string v3, "button"

    .line 106
    .line 107
    if-ne p1, v2, :cond_2

    .line 108
    .line 109
    const-string p1, "Claim"

    .line 110
    .line 111
    invoke-virtual {v1, v3, p1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 112
    .line 113
    .line 114
    const/4 p1, 0x1

    .line 115
    iput-boolean p1, v0, Lcom/transsnet/palmpay/main/export/bean/rsp/HomeCouponRewardsItems;->isLoading:Z

    .line 116
    .line 117
    invoke-virtual {p2, p3, p1}, LMe/o;->a(IZ)V

    .line 118
    .line 119
    .line 120
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    iget-object p2, p2, LMe/o;->b:LBa/a;

    .line 125
    .line 126
    invoke-virtual {p2, v0, p1}, LBa/a;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    goto :goto_1

    .line 130
    :cond_2
    sget p3, LAc/e;->btnUse:I

    .line 131
    .line 132
    if-ne p1, p3, :cond_4

    .line 133
    .line 134
    const-string p1, "Use"

    .line 135
    .line 136
    invoke-virtual {v1, v3, p1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 137
    .line 138
    .line 139
    iget-object p1, v0, Lcom/transsnet/palmpay/core/bean/CouponItem;->androidLinkUrl:Ljava/lang/String;

    .line 140
    .line 141
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 142
    .line 143
    .line 144
    move-result p1

    .line 145
    if-eqz p1, :cond_3

    .line 146
    .line 147
    const/4 p1, 0x0

    .line 148
    const-string p2, "Coupon"

    .line 149
    .line 150
    invoke-static {p1, p2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    goto :goto_1

    .line 154
    :cond_3
    iget-object p1, p2, LMe/o;->d:Landroid/content/Context;

    .line 155
    .line 156
    iget-object p2, v0, Lcom/transsnet/palmpay/core/bean/CouponItem;->androidLinkUrl:Ljava/lang/String;

    .line 157
    .line 158
    invoke-static {p1, p2}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 163
    .line 164
    .line 165
    :cond_4
    :goto_1
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 166
    .line 167
    .line 168
    move-result-object p1

    .line 169
    invoke-virtual {p1, v1}, LPa/n0;->q(Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;)V

    .line 170
    .line 171
    .line 172
    :cond_5
    :goto_2
    return-void

    .line 173
    :pswitch_0
    const-string v0, "adapter"

    .line 174
    .line 175
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 176
    .line 177
    .line 178
    const-string v0, "view"

    .line 179
    .line 180
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    const-string p3, "null cannot be cast to non-null type com.transsnet.palmpay.credit.bean.resp.mobile_Installment.CLPhoneInstallmentMainData"

    .line 188
    .line 189
    invoke-static {p1, p3}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    check-cast p1, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;

    .line 193
    .line 194
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getItemLayoutType()Ljava/lang/Integer;

    .line 195
    .line 196
    .line 197
    move-result-object p3

    .line 198
    const/4 v0, 0x0

    .line 199
    const/16 v1, 0x1c

    .line 200
    .line 201
    const/4 v2, 0x0

    .line 202
    iget-object v3, p0, LDg/a;->b:Ljava/lang/Object;

    .line 203
    .line 204
    check-cast v3, LGb/y;

    .line 205
    .line 206
    if-nez p3, :cond_6

    .line 207
    .line 208
    goto/16 :goto_a

    .line 209
    .line 210
    :cond_6
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 211
    .line 212
    .line 213
    move-result v4

    .line 214
    if-nez v4, :cond_16

    .line 215
    .line 216
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getMobileInstallmentCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;

    .line 217
    .line 218
    .line 219
    move-result-object p3

    .line 220
    invoke-virtual {p2}, Landroid/view/View;->getId()I

    .line 221
    .line 222
    .line 223
    move-result p2

    .line 224
    sget v4, LYa/e;->ivRefreshLockTime:I

    .line 225
    .line 226
    if-eq p2, v4, :cond_15

    .line 227
    .line 228
    sget v4, LYa/e;->tvDeviceActiveTime:I

    .line 229
    .line 230
    if-ne p2, v4, :cond_7

    .line 231
    .line 232
    goto/16 :goto_9

    .line 233
    .line 234
    :cond_7
    sget v4, LYa/e;->btnRepay:I

    .line 235
    .line 236
    if-ne p2, v4, :cond_b

    .line 237
    .line 238
    if-eqz p3, :cond_8

    .line 239
    .line 240
    invoke-virtual {p3}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLoanTermSpanUnit()Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object p1

    .line 244
    goto :goto_3

    .line 245
    :cond_8
    move-object p1, v2

    .line 246
    :goto_3
    if-eqz p1, :cond_9

    .line 247
    .line 248
    invoke-static {p1}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 249
    .line 250
    .line 251
    move-result-object p1

    .line 252
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 253
    .line 254
    .line 255
    move-result-object p1

    .line 256
    goto :goto_4

    .line 257
    :cond_9
    move-object p1, v2

    .line 258
    :goto_4
    const-string p2, "D"

    .line 259
    .line 260
    invoke-virtual {p2, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 261
    .line 262
    .line 263
    move-result p1

    .line 264
    if-eqz p1, :cond_a

    .line 265
    .line 266
    invoke-static {p3}, LD3/a;->w(Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;)V

    .line 267
    .line 268
    .line 269
    goto/16 :goto_c

    .line 270
    .line 271
    :cond_a
    const-string p1, "MobileInstallmentRepaymentHome"

    .line 272
    .line 273
    invoke-static {v2, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 274
    .line 275
    .line 276
    goto/16 :goto_c

    .line 277
    .line 278
    :cond_b
    sget v4, LYa/e;->btnDailyRepay:I

    .line 279
    .line 280
    if-ne p2, v4, :cond_c

    .line 281
    .line 282
    invoke-static {p3}, LD3/a;->w(Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;)V

    .line 283
    .line 284
    .line 285
    goto/16 :goto_c

    .line 286
    .line 287
    :cond_c
    sget v4, LYa/e;->llDailyRepaymentHistory:I

    .line 288
    .line 289
    const-string v5, "loanNo"

    .line 290
    .line 291
    const-string v6, ""

    .line 292
    .line 293
    if-ne p2, v4, :cond_11

    .line 294
    .line 295
    new-instance p1, Landroid/os/Bundle;

    .line 296
    .line 297
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 298
    .line 299
    .line 300
    if-eqz p3, :cond_d

    .line 301
    .line 302
    invoke-virtual {p3}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLoanNo()Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    move-result-object p2

    .line 306
    goto :goto_5

    .line 307
    :cond_d
    move-object p2, v2

    .line 308
    :goto_5
    if-nez p2, :cond_e

    .line 309
    .line 310
    move-object p2, v6

    .line 311
    :cond_e
    invoke-virtual {p1, v5, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 312
    .line 313
    .line 314
    if-eqz p3, :cond_f

    .line 315
    .line 316
    invoke-virtual {p3}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getCardNo()Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object v2

    .line 320
    :cond_f
    if-nez v2, :cond_10

    .line 321
    .line 322
    goto :goto_6

    .line 323
    :cond_10
    move-object v6, v2

    .line 324
    :goto_6
    const-string p2, "cardNo"

    .line 325
    .line 326
    invoke-virtual {p1, p2, v6}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 327
    .line 328
    .line 329
    const-string p2, "MobileInstallmentDailyRepaymentHistory"

    .line 330
    .line 331
    invoke-static {p1, p2}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 332
    .line 333
    .line 334
    goto/16 :goto_c

    .line 335
    .line 336
    :cond_11
    sget v4, LYa/e;->btnUnlock:I

    .line 337
    .line 338
    if-ne p2, v4, :cond_13

    .line 339
    .line 340
    iget-object p1, v3, LGb/y;->b:Ljava/lang/ref/WeakReference;

    .line 341
    .line 342
    if-eqz p1, :cond_1b

    .line 343
    .line 344
    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    move-result-object p1

    .line 348
    check-cast p1, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeMobileInstalmentTabFragment;

    .line 349
    .line 350
    if-eqz p1, :cond_1b

    .line 351
    .line 352
    if-eqz p3, :cond_12

    .line 353
    .line 354
    invoke-virtual {p3}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLoanNo()Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object p2

    .line 358
    goto :goto_7

    .line 359
    :cond_12
    move-object p2, v2

    .line 360
    :goto_7
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/ui/fragment/OcHomeMobileInstalmentTabFragment;->x()Lcom/transsnet/palmpay/credit/viewmodel/OcHomeFinanceViewModel;

    .line 361
    .line 362
    .line 363
    move-result-object p1

    .line 364
    if-eqz p1, :cond_1b

    .line 365
    .line 366
    new-instance p3, LJb/v;

    .line 367
    .line 368
    invoke-direct {p3, p2, v2}, LJb/v;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 369
    .line 370
    .line 371
    iget-object p2, p1, Lcom/transsnet/palmpay/credit/viewmodel/OcHomeFinanceViewModel;->t:Lcom/transsnet/palmpay/core/base/l;

    .line 372
    .line 373
    invoke-static {p1, p3, p2, v0, v1}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 374
    .line 375
    .line 376
    goto/16 :goto_c

    .line 377
    .line 378
    :cond_13
    sget p3, LYa/e;->llTotalOutstanding:I

    .line 379
    .line 380
    if-ne p2, p3, :cond_1b

    .line 381
    .line 382
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getMobileInstallmentCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;

    .line 383
    .line 384
    .line 385
    move-result-object p1

    .line 386
    if-eqz p1, :cond_1b

    .line 387
    .line 388
    new-instance p2, Landroid/os/Bundle;

    .line 389
    .line 390
    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    .line 391
    .line 392
    .line 393
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentCardData;->getLoanNo()Ljava/lang/String;

    .line 394
    .line 395
    .line 396
    move-result-object p1

    .line 397
    if-nez p1, :cond_14

    .line 398
    .line 399
    goto :goto_8

    .line 400
    :cond_14
    move-object v6, p1

    .line 401
    :goto_8
    invoke-virtual {p2, v5, v6}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 402
    .line 403
    .line 404
    const-string p1, "loanProduct"

    .line 405
    .line 406
    const-string p3, "HIRE_PURCHASE"

    .line 407
    .line 408
    invoke-virtual {p2, p1, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 409
    .line 410
    .line 411
    const-string p1, "MobileInstallmentOverview"

    .line 412
    .line 413
    invoke-static {p2, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 414
    .line 415
    .line 416
    goto :goto_c

    .line 417
    :cond_15
    :goto_9
    iget-object p1, v3, LGb/y;->e:Lcom/transsnet/palmpay/credit/viewmodel/OcHomeFinanceViewModel;

    .line 418
    .line 419
    if-eqz p1, :cond_1b

    .line 420
    .line 421
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/viewmodel/OcHomeFinanceViewModel;->d()V

    .line 422
    .line 423
    .line 424
    goto :goto_c

    .line 425
    :cond_16
    :goto_a
    if-nez p3, :cond_17

    .line 426
    .line 427
    goto :goto_b

    .line 428
    :cond_17
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 429
    .line 430
    .line 431
    move-result v4

    .line 432
    const/4 v5, 0x3

    .line 433
    if-ne v4, v5, :cond_19

    .line 434
    .line 435
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getHirePurchaseDownPayCardData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;

    .line 436
    .line 437
    .line 438
    move-result-object p1

    .line 439
    invoke-virtual {p2}, Landroid/view/View;->getId()I

    .line 440
    .line 441
    .line 442
    move-result p2

    .line 443
    sget p3, LYa/e;->btnConfirmPay:I

    .line 444
    .line 445
    if-ne p2, p3, :cond_1b

    .line 446
    .line 447
    if-eqz p1, :cond_1b

    .line 448
    .line 449
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getRepaymentStatus()Ljava/lang/Integer;

    .line 450
    .line 451
    .line 452
    move-result-object p2

    .line 453
    if-nez p2, :cond_18

    .line 454
    .line 455
    goto :goto_c

    .line 456
    :cond_18
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 457
    .line 458
    .line 459
    move-result p2

    .line 460
    const/4 p3, 0x6

    .line 461
    if-ne p2, p3, :cond_1b

    .line 462
    .line 463
    iget-object p2, v3, LGb/y;->e:Lcom/transsnet/palmpay/credit/viewmodel/OcHomeFinanceViewModel;

    .line 464
    .line 465
    if-eqz p2, :cond_1b

    .line 466
    .line 467
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/MobileInstallmentFirstPayCardData;->getOrderNo()Ljava/lang/String;

    .line 468
    .line 469
    .line 470
    move-result-object p1

    .line 471
    new-instance p3, LJb/o;

    .line 472
    .line 473
    invoke-direct {p3, p1, v2}, LJb/o;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 474
    .line 475
    .line 476
    iget-object p1, p2, Lcom/transsnet/palmpay/credit/viewmodel/OcHomeFinanceViewModel;->i:Lcom/transsnet/palmpay/core/base/l;

    .line 477
    .line 478
    invoke-static {p2, p3, p1, v0, v1}, Lj8/f;->u(Lcom/transsnet/palmpay/core/base/BaseViewModel;Lkotlin/jvm/functions/Function1;Lcom/transsnet/palmpay/core/base/l;ZI)LWf/t0;

    .line 479
    .line 480
    .line 481
    goto :goto_c

    .line 482
    :cond_19
    :goto_b
    if-nez p3, :cond_1a

    .line 483
    .line 484
    goto :goto_c

    .line 485
    :cond_1a
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 486
    .line 487
    .line 488
    move-result p2

    .line 489
    const/4 p3, 0x5

    .line 490
    if-ne p2, p3, :cond_1b

    .line 491
    .line 492
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/CLPhoneInstallmentMainData;->getProductInfoChangeData()Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;

    .line 493
    .line 494
    .line 495
    move-result-object p1

    .line 496
    if-eqz p1, :cond_1b

    .line 497
    .line 498
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getJumpPath()Ljava/lang/String;

    .line 499
    .line 500
    .line 501
    move-result-object p2

    .line 502
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getJumpType()Ljava/lang/String;

    .line 503
    .line 504
    .line 505
    move-result-object p3

    .line 506
    invoke-virtual {p1}, Lcom/transsnet/palmpay/credit/bean/resp/mobile_Installment/ProductInfoChangeData;->getJumpParams()Ljava/lang/String;

    .line 507
    .line 508
    .line 509
    move-result-object p1

    .line 510
    invoke-static {p2, p3, p1}, LPa/F;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 511
    .line 512
    .line 513
    :cond_1b
    :goto_c
    return-void

    .line 514
    nop

    .line 515
    :pswitch_data_0
    .packed-switch 0xd
        :pswitch_0
    .end packed-switch
.end method

.method public onItemClick(LM1/j;Landroid/view/View;I)V
    .locals 4

    .line 1
    iget v0, p0, LDg/a;->a:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "adapter"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "<unused var>"

    .line 12
    .line 13
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    const-string p2, "null cannot be cast to non-null type com.transsnet.palmpay.main.export.bean.rsp.QueryTargetSavingsModul"

    .line 21
    .line 22
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    check-cast p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryTargetSavingsModul;

    .line 26
    .line 27
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 28
    .line 29
    .line 30
    move-result-object p2

    .line 31
    new-instance p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 32
    .line 33
    const-string v0, "FinanceTab_TargetSavings_Target_Click"

    .line 34
    .line 35
    invoke-direct {p3, v0}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    const-string v0, "element_name"

    .line 39
    .line 40
    iget-object v1, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryTargetSavingsModul;->publicTsId:Ljava/lang/String;

    .line 41
    .line 42
    invoke-virtual {p3, v0, v1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 43
    .line 44
    .line 45
    move-result-object p3

    .line 46
    check-cast p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 47
    .line 48
    invoke-virtual {p2, p3}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 49
    .line 50
    .line 51
    iget-object p2, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryTargetSavingsModul;->androidUrl:Ljava/lang/String;

    .line 52
    .line 53
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 54
    .line 55
    .line 56
    move-result p2

    .line 57
    if-nez p2, :cond_1

    .line 58
    .line 59
    iget-object p2, p0, LDg/a;->b:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast p2, LIe/w;

    .line 62
    .line 63
    iget-object p2, p2, LIe/w;->a:Landroid/view/View;

    .line 64
    .line 65
    if-eqz p2, :cond_0

    .line 66
    .line 67
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 68
    .line 69
    .line 70
    move-result-object p2

    .line 71
    goto :goto_0

    .line 72
    :cond_0
    const/4 p2, 0x0

    .line 73
    :goto_0
    iget-object p1, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryTargetSavingsModul;->androidUrl:Ljava/lang/String;

    .line 74
    .line 75
    invoke-static {p2, p1}, LPa/F;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    if-eqz p1, :cond_2

    .line 80
    .line 81
    invoke-static {p1}, Lcom/transsnet/palmpay/util/ActivityUtils;->startActivity(Landroid/content/Intent;)V

    .line 82
    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_1
    new-instance p2, Landroid/os/Bundle;

    .line 86
    .line 87
    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    .line 88
    .line 89
    .line 90
    const-string p3, "tsId"

    .line 91
    .line 92
    iget-object v0, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryTargetSavingsModul;->tsId:Ljava/lang/String;

    .line 93
    .line 94
    invoke-virtual {p2, p3, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    const-string p3, "publicTsId"

    .line 98
    .line 99
    iget-object v0, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryTargetSavingsModul;->publicTsId:Ljava/lang/String;

    .line 100
    .line 101
    invoke-virtual {p2, p3, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    iget-object p1, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryTargetSavingsModul;->isJoined:Ljava/lang/Boolean;

    .line 105
    .line 106
    sget-object p3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 107
    .line 108
    invoke-static {p1, p3}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result p1

    .line 112
    const-string p3, "isJoined"

    .line 113
    .line 114
    invoke-virtual {p2, p3, p1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 115
    .line 116
    .line 117
    const-string p1, "PublicSavingTargetDetail"

    .line 118
    .line 119
    invoke-static {p2, p1}, Lcom/palmpay/lib/apm/launchcounter/util/d;->x(Landroid/os/Bundle;Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    :cond_2
    :goto_1
    return-void

    .line 123
    :sswitch_0
    const-string v0, "adapter"

    .line 124
    .line 125
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    const-string v0, "<unused var>"

    .line 129
    .line 130
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1, p3}, LM1/j;->getItem(I)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    const-string p2, "null cannot be cast to non-null type com.transsnet.palmpay.main.export.bean.rsp.QueryHotStockModuleResp"

    .line 138
    .line 139
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    check-cast p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryHotStockModuleResp;

    .line 143
    .line 144
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 145
    .line 146
    .line 147
    move-result-object p2

    .line 148
    new-instance p3, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 149
    .line 150
    const-string v0, "FinanceTab_USStock_Company_Click"

    .line 151
    .line 152
    invoke-direct {p3, v0}, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;-><init>(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    const-string v0, "stockName"

    .line 156
    .line 157
    iget-object p1, p1, Lcom/transsnet/palmpay/main/export/bean/rsp/QueryHotStockModuleResp;->stockName:Ljava/lang/String;

    .line 158
    .line 159
    invoke-virtual {p3, v0, p1}, Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;->add(Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    check-cast p1, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 164
    .line 165
    invoke-virtual {p2, p1}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 166
    .line 167
    .line 168
    iget-object p1, p0, LDg/a;->b:Ljava/lang/Object;

    .line 169
    .line 170
    check-cast p1, LIe/v;

    .line 171
    .line 172
    iget-object p1, p1, LIe/v;->d:Ljava/lang/String;

    .line 173
    .line 174
    if-eqz p1, :cond_3

    .line 175
    .line 176
    invoke-static {p1}, LPa/i0;->b0(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    :cond_3
    return-void

    .line 180
    :sswitch_1
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 181
    .line 182
    check-cast v0, Lcom/transsnet/palmpay/ui/view/ModelPalmPrizeBanner;

    .line 183
    .line 184
    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/ui/view/ModelPalmPrizeBanner;->c(Lcom/transsnet/palmpay/ui/view/ModelPalmPrizeBanner;LM1/j;Landroid/view/View;I)V

    .line 185
    .line 186
    .line 187
    return-void

    .line 188
    :sswitch_2
    const-string v0, "<unused var>"

    .line 189
    .line 190
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    iget-object p1, p0, LDg/a;->b:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast p1, Lda/b0;

    .line 199
    .line 200
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 201
    .line 202
    .line 203
    move-result-object p2

    .line 204
    check-cast p2, Ljava/util/Collection;

    .line 205
    .line 206
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 207
    .line 208
    .line 209
    move-result p2

    .line 210
    const/4 v0, 0x0

    .line 211
    move v1, v0

    .line 212
    :goto_2
    if-ge v1, p2, :cond_5

    .line 213
    .line 214
    invoke-virtual {p1}, LM1/j;->getData()Ljava/util/List;

    .line 215
    .line 216
    .line 217
    move-result-object v2

    .line 218
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v2

    .line 222
    check-cast v2, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;

    .line 223
    .line 224
    if-ne v1, p3, :cond_4

    .line 225
    .line 226
    const/4 v3, 0x1

    .line 227
    goto :goto_3

    .line 228
    :cond_4
    move v3, v0

    .line 229
    :goto_3
    invoke-virtual {v2, v3}, Lcom/transsnet/palmpay/core/bean/rsp/TransactionFilterResp$FilterBean;->setSelected(Z)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$Adapter;->notifyDataSetChanged()V

    .line 233
    .line 234
    .line 235
    add-int/lit8 v1, v1, 0x1

    .line 236
    .line 237
    goto :goto_2

    .line 238
    :cond_5
    return-void

    .line 239
    :sswitch_3
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 240
    .line 241
    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/view/TransferDetailQuestionView;

    .line 242
    .line 243
    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/send_money/ui/view/TransferDetailQuestionView;->a(Lcom/transsnet/palmpay/send_money/ui/view/TransferDetailQuestionView;LM1/j;Landroid/view/View;I)V

    .line 244
    .line 245
    .line 246
    return-void

    .line 247
    :sswitch_4
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 248
    .line 249
    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/view/SearchRecipientAccountToBankView;

    .line 250
    .line 251
    invoke-static {v0, p1, p2, p3}, Lcom/transsnet/palmpay/send_money/ui/view/SearchRecipientAccountToBankView;->a(Lcom/transsnet/palmpay/send_money/ui/view/SearchRecipientAccountToBankView;LM1/j;Landroid/view/View;I)V

    .line 252
    .line 253
    .line 254
    return-void

    .line 255
    :sswitch_5
    const-string v0, "<unused var>"

    .line 256
    .line 257
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    iget-object p1, p0, LDg/a;->b:Ljava/lang/Object;

    .line 264
    .line 265
    check-cast p1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomeFavoriteFragment;

    .line 266
    .line 267
    invoke-virtual {p1}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/TransferToBankHomeFavoriteFragment;->t()Lld/x;

    .line 268
    .line 269
    .line 270
    move-result-object p2

    .line 271
    invoke-virtual {p2}, LM1/j;->getData()Ljava/util/List;

    .line 272
    .line 273
    .line 274
    move-result-object p2

    .line 275
    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    move-result-object p2

    .line 279
    check-cast p2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 280
    .line 281
    if-eqz p2, :cond_7

    .line 282
    .line 283
    invoke-static {}, LPa/n0;->g()LPa/n0;

    .line 284
    .line 285
    .line 286
    move-result-object p3

    .line 287
    const-string v0, "Transfer_ToBank_ContactZone_Click"

    .line 288
    .line 289
    const-string v1, "element_name"

    .line 290
    .line 291
    const-string v2, "Favorites"

    .line 292
    .line 293
    invoke-static {v0, v1, v2}, LC0/G;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/transsnet/palmpay/core/util/statistic/BaseTrackEvent;

    .line 294
    .line 295
    .line 296
    move-result-object v0

    .line 297
    check-cast v0, Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;

    .line 298
    .line 299
    invoke-virtual {p3, v0}, LPa/n0;->k(Lcom/transsnet/palmpay/core/util/statistic/ClickEvent;)V

    .line 300
    .line 301
    .line 302
    iget p3, p2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->tagType:I

    .line 303
    .line 304
    const/4 v0, 0x2

    .line 305
    if-ne p3, v0, :cond_6

    .line 306
    .line 307
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 308
    .line 309
    check-cast p1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 310
    .line 311
    if-eqz p1, :cond_7

    .line 312
    .line 313
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->d(Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;)V

    .line 314
    .line 315
    .line 316
    goto :goto_4

    .line 317
    :cond_6
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 318
    .line 319
    check-cast p1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 320
    .line 321
    if-eqz p1, :cond_7

    .line 322
    .line 323
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->f(Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;)V

    .line 324
    .line 325
    .line 326
    :cond_7
    :goto_4
    return-void

    .line 327
    :sswitch_6
    const-string v0, "<unused var>"

    .line 328
    .line 329
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    iget-object p1, p0, LDg/a;->b:Ljava/lang/Object;

    .line 336
    .line 337
    check-cast p1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;

    .line 338
    .line 339
    invoke-virtual {p1}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;->t()Lld/x;

    .line 340
    .line 341
    .line 342
    move-result-object p2

    .line 343
    invoke-virtual {p2}, LM1/j;->getData()Ljava/util/List;

    .line 344
    .line 345
    .line 346
    move-result-object p2

    .line 347
    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 348
    .line 349
    .line 350
    move-result-object p2

    .line 351
    check-cast p2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 352
    .line 353
    iget-boolean p3, p1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountFavoriteFragment;->o:Z

    .line 354
    .line 355
    const/4 v0, 0x2

    .line 356
    if-eqz p3, :cond_a

    .line 357
    .line 358
    new-instance p3, Landroid/content/Intent;

    .line 359
    .line 360
    invoke-direct {p3}, Landroid/content/Intent;-><init>()V

    .line 361
    .line 362
    .line 363
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientAccountNumber()Ljava/lang/String;

    .line 364
    .line 365
    .line 366
    move-result-object v1

    .line 367
    const-string v2, "BANK_ACCOUNT_NUMBER"

    .line 368
    .line 369
    invoke-virtual {p3, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 370
    .line 371
    .line 372
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientPhone()Ljava/lang/String;

    .line 373
    .line 374
    .line 375
    move-result-object v1

    .line 376
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 377
    .line 378
    .line 379
    move-result v1

    .line 380
    if-nez v1, :cond_8

    .line 381
    .line 382
    const-string v1, "PHONE_NUMBER"

    .line 383
    .line 384
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientPhone()Ljava/lang/String;

    .line 385
    .line 386
    .line 387
    move-result-object v2

    .line 388
    invoke-virtual {p3, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 389
    .line 390
    .line 391
    :cond_8
    new-instance v1, Lcom/transsnet/palmpay/core/bean/BankInfo;

    .line 392
    .line 393
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/BankInfo;-><init>()V

    .line 394
    .line 395
    .line 396
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientBankCode()Ljava/lang/String;

    .line 397
    .line 398
    .line 399
    move-result-object v2

    .line 400
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankCode:Ljava/lang/String;

    .line 401
    .line 402
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientAccountNumber()Ljava/lang/String;

    .line 403
    .line 404
    .line 405
    move-result-object v2

    .line 406
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankCardNo:Ljava/lang/String;

    .line 407
    .line 408
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientHeadImage()Ljava/lang/String;

    .line 409
    .line 410
    .line 411
    move-result-object v2

    .line 412
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankUrl:Ljava/lang/String;

    .line 413
    .line 414
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientBankName()Ljava/lang/String;

    .line 415
    .line 416
    .line 417
    move-result-object v2

    .line 418
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankName:Ljava/lang/String;

    .line 419
    .line 420
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientType()I

    .line 421
    .line 422
    .line 423
    move-result v2

    .line 424
    if-ne v2, v0, :cond_9

    .line 425
    .line 426
    const/4 v0, 0x0

    .line 427
    goto :goto_5

    .line 428
    :cond_9
    const/4 v0, 0x1

    .line 429
    :goto_5
    iput v0, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->mmo:I

    .line 430
    .line 431
    const-string v0, "BANK_CARD_INFO"

    .line 432
    .line 433
    invoke-virtual {p3, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 434
    .line 435
    .line 436
    const-string v0, "trans_amount"

    .line 437
    .line 438
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getAmount()J

    .line 439
    .line 440
    .line 441
    move-result-wide v1

    .line 442
    invoke-virtual {p3, v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 443
    .line 444
    .line 445
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 446
    .line 447
    .line 448
    move-result-object p1

    .line 449
    if-eqz p1, :cond_c

    .line 450
    .line 451
    const/4 p2, -0x1

    .line 452
    invoke-virtual {p1, p2, p3}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 453
    .line 454
    .line 455
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 456
    .line 457
    .line 458
    goto :goto_6

    .line 459
    :cond_a
    iget p3, p2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->tagType:I

    .line 460
    .line 461
    if-ne p3, v0, :cond_b

    .line 462
    .line 463
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 464
    .line 465
    check-cast p1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 466
    .line 467
    if-eqz p1, :cond_c

    .line 468
    .line 469
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->d(Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;)V

    .line 470
    .line 471
    .line 472
    goto :goto_6

    .line 473
    :cond_b
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 474
    .line 475
    check-cast p1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 476
    .line 477
    if-eqz p1, :cond_c

    .line 478
    .line 479
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->f(Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;)V

    .line 480
    .line 481
    .line 482
    :cond_c
    :goto_6
    return-void

    .line 483
    :sswitch_7
    const-string v0, "<unused var>"

    .line 484
    .line 485
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 486
    .line 487
    .line 488
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 489
    .line 490
    .line 491
    iget-object p1, p0, LDg/a;->b:Ljava/lang/Object;

    .line 492
    .line 493
    check-cast p1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;

    .line 494
    .line 495
    const-string p2, "History Bank"

    .line 496
    .line 497
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;->t(Ljava/lang/String;)V

    .line 498
    .line 499
    .line 500
    invoke-virtual {p1}, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;->u()Lld/x;

    .line 501
    .line 502
    .line 503
    move-result-object p2

    .line 504
    invoke-virtual {p2}, LM1/j;->getData()Ljava/util/List;

    .line 505
    .line 506
    .line 507
    move-result-object p2

    .line 508
    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 509
    .line 510
    .line 511
    move-result-object p2

    .line 512
    check-cast p2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;

    .line 513
    .line 514
    iget-boolean p3, p1, Lcom/transsnet/palmpay/send_money/ui/fragment/to_bank/BankAccountBeneficiaryFragment;->w:Z

    .line 515
    .line 516
    const/4 v0, 0x2

    .line 517
    if-eqz p3, :cond_f

    .line 518
    .line 519
    new-instance p3, Landroid/content/Intent;

    .line 520
    .line 521
    invoke-direct {p3}, Landroid/content/Intent;-><init>()V

    .line 522
    .line 523
    .line 524
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientAccountNumber()Ljava/lang/String;

    .line 525
    .line 526
    .line 527
    move-result-object v1

    .line 528
    const-string v2, "BANK_ACCOUNT_NUMBER"

    .line 529
    .line 530
    invoke-virtual {p3, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 531
    .line 532
    .line 533
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientPhone()Ljava/lang/String;

    .line 534
    .line 535
    .line 536
    move-result-object v1

    .line 537
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 538
    .line 539
    .line 540
    move-result v1

    .line 541
    if-nez v1, :cond_d

    .line 542
    .line 543
    const-string v1, "PHONE_NUMBER"

    .line 544
    .line 545
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientPhone()Ljava/lang/String;

    .line 546
    .line 547
    .line 548
    move-result-object v2

    .line 549
    invoke-virtual {p3, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 550
    .line 551
    .line 552
    :cond_d
    new-instance v1, Lcom/transsnet/palmpay/core/bean/BankInfo;

    .line 553
    .line 554
    invoke-direct {v1}, Lcom/transsnet/palmpay/core/bean/BankInfo;-><init>()V

    .line 555
    .line 556
    .line 557
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientBankCode()Ljava/lang/String;

    .line 558
    .line 559
    .line 560
    move-result-object v2

    .line 561
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankCode:Ljava/lang/String;

    .line 562
    .line 563
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientAccountNumber()Ljava/lang/String;

    .line 564
    .line 565
    .line 566
    move-result-object v2

    .line 567
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankCardNo:Ljava/lang/String;

    .line 568
    .line 569
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientHeadImage()Ljava/lang/String;

    .line 570
    .line 571
    .line 572
    move-result-object v2

    .line 573
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankUrl:Ljava/lang/String;

    .line 574
    .line 575
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientBankName()Ljava/lang/String;

    .line 576
    .line 577
    .line 578
    move-result-object v2

    .line 579
    iput-object v2, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->bankName:Ljava/lang/String;

    .line 580
    .line 581
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getRecipientType()I

    .line 582
    .line 583
    .line 584
    move-result v2

    .line 585
    if-ne v2, v0, :cond_e

    .line 586
    .line 587
    const/4 v0, 0x0

    .line 588
    goto :goto_7

    .line 589
    :cond_e
    const/4 v0, 0x1

    .line 590
    :goto_7
    iput v0, v1, Lcom/transsnet/palmpay/core/bean/BankInfo;->mmo:I

    .line 591
    .line 592
    const-string v0, "BANK_CARD_INFO"

    .line 593
    .line 594
    invoke-virtual {p3, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 595
    .line 596
    .line 597
    const-string v0, "trans_amount"

    .line 598
    .line 599
    invoke-virtual {p2}, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->getAmount()J

    .line 600
    .line 601
    .line 602
    move-result-wide v1

    .line 603
    invoke-virtual {p3, v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 604
    .line 605
    .line 606
    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/E;

    .line 607
    .line 608
    .line 609
    move-result-object p1

    .line 610
    if-eqz p1, :cond_11

    .line 611
    .line 612
    const/4 p2, -0x1

    .line 613
    invoke-virtual {p1, p2, p3}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 614
    .line 615
    .line 616
    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    .line 617
    .line 618
    .line 619
    goto :goto_8

    .line 620
    :cond_f
    iget p3, p2, Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;->tagType:I

    .line 621
    .line 622
    if-ne p3, v0, :cond_10

    .line 623
    .line 624
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 625
    .line 626
    check-cast p1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 627
    .line 628
    if-eqz p1, :cond_11

    .line 629
    .line 630
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->d(Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;)V

    .line 631
    .line 632
    .line 633
    goto :goto_8

    .line 634
    :cond_10
    iget-object p1, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmFragment;->i:Lcom/transsnet/palmpay/core/base/BaseViewModel;

    .line 635
    .line 636
    check-cast p1, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;

    .line 637
    .line 638
    if-eqz p1, :cond_11

    .line 639
    .line 640
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/send_money/viewmodel/TransferToBankHomeViewModel;->f(Lcom/transsnet/palmpay/send_money/bean/RecipientListResp$RecipientBean;)V

    .line 641
    .line 642
    .line 643
    :cond_11
    :goto_8
    return-void

    .line 644
    nop

    .line 645
    :sswitch_data_0
    .sparse-switch
        0x5 -> :sswitch_7
        0x7 -> :sswitch_6
        0x8 -> :sswitch_5
        0xf -> :sswitch_4
        0x10 -> :sswitch_3
        0x11 -> :sswitch_2
        0x12 -> :sswitch_1
        0x14 -> :sswitch_0
    .end sparse-switch
.end method

.method public onPinEntered(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/core/ui/fragment/verify/CheckPalmPayPinFragment;

    .line 4
    .line 5
    sget v1, Lcom/transsnet/palmpay/core/ui/fragment/verify/CheckPalmPayPinFragment;->L:I

    .line 6
    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v2, 0x4

    .line 14
    if-ne v1, v2, :cond_0

    .line 15
    .line 16
    :try_start_0
    invoke-virtual {v0}, Lcom/transsnet/palmpay/core/ui/fragment/verify/BaseVerifyFragment;->u()Lcom/transsnet/palmpay/core/callback/PayVerificationCallback;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    invoke-static {p1}, Lcom/transsnet/palmpay/security/utils/SecurityUtils;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    const/4 v2, 0x7

    .line 27
    invoke-interface {v1, p1, v2}, Lcom/transsnet/palmpay/core/callback/PayVerificationCallback;->verifyPayMethod(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :catch_0
    move-exception p1

    .line 32
    const-string v1, "onPinEntered: "

    .line 33
    .line 34
    filled-new-array {v1, p1}, [Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    iget-object v0, v0, Lcom/transsnet/palmpay/core/base/BaseFragment;->a:Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {v0, p1}, LF6/d;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    return-void
.end method

.method public onSelected(Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;)V
    .locals 1

    .line 1
    iget-object v0, p0, LDg/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment;

    .line 4
    .line 5
    iget-object v0, v0, Lcom/transsnet/palmpay/send_money/ui/fragment/to_palmpay/TransferToPalmPayAddMobileAccountFragment;->H:LRd/k0;

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    iget-object v0, v0, LRd/k0;->i:Landroid/view/View;

    .line 10
    .line 11
    check-cast v0, Landroid/widget/EditText;

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    if-eqz p1, :cond_0

    .line 16
    .line 17
    invoke-virtual {p1}, Lcom/transsnet/palmpay/send_money/bean/AddFromContactListResp;->getRecipientPhone()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    invoke-static {p1}, LPa/r0;->w(Ljava/lang/String;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    const/4 p1, 0x0

    .line 29
    :goto_0
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 30
    .line 31
    .line 32
    :cond_1
    return-void
.end method

.method public subscribe(Lio/reactivex/ObservableEmitter;)V
    .locals 3

    .line 1
    new-instance v0, Ljava/io/File;

    .line 2
    .line 3
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->get()Lcom/transsnet/palmpay/core/base/BaseApplication;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget-object v2, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v1, v2}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const-string v2, "share"

    .line 14
    .line 15
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-nez v1, :cond_0

    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 25
    .line 26
    .line 27
    :cond_0
    iget-object v1, p0, LDg/a;->b:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v1, Landroid/graphics/Bitmap;

    .line 30
    .line 31
    invoke-static {v1, v0}, LJ3/a;->O(Landroid/graphics/Bitmap;Ljava/io/File;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-static {}, Lcom/transsnet/palmpay/core/base/BaseApplication;->getContext()Landroid/content/Context;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-static {v1, v0}, LPa/r0;->N1(Landroid/content/Context;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-interface {p1, v0}, Lio/reactivex/Emitter;->onNext(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    invoke-interface {p1}, Lio/reactivex/Emitter;->onComplete()V

    .line 46
    .line 47
    .line 48
    return-void
.end method
