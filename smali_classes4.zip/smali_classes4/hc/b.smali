.class public final Lhc/b;
.super LFf/h;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic a:Lcom/transsnet/palmpay/core/bean/CommonResult;

.field public final synthetic b:Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lhc/b;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 2
    .line 3
    iput-object p3, p0, Lhc/b;->b:Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, LFf/h;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 1
    new-instance p1, Lhc/b;

    .line 2
    .line 3
    iget-object v0, p0, Lhc/b;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 4
    .line 5
    iget-object v1, p0, Lhc/b;->b:Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;

    .line 6
    .line 7
    invoke-direct {p1, v0, p2, v1}, Lhc/b;-><init>(Lcom/transsnet/palmpay/core/bean/CommonResult;Lkotlin/coroutines/Continuation;Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 2
    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lhc/b;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lhc/b;

    .line 10
    .line 11
    sget-object p2, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lhc/b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    sget-object v0, LEf/a;->a:LEf/a;

    .line 2
    .line 3
    invoke-static {p1}, Landroidx/camera/core/impl/utils/executor/g;->M(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lhc/b;->a:Lcom/transsnet/palmpay/core/bean/CommonResult;

    .line 7
    .line 8
    check-cast p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;

    .line 9
    .line 10
    iget-object v0, p0, Lhc/b;->b:Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    if-eqz p1, :cond_a

    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/transsnet/palmpay/core/bean/CommonResult;->isSuccess()Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    const/4 v3, 0x1

    .line 20
    if-ne v2, v3, :cond_a

    .line 21
    .line 22
    iget-object p1, p1, Lcom/transsnet/palmpay/core/bean/CommonBeanResult;->data:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast p1, Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendBean;

    .line 25
    .line 26
    if-eqz p1, :cond_0

    .line 27
    .line 28
    iget-object p1, p1, Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendBean;->items:Ljava/util/List;

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move-object p1, v1

    .line 32
    :goto_0
    if-nez p1, :cond_1

    .line 33
    .line 34
    sget-object p1, Lkotlin/collections/z;->a:Lkotlin/collections/z;

    .line 35
    .line 36
    :cond_1
    check-cast p1, Ljava/lang/Iterable;

    .line 37
    .line 38
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    :cond_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    if-eqz v2, :cond_9

    .line 47
    .line 48
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    move-object v4, v2

    .line 53
    check-cast v4, Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendItemBean;

    .line 54
    .line 55
    iget-object v5, v0, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->v:Ljava/lang/String;

    .line 56
    .line 57
    if-eqz v5, :cond_5

    .line 58
    .line 59
    invoke-static {v5}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    if-eqz v5, :cond_3

    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_3
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendItemBean;->billerId:Ljava/lang/String;

    .line 67
    .line 68
    if-eqz v5, :cond_5

    .line 69
    .line 70
    invoke-static {v5}, Lkotlin/text/StringsKt;->F(Ljava/lang/CharSequence;)Z

    .line 71
    .line 72
    .line 73
    move-result v5

    .line 74
    if-eqz v5, :cond_4

    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_4
    iget-object v5, v0, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->v:Ljava/lang/String;

    .line 78
    .line 79
    iget-object v6, v4, Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendItemBean;->billerId:Ljava/lang/String;

    .line 80
    .line 81
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v5

    .line 85
    goto :goto_3

    .line 86
    :cond_5
    :goto_1
    iget-object v5, v4, Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendItemBean;->billerName:Ljava/lang/String;

    .line 87
    .line 88
    if-eqz v5, :cond_7

    .line 89
    .line 90
    invoke-static {v5}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 91
    .line 92
    .line 93
    move-result-object v5

    .line 94
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v5

    .line 98
    if-eqz v5, :cond_7

    .line 99
    .line 100
    iget-object v6, v0, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->w:Ljava/lang/String;

    .line 101
    .line 102
    if-eqz v6, :cond_6

    .line 103
    .line 104
    invoke-static {v6}, Lkotlin/text/StringsKt;->V(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 105
    .line 106
    .line 107
    move-result-object v6

    .line 108
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v6

    .line 112
    goto :goto_2

    .line 113
    :cond_6
    move-object v6, v1

    .line 114
    :goto_2
    invoke-virtual {v5, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 115
    .line 116
    .line 117
    move-result v5

    .line 118
    if-ne v5, v3, :cond_7

    .line 119
    .line 120
    move v5, v3

    .line 121
    goto :goto_3

    .line 122
    :cond_7
    const/4 v5, 0x0

    .line 123
    :goto_3
    if-eqz v5, :cond_2

    .line 124
    .line 125
    iget-object v4, v4, Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendItemBean;->item:Lcom/transsnet/palmpay/teller/bean/DataBundleListByCategoryIdResp$DataBundleWalletItemChildBean;

    .line 126
    .line 127
    const-wide/16 v5, 0x0

    .line 128
    .line 129
    if-eqz v4, :cond_8

    .line 130
    .line 131
    invoke-virtual {v4}, Lcom/transsnet/palmpay/teller/bean/DataBundleListByCategoryIdResp$DataBundleWalletItemChildBean;->getPrice()J

    .line 132
    .line 133
    .line 134
    move-result-wide v7

    .line 135
    goto :goto_4

    .line 136
    :cond_8
    move-wide v7, v5

    .line 137
    :goto_4
    cmp-long v4, v7, v5

    .line 138
    .line 139
    if-lez v4, :cond_2

    .line 140
    .line 141
    move-object v1, v2

    .line 142
    :cond_9
    check-cast v1, Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendItemBean;

    .line 143
    .line 144
    :cond_a
    sget p1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 145
    .line 146
    invoke-virtual {v0, v1}, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->e(Lcom/transsnet/palmpay/teller/bean/DataBundleHighlyRecommendItemBean;)V

    .line 147
    .line 148
    .line 149
    sget-object p1, Lkotlin/Unit;->a:Lkotlin/Unit;

    .line 150
    .line 151
    return-object p1
.end method
