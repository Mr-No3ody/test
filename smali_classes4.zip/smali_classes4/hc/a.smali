.class public final synthetic Lhc/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;


# direct methods
.method public synthetic constructor <init>(Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;I)V
    .locals 0

    .line 1
    iput p2, p0, Lhc/a;->a:I

    iput-object p1, p0, Lhc/a;->b:Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, Lhc/a;->b:Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;

    .line 2
    .line 3
    iget v1, p0, Lhc/a;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget v1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 9
    .line 10
    sget v1, LPd/c;->btn_recommend_buy:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Lcom/palmpay/lib/ui/button/PpButton;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    sget v1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 20
    .line 21
    sget v1, LPd/c;->iv_recommend_info:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    check-cast v0, Lcom/mikepenz/iconics/view/IconicsImageView;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    sget v1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 31
    .line 32
    sget v1, LPd/c;->tv_recommend_validity:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Landroid/widget/TextView;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_2
    sget v1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 42
    .line 43
    sget v1, LPd/c;->tv_recommend_business_price:I

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Landroid/widget/TextView;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_3
    sget v1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 53
    .line 54
    sget v1, LPd/c;->tv_recommend_price:I

    .line 55
    .line 56
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Landroid/widget/TextView;

    .line 61
    .line 62
    return-object v0

    .line 63
    :pswitch_4
    sget v1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 64
    .line 65
    sget v1, LPd/c;->tv_recommend_volume:I

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Landroid/widget/TextView;

    .line 72
    .line 73
    return-object v0

    .line 74
    :pswitch_5
    sget v1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 75
    .line 76
    sget v1, LPd/c;->tv_recommend_tag:I

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    check-cast v0, Landroid/widget/TextView;

    .line 83
    .line 84
    return-object v0

    .line 85
    :pswitch_6
    sget v1, Lcom/transsnet/palmpay/databundle/ui/view/ModelDataBundleHighlyRecommendItem;->B:I

    .line 86
    .line 87
    sget v1, LPd/c;->iv_recommend_badge:I

    .line 88
    .line 89
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    check-cast v0, Landroid/widget/ImageView;

    .line 94
    .line 95
    return-object v0

    .line 96
    nop

    .line 97
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
