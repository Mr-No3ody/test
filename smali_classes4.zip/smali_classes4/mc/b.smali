.class public final Lmc/b;
.super Landroid/webkit/WebViewClient;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/webkit/WebView;

.field public final synthetic c:Lcom/transsnet/palmpay/core/base/BaseActivity;


# direct methods
.method public constructor <init>(Lcom/transsnet/palmpay/core/viewmodel/AndroidXWebView;Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lmc/b;->a:I

    iput-object p1, p0, Lmc/b;->b:Landroid/webkit/WebView;

    iput-object p2, p0, Lmc/b;->c:Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 1
    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/transsnet/palmpay/echat/EchatActivity;Landroid/webkit/WebView;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lmc/b;->a:I

    .line 2
    iput-object p1, p0, Lmc/b;->c:Lcom/transsnet/palmpay/core/base/BaseActivity;

    iput-object p2, p0, Lmc/b;->b:Landroid/webkit/WebView;

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method


# virtual methods
.method public final onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 3

    .line 1
    iget v0, p0, Lmc/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "view"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "url"

    .line 12
    .line 13
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object p1, p0, Lmc/b;->c:Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 20
    .line 21
    check-cast p1, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;

    .line 22
    .line 23
    iget-object v0, p1, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;->i:Ljava/lang/String;

    .line 24
    .line 25
    if-eqz v0, :cond_5

    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_0

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    iget-object v0, p1, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;->i:Ljava/lang/String;

    .line 35
    .line 36
    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_1

    .line 41
    .line 42
    iget-object v0, p1, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;->i:Ljava/lang/String;

    .line 43
    .line 44
    new-instance v1, Ljava/lang/StringBuilder;

    .line 45
    .line 46
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    const-string v0, "/index"

    .line 53
    .line 54
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    invoke-static {p2, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    if-nez v1, :cond_1

    .line 66
    .line 67
    iget-object v1, p1, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;->i:Ljava/lang/String;

    .line 68
    .line 69
    new-instance v2, Ljava/lang/StringBuilder;

    .line 70
    .line 71
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    invoke-static {p2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 85
    .line 86
    .line 87
    move-result p2

    .line 88
    if-eqz p2, :cond_5

    .line 89
    .line 90
    :cond_1
    iget-object p2, p1, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;->g:LWf/t0;

    .line 91
    .line 92
    const/4 v0, 0x0

    .line 93
    if-eqz p2, :cond_2

    .line 94
    .line 95
    invoke-virtual {p2, v0}, LWf/n0;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 96
    .line 97
    .line 98
    :cond_2
    iget-object p2, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 99
    .line 100
    check-cast p2, LRd/i;

    .line 101
    .line 102
    if-eqz p2, :cond_3

    .line 103
    .line 104
    iget-object p2, p2, LRd/i;->d:Lcom/airbnb/lottie/LottieAnimationView;

    .line 105
    .line 106
    invoke-virtual {p2}, Lcom/airbnb/lottie/LottieAnimationView;->a()V

    .line 107
    .line 108
    .line 109
    :cond_3
    iget-object p2, p1, Lcom/transsnet/palmpay/core/base/BaseMvvmVBActivity;->c:Landroidx/viewbinding/ViewBinding;

    .line 110
    .line 111
    check-cast p2, LRd/i;

    .line 112
    .line 113
    if-eqz p2, :cond_4

    .line 114
    .line 115
    iget-object p2, p2, LRd/i;->b:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 116
    .line 117
    const/4 v1, 0x0

    .line 118
    invoke-static {p2, v1}, Loa/h;->s(Landroid/view/View;Z)V

    .line 119
    .line 120
    .line 121
    :cond_4
    iput-object v0, p1, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;->i:Ljava/lang/String;

    .line 122
    .line 123
    :cond_5
    :goto_0
    return-void

    .line 124
    :pswitch_0
    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    iget-object p1, p0, Lmc/b;->c:Lcom/transsnet/palmpay/core/base/BaseActivity;

    .line 128
    .line 129
    check-cast p1, Lcom/transsnet/palmpay/echat/EchatActivity;

    .line 130
    .line 131
    const/4 p2, 0x0

    .line 132
    invoke-virtual {p1, p2}, Lcom/transsnet/palmpay/core/base/BaseActivity;->showLoadingDialog(Z)V

    .line 133
    .line 134
    .line 135
    return-void

    .line 136
    nop

    .line 137
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final onRenderProcessGone(Landroid/webkit/WebView;Landroid/webkit/RenderProcessGoneDetail;)Z
    .locals 1

    .line 1
    iget v0, p0, Lmc/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "view"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string p1, "detail"

    .line 12
    .line 13
    invoke-static {p2, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 17
    .line 18
    const/16 v0, 0x1a

    .line 19
    .line 20
    if-ge p1, v0, :cond_0

    .line 21
    .line 22
    const/4 p1, 0x0

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    iget-object p1, p0, Lmc/b;->b:Landroid/webkit/WebView;

    .line 25
    .line 26
    check-cast p1, Lcom/transsnet/palmpay/core/viewmodel/AndroidXWebView;

    .line 27
    .line 28
    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onRenderProcessGone(Landroid/webkit/WebView;Landroid/webkit/RenderProcessGoneDetail;)Z

    .line 29
    .line 30
    .line 31
    const/4 p1, 0x1

    .line 32
    :goto_0
    return p1

    .line 33
    :pswitch_0
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 34
    .line 35
    const/16 v0, 0x1a

    .line 36
    .line 37
    if-ge p1, v0, :cond_1

    .line 38
    .line 39
    const/4 p1, 0x0

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    iget-object p1, p0, Lmc/b;->b:Landroid/webkit/WebView;

    .line 42
    .line 43
    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onRenderProcessGone(Landroid/webkit/WebView;Landroid/webkit/RenderProcessGoneDetail;)Z

    .line 44
    .line 45
    .line 46
    const/4 p1, 0x1

    .line 47
    :goto_1
    return p1

    .line 48
    nop

    .line 49
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final shouldOverrideUrlLoading(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z
    .locals 1

    iget v0, p0, Lmc/b;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "request"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 3
    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {p2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p2

    .line 4
    iget-object v0, p0, Lmc/b;->c:Lcom/transsnet/palmpay/core/base/BaseActivity;

    check-cast v0, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;

    invoke-virtual {v0, p1, p2}, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;->q(Landroid/webkit/WebView;Ljava/lang/String;)Z

    move-result p1

    return p1

    .line 5
    :pswitch_0
    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {p2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lmc/b;->c:Lcom/transsnet/palmpay/core/base/BaseActivity;

    check-cast v0, Lcom/transsnet/palmpay/echat/EchatActivity;

    invoke-virtual {v0, p1, p2}, Lcom/transsnet/palmpay/echat/EchatActivity;->l(Landroid/webkit/WebView;Ljava/lang/String;)Z

    const/4 p1, 0x1

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .locals 1

    iget v0, p0, Lmc/b;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v0, "view"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    iget-object v0, p0, Lmc/b;->c:Lcom/transsnet/palmpay/core/base/BaseActivity;

    check-cast v0, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;

    invoke-virtual {v0, p1, p2}, Lcom/transsnet/palmpay/betting/ui/activity/BettingQuickBetWebActivity;->q(Landroid/webkit/WebView;Ljava/lang/String;)Z

    move-result p1

    return p1

    .line 2
    :pswitch_0
    iget-object v0, p0, Lmc/b;->c:Lcom/transsnet/palmpay/core/base/BaseActivity;

    check-cast v0, Lcom/transsnet/palmpay/echat/EchatActivity;

    invoke-virtual {v0, p1, p2}, Lcom/transsnet/palmpay/echat/EchatActivity;->l(Landroid/webkit/WebView;Ljava/lang/String;)Z

    const/4 p1, 0x1

    return p1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
