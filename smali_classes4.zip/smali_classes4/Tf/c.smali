.class public final LTf/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# static fields
.field public static final b:LTf/b;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field public static final c:J

.field public static final d:J


# instance fields
.field public final a:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LTf/b;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LTf/b;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LTf/c;->b:LTf/b;

    .line 8
    .line 9
    sget v0, LTf/d;->a:I

    .line 10
    .line 11
    const-wide v0, 0x3fffffffffffffffL    # 1.9999999999999998

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1}, LE/c;->o(J)J

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    sput-wide v0, LTf/c;->c:J

    .line 21
    .line 22
    const-wide v0, -0x3fffffffffffffffL    # -2.0000000000000004

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    invoke-static {v0, v1}, LE/c;->o(J)J

    .line 28
    .line 29
    .line 30
    move-result-wide v0

    .line 31
    sput-wide v0, LTf/c;->d:J

    .line 32
    .line 33
    return-void
.end method

.method public synthetic constructor <init>(J)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, LTf/c;->a:J

    .line 5
    .line 6
    return-void
.end method

.method public static final a(JJ)J
    .locals 10

    .line 1
    const v0, 0xf4240

    .line 2
    .line 3
    .line 4
    int-to-long v0, v0

    .line 5
    div-long v2, p2, v0

    .line 6
    .line 7
    add-long v4, p0, v2

    .line 8
    .line 9
    const-wide p0, -0x431bde82d7aL

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    cmp-long p0, p0, v4

    .line 15
    .line 16
    if-gtz p0, :cond_0

    .line 17
    .line 18
    const-wide p0, 0x431bde82d7bL

    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    cmp-long p0, v4, p0

    .line 24
    .line 25
    if-gez p0, :cond_0

    .line 26
    .line 27
    mul-long/2addr v2, v0

    .line 28
    sub-long/2addr p2, v2

    .line 29
    mul-long/2addr v4, v0

    .line 30
    add-long/2addr v4, p2

    .line 31
    invoke-static {v4, v5}, LE/c;->q(J)J

    .line 32
    .line 33
    .line 34
    move-result-wide p0

    .line 35
    return-wide p0

    .line 36
    :cond_0
    const-wide v6, -0x3fffffffffffffffL    # -2.0000000000000004

    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    const-wide v8, 0x3fffffffffffffffL    # 1.9999999999999998

    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    invoke-static/range {v4 .. v9}, Lkotlin/ranges/b;->d(JJJ)J

    .line 47
    .line 48
    .line 49
    move-result-wide p0

    .line 50
    invoke-static {p0, p1}, LE/c;->o(J)J

    .line 51
    .line 52
    .line 53
    move-result-wide p0

    .line 54
    return-wide p0
.end method

.method public static final b(Ljava/lang/StringBuilder;IIILjava/lang/String;Z)V
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 2
    .line 3
    .line 4
    if-eqz p2, :cond_7

    .line 5
    .line 6
    const/16 p1, 0x2e

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    const-string p2, "<this>"

    .line 16
    .line 17
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    if-ltz p3, :cond_6

    .line 24
    .line 25
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 26
    .line 27
    .line 28
    move-result p2

    .line 29
    const/16 v0, 0x30

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    if-gt p3, p2, :cond_0

    .line 33
    .line 34
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 35
    .line 36
    .line 37
    move-result p2

    .line 38
    invoke-virtual {p1, v1, p2}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    goto :goto_1

    .line 43
    :cond_0
    new-instance p2, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    sub-int/2addr p3, v2

    .line 53
    const/4 v2, 0x1

    .line 54
    if-gt v2, p3, :cond_1

    .line 55
    .line 56
    :goto_0
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    if-eq v2, p3, :cond_1

    .line 60
    .line 61
    add-int/lit8 v2, v2, 0x1

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_1
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    move-object p1, p2

    .line 68
    :goto_1
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 73
    .line 74
    .line 75
    move-result p2

    .line 76
    const/4 p3, -0x1

    .line 77
    add-int/2addr p2, p3

    .line 78
    if-ltz p2, :cond_4

    .line 79
    .line 80
    :goto_2
    add-int/lit8 v2, p2, -0x1

    .line 81
    .line 82
    invoke-virtual {p1, p2}, Ljava/lang/String;->charAt(I)C

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    if-eq v3, v0, :cond_2

    .line 87
    .line 88
    move p3, p2

    .line 89
    goto :goto_3

    .line 90
    :cond_2
    if-gez v2, :cond_3

    .line 91
    .line 92
    goto :goto_3

    .line 93
    :cond_3
    move p2, v2

    .line 94
    goto :goto_2

    .line 95
    :cond_4
    :goto_3
    add-int/lit8 p2, p3, 0x1

    .line 96
    .line 97
    const-string v0, "append(...)"

    .line 98
    .line 99
    const/4 v2, 0x3

    .line 100
    if-nez p5, :cond_5

    .line 101
    .line 102
    if-ge p2, v2, :cond_5

    .line 103
    .line 104
    invoke-virtual {p0, p1, v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 105
    .line 106
    .line 107
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    goto :goto_4

    .line 111
    :cond_5
    add-int/2addr p3, v2

    .line 112
    div-int/2addr p3, v2

    .line 113
    mul-int/2addr p3, v2

    .line 114
    invoke-virtual {p0, p1, v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    goto :goto_4

    .line 121
    :cond_6
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 122
    .line 123
    const-string p1, "Desired length "

    .line 124
    .line 125
    const-string p2, " is less than zero."

    .line 126
    .line 127
    invoke-static {p3, p1, p2}, Landroidx/camera/camera2/internal/F;->c(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    throw p0

    .line 135
    :cond_7
    :goto_4
    invoke-virtual {p0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    return-void
.end method

.method public static c(JJ)I
    .locals 4

    .line 1
    xor-long v0, p0, p2

    .line 2
    .line 3
    const-wide/16 v2, 0x0

    .line 4
    .line 5
    cmp-long v2, v0, v2

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    if-ltz v2, :cond_2

    .line 9
    .line 10
    long-to-int v0, v0

    .line 11
    and-int/2addr v0, v3

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    long-to-int v0, p0

    .line 16
    and-int/2addr v0, v3

    .line 17
    long-to-int p2, p2

    .line 18
    and-int/2addr p2, v3

    .line 19
    sub-int/2addr v0, p2

    .line 20
    invoke-static {p0, p1}, LTf/c;->f(J)Z

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    if-eqz p0, :cond_1

    .line 25
    .line 26
    neg-int p0, v0

    .line 27
    return p0

    .line 28
    :cond_1
    return v0

    .line 29
    :cond_2
    :goto_0
    cmp-long p0, p0, p2

    .line 30
    .line 31
    if-gez p0, :cond_3

    .line 32
    .line 33
    const/4 p0, -0x1

    .line 34
    return p0

    .line 35
    :cond_3
    if-nez p0, :cond_4

    .line 36
    .line 37
    const/4 p0, 0x0

    .line 38
    return p0

    .line 39
    :cond_4
    return v3
.end method

.method public static final d(J)I
    .locals 3

    .line 1
    invoke-static {p0, p1}, LTf/c;->e(J)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    return v1

    .line 9
    :cond_0
    long-to-int v0, p0

    .line 10
    const/4 v2, 0x1

    .line 11
    and-int/2addr v0, v2

    .line 12
    if-ne v0, v2, :cond_1

    .line 13
    .line 14
    move v1, v2

    .line 15
    :cond_1
    if-eqz v1, :cond_2

    .line 16
    .line 17
    shr-long/2addr p0, v2

    .line 18
    const/16 v0, 0x3e8

    .line 19
    .line 20
    int-to-long v0, v0

    .line 21
    rem-long/2addr p0, v0

    .line 22
    const v0, 0xf4240

    .line 23
    .line 24
    .line 25
    int-to-long v0, v0

    .line 26
    mul-long/2addr p0, v0

    .line 27
    long-to-int p0, p0

    .line 28
    return p0

    .line 29
    :cond_2
    shr-long/2addr p0, v2

    .line 30
    const v0, 0x3b9aca00

    .line 31
    .line 32
    .line 33
    int-to-long v0, v0

    .line 34
    rem-long/2addr p0, v0

    .line 35
    long-to-int p0, p0

    .line 36
    return p0
.end method

.method public static final e(J)Z
    .locals 2

    .line 1
    sget-wide v0, LTf/c;->c:J

    .line 2
    .line 3
    cmp-long v0, p0, v0

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    sget-wide v0, LTf/c;->d:J

    .line 8
    .line 9
    cmp-long p0, p0, v0

    .line 10
    .line 11
    if-nez p0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 p0, 0x0

    .line 15
    return p0

    .line 16
    :cond_1
    :goto_0
    const/4 p0, 0x1

    .line 17
    return p0
.end method

.method public static final f(J)Z
    .locals 2

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long p0, p0, v0

    .line 4
    .line 5
    if-gez p0, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_0
    const/4 p0, 0x0

    .line 10
    return p0
.end method

.method public static final g(JJ)J
    .locals 3

    .line 1
    invoke-static {p0, p1}, LTf/c;->e(J)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    invoke-static {p2, p3}, LTf/c;->e(J)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    xor-long/2addr p2, p0

    .line 14
    const-wide/16 v0, 0x0

    .line 15
    .line 16
    cmp-long p2, p2, v0

    .line 17
    .line 18
    if-ltz p2, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 22
    .line 23
    const-string p1, "Summing infinite durations of different signs yields an undefined result."

    .line 24
    .line 25
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw p0

    .line 29
    :cond_1
    :goto_0
    return-wide p0

    .line 30
    :cond_2
    invoke-static {p2, p3}, LTf/c;->e(J)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_3

    .line 35
    .line 36
    return-wide p2

    .line 37
    :cond_3
    long-to-int v0, p0

    .line 38
    const/4 v1, 0x1

    .line 39
    and-int/2addr v0, v1

    .line 40
    long-to-int v2, p2

    .line 41
    and-int/2addr v2, v1

    .line 42
    if-ne v0, v2, :cond_6

    .line 43
    .line 44
    shr-long/2addr p0, v1

    .line 45
    shr-long/2addr p2, v1

    .line 46
    add-long/2addr p0, p2

    .line 47
    if-nez v0, :cond_5

    .line 48
    .line 49
    const-wide p2, -0x3ffffffffffa14bfL    # -2.0000000001722644

    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    cmp-long p2, p2, p0

    .line 55
    .line 56
    if-gtz p2, :cond_4

    .line 57
    .line 58
    const-wide p2, 0x3ffffffffffa14c0L    # 1.999999999913868

    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    cmp-long p2, p0, p2

    .line 64
    .line 65
    if-gez p2, :cond_4

    .line 66
    .line 67
    invoke-static {p0, p1}, LE/c;->q(J)J

    .line 68
    .line 69
    .line 70
    move-result-wide p0

    .line 71
    return-wide p0

    .line 72
    :cond_4
    const p2, 0xf4240

    .line 73
    .line 74
    .line 75
    int-to-long p2, p2

    .line 76
    div-long/2addr p0, p2

    .line 77
    invoke-static {p0, p1}, LE/c;->o(J)J

    .line 78
    .line 79
    .line 80
    move-result-wide p0

    .line 81
    return-wide p0

    .line 82
    :cond_5
    invoke-static {p0, p1}, LE/c;->p(J)J

    .line 83
    .line 84
    .line 85
    move-result-wide p0

    .line 86
    return-wide p0

    .line 87
    :cond_6
    if-ne v0, v1, :cond_7

    .line 88
    .line 89
    shr-long/2addr p0, v1

    .line 90
    shr-long/2addr p2, v1

    .line 91
    invoke-static {p0, p1, p2, p3}, LTf/c;->a(JJ)J

    .line 92
    .line 93
    .line 94
    move-result-wide p0

    .line 95
    return-wide p0

    .line 96
    :cond_7
    shr-long/2addr p2, v1

    .line 97
    shr-long/2addr p0, v1

    .line 98
    invoke-static {p2, p3, p0, p1}, LTf/c;->a(JJ)J

    .line 99
    .line 100
    .line 101
    move-result-wide p0

    .line 102
    return-wide p0
.end method

.method public static final h(JLTf/e;)J
    .locals 3

    .line 1
    const-string v0, "unit"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-wide v0, LTf/c;->c:J

    .line 7
    .line 8
    cmp-long v0, p0, v0

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    const-wide p0, 0x7fffffffffffffffL

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    return-wide p0

    .line 18
    :cond_0
    sget-wide v0, LTf/c;->d:J

    .line 19
    .line 20
    cmp-long v0, p0, v0

    .line 21
    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    const-wide/high16 p0, -0x8000000000000000L

    .line 25
    .line 26
    return-wide p0

    .line 27
    :cond_1
    const/4 v0, 0x1

    .line 28
    shr-long v1, p0, v0

    .line 29
    .line 30
    long-to-int p0, p0

    .line 31
    and-int/2addr p0, v0

    .line 32
    if-nez p0, :cond_2

    .line 33
    .line 34
    sget-object p0, LTf/e;->b:LTf/e;

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_2
    sget-object p0, LTf/e;->d:LTf/e;

    .line 38
    .line 39
    :goto_0
    invoke-static {v1, v2, p0, p2}, LTf/f;->b(JLTf/e;LTf/e;)J

    .line 40
    .line 41
    .line 42
    move-result-wide p0

    .line 43
    return-wide p0
.end method

.method public static final i(J)J
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    shr-long v1, p0, v0

    .line 3
    .line 4
    neg-long v1, v1

    .line 5
    long-to-int p0, p0

    .line 6
    and-int/2addr p0, v0

    .line 7
    shl-long v0, v1, v0

    .line 8
    .line 9
    int-to-long p0, p0

    .line 10
    add-long/2addr v0, p0

    .line 11
    sget p0, LTf/d;->a:I

    .line 12
    .line 13
    return-wide v0
.end method


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .locals 4

    .line 1
    check-cast p1, LTf/c;

    .line 2
    .line 3
    iget-wide v0, p1, LTf/c;->a:J

    .line 4
    .line 5
    iget-wide v2, p0, LTf/c;->a:J

    .line 6
    .line 7
    invoke-static {v2, v3, v0, v1}, LTf/c;->c(JJ)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    instance-of v0, p1, LTf/c;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    check-cast p1, LTf/c;

    .line 7
    .line 8
    iget-wide v0, p1, LTf/c;->a:J

    .line 9
    .line 10
    iget-wide v2, p0, LTf/c;->a:J

    .line 11
    .line 12
    cmp-long p1, v2, v0

    .line 13
    .line 14
    if-eqz p1, :cond_1

    .line 15
    .line 16
    :goto_0
    const/4 p1, 0x0

    .line 17
    return p1

    .line 18
    :cond_1
    const/4 p1, 0x1

    .line 19
    return p1
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-wide v0, p0, LTf/c;->a:J

    .line 2
    .line 3
    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-wide v1, v0, LTf/c;->a:J

    .line 4
    .line 5
    const-wide/16 v3, 0x0

    .line 6
    .line 7
    cmp-long v5, v1, v3

    .line 8
    .line 9
    if-nez v5, :cond_0

    .line 10
    .line 11
    const-string v1, "0s"

    .line 12
    .line 13
    return-object v1

    .line 14
    :cond_0
    sget-wide v5, LTf/c;->c:J

    .line 15
    .line 16
    cmp-long v5, v1, v5

    .line 17
    .line 18
    if-nez v5, :cond_1

    .line 19
    .line 20
    const-string v1, "Infinity"

    .line 21
    .line 22
    return-object v1

    .line 23
    :cond_1
    sget-wide v5, LTf/c;->d:J

    .line 24
    .line 25
    cmp-long v5, v1, v5

    .line 26
    .line 27
    if-nez v5, :cond_2

    .line 28
    .line 29
    const-string v1, "-Infinity"

    .line 30
    .line 31
    return-object v1

    .line 32
    :cond_2
    invoke-static {v1, v2}, LTf/c;->f(J)Z

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    new-instance v6, Ljava/lang/StringBuilder;

    .line 37
    .line 38
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 39
    .line 40
    .line 41
    if-eqz v5, :cond_3

    .line 42
    .line 43
    const/16 v7, 0x2d

    .line 44
    .line 45
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    :cond_3
    invoke-static {v1, v2}, LTf/c;->f(J)Z

    .line 49
    .line 50
    .line 51
    move-result v7

    .line 52
    if-eqz v7, :cond_4

    .line 53
    .line 54
    invoke-static {v1, v2}, LTf/c;->i(J)J

    .line 55
    .line 56
    .line 57
    move-result-wide v1

    .line 58
    :cond_4
    sget-object v7, LTf/e;->i:LTf/e;

    .line 59
    .line 60
    invoke-static {v1, v2, v7}, LTf/c;->h(JLTf/e;)J

    .line 61
    .line 62
    .line 63
    move-result-wide v7

    .line 64
    invoke-static {v1, v2}, LTf/c;->e(J)Z

    .line 65
    .line 66
    .line 67
    move-result v9

    .line 68
    const/4 v10, 0x0

    .line 69
    if-eqz v9, :cond_5

    .line 70
    .line 71
    move v9, v10

    .line 72
    goto :goto_0

    .line 73
    :cond_5
    sget-object v9, LTf/e;->g:LTf/e;

    .line 74
    .line 75
    invoke-static {v1, v2, v9}, LTf/c;->h(JLTf/e;)J

    .line 76
    .line 77
    .line 78
    move-result-wide v11

    .line 79
    const/16 v9, 0x18

    .line 80
    .line 81
    int-to-long v13, v9

    .line 82
    rem-long/2addr v11, v13

    .line 83
    long-to-int v9, v11

    .line 84
    :goto_0
    invoke-static {v1, v2}, LTf/c;->e(J)Z

    .line 85
    .line 86
    .line 87
    move-result v11

    .line 88
    const/16 v12, 0x3c

    .line 89
    .line 90
    if-eqz v11, :cond_6

    .line 91
    .line 92
    move-wide v15, v3

    .line 93
    move v3, v10

    .line 94
    goto :goto_1

    .line 95
    :cond_6
    sget-object v11, LTf/e;->f:LTf/e;

    .line 96
    .line 97
    invoke-static {v1, v2, v11}, LTf/c;->h(JLTf/e;)J

    .line 98
    .line 99
    .line 100
    move-result-wide v13

    .line 101
    move-wide v15, v3

    .line 102
    int-to-long v3, v12

    .line 103
    rem-long/2addr v13, v3

    .line 104
    long-to-int v3, v13

    .line 105
    :goto_1
    invoke-static {v1, v2}, LTf/c;->e(J)Z

    .line 106
    .line 107
    .line 108
    move-result v4

    .line 109
    if-eqz v4, :cond_7

    .line 110
    .line 111
    move v4, v10

    .line 112
    goto :goto_2

    .line 113
    :cond_7
    sget-object v4, LTf/e;->e:LTf/e;

    .line 114
    .line 115
    invoke-static {v1, v2, v4}, LTf/c;->h(JLTf/e;)J

    .line 116
    .line 117
    .line 118
    move-result-wide v13

    .line 119
    int-to-long v11, v12

    .line 120
    rem-long/2addr v13, v11

    .line 121
    long-to-int v4, v13

    .line 122
    :goto_2
    invoke-static {v1, v2}, LTf/c;->d(J)I

    .line 123
    .line 124
    .line 125
    move-result v1

    .line 126
    cmp-long v2, v7, v15

    .line 127
    .line 128
    const/4 v12, 0x1

    .line 129
    if-eqz v2, :cond_8

    .line 130
    .line 131
    move v2, v12

    .line 132
    goto :goto_3

    .line 133
    :cond_8
    move v2, v10

    .line 134
    :goto_3
    if-eqz v9, :cond_9

    .line 135
    .line 136
    move v11, v12

    .line 137
    goto :goto_4

    .line 138
    :cond_9
    move v11, v10

    .line 139
    :goto_4
    if-eqz v3, :cond_a

    .line 140
    .line 141
    move v13, v12

    .line 142
    goto :goto_5

    .line 143
    :cond_a
    move v13, v10

    .line 144
    :goto_5
    if-nez v4, :cond_c

    .line 145
    .line 146
    if-eqz v1, :cond_b

    .line 147
    .line 148
    goto :goto_6

    .line 149
    :cond_b
    move v14, v10

    .line 150
    goto :goto_7

    .line 151
    :cond_c
    :goto_6
    move v14, v12

    .line 152
    :goto_7
    if-eqz v2, :cond_d

    .line 153
    .line 154
    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    const/16 v7, 0x64

    .line 158
    .line 159
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 160
    .line 161
    .line 162
    move v10, v12

    .line 163
    :cond_d
    const/16 v7, 0x20

    .line 164
    .line 165
    if-nez v11, :cond_e

    .line 166
    .line 167
    if-eqz v2, :cond_10

    .line 168
    .line 169
    if-nez v13, :cond_e

    .line 170
    .line 171
    if-eqz v14, :cond_10

    .line 172
    .line 173
    :cond_e
    add-int/lit8 v8, v10, 0x1

    .line 174
    .line 175
    if-lez v10, :cond_f

    .line 176
    .line 177
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    :cond_f
    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    const/16 v9, 0x68

    .line 184
    .line 185
    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    move v10, v8

    .line 189
    :cond_10
    if-nez v13, :cond_11

    .line 190
    .line 191
    if-eqz v14, :cond_13

    .line 192
    .line 193
    if-nez v11, :cond_11

    .line 194
    .line 195
    if-eqz v2, :cond_13

    .line 196
    .line 197
    :cond_11
    add-int/lit8 v8, v10, 0x1

    .line 198
    .line 199
    if-lez v10, :cond_12

    .line 200
    .line 201
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 202
    .line 203
    .line 204
    :cond_12
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 205
    .line 206
    .line 207
    const/16 v3, 0x6d

    .line 208
    .line 209
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    move v10, v8

    .line 213
    :cond_13
    if-eqz v14, :cond_19

    .line 214
    .line 215
    add-int/lit8 v3, v10, 0x1

    .line 216
    .line 217
    if-lez v10, :cond_14

    .line 218
    .line 219
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 220
    .line 221
    .line 222
    :cond_14
    if-nez v4, :cond_18

    .line 223
    .line 224
    if-nez v2, :cond_18

    .line 225
    .line 226
    if-nez v11, :cond_18

    .line 227
    .line 228
    if-eqz v13, :cond_15

    .line 229
    .line 230
    goto :goto_8

    .line 231
    :cond_15
    const v2, 0xf4240

    .line 232
    .line 233
    .line 234
    if-lt v1, v2, :cond_16

    .line 235
    .line 236
    div-int v7, v1, v2

    .line 237
    .line 238
    rem-int v8, v1, v2

    .line 239
    .line 240
    const/4 v9, 0x6

    .line 241
    const-string v10, "ms"

    .line 242
    .line 243
    const/4 v11, 0x0

    .line 244
    invoke-static/range {v6 .. v11}, LTf/c;->b(Ljava/lang/StringBuilder;IIILjava/lang/String;Z)V

    .line 245
    .line 246
    .line 247
    goto :goto_9

    .line 248
    :cond_16
    const/16 v2, 0x3e8

    .line 249
    .line 250
    if-lt v1, v2, :cond_17

    .line 251
    .line 252
    div-int/lit16 v7, v1, 0x3e8

    .line 253
    .line 254
    rem-int/lit16 v8, v1, 0x3e8

    .line 255
    .line 256
    const/4 v9, 0x3

    .line 257
    const-string v10, "us"

    .line 258
    .line 259
    const/4 v11, 0x0

    .line 260
    invoke-static/range {v6 .. v11}, LTf/c;->b(Ljava/lang/StringBuilder;IIILjava/lang/String;Z)V

    .line 261
    .line 262
    .line 263
    goto :goto_9

    .line 264
    :cond_17
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 265
    .line 266
    .line 267
    const-string v1, "ns"

    .line 268
    .line 269
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 270
    .line 271
    .line 272
    goto :goto_9

    .line 273
    :cond_18
    :goto_8
    const/16 v9, 0x9

    .line 274
    .line 275
    const-string v10, "s"

    .line 276
    .line 277
    const/4 v11, 0x0

    .line 278
    move v8, v1

    .line 279
    move v7, v4

    .line 280
    invoke-static/range {v6 .. v11}, LTf/c;->b(Ljava/lang/StringBuilder;IIILjava/lang/String;Z)V

    .line 281
    .line 282
    .line 283
    :goto_9
    move v10, v3

    .line 284
    :cond_19
    if-eqz v5, :cond_1a

    .line 285
    .line 286
    if-le v10, v12, :cond_1a

    .line 287
    .line 288
    const/16 v1, 0x28

    .line 289
    .line 290
    invoke-virtual {v6, v12, v1}, Ljava/lang/StringBuilder;->insert(IC)Ljava/lang/StringBuilder;

    .line 291
    .line 292
    .line 293
    move-result-object v1

    .line 294
    const/16 v2, 0x29

    .line 295
    .line 296
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 297
    .line 298
    .line 299
    :cond_1a
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object v1

    .line 303
    return-object v1
.end method
