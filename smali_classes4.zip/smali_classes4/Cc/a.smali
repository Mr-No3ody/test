.class public abstract LCc/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lm6/j;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lm6/j;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, v1}, Lm6/j;-><init>(I)V

    .line 5
    .line 6
    .line 7
    invoke-static {}, Lva/e;->a()Lva/e;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    iget-object v1, v1, Lva/e;->a:Lretrofit2/N;

    .line 12
    .line 13
    const-class v2, Lcom/transsnet/palmpay/main/export/business/IApiMainService;

    .line 14
    .line 15
    invoke-virtual {v1, v2}, Lretrofit2/N;->b(Ljava/lang/Class;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Lcom/transsnet/palmpay/main/export/business/IApiMainService;

    .line 20
    .line 21
    iput-object v1, v0, Lm6/j;->b:Ljava/lang/Object;

    .line 22
    .line 23
    sput-object v0, LCc/a;->a:Lm6/j;

    .line 24
    .line 25
    return-void
.end method
