.class final Lcom/google/firebase/perf/config/ConfigurationConstants;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/firebase/perf/config/ConfigurationConstants$ExperimentTTID;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$FragmentSamplingRate;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$LogSourceName;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$SessionsSamplingRate;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$RateLimitSec;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$NetworkEventCountBackground;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$NetworkEventCountForeground;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$TraceEventCountBackground;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$TraceEventCountForeground;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$SessionsMaxDurationMinutes;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$SessionsMemoryCaptureFrequencyBackgroundMs;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$SessionsMemoryCaptureFrequencyForegroundMs;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$SessionsCpuCaptureFrequencyBackgroundMs;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$SessionsCpuCaptureFrequencyForegroundMs;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$NetworkRequestSamplingRate;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$TraceSamplingRate;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$SdkDisabledVersions;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$SdkEnabled;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$CollectionEnabled;,
        Lcom/google/firebase/perf/config/ConfigurationConstants$CollectionDeactivated;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
